
CREATE PROCEDURE [dbo].[SetClientSecret]
@ClientSecret nvarchar (260)
AS

UPDATE [dbo].[ConfigurationInfo]
SET [Value] = @ClientSecret
WHERE [Name] = 'ClientSecret'
GO
