
create procedure ts_w_canmodify
(@tablename  varchar(20),
 @nid          int=0
)
AS
/*Params Ini begin*/
if @nid is null  SET @nid = 0
/*Params Ini end*/
declare @nRet int
set @nRet = 0

if @tablename='employees'
begin
   if exists(select * from employees where emp_id= @nid and Y_ID =0)
      set @nRet = 0
   else   
   if exists ( select * from billidx where e_id=@nid) 
     set @nRet =-1      
end

if @tablename='storages'
begin
   if exists(select * from storages where storage_id= @nid and Y_ID =0)
      set @nRet = 0 
   else 
   if exists ( select * from storehouse where s_id=@nid)
      or exists (select * from storehouseini where s_id=@nid)
      set @nRet =-1
   
end

return @nRet
GO
