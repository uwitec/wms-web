create procedure ts_e_VipCardSumarry
  @BeginDate DateTime, /*开始时间*/
  @EndDate DateTime, /*结束时间*/
  @GroupType Int = -1, /*汇总条件 -1：无；0：机构Y_ID； 1：发卡人E_ID； 2：推荐人；3会员卡类型*/

  @AgeCheck       int = 0,/*年龄   0：没选中否则就是选中*/
  @GuestAgeCheck  int = 0,/*客龄   0：没选中否则就是选中*/
  @SexCheck       int = 0,/*性别   0：没选中否则就是选中*/
   
  @ProductGroupCheckd int=0, /*判断商品类别是否被勾中*/
  @ProductGroupClssid varchar(100),/*-商品类别ClassId*/
  @ProductsGroupRange  int=-1,/*类别范围 0：大，1中，2小 ，默认无-1*/
  
  @TimeChecked Int = 0, /*是否时间段汇总，默认否0*/
  @TimeRange Int = -1,   /*时间段范围，0：日，1：月2：季度，默认无-1*/
  @nloginEID int = 0     /*当前职员  */
  
as
begin

  Declare @Companytable INTEGER
  create table #Companytable([id] int)

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权 */
  
    DECLARE @PColName VARCHAR(100)
    SET @PColName = ''
    CREATE TABLE #TmpP (
    [class_id] [varchar](100) NOT NULL DEFAULT(''),    
    [baseinfo_id] [int] NOT NULL DEFAULT(0),
    [id] [int]  NOT NULL DEFAULT(0),
    [name] [varchar](200) NOT NULL DEFAULT('')
    )
    IF @ProductGroupCheckd = 0
      INSERT INTO #TmpP(class_id,baseinfo_id,id,name) 
      SELECT '',product_id,0,'' FROM products WHERE deleted = 0 AND class_id <> '000000' 
    ELSE
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id FROM customCategory WHERE class_id  = @ProductGroupClssid    
      SET @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')
      SET @PszSql = ' INSERT INTO #TmpP(class_id,baseinfo_id,id,name) '
                + ' select isnull(cc.class_id,''''),p.product_id as baseinfo_id,isnull(cc.id,0),isnull(cc.name,'''') from products p ' 
                + ' left join ProductCategory pc on p.product_id = pc.P_id '
                + ' left join customCategory cc on pc.' + @PColName + ' = cc.class_id where  left(pc.' + @PColName + ',2) like ''' + @ProductGroupClssid + '%'''
	  EXEC (@PszSql)        
    END

	select ad.*, 
	/*dbo.GetAge(vv.Birthday, getdate()) as age, */
	CASE WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 18 THEN '18岁以下'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 25 THEN '18-25'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 30 THEN '25-30'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 35 THEN '30-35'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 40 THEN '35-40'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 45 THEN '40-45'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 50 THEN '45-50'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 55 THEN '50-55'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 60 THEN '55-60'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 65 THEN '60-65'
	WHEN DATEDIFF(YEAR, VV.Birthday, GETDATE()) < 70 THEN '65-70'
	ELSE '70岁以上'
	END AS AGE,
	vv.CT_ID, vt.Name, 
	/*DATEDIFF(mm, vv.buliddate, getdate()) as guestAge, */
	CASE WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 3 THEN '3个月以下'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 6 THEN '3-6个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 12 THEN '6-12个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 24 THEN '12-24个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 36 THEN '24-36个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 48 THEN '36-48个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 60 THEN '48-60个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 72 THEN '60-72个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 84 THEN '72-84个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 96 THEN '84-96个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 108 THEN '96-108个月'
	WHEN DATEDIFF(MONTH, VV.buliddate, GETDATE()) < 120 THEN '108-120个月'
	ELSE '120个月以上'
	END AS guestAge,
	vv.sex, vv.E_id, ee.name as inputman, y.name as yname, total - cost as ml,
	viptotal - vipcost as vml, 
	case @TimeRange when 0 then convert(varchar(10), ad.BulidDate, 120) 
		when 1 then convert(varchar(7), ad.BulidDate, 120) 
		else cast(DATEPART(yyyy, ad.BulidDate) as varchar(4)) + '年' + cast(DATEPART(qq, ad.BulidDate) as varchar(4)) + '季度' end as TimeRange
	into #tmp
	from
	(
	  select av.*, d.new, d.newValid, d.valid, 0 as Total, 0 as cost, 0 as viptotal, 0 as vipcost,
	         0 as VCount, 0 as GCount, 0 as pid, 0 as cusid, '' as cusname, e.sleep
	         from
	          (
	            select 1 as vipcount, BulidDate, y_id, vipcardid from VIPCard where Y_ID > 0 and E_id > 0
	          ) av
	          left join
	         (
	              select a.VIPCardID, b.new, c.valid, b.new & c.valid as newValid, c.VCount from
	                    (
	                       select VIPCardID from VIPCard where BulidDate between @BeginDate and @EndDate
	                       and Y_ID > 0 and E_id > 0
	                       union
	                       select VIPCardID from billidx where billstates = 0 and billtype = 12 
	                             and billdate between @BeginDate and @EndDate and VIPCardID > 0
	                    ) a
	                left join
	                (
	                      SELECT   VIPCardID, Y_ID, 1 as new
					 FROM      dbo.VIPCard
					 WHERE   (E_id > 0) AND (Y_ID > 0) AND (BulidDate BETWEEN @BeginDate AND @EndDate)
					 )b  on a.VIPCardID = b.VIPCardID
	                 left join
	                (
	                    SELECT   i.VIPCardID, 1 as valid, COUNT(billid) as VCount
								 FROM      dbo.VIPCard v
								 inner join billidx i
								 on v.VIPCardID = i.VIPCardID
								 where billstates = 0 and billtype = 12
								  and billdate between @BeginDate and @EndDate and i.VIPCardID > 0
	                              and v.E_id > 0 and v.Y_ID > 0
					              group by i.VIPCardID
	                ) c on a.VIPCardID = c.VIPCardID
            ) d on av.VIPCardID = d.VIPCardID
	       left join
	       (
	          select distinct VIPCardID, 0 as sleep from billidx where BillStates = 0 and billtype = 12
	                and billdate >= getdate() - 60
	        ) e  on av.VIPCardID = e.VIPCardID

    union all
    select 0,cxf.billdate as  billdate,
    cxf.Y_ID as  Y_ID, cxf.VIPCardID as  VIPCardID, 0, 0, 0,sum(taxtotal*dix) as total, 
    sum(costtaxtotal*dix) as costtaxtotal,
	sum(case when VIPCardID <> 0 and E_id > 0 and Y_ID > 0 then taxtotal*dix else 0 end),
	sum(case when VIPCardID <> 0 and E_id > 0 and Y_ID > 0 then costtaxtotal*dix  else 0 end),
	0,
	0,
	cxf.p_id as p_id,
	cxf.id as  id,
	cxf.name as  name,
	0
	from 
	(
		select i.billdate, i.Y_ID, i.VIPCardID, taxtotal as taxtotal, 
		costtaxtotal,
		v.e_id,
		sb.p_id,
		cx.id,
		cx.name,
		/*zjx-tfs41914-2016-10-18-处理销售金额减去零售退货退货*/
		case when billtype in(12)  then 1 when billtype in(13) then  -1  End as dix 
		from
		billidx i inner join
		salemanagebill sb
		on i.billid = sb.bill_id
		left join VIPCard v
		on i.VIPCardID = v.VIPCardID
		left join
		(
			   select * from
				(
					select c.name, c.baseinfo_id, c.id, case when len(class_id) > 6 then 3 when len(class_id) > 4 then 2 else 1 end as lv from
					 #TmpP c where class_id like @ProductGroupClssid + '%'
				) pp  where lv = @ProductsGroupRange + 1
		) cx on p_id = cx.baseinfo_id
		where billdate between @BeginDate and @EndDate
		and billstates = 0 
		and billtype in(12,13)
		and p_id > 0
	/*	and ((@Companytable=0)or (sb.Y_ID in (select [id] from #Companytable)))   --暂时不增加权限判断，等产品部的讨论结果*/
		
   ) cxf group by VIPCardID, Y_ID, billdate, p_id, id, name
    union all
    /*zjx--tfs46149---2017-03-07--计算会员卡的客流量*/
	SELECT   0,'',i.Y_ID,0,0,0,0,0,
	         0,
	         0,
	         0,
	         COUNT(billid) as VCount,
	         0,
	         0,
			 0,
		 	 '',
			 0
	          FROM      dbo.VIPCard v
								 inner join billidx i
								 on v.VIPCardID = i.VIPCardID
								 where billstates = 0 and billtype = 12
								  and billdate between @BeginDate and @EndDate and i.VIPCardID > 0
	                              and v.E_id > 0 and v.Y_ID > 0
					              group by i.Y_ID
	union all
	select 0, i.billdate, i.Y_ID, i.VIPCardID, 0, 0, 0, 0,
	0,
	0,
	0,
	0,
	COUNT(billid),
	0,
	0,
	'',
	0
	from billidx i
	where billdate between @BeginDate and @EndDate
	and billstates = 0 
	and billtype = 12
	group by i.VIPCardID, i.Y_ID, i.billdate
 )  ad   left join VIPCard vv  on ad.VIPCardID = vv.VIPCardID
	     left join VIPCardType vt on vv.CT_ID = vt.ct_id
	     left join employees ee on vv.E_id = ee.emp_id
	     left join company y  on ad.Y_ID = y.company_id

	declare @sSum varchar(8000)
	declare @sSelect varchar(8000)
	declare @sGroup nvarchar(4000)
	declare @Where  nvarchar(4000)
	declare @sBody varchar(8000)

	set @sSum = 'declare @vipAllSale NUMERIC(25,8)
		select @vipAllSale = sum(viptotal) from #tmp ' 

	set @sBody = ' sum(vipcount) as SumVipCardNum, sum(new) as NewAddVipCardNum, sum(valid) as ValidVipCardNum,
					sum(newvalid) as NewAddValidVipCardNum, sum(isnull(sleep, 1)) as SleepVipCardNum, cast(sum(valid) as NUMERIC(25,8)) / nullif(sum(vipcount), 0) * 100 as ValidVipCardZb,
					sum(total) as SaleTotal, sum(viptotal) as VipSaleTotal, sum(viptotal) / nullif(sum(total), 0) * 100 as VipSaleZb,
					sum(viptotal) / nullif(@vipAllSale, 0) * 100 as VipSaleYZb, sum(gcount) as GuestNum,
					sum(total) / nullif(sum(gcount), 0) as GuestPrice, sum(VCount) as VipCardGuestNum,
					sum(viptotal) / nullif(sum(VCount), 0) as VipCardGuestPrice,
					cast(sum(vcount) as NUMERIC(25,8)) / nullif(sum(gcount), 0) * 100 as VipCardGuestNumZb,
					sum(ml) as ML, sum(vml) as VipCardML, sum(vml) / nullif(sum(ml), 0) * 100 as VipCardMLZb,
					sum(ml) / nullif(sum(total), 0) * 100 as MLV, sum(vml) / nullif(sum(viptotal), 0) * 100 as VipCardMLV
				from #tmp '
	set @sSelect = 'select '
	set @sGroup = ' group by '

	/*if @GroupType = -1*/
	/*begin*/
	/*	exec (@sSum + @sSelect + @sBody)*/
	/*end*/
	/*else*/
	begin
		if @GroupType = 0
		begin
			set @sSelect = @sSelect + 'Y_ID, yname, '
			set @sGroup = @sGroup + 'Y_ID, yname, '			
		end
		else
		if @GroupType = 1
		begin
			set @sSelect = @sSelect + 'E_ID, inputman as OpenEName, '
			set @sGroup = @sGroup + 'E_ID, inputman, '
		end
		else
		if @GroupType = 2
		begin
			set @sSelect = @sSelect + 'E_ID, inputman as OpenEName, '
			set @sGroup = @sGroup + 'E_ID, inputman, '
		end
		else
		if @GroupType = 3
		begin
			set @sSelect = @sSelect + 'CT_ID, Name as CardTypeName, '
			set @sGroup = @sGroup + 'CT_ID, Name, '
		end
		if @TimeChecked > 0
		begin
			set @sSelect = @sSelect + 'TimeRange as YtimeType, '
			set @sGroup = @sGroup + 'TimeRange, '
		end
		if @AgeCheck > 0
		begin
			set @sSelect = @sSelect + 'Age, '
			set @sGroup = @sGroup + 'Age, '
		end
		if @GuestAgeCheck > 0
		begin
			set @sSelect = @sSelect + 'GuestAge, '
			set @sGroup = @sGroup + 'GuestAge, '
		end
		if @SexCheck > 0
		begin
			set @sSelect = @sSelect + 'Sex, '
			set @sGroup = @sGroup + 'Sex, '
		end
		set @sGroup = SUBSTRING(@sGroup, 1, LEN(@sGroup) - 1)
		if LEN(@sGroup) < 10
			set @sGroup = ''
		if @GroupType = 0 and @TimeChecked = 0
		begin
		  declare @vipAllSale NUMERIC(25,8)
		         select @vipAllSale = sum(viptotal) from #tmp select Y_ID, yname,  sum(vipcount) as SumVipCardNum, sum(new) as NewAddVipCardNum, sum(valid) as ValidVipCardNum,
					sum(newvalid) as NewAddValidVipCardNum, sum(isnull(sleep, 1)) as SleepVipCardNum, cast(sum(valid) as NUMERIC(25,8)) / nullif(sum(vipcount), 0) * 100 as ValidVipCardZb,
					sum(total) as SaleTotal, sum(viptotal) as VipSaleTotal, sum(viptotal) / nullif(sum(total), 0) * 100 as VipSaleZb,
					sum(viptotal) / nullif(@vipAllSale, 0) * 100 as VipSaleYZb, sum(gcount) as GuestNum,
					sum(total) / nullif(sum(gcount), 0) as GuestPrice,
					sum(viptotal) / nullif(sum(VCount), 0) as VipCardGuestPrice,
					cast(sum(vcount) as NUMERIC(25,8)) / nullif(sum(gcount), 0) * 100 as VipCardGuestNumZb,
					sum(ml) as ML, sum(vml) as VipCardML, sum(vml) / nullif(sum(ml), 0) * 100 as VipCardMLZb,
					sum(ml) / nullif(sum(total), 0) * 100 as MLV, sum(vml) / nullif(sum(viptotal), 0) * 100 as VipCardMLV
			    into #a	from #tmp  group by Y_ID, yname
				select a.*,b.VCount as VipCardGuestNum from  #a a left join
				(select COUNT(billid) as VCount,Y_ID from billidx 
                where billstates=0 and billdate between @BeginDate and @EndDate and billtype = 12
                and VIPCardID>0
                group by Y_ID 
				) b on a.Y_ID = b.Y_ID				
				goto SUCCEE
		end	
		else
		begin
		   if @GroupType=3
	       begin
	        set @Where=' where ct_id>0 '
	       	exec (@sSum + @sSelect + @sBody +@Where + @sGroup)
	       end
	       else
	       begin
		    exec (@sSum + @sSelect + @sBody + @sGroup)
		   end
		end
	end

SUCCEE:
  RETURN 0	
	
	drop table #tmp
	
	IF object_id(N'#a', N'U') is not null 
	drop table #a
end
GO
