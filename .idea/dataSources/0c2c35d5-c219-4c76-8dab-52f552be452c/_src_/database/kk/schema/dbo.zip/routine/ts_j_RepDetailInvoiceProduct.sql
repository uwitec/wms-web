

CREATE	 PROCEDURE [ts_j_RepDetailInvoiceProduct]
	(
	 @nC_ID           VARCHAR(30)='',
 	 @nP_ID           VARCHAR(30)='',
 	 @nE_ID           VARCHAR(30)='',
 	 @szIClass_ID     VARCHAR(30)='',
	 @nDClass_ID      INT=0,
	 @Billnumber      VARCHAR(255)='',
	 @szComment       VARCHAR(255)='',
	 @nJsFlag	  INT=0, /*０全部　１　已结算　２未结算*/
	 @BeginDate 	  DATETIME=0,
	 @EndDate         DATETIME=0,
	 @StoredProcMode  INT=0,    /*销售　　１采购*/
	 @OperatorID      INT=1,
  	 @szOrderInvoice  VARCHAR(30)='',
         @YClass_id          varchar(30)=''
        )
AS 
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = ''
if @nP_ID is null  SET @nP_ID = ''
if @nE_ID is null  SET @nE_ID = ''
if @szIClass_ID is null  SET @szIClass_ID = ''
if @nDClass_ID is null  SET @nDClass_ID = 0
if @Billnumber is null  SET @Billnumber = ''
if @szComment is null  SET @szComment = ''
if @nJsFlag is null  SET @nJsFlag = 0
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @StoredProcMode is null  SET @StoredProcMode = 0
if @OperatorID is null  SET @OperatorID = 1
if @szOrderInvoice is null  SET @szOrderInvoice = ''
if @YClass_id is null  SET @YClass_id = ''
/*Params Ini end*/

declare  @szBillType VARCHAR(30)
declare @ClientTable  int ,@Companytable int
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/


if @nC_ID <> '' set @nC_ID = @nC_ID + '%'  
if @nP_ID <> '' set @nP_ID = @nP_ID + '%'
if @nE_ID <> '' set @nE_ID = @nE_ID + '%'
if @szIClass_ID <> '' set  @szIClass_ID = @szIClass_ID + '%'
if @Billnumber <>'' set @Billnumber = '%' + @Billnumber + '%'
if @szComment <> '' set @szComment = '%' + @szComment + '%'
if @szOrderInvoice = '' set @szOrderInvoice = '2,3'
if @StoredProcMode = 0 
  set @szBilltype = '10,11,12,13,18,32,112,210,211'  /*销售类*/
else
  set @szBilltype = '20,21,28,35,122,220,221'  /*采购类*/
  
  select billid, 	billtype,	[AuditmanName],		[DepartmentName], 
	 Billdate, 	[AuditDate], 	[Billnumber], 		[CName] AS [Clientname],
       	 [Ename] AS [EmployeeName], 	[InputMan], 		[InputmanName], 	 
         [Note],		[invoice] 
    into #BillTmp
    from vw_x_billidx 
    where Billtype in (select type from dbo.decodestr(@szBilltype)) and
 	  Billstates = 0 and
          (@ClientTable=0 or c_id in (select [id] from #Clienttable)) and
          (@Companytable=0 or Y_id in (select [id] from #Companytable)) and 
          (@YClass_id='' or YClass_id like @YClass_id+'%') and 
 	  (Cclass_id like @nC_ID or @nC_ID = '')and
	  (Eclass_id like @nE_ID or @nE_ID = '')and
	  (inputmanclass_id like @szIClass_ID or @szIClass_ID = '')and
	  (department_id = @nDClass_ID or @nDClass_ID = 0)and 
	  (billnumber like @Billnumber or @Billnumber = '')and
	  (note like @szComment or @szComment = '') and
	  (billdate >= @begindate and billdate < @endDate) and
	  billid not in (select distinct billid from vw_j_invoice where states = 2 and jsflag = 1)

 
create table #ivMXTmp
( p_id int, 		smb_id int,			bill_id int,
  quantity NUMERIC(25,8), 	totalmoney NUMERIC(25,8),		costprice NUMERIC(25,8), 		
  taxtotal NUMERIC(25,8),  	IOTAG int, 		        CostTotal NUMERIC(25,8)
) 
if @StoredProcMode = 0

insert into #ivMXTmp 
   select    p_id, 		smb_id,			bill_id,
	     quantity, 		totalmoney,		costprice, 		taxtotal,
	     IOTAG, 		[Quantity]*[CostPrice] AS [CostTotal]
     from vw_x_salemb
     where bill_id in (select billid from #BillTmp) and
	   (pClass_id like @nP_ID or @nP_ID = '') and aoid in (0,8)
else
insert into #ivMXTmp 
  select     p_id, 		smb_id,			bill_id,
	     quantity, 		totalmoney,		costprice, 		taxtotal,
	     IOTAG, 		[Quantity]*[CostPrice] AS [CostTotal]
     from vw_x_BuyMB  
     where bill_id in (select billid from #BillTmp) and
	   (pClass_id like @nP_ID or @nP_ID = '') and  aoid in (0,8)
  select  billid, smb_id, 
   /*       sum(case invoiceBilltype when 0 then currQuantity else -currQuantity end) OverQty,*/
	  /*sum(case invoiceBilltype when 0 then currTotal else -currTotal end) OverTotal*/
          sum(currQuantity) OverQty,
	  sum(currTotal) OverTotal
    into #IVTmp
    from vw_j_invoice
    where states = 2 and jsFlag=2 and 
	  smb_id in (select smb_id from #ivMXTmp) and
	  billid in (select distinct bill_id from #ivMXTmp) 
    group by billid, smb_id



SELECT   MX.[BillID], 	MX.[Billtype], 		MX.[Billdate], 		MX.[AuditDate], 
         MX.[Billnumber],       MX.[ClientName],MX.[EmployeeName], 	MX.[InputMan], 		MX.[InputmanName], 
         MX.[AuditmanName], 	MX.[DepartmentName], 			MX.[Note], 	
         MX.[CostPrice], 	isnull(iv.OverQty, 0) OverQty, 		isnull(iv.OverTotal, 0) OverTotal,
         CASE MX.[Quantity] WHEN 0 THEN 0.0 ELSE MX.[TotalMoney]/MX.[Quantity] END AS [DiscountPrice],
         CASE MX.[Quantity] WHEN 0 THEN 0.0 ELSE MX.[TaxTotal]/MX.[Quantity] END AS [TaxPrice],
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[Quantity] ELSE MX.[Quantity] END AS [Quantity], 
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[CostTotal] ELSE MX.[CostTotal] END AS [CostTotal], 
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[TotalMoney] ELSE MX.[TotalMoney] END AS [TotalMoney], 
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[TaxTotal] ELSE MX.[TaxTotal] END AS [TaxTotal],
	 CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[NeedQuantity] ELSE MX.[NeedQuantity] END AS [NeedQty], 
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[NeedTotal] ELSE MX.[NeedTotal] END AS [NeedTotal],  
         CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[Quantity] - isnull(iv.OverQty, 0) ELSE MX.[Quantity] - isnull(iv.OverQty, 0)  END AS [noOVerQty],
	 CASE WHEN MX.[Billtype] IN (11,13,21) OR (MX.[Billtype] IN (18,28) AND MX.[IoTag]=0) THEN -MX.[TaxTotal] - isnull(iv.OverTotal,0) ELSE MX.[TaxTotal] - isnull(iv.OverTotal, 0) END AS [noOVerTotal],
	 P.*
from
     (select 
	     bi.*,
	     s.p_id, 		s.smb_id,
	     s.quantity, 	s.totalmoney,		s.costprice, 		s.taxtotal,
	     s.IOTAG, 		s.[CostTotal],
	     case when ov.type is not null then s.Quantity else 0 end as NeedQuantity,
   	     case when ov.type is not null then s.taxTotal else 0 end as NeedTotal 		   
        from #BillTmp bi
 	inner join #ivMXTmp s on bi.billid = s.bill_id  
        left join (select type from dbo.decodestr(@szOrderInvoice)) as OV on bi.invoice = ov.type
     ) mx 
left join #IVTmp  iv       on mx.billid = iv.billid and mx.smb_id = iv.smb_id
left join  VW_X_Products p on mx.p_id = p.product_id
where   (@nJsFlag = 0) or 
        (@nJsFlag = 1 and abs(abs(mx.quantity)-abs(isnull(iv.Overqty, 0))) < 0.0001) or
	(@nJsFlag = 2 and abs(abs(mx.quantity)-abs(isnull(iv.Overqty, 0))) > 0.0001)
order by mx.billdate, mx.billid 

drop table #BillTmp
drop table #ivMXTmp
drop table #IVTmp
GO
