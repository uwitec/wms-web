/************************************************************

--功能：更新往来单位证照   
--创建人：zfl

**************************************************************/

CREATE	 PROCEDURE [ts_UpdateClientReport2]
	(     
	      @flag int, /*标示是新增还是修改*/
          @C_ID int =0,
          @rpn_id int,
          @repNo varchar(100),
          @validtime datetime,
          @inputTime datetime,
          @pathname varchar(120),
          @ctype int
        )
AS 
   /* if @repNo = ''*/
    
	if @C_ID < 0
	begin
		exec ts_UpdateClientReport2_His @flag,
			@C_ID,
			@rpn_id,
			@repNo,
			@validtime,
			@inputTime,
			@pathname,
			@ctype
	end
	else
	begin
		if exists(select 1 from ClientReport2 where c_id = @C_ID and rpn_id = @rpn_id and ctype=@ctype)
		begin /*修改*/
			update ClientReport2 
			set repNo = @repNo,
			   /* inputTime = @inputTime,*/
				validtime = @validtime,
				Pathname =  @pathname
			where c_id = @C_ID and rpn_id = @rpn_id and ctype=@ctype 
		end
		else
		begin /*添加*/
				insert into ClientReport2(repNo, c_id, inputTime, validTime, rpn_id, Pathname, ctype)
				values(@repNo,@C_ID,@inputTime,@validtime,@rpn_id,@pathname, @ctype)
		end
	end
GO
