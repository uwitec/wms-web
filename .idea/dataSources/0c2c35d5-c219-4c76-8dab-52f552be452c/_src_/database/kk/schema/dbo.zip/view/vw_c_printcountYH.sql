
/*处理拣货单、销售订单*/
CREATE VIEW dbo.vw_c_printcountYH
AS
SELECT Rep_ID, COUNT(Rep_ID) AS printcount,nflag
FROM dbo.PrintDetail
GROUP BY Rep_ID,nflag
GO
