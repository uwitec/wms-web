


CREATE PROCEDURE ts_b_GetGspLimDefaultName
(
@nGspLim int,
@szRet varchar(20) out
)
/*with encryption*/
 AS
SET @szRet = ''
SELECT @szRet = ename FROM gspaudit WHERE GSP_AuditLimit = @nGspLim
GO
