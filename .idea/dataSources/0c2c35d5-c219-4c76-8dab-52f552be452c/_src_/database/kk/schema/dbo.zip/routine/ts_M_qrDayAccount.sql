

CREATE	 PROCEDURE ts_M_qrDayAccount 
(   @nFlag int =0,
	@Y_ID	int=0,
	@BeginDate datetime=0,
	@EndDate datetime=0,
	@nQrMode int=0
)
AS
/*Params Ini begin*/
if @nFlag is null  SET @nFlag = 0
if @Y_ID is null  SET @Y_ID = 0
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nQrMode is null  SET @nQrMode = 0
/*Params Ini end*/

if @nflag = 0 goto posdata
else if @nflag = 1 goto zbdata

posdata:
    /*门店日结查询*/
declare @minDate datetime, @maxDate datetime, @nDBY_ID int, @szYName varchar(100)
select @minDate = max(enddate)+0.0001 from dayaccount
select @MaxDate = getdate()
if @minDate is null
 set @minDate = cast(cast(@maxDate as varchar(10)) as datetime)
select @nDBY_ID = cast(sysvalue as int) from sysconfig where [sysname] = 'Y_ID' 
select @szYname = [name] from company where company_id = @nDBY_ID


select * from
       (
	SELECT b.*,
	[AllPosRetailQty]=(b.PosRetailQty - b.PosBackQty),
	[AllPosRetailTotal]=(b.PosRetailTotal - b.PosBackTotal),
	[AllZBRetailQty]=(b.ZBRetailQty - b.ZBBackQty),
	[AllZBRetailTotal]=(b.ZBRetailTotal - b.ZBBackTotal)
	FROM 
	(
		SELECT 
		DA.[id],DA.[Y_ID],YName=Y.[Name],DA.[BeginDate],DA.[EndDate],
		DA.[PosRetailQty],
		DA.[PosRetailTotal],
		DA.[PosBackQty],
		DA.[PosBackTotal],
		DA.[ZBRetailQty],
		DA.[ZBRetailTotal],
		DA.[ZBBackQty],
		DA.[ZBBackTotal],
		DA.[ifValidate],[ifValidateName]=(Case when DA.[ifValidate]=0 then '否' else '是' end),
		DA.[ifDayAccount],[ifDayAccountName]=(Case when DA.[ifDayAccount]=0 then '否' else '是' end),
		DA.[GUID]
		FROM DayAccount DA 
		left join company Y ON DA.Y_ID=Y.company_id
		/*where DA.BeginDate>=@BeginDate and DA.EndDate<=@EndDate*/

	) b
        union all

        SELECT a.*,
	[AllPosRetailQty]=(a.PosRetailQty - a.PosBackQty),
	[AllPosRetailTotal]=(a.PosRetailTotal - a.PosBackTotal),
	[AllZBRetailQty]=(a.ZBRetailQty - a.ZBBackQty),
	[AllZBRetailTotal]=(a.ZBRetailTotal - a.ZBBackTotal)
	FROM 
	(

           select 0 as [id],  bi.y_id,  yname=y.[name], min(bi.retaildate) as begindate, max(bi.retaildate) as enddate,
                  sum(case bi.billtype when 12 then sm.quantity else 0 end) as PosRetailQty,
                  sum(case bi.billtype when 12 then sm.taxtotal else 0 end) as PosRetailTotal,
                  sum(case bi.billtype when 13 then sm.quantity else 0 end) as PosBackQty,
                  sum(case bi.billtype when 13 then sm.taxtotal else 0 end) as PosBackTotal, 
                  0 as ZBRetailQty, 0 as ZBRetailTotal, 0 as ZBBackQty, 0 as ZBBackTotal,
                  0 as ifValidate,  ' 'as ifValidateName,  0 as ifDayAccount, '否' as ifDayAccountName,
                  newid() as GUID
             from billidx bi 
             inner join salemanagebill sm on bi.billid = sm.bill_id
          /*   inner join UPBillList up on bi.billid = up.mdbillid*/
             left join company Y ON bi.Y_ID=Y.company_id
             where bi.billtype in(12, 13) 
            /* and up.mdDA_ID=0 */
             and sm.p_id >0 and  bi.billstates = '0' and sm.AOID<>7
             and bi.transcount=0
             group by  bi.y_id,y.[name]   

	) a
      union all
  
        SELECT c.*,
	[AllPosRetailQty]=0,
	[AllPosRetailTotal]=0,
	[AllZBRetailQty]=0,
	[AllZBRetailTotal]=0
	FROM 
	(

           select 0 as [id],  @Y_ID as Y_ID,  @szYName as Yname, @minDate as begindate, @maxDate as enddate,
                  0 as PosRetailQty,
                  0 as PosRetailTotal,
                  0 as PosBackQty,
                  0 as PosBackTotal, 
                  0 as ZBRetailQty, 0 as ZBRetailTotal, 0 as ZBBackQty, 0 as ZBBackTotal,
                  0 as ifValidate,  ' 'as ifValidateName,  0 as ifDayAccount, '否' as ifDayAccountName,
                  newid() as GUID
             from billidx bi
            /* inner join upBilllist up on bi.billid = up.mdBillid*/
             where bi.billtype in (12, 13) /*and up.mdDA_ID = 0 */
             and bi.billstates = '0'
             having count(1) = 0 and  
                  cast(cast(getdate() as varchar(10)) as datetime) > cast(cast(@minDate as varchar(10)) as datetime)

	) c
	
		    

)c
order by c.EndDate desc


return 0

zbdata:

select * from 
(   /*总部没有确认过的单据*/
	SELECT a.*,
	[AllPosRetailQty]=(a.PosRetailQty - a.PosBackQty),
	[AllPosRetailTotal]=(a.PosRetailTotal - a.PosBackTotal),
	[AllZBRetailQty]=(a.ZBRetailQty - a.ZBBackQty),
	[AllZBRetailTotal]=(a.ZBRetailTotal - a.ZBBackTotal)
	FROM 
	(
		SELECT 
		DA.[id],DA.[Y_ID],YName=Y.[Name],DA.[BeginDate],DA.[EndDate],
		DA.[PosRetailQty],
		DA.[PosRetailTotal],
		DA.[PosBackQty],
		DA.[PosBackTotal],
		[ZBRetailQty]=sum(case  when (sm.RetailDate between DA.BeginDate and DA.EndDate) and (sm.billtype=12) then sm.quantity else 0 end),
		[ZBRetailTotal]=sum(case when (sm.RetailDate between DA.BeginDate and DA.EndDate) and (sm.billtype=12) then sm.taxtotal else 0 end),
		[ZBBackQty]=sum(case when (sm.RetailDate between DA.BeginDate and DA.EndDate) and (sm.billtype=13) then sm.quantity else 0 end),
		[ZBBackTotal]=sum(case when (sm.RetailDate between DA.BeginDate and DA.EndDate)and (sm.billtype=13) then sm.taxtotal else 0 end),
		DA.[ifValidate],[ifValidateName]=(Case when DA.[ifValidate]=0 then '否' else '是' end),
		DA.[ifDayAccount],[ifDayAccountName]=(Case when DA.[ifDayAccount]=0 then '否' else '是' end),
		DA.[GUID]
		FROM DayAccount DA 
		left join company Y ON DA.Y_ID=Y.company_id
		left join 
		(
			select b.Y_ID,b.RetailDate,b.billtype,sm.quantity,sm.taxtotal
			from salemanagebill sm
			inner join billidx b on sm.bill_id=b.billid
			where b.RetailDate between @BeginDate and @EndDate and b.billtype in(12,13) 
			and b.billstates='0' and (@Y_ID=0 or sm.Y_ID=@Y_ID) and sm.p_id>0 and sm.AOID<>7
		) sm on DA.Y_ID=sm.Y_ID

		where ((@nQrmode = 0 and DA.BeginDate>=@BeginDate and DA.EndDate<=@EndDate) or
                       (@nQrmode = 1 and cast(cast(DA.EndDate as varchar(10)) as datetime)= cast(cast((@EndDate-0.01) as varchar(10)) as datetime)))
		and (@Y_ID=0 or DA.Y_ID=@Y_ID) and DA.ifValidate=0
		group by DA.[id],DA.[Y_ID],Y.[Name],DA.[BeginDate],DA.[EndDate],
		DA.[PosRetailQty],
		DA.[PosRetailTotal],
		DA.[PosBackQty],
		DA.[PosBackTotal],
		DA.[ifValidate],
		DA.[ifDayAccount],
		DA.[GUID]
	) a

	union all
    /*总部确认过的单据*/
	SELECT b.*,
	[AllPosRetailQty]=(b.PosRetailQty - b.PosBackQty),
	[AllPosRetailTotal]=(b.PosRetailTotal - b.PosBackTotal),
	[AllZBRetailQty]=(b.ZBRetailQty - b.ZBBackQty),
	[AllZBRetailTotal]=(b.ZBRetailTotal - b.ZBBackTotal)
	FROM 
	(
		SELECT 
		DA.[id],DA.[Y_ID],YName=Y.[Name],DA.[BeginDate],DA.[EndDate],
		DA.[PosRetailQty],
		DA.[PosRetailTotal],
		DA.[PosBackQty],
		DA.[PosBackTotal],
		DA.[ZBRetailQty],
		DA.[ZBRetailTotal],
		DA.[ZBBackQty],
		DA.[ZBBackTotal],
		DA.[ifValidate],[ifValidateName]=(Case when DA.[ifValidate]=0 then '否' else '是' end),
		DA.[ifDayAccount],[ifDayAccountName]=(Case when DA.[ifDayAccount]=0 then '否' else '是' end),
		DA.[GUID]
		FROM DayAccount DA 
		left join company Y ON DA.Y_ID=Y.company_id
		where ((@nQrmode = 0 and DA.BeginDate>=@BeginDate and DA.EndDate<=@EndDate) or
                       (@nQrmode = 1 and cast(cast(DA.EndDate as varchar(10)) as datetime)= cast(cast((@EndDate-0.01) as varchar(10)) as datetime)))
		and (@Y_ID=0 or DA.Y_ID=@Y_ID) and DA.ifValidate=1
	) b
)c
order by c.EndDate, c.Y_ID desc
return 0
GO
