

CREATE PROCEDURE ts_M_InsStopSaleDay
(
  @BillType int,
  @Day int
)
AS
/*禁止近效期商品销售*/

if NOT EXISTS(select * from StopSaleDay where BillType=@BillType)
BEGIN
    INSERT INTO [StopSaleDay]([BillType],[Day]) VALUES(@BillType,@Day)
END 
ELSE 
BEGIN
    UPDATE StopSaleDay SET [Day]=@Day WHERE BillType=@BillType
END
GO
