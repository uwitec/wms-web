
CREATE   PROCEDURE Ts_K_SetPermission
(
	@nE_id 		    INT = 0,
	@szRequestReason VARCHAR(800) = '',
	@nLim	        IMAGE,
	@nlimPlugin  	BINARY(1200),
	@szProductInfo	VARCHAR(2000) = '',
	@szClientInfo	VARCHAR(2000) = '',
	@szPriceInfo	VARCHAR(2000) = '',
	@nYId  	        INT,
	@szComment	    VARCHAR(800) = ''
)
/*with encryption*/
AS
BEGIN
	INSERT INTO EmployeesPermission(Emp_id, RequestDate, RequestReason, lim, limPlugin, ProductInfo, ClientInfo,
	   							    PriceInfo, Audit_Id, AuditDate, AuditStates, AuditReason, Y_Id, Comment)
	VALUES(@nE_id, GETDATE(), @szRequestReason, @nLim, @nlimPlugin, @szProductInfo, @szClientInfo, 
		   @szPriceInfo, 0, '1900-01-01', 0, '', @nYId, @szComment)
END
GO
