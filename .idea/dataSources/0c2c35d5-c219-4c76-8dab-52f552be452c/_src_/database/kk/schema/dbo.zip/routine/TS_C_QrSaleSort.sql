/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*******************************************

各种销售排行榜的统计
最后的修改日期 2003-11-07
@nSortType=0 GOTO GetPSaleSort --商品销售排行
@nSortType=1 GOTO csalesort --客户销售排行
@nSortType=2 GOTO esalesort --职员销售排行
@nSortType=3 GOTO msalesort --门店销售排行
@nSortType=4 GOTO ssalesort --仓库销售排行
@nSortType=5 GOTO asalesort --片区销售排行
@nSortType=6 GOTO dsalesort --部门销售排行
@nSortType=7 GOTO lsalesort --货位销售排行榜
@nSortType=8 GOTO Supsalesort --供应商商品销售排行榜
*********************************************/
CREATE PROCEDURE TS_C_QrSaleSort
(	@BeginDate 	  DATETIME,/*开始时间*/
	@EndDate	 	  DATETIME,/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szEClass_ID	VARCHAR(30)='',/*经手人ID*/
	@szSClass_ID	VARCHAR(30)='',/*库房ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szParent_ID	VARCHAR(30)='',/*产品父类ID*/
	@szListFlag		VARCHAR(1)='L',/*分级显示*/
	@nSortType    INT=0,           /*查询分级*/
	@dMlTotal			NUMERIC(25,8) OUTPUT,/*总销售金额*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
	@nLocation_Id   INT=0,        /*货位ID*/
    @nYClassid                 varchar(100)='',
    @nloginEID               int=0,
    @szRClass_id   varchar(50) = '', /*片区 */
    @Largess       int=0, /*统计赠品*/
    @szmlroomId    varchar(300) = ''
)
AS
/*Params Ini begin*/
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szSClass_ID is null  SET @szSClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szParent_ID is null  SET @szParent_ID = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @nSortType is null  SET @nSortType = 0
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @nLocation_Id is null  SET @nLocation_Id = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @szRClass_id is null  SET @szRClass_id = ''
if @szmlroomId is null SET @szmlroomId = ''
/*Params Ini end*/
  /*SET NOCOUNT ON */
  
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
  
  DECLARE @SQLScript VARCHAR(8000), @SQLChildTemp VARCHAR(200)
  Declare @SQLSid varchar(100) /*查询库房,*/
  Declare @SQLStorage varchar(50),@SQLnotStorage varchar(50)/*查询单据,*/
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  Declare @isfinally int
  Declare @tablename varchar(8000)
  declare @szPC_ID varchar(30)
  declare @nPLen int
  declare @nTmpY int
  declare @nregion_id int
  declare @StrAOID varchar(200)
  
	if @szParent_ID in ('', '%%', '000000')
	begin
		set @szPC_ID = ''
		set @nPLen = 6
	end
	else
	begin
		set @szPC_ID = @szParent_ID
		set @nPLen = LEN(@szParent_ID) + 6
	end
	
	if @Largess = 0 
	begin 
	  set @StrAOID = '0,5'
	end
	else
	begin
	  set @StrAOID = '0,5,6,7'
	end
	
	select szTYPE into #Largess from DecodeToStr(@StrAOID) 
	
	select @nTmpY = company_id from company where class_id = @nYClassid
	if @nTmpY is null or @nTmpY = 0
		set @nTmpY = 2
  
    if @szRClass_id <> ''  /*--获取片区ID*/
      select @nregion_id =region_id  from Region where class_id = @szRClass_id 
    else
      set @nregion_id = 0
        
  /*if @szRClass_id = '' or @szRClass_id = '000000' set @szRClass_id = '0'*/
  /*else set @szRClass_id = @szRClass_id + '%'*/

  if OBJECT_ID('tempdb..#Clienttable') is not null
    drop table #Clienttable
  create table #Clienttable([id] int) 
  if OBJECT_ID('tempdb..#Companytable') is not null
    drop table #Companytable
  create table #Companytable([id] int)
  if OBJECT_ID('tempdb..#employeestable') is not null
    drop table #employeestable  
  create table #employeestable([id] int) 
  if OBJECT_ID('tempdb..#storagestable') is not null
    drop table #storagestable   
  create table #storagestable([id] int) 
  
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

GetMainOne:
/*先得到列表方式不同时用的语句  */

/*  SELECT @dMlTotal=ISNULL(SUM(P.[Total]),0)  --abs(ISNULL(SUM(P.[Costtotal]),0))*/
/*    FROM*/
/*      (SELECT b.c_id,b.Inputman,sm.p_id,sm.RowE_id,sm.ss_id,B.Y_id,*/
/*             (case when B.billtype IN (10,12,32,112,53,16,210) then sm.totalmoney else -sm.totalmoney end)total*/
/*           --  (case when billtype IN (10,12,32,112,53,16,210) then sm.costtotal  else -sm.costtotal end)Costtotal*/
/*         FROM       */
/*            (SELECT bill_id,p_id,totalmoney,RowE_id,ss_id       --,(costprice*quantity)as costtotal*/
/*               FROM salemanagebill  where p_id>0 and aoid in (0,5)*/
/*            )sm*/
/*         LEFT JOIN Billidx   B  ON SM.bill_id=B.billid*/
/*         LEFT JOIN products  P  ON sm.p_id=p.product_id*/
/*         LEFT JOIN Clients   C  ON B.c_id=C.Client_id*/
/*         LEFT JOIN Employees RE ON sm.Rowe_id=RE.emp_id*/
/*         LEFT JOIN storages  S  ON sm.ss_id=S.storage_id*/
/*         LEFT JOIN Company   Y  on B.Y_ID=Y.Company_id*/
/*         LEFT JOIN Employees E  on B.Inputman=E.emp_id*/
/*         Where  B.[BillDate] BETWEEN @BeginDate AND @EndDate and*/
/*                B.[Billtype] IN (10,11,12,13,112,16,17,32,53,54,212) AND*/
/*                B.[Billstates]='0' and */
/*                (@szRClass_id = '' or (B.region_id in (select region_id from Region where class_id like @szRClass_id and child_number = 0))) */
/*                and */
/*                C.[Class_ID] LIKE @szCClass_ID+'%' AND*/
/*               RE.[Class_ID] LIKE @szEClass_ID+'%' AND */
/*                S.[class_ID] LIKE @szSClass_ID+'%'  AND*/
/*                E.[Class_ID] LIKE @szInputClass_ID+'%' AND*/
/*                P.[Class_id] LIKE @szPClass_id+'%' AND*/
/*                Y.[Class_id] like @nYClassid+'%'*/
/*)P   */



 /* SELECT @SQLScript='' 
  SELECT @SQLStorage='', @SQLSid='',@SQLnotStorage=''
  Select @SQLSid='where storehouse_id>0'
 
  IF @szPClass_ID NOT IN ('', '%%', '000000')
    SELECT @SQLScript=@SQLScript+' AND VP.[pclass_id] LIKE '+CHAR(39)+@szPClass_ID+CHAR(39)+'+'+CHAR(39)+'%'+CHAR(39)

  IF @szCClass_ID NOT IN ('', '%%', '000000')
    SELECT @SQLScript=@SQLScript+' AND VB.[CClass_ID] LIKE '+CHAR(39)+@szCClass_ID+CHAR(39)+'+'+CHAR(39)+'%'+CHAR(39)

  IF @szEClass_ID NOT IN ('', '%%', '000000')
    SELECT @SQLScript=@SQLScript+' AND Vp.[EClass_ID] LIKE '+CHAR(39)+@szEClass_ID+CHAR(39)+'+'+CHAR(39)+'%'+CHAR(39)

  IF @szSClass_ID NOT IN ('', '%%', '000000')
  begin
    SELECT @SQLSid=@SQLSid+'  AND sclassid like '''+@szSClass_ID+'%'''
    SELECT @SQLStorage=' AND VP.[ssclass_ID] LIKE '''+@szSClass_ID+'%'''
    SELECT @SQLnotStorage=' OR Vp.[ssclass_ID] not like '''+@szSClass_ID+'%'''
  end

--增加货位查询
  IF @nLocation_Id > 0
  begin
    SELECT @SQLSid=@SQLSid+' AND Location_Id='+cast(@nLocation_Id as varchar(30))
    SELECT @SQLStorage=@SQLStorage+' and VP.location_id='+cast(@nLocation_Id as varchar(30))
  end
 
  IF @szInputClass_ID NOT IN ('', '%%', '000000')
    SELECT @SQLScript=@SQLScript+' AND VB.[InputmanClass_ID] LIKE '+CHAR(39)+@szInputClass_ID+CHAR(39)+'+'+CHAR(39)+'%'+CHAR(39)
  */


  select emp_id into #tmpInput from employees where class_id LIKE @szInputClass_ID + '%'	/*制单人*/
  select emp_id into #tmpEmp from employees where class_id LIKE @szEClass_ID + '%'	/*经手人*/
  select client_id into #tmpC from clients where class_id LIKE @szCClass_ID + '%'	/*往来单位*/
  select company_id into #tmpY from company where class_id LIKE @nYClassid + '%'	/*分支机构*/
  
  select * into #tmpI from dbo.billidx where (billdate BETWEEN @BeginDate AND @EndDate) AND (billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) 
  AND (billstates = 0) AND ((@ClientTable=0) or (c_id in (select [id] from #Clienttable)))AND
  ((@Companytable=0)or (Y_id in (select [id] from #Companytable))) AND
  inputman in (select emp_id from #tmpInput) AND c_id in(select client_id from #tmpC) AND
  Y_ID in (select company_id from #tmpY)

/* 优化使用FilterSalemanagebill函数导致商品销售排行榜查询效率。 Wsj 2016.09.26 */         
/*yypeng-2016-09-28 16:59:14--尽量少用函数进行连接，效率极低，以后的开发切忌再这么干了，此报表的优化没有做完，具体思路有，过后会让小吴做优化*/
/* 去掉价格保护权限优化查询效率 -Wsj-2017-01-17-tfs44981*/
/*
declare @nSubLimit int
select @nSubLimit = dbo.A_GetSubLimit(@nloginEID, 4007, -1)

           
   SELECT    sb.smb_id, sb.bill_id, sb.p_id, sb.batchno, sb.quantity, CASE WHEN @nSubLimit = 1 or p.protectprice = 0 THEN sb.costprice ELSE 0 END AS costprice, sb.saleprice, sb.discount, sb.discountprice, sb.totalmoney, sb.taxprice, 
			sb.taxtotal, sb.taxmoney, sb.retailprice, sb.retailtotal, sb.makedate, sb.validdate, sb.qualitystatus, sb.price_id, sb.ss_id, sb.sd_id, sb.location_id, 
			sb.supplier_id, sb.commissionflag, sb.comment, sb.unitid, sb.taxrate, sb.order_id, sb.total, sb.iotag, sb.InvoiceTotal, sb.thqty, sb.newprice, 
			sb.orgbillid, sb.jsprice, sb.AOID, sb.invoice, sb.invoiceno, sb.BatchBarCode, sb.SendQTY, CASE WHEN @nSubLimit = 1 or p.protectprice = 0 THEN sb.SendCostTotal ELSE 0 END AS SendCostTotal, 
			sb.RowGuid, sb.RowE_id, CASE WHEN @nSubLimit = 1 or p.protectprice = 0 THEN sb.YCostPrice ELSE '0' END AS YCostPrice, 
			sb.YGuid, sb.Y_ID, sb.transflag, sb.instoretime, sb.cxType, sb.PriceType, sb.location_id2, sb.comment2, sb.scomment, sb.batchprice, sb.CxGuid, 
			sb.Conclusion,isnull(f.AccountComment,'') as factory,sb.costtaxprice,sb.costtaxrate,sb.costtaxtotal
	 into #tmpS FROM  dbo.products AS p INNER JOIN
				   dbo.salemanagebill AS sb ON p.product_id = sb.p_id
				   left join basefactory f on sb.factoryid=f.CommID 
				   inner join #tmpI i on i.billid = sb.bill_id 

*/

  IF @nSortType=0 GOTO GetPSaleSort /*商品销售排行*/
  IF @nSortType=1 GOTO GetCSaleSort /*客户销售排行*/
  IF @nSortType=2 GOTO GetESaleSort /*职员销售排行*/
  IF @nSortType=3 GOTO GetMSaleSort /*分支机构销售排行*/
  IF @nSortType=4 GOTO GetSSaleSort /*仓库销售排行*/
  IF @nSortType=5 GOTO GetASaleSort /*片区销售排行*/
  IF @nSortType=6 GOTO GetDSaleSort /*部门销售排行*/
  IF @nSortType=7 GOTO GetLSaleSort /*货位销售排行*/
  IF @nSortType=8 GOTO GetSupsalesort /*供应商商品销售排行榜*/

/*商品销售排行	修改为使用多个临时表缓存数据，在存储过程中多次使用Left join效率相当低。 Huang.Y 2011-9-2 修改。*/
GetPSaleSort:
BEGIN

  DECLARE @where varchar(3000) 
  set @where = ''
  set @where = dbo.GetWhereStr(@szmlroomId)
/*  print(@where)  */
 
  

  IF @szListFlag='L'
  BEGIN
  
  if OBJECT_ID('tempdb..#tmpresult') is not null
    drop table #tmpresult   
  create table #tmpresult(
	[quantity] NUMERIC(25,8),
	[presentQty] NUMERIC(25,8),
	[totalmoney] NUMERIC(25,8),
	[SendQTY] NUMERIC(25,8),
	[sendtotal] NUMERIC(25,8),
	[SendCostTotal] NUMERIC(25,8),
	[taxtotal] NUMERIC(25,8),
	[taxmoney] NUMERIC(25,8),
	[ml] NUMERIC(25,8),
	[avgCost] NUMERIC(25,8),
	[mlRate] NUMERIC(25,8),
	[costtotal] NUMERIC(25,8),
	[class_id] varchar(200),
	[p_id] int,
	[dir] int
	)   
  
  declare @sqltemp nvarchar(4000)
 /*先根据条件过滤明细*/
SELECT     SUM(bd.quantity * bd.dir) AS quantity,SUM(bd.presentQty * bd.dir) as presentQty ,SUM(bd.totalmoney * bd.dir) AS totalmoney, SUM(bd.SendQTY * bd.dir) AS SendQTY, 
                                                   CAST(SUM(bd.sendtotal * bd.dir) AS NUMERIC(25,8)) AS sendtotal, SUM(bd.SendCostTotal * bd.dir) AS SendCostTotal, 
                                                   SUM(bd.taxtotal * bd.dir) AS taxtotal, SUM(bd.taxmoney * bd.dir) AS taxmoney, SUM(bd.ml * bd.dir) AS ml, 
                                                   case when SUM(bd.SendQTY)=0 then 0 else CAST(SUM(bd.SendCostTotal) / SUM(bd.SendQTY) AS NUMERIC(18, 6)) end AS avgCost, 
                                                   CASE WHEN SUM(sendtotal * dir) = 0 THEN 0 ELSE cast(SUM(ml * dir) / SUM(sendtotal * dir) * 100 as NUMERIC(25,8)) END AS mlRate, SUM(bd.costtotal * bd.dir) 
                                                   AS costtotal, bd.class_id, bd.p_id,dir
INTO #tmpL_pD  from(  
  
	SELECT     sb.p_id, sb.quantity, 0 as presentQty,sb.totalmoney, sb.SendQTY, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate)AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate) AS SendCostTotal, sb.taxtotal, 
						   sb.taxmoney, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate) - sb.SendCostTotal * (1 + sb.taxrate) AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
						   112, 53, 16, 210) THEN 1 ELSE -1 END AS dir, sb.quantity * sb.costprice AS costtotal, LEFT(p.class_id, @nPLen) AS class_id, 
						   i.billdate, i.billnumber
	FROM          #tmpI AS i INNER JOIN
						   /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
						   salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
						   dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
						   dbo.employees AS e ON sb.RowE_id = e.emp_id INNER JOIN
						   dbo.products AS p ON sb.p_id = p.product_id
	WHERE    (@nregion_id = 0 OR @nregion_id = i.region_id) AND ((sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(sb.location_id = @nLocation_Id) AND (p.class_id LIKE @szPC_ID + '%') OR
						   (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(p.class_id LIKE @szPC_ID + '%') AND (@nLocation_Id = 0) OR
						   (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(sb.location_id = @nLocation_Id) AND (p.parent_id = @szParent_ID) OR
						   (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(@nLocation_Id = 0) AND (p.parent_id = @szParent_ID)) and
							s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零							*/
							
		union all 

	SELECT     sb.p_id, 0 as quantity, sb.quantity as presentQty,  0 as totalmoney, sb.SendQTY, 0 AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate), sb.taxtotal, 
						   sb.taxmoney, 0 AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
						   112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir, 0 AS costtotal, LEFT(p.class_id, @nPLen) AS class_id, 
						   i.billdate, i.billnumber
	FROM          #tmpI AS i INNER JOIN
						   /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
						   salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
						   dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
						   dbo.employees AS e ON sb.RowE_id = e.emp_id INNER JOIN
						   dbo.products AS p ON sb.p_id = p.product_id
	WHERE      (@nregion_id = 0 OR @nregion_id = i.region_id) AND ((sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(sb.location_id = @nLocation_Id) AND (p.class_id LIKE @szPC_ID + '%') OR
						   (sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(p.class_id LIKE @szPC_ID + '%') AND (@nLocation_Id = 0) OR
						   (sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(sb.location_id = @nLocation_Id) AND (p.parent_id = @szParent_ID) OR
						   (sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
						   ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
							((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
						   (s.class_id LIKE @szSClass_ID + '%') AND
							(@nLocation_Id = 0) AND (p.parent_id = @szParent_ID)) and 
							s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		                        */
  ) bd                     
  GROUP BY p_id,class_id,dir   
  
if @where <> ''
	set @where = ' where ' + @where	
	
	

   set @sqltemp ='insert into #tmpresult select *  from  #tmpL_pD  ' + @where
   exec(@sqltemp)  
  
/*  select * from #tmpresult*/
  
  SELECT     SUM(bd.quantity) AS quantity,SUM(bd.presentQty) as presentQty ,SUM(bd.totalmoney) AS totalmoney, SUM(bd.SendQTY ) AS SendQTY, 
                                                   CAST(SUM(bd.sendtotal ) AS NUMERIC(25,8)) AS sendtotal, SUM(bd.SendCostTotal) AS SendCostTotal, 
                                                   SUM(bd.taxtotal) AS taxtotal, SUM(bd.taxmoney) AS taxmoney, SUM(bd.ml ) AS ml, 
                                                   case when SUM(bd.SendQTY)=0 then 0 else CAST(SUM(bd.SendCostTotal) / SUM(bd.SendQTY) AS NUMERIC(18, 6)) end AS avgCost, 
                                                   CASE WHEN SUM(sendtotal ) = 0 THEN 0 ELSE cast(SUM(ml) / SUM(sendtotal) * 100 as NUMERIC(25,8)) END AS mlRate, SUM(bd.costtotal) 
                                                   AS costtotal, bd.class_id, p.product_id
INTO #tmpL_D
                            FROM          #tmpresult AS bd INNER JOIN
                                                   dbo.products AS p ON bd.class_id = p.class_id
                            GROUP BY bd.class_id, p.product_id
                            

/*if @where = ''*/
/*select * from #tmpL_D*/
select @dMlTotal = isnull(SUM(ml), 0) from #tmpL_D 
 
SELECT     pd.product_id, pd.class_id, pd.serial_number, pd.name, pd.alias, pd.standard, pd.makearea, pd.deduct, pd.TC1, pd.TC2, 
                      pd.tcmoney, pd.Inputman, pd.Inputdate, pd.UnitName1, ISNULL(sd.quantity, 0) AS quantity,ISNULL(sd.presentQty,0) as presentQty ,ISNULL(sd.totalmoney, 0) AS saletotal, ISNULL(sd.SendQTY,
                       0) AS SendQTY, CAST(ISNULL(sd.sendtotal, 0) AS NUMERIC(25,8)) AS sendtotal, ISNULL(sd.SendCostTotal, 0) AS SendCostTotal, ISNULL(sd.taxtotal, 0) 
                      AS taxtotal, ISNULL(sd.taxmoney, 0) AS setotal, CAST(ISNULL(sd.ml, 0) AS NUMERIC(25,8)) AS MlTotal, ISNULL(sd.avgCost, 0) AS costprice, 
                      ISNULL(sd.mlRate, 0) AS mlRate, 
                      pd.Custompro1, pd.Custompro2, pd.Custompro3, pd.Custompro4, pd.Custompro5, pd.parent_id, pd.deleted, pd.child_number, ISNULL(sd.costtotal, 0) 
                      AS costtotal, 
                      /*CAST(sd.ml / @dMlTotal * 100 AS NUMERIC(25,8)) AS ratio, */
                      CASE WHEN @dMlTotal = 0 THEN 0 ELSE CAST(sd.ml / @dMlTotal * 100 AS NUMERIC(25,8)) END AS ratio,
                      pd.retailprice
INTO #tmpList
FROM         (
                SELECT     p.product_id, p.class_id, p.serial_number, p.name, p.alias, p.standard, p.makearea, p.deduct, p.TC1, p.TC2, p.tcmoney, p.Inputman, 
                                              p.Inputdate, ISNULL(c.retailprice, 0) AS retailprice, ISNULL(u.name, ' ') AS UnitName1, p.child_number, p.Custompro1, p.Custompro2, 
                                              p.Custompro3, p.Custompro4, p.Custompro5, p.parent_id, p.deleted
                       FROM          dbo.products AS p LEFT OUTER JOIN
                                              dbo.price AS c ON p.product_id = c.p_id AND p.unit1_id = c.u_id LEFT OUTER JOIN
                                              dbo.unit AS u ON p.unit1_id = u.unit_id
                       WHERE      (p.deleted <> 1) AND (p.parent_id = @szParent_ID) and p.IsSplit=0/*zjx--tfs46253--20170308--过滤掉拆零		*/
              ) AS pd LEFT OUTER JOIN
                          #tmpL_D AS sd ON pd.product_id = sd.product_id
                          
                          
/*if @where = ''   */

/*select * from #tmpList*/
                          
SELECT     pd.product_id, pd.class_id, pd.serial_number, pd.name, pd.alias, pd.standard, pd.makearea, pd.deduct, pd.TC1, pd.TC2, 
                      pd.tcmoney, pd.Inputman, pd.Inputdate, pd.UnitName1, quantity, pd.presentQty,saletotal, SendQTY, sendtotal, SendCostTotal, taxtotal, 
                      setotal, MlTotal, costprice, 
                      mlRate, ISNULL(sh.SHQTY, 0) AS SHQTY, ISNULL(sh.C_Name, ' ') AS C_Name, ISNULL(sh.e_name, ' ') AS e_name, 
                      pd.Custompro1, pd.Custompro2, pd.Custompro3, pd.Custompro4, pd.Custompro5, pd.parent_id, pd.deleted, pd.child_number, costtotal, CAST(isnull(pd.ratio, 0) AS NUMERIC(25,8)) AS ratio, pd.retailprice
/*INTO #tmpresult*/
FROM #tmpList pd         
LEFT OUTER JOIN
                          (
                            SELECT     s_1.class_id, s_1.SHQTY, pb.C_Name, pb.e_name, p.product_id
                            FROM   (
                                             SELECT     SUM(h.quantity) AS SHQTY, LEFT(p.class_id, @nPLen) AS class_id
                                                    FROM          dbo.FilterStorehouse(@nloginEID) AS h INNER JOIN
                                                                           dbo.products AS p ON h.p_id = p.product_id LEFT OUTER JOIN
                                                                           dbo.company AS y ON h.Y_ID = y.company_id LEFT OUTER JOIN
                                                                           dbo.storages AS g ON h.s_id = g.storage_id
                                                    WHERE      (g.class_id LIKE @szSClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%')
                                                    AND ((@Storetable=0) OR (h.s_id in (select [id] from #storagestable)))
												   AND ((@Companytable=0) or (h.Y_id in (select [id] from #Companytable)))
												   and g.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		*/
												   GROUP BY LEFT(p.class_id, @nPLen)
								  ) AS s_1 INNER JOIN  dbo.products AS p ON s_1.class_id = p.class_id 
                                           LEFT OUTER JOIN
                                                       (
                                                          SELECT     v.C_Name, v.e_name, p.class_id
                                                         FROM          dbo.vw_productbalance AS v INNER JOIN
                                                                                dbo.products AS p ON v.p_id = p.product_id
                                                         WHERE      (v.Y_id = @nTmpY)
                                                       ) AS pb ON s_1.class_id = pb.class_id
                         ) AS sh ON pd.product_id = sh.product_id
ORDER BY pd.product_id

END
  
  IF @szListFlag='P'
  BEGIN
SELECT     p.product_id, p.class_id, p.serial_number, p.name, p.alias, p.standard, p.makearea, p.deduct, p.TC1, p.TC2, p.tcmoney, p.Inputman, 
                                              p.Inputdate, c.retailprice, u.name AS UnitName1, p.child_number, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                                              p.Custompro5, p.parent_id, p.deleted
INTO #tmpP_P
                       FROM          dbo.products AS p INNER JOIN
                                              dbo.price AS c ON p.product_id = c.p_id AND p.unit1_id = c.u_id INNER JOIN
                                              dbo.unit AS u ON p.unit1_id = u.unit_id
                       WHERE      (p.child_number = 0) AND (p.deleted <> 1) AND (p.class_id LIKE @szPC_ID + '%')
                                   and  p.IsSplit=0/*zjx--tfs46253--20170308--过滤掉拆零			*/
                       	
SELECT     p_id, SUM(quantity * dir) AS quantity,SUM(presentQty * dir) as presentQty ,SUM(totalmoney * dir) AS totalmoney, SUM(SendQTY * dir) AS SendQTY, CAST(SUM(sendtotal * dir) 
                                                   AS NUMERIC(25,8)) AS sendtotal, SUM(SendCostTotal * dir) AS SendCostTotal, SUM(taxtotal * dir) AS taxtotal, SUM(taxmoney * dir) 
                                                   AS taxmoney, SUM(ml * dir) AS ml, AVG(costprice) AS avgCost, CASE WHEN SUM(sendtotal * dir) = 0 THEN 0 ELSE CAST(SUM(ml * dir) 
                                                   / SUM(sendtotal * dir) * 100 AS NUMERIC(25,8)) END AS mlRate, SUM(costtotal) AS costtotal
INTO #tmpP_D
                            FROM          (SELECT     sb.p_id, sb.quantity, 0 as presentQty ,sb.totalmoney, sb.SendQTY, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate) AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate) AS SendCostTotal, sb.taxtotal, 
                                                                           sb.taxmoney, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate) - sb.SendCostTotal * (1 + sb.taxrate) AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
                                                                           112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir, sb.quantity * sb.costprice AS costtotal
                                                    FROM          #tmpI AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
                                                                           salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
                                                                           dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
                                                                           dbo.employees AS e ON sb.RowE_id = e.emp_id INNER JOIN
                                                                           dbo.products AS p ON sb.p_id = p.product_id INNER JOIN
                                                                           (SELECT     region_id, class_id
                                                                                FROM          dbo.Region
                                                                                UNION ALL
                                                                                SELECT     0 AS region_id, NULL AS class_id) AS r ON i.region_id = r.region_id
                                                    WHERE      (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			(s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (sb.location_id = @nLocation_Id) AND (p.class_id LIKE @szPC_ID + '%') OR
                                                                           (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			(s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (p.class_id LIKE @szPC_ID + '%') AND (@nLocation_Id = 0)and
                                                                           s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		*/
                                           union all
                                           
                                           SELECT     sb.p_id, 0 as quantity,sb.quantity as presentQty ,0 as totalmoney, sb.SendQTY, 0 AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate), sb.taxtotal, 
                                                                           sb.taxmoney,0 AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
                                                                           112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir, sb.quantity * sb.costprice AS costtotal
                                                    FROM          #tmpI AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
                                                                           salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
                                                                           dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
                                                                           dbo.employees AS e ON sb.RowE_id = e.emp_id INNER JOIN
                                                                           dbo.products AS p ON sb.p_id = p.product_id INNER JOIN
                                                                           (SELECT     region_id, class_id
                                                                                FROM          dbo.Region
                                                                                UNION ALL
                                                                                SELECT     0 AS region_id, NULL AS class_id) AS r ON i.region_id = r.region_id
                                                    WHERE      (sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			(s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (sb.location_id = @nLocation_Id) AND (p.class_id LIKE @szPC_ID + '%') OR
                                                                           (sb.aoid in (7)) and (sb.p_id > 0) AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			(s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (p.class_id LIKE @szPC_ID + '%') AND (@nLocation_Id = 0)and
                                                                           s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		                             */
                                             ) AS bd
                            GROUP BY p_id                            
		
select @dMlTotal = isnull(SUM(ml), 0) from #tmpP_D
  
SELECT     pd.product_id, pd.class_id, pd.serial_number, pd.name, pd.alias, pd.standard, pd.makearea, pd.deduct, pd.TC1, pd.TC2, 
                      pd.tcmoney, pd.Inputman, pd.Inputdate, pd.UnitName1, ISNULL(sd.quantity, 0) AS quantity, ISNULL(sd.presentQty,0) as presentQty, ISNULL(sd.totalmoney, 0) AS saletotal, ISNULL(sd.SendQTY,
                       0) AS SendQTY, CAST(ISNULL(sd.sendtotal, 0) AS NUMERIC(25,8)) AS sendtotal, ISNULL(sd.SendCostTotal, 0) AS SendCostTotal, ISNULL(sd.taxtotal, 0) 
                      AS taxtotal, ISNULL(sd.taxmoney, 0) AS setotal, CAST(ISNULL(sd.ml, 0) AS NUMERIC(25,8)) AS MlTotal, ISNULL(sd.avgCost, 0) AS costprice, 
                      ISNULL(sd.mlRate, 0) AS mlRate, 
                      pd.Custompro1, pd.Custompro2, pd.Custompro3, pd.Custompro4, pd.Custompro5, pd.parent_id, pd.deleted, pd.child_number, ISNULL(sd.costtotal, 0) 
                      AS costtotal, 
                      /*CAST(sd.ml / @dMlTotal * 100 AS NUMERIC(25,8)) AS ratio, */
                      CASE WHEN @dMlTotal = 0 THEN 0 ELSE CAST(sd.ml / @dMlTotal * 100 AS NUMERIC(25,8)) END AS ratio,
                      pd.retailprice
INTO #tmpList2
FROM         #tmpP_P pd inner join
(select * from #tmpP_D
union all
SELECT     product_id AS p_id, 0 AS quantity, 0 as presentQty,0 AS totalmoney, 0 AS SendQTY, 0 AS sendtotal, 0 AS SendCostTotal, 0 AS taxtotal, 
                                                                     0 AS taxmoney, 0 AS ml, 0 AS avgCost, 0 AS mlRate, 0 AS costtotal
                                              FROM     #tmpP_P                   
WHERE product_id not in (select p_id from #tmpP_D)) sd
on pd.product_id = sd.p_id

SELECT     pd.product_id, pd.class_id, pd.serial_number, pd.name, pd.alias, pd.standard, pd.makearea, pd.deduct, pd.TC1, pd.TC2, 
                      pd.tcmoney, pd.Inputman, pd.Inputdate, pd.UnitName1, quantity, presentQty,saletotal, SendQTY, sendtotal, SendCostTotal, taxtotal, 
                      setotal, MlTotal, costprice, 
                      mlRate, ISNULL(sh.SHQTY, 0) AS SHQTY, ISNULL(sh.C_Name, ' ') AS C_Name, ISNULL(sh.e_name, ' ') AS e_name, 
                      pd.Custompro1, pd.Custompro2, pd.Custompro3, pd.Custompro4, pd.Custompro5, pd.parent_id, pd.deleted, pd.child_number, costtotal, CAST(isnull(pd.ratio, 0) AS NUMERIC(25,8)) AS ratio, pd.retailprice
FROM #tmpList2 pd         
                            LEFT OUTER JOIN
                          (SELECT     s_1.p_id, s_1.SHQTY, pb.C_Name, pb.e_name
                            FROM          (SELECT     h.p_id, SUM(h.quantity) AS SHQTY
                                                    FROM          dbo.FilterStorehouse(@nloginEID) AS h INNER JOIN
                                                                           dbo.products AS p ON h.p_id = p.product_id LEFT OUTER JOIN
                                                                           dbo.company AS y ON h.Y_ID = y.company_id LEFT OUTER JOIN
                                                                           dbo.storages AS g ON h.s_id = g.storage_id
                                                    WHERE      (g.class_id LIKE @szSClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%') AND (p.class_id LIKE @szPC_ID + '%')
                                                    AND ((@Storetable=0) OR (h.s_id in (select [id] from #storagestable)))
												   AND ((@Companytable=0) or (h.Y_id in (select [id] from #Companytable)))
												   and g.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		*/
                                                    GROUP BY h.p_id) AS s_1 LEFT OUTER JOIN
                                                       (SELECT     p_id, C_Name, e_name
                                                         FROM          dbo.vw_productbalance
                                                         WHERE      (Y_id = @nTmpY)
                                                         GROUP BY p_id, C_Name, e_name) AS pb ON s_1.p_id = pb.p_id) AS sh ON pd.product_id = sh.p_id
ORDER BY pd.product_id
  END
  
  IF @szListFlag='A'
  BEGIN

SELECT     p_id, SUM(quantity * dir) AS quantity, SUM(presentQty * dir) as presentQty,SUM(totalmoney * dir) AS totalmoney, SUM(SendQTY * dir) AS SendQTY, CAST(SUM(sendtotal * dir) 
                                                   AS NUMERIC(25,8)) AS sendtotal, SUM(SendCostTotal * dir) AS SendCostTotal, SUM(taxtotal * dir) AS taxtotal, SUM(taxmoney * dir) 
                                                   AS taxmoney, SUM(ml * dir) AS ml, AVG(costprice) AS avgCost, CASE WHEN SUM(sendtotal * dir) = 0 THEN 0 ELSE CAST(SUM(ml * dir) 
                                                   / SUM(sendtotal * dir) * 100 AS NUMERIC(25,8)) END AS mlRate, SUM(costtotal) AS costtotal
INTO #tmpA_D
                            FROM          (SELECT     sb.p_id, sb.quantity, 0 as presentQty, sb.totalmoney, sb.SendQTY, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate) AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate) AS SendCostTotal, sb.taxtotal, 
                                                                           sb.taxmoney, sb.SendQTY * sb.totalmoney / sb.quantity * (1 + sb.taxrate) - sb.SendCostTotal * (1 + sb.taxrate) AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
                                                                           112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir, sb.quantity * sb.costprice AS costtotal
                                                    FROM          dbo.billidx AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
                                                                           salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
                                                                           dbo.employees AS ip ON i.inputman = ip.emp_id INNER JOIN
                                                                           dbo.clients AS c ON i.c_id = c.client_id INNER JOIN
                                                                           dbo.company AS y ON i.Y_ID = y.company_id INNER JOIN
                                                                           dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
                                                                           dbo.employees AS e ON sb.RowE_id = e.emp_id LEFT OUTER JOIN
                                                                           dbo.Region AS r ON i.region_id = r.region_id
                                                    WHERE      (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) AND 
                                                                           (i.billstates = 0) AND (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (ip.class_id LIKE @szInputClass_ID + '%') AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			((@ClientTable=0) or (i.c_id in (select [id] from #Clienttable)))AND
																			((@Companytable=0)or (i.Y_id in (select [id] from #Companytable))) AND
                                                                           (c.class_id LIKE @szCClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%') AND (s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (sb.location_id = @nLocation_Id) OR
                                                                           (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) AND 
                                                                           (i.billstates = 0) AND (sb.aoid in (select szTYPE from #Largess)) and (sb.p_id > 0) AND (ip.class_id LIKE @szInputClass_ID + '%') AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			((@ClientTable=0) or (i.c_id in (select [id] from #Clienttable)))AND
																			((@Companytable=0)or (i.Y_id in (select [id] from #Companytable))) AND
                                                                           (c.class_id LIKE @szCClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%') AND (s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (@nLocation_Id = 0) and
                                                                           s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		*/
                                                    union all
                                                    
                                           SELECT     sb.p_id, 0 as quantity,sb.quantity as presentQty,  0 as totalmoney, sb.SendQTY, 0 AS sendtotal, sb.SendCostTotal * (1 + sb.taxrate) AS SendCostTotal, sb.taxtotal, 
                                                                           sb.taxmoney, 0 AS ml, sb.costprice, CASE WHEN i.billtype IN (10, 12, 32, 
                                                                           112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir, sb.quantity * sb.costprice AS costtotal
                                                    FROM          dbo.billidx AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
                                                                           salemanagebill sb ON i.billid = sb.bill_id INNER JOIN
                                                                           dbo.employees AS ip ON i.inputman = ip.emp_id INNER JOIN
                                                                           dbo.clients AS c ON i.c_id = c.client_id INNER JOIN
                                                                           dbo.company AS y ON i.Y_ID = y.company_id INNER JOIN
                                                                           dbo.storages AS s ON sb.ss_id = s.storage_id INNER JOIN
                                                                           dbo.employees AS e ON sb.RowE_id = e.emp_id LEFT OUTER JOIN
                                                                           dbo.Region AS r ON i.region_id = r.region_id
                                                    WHERE      (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) AND 
                                                                           (i.billstates = 0) AND (sb.aoid in (7)) and (sb.p_id > 0) AND (ip.class_id LIKE @szInputClass_ID + '%') AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			((@ClientTable=0) or (i.c_id in (select [id] from #Clienttable)))AND
																			((@Companytable=0)or (i.Y_id in (select [id] from #Companytable))) AND
                                                                           (c.class_id LIKE @szCClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%') AND (s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (sb.location_id = @nLocation_Id) OR
                                                                           (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) AND 
                                                                           (i.billstates = 0) AND (sb.aoid in (7)) and (sb.p_id > 0) AND (ip.class_id LIKE @szInputClass_ID + '%') AND (e.class_id LIKE @szEClass_ID + '%') AND 
                                                                           ((@employeestable=0) OR (sb.RowE_id in (select [id] from #employeestable))) AND
																			((@Storetable=0) OR (sb.ss_id in (select [id] from #storagestable))) AND
																			((@ClientTable=0) or (i.c_id in (select [id] from #Clienttable)))AND
																			((@Companytable=0)or (i.Y_id in (select [id] from #Companytable))) AND
                                                                           (c.class_id LIKE @szCClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%') AND (s.class_id LIKE @szSClass_ID + '%') AND
                                                                            (r.class_id LIKE @szRClass_id + '%' OR
                                                                           r.class_id IS NULL) AND (@nLocation_Id = 0)   and 
                                                                           s.WholeFlag<>3/*zjx--tfs46253--20170308--过滤掉拆零		                         */
                                             ) AS bd
                            GROUP BY p_id  
  
select @dMlTotal = isnull(SUM(ml), 0) from #tmpA_D
  
SELECT     pd.product_id, pd.class_id, pd.serial_number, pd.name, pd.alias, pd.standard, pd.makearea, pd.deduct, pd.TC1, pd.TC2, 
                      pd.tcmoney, pd.Inputman, pd.Inputdate, pd.retailprice, pd.UnitName1, ISNULL(sd.quantity, 0) AS quantity,ISNULL(sd.presentQty,0) as presentQty, ISNULL(sd.totalmoney, 0) AS saletotal, 
                      ISNULL(sd.SendQTY, 0) AS SendQTY, CAST(ISNULL(sd.sendtotal, 0) AS NUMERIC(25,8)) AS sendtotal, ISNULL(sd.SendCostTotal, 0) AS SendCostTotal, 
                      ISNULL(sd.taxtotal, 0) AS taxtotal, ISNULL(sd.taxmoney, 0) AS setotal, CAST(ISNULL(sd.ml, 0) AS NUMERIC(25,8)) AS MlTotal, ISNULL(sd.avgCost, 0) 
                      AS costprice, ISNULL(sd.mlRate, 0) AS mlRate, ISNULL(sh.SHQTY, 0) AS SHQTY, ISNULL(P_other.C_Name, ' ') AS C_Name, ISNULL(P_other.e_name, ' ') 
                      AS e_name, pd.Custompro1, pd.Custompro2, pd.Custompro3, pd.Custompro4, pd.Custompro5, pd.parent_id, pd.deleted, pd.child_number, 
                      ISNULL(sd.costtotal, 0) AS costtotal, 
                      /*CAST(isnull(sd.ml / @dMlTotal * 100, 0) AS NUMERIC(25,8)) AS ratio*/
                      CASE WHEN @dMlTotal = 0 THEN 0 ELSE CAST(sd.ml / @dMlTotal * 100 AS NUMERIC(25,8)) END AS ratio
FROM         (SELECT     p.product_id, p.class_id, p.serial_number, p.name, p.alias, p.standard, p.makearea, p.deduct, p.TC1, p.TC2, p.tcmoney, p.Inputman, 
                                              p.Inputdate, c.retailprice, u.name AS UnitName1, p.child_number, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                                              p.Custompro5, p.parent_id, p.deleted
                       FROM          dbo.products AS p LEFT JOIN
                                              dbo.price AS c ON p.product_id = c.p_id AND p.unit1_id = c.u_id INNER JOIN
                                              dbo.unit AS u ON p.unit1_id = u.unit_id
                       WHERE      (p.child_number = 0) AND (p.deleted <> 1) and p.IsSplit=0/*zjx--tfs46253--20170308--过滤掉拆零		*/
                         ) AS pd LEFT OUTER JOIN
                          (select * from #tmpA_D) AS sd ON pd.product_id = sd.p_id LEFT OUTER JOIN
                          (SELECT     s_1.p_id, s_1.SHQTY
                            FROM          (SELECT     h.p_id, SUM(h.quantity) AS SHQTY
                                                    FROM          dbo.FilterStorehouse(@nloginEID) AS h LEFT OUTER JOIN
                                                                           dbo.company AS y ON h.Y_ID = y.company_id LEFT OUTER JOIN
                                                                           dbo.storages AS g ON h.s_id = g.storage_id
                                                    WHERE      (g.class_id LIKE @szSClass_ID + '%') AND (y.class_id LIKE @nYClassid + '%')
                                                    AND ((@Storetable=0) OR (h.s_id in (select [id] from #storagestable)))
												   AND ((@Companytable=0) or (h.Y_id in (select [id] from #Companytable)))
                                                    GROUP BY h.p_id) AS s_1
                                                    ) AS sh ON pd.product_id = sh.p_id
                      left join (SELECT     p_id, C_Name, e_name
                                                         FROM          dbo.vw_productbalance
                                                         WHERE      (Y_id = @nTmpY)
                                                         GROUP BY p_id, C_Name, e_name) AS P_other on P_other.p_id = pd.product_id                                    
ORDER BY pd.product_id
  END
	GOTO SUCCEE

END
	
/*客户销售排行*/
GetCSaleSort:
BEGIN
   if OBJECT_ID('tempdb..#TempCSalePH') is not null
        drop table #TempCSalePH

   SELECT P.[Class_ID] as PClass_id,
		  ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],  ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
		  ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
		  ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
		  ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
		  ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

		  /*abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,*/
		  ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
		  ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
	    
	   	  /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,*/
		  (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

     INTO #TempCSalePH
     FROM  
       (select * from Clients where  deleted<>1
        AND ((@ClientTable=0) or (Client_id in (select [id] from #Clienttable)))
       )P
     LEFT JOIN
       (SELECT YPD.[C_ID],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[Quantity] else -YPD.[Quantity] end),0) AS [Quantity],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[TaxTotal] else -YPD.[TaxTotal] end),0) AS [TaxTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],
	  		   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[SendQTY]  ELSE -YPD.[SendQTY] end), 0) AS [SendQTY],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[SendCostTotal] else -YPD.[SendCostTotal] end),0) AS [SendCostTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] else -YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] end),0) AS [SendTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[quantity]*YPD.[costprice]  else -YPD.[quantity]*YPD.[costprice] end), 0) AS [CostTotal]
          FROM 
            (SELECT b.c_id,sm.quantity,costprice,totalmoney,taxtotal,
                    sm.SendQTY,sm.SendCostTotal,B.billtype
               FROM  salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm                  */
               LEFT JOIN billidx   b  ON b.billid=sm.bill_id
               LEFT JOIN Products  p  on p.product_id=sm.p_id
               LEFT JOIN employees RE on re.emp_id=sm.RowE_id
               LEFT JOIN storages  S  on S.storage_id=sm.ss_id
               LEFT JOIN Clients   C  on b.c_id=c.client_id
               LEFT JOIN employees E  on b.inputman=E.emp_id 
               LEFT JOIN Company   Y  on Y.Company_id=b.y_id 
               LEFT JOIN Region    R  ON b.region_id=r.region_id               
              WHERE ([Billdate] BETWEEN   @BeginDate AND  @EndDate) and
                    [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                    AND aoid in (0,5) and p_id>0 and
                    ((@szPClass_ID IN ('', '%%', '000000')) or (p.class_id LIKE @szPClass_ID+'%'))  AND
                    ((@szRClass_id IN ('', '%%', '000000')) or (R.class_id like @szRClass_id+'%')) AND
                    ((@szEClass_ID IN ('', '%%', '000000')) or (Re.class_id like @szEClass_ID+'%'))AND
                    ((@szSClass_ID IN ('', '%%', '000000')) OR (S.Class_id like @szSClass_id+'%')) AND 
                    ((@szCClass_ID IN ('', '%%', '000000')) OR (C.Class_ID LIKE @szCClass_id+'%')) AND
                    ((@nLocation_Id=0)  OR (sm.Location_Id=@nLocation_Id)) AND
                    ((@szInputClass_ID IN ('', '%%', '000000')) OR (E.Class_ID LIKE @szInputClass_id+'%')) AND
                    ((@nYClassID='') or (Y.Class_id like @nYClassID+'%')) AND
                    ((@ClientTable=0) or (B.c_id in (select [id] from #Clienttable)))AND
                    ((@Companytable=0)or (B.Y_id in (select [id] from #Companytable)))  and
                    ((@Storetable=0) OR (sm.ss_id in (select [id] from #storagestable)   ))           
            )YPD
        GROUP BY YPD.[C_ID]
       ) SM ON P.[Client_ID]=sm.[C_ID]
    GROUP BY P.[Class_ID]
	SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempCSalePH
 IF @szListFlag='L'
  BEGIN
  	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
			 ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],  ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal],
			 ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],
			 ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			  ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio, 
			  /*ISNULL(SUM(SH.ratio),0) as ratio,*/
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From clients P
		Left join #TempCSalePH SH on LEFT(SH.[PClass_ID],LEN(p.[Class_ID]))=p.[Class_ID]
		where  p.parent_id=@szParent_id and p.deleted<>1 and (P.region_id = @nregion_id OR @nregion_id = 0)  /*通过片区过滤 add by luowei 2012-12-05*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
                  P.[Name], P.[Contact_personal], P.[Address],
                  p.[Parent_ID],P.C_Customname1,p.C_Customname2,
                  p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_id
  END
  
  IF @szListFlag='P'
  BEGIN
	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
	         ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio, 
			 /*ISNULL(SUM(SH.ratio),0) as ratio,*/
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From Clients P
		Left join #TempCSalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where  LEFT(p.[Class_ID], LEN(@szParent_id))=@szParent_id and p.deleted<>1 and p.[Child_Number]=0
		and (P.region_id = @nregion_id OR @nregion_id = 0)  /*通过片区过滤 add by luowei 2012-12-05*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_ID    
  END
  
  IF @szListFlag='A'
  BEGIN
	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
             ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio, 
			 /*ISNULL(SUM(SH.ratio),0) as ratio,*/
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From clients P
		Left join #TempCSalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where p.[DELETEd]<>1 and p.[Child_Number]=0 and p.[Client_ID]<>1
		and (P.region_id = @nregion_id OR @nregion_id = 0)  /*通过片区过滤 add by luowei 2012-12-05*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_ID  
  END   
  GOTO SUCCEE
  
END	

/*职员销售排行*/
GetESaleSort:	
BEGIN
     if OBJECT_ID('tempdb..#TempESalePH') is not null
        drop table #TempESalePH

  SELECT P.[Class_ID] as PClass_id,
		 ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
		 ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
		 ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
		 ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
		 ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
		 ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
		 ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

	     /*abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,*/
		 ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
		 ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
	     
		 /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,*/
		 (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

    INTO  #TempESalePH
    FROM 
      (select * from Employees where deleted<>1
       AND ((@employeestable=0) OR (Emp_id in (select [id] from #Employeestable)))
      )P
    LEFT JOIN
    (SELECT YPD.[RowE_ID],
	        ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]  ELSE -YPD.[QUANTITY] END), 0) AS [QUANTITY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TAXTOTAL]  ELSE -YPD.[TAXTOTAL] END), 0) AS [TAXTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TOTALMONEY] ELSE  -YPD.[TOTALMONEY] END),0) AS [SALETOTAL],
		
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0) AS [SENDQTY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDCOSTTOTAL]  ELSE -YPD.[SENDCOSTTOTAL] END),0) AS [SENDCOSTTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY*(1+YPD.taxrate) ELSE -YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY*(1+YPD.taxrate) END),0) AS [SENDTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]*YPD.[COSTPRICE]  ELSE -YPD.[QUANTITY]*YPD.[COSTPRICE] END), 0) AS [COSTTOTAL]

       FROM  
         (SELECT sm.RowE_id,sm.quantity,costprice,totalmoney,taxtotal,
                 sm.SendQTY,sm.SendCostTotal * (1 + sm.taxrate) AS SendCostTotal,B.billtype,sm.taxrate
            FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm                  */
            LEFT JOIN billidx   b  on sm.bill_id=b.billid
            LEFT JOIN Products  p  on p.product_id=SM.p_id
            LEFT JOIN employees RE on re.emp_id=SM.RowE_id
            LEFT JOIN storages  S  on S.storage_id=SM.ss_id
            LEFT JOIN Clients   C  on B.c_id=c.client_id
            LEFT JOIN employees E  on b.inputman=E.emp_id 
            LEFT JOIN Company   Y  on Y.Company_id=b.y_id            
            WHERE ([Billdate] BETWEEN   @BeginDate AND  @EndDate) and 
                  B.[billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and
                  [Billstates]=0 AND aoid in (0,5) and p_id>0 and 
                  ((@szPClass_ID IN ('', '%%', '000000')) or (p.class_id LIKE @szPClass_ID+'%'))  AND
                  ((@szSClass_ID IN ('', '%%', '000000')) OR (S.Class_id like @szSClass_id+'%')) AND 
                  ((@szCClass_ID IN ('', '%%', '000000')) OR (C.Class_ID LIKE @szCClass_id+'%')) AND
                  ((@nLocation_Id=0)  OR (sm.Location_Id=@nLocation_Id)) AND
                  ((@nYClassID='') or (Y.Class_id like @nYClassID+'%')) AND
                  ((@employeestable=0) OR (sm.RowE_id in (select [id] from #employeestable))) AND
                  ((@ClientTable=0) or (B.c_id in (select [id] from #Clienttable)))AND
                  ((@Companytable=0)or (B.Y_id in (select [id] from #Companytable)))   and
                   ((@Storetable=0) OR (sm.ss_id in (select [id] from #storagestable)   ))               
         )YPD
       GROUP BY YPD.[ROWE_ID]) SM
    ON SM.[ROWE_ID]=P.[Emp_ID]
    GROUP BY P.[Class_ID]
	SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempESalePH
 IF @szListFlag='L'
  BEGIN
	  Select P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
             P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted],
			 ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],  ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal],
			 ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],
			 ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 /*ISNULL(SUM(SH.ratio),0) as ratio,*/
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio,
             (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From employees P
		Left join #TempESalePH SH on LEFT(SH.[PClass_ID],LEN(p.[Class_ID]))=p.[Class_ID]
		where  p.parent_id=@szParent_id and p.deleted<>1
		Group by  P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
                  P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted]
		Order by p.emp_id
  END
  
  IF @szListFlag='P'
  BEGIN
	  Select P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
             P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted],
	         ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio,
			 /*ISNULL(SUM(SH.ratio),0) as ratio,*/
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From employees P
		Left join #TempESalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where  LEFT(p.[Class_ID], LEN(@szParent_id))=@szParent_id and p.deleted<>1 and p.[Child_Number]=0
		Group by  P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
             P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted]
		Order by p.emp_ID    
  END
  
  IF @szListFlag='A'
  BEGIN
	  Select P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
             P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted],
             ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 CASE WHEN @dMlTotal <> 0 THEN ISNULL(SUM(SH.MlTotal),0)/@dMlTotal*100 ELSE 0 END AS ratio,
			 /*ISNULL(SUM(SH.ratio),0) as ratio,*/
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From employees P
		Left join #TempESalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where p.[DELETEd]<>1 and p.[Child_Number]=0 and p.[emp_ID]<>1
		Group by  P.[Class_ID],P.[Emp_ID],  P.[Child_Number], P.[Serial_Number], P.[Name],
             P.[Phone], P.[Address] ,p.[Parent_ID],p.[Deleted]
        Order by p.emp_id  
  END   

  GOTO SUCCEE
END

/*分支机构销售排行*/
GetMSaleSort:	

BEGIN
   if OBJECT_ID('tempdb..#YTempYSalePH') is not null
        drop table #YTempYSalePH


SELECT Y.* INTO #YTempYSalePH FROM
  (SELECT P.[company_id] as Posid, P.[serial_number], P.[Name], P.[Child_Number] , P.[parent_id],p.class_id,p.[Deleted],
    ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
    ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
    ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
    
    ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
    ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
    ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
    ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

    abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,
    ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
    ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
    
    /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,*/
    (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

  FROM 
    (select * from Company where deleted<>1
     AND (@CompanyTable=0 or (Company_id in (select [id] from #Companytable)))
    )P 
    
    LEFT JOIN 
    (SELECT YPD.[YClass_ID],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]  ELSE -YPD.[QUANTITY] END), 0) AS [QUANTITY],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TAXTOTAL]  ELSE -YPD.[TAXTOTAL] END), 0) AS [TAXTOTAL],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TOTALMONEY] ELSE  -YPD.[TOTALMONEY] END),0) AS [SALETOTAL],
	
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0) AS [SENDQTY],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDCOSTTOTAL]  ELSE -YPD.[SENDCOSTTOTAL] END),0) AS [SENDCOSTTOTAL],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY  ELSE -YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY END),0) AS [SENDTOTAL],
	ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]*YPD.[COSTPRICE]  ELSE -YPD.[QUANTITY]*YPD.[COSTPRICE] END), 0) AS [COSTTOTAL]

     FROM  
        (SELECT SMYPD.* from 
           (SELECT PD.*,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(S.Class_id,'')SClass_id
                  ,isnull(C.Class_id,'')CClass_id,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id 
            FROM 
              (select VP.*,VB.billtype,VB.inputman,VB.c_id,VB.Y_ID  from
                (select stm.* from 
                  (select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from salemanagebill sm   /*FilterSalemanagebill(@nloginEID)*/
                   where aoid in (0,5) and p_id>0 AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable))
                   UNION ALL
                   select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from TranManagebill 
                   where aoid in (0,5) and p_id>0 AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable))
                  )stm
                )VP 
            INNER JOIN
              (select B.* from 
                (select billid,billtype,billstates,b.inputman,billdate,c_id,b.y_id                     
                 from billidx b 
                 where [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                       AND ([Billdate] BETWEEN   @BeginDate AND  @EndDate)
                )B
              )VB  ON VP.[Bill_ID]=VB.[BillID]               
          )PD
              LEFT JOIN Products  p  on p.product_id=PD.p_id
              LEFT JOIN employees RE on re.emp_id=PD.RowE_id
              LEFT JOIN storages  S  on S.storage_id=PD.s_id
              LEFT JOIN Clients   C  on PD.c_id=c.client_id
              LEFT JOIN employees E  on PD.inputman=E.emp_id 
              LEFT JOIN Company   Y  on Y.Company_id=pd.y_id
         )SMYPD
        )YPD
            WHERE 
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*              AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*              AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
/*              AND ((@ClientTable=0) or (YPD.c_id in (select [id] from #Clienttable)))*/
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable))) 
    
    GROUP BY YPD.[YClass_id]) SM

    ON LEFT(SM.[YClass_ID], LEN(P.[Class_ID]))=P.[Class_ID]

   GROUP BY P.[company_id], P.[serial_number], P.[Name], P.[parent_id],p.class_id, P.[Child_Number],p.[Deleted]
  )Y
   ORDER BY Y.[Posid]

  GOTO SalePH
    
END

/*仓库销售排行*/
GetSSaleSort:	
BEGIN
if OBJECT_ID('tempdb..#TempSSalePH') is not null
        drop table #TempSSalePH

select S.* into #TempSSalePH FROM 
    (SELECT P.[Storage_ID], P.[Class_ID], P.[Child_Number], P.[Serial_Number], P.[Name],P.[Parent_ID],p.[Deleted],
    ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
    ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],
    ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
    ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
    ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
    ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
    ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],

    abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,
    ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
    ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
    /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,*/
    (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

 
    FROM 
    (select * from vw_Storage where /*(@nYClassID='' or YClass_id like @nYClassID+'%' or YClass_id='') and*/
      deleted<>1
     AND (@Storetable=0   or ((class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and class_id like u.psc_id+'%'))))
    )P

    LEFT JOIN

    (SELECT YPD.[sclass_ID],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Quantity] else -YPD.[Quantity] end), 0) AS [Quantity],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[TaxTotal] else -YPD.[TaxTotal] end), 0) AS [TaxTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendQTY]  else -YPD.[SendQTY] end), 0) AS [SendQTY],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendCostTotal] else -YPD.[SendCostTotal] end),0) AS [SendCostTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] else -YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] end),0) AS [SendTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[quantity]*YPD.[costprice] else -YPD.[quantity]*YPD.[costprice]  end), 0) AS [CostTotal]
    FROM 
        (SELECT SMYPD.* from 
           (SELECT PD.*,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(S.Class_id,'')SClass_id
                  ,isnull(C.Class_id,'')CClass_id,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id 
            FROM 
              (select VP.*,VB.billtype,VB.inputman,VB.c_id,VB.Y_ID  from
                (select stm.* from 
                  (select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from salemanagebill sm   /*FilterSalemanagebill(@nloginEID)*/
                   where aoid in (0,5) and p_id>0 AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable))
                   UNION ALL
                   select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from TranManagebill 
                   where aoid in (0,5) and p_id>0 AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable))
                  )stm
                )VP 
            INNER JOIN
              (select B.* from 
                (select billid,billtype,billstates,b.inputman,billdate,c_id,b.y_id                     
                 from billidx b 
                 where [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                       AND ([Billdate] BETWEEN   @BeginDate AND  @EndDate)
                )B
              )VB  ON VP.[Bill_ID]=VB.[BillID]               
          )PD
              LEFT JOIN Products  p  on p.product_id=PD.p_id
              LEFT JOIN employees RE on re.emp_id=PD.RowE_id
              LEFT JOIN storages  S  on S.storage_id=PD.s_id
              LEFT JOIN Clients   C  on PD.c_id=c.client_id
              LEFT JOIN employees E  on PD.inputman=E.emp_id 
              LEFT JOIN Company   Y  on Y.Company_id=pd.y_id
         )SMYPD
        )YPD
            WHERE 
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*             AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
             AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) 
/*             AND ((@ClientTable=0) or (YPD.c_id in (select [id] from #Clienttable)))*/
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable))) 

     GROUP BY YPD.[sclass_ID]) SM 
     ON LEFT(SM.[sclass_ID], LEN(P.[Class_ID]))=P.[Class_ID]
    
     GROUP BY P.[Storage_ID], P.[Class_ID], P.[Child_Number], P.[Serial_Number], P.[Name],p.[Parent_ID],p.[Deleted]
    )S 
    ORDER BY S.[Storage_ID]

  GOTO SalePH
END

/*片区销售排行*/
GetASaleSort:	
BEGIN

if OBJECT_ID('tempdb..#TempRSalePH') is not null
        drop table #TempRSalePH

  SELECT S.* INTO #TempRSalePH from
    (SELECT P.[Region_ID], P.[Class_ID], P.[Child_Number], P.[Serial_Number], P.[Name],P.[Parent_ID],p.[Deleted],

    ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
    ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
    ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
    
    ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
    ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
    ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
    ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

    abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,
    ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
    ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
    
    /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal  else 0 end) as ratio,*/
    (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate


    FROM (select * from Region where deleted<>1)P  LEFT JOIN 

    (SELECT YPD.[RClass_ID] AS [Class_ID],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Quantity] else -YPD.[Quantity]   end), 0) AS [Quantity],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[TaxTotal] else -YPD.[TaxTotal]   end), 0) AS [TaxTotal],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],

      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendQTY]  else -YPD.[SendQTY]  end), 0) AS [SendQTY],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendCostTotal]  else -YPD.[SendCostTotal] end),0) AS [SendCostTotal],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.totalmoney  else -YPD.totalmoney end),0) AS [SendTotal],
      ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[quantity]*YPD.[costprice] else -YPD.[quantity]*YPD.[costprice] end), 0) AS [CostTotal]

      FROM
        (SELECT SMYPD.* from 
           (SELECT PD.*,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(S.Class_id,'')SClass_id
                  ,isnull(C.Class_id,'')CClass_id,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id
                  ,ISNULL(r.class_id,'')RClass_id 
            FROM 
              (select VP.*,VB.billtype,VB.inputman,VB.c_id,VB.Y_ID,region_id  from
                (select stm.* from 
                  (select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from salemanagebill sm   /*FilterSalemanagebill(@nloginEID)*/
                   where aoid in (0,5) and p_id>0  AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable))
                   UNION ALL
                   select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from TranManagebill 
                   where aoid in (0,5) and p_id>0  AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable) )
                  )stm
                )VP 
            INNER JOIN
              (select B.* from 
                (select billid,billtype,billstates,b.inputman,billdate,c_id,b.y_id ,region_id                    
                 from billidx b 
                 where [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                       AND ([Billdate] BETWEEN   @BeginDate AND  @EndDate)
                )B
              )VB  ON VP.[Bill_ID]=VB.[BillID]
          )PD
              LEFT JOIN Products  p  on p.product_id=PD.p_id
              LEFT JOIN employees RE on re.emp_id=PD.RowE_id
              LEFT JOIN storages  S  on S.storage_id=PD.s_id
              LEFT JOIN Clients   C  on PD.c_id=c.client_id
              LEFT JOIN employees E  on PD.inputman=E.emp_id 
              LEFT JOIN Company   Y  on Y.Company_id=pd.y_id
              LEFT JOIN Region    r  on r.region_id=pd.region_id
         )SMYPD
        )YPD
            WHERE 
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*             AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*             AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
/*             AND ((@ClientTable=0) or (YPD.c_id in (select [id] from #Clienttable)))*/
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable))) 
    Group by YPD.RClass_ID
    ) SM
       ON LEFT(SM.[class_ID], LEN(P.[Class_ID]))=P.[Class_ID]

   WHERE P.[Deleted]<>1
   GROUP BY P.[Region_ID], P.[Class_ID], P.[Child_Number], P.[Serial_Number], P.[Name],P.[Parent_ID],p.[Deleted]
   )S
   ORDER BY S.Region_ID


  GOTO SalePH
END


/*部门销售排行*/
GetDSaleSort: 	
BEGIN
/*加入一个临时的部门表,再插入一行，名称为临时部门*/
  if OBJECT_ID('tempdb..#TempDepartment') is not null
    drop table #TempDepartment
  SELECT top 0 (0) as DepartmentID, [Serial_number], [Name], [Deleted], (0) AS [ID1] INTO #TempDepartment
    from Department
    
  insert INTO #TempDepartment([DepartmentID], [Serial_number], [Name], [Deleted], [ID1])
    SELECT [DepartmentID], [Serial_number], [Name], [Deleted], (0) AS [ID1] 
       FROM Department
       WHERE [Deleted]<>1

    INSERT INTO #TempDepartment([DepartmentID], [Serial_number], [Name], [Deleted], [ID1])
    VALUES(0, '', '其它部门', 0, 1)

    DECLARE @TempDeptResult TABLE (DepartmentID [INT], Serial_Number [VARCHAR] (100), NAME [VARCHAR] (100), ID1 [INT], 
                                   Quantity [NUMERIC] (18, 4), TaxTotal [NUMERIC] (18, 4), SaleTotal [NUMERIC] (18, 4),
                                   SendQTY [NUMERIC] (18, 4), SendCostTotal [NUMERIC] (18, 4), SendTotal [NUMERIC] (18, 4), 
                                   CostTotal [NUMERIC] (18, 4), ml [NUMERIC] (18, 4))
    INSERT INTO @TempDeptResult
    SELECT P.[DepartmentID], P.[Serial_Number], P.[Name], P.[ID1],
    ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
    ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
    ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
    ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
    ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
    ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
    ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],
    CASE WHEN ISNULL(SUM(SM.[Quantity]), 0) <> 0 THEN ISNULL(SUM(SM.[SendQTY]), 0) * ISNULL(SUM(SM.[TaxTotal]), 0) / ISNULL(SUM(SM.[Quantity]), 0) - ISNULL(SUM(SM.[SendCostTotal]),0) ELSE 0 END AS ml
    FROM #TempDepartment P
    LEFT JOIN 
    (SELECT YPD.[Department_ID] AS [Class_ID],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Quantity] else -YPD.[Quantity] end), 0) AS [Quantity],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[TaxTotal] else -YPD.[TaxTotal] end), 0) AS [TaxTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],

    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendQTY]  else -YPD.[SendQTY]  end), 0) AS [SendQTY],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendCostTotal]  else -YPD.[SendCostTotal]  end),0) AS [SendCostTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.totalmoney/YPD.quantity*YPD.[SendQTY]  else -YPD.totalmoney/YPD.quantity*YPD.[SendQTY] end),0) AS [SendTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[quantity]*YPD.[costprice] else -YPD.[quantity]*YPD.[costprice] end), 0) AS [CostTotal]

    FROM 
       (SELECT SMYPD.* from 
           (SELECT PD.*,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(S.Class_id,'')SClass_id
                  ,isnull(C.Class_id,'')CClass_id,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id
                   
            FROM 
              (select VP.*,VB.billtype,VB.inputman,VB.c_id,VB.Y_ID,VB.Department_ID  from
                (select stm.* from 
                  (select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from salemanagebill sm   /*FilterSalemanagebill(@nloginEID)*/
                   where aoid in (0,5) and p_id>0  AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable) )
                   UNION ALL
                   select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from TranManagebill 
                   where aoid in (0,5) and p_id>0  AND ((@Storetable=0) OR ss_id in (select [id] from #storagestable) )
                  )stm
                )VP 
            INNER JOIN
              (select B.* from 
                (select billid,billtype,billstates,b.inputman,billdate,c_id,b.y_id ,Department_ID                    
                 from billidx b 
                 where [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                      AND ([Billdate] BETWEEN   @BeginDate AND  @EndDate)
                )B
              )VB  ON VP.[Bill_ID]=VB.[BillID]               
          )PD
              LEFT JOIN Products  p  on p.product_id=PD.p_id
              LEFT JOIN employees RE on re.emp_id=PD.RowE_id
              LEFT JOIN storages  S  on S.storage_id=PD.s_id
              LEFT JOIN Clients   C  on PD.c_id=c.client_id
              LEFT JOIN employees E  on PD.inputman=E.emp_id 
              LEFT JOIN Company   Y  on Y.Company_id=pd.y_id
         )SMYPD
        )YPD
            WHERE 
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*              AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*              AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
/*              AND ((@ClientTable=0) or (YPD.c_id in (select [id] from #Clienttable)))*/
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable))) 

     GROUP BY YPD.[Department_ID]) SM
     ON  SM.[Class_ID]=P.[DepartmentID]

    WHERE P.[Deleted]<>1
    GROUP BY P.[DepartmentID], P.[Serial_Number], P.[Name], P.[ID1]
    ORDER BY P.[ID1], P.[DepartmentID]
  SELECT @dMlTotal = ISNULL(SUM(ml), 0) FROM @TempDeptResult
  SELECT * FROM @TempDeptResult
  if OBJECT_ID('tempdb..#TempDepartment') is not null
    drop table #TempDepartment
  GOTO SUCCEE
END

/*货位销售排行榜*/
GetLSaleSort:
BEGIN
	DECLARE @nSID INT
	IF @szSClass_ID NOT IN ('', '%%','000000') 
    SELECT @nSID=[Storage_ID] FROM Storages WHERE [Class_ID]=@szSClass_ID AND [Deleted]<>1
	DECLARE @TempLocResult TABLE (Loc_ID [INT], Loc_Code [VARCHAR] (100), Loc_Name [VARCHAR] (100), Loc_Comment [VARCHAR] (200), Quantity [NUMERIC] (18, 4), 
	                              TaxTotal [NUMERIC] (18, 4), SaleTotal [NUMERIC] (18, 4), SendQTY [NUMERIC] (18, 4), SendCostTotal [NUMERIC] (18, 4),
	                              SendTotal [NUMERIC] (18, 4), CostTotal [NUMERIC] (18, 4), CostPrice [NUMERIC] (18, 4), setotal [NUMERIC] (18, 4), 
	                              MlTotal [NUMERIC] (18, 4), Mlrate[NUMERIC] (18,4))  
  INSERT INTO @TempLocResult
  SELECT P.[Loc_ID], P.[Loc_Code], P.[Loc_Name], P.[Loc_Comment],
    ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
    ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
    ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
    ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
    ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
    ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal], 
    ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],
    abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,
    ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
    ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
    /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,*/
    (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate
 FROM location P LEFT JOIN 
    (SELECT YPD.[Location_ID],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Quantity] else -YPD.[Quantity] end), 0) AS [Quantity],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[TaxTotal] else -YPD.[TaxTotal] end), 0) AS [TaxTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],             
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendQTY] else -YPD.[SendQTY] end), 0) AS [SendQTY],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[SendCostTotal] else -YPD.[SendCostTotal] end),0) AS [SendCostTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.totalmoney/YPD.quantity*YPD.[SendQTY] else -YPD.totalmoney/YPD.quantity*YPD.[SendQTY] end),0) AS [SendTotal],
    ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) then YPD.[quantity]*YPD.[costprice] else -YPD.[quantity]*YPD.[costprice]  end), 0) AS [CostTotal]
    FROM 
       (SELECT SMYPD.* from 
           (SELECT PD.*,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(S.Class_id,'')SClass_id
                  ,isnull(C.Class_id,'')CClass_id,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id
                   
            FROM 
              (select VP.*,VB.billtype,VB.inputman,VB.c_id,VB.Y_ID  from
                (select stm.* from 
                  (select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from salemanagebill sm   /*FilterSalemanagebill(@nloginEID)*/
                   where aoid in (0,5) and p_id>0
                   UNION ALL 
                   select bill_id,p_id,quantity,costprice,totalmoney,taxtotal,ss_id as s_id,location_id,RowE_id,SendQTY,SendCostTotal from TranManagebill 
                   where aoid in (0,5) and p_id>0
                  )stm
                )VP 
            INNER JOIN
              (select B.* from 
                (select billid,billtype,billstates,b.inputman,billdate,c_id,b.y_id                     
                 from billidx b 
                 where [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                       AND ([Billdate] BETWEEN   @BeginDate AND  @EndDate)
                )B
              )VB  ON VP.[Bill_ID]=VB.[BillID] 
          )PD
              LEFT JOIN Products  p  on p.product_id=PD.p_id
              LEFT JOIN employees RE on re.emp_id=PD.RowE_id
              LEFT JOIN storages  S  on S.storage_id=PD.s_id
              LEFT JOIN Clients   C  on PD.c_id=c.client_id
              LEFT JOIN employees E  on PD.inputman=E.emp_id 
              LEFT JOIN Company   Y  on Y.Company_id=pd.y_id
         )SMYPD
        )YPD
            WHERE 
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*              AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*              AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
/*              AND ((@ClientTable=0) or (YPD.c_id in (select [id] from #Clienttable)))*/
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable)))

    GROUP BY YPD.[Location_ID]) SM
    ON P.[Loc_ID]=SM.[Location_ID]
  WHERE P.[Deleted]<>1 AND P.[S_ID]=@nSID
  GROUP BY P.[Loc_ID], P.[Loc_Code], P.[Loc_Name], P.[Loc_Comment]
  ORDER BY P.[Loc_ID]
  SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM @TempLocResult
  SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN MlTotal/@dMlTotal*100 ELSE 0 END AS ratio FROM @TempLocResult P
  GOTO SUCCEE
END

GetSupsalesort:
BEGIN
	
  declare @cLen int
  if (@szParent_ID in ('', '%%', '000000'))
    set @cLen = 6
  else
    set @cLen = 6 + LEN(@szParent_ID)

  if OBJECT_ID('tempdb..#suppliersale') is not null
    drop table #suppliersale
  if OBJECT_ID('tempdb..#suppliersaleA') is not null  /*-全部列表*/
    drop table #suppliersaleA
    
    
  if @szListFlag NOT IN ('A','P')
  SELECT C.[Client_ID], C.[Class_ID], C.[Child_Number], C.[Serial_Number], c.Deleted,
     C.[Name],C.[Contact_personal], C.[Address],C.[Parent_ID],C.C_Customname1,C.C_Customname2,
     C.C_Customname3,C.C_Customname4,C.C_Customname5,isnull(p.qty,0)QTY,isnull(p.total,0)total,
     isnull(SendQty,0)SendQTY,isnull(Sendtotal,0)SendTotal,isnull(SendCostprice,0)SendCostprice,
     isnull(SendCosttotal,0)SendCosttotal,isnull(setotal,0)setotal,isnull(taxtotal,0)taxtotal,
     isnull(mltotal,0)mltotal,isnull(Mlrate,0)Mlrate

     into #suppliersale from Clients C 
  LEFT JOIN 
    (SELECT  LEFT(CClass_id, @cLen) as CClass_id,isnull(sum(-quantity),0)QTY,isnull(sum(-total),0)total,isnull(sum(-Sendqty),0)Sendqty,
        isnull(sum(-Sendqty*total/quantity),0)SendTotal,
        (case when isnull(sum(sendqty),0)<>0 then abs(sum(SendCosttotal)/sum(SendQty)) else 0 end)SendCostprice,  
        isnull(sum(-SendCosttotal),0)SendCosttotal,
        abs(isnull(sum(-taxtotal)-sum(-total),0))setotal,
        isnull(sum(-taxtotal),0)taxtotal,
        isnull(sum(-SendQty*total/quantity)-sum(-SendCosttotal),0) as MlTotal,
        (case when isnull(sum(-Sendqty*total/quantity),0)<>0 then (sum(-SendQty*total/quantity)-sum(-SendCosttotal))/sum(-SendQty*total/quantity) else 0 end )Mlrate 
        /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(-Sendqty*total/quantity) as NUMERIC(25,8)),0)-ISNULL(SUM(-[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio*/

     FROM
         (SELECT YPPD.*,isnull(C.[Class_id],'')CClass_id,isnull(P.[Class_id],'')PClass_id,
                 isnull(S.[Class_id],'')SClass_id,isnull(Y.[Class_id],'')YClass_id,isnull(RE.[Class_id],'')REClass_id,
                 isnull(E.[Class_id],'')InputmanClass_id
          FROM     
           (SELECT PD.*,b.Y_id,b.Inputman FROM
             (select  supplier_id,quantity,Total,SendQty,SendCosttotal,taxtotal,p_id,RowE_id,s_id,billid,location_id
                from  FilterProductdetail(@nloginEID) where aoid in (select szTYPE from #Largess) and p_id>0)PD
            INNER JOIN 
             (select billid,Y_id,Inputman
                from billidx where  [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and billstates=0
                                    and  (billdate between @begindate and @Enddate)          
              )B ON PD.billid=B.billid         
          )YPPD
          LEFT JOIN Clients   C  on C.Client_id=YPPD.supplier_id
          LEFT JOIN products  P  on P.product_id=YPPD.p_id
          LEFT JOIN employees RE on RE.emp_id=YPPD.RowE_id
          LEFT JOIN storages  S  on S.storage_id=YPPD.s_id
          LEFT JOIN Company   Y  on Y.Company_id=YPPD.Y_ID
          LEFT JOIN employees E  on E.emp_id=YPPD.inputman     
          )YPD
     WHERE       
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*           AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*           AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
             AND ((@ClientTable=0) or (YPD.supplier_id in (select [id] from #Clienttable)))
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable)))
        Group by LEFT(CClass_id, @cLen)
    )p   ON LEFT(p.[cclass_ID], LEN(c.[Class_ID]))=c.[Class_ID]

  WHERE  C.deleted<>1
  else
  SELECT C.[Client_ID], C.[Class_ID], C.[Child_Number], C.[Serial_Number], c.Deleted,
     C.[Name],C.[Contact_personal], C.[Address],C.[Parent_ID],C.C_Customname1,C.C_Customname2,
     C.C_Customname3,C.C_Customname4,C.C_Customname5,isnull(p.qty,0)QTY,isnull(p.total,0)total,
     isnull(SendQty,0)SendQTY,isnull(Sendtotal,0)SendTotal,isnull(SendCostprice,0)SendCostprice,
     isnull(SendCosttotal,0)SendCosttotal,isnull(setotal,0)setotal,isnull(taxtotal,0)taxtotal,
     isnull(mltotal,0)mltotal,isnull(Mlrate,0)Mlrate

     into #suppliersaleA from Clients C 
  LEFT JOIN 
    (SELECT  CClass_id,isnull(sum(-quantity),0)QTY,isnull(sum(-total),0)total,isnull(sum(-Sendqty),0)Sendqty,
        isnull(sum(-Sendqty*total/quantity),0)SendTotal,
        (case when isnull(sum(sendqty),0)<>0 then abs(sum(SendCosttotal)/sum(SendQty)) else 0 end)SendCostprice,  
        isnull(sum(-SendCosttotal),0)SendCosttotal,
        abs(isnull(sum(-taxtotal)-sum(-total),0))setotal,
        isnull(sum(-taxtotal),0)taxtotal,
        isnull(sum(-SendQty*total/quantity)-sum(-SendCosttotal),0) as MlTotal,
        (case when isnull(sum(-Sendqty*total/quantity),0)<>0 then (sum(-SendQty*total/quantity)-sum(-SendCosttotal))/sum(-SendQty*total/quantity) else 0 end )Mlrate 
        /*(case when @dMlTotal<>0 then (ISNULL(cast(SUM(-Sendqty*total/quantity) as NUMERIC(25,8)),0)-ISNULL(SUM(-[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio*/

     FROM
         (SELECT YPPD.*,isnull(C.[Class_id],'')CClass_id,isnull(P.[Class_id],'')PClass_id,
                 isnull(S.[Class_id],'')SClass_id,isnull(Y.[Class_id],'')YClass_id,isnull(RE.[Class_id],'')REClass_id,
                 isnull(E.[Class_id],'')InputmanClass_id
          FROM     
           (SELECT PD.*,b.Y_id,b.Inputman FROM
             (select  supplier_id,quantity,Total,SendQty,SendCosttotal,taxtotal,p_id,RowE_id,s_id,billid,location_id
                from  FilterProductdetail(@nloginEID) where aoid in (select szTYPE from #Largess) and p_id>0)PD
            INNER JOIN 
             (select billid,Y_id,Inputman
                from billidx where  [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and billstates=0
                                    and  (billdate between @begindate and @Enddate)          
              )B ON PD.billid=B.billid         
          )YPPD
          LEFT JOIN Clients   C  on C.Client_id=YPPD.supplier_id
          LEFT JOIN products  P  on P.product_id=YPPD.p_id
          LEFT JOIN employees RE on RE.emp_id=YPPD.RowE_id
          LEFT JOIN storages  S  on S.storage_id=YPPD.s_id
          LEFT JOIN Company   Y  on Y.Company_id=YPPD.Y_ID
          LEFT JOIN employees E  on E.emp_id=YPPD.inputman     
          )YPD
     WHERE       
                 ((@szPClass_ID IN ('', '%%', '000000')) or (YPD.pclass_id LIKE @szPClass_ID+'%'))
             AND ((@szEClass_ID IN ('', '%%', '000000')) or (YPD.Reclass_id like @szEClass_ID+'%'))
             AND ((@szSClass_ID IN ('', '%%', '000000')) OR (YPD.SClass_id like @szSClass_id+'%'))
             AND ((@nLocation_Id=0)  OR (YPD.Location_Id=@nLocation_Id))
             AND ((@szCClass_ID IN ('', '%%', '000000')) OR (YPD.CClass_ID LIKE @szCClass_id+'%'))
             AND ((@szInputClass_ID IN ('', '%%', '000000')) OR (YPD.InputmanClass_ID LIKE @szInputClass_id+'%'))
             AND ((@nYClassID='') or (YPD.YClass_id like @nYClassID+'%'))
/*           AND ((@employeestable=0) OR (YPD.RowE_id in (select [id] from #employeestable)))*/
/*           AND ((@Storetable=0) OR (YPD.s_id in (select [id] from #storagestable))) */
             AND ((@ClientTable=0) or (YPD.supplier_id in (select [id] from #Clienttable)))
             AND ((@Companytable=0)or (YPD.Y_id in (select [id] from #Companytable)))
        Group by CClass_id
    )p   ON LEFT(p.[cclass_ID], LEN(c.[Class_ID]))=c.[Class_ID]

  WHERE  C.deleted<>1
  
	 
IF @szListFlag='L'
BEGIN
	SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #suppliersale WHERE  [Parent_ID]=@szParent_ID
    select p.*, CASE WHEN @dMlTotal <> 0 THEN MlTotal/@dMlTotal*100 ELSE 0 END AS ratio from  #suppliersale p WHERE  p.[Parent_ID]=@szParent_ID
END    
IF @szListFlag='A'
BEGIN
	SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #suppliersaleA WHERE [Child_Number]=0 
    select p.*, CASE WHEN @dMlTotal <> 0 THEN MlTotal/@dMlTotal*100 ELSE 0 END AS ratio from  #suppliersaleA p WHERE P.[Child_Number]=0 
END
IF @szListFlag='P'
BEGIN
    SELECT @dMlTotal = ISNULL(SUM(P.MlTotal), 0) FROM #suppliersaleA P WHERE LEFT(P.[Class_ID], LEN(@szParent_ID))=@szParent_ID AND P.[Deleted]<>1 AND P.[Child_Number]=0
    select p.*, CASE WHEN @dMlTotal <> 0 THEN MlTotal/@dMlTotal*100 ELSE 0 END AS ratio from  #suppliersaleA p WHERE LEFT(P.[Class_ID], LEN(@szParent_ID))=@szParent_ID AND P.[Deleted]<>1 AND P.[Child_Number]=0
END
GOTO SUCCEE
END


SalePH:
BEGIN
    IF @nSortType = 0 OR @nSortType = 1 OR @nSortType = 2 
    BEGIN
        IF @nSortType=0  SELECT @tablename=' #TempPSalePH  P'
		IF @nSortType=1  SELECT @tablename=' #TempCSalePH  p'
		IF @nSortType=2  SELECT @tablename=' #TempESalePH  P'
		IF @szListFlag='L'
			SELECT @SQLChildTemp='select * from '+@tablename+'  WHERE P.[Parent_ID]='+CHAR(39)+@szParent_ID+CHAR(39)
        IF @szListFlag='A'
			SELECT @SQLChildTemp='select * from '+@tablename+'  WHERE P.[Child_Number]=0 '
		IF @szListFlag='P'
			SELECT @SQLChildTemp='select * from '+@tablename+'  WHERE LEFT(P.[Class_ID], LEN('+CHAR(39)+@szParent_ID+CHAR(39)+'))='+CHAR(39)+@szParent_ID+CHAR(39)
						+' AND P.[Deleted]<>1 AND P.[Child_Number]=0'
		EXEC (@SQLChildTemp)	
    END 
    IF @nSortType=3  
    BEGIN
    	IF @szListFlag='L' 
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #YTempYSalePH WHERE Parent_ID = @szParent_ID
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #YTempYSalePH P WHERE P.Parent_ID = @szParent_ID
		END
		IF @szListFlag='A'
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #YTempYSalePH WHERE Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #YTempYSalePH P WHERE P.Child_Number = 0
		END	
		IF @szListFlag='P'	
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #YTempYSalePH 
			WHERE LEFT(Class_ID, LEN(@szParent_ID)) = @szParent_ID AND Deleted <> 1 AND Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #YTempYSalePH P WHERE LEFT(P.Class_ID, LEN(@szParent_ID)) = @szParent_ID AND P.Deleted <> 1 AND P.Child_Number = 0
		END
    END
    IF @nSortType=4  
    BEGIN
		IF @szListFlag='L'
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempSSalePH WHERE Parent_ID = @szParent_ID
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempSSalePH P WHERE P.Parent_ID = @szParent_ID
		END
		IF @szListFlag='A'
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempSSalePH WHERE Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempSSalePH P WHERE P.Child_Number = 0
		END	
		IF @szListFlag='P'
		BEGIN	
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempSSalePH 
			WHERE LEFT(Class_ID, LEN(@szParent_ID)) = @szParent_ID AND Deleted <> 1 AND Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempSSalePH P WHERE LEFT(P.Class_ID, LEN(@szParent_ID)) = @szParent_ID AND P.Deleted <> 1 AND P.Child_Number = 0
		END	
    END
    IF @nSortType=5  
    BEGIN
		IF @szListFlag='L'
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempRSalePH WHERE Parent_ID = @szParent_ID
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempRSalePH P WHERE P.Parent_ID = @szParent_ID
		END
		IF @szListFlag='A'
		BEGIN
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempRSalePH WHERE Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempRSalePH P WHERE P.Child_Number = 0
		END	
		IF @szListFlag='P'
		BEGIN	
			SELECT @dMlTotal = ISNULL(SUM(MlTotal), 0) FROM #TempRSalePH 
			WHERE LEFT(Class_ID, LEN(@szParent_ID)) = @szParent_ID AND Deleted <> 1 AND Child_Number = 0
			SELECT P.*, CASE WHEN @dMlTotal <> 0 THEN P.MlTotal/@dMlTotal*100 ELSE 0 END AS ratio 
			FROM #TempRSalePH P WHERE LEFT(P.Class_ID, LEN(@szParent_ID)) = @szParent_ID AND P.Deleted <> 1 AND P.Child_Number = 0
		END	
    END     
GOTO
 SUCCEE
END

Succee:
  drop table #Clienttable
  drop table #Companytable
  drop table #employeestable
  drop table #storagestable
  if @nSortType <> 0
	if not OBJECT_ID('#TempPSalePH') IS NULL
	   drop table #TempPSalePH
  if not OBJECT_ID('#tmpresult') IS NULL
	drop table #tmpresult
	   
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED

  RETURN 0

ERROR101:
  drop table #Clienttable
  drop table #Companytable
  drop table #employeestable
  drop table #storagestable
  drop table #TempPSalePH
  if not OBJECT_ID('#tmpresult') IS NULL
	drop table #tmpresult
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  RETURN -1
GO
