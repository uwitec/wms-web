


CREATE VIEW dbo.vw_Employee
AS
SELECT     e.emp_id, e.class_id, e.parent_id, e.child_number, e.child_count, e.name, e.alias, e.serial_number, e.dep_id, e.phone, e.address, e.comment, 
                      e.aplimit, e.arlimit, e.aptotal, e.artotal, e.discountlimit, e.ls, e.th, e.pinyin, e.deleted, e.LowPrice, e.HighPrice, e.SNCount, e.GSPSNCount, e.Study, 
                      e.Duty, e.GraduateDate, e.Teach, e.szWork, e.InDate, e.ModifyDate, e.deduct, e.RowIndex, e.IdCard, e.CertNo, e.Tp_ID, e.Y_ID, e.GradeId, e.limPlugin, 
                      e.Y_ID AS EY_id, ISNULL(Y.name, '') AS EY_name, ISNULL(d.name, '') AS DepName, ISNULL(d.serial_number, '') AS DepCode, ISNULL(d.comment, '') 
                      AS DepComment, ISNULL(tp.Name, '') AS TpName, (CASE WHEN e.deleted = 0 THEN '正常' WHEN e.deleted = 4 THEN '停用' ELSE '删除' END) 
                      AS StatusName
FROM         dbo.employees AS e LEFT OUTER JOIN
                      dbo.department AS d ON e.dep_id = d.departmentId LEFT OUTER JOIN
                      dbo.TcProject AS tp ON e.Tp_ID = tp.TcProject_id LEFT OUTER JOIN
                      dbo.company AS Y ON Y.company_id = e.Y_ID
WHERE     (e.deleted <> 1)
GO
