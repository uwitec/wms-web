
CREATE PROCEDURE [dbo].[TS_H_PatientAct]
(
    @Tag		int =0,   /*0:新增 1:修改 2 :修改状态[删除,挂失,停用]   */
    @PatientID	int = 0,
    @Deleted	int =0,  
    @Name       varchar(20)='',
    @sex		varchar(10)='',
    @Tel		varchar(80)='',
    @Birthday	datetime=0,
    @Address	varchar(60)='',
    @Comment	varchar(300)='',
    @IDCard		varchar(20)='',
    @BulidDate	datetime=0,
    @Pos_id		int=0,
    @PinYin		varchar(20)='',
    @job		varchar(20)='',
    @isVIP		bit = 0,
    @VipID		int = 0
)
AS
/*Params Ini begin*/
if @Tag is null  SET @Tag = 0
if @PatientID is null  SET @PatientID = 0
if @Deleted is null  SET @Deleted = 0
if @Name is null  SET @Name = ''
if @sex is null  SET @sex = ''
if @Tel is null  SET @Tel = ''
if @Birthday is null  SET @Birthday = 0
if @Address is null  SET @Address = ''
if @Comment is null  SET @Comment = ''
if @IDCard is null  SET @IDCard = ''
if @BulidDate is null  SET @BulidDate = 0
if @Pos_id is null  SET @Pos_id = 0
if @PinYin is null  SET @PinYin = ''
if @job is null  SET @job = ''
if @isVIP is null  SET @isVIP = 0
if @VipID is null  SET @VipID = 0
/*Params Ini end*/
/*0:新增 */
IF @Tag=0 
BEGIN
    Declare @NewID int
    IF exists(select * from patients where patientid=@patientid)
    begin
       RETURN @patientid
    end
    
    INSERT INTO patients([Name],
                        sex,
                        Tel,
                        Birthday,
                        job,
                        Address,
                        Comment,
                        IDCard,
                        BulidDate,
                        Pos_Id,
					    Deleted,
                        PinYin,
                        isVip,
                        Vip_ID
                        )
    VALUES(@Name,
           @sex,
           @Tel,
           @Birthday,
           @Job,
           @Address,
           @Comment,
           @IDCard,
           @BulidDate,
           @Pos_Id,
		   @Deleted,  
           @PinYin,
           @isVip,
           @VipID
           )
    IF (@@error!=0)
    BEGIN
		RAISERROR('新增病人资料失败! ',16,1) 
		RETURN -1  
    END
    ELSE
    BEGIN 
		RETURN @@Identity
    END
END
/*1:修改 */
else
IF @Tag=1
BEGIN
    UPDATE patients SET
        [Name]=@Name,
        sex=@sex,
        Tel=@Tel,
        Birthday=@Birthday,
        Address=@Address,
        job=@job,
        Comment=@Comment,
        IDCard=@IDCard,
        PinYin=@PinYin
	WHERE patientID = @PatientID
    IF (@@error!=0)
    BEGIN
		RAISERROR('修改病人资料失败! ',16,1) 
		RETURN -1  
    END
    ELSE RETURN @PatientID
END
else
if @Tag = 2
begin
	if exists(select * from registered where patient_id = @patientId)
	begin
		raiserror('病人资料已被使用，不能删除！', 16, 1)
		return -1
	end
	delete from patients where patientid = @patientid
	return @patientid
end
GO
