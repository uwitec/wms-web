Create  procedure Ts_L_findIntegralgz 
  ( @bill_id  int             /*单据ID*/
  )  

AS	
set nocount on
 create table #tmpI    /*找出的积分的规则明细*/
 (
  p_id      int,
  billid    int,
  smb_id    int,
  VIPCardID int,
  Y_ID      int,
  CT_ID     int,
  I_id      int,
  isjf      int,
  Birthday  datetime,
  billdate  datetime,
  totalmoney  numeric(18, 2),
  billmoney  numeric(18, 2),
  basejf     numeric(18, 2), /*基础积分(来源会员卡类型，好多钱积一分)*/
  ubl        numeric(18, 2),
  cxbl       numeric(18, 2), /*促销比例*/
  jfbl       numeric(18, 2), /*积分比例*/
  totaljf    numeric(18, 2),  /*总积分 */
  SpecialPrice  numeric(18, 2),  /*商品特价*/
  rowguid uniqueidentifier,
  cxguid uniqueidentifier,   /*-xxx.2016-11-30 用来处理相同商品不同促销的时候取不同的积分设置*/
  remake  VARCHAR(100) NOT NULL DEFAULT ('积分明细')   /*明细备注*/
 )
 create table #tmpbl
 (
  I_ID        int,
  jfmoney     NUMERIC(25,8), 
  jfmode      int,
  daymode     int, 
  memberbl    numeric(18, 2), 
  birthdaybl  numeric(18, 2),
  SpecialIntegral int,   /*特价商品是否积分*/
  VSjfmoney     numeric(10, 4), /*会员日积分基础(来源会员卡类型，好多钱积一分)*/
  BSjfmoney     numeric(10, 4), /*会员生日积分基础(来源会员卡类型，好多钱积一分)*/
  VDayType     int,				/*会员日期选择类型*/
  VDays		   varchar(500),	/*会员日期字符串*/
/*  BDayType     int,				--会员生日期选择类型*/
  BDays		   INT				/*会员生日选择日期		*/
 )
  declare  @isItg int,@jfmode int,@ishyr int, @ishysr int,@cardid int,@I_id int,@daymode int,@rcount int
  declare  @daystr int,@vipcid int
  declare  @total numeric(18, 2),@ItgMoney numeric(18, 2)
  declare  @hyrbl numeric(18, 2),@hysrbl numeric(18, 2),@totalItg numeric(18, 2)
  declare  @Birthday  datetime,@billdate  datetime
  declare  @nl_day varchar(20),@week_day varchar(20) 
  declare  @yid int     /*单据的机构*/
  declare  @VItgMoney numeric(10, 4)    /*会员日基础积分金额*/
  declare  @BItgMoney numeric(10, 4)    /*会员生日基础积分金额*/
  declare  @VDayType int    /*会员日类型*/
  declare  @VDays varchar(500)    /*会员日时间*/
  declare  @BDays int    /*会员生日时间*/
  declare  @billguid varchar(60)
  set @ishyr  =0
  set @ishysr =0
  declare @nBillType int
  declare @isSpecialIntegral int
  /*-zjx--2017-02-04---tfs45293--处理零售单和零售退货单刷卡后没有写日志问题定义变量*/
  declare @comment varchar(100)
  declare @eid     int
  declare @order   varchar(50)
  declare @Currentintegral  numeric(18, 2)/*会员卡当前积分*/
  declare @CurrentCzYe numeric(18, 2)/*-储值卡当前余额*/
  declare @BcIntegrral  numeric(18, 2)/*会员卡本单积分*/
  declare @YIntegrral numeric(18, 2)/*会员卡原有积分*/
  declare @account_id  int  /*积分抵现科目id*/
  
   declare @by_id int
   declare @SzY_id varchar(10)
   declare @nPosDataMode int
   declare @IsBank int   /*是否是储值卡*/
  
  select @account_id = account_id from account where class_id = '000004000003000009'
  if @account_id is null set @account_id = 0
  
  select @nBillType = billtype, @yid = Y_ID, @billguid = [guid],@eid=e_id,@order=billnumber from billidx where billid = @bill_id
   /*-根据单据ID 获得明细商品ID*/
   insert into #tmpI
   select distinct b.p_id,a.billid,b.smb_id,a.VIPCardID,a.Y_ID,c.CT_ID,0 as I_id,d.isIntegral,
        c.Birthday,a.billdate,case when b.p_id >0 then b.taxtotal else -b.total end as totalmoney,a.ysmoney,0 as basejf,1 as ubl,1 as cxbl,0 as jfbl,0 as totaljf, 
        isnull(r.specialprice,0) as specialprice,b.RowGuid,b.CxGuid,'积分明细' as remake
   from billidx a,salemanagebill b,VIPCard c,VIPCardType d,products p,(select distinct p_id,MAX(specialprice) as specialprice from price group by p_id) r   /*暂时不考虑独立物价的*/
   where  a.billid=@bill_id and  a.billid=b.bill_id and b.AOID in(0,5) 
          and a.billtype in(12, 13) and b.p_id > 0
          and a.VIPCardID=c.VIPCardID  and c.CT_ID=d.ct_id
          and p.product_id=b.p_id 
          and b.p_id = r.p_id
          and d.isIntegral = 1   /*勾选了允许积分才能积分*/
          and p.ifIntegral=1 /*在商品资料中未勾选会员积分的排除 */
        
  /*---根据单据 机构和卡类型 找到最近的积分方案*/
  update #tmpI set basejf = ve.IntegralMoney from VipCardTypeExtend ve where #tmpI.CT_ID = ve.bill_id  /*取基础积分*/
  /*select * from #tmpI       */
    /*获得积分倍数*/
    insert into #tmpbl
    SELECT E.bill_id,E.IntegralMoney,E.Integralmode,e.Integralmode,E.memberbl,E.birthdaybl,E.isSpecialIntegral,/*,E.Specialbl,E.discountbl*/
			ISNULL(SD.VipDayInt,0) as VipDayInt,ISNULL(SD.BirDayInt,0) as BirDayInt,   /*取会员日的积分基数*/
			isnull(case when VipDayCheck = 0 then -1 when sd.calendar = 1 then 0 when sd.Lunar = 1 then 1 else 2 end,-1) as VDayType,
			isnull(case when VipDayCheck = 0 then '' when sd.calendar = 1 then sd.calendarStr when sd.Lunar = 1 then sd.LunarStr else WeekStr end,'') as VDays,
			isnull(case when BirCheck = 0 then -1 else BirStr end,-1) as BDays
						
    FROM VIPCARDTYPEEXTEND E left join 
		(select  * from VipCardTypeSpecialDay vs where (vs.YType = 0 or (vs.YType = 1 and vs.yidStr = CAST(@yid as varchar)) 
								or(vs.YType = 2 and  @yid in ( 
											   select company_id from FilterCompany(2) where company_id in ( 
												   select baseinfo_id from customCategoryMapping where category_id in 
												   (select id from customCategory where charindex('02',class_id)=1 and child_count = 0 and child_number = 0 
												   AND baseType in (2,-1) AND class_id <> '00') 
												   ) and deleted = 0  and child_count = 0 and child_number = 0     
											   )))
		)sd
    ON E.bill_id = sd.Bill_Id
    WHERE E.bill_id in (select CT_ID from #tmpI group by CT_ID)  
/*	select * from #tmpbl */
    /*-提取公共参数*/
    set @isItg=(select distinct isjf from  #tmpI)         /*是否积分*/
    set @Birthday=(select distinct Birthday from  #tmpI)  /*会员生日*/
    set @billdate=(select distinct billdate from  #tmpI)  /*单据日期*/
    set @vipcid  = (select top 1 VIPCardID from  #tmpI)   /*会员卡ID */
    if @vipcid is null
		select  @vipcid = VIPCardID from billidx where billid = @bill_id
    /*set @total   = (select top 1 billmoney from  #tmpI)   --总金额  这儿去消费的金额*/
    select  @total = SUM(taxtotal) from salemanagebill where bill_id = @bill_id and p_id > 0
    
    set @jfmode=(select distinct top 1 jfmode from  #tmpbl)     /*积分模式*/
    set @daymode=(select distinct top 1 daymode from  #tmpbl)   /*会员日设置模式*/
    set @daystr=DAY(@billdate)                            /*获得单据天*/
    select @nl_day=dbo.fn_GetLunar(@billdate,'dd')                /*农历天*/
    /*set language N’Simplified Chinese’    ---输出星期几 安装时一定要是 中文*/
    select  @week_day=datename(weekday,@billdate)             /*星期X*/
    set @I_id  =(select top 1 I_ID from #tmpbl)        /*积分方案ID*/
    set @ItgMoney=(select top 1 jfmoney from #tmpbl)      /*基础积分金额*/
    set @VItgMoney=(select top 1 VSjfmoney from #tmpbl)      /*会员日基础积分金额*/
	set @BItgMoney=(select top 1 BSjfmoney from #tmpbl)	      /*会员生日基础积分金额*/
    set @isSpecialIntegral =(select distinct top 1 SpecialIntegral from  #tmpbl) /*特价商品是否积分*/
    set @VDayType=(select top 1 VDayType from #tmpbl)      /*会员日类型*/
	set @VDays=(select top 1 VDays from #tmpbl)	      /*会员日时间*/
    set @BDays=(select top 1 BDays from #tmpbl)      /*会员生日时间选择  */
	
	/*取值原则：按积分高的优先，在统一处理中都乘了设置的积分倍数，所以如果是促销，也会乘以设置的积分倍数*/
	declare @CurDay varchar(10)
    if @VItgMoney > 0 or @BItgMoney > 0    /*设置了特殊日积分*/
    begin
        /*先处理会员日*/
		if @VItgMoney > 0 and @VDays <> ''   /*表示选择了会员日*/
		begin
			IF 	@VDayType = 0  /*表示公历*/
			begin
				select @CurDay = DAY(@billdate)  	
				if  CHARINDEX(@CurDay+',',@VDays+',') >0   /*表示单据日期在选择范围内*/
				begin
					if @VItgMoney < @ItgMoney
					  set @ItgMoney = @VItgMoney	 /*取最优  */
				end
			end
			ELSE IF @VDayType = 1  /*表示农历*/
			begin
				select @CurDay = SUBSTRING(dbo.fnSolarDateToLunarDate(@billdate), CharIndex('月', dbo.fnSolarDateToLunarDate(@billdate)) + 1, 2)   	
				if  CHARINDEX(@CurDay+',',@VDays+',') >0   /*表示单据日期在选择范围内*/
				begin
					if @VItgMoney < @ItgMoney
					  set @ItgMoney = @VItgMoney	 /*取最大积分  */
				end
			end	
			ELSE IF @VDayType = 2  /*表示星期*/
			begin
				select @CurDay = datename(WEEKDAY,@billdate)   	  /*datepart(WEEKDAY,GETDATE())*/
				if  CHARINDEX(@CurDay+',',@VDays+',') >0   /*表示单据日期在选择范围内*/
				begin
					if @VItgMoney < @ItgMoney
					  set @ItgMoney = @VItgMoney	 /*取最大积分  */
				end
			end
		end	  /*处理会员日结束*/
		/*再处理会员生日					*/
		if @BItgMoney > 0 and @BDays >= 0 and @BItgMoney < @ItgMoney  /*表示选择了会员生日,且积分的值最优*/
		begin
			if @BDays = 0  /*表示选择的会员生日当天*/
			begin
				if DAY(@Birthday) = DAY(@billdate) and MONTH(@Birthday) = MONTH(@billdate)	
				  set @ItgMoney = @BItgMoney  	
			end
			ELSE IF @BDays = 1   /*当周*/
			begin
				if datepart(WEEK,@Birthday) = datepart(WEEK,@billdate)	
				  set @ItgMoney = @BItgMoney 			
			end	
			ELSE IF @BDays = 2   /*当月*/
			begin
				if datepart(MONTH,@Birthday) = datepart(MONTH,@billdate)	
				  set @ItgMoney = @BItgMoney 			
			end
		end	/*处理会员生日结束*/
	end

    /*会员日统一用促销处理*/
   /* select * into #tmpvalidbl    --获取有效的会员日的方案
    from #tmpbl
       where I_ID in (SELECT distinct I_id FROM DayIntegral WHERE I_id in (select I_ID from #tmpbl where daymode = 2) and daystr=@week_day)
         or I_ID in (SELECT distinct I_id FROM DayIntegral WHERE I_id in (select I_ID from #tmpbl where daymode = 1) and daystr=@nl_day)
         or I_ID in (SELECT distinct I_id FROM DayIntegral WHERE I_id in (select I_ID from #tmpbl where daymode = 0) and (convert(int,daystr))=@daystr)
     --where deleted = 0   
    -- select *  from #tmpvalidbl 
    set @hyrbl =(select max(memberbl)  from #tmpvalidbl )     --会员日比例  --取满足条件的最大那个值
    set @hysrbl=(select max(birthdaybl) from #tmpbl)     --会员生日比例 --会员生日直接取最大的（按理同个机构多个方案会员生日的倍率也一样）
		*/
	/*XXX.处理该单没有积分但有积分抵现的情况	*/
	if (@isItg is null) and  exists(select 1 from salemanagebill where bill_id = @bill_id and p_id = -@account_id)
	begin
	   set @isItg= 0
	   select @isItg = d.isIntegral,
	          @vipcid=a.VIPCardID
	   from billidx a,VIPCard c,VIPCardType d
	   where  a.billid=@bill_id  and a.VIPCardID=c.VIPCardID  and c.CT_ID=d.ct_id
	end
    if @isItg=1   /*-该卡积分*/
     begin
   /*取消会员生日*/
    
    set @jfmode=(select distinct top 1 jfmode from  #tmpbl where I_ID = @I_id)     /*最终积分模式  */
    
    if @isSpecialIntegral = 0 /*默认是0，不参与积分*/
    begin
		delete from #tmpI where #tmpI.SpecialPrice > 0 
    end
    
    /*---计算基本积分 商品金额除以积分金额*/
    update #tmpI set basejf=(totalmoney/@ItgMoney)
       
    /*---------特殊商品积分,打折商品积分*/
    /*此处获取价格促销单中积分倍数字段Itgrate，默认为0 就是不参与积分*/
    update #tmpI set cxbl=y.Itgrate
    from #tmpI x,
    (select s.p_id,c.Itgrate,s.CxGuid
    from salemanagebill s,CxDetail c
    where s.CxGuid=c.guid and s.bill_id=@bill_id )y
    where x.p_id=y.p_id AND x.cxguid = y.CxGuid   /*XXX.不同的促销方案需要使用对应的积分倍数*/
		and x.smb_id in (select smb_id from salemanagebill where bill_id = @bill_id and CxGuid > 0x0)

    /*--获取并更新实际比例 bl：比例 */
    update #tmpI set jfbl=y1.bl
    from #tmpI x1,
    (select p_id,smb_id,( CASE cxbl WHEN 0 THEN 0  WHEN 1 THEN ubl else  cxbl  END )bl         
    from #tmpI) y1
    where  x1.p_id=y1.p_id and x1.smb_id = y1.smb_id

    /*----------计算积分 */
    UPDATE #tmpI set jfbl= ISNULL(jfbl,0) * (25 - @nBillType * 2)  /*这儿更新倍数，让符号一致*/
    update #tmpI set totaljf=(basejf*jfbl) /* * (25 - @nBillType * 2)*/

    /*-------------------------写入积分流水表*/
    set @totalItg=(select SUM(totaljf)  from #tmpI)
    
    if @totalItg is null set @totalItg = 0  /*可能存在整单的商品都不满足积分的*/
    /*--计算*/
    declare @plj numeric(18, 2),@zplj numeric(18, 2),@lplj numeric(18, 2)
    declare @newP_id int
    if @jfmode=0 /*累积积分*/
    begin  
       set @plj=(isnull((select top 1  ljtotalye from Integralidx  where VIPCardID=@vipcid order by billid desc),0))  
    end
    if @jfmode=1 /*按单 */
    begin 
       set @plj=0  
    end 
    if @jfmode=2 /*按天 */
    begin 
       set @plj=(isnull((select top 1  ljtotalye from Integralidx  
                 where VIPCardID=@vipcid and billdate=@billdate  order by billid desc),0))  
    end
    /*--*/
    
 	/*XXX.2017-02-15 处理扣除积分抵现 */
	declare @nkcIntegral numeric(18,2) 
	insert into #tmpI 
    select distinct p_id,@bill_id,smb_id,@vipcid,Y_ID,0,0 as I_id,0,
        0,0,total as totalmoney,0,isnull(total,0)/@ItgMoney as basejf,1 as ubl,1 as cxbl,-(25 - @nBillType * 2) as jfbl,-isnull(total,0)/@ItgMoney *(25 - @nBillType * 2) as totaljf, 
        0 as SpecialPrice, RowGuid,CxGuid,'扣除抵现金额的积分' AS remake
	from salemanagebill where bill_id = @bill_id and p_id = -@account_id
	
	select @nkcIntegral = totaljf from #tmpI where billid = @bill_id and p_id = -@account_id   /*这儿最多只会有一条数据*/
	if @nkcIntegral is null set @nkcIntegral = 0
	if abs(@nkcIntegral) > ABS(@totalItg)
	begin
		update #tmpI set totaljf = -@zplj where billid = @bill_id and p_id = -@account_id 
		set @totalItg = 0
	end 
	else
		set @totalItg = @totalItg + @nkcIntegral   
    
    
    /*XXX.2016-11-17 BUG_42927  */
    IF @totalItg > 0
    begin
		set @zplj=FLOOR(@totalItg)+ FLOOR(@plj+(@totalItg-FLOOR(@totalItg)))
		set @lplj=  (@plj +(@totalItg-FLOOR(@totalItg))) - FLOOR(@plj+(@totalItg-FLOOR(@totalItg)))
	end
	ELSE IF @totalItg = 0
	begin
		set @zplj = 0
		set @lplj=  (@plj +(@totalItg-FLOOR(@totalItg))) - FLOOR(@plj+(@totalItg-FLOOR(@totalItg)))
	end
	ELSE
	begin
	   if @jfmode=1 /*按单*/
		   set @zplj=CEILING(@totalItg)+ CEILING(@plj+(@totalItg-CEILING(@totalItg)))   
	   else				/*要累计积分的时候保证余额累计始终为正*/
		   set @zplj=FLOOR(@totalItg)+ FLOOR(@plj+(@totalItg-FLOOR(@totalItg)))     
		set @lplj= @plj + @totalItg - @zplj 
	end
    
    if @zplj is null set @zplj = 0
    
    
    /*update #tmpI set remake = '扣除抵现金额的积分' where p_id = -@account_id    --更改不抵现部分的备注*/
   /* select * from #tmpI */

	/* 写入积分抵现*/
	DECLARE @nCashRate NUMERIC(25,8)		/* 积分抵现比例*/
	DECLARE @nCashIntegral NUMERIC(25,8)	/* 抵现积分*/
	DECLARE @nDxIntegral INT                /* 抵现后是否整单参与积分*/
	set @nCashRate = 0
	SET @nCashIntegral = 0
	/*select @nCashRate = sysvalue from sysconfig where sysname = 'IntegralToCash'*/
	select @nCashRate = dxRate,@nDxIntegral = isdxIntegral from VipCardTypeExtend where bill_id = @I_id
	insert into #tmpI 
    select distinct p_id,@bill_id,smb_id,@vipcid,Y_ID,0,0 as I_id,0,
        0,0,isnull(total,0) as totalmoney,0,@nCashRate as basejf ,1 as ubl,1 as cxbl,(-total)*(25 - @nBillType * 2) as jfbl,-total * @nCashRate *(25 - @nBillType * 2) as totaljf, 
        0 as SpecialPrice, RowGuid,CxGuid,'积分抵现' AS remake
	from salemanagebill where bill_id = @bill_id and p_id = -@account_id
	
	SELECT @nCashIntegral = SUM(-total * @nCashRate) FROM salemanagebill where bill_id = @bill_id and p_id = -@account_id
    set @nCashIntegral = @nCashIntegral * (25 - @nBillType * 2)   /*用来判断符号*/
   
    if @nCashIntegral is null set @nCashIntegral = 0
    if (@nDxIntegral = 0) and exists (select 1 from salemanagebill where bill_id = @bill_id and p_id = -@account_id)   /*在有积分抵现的情况下，勾选了积分抵现整单参与积分的该单才积分*/
    begin   
      delete from #tmpI where p_id > 0 or remake = '扣除抵现金额的积分'  /*不积分*/
      set @zplj = 0
      set @totalItg = 0
      set @lplj= @plj
    end

       /* set @totalItg=(select SUM(totaljf)  from #tmpI where )*/
	/*--写入主表*/
	insert into Integralidx(bill_id,billguid,VIPCardID,I_id,Itgmode,totalItg,totalye,ljtotalye,billdate,Y_ID)
	select @bill_id,@billguid, @vipcid,@I_id,@jfmode,@zplj + @nCashIntegral,@totalItg-FLOOR(@totalItg),@lplj,@billdate,@yid   
	 
	 /*select * from #tmpI      */
	set  @newP_id= @@IDENTITY  
	/*--写入明细表*/
	insert into Integraldetail(billid,smb_id,totalmoney,baseItg,Itgrate,totalItg, Y_ID, rowguid,remake)
	select @newP_id,smb_id,totalmoney,basejf,jfbl,totaljf, @yid, rowguid,remake
	from #tmpI 
    /*开始返还介绍人积分，如果有的话*/
    DECLARE @IntroCardID INT, @NEWBILLID INT, @INTRJFBL numeric(18, 2)
    DECLARE @IdxITG numeric(18, 2), @IdxYe numeric(18, 2), @IdxLjYe numeric(18, 2), @IdxPTotalItg numeric(18, 2)
    DECLARE @IntrTotalMoney numeric(18, 2)
    DECLARE @HisLj numeric(18, 2)
    SELECT @IntroCardID = IntroducerID FROM VIPCard WHERE VIPCardID = @vipcid
    IF @IntroCardID > 0  /*有介绍人*/
    BEGIN
      /*如果停用，判断是否换为新卡*/
      IF IsNull((select IsNull(StopUse, 0) from VIPCard where VIPCardID = @IntroCardID), 0) = 1 
        select @IntroCardID = IsNull(NewVIPCardID, 0) from ExchangeVIPCard where OldVIPCardID = @IntroCardID
      IF @IntroCardID > 0 
      BEGIN
        SELECT @INTRJFBL = BackIntNeedMoney FROM VipCardTypeExtend WHERE bill_id = @I_id
        IF @INTRJFBL > 0 /*有设置介绍人返积分基础金额*/
        BEGIN 
          /*单据总金额，计ssmoney*/
          select @IntrTotalMoney = ssmoney * (25 - BillType * 2) from billidx where billid = @bill_id   
          /*介绍人返积分总数*/
          select @IdxITG = Floor(@IntrTotalMoney/@INTRJFBL)
          /*介绍人返积分后本单余额*/
          select @IdxYe = @IntrTotalMoney - Floor(@IntrTotalMoney/@INTRJFBL) * @INTRJFBL
          /*介绍人返积分后总计余额*/
          if @jfmode = 0 /*累积积分*/
          begin  
            set @HisLj = (isnull((select top 1  ljtotalye from Integralidx  where VIPCardID = @IntroCardID order by billid desc),0))  
          end
          if @jfmode = 1 /*按单 */
          begin 
            set @HisLj = 0  
          end 
          if @jfmode = 2 /*按天 */
          begin 
            set @HisLj = (isnull((select top 1 ljtotalye from Integralidx where VIPCardID = @IntroCardID and billdate = @billdate  order by billid desc),0))  
          end
          /*本单余额+历史累计余额 > 返积分单位金额，则要累加*/
          IF @IdxYe + @HisLj >= @INTRJFBL
          BEGIN
            SET @IdxITG = @IdxITG + FLOOR((@IdxYe + @HisLj)/@INTRJFBL)
            SET @HisLj = (@IdxYe + @HisLj) - FLOOR((@IdxYe + @HisLj)/@INTRJFBL) * @INTRJFBL
          END
          ELSE 
            SET @HisLj = @IdxYe + @HisLj   
          /*--刷新介绍人卡的累计积分*/
          select top 1 @IdxPTotalItg = (ptotalItg + totalItg) from Integralidx where VIPCardID = @IntroCardID Order by billid desc                          
          /*--写入主表        */
          insert into Integralidx (bill_id, billguid, VIPCardID, I_id, Itgmode, totalItg, totalye, ljtotalye, billdate, remake, PtotalItg,Y_ID)
            select @bill_id, @billguid, @IntroCardID, @I_id, @jfmode, ISNULL(@IdxITG, 0), ISNULL(@IdxYe, 0), ISNULL(@HisLj, 0), @billdate, '介绍人返积分', ISNULL(@IdxPTotalItg, 0), @yid
          /*--写入明细表       */
          set @NEWBILLID = @@IDENTITY                           
          insert into Integraldetail (billid, smb_id, totalmoney, baseItg, Itgrate, totalItg, Y_ID, rowguid,remake)
            select @NEWBILLID, smb_id, totalmoney, CONVERT(DECIMAL(18, 2), totalmoney/@INTRJFBL), @INTRJFBL, CONVERT(DECIMAL(18, 2), totalmoney/@INTRJFBL),@yid, rowguid,remake from #tmpI  
            where p_id > 0                      
          /*刷新介绍人卡总积分*/
          update VIPCard set Integral = Integral + @IdxITG where VIPCardID = @IntroCardID               
        END
      END
    END    
    
    /*select * from #tmpI */
    /*介绍人积分返还结束*/
   /*select @nPosDataMode = sysvalue from sysconfig where sysname='PosDataMode'      */
   select @SzY_id = sysvalue from sysconfig where sysname = 'Y_ID'
   select @by_id = Y_ID from billidx where billid = @bill_id
   /*XXX.2016-10-12  这儿去系统的连接模式不对，应该直接去对应的机构的实际的连接模式*/
   select @nPosDataMode = PosDataMode from company where company_id = @by_id
      
   select @IsBank = VT.isBank,@YIntegrral = v.Integral from VIPCard V,VIPCardType VT where V.CT_ID = VT.ct_id AND V.VIPCardID = @vipcid   
   IF @IsBank IS NULL SET @IsBank = 0

   IF (@nBillType in (13)) and (@YIntegrral < abs(@zplj)-@nCashIntegral)
   begin 
   	raiserror('本次扣减积分不能大于会员当前积分！',16,1)
   	return -26
   end   
   
   if (@nPosDataMode = 0 ) or (@SzY_id = '2' and @by_id =2)   /*实时模式直接扣减抵现积分*/
   begin
    /*--累积会员卡的积分      ---xxx  ptotalItg 字段的具体作用?这儿是否和会员卡更新顺序换一下*/
    update  Integralidx set ptotalItg=(select Integral from  VIPCard where VIPCardID=@vipcid) /*- @nCashIntegral*/
    where billid=@newP_id

	/*XXX. 2016-12-21   实时模式的时候，储值卡只需要在这儿更新 积分和消费次数即可 */
    IF @IsBank = 1 
    BEGIN
		update  VIPCard set Integral=Integral+@zplj+@nCashIntegral,SwapIntegral=SwapIntegral - @nCashIntegral,buycount=buycount+1/*,TotalBuyMoney=TotalBuyMoney+@total*/ where VIPCardID=@vipcid
    END 
    else
		update  VIPCard set Integral=Integral+@zplj+@nCashIntegral,SwapIntegral=SwapIntegral - @nCashIntegral,buycount=buycount+1/*,TotalBuyMoney=TotalBuyMoney+@total*/ where VIPCardID=@vipcid
   
   end
   else
   begin
    /*--累积会员卡的积分      ---xxx  ptotalItg 字段的具体作用?这儿是否和会员卡更新顺序换一下*/
    update  Integralidx set ptotalItg=(select Integral from  VIPCard where VIPCardID=@vipcid) /*- @nCashIntegral*/
    where billid=@newP_id
    /*--*/
    /*这儿要判断卡是否是储值卡，如果储值卡则会直接更新总部，所以这儿不更新消费金额和次数*/
    IF @IsBank = 1 
    BEGIN
		update  VIPCard set Integral=Integral+@zplj+@nCashIntegral/*,buycount=buycount+1,TotalBuyMoney=TotalBuyMoney+@total*/ where VIPCardID=@vipcid
    END
    ELSE
		update  VIPCard set Integral=Integral+@zplj+@nCashIntegral,SwapIntegral=SwapIntegral - @nCashIntegral,buycount=buycount+1/*,TotalBuyMoney=TotalBuyMoney+@total*/ where VIPCardID=@vipcid	
   end
    update  billidx set integral =@zplj + @nCashIntegral   where billid =@bill_id
    update  retailbillidx set integral =@zplj + @nCashIntegral where GUID = (select GUID from billidx where billid=@bill_id) 
   
   end  /*-该卡积分*/

	/*XXX.2017-06-20 不管是否积分都需要更新，消费金额 */
   select @SzY_id = sysvalue from sysconfig where sysname = 'Y_ID'
   select @by_id = Y_ID from billidx where billid = @bill_id
   select @nPosDataMode = PosDataMode from company where company_id = @by_id
      
   select @IsBank = VT.isBank,@YIntegrral = v.Integral from VIPCard V,VIPCardType VT where V.CT_ID = VT.ct_id AND V.VIPCardID = @vipcid   
   IF @IsBank IS NULL SET @IsBank = 0

   if NOT (((@nPosDataMode = 0 ) or (@SzY_id = '2' and @by_id =2)) and (@IsBank = 1))    /*非实时模式下的储值卡都需要更新消费金额*/
   BEGIN		
		update  VIPCard set TotalBuyMoney=TotalBuyMoney+ @total *(25 - @nBillType * 2)  where VIPCardID=@vipcid
   END

   drop table #tmpI
   drop table #tmpbl
   if  OBJECT_ID('tempdb..#tmpvalidbl') IS NOT NULL
     drop table #tmpvalidbl
     
  DECLARE @Y_id INT	/*发卡机构*/
  
  select @Y_id = Y_ID from VIPCard where VIPCardID=@vipcid    
  if @Y_id is null set @Y_id = 0
  /*if @Y_id not in (27,28,29)*/
 /* begin    --同仁堂特殊处理*/
     
	/* 增加会员卡自动升级功能*/
	DECLARE @CARDTYPE INT	/*卡类型*/
	DECLARE @MONEYLIMIT NUMERIC(25,8)
	DECLARE @ITGLIMIT NUMERIC(25,8)
	DECLARE @Integralupkc NUMERIC(25,8)
	DECLARE @NEWCARDMONEY INT
	DECLARE @NEWCARDITG INT
	DECLARE @CURMONEY NUMERIC(25,8)
	DECLARE @CURITG NUMERIC(25,8)
	DECLARE @UPGRADED BIT
	DECLARE @CardName varchar(100)
	DECLARE @moneyUPCName varchar(100)
	DECLARE @integraUPCName varchar(100)
    
    declare @CZMoney   NUMERIC(25,8)
	declare @NEWCZMONEY  INT
	DECLARE @CZGLIMIT NUMERIC(25,8)
	DECLARE @CZUPCName varchar(100)
	
	SET @UPGRADED = 0

	SELECT @CARDTYPE = CT_ID, @CURMONEY = TotalBuyMoney, @CURITG = Integral,@CZMoney=SaveMoney FROM VIPCard WHERE VIPCardID = @vipcid
	IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
						AND ismoneyup = 1 and isMoneyAutoup = 1)  /*先判断消费金额升级*/
	BEGIN
		/*SELECT TOP 1 @AUTOUP = isautoup, @UPBYMONEY = ismoneyup, @UPBYITG = isIntegralup,
			@MONEYLIMIT = moneyup, @ITGLIMIT = Integralup, @NEWCARDMONEY = moneyupC_id,
			@NEWCARDITG = IntegralupC_id,
			@CardName = ISNULL(cardnamestr,''),@moneyUPCName = ISNULL(moneyupC_name,''),@integraUPCName =ISNULL(IntegralupC_name,'')
		FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE AND isautoup = 1 AND Deleted = 0 */
		SELECT TOP 1 @MONEYLIMIT = moneyup,  @NEWCARDMONEY = moneyupC_id,
			@CardName = ISNULL(cardnamestr,''),@moneyUPCName = ISNULL(moneyupC_name,'')
		FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 AND ismoneyup = 1 and isMoneyAutoup = 1			

		IF @CURMONEY >= @MONEYLIMIT AND @NEWCARDMONEY <> @CARDTYPE
		BEGIN
			UPDATE VIPCard SET CT_ID = @NEWCARDMONEY WHERE VIPCardID = @vipcid
			/*写入日志*/
			insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
			select 1,'system','自动升级',GETDATE(),VIPCardID,0,isnull(Integral,0.0),isnull(TotalBuyMoney,0.0),0,0.00,@CardName + '→' +@moneyUPCName
				FROM VIPCard WHERE VIPCardID = @vipcid
			SET @UPGRADED = 1
				
		END
	END
	IF @UPGRADED = 0
	BEGIN
		IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
							AND isIntegralup = 1 and isautoup = 1)  /*如果为执行消费金额升级，再判断积分升级*/
		BEGIN
			SELECT TOP 1 @ITGLIMIT = Integralup,@Integralupkc = Integralupkc,  @NEWCARDITG = IntegralupC_id,
				@CardName = ISNULL(cardnamestr,''),@integraUPCName =ISNULL(IntegralupC_name,'')
			FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 AND isIntegralup = 1 and isautoup = 1

			IF @CURITG >= @ITGLIMIT AND @NEWCARDITG <> @CARDTYPE
			BEGIN
				UPDATE VIPCard SET CT_ID = @NEWCARDITG,Integral = Integral-isnull(@Integralupkc,0)  WHERE VIPCardID = @vipcid
				/*写入日志*/
				insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
				select 1,'system','自动升级',GETDATE(),VIPCardID,0,isnull(Integral,0.0),isnull(TotalBuyMoney,0.0),0,0.00,@CardName + '→' +@integraUPCName
				FROM VIPCard WHERE VIPCardID = @vipcid
				/*SET @UPGRADED = 1*/
			END
		END
	END
	/*-zjx--2017-02-04---tfs45293--处理零售单和零售退货单刷卡后没有写日志问题*/
    select @Currentintegral=isnull(Integral,0.00),@CurrentCzYe=isnull(RemainderMoney,0.00) FROM VIPCard WHERE VIPCardID = @vipcid
	set @BcIntegrral=@zplj + @nCashIntegral
	if (@nBillType=12) and (@vipcid>0) 
    begin	
        select @comment='零售单：【'+@order+'】'
        Insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NowIntegral,ModIntegral,NowMoney,ModMoney,NewVIPCardID,Comment) 
        values(@eid,'','零售单',convert(varchar(10),getdate(),20),@vipcid,@Currentintegral,@BcIntegrral,@CurrentCzYe,0,0,@Comment)
    end
    if @nBillType=13 and (@vipcid>0) 
    begin
       select @comment='零售退货单：【'+@order+'】'
       Insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NowIntegral,ModIntegral,NowMoney,ModMoney,NewVIPCardID,Comment) 
       values(@eid,'','零售退货单',convert(varchar(10),getdate(),20),@vipcid,@Currentintegral,@BcIntegrral,@CurrentCzYe,0,0,@Comment)
    end
	/*IF @UPGRADED = 0
	BEGIN
		IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
										AND isStoragUp = 1 and isStoragAutoup = 1)  --如果为执行积分升级，再判断储值升级
		BEGIN
			SELECT TOP 1 @CZGLIMIT=A.UPSTORAG,  @NEWCZMONEY = A.LSTORAGUPCT_ID,
							@CARDNAME = ISNULL(A.CARDNAMESTR,''),@CZUPCNAME =ISNULL(B.NAME,'')
			            FROM VIPCARDTYPEEXTEND A LEFT JOIN VIPCARDTYPE B ON A.LSTORAGUPCT_ID=B.CT_ID WHERE BILL_ID = @CARDTYPE 
						AND A.DELETED = 0 AND A.ISSTORAGUP = 1 AND A.ISSTORAGAUTOUP = 1

			IF @CZMONEY >= @CZGLIMIT AND @NEWCZMONEY <> @CARDTYPE
			BEGIN
					UPDATE VIPCARD SET CT_ID = @NEWCZMONEY  WHERE VIPCARDID = @VIPCID
							--写入日志
					INSERT INTO VIPLOG(EID,COMPUTER,ACTNAME,ACTDATE,VIPCARDID,NEWVIPCARDID,NOWINTEGRAL,NOWMONEY,MODINTEGRAL,MODMONEY,COMMENT)
					SELECT 1,'SYSTEM','自动升级',GETDATE(),VIPCARDID,0,ISNULL(INTEGRAL,0.0),ISNULL(TOTALBUYMONEY,0.0),0,0.00,@CARDNAME + '→' +@CZUPCNAME
					FROM VIPCARD WHERE VIPCARDID = @VIPCID
			END
	   END
	END*/
/*  end*/
GO
