
/*会员换卡后单据的对应更新*/
CREATE      procedure TS_L_insAfterChangeVIPCard
(
  @OldVipCardid  int,	 /*换卡前id	*/
  @NewVipCardid  int     /*新id*/
  )
  
as 

declare @Msg varchar(50)
begin

begin  transaction
  IF exists(select VIPcardid from Vipcard where VIPcardid=@NewVipCardid and Deleted<>1)
  begin
    update retailbillidx set VIPCardID = @NewVipCardid where VIPCardID = @OldVipCardid		/*零售单*/
    update billidx set VIPCardID = @NewVipCardid where billtype = 12 and VIPCardID = @OldVipCardid 		/*零售单*/
    update BillDraftidx set VIPCardID = @NewVipCardid where VIPCardID = @OldVipCardid		/*积分兑换单     */
  end
  else 
  begin
    set @Msg = '会员卡号【'+@NewVipCardid+'】不存在或已经删除，更新零售单会员卡号失败！'
    raiserror(@Msg,16,1)
    return -1
  end

  IF @@ERROR=0
    COMMIT transaction
  ELSE
    ROLLBACK transaction      

end
GO
