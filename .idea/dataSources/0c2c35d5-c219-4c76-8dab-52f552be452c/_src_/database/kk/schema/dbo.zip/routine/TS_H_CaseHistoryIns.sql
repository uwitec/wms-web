
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-19*/
/* Description:	插入病历*/
/* =============================================*/
CREATE PROCEDURE TS_H_CaseHistoryIns
    @Case_ID        int, 
	@BillNo			varchar(60),
	@Reg_ID			int,
	@Patient_ID		int,
	@Age			int,
	@Doctor_ID		int,
	@Doctor			varchar(50),
	@CaseDate		datetime,
	@SelfExp		varchar(500) = '',
	@Medical		varchar(500) = '',
	@BodyExam		varchar(500) = '',
	@AssisExam		varchar(500) = '',
	@Diagnose		varchar(500) = '',
	@Deal			varchar(500) = '',
	@Custom1		varchar(500) = '',
	@Custom2		varchar(500) = '',
	@Custom3		varchar(500) = '',
	@Custom4		varchar(500) = '',	
	@Diseasetime	varchar(200)= '',
	@Allergies		varchar(400)= '',
	@Symptom		varchar(400)= '',
	@BloodSugar		varchar(200) = '',
	@BloodPressure  varchar(200)= '',
	@HeartFunction  varchar(400) = '',
	@LiverFunction  varchar(400)= '',
	@RenalFunction  varchar(400)= '',
	@FoodHabits		varchar(400)= '',
	@Medication		varchar(400) = '',
	@VipCardID		int	
	
AS
BEGIN
/*Params Ini begin*/
if @SelfExp is null  SET @SelfExp = ''
if @Medical is null  SET @Medical = ''
if @BodyExam is null  SET @BodyExam = ''
if @AssisExam is null  SET @AssisExam = ''
if @Diagnose is null  SET @Diagnose = ''
if @Deal is null  SET @Deal = ''
if @Custom1 is null  SET @Custom1 = ''
if @Custom2 is null  SET @Custom2 = ''
if @Custom3 is null  SET @Custom3 = ''
if @Custom4 is null  SET @Custom4 = ''
if @Diseasetime		is null  SET @Diseasetime	= ''
if @Allergies		is null  SET @Allergies		= ''
if @Symptom			is null  SET @Symptom		= ''
if @BloodSugar		is null  SET @BloodSugar	= ''
if @BloodPressure	is null  SET @BloodPressure	= ''
if @HeartFunction	is null  SET @HeartFunction	= ''
if @LiverFunction	is null  SET @LiverFunction	= ''
if @RenalFunction	is null  SET @RenalFunction	= ''
if @FoodHabits		is null  SET @FoodHabits	= ''
if @Medication		is null  SET @Medication	= ''
								 
/*Params Ini end*/
	SET NOCOUNT ON;	
	
 if (@VipCardID = 0) and (@Patient_ID > 0) 	
   select @VipCardID = isnull(vip_id, 0) from Patients where PatientID = @Patient_ID
  	
  if @Case_ID = 0
  begin	
    if exists(select * from casehistory where billno = @billno)
	begin
		raiserror('病历号已存在！', 16, 1)
		return 0
	end
	declare @ID int

	insert into [casehistory] (
		BillNo,
		Reg_ID,
		Patient_ID,
		Age,
		Doctor_ID,
		Doctor,
		CaseDate,
		SelfExp,
		Medical,
		BodyExam,
		AssisExam,
		Diagnose,
		Deal,
		Custom1,
		Custom2,
		Custom3,
		Custom4,
		Diseasetime,	
		Allergies,	
		Symptom,		
		BloodSugar,	
		BloodPressure,
		HeartFunction,
		LiverFunction,
		RenalFunction,
		FoodHabits,	
		Medication,
		VipCardID																																							
		
	) values (
		@BillNo,
		@Reg_ID,
		@Patient_ID,
		@Age,
		@Doctor_ID,
		@Doctor,
		@CaseDate,
		@SelfExp,
		@Medical,
		@BodyExam,
		@AssisExam,
		@Diagnose,
		@Deal,
		@Custom1,
		@Custom2,
		@Custom3,
		@Custom4,
		@Diseasetime,	
		@Allergies,	
		@Symptom,		
		@BloodSugar,	
		@BloodPressure,
		@HeartFunction,
		@LiverFunction,
		@RenalFunction,
		@FoodHabits,	
		@Medication,
		@VipCardID																																									
	)
	
	set @ID = @@identity
	if @Reg_ID > 0 
	  update registered set CaseState = 1 where reg_id = @Reg_ID
	return @ID
  end else 	if @Case_ID > 0
  begin
    if exists(select * from casehistory where billno = @billno and Case_ID <> @Case_ID)
	begin
		raiserror('病历号已存在！', 16, 1)
		return 0
	end
       
    update [casehistory] set  
							BillNo=				@BillNo,
							Reg_ID=				@Reg_ID,
							Patient_ID=			@Patient_ID,
							Age=				@Age,
							Doctor_ID=			@Doctor_ID,
							Doctor=				@Doctor,
							CaseDate=			@CaseDate,
							SelfExp=			@SelfExp,
							Medical=			@Medical,
							BodyExam=			@BodyExam,
							AssisExam=			@AssisExam,
							Diagnose=			@Diagnose,
							Deal=				@Deal,
							Custom1=			@Custom1,
							Custom2=			@Custom2,
							Custom3=			@Custom3,
							Custom4=			@Custom4,
							Diseasetime=		@Diseasetime,	
							Allergies=			@Allergies,	
							Symptom=			@Symptom,		
							BloodSugar=			@BloodSugar,	
							BloodPressure=		@BloodPressure,
							HeartFunction=		@HeartFunction,
							LiverFunction=		@LiverFunction,
							RenalFunction=		@RenalFunction,
							FoodHabits=			@FoodHabits,	
							Medication=			@Medication,
							VipCardID=			@VipCardID		
			        where Case_ID = @Case_ID
	 return @Case_ID        										                                                                                                                        
  end	
END
GO
