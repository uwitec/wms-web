
CREATE  proc Ts_b_LoadRetailDetail
(
@billid  int,
@Tag int
)
AS
SET NOCOUNT ON
if @TAG in (5, 25)
SELECT b.smb_ID,b.bill_id,b.p_id,b.batchno,b.saleprice as price,b.discount,b.discountprice,b.totalmoney, b.total,
  b.taxprice,b.taxtotal,b.taxmoney,b.makedate,b.validdate, b.comment,b.taxrate,b.aoid,
  CASE b.unitid
  WHEN p.unit1_id THEN b.quantity
  WHEN p.unit2_id THEN b.quantity/p.unitrate2
  WHEN p.unit3_id THEN b.quantity/p.unitrate3
  WHEN p.unit4_id THEN b.quantity/p.unitrate4
  END AS quantity,
  CASE b.unitid
  WHEN p.unit1_id THEN p.unit1
  WHEN p.unit2_id THEN p.unit2
  WHEN p.unit3_id THEN p.unit3
  WHEN p.unit4_id THEN p.unit4
  END AS unit,
  CASE p.OTCType
  WHEN 0 THEN '甲类'
  WHEN 1 THEN '乙类'
  ELSE '无'
  END AS OTCType,
  
  ISNULL(r.rname ,'') AS RName,

  p.code,p.name,p.standard,p.modal,p.makearea, p.permitcode, p.trademark,p.medtype,p.otcflag,
  '' as comment2,b.batchbarcode,b.scomment,b.batchprice

FROM retailbill b
inner join vw_b_Products p on b.p_id = p.p_id
left  join Range r on p.r_id = r.rid
WHERE bill_id = @billid
ORDER BY b.smb_ID
else
if @TAG in (15)
SELECT b.smb_ID,b.bill_id,b.p_id,b.batchno,b.saleprice as price,b.discount,b.discountprice,b.totalmoney, b.total,
  b.taxprice,b.taxtotal,b.taxmoney,b.makedate,b.validdate, b.comment,b.taxrate,b.aoid,
  CASE b.unitid
  WHEN p.unit1_id THEN b.quantity
  WHEN p.unit2_id THEN b.quantity/p.unitrate2
  WHEN p.unit3_id THEN b.quantity/p.unitrate3
  WHEN p.unit4_id THEN b.quantity/p.unitrate4
  END AS quantity,
  CASE b.unitid
  WHEN p.unit1_id THEN p.unit1
  WHEN p.unit2_id THEN p.unit2
  WHEN p.unit3_id THEN p.unit3
  WHEN p.unit4_id THEN p.unit4
  END AS unit,
  CASE p.OTCType
  WHEN 0 THEN '甲类'
  WHEN 1 THEN '乙类'
  ELSE '无'
  END AS OTCType,
  
  ISNULL(r.name ,'') AS RName,

  p.code,p.name,p.standard,p.modal,p.makearea, p.permitcode, p.trademark,p.medtype,p.otcflag, 
  ''as comment2,b.batchbarcode,b.scomment,b.batchprice

FROM salemanagebill b
inner  join vw_b_Products p on b.p_id = p.p_id
left   join 
(
             select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
) r  on p.p_id = r.baseinfo_id
WHERE bill_id = @billid
ORDER BY b.smb_ID
GO
