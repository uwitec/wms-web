
CREATE PROCEDURE TS_L_CustomBaseboard
(	@szListFlag		VARCHAR(1)='L',/*分级显示*/
    @szParent_ID	VARCHAR(30)='',/*产品父类ID*/
    @nloginEID      int=0,/*登陆人ID*/
	@BeginDate   	VARCHAR(30),/*开始时间*/
	@EndDate	    VARCHAR(30),/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szEClass_ID	VARCHAR(30)='',/*经手人ID*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
	@szSClass_ID	VARCHAR(30)='',/*库房ID*/
	@nLocation_Id   VARCHAR(30)='',        /*货位ID*/
	@Department_ID  varchar(30)='',/*部门*/
	@szRClass_id   varchar(50) = '', /*片区 */
	@nYClassid                 varchar(100)=''         
)
AS
/*Params Ini begin*/
if @szListFlag is null  SET @szListFlag = 'L'
if @szParent_ID is null  SET @szParent_ID = ''
if @nloginEID is null  SET @nloginEID = 0
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @szSClass_ID is null  SET @szSClass_ID = ''
if @nLocation_Id is null  SET @nLocation_Id = ''
if @Department_ID is null  SET @Department_ID = ''
if @szRClass_id is null  SET @szRClass_id = ''
if @nYClassid is null  SET @nYClassid = ''
/*Params Ini end*/
 select * from products
GO
