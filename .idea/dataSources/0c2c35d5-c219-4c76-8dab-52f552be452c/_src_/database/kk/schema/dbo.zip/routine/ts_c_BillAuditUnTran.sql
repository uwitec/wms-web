
/*nReturnNumber
－100：单据日期小于本期开始日期
 -101: 本张单据里包含结算金额大于结算余额的业务单据,可能的原因是业务单据已被其他人结算
	-1: 负库存
	-2:
	-3: 数量为零
	-4: 期初不能修改
	-5: 无成本价
  -6: 异常错误
  -7: 已经开帐，数据不能修改
	-8: 会计凭证不平
	-9：商品已删除
	-10：仓库已删除
	-11：职员已删除
	-12：往来单位已删除
	-13: 会计科目已删除
	-14: 货位已删除
	-15：商品单位已删除

	-21:退货数量大于原单数量
	-22:未指定当前机构
	-23:超出往来单位信用额度
	-24:超出职员信用额度
	
	-25:自动生成内部移库单错误
	-26:自动生成发货单错误
	
	-30:更新科目余额表错误
*/
CREATE  procedure ts_c_BillAuditUnTran
(
	@nBillId int,
	@nP_id int output,
	@nReturnNumber int output,
	@nVchtype int
)
/*with encryption*/
as
set nocount on

declare @nTempPid int,@szBillNumber varchar(20),@szProductName varchar(60),@nNewBillId int
declare @nC_id int,@nE_id int,@tBillDate datetime,@tBeginDate datetime,@tAuditDate datetime
declare @nDep_id int,@nRegion_id int,@nPeriod int,@cBillState char(1),@nBilltype int,@cJsFlag char(1)
declare @totalmoney NUMERIC(25,8),@billguid varchar(50)
declare @Y_id int,@billdateAudit int, @nCreditPost int
declare @orderbillid int
select @nCreditPost = CAST(sysvalue as int) from sysconfig where [sysname] = 'CreditPost' and Y_ID = 0

if @nCreditPost = 1
begin
  exec ts_j_checkCreditPost @nBillId, @nVchtype, @nReturnNumber output, 0,0,0,0,0
  if @nReturnNumber < 0 return 0
end

/*
declare @nPosid int

select @nPosid=0
exec ts_getsysvalue 'Posid',@nPosid out
*/

/*if @nVchtype not in (12,13)*/
	select @nC_id=c_id,@nE_id=e_id,@tBillDate=billdate,@cBillState=billstates,@nBilltype=billtype,@szBillNumber=billnumber,@cJsFlag=jsflag,@Y_id=Y_id,@billguid=guid  from billdraftidx where billid=@nBillid
/*else*/
/*	select @nC_id=c_id,@nE_id=e_id,@tBillDate=billdate,@cBillState=billstates,@nBilltype=billtype,@szBillNumber=billnumber,@cJsFlag=jsflag from retailbillidx where billid=@nBillid*/

select @tBeginDate=begindate from MonthSettleInfo where monthname='本期' and Y_id=@Y_id
if exists(select 1 from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id)
  select @nPeriod=cast(sysvalue as int) from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id
else set @nPeriod = 1

if @tBillDate<@tBeginDate 
begin 
	select @nReturnNumber=-100
	return 0
end

set @nReturnNumber = -1

/*无事务过账*/
/*SET TRANSACTION ISOLATION LEVEL SERIALIZABLE */

/*begin tran Audit*/

	select @nRegion_id=region_id from clients where client_id=@nC_id
	select @nDep_id=dep_id from employees where emp_id=@nE_id
	if @nRegion_id is null select @nRegion_id=0
	if @nDep_id is null select @nDep_id=0
	
	
	/*按次控制 (李文云:退货,红冲不影响按次控制数量)  add by luowei 2013-10-31*/
	declare @UseRange varchar(10),
	        @cdt_id int,
			@r_id int,
			@cdt_time int
        declare @RangeDZ varchar(50)  /*重庆李文云定制功能*/
	set @UseRange='0' 
	select @UseRange=sysvalue from sysconfig where sysname='UseRange'
	set @RangeDZ='0' 
	select @RangeDZ=sysvalue from sysconfigtmp where sysname='RangeCoditionBM'
	if @nbilltype in (10,110,212) and @UseRange='1' and @RangeDZ='1'
	begin
	  select p.r_id into #smTemp from salemanagebilldrf sm 
	  left join products p on p.product_id=sm.p_id
	  where sm.bill_id=@nBillId and p.r_id>0
      /*检查按次控制*/
	  if exists(select top 1 * from RangeConditionBM b where b.c_id=@nC_id and b.cdt_type=1
	       and b.cdt_time<1 and b.r_id in (select r_id from #smTemp) )
	  begin
		set @nReturnNumber= -1000
		goto error
	  end
	  /*更新按次控制 更新此往来单位联系人的该经营范围对应所有往来单位的次数  次数只和联系人、经营范围相关与往来单位无关*/
	  select client_id as c_id into #temp_c from clients where contact_personal in(select contact_personal from clients where client_id=@nC_id)
	  update RangeConditionBM  set cdt_time=(cdt_time-1)  
	      where cdt_type=1 and r_id in (select r_id from #smTemp) and c_id in (select c_id from #temp_c)
	  /*更新往来单位经营范围*/
	  delete rc from customCategoryMapping rc,RangeConditionBM bm 
	    where bm.cdt_type=1 and bm.cdt_time<1 and rc.baseinfo_id=bm.c_id and rc.category_id=bm.r_id and rc.BaseTypeid=1 and rc.deleted=0
	end
	

    /*启用销售出库单异常存草稿时，过账重置location_id2 为0 add by luowei 2012-12-29*/
    if exists(select 1 from sysconfigtmp where sysname = 'AllowSaveDraft' and sysvalue = '1')
      and (@nBilltype = 10)
    begin
      update salemanagebilldrf set location_id2 = 0 where bill_id = @nBillId
    end
    /*-启用拣货流程，销售出库单掉订单的单据回写order_id add by luowei 2013-05-23*/
    if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and (@nBilltype = 10 ) 
	begin
      update salemanagebilldrf set order_id = orgbillid where bill_id = @nBillId	
	end
	/*-启用拣货流程，拆零自动生成的同价调拨单的过账更新对应销售出库单明细的货位id,防止同价调拨单草稿跟改货位后销售出库单无法过账 add by luowei 2013-11-19*/
	if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and (@nBilltype = 44)
	begin
	  /*-更新原单*/
	  update salemanagebilldrf  set location_id = st.location_id2
	  from storemanagebilldrf st where  exists(select 1 from billdraftidx where st.bill_id = billid and billtype = 44)
	  and exists(select 1 from billdraftidx where  salemanagebilldrf.bill_id = billid and billtype = 10)
	  and st.bill_id = @nBillId and salemanagebilldrf.invoiceno = st.bill_id and  salemanagebilldrf.p_id = st.p_id
	 /*--更新拣货单*/
	 
	 update salemanagebilldrf set location_id = sm.location_id
	 from (
	         select smb_id,location_id from salemanagebilldrf 
	         where exists(select 1 from billdraftidx where bill_id = billid and billtype = 10)
	         and invoiceno = @nBillId
	      ) sm where sm.smb_id = order_id 
	      and exists(select 1 from billdraftidx where salemanagebilldrf.bill_id = billid and billtype = 254)
	end   
	exec @nReturnNumber=ts_c_DraftToHis @nBillId,@nNewBillId output/*从草稿库拷贝到历史单据库*/
	if @nReturnNumber<>0 
	begin
		if @nReturnNumber > 35000000
		begin
			set @nP_id = @nReturnNumber - 35000000
			set @nReturnNumber = -35
		end
		goto error
	end
	
/*	if @nBilltype = 12
	begin
		exec TS_H_AutoCreateBill @nNewBillId, @nBilltype, @nReturnNumber output
		if @nReturnNumber <> 0
			goto error
	end
*/
	
	update PrintDetail set Rep_ID=@nNewBillId,nflag=0 where Rep_ID=@nBillId and nflag=1/*重复打印次数从草稿更新为历史单据*/

        /*update retailmerge set draft=0 where newbillguid=@billguid and draft=1*/
declare @nIntergalYE NUMERIC(25,8)/*单据积分余额*/
declare @intergal int, /*积分*/
	@vipCardID int
declare @dicount NUMERIC(25,8), @isBank int/*会员卡所有商品折扣*/
declare @ArApTotal NUMERIC(25,8)  /*标识是否已计算过积分*/

declare @nRetailBillID int, @nNewYBillId int

set @billguid=''
set @totalmoney= 0
select @ArApTotal=ArApTotal,@billguid=guid,@intergal = order_id,@vipCardID =vipcardid,@totalmoney =ssmoney ,@nIntergalYE =invoicetotal from billidx where billid=@nNewBillId
select @dicount=ct.Discount, @isBank = ct.isBank from VIPCardType ct,Vipcard V where V.ct_id=ct.ct_id and v.VIPCardID= @vipcardid

	if @nbilltype in (12,13)
	begin
		/*update retailmerge set draft=0 where newbillguid=@billguid and draft=1*/
		if @nBilltype in(12,13) and  @vipCardID <> 0
		begin
		  if @ArApTotal=0 
		  begin
		    if exists(select top 1 * from salemanagebill s, CTIntegralOther ct, VIPCard V,billidx b where b.billid=s.bill_id and s.p_id=ct.p_id and v.ct_id=ct.ct_id and b.VIPCardID=v.vipcardid and billid=@nNewBillId)
	          begin        
			    execute ts_c_VipIntergral @nNewBillId,@nBilltype
			    if @@error<>0 goto error	
	          end else
	          begin
	            exec  ts_c_TheAllVipIntergral  @nNewBillId,@nBilltype
	            if @@error<>0 goto error	
	          end          		    
		  end
		  if @ArApTotal=1
		  begin
		    execute ts_c_YVipIntergral @nBillId,@nBilltype
			if @@error<>0 goto error
		  end
		  update billidx set ArApTotal=2 where billid=@nNewBillId		         		  		 		    
		end							

		if exists(select 1 from sysconfig where [sysname] = 'PosDataMode' and sysvalue = '2')
		  if exists(select 1 from sysconfig where [sysname] = 'YclassID' and sysvalue <> '000001')
	          begin
		    select @nRetailBillID = billid from retailbillidx where [GUID] = @billguid
                    if @nRetailBillID is not null
                    begin
	              exec @nReturnNumber=ts_c_OfflineRetailToHis @nRetailBillID, @nNewYBillId output
	              if @nReturnNumber<>0 goto error
                      if @nNewYBillId < 1 goto error
 	 	    end
	          end
	end
   /*销售出库单里增加会员卡积分功能, 只处理批发企业 */
   if @nbilltype in (10,11,210,211)
	begin
	   	set @vipCardID=0
		select @vipCardID=card_id from clients where client_id in (select c_id from billidx where billid=@nNewBillId)
		select @dicount=ct.Discount, @isBank = ct.isBank from VIPCardType ct,Vipcard V where V.ct_id=ct.ct_id and v.VIPCardID= @vipcardid
  		if (@vipCardID <> 0) 
		begin
          if exists(select top 1 * from salemanagebill s, CTIntegralOther ct, VIPCard V,billidx b where b.billid=s.bill_id and s.p_id=ct.p_id and v.ct_id=ct.ct_id and b.VIPCardID=v.vipcardid and billid=@nNewBillId)
          begin        
		    execute ts_c_VipIntergral @nNewBillId,@nBilltype
		    if @@error<>0 goto error	
          end 
          else begin
            exec  ts_c_TheAllVipIntergral  @nNewBillId,@nBilltype
            if @@error<>0 goto error	
          end        
		end
	end

	if @nBilltype in(15,23,155,165,170) 
	begin
		if exists(select * from jspdetail where skd_bid=@nBillid and flag=1)
		begin
			insert jspdetail (c_id,skd_bid,xsd_bid,billtype,quantity,jstotal,detail_id,yj_quantity,flag,RowGuid,Y_Id,DetailGuid,skdGuid,xsdGuid)
			select c_id,@nNewBillId,xsd_bid,billtype,quantity,jstotal,detail_id,yj_quantity,0,RowGuid,Y_Id,DetailGuid,skdGuid,xsdGuid
			from jspdetail where skd_bid=@nBillid and flag=1
			
/*			delete from jspdetail where skd_bid=@nBillid and flag=1*/
/*			update jspdetail set skd_bid=@nNewBillId,flag=0 where skd_bid=@nBillid*/
		end
		if exists(select 1 from jsbdetail where skd_bid=@nBillid and flag=1)
		begin
			insert jsbdetail (c_id,skd_bid,xsd_bid,billtype,jstotal,remaintotal,flag,Y_Id,skdGuid,xsdGuid,RowGuid)
			select c_id,@nNewBillId,xsd_bid,billtype,jstotal,remaintotal,0,Y_Id,skdGuid,xsdGuid,RowGuid
			from jsbdetail where skd_bid=@nBillid and flag=1
			
/*			delete from jsbdetail where skd_bid=@nBillid and flag=1*/
/*			update jsbdetail set skd_bid=@nNewBillId,flag=0 where skd_bid=@nBillid*/
		end
	end
	
	delete from billdraftidx where billid=@nBillid /*删除原草稿单据*/

        /*处理采购、销售单(财务收款)后,删除原草稿单据的(业务开单)记录-------------*/
        Declare @DrfBillId int /*草稿单据ID*/
        Declare @smb_id int    /*正式单据中,记录草稿明细ID*/
	set  @DrfBillId=0
	set  @smb_id=0  
        if @nVchtype in(220)
        begin     
                select top 1 @smb_id=orgBillid from BuyManagebill where bill_id=@nNewBillId  
                if (@smb_id>0)
                begin
                    select top 1 @DrfBillId=isnull(Bill_id,0) from BuyManagebillDrf where smb_id=@smb_id
                    if (@DrfBillId>0) 
                    begin
                      if exists(select * from billDraftidx where Billid=@DrfBillId and BillStates=8)
                          begin
                                delete billDraftidx where Billid=@DrfBillId  /*删除原草稿单据的(业务开单)记录*/
                          end
		    end 
 		end                   
        end
        if @nVchtype in(210)
        begin     
                select top 1 @smb_id=orgBillid from SaleManagebill where bill_id=@nNewBillId  
                if (@smb_id>0)
                begin
                    select top 1 @DrfBillId=isnull(Bill_id,0) from SaleManagebillDrf where smb_id=@smb_id
                    if (@DrfBillId>0) 
                    begin
                      if exists(select * from billDraftidx where Billid=@DrfBillId and BillStates=8)
                          begin
                            delete billDraftidx where Billid=@DrfBillId /*删除原草稿单据的(业务开单)记录*/
                          end
		    end 
 		end                   
        end
        /*处理采购、销售单(财务收款)后,删除草稿中的(业务开单)记录-------------*/
    
	exec ts_getsystmpvalue 'billdateAudidate',2,@billdateAudit out
    
    Select @tAuditDate=getdate()
	
	IF ISNULL(@billdateAudit,0)=0
	  update billidx set billstates='0',period=@nPeriod,AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	  where BillId=@nNewBillId
	ELSE
      update billidx set billstates='0',period=@nPeriod,billdate=left(@tAuditDate,10),AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	  where BillId=@nNewBillId

	if @@error<>0 goto error
	
	if @nbilltype=141 
	begin
		exec @nReturnNumber=ts_c_AuditIniBill @nNewBillId,@Y_id,@nP_Id out,@nReturnNumber out
		if @@error<>0 goto error
		if @nReturnNumber<>0 goto error
        exec TS_L_UpIniInputBillProduct @nNewBillId,0,0,1
        if (@nReturnNumber = 0) and (@nP_Id =0) set @nP_Id = @nNewBillId
		/*commit tran Audit*/
		/*SET TRANSACTION ISOLATION LEVEL READ COMMITTED*/
		return 0
	end

	exec @nReturnNumber=ts_c_CreatePDetail @nNewBillId /*产生商品明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	

	exec ts_c_AuditP @nNewBillId,@nP_Id out,@nReturnNumber out /*商品登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error

	exec @nReturnNumber=ts_c_CreateADetail @nNewBillId /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
	
	/*检查是否存在删除的基本资料*/
	if @nbilltype not in (30,31,32,33,34,35,120,121,122,110,112,112,149)
	begin
		exec @nReturnNumber=ts_c_validcheck @nNewBillId,@nbilltype
		if @@error<>0 goto error
		if @nReturnNumber<>0 goto error
		/*begin
			rollback tran Audit
			SET TRANSACTION ISOLATION LEVEL READ COMMITTED
			return -1
		end*/
	end	

	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
		/*begin
			rollback tran Audit
			SET TRANSACTION ISOLATION LEVEL READ COMMITTED
			return -1
		end*/
	

	exec ts_c_AuditA @nNewBillId,@nReturnNumber out /*科目登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
    
	if @nBilltype in(15,23,155,165,170) and (@cJsFlag in ('B','P'))
	begin
		exec @nReturnNumber=ts_c_SFKJs @nNewBillId,@nBilltype,@cJsFlag,'0'
		if @nReturnNumber=-101
		if @nReturnNumber<>0 goto error
		/*begin
			rollback tran Audit
			SET TRANSACTION ISOLATION LEVEL READ COMMITTED
			return -101
		end*/
	end

        /*应修改为 下传公司发货单 */
	if @nBilltype in (30,34,38,41,44,46,47,48,49,51) /*统计表头的金额 2004-07-23 曾川改*/
	begin
		select @totalmoney=0
		select @totalmoney=isnull(sum(total),0) from storemanagebill where bill_id=@nNewBillId and aoid=0
		update billidx set ysmoney=@totalmoney,ssmoney=@totalmoney where billid=@nNewBillId
	end

	if @np_id=0 set @nP_id=isnull(@nNewBillid,0)
	
	/*if not exists(select 1 from sysconfig where sysname ='PosDataMode' and sysvalue = 2) -- 因为离线模式传送方式改为自动传送，故离线模式取消添加到传送任务 modify by luowei 2012-07-18*/
    /*if @nBilltype in (150,161,152,163) exec ts_c_AddTask @nNewBillid,@nBilltype--添加任务  */

    if exists(select 1 from sysconfigtmp where sysname='storagebillbySalebill' and sysvalue = '1')  /*增加开关 add by luowei 2012-10-10*/
    begin
		if @nBilltype =210 exec @nReturnNumber=ts_M_Autobill @nNewBillId,@nE_id,@Y_id  /*生成内部移库单*/
		if @nReturnNumber<>0 goto error
	end																
    
    
    if @nBilltype in (44) /*后继版本加控制，在不需要的时候不插入此表*/
    begin								
	  insert msgcenter([msgtype],[billid],[billtype])
	  values
	  (0,@nNewBillId,@nBilltype)
	end
	
	exec ts_c_deletetmpdetail @nNewBillid
	
	if @nBilltype = 10	/* 销售出库时回填平台标志，云南*/
	begin
		declare @nOrder int
		declare @sPlatBillNum varchar(36)
		declare @sSaleBillNum varchar(36)
		declare @dBillDate datetime
		
		SELECT     @nOrder=b.order_id
		FROM      billidx a,salemanagebill b
		WHERE  a.billid=b.bill_id and a.billid = @nNewBillId
							  
		if @nOrder > 0
		begin
		  
		    set @sPlatBillNum=''
			select @sPlatBillNum = a.InvoiceNO from orderidx a,OrderBill b
			where a.billid=b.bill_id and b.smb_id = @nOrder and a.billtype = 14 and a.order_id=-9
			if @sPlatBillNum<>''
			begin
				update zb_sa_lst set SALESID = @szBillNumber, CKDATE = @tAuditDate where ZBSADTLNO = @sPlatBillNum
			end
		end
	END
	else
	/* 采购入库单/销售出库退货单/采购退货单过账更新整个流程单据状态为已完成（原始状态为已审核）*/
	if @nBilltype IN (20, 11,21)
	begin
		UPDATE GSPbillidx SET BillStates = 15 WHERE Gspbillid IN(SELECT billId FROM billTrace WHERE traceGuid = (SELECT TOP 1 traceGuid FROM billTrace WHERE billId = @nNewBillId AND BillType = @nBilltype AND isDraft = 0 ORDER BY id DESC))
			AND BillType BETWEEN 501 AND 599 AND BillStates = 13
	end	
	EXEC Ts_K_AfterBillAudit @nBilltype, @nBillId, @nNewBillId /*处理电子监管码*/
	/* 实时连接的收货机构自动生成机构验收单*/
	if @nBilltype IN (150, 152)
	begin
		/* 判断收货机构是否实时连接*/
		IF EXISTS(SELECT * FROM company WHERE company_id = (SELECT c_id FROM billidx WHERE billid = @nNewBillId) AND posdatamode = 0)
		BEGIN
			/* 置为负数，下面的存储过程好区分处理*/
			SET @nBilltype = -@nBilltype
			EXEC TS_H_CreateNewGspBill @nNewBillId, @nBillType, 523, 0
		END
	end
	/* 实时连接的收货机构自动生成机构退货验收单*/
	if @nBilltype IN (161, 163)
	begin
		/* 判断退货机构是否实时连接*/
		IF EXISTS(SELECT * FROM company WHERE company_id = (SELECT Y_ID FROM billidx WHERE billid = @nNewBillId) AND posdatamode = 0)
		BEGIN
			/* 置为负数，下面的存储过程好区分处理*/
			SET @nBilltype = -@nBilltype
			EXEC TS_H_CreateNewGspBill @nNewBillId, @nBillType, 524, 0
		END
	end	
	/*commit tran Audit
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	*/
 	return 0
error:
	/*rollback tran Audit
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED*/
	return @nReturnNumber
GO
