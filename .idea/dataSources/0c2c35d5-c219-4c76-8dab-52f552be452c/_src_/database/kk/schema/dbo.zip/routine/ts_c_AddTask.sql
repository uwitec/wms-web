

create proc ts_c_AddTask
(
	@nbillid int,
	@nbilltype int
)
/*with encryption*/
as
set nocount on
/*判断单据是否已经存在于传送任务中，有则不传送 add by luowei 2012-07-18*/
if exists(select 1 from tasklist where billid = @nbillid) 
return 0

/*独立账套，离线账套下传单据，实时帐套不下传单据*/
declare @nPodaDataMode int, @nBillY_ID int, @nYType int
declare @nYPosDataMode int /*分支机构的posdatamode*/


/*用于总部帐套，0 实时账套、1 独立账套、2 离线账套*/
select @nPodaDataMode = CAST(sysvalue as int) from sysconfig where [sysname] = 'PosDataMode' 

select @nBillY_ID = c_id from billidx where billid = @nbillid

select @nYType = Ytype from company where company_id = @nBillY_ID 
/*0 分公司--1 自营店--2 加盟店--3 内部机构*/


/*if (@nPodaDataMode <> 1) and @nYType <> 2 return 0  */
  
declare @nY_id  int, @nDY_ID int, @szBillGuid varchar(50), @szYclassID varchar(30), @nBillStates int
declare @nRet int

SELECT @nY_id=ISNULL(cast(sysvalue as int), 0) FROM sysconfig WHERE upper([sysname])='Y_ID'
SELECT @szYclassID=[sysvalue] FROM sysconfig WHERE upper([sysname])='YCLASSID'

if @nY_id=0 return -1 


if (@nbilltype in (150, 161, 152, 163) and @nYType not in (1,2)) or (@nbilltype in (150, 161, 152, 163) and @nPodaDataMode = 0 and @nYType not in (1)) /*--add by luowei 2013-02-05 实时模式自营店生成机构收货单草稿 */
begin
  select @nDY_ID = c_id, @nY_id = y_id from billidx where billid = @nbillid
  if exists(select 1 from company where company_id = @nDY_ID and superior_id = @nY_id and @nbilltype = 150)
  begin
    exec @nRet = ts_j_ConvertYVch @nbillid, @nbilltype
    if exists(select 1 from company where posdatamode =0 and company_id = @nY_ID)
    Return 0
  end
  if exists(select 1 from company where company_id = @nY_ID and posdatamode = 0 and superior_id = @nDY_ID and @nbilltype = 161)
  begin
    exec @nRet = ts_j_ConvertYVch @nbillid, @nbilltype
    return @nRet
  end
end

/*if exists(select * from sysconfig where upper([SysName])= 'ISUPDATEFILIALE' and sysValue = '0') return -1*/

if @nbilltype in (150, 152) 
begin
    if exists(select * from tasklist where billid=@nbillid and billtype = 150 and trantype = 0) return -1
	select @nDY_ID=c_id, @nY_id=Y_ID, @szBillGuid = guid from billidx where billid=@nbillid and billtype in (150,152)
	/*判断机构的posdatamode*/
	set @nYPosDataMode=-1
	select @nYPosDataMode=posdatamode from company where company_id=@nDY_ID
	
	if (@nY_id is null) or (@nDY_ID is null)  return -2
	insert tasklist(taskdate,billid,billtype,Y_ID,billGuid, DY_ID) values (getdate(),@nbillid,@nbilltype,@nY_ID,@szBillGuid,@nDY_ID)
	if @nYPosDataMode>0 /*离线模式的时候，默认为不能下载配送单或者机构发货单，做收货确认后 才可以下载*/
	begin
		if @nYPosDataMode=2 update tasklist set tranflag=2 where billid=@nbillid and billtype=@nbilltype and DY_ID=@nDY_ID and Y_ID=@nY_id
	end
	return 0
end else if @nbilltype in (180,181,182,183) 
begin
    select @nDY_ID=posid, @nY_id=Y_ID, @szBillGuid = guid, @nBillStates =billstates from Cxidx where billid=@nbillid and billtype in (180,181,182,183)
    if @nBillStates = 5
      update tasklist set tranflag = 3 where billtype in (180,181,182,183)  and trantype = 0 and billstates = 3 and billguid  = @szBillGuid
    if exists(select * from tasklist where billguid  = @szBillGuid and billtype in (180,181,182,183)  and trantype = 0 and billstates = @nBillStates) return -1
	if (@nY_id is null) or (@nDY_ID is null)  return -2
	insert tasklist(taskdate,billid,billtype,Y_ID,billGuid, DY_ID,billstates) values (getdate(),@nbillid,@nbilltype,@nY_ID,@szBillGuid,@nDY_ID,@nBillStates)
	return 0
end else if @nbilltype in (140)
begin   
        select @szBillGuid = guid from priceidx where billid = @nbillid and billtype =140
        if exists(select * from priceidx where billid = @nbillid and billtype =140 and posid = @nY_ID)
        begin
          if not exists(select * from tasklistup where billguid = @szBillGuid and trantype = 0 and TableType='O')
            insert into TaskListUp(taskdate, y_id, billguid, TableType,Trantype) values(getdate(), @nY_ID, @szBillGuid,'O',0)
        end
        if exists(select * from tasklist where billid=@nbillid and billtype = 140 and trantype = 0) return -1
        select @nDY_ID = posid from priceidx  where billid = @nbillid and billtype =140
        if @szYclassID = '000001' and @nDY_ID = @nY_ID set @nDY_ID = 0
	insert tasklist(taskdate,billid,billtype,Y_ID,billGuid, DY_ID) values (getdate(),@nbillid,@nbilltype,@nY_ID,@szBillGuid,@nDY_ID)
	return 0
end
GO
