




/*商品导入*/
/*得到需要上传到微信商城的商品*/
CREATE PROCEDURE [WebAPP_GetProductList]
(
    @importflag	int,
    @timestamp int
)

/*$Encode$--*/

AS
/*增量更新*/
if @importflag=1
begin
	if @timestamp=0
	begin
		select @timestamp=value from wx_import_ModifyDate where datatype='products'
		select @timestamp=isnull(@timestamp,0)
	end
end

if not exists(select top 1 1 from products where child_number=0 and child_count=0 and cast(ModifyDate as int)>@timestamp and isimport2wx=1)
begin
	select @timestamp=max(cast(ModifyDate as int)) from products 
	if not exists(select 1 from wx_import_ModifyDate where datatype='products')
	begin
		insert into wx_import_ModifyDate(datatype,value) values('products',@timestamp)		
	end
	else
	begin
		update wx_import_ModifyDate set value=@timestamp where datatype='products'
	end
end

/*这儿可以跟据数据的大小来确定top*/
/*服装的颜色尺码比较多，建议这个top值少一点*/
select top 2000 product_id as p_id,name as pname,unit1_id as u_id,'' as unit,deleted,cast(ModifyDate as int) as md
,0 as SizeGroupID,0 as colorGroupID/*服装特有，其它项目可以不用写*/
into #products
from products 
where child_number=0 and child_count=0 and isimport2wx=1 and cast(ModifyDate as int)>@timestamp and deleted in (0,3)
order by ModifyDate asc
/*需要导入的售价各项目自己解决*/
select p.*,pr.retailprice as price from #products p left join price pr on p.p_id=pr.p_id and p.u_id=pr.u_id order by p.md asc

/*
如果是服装，则需要在这儿查找颜色尺码
下面查找颜色尺码也是服装特有，其它项目直接注释掉
*/
/*
select p.p_id,
p.SizeGroupID,
isnull(s.ID,0) as sizeid,isnull(s.name,'无') as sizename,
p.ColorGroupID,
isnull(c.ID,0) as colorid,isnull(c.name,'无') as colorname 
from #products p
left join sizegroup sg on p.SizeGroupID=sg.ID
left join SizeGroups sgs on sg.ID=sgs.SizeGroupID
left join Size s on s.ID=sgs.SizeID
left join colorgroup cg on p.colorGroupID=cg.ID
left join colorGroups cgs on cg.ID=cgs.colorGroupID
left join color c on c.ID=cgs.colorID
where p.deleted=0
*/
GO
