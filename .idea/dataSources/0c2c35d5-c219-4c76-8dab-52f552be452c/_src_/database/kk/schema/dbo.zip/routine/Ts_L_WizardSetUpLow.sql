


CREATE	PROCEDURE [Ts_L_WizardSetUpLow] 
(	@BeginDate	varchar(20),		/*开始日期*/
	@EndDate	varchar(20),		/*结束日期*/
	@s_id		int,				/*仓库ID*/
	@sClassid	varchar(30),		/*仓库 */
	@Pclassid	varchar(30),		/*商品*/
	@lQty		NUMERIC(25,8),	    /*销售数量*/
	@lTotal 	NUMERIC(25,8),	    /*销售金额 */
	@szQtyCase	Varchar(4),	        /*数量的条件*/
	@szTotalCase	varchar(4),	    /*金额的条件*/
	@dUpLimitRate	NUMERIC(25,8),	/*库存上限比率*/
	@dLowLimitRate	NUMERIC(25,8),	/*库存下限比率*/
	@bPreView	bit,				/*是否为预览模式*/
	@nY_id          int,            /*分支机构ID*/
    @isupdata       int=0           /*根据门店销售数据生成库存上下限*/
)
AS
 
 if @isupdata is null  SET @isupdata = 0
  
 if object_id('tempdb..##mytempdb') is not null
 drop table ##mytempdb
 
	set nocount On	
	declare @szsql varchar(8000)
        select @szsql='select * into ##mytempdb from (SELECT dbo.products.class_id,
				  ISNULL(SUM(CASE WHEN b.billtype IN (11, 13, 211, 151) THEN -a.quantity ELSE a.quantity END), 0) AS quantity, 
				  ISNULL(SUM(CASE WHEN b.billtype IN (11, 13, 211, 151) THEN -a.taxtotal ELSE a.taxtotal END), 0) AS costtotal,
				  ISNULL(SUM(CASE WHEN b.billtype IN (11, 13, 211, 151) THEN -a.retailtotal ELSE a.retailtotal END), 0) AS retailtotal
			FROM vw_c_salemb a INNER JOIN
						 dbo.products ON a.p_id = dbo.products.product_id
			 left join vw_c_billidx b on b.billid=a.bill_id
			where dbo.products.deleted<>1  and b.billdate between '
				   +char(39)+convert(varchar(10),@Begindate,20)
				   +char(39)+' and '+char(39)+convert(varchar(10),@EndDate,20)+char(39)+
			 ' and b.billtype in (10,11,12,13,210,211,112,150,151) and b.billstates=''0'''
		   /*if @sClassid<>''  set @szsql=@szsql+' and  left(a.ssclass_id,len('+char(39)+@sClassid+char(39)+'))='+char(39)+@sClassid+char(39)*/
		   if @szQtyCase<>'' set @szSql=@szSql+' and a.Quantity '+@szQtyCase+Cast(@lQty as Varchar(18))
		   if @szTotalCase<>'' set @szSql=@szSql+' and a.taxtotal '+@szTotalCase+cast(@lTotal as varchar(18))
		   set @szsql=@szsql+' and Class_id like '+char(39)+@PClassid+char(39)
		   IF @isupdata = 0
		     SET @szsql = @szsql + ' AND a.ss_id = ' + CHAR(39) + CONVERT(VARCHAR(10), @s_id) + CHAR(39)
		   ELSE
		     SET @szsql = @szsql + ' AND a.ss_id IN (SELECT s.storage_id FROM storages s WHERE s.child_count = 0 AND s.[deleted] = 0 AND s.Y_ID <> 2) '	
		   set @szsql=@szsql+' GROUP BY dbo.products.class_id) as t' 
  print @SzSql
 exec (@szsql)
 if (select Count(0) from ##mytempdb)=0 
 begin
  Drop Table ##mytempdb
  return -1  
 end
 delete from StoreLimit 
 where slid in (select slid from vw_l_StockLimit a,##mytempdb b
   where a.pclass_id=b.class_id and a.Y_id=@nY_id  and
    a.PClass_id like @PClassid and a.sClass_id like @sClassid)
    
	UPDATE ##mytempdb SET quantity=0 WHERE ISNULL(quantity,0)<=0
	
	INSERT INTO StoreLimit(P_id,S_id,UpperLimit,LowLimit,Y_id)
    SELECT p.product_id, @s_id,
           CAST(ISNULL(a.quantity, 0) * @duplimitRate AS NUMERIC(25,8)) AS setUpper,
	       CAST(ISNULL(a.quantity, 0) * @dLowlimitRate AS NUMERIC(25,8)) AS setLow,
	       @nY_id 
      FROM ##mytempdb a INNER JOIN products p ON a.class_id = p.class_id
 
 if object_id('tempdb..##mytempdb') is not null
 drop table ##mytempdb

 return 1
GO
