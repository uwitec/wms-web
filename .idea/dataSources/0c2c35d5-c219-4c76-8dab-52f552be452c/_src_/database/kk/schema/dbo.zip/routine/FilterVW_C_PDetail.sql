
CREATE FUNCTION FilterVW_C_PDetail(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     pd.pd_id, pd.billid, pd.p_id, pd.s_id, pd.quantity, pd.price, pd.total, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costprice ELSE 0 END AS costprice, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costtotal ELSE 0 END AS costtotal, pd.taxprice, pd.taxtotal, pd.batchno, pd.makedate, 
							  pd.validdate, pd.commissionflag, pd.supplier_id, pd.location_id, pd.storetype, pd.price_id, pd.order_id, pd.unitid, pd.smb_id, pd.comment, pd.jsprice, 
							  pd.oldcommissionflag, pd.AOID, pd.Y_ID, pd.rowguid, pd.ROWE_id, pd.SendQTY, pd.SendCostTotal, pd.retailtotal,pd.sname,pd.standard,pd.makearea,pd.pname,pd.serial_number,pd.pcomment,pd.alias,
							  pd.locname,pd.suppliername,pd.flowflag, pd.SCName,isnull(pd.factory,'') as factory
		FROM         dbo.VW_C_PDetail AS pd INNER JOIN
							  dbo.products AS p ON pd.p_id = p.product_id
GO
