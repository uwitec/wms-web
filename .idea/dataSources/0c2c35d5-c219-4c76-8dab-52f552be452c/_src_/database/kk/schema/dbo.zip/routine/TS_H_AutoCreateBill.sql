
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-11-19*/
/* Description:	自动生成指定单据*/
/* =============================================*/
CREATE PROCEDURE [TS_H_AutoCreateBill] 
	@nBillId		int,
	@nBillType		int,
	@nRetNum		int output
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @nNewBillId int
	declare @sBillNumber varchar(50)
	return 0
	if @nBillType = 12
	begin
		declare @nQtyCtrl int
		select @nQtyCtrl = sysvalue from sysconfig where sysname = 'RetailStohsCtrl' and Y_ID = 0
		if @nQtyCtrl = 0
			return 0
		/* 启用零售不管批次后无效*/
		select @nQtyCtrl = sysvalue from sysconfig where sysname = 'RetailNoBatchno' and Y_ID = 0
		if @nQtyCtrl = 1
			return 0
		/* 统一成本核算法且不为手工指定无效*/
		if exists(select 0 from sysconfig where sysvalue <> '3' and sysname = 'CostMethod') and
			exists(select 0 from sysconfig where sysvalue = '1' and sysname = 'UseSameCostMethod')
			return 0
		select p_id into #p
		from salemanagebill where bill_id = @nBillId
		if exists(select 0 from sysconfig where sysvalue = '0' and sysname = 'UseSameCostMethod')
		begin
			delete from #p where p_id in (select product_id from products where costmethod <> 3)
		end
			
		exec TS_H_CreateBillSN 42, 1, null, 0, 0, @sBillNumber output
			
		insert into billdraftidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
                      order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
                      InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
                      B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty)
        select billdate, @sBillNumber, 42, 0, 0, e_id, sout_id, sout_id, inputman, inputman, 0, 0, 0, 0, period, 3, 
                      @nBillId, department_id, posid, 0, auditdate, skdate, 0, jsflag, '由零售单自动生成：' + billnumber, summary, invoice, transcount, lasttranstime, NEWID(), InvoiceTotal, 
                      InvoiceNO, BusinessType, 0, 0, GatheringMan, 0, jsInvoiceTotal, Y_ID, 2, begindate, Enddate, 0, 0, 
                      '', '', '', '1900-1-1', 0, 0, 0 
        from billidx where billid = @nBillId
        
        set @nNewBillId = @@IDENTITY
        
        insert into storemanagebilldrf (bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, 
                      SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion)
        select @nNewBillId, sb.p_id, sb.batchno, sb.quantity - ISNULL(sh.quantity, 0), CASE sb.costprice WHEN 0 THEN CASE p.recprice WHEN 0 THEN sb.saleprice WHEN NULL THEN sb.saleprice ELSE p.recprice END ELSE sb.costprice END, 0, CASE sb.costprice WHEN 0 THEN CASE p.recprice WHEN 0 THEN sb.saleprice WHEN NULL THEN sb.saleprice ELSE p.recprice END ELSE sb.costprice END, 0, sb.retailprice, 0, sb.makedate, sb.validdate, sb.qualitystatus, sb.price_id, 
                      sb.ss_id, 0, sb.location_id, sb.supplier_id, sb.commissionflag, dbo.GetProductComment(sb.p_id, sb.quantity - ISNULL(sh.quantity, 0)), sb.unitid, 0, 0, 0, 0, sb.quantity - ISNULL(sh.quantity, 0), CASE sb.costprice WHEN 0 THEN CASE p.recprice WHEN 0 THEN sb.saleprice WHEN NULL THEN sb.saleprice ELSE p.recprice END ELSE sb.costprice END, sb.smb_id, sb.AOID,
                      sb.quantity - ISNULL(sh.quantity, 0), 0, NEWID(), sb.RowE_id, sb.Y_ID, sb.instoretime, '', '', 0, sb.Conclusion
        from salemanagebill sb
			left join (SELECT     location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, validdate, commissionflag, Y_ID
				FROM         dbo.storehouse
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, validdate, commissionflag, Y_ID) sh
					on sb.p_id = sh.p_id
					and sb.ss_id = sh.s_id
					and sb.batchno = sh.batchno
					and sb.costprice = sh.costprice
					and sb.Y_ID = sh.Y_ID
					and sb.supplier_id = sh.supplier_id
					and sb.makedate = sh.makedate
					and sb.validdate = sh.validdate
					and sb.location_id = sh.location_id
					and sb.commissionflag = sh.commissionflag
			LEFT JOIN (SELECT p_id, recprice FROM price where unittype = 1) p on sb.p_id = p.p_id
			where (sh.p_id is null
			or sh.quantity < sb.quantity
			) and sb.p_id > 0 and sb.bill_id = @nBillId and sb.AOID in (0, 7) and sb.p_id in(select p_id from #p)
		
		if not exists(select 0 from storemanagebilldrf where bill_id = @nNewBillId)
		begin
			delete from billdraftidx where billid = @nNewBillId
			return 0
		end
			
		update storemanagebilldrf set costtotal = costprice * quantity, total = price * quantity, retailmoney = retailprice * quantity, SendCostTotal = costprice * quantity where bill_id = @nNewBillId
		
		update billdraftidx set ysmoney = x.total, ssmoney = x.total, quantity = x.qty, SendQTY = x.qty
		from (select SUM(costtotal)as total, SUM(quantity) as qty from storemanagebilldrf where bill_id = @nNewBillId) x
		where billdraftidx.billid = @nNewBillId
		
		update salemanagebill set costprice = x.costprice
		from (select orgbillid, costprice from storemanagebilldrf where bill_id = @nNewBillId) x
		where salemanagebill.smb_id = x.orgbillid and bill_id = @nBillId
		
		update salemanagebilltmp set costprice = x.costprice
		from (select orgbillid, costprice from storemanagebilldrf where bill_id = @nNewBillId) x
		where salemanagebilltmp.smb_id = x.orgbillid and bill_id = @nBillId
		
		exec ts_c_BillAudit @nNewBillId, @nNewBillId output, @nRetNum output, @nBillType
	end
END
GO
