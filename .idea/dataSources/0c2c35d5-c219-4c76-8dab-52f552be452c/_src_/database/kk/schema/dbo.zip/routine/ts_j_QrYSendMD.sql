


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

合同查询
@cMode=0 以单据日期筛选
	=1 以过帐日期筛选

********************************************/
CREATE PROCEDURE [ts_j_QrYSendMD]
(	@Begindate              DATETIME='',
	@EndDate		DATETIME='',
	@nE_ID			INT=0,
        @nInputman              INT=0,  
        @szYClassID             INT=0,
        @nLoginEid              INT=0,
        @nQrMode		INT=0
)
AS
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = ''
if @EndDate is null  SET @EndDate = ''
if @nE_ID is null  SET @nE_ID = 0
if @nInputman is null  SET @nInputman = 0
if @szYClassID is null  SET @szYClassID = 0
if @nLoginEid is null  SET @nLoginEid = 0
if @nQrMode is null  SET @nQrMode = 0
/*Params Ini end*/
SET NOCOUNT ON

   set @Begindate=CONVERT(varchar(10),@begindate,21)
   set @EndDate=CONVERT(varchar(10),@EndDate,21)

  declare @billtype int, @billtypeOne int
  if @nQrMode = 0 
   begin 
     set @billtype = 152
     set @billtypeOne = 162
   end
  if @nQrMode = 1 
   begin 
     set @billtype = 150
     set @billtypeOne = 160
   end
/*--xzdong-2016-11-07-TFS42264-门店收货确认查询查不到总部发货而门店未收货的单据*/
select distinct B.* from
( select a.[BillID],a.[Billtype], a.[Billdate], a.[Billnumber], a.[Billstates],
      a.[Inputman], a.[Auditman], a.[Note],     a.[Summary],    a.[Quantity],
      a.[Ysmoney],  a.[Ssmoney],  a.[Taxrate],  a.[Auditdate],
      3 as transflag,0 as serialno,'' as [Billname],
	  a.[Ename]          AS [Employeename],
	  a.[Auditmanname]   AS [Auditmanname],
	  a.[Inputmanname]   AS [Inputmanname],
	  a.[Aname]          AS [Accountname],
	  a.[Departmentname] AS [Departmentname],
	  a.[Regionname]     AS [Regionname],
	  a.[Yname] as CName, a.b_customName3,a.[cname] as YName
	  ,[E_ID],c_id,YClass_ID 
	  from (select * from vw_c_billidx where billtype = 152 )a inner join (
            select billid,YGuid,Y_ID,billtype from vw_c_billidx where billtype = 162) b on a.YGuid = b.YGuid 
            where a.billstates=0 
)B   where [Billdate] BETWEEN @Begindate and @EndDate and
	       (@nE_ID =0 or [E_ID]= @nE_ID) and  (@nInputman = 0 or [Inputman]= @nInputman) and 
           billstates = '0' and  
           (@szYClassID = 0 or  c_id = @szYClassID) and ((@nQrMode = 0) or (YClass_ID <> '000001'))
UNION ALL         
( select distinct a.[BillID],a.[Billtype], a.[Billdate], a.[Billnumber], a.[Billstates],
      a.[Inputman], a.[Auditman], a.[Note],     a.[Summary],    a.[Quantity],
      a.[Ysmoney],  a.[Ssmoney],  a.[Taxrate],  a.[Auditdate],
      0 as transflag,0 as serialno,'' as [Billname],
	  a.[Ename]          AS [Employeename],
	  a.[Auditmanname]   AS [Auditmanname],
	  a.[Inputmanname]   AS [Inputmanname],
	  a.[Aname]          AS [Accountname],
	  a.[Departmentname] AS [Departmentname],
	  a.[Regionname]     AS [Regionname],
	  a.[Yname] as CName, a.b_customName3,a.[cname] as YName
	  ,[E_ID],c_id,YClass_ID 
	  from vw_c_billidx a where yguid not in ( select a.yguid from (select * from vw_c_billidx where billtype = 152 )a 
	  inner join (select billid,YGuid,Y_ID,billtype from vw_c_billidx where billtype = 162) b on a.YGuid = b.YGuid 
	  where a.billstates=0 ) 
	  and billtype=152 and  [Billdate] BETWEEN @Begindate and @EndDate and
	  (@nE_ID =0 or [E_ID]= @nE_ID) and  (@nInputman = 0 or [Inputman]= @nInputman) and 
      billstates = '0' and (@szYClassID = 0 or  c_id = @szYClassID) and ((@nQrMode = 0) or (YClass_ID <> '000001')))
      order by billdate
/*    SELECT 
      b.[BillID],   B.[Billtype], B.[Billdate], B.[Billnumber], B.[Billstates],
      B.[Inputman], B.[Auditman], B.[Note],     B.[Summary],    B.[Quantity],
      B.[Ysmoney],  B.[Ssmoney],  B.[Taxrate],  B.[Auditdate],
      B.[transflag],0 as serialno,
		 [Billname]=CASE B.[Billtype]
		  WHEN 150 THEN '门店出库单'
		  WHEN 152 THEN '自营店发货单' END,
		  B.[Ename]          AS [Employeename],
		  B.[Auditmanname]   AS [Auditmanname],
		  B.[Inputmanname]   AS [Inputmanname],
		  B.[Aname]          AS [Accountname],
		  B.[Departmentname] AS [Departmentname],
		  B.[Regionname]     AS [Regionname],
		  B.[Yname] as CName, b.b_customName3, B.[cname] as YName		  
          FROM 
          --------门店收货确认查询 Wsj--2016.10.20修改-tfs41711---------------------------
          ( select a.* from (select * from vw_c_billidx where billtype = @billtype )a inner join (
               select billid,YGuid,Y_ID,billtype from vw_c_billidx where billtype = @billtypeOne) b on a.YGuid = b.YGuid where a.billstates=0 
           )B 
           where [Billdate] BETWEEN @Begindate and @EndDate and
	        (@nE_ID =0 or [E_ID]= @nE_ID) and  (@nInputman = 0 or [Inputman]= @nInputman) and 
              billstates = '0' and  
              (@szYClassID = 0 or  c_id = @szYClassID) and ((@nQrMode = 0) or (YClass_ID <> '000001'))
*/
/*		  
  	FROM vw_c_billidx B
        where [Billdate] BETWEEN @Begindate and @EndDate AND [Billtype]=@billtype and
	      (@nE_ID =0 or [E_ID]= @nE_ID) and  (@nInputman = 0 or [Inputman]= @nInputman) and 
              billstates = '0' and  
              (@szYClassID = 0 or  c_id = @szYClassID) and ((@nQrMode = 0) or (YClass_ID <> '000001'))  
*/
GO
