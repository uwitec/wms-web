

/*====================================*/
/*卡卷设置*/
/*select * from wx_vip_ticket*/
/*====================================*/
CREATE PROCEDURE WebAPP_GetVipticketByID
(
@chvid	int
)
/*$Encode$--*/
AS

select name,total,begindate,enddate,typeid,content,endday,useflag,givecount from wx_vip_ticket where id=@chvid
return 0
GO
