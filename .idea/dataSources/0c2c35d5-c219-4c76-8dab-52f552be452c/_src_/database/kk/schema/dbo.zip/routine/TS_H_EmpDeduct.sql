
/* =============================================*/
/* Author:  黄耀*/
/* Create date: 2010-11-8*/
/* Description: 记录职员提成*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_EmpDeduct]
 @BillID  int,
 @In   bit
AS
BEGIN
 SET NOCOUNT ON;
 
 insert into EmpDeduct
 SELECT     b.p_id, b.bill_id, r.Emp_ID, 0 as deduct, @in as price
 FROM         dbo.salemanagebill AS b INNER JOIN
        dbo.ProductEmpRight AS r ON b.p_id = r.p_id INNER JOIN
        dbo.billidx AS i ON b.bill_id = i.billid INNER JOIN
        dbo.clients AS c ON i.c_id = c.client_id AND r.R_ID = c.region_id
 where b.bill_id = @billid
END
GO
