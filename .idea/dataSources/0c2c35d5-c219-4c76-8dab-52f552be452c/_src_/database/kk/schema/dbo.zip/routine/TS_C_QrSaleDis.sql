

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

发货分布

********************************************/
CREATE PROCEDURE TS_C_QrSaleDis
(	@BeginDate 	DATETIME=0,
	@Enddate   	DATETIME=0,
	@szParid	  VARCHAR(30)='000000',	
	@szListFlag	CHAR(1)='L',
	@nE_id		  INT=0,
    @YClassID         varchar(50)='',
    @isaddDate        int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @Enddate is null  SET @Enddate = 0
if @szParid is null  SET @szParid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nE_id is null  SET @nE_id = 0
if @YClassID is null  SET @YClassID = ''
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000),@SZYClassID varchar(20), @nP_id INT, @nS_id INT,@nYid int,
  @szS_ID VARCHAR(30), @dQty NUMERIC(25,8), @dTotal NUMERIC(25,8)
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
  select @SZYClassID='000001'
  if @YClassID=''
  begin
    select  @YClassID='%%'
    Set @nYid=2
  end 
  else 
  begin
    select @nYid=company_id from company where class_id=@YClassID 
    select @YClassID=@YClassID+'%'
  end
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nE_id  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nE_id  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nE_id  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nE_id and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nE_id  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

if OBJECT_ID('tempdb..#product') is not null
   drop table #product
CREATE TABLE #product
(	PRODUCT_ID   INT)
if OBJECT_ID('tempdb..#storages') is not null
   drop table #storages
CREATE TABLE #storages
(	[ID] INT,
	CLASSID VARCHAR(30)
)
if OBJECT_ID('tempdb..#storehouse') is not null
   drop table #storehouse
CREATE TABLE #storehouse
(	P_ID INT,
	S_ID INT,
	szS_ID VARCHAR(30),
	QUANTITY NUMERIC(25,8),
  Total    NUMERIC(25,8))
/*取得商品*/
  IF @szListFlag='L'
  BEGIN
  	INSERT #product (product_id)
  	SELECT  product_id
  	FROM products
  	WHERE parent_id=@szParid AND deleted<>1 AND product_id<>1
  END
  IF @szListFlag='P'
  BEGIN
  	INSERT #product (product_id)
  	SELECT  product_id
  	FROM products
  	WHERE class_id like (@szParid+'%') AND deleted<>1 AND child_number=0
  END
  IF @szListFlag='A'
  BEGIN
  	INSERT #product (product_id)
  	SELECT  product_id
  	FROM products
  	WHERE  deleted<>1 AND child_number=0 AND product_id<>1
  END

  EXEC(@SQLScript)
/*取得仓库*/

 CREATE TABLE #LastClient
( [Product_ID] INT,
  [Class_ID] VARCHAR(30),
  [ClientName] VARCHAR(120),
  [Phone_number] VARCHAR(120),
  [RecPrice] NUMERIC(25,8)
)

insert into #lastclient(product_id,class_id,recprice,clientname,phone_number)
SELECT  P.[Product_ID] , P.[Class_ID],pd.buyprice,
   c.[name] AS [ClientName],c.phone_number 
   FROM  products p ,
	(select a.* from buypricehis a ,
		(select bp.p_id,bp.Y_ID,max(bp.modifydate) as modifydate from buypricehis bp left join company c on bp.Y_ID=c.company_id where c.Class_id=@szYClassID group by p_id,Y_ID) b
	 where a.p_id=b.p_id and a.modifydate=b.modifydate and a.Y_ID=b.Y_ID 
	)  as PD, 
        (select C.client_id,C.[name],C.[phone_number],c.class_ID from Clients C where deleted<>1
         AND (@Clienttable=0 or client_id in (select [id] from #Clienttable)))C

   WHERE P.[Child_Number]=0 AND p.deleted<>1 and pd.c_id=c.client_id and  pd.p_id=p.product_id

	

	
	INSERT #storages([ID],classid)
	SELECT S.Storage_id,S.class_id
	FROM vw_storage S
	WHERE  s.deleted=0 AND s.child_number=0 
        AND (@Storetable=0 or Storage_id in (select [id] from #storagestable))
 
        ORDER BY s.class_id
	

	DECLARE stockcur CURSOR FOR
	SELECT classid FROM #storages
	OPEN stockcur
	FETCH NEXT FROM stockcur into @szS_ID 
	WHILE @@FETCH_STATUS=0
	BEGIN
		SET @SQLScript =  'ALTER TABLE #product ADD A'+@szS_ID+ ' NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES'
		EXEC (@SQLScript)

		SET @SQLScript =  'ALTER TABLE #product ADD A'+@szS_ID+'T'+' NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES'
		EXEC (@SQLScript)
		FETCH NEXT FROM stockcur INTO @szS_ID
	END
	CLOSE stockcur
	DEALLOCATE stockcur
	EXEC ('ALTER TABLE #product ADD A000000  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES')
	EXEC ('ALTER TABLE #product ADD A000000T NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES')

BEGIN
  IF @szListFlag='L'
  BEGIN
  	INSERT #storehouse ([p_id],[s_id],[quantity], [total], [szS_ID])
  	SELECT p.product_id,st.[ID],SUM(-vs.quantity) AS quantity,
               SUM(-vs.total) as total, st.classID  
  	FROM #product p, #storages st,       
      
      ( select p.product_id,vt.s_id,isnull(SUM(vt.quantity),0) as quantity,isnull(SUM(vt.total),0) as total  from 
         (select * from products p where parent_id=@szParid) p,
		 (  SELECT p.[Product_ID],p.class_id, isnull(vs.[s_id],0) s_id, isnull(vs.[Quantity],0) quantity,isnull(vs.total,0) total  
			FROM products p 
			LEFT JOIN 
			(select vs.p_id,vs.s_id,isnull(vs.quantity,0) quantity,isnull(vs.total,0) total,isnull(Y.class_id,'') as Yclass_id  from productdetail vs
			 inner join (SELECT [BillID],isnull(Y.class_id,'') as Yclass_id  FROM billidx b 
						left join Company Y on Y.company_id=b.Y_id 
						WHERE Y.class_id like @YClassID  and  billdate BETWEEN @BeginDate AND @Enddate
						AND billtype in (10,11,12,13,112,53,54,212) and billstates='0') b 
			 on vs.billid=b.billid
			 left join Company Y on Y.company_id=vs.Y_id   
			 where Y.class_id like @YClassID and vs.aoid in(0, 5) and vs.p_id>0 
			 union all
			 select Yp.p_id,Yp.s_id,isnull(Yp.quantity,0) quantity,isnull(Yp.total,0) total,isnull(Y.class_id,'') as Yclass_id  from Yproductdetail Yp
			 left join Company Y on Y.company_id=Yp.Y_id
			 where Y.class_id like @YClassID  and Yp.billtype in (10,11,12,13,112,53,54,212) and Yp.aoid in (0, 5) 
				   and Yp.billdate BETWEEN @BeginDate AND @Enddate  and Yp.billstates='0' and Yp.p_id>0
			 ) vs
		 ON p.product_id=vs.p_id
		 ) vt 
	     where LEFT(vt.class_id,LEN(p.class_id)) = p.class_id
	     group by p.product_id,vt.s_id 
        ) vs        
        where p.product_id=vs.product_id and st.[id]=vs.s_id
        GROUP BY p.product_id,st.[ID],st.classID
  END
  ELSE BEGIN
  	INSERT #storehouse ([p_id],[s_id],[quantity], [total], [szS_ID])
  	SELECT p.product_id,st.[ID],SUM(-vs.quantity) AS quantity,
               SUM(-vs.total) as total, st.classID  
  	FROM #product p, #storages st, 
        (select vs.p_id,vs.s_id,isnull(vs.quantity,0) quantity,isnull(vs.total,0) total,isnull(Y.class_id,'') as Yclass_id  from productdetail vs
         inner join (SELECT [BillID],isnull(Y.class_id,'') as Yclass_id  FROM billidx b 
                    left join Company Y on Y.company_id=b.Y_id 
                    WHERE Y.class_id like @YClassID  and  billdate BETWEEN @BeginDate AND @Enddate
                    AND billtype in (10,11,12,13,112,53,54,212) and billstates='0') b 
         on vs.billid=b.billid
         left join Company Y on Y.company_id=vs.Y_id   
         where Y.class_id like @YClassID and vs.aoid in(0, 5) and vs.p_id>0
         union all
         select Yp.p_id,Yp.s_id,isnull(Yp.quantity,0) quantity,isnull(Yp.total,0) total,isnull(Y.class_id,'') as Yclass_id  from Yproductdetail Yp
         left join Company Y on Y.company_id=Yp.Y_id
         where Y.class_id like @YClassID  and Yp.billtype in (10,11,12,13,112,53,54,212) and Yp.aoid in (0, 5) 
               and Yp.billdate BETWEEN @BeginDate AND @Enddate  and Yp.billstates='0' and Yp.p_id>0
         )vs
         where p.product_id=vs.p_id and st.[id]=vs.s_id
  	 GROUP BY p.product_id,st.[ID],st.classID

  END
END

  DECLARE pdis CURSOR FOR
	SELECT p_id,s_id,quantity,[total], szS_ID
	FROM #storehouse	
	OPEN pdis
	FETCH NEXT FROM pdis INTO @nP_id,@nS_id,@dQty, @dTotal, @szS_ID
	WHILE @@FETCH_STATUS=0
	BEGIN
	  IF @dqty IS NULL SET @dqty = 0
		SET @SQLScript='UPDATE #product SET A'+@szS_ID+'='+CAST(@dqty AS VARCHAR)
      +' WHERE product_id='+cast(@nP_ID as Varchar)
    EXEC(@SQLScript)

		SET @SQLScript='UPDATE #product SET A'+@szS_ID+'T'+'='+CAST(@dTotal AS VARCHAR)
      +' WHERE product_id='+cast(@nP_ID as Varchar)
    EXEC(@SQLScript)

		SET @SQLScript='UPDATE #product SET [A000000]=[A000000]+'+CAST(@dqty AS VARCHAR)
      +' WHERE product_id='+cast(@nP_ID as Varchar)
    EXEC(@SQLScript)

		SET @SQLScript='UPDATE #product SET [A000000T]=[A000000T]+'+CAST(@dtotal AS VARCHAR)
      +' WHERE product_id='+cast(@nP_ID as Varchar)
    EXEC(@SQLScript)
  	FETCH NEXT FROM pdis INTO @nP_id,@nS_id,@dQty, @dTotal,@szS_ID
	END
	
	CLOSE pdis
	DEALLOCATE pdis

	ALTER TABLE #product ADD TempSN VARCHAR(6) NOT NULL DEFAULT('1')
	SET @SQLScript=
	'SELECT p1.TempSN as serialno,p2.class_id, p2.child_number, p2.code, p2.[name], 
  p2.standard, p2.makearea, p2.medtype,isnull(vp.e_name,'''') as e_name, isnull(vp.C_Name,'''') as C_Name,
        p2.Inputman,p2.InputDate,p2.Custompro1,p2.Custompro2,p2.Custompro3,p2.Custompro4,p2.Custompro5,p1.* ,
  ISNULL(BM.[RecPrice], 0) AS [Recprice], ISNULL(BM.[ClientName] ,'''') AS [ClientName], 
  ISNULL(BM.[Phone_number], '''') AS [Phone_number]
	FROM #product p1
  LEFT Join vw_productbalance vp On p1.[product_ID]=vp.[P_id]
  LEFT JOIN #LastClient BM ON P1.[Product_ID]=BM.[Product_ID], 
  vw_c_products p2 where p1.product_id=p2.product_id and vp.y_id= '+convert(varchar(30),@nYid) 
	EXEC(@SQLScript)

	/*DROP TABLE #product
	DROP TABLE #storages
	DROP TABLE #storehouse
	*/
  	DROP TABLE #LastClient
GO
