create procedure KKDZ_T_QryRetailBillMxSum
(	@szListFlag		VARCHAR(1)='L',/*分级显示*/
    @szParent_ID	VARCHAR(30)='',/*产品父类ID*/
    @nloginEID      int=0,/*登陆人ID*/
	@BeginDate   	VARCHAR(30),/*开始时间*/
	@EndDate	    VARCHAR(30),/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szEClass_ID	VARCHAR(30)='',/*经手人ID*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
	@szSClass_ID	VARCHAR(30)='',/*库房ID*/
	@nLocation_Id   VARCHAR(30)='',        /*货位ID*/
	@Department_ID  varchar(30)='',/*部门*/
	@szRClass_id   varchar(50) = '', /*片区 */
	@nYClassid                 varchar(100)=''         
)
AS
/*Params Ini begin*/
if @szListFlag is null  SET @szListFlag = 'L'
if @szParent_ID is null  SET @szParent_ID = ''
if @nloginEID is null  SET @nloginEID = 0
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @szSClass_ID is null  SET @szSClass_ID = ''
if @nLocation_Id is null  SET @nLocation_Id = ''
if @Department_ID is null  SET @Department_ID = ''
if @szRClass_id is null  SET @szRClass_id = ''
if @nYClassid is null  SET @nYClassid = ''
/*Params Ini end*/
DECLARE @SQLTemp varchar(8000)
DECLARE @sql varchar (8000)
/*
IF @szListFlag='L'  SELECT @SQLTemp='and p.[Deleted]<>1 AND p.[Parent_ID]='+CHAR(39)+@szParent_ID+CHAR(39)
IF @szListFlag='A' 	SELECT @SQLTemp='and p.[Deleted]<>1 AND p.[Child_number]=0'
IF @szListFlag='P' 	SELECT @SQLTemp='and p.[Deleted]<>1 AND p.[Child_number]=0 AND LEFT(P.[Class_ID], LEN('+CHAR(39)+@szParent_ID+CHAR(39)+'))='+CHAR(39)+@szParent_ID+CHAR(39)
*/
begin
   select a.product_id,a.serial_number,a.alias,a.standard,a.uname,a.AccountComment,a.Y_ID,c.name,sum(a.quantity) as quantity 
       into #Products from  ( 
         select idx.Y_ID,p.product_id,p.serial_number , p.alias ,p.standard ,u.name as uname,b.AccountComment ,
        (case when idx.billtype = 12 then s.quantity else -s.quantity end) as quantity 
         from salemanagebill s 
         left join products p on s.p_id = p.product_id
         left join unit u on s.unitid = u.unit_id
         left join basefactory b on p.factoryc_id = b.CommID
         left join billidx idx on idx.billid = s.bill_id 
         where s.p_id >0 and idx.billdate between @BeginDate  and  @EndDate 
         and idx.billstates = 0 and idx.billtype in (12,13)
         )a     
     left join company c on a.Y_ID = c.company_id 
     group by product_id,a.serial_number,a.alias,a.standard,a.uname,a.AccountComment,a.Y_ID,c.name

  select @sql = 'select row_number() over (order by serial_number) as 序号,serial_number as 编号,alias as 通用名,standard as 规格,uname as 单位,isnull(AccountComment,'''+''+''') as 生产厂家'
	select @sql = @sql +', sum(case Y_id when '+ cast(company_id as varchar) +' then quantity else 0 end) ['+Name+']'
	from(select company_id,Name from company where company_id <> 1 and deleted &1 =0)t1
	select @sql =@sql + ' ,sum(quantity) as ''合计''
	from #Products group by serial_number,alias,standard,uname,AccountComment'
   exec (@sql)
end  
drop table #Products
GO
