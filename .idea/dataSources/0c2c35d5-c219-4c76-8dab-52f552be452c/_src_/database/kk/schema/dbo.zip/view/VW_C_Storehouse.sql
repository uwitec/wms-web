




CREATE VIEW dbo.VW_C_Storehouse
AS
SELECT SH.*,
  ISNULL(P.[Serial_number] ,'') AS [Code],
  ISNULL(P.[Name]          ,'') AS [Pname],
  ISNULL(P.[Alias]         ,'') AS [Alias],
  ISNULL(P.[Standard]      ,'') AS [Standard],
  ISNULL(m.id       ,0) AS [Medtype],
  ISNULL(P.[Makearea]      ,'') AS [Makearea],
  ISNULL(P.[comment]       ,'') AS [comment],
  ISNULL(P.[Otcflag]       ,'') AS [Otcflag],
  ISNULL(P.[Validmonth]    ,'') AS [Validmonth],
  ISNULL(P.[Permitcode]    ,'') AS [Permitcode],
  ISNULL(P.[SR2_id]       ,'') AS  [SR2_id],
  ISNULL(Pic.[price1] ,0) AS [price1],
  ISNULL(Pic.[price2] ,0) AS [price2],
  ISNULL(Pic.[price3] ,0) AS [price3],
  ISNULL(Pic.[lowprice] ,0) AS [lowprice],
  ISNULL(Pic.[retailprice] ,0) AS [retailprice],
  ISNULL(SH.[quantity]*Pic.[retailprice],0) AS [RetailTotal],
  ISNULL(C.[Class_ID]      ,'') AS [CclassID],
  ISNULL(C.[Name]          ,'') AS [Cname],
  ISNULL(L.[Loc_name]      ,'') AS [Locname],
  ISNULL(S.[Class_ID]      ,'') AS [SClassID],
  ISNULL(S.[Name]          ,'') AS [Sname],
  isnull(s.[serial_number], '') as [scode],
  ISNULL(P.[Class_ID]      ,'') AS [PClassID],
  ISNULL(P.[Rate2]         ,0)  AS [Rate2],
  ISNULL(P.[Rate3]         ,0)  AS [Rate3],
  ISNULL(P.[Rate4]         ,0)  AS [Rate4],
  ISNULL(U1.[Name]         ,'') AS [Name1],
  ISNULL(U2.[Name]         ,'') AS [Name2],
  ISNULL(U3.[Name]         ,'') AS [Name3],
  ISNULL(U4.[Name]         ,'') AS [Name4],
  ISNULL(M.medtype       ,'') AS [MedName],
  ISNULL(Y.Class_id        ,'') AS YClass_id,
  ISNULL(Y.[name]          ,'') AS Yname,
  ISNULL(Pb.[e_name]       ,'') AS e_name,
  ISNULL(Pb.[C_Name]       ,'') AS C_Name,
  ISNULL(f.AccountComment  ,'') as factory
     
FROM 
  StoreHouse SH
  LEFT JOIN (select * from price where unittype=1)   pic ON SH.[p_id]=pic.[p_id]
  LEFT JOIN Products P  ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN Clients  C  ON SH.[Supplier_ID]=C.[Client_ID]
  LEFT JOIN Storages S  ON SH.[S_ID]=S.[Storage_ID]
  LEFT JOIN Location L  ON SH.[Location_ID]=L.[Loc_ID]
  LEFT JOIN Unit     U1 ON P.[Unit1_ID]=U1.[Unit_ID]
  LEFT JOIN Unit     U2 ON P.[Unit2_ID]=U2.[Unit_ID]
  LEFT JOIN Unit     U3 ON P.[Unit3_ID]=U3.[Unit_ID]
  LEFT JOIN Unit     U4 ON P.[Unit4_ID]=U4.[Unit_ID]
  left   join VW_MedType m on p.product_id = m.product_id
  LEFT JOIN Company  Y  ON Y.company_id=SH.Y_id
  LEFT JOIN vw_productbalance Pb ON Pb.p_id = p.product_id and SH.Y_ID = Pb.Y_id
  left join basefactory f on sh.Factoryid=f.CommID
 /*where pic.unittype=1*/
GO
