




/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_ClientBind]
(
    @bindid		varchar(50),
    @bindpass	varchar(50),
    @weixinno	varchar(50),	
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
select @chvErrMsg=''
 if @weixinno=''
 begin
   select @chvErrMsg='微信号不能为空'
   select @chvErrMsg as outMsg,-1 as reCode
   return -1
end
if @bindpass=''
begin
	select '密钥不正确' as outMsg,-1 as reCode
	return -1
end
declare @id int,@name as varchar(200)
select @id=client_id,@name=name from clients where serial_number=@bindid and wxbindpass<>'' and wxbindpass=@bindpass

if isnull(@id,0)=0
begin
	select '输入的信息有误，请核对后再重新输入' as outMsg,-1 as reCode
	return -1
end

if exists(select 1 from ClientsBind where weixinno=@weixinno)
begin
	select '微信号已经绑定往来单位' as outMsg,-1 as reCode
	return -1
end

insert into ClientsBind(C_ID,WeiXinNo)
values(@id,@weixinno)
update clients set wxbindpass='' where client_id=@id/*绑定后密钥清空*/
select '绑定完成' as outMsg,@id as reCode,@name as name

return 0
GO
