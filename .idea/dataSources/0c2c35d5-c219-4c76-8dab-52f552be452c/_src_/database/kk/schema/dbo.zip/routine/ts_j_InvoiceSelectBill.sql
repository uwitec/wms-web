

CREATE	 PROCEDURE [ts_j_InvoiceSelectBill]
	(
	 @nClientID int=0,
         @nInvoiceType int=0,    /*0销售类，１采购类　２　财务类*/
         @szBillNumber varchar(60) = '',
 	 @begindate datetime,
 	 @enddate datetime,
	 @nJsflag int = 0,  /*1 按单，２按行*/
	 @nY_ID int = 0,  /*当前机构ID*/
	 @nloginEID int = 0 , /*登陆人员Id*/
	 @nSendC_id int = 0 , 
 	 @nRet int output
        )
AS 
/*Params Ini begin*/
if @nClientID is null  SET @nClientID = 0
if @nInvoiceType is null  SET @nInvoiceType = 0
if @szBillNumber is null  SET @szBillNumber = ''
if @nJsflag is null  SET @nJsflag = 0
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/


/*------初始化授权信息*/
declare @Storetable int
create table #storagestable([id] int)
/*------初始化授权信息*/



/*---仓库授权*/
   create table #storageslimt(id int)
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      
      insert into #storageslimt
      select a.billid from  billidx a
           left join salemanagebill   b on a.billid=b.bill_id 
           where a.billtype in (10,11,12,13,16,17,32,112,210,211)  and a.billdate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and b.p_id>0 and a.billstates=0
      union all
      select a.billid from  billidx a 
           left join buymanagebill   b on a.billid=b.bill_id where a.billtype in (20,21,24,25,28,35,122,220,221)  and a.billdate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and b.p_id>0 and a.billstates=0
   end
/*---仓库授权*/

  declare @szBilltype varchar(120), @nIVJsFlag int

  if @szBillNumber = '' set @szBillNumber ='%%' 
  else begin
     set @szBillNumber = '%'+ @szBillNumber + '%'
     set @begindate= '1900-01-01'
     set @Enddate= '2099-12-31'
  end

if @nJsFlag = 2  
begin
  if @nInvoiceType = 0 
    set @szBilltype = '10,11,12,13,32,112,210,211' 
  else     /*销售类*/
    set @szBilltype = '20,21,28,35,122,220,221'  /*采购类*/
  set @nIVJsFlag = 1   
end 
else begin   
  if @nInvoiceType = 0 set @szBilltype = '10,11,12,13,16,17,32,112,210,211' else     /*销售类*/
  if @nInvoiceType = 1 set @szBilltype = '20,21,24,25,28,35,122,220,221' else 
  if @nInvoiceType = 2 set @szBilltype = '15,23,87,88' else  
                       set @szBilltype = '0'  /*处理当参数查询错误时不返回结果,避免出现不可意料的状态*/
  set @nIVJsFlag = 2 
end

  set @nRet = -1
  
  select 
	 bi.billid, 	bi.billdate,	bi.auditdate,	bi.billnumber,	bi.Cname, 
	     isnull(c.name,'') as SendCname,
         bi.BILLSTATES,	bi.Ename,	' ' as billname, 		bi.invoice as orderinvoiceid,
         bi.note,	bi.inputmanname,		bi.auditManName,
 	 bi.ysmoney,	bi.inputman,	bi.auditman,			bi.jsInvoiceTotal as YKTotal,
         bi.guid as billGuid,		bi.billtype as billtype

      /*   case  bi.invoice when 0 then ' ' 	when 1 then '收据' */
/*			  when 2 then '普票' 	when 3 then '增值税票' */
	/*		  when 4 then '其他' */
         /*end as orderinvoice*/
         
      /*   wktotal = case when abs(bi.jsInvoiceTotal) - abs(bi.ysmoney) >= 0 then 0*/
      /*			else abs(bi.ysmoney) - abs(bi.jsInvoiceTotal)*/
      /*             end*/
  
    from vw_x_billidx as bi
      left join clients c on bi.sendC_id = c.client_id 
/*    left join billtypename as bn on bi.billtype = bn.billtype*/
   where bi.c_id = @nClientID and bi.Y_ID = @nY_ID and 
         (@nSendC_id = 0 or bi.sendC_id = @nSendC_id) and
         bi.billtype in (select type from dbo.decodestr(@szBilltype) )
         and bi.billnumber like @szBillNumber
	 and bi.billstates=0
         and bi.billdate >= @begindate and bi.billdate <= @enddate
	 and (abs(bi.ysmoney) - abs(bi.jsInvoiceTotal)) > 0 
	 and bi.billid not in(select distinct billid 
                                from vw_j_invoice 
                                where jsflag = @nIVJsflag and states in (0,1,2) and
                                               invoicetype = @nInvoiceType)
     /*and (@Storetable = 0 or exists(select 1 from #storagestable where id = bi.sin_id) or (bi.sin_id = 0))       */
     and bi.billid not in (select id from #storageslimt)                                   
   order by bi.billdate, bi.billnumber
   
   drop table #storagestable
   drop table #storageslimt		
IF @@ROWCOUNT >0 SET @nRET = 1
RETURN 0
GO
