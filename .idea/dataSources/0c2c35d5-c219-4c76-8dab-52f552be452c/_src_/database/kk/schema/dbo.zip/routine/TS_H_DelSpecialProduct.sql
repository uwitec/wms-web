
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-18*/
/* Description:	删除诊治费用资料*/
/* =============================================*/
CREATE PROCEDURE TS_H_DelSpecialProduct 
	@PID		int
AS
BEGIN
	SET NOCOUNT ON;
	
	if exists(select * from prescriptiondetail where pdt_id = @PID and pdttype = 1)
	begin
		raiserror('商品已被使用，不能删除！', 16, 1)
		return 0
	end

	if exists(select * from doctorgrade where spid = @PID)
	begin
		raiserror('商品已被使用，不能删除！', 16, 1)
		return 0
	end
	
	delete from specialproducts where product_id = @Pid
	return @pid
END
GO
