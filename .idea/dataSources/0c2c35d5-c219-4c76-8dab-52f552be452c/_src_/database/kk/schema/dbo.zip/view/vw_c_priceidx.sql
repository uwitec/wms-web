

CREATE VIEW dbo.vw_c_priceidx
AS
SELECT dbo.PriceIdx.*, ISNULL(dbo.employees.name, '') AS ename, 
      ISNULL(dbo.employees.class_id, '') AS eclass_id, ISNULL(emp.class_id, '') 
      AS inputmanclass_id, ISNULL(emp.name, '') AS inputmanname, ISNULL(empa.name, 
      '') AS auditmanname, ISNULL(empa.class_id, '') AS auditmanclass_id, 
      ISNULL(dep.name, '') AS departmentname, ISNULL(reg.name, '') AS regionname, ISNULL(reg.class_id, '') AS regclass_id, 
      '' AS posname,'' as PosClass_id,
      ISNULL(Y.Class_ID,'') as YClass_id,ISNULL(Y.[name],'') as Yname
FROM dbo.PriceIdx LEFT OUTER JOIN
      /*dbo.Company POS  ON dbo.PriceIdx.posid = POS.Company_id LEFT OUTER JOIN*/
      dbo.employees ON dbo.PriceIdx.e_id = dbo.employees.emp_id LEFT OUTER JOIN
      dbo.employees emp ON dbo.PriceIdx.inputman = emp.emp_id LEFT OUTER JOIN
      dbo.employees empa ON dbo.PriceIdx.auditman = empa.emp_id LEFT OUTER JOIN
      dbo.department dep ON 
      dbo.PriceIdx.department_id = dep.departmentId LEFT OUTER JOIN
      dbo.Region reg ON dbo.PriceIdx.region_id = reg.region_id  LEFT OUTER JOIN
      Company Y     ON dbo.PriceIdx.Y_id=Y.Company_id
GO
