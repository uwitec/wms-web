
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012.8.28*/
/* Description:	获取零售商品价格体系*/
/* =============================================*/
CREATE PROCEDURE [TS_H_GetRetailPrices] 
	@Pid int,
	@Yid int,
	@PosPrice int
AS
BEGIN
	SET NOCOUNT ON;
	declare @count int

	/* 独立物价*/
	if @PosPrice = 0
	begin
		SELECT     p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, lowprice
		FROM         dbo.price
		WHERE     (p_id = @Pid)
	end
	else
	begin
	    select @count = COUNT(*) FROM         dbo.PosPrice where p_id = @Pid and Y_ID = @Yid 
	    if @count > 0 
		SELECT     p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, lowprice
		FROM         dbo.PosPrice where p_id = @Pid and Y_ID = @Yid
		else
			SELECT     p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, lowprice
			FROM         dbo.price
			WHERE     (p_id = @Pid)
	end
END
GO
