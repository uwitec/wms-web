

/*TS_j_QrCustomMapping*/

/*Exec TS_X_LoadCategory;1 0, 492,9, 0*/
/*自定义类别读取关联的基本资料*/
create   PROCEDURE TS_X_LoadCategory
(	
    @baseType	int,
	@CG_ID 		int,
	@class_id   varchar(50),
	@info_ID	int=0,
	@nMode	int=0   /*0　从自定义类别查询, 1 从基本资料查询*/
)
AS
/*Exec TS_X_LoadCategory;1 2, 27, '0901',1, 0*/
declare @colName varchar(20)
declare @szsql varchar(5000)
declare @where varchar(2000)

if @nMode = 0 
begin 
   if @info_ID = 0 
   begin
   select p.CODE, p.NAME, p.STANDARD, p.MODAL, p.MAKEAREA, p.PERMITCODE,
			p.MEDTYPE, p.TRADEMARK, p.ALIAS, p.PACKSTD, p.FACTORY, p.COMMENT,
			p.BULIDNO, p.REGISTERNO,p.PRODUCT_ID 
       from VW_C_Products p
       where p.Product_ID = 0
     return 0 
    end 
   if (@baseType in (-1,0)) 
   begin
     set @colName = '[PComent' + CAST(@info_ID  as varchar) + ']' 
     
     set @szsql = 
     'select p.CODE, p.NAME, p.STANDARD, p.MODAL, p.MAKEAREA, p.PERMITCODE,
			p.MEDTYPE, p.TRADEMARK, p.ALIAS, p.PACKSTD, p.FACTORY, p.COMMENT,
			p.BULIDNO, p.REGISTERNO,p.PRODUCT_ID 
       from VW_C_Products p
       inner join ProductCategory c on p.Product_ID = c.p_id '
     set @where =
       'where c.' + @colName +' = '''+ @class_id+'''' /*CAST(@CG_ID  as varchar)*/ 
       
     set @szsql = @szsql + @where +  ' order by p.Class_ID'
    print @szsql
    exec(@szsql)
   end    
   else if (@baseType = 1) 
   begin      
     set @colName = '[CComent' + CAST(@info_ID  as varchar) + ']'  
     
     set @szsql = 
     'select p.SERIAL_NUMBER, p.NAME, p.ALIAS,  p.RegionName as SZREGION, p.COMMENT,
			p.contact_personal as contact, p.phone_number as PHONE, p.cename, p.client_id 
       from vw_Clients p
       inner join ClientCategory c on p.client_id = c.C_id '
     set @where =
       'where c.' + @colName +' =  '''+ @class_id+'''' /*CAST(@CG_ID  as varchar)*/ 
       
     set @szsql = @szsql + @where +  ' order by p.Class_ID'
    print @szsql
    exec(@szsql)       
                  
   end
   else if (@baseType = 2) 
   begin
   
      set @colName = '[YComent' + CAST(@info_ID  as varchar) + ']' 
     /*print @colName*/
     set @szsql = 
     'select p.serial_number as COMPANY_NO, p.NAME,p.ALIAS, p.MANAGER, p.TEL, p.OPADDRESS, p.company_id 
       from vw_L_Company p
       inner join CompanyCategory c on p.company_id = c.Y_id '
     set @where =
       ' where c.' + @colName +' =  '''+ @class_id+'''' /*CAST(@CG_ID  as varchar)*/ 
       
     set @szsql = @szsql + @where +  ' order by p.Class_ID'
    print @szsql
    exec(@szsql)  
 
   end    
end
/*else if @nMode =1
begin
    if @baseType = 0
    begin
       if @info_ID=0 
       begin
           select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=0 
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id
				   from customCategory a left join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  left join products p on b.baseinfo_id=p.product_id
										  where BaseTypeid=0 and a.deleted=0 and Typeid=0 and b.baseinfo_id=0 
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id
       end
       else
       begin
		   select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=0 
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id 
				   from customCategory a inner join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  inner join products p on b.baseinfo_id=p.product_id
										  where BaseTypeid=0 and a.deleted=0 and Typeid=0 and b.baseinfo_id=@info_ID 
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id
      end
    end     
    else if  @baseType = 1
    begin   
       if @info_ID=0 
       begin
          select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=1 
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id 
				   from customCategory a  left join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  left join clients p on b.baseinfo_id=p.client_id
										  where BaseTypeid=1 and a.deleted=0 and Typeid=0 and b.baseinfo_id=0 
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id    
       end
       else
       begin
		   select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=1 
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id 
				   from customCategory a inner join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  inner join clients p on b.baseinfo_id=p.client_id
										  where BaseTypeid=1 and a.deleted=0 and Typeid=0 and b.baseinfo_id=@info_ID 
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id    
      end      
   end
   else if  @baseType = 2
   begin
       if @info_ID=0 
       begin
          select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=2
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id 
				   from customCategory a  left join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  left join company p on b.baseinfo_id=p.company_id
										  where BaseTypeid=2 and a.deleted=0 and Typeid=0 and b.baseinfo_id=0
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id    
       end
       else
       begin
		   select isnull(r.category_id,0) as id, isnull(q.name,'') as name,isnull(q.class_id,'') as class_id,
				 ISNULL(q.parent_id,0) as parent_id,isnull(q.basetype,0) as basetype,isnull(q.rowindex,0) as rowindex,
				 q.modifydate,isnull(q.deleted,0) as deleted,isnull(q.pinyin,0) as pinyin,
				 isnull(q.Child_Number,0) as Child_Number, isnull(q.Child_Count,0) as Child_Count,
				 isnull(q.Child_Count,0) as Child_Count,isnull(q.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.category_id,0) as CG_ID     
		   from 
		  ( 
		   select a.*,b.bclass_id as bclass_id,b.category_id from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=2
		   ) a
		   left join 
		   (
		   select distinct a.id, left(a.class_id,2)  as class_id,a.class_id as bclass_id,b.category_id 
				   from customCategory a  inner join (select * from customCategoryMapping where deleted=0) b on a.id=b.category_id
										  inner join company p on b.baseinfo_id=p.company_id
										  where BaseTypeid=2 and a.deleted=0 and Typeid=0 and b.baseinfo_id=@info_ID
		   ) b on a.class_id=b.class_id
		  ) r left join customCategory q on r.category_id=q.id    
      end  
  end  
end
*/
return 0
GO
