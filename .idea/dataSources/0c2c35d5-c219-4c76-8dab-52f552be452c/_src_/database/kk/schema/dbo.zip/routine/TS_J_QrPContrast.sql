
/* 功能：商品选择对比分析
   zjl 2013-06-27
  
*/

CREATE PROCEDURE TS_J_QrPContrast
( 
	@p_id       int,        /*商品*/
	@PreBegindate datetime,   /*上期开始时间*/
	@PreEnddate   datetime,   /*结束时间*/
	@CurBegindate datetime,   /*开始时间*/
	@CurEnddate   datetime    /*结束时间	*/
)

AS
               
/*创建返回信息表*/
/*计算返回值			      */
if OBJECT_ID('tempdb..#qrPContrast' ) is not null 
  drop table #qrPContrast
create table #qrPContrast
            (                                          
			   p_id	int,						/* 商品*/
			   CurQty NUMERIC(25,8),			        /* 本期数量*/
			   PreQty NUMERIC(25,8),					/*	上期数量*/
			   UpQty  NUMERIC(25,8),					/*	数量增长*/
			   UPQtyRate NUMERIC(25,8),					/*	数量增长率*/
			   CurCosttotal NUMERIC(25,8),			    /*  本期成本金额 */
			   CurTotal  NUMERIC(25,8),					/*	本期销售金额			   */
			   PreTotal  NUMERIC(25,8),					/*	上期销售金额*/
			   PreCosttotal NUMERIC(25,8),			    /*  上期成本金额*/
			   UpTotal	 NUMERIC(25,8),					/*	销售金额增长			    */
			   UpTotalRate NUMERIC(25,8),				/*	销售金额增长率*/
			   PreGeust int,					/*	上期来客数*/
			   CurGeust int,					/*	本期来客数*/
			   UpGeust  int,					/*	来客数增长*/
			   UpGeustRate NUMERIC(25,8),				/*	来客数增长率*/
			   PreProfit   NUMERIC(25,8),				/*	上期毛利*/
			   CurProfit   NUMERIC(25,8),				/*	本期毛利*/
			   UpProfit    NUMERIC(25,8),	 			/*	毛利增长*/
			   UpProfitRate NUMERIC(25,8),				/*	毛利增长率*/
			   PreGLQty 	NUMERIC(25,8),				/*	上期联动数量*/
			   CurGLQty     NUMERIC(25,8),				/*	本期联动数量*/
			   UpGLQty      NUMERIC(25,8),				/*	联动数量增长*/
		       UpGLQtyRate  NUMERIC(25,8),				/*	联动数量增长率*/
			   PreGLTotal   NUMERIC(25,8),				/*	上期联动金额*/
			   CurGlTotal   NUMERIC(25,8),				/*	本期联动金额*/
			   UpGLTotal    NUMERIC(25,8),				/*	联动金额数量增长*/
			   UpGLTotalRate NUMERIC(25,8), 			/*	联动金额增长率*/
			   CurGLCosttotal NUMERIC(25,8),			/*  本期关联成本金额*/
			   PreGLCosttotal NUMERIC(25,8),			/*  上期关联成本金额*/
			   PreGLProfit   NUMERIC(25,8),				/*	上期联动毛利*/
			   CurGLProfit	 NUMERIC(25,8),  			/*	本期联动毛利*/
			   UpGLProfit    NUMERIC(25,8),				/*	联动毛利增长			  */
			   UpGLProfitRate NUMERIC(25,8)				/*	联动毛利增长率*/
				)
/*初始化表*/
  insert into #qrPContrast(p_id) 				
       select product_id 
        from products where child_number = 0 and deleted <> 1 and class_id <> '000000' and product_id = @p_id 
        order by class_id, RowIndex                      
                  								
/*计算本期数量、本期金额、成本金额*/
    update  q1 set curQty  = t1.CurQty, curTotal = t1.curTotal, CurCosttotal = t1.CurCostTotal
      from  #qrPContrast q1,    
    (select mx.p_id, sum(Case when bi.billtype in(11, 13) then -mx.quantity  else mx.quantity end) as curQty,
				    sum(Case when bi.billtype in(11, 13) then -totalmoney else totalmoney end) as CurTotal,
				    sum(Case when bi.billtype in(11, 13) then -mx.quantity*mx.costprice else mx.Quantity*mx.costprice end) as CurCostTotal    		         				   				            		         
      from salemanagebill mx
      inner join billidx bi on mx.bill_id = bi.billid
      where (mx.p_id = @p_id) and
            billdate between @CurBegindate and  @CurEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0 
      group by mx.p_id) t1
      where q1.p_id = t1.p_id                                   

/*计算本期来客数 此处需求文档不正确，应为购买次数，来客数应是针对整单*/
   update  q1 set CurGeust  = t1.CurGeust
      from  #qrPContrast q1,    
    (select mx.p_id, COUNT(mx.bill_id) as  curGeust  		         
      from salemanagebill mx
      inner join billidx bi on mx.bill_id = bi.billid
      where (mx.p_id = @p_id) and
            bi.billdate between @CurBegindate and  @CurEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0
      group by mx.p_id) t1
      where q1.p_id = t1.p_id 

/*取得联动商品表*/
      if OBJECT_ID('tempdb..#QRglProducts') is not null
        drop table #QRglProducts 
              
	   select g2.P_id as p_id, g3.P_id as glp_id into #QRglProducts
		 from
		(select  g1.GLName, g1.P_id from GL_Products g1
		where g1.p_id = @p_id) g2
		left join  GL_Products g3 on g2.glname = g3.glname  and g2.P_id <> g3.P_id
		where g3.p_id is not null
		order by g2.P_id 
												
/*计算本期联动数量、金额、成本*/
   update  q1 set CurGLQty  = t1.Qty, CurGlTotal = t1.Total, CurGLCosttotal = t1.CostTotal
      from  #qrPContrast q1,      
    (select 
           p.p_id, sum(Case when bi.billtype in(11, 13) then -mx.quantity  else mx.quantity end) as Qty,				    
				   sum(Case when bi.billtype in(11, 13) then -mx.totalmoney else mx.totalmoney end) as Total,
				   sum(Case when bi.billtype in(11, 13) then -mx.quantity*mx.costprice else mx.Quantity*mx.costprice end) as CostTotal    		         				   				         
       from #QRglProducts p
       left join salemanagebill mx  on p.glp_id = mx.p_id
       inner join billidx bi on mx.bill_id = bi.billid
      where bi.billdate between @CurBegindate and  @CurEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0
      group by p.p_id) t1              
                  
/*计算上期数量、上期金额、上期成本金额*/
 update  q1 set PreQty  = t1.PreQty, PreTotal = t1.PreTotal, PreCosttotal = t1.PreCostTotal
      from  #qrPContrast q1,    
    (select mx.p_id, sum(Case when bi.billtype in(11, 13) then -mx.quantity  else mx.quantity end) as PreQty,
				    sum(Case when bi.billtype in(11, 13) then -totalmoney else totalmoney end) as PreTotal,
				    sum(Case when bi.billtype in(11, 13) then -mx.quantity*mx.costprice else mx.Quantity*mx.costprice end) as PreCostTotal    		         				   				            		         
      from salemanagebill mx
      inner join billidx bi on mx.bill_id = bi.billid
      where (mx.p_id = @p_id) and
            billdate between @PreBegindate and  @PreEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0 
      group by mx.p_id) t1
      where q1.p_id = t1.p_id   

/*计算上期来客数*/
 update  q1 set PreGeust  = t1.PreGeust
      from  #qrPContrast q1,    
    (select mx.p_id, COUNT(mx.bill_id) as  PreGeust  		         
      from salemanagebill mx
      inner join billidx bi on mx.bill_id = bi.billid
      where (mx.p_id = @p_id) and
            bi.billdate between @PreBegindate and  @PreEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0
      group by mx.p_id) t1
      where q1.p_id = t1.p_id 

/*计算上期联动数量、金额*/
 update  q1 set PreGLQty  = t1.Qty, PreGlTotal = t1.Total, preGLCosttotal = t1.CostTotal
      from  #qrPContrast q1,      
    (select 
           p.p_id, sum(Case when bi.billtype in(11, 13) then -mx.quantity  else mx.quantity end) as Qty,				    
				   sum(Case when bi.billtype in(11, 13) then -mx.totalmoney else mx.totalmoney end) as Total,
				   sum(Case when bi.billtype in(11, 13) then -mx.quantity*mx.costprice else mx.Quantity*mx.costprice end) as CostTotal    		         				   				         
       from #QRglProducts p
       left join salemanagebill mx  on p.glp_id = mx.p_id
       inner join billidx bi on mx.bill_id = bi.billid
      where bi.billdate between @PreBegindate and  @PreEnddate and bi.billtype in (10, 11, 12, 13) and
            mx.AOID = 0 and mx.p_id > 0
      group by p.p_id) t1
      

/*删除所有字段为null的记录*/
  delete  #qrPContrast where 							
							 CurQty is null and		
							 PreQty  is null and
							 CurCosttotal  is null and	
							 CurTotal   is null and		
							 PreTotal   is null and		
							 PreCosttotal  is null and								
							 PreGeust  is null and		
							 CurGeust  is null and									 							 							 
							 PreGLQty 	 is null and	
							 CurGLQty      is null and								
							 PreGLTotal    is null and	
							 CurGlTotal    is null and								
							 CurGLCosttotal  is null and
							 PreGLCosttotal  is null							 			

/*处理Null*/
   update #qrPContrast set	CurQty	      =0 where			CurQty is null		   
   update #qrPContrast set	PreQty		  =0 where			PreQty  is null
   update #qrPContrast set	CurCosttotal  =0 where			CurCosttotal  is null 
   update #qrPContrast set 	CurTotal  	  =0 where			CurTotal   is null 		
   update #qrPContrast set	PreTotal	  =0 where			PreTotal   is null 
   update #qrPContrast set	PreCosttotal  =0 where			PreCosttotal  is null 							
   update #qrPContrast set	PreGeust	  =0 where			PreGeust  is null		
   update #qrPContrast set	CurGeust	  =0 where			CurGeust  is null
   update #qrPContrast set	PreGLQty	  =0 where			PreGLQty 	 is null
   update #qrPContrast set	CurGLQty	  =0 where			CurGLQty      is null
   update #qrPContrast set	PreGLTotal	  =0 where			PreGLTotal    is null
   update #qrPContrast set	CurGlTotal	  =0 where			CurGlTotal    is null
   update #qrPContrast set	CurGLCosttotal=0 where 			CurGLCosttotal  is null
   update #qrPContrast set	PreGLCosttotal=0 where			PreGLCosttotal  is null							 			


/*计算     */
    update #qrPContrast set CurProfit = CurTotal-CurCosttotal,				/*本期毛利*/
							PreProfit = PreTotal-PreCosttotal,				/*上期毛利*/
							UpQty = CurQty-PreQty,							/*数量增长			*/
						    UpTotal = CurTotal-PreTotal,					/*销售金额增长						    */
							UpGeust = CurGeust-PreGeust, 					/*来客数增长							*/
							UpProfit = (CurTotal-CurCosttotal)-(PreTotal-PreCosttotal),			/*毛利增长                         */
							UpGLQty = CurGLQty-PreGLQty,										/*联动数量增长							*/
							UpGLTotal = CurGlTotal-PreGLTotal,									/*联动金额增长								*/
							PreGLProfit = PreGLTotal - PreGLCosttotal,		   					/*上期联动毛利*/
							CurGLprofit = CurGlTotal - CurGLCosttotal,							/*本期联动毛利						*/
							UpGLProfit = (CurGlTotal - CurGLCosttotal) - (PreGLTotal - PreGLCosttotal) 	/*联动毛利增长							*/
														
	update #qrPContrast set UPQtyRate = UPQty/PreQty*100 where PreQty <> 0						/*数量增长率*/
    update #qrPContrast set UpTotalRate = UpTotal/PreTotal*100 where PreTotal <> 0				/*销售金额增长率*/
	update #qrPContrast set UpGeustRate = UpGeust/PreGeust*100 where PreGeust <> 0				/*来客数增长率*/
	update #qrPContrast set UpProfitRate = UpProfit/PreProfit*100 where PreProfit <> 0			/*毛利增长率*/
	update #qrPContrast set UpGLQtyRate = UpGLQty/PreGLQty*100 where PreGLQty <> 0				/*联动数量增长率*/
	update #qrPContrast set UpGLTotalRate = UpGLTotal/PreGLTotal*100 where PreGLTotal <> 0		/*联动金额增长率*/
	update #qrPContrast set UpGLProfitRate = UpProfit/PreProfit*100 where PreProfit <> 0		/*联动毛利增长率  */

/*返回查询结果*/
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int      
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'

	select 
			p_id,			
			dbo.DecimalQrValue(@nSL,CurQty) CurQty,		
			dbo.DecimalQrValue(@nSL,PreQty) PreQty,		
			dbo.DecimalQrValue(@nSL,UpQty) UpQty,		
			dbo.DecimalQrValue(@nOther,UPQtyRate) UPQtyRate,		
			dbo.DecimalQrValue(@nTotal,CurCosttotal) CurCosttotal,	
			dbo.DecimalQrValue(@nTotal,CurTotal) CurTotal,		
			dbo.DecimalQrValue(@nTotal,PreTotal) PreTotal,		
			dbo.DecimalQrValue(@nTotal,PreCosttotal) PreCosttotal,	
			dbo.DecimalQrValue(@nTotal,UpTotal) UpTotal, 		
			dbo.DecimalQrValue(@nOther,UpTotalRate) UpTotalRate,	
			PreGeust,		
			CurGeust,		
			UpGeust,		
			dbo.DecimalQrValue(@nOther,UpGeustRate) UpGeustRate,	
			dbo.DecimalQrValue(@nTotal,PreProfit) PreProfit,	
			dbo.DecimalQrValue(@nTotal,CurProfit) CurProfit,	
			dbo.DecimalQrValue(@nTotal,UpProfit) UpProfit,	
			dbo.DecimalQrValue(@nOther,UpProfitRate) UpProfitRate,	
			dbo.DecimalQrValue(@nSL,PreGLQty) PreGLQty,	
			dbo.DecimalQrValue(@nSL,CurGLQty) CurGLQty,	
			dbo.DecimalQrValue(@nSL,UpGLQty) UpGLQty,	
			dbo.DecimalQrValue(@nOther,UpGLQtyRate) UpGLQtyRate,	
			dbo.DecimalQrValue(@nTotal,PreGLTotal) PreGLTotal,	
			dbo.DecimalQrValue(@nTotal,CurGlTotal) CurGlTotal,	
			dbo.DecimalQrValue(@nTotal,UpGLTotal) UpGLTotal,	
			dbo.DecimalQrValue(@nOther,UpGLTotalRate) UpGLTotalRate, 
			dbo.DecimalQrValue(@nTotal,CurGLCosttotal) CurGLCosttotal,
			dbo.DecimalQrValue(@nTotal,PreGLCosttotal) PreGLCosttotal,
			dbo.DecimalQrValue(@nTotal,PreGLProfit) PreGLProfit,	
			dbo.DecimalQrValue(@nTotal,CurGLProfit) CurGLProfit, 
			dbo.DecimalQrValue(@nTotal,UpGLProfit) UpGLProfit,	
			dbo.DecimalQrValue(@nOther,UpGLProfitRate) UpGLProfitRate
	from #qrPContrast
	
	Return 0
GO
