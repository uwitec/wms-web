
Create  procedure Ts_X_CheckDate 
  ( @nmode  int = 0,             /*检查类型 ，现在0 表示检查抵现日期是否满足*/
    @vipcardID int = 0,          /*会员卡*/
    @nRET     int output
  )  

AS	

  set @nRET = 0 
  
  DECLARE @DTYPR INT  /*表示设置的日期类型*/
  DECLARE @DdyStr VARCHAR(200)  /*设置的日期字段*/
  DECLARE @week_day VARCHAR(200)   /*星期*/
  DECLARE @d_day VARCHAR(200)   /*日期*/
  DECLARE @TimeLimt int       /*时间限制*/
  DECLARE @dNow datetime      /*当前时间*/
  DECLARE @dBegin datetime      /*当前时间*/
  DECLARE @dEnd datetime      /*当前时间*/
  
 select @DTYPR = daymode,@DdyStr = dmstr,@dBegin = cast(dxBegintime as datetime),@dEnd =CAST(dxEndtime as datetime),
		@TimeLimt = e.islimitDate from VIPCard v
			left join VipCardTypeExtend e on v.CT_ID = e.bill_id where VIPCardID = @vipcardID
  
 if @DTYPR is null set @DTYPR = -1
 if @DdyStr is null set @DdyStr = ''
 if @TimeLimt is null set @TimeLimt = 0
 if @dBegin is null set @dBegin = ''
 if @dEnd is null set @dEnd = ''
 
 if @DTYPR = 0   /*表示存储的星期*/
 begin
   select  @week_day=datename(weekday,GETDATE())             /*星期X  */
   if CHARINDEX(@week_day,@DdyStr) >0
   begin
     if @TimeLimt = 0
       set @nRET = 1
     else
     begin  
		 select @dNow = CAST( convert(varchar(60),GETDATE(),108) as datetime)
		 if @dNow between @dBegin and @dEnd	
			set @nRET = 1 
	 end
   end 
 end
 else if @DTYPR = 1  /*表示存储的日历*/
 begin
   select @d_day = datename(DAY,GETDATE())             /*日期  */
   if CHARINDEX(','+@d_day+',',','+@DdyStr+',') >0
   begin
     if @TimeLimt = 0
       set @nRET = 1
     else
     begin
		 select @dNow = CAST( convert(varchar(60),GETDATE(),108) as datetime)
		 if @dNow between @dBegin and @dEnd	
			set @nRET = 1  
	end  
   end
 end 

  return @nRET
GO
