


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
得到一个基本信息的一个时间段的余额
@cMode 方式 A 科目 P 商品 E 职员 C 客户 S 仓库 L 货位
@lMode 备用方式 
@A_ID  科目的ID号
@P_ID  商品的ID号
@C_ID  单位的ID号
@E_ID  职员的ID号
@S_ID  仓库的ID号
@L_ID  货位的ID号
@CurDate   统计的时间段
@dCurQty   返回的数量
@dCurTotal 返回的金额
********************************************/
CREATE PROCEDURE TS_X_GetOneBaseCurQtyTotal
( @cMode VARCHAR(1),
  @lMode INT=0,
  @A_ID  INT=0,
  @P_ID  INT=0,
  @C_ID  INT=0,
  @E_ID  INT=0,
  @S_ID  INT=0,
  @L_ID  INT=0,
  @CurDate   DATETIME,
  @szYClass_id  varchar(20)='',
  @dCurQty   NUMERIC(25,8)=0 OUTPUT, 
  @dCurTotal NUMERIC(25,8)=0 OUTPUT
)
/*with encryption*/
AS
/*Params Ini begin*/
if @lMode is null  SET @lMode = 0
if @A_ID is null  SET @A_ID = 0
if @P_ID is null  SET @P_ID = 0
if @C_ID is null  SET @C_ID = 0
if @E_ID is null  SET @E_ID = 0
if @S_ID is null  SET @S_ID = 0
if @L_ID is null  SET @L_ID = 0
if @szYClass_id is null  SET @szYClass_id = ''
if @dCurQty is null  SET @dCurQty = 0 
if @dCurTotal is null  SET @dCurTotal = 0 
/*Params Ini end*/

  SET NOCOUNT ON
  DECLARE @SQLScript  VARCHAR(500)
  DECLARE @szAR_ID    VARCHAR(30)
  DECLARE @szAP_ID    VARCHAR(30)
  DECLARE @dTempQty   NUMERIC(25,8)
  DECLARE @dTempTotal NUMERIC(25,8)
/*应收应付科目ID号*/
  DECLARE @AR_ID      INT
  DECLARE @AP_ID      INT
  DECLARE @EXPENSE_ID VARCHAR(30)

  IF @szYClass_id='' select @szYClass_id='%%' else select @szYClass_id=@szYClass_id+'%'

  SELECT  @szAR_ID='000001000005', @szAP_ID='000002000001', 
    @AR_ID=9, @AP_ID=15, @EXPENSE_ID='000004000003'
  
  
  IF  @cMode='A' GOTO GetAccount
  IF  @cMode='P' GOTO GetProducts
  IF  @cMode='C' GOTO GetClients
  IF  @cMode='E' GOTO GetEmployees
  IF  @cMode='S' GOTO GetStorages
  IF  @cMode='L' GOTO GetLocation

GetAccount:
/*计算一个时间点的科目金额，用期初和科目明细库计算*/
  SELECT  @dCurQty=ISNULL(SUM([ini_total]), 0) FROM Accountbalance A,company C 
          WHERE A.Y_id=C.company_id and [A_ID]=@A_ID and C.class_id like @szYClass_id 
  SELECT  @dTempQty=ISNULL(SUM([jdmoney]), 0) FROM Accountdetail ad, BillIDX bi,company Y
  WHERE ad.[BillID]=bi.[BillID] and ad.Y_id=Y.company_id and bi.[Billdate]<=@CurDate 
  and ad.[A_ID]=@A_ID and ad.[C_ID]=@C_ID and Y.class_id like @szYClass_id
  SELECT  @dCurTotal=@dCurQty
  GOTO Succee

GetProducts:
/*计算一个时间点的库存数量和金额，用期初库和商品明细库计算*/
/*所有的仓库*/
  IF  @S_ID=0
  BEGIN
    SELECT  @dCurQty=ISNULL(SUM([quantity]), 0), @dCurTotal=ISNULL(SUM([costtotal]), 0) 
    FROM storehouseini st,company Y  WHERE [P_ID]=@P_ID and st.Y_id=Y.company_id and Y.class_id like @szYClass_id
    
    SELECT  @dTempQty=ISNULL(SUM(pd.[quantity]), 0), @dTempTotal=ISNULL(SUM(pd.[costtotal]), 0)
    FROM productdetail pd, BillIDX bi,company Y
    WHERE pd.[P_ID]=@P_ID and pd.[BillID]=bi.[BillID] and pd.Y_id=Y.company_id and Y.class_id like @szYClass_id and pd.storetype=0
    and bi.[Billdate]<=@CurDate

    SELECT  @dCurQty=@dCurQty+@dTempQty, @dCurTotal=@dCurTotal+@dTempTotal
  END
/*单一的仓库*/
  ELSE
  BEGIN
    SELECT  @dCurQty=ISNULL(SUM([quantity]), 0), @dCurTotal=ISNULL(SUM([costtotal]), 0) 
    FROM storehouseini st,company Y  WHERE [P_ID]=@P_ID and [S_ID]=@S_ID and st.Y_id=Y.company_id and Y.class_id like @szYClass_id
    
    SELECT  @dTempQty=ISNULL(SUM(pd.[quantity]), 0), @dTempTotal=ISNULL(SUM(pd.[costtotal]), 0)
    FROM productdetail pd, BillIDX bi,company Y
    WHERE pd.[P_ID]=@P_ID and pd.[S_ID]=@S_ID and pd.[BillID]=bi.[BillID] and pd.Y_id=Y.company_id and Y.class_id like @szYClass_id and pd.storetype=0
    and bi.[Billdate]<=@CurDate

    SELECT  @dCurQty=@dCurQty+@dTempQty, @dCurTotal=@dCurTotal+@dTempTotal
  END

  GOTO Succee

GetClients:

/*计算一个时间点的住来单位应收应付，用期初库和科目明细库计算*/
  SELECT  @dCurQty=ISNULL(SUM([artotal_ini]), 0), @dCurTotal=ISNULL(SUM([aptotal_ini]), 0) 
  FROM Clientsbalance c,company Y WHERE [C_ID]=@C_ID and c.Y_id=Y.company_id and Y.class_id like @szYClass_id
  
  SELECT  @dTempQty=ISNULL(SUM(ad.[JdMoney]), 0) FROM Accountdetail ad, BillIDX bi,company Y
  WHERE ad.[BillID]=bi.[BillID] and ad.Y_id=Y.company_id and Y.class_id like @szYClass_id and bi.[Billdate]<=@CurDate and ad.[C_ID]=@C_ID
  and ad.[A_ID]=@AR_ID
  SELECT  @dTempTotal=ISNULL(SUM(ad.[JdMoney]), 0) FROM Accountdetail ad, BillIDX bi,company Y
  WHERE ad.[BillID]=bi.[BillID] and ad.Y_id=Y.company_id and Y.class_id like @szYClass_id and bi.[Billdate]<=@CurDate and ad.[C_ID]=@C_ID
  and ad.[A_ID]=@AP_ID

  SELECT  @dCurQty=@dCurQty+@dTempQty, @dCurTotal=@dCurTotal+@dTempTotal

  GOTO Succee

GetEmployees:

/*计算一个时间点的职员费用，用期初库和科目明细库计算*/
  SELECT  @dCurQty=ISNULL(SUM(ad.[JdMoney]), 0) FROM Accountdetail ad, BillIDX bi,company Y, 
  (SELECT  [Account_ID] FROM Account WHERE LEFT([Class_ID], LEN(@EXPENSE_ID))=@EXPENSE_ID
  and [DELETEd]<>1 and [Child_Number]=0) a
  WHERE ad.[BillID]=bi.[BillID] and bi.[Billdate]<=@CurDate and bi.[E_ID]=@E_ID
  and a.[Account_ID]=ad.[A_ID] and ad.Y_id=Y.company_id and Y.class_id like @szYClass_id

  SELECT  @dCurTotal=@dCurQty

  GOTO Succee

GetStorages:

/*计算一个时间点的库存数量和金额，用期初库和商品明细库计算*/
  SELECT  @dCurQty=ISNULL(SUM([quantity]), 0), @dCurTotal=ISNULL(SUM([costtotal]), 0) 
  FROM storehouseini st,company Y WHERE [S_ID]=@S_ID and st.Y_id=Y.company_id and Y.class_id like @szYClass_id
  
  SELECT  @dTempQty=ISNULL(SUM(pd.[quantity]), 0), @dTempTotal=ISNULL(SUM(pd.[costtotal]), 0)
  FROM productdetail pd, BillIDX bi,company Y
  WHERE pd.[S_ID]=@S_ID and pd.[BillID]=bi.[BillID] and pd.Y_id=Y.company_id and Y.class_id like @szYClass_id and bi.[Billdate]<=@CurDate and pd.storetype=0

  SELECT  @dCurQty=@dCurQty+@dTempQty, @dCurTotal=@dCurTotal+@dTempTotal
  GOTO Succee

GetLocation:

/*计算一个时间点的货位数量和金额，用期初库和商品明细库计算*/
  SELECT  @dCurQty=ISNULL(SUM([quantity]), 0), @dCurTotal=ISNULL(SUM([costtotal]), 0) 
  FROM storehouseini st,company Y WHERE [Location_ID]=@L_ID and st.Y_id=Y.company_id and Y.class_id like @szYClass_id
  
  SELECT  @dTempQty=ISNULL(SUM(pd.[quantity]), 0), @dTempTotal=ISNULL(SUM(pd.[costtotal]), 0)
  FROM productdetail pd, BillIDX bi,company Y
  WHERE pd.[Location_ID]=@L_ID and pd.[BillID]=bi.[BillID] and pd.Y_id=Y.company_id and Y.class_id like @szYClass_id and bi.[Billdate]<=@CurDate and pd.storetype=0

  SELECT  @dCurQty=@dCurQty+@dTempQty, @dCurTotal=@dCurTotal+@dTempTotal
  GOTO Succee

Succee:
  RETURN  0
GO
