







CREATE	 PROCEDURE ts_L_GoodsCheckBill 
(	@Bille	int,
	@nsid	int,
	@nLid	int)
AS

declare @nret	int,
	@szPeriod varchar(30),
	@lPeriod int,
	@lBillRet int,
	@toDay varchar(12),
	@billtype int,
	@lTmp int,
/*	@idxQty NUMERIC(25,8),*/
	@idxTotal NUMERIC(25,8)

declare @nC_id int,
	@nL_id int,
	@ValidDate datetime,
	@MakeDate datetime,
	@CostPrice NUMERIC(25,8),
	@TotalMoney NUMERIC(25,8),
	@batchno varchar(30),
	@lP_id int,
	@ls_id int,
	@RealQty NUMERIC(25,8),
	@nTableTag int,
	@commissionFlag tinyint,
	@quantity	NUMERIC(25,8),
	@LoseQty	NUMERIC(25,8),
	@LoseTotal      NUMERIC(25,8),
        @Y_ID		int,
	@CURY_ID	int
	
declare @szBillSN varchar(200)


if not exists(select ss_id from autoGoodsCheck where ss_id=@nsid) return -1


exec ts_GetSysValue 'AccountPeriod',@szPeriod output
set @lperiod=Cast(@szPeriod as int)
set @nTableTag=6
set @billtype=50
set @toDay=convert(varchar(10),GetDate(),20)

select @idxTotal=sum((s.discountPrice-s.quantity)*s.costPrice)
from autogoodsCheck s
where s.ss_id=@nsid and s.DiscountPrice<>s.Quantity

select @Y_ID=s.Y_ID,@CURY_ID=s.Y_ID
from autogoodsCheck s
where s.ss_id=@nsid and s.DiscountPrice<>s.Quantity

if not exists(select s.p_id from autogoodsCheck s where s.ss_id=@nsid and s.DiscountPrice<>s.Quantity)
begin
	raiserror('没有附合条件的记录，或没有盘点数量没有发生变化!!',16,1)
	return -1 
end

exec TS_H_CreateBillSN @Billtype, 1, null, @Bille, @Bille, @szBillSN output

exec Ts_b_InsertBillIndexDraft  @nret output,
				0,@ntabletag,0,@today,@szBillSN,
				@Billtype,0,0,@Bille,@nsid,
				0,@bille,@Bille,@idxtotal,0,
				0,0,@lperiod,'2',0,
				0,@Y_ID,0,0,0,
				0,'0','【自动盘点】','',0,
				'',0,0,0,0,
				0,0,0,0,0,
				0,'1111111',@CURY_ID
if @nret<>0 
begin
	declare Limit_cur cursor for 
		select s.p_id,s.ss_id,s.discountPrice,s.Supplier_id,
		s.location_id,s.validDate,s.MakeDate,s.costPrice,s.totalMoney,s.batchno,s.Commissionflag,s.Quantity
		from autogoodsCheck s
		where s.ss_id=@nsid and s.DiscountPrice<>s.Quantity
	
	open Limit_cur
	fetch next from Limit_cur 
		into @lp_id,@lS_id,@RealQty,@nC_id,@nL_id,@ValidDate,@MakeDate,
			@CostPrice,@TotalMoney,@batchno,@commissionFlag,@quantity
	
	while @@fetch_status=0
	begin
		set @LoseQty=@realQty-@quantity
		set @loseTotal=@loseQty*@CostPrice
		exec Ts_b_InsertBillDetailDraft @lBillret output,
						@nTableTag,
						0,
						@nret,
						0,
						@lp_id,
						@batchno,
						@realQty,
						@costprice,
						@costPrice,@totalMoney,1,
						@quantity,
						@loseQty,
						@quantity,@loseTotal,@LoseQty,0,0,
						@makedate,
						@validdate,
						'合格',
						0,
						@nsid,
						0,0,
						@nl_id,
						@nC_id,@commissionFlag,'',0,0,0,0,0,0,0,0,0,0
		if @lBillret=-1 
		begin
			exec Ts_b_DeleteBillDraft @ltmp output,50,@nret
			return -1 
		end
		fetch next from Limit_cur 
			into @lp_id,@lS_id,@RealQty,@nC_id,@nL_id,@ValidDate,@MakeDate,
				@CostPrice,@TotalMoney,@batchno,@commissionFlag,@quantity
	end
	
	close Limit_cur
	deallocate Limit_cur
end
  
return @nret
GO
