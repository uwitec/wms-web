
/**********生成捡货单************/
/****add by luowei**2012-12-11**********/
/******************************/

create procedure TS_L_CreateJHBill
(
  @billid int
)
as
begin
  SET NOCOUNT ON;
  
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 
    begin tran CreateJHBill
  
  if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1')
  begin
    declare @s_count int  /*单据中的仓库数目*/
    declare @s_id int    /*仓库ID*/
    declare @qty NUMERIC(25,8)  /*商品数量*/
    declare @newbill int  /*捡货单主表id*/
    declare @billnumber varchar(50) /*-销售出库单编号*/
    declare @JHbillnumber VARCHAR(50)   /*-捡货单编号 */
    declare @nBillCount int   /*--当天捡货单数目，用于生成捡货单编号*/
    declare @billdate datetime  /*-单据日期*/
    declare @nError int
    set @s_count = 0
    set @s_id = 0
    set @qty = 0
    set @nBillCount = 0
    set @JHbillnumber = ''
    set @nError = 0
    
    select @billnumber = billnumber from billdraftidx where billid = @billid  /*获取原单编号*/
    select @billdate = billdate from billdraftidx where billid = @billid
    select @nBillCount = isnull(COUNT(billid),0) from billdraftidx   /*获取捡货单单据数目*/
    where billdate = @billdate and billtype = 254

	select @s_count = COUNT(ss_id) from  /*获取仓库数目 */
	(
		select  ss_id from salemanageBilldrf where bill_id = @billid group by ss_id
	) s
	
	/*---------更新销售出库单据id 到对应的同价调拨单的order_id 中，以便捡货单退回后捡货单重新关联上同价调拨单 add by luowei 2012-12-19*/
	/*update billdraftidx set order_id = @billid from salemanagebilldrf mx*/
	/*where billid = CAST(mx.invoiceno as int) and billtype = 44 */
	/*and exists(select 1 from billdraftidx i where mx.bill_id = i.billid and billtype = 10) */
    
	/* 判断是否启用拆分销售出库单*/
	DECLARE @nSplitSaleBill int
	set @nSplitSaleBill = 0
	SELECT @nSplitSaleBill = sysvalue FROM sysconfigtmp WHERE sysname = 'SplitSaleBillByStorage'

	/* 拆分销售出库单之后不再拆分拣货单*/
	IF @nSplitSaleBill = 1
	BEGIN
		set @nBillCount=@nBillCount+1
		set @JHbillnumber=''
		exec TS_H_CreateBillSN 254, 1, null, 0, 0, @JHbillnumber output
		/*set @JHbillnumber='JHD'+'-'+left(CONVERT(varchar,@billdate,21),10)+'-'+CAST(@nBillCount as varchar)*/
		INSERT INTO billdraftidx
		(
			billdate ,billnumber,GUID,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
			ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
			region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,WHOLEQTY,PARTQTY,RetailDate
		)
		Select billdate,@JHbillnumber,NEWID(),254,0, CASE billtype WHEN 10 THEN c_id ELSE 0 END,e_id,sout_id,sin_id,auditman,inputman,
		0,0,0,quantity,0,period,billstates,@billid,0,
		0,auditdate,skdate,jsflag,note,'',0,0,cast(GUID as varchar(50)),0,0,GatheringMan,0,2,Y_ID, /*-使用vipcardid 存储捡货单状态 2表示成功,1表示捡货单退回*/
		'','','',sendC_id,0,0,GETDATE() 
		from BillDraftidx where billid = @billid
		
		/*--判断拣货单主表是否生成成功 add by luowei 2014-01-17*/
	    if @@ROWCOUNT<= 0 
		goto error
		
		SET @newbill = @@IDENTITY
		
		update BillDraftidx set RetailDate = GETDATE() where billid = @newbill
		
		INSERT INTO salemanageBilldrf
		(
		bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,
		discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,
		retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,
		location_id  ,location_id2, supplier_id  ,commissionflag  ,comment  ,unitid	,
		taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID, jsprice,
		AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID,
		invoice,INVOICENO, Y_ID, InStoreTime, cxType, comment2, scomment, batchprice, BatchBarCode,
			CxGuid, Conclusion
		)
		select @newbill,p_id,batchno,quantity, costprice,  saleprice ,discount ,
			discountprice ,totalmoney  ,taxprice   ,taxtotal  , taxmoney , retailprice ,
			retailtotal, makedate  , validdate , price_id ,ss_id  ,sd_id , smb_id,  /*-orderID 存储原单明细ID*/
			location_id, location_id2, supplier_id, commissionflag, comment, unitid,
			taxrate, qualitystatus, total, iotag , InvoiceTotal, orgbillid,jsprice,
			0,0,0,PriceType,RowE_id,YCostPrice,NEWID(),YGuid,
			CAST(INVOICENO as int),'',Y_ID, instoretime,cxType,comment2,scomment,0,BatchBarCode,
			RowGuid,Conclusion /*-CXGUID 存储原单rowguid */
		from  salemanageBilldrf mx where bill_id = @billid AND p_id > 0
			and not exists(select 1 from salemanagebilldrf mx1 where mx.smb_id = mx1.order_id 
				and exists(select 1 from billdraftidx where billid = mx1.bill_id and billtype = 254))
		/*--判断拣货单明细是否生成成功 add by luowei 2014-01-17		*/
		if @@ROWCOUNT<= 0 
		 goto error	
		 
		/*---判断拣货单是否生成成功 add by luowei 2014-01-20*/
		  if (not exists(select 1 from billdraftidx where billid = @newbill and billtype = 254)) 
		  or (not exists(select 1 from salemanagebilldrf where bill_id = @newbill 
				 and exists(select 1 from billdraftidx where billid = bill_id and billtype = 254))) 
		  goto error 
		  
		 /*--检测信息*/
		  exec TS_L_CheckJhInfo @billid,@newbill,2,@nError output
		  if @nError < 0 
		  goto error    
			 	
		update JHBillInfo set jhBillId = @newbill where saleBillGuid = (select GUID from billdraftidx where billid = @billid)
		/*----------更新仓库*/
		declare @outs_id int 
		select @outs_id = MAX(ss_id) from salemanagebilldrf where bill_id = @newbill
		update billdraftidx set sout_id = @outs_id where billid = @newbill
	END
	ELSE
    BEGIN
		declare Scursors cursor for select  ss_id from salemanageBilldrf 
		 where bill_id = @billid and exists(select 1 from billdraftidx where billid = @billid and auditman <> 0)
		 group by ss_id
		 open Scursors
		 fetch next from Scursors into @s_id
		 WHILE @@FETCH_STATUS = 0
		 begin
		   /*-----获取仓库的商品数量*/
		   select @qty = SUM(quantity) from salemanageBilldrf mx where bill_id = @billid and ss_id = @s_id 
				   and not exists(select 1 from salemanagebilldrf mx1 where mx.smb_id = mx1.order_id)
       
		   set @nBillCount=@nBillCount+1
		   set @JHbillnumber=''
			exec TS_H_CreateBillSN 254, 1, null, 0, 0, @JHbillnumber output
	/*	   set @JHbillnumber='JHD'+'-'+left(CONVERT(varchar,@billdate,21),10)+'-'+CAST(@nBillCount as varchar)*/
       
		   /*-----插入主表BillDraftidx*/
		   if @qty > 0
		   begin
			   INSERT into  BillDraftidx
					(
					billdate ,billnumber,GUID,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
					ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
					region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
					B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,WHOLEQTY,PARTQTY,RetailDate
					)
				Select billdate,@JHbillnumber,NEWID(),254,0,c_id,e_id,@s_id,sin_id,auditman,inputman,
					   0,0,0,@qty,0,period,billstates,@billid,0,
					   0,auditdate,skdate,jsflag,note+'销售出库单编号：'+@billnumber+'','',0,0,cast(GUID as varchar(50)),0,0,GatheringMan,0,2,Y_ID, /*-使用vipcardid 存储捡货单状态 2表示成功,1表示捡货单退回*/
					   '','','',sendC_id,0,0,GETDATE() 
					   from BillDraftidx where billid = @billid
	            
	            /*--判断拣货单主表是否生成成功 add by luowei 2014-01-17*/
				if @@ROWCOUNT<= 0 
				goto error
	            		
				/*---插入明细表salemanageBilldrf*/
				IF @@ROWCOUNT=1
				begin
				  SET @newbill = @@IDENTITY  
				  
				  update BillDraftidx set RetailDate = GETDATE() where billid = @newbill
			  
				  INSERT INTO salemanageBilldrf
				  (
				   bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,
				   discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,
				   retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,
				   location_id  ,location_id2, supplier_id  ,commissionflag  ,comment  ,unitid	,
				   taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID, jsprice,
				   AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID,
					invoice,INVOICENO, Y_ID, InStoreTime, cxType, comment2, scomment, batchprice, BatchBarCode,
					 CxGuid, Conclusion
				  )
				  select @newbill,p_id,batchno,quantity, costprice,  saleprice ,discount ,
					discountprice ,totalmoney  ,taxprice   ,taxtotal  , taxmoney , retailprice ,
					 retailtotal, makedate  , validdate , price_id ,ss_id  ,sd_id , smb_id,  /*-orderID 存储原单明细ID*/
					 location_id, location_id2, supplier_id, commissionflag, comment, unitid,
					 taxrate, qualitystatus, total, iotag , InvoiceTotal, orgbillid,jsprice,
					 0,0,0,PriceType,RowE_id,YCostPrice,NEWID(),YGuid,
					 CAST(INVOICENO as int),'',Y_ID, instoretime,cxType,comment2,scomment,0,BatchBarCode,
					 RowGuid,Conclusion /*-CXGUID 存储原单rowguid */
					 from  salemanageBilldrf mx where bill_id = @billid and ss_id = @s_id 
						   and not exists(select 1 from salemanagebilldrf mx1 where mx.smb_id = mx1.order_id 
							  and exists(select 1 from billdraftidx where billid = mx1.bill_id and billtype = 254) )
				  	
				  /*--判断拣货单明细是否生成成功 add by luowei 2014-01-17		*/
					if @@ROWCOUNT<= 0 
					 goto error	
					 
				  /*---判断拣货单是否生成成功 add by luowei 2014-01-20*/
				  if (not exists(select 1 from billdraftidx where billid = @newbill and billtype = 254)) 
				  or (not exists(select 1 from salemanagebilldrf where bill_id = @newbill 
				         and exists(select 1 from billdraftidx where billid = bill_id and billtype = 254))) 
				  goto error
				  
				  /*--检测信息*/
				  exec TS_L_CheckJhInfo @billid,@newbill,2,@nError output
				  if @nError < 0 
				  goto error           
						  	 	
				  		          		       
					insert into JHBillInfo(saleBillId, saleBillGuid, jhBillId)
					select @billid, GUID, @newbill from billdraftidx where billid = @billid
					
					/*----更新拣货单仓库*/
				    update billdraftidx set sout_id = @s_id where billid = @newbill   
				  /*update salemanagebilldrf set invoiceno = '' where bill_id = @billid and ss_id = @s_id	  */
			  
				  /*--------------更新此时的单据中对应可开数量到拣货单的jsprice中 add by luowei 2013-10-21*/
			      if exists(select 1 from sysconfig where sysname = 'CheckSaleQty' and sysvalue = 0)
					  update salemanagebilldrf  set jsprice = isnull(isnull(qty,0)-salemanagebilldrf.quantity,0) + t.quantity from (
					  select p_id as product_id,SUM(quantity) as qty from storehouse 
					  group by p_id  
					  ) sh,OutBatchNotS() t where salemanagebilldrf.p_id = product_id and salemanagebilldrf.p_id = t.p_id 
					  and bill_id = @newbill 
				  else
				    update salemanagebilldrf  set jsprice = isnull(qty,0) + t.quantity from (
				  select p_id as product_id,SUM(quantity) as qty from storehouse 
				  group by p_id  
				  ) sh,OutBatchNotS() t where salemanagebilldrf.p_id = product_id and salemanagebilldrf.p_id = t.p_id
				   and bill_id = @newbill
				end
		   end
		   fetch next from Scursors into @s_id  
		 end 
		 CLOSE Scursors;
		 DEALLOCATE Scursors;
     END

     /*---------------当invoice为0 时 判断捡货单商品批次是否存在对应的同价调拨单草稿，并将其对应的捡货单ID写入  ----add by luowei 2012-2-19*/
     /*update salemanagebilldrf set invoice = s.bill_id from storemanagebilldrf s*/
		   /*where exists(select 1 from billdraftidx i where s.bill_id = i.billid and i.billtype = 44 and order_id = @billid)*/
		   /*and salemanagebilldrf.p_id = s.p_id and salemanagebilldrf.batchno = s.batchno and salemanagebilldrf.supplier_id = s.supplier_id*/
		   /*and salemanagebilldrf.costprice = s.costprice and salemanagebilldrf.ss_id = s.sd_id and salemanagebilldrf.makedate = s.makedate*/
		   /*and salemanagebilldrf.validdate = s.validdate and salemanagebilldrf.commissionflag = s.commissionflag */
		   /*and salemanagebilldrf.location_id = s.location_id2 */
		   /*and exists(select 1 from storages where salemanagebilldrf.ss_id = storage_id and WholeFlag = 2)*/
		   /*and exists(select 1 from billdraftidx where salemanagebilldrf.bill_id = billid and billtype = 254)*/
		   /*and salemanagebilldrf.invoice = 0	*/
				
    commit tran CreateJHBill
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	return 0
  end
  
  error:
	rollback tran CreateJHBill
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	/*raiserror('拣货单生成失败，请重试！',16,1)*/
	return -2
end
GO
