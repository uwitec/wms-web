

CREATE	 PROCEDURE [ts_j_LoadInvoiceIDX]
	(
	 @nInvoiceBillID int = 0,
/*         @nQrMode int = 0,    --0查询表头， ，查询明细*/
 	 @nRet int output     /*判断是否有查询数据返回*/
        )
AS 
/*Params Ini begin*/
if @nInvoiceBillID is null  SET @nInvoiceBillID = 0
/*Params Ini end*/

set @nRet = -1

/*if @nQrMode = 0*/
   select iv.*, 
	  e1.[name] as InputManName,		e2.[name] as AuditManName,	e3.[name] as ReAuditManname,
 	  d.[name] as DepName,			c.[name] as CName,  c1.name as SendCName
     from invoiceidx iv
     left join employees e1 on iv.inputman = e1.emp_id
     left join employees e2 on iv.auditman = e2.emp_id	
     left join employees e3 on iv.reauditman = e3.emp_id
     left join department d on iv.departmentid = d.departmentid
     left join clients c     on iv.c_id = c.client_id
     left join clients c1    on iv.SendC_id = c1.client_id
     where [id] = @nInvoiceBillID

IF @@ROWCOUNT >0 SET @nRET = 1
RETURN 0
GO
