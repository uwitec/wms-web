/************************************************************

--功能：计算会员卡积分  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [TS_j_LockVipCard]
	(
	  @VipCardID int
     )
AS 

declare @nRet int
set @nRet =-1 
if exists(select 1 from vipcard where  vipcardid = @vipCardid and isLock = 0)
begin
  update vipcard set isLock = 1 where vipcardid = @vipCardid
  if @@ROWCOUNT  = 1 set @nRet =0
end


return @nRet
GO
