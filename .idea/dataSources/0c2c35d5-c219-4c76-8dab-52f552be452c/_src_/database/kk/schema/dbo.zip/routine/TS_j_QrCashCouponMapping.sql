
/*代金券关联查询  zjl 2013-06-04*/
create   PROCEDURE TS_j_QrCashCouponMapping
(	
    @nTypeID	int,
	@nLimitFlag int	
)
AS

set nocount on




if @nLimitFlag = 1 
begin    
     select p.CODE, p.NAME, p.STANDARD, p.MODAL, p.MAKEAREA, p.PERMITCODE,
			p.MEDTYPE, p.TRADEMARK, p.ALIAS, p.PACKSTD, p.FACTORY, p.COMMENT,
			p.BULIDNO, p.REGISTERNO,p.PRODUCT_ID 
       from VW_C_Products p
       inner join CashcouponMapping c on p.Product_ID = c.baseid
       where c.typeid = @nTypeID
       order by p.Class_ID                
end

if @nLimitFlag =2
begin   
     select cg.*,         
         LEFT(cg.class_id, 2) as MAINCATEGORYNO,  
         dbo.GetCateGoryStr(cg.ID, 'MAINCATEGORY') as MAINCATEGORY, 
         cg.class_id as SUBCATEGORYNO,
         dbo.GetCateGoryStr(cg.ID, 'SUBCATEGORY') as SUBCATEGORY,         
         cg.id as CG_ID                       
       from CashcouponMapping c    
       inner join customCategory cg on c.BaseID = cg.id
       where c.typeid = @nTypeID and cg.baseType in (0,-1)   /*XXX.商品的自定义类别类型是-1,0*/
       order by cg.Class_ID, cg.rowIndex            
end

return 0
GO
