

CREATE	 PROCEDURE [ts_j_RepClientInvoice]
	(
	 @szCurrentParentID  VARCHAR(250)='000000',
         @CClassID           VARCHAR(250)='000', 
	 @nIVType            int = 0,	/* 发票类型*/
 	 @begindate          varchar(50),
   	 @enddate   	     varchar(50),
	 @OperatorID	     int = 1,	
	 @ListMode           INT=3,    /*显示方式 1：全部列表 2：部分列表 3: 分级显示*/
	 @szOrderInvoice     varchar(60) = '2,3', /*原始单据上选择的可开发票状态*/
	 @szInvoice 	     varchar(60)='1,2,3,4', /*发票单中的发票类型*/
         @szY_id             int=0
        )	
AS 
/*Params Ini begin*/
if @szCurrentParentID is null  SET @szCurrentParentID = '000000'
if @CClassID is null  SET @CClassID = '000'
if @nIVType is null  SET @nIVType = 0
if @OperatorID is null  SET @OperatorID = 1
if @ListMode is null  SET @ListMode = 3
if @szOrderInvoice is null  SET @szOrderInvoice = '2,3'
if @szInvoice is null  SET @szInvoice = '1,2,3,4'
if @szY_id is null  SET @szY_id = 0
/*Params Ini end*/

declare @nClass int
if @CClassID = ''
begin
	if @szCurrentParentID = '000000'
		set @nClass = LEN(@szCurrentParentID)
	else
		set @nClass = LEN(@szCurrentParentID) + 6
end
else
	set @nClass = LEN(@CClassID)

if @szOrderInvoice = '' set @szOrderInvoice = '2,3'   /*普票、增值税票  */
if @szInvoice ='' set @szInvoice = '1,2,3,4'

/*销售类　10,11,12,13,16,17,18,32,112*/
/*采购类　20,21,24,25,28,35,122*/
/*11, 13 , 21, 24,　25 需要反号*/

if @ListMode = 1
begin
	SELECT   distinct   ' ' AS PicturePath, vc.class_id, vc.parent_id, vc.client_id, vc.child_number, vc.name, vc.alias, vc.serial_number, 
						  vc.phone_number, vc.address, vc.contact_personal, vc.cename, vc.RegionName, vc.zipcode, vc.acount_number, vc.tax_number, vc.credit_total, 
						  vc.comment, ISNULL(bi.TotalMoney, 0) AS SaleTotal, ISNULL(iv.TotalMoney, 0) AS NeedTotal, ISNULL(vi.TotalMoney, 0) AS overtotal,
						  CAST(ISNULL(iv.TotalMoney, 0) - ISNULL(vi.TotalMoney, 0) AS NUMERIC(25,8)) AS nototal
	FROM         dbo.vw_Clients AS vc 
	                          LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney 
							                       ELSE ysmoney END) AS TotalMoney, 
													   c.class_id, i.c_id
								FROM          dbo.billidx AS i INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.billdate BETWEEN 
													   @BeginDate AND @EndDate)
								GROUP BY c.class_id, i.c_id) AS bi ON vc.client_id = bi.c_id 
								LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney 
							                       ELSE ysmoney END) AS TotalMoney, 
													   c.class_id, i.c_id
								FROM          dbo.billidx AS i 
								INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2)) AND (i.billdate BETWEEN @BeginDate AND @EndDate) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2)) AND (i.billdate BETWEEN @BeginDate AND @EndDate)
								GROUP BY c.class_id, i.c_id) AS iv ON vc.client_id = iv.c_id 
								LEFT OUTER JOIN
							  (SELECT     c.class_id, /*-SUM(CASE when invoicetype = InvoiceBillType then invoicetotal ELSE - invoicetotal END) AS TotalMoney, i.c_id*/
							              SUM(case when InvoiceBilltype =1 then -invoicetotal else invoicetotal end) AS TotalMoney, i.c_id
								FROM          dbo.clients AS c 
								INNER JOIN
													   dbo.invoiceidx AS i ON c.client_id = i.c_id
								WHERE      (i.invoicedate BETWEEN @BeginDate AND @EndDate) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szInvoice) AS DecodeStr_1)) AND (i.states = 2) AND (i.invoicetype = @nIVType)
								GROUP BY c.class_id, i.c_id) AS vi ON vc.client_id = vi.c_id
	WHERE     (vc.child_number = 0) AND (vc.deleted = 0) AND (vc.class_id LIKE @CClassID + '%')
		AND vc.client_id IN (SELECT client_id from authorizeclients(@OperatorID))
	ORDER BY vc.class_id
end
else if @ListMode = 2
begin
	SELECT   distinct   ' ' AS PicturePath, vc.class_id, vc.parent_id, vc.client_id, vc.child_number, vc.name, vc.alias, vc.serial_number, 
						  vc.phone_number, vc.address, vc.contact_personal, vc.cename, vc.RegionName, vc.zipcode, vc.acount_number, vc.tax_number, vc.credit_total, 
						  vc.comment, ISNULL(bi.TotalMoney, 0) AS SaleTotal, ISNULL(iv.TotalMoney, 0) AS NeedTotal, ISNULL(vi.TotalMoney, 0) AS overtotal,
						  CAST(ISNULL(iv.TotalMoney, 0) - ISNULL(vi.TotalMoney, 0) AS NUMERIC(25,8)) AS nototal
	FROM         dbo.vw_Clients AS vc LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney ELSE ysmoney END) AS TotalMoney, 
													   c.class_id, i.c_id
								FROM          dbo.billidx AS i INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.billdate BETWEEN 
													   @BeginDate AND @EndDate)
								GROUP BY c.class_id, i.c_id) AS bi ON vc.client_id = bi.c_id LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney ELSE ysmoney END) AS TotalMoney, 
													   c.class_id, i.c_id
								FROM          dbo.billidx AS i INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2)) AND (i.billdate BETWEEN @BeginDate AND @EndDate) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2)) AND (i.billdate BETWEEN @BeginDate AND @EndDate)
								GROUP BY c.class_id, i.c_id) AS iv ON vc.client_id = iv.c_id LEFT OUTER JOIN
							  (SELECT     c.class_id, /*SUM(CASE when invoicetype = InvoiceBillType then invoicetotal ELSE - invoicetotal END) AS TotalMoney*/
							               SUM(case when InvoiceBilltype =1 then -invoicetotal else invoicetotal end) AS TotalMoney
							               , i.c_id
								FROM          dbo.clients AS c INNER JOIN
													   dbo.invoiceidx AS i ON c.client_id = i.c_id
								WHERE      (i.invoicedate BETWEEN @BeginDate AND @EndDate) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szInvoice) AS DecodeStr_1)) AND (i.states = 2) AND (i.invoicetype = @nIVType)
								GROUP BY c.class_id, i.c_id) AS vi ON vc.client_id = vi.c_id
	WHERE     (vc.child_number = 0) AND (vc.deleted = 0) AND (vc.class_id LIKE @CClassID + '%')
		AND (vc.class_id LIKE @szCurrentParentID + '%')
		AND vc.client_id IN (SELECT client_id from authorizeclients(@OperatorID))
	ORDER BY vc.class_id
end
else
if @ListMode = 3
begin
	SELECT   distinct   ' ' AS PicturePath, vc.class_id, vc.parent_id, vc.client_id, vc.child_number, vc.name, vc.alias, vc.serial_number, 
						  vc.phone_number, vc.address, vc.contact_personal, vc.cename, vc.RegionName, vc.zipcode, vc.acount_number, vc.tax_number, vc.credit_total, 
						  vc.comment, ISNULL(bi.TotalMoney, 0) AS SaleTotal, ISNULL(iv.TotalMoney, 0) AS NeedTotal, ISNULL(vi.TotalMoney, 0) AS overtotal,
						  CAST(ISNULL(iv.TotalMoney, 0) - ISNULL(vi.TotalMoney, 0) AS NUMERIC(25,8)) AS nototal
	FROM         dbo.vw_Clients AS vc LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney ELSE ysmoney END) AS TotalMoney, 
													   LEFT(c.class_id, @nClass) AS class_id
								FROM          dbo.billidx AS i INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.billdate BETWEEN 
													   @BeginDate AND @EndDate)
								GROUP BY LEFT(c.class_id, @nClass)) AS bi ON vc.class_id = bi.class_id LEFT OUTER JOIN
							  (SELECT     SUM(CASE WHEN billtype IN (11, 13, 21, 24, 25, 54, 111, 121, 211, 221) THEN - ysmoney 
							                       ELSE ysmoney END) AS TotalMoney, 
													   LEFT(c.class_id, @nClass) AS class_id
								FROM          dbo.billidx AS i 
								INNER JOIN
													   dbo.clients AS c ON i.c_id = c.client_id
								WHERE      (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (12, 13, 10, 210, 211, 212, 11, 16, 17, 110, 111, 112, 150, 151, 152, 153)) AND 
													   (@nIVType = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2)) OR
													   (i.Y_ID = 2) AND (i.billstates = '0') AND (i.billtype IN (20, 21, 24, 25, 28, 35, 122, 220, 221)) AND (@nIVType = 1) AND (i.billdate BETWEEN 
													   @BeginDate AND @EndDate) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szOrderInvoice) AS DecodeStr_2))
								GROUP BY LEFT(c.class_id, @nClass)) AS iv ON vc.class_id = iv.class_id 
								LEFT OUTER JOIN
							  (SELECT     LEFT(c.class_id, @nClass) AS class_id, 
							      /* SUM(CASE when invoicetype = InvoiceBillType then  invoicetotal */
							      /*          ELSE - invoicetotal END) AS TotalMoney*/
							      SUM(case when InvoiceBilltype =1 then -invoicetotal else invoicetotal end) as TotalMoney
								FROM          dbo.clients AS c INNER JOIN
													   dbo.invoiceidx AS i ON c.client_id = i.c_id
								WHERE      (i.invoicedate BETWEEN @BeginDate AND @EndDate) AND (i.invoice IN
														   (SELECT     TYPE
															 FROM          dbo.DecodeStr(@szInvoice) AS DecodeStr_1)) AND (i.states = 2) AND (i.invoicetype = @nIVType)
								GROUP BY LEFT(c.class_id, @nClass)) AS vi ON vc.class_id = vi.class_id
	WHERE     (vc.deleted = 0) AND (vc.class_id LIKE @CClassID + '%') 
		AND ((@CClassID = '' AND vc.parent_id = @szCurrentParentID) OR (@CClassID <> ''))
		AND vc.client_id IN (SELECT client_id from authorizeclients(@OperatorID))
	ORDER BY vc.class_id
end
GO
