






CREATE FUNCTION AuthorizeClients (@OperatorID int)
RETURNS TABLE
AS
RETURN(
 SELECT distinct c.Client_ID, c.Class_ID, c.Parent_ID, c.Child_Number, c.Serial_Number, c.[Name] FROM CLIENTS C
    INNER JOIN
     (SELECT * FROM userauthorize WHERE upper(type) = 'C' AND e_id = @OperatorID) AS UA
   ON (LEFT(C.Class_id,LEN(UA.psc_id)) = UA.psc_id) OR (LEFT(UA.psc_id,LEN(C.class_id)) = C.class_id)
  WHERE C.[DELETED] in (0,4,5)
 UNION ALL
 SELECT distinct c.Client_ID, c.Class_ID, c.Parent_ID, c.Child_Number, c.Serial_Number, c.[Name] FROM CLIENTS C  
     WHERE [DELETED] in (0,4,5) AND ((NOT EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'C' AND e_id = @OperatorID))
      OR (EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'C' AND e_id = @OperatorID AND psc_id = '000000')))
)
GO
