
CREATE  PROCEDURE TS_C_BatchModify
(@mode       int=0,                   /*更新商品或者是往来单位    */
 @ClassID     varchar(6000)='000000',   /*商品class_id*/
 @FieldName   varchar(50)='',          /*更新商品的列名*/
 @NewValue    varchar(50)='',   	       /*更新商品列名的值*/
 @nY_id      int=0                    /*分支机构ID*/

)

/*with encryption*/
AS
/*Params Ini begin*/
if @mode is null  SET @mode = 0
if @ClassID is null  SET @ClassID = '000000'
if @FieldName is null  SET @FieldName = ''
if @NewValue is null  SET @NewValue = ''
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

declare @szsql varchar(7000),
        @szsq  varchar(500)
  if @FieldName='ValidDay'  set @szsq=', ValidMonth=''0''' 
  else   if @FieldName='ValidMonth'  set @szsq=', ValidDay=''0''' 
  else  
  set @szsq=''  
  /*撤销有效期时，撤销一个不影响另一个  modify by luowei 2012-06-14*/
  if @FieldName ='CancelValidDay' set @fieldname = 'ValidDay'
  if @FieldName ='CancelValidMonth' set @fieldname ='ValidMonth'  
if @mode=0
begin
  if @FieldName = 'medtype' /*修改剂型*/
  begin
    /*首先删除已经存在的剂型自定义类条目*/
    select @szsql=
    'delete from customCategoryMapping ' 
    +'where baseinfo_id in (select product_id from products where class_id in ('+ @ClassID+')) and category_id in (select id From customCategory where Typeid = 2 and Child_Number = 0) '
    exec(@szsql)
    /*添加自定义类别条目*/
    select @szsql=
    'insert into customCategoryMapping(baseinfo_id,category_id,BaseTypeid,deleted) '
    +'select p.product_id,'+@NewValue+',0,0 from products p where p.class_id in ('+@ClassID+')'  
    exec(@szsql)  
  end
  else /*修改其他字段*/
  begin
  	 select @szsql='update products set '+@fieldname+'='''+@NewValue+''''+@szsq+' from  products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
	 where p.Class_id like M.class_id+''%'''
	 /*print(@szsql) */
	 exec (@szsql)
  end
end
else
if @mode=2   
begin

	 select @szsql='update productbalance set '+@fieldname+'='''+@NewValue+''' from  products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
	 where p.Class_id like M.class_id+''%'' and productbalance.Y_id='+cast(@nY_id as varchar(50))+' and productbalance.p_id=p.product_id'
	/* print(@szsql) */
	 exec(@szsql)
     
     if Upper(@fieldname)='WHOLELOC'
     begin
      select @szsql='insert productbalance(p_id,WholeLoc,SingleLoc,Y_id)
      select product_id,'+@NewValue+',0,'+cast(@nY_id as varchar(50))+'
        from products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
        where p.Class_id like M.class_id+''%'' and product_id not in (select p_id from productbalance where Y_id='+cast(@nY_id as varchar(50))+')'
      exec (@szsql)
     end else      
     if Upper(@fieldname)='SINGLELOC'
     begin
       select @szsql='insert productbalance(p_id,WholeLoc,SingleLoc,Y_id)
         select product_id,0,'+@NewValue+','+cast(@nY_id as varchar(50))+'
           from products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
           where p.Class_id like M.class_id+''%'' and product_id not in (select p_id from productbalance  where Y_id='+cast(@nY_id as varchar(50))+')'
      exec(@szsql)
     end else
     if Upper(@fieldname)='SUPPLIER_ID'
     begin
      select @szsql='insert productbalance(p_id,supplier_id,Y_id)
         select product_id,'+@NewValue+','+cast(@nY_id as varchar(50))+'
         from products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
         where p.Class_id like M.class_id+''%'' and product_id not in (select p_id from productbalance where Y_id='+cast(@nY_id as varchar(50))+')'
      exec(@szsql)
     end else
     if Upper(@fieldname)='LOCATIONID'
     begin
       select @szsql='insert productbalance(p_id,locationid,Y_id)
         select product_id,'+@NewValue+','+cast(@nY_id as varchar(50))+'
            from products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
          where p.Class_id like M.class_id+''%'' and product_id not in (select p_id from productbalance where Y_id='+cast(@nY_id as varchar(50))+')'
        exec(@szsql)
     end else
     if Upper(@fieldname)='EMP_ID'
     begin
      select @szsql='insert productbalance(p_id,emp_id,Y_id)
        select product_id,'+@NewValue+','+cast(@nY_id as varchar(50))+'
        from products p,(select class_id FROM products where class_id in ('+@ClassID+')) M
        where p.Class_id like M.class_id+''%'' and product_id not in (select p_id from productbalance where Y_id='+cast(@nY_id as varchar(50))+')'
       exec(@szsql)
     end
end

else 
begin 
   if Upper(@FieldName)='E_ID'
   begin
	select @szsql='update clientsbalance  set '+@fieldname+'='''+@NewValue+''' from  clientsbalance p,(select client_id FROM clients  where class_id in ('+@ClassID+')) M
	 where p.c_id = M.client_id and p.Y_id='+cast(@nY_ID as varchar(10))+''
	 /*print(@szsql) */
	 exec (@szsql)
   end
   else begin
        select @szsql='update clients  set '+@fieldname+'='''+@NewValue+''' from  clients p,(select class_id FROM clients  where class_id in ('+@ClassID+')) M
	 where p.Class_id like M.class_id+''%'''
	/* print(@szsql) */
	 exec (@szsql) 
   end 

end
GO
