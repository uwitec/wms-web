

CREATE PROCEDURE ts_b_LoadGoodsCheckData
(
@nRET	int output,
@nStore Varchar(100),
@nY_id int=0,
@nLocation int,
@nPID Int,
@nShelfid int,
@nOption Int,
@szPar1 varchar(20),  /*品名或拼音*/
@szPar2 varchar(20),  /*产地*/
@szPar3 varchar(20),  /*剂型*/
@szPar4 varchar(20)  /*货位*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nY_id is null  SET @nY_id = 0
if @nLocation is null set @nLocation = 0
if @nPID is null set @nY_id = 0
if @nShelfid is null set  @nShelfid = 0
/*Params Ini end*/
Declare @SQL varchar(8000),@SQL2 varchar(3000),@sql3 varchar(1000), @szPFields varchar(1000)
DECLARE @szClass_ID varchar(60),@qttj varchar(2000)
set @SQL = 'abc' set @SQL2  = '' set @sql3 = ''
set @szPFields = '' set @qttj = ''
set @szClass_ID = ''

set @qttj=' (select * from storehouse where (location_id=0 or location_id in (select loc_id from location where loc_code like '''+@szpar4+'%'')) and p_id in (select product_id from products where (name like ''% '+@szpar1+'%''  or pinyin like ''%'+@szpar1+'%'') and makearea like ''%'+@szpar2+'%'' and ('''+@szpar3+'''='''' OR  medtype in (select mt_id from medtype where mt_name like ''%'+@szpar3+'%''))) )'

declare @filter varchar(100)
set @filter = ''

/*------判断是否传入零货商品条件,并且分解出过滤条件 add by luowei 2013-06-25*/
if CHARINDEX('99',@nStore) > 0
begin
  set @filter = SUBSTRING(@nStore,CHARINDEX(')',@nStore)+1,LEN(@nStore)-CHARINDEX(')',@nStore))
  set @nStore = SUBSTRING(@nStore,1,CHARINDEX(')',@nStore))
    set @filter = replace(@filter,'p_id','b.p_id')
end

IF @nPID>0
BEGIN
  SET @szClass_ID=''
  SELECT @szClass_ID = Class_ID FROM Products WHERE Product_id = @nPID
END

if @nStore<>'' 
begin
  set @nStore = replace(@nStore,'p_id','b.p_id')
  select @nStore=' and b.s_id in '+@nStore
end  

IF @nOption<>0
BEGIN
  TRUNCATE TABLE billbatchout
  select @sql3='INSERT INTO billbatchout(billid) SELECT DISTINCT b.p_id  FROM storehouse b where p_id>0 and b.Y_id='+cast(@nY_id as varchar(50))+@nStore
  exec(@sql3) 
END

IF @nOption<>1
  SET @szPFields =
    ' p.code,p.name,p.standard,p.modal,p.makearea,isnull(p.Factory,'''') Factory,p.BulidNo,p.RegisterNo,p.comment as PComment,p.permitcode, trademark,medtype,medtype_id,
    unitrate2, unitrate3, unitrate4, 
    CASE WHEN s.WholeFlag = 3 THEN unitcl ELSE unit1 END AS unit1, 
    CASE WHEN s.WholeFlag = 3 THEN '''' ELSE unit2 END AS unit2,
    CASE WHEN s.WholeFlag = 3 THEN '''' ELSE unit3 END AS unit3,
    CASE WHEN s.WholeFlag = 3 THEN '''' ELSE unit4 END AS unit4,
    validmonth, validday, costmethod,
    Unit1_id, Unit2_id, Unit3_id, Unit4_id, otcflag, p.alias, PackStd, StorageCon, isnull(PcName,'''') as pcName, isnull(PcCode,'''') as pcCode '
    
IF @nOption<>0
  SET @szPFields =
    ' p.code,p.name,p.standard,p.modal,p.makearea,isnull(p.Factory,'''') Factory,p.BulidNo,p.RegisterNo,p.comment as PComment,p.permitcode, trademark,medtype,medtype_id,
    unitrate2, unitrate3, unitrate4, 
    unit1, 
    unit2,
    unit3,
    unit4,
    validmonth, validday, costmethod,
    Unit1_id, Unit2_id, Unit3_id, Unit4_id, otcflag, p.alias, PackStd, StorageCon, isnull(PcName,'''') as pcName, isnull(PcCode,'''') as pcCode '

IF @nOption<>1
BEGIN
	SET @SQL =
	'SELECT 0 as smb_ID,0 as bill_id,0 as a_id, b.p_id,b.batchno,b.quantity,b.costprice,b.costprice as price,0 as discount,b.quantity as discountprice,0 as totalmoney, b.costtotal as total,
	  b.quantity as taxprice,0 as taxtotal,0 as taxmoney,0 as retailprice,0 as retailtotal,b.makedate,b.validdate,'''' as qualitystatus, b.storehouse_id as order_id, 0 as orgbillid, 0 as  JSPrice,
	  0 as price_id, b.s_id,s.S_name, b.s_id as s_id2, b.location_id as l_id , b.supplier_id as b_id, b.commissionflag, '''' as comment, 0 as unitid,0 as taxrate,b.location_id as l_id2, 0 as iotag,0 as aoid, '
	+@szPFields+',
	  ISNULL(l.l_name,'''') as location,
	  '''' as location2,
	  ISNULL(s.s_name,'''') as STORAGE,
	  Isnull(s.wholeflag,0) as wholeflag,
	  '''' as STORAGE2,
	  0 as wholeflag2,
	  0 as INVOICETOTAL,

	  0 as COMEDATE,
	  0 as COMEQTY,
	  '''' as SN,
	  isnull(C.[name],'''') as Vendor,
	  0 as thQTY,
	  0 as SendQTY,
	  0 as SendCostTotal  
	  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.Wholerate
	  ,0 as priceType,'''' as RowEName, 0 as RowE_ID, NewID() as YGUID,0 as YCostPrice, ''0'' as INVOICENO,b.Y_ID,b.InStoreTime
	  ,0 as cxtype, '''' as comment2,
	  scomment,
	  batchbarcode,
	  batchprice,0 as newprice, '''' as cxGuid,'''' as Conclusion,factoryid, costtaxprice,taxrate as costtaxrate,costtaxtotal, p.IfZYCheck
	  
	FROM '+@qttj+' b
	inner join vw_b_Products p on b.p_id = p.p_id
	inner join vw_b_storage s  on b.s_id = s.s_id
	left  join vw_b_location l on b.location_id=l.l_id
	left  join Clients C       on b.supplier_id = c.Client_id
	WHERE stopsaleflag = 0
	AND b.Y_id='+cast(@nY_id as varchar(50))+@nStore + @filter
             
	IF @nPID>0
	BEGIN
	  IF @szClass_ID<>'' AND @szClass_ID<>'000000'
	  BEGIN
		SET @szClass_ID= @szClass_ID+'%'
		SET @SQL = @SQL + char(13)+char(10)+'AND p.pclass_id like '''+@szClass_ID+''''
	  END
	END
	IF @nLocation>0
	BEGIN
		SET @SQL = @SQL + char(13)+char(10)+'AND L.L_ID= '+cast( @nLocation as Varchar)
	END
IF @nShelfid>0
BEGIN
    SET @SQL = @SQL + char(13)+char(10)+'AND L.slid= '+cast( @nShelfid as Varchar)
END
/*
ELSE
IF @nLocation<=0
BEGIN
    SET @SQL = @SQL + char(13)+char(10)+'AND b.location_id =0 '
END*/

	IF @nOption <> 2

	SET @SQL = @SQL +char(13)+char(10)+'ORDER BY b.p_id'
END


IF @nOption <> 0
BEGIN
	SET @SQL2 =
	'SELECT 0 as smb_ID,0 as bill_id,0 as a_id,p_id, '''' as batchno,0 as quantity,0 as costprice,0 as price,0 as discount,0 as discountprice,0 as totalmoney, 0 as total,
	  0 as taxprice,0 as taxtotal,0 as taxmoney,0 as retailprice,0 as retailtotal,'''' as makedate,'''' as validdate,'''' as qualitystatus, 0 as order_id, 0 as orgbillid, 0 as  JSPrice,
	  0 as price_id, 0 as s_id,'' '' as s_name, 0 as s_id2, 0 as l_id , 0 as b_id, 0 as commissionflag, '''' as comment, 0 as unitid,0 as taxrate,0 as l_id2, 0 as iotag,0 as aoid,'
	+@szPFields+',
	  ''''as location,
	  '''' as location2,
	  '''' as STORAGE,
	  0 as wholeflag,  
	  '''' as STORAGE2,
	  0 as wholeflag2,
	  0 as INVOICETOTAL,

	  0 as COMEDATE,
	  0 as COMEQTY,
	  '''' as SN,
	  '''' as Vendor,
	  0 as thQTY,
	  0 as SendQTY,
	  0 as SendCostTotal
	  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.Wholerate
	  ,0 as priceType,'''' as RowEName, 0 as RowE_ID, NewID() as YGUID,0 as YCostPrice, ''0'' as INVOICENO,0 as Y_ID,0 as InStoreTime
	  ,0 as cxtype, '''' as comment2
	  , '''' as scomment
	  , '''' as batchbarcode
	  ,0 as batchprice,0 as newprice, '''' as cxGuid,'''' as Conclusion,0 as factoryid,0 as costtaxprice,0 as costtaxrate,0 as costtaxtotal,
      IfZYCheck
	FROM (
	select *
	from vw_b_Products b
	where child_number = 0 and (not (p_id in (select billid from billbatchout)))' + @filter

	IF @nPID>0
	BEGIN
	  IF @szClass_ID<>'' AND @szClass_ID<>'000000'
	  BEGIN
		SET @szClass_ID= @szClass_ID+'%'
		SET @SQL2 = @SQL2 + char(13)+char(10)+'AND pclass_id like '''+@szClass_ID+''''
	  END
	END

	SET @SQL2 = @SQL2 + char(13)+char(10)+') p '

	IF @nOption <> 2
	SET @SQL2 = @SQL2 +char(13)+char(10)+'ORDER BY p.name'
END

IF @nOption = 2 
	SET @SQL = @SQL +
	'
	UNION ALL 
	' +@SQL2

/*print @qttj*/
/*PRINT @sql2*/
 /*print @sql*/

PRINT @SQL

  IF @nOption = 1 EXEC(@SQL2)
  ELSE  EXEC(@SQL)
  IF @nOption<>0 TRUNCATE TABLE billbatchout
  SET @nRet = 0
GO
