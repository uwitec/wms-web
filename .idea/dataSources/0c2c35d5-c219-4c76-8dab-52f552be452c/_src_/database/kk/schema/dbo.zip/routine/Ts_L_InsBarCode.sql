



CREATE PROCEDURE [Ts_L_InsBarCode]
 (@p_id [int],
  @barcode [varchar](30),
  @AutoCode [int])
AS INSERT INTO [barcode] 
  ( [p_id],
  [barcode],
  [AutoCode]) 
 
VALUES 
 ( @p_id,
  @barcode,
  @AutoCode)
GO
