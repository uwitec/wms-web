



/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_BindVip]
(
    @cardno	  varchar(30),
    @tel	    varchar(30),
    @weixinno		varchar(30),	
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
 if(@weixinno='')
 begin
   select @chvErrMsg='微信号不能为空'
   select @chvErrMsg as outMsg,-1 as reCode
   return -1
end
if (@cardno='' and @tel ='')
begin
  select @chvErrMsg='卡号和电话号码不能同时为空'
  select @chvErrMsg as outMsg,-1 as reCode
  return -1
end

select @cardno = isnull(@cardno,'')
select @tel = isnull(@tel,'')

if not exists(select 1 from VIPCard where ((@cardno <>'' and CardNo=@cardno) or (@tel <>'' and Tel =@tel))  and Deleted=0 and isLock=0)
begin
  select @chvErrMsg='卡号和电话号码信息不正确'
  select @chvErrMsg as outMsg,-1 as reCode
   return -1
end

if exists(select 1 from VIPCard where ((@cardno <>'' and CardNo=@cardno) or (@tel <>'' and Tel =@tel)) and Deleted=0 and isLock=0 HAVING count(1)>1)
begin
  select @chvErrMsg='卡号和电话号码信息不唯一'
  select @chvErrMsg as outMsg,-1 as reCode
   return -1
end

declare @vipcardid int
select @vipcardid=VIPCardID,@cardno=cardno from VIPCard where ((@cardno<>'' and CardNo=@cardno) or (@tel <>'' and Tel =@tel)) and Deleted=0 and isLock=0

if exists (select 1 from vipcardbind where VIPCardID=@vipcardid)
begin
  select @chvErrMsg='会员卡号已绑定'
  select @chvErrMsg as outMsg,-1 as reCode
   return -1
end

if exists (select 1 from vipcardbind where WeiXinNo=@weixinno)
begin
  select @chvErrMsg='微信号已绑定'
  select @chvErrMsg as outMsg,-1 as reCode
   return -1
end

insert into VIPCardBind(VIPCardID,WeiXinNo)
values(@vipcardid,@weixinno)

select @chvErrMsg=@cardno
select @chvErrMsg as outMsg,@vipcardid as reCode/*返回需要绑定的会员卡号及ID*/
return 0
GO
