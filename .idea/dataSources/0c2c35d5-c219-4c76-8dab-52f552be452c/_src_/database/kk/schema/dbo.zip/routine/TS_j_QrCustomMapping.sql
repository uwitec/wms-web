/*Exec TS_j_QrCustomMapping -1, 488,0, 0, 0*/
/*自定义类别查询  zjl 2013-05-08*/
/*Exec TS_j_QrCustomMapping  2521,-1, 0, 0*/
create   PROCEDURE TS_j_QrCustomMapping
(	
    @baseType	int,
	@CG_ID 		int,
	@CPType     int=0,
	@info_ID	int=0,
	@nMode	int=0   /*0　从自定义类别查询, 1 从基本资料查询*/
)
AS
/*Exec TS_j_QrCustomMapping;1 0, 0,0, 0, 1*/
set nocount on
if @nMode = 0 
begin 
   if ((@baseType = 0) or (@baseType=-1)) and @CPType=0
   begin
     select p.CODE, p.NAME, p.STANDARD, p.MODAL, p.MAKEAREA, p.PERMITCODE,
			p.MEDTYPE, p.TRADEMARK, p.ALIAS, p.PACKSTD, p.FACTORY, p.COMMENT,
			p.BULIDNO, p.REGISTERNO,p.PRODUCT_ID 
       from VW_C_Products p
       inner join customCategoryMapping c on p.Product_ID = c.baseinfo_id
       where c.category_id = @CG_ID and c.BaseTypeid=0 and p.Child_number=0 and c.deleted=0
       order by p.Class_ID
   end    
   else if ((@baseType = 1) or (@baseType=-1)) and @CPType=1
   begin   
     select p.SERIAL_NUMBER, p.NAME, p.ALIAS,  p.RegionName as SZREGION, p.COMMENT,
			p.contact_personal as contact, p.phone_number as PHONE, p.cename, p.client_id 
       from vw_Clients p
       inner join customCategoryMapping c on p.client_id = c.baseinfo_id
       where c.category_id = @CG_ID and c.BaseTypeid=1 and p.Child_number=0 and c.deleted=0
       order by p.Class_ID            
   end
   else if ((@baseType = 2) or (@baseType=-1)) and @CPType=2
   begin
     select p.serial_number as COMPANY_NO, p.NAME,p.ALIAS, p.MANAGER, p.TEL, p.OPADDRESS, p.company_id 
       from vw_L_Company p
       inner join customCategoryMapping c on p.company_id = c.baseinfo_id
       where c.category_id = @CG_ID and c.BaseTypeid=2 and p.Child_number=0 and c.deleted=0
       order by p.Class_ID 
   end    
end
/*Exec TS_j_QrCustomMapping;1 0, 0,0, 0, 1*/
if @nMode =1
begin
    if @baseType = 0
    begin
       if @info_ID=0 
       begin
           select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
			 ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=0
		   ) a
		   left join (select * from CategoryTemplate where BaseType=1) c on a.Category_id=c.Sx_id
		  ) r where r.Type=5  
       end
       else
       begin
		   select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
			 ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName     
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type  from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=0
		   ) a
		   left join (select * from CategoryTemplate where BaseType=1) c on a.Category_id=c.Sx_id
		  ) r where r.Type=5  
      end
    end     
    else if  @baseType = 1
    begin   
       if @info_ID=0 
       begin
          select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
		     ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName          
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=1
		   ) a
		   left join (select * from CategoryTemplate where BaseType=2) c on a.Category_id=c.Sx_id
		  ) r  where r.Type=5  
       end
       else
       begin
		  select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
		     ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName    
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=1
		   ) a
		   left join (select * from CategoryTemplate where BaseType=2) c on a.Category_id=c.Sx_id
		  ) r left join customCategory q on r.category_id=q.id   where r.Type=5  
      end      
   end
   else if  @baseType = 2
   begin
       if @info_ID=0 
       begin
         select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
		     ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName      
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type  from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=2
		   ) a
		    left join (select * from CategoryTemplate where BaseType=3) c on a.Category_id=c.Sx_id
		  ) r  where r.Type=5    
       end
       else
       begin
		   select isnull(r.category_id,0) as id, isnull(r.name,'') as name,isnull(r.class_id,'') as class_id,
				 ISNULL(r.parent_id,0) as parent_id,isnull(r.basetype,0) as basetype,isnull(r.rowindex,0) as rowindex,
				 r.modifydate,isnull(r.deleted,0) as deleted,isnull(r.pinyin,0) as pinyin,
				 isnull(r.Child_Number,0) as Child_Number, isnull(r.Child_Count,0) as Child_Count,
				 isnull(r.Child_Count,0) as Child_Count,isnull(r.typeid,0) as typeid,
			 Case r.baseType	when 0 then '商品资料'
								when 1 then '往来单位资料'		        
								when 2 then '分支机构资料' 
			 end as baseTypename, 
			 isnull(LEFT(r.class_id, 2),'') as MAINCATEGORYNO,  
			 ISNULL(dbo.GetCateGoryStr(r.id, 'MAINCATEGORY'),'') as MAINCATEGORY, 
			 isnull(r.bclass_id,'') as SUBCATEGORYNO,
			 isnull(dbo.GetCateGoryStr(r.category_id, 'SUBCATEGORY'),'') as SUBCATEGORY,         
			 isnull(r.categoryd_id,0) as CG_ID,
		     ISNULL(r.Category_id,0)  as Categoryd_id,   
			 isnull(r.FieldName,'') as  FieldName        
		   from 
		  ( 
		   select a.*,'' as bclass_id,a.id as categoryd_id,c.FieldName,c.Type  from 
		   (
			   select * from customCategory where parent_id=1 and Typeid=0 and deleted=0 and baseType=2
		   ) a
		     left join (select * from CategoryTemplate where BaseType=3) c on a.Category_id=c.Sx_id
		  ) r where r.Type=5    
      end  
  end  
end

return 0
GO
