
CREATE VIEW vw_Integralcontact
AS
  SELECT   MAX(A.I_ID) as I_ID ,a.c_id as y_id,b.c_id as ct_id
   FROM 
    (SELECT I_ID,C_ID,CTYPE FROM INTEGRALCONTACT WHERE CTYPE=1	
    ) A,
    (SELECT I_ID,C_ID,CTYPE FROM INTEGRALCONTACT WHERE CTYPE=2	
    ) B,
    VIPCARDTYPEEXTEND c
   WHERE A.I_ID=B.I_ID and c.I_id=A.I_ID and c.deleted=0
   group by a.c_id ,b.c_id
GO
