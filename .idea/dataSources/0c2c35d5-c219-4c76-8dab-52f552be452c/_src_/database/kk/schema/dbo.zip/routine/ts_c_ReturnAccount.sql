







CREATE PROCEDURE ts_c_ReturnAccount
AS
set nocount on
select * from tsaccount
GO
