

/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_ClientLowPrice
( @Pid         int,
  @Cid         int,
  @YID         int        
 )	
AS

   select CL.*,isnull(C.serial_number,'')Cnumber, isnull(C.[name],'')Cname,isnull(C.phone_number,'') as Cphone,isnull(C.address,'') as Caddress
    ,isnull(C.C_Customname1,'')C_Customname1,isnull(C.C_Customname2,'')C_Customname2,isnull(C.C_Customname3,'')C_Customname3
    ,isnull(C.C_Customname4,'')C_Customname4,isnull(C.C_Customname5,'')C_Customname5
    ,isnull(P.serial_number,'')Pnumber,isnull(p.[name],'')Pname,isnull(P.alias,'')alias,isnull(P.standard,'')standard
    ,isnull(P.permitcode,'')Permitcode,isnull(P.makearea,'')makearea,isnull(P.trademark,'')trademark
    ,isnull(P.Custompro1,'')Custompro1,isnull(P.Custompro2,'')Custompro2,isnull(P.Custompro3,'')Custompro3
    ,isnull(P.Custompro4,'')Custompro4,isnull(P.Custompro5,'')Custompro5
    ,isnull(Y.[name],'')Yname
    from ClientLowPrice CL
    left join Clients  C on CL.c_id=c.Client_id
    left join Products P on CL.p_id=P.product_id
    left join Company  Y on CL.Y_id=Y.Company_id
    where (@pid=0 or CL.p_id=@Pid)
    and   (@cid=0 or CL.c_id=@cid)
    and   (@Yid=0 or CL.Y_id=@yid)
GO
