




/*保存订单明细*/
CREATE PROCEDURE [WebAPP_WxOrderlDrfSave]
(
    @BillID		int,
    @p_id		int,
    @price		numeric(18,2),
    @qty		numeric(18,2),
    @color		int,
    @size		int,
    @RetMessage varchar(200) out
)

/*$Encode$--*/

AS
select @RetMessage='操作成功'
declare @retailprice numeric(23,7),@unitid int
/*取零售价*/
select @retailprice=0
select @unitid=unit1_id from products where product_id=@p_id
/*select * from orderbill*/
INSERT INTO ORDERBILL
	(
	 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total
	 /*bdcomment1, bdcomment2, bdcomment3, bdcomment4, bdcomment5,unitnote*/
	 /*,bdcomment6,bdcomment7, bdcomment8, bdcomment9, bdcomment10*/
	)
	VALUES
	(
	 @BillID  ,@p_id  ,''  ,@qty  ,0  ,@price	,1  ,@price  ,@price*@qty  ,@price  ,@price*@qty  ,0  ,@retailprice  ,@retailprice*@qty  ,'1900-01-01'  ,'1900-01-01'  ,0  ,0  ,0  ,0  ,0  ,0  ,''	,@unitid  ,0, '', @price*@qty
	 /* '', '', '', '', '',''*/
	 /*,'','','','',''*/
	)

if @@error<>0 
begin
	select @RetMessage = '操作发生错误'
	select @RetMessage as outMsg,-1 as reCode
	return -1
end
else
begin
	select @RetMessage as outMsg,@BillID as reCode
	return @BillID
end
GO
