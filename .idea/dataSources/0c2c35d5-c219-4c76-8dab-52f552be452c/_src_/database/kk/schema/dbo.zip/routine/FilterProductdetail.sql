
CREATE FUNCTION FilterProductdetail(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     pd.pd_id, pd.billid, pd.p_id, pd.s_id, pd.quantity, pd.price, pd.total, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costprice ELSE 0 END AS costprice, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costtotal ELSE 0 END AS costtotal,
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.SendCostTotal ELSE 0 END AS SendCostTotal,
                  pd.taxprice, pd.taxtotal, pd.batchno, pd.makedate, 
				  pd.validdate, pd.commissionflag, pd.supplier_id, pd.location_id, pd.storetype, pd.price_id, pd.order_id, pd.unitid, pd.smb_id, pd.comment, pd.jsprice, 
				  pd.oldcommissionflag, pd.AOID, pd.Y_ID, pd.rowguid, pd.ROWE_id, pd.SendQTY, pd.retailtotal, pd.transflag, pd.retailprice, 
				  pd.instoretime, pd.cxType, pd.thqty, pd.FlowFlag, pd.BatchBarCode, pd.scomment, pd.batchprice,isnull(f.AccountComment,'') as factory,
				  pd.costtaxprice,pd.costtaxrate,pd.costtaxtotal
		FROM         dbo.productdetail AS pd INNER JOIN
							  dbo.products AS p ON pd.p_id = p.product_id
							  left join basefactory f on pd.Factoryid=f.CommID
GO
