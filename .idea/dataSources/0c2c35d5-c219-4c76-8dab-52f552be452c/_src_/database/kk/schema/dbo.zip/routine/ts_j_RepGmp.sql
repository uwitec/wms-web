/************************************************************

--功能：GMP证书查询   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_RepGmp
	(
      @C_ID int = 0,
      @mt_id int = 0,
      @begindate datetime =0,
      @endDate datetime =0
     )
AS 
/*Params Ini begin*/
if @C_ID is null  SET @C_ID = 0
if @mt_id is null  SET @mt_id = 0
if @begindate is null  SET @begindate = 0
if @endDate is null  SET @endDate = 0

SELECT   distinct a.Gmp_NO AS g_gmpno, c.*, a.validdate as gmpDate, a.g_id,gr.ranges as gmpRange
FROM      dbo.clients AS c left JOIN
                dbo.GMPIndex AS a ON c.client_id = a.c_id
               left join GetGMPRangTable() as gr on a.g_id = gr.R_id
               left join GMPMedtype as gd on a.g_id = gd.ga_id 
WHERE   C.deleted <> 1 AND (@C_ID = 0 or A.c_id = @C_ID)
		 and (A.validdate between @begindate and @endDate)
		 and (gd.mt_id=@mt_id or @mt_id=0)
GO
