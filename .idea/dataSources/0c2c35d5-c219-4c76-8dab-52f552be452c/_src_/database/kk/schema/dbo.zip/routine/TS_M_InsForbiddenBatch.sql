
/*禁止销售批次表 */
CREATE PROCEDURE TS_M_InsForbiddenBatch
(
	@Tag		int =0,			/*0:新增 1:修改 2 :删除 3 :批量修改*/
	@fb_id 		int =-1 OUTPUT,
	@PermitCode 	varchar (100)  ='',
	@BatchNo 	varchar (20)  ='',
	@InputMan 	int  =-1,
	@InputTime 	datetime  =0,
	@note 		varchar (256) ='',
	@fb_idList	varchar (8000) ='',	/*批量修改录入人,录入时间*/
	@PName	        varchar(100)='',
	@P_ID		int	=0,
    @fbType		int	=0,
    @StopSale   int = 0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @Tag is null  SET @Tag = 0
if @fb_id is null  SET @fb_id = -1 
if @PermitCode is null  SET @PermitCode = ''
if @BatchNo is null  SET @BatchNo = ''
if @InputMan is null  SET @InputMan = -1
if @InputTime is null  SET @InputTime = 0
if @note is null  SET @note = ''
if @fb_idList is null  SET @fb_idList = ''
if @PName is null  SET @PName = ''
if @P_ID is null  SET @P_ID = 0
if @fbType is null  SET @fbType = 0
if @StopSale is null Set @StopSale = 0
/*Params Ini end*/
/*@Tag=0:新增 */
IF @Tag = 0
BEGIN
	IF Exists(SELECT * FROM ForbiddenBatch WHERE [PermitCode]=@PermitCode and BatchNo=@BatchNo and fbType=@fbType) 
        BEGIN
 		raiserror('批准文号和批号已经存在,请重新录入!',16,1)
	   	return -1
	END

	INSERT INTO [ForbiddenBatch]( [PermitCode], [BatchNo], [InputMan], [InputTime], [note],[PName],[P_ID],[fbType])
	VALUES(@PermitCode, @BatchNo, @InputMan, @InputTime, @note,@PName,@P_ID,@fbType)
	select @fb_id=@@IDENTITY 
	
	/* 对禁销批次停售*/
	if @StopSale = 1
		update storehouse set stopsaleflag = 1 where p_id = @P_ID and batchno = @BatchNo
	
END
/*@Tag=1:修改 */
IF @Tag = 1
BEGIN
   IF Exists(SELECT * FROM ForbiddenBatch WHERE [PermitCode]=@PermitCode and BatchNo=@BatchNo and fbType=@fbType and InputMan=@InputMan 
               and  InputTime=@InputTime and  note=@note and fb_id <> @fb_id) 
        BEGIN
 		raiserror('数据已经存在,请重新修改!',16,1)
	   	return -1
	END
	UPDATE [ForbiddenBatch]
	SET [PermitCode]=@PermitCode, [BatchNo]=@BatchNo, 
	[InputMan]=@InputMan, [InputTime]=@InputTime,
        [note]=@note,[PName]=@PName,P_ID=@P_ID,[fbType]=@fbType
	WHERE [fb_id]=@fb_id
	
	update storehouse set stopsaleflag = @StopSale where p_id = @P_ID and batchno = @BatchNo
END
/*@Tag=2 :删除*/
IF @Tag = 2
BEGIN
	update storehouse set stopsaleflag = 0 where p_id = (select p_id from ForbiddenBatch where fb_id = @fb_id) 
		and batchno = (select batchno from ForbiddenBatch where fb_id = @fb_id)
		
	DELETE [ForbiddenBatch] WHERE fb_id=@fb_id
END

/*@Tag=3 :批量修改录入人,录入时间*/
IF @Tag = 3
BEGIN
	Declare @SQLScript varchar(8000) 

	Set @SQLScript='UPDATE ForbiddenBatch SET [InputMan]=' + char(39)+ Cast(@InputMan as varchar(100))+ char(39)
			+', [InputTime]=' + char(39)+CAST(YEAR(@InputTime) as varchar(10))+'-'+CAST(MONTH(@InputTime)as varchar(10))+'-'+CAST(DAY(@InputTime)as varchar(10))+ char(39)
			+', [note]=' + char(39)+ @note + char(39)
			+'   WHERE fb_id IN ('+@fb_idList+')'

	/*Print (@SQLScript)*/
	Execute (@SQLScript)

END
GO
