
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_GLPRODUCTS
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

    if @szListFlag=''  goto ListLeavelGLP  /*分级显示*/
   if @szListFlag='A' goto ListAllGLP     /*全部列表*/
   if @szListFlag='P' goto ListPartGLP    /*部分列表*/
  return 0     
  ListLeavelGLP: 
  begin
      select * from  vw_T_GLProducts where  Parent_id=@parent_id 
   return 0 
  end
  ListAllGLP:
  begin								
      select * from  vw_T_GLProducts where  child_number=0 
  return 0 
  end
  ListPartGLP:
  begin   
      select * from  vw_T_GLProducts where child_number=0 and left(Parent_id,len(@parent_id))=@parent_id
  return 0
  end
GO
