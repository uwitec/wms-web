

CREATE PROCEDURE [dbo].[Ts_H_DepAct]
	(@Act			int,
	@Dept_ID		int = 0,
	 @serial_number	[varchar](10),
	 @name	[varchar](50),
	 @comment	[varchar](50),
	 @Type int = 0
	)
AS
/*Params Ini begin*/
if @Dept_ID is null  SET @Dept_ID = 0
if @Type is null  SET @Type = 0
/*Params Ini end*/

if @Act = 0
begin
	if exists(select * from department where ([name]=@name or serial_number=@serial_number))
	begin
		RAISERROR('部门名称或部门编号重复，请检查',16,1) 
		return 0
	end 
	INSERT INTO [department] 
		 ( [serial_number],
		 [name],
		 [comment],
		 [Type_id]
		 )	 
	VALUES 
		(@serial_number,
		 @name,
		 @comment,
		 @Type
		 )
	if @@rowcount <>0 
		return @@IDENTITY
	else return 0
end
else
if @Act = 1
BEGIN
	if exists(select * from department where ([name]=@name or serial_number=@serial_number) and departmentid <> @dept_id)
	begin
		RAISERROR('部门名称或部门编号重复，请检查',16,1) 
		return 0
	end 
	update [department] set
		 [serial_number] = @serial_number,
		 [name] = @name,
		 [comment] = @comment,
		 [Type_id] = @Type
	where departmentid = @dept_id
	if @@rowcount <>0 
		return @@IDENTITY
	else return 0
END
GO
