
CREATE VIEW dbo.vw_h_WorkPlan
AS
SELECT     TOP 100 PERCENT ExamPatients.PatientID, ExamPatients.Name, ExamPatients.sex, ExamPatients.Tel, ExamPatients.Birthday, ExamPatients.Job, 
                      ExamPatients.Address, ExamPatients.Comment, ExamPatients.IDCard, ExamPatients.BulidDate, ExamPatients.Pos_Id, ExamPatients.Deleted, 
                      employees_1.PinYin, ExamPatients.Guid, ExamPatients.ModifyDate, ExamPatients.isVIP, ExamPatients.VIP_ID, ExamPatients.regDate, 
                      ExamPatients.Count, ExamPatients.PosName, ExamPatients.Age, dbo.WorkPlan.Plan_ID, dbo.WorkPlan.WorkDay, dbo.WorkPlan.Doctor_ID, 
                      dbo.WorkPlan.onDuty, dbo.WorkPlan.MaxReg, dbo.WorkPart.Name AS dayPartName, dbo.department.name AS DeptName, 
                      employees_1.name AS EmpName, employees_1.class_id, employees_1.parent_id, employees_1.RowIndex, dbo.department.departmentId, 
                      dbo.WorkPart.Part_ID, dbo.WorkPlan.WorkPart_ID, ISNULL(Reg.RegCount, 0) AS RegCount, CONVERT(varchar(8), dbo.WorkPart.StartTime, 108) 
                      AS StartTime, CONVERT(varchar(8), dbo.WorkPart.EndTime, 108) AS EndTime,'' as CardNo
FROM         dbo.WorkPart INNER JOIN
                      dbo.WorkPlan ON dbo.WorkPart.Part_ID = dbo.WorkPlan.WorkPart_ID INNER JOIN
                      dbo.employees AS employees_1 ON dbo.WorkPlan.Doctor_ID = employees_1.emp_id INNER JOIN
                      dbo.department ON employees_1.dep_id = dbo.department.departmentId LEFT OUTER JOIN
                          (SELECT     dbo.Patients.PatientID, dbo.Patients.Name, dbo.Patients.sex, dbo.Patients.Tel, dbo.Patients.Birthday, dbo.Patients.Job, 
                                                   dbo.Patients.Address, dbo.Patients.Comment, dbo.Patients.IDCard, dbo.Patients.BulidDate, dbo.Patients.Pos_Id, dbo.Patients.Deleted, 
                                                   dbo.Patients.PinYin, dbo.Patients.Guid, dbo.Patients.ModifyDate, dbo.Patients.isVIP, dbo.Patients.VIP_ID, ISNULL(Registered.regDate, 
                                                   '1900-1-1') AS regDate, ISNULL(Registered.count, 0) AS Count, dbo.employees.name AS PosName, dbo.GetAge(dbo.Patients.Birthday, 
                                                   GETDATE()) AS Age
                            FROM          dbo.Patients INNER JOIN
                                                   dbo.employees ON dbo.Patients.Pos_Id = dbo.employees.emp_id LEFT OUTER JOIN
                                                       (SELECT     Patient_ID, MAX(RegDate) AS regDate, COUNT(*) AS count
                                                         FROM          dbo.Registered AS Registered_1
                                                         GROUP BY Patient_ID) AS Registered ON dbo.Patients.PatientID = Registered.Patient_ID
                            WHERE      (dbo.Patients.Deleted = 0)) AS ExamPatients ON ExamPatients.PatientID = 0 LEFT OUTER JOIN
                          (SELECT     RegWorkPlan, COUNT(RegWorkPlan) AS RegCount
                            FROM          dbo.Registered AS Registered_2
                            GROUP BY RegWorkPlan) AS Reg ON dbo.WorkPlan.Plan_ID = Reg.RegWorkPlan
ORDER BY dbo.WorkPlan.WorkDay DESC, dbo.WorkPart.EndTime DESC
GO
