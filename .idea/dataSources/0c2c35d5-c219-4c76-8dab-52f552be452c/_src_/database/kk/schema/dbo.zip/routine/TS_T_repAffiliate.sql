
CREATE  PROCEDURE TS_T_repAffiliate
(     @parent_id   varchar(36),
      @Product_id  int,
      @Y_id        int ,
      @szlistflag   char(1)='',
      @Unit_type  int
     
)
AS
/*Params Ini begin*/
if @szlistflag is null  SET @szlistflag = ''
/*Params Ini end*/

 if @szListFlag='L'  goto ListLeavel  /*分级显示*/
 if @szListFlag='A'  goto ListAll     /*全部列表*/
 if @szListFlag='P'  goto ListPart    /*部分列表*/

ListAll:
if @Y_id=0
begin
   select isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name],c.child_number,c.class_id,
          c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
          isnull(P.retailprice,0) as retailprice,
          isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
          isnull(p.price2,0) as price2, isnull(p.price3,0)   as price3,  
          isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
          isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
          isnull(p.lowprice,0) as lowprice ,@Product_id as product_id 
       
    from  Company c 
         left join  posprice p  on   p.Y_id=c.company_id  and (p.p_id = @Product_id  and  p.Unittype=@Unit_type) 
                
    WHERE  c.[Child_number]=0 and c.[deleted]<>1 
    
        
end
else
begin
   select isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name],c.child_number,c.class_id,
           c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
          isnull(P.retailprice,0) as retailprice,
          isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
          isnull(p.price2,0) as price2, isnull(p.price3,0)   as price3,  
          isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
          isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
          isnull(p.lowprice,0) as lowprice ,@Product_id as product_id 
       
    from  Company c 
         left join  posprice p  on   p.Y_id=c.company_id  and (p.p_id = @Product_id and p.Unittype=@Unit_type)  
                
    WHERE P.Y_id=@Y_id and c.[Child_number]=0 and c.[deleted]<>1
    
end
return 0

ListPart:
if  @Y_id=0
begin
   select  isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name],c.child_number,c.class_id, 
           c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
           isnull(P.retailprice,0) as retailprice,
           isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
           isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  
           isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
           isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
           isnull(p.lowprice,0) as lowprice ,@Product_id as product_id 
       
    from  Company c 
        left join  posprice p  on  p.Y_id=c.company_id  and (p.p_id =@Product_id and p.Unittype=@Unit_type) 
                
    where Parent_id like @parent_id  and Child_Number=0 and c.[deleted]<>1
    
end
else
begin
    select isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name], c.child_number,c.class_id,
            c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
           isnull(P.retailprice,0) as retailprice,
           isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
           isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  
           isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
           isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
           isnull(p.lowprice,0) as lowprice,@Product_id as product_id 
       
    from  Company c 
        left join  posprice p  on  p.Y_id=c.company_id  and (p.p_id = @Product_id and p.Unittype=@Unit_type) 
                  
    where P.Y_id=@Y_id and Parent_id like @parent_id and Child_Number=0 and c.[deleted]<>1
   
end
 return 0
ListLeavel:
if @Y_id=0
begin
    select isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name],c.child_number,c.class_id, 
            c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
            isnull(P.retailprice,0) as retailprice,
            isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
            isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  
            isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
            isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
            isnull(p.lowprice,0) as lowprice,@Product_id as product_id 
       
    from  Company c 
       left join  posprice p  on  p.Y_id=c.company_id  and (p.p_id = @Product_id and p.Unittype=@Unit_type) 
                          
    where Parent_id=@parent_id and c.[deleted]<>1
    
end
else
begin
    select isnull(c.serial_number,0) as serial_number,isnull(c.[name],0) as [name],c.child_number,c.class_id, 
          c.[tel],c.[manager],c.[bank],c.[opaddress],c.[communicateaddr],c.[email],
          isnull(P.retailprice,0) as retailprice,
          isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
          isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  
          isnull(p.price4,0) as price4, isnull(p.gpprice,0)     as gpprice,    
          isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
          isnull(p.lowprice,0) as lowprice,@Product_id as product_id 
       
    from  Company c 
       left join  posprice p  on  p.Y_id=c.company_id  and (p.p_id = @Product_id  and p.Unittype=@Unit_type) 
                  
  where p.Y_id=@Y_id and Parent_id=@parent_id and c.[deleted]<>1

 
end
return 0

SET QUOTED_IDENTIFIER OFF
GO
