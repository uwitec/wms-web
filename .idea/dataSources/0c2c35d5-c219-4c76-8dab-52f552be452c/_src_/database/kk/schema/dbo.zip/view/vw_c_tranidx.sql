create   VIEW dbo.vw_c_tranidx AS 
SELECT isnull(y2.name, '') as cname, isnull(dbo.account.name, '') 
      as aname, isnull(dbo.employees.name, '') as ename, isnull(dbo.account.class_id, 
      '') as aclass_id, isnull(y2.class_id, '') as cclass_id, 
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      isnull(ss.[name],'') as ssname,
      isnull(sd.[name],'') as sdname,
      isnull(Y.Class_ID,'') as YClass_id,
      isnull(Y.[name],'') as Yname,
	  ISNULL(CA.name, '') AS CenterAuditName,
	  a.billid,a.billdate,a.billnumber,a.billtype,a.c_id,a.a_id,a.e_id,a.sout_id,a.auditman,a.inputman,a.ysmoney,a.ssmoney,
	  a.quantity,a.taxrate,a.period,a.billstates,order_id,a.department_id,a.posid,a.region_id,a.auditdate,a.skdate,
	  a.jsye,a.jsflag,a.note,a.summary,a.invoice,a.transcount,a.lasttranstime,a.InvoiceTotal,a.InvoiceNO,
	  a.GUID,a.ArAptotal,a.SendQTY,GatheringMan,a.Y_ID,a.CenterAuditDate,a.CenterAuditMan,a.UpCenterdate
from dbo.tranidx a  left outer join
      dbo.account on a.a_id = dbo.account.account_id left outer join
      dbo.company y2 on a.c_id = y2.company_id left outer join
      dbo.employees on a.e_id = dbo.employees.emp_id
      left outer join employees emp on a.inputman=emp.emp_id
      left outer join employees empa on a.auditman=empa.emp_id
      left outer join department dep on a.department_id=dep.departmentid
      left outer join region reg on a.region_id=reg.region_id
      left outer join storages ss on a.sout_id=ss.storage_id
      left outer join storages sd on a.sin_id=sd.storage_id
      left outer join Company  Y  on Y.Company_id=a.Y_id
	  LEFT JOIN employees CA ON a.CenterAuditMan = CA.emp_id
GO
