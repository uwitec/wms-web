/************************************************************
--过程名称：Ts_T_SendSaleDetail
--功能：显示销售出库单和销售出库退货单明细
--创建人：LUO XIAOTIAN 
--创建时间：2010-12-07  
--最后修改:


参数说明：
		   

备注：
**************************************************************/
create proc [dbo].[Ts_T_SendSaleDetail]
( @billid      int
)
as

select bd.billdate,bd.billnumber,billname=case bd.billtype when 10 then '销售出库单' when 11 then '销售出库退货单'  end,
       p.serial_number,p.name,p.standard,p.makearea,u.name,sm.quantity,sm.totalmoney  
from  salemanagebill sm  left join billidx bd  on bd.billid=sm.bill_id
                 left join products   p      on sm.p_id =p.product_id 
                 left join unit       u      on sm.unitid=u.unit_id 
where  bd.billid=@billid
GO
