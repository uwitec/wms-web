

CREATE PROCEDURE Ts_L_GetBillProductRetailLimit
(
    @nType       INT = 2,   /* 1.查询给定YID的主表 2.查询给定的idxID的明细 3.新增、修改委托书主表；4.新增、修改委托书明细表*/
    @IdxID       INT = 0,
    @BillType    INT = 12,
    @BeginTime   DATETIME,
    @EndTime     DATETIME,
    @PCount      NUMERIC(18,4)=0,
    @PQty        NUMERIC(18,4)=0,
    @Note        VARCHAR(600)='',
    @States      INT=0,
    @EId         INT=1,
    @YId         INT=2,  /*只有两类值:2  分公司、自营店、内部机构都用同一套规则 ; N  加盟店自己的YID */
/*----------------------------------  */
    @PId         INT=0,
    @Qty         numeric(18,4)=0,
    @Comment     varchar(600)='',
    @nRet        INT = 0 OUTPUT     
)
AS
BEGIN
/*--Param Init-------*/
IF @nType IS NULL SET @nType=2
IF @idxID IS NULL SET @idxID=0
IF @billtype IS NULL SET @billType=12
IF @begintime IS NULL SET @beginTime='2016-01-01'
IF @Endtime IS NULL SET @Endtime='2020-12-31'
IF @pCount IS NULL SET @pCount=0
IF @pQty IS NULL SET @pQty=0
IF @note IS NULL SET @note=''
IF @States IS NULL SET @states=0
IF @Eid IS NULL SET @Eid=1
IF @YID IS NULL SET @YID=2
IF @PID IS NULL SET @PID=0
IF @Qty IS NULL SET @Qty=0
IF @Comment IS NULL SET @Comment=''
IF @nRet IS NULL SET @nRet=0
/*--Param Init-------*/
	IF @nType = 1
	BEGIN	
		SELECT
		DISTINCT 
		a.idxID,billType,BeginTime,EndTime,PCount,PQty,Note
		,States
		,CASE WHEN States=0 THEN '启用' ELSE '停用' END StatesName
		,EID,YID,com.Name AS YName,emp.name AS EName,a.CreateDate,a.ModifyDate		
		FROM BillProductLimit_Idx a
		LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID
		LEFT JOIN company com ON a.YID=com.Company_ID
		LEFT JOIN employees emp ON a.Eid=emp.emp_id
		LEFT JOIN vw_c_products pdt ON b.pid=pdt.product_id
		WHERE 
		(@YID=0 OR YID=@YID)  
		AND b.idxID IS NOT NULL
		AND (@States=-1 OR States=@States)
		/*AND (begintime>=@Begintime) AND (Endtime<=@EndTime)*/
		AND (begintime<=@Endtime) AND (Endtime>=@BeginTime)
		ORDER BY a.idxID
		
	    SET @nRet= @@RowCount
	    
	    RETURN 0		
	end	

	IF @nType = 2
	BEGIN	
		SELECT
		a.idxID,billType,Begintime,Endtime,PCount,PQty,Note
		,States
		,CASE WHEN States=0 THEN '启用' ELSE '停用' END StatesName
		,EID,YID,com.Name AS YName,emp.name AS EName,a.CreateDate,a.ModifyDate
		,b.DetailID,PId,b.Qty,pdt.name,pdt.Alias,pdt.Standard,pdt.UnitName1,pdt.permitCode,pdt.MakeArea,pdt.Factory,b.Comment,b.ModifyDate
		FROM BillProductLimit_Idx a
		LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID
		LEFT JOIN company com ON a.YID=com.Company_ID
		LEFT JOIN employees emp ON a.Eid=emp.emp_id
		LEFT JOIN vw_c_products pdt ON b.pid=pdt.product_id
		WHERE a.idxID=@idxID 
		AND b.idxID IS NOT null
		ORDER BY b.DetailID desc
        
	    SET @nRet= @@RowCount
	    
	    RETURN 0
	END
	
	IF @nType = 3
	BEGIN
	    IF EXISTS(
	           SELECT 1
	           FROM   BillProductLimit_Idx
	           WHERE  idxID = @idxID
	       )
	    BEGIN
	    	UPDATE BillProductLimit_Idx
	    	SET
	    		BillType = @BillType,
	    		BeginTime = @BeginTime,
	    		EndTime = @EndTime,
	    		PCount = @PCount,
	    		PQty = @PQty,
	    		Note = @Note,
	    		States = @States,
	    		EId = @EId,
	    		YID = @YID
	    	WHERE IdxID = @IdxID
	    	
	    	IF @@ERROR = 0
	        BEGIN
	            DELETE FROM BillProductLimit_Detail WHERE idxID = @idxID
	            SET @nRet = @idxID  /*Return ID to Insert Detail*/
	        END
	        ELSE
	        BEGIN
	            SET @nRet = -1	
	        END
	        RETURN 0
	    END
	    ELSE
	    BEGIN
	    	INSERT INTO BillProductLimit_Idx
	    	(
	    		BillType,
	    		BeginTime,
	    		EndTime,
	    		PCount,
	    		PQty,
	    		Note,
	    		States,
	    		EId,
	    		CreateDate,
	    		YID
	    	)
	    	VALUES
	    	(
	    		@BillType,
	    		@BeginTime,
	    		@EndTime,
	    		@PCount,
	    		@PQty,
	    		@Note,
	    		@States,
	    		@EId,
	    		GETDATE(),
	    		@YID	    		
	    	)
	    	
	    	IF @@ERROR = 0
	        BEGIN
	            SET @nRet = @@IDENTITY  /*return id to insert Detail*/
	        END
	        ELSE
	        BEGIN
	            SET @nRet = -1	
	        END
	        RETURN 0
	    END	    
	END

	IF @nType = 4 
	BEGIN
		INSERT INTO BillProductLimit_Detail
		(
			IdxID,
			PID,
			Qty,
			Comment
		)
		VALUES
		(
			@idxID,
			@PID,
			@Qty,
			@Comment
		)
		IF @@ERROR = 0
		BEGIN
		    SET @nRet = @@IDENTITY
		END
		ELSE
		BEGIN
		    SET @nRet = -1
		END
		
		RETURN 0
	END
END
GO
