

CREATE TRIGGER UpdateRecDate ON [dbo].[buypricehis]
FOR  UPDATE
AS
if update(buyprice)
begin
	declare @nc_id int,@np_id int,@nunit_id int, @nY_id int
	select @nc_id=c_id,@np_id=p_id,@nunit_id=unit_id, @nY_id = Y_ID from deleted
	update buypricehis set modifydate=getdate() where  p_id=@np_id and c_id=@nc_id and unit_id=@nunit_id and Y_ID = @nY_id
end
GO
