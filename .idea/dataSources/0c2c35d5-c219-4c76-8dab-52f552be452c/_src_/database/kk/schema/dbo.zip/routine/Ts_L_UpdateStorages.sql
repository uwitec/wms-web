









CREATE	PROCEDURE [Ts_L_UpdateStorages]	(
	@storage_id			[int],
	@name				[varchar](80),
	@alias				[varchar](30),
	@serial_number		[varchar](26),
	@Comment			[varchar](256),
	@flag				[TinyInt],
	@PinYin				[varchar](80),
	@WholeFlag			int =0,
	@Y_ID				int =0,
	@Fzr_id				int =0,
	@Bgy_id				int =0,
	@StoreCondition		int = 0,
	@QualityFlag		int = 0
)

AS
/*Params Ini begin*/
if @WholeFlag is null  SET @WholeFlag = 0
if @Y_ID is null  SET @Y_ID = 0
/*Params Ini end*/
if exists(select * from storages where serial_number=@serial_number and [storage_id]<> @storage_id and deleted=0)
begin
	RAISERROR('编号重复！不能添加！！',16,1)
	return -2
end

 UPDATE [storages] 

SET  [name]	 = @name,
	 [alias]	 = @alias,
	 [serial_number]	 = @serial_number,
	 [Comment]	 = @Comment,
	 [flag]  = @flag,
	 [PinYin]	 = @PinYin, 
         [WholeFlag]    = @WholeFlag,
          Y_id          =@Y_id,
         Fzr_id         =@Fzr_id,
         Bgy_id         =@Bgy_id,
		 StoreCondition = @StoreCondition,
		 QualityFlag = @QualityFlag

WHERE 
	( [storage_id]	 = @storage_id)
GO
