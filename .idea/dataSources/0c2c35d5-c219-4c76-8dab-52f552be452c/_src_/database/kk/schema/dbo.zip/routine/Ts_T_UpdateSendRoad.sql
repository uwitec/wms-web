 Create procedure [dbo].[Ts_T_UpdateSendRoad]
 (            
    @RoadName   varchar(30),
	@RoadCode   varchar(20),
	@RoadComment varchar(200),
	@Roadid     int
 ) 
AS
if exists(select 1 from SendRoad where  RoadCode=@RoadCode and RoadID<>@Roadid and deleted=0)
begin
	RAISERROR('输入编号重复！',16,1) 
	return -2 
end

Update [dbo].[SendRoad] 
set RoadName =@RoadName,
    RoadCode =@RoadCode,
    RoadComment=@RoadComment
Where roadID=@Roadid

return 0
 GO
