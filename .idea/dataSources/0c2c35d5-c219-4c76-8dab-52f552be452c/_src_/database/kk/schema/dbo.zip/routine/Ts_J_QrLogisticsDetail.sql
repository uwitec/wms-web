CREATE PROCEDURE Ts_J_QrLogisticsDetail
(@szBillid varchar(1000))
AS
BEGIN     
	SELECT v.name AS P_Name, v.alias AS P_Alias, v.serial_number AS P_Code, v.MedName AS P_MedType, v.[standard] AS P_Standard,
	       v.Factory AS P_FACTORY, v.makearea AS P_MakeArea, v.permitcode AS P_PermitCode,
	       CASE WHEN d.makedate = '1900-01-01' THEN '' ELSE d.makedate END AS P_makedate, 
	       CASE WHEN d.validdate = '1900-01-01' THEN '' ELSE d.validdate END AS P_validity,
	       d.batchno, v.unit1name AS P_Unit, d.quantity AS Qty, d.taxprice, d.taxtotal, 
	       d.p_id as P_product_id, d.bill_id as VCH_P_BILLID, b.billdate, b.billnumber,
	       CASE WHEN b.billtype IN (10, 11, 16, 17, 212, 21) THEN e.name ELSE f.name END AS CName,
	       d.comment as memo, d.comment2 as memo2, b.note as billnote,v.PackStd  	       	      	  
      FROM (select CAST(szTYPE as int) as billid from dbo.DecodeToStr(@szBillid)) c 
           INNER JOIN billidx b ON c.billid = b.billid
           INNER JOIN salemanagebill d ON b.billid = d.bill_id
           INNER JOIN vw_Products v ON d.p_id = v.Product_Id 
           LEFT JOIN clients e ON b.c_id = e.client_id 
           LEFT JOIN company f ON b.c_id = f.company_id           
	WHERE  b.billtype IN (10, 11, 16, 17, 212, 21, 150, 152)
	UNION ALL
	SELECT v.name AS P_Name, v.alias AS P_Alias, v.serial_number AS P_Code, v.MedName AS P_MedType, v.[standard] AS P_Standard,
	       v.Factory AS P_FACTORY, v.makearea AS P_MakeArea, v.permitcode AS P_PermitCode,
	       CASE WHEN d.makedate = '1900-01-01' THEN '' ELSE d.makedate END AS P_makedate, 
	       CASE WHEN d.validdate = '1900-01-01' THEN '' ELSE d.validdate END AS P_validity,
	       d.batchno, v.unit1name AS P_Unit, d.quantity AS Qty, d.taxprice, d.taxtotal,
	       d.p_id as P_product_id, d.bill_id as VCH_P_BILLID, b.billdate, b.billnumber, 
	       CASE WHEN b.billtype IN (10, 11, 16, 17, 212, 21) THEN e.name ELSE f.name END AS C_Name,
	       d.comment as memo, d.comment2 as memo2, b.note as billnote,v.PackStd       	       
		FROM  (select CAST(szTYPE as int) as billid from dbo.DecodeToStr(@szBillid)) c
			   INNER JOIN billidx b ON c.billid = b.billid
			   INNER JOIN buymanagebill d ON b.billid = d.bill_id
			   INNER JOIN vw_Products v ON d.p_id = v.Product_Id 
			   LEFT JOIN clients e ON b.c_id = e.client_id 
			   LEFT JOIN company f ON b.c_id = f.company_id
	WHERE  b.billtype IN (16, 17, 21)
END
GO
