
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-10-17*/
/* Description:	模糊查找商品ID*/
/* =============================================*/
CREATE FUNCTION FN_FindProducts 
(	
	@sKeyword varchar(8000)
)
RETURNS 
@Ptd TABLE 
(
	product_id [int] NOT NULL,
	deleted [int] NOT NULL,
	child_number [int] NOT NULL
)
AS
BEGIN
	IF LEFT(@sKeyword, 1) = '}'
	BEGIN
		SET @sKeyword = SUBSTRING(@sKeyword, 2, LEN(@sKeyword))
		INSERT INTO @Ptd
		SELECT product_id, deleted, child_number FROM products 
		WHERE parent_id = @sKeyword
	END
	ELSE
	IF LEFT(@sKeyword, 1) = ' '
	BEGIN
		SET @sKeyword = SUBSTRING(@sKeyword, 2, LEN(@sKeyword))
		INSERT INTO @Ptd
		SELECT product_id, deleted, child_number FROM products 
		WHERE product_id IN (SELECT [TYPE] FROM DecodeStr(@sKeyword))
	END
	ELSE
	BEGIN
		INSERT INTO @Ptd
		SELECT DISTINCT p.product_id, p.deleted, p.child_number
		FROM      dbo.products AS p LEFT OUTER JOIN
						dbo.barcode AS b ON p.product_id = b.p_id
		WHERE   (p.name LIKE @sKeyword) OR
					(p.alias LIKE @sKeyword) OR
					(p.serial_number LIKE @sKeyword) OR
					(p.pinyin LIKE @sKeyword) OR
					(b.barcode LIKE @sKeyword)
	END
	RETURN
END
GO
