
CREATE PROCEDURE [dbo].[ts_M_InsWarrantBill] 
(
@W_ID int,
@BillID int,
@Filter int=0  /*过滤已经生成过的凭证 0:不过滤*/
)
AS
DECLARE @BIllTYPE INT

IF (@Filter=1)
 IF Exists(select 1 from WarrantBill WHERE BillID=@BillID)
    return 0

SELECT @BIllTYPE=BIllTYPE FROM BILLIDX WHERE BillID=@BillID

/*只生成销售凭证/报损凭证/调拨凭证/报溢凭证/采购凭证*/
IF (@BIllTYPE IN(10,11,210,211,41,42,44,45,20,21,220,221))
   INSERT INTO WarrantBill ([W_ID], [BillID]) VALUES(@W_ID,  @BillID)
GO
