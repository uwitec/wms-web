
CREATE PROCEDURE [dbo].[ts_M_ClacWarrant] 
(
@W_ID int,
@Type int
)
AS

declare @BillID  Int
declare @BillCount Int
declare @YsMoney  NUMERIC(25,8)/*应收帐款：12张销售单的合计含税金额*/
declare @YsMoneyTmp  NUMERIC(25,8)
declare @MoneyTotal  NUMERIC(25,8)/*销售收入：12张销售单的合计含税金额 / 1.17（注：药品税率是17%、计生用品是0税率、中药材是13%）*/
declare @MoneyTotalTmp  NUMERIC(25,8)
declare @TaxTotal   NUMERIC(25,8)/*销售税额：销售收入 X  0.17 */
declare @TaxTotalTmp   NUMERIC(25,8)
declare @CostTotal   NUMERIC(25,8)/*销售成本：进货不含税成本*/
declare @CostTotalTmp   NUMERIC(25,8)
declare @Profit  NUMERIC(25,8)/*利润率=（销售收入 一 销售成本）/ 销售收入 * 100%*/

set @BillCount=0 
set @YsMoney=0   
set @MoneyTotal=0   
set @TaxTotal=0     
set @CostTotal=0  
set @Profit=0 

IF not Exists(SELECT top 1 * from WarrantBill WHERE W_ID = @W_ID)
  RETURN 0

/*游标A开始:取单据ID*/
DECLARE aCursor CURSOR FOR 
SELECT BillID FROM WarrantBill WHERE W_ID = @W_ID
OPEN aCursor
FETCH NEXT FROM aCursor INTO @BillID
WHILE @@FETCH_STATUS = 0
BEGIN
   
 set @YsMoneyTmp=0 set @MoneyTotalTmp=0
 set @TaxTotalTmp=0  set @CostTotalTmp=0 
 /*游标B开始:统计计算*/
        IF (@Type=1) /**/
 BEGIN 
         /*销售类凭证*/
  DECLARE bCursor CURSOR FOR
  SELECT YsMoneyTmp=(case when BI.Billtype in (11, 211) then -smb.TaxTotal  else smb.TaxTotal end)
       ,MoneyTotalTmp=(case when BI.Billtype in (11, 211) then -smb.TaxTotal  else smb.TaxTotal end)/(1+smb.taxrate)
       ,TaxTotalTmp=((case when BI.Billtype in (11, 211) then -smb.TaxTotal  else smb.TaxTotal end)/(1+smb.taxrate))*smb.taxrate
       ,CostTotalTmp=(case when BI.Billtype in (11, 211) then -smb.costPrice * smb.quantity  else smb.costPrice * smb.quantity end)
  FROM SaleManageBill smb left join BillIdx BI on smb.bill_id=bi.billid
  WHERE smb.P_ID>0 and BI.BillStates=0 and smb.Bill_ID = @BillID
  OPEN bCursor
  FETCH NEXT FROM bCursor INTO @YsMoneyTmp,@MoneyTotalTmp,@TaxTotalTmp,@CostTotalTmp
        END ELSE
 BEGIN
         /*采购类凭证*/
  DECLARE bCursor CURSOR FOR
  SELECT YsMoneyTmp=(case when BI.Billtype in (21, 221) then -smb.TaxTotal  else smb.TaxTotal end)
       ,MoneyTotalTmp=(case when BI.Billtype in (21, 221) then -smb.TaxTotal  else smb.TaxTotal end)/(1+smb.taxrate)
       ,TaxTotalTmp=((case when BI.Billtype in (21, 221) then -smb.TaxTotal  else smb.TaxTotal end)/(1+smb.taxrate))*smb.taxrate
       ,CostTotalTmp=(case when BI.Billtype in (21, 221) then -smb.costPrice * smb.quantity  else smb.costPrice * smb.quantity end)
  FROM BuyManageBill smb left join BillIdx BI on smb.bill_id=bi.billid
  WHERE smb.P_ID>0 and BI.BillStates=0 and smb.Bill_ID = @BillID
  OPEN bCursor
  FETCH NEXT FROM bCursor INTO @YsMoneyTmp,@MoneyTotalTmp,@TaxTotalTmp,@CostTotalTmp
 END

 WHILE @@FETCH_STATUS = 0
 BEGIN
   set @YsMoney=(@YsMoney + @YsMoneyTmp)  /*应付帐款*/
   IF (@Type=1) /*销售类凭证*/
     set @MoneyTotal=(@MoneyTotal + @MoneyTotalTmp)/*销售收入*/
   else set @MoneyTotal=0    /*采购收入*/
   set @TaxTotal=(@TaxTotal + @TaxTotalTmp)   /*采购税额*/
          set @CostTotal=(@CostTotal + @CostTotalTmp)  /*采购成本*/
   FETCH NEXT FROM bCursor INTO @YsMoneyTmp,@MoneyTotalTmp,@TaxTotalTmp,@CostTotalTmp
 END
 CLOSE bCursor
 DEALLOCATE bCursor
        /*游标B:结束*/
   
   FETCH NEXT FROM aCursor INTO @BillID
END

CLOSE aCursor
DEALLOCATE aCursor
/*游标A:结束*/

/*附清单数*/
SELECT @BillCount=count(*) from WarrantBill WHERE W_ID = @W_ID
/*利润率=（销售收入 一 销售成本）/ 销售收入 * 100%*/
IF (@Type=1)
  SET @Profit=((@MoneyTotal-@CostTotal)/@MoneyTotal)*100  /*销售类凭证*/
ELSE SET @Profit=0  /*采购类凭证*/

/*更新金额*/
UPDATE [WarrantIdx]
SET [BillCount]=@BillCount, [YsMoney]=@YsMoney,[MoneyTotal]=@MoneyTotal, 
    [TaxTotal]=@TaxTotal, [CostTotal]=@CostTotal,[Profit]=@Profit
WHERE W_ID = @W_ID
GO
