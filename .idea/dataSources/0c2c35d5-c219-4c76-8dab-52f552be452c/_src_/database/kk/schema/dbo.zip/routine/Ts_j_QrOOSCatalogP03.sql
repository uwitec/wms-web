
/*缺货分析　按商品汇总，表格3*/
/*最近5次进价*/

CREATE	       PROCEDURE Ts_j_QrOOSCatalogP03
(
	@p_id  int       /*商品ID  */

)
/*with encryption*/
AS
	
	 SELECT top 5 bi.c_id, c.serial_number as cserial_number, c.name as cname, c.contact_personal, c.phone_number,
	        ISNULL(e.name, '') as ename, ISNULL(e.phone, '') as ephone,
			bi.billdate, mx.buyprice, mx.quantity 	
	   from buymanagebill mx 
	   inner join billidx bi on mx. bill_id = bi.billid	   
	   left join clients c on bi.c_id = c.client_id
	   left join employees e on bi.e_id = e.emp_id	   
	   where mx .p_id = @p_id and bi.billtype = 20 and billstates = '0'
	   order by bi.billdate desc
GO
