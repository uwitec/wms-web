/************************************************************

--功能：日结会计科目明细  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_repDayAccountmx]
	(
	 @nDA_ID int = 0
        )
AS 
/*Params Ini begin*/
if @nDA_ID is null  SET @nDA_ID = 0
/*Params Ini end*/

declare @begindate datetime, @enddate datetime

if @nDA_ID = 0
begin
  select @begindate = min(retaildate), @enddate = max(retaildate) 
  from billidx  bi
  inner join upBillList up on bi.billid = up.mdbillid 
  where bi.billtype in (12, 13) and bi.billstates = '0' and up.mdDA_ID =0
  if @begindate is null set @begindate = 0
  if @enddate is null set @enddate = 0   
 
  select @begindate as begindate, @endDate as enddate, cast(0 as int) as id, cast( 0 as int) as da_id, 
         sm.*, y.[name] as yname, a.[name] as aname, newid() as GUID 
   from 
     (select mx.y_id, abs(mx.p_id) as a_id, sum(case bi.billtype when 12 then mx.total else -mx.total end) as total
        from salemanagebill mx inner join billidx bi 
          on mx.bill_id = bi.billid
        inner join UPBillList up on bi.billid = up.mdbillid   
        where mx.p_id < 0 and up.mdDA_ID = 0 and bi.billtype in (12, 13) and bi.billstates = '0'
        group by mx.y_id, mx.p_id) sm
     left join company y on sm.y_id = y.company_id 
     left join account a on sm.a_id = a.account_Id
end
else begin
 
  select @begindate = begindate, @enddate = enddate from Dayaccount where [id] = @nDA_ID
  if @begindate is null set @begindate = 0
  if @enddate is null set @enddate = 0  

  select @begindate as begindate, @endDate as enddate, sm.*, y.[name] as yname, a.[name] as aname 
    from dayaccountdetail sm
    left join company y on sm.y_id = y.company_id 
    left join account a on sm.a_id = a.account_Id
    where sm.DA_ID = @nDA_ID
 

end
GO
