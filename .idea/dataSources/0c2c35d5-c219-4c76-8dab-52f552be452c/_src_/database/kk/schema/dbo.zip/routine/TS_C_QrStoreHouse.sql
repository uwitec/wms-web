

/******************************************

库存商品统计
最后的修改日期 2003-12-17
(显示方式后面增加'-0'表示全部商品,'-1'表示正常商品,'-2'表示零货商品此判断目前只限于此存储过程 add by luowei 2013-08-30 )
与药易通的区别 ： 药易通显示为类型，精算显示为型号

********************************************/

CREATE PROCEDURE TS_C_QrStoreHouse
(	@szParID 			VARCHAR(30)='000000',
	@nS_ID 				INT=0,					      /*仓库id号*/
	@szPeriod 		VARCHAR(1)='0',		    /*'0' 期初 ‘’当前*/
	@szListFlag		VARCHAR(3)='L',			  /*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
        @nUnitMode              int,                         /*单位方式*/
        @nYClassID              varchar(50)='',
        @nloginEID              int=0,
    @isstop                     int=0       /*-默认显示 0 停用商品 1不显示    */

)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParID is null  SET @szParID = '000000'
if @nS_ID is null  SET @nS_ID = 0
if @szPeriod is null  SET @szPeriod = '0'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0

/*---处理是否显示零货商品 add by luowei 2013-08-30*/
declare @ProductType int 
/*declare @flags varchar(10)
if(CHARINDEX('-',@szListFlag,1)) > 0 
begin
  set @flags = SUBSTRING(@szListFlag,3,1)
  if @flags = '0'
  set @ProductType = -1
  if @flags = '1'
  set @ProductType = 0
  if @flags = '2'
  set @ProductType = 1         
end
else
set @ProductType = -1 ---- -1 表示查询全部类型的商品*/

set @ProductType = 0   /*商品类型默认为-1，现在设计拆零商品就是放到拆零库的商品*/
set @szListFlag = SUBSTRING(@szListFlag,1,1)

/*Params Ini end*/
SET NOCOUNT ON
DECLARE
  @szSClassID VARCHAR(30)

Declare @Companytable int,@Storetable int, @nY_ID int
if @nYClassID = ''
  set @ny_id = 2
else
  select @nY_ID = isnull(company_id, 2) from company where class_id = @nYClassId and child_number = 0




  create table #Companytable([id] int)
  create table #storagestable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
/*---update by yh 2014-12-10 根据仓库类型判断是否显示拆零商品 bug 20176*/
   if @nS_ID > 1
     SELECT @szSClassID=ISNULL([Class_ID], '000000') FROM Storages WHERE [Storage_ID]=@nS_ID
   else 
	 SELECT @szSClassID='%%'
       
     
   set @ProductType= -1
/*取消现有零售拆零商品用IsSplit=-1的方式，现在的 拆零商品就是放到拆零库的商品*/
 /*IF @nS_ID IN (0, 1)
  BEGIN
    SELECT @szSClassID='%%'
    set @ProductType=0
  END
  ELSE
  begin
    SELECT @szSClassID=ISNULL([Class_ID], '000000') FROM Storages WHERE [Storage_ID]=@nS_ID
    SELECT @ProductType=WholeFlag FROM Storages WHERE [Storage_ID]=@nS_ID
    if @ProductType=3 
    begin
      set @ProductType=1
    end
    else
    begin
      set @ProductType=0
    end
  end*/
  
	
  IF @nYClassid IN ('','000000','%%')
    select @nYClassid='%%'
  ELSE 
    select @nYClassid=@nYClassid+'%'
  SELECT distinct * INTO #LastClient
  FROM
  (SELECT  P.[Product_ID], P.[Class_ID],
   C.[Name] AS [ClientName], C.[Phone_number]
   FROM Products P,
	(SELECT A.* FROM Buypricehis A,
		(SELECT distinct [P_ID], MAX([Modifydate]) AS [Modifydate]
         FROM Buypricehis GROUP BY [P_ID]) B
         WHERE A.[P_ID]=B.[P_ID] AND A.[Modifydate]=B.[Modifydate] 
	 ) AS PD, Clients C
   WHERE P.[Child_Number]=0 AND P.[Deleted]<>1 AND PD.[C_ID]=C.[Client_ID] AND PD.[P_ID]=P.[Product_ID]) BM 
   
IF @szListFlag='L'  GOTO ListLeavel
IF @szListFlag='A' 	GOTO ListAll
IF @szListFlag='P' 	GOTO ListPart

GOTO SUCCEE

ListLeavel:
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
/*-------------------------------------------*/
/*当前库存，分级显示*/
/*-------------------------------------------*/
declare @RetailPrice int 
exec ts_GetSysValue  'RetailPrice',@RetailPrice out

IF @szPeriod=''
BEGIN

	SELECT 
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod], p.[Comment],   
    P.[Rate2],      P.[Rate3],     P.[Rate4],	     P.[EngName],
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
    isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
    isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
    P.[Unitname2], P.[Unitname3],  P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    isnull(p.cljg,0) as cljg,
    ISNULL(SUM(B.[Quantity])  ,0) AS [Quantity],
	ISNULL(SUM(B.[Costtotal]) ,0) AS [Costtotal],
	ISNULL(SUM(B.costtaxtotal) ,0) AS taxtotal,
	'' AS [ClientName],
    '' AS [Phone_number],
    ISNULL(sum(B.NoSendQTY),0) as NoSendQTY,
    /*cast(sum(ISNULL(P.[RetailPrice],0)*ISNULL(B.Quantity,0)) as NUMERIC(25,8)) AS [RetailTotal],*/
    ISNULL(SUM(B.retailtotal) ,0) AS retailtotal,
    P.PackStd, P.ename, P.emp_id, P.c_name,p.Factory,P.IsSplit,
    isnull(sum(B.ZTquantity),0) as ZTquantity,
    isnull(sum(B.ZTtaxtotal),0) as ZTtaxtotal,
    ISNULL(SUM(B.clquantity) ,0) AS [clquantity],
    ISNULL(SUM(B.clquantity)  ,0)*isnull(p.cljg,0) AS [cltotal]
    FROM 
    (
		   select distinct P.*,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
					isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
					isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
					isnull(pri.[unitname],'') as unitname, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name   
		  from Vw_C_Products P
		  left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
	      
			   LEFT JOIN 
				(select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
			   ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
				 or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
				 or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
				 or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
				   ) 
		 where [Parent_ID]=@szParID AND ((@isstop=0 and  p.[Deleted]<>1) or (@isstop>0 and  p.[Deleted]=0))
			   AND P.[Product_ID]<>1  AND P.[Child_number]<>0
			   AND (@ProductType = -1 OR IsSplit = @ProductType) 
    ) P 
    LEFT JOIN
    (  
         SELECT P.*,
                ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity],
			    ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal],
			    ISNULL(SUM(SH.[Costtaxtotal]) ,0) AS [Costtaxtotal],
			    ISNULL(SUM(SM.[NoSendQTY]),0)  As NoSendQTY,
			    ISNULL(SUM(SH.[retailtotal]) ,0) AS [retailtotal],
			    ISNULL(SUM(a.ZTquantity) ,0) AS ZTquantity,
			    ISNULL(SUM(a.ZTtaxtotal) ,0) AS ZTtaxtotal,
			    ISNULL(SUM(SH.clquantity) ,0) AS clquantity
		   FROM 
			(
			  SELECT [Product_ID], [Class_ID] FROM Products WHERE  ((@isstop=0 and  [Deleted]<>1) or (@isstop>0 and  [Deleted]=0)) AND [Child_Number]=0
			)P
           LEFT JOIN
            (
                SELECT P_id,
                      ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
                      ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal],
                      ISNULL(SUM(SH.costtaxtotal) ,0) AS costtaxtotal,
                      ISNULL(SUM(SH.retailtotal) ,0) AS retailtotal,
                      ISNULL(SUM(SH.clquantity) ,0) AS clquantity
                      
               FROM 
                 (
                     select sh.p_id,s_id,sh.Y_id,case when  s.WholeFlag<>3 then  Quantity else 0 end as  Quantity,
					    case when s.WholeFlag<>3 then  Costtotal else 0 end as Costtotal,
					    case when s.WholeFlag<>3 then  costtaxtotal else 0 end as costtaxtotal,
					    case when  s.WholeFlag<>3 then Quantity*pc.retailprice else 0 end as retailtotal ,
					    ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,   
					    case when  s.WholeFlag=3 then Quantity  else 0 end as clquantity   
					   from FilterStorehouse(@nloginEID) SH
					   left join storages  S ON S.storage_id=SH.s_id
					   left join Company Y ON Y.Company_id=SH.Y_id
					   left join (select retailprice,p_id from price where unittype=1)  pc on sh.p_id=pc.p_id
                       where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                )SH
			   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
					 AND SH.YClass_id like @nYClassid  
					 AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
					 AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable)))          
			   GROUP BY SH.[P_id]
	        )AS SH  ON SH.[P_id]=P.[Product_ID]
          LEFT JOIN
          (
			   SELECT PD.[p_id], ISNULL(SUM(PD.THQTY)-sum(PD.[SendQTY]), 0) AS [NoSendQTY] 
			   FROM
			   (
				 select sm.p_id,sum(sm.thqty) as thqty,sum(sm.SendQTY) as sendqty,sm.ss_id as s_id,B.Y_id,isnull(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id
					  FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
					 left join billidx b on b.billid=sm.bill_id
					 left join Storages s ON sm.ss_id=S.storage_id
					 left join Company Y ON Y.Company_id=b.Y_id
					where sm.thqty>sm.SendQTY and b.billstates=0 and b.billtype in (210)
					group by sm.p_id,sm.ss_id,B.Y_id,s.class_id,Y.class_id
				 )PD
				   where LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
					 and PD.YClass_id like @nYClassID 
					 AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) 
					 AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
				   Group by PD.[p_id]
			  )SM  ON SM.[p_id]=P.[Product_ID]
			  /*-Wsj--2016-10-19 add--在途数量,在途金额-----*/
			  left join
			   ( select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,p.class_id as pclass_id from ( select a.billid from 
                   (select * from billidx where billtype = 152)a left join (
                    select billid,YGuid,Y_ID from billidx where billtype = 162) b on a.YGuid = b.YGuid where b.YGuid is null and a.billstates=0 ) a left join
                    salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Vw_C_Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where st.class_id like @szSClassID and c.class_id like @nYClassID
                    group by p_id,p.class_id 
                )a on a.p_id = P.product_id                    
			 Group by  [Product_ID], [Class_ID]
  )B  ON LEFT(B.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
    p.glprice, p.specialprice,P.PackStd, p.[EName],p.emp_id, p.C_Name,P.Factory,P.IsSplit,p.cljg
   
	UNION 	
	SELECT 
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
    isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
    isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    isnull(p.cljg,0) as cljg,
    ISNULL(SUM(SH.[Quantity])     , 0) AS [Quantity],
    ISNULL(SUM(SH.[Costtotal])    , 0) AS [Costtotal],
    ISNULL(SUM(SH.[Costtaxtotal])    , 0) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    ISNULL(SUM(SM.[NoSendQTY]),0) as NoSendQTY,
    /*cast(sum(ISNULL(P.[RetailPrice],0)*ISNULL(SH.Quantity,0)) as NUMERIC(25,8)) AS [RetailTotal],*/
    ISNULL(SUM(sh.retailtotal) ,0) AS retailtotal,
    P.PackStd, P.ename, P.emp_id, P.c_name,P.Factory,P.IsSplit,
    isnull(sum(a.ZTquantity),0) as ZTquantity,
    isnull(sum(a.ZTtaxtotal),0) as ZTtaxtotal,
    isnull(sum(SH.clquantity),0) as clquantity,
    isnull(sum(SH.clquantity),0)*isnull(p.cljg,0) as cltotal  
   FROM
   (
       select distinct P.*,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
           isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
           isnull(pri.[unitname],'') as unitname,   isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name 
           from Vw_C_Products P
           left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
       /* WHERE  P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0*/
          WHERE  P.[Parent_ID]=@szParID 
               AND  ((@isstop=0 and  p.[Deleted]<>1) or ( @isstop>0 and  p.[Deleted]=0 ))
               AND P.[Product_ID]<>1 AND P.[Child_number]=0 AND (@ProductType = -1 OR IsSplit = @ProductType) 
       ) P
      LEFT JOIN
           (
             SELECT SH.[P_ID],ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity],ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal],
                      ISNULL(SUM(SH.[Costtaxtotal]) ,0) AS [Costtaxtotal], ISNULL(SUM(SH.[retailtotal]) ,0) AS [retailtotal],
                       ISNULL(SUM(SH.[clquantity]) ,0) AS [clquantity]
	         FROM
                (
				       select sh.p_id,s_id,sh.Y_id,case when  s.WholeFlag<>3 then  Quantity else 0 end as  Quantity,
					   case when s.WholeFlag<>3 then  Costtotal else 0 end as Costtotal,
					   case when s.WholeFlag<>3 then  costtaxtotal else 0 end as costtaxtotal,
					   case when  s.WholeFlag<>3 then Quantity*pc.retailprice else 0 end as retailtotal ,
					   ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,   
					   case when  s.WholeFlag=3 then Quantity  else 0 end as clquantity   
					   from FilterStorehouse(@nloginEID) SH
					   left join storages  S ON S.storage_id=SH.s_id
					   left join Company Y ON Y.Company_id=SH.Y_id
					   left join (select retailprice,p_id from price where unittype=1)  pc on sh.p_id=pc.p_id
					   where (@ProductType = -1 or SH.IsSplit = @ProductType)
                 )SH
	          WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
              AND SH.YClass_id like @nYClassID  
              AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
              AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable)))   
            GROUP BY SH.[P_ID]
	   )SH 
      ON SH.[P_ID]=P.[Product_ID]
  
    LEFT JOIN
     (SELECT P.[class_id] as PClass_id,PD.[p_id],ISNULL(SUM(PD.THQTY-PD.[SendQTY]), 0) AS [NoSendQTY] 
      FROM (select sm.p_id,sum(sm.thqty) as thqty,sum(sm.SendQTY) as sendqty,sm.ss_id as s_id,B.Y_id,isnull(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id
                  FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
                 left join billidx b on b.billid=sm.bill_id
                 left join Storages s ON sm.ss_id=S.storage_id
                 left join Company Y ON Y.Company_id=b.Y_id
                where sm.thqty>sm.SendQTY and b.billstates=0 and b.billtype in (210)
                group by sm.p_id,sm.ss_id,B.Y_id,s.class_id,Y.class_id
           )PD
       LEFT JOIN Products P ON PD.p_id=P.Product_id
      WHERE LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
             and PD.YClass_id like @nYClassID 
             AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) 
             AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 

      Group by P.[class_id],PD.[p_id])SM
    ON LEFT(SM.[pclass_id], LEN(P.[Class_ID]))=P.[Class_ID]

  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  left join (
   select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,p.class_id as pclass_id from ( select a.billid from 
                   (select * from billidx where billtype = 152)a left join (
                    select billid,YGuid,Y_ID from billidx where billtype = 162) b on a.YGuid = b.YGuid where b.YGuid is null and a.billstates=0 ) a left join
                    salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Vw_C_Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where st.class_id like @szSClassID and c.class_id like @nYClassID
                    group by p_id,p.class_id 
  ) a  on LEFT(a.pclass_id, LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,  
    P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
    p.glprice, p.specialprice,P.PackStd, p.[EName],p.emp_id,p.C_Name,P.Factory,P.IsSplit,p.cljg


END 
/*-------------------------------------------*/
/*期初库存，分级显示*/
/*-------------------------------------------*/
ELSE BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1] as Unitname,
    cast(0 as NUMERIC(25,8)) as retailprice,cast(0 as NUMERIC(25,8)) as recprice,cast(0 as NUMERIC(25,8)) as price1,
    cast(0 as NUMERIC(25,8)) as price2,     cast(0 as NUMERIC(25,8)) as price3,  cast(0 as NUMERIC(25,8)) as price4,
    cast(0 as NUMERIC(25,8)) as gpprice,    cast(0 as NUMERIC(25,8)) as glprice, cast(0 as NUMERIC(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity],
		ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal],
		ISNULL(SUM(SH.costtaxtotal) ,0) AS taxtotal,
    '' AS [ClientName],
    '' AS [Phone_number],
    0.0000 AS NOSendQTY,
    cast(0 as NUMERIC(25,8)) as RetailTotal,P.PackStd, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name
    ,P.Factory,P.IsSplit, 0.00 as ZTquantity,0.00 as ZTtaxtotal,0.00 as cljg,0.00 as clquantity,0.00 as cltotal
 		FROM Vw_C_Products P
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN 
         (SELECT P.[Class_ID],ISNULL(SUM(SH.[Quantity]),0)[Quantity],ISNULL(SUM(SH.[Costtotal]),0)[Costtotal],ISNULL(SUM(SH.costtaxtotal),0) costtaxtotal
            FROM (select p_id,s_id,sh.Y_id,Quantity,Costtotal
                  ,ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,costtaxtotal
                  from FilterStorehouseini(@nloginEID) SH
                  left join storages  S ON S.storage_id=SH.s_id
                  left join Company   Y ON Y.Company_id=SH.Y_id
                  where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                 )SH
                left join Products  P ON P.product_id=SH.p_id 
	   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
             AND SH.YClass_id like @nYClassid  
             AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
             AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable))) 
	   GROUP BY P.[Class_ID]
	  ) AS SH  
    ON LEFT(sh.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]

  WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]<>0 AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1], 
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.PackStd, pb.[E_Name],pb.emp_id,pb.C_Name,P.Factory,P.IsSplit
	UNION
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1] as Unitname, 

    cast(0 as NUMERIC(25,8)) as retailprice,cast(0 as NUMERIC(25,8)) as recprice,cast(0 as NUMERIC(25,8)) as price1,
    cast(0 as NUMERIC(25,8)) as price2,     cast(0 as NUMERIC(25,8)) as price3,  cast(0 as NUMERIC(25,8)) as price4,
    cast(0 as NUMERIC(25,8)) as gpprice,    cast(0 as NUMERIC(25,8)) as glprice, cast(0 as NUMERIC(25,8)) as specialprice,

    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    ISNULL(SUM(SH.[Quantity])     , 0) AS [Quantity],
    ISNULL(SUM(SH.[Costtotal])    , 0) AS [Costtotal],
    ISNULL(SUM(SH.costtaxtotal) ,0) AS taxtotal,
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 AS NOSendQTY,
    cast(0 as NUMERIC(25,8)) as RetailTotal,P.PackStd, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name
    ,P.Factory,P.IsSplit, 0.00 as ZTquantity,0.00 as ZTtaxtotal,0.00 as cljg,0.00 as clquantity,0.00 as cltotal
    FROM Vw_C_Products P 
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
       (SELECT SH.[P_ID], ISNULL(SUM(SH.[Quantity]),0)[Quantity],ISNULL(SUM(SH.[Costtotal]),0)[Costtotal],ISNULL(SUM(SH.costtaxtotal),0)costtaxtotal
	  FROM (select p_id,s_id,sh.Y_id,Quantity,Costtotal
                  ,ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,costtaxtotal
                  from FilterStorehouseini(@nloginEID) SH
                  left join storages  S ON S.storage_id=SH.s_id
                  left join Company   Y ON Y.Company_id=SH.Y_id
                  where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                 )SH
	   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
             AND SH.YClass_id like @nYClassid  
             AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
             AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable))) 
	   GROUP BY SH.[p_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
  AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod], P.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.PackStd, pb.[E_Name],pb.emp_id,pb.C_Name,P.Factory,P.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

ListAll:
/*-------------------------------------------*/
/*当前库存，全部列表*/
/*-------------------------------------------*/
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
IF @szPeriod=''
BEGIN
  SELECT 
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
    isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
    isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
    P.[Unitname2],  P.[Unitname3], P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    isnull(p.cljg,0) as cljg,
    ISNULL(SUM(SH.[Quantity])     , 0) AS [Quantity],
    ISNULL(SUM(SH.[Costtotal])    , 0) AS [Costtotal],
    ISNULL(SUM(SH.costtaxtotal)    , 0) AS taxtotal,
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    ISNULL(SUM(SM.[NoSendQTY]),0) as NoSendQTY,
    cast(ISNULL((case when @RetailPrice=0 then 0 else sum(case WHEN cast(dbo.GetRetailRate(P.Product_id,@nUnitMode) as NUMERIC(25,8))=0 then 0 else ((ISNULL(P.[RetailPrice],0)*ISNULL(SH.[Quantity],0)) / cast(dbo.GetRetailRate(P.Product_id,@nUnitMode)as NUMERIC(25,8)) ) end) end),0)as NUMERIC(25,8))AS [RetailTotal],
    P.PackStd, P.ename, P.emp_id, P.c_name,P.Factory,P.IsSplit,
    isnull(sum(a.ZTquantity),0) as ZTquantity,
    isnull(sum(a.ZTtaxtotal),0) as ZTtaxtotal,
    ISNULL(SUM(SH.[clquantity])     , 0) AS clquantity,
    ISNULL(SUM(SH.[clquantity])     , 0)*isnull(p.cljg,0) as cltotal
  FROM 
          (SELECT  distinct P.*,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
           isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
           isnull(pri.[unitname],'') as unitname, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name 
           from Vw_C_Products P
           left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
           /*WHERE P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0*/
           WHERE ((@isstop=0 and  p.[Deleted]<>1) or (@isstop>0 and  p.[Deleted]=0))
                AND P.[Product_ID]<>1 AND P.[Child_number]=0 AND (@ProductType = -1 OR IsSplit = @ProductType) 
          ) P 
    LEFT JOIN
          (
					   
              SELECT SH.[P_ID],ISNULL(SUM(case when  sh.WholeFlag<>3 then  sh.Quantity else 0 end),0)[Quantity],
                      ISNULL(SUM(case when  sh.WholeFlag=3 then  sh.Quantity else 0 end),0)[clquantity],
                      ISNULL(SUM(case when sh.WholeFlag<>3 then  sh.Costtotal else 0 end) ,0)[Costtotal],
                     ISNULL(SUM(case when sh.WholeFlag<>3 then  costtaxtotal else 0 end ) ,0) costtaxtotal
               FROM (
                      select p_id,s_id,s.WholeFlag, sh.Y_id,Quantity,Costtotal,ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,sh.costtaxtotal
                      from FilterStorehouse(@nloginEID) SH
					  left join storages  S ON S.storage_id=SH.s_id
					  left join Company Y ON Y.Company_id=SH.Y_id 
					  where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                   )SH
	    WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
             AND SH.YClass_id like @nYClassid  
             AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
             AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable))) 
             GROUP BY SH.[P_ID]
	  )SH 
    ON SH.[P_ID]=P.[Product_ID]

    LEFT JOIN
     (SELECT PD.[p_id],
          ISNULL(SUM(PD.THQTY-PD.[SendQTY]), 0) AS [NoSendQTY] 
      FROM (select sm.p_id,sm.thqty,sm.SendQTY,sm.ss_id as s_id,B.Y_id,isnull(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id
              FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
              left join billidx b on b.billid=sm.bill_id
              left join Storages s ON sm.ss_id=S.storage_id
              left join Company Y ON Y.Company_id=b.Y_id
             where sm.thqty>sm.SendQTY and b.billstates=0 and b.billtype in (210)
           )PD
      where LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
        AND  PD.YClass_id like @nYClassid   
        AND ((@Storetable=0) OR (pd.s_id in (select [id] from #storagestable))) 
        AND ((@Companytable=0)or (pd.Y_id in (select [id] from #Companytable))) 
      Group by PD.[p_id])SM
    ON SM.[P_ID]=P.[Product_ID]
    LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
    left join (
    select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,p.class_id as pclass_id from ( select a.billid from 
                   (select * from billidx where billtype = 152)a left join (
                    select billid,YGuid,Y_ID from billidx where billtype = 162) b on a.YGuid = b.YGuid where b.YGuid is null and a.billstates=0 ) a left join
                    salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Vw_C_Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where st.class_id like @szSClassID and c.class_id like @nYClassID
                    group by p_id,p.class_id 
    ) a on p.Product_ID = a.p_id

  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
    p.glprice, p.specialprice,P.PackStd, p.[EName],p.emp_id,p.C_Name,P.Factory,P.IsSplit,p.cljg
END

/*-------------------------------------------*/
/*期初库存，全部列表*/
/*-------------------------------------------*/
ELSE BEGIN
  SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1]as Unitname, 

    cast(0 as NUMERIC(25,8)) as retailprice,cast(0 as NUMERIC(25,8)) as recprice,cast(0 as NUMERIC(25,8)) as price1,
    cast(0 as NUMERIC(25,8)) as price2,     cast(0 as NUMERIC(25,8)) as price3,  cast(0 as NUMERIC(25,8)) as price4,
    cast(0 as NUMERIC(25,8)) as gpprice,    cast(0 as NUMERIC(25,8)) as glprice, cast(0 as NUMERIC(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    ISNULL(SUM(SH.[Quantity])     , 0) AS [Quantity],
    ISNULL(SUM(SH.[Costtotal])    , 0) AS [Costtotal],
    ISNULL(SUM(SH.[Costtaxtotal])    , 0) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 AS NOSendQTY,
    cast(0 as NUMERIC(25,8)) as RetailTotal,P.PackStd, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name
  ,P.Factory,P.IsSplit, 0.00 as ZTquantity,0.00 as ZTtaxtotal,0.00 as cljg,0.00 as clquantity,0.00 as cltotal
  FROM Vw_C_Products P
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
        (SELECT SH.[P_ID],ISNULL(SUM(SH.[Quantity]),0)[Quantity],ISNULL(SUM(SH.[Costtotal]),0)[Costtotal],ISNULL(SUM(SH.costtaxtotal),0)costtaxtotal
	   FROM
               (select p_id,s_id,sh.Y_id,Quantity,Costtotal,ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,costtaxtotal
                   from FilterStorehouseini(@nloginEID) SH
                   left join storages  S ON S.storage_id=SH.s_id
                   left join Company Y ON Y.Company_id=SH.Y_id
                   where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                )SH                     
	  WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
            AND SH.YClass_id like @nYClassid  
            AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
            AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable)))
       GROUP BY SH.[P_ID]
        )SH 
    ON SH.[P_ID]=P.[Product_ID]
    LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0 AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.PackStd, pb.[E_Name],pb.emp_id,pb.C_Name,P.Factory,P.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

ListPart:
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
/*-------------------------------------------*/
/*当前库存，部分列表*/
/*-------------------------------------------*/
IF @szPeriod=''
BEGIN
  SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
    isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
    isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
    P.[Unitname2],  P.[Unitname3], P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    isnull(p.cljg,0) as cljg, 
		ISNULL(SUM(SM.[Quantity])     , 0) AS [Quantity],
		ISNULL(SUM(SM.[Costtotal])    , 0) AS [Costtotal],
		ISNULL(SUM(SM.[Costtaxtotal])    , 0) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    ISNULL(SUM(SM.[NoSendQTY]),0) as NoSendQTY,
    cast(ISNULL((case when @RetailPrice=0 then 0 else sum(case WHEN cast(dbo.GetRetailRate(P.Product_id,@nUnitMode) as NUMERIC(25,8))=0 then 0 else ((ISNULL(P.[RetailPrice],0)*ISNULL(SM.[Quantity],0)) / cast(dbo.GetRetailRate(P.Product_id,@nUnitMode)as NUMERIC(25,8)) ) end) end),0)as NUMERIC(25,8))AS [RetailTotal],
    P.PackStd, P.ename, P.emp_id, P.c_name,P.Factory,P.IsSplit,
    isnull(sum(a.ZTquantity),0) as ZTquantity,
    isnull(sum(a.ZTtaxtotal),0) as ZTtaxtotal, 
    isnull(sum(sm.clquantity),0) as clquantity, 
    isnull(sum(sm.clquantity),0)* isnull(p.cljg,0) as cltotal
  FROM
     (select distinct P.*,
            isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
            isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
            isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
            isnull(pri.[unitname],'') as unitname, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name 
      from Vw_C_Products P
      left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
      LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
      /*WHERE LEFT(P.[Class_ID], LEN(@szParID))=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0*/
     WHERE LEFT(P.[Class_ID], LEN(@szParID))=@szParID 
     AND ((@isstop=0 and  p.[Deleted]<>1) or ( @isstop>0 and  p.[Deleted]=0 )) 
     AND P.[Product_ID]<>1 AND P.[Child_number]=0 AND (@ProductType = -1 OR IsSplit = @ProductType) 
     ) P 
  LEFT JOIN
     (SELECT  P.*, isnull(SH.quantity,0)quantity,isnull(SH.Costtotal,0)Costtotal,isnull(SM.NoSendQTY,0)NoSendQTY,isnull(SH.costtaxtotal,0)costtaxtotal,
              isnull(SH.clquantity,0)clquantity
        FROM  
         (SELECT product_id,class_id from products) p
        
        LEFT JOIN
            (
              SELECT SH.[P_ID],ISNULL(SUM(SH.[Quantity]) ,0)[Quantity],ISNULL(SUM(SH.[Costtotal]),0)[Costtotal],ISNULL(SUM(SH.costtaxtotal),0)costtaxtotal,
                     ISNULL(SUM(SH.clquantity),0) clquantity
	          FROM
                (
                  select p_id,s_id,sh.Y_id,case when  s.WholeFlag<>3 then  sh.Quantity else 0 end as Quantity,
					  case when s.WholeFlag<>3 then  sh.Costtotal else 0 end as Costtotal,
					  ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,
					  case when s.WholeFlag<>3 then  costtaxtotal else 0 end as costtaxtotal,
					  case when  s.WholeFlag=3 then  sh.Quantity else 0 end as clquantity
                   from FilterStorehouse(@nloginEID) SH
                   left join storages  S ON S.storage_id=SH.s_id
                   left join Company Y ON Y.Company_id=SH.Y_id
                   where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                )SH
	      WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
                AND SH.YClass_id like @nYClassid  
                AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
                AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable)))  
	      GROUP BY SH.[P_ID]
            ) SH 
        ON P.product_id=SH.P_id

        LEFT JOIN
            (SELECT PD.[p_id],ISNULL(SUM(PD.thqty-PD.[SendQTY]),0) AS [NoSendQTY] 
               FROM
                 (select sm.p_id,sm.thqty,sm.SendQTY,sm.ss_id as s_id,B.Y_id,isnull(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id
                    FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
                   left join billidx b on b.billid=sm.bill_id
                   left join Storages s ON sm.ss_id=S.storage_id
                   left join Company Y ON Y.Company_id=b.Y_id
               where sm.thqty>sm.SendQTY and b.billstates=0 and b.billtype in (210)
                 )PD 
              WHERE LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
               and PD.YClass_id like @nYClassID 
               AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) 
               AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
              Group by PD.[p_id])SM
        ON SM.[P_ID]=P.[Product_ID]

     )SM ON SM.Product_id=P.Product_id

  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  left join (
      select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,p.class_id as pclass_id from ( select a.billid from 
                   (select * from billidx where billtype = 152)a left join (
                    select billid,YGuid,Y_ID from billidx where billtype = 162) b on a.YGuid = b.YGuid where b.YGuid is null and a.billstates=0 ) a left join
                    salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Vw_C_Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where st.class_id like @szSClassID and c.class_id like @nYClassID
                    group by p_id,p.class_id 
    ) a on p.Product_ID = a.p_id
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
    p.glprice, p.specialprice,P.PackStd, p.[EName],p.emp_id,p.C_Name,P.Factory,P.IsSplit,p.cljg
END
/*-------------------------------------------*/
/*期初库存，部分列表*/
/*-------------------------------------------*/
ELSE BEGIN
  SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1] as Unitname, 
    cast(0 as NUMERIC(25,8)) as retailprice,cast(0 as NUMERIC(25,8)) as recprice,cast(0 as NUMERIC(25,8)) as price1,
    cast(0 as NUMERIC(25,8)) as price2,     cast(0 as NUMERIC(25,8)) as price3,  cast(0 as NUMERIC(25,8)) as price4,
    cast(0 as NUMERIC(25,8)) as gpprice,    cast(0 as NUMERIC(25,8)) as glprice, cast(0 as NUMERIC(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    ISNULL(SUM(SH.[Quantity])     , 0) AS [Quantity],
    ISNULL(SUM(SH.[Costtotal])    , 0) AS [Costtotal],
    ISNULL(SUM(SH.[Costtaxtotal])    , 0) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 AS NOSendQTY,
    cast(0 as NUMERIC(25,8)) as RetailTotal,P.PackStd, isnull(pb.[e_name], '') as ename, isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name
  ,P.Factory,P.IsSplit,  0.00 as ZTquantity,0.00 as ZTtaxtotal,0.00 as cljg,0.00 as clquantity,0.00 as cltotal
  FROM Vw_C_Products P
  left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
  LEFT JOIN
      (SELECT SH.[P_ID],ISNULL(SUM(SH.[Quantity]),0)[Quantity],ISNULL(SUM(SH.[Costtotal]),0)[Costtotal],ISNULL(SUM(SH.costtaxtotal),0)costtaxtotal
       FROM   (select p_id,s_id,sh.Y_id,Quantity,Costtotal,ISNULL(S.Class_id,'')SClass_id,isnull(Y.Class_id,'')YClass_id,costtaxtotal
                   from FilterStorehouse(@nloginEID) SH
                   left join storages  S ON S.storage_id=SH.s_id
                   left join Company Y ON Y.Company_id=SH.Y_id
                   where (@ProductType = -1 or SH.IsSplit = @ProductType) 
                )SH
       WHERE  LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
         AND SH.YClass_id like @nYClassid  
         AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable))) 
         AND ((@Companytable=0)or (sh.Y_id in (select [id] from #Companytable))) 
       GROUP BY SH.[P_ID]
      )SH 
  ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE LEFT(P.[Class_ID], LEN(@szParID))=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
        AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],  P.[Modal],        P.[Makearea], P.[Costmethod],p.[Comment],
    P.[Rate2],      P.[Rate3],     P.[Rate4],        P.[EngName],
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,
    P.Custompro4,P.Custompro5,P.PackStd, pb.[E_Name],pb.emp_id,pb.C_Name,P.Factory,P.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

SUCCEE:
  DROP TABLE #LastClient
  RETURN 0
GO
