













create   view dbo.vw_c_retailbillidx
as
select dbo.retailbillidx.*, isnull(dbo.clients.name, '') as cname, isnull(dbo.account.name, '') 
      as aname, isnull(dbo.employees.name, '') as ename, isnull(dbo.account.class_id, 
      '') as aclass_id, isnull(dbo.clients.class_id, '') as cclass_id, 
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id
from dbo.retailbillidx left outer join
      dbo.account on dbo.retailbillidx.a_id = dbo.account.account_id left outer join
      dbo.clients on dbo.retailbillidx.c_id = dbo.clients.client_id left outer join
      dbo.employees on dbo.retailbillidx.e_id = dbo.employees.emp_id
      left outer join employees emp on dbo.retailbillidx.inputman=emp.emp_id
      left outer join employees empa on dbo.retailbillidx.auditman=empa.emp_id
      left outer join department dep on dbo.retailbillidx.department_id=dep.departmentid
      left outer join region reg on dbo.retailbillidx.region_id=reg.region_id
      left outer join storages ss on dbo.retailbillidx.sout_id=ss.storage_id
      left outer join storages sd on dbo.retailbillidx.sin_id=sd.storage_id
GO
