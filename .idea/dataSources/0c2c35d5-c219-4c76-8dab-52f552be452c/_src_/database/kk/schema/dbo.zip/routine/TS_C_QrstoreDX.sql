




/********************************************************************************************************************************************************************************************************************
***************************************************************************************************************************************************************************************/
/******************************************
代销商品的查询
(显示方式后面增加'-0'表示全部商品,'-1'表示正常商品,'-2'表示零货商品此判断目前只限于此存储过程 add by luowei 2013-08-30 )
********************************************/
CREATE PROCEDURE TS_C_QrstoreDX
(       @szParid 		VARCHAR(30)='',
	@nC_ID 			INT=0,					/*仓库id号*/
	@szPeriod 		VARCHAR(1)='0',	/*'0' 期初 ‘’当前*/
	@szListFlag		VARCHAR(3)='L',	/*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
	@nCommissionflag        INT=1,      /* 1 委托代销 2 受托代销*/
        @nYClassId              Varchar(50)='',
        @nloginEID              int=0,
        @nUnitMode              int  /*单位方式*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParid is null  SET @szParid = ''
if @nC_ID is null  SET @nC_ID = 0
if @szPeriod is null  SET @szPeriod = '0'
if @szListFlag is null  SET @szListFlag = 'L'
if @nCommissionflag is null  SET @nCommissionflag = 1
if @nYClassId is null  SET @nYClassId = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/


/*---处理是否显示零货商品 add by luowei 2013-08-30*/
declare @ProductType int 
declare @flags varchar(10)
if(CHARINDEX('-',@szListFlag,1)) > 0 
begin
  set @flags = SUBSTRING(@szListFlag,3,1)
  if @flags = '0'
  set @ProductType = -1
  if @flags = '1'
  set @ProductType = 0
  if @flags = '2'
  set @ProductType = 1         
end
else
set @ProductType = -1 /*-- -1 表示查询全部类型的商品*/

set @szListFlag = SUBSTRING(@szListFlag,1,1)


SET NOCOUNT ON

  Declare @ClientTable int,@Companytable int, @nY_ID int
  select @nY_ID = isnull(company_id, 0) from company where class_id = @nYClassId and child_number = 0
  if @ny_id is null set @ny_id = 0   
 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
  if @nYClassId='' select @nYClassId='%%'  else select @nYClassId=@nYClassId+'%'


if @szListFlag='L'      goto ListLeavel
if @szListFlag='A' 	goto ListAll
if @szListFlag='P' 	goto ListPart

RETURN 0

ListLeavel:
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
IF @szPeriod=''
BEGIN
  IF @nC_ID=0
  BEGIN
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname as Unitname ,a.[PackStd], isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name, 
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
           a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit, cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a   
     left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            )  
    left join	(SELECT dbo.products.class_id,
		 ISNULL(SUM(s.quantity), 0) AS quantity, 
		 ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedx s 
                 INNER JOIN
		 dbo.products ON s.p_id = dbo.products.product_id
 		 where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
 		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
 		 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
  		 AND (s.YClass_id like @nYClassID)
	         GROUP BY dbo.products.class_id
		 ) as b 
    on (a.class_id=left(b.class_id,len(a.class_id)))
    where a.parent_id=@szParid and a.deleted<>1  and a.product_id<>1
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
             Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
             pri.glprice, pri.specialprice, a.Factory,a.IsSplit,a.[PermitCode]
    order by a.product_id
  end else /*c_id>0*/
    begin
      select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname as Unitname ,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name, 
    	     isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
             isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
             isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
             a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	     cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	     cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
             ' ' AS [ClientName],
             ' ' AS [Phone_number],
             0.0000 AS [NOSendQTY],
             cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
             a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
      from vw_c_products a
      left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
      LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
      ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            )  
      left join	(SELECT dbo.products.class_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedx s 
                 INNER JOIN
		 dbo.products ON s.p_id = dbo.products.product_id
		 where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
	         AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
	         GROUP BY dbo.products.class_id
		) as b 
      on (a.class_id=left(b.class_id,len(a.class_id)))
      where a.parent_id=@szParid and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
      group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
               a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
               a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit,a.[PermitCode] 
      order by a.product_id
    end
end else  /* @szPeriod='0'*/
begin
    if @nC_ID=0
    begin
      select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,  
             isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
             isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
             isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	     a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	     cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	     cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
	     ' ' AS [ClientName],
	     ' ' AS [Phone_number],
             0.0000 AS [NOSendQTY],
             cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit, cast(0 as NUMERIC(25,8)) as taxtotal,
             a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
      from vw_c_products a 
      left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
      LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
      ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
      left join	(SELECT dbo.products.class_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedxini s 
                 INNER JOIN
		 dbo.products ON s.p_id = dbo.products.product_id
		 where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
	         AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.class_id
		 ) as b 
       on (a.class_id=left(b.class_id,len(a.class_id)))
       where a.parent_id=@szParid and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
       group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
                a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd], pb.[E_Name],pb.emp_id,pb.C_Name,
                Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
                pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
       order by a.product_id
     end else
     begin
	select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
               a.rate2,a.rate3,a.rate4,pri.unitname  as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
               isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
               isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
               isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	       a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
               a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	       cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	       cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
               ' ' AS [ClientName],
               ' ' AS [Phone_number],
               0.0000 AS [NOSendQTY],
               cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
               a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
	from vw_c_products a
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id  
        LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
        ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
	left join	(SELECT dbo.products.class_id,
		         ISNULL(SUM(s.quantity), 0) AS quantity, 
		         ISNULL(SUM(s.costtotal), 0) AS costtotal
			 FROM vw_c_storedxini s 
                         INNER JOIN
		         dbo.products ON s.p_id = dbo.products.product_id 
			 where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
			 AND (@ProductType = -1 OR IsSplit = @ProductType) 
	                 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		         AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                         AND (s.YClass_id like @nYClassID)
		         GROUP BY dbo.products.class_id
		        ) as b 
	on (a.class_id=left(b.class_id,len(a.class_id)))
	where a.parent_id=@szParid and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
	group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
                 a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
                 a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
                 Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
                 pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
	order by a.product_id
    end
end
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
return 0



ListAll:

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
if @szPeriod=''
begin
   if @nC_ID=0
   begin
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname  as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,  
	   isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	   a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
 	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a 
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
    left join(SELECT dbo.products.product_id,
	      ISNULL(SUM(s.quantity), 0) AS quantity, 
	      ISNULL(SUM(s.costtotal), 0) AS costtotal
	      FROM vw_c_storedx s 
              INNER JOIN
	      dbo.products ON s.p_id = dbo.products.product_id 
	      where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
	      AND (@ProductType = -1 OR IsSplit = @ProductType) 
	      AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 	      AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
              AND (s.YClass_id like @nYClassID)
	      GROUP BY dbo.products.product_id
	      ) as b 
    on (a.product_id=b.product_id)
    where a.child_number=0 and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
             Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
             pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
    order by a.product_id
   end else
   begin
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd], isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name, 
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
           a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            )  
    left join	(SELECT dbo.products.product_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedx s 
                 INNER JOIN
	         dbo.products ON s.p_id = dbo.products.product_id
		 where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
		 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.product_id
		 ) as b 
    on (a.product_id=b.product_id)
    where a.child_number=0 and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
             Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
             pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
    order by a.product_id
   end
end else
   begin
   if @nC_ID=0
     begin
      select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
            a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd], isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
            isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
            isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
            isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	    a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
            a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	    cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	    cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
            ' ' AS [ClientName],
            ' ' AS [Phone_number],
            0.0000 AS [NOSendQTY],
            cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
            a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
     from vw_c_products a 
     left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
     left join	(SELECT dbo.products.product_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
	         FROM vw_c_storedxini s 
                 INNER JOIN
	         dbo.products ON s.p_id = dbo.products.product_id 
		 where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
		 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.product_id
	        ) as b 
     on (a.product_id=b.product_id)
     where a.child_number=0 and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
     group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
              a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
              a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
              Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
              pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
     order by a.product_id
    end else
    begin
     select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
            a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
            isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
            isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
            isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
            a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
            a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	    cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	    cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
            '''' AS [ClientName],
            '''' AS [Phone_number],
            0.0000 AS [NOSendQTY],
            cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
            a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
     from vw_c_products a 
     left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
     left join	(SELECT dbo.products.product_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedxini s 
                 INNER JOIN
                 dbo.products ON s.p_id = dbo.products.product_id
		 where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
		 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.product_id
		) as b 
     on (a.product_id=b.product_id)
     where a.child_number=0 and a.deleted<>1  and a.product_id<>1 AND (@ProductType = -1 OR IsSplit = @ProductType) 
     group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
              a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
              a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
     order by a.product_id
    end
end
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
return 0

ListPart:
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
if @szPeriod=''
begin
   if @nC_ID=0
   begin
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name, 
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	   a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a 
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
    left join	(SELECT dbo.products.product_id,
	         ISNULL(SUM(S.quantity), 0) AS quantity, 
	         ISNULL(SUM(S.costtotal), 0) AS costtotal
		 FROM vw_c_storedx S INNER JOIN
	         dbo.products ON s.p_id = dbo.products.product_id
		 where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
	 	 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
	         AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.product_id
		) as b 
    on (a.product_id=b.product_id)
    where left(a.class_id,len(@szParid))=@szParid and a.child_number=0 and a.deleted<>1  and a.product_id<>1 
    AND (@ProductType = -1 OR IsSplit = @ProductType) 
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
    order by a.product_id
   end else
   begin
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	   a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a 
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
    left join	(
		SELECT dbo.products.product_id,
		ISNULL(SUM(s.quantity), 0) AS quantity, 
		ISNULL(SUM(s.costtotal), 0) AS costtotal
		FROM vw_c_storedx s INNER JOIN
		dbo.products ON s.p_id = dbo.products.product_id
		where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag	
		AND (@ProductType = -1 OR IsSplit = @ProductType) 
	        AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
	        AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
         	AND (s.YClass_id like @nYClassID)
		GROUP BY dbo.products.product_id
		) as b 
    on (a.product_id=b.product_id) 
    where left(a.class_id,len(@szParid))=@szParid and a.child_number=0 and a.deleted<>1  and a.product_id<>1
    AND (@ProductType = -1 OR IsSplit = @ProductType) 
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit ,a.[PermitCode] 
    order by a.product_id
   end
end else
   begin
   if @nC_ID=0
    begin
     select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
            a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
            isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
            isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
            isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	    a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
	    a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	    cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
	    cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
            ' ' AS [ClientName],
            ' ' AS [Phone_number],
            0.0000 AS [NOSendQTY],
            cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
            a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
     from vw_c_products a 
     left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 			     
     left join	(
		SELECT dbo.products.product_id,
      		ISNULL(SUM(s.quantity), 0) AS quantity, 
      		ISNULL(SUM(s.costtotal), 0) AS costtotal
		FROM vw_c_storedxini s INNER JOIN
                dbo.products ON s.p_id = dbo.products.product_id
		where dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		AND (@ProductType = -1 OR IsSplit = @ProductType) 
		AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
	        AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
         	AND (s.YClass_id like @nYClassID)
		GROUP BY dbo.products.product_id
		) as b 
     on (a.product_id=b.product_id)
     where left(a.class_id,len(@szParid))=@szParid and a.child_number=0 and a.deleted<>1  and a.product_id<>1
     AND (@ProductType = -1 OR IsSplit = @ProductType) 
     group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
              a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
              a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd],  pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit,a.[PermitCode]  
     order by a.product_id
   end else
   begin
    select a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
           a.rate2,a.rate3,a.rate4,pri.unitname as Unitname,a.[PackStd],  isnull(pb.[e_name], '') as ename,
           isnull(pb.emp_id, 0) emp_id, isnull(pb.c_name, '') c_name,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0 ) as price1,
           isnull(pri.price2,0) as price2,     isnull(pri.price3,0 ) as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0) as gpprice,    isnull(pri.glprice,0 ) as glprice, isnull(pri.specialprice,0) as specialprice,
	   a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
           a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   cast(isnull(sum(b.quantity),0)  as NUMERIC(25,8)) as quantity,
 	   cast(isnull(sum(b.costtotal),0) as NUMERIC(25,8)) as costtotal,
           ' ' AS [ClientName],
           ' ' AS [Phone_number],
           0.0000 AS [NOSendQTY],
           cast(0 as NUMERIC(25,8)) as RetailTotal, a.Factory,a.IsSplit,  cast(0 as NUMERIC(25,8)) as taxtotal,
           a.[PermitCode],0.0 as cljg,0.0 as clquantity,0.0 as cltotal, 0.0 as ZTquantity, 0.0 as ZTtaxtotal
    from vw_c_products a 
    left join (select * from vw_productbalance where Y_id = @nY_ID) pb on a.product_id = pb.p_id 
     LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
     ON     ( (@nUnitMode=1 and (pri.p_id=a.product_id and a.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=a.product_id and a.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=a.product_id and a.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=a.product_id and a.unit4_id=pri.u_id))
            ) 
    left join	(SELECT dbo.products.product_id,
	         ISNULL(SUM(s.quantity), 0) AS quantity, 
	         ISNULL(SUM(s.costtotal), 0) AS costtotal
		 FROM vw_c_storedxini s INNER JOIN
	         dbo.products ON s.p_id = dbo.products.product_id
		 where s.c_id=@nC_ID and dbo.products.deleted<>1  and s.commissionflag=@nCommissionflag
		 AND (@ProductType = -1 OR IsSplit = @ProductType) 
		 AND (@ClientTable=0  or (s.c_id in (select [id] from #Clienttable)))
 		 AND (@CompanyTable=0 or (s.Y_id in (select [id] from #Companytable)))
                 AND (s.YClass_id like @nYClassID)
		 GROUP BY dbo.products.product_id
		 ) as b 
    on (a.product_id=b.product_id)
    where left(a.class_id,len(@szParid))=@szParid and a.child_number=0 and a.deleted<>1  and a.product_id<>1
    AND (@ProductType = -1 OR IsSplit = @ProductType) 
    group by a.product_id,a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.modal,a.makearea,
             a.rate2,a.rate3,a.rate4,pri.unitname,a.[costmethod],a.Comment,a.[pinyin],a.[medtype],a.[Taxrate],a.[otcflag],
             a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.[PackStd], pb.[E_Name],pb.emp_id,pb.C_Name,
               Pri.retailprice,pri.recprice,pri.price1,  pri.price2,    pri.price3,   pri.price4     ,pri.gpprice,
               pri.glprice, pri.specialprice, a.Factory,a.IsSplit,a.[PermitCode] 
    order by a.product_id
   end
end
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
return 0
GO
