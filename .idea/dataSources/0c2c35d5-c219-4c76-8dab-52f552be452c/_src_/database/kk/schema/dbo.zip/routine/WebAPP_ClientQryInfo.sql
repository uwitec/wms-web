




/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_ClientQryInfo]
(
    @weixinno	varchar(50),	
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
select @chvErrMsg=''

declare @c_id int,@name varchar(200)
select @c_id=C_ID from ClientsBind where WeiXinNo=@weixinno

if isnull(@c_id,0)=0
begin
	select '没有找到绑定往来单位信息' as outMsg,-1 as reCode
	return -1
end
select @name=name from clients where client_id=@c_id

select isnull(sum(credit_total),0) as credit_total,
isnull(sum(artotal-aptotal),0) as araptotal,
isnull(sum(pre_artotal-pre_aptotal),0) as prearaptotal,
isnull(@name,'') as name
from clientsbalance where c_id=@c_id

return 0
GO
