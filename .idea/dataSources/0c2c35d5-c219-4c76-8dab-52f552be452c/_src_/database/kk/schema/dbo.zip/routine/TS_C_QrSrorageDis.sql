



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
库存分布
********************************************/
CREATE PROCEDURE TS_C_QrSrorageDis
(	@szParID	  VARCHAR(30)='000000',	
	@szListFlag	CHAR(1)='L',
	@nE_id		  INT=0,
	@szStorageId	  varchar(8000)='''000000''',/*'000000'所有仓库*/
        @nYClassid                 varchar(100)='',
        @nloginEID               int=0,
        @nQrMode     	         int=0,  /*3 时不判断授权*/
        @isstop                  int=0
)
AS
/*Params Ini begin*/
if @szParID is null  SET @szParID = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nE_id is null  SET @nE_id = 0
if @szStorageId is null  SET @szStorageId = '''000000'''
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @nQrMode is null  SET @nQrMode = 0




/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000),@nP_ID int, @nS_id INT, @dQty NUMERIC(25,8),@dTotal NUMERIC(25,8), @szS_ID varchar(30),@ny_id int, @nSelOtherPos int
  
 select @nSelOtherPos = CAST(sysvalue as int) from sysconfigtmp where [sysname]  = 'SelOtherPos'
 if @nSelOtherPos is null set @nSelOtherPos = 0 
 if @nSelOtherPos = 1 set @nQrMode = 3
    
if @nYClassid = ''
   Set @ny_id=2
else
  select @ny_id=company_id  from company where class_id= @nYClassid 
  

CREATE TABLE #product
(	PRODUCT_ID   INT,
    PCLASS_ID varchar(30)
 )

CREATE TABLE #storages
(	[ID] INT,
	CLASSID VARCHAR(30)
)

CREATE TABLE #storehouse
(	P_ID INT,
	S_ID INT,
	szS_ID VARCHAR(30),
	QUANTITY NUMERIC(25,8),
  Total    NUMERIC(25,8))
/*取得商品*/
  IF @szListFlag='L'
  BEGIN
  	INSERT #product (product_id,PCLASS_ID)
  	SELECT  product_id,class_id
  	FROM products
  	/*WHERE parent_id=@szParid AND deleted<>1  AND product_id<>1*/
  	WHERE parent_id=@szParid AND ((@isstop=0 and  [Deleted]<>1) or (@isstop>0 and  [Deleted]=0)) AND product_id<>1   
  END
  IF @szListFlag='P'
  BEGIN
  	INSERT #product (product_id,PCLASS_ID)
  	SELECT  product_id,class_id
  	FROM products
  	/*WHERE class_id like (@szParid+'%') AND deleted<>1  AND child_number=0*/
  	WHERE class_id like (@szParid+'%') AND ((@isstop=0 and  [Deleted]<>1) or (@isstop>0 and  [Deleted]=0))  AND child_number=0
  END
  IF @szListFlag='A'
  BEGIN
  	INSERT #product (product_id,PCLASS_ID)
  	SELECT  product_id,class_id
  	FROM products
  	/*WHERE  deleted<>1  AND child_number=0 AND product_id<>1*/
  	WHERE  ((@isstop=0 and  [Deleted]<>1) or (@isstop>0 and  [Deleted]=0))   AND child_number=0 AND product_id<>1
  END
  IF @szListFlag='S'/*single单个商品*/
  BEGIN
  	INSERT #product (product_id,PCLASS_ID)
  	SELECT  product_id,class_id
  	FROM products
  	/*WHERE  product_id=@szParID*/
        WHERE  product_id=@szParID and	((@isstop=0 and  [Deleted]<>1) or (@isstop>0 and  [Deleted]=0))
  END


 CREATE TABLE #LastClient
(	[Product_ID] INT,
	[Class_ID] VARCHAR(30),
  [ClientName] VARCHAR(180),
  [Phone_number] VARCHAR(180),
  [RecPrice] NUMERIC(25,8)
)

insert into #lastclient(product_id,class_id,recprice,clientname,phone_number)
SELECT  P.[Product_ID] , P.[Class_ID],pd.buyprice,
   c.[name] AS [ClientName],c.phone_number 
   FROM  products p ,
	(select a.* from buypricehis a ,
		(select p_id,max(modifydate) as modifydate from buypricehis group by p_id) b
	 where a.p_id=b.p_id and a.modifydate=b.modifydate 
	)  as PD, Clients C
   WHERE P.[Child_Number]=0 AND p.deleted<>1  and pd.c_id=c.client_id and  pd.p_id=p.product_id


/*取得仓库*/
	IF @nQrMode = 3
	BEGIN
	    SET @SQLScript = 
	        'INSERT #storages([ID],classid)
				SELECT Storage_id,class_id
		 		FROM vw_storage
				WHERE deleted=0 AND child_number=0 and yclass_id <> ''000001'''
	    
	    IF @szStorageId <> '''000000'''
	        SET @SQLScript = @SQLScript + ' and Class_Id in(' + @szStorageId + 
	            ')'
	    
	    SET @SQLScript = @SQLScript + ' ORDER BY class_id'
	    EXEC (@SQLScript)
	END
	ELSE
	BEGIN
	    SET @SQLScript = 
	        'INSERT #storages([ID],classid)
				SELECT Storage_id,class_id
		 		FROM vw_storage
				WHERE deleted=0 AND child_number=0 '
	    
	    IF @szStorageId <> '''000000'''
	        SET @SQLScript = @SQLScript + ' and Class_Id in(' + @szStorageId + 
	            ')'
	    
	    SET @SQLScript = @SQLScript + ' ORDER BY class_id'
	    EXEC (@SQLScript)
	END
	
  IF @szListFlag='L'
  BEGIN
    declare @nlen int
    select @nlen = LEN(PCLASS_ID) from #product
  	INSERT #storehouse (p_id,s_id,quantity, [total], szS_ID)
  	SELECT p.product_id,st.[ID],SUM(vs.quantity) AS quantity, SUM(vs.total) as total, st.classID
  	FROM #product p, #storages st,
    (SELECT p.[Product_ID], vs.[s_id],ISNULL(SUM(vs.[Quantity]), 0) AS [Quantity], SUM(vs.costtotal) as total  
    FROM #product p
    LEFT JOIN 
     (select * from VW_C_storehouse where (@nYClassID='' or YClass_id like @nYClassID+'%')
      /*AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))*/

     ) vs ON p.PCLASS_ID = LEFT(vs.PClassID,@nlen)/*vs.[pclassid] LIKE p.[class_id]+'%'*/
    GROUP BY p.[Product_ID], vs.[s_id]) vs
   	WHERE vs.s_id=st.[ID] AND vs.Product_ID=p.product_id
  	GROUP BY p.product_id,st.[ID],st.classID
  END
  ELSE 
  BEGIN
  	INSERT #storehouse (p_id,s_id,quantity, [total], szS_ID)
  	SELECT p.product_id,st.[ID],SUM(vs.quantity) AS quantity,SUM(vs.costtotal) as total,st.classID
  	FROM #product p, #storages st,
        (select * from VW_C_storehouse where (@nYClassID='' or YClass_id like @nYClassID+'%')
        /*AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))*/
        )vs

   	WHERE vs.s_id=st.[ID] AND vs.P_ID=p.product_id
  	GROUP BY p.product_id,st.[ID],st.classID
  END

   declare @pricey_id int     /*价格表对应的机构ID*/
   declare @nqty NUMERIC(25,8)      /*--合计数量*/
   declare @ntotal NUMERIC(25,8)    /*--合计金额*/
   set @pricey_id = 0
   set @nqty = 0
   set @ntotal = 0
   
	DECLARE stockcur CURSOR FOR
	SELECT classid FROM #storages
	OPEN stockcur
	FETCH NEXT FROM stockcur INTO @szS_ID
	WHILE @@FETCH_STATUS=0
	BEGIN
        SET @SQLScript =  'ALTER TABLE #product ADD A'+@szS_ID+'RP'+' NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES' /*零售价*/
		EXEC(@SQLScript)	
	
		SET @SQLScript =  'ALTER TABLE #product ADD A'+@szS_ID+ ' NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES'
		EXEC (@SQLScript)

		SET @SQLScript =  'ALTER TABLE #product ADD A'+@szS_ID+'T'+' NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES'
		EXEC (@SQLScript)
		/*-----------------处理零售价---begin-----------------------add by luowei 2012-12-04*/
		select @pricey_id =Y_ID  from storages where class_id = @szS_ID 
		      
	    if exists(select 1 from company c,storages s where c.company_id = s.Y_ID and s.class_id = @szS_ID and c.swarajPrice = 1)  /*判断是否启用独立物价  */
		  set @SQLScript = 'update #product set A'+@szS_ID+'RP'+'= retailprice from #product,PosPrice'
		  +' WHERE product_id=p_id and unittype = 1 and Y_ID ='+cast(@pricey_id as varchar)
		else
		  set @SQLScript = 'update #product set A'+@szS_ID+'RP'+'= retailprice from #product,Price'
		  +' WHERE product_id=p_id and unittype = 1' 
		  
		EXEC(@SQLScript)  
    
    /*------------------处理零售价------end------------------------add by luowei 2012-12-04*/
    
    /*-----------------处理数量与金额---------begin-------modify by luowei 2012-12-04*/
    
		SET @SQLScript='UPDATE #product SET A'+@szS_ID+'=isnull(quantity,0) from #product,#storehouse'
      +' WHERE product_id=p_id and szS_ID ='''+CAST(@szS_ID as varchar)+''''
    EXEC(@SQLScript)

		SET @SQLScript='UPDATE #product SET A'+@szS_ID+'T'+'=isnull(Total,0) from #product,#storehouse'
      +' WHERE product_id=p_id and szS_ID='''+CAST(@szS_ID as varchar)+''''
    EXEC(@SQLScript)
        
    /*-----------------处理数量与金额---------end-------modify by luowei 2012-12-04 */
		
		FETCH NEXT FROM stockcur INTO @szS_ID
	END
	CLOSE stockcur
	DEALLOCATE stockcur
	
	/*-------------------处理合计数量与合计金额--------------begin-------------------------*/
	EXEC ('ALTER TABLE #product ADD A000000  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES')
	EXEC ('ALTER TABLE #product ADD A000000T NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES')
	/*EXEC ('ALTER TABLE #product DROP COLUMN PCLASS_ID ')  ---删除class_id 列（sql2000中不兼容该写法，故在代码中控制）*/
	
	DECLARE sumcur CURSOR FOR
	SELECT classid FROM #storages
	OPEN sumcur
	FETCH NEXT FROM sumcur INTO @szS_ID
	WHILE @@FETCH_STATUS=0
	begin
	  SET @SQLScript='UPDATE #product SET [A000000]=[A000000]+A'+@szS_ID+''
    EXEC(@SQLScript)

		SET @SQLScript='UPDATE #product SET [A000000T]=[A000000T]+A'+@szS_ID+'T'
    EXEC(@SQLScript)
    
    FETCH NEXT FROM sumcur INTO @szS_ID
	end
	CLOSE sumcur
	DEALLOCATE sumcur
	/*---------------------处理合计数量与合计金额---------end-------*/
 
	ALTER TABLE #product ADD TempSN VARCHAR(6) NOT NULL DEFAULT('1')
	SET @SQLScript=
	'SELECT p1.TempSN as serialno,p2.class_id, p2.child_number, p2.code, p2.[name],
  p2.standard, p2.makearea, p2.medtype, cast(vp.e_name as varchar(80)) as e_name,cast(vp.C_Name as varchar(80)) as c_name,
        p2.Inputman,p2.InputDate,p2.Custompro1,p2.Custompro2,p2.Custompro3,p2.Custompro4,p2.Custompro5,p1.* , 
  ISNULL(BM.[RecPrice], 0) AS [Recprice], ISNULL(BM.[ClientName] ,'''') AS [ClientName], 
  ISNULL(BM.[Phone_number], '''') AS [Phone_number]
	FROM #product p1
  LEFT JOIN #LastClient BM ON P1.[Product_ID]=BM.[Product_ID] 
  INNER JOIN vw_c_products p2 ON p1.product_id=p2.product_id
  LEFT JOIN (select * from vw_productbalance Where y_id = ' + Cast(@ny_id as varchar(6)) + ') vp ON p1.product_id=vp.p_id'
  
    PRINT @SQLScript
	EXEC(@SQLScript)

	DROP TABLE #product
	DROP TABLE #storages
	DROP TABLE #storehouse
  DROP TABLE #LastClient
  
  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
