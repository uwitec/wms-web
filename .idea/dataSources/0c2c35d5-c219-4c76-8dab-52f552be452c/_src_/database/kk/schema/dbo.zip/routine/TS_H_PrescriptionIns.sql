
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-15*/
/* Description:	插入处方笺*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_PrescriptionIns]
	@BillNo			varchar(60),
	@DeptName		varchar(50),
	@Doctor_ID		int,
	@Doctor			varchar(80),
	@Reg_ID			int,
	@BillDate		datetime,
	@Diagnose		varchar(500),
	@BedNo			varchar(10),
	@Patient_ID		int,
	@Symptom		varchar(50),
	@Age			int
AS
BEGIN
	SET NOCOUNT ON;
	
	if exists(select * from prescriptions where billno = @billNo)
	begin
		raiserror('单号重复！', 16, 1)
		return 0
	end
	
	declare @ID int

	insert into Prescriptions(
		[billNo],
		[DeptName],
		[doctor_id],
		[doctor],
		[Reg_ID],
		[billDate],
		[Diagnose],
		[bedNo],
		[Patient_ID],
		[Symptom],
		[Age]
	) values(
		@BillNo,
		@DeptName,
		@Doctor_ID,
		@Doctor,
		@Reg_ID,
		@BillDate,
		@Diagnose,
		@BedNo,
		@Patient_ID,
		@Symptom,
		@Age
	)
	
	set @ID = @@Identity
	
	update registered set presState = 1 where reg_id = @Reg_id
	
	Return @ID
END
GO
