
CREATE	PROCEDURE TS_M_FindBill
( @W_ID      INT
)
/*with encryption*/
AS
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000) 
    SELECT @SQLScript='SELECT DISTINCT b.[billid], b.[billtype], b.[billdate], b.[billstates],
      b.[billnumber], b.[inputman], b.[auditman], b.[note], b.[summary], b.[quantity],
      b.[ysmoney], b.[ssmoney], b.[araptotal], b.[taxrate], b.[auditdate],
      CASE WHEN b.[billtype] IN (44, 45) THEN b.[ssname] ELSE b.[cname] END AS [cname],
  		b.[ename] AS [employeename],
   		b.[auditmanname],
   		b.[inputmanname],
   		b.[aname] AS [accountname],
   		b.[departmentname],
   		b.[regionname],b.Y_Id, b.B_CustomName1, b.B_CustomName2, b.B_CustomName3, 
   		b.skdate, b.transflag, b.inputman, b.auditman, b.invoicetype 
     	FROM VW_C_BillIDX b LEFT JOIN 
      (SELECT DISTINCT bm.[Bill_ID], p.[Class_ID] FROM BuyManageBill bm, Products p
       WHERE bm.[P_ID]=p.[Product_ID]
       UNION
      SELECT DISTINCT sm.[Bill_ID], p.[Class_ID] FROM SaleManageBill sm, Products p
       WHERE sm.[P_ID]=p.[Product_ID]
       UNION
      SELECT DISTINCT st.[Bill_ID], p.[Class_ID] FROM StoreManageBill st, Products p
       WHERE st.[P_ID]=p.[Product_ID]
       UNION
      SELECT DISTINCT gc.[Bill_ID], p.[Class_ID] FROM GoodsCheckBill gc, Products p
       WHERE gc.[P_ID]=p.[Product_ID]
       UNION
      SELECT DISTINCT tm.[Bill_ID], p.[Class_ID] FROM TranManagebill tm, Products p
       WHERE tm.[P_ID]=p.[Product_ID]
      ) pd ON b.[BillID]=pd.[Bill_ID] '
      + ' WHERE b.[billid] IN (SELECT BillID FROM WarrantBill WHERE W_ID='
      + cast(@W_ID as varchar(1000)) +' )'
      
/*PRINT @SQLScript*/
  EXEC (@SQLScript)
  GOTO SUCCEE
SUCCEE:
  RETURN 0
GO
