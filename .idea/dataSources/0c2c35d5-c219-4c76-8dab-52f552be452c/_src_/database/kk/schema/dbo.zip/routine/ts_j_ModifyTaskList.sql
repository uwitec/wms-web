/************************************************************

--功能: 
--创建人：
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_ModifyTaskList]

AS 
  
declare @nY_ID int
exec ts_getsysvalue 'Y_ID',@nY_ID out
  
  
begin tran  
       /*处理促促销单停用begin(只考虑文件方式，在线方式单独处理)*/
     if exists(select 1 from tasklistdtsin where billtype in (180,181,182,183) and billstates = 5 and tranType = 0)
     begin
       update cxidx set billstates = 5 
         where guid in (select billguid from tasklistdtsin where billtype in (180,181,182,183) and billstates = 5)
       
       delete tasklistDtsIN where billguid not in (select guid from cxidx)  
       
       update tasklistdtsin set tranType = -1 from tasklistdtsin t1, tasklist t2 where t1.billtype = t2.billtype and 
              t1.billguid = t2.billguid and t2.tranType = 1 and t2.billstates = 5
              
       insert into tasklist(billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates)
	     select billid, billtype, GETDATE(), 0, 0, 3, posid, DY_ID, Y_ID, billguid, 1, billstates 
	      from  tasklistdtsin
	      where billtype in (180,181,182,183) and billstates = 5 and tranType = 0 
	      
	   /*多级机构，继续下传   */
	   update tasklistdtsin set tranType = -2 from tasklistdtsin t1, tasklist t2 where t1.billtype = t2.billtype and 
              t1.billguid = t2.billguid and t2.tranType = 0 and t2.billstates = 5

	   insert into tasklist(billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates)
	     select billid, billtype, GETDATE(), 0, 0, 1, posid, DY_ID, Y_ID, billguid, 0, billstates 
	      from  tasklistdtsin
	      where billtype in (180,181,182,183) and billstates = 5 and tranType <>-2 and DY_ID <> @nY_ID   
     end
commit tran

truncate table TaskListUpDtsIN
GO
