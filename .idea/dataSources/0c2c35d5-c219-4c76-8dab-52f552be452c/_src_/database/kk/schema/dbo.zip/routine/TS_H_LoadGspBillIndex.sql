
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-4*/
/* Description:	读取Gsp单据主表*/
/* =============================================*/
CREATE PROCEDURE TS_H_LoadGspBillIndex 
	@billtype int = 0,	/* 单据类型*/
	@billid int = 0,	/* 单据编号*/
	@nRet int output	/* 返回值*/
AS
BEGIN
	SET NOCOUNT ON;
	/* 直调采购单读取直调订单*/
    if @billtype in (108)
	begin
		SELECT   0 AS Gspbillid, 515 AS billtype, '' AS billnumber, Y_ID, c_id, GETDATE() AS billdate, 0 AS inputman, 0 AS auditman1, 
                '1900-1-1' AS audittime1, 0 AS auditman2, '1900-1-1' AS audittime2, auditman AS upauditman1, 0 AS upauditman2, 
                traffictype AS traffictype, '' AS traffictools, 0 AS traffictime, '' AS tempcontrol, '' AS spectrafficprove, '' AS sendaddress, 
                sendtime AS sendtime, trafficCompany AS trafficCompany, '' AS tempcontrolmode, 0 AS WholeQty, 0 AS PartQty, 
                ysmoney AS discountTotal, ysmoney AS InvoiceTotal, billid AS Ybillid, billtype AS Ybilltype, Guid AS Yguid, 
                '' AS b_CustomName1, '' AS b_CustomName2, '' AS b_CustomName3, '' AS b_CustomName4, '' AS b_CustomName5, 
                10 AS billstates, sin_id AS s_id, Yname AS Y_NAME, cname AS C_NAME, inputmanname AS INPUTER, '' AS AUDITER1, 
                '' AS AUDITER2, auditmanname AS UPAUDITER1, '' AS UPAUDITER2, '' AS S_NAME, ysmoney AS TaxTotal, I.taxrate,
                ename AS YE_NAME, I.e_id AS YE_ID, I.billnumber AS YBILLNUMBER, '' AS note,
                CASE I.invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
                0 as financeAudit,'' as financeAuditDate,'' as FinanceAuditer, '' as billstateText,
		'' as FollowNumber,'1900-01-01' as TicketDate, I.BalanceMode,0 as inbags,'' as sendcname,0 as SendC_Id  
		FROM      dbo.vw_c_orderidx AS I WHERE billid = @billid
	end
	ELSE
	/* 采购收货单读取采购订单*/
	if @billtype in (22)
	begin
		SELECT   0 AS Gspbillid, 511 AS billtype, '' AS billnumber, Y_ID, c_id, GETDATE() AS billdate, 0 AS inputman, 0 AS auditman1, 
                '1900-1-1' AS audittime1, 0 AS auditman2, CONVERT(varchar(100), GETDATE(),23) AS audittime2, auditman AS upauditman1, 0 AS upauditman2, 
                traffictype AS traffictype, '' AS traffictools, 0 AS traffictime, '' AS tempcontrol, '' AS spectrafficprove, '' AS sendaddress, 
                sendtime AS sendtime, trafficCompany AS trafficCompany, '' AS tempcontrolmode, 0 AS WholeQty, 0 AS PartQty, 
                ysmoney AS discountTotal, ysmoney AS InvoiceTotal, billid AS Ybillid, billtype AS Ybilltype, Guid AS Yguid, 
                '' AS b_CustomName1, '' AS b_CustomName2, '' AS b_CustomName3, '' AS b_CustomName4, '' AS b_CustomName5, 
                10 AS billstates, 0 AS s_id, Yname AS Y_NAME, cname AS C_NAME, inputmanname AS INPUTER, '' AS AUDITER1, 
                '' AS AUDITER2, auditmanname AS UPAUDITER1, '' AS UPAUDITER2, '' AS S_NAME, ysmoney AS TaxTotal, I.taxrate,
                ename AS YE_NAME, I.e_id AS YE_ID, I.billnumber AS YBILLNUMBER, I.note AS note,
                CASE I.invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
                0 as financeAudit,'' as financeAuditDate,'' as FinanceAuditer, '' as billstateText,
		'' as FollowNumber,CONVERT(varchar(100), GETDATE(),23) as TicketDate, I.BalanceMode,0 as inbags,'' as sendcname,0 as SendC_Id  
		FROM      dbo.vw_c_orderidx AS I WHERE billid = @billid
	end
	ELSE
	/* 退出申请单读取原销售/采购单/机构收货单/自营店收货单*/
	if @billtype in (10, 20,160,162)
	begin
		SELECT   0 AS Gspbillid, 511 AS billtype, '' AS billnumber, Y_ID, c_id, GETDATE() AS billdate, 0 AS inputman, 0 AS auditman1, 
                '1900-1-1' AS audittime1, 0 AS auditman2, '1900-1-1' AS audittime2, auditman AS upauditman1, 0 AS upauditman2, 
                '' AS traffictype, ' ' AS traffictools, 0 AS traffictime, ' ' AS tempcontrol, ' ' AS spectrafficprove, ' ' AS sendaddress, 
                0 AS sendtime, '' AS trafficCompany, '' AS tempcontrolmode, 0 AS WholeQty, 0 AS PartQty, 
                ysmoney AS discountTotal, ysmoney AS InvoiceTotal, billid AS Ybillid, billtype AS Ybilltype, Guid AS Yguid, 
                '' AS b_CustomName1, '' AS b_CustomName2, '' AS b_CustomName3, '' AS b_CustomName4, '' AS b_CustomName5, 
                10 AS billstates, sin_id AS s_id, Yname AS Y_NAME, cname AS C_NAME, '' AS INPUTER, '' AS AUDITER1, 
                '' AS AUDITER2, auditmanname AS UPAUDITER1, ' ' AS UPAUDITER2, '' AS S_NAME, ysmoney AS TaxTotal, I.taxrate,
                ename AS YE_NAME, I.e_id AS YE_ID, I.billnumber AS YBILLNUMBER, '' AS note,
                CASE I.invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
                0 as financeAudit,'' as financeAuditDate,'' as FinanceAuditer, ''as billstateText,
		FollowNumber, TicketDate, I.BalanceMode,0 as inbags,sendcname,SendC_Id 
		FROM      dbo.vw_c_billidx AS I WHERE billid = @billid
	end
	ELSE
	IF @billtype in (523, 525)
	BEGIN
		SELECT  Gspbillid, billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
                upauditman1, upauditman2, traffictype, traffictools, traffictime, tempcontrol, spectrafficprove, sendaddress, sendtime, 
                trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, taxTotal, Ybillid, Ybilltype, Yguid, 
                b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, Y_NAME, 
                C_NAME, INPUTER, AUDITER1, AUDITER2, UPAUDITER1, UPAUDITER2, S_NAME, TaxTotal, TaxRate, 
				INPUTER AS YE_NAME, inputman AS YE_ID,billnumber as  YBILLNUMBER, Note, 
				CASE invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
				0 as financeAudit,'' as financeAuditDate,'' as FinanceAuditer, billstateText,
				FollowNumber, TicketDate, BalanceMode,0 as inbags, sendcname,SendC_Id 
		FROM      dbo.VW_GSPBILLIDX WHERE GSPBILLID = @billid	
	END
	else
	if  @billtype in (563)
	begin
	   SELECT   a.Gspbillid, a.billtype, a.billnumber, a.Y_id, a.c_id, a.billdate, a.inputman, a.auditman1, a.audittime1,
	            a.auditman2, a.audittime2, a.upauditman1, a.upauditman2, a.traffictype, a.traffictools, a.traffictime,
	            a.tempcontrol, a.spectrafficprove, a.sendaddress, a.sendtime, 
                a.trafficCompany, a.tempcontrolmode, a.WholeQty, a.PartQty, a.discountTotal, a.taxTotal, a.Ybillid, 
                a.Ybilltype, a.Yguid, 
                a.b_CustomName1, a.b_CustomName2, a.b_CustomName3, a.b_CustomName4, a.b_CustomName5, a.billstates, a.s_id, Y_NAME, 
                a.C_NAME, INPUTER, AUDITER1, AUDITER2, UPAUDITER1, UPAUDITER2, S_NAME, a.TaxTotal, TaxRate, 
				e.name as YE_NAME,e.emp_id as  YE_ID, b.BillNumber as YBILLNUMBER, a.Note,
			    CASE invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
				a.financeAudit,a.financeAuditDate,FinanceAuditer, billstateText,
				a.FollowNumber, a.TicketDate, a.BalanceMode,0 as inbags,SendCname, a.SendC_Id 
		FROM      dbo.VW_GSPBILLIDX  a left join 
		         (select * from gspbillidx where billtype=523) b  on a.Yguid=b.Yguid
		         left join employees e on b.InputMan=e.emp_id
		  WHERE a.GSPBILLID = @billid
		              
	end
	ELSE
	BEGIN
		SELECT   Gspbillid, billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
                upauditman1, upauditman2, traffictype, traffictools, traffictime, tempcontrol, spectrafficprove, sendaddress, 
                CASE WHEN sendtime <10 THEN '1900-01-01' ELSE sendtime END sendtime, 
                trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, taxTotal, Ybillid, Ybilltype, Yguid, 
                b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, Y_NAME, 
                C_NAME, INPUTER, AUDITER1, AUDITER2, UPAUDITER1, UPAUDITER2, S_NAME, TaxTotal, TaxRate, 
				YE_NAME, YE_ID, YBILLNUMBER, Note,
			    CASE invoice WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
				financeAudit,financeAuditDate,FinanceAuditer, billstateText,
				FollowNumber, TicketDate, BalanceMode,inbags,sendcname,SendC_Id
		FROM      dbo.VW_GSPBILLIDX WHERE GSPBILLID = @billid
	END

	SET @nRet = 0
END
GO
