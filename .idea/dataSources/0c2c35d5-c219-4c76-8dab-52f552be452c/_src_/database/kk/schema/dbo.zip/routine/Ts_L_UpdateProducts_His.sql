
CREATE	  PROCEDURE [Ts_L_UpdateProducts_His]
		(@product_id	[int] OUTPUT,
		@serial_number 	[varchar](26),
		@name	[varchar](80),
		@alias 	[varchar](80),
		@standard	[varchar](100),
		@modal 	[varchar](20),
		@permitcode	[varchar](50),
		@trademark	[varchar](50),
		@makearea	[varchar](60),
		@unit1_id	[smallint],
		@unit2_id	[smallint],
		@unit3_id	[smallint],
		@unit4_id	[smallint],
		@rate2 	NUMERIC(25,8),
		@rate3 	NUMERIC(25,8),
		@rate4 	NUMERIC(25,8),
		@validmonth	[smallint],
		@validday	[smallint],
		@comment	[varchar](250),
		@pinyin	[varchar](80),
		@firstcheck	[bit],
		@otcflag	[char](1),
		@gspflag	[char](2),
		@medtype	int,
		@costmethod	[char](1),
		@engName	[varchar](50),
		@chemName	[varChar](50),
		@latinName	[varChar](50),
		@deduct	NUMERIC(25,8),
		@OtcType	[tinyint],
		@gmp		[bit],
		@gross		NUMERIC(25,8),
		@MaintainType	[tinyint],
		@maintainDay	[int],
		@range		[int],
		@packStd	[varchar](60),
		@storageCon	[varchar](60),
		@taxrate	NUMERIC(25,8),
		@supplier_id	[int],
		@Emp_id	[int],
		@PosYhDay	[int],
		@ifIntegral [bit],
		@integral   [int],
		@Factory    varchar(80),
		@tc1   NUMERIC(25,8),
		@tc2   NUMERIC(25,8),
		@tcmoney NUMERIC(25,8),
		@TcCost NUMERIC(25,8),
		@BulidNo	[varchar](500),
		@RegisterNo	[varchar](500),
		@PrintClass int,
		@WholeUnit_id int,
		@deleted  int,
		@Inputdate varchar(50),
		@Inputman  varchar(50),
		@Custompro1 Varchar(100),
		@Custompro2 varchar(100),
		@Custompro3 varchar(100),
		@Custompro4 varchar(100),
		@Custompro5 varchar(100),
		@Locid      int,
		@NoneQuantity NUMERIC(25,8),/*断货数量参数*/
		@FactoryC_ID int,
		@SR_id       int,
		@nY_id       int,  
		@drate       NUMERIC(25,8),
		@basicMedication NUMERIC(25,8), /*基本药物  */
		@SR2_id      int,
        @Wholeloc    int,
        @SingleLoc   int,
        @protectprice int,
        @RegistervalidDate datetime,  /*--注册证号有效期 add by luowei 2013-03-26*/
        @PerCodevalidDate datetime, /*--批准文号有效期 add by luowei 2013-03-26*/
        @TransToYJ    [char](1),
		@ControlYard  [char](1),
		@ifdiscount  char(1),
		@pack varchar(100),
		@isCheckReport bit,
        @GMPNo varchar(120),
        @GMPValiddate  datetime,
	    @Kcl INT,
	    @Kcldw INT,
	    @Khsbl NUMERIC(25,8),
	    @Kcljg NUMERIC(25,8),
	    @incRate2 NUMERIC(25,8),
	    @incRate3 NUMERIC(25,8),
	    @isCheckLT BIT,
	    @StoreCondition INT,
	    @IsValidP int, /*zfl贵细药品*/
	    @IfZYCheck int,/*中药*/
	    @IsClientdiscount int, /*折扣 往来单位*/
	    @commodityCode varchar(100),
	    @fztaxrate     NUMERIC(25,8),/*辅助税率*/
        @taxrateflcode varchar(100), /*税务类型编号*/
        @Z_ZNumber     varchar(100),  /*证照编号*/
        @Z_ZBillDate   datetime, /*证照期限*/
        @AloneLocation INT,
        @LocationRequirement INT,
        @DefaultBuyUnit INT,
        @DefaultSaleUnit INT,
        @SaleUnitMultiple INT  		
		)
		AS

		SET @product_id = ABS(@product_id)

		/* 判断是否存在未处理申请修改*/
		IF EXISTS(SELECT * FROM BaseInfoHistory WHERE BaseInfoType = 'P' AND BaseInfo_ID = @product_id AND Status = 0)
		BEGIN
			RAISERROR ('本商品已提交过修改申请，请等待处理后再次提交！', 16, 1)
			set @product_id = -@product_id
			RETURN -50
		END

		SELECT * 
		INTO #TP
		FROM products
		WHERE product_id = @product_id

		UPDATE #TP 
		SET  
		[serial_number]	 = @serial_number,
		[name]  = @name,
		[alias]	 = @alias,
		[standard]	 = @standard,
		[modal]	 = @modal,
		[permitcode]	 = @permitcode,
		[trademark]	 = @trademark,
		[makearea]	 = @makearea,
		[unit1_id]	 = @unit1_id,
		[unit2_id]	 = @unit2_id,
		[unit3_id]	 = @unit3_id,
		[unit4_id]	 = @unit4_id,
		[rate2]	 = @rate2,
		[rate3]	 = @rate3,
		[rate4]	 = @rate4,
		[validmonth]	 = @validmonth,
		[validday]	 = @validday,
		[comment]	 = @comment,
		[pinyin]	 = @pinyin,
		[firstcheck]	 = @firstcheck,
		[otcflag]	 = @otcflag,
		[gspflag]	 = @gspflag,
		[medtype]	 = @medtype,
		[costmethod]	 = @costmethod ,
		[engName]	 =@engName,
		[chemName]	 =@chemName,
		[LatinName]	 =@latinName,
		[deduct]	 =@deduct,
		[otcType]	 =@otcType,
		[Gmp]		 =@gmp,
		[Gross]	 =@gross,
		[maintainType]  = @MaintainType,
		[MaintainDay]	 = @maintainDay,
		[r_id]		 = @range,
		packStd	 =@packStd,
		storagecon	 =@storageCon,	
		taxrate		=@taxrate,
		PosYhDay	=@posYhDay,
		ifIntegral=@ifIntegral,
		Integral  =@Integral,
		factory  =@Factory,
		tc1		= @tc1,
		tc2   = @tc2,
		tcmoney=@tcmoney,
		TcCost=@TcCost,
		BulidNo=@BulidNo,
		LastUpDate=@Inputdate,
		LastUpdateman=@Inputman,
		RegisterNo=@RegisterNo,
		PrintClass=@PrintClass,
		WholeUnit_id=@WholeUnit_id,
		Custompro1=@Custompro1, 
		Custompro2=@Custompro2,
		Custompro3=@Custompro3, 
		Custompro4=@Custompro4, 
		Custompro5=@Custompro5,
		NoneQuantity=@NoneQuantity, /*断货数量参数*/
		FactoryC_ID = @FactoryC_ID,
		SR_ID    =@SR_id,
		SR2_ID   =@SR2_id,
		Incrate =@drate,
		basicMedication=@basicMedication,
		protectprice = @protectprice,
		Registervalid = @RegistervalidDate,
		PerCodevalid  = @PerCodevalidDate,
		TransToYJ=@TransToYJ,
		ControlYard=@ControlYard,
		ifdiscount=@ifdiscount,
		pack=@pack,
		[isCheckReport] = @isCheckReport,
		GMPNo=@GMPNo,
		GMPvaliddate=@GMPvaliddate,
		sfcl = @Kcl,
		cldw = @Kcldw,
		hsbl = @Khsbl,
		cljg = @Kcljg,
		incRate2 = @incRate2,
		incRate3 = @incRate3,
		LTTime = @isCheckLT,
		StoreCondition = @StoreCondition,
		IsValuedProduct = @IsValidP,	 
		IfZYCheck=@IfZYCheck,
		IsClientdiscount=@IsClientdiscount,
		commodityCode=@commodityCode,
        fztaxrate =@fztaxrate,    
        taxrateflcode=@taxrateflcode,
        Z_ZNumber=@Z_ZNumber,
        Z_ZBillDate=@Z_ZBillDate,
		AloneLocation=@AloneLocation,
        LocationRequirement=@LocationRequirement,
        DefaultBuyUnit=@DefaultBuyUnit,
        DefaultSaleUnit=@DefaultSaleUnit,
        SaleUnitMultiplex=@SaleUnitMultiple
		WHERE 
		( [product_id]	 = @product_id)
	
		if @@ERROR <> 0
		begin
			set @product_id = -@product_id
			return -1
		end

		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
		SELECT @product_id, 'P', (SELECT * FROM #TP AS products FOR XML AUTO, TYPE, ROOT), 0

		DROP TABLE #TP

		SELECT TOP 0 * 
		INTO #TCCM
		FROM customCategoryMapping

		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@taxrate,@product_id,0,0)
		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@medtype,@product_id,0,0)
		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@range,@product_id,0,0)
		
		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
		SELECT @product_id, 'CCMP', (SELECT * FROM #TCCM AS customCategoryMapping FOR XML AUTO, TYPE, ROOT), 0
		DROP TABLE #TCCM

 		SELECT TOP 0 * 
		INTO #TPB
		FROM Productbalance

		INSERT INTO #TPB(Y_id,P_ID,Locationid,Wholeloc,Singleloc,Supplier_id,Emp_id)
		VALUES(@nY_id,@product_id,@Locid,@Wholeloc,@SingleLoc,@supplier_id,@emp_id)

		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
		SELECT @product_id, 'PB', (SELECT * FROM #TPB AS Productbalance FOR XML AUTO, TYPE, ROOT), 0
		DROP TABLE #TPB

return @product_Id
GO
