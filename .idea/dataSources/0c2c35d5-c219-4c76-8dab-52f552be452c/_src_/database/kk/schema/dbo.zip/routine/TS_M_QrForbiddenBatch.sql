
/*禁采/禁销批次表 */
CREATE PROCEDURE TS_M_QrForbiddenBatch
(
	@fbType		int=0,
	@BeginDate      varchar(50),
	@EndDate	varchar(50),
	@InputMan	int,
	@PName		varchar(100),
	@PermitCode     varchar(100),
	@BatchNo        varchar(20)
	
)
/*with encryption*/
AS
/*Params Ini begin*/
if @fbType is null  SET @fbType = 0
/*Params Ini end*/


DECLARE @SQL varchar(8000)

DECLARE @SQLWhere varchar(8000)
/*BEGIN SQLWHERE*/
SET @SQLWhere = ' and InputTime between '+char(39)+@BeginDate+char(39)+'  and ' +char(39)+@EndDate+char(39)
IF @InputMan<>0  
	SET @SQLWhere = @SQLWhere+' and InputMan='+cast(@InputMan as varchar(20))
IF @PName<>''  
	SET @SQLWhere = @SQLWhere+' and PName like'+char(39)+'%'+@PName+'%'+char(39)
IF @PermitCode<>''  
	SET @SQLWhere = @SQLWhere+' and PermitCode like'+char(39)+'%'+@PermitCode+'%'+char(39)
IF @BatchNo<>''  
	SET @SQLWhere = @SQLWhere+' and BatchNo like'+char(39)+'%'+@BatchNo+'%'+char(39)
/*END SQLWHERE */
SET @SQL='SELECT F.fb_id,ISNULL(F.PermitCode,'''') as PermitCode,ISNULL(F.BatchNo,'''') as BatchNo,
          F.InputMan,F.InputTime,ISNULL(F.note,'''') as note, ISNULL(E.NAME,'''') as InputManName, 
          ISNULL(F.fbType,0) as fbType, F.PName, F.P_ID
          FROM ForbiddenBatch F
	  LEFT JOIN Employees E ON F.InputMan=E.Emp_ID 
	    WHERE 	fbType='+cast(@FBType as varchar(20))
/*PRINT (@SQL + @SQLWhere)*/
EXEC (@SQL + @SQLWhere)
GO
