




/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_VipQryDetail]
(
    @vipid		int,
    @page		int,
    @chvErrMsg		varchar(200) output
)

/*$Encode$--*/

AS
select @chvErrMsg=''
declare @sdate datetime
select @sdate=DATEADD(day ,-92, getdate()) /*只查询三个月内数据*/
select i.auditdate as billdate,/*过账日期*/
case when i.billtype in (10,12) then i.ssmoney else -i.ssmoney end as buyTotal,/*消费金额*/
i.integral as integraltotal,/*本次积分*/
case when i.billtype in (10,12) then i.quantity else -i.quantity end as qty,/*消费数量*/
i.integral as BillIntegralTotal, 
/*v.BillIntegralTotal,--本单积分*/
case  when i.billtype in (10,12) then '购买' else '退货' end saleFlag
from vw_vipcard v
inner join Billidx i on v.vipcardid=i.VIPCardID
left join vipcardtype ct on v.ct_id= ct.ct_id
where v.VIPCardID=@vipid  and i.billstates='0' and i.billtype in (10,11,12,13)
and i.auditdate>=@sdate
return 0
GO
