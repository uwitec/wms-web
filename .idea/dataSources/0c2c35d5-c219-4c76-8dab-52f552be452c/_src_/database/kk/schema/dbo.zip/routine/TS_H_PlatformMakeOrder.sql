
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-8-22*/
/* Description:	云南省基本药物集中采购交易系统接口生成销售订单*/
/* =============================================*/
CREATE PROCEDURE [TS_H_PlatformMakeOrder] 
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @nInput int
	declare @nBillId int
	declare @nFor int
	declare @sNillNum varchar(36)
	
	select @nInput = sysvalue from sysconfig where sysname = 'localinputman' and Y_ID = 2

	/* 获取需处理表*/
	declare curSplit scroll cursor for
	select distinct(ZBSADTLNO) from zb_sa_lst where RETURNFLAG = 0 and ZBSADTLNO not in (select InvoiceNO from orderidx where InvoiceNO<>'')
	open curSplit
	set @nFor = 0
        declare @count int
        set @count = @@cursor_rows
	while @nFor < @count
	begin
		fetch next from curSplit into @sNillNum
     
		/* 写入主表*/
		insert into orderidx([billdate]
		  ,[billnumber]
		  ,[billtype]
		  ,[a_id]
		  ,[c_id]
		  ,[e_id]
		  ,[sout_id]
		  ,[sin_id]
		  ,[auditman]
		  ,[inputman]
		  ,[ysmoney]
		  ,[ssmoney]
		  ,[quantity]
		  ,[taxrate]
		  ,[period]
		  ,[billstates]
		  ,[order_id]
		  ,[department_id]
		  ,[posid]
		  ,[region_id]
		  ,[auditdate]
		  ,[skdate]
		  ,[jsye]
		  ,[jsflag]
		  ,[note]
		  ,[summary]
		  ,[invoice]
		  ,[InvoiceTotal]
		  ,[InvoiceNO]
		  ,[BusinessType]
		  ,[Guid]
		  ,[Y_ID])
		select CONVERT(VARCHAR(10), GETDATE(), 120), '', 14, 0, c.client_id, 0, 0, 0, 0, @nInput, 0, 0, 0, 0, 0, '2'
			, -9, 0, 0, 0, '1900-1-1', '1900-1-1', 0, 0, '[由集中采购交易系统生成]', '', 0, 0, z.ZBSADTLNO, 0, NEWID(), 2
		from zb_sa_lst z 
			inner join clients c on z.ZBCUSTOMNO = c.serial_number
			where z.ZBSADTLNO = @sNillNum
			group by z.ZBSADTLNO, c.client_id
			
		set @nBillId = @@IDENTITY
		
		/* 写入明细*/
		INSERT INTO [OrderBill]
			   ([bill_id]
			   ,[p_id]
			   ,[batchno]
			   ,[quantity]
			   ,[costprice]
			   ,[saleprice]
			   ,[discount]
			   ,[discountprice]
			   ,[totalmoney]
			   ,[taxprice]
			   ,[taxtotal]
			   ,[taxmoney]
			   ,[retailprice]
			   ,[retailtotal]
			   ,[makedate]
			   ,[validdate]
			   ,[qualitystatus]
			   ,[price_id]
			   ,[ss_id]
			   ,[sd_id]
			   ,[location_id]
			   ,[supplier_id]
			   ,[commissionflag]
			   ,[comment]
			   ,[unitid]
			   ,[taxrate]
			   ,[ComeDate]
			   ,[ComeQty]
			   ,[total]
			   ,[RowGuid]
			   ,[RowE_id]
			   ,[Y_ID]
			   ,[comment2])
		select @nBillId, p.product_id, '', z.ZBGOODSQTY, 0, z.ZBUNITPRICE, 1, z.ZBUNITPRICE, z.ZBUNITPRICE * z.ZBGOODSQTY
			, z.ZBUNITPRICE, z.ZBUNITPRICE * z.ZBGOODSQTY, 0, ISNULL(c.retailprice, 0), ISNULL(c.retailprice * z.ZBGOODSQTY, 0)
			, '1900-1-1', '1900-1-1', '合格', 0, 0, 0, 0, 0, 0, '', p.unit1_id, 0, '1900-1-1', 0, ISNULL(z.ZBUNITPRICE * z.ZBGOODSQTY, 0), NEWID(), 0, 2, ''
		from zb_sa_lst z inner join products p
		on z.ZBGOODSNO = p.serial_number
		left join price c on p.product_id = c.p_id and p.unit1_id = c.u_id
		where z.ZBSADTLNO = @sNillNum
		
		/* 更新主表数量、金额*/
		update orderidx set quantity = x.qty, ysmoney = x.total, jsye = x.total
		from (select bill_id, SUM(quantity) as qty, SUM(totalmoney) as total from OrderBill where bill_id = @nBillId group by bill_id) x
		where orderidx.billid = x.bill_id
		set @nFor = @nFor + 1
		
	end
	DEALLOCATE curSplit
END
GO
