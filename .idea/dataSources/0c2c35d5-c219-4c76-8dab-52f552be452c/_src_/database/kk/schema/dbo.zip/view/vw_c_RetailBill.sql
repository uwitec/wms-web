





create   VIEW dbo.vw_c_RetailBill
AS
SELECT dbo.RetailBill.*, 
isnull(storages_2.class_id,'') AS ssclass_id, 
isnull(storages_1.class_id,'') AS sdclass_id, 
isnull(storages_2.name,'') AS ssname, 
isnull(storages_1.name,'') AS sdname,
isnull(u.name,'') as unitname,
isnull(l.loc_name,'') as locname,
isnull(e.name,'') as RowE_name,
isnull(e.class_id,'') as RowEClass_id
FROM dbo.Retailbill LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.Retailbill.sd_id = storages_1.storage_id 
      LEFT OUTER JOIN
      dbo.storages storages_2 ON dbo.Retailbill.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON dbo.Retailbill.unitid = u.unit_id
      LEFT OUTER JOIN
      location l ON dbo.Retailbill.location_id = l.loc_id
      LEFT OUTER JOIN
      employees E ON dbo.Retailbill.RowE_id=E.emp_id
where dbo.Retailbill.aoid=0
GO
