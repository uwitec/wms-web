

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

日期销售报表

********************************************/
CREATE PROCEDURE TS_C_QrSaleByDay
(	@Begindate 	varchar(100),
	@Enddate	varchar(100),
        @nCID           INT,
        @nSID           INT,
        @nEID           INT,
        @InputmanID     INT,
        @nYClassid      varchar(100)='',/*不考虑其他机构的查询*/
        @nloginEID      int=0,
        @nQrMode      int=1 /* 0:本地零售;1:总部数据*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @nQrMode is null  SET @nQrMode = 1
/*Params Ini end*/
/*SET NOCOUNT ON */
 
  /*declare @szClient varchar(50),@szStore varchar(50),@szEid varchar(100)*/
  /*declare @sqlwhere varchar(8000),@szsql varchar(8000)*/
  Declare @sqlEid varchar(100),@sqlCid varchar(100),@sqlinputmanid varchar(100)
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  Declare @nY_id int
  If @nYClassid='' select @nY_id=0  else select @nY_id=(select company_id from company  where class_id=@nYClassid) 
 
  select company_ID into #AuthorizeCompany from AuthorizeCompany(@nloginEID)
   
 /* Declare @Companytabled INTEGER
  create table #Companytable([id] int)
  ------分支机构授权
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end*/
/*---分支机构授权 */
if @nQrMode = 0
begin
  SELECT b.billdate,b.saletotal,(isnull(b.ssmoney,0))ssmoney,cast(0 as NUMERIC(25,8))NonBillMoney,cast(b.costtotal as NUMERIC(25,8))costtotal,b.taxtotal,b.mltotal,cast(0 as NUMERIC(25,8)) ZRTotal, 
         CAST(b.ncount AS NUMERIC(25,8)) ncount,         
         /*(case when b.sendtotal=0 then 0 else cast(b.mltotal/abs(b.Sendtotal) as NUMERIC(25,8))*100 end) mlrate  ,*/
         
         /*采用含税金额，和新报表一致*/
         (case when b.taxtotal=0 then 0 else cast(b.mltotal/abs(b.taxtotal) as NUMERIC(25,8))*100 end) mlrate  ,
         
         isnull(G.BillZR,0) as BillZR, 
         isnull(b.SendQTY,0) as SendQTY,isnull(b.SendCostTotal,0) as SendCostTotal,isnull(b.SendTotal,0) as SendTotal
  FROM
      (SELECT YB.billdate, SUM(YB.ssmoney) AS ssmoney,COUNT(DISTINCT YB.billid) AS ncount,sum(YB.quantity)quantity,
       		cast(ISNULL(SUM(case when YB.billtype =12 then (case AOID when 7 then 0 else YB.totalmoney end) else -(case AOID when 7 then 0 else YB.totalmoney end) end),0) as NUMERIC(25,8))as saletotal,
       		ISNULL(SUM(case when YB.billtype =12 then YB.costprice*YB.quantity else -YB.costprice*YB.quantity end),0) AS costtotal,
       		ISNULL(SUM(case when YB.billtype =12 then (case AOID when 7 then 0 else YB.taxtotal end)  else -(case AOID when 7 then 0 else YB.taxtotal end)  end),0) AS taxtotal,
       		
       		cast(ISNULL(SUM(case when YB.billtype =12 then (case AOID when 7 then 0 else YB.totalmoney/YB.quantity*YB.SendQTY end)  else -(case AOID when 7 then 0 else YB.totalmoney/YB.quantity*YB.SendQTY end) end),0) as NUMERIC(25,8)) AS SendTotal,
       		/*cast(ISNULL(SUM(case when YB.billtype =12 then (YB.SendQTY*YB.totalmoney/YB.quantity-YB.SendCosttotal)  */
       		/*                     else -(YB.SendQTY*YB.totalmoney/YB.quantity-YB.SendCosttotal) end),0) as NUMERIC(25,8)) AS mltotal,*/
       		/*采用含税金额，和新报表一致       		*/
       		cast(ISNULL(SUM(case when YB.billtype =12 then (case AOID when 7 then 0 -YB.costtaxtotal else YB.taxtotal -YB.costtaxtotal end) else -(case AOID when 7 then 0 -YB.costtaxtotal else YB.taxtotal -YB.costtaxtotal end) end),0) as NUMERIC(25,8)) AS mltotal,	                     
       		isnull(SUM(case when YB.billtype =12 then YB.sendQty   else -YB.sendQty end),0) as SendQTY,
       		isnull(sum(case when YB.billtype =12 then YB.costtaxtotal   else -YB.costtaxtotal end),0) as SendCostTotal
       FROM (select b.billdate,b.ssmoney,billid,vp.quantity,b.billtype,vp.totalmoney,vp.costprice,
                    vp.taxtotal, vp.costtaxtotal,AOID, vp.quantity as sendqty,  cast((vp.quantity * vp.costprice)as NUMERIC(25,8)) as SendCosttotal
               from  retailbillidx b
               INNER JOIN company c ON b.Y_ID = c.company_id 
               LEFT JOIN retailbill vp ON b.billid=vp.bill_id
             WHERE  (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and
               (vp.y_id = 0 OR vp.y_id IN (select company_ID from #AuthorizeCompany)) and
               (c.company_id = 0 OR c.company_id IN (select company_ID from #AuthorizeCompany))
               and (@nYClassid='' or c.Class_id like @nYClassid+'%') /*(@nY_id=0 or B.Y_id=@nY_id)*/
               AND B.billdate between @Begindate and @Enddate
               and (@nCID=0 or b.c_id=@nCID)
               and (@nSID=0 or vp.ss_id=@nSID)
               and (@nEID=0 or vp.RowE_id=@nEID)
               and (@InputmanID=0 or b.Inputman=@InputmanID)
               AND billstates=0 and vp.P_Id>0 /* and vp.aoid in (0, 5)*/
            )YB  

       GROUP BY YB.billdate
       )b

  LEFT JOIN 
      (  SELECT YB.billdate,SUM(ISNULL(YB.JdMoney,0)) AS BillZR
         FROM (select billdate,jdmoney from billidx b , AccountDetail AD, company c 
	        where /*(B.Y_id=@nY_id or @nY_id=0)*/
                   b.BillId=AD.billid and
                   (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and
                   (c.company_id = 0 OR c.company_id IN (select company_ID from #AuthorizeCompany))
                   and b.billtype IN (10,11,12,13,112,53,54,16,17,170,210,211)
                   and AD.A_Id=59
                   AND (@nYClassid='' or c.Class_id like @nYClassid+'%')
                   and (@nCID=0 or b.c_id=@nCID)
                   and (@InputmanID=0 or b.Inputman=@InputmanID) 
                   
              )YB
        GROUP BY YB.billdate
      )g ON g.billdate=b.billdate 
	/*-----*/
               ORDER BY b.billdate



   GOTO SUCCEE

end

else begin

  SELECT b.billdate,b.saletotal,(isnull(c.ssmoney,0))ssmoney,isnull(d.NonBillMoney,0)NonBillMoney,cast(b.costtotal as NUMERIC(25,8))costtotal,b.taxtotal,b.mltotal,isnull(f.ZRTotal,0)ZRTotal, 
         CAST(b.ncount AS NUMERIC(25,8)) ncount,
         /*(case when b.sendtotal=0 then 0 else cast(b.mltotal/abs(b.Sendtotal) as NUMERIC(25,8))*100 end) mlrate  ,*/
         /*采用含税金额，和新报表一致*/
         (case when b.taxtotal=0 then 0 else cast(b.mltotal/abs(b.taxtotal) as NUMERIC(25,8))*100 end) mlrate  ,
         
         isnull(G.BillZR,0) as BillZR, 
         isnull(b.SendQTY,0) as SendQTY,isnull(b.SendCostTotal,0) as SendCostTotal,isnull(b.SendTotal,0) as SendTotal
  FROM
      (SELECT YB.billdate, SUM(YB.ssmoney) AS ssmoney,COUNT(DISTINCT YB.billid) AS ncount,sum(YB.quantity)quantity,
       		cast(ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then (case AOID when 7 then 0 else YB.totalmoney end)  else -(case AOID when 7 then 0 else YB.totalmoney end) end),0) as NUMERIC(25,8))as saletotal,
       		ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then YB.costprice*YB.quantity else -YB.costprice*YB.quantity end),0) AS costtotal,
       		ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then (case AOID when 7 then 0 else YB.taxtotal end)  else -(case AOID when 7 then 0 else YB.taxtotal end) end),0) AS taxtotal,
       		cast(ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then (case AOID when 7 then 0 else YB.totalmoney/YB.quantity*YB.SendQTY end)  else -(case AOID when 7 then 0 else YB.totalmoney/YB.quantity*YB.SendQTY end) end),0) as NUMERIC(25,8)) AS SendTotal,
       		/*cast(ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then (YB.SendQTY*YB.totalmoney/YB.quantity-YB.SendCosttotal)  */
       		/*                else -(YB.SendQTY*YB.totalmoney/YB.quantity-YB.SendCosttotal) end),0) as NUMERIC(25,8)) AS mltotal,*/
       		/*采用含税金额，和新报表一致       		*/
       		cast(ISNULL(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then (case AOID when 7 then 0 -YB.costtaxtotal else YB.taxtotal -YB.costtaxtotal end) 
       		                else -(case AOID when 7 then 0 -YB.costtaxtotal else YB.taxtotal -YB.costtaxtotal end) end),0) as NUMERIC(25,8)) AS mltotal,
       		
       		isnull(SUM(case when YB.billtype in (10,12,32,112,53,16,210) then YB.SendQTY   else -YB.SendQTY end),0) as SendQTY,
       		isnull(sum(case when YB.billtype in (10,12,32,112,53,16,210) then YB.costtaxtotal   else -YB.costtaxtotal end),0) as SendCostTotal
       FROM (select b.billdate,b.ssmoney,billid,vp.quantity,b.billtype,vp.totalmoney,vp.costprice,
                    vp.taxtotal, vp.costtaxtotal,AOID, vp.sendQty,Vp.SendCosttotal
               from Salemanagebill vp
               LEFT JOIN  billidx b ON b.billid=vp.bill_id
               INNER JOIN company c ON b.Y_ID = c.company_id
               /*-Wsj-2017-01-17-tfs44998 去掉价格保护,优化报表查询速度*/
              /* LEFT JOIN FilterSalemanagebill(@nloginEID) vp ON b.billid=vp.bill_id*/
              where /*(@nY_id=0 or B.Y_id=@nY_id)*/
               (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and
               (c.company_id = 0 OR c.company_id IN (select company_ID from #AuthorizeCompany)) and
               (@nYClassid='' or c.Class_id like @nYClassid+'%')
               and  b.billtype IN (10,11,12,13,112,53,54,16,17,210,211)
               and  B.billdate between @Begindate and @Enddate
               and (@nCID=0 or b.c_id=@nCID)
               and (@nSID=0 or vp.ss_id=@nSID)
               and (@nEID=0 or vp.RowE_id=@nEID)
               and (@InputmanID=0 or b.Inputman=@InputmanID)
               AND billstates=0 and vp.P_Id>0 /*and vp.aoid in (0, 5)*/
            )YB  

       GROUP BY YB.billdate
       )b

	/*有单结算金额=单据上结算金额+单据在"收款单"上结算金额*/
  LEFT JOIN
       (SELECT YB.billdate,SUM(YB.ssmoney)AS ssmoney /*有单结算金额*/
        FROM
             (select distinct b.billid,billdate,((CASE WHEN b.billtype in (10,12,112,53,15,16,17,170,210) THEN b.ssmoney ELSE -b.ssmoney END) - ISNULL(f.jftotal,0))ssmoney
                from  billidx  b  
     	        LEFT JOIN  FinanceBill f ON b.billid=f.bill_id AND f.a_id=59   /*在日期销售报表中的有结算或无结算字段都不应该统计收款单上折让那部份金额. */
	            INNER JOIN company c ON b.y_id = c.company_id
	       where      (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and
	                  (c.company_id = 0 OR c.company_id IN (select company_ID from #AuthorizeCompany)) and 
	                  (@nYClassid='' or c.Class_id like @nYClassid+'%')/*(B.Y_id=@nY_id or @nY_id=0) */
	                  and B.billdate between @Begindate and @Enddate 
	                  and b.billtype IN (10,11,12,13,112,53,54,15,16,17,170,210,211) AND billstates=0
                      AND (b.JsFlag<>'0' or (b.JsFlag='0' and b.billid not in (select bill_id from FinanceBill ))) 
                      and (@nCID=0 or b.c_id=@nCID)
                      and (@InputmanID=0 or b.Inputman=@InputmanID)
             )YB
        GROUP BY YB.billdate

       )c  ON b.billdate=c.billdate
 
	/*无单收款结算金额*/
  LEFT JOIN
       (SELECT YB.billdate,SUM(NObillmoney) AS NonBillMoney 
	  FROM (select billdate,(b.ssmoney-isnull(f.jftotal,0))NoBillmoney
                  from billidx b  
                  LEFT JOIN  FinanceBill f  ON b.billid=f.bill_id AND f.a_id=59  /*在日期销售报表中的有结算或无结算字段都不应该统计收款单上折让那部份金额. */
	              INNER JOIN company c2 ON b.Y_ID = c2.company_id
	         where     (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and  
	                   (c2.company_id = 0 OR c2.company_id IN (select company_ID from #AuthorizeCompany)) and
	                   (@nYClassid='' or c2.Class_id like @nYClassid+'%')/*(B.Y_id=@nY_id or @nY_id=0) */
	                    and B.billdate between @Begindate and @Enddate 
	                    and b.billtype IN (15) AND billstates=0
      	                AND b.JsFlag='0' and b.billid  in (select bill_id from FinanceBill)
      	                and (@nCID=0 or b.c_id=@nCID)
      	                and (@InputmanID=0 or b.Inputman=@InputmanID)              
               )YB
        GROUP BY YB.billdate
       )d  ON b.billdate=d.billdate
/*
	 LEFT JOIN (
		--零售多账户收款[去掉现金部分]
  		SELECT b.billdate,SUM(CASE WHEN b.billtype in (12) THEN s.Total ELSE -s.Total END) AS ssmoney
  		FROM VW_C_BillIDX b,SaleManageBill s
		WHERE 	b.BillId=s.Bill_Id	AND s.P_id<0
			AND  (b.billdate BETWEEN @begindate AND @enddate)
			AND b.billtype IN (12,13) AND billstates='0'
  		GROUP BY b.billdate
	)e
    ON e.billdate=c.billdate
*/
	/*收款单|折让*/
  LEFT JOIN
       (SELECT YB.billdate,SUM(YB.JfTotal) AS ZRTotal
	  FROM (select b.billdate,f.jftotal  
                  from billidx b 
                  LEFT JOIN  FinanceBill f  ON b.billid=f.bill_id
                  INNER JOIN company c2 ON b.Y_ID = c2.company_id   
                 where 
                      (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany)) and
                      (c2.company_id = 0 OR c2.company_id IN (select company_ID from #AuthorizeCompany)) and 
                      (@nYClassid='' or c2.Class_id like @nYClassid+'%')/*(B.Y_id=@nY_id or @nY_id=0) */
                       and B.billdate between @Begindate and @Enddate and 
	                   b.BillId=f.Bill_Id AND b.billtype IN (15,170) AND f.a_id=59 and b.billstates=0 and 
                       (@nCID=0 or b.c_id=@nCID) and
                       (@InputmanID=0 or b.Inputman=@InputmanID)

               )YB 
	GROUP BY YB.billdate
       ) f  ON f.billdate=b.billdate
   	/*单据折让金额*/
  LEFT JOIN 
      (
         SELECT YB.billdate,SUM(ISNULL(YB.JdMoney,0)) AS BillZR  FROM 
           (
             select billdate,jdmoney from  AccountDetail AD, billidx b , company c2 
	         where  b.y_id = c2.company_id 
	               and b.BillId=AD.billid
	               and AD.A_Id=59
	               and (b.y_id = 0 OR b.y_id IN (select company_ID from #AuthorizeCompany))
	               and (c2.company_id = 0 OR c2.company_id IN (select company_ID from #AuthorizeCompany))
	               AND (@nYClassid='' or c2.Class_id like @nYClassid+'%')/*(B.Y_id=@nY_id or @nY_id=0)*/
                   and b.billtype IN (10,11,12,13,112,53,54,16,17,170,210,211)
                   and (@nCID=0 or b.c_id=@nCID)
                   and (@InputmanID=0 or b.Inputman=@InputmanID) 
                   
              )YB
        GROUP BY YB.billdate
      )g ON g.billdate=b.billdate 
	/*-----*/
               ORDER BY b.billdate
  /*print(@szsql)*/
  /*exec(@szsql)*/

   GOTO SUCCEE
end

SUCCEE:
  RETURN 0
GO
