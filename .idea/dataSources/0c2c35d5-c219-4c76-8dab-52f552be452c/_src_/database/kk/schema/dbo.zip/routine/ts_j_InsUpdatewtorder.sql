/************************************************************

--功能：GMP证书查询   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_InsUpdatewtorder
	(
      @C_ID int = 0,
      @p_id int = 0,
      @saleEname varchar(30),
      @szSaleArea varchar(100),
      @validdate datetime =0,
      @WTNO varchar(120),
      @szComment varchar(200),  /*0添加*/
      @szPersonNo varchar(40),
      @wt_id int = 0,
      @type int = 0,  /*---委托书类型 0 为供货商法人委托书,1 为购货单位采购委托书*/
	  @szPickUp varchar(40) = '',
	  @szPickUpID varchar(20) = '',
	  @MakeDate datetime =0
     )
AS 
/*Params Ini begin*/
if @C_ID is null  SET @C_ID = 0
if @p_id is null  SET @p_id = 0
if @validdate is null  SET @validdate = 0
if @wt_id is null  SET @wt_id = 0
if @type is null set @type = 0
if @szPickUp is null set @szPickUp = ''
if @szPickUpID is null set @szPickUpID = ''
/*Params Ini end*/


declare @nRet int
set @nRet = -1
  if exists(select * from wtorder where c_id = @C_ID and wtNO = @WTNO and @wt_id = 0 and @type = [type])
  begin
    set @nRet = -2 
    return @nRet
  end
  /*-判断身份证可以重复*/
  if not exists (select * from sysconfigtmp where sysvalue='1' and sysname='scdz02') 
  begin
	  /* 判断身份证*/
	  IF EXISTS(SELECT * FROM wtorder WHERE wt_id <> @wt_id and PersonNO = @szPersonNo)
	  BEGIN
		SET @nRet = -3
		RETURN @nRet
	  END
  end
  if exists(select * from  wtorder where wt_Id = @wt_id and [type] = @type)
  begin
    update wtorder set 
                    C_ID = @C_ID, p_id = @p_id, saleEname = @saleEname,
					saleArea = @szSaleArea, validdate = @validdate,
                    wtno = @WTNO, wtcomment = @szComment, personNO = @szPersonNo,
                    [type] = @type , Pickup = @szPickUp, PickupID = @szPickUpID, MakeDate = @MakeDate
       where wt_Id = @wt_ID
	   set @nRet = @wt_id
	end
  else
  begin
    insert into wtorder(C_ID, p_id, saleEname,saleArea, validdate, wtno, wtcomment, personNO,[type], Pickup, PickupID,MakeDate)
      values (@C_ID, @p_id, @saleEname,@szsaleArea, @validdate, @wtno, @szcomment, @szPersonNo,@type, @szPickUp, @szPickUpID,@MakeDate)
	 set @nRet = @@IDENTITY
	end
 delete from wtDetail where wt_id = @wt_id
 return @nRet
GO
