/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-07-13*/
/* Description:	根据出入类型格式化数据格式*/
/*@Atype  参数说明 1:SLFMT 数量;2:DJFMT 单价;3:TOTALFMT 金额;4:TAXPRICEFMT 税价;5:FLOATFMT 其他;*/
/*@Avalue:被格式数据 */
/* =============================================*/
CREATE FUNCTION [dbo].[Decimalbits]( @Atype INT,@Avalue Float)
RETURNS float AS  
BEGIN 
  declare @Ret  float
  declare @alen int 

     set @alen =
     case @Atype
     when 1 then convert(int,(select sysValue from sysconfig where [sysname]='SLFMT'))
     when 2 then convert(int,(select sysValue from sysconfig where [sysname]='DJFMT'))
     when 3 then convert(int,(select sysValue from sysconfig where [sysname]='TOTALFMT'))
     when 4 then convert(int,(select sysValue from sysconfig where [sysname]='TAXPRICEFMT'))
     when 5 then convert(int,(select sysValue from sysconfig where [sysname]='FLOATFMT'))
     else 0
     end
     
     SET @Ret = 
     case  @alen  
     when 0 then convert(int,@Avalue)
     when 1 then convert(numeric(18,1),@Avalue)
     when 2 then convert(numeric(18,2),@Avalue)
     when 3 then convert(numeric(18,3),@Avalue)
     when 4 then convert(numeric(18,4),@Avalue)
     when 5 then convert(numeric(18,5),@Avalue)
     when 6 then convert(numeric(18,6),@Avalue)
     when 7 then convert(numeric(18,7),@Avalue)
     when 8 then convert(numeric(18,8),@Avalue)
     else  0       
     end
     
  
  return @Ret
END
GO
