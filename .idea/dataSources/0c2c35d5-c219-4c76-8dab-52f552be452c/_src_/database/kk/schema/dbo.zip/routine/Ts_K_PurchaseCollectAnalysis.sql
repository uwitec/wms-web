

CREATE PROCEDURE Ts_K_PurchaseCollectAnalysis(
	@Begin				DATETIME, 
	@End				DATETIME, 
	@YId				INT, 
	@IsCollect			INT,       /*是否选择汇总类型 0否；1是*/
	@CollectType        INT,       /*汇总类型0供应商；1采购员；2商品*/
	@IsClass            INT,	   /*是否选择商品类别 0否；1是 */
	@ClassCgId          INT,       /*商品自定义类别组Cg_Id*/
	@ClassType          INT,	   /*商品类别大中小 0大；1中；2小*/
	@IsTime             INT,       /*是否选择时间段 0否；1是*/
	@TimeType           INT,		   /*时间段类型0日；1月；2季度*/
	@strBusinessType    varchar(50)
)
AS
declare @info_id int
declare @ColName varchar(100)
declare @sqlstr  varchar(2000)
BEGIN
    set @ColName=''
    if @ClassCgId<>0
    begin
      SELECT distinct @info_id = Category_id FROM customCategory WHERE ID=@ClassCgId
      set @ColName = dbo.GetColName(@info_id,'ProductCategory')  
    end
	IF @IsClass = 1
	BEGIN
		DECLARE @ClassId VARCHAR(30), @Len INT
		SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @ClassCgId
		
		SET @Len = 0
		/*SET @BaseType = 0*/
		IF @ClassId = '01%'
		BEGIN
			/*仅功能主治有大中小，其他类别只有大*/
			IF @ClassType = 0
				SET @Len = 4
			IF @ClassType = 1
				SET @Len = 2
			IF @ClassType = 2
				SET @Len = 0	
		END
		ELSE
		IF (@ClassId = '02%') OR (@ClassId = '03%') OR (@ClassId = '04%')   	
			SET @Len = 0
		ELSE
		BEGIN
			/*自定义的类别组*/
			IF @ClassType = 0
				SET @Len = 4
			IF @ClassType = 1
				SET @Len = 2
			IF @ClassType = 2
				SET @Len = 0	
		END
			
		/*DECLARE #ProductList TABLE (CgId INT, PId INT)*/
		CREATE TABLE #ProductList (CgId INT, PId INT)
		CREATE TABLE #tempOne (Class_id varchar(100), name varchar(100),p_id int,id int)
		set @sqlstr='
		insert into #tempOne(Class_id,name,p_id,id)
		SELECT cg.class_id, cg.name, cm.p_id as baseinfo_id,cg.id    
				 FROM ProductCategory cm INNER JOIN customCategory cg ON cm.'+@ColName+' =cg.class_id
				 WHERE cg.class_id LIKE '''+@ClassId+''''
	    exec (@sqlstr)
	    
		INSERT INTO #ProductList(CgId, PId) 
		SELECT b.id, a.p_id as baseinfo_id 
			FROM #tempOne a INNER JOIN customCategory b ON SUBSTRING(a.Class_id, 1, len(a.Class_id) - @Len) = b.class_id
	END
/*-------------------------	*/
/*销售数量*/
	 select s.p_id,sum (s.quantity) as SaleQty into #SaleList 
	        from billidx b left join salemanagebill s on b.billid = s.bill_id   
	        where billtype in(10,12,150,152,210) and 
	       (@YId = 0 or  b.Y_ID = @YId) and b.billdate BETWEEN @Begin AND @End 
	       and b.billstates = 0 and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
	 group by s.p_id	
/*-------------------------	*/
	IF (@IsCollect = 1) AND (@IsClass = 0) AND (@IsTime = 0) GOTO RepOnlyCollect
	IF (@IsCollect = 1) AND (@IsClass = 1) AND (@IsTime = 0) GOTO RepOnlyCollectClass
	IF (@IsCollect = 1) AND (@IsClass = 0) AND (@IsTime = 1) GOTO RepOnlyCollectTime
	IF (@IsCollect = 1) AND (@IsClass = 1) AND (@IsTime = 1) GOTO RepCollectClassTime
	IF (@IsCollect = 0) AND (@IsClass = 0) AND (@IsTime = 1) GOTO RepOnlyTime
	IF (@IsCollect = 0) AND (@IsClass = 1) AND (@IsTime = 1) GOTO RepClassTime
	IF (@IsCollect = 0) AND (@IsClass = 1) AND (@IsTime = 0) GOTO RepOnlyClass
	
	
	RETURN 0
	
	/*汇总、类别与时间段*/
	RepCollectClassTime:
		/*DECLARE #RepCollectClassTimeDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,*/
		/*                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), CgId INT, */
		/*                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		*/
		CREATE TABLE #RepCollectClassTimeDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,
		                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), CgId INT, 
		                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		
		
		INSERT INTO #RepCollectClassTimeDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal,
		                                   PId, SupplierId, EId, Price, TaxPrice, CgId, OrderQty, InvoiceTotal)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, 
		       b.c_id AS supplier_id, b.e_id, s.buyprice, s.taxprice, p.CgId, ISNULL(o.quantity, 0.00) AS OrderQty, ISNULL(i.CurrTotal, 0.00) AS InvoiceTotal
 			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			               INNER JOIN #ProductList p ON s.p_id = p.PId	
			               LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid
			               LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
			                            FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
			                          WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid         
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
			  /*b.billtype IN (20, 21, 160, 161, 162, 163,24, 25) AND b.billstates = 0*/
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY 
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id,
			   b.c_id AS supplier_id, b.e_id, s.saleprice, s.taxprice, p.CgId, 0.00 AS OrderQty, 0.00 AS InvoiceTotal
		    FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
		         INNER JOIN #ProductList p ON s.p_id = p.PId
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		IF @CollectType = 0
		BEGIN
			/*供应商*/
			IF @TimeType = 0
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvocieTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
			       						   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   CONVERT(VARCHAR(50), a.BillDate, 23) AS Class2
					FROM (
						SELECT a.SupplierId, a.CgId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(23, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(25, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(27, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NoSalePCount,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
							   SUM(a.MlTotal) AS MlTotal,
							   SUM(a.OrderQty) AS OrderQty,
							   SUM(a.InvoiceTotal) AS InvocieTotal 
							FROM #RepCollectClassTimeDB a 
						GROUP BY a.SupplierId, a.CgId, a.BillDate
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
						INNER JOIN (
		    						SELECT a.SupplierId, a.CgId, a.BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.SupplierId, a.CgId, a.BillDate
						) b ON a.CgId = b.CgId AND a.SupplierId = b.SupplierId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.SupplierId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
			       						   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class2
					FROM (
						SELECT a.SupplierId, a.CgId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(23, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(25, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(27, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NoSalePCount,	
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleTotal,
							   a.MlTotal,
							   a.OrderQty,
							   a.InvoiceTotal
							FROM (
								SELECT a.SupplierId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, 
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty,
									   SUM(a.InvoiceTotal) AS InvoiceTotal
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.SupplierId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)
							) a
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
						INNER JOIN (
		    						SELECT a.SupplierId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.SupplierId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)
						) b ON a.CgId = b.CgId AND a.SupplierId = b.SupplierId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.SupplierId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
			       						   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class2
					FROM (
						SELECT a.SupplierId, a.CgId, a.BillDate,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(23, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(25, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(27, a.BillDate, a.BillDate,  @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, a.CgId) AS INT) AS NoSalePCount,
							   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, 
							   a.BackTotal, a.SaleTotal, a.MlTotal, a.OrderQty, a.InvoiceTotal 
							FROM (
								SELECT a.SupplierId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
								       SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty,
									   SUM(a.InvoiceTotal) AS InvoiceTotal 
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.SupplierId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
							) a 
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
						INNER JOIN (
		    						SELECT a.SupplierId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.SupplierId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
						) b ON a.CgId = b.CgId AND a.SupplierId = b.SupplierId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.SupplierId, a.CgId, a.BillDate DESC
				RETURN 0
			END
			ELSE
				RETURN 0
		END	
		ELSE
		IF @CollectType = 1
		BEGIN
			/*采购员*/
			IF @TimeType = 0
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS EName, 
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
					   0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   CONVERT(VARCHAR(50), a.BillDate, 23) AS Class2
					FROM (
						SELECT a.EId, a.CgId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(24, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(26, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NoSalePCount,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
							   SUM(a.MlTotal) AS MlTotal,
							   SUM(a.OrderQty) AS OrderQty 
							FROM #RepCollectClassTimeDB a 
						GROUP BY a.EId, a.CgId, a.BillDate
					) a INNER JOIN employees c ON a.EId = c.emp_id
						INNER JOIN (
		    						SELECT a.EId, a.CgId, a.BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.EId, a.CgId, a.BillDate
						) b ON a.CgId = b.CgId AND a.EId = b.EId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.EId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS EName, 
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
					   0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class2
					FROM (
						SELECT a.EId, a.CgId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(24, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(26, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NoSalePCount,
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleTotal,
							   a.MlTotal,
							   a.OrderQty
							FROM (
								SELECT a.EId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, 
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 220) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 220) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty 
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.EId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)	
							) a
					) a INNER JOIN employees c ON a.EId = c.emp_id
						INNER JOIN (
		    						SELECT a.EId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.EId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)
						) b ON a.CgId = b.CgId AND a.EId = b.EId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.EId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS EName, 
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
					   0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class2
					FROM (
						SELECT a.EId, a.CgId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(24, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(26, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, a.CgId) AS INT) AS NoSalePCount,
							   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal, a.OrderQty 
							FROM (
								SELECT a.EId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,   
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty 
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.EId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
							) a
					) a INNER JOIN employees c ON a.EId = c.emp_id
						INNER JOIN (
		    						SELECT a.EId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.EId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
						) b ON a.CgId = b.CgId AND a.EId = b.EId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
				ORDER BY a.EId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
				RETURN 0
		END
		ELSE
		IF @CollectType = 2
		BEGIN
			/*商品*/
			IF @TimeType = 0
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName,
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
					   CASE WHEN AvgCount <> 0 THEN a.AvgPrice / AvgCount ELSE 0.00 END AS AvgPrice, 
					   CASE WHEN AvgCount <> 0 THEN a.AvgTaxPrice / AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   a.HighStoreHouse, a.LowStoreHouse, sh.StockQty, 
					   s.SaleQty/DATEDIFF(D,@Begin,@End) as AvgSaleQty, 
					   sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay, 
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   CONVERT(VARCHAR(50), a.BillDate, 23) AS Class2
					FROM (
						SELECT a.PId, a.CgId, a.BillDate,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS StockQty,*/
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(28, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS HighStoreHouse,
						       CAST(dbo.GetPurchaseCollectAnalysisInfo(29, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS LowStoreHouse,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
							   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
							   SUM(a.MlTotal) AS MlTotal 
							FROM #RepCollectClassTimeDB a 
						GROUP BY a.CgId, a.BillDate, a.PId
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						INNER JOIN (
		    						SELECT a.PId, a.CgId, a.BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.CgId, a.BillDate, a.PId
						) b ON a.CgId = b.CgId AND a.PId = b.PId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
							LEFT JOIN (
						     		    SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
						     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
						left join #SaleList s on a.PId = s.p_id
						left join ( 
						           select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id              	
				ORDER BY a.PId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName,
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   a.HighStoreHouse, a.LowStoreHouse, sh.StockQty, 
			           s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			           sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class2
					FROM (
						SELECT a.PId, a.CgId, a.BillDate,
						       /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS StockQty,*/
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(28, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS HighStoreHouse,
						       CAST(dbo.GetPurchaseCollectAnalysisInfo(29, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS LowStoreHouse,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
							   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
							   a.AvgPrice,
							   a.AvgTaxPrice,
							   a.AvgCount,
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleQty,
							   a.SaleTotal,
							   a.MlTotal 
							FROM (
								SELECT a.PId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal 
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.CgId, CONVERT(VARCHAR(7), a.billdate, 20), a.PId	
							) a
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						INNER JOIN (
		    						SELECT a.PId, a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.CgId, CONVERT(VARCHAR(7), a.billdate, 20), a.PId
						) b ON a.CgId = b.CgId AND a.PId = b.PId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
							LEFT JOIN (
						     		    SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
						     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
						    LEFT JOIN #SaleList s on a.PId = s.p_id
						    left join ( 
						           select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						    left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id           	
				ORDER BY a.PId, a.CgId, a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName,
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   a.HighStoreHouse, a.LowStoreHouse, sh.StockQty, 
			           s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			           sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class2
					FROM (
						SELECT a.PId, a.CgId, a.BillDate, 
						       /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS StockQty,*/
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(28, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS HighStoreHouse,
						       CAST(dbo.GetPurchaseCollectAnalysisInfo(29, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, a.CgId) AS NUMERIC(25,8)) AS LowStoreHouse,
							   	   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
									   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
									   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
									   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
								a.AvgPrice, a.AvgTaxPrice, a.AvgCount, a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal	
							FROM (
								SELECT a.PId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal 
									FROM #RepCollectClassTimeDB a 
								GROUP BY a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR), a.PId
						) a
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						INNER JOIN (
		    						SELECT a.PId, a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
										FROM #RepCollectClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
									GROUP BY a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR), a.PId
						) b ON a.CgId = b.CgId AND a.PId = b.PId AND a.BillDate = b.BillDate
							INNER JOIN customCategory cg1 ON a.CgId = cg1.id
							LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
							LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
							LEFT JOIN (
						     		    SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
						     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
						    left join #SaleList s on a.PId = s.p_id
						    left join ( 
						           select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						    left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id         						     	
				ORDER BY a.PId, a.CgId, a.BillDate  DESC
				RETURN 0	
			END
			ELSE
				RETURN 0
		END
		ELSE
			RETURN 0
		
	/*类别与时间段*/
	RepClassTime:
		/*DECLARE #RepClassTimeDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                               TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT, CgId INT)		*/
		CREATE TABLE #RepClassTimeDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                               TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT, CgId INT)		
		
		INSERT INTO #RepClassTimeDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, PId, CgId)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, p.CgId
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			               INNER JOIN #ProductList p ON s.p_id = p.PId
			               LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY 
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id, p.CgId
			FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id
		                   INNER JOIN #ProductList p ON s.p_id = p.PId	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		IF @TimeType = 0
		BEGIN
			SELECT a.CgId, 
				   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS CgName,
				   b.ProductCount, b.ValidPCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
				   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
				   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate, a.BillDate AS Class1
				FROM (	
					SELECT a.CgId, CONVERT(VARCHAR(50), a.BillDate, 23) AS BillDate,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS ProductCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchasePCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NewPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchaseBackPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NoSalePCount,*/
						   COUNT(a.PId) AS PurchasePCount, COUNT(a.PId) AS NewPCount, COUNT(a.PId) AS NoSalePCount, COUNT(a.PId) AS PurchaseBackPCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal 
						FROM #RepClassTimeDB a 
					GROUP BY a.CgId, a.BillDate
				) a INNER JOIN (
		    				SELECT a.CgId, a.BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
								FROM #RepClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
							GROUP BY a.CgId, a.BillDate
				) b ON a.CgId = b.CgId AND a.BillDate = b.BillDate
					INNER JOIN customCategory cg1 ON a.CgId = cg1.id
					LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
			ORDER BY a.CgId, a.BillDate DESC	
			    			    
			RETURN 0	
		END
		ELSE
		IF @TimeType = 1
		BEGIN
			SELECT a.CgId, 
				   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS CgName,
				   b.ProductCount, b.ValidPCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
				   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
				   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate, 
				   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class1
				FROM (	
					SELECT a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS ProductCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchasePCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NewPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchaseBackPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NoSalePCount,*/
						   COUNT(a.PId) AS PurchasePCount, COUNT(a.PId) AS NewPCount, COUNT(a.PId) AS NoSalePCount, COUNT(a.PId) AS PurchaseBackPCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal 
						FROM #RepClassTimeDB a 
					GROUP BY a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)
				) a INNER JOIN (
		    				SELECT a.CgId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
								FROM #RepClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
							GROUP BY a.CgId, CONVERT(VARCHAR(7), a.billdate, 20)
				) b ON a.CgId = b.CgId AND a.BillDate = b.BillDate
					INNER JOIN customCategory cg1 ON a.CgId = cg1.id
					LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
			ORDER BY a.CgId, a.BillDate DESC	
			    			    
			RETURN 0	
		END
		ELSE
		IF @TimeType = 2
		BEGIN
			SELECT a.CgId, 
				   CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS CgName,
				   b.ProductCount, b.ValidPCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
				   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
				   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate, 
				   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class1
				FROM (	
					SELECT a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS ProductCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchasePCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NewPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchaseBackPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NoSalePCount,*/
						   COUNT(a.PId) AS PurchasePCount, COUNT(a.PId) AS NewPCount, COUNT(a.PId) AS NoSalePCount, COUNT(a.PId) AS PurchaseBackPCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal 
						FROM #RepClassTimeDB a 
					GROUP BY a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
				) a INNER JOIN (
		    				SELECT a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate, COUNT(a.PId) AS ProductCount, SUM(ISNULL(0, 1)) AS ValidPCount 
								FROM #RepClassTimeDB a LEFT JOIN storehouse s ON a.PId = s.p_id AND s.Y_ID = @YId
							GROUP BY a.CgId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
				) b ON a.CgId = b.CgId AND a.BillDate = b.BillDate
					INNER JOIN customCategory cg1 ON a.CgId = cg1.id
					LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
			ORDER BY a.CgId, a.BillDate DESC	
			    			    
			RETURN 0	
		END
		ELSE
			RETURN 0
			
		
	/*汇总与时间段*/
	RepOnlyCollectTime:
		/*DECLARE #RepOnlyCollectTimeDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,*/
		/*                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), */
		/*                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		*/
		CREATE TABLE #RepOnlyCollectTimeDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,
		                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), 
		                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		
		
		INSERT INTO #RepOnlyCollectTimeDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, 
		                                  PId, SupplierId, EId, Price, TaxPrice, OrderQty, InvoiceTotal)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, 
		       b.c_id AS supplier_id, b.e_id, s.buyprice, s.taxprice, ISNULL(o.quantity, 0.00) AS OrderQty, ISNULL(i.CurrTotal, 0.00) AS InvoiceTotal
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
			               LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid
			               LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
			                            FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
			                          WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid         
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN s.taxprice * s.quantity - s.costtaxprice * s.quantity
			   ELSE -(s.taxprice * s.quantity - s.costtaxprice * s.quantity) END AS MlTotal, s.p_id,
			   b.c_id AS supplier_id, b.e_id, s.saleprice, s.taxprice, 0.00 AS OrderQty, 0.00 AS InvoiceTotal
		    FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND  
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0 AND 
			  s.p_id IN (
					SELECT s.p_id
						FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
									   LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid
									   LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
													FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
												  WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid
					WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
						  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
						  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
						  GROUP BY s.p_id
						  
						  						
			  ) AND
			  b.c_id IN (
					SELECT b.c_id
						FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
									   LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid
									   LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
													FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
												  WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid
					WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
						  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0 
						  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
						  GROUP BY b.c_id
						  	
			  
			  )
		
		IF @CollectType = 0
		BEGIN
			/*供应商*/
			IF @TimeType = 0
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
		       							   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
					   CONVERT(VARCHAR(50), a.BillDate, 23) AS Class1, '' AS Class2
					FROM (
						SELECT a.SupplierId, a.BillDate, 
						       CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NoSalePCount,
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleTotal,
							   a.MlTotal,
							   a.OrderQty,
							   a.InvoiceTotal 
							FROM (
								SELECT a.SupplierId, a.BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty,
									   SUM(a.InvoiceTotal) AS InvoiceTotal 
									FROM #RepOnlyCollectTimeDB a 
								GROUP BY a.SupplierId, a.BillDate	
							) a
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
				
				RETURN 0		
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
		       							   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class1, '' AS Class2
					FROM (
						SELECT a.SupplierId, a.BillDate, 
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(6, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS ProductCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(7, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchasePCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NewPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(9, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
							   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NoSalePCount,
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleTotal,
							   a.MlTotal,
							   a.OrderQty,
							   a.InvoiceTotal 	
							FROM (
								SELECT a.SupplierId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal,
									   SUM(a.OrderQty) AS OrderQty,
									   SUM(a.InvoiceTotal) AS InvoiceTotal 
									FROM #RepOnlyCollectTimeDB a 
								GROUP BY a.SupplierId, CONVERT(VARCHAR(7), a.billdate, 20)	
							) a
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
				
				RETURN 0
			END
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
					   CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
		       							   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
					   CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
					   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class1, 
					   '' AS Class2
					FROM (
						SELECT a.SupplierId, 
							   CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
						       0 AS ProductCount,
						       /*CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS ProductCount,*/
							   0 AS PurchasePCount,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchasePCount,*/
							   0 AS NewPCount,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NewPCount,*/
							   0 AS PurchaseBackPCount,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS PurchaseBackPCount,*/
							   0 AS NoSalePCount,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId) AS INT) AS NoSalePCount,*/
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
							   SUM(a.MlTotal) AS MlTotal,
							   SUM(a.OrderQty) AS OrderQty,
							   SUM(a.InvoiceTotal) AS InvoiceTotal 
							FROM #RepOnlyCollectTimeDB a 
						GROUP BY a.SupplierId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
					) a INNER JOIN clients c ON a.SupplierId = c.client_id
						LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
				
				RETURN 0
			END
			ELSE
				RETURN 0
		END
		ELSE
		IF @CollectType = 1
		BEGIN
			/*采购员*/
			IF @TimeType = 0
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS EName, 
			       CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
			       0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
			       CONVERT(VARCHAR(50), a.BillDate, 23) AS Class1, '' AS Class2
			    FROM (
					SELECT a.EId, a.BillDate,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(11, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal,
						   SUM(a.OrderQty) AS OrderQty 
						FROM #RepOnlyCollectTimeDB a 
					GROUP BY a.EId, a.BillDate
				) a INNER JOIN employees c ON a.EId = c.emp_id	
				
				RETURN 0
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS EName, 
			       CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
			       0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
			       SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class1, '' AS Class2
			    FROM (
					SELECT a.EId, a.BillDate, 
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(11, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(12, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NoSalePCount,
						   a.PurchaseQty,
						   a.PurchaseTotal,
						   a.PurchaseTaxMoney,
						   a.PurchaseTaxTotal,
						   a.BackQty,
						   a.BackTotal,
						   a.SaleTotal,
						   a.MlTotal,
						   a.OrderQty
						FROM (
							SELECT a.EId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
								   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
								   SUM(a.MlTotal) AS MlTotal,
								   SUM(a.OrderQty) AS OrderQty 
								FROM #RepOnlyCollectTimeDB a 
							GROUP BY a.EId, CONVERT(VARCHAR(7), a.billdate, 20)	
						) a
				) a INNER JOIN employees c ON a.EId = c.emp_id	
				
				RETURN 0	
			END	
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS EName, 
			       CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,
			       0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
			       SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class1, '' AS Class2
			    FROM (
					SELECT a.EId, a.BillDate, 
					       CAST(dbo.GetPurchaseCollectAnalysisInfo(11, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(12, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, a.BillDate, a.BillDate,  @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NoSalePCount, 
						   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal, a.OrderQty
						FROM (
							SELECT a.EId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
								   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
								   SUM(a.MlTotal) AS MlTotal,
								   SUM(a.OrderQty) AS OrderQty 
								FROM #RepOnlyCollectTimeDB a 
							GROUP BY a.EId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
					) a
				) a INNER JOIN employees c ON a.EId = c.emp_id	
				RETURN 0
			END
			ELSE
				RETURN 0
		END
		ELSE
		IF @CollectType = 2
		BEGIN
			/*商品*/
			IF @TimeType = 0
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName, 
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   0.00 AS HighStoreHouse, 0.00 AS LowStoreHouse, sh.StockQty, 
			           s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			           sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   CONVERT(VARCHAR(50), a.BillDate, 23) AS Class1, '' AS Class2
					FROM (
						SELECT a.PId, a.BillDate,
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS StockQty,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
							   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
							   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
							   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
							   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
							   SUM(a.MlTotal) AS MlTotal 
							FROM #RepOnlyCollectTimeDB a 
						GROUP BY a.BillDate, a.PId
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						LEFT JOIN (
					     		 SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
					     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
					    left join #SaleList s on a.PId = s.p_id
						left join ( 
						        select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id              					    	
				ORDER BY a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 1
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName, 
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   0.00 AS HighStoreHouse, 0.00 AS LowStoreHouse, sh.StockQty, 
			           s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			           sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS Class1, '' AS Class2
					FROM (
						SELECT a.PId, a.BillDate, 
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS StockQty,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
							   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
							   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
							   a.AvgPrice,
							   a.AvgTaxPrice,
							   a.AvgCount,
							   a.PurchaseQty,
							   a.PurchaseTotal,
							   a.PurchaseTaxMoney,
							   a.PurchaseTaxTotal,
							   a.BackQty,
							   a.BackTotal,
							   a.SaleQty,
							   a.SaleTotal,
							   a.MlTotal 
							FROM (
								SELECT a.PId, CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal 
									FROM #RepOnlyCollectTimeDB a 
								GROUP BY CONVERT(VARCHAR(7), a.billdate, 20), a.PId
							) a
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						LEFT JOIN (
					     		     SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
					     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
					    left join #SaleList s on a.PId = s.p_id
						left join ( 
						         select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id              					     	
				ORDER BY a.BillDate DESC
				RETURN 0	
			END
			ELSE
			IF @TimeType = 2
			BEGIN
				SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName,
					   /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
					   CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			           CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
					   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
					   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
					   0.00 AS HighStoreHouse, 0.00 AS LowStoreHouse, sh.StockQty, 
			           s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			           sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
					   t.BreakOffCount AS BreakOffCount,
					   CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
					   0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
					   SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS Class1, '' AS Class2
					FROM (
						SELECT a.PId, a.BillDate,
						       /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS StockQty,*/
									   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
									   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
									   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
									   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
							   a.AvgPrice, a.AvgTaxPrice, a.AvgCount, a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, 
							   a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal 	
							FROM (
								SELECT a.PId, CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
									   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
									   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
									   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
									   SUM(a.MlTotal) AS MlTotal 
									FROM #RepOnlyCollectTimeDB a 
								GROUP BY CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR), a.PId
						) a
					) a INNER JOIN products c ON a.PId = c.product_id
						INNER JOIN unit u ON c.unit1_id = u.unit_id
						LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
						LEFT JOIN employees e ON p.Emp_id = e.emp_id
						LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
						LEFT JOIN (
					     		      SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
					     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
					    left join #SaleList s on a.PId = s.p_id
						left join ( 
						        select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						           ) t on a.PId = t.p_id
						left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id              					     	
				ORDER BY a.BillDate DESC	
				RETURN 0	
			END
			ELSE
				RETURN 0
		END
		ELSE
			RETURN 0
		
	/*汇总与类别*/
    RepOnlyCollectClass:
		/*DECLARE #RepOnlyCollectClassDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,*/
		/*                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), CgId INT, */
		/*                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		*/
		CREATE TABLE #RepOnlyCollectClassDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,
		                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), CgId INT, 
		                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		
		
		INSERT INTO #RepOnlyCollectClassDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, PId, 
		                                   SupplierId, EId, Price, TaxPrice, CgId, OrderQty, InvoiceTotal)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, 
		       b.c_id AS supplier_id, b.e_id, s.buyprice, s.taxprice, p.CgId, ISNULL(o.quantity, 0.00) AS OrderQty, ISNULL(i.CurrTotal, 0.00) AS InvoiceTotal
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			               INNER JOIN #ProductList p ON s.p_id = p.PId
			               LEFT JOIN OrderBill o ON s.YGuid = o.RowGuid	
			               LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
			                            FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
			                          WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid     
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  /*b.billtype IN (20, 21, 160, 161, 162, 163, 24, 25) AND b.billstates = 0*/
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id,
			   b.c_id AS supplier_id, b.e_id, s.saleprice, s.taxprice, p.CgId, 0.00 AS OrderQty, 0.00 AS InvoiceTotal
		    FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id
		                   INNER JOIN #ProductList p ON s.p_id = p.PId	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		IF @CollectType = 0
		BEGIN
			/*供应商*/
			SELECT a.SupplierId, a.CgId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, 
			       a.PurchaseTaxTotal AS InvoiceTotal, a.PurchaseTaxTotal - a.InvoiceTotal AS UnInvoiceTotal,
			       CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
			       	                   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
			       CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
			       '' AS Class2,
			       CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate
			    FROM (
					SELECT a.SupplierId, CgId,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal,
						   SUM(a.OrderQty) AS OrderQty,
						   SUM(a.InvoiceTotal) AS InvoiceTotal
						FROM #RepOnlyCollectClassDB a 
					GROUP BY a.SupplierId, a.CgId
				) a INNER JOIN clients c ON a.SupplierId = c.client_id
				    LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
				    INNER JOIN customCategory cg1 ON a.CgId = cg1.id
					LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
			
			RETURN 0	
		END
		ELSE
		IF @CollectType = 1
		BEGIN
			/*采购员*/
			SELECT a.EId, a.CgId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS EName, 
			       CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate, 
			       0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, 
			       CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
			       '' AS Class2
			    FROM (
					SELECT a.EId, a.CgId,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(11, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal,
						   SUM(a.OrderQty) AS OrderQty 
						FROM #RepOnlyCollectClassDB a 
					GROUP BY a.EId, a.CgId
				) a INNER JOIN employees c ON a.EId = c.emp_id
				    INNER JOIN customCategory cg1 ON a.CgId = cg1.id
				    LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
		
			RETURN 0		    	
		END
		ELSE
		IF @CollectType = 2
		BEGIN
			/*商品*/
			SELECT a.PId, a.CgId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName, 
			       /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
			       CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			       CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			       CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       a.HighStoreHouse, a.LowStoreHouse, sh.StockQty, 
			       s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			       sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay,
			       t.BreakOffCount AS BreakOffCount,
			       CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
			       0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, 
			       CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS Class1, 
			       '' AS Class2
			    FROM (
					SELECT a.PId, a.CgId,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS StockQty,*/
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(28, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS HighStoreHouse,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(29, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS LowStoreHouse,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
						   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal 
						FROM #RepOnlyCollectClassDB a 
					GROUP BY a.CgId, a.PId 
				) a INNER JOIN products c ON a.PId = c.product_id
				    INNER JOIN unit u ON c.unit1_id = u.unit_id
				    LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
				    LEFT JOIN employees e ON p.Emp_id = e.emp_id
				    LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
				    INNER JOIN customCategory cg1 ON a.CgId = cg1.id
				    LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
					LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
					LEFT JOIN (
				     		     SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
				     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
				    left join #SaleList s on a.PId = s.p_id
					left join ( 
						       select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						       ) t on a.PId = t.p_id
					left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id 	         				      	
			RETURN 0
		END
		ELSE
			RETURN 0
    
	/*仅类别*/
	RepOnlyClass:
		/*DECLARE #RepOnlyClassDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                               TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT, CgId INT)		*/
		CREATE TABLE #RepOnlyClassDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                               TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT, CgId INT)		
		
		INSERT INTO #RepOnlyClassDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, PId, CgId)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, p.CgId
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			               INNER JOIN #ProductList p ON s.p_id = p.PId
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  /*b.billtype IN (20, 21, 160, 161, 162, 163, 24, 25) AND b.billstates = 0*/
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY 
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id, p.CgId
			FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id
		                   INNER JOIN #ProductList p ON s.p_id = p.PId	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		SELECT a.CgId, 
		       CASE WHEN ISNULL(cg2.name, '') <> '' THEN (CASE WHEN ISNULL(cg3.name, '') <> '' THEN ISNULL(cg3.name, '') + '->' + ISNULL(cg2.name, '') + '->' + cg1.name ELSE ISNULL(cg2.name, '') + '->' + cg1.name END) ELSE cg1.name END AS CgName,
		       a.ProductCount, a.ValidPCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
		       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
		       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate, '' AS Class1
		    FROM (	
				SELECT a.CgId,
				       CAST(dbo.GetPurchaseCollectAnalysisInfo(17, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS ProductCount,
					   CAST(dbo.GetPurchaseCollectAnalysisInfo(18, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS ValidPCount,
					   CAST(dbo.GetPurchaseCollectAnalysisInfo(19, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS PurchasePCount,
					   CAST(dbo.GetPurchaseCollectAnalysisInfo(20, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS NewPCount,
					   CAST(dbo.GetPurchaseCollectAnalysisInfo(21, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS NoSalePCount,
					   CAST(dbo.GetPurchaseCollectAnalysisInfo(22, @Begin, @End, @YId, @TimeType, @CollectType, a.CgId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
					   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
					   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
					   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
					   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
					   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
					   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
					   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
					   SUM(a.MlTotal) AS MlTotal 
					FROM #RepOnlyClassDB a 
				GROUP BY a.CgId
		    ) a INNER JOIN customCategory cg1 ON a.CgId = cg1.id
			    LEFT JOIN customCategory cg2 ON SUBSTRING(cg1.class_id, 1, LEN(cg1.class_id) - 2) = cg2.class_id AND LEN(cg2.class_id) > 2
			    LEFT JOIN customCategory cg3 ON SUBSTRING(cg2.class_id, 1, LEN(cg1.class_id) - 4) = cg3.class_id AND LEN(cg3.class_id) > 2
			    			    
		RETURN 0
						
		
	/*仅汇总*/
	RepOnlyCollect:
		/*DECLARE #RepOnlyCollectDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,*/
		/*                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), */
		/*                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		*/
		CREATE TABLE #RepOnlyCollectDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                                 TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT,
		                                 SupplierId INT, EId INT, Price NUMERIC(25,8), TaxPrice NUMERIC(25,8), 
		                                 OrderQty NUMERIC(25,8), InvoiceTotal NUMERIC(25,8))		
		
		INSERT INTO #RepOnlyCollectDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, PId, 
		                              SupplierId, EId, Price, TaxPrice, OrderQty, InvoiceTotal)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id, 
		       b.c_id AS supplier_id, b.e_id, s.buyprice, s.taxprice, ISNULL(o.quantity, 0.00) AS OrderQty, ISNULL(i.CurrTotal, 0.00) AS InvoiceTotal
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			               LEFT JOIN OrderBill o ON s.YGUID = o.RowGuid
			               LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
			                            FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
			                          WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid          
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
			  /*b.billtype IN (20, 21, 160, 161, 162, 163, 24, 25) AND b.billstates = 0*/
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY 
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id,
			   b.c_id AS supplier_id, b.e_id, s.saleprice, s.taxprice, 0.00 AS OrderQty, 0.00 AS InvoiceTotal
		    FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		/*单独计算订单数量，避免从订单明细重复累加数量 BUG33870*/
		DECLARE @SumOrderQty NUMERIC(25,8)		
		select @SumOrderQty = sum(quantity) from OrderBill where bill_id in 
		 (	  
            select distinct o.bill_id
              FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
			                 LEFT JOIN OrderBill o ON s.YGUID = o.RowGuid
			                 LEFT JOIN (SELECT a.billid, SUM(a.CurrTotal) AS CurrTotal
			                              FROM invoice a INNER JOIN invoiceidx b ON a.invoiceid = b.id 
			                                WHERE b.states = 2 GROUP BY a.billid) i ON b.billid = i.billid
		        WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			          /*b.billtype IN (20, 21, 160, 161, 162, 163, 24, 25) AND b.billstates = 0*/
			          b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			          and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))		  
        )                               
		
		IF @CollectType = 0
		BEGIN
			/*供应商*/
			SELECT a.SupplierId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS SupplierName, c2.aptotal AS ApTotal, c2.SkLimit, a.PurchaseTaxTotal AS InvoiceTotal, 
			       a.PurchaseTaxTotal - InvoiceTotal AS UnInvoiceTotal,
			       CASE c2.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂账' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
			       	                   WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE '' END AS BalanceMode,
			       /*CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,*/
			       CASE WHEN @SumOrderQty <> 0 THEN a.PurchaseQty / @SumOrderQty * 100 ELSE 0.00 END AS OrderRate,			       
			       '' AS Class1, '' AS Class2
			    FROM (
					SELECT a.SupplierId,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(6, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(7, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(8, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(9, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(10, @Begin, @End, @YId, @TimeType, @CollectType, a.SupplierId, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal,
						   SUM(a.OrderQty) AS OrderQty,
						   SUM(a.InvoiceTotal) AS InvoiceTotal 
						FROM #RepOnlyCollectDB a 
					GROUP BY a.SupplierId
				) a INNER JOIN clients c ON a.SupplierId = c.client_id
				    LEFT JOIN Clientsbalance c2 ON c.client_id = c2.C_ID AND c2.Y_id = @YId
			
			RETURN 0	
		END	
		ELSE
		IF @CollectType = 1
		BEGIN
			/*采购员*/
			SELECT a.EId, a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       c.name AS EName, 
			       /*CASE WHEN a.OrderQty <> 0 THEN a.PurchaseQty / a.OrderQty * 100 ELSE 0.00 END AS OrderRate,*/
			       CASE WHEN @SumOrderQty <> 0 THEN a.PurchaseQty / @SumOrderQty * 100 ELSE 0.00 END AS OrderRate,
			       0 AS OverHighStoreHouse, 0 AS OverLowStoreHouse, 0 AS BreakOffPCount, '' AS Class1, '' AS Class2
			    FROM (
					SELECT a.EId,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(11, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal,
						   SUM(a.OrderQty) AS OrderQty 
						FROM #RepOnlyCollectDB a 
					GROUP BY a.EId
				) a INNER JOIN employees c ON a.EId = c.emp_id
		
			RETURN 0		    	
		END
		ELSE
		IF @CollectType = 2
		BEGIN
			/*商品*/
			SELECT a.PId, c.serial_number, c.name AS PName, c.alias, c.[standard], c.permitcode, c.makearea, c.Factory, u.name AS UnitName,
			       /*a.ProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, */
			       CAST(ISNULL(o.name, '0.00') AS NUMERIC(25,8)) AS TaxRate, 
			       CASE WHEN a.AvgCount <> 0 THEN a.AvgPrice / a.AvgCount ELSE 0.00 END AS AvgPrice, 
			       CASE WHEN a.AvgCount <> 0 THEN a.AvgTaxPrice / a.AvgCount ELSE 0.00 END AS AvgTaxPrice,
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleQty, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate,
			       a.HighStoreHouse, a.LowStoreHouse, sh.StockQty,  
			       s.SaleQty/DATEDIFF(D,@Begin,@End) AS AvgSaleQty, 
			       sh.StockQty/(s.SaleQty/DATEDIFF(D,@Begin,@End)) AS CanSaleDay, 
			       t.BreakOffCount AS BreakOffCount,
			       CASE WHEN a.PurchaseQty > 0 THEN ROUND(a.BackQty / a.PurchaseQty * 100, 2) ELSE 0.00 END AS BackRate,
			       0 AS SaleFreq, ISNULL(e.name, '') AS EName, ISNULL(cc.name, '') AS SupplierName, '' AS Class1, '' AS Class2
			    FROM (
					SELECT a.PId,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(16, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS StockQty,*/
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(28, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS HighStoreHouse,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(29, @Begin, @End, @YId, @TimeType, @CollectType, a.PId, @IsTime, 0) AS NUMERIC(25,8)) AS LowStoreHouse,
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(12, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchasePCount,*/
						   /* CAST(dbo.GetPurchaseCollectAnalysisInfo(14, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NewPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(13, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS PurchaseBackPCount,*/
						   /*CAST(dbo.GetPurchaseCollectAnalysisInfo(15, @Begin, @End, @YId, @TimeType, @CollectType, a.EId) AS INT) AS NoSalePCount,*/
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.Price ELSE 0 END) AS AvgPrice,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.TaxPrice ELSE 0 END) AS AvgTaxPrice,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN 1 ELSE 0 END) AS AvgCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.TaxTotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.Quantity WHEN a.billType IN (11, 13, 151, 153) THEN -a.Quantity ELSE 0 END) AS SaleQty,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.TaxTotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.TaxTotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal 
						FROM #RepOnlyCollectDB a 
					GROUP BY a.PId
				) a INNER JOIN products c ON a.PId = c.product_id
				    INNER JOIN unit u ON c.unit1_id = u.unit_id
				    LEFT JOIN productbalance p ON c.product_id = P.p_id AND p.Y_id = @YId
				    LEFT JOIN employees e ON p.Emp_id = e.emp_id
				    LEFT JOIN clients cc ON p.Supplier_id = cc.client_id
					LEFT JOIN (
						     	SELECT c.name, c.id, cm.P_id  as baseinfo_id
						     			FROM customCategory c INNER JOIN ProductCategory  cm ON c.class_id  = cm.PComent2
						     		    WHERE  c.[deleted] = 0
						     	) o ON c.product_id = o.baseinfo_id AND c.TaxRate = o.id
			        left join #SaleList s on s.p_id = a.PId
					left join ( 
						       select  p_id,COUNT(*) as BreakOffCount 
						              from PerStockData  where qty = 0 and y_id = @YId
						              and datetime between @Begin and @End 
						              group by p_id
						       ) t on a.PId = t.p_id
					left join (select p_id,SUM(quantity) as StockQty from storehouse where Y_ID =@YId group by p_id) sh on c.product_id = sh.p_id 	         			        			     	
			RETURN 0
		END
		ELSE
			RETURN 0
	
	/*仅时间段*/
	RepOnlyTime:
		/*DECLARE #RepOnlyTimeDB TABLE (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), */
		/*                              TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT)		*/
		CREATE TABLE #RepOnlyTimeDB (BillType INT, BillDate DATETIME, Quantity NUMERIC(25,8), Total NUMERIC(22, 8), 
		                              TaxMoney NUMERIC(22, 8), TaxTotal NUMERIC(25,8), MlTotal NUMERIC(22, 8), PId INT)		
		
		INSERT INTO #RepOnlyTimeDB(BillType, BillDate, Quantity, Total, TaxMoney, TaxTotal, MlTotal, PId)
		SELECT b.billtype, b.billdate, s.quantity, s.taxtotal / (1 + s.taxrate), s.taxtotal - s.taxtotal / (1 + s.taxrate), s.taxtotal, 0.00 AS MlTotal, s.p_id
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  /*b.billtype IN (20, 21, 160, 161, 162, 163, 24, 25) AND b.billstates = 0*/
			  b.billtype IN (20, 21, 24, 25, 35, 220, 221) AND b.billstates = 0
			  and s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
		/*
		UNION ALL 
		SELECT b.billtype, b.billdate, s.quantity, s.totalmoney, s.taxmoney, s.taxtotal, 
			   CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY 
			   ELSE -((s.SendQTY * s.taxtotal/ s.quantity) - s.costtaxprice * s.SendQTY) END AS MlTotal, s.p_id
		    FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
			  b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.billstates = 0
		*/
		IF @TimeType = 0
		BEGIN
			/*日*/
			SELECT a.BillDate, a.ProductCount, a.ValidProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, 
			       a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
			       CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate 
				FROM (
					SELECT CONVERT(VARCHAR(50), a.BillDate, 23) AS BillDate,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(4, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(5, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ValidProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(0, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(1, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(2, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(3, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NoSalePCount,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
						   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
						   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
						   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
						   SUM(a.MlTotal) AS MlTotal
						FROM #RepOnlyTimeDB a
					GROUP BY a.BillDate
				) a ORDER BY a.BillDate DESC 	
			
			RETURN 0		
		END
		ELSE
		IF @TimeType = 1
		BEGIN
			/*月*/
			SELECT SUBSTRING(a.BillDate, 1, 4) + '年' + CAST(CAST(SUBSTRING(a.BillDate, 6, 7) AS INT) AS VARCHAR) + '月' AS BillDate,
				   a.ProductCount, a.ValidProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, a.PurchaseQty, 
				   a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
				   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate 
				FROM (
					SELECT a.billdate,
					       CAST(dbo.GetPurchaseCollectAnalysisInfo(4, a.billdate, a.billdate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(5, a.billdate, a.billdate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ValidProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(0, a.billdate, a.billdate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(1, a.billdate, a.billdate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(2, a.billdate, a.billdate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(3, a.billdate, a.billdate,  @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NoSalePCount, 
						   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal			 
						FROM (
							SELECT CONVERT(VARCHAR(7), a.billdate, 20) AS BillDate,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
								   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
								   SUM(a.MlTotal) AS MlTotal
								FROM #RepOnlyTimeDB a
							GROUP BY CONVERT(VARCHAR(7), a.billdate, 20)
						) a
				) a	ORDER BY a.BillDate DESC
			
			RETURN 0
		END
		ELSE
		IF @TimeType = 2
		BEGIN
			/*季度*/
			SELECT SUBSTRING(a.BillDate, 1, 4) + '年' + SUBSTRING(a.BillDate, 5, 5) + '季度' AS BillDate,
				   a.ProductCount, a.ValidProductCount, a.PurchasePCount, a.PurchaseBackPCount, a.NewPCount, a.NoSalePCount, a.PurchaseQty, 
				   a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal,
				   CASE WHEN a.SaleTotal > 0 THEN a.MlTotal / a.SaleTotal * 100  ELSE 0.00 END AS MlRate   
				FROM (
					SELECT a.BillDate,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(4, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(5, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS ValidProductCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(0, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchasePCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(1, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS PurchaseBackPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(2, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NewPCount,
						   CAST(dbo.GetPurchaseCollectAnalysisInfo(3, a.BillDate, a.BillDate, @YId, @TimeType, @CollectType, 0, @IsTime, 0) AS INT) AS NoSalePCount,
						   a.PurchaseQty, a.PurchaseTotal, a.PurchaseTaxMoney, a.PurchaseTaxTotal, a.BackQty, a.BackTotal, a.SaleTotal, a.MlTotal	
						FROM (
							SELECT CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR) AS BillDate,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.quantity ELSE 0 END) AS PurchaseQty,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.total ELSE 0 END) AS PurchaseTotal,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxmoney ELSE 0 END) AS PurchaseTaxMoney,
								   SUM(CASE WHEN a.billtype IN (20, 24, 35, 220) THEN a.taxtotal ELSE 0 END) AS PurchaseTaxTotal,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.quantity ELSE 0 END) AS BackQty,
								   SUM(CASE WHEN a.billtype IN (21, 25, 221) THEN a.taxtotal ELSE 0 END) AS BackTotal,
								   SUM(CASE WHEN a.billtype IN (10, 12, 150, 152) THEN a.taxtotal WHEN a.billType IN (11, 13, 151, 153) THEN -a.taxtotal ELSE 0 END) AS SaleTotal,
								   SUM(a.MlTotal) AS MlTotal
								FROM #RepOnlyTimeDB a
							GROUP BY CAST(DATEPART(YEAR, a.BillDate) AS VARCHAR(4)) + CAST(DATEPART(QUARTER, a.BillDate) AS VARCHAR)
						) a
				) a ORDER BY a.BillDate DESC
			
			RETURN 0	
		END
		ELSE
			RETURN 0		
	DROP TABLE #ProductList
	DROP TABLE #RepCollectClassTimeDB
	DROP TABLE #RepClassTimeDB
	DROP TABLE #RepOnlyCollectTimeDB
	DROP TABLE #RepOnlyCollectClassDB
	DROP TABLE #RepOnlyClassDB
	DROP TABLE #RepOnlyCollectDB
	DROP TABLE #RepOnlyTimeDB
	DROP TABLE #SaleList
	DROP TABLE #tempOne
END
GO
