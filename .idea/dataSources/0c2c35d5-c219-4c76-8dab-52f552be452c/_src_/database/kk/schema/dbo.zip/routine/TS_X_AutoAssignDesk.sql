
/* =============================================*/
/* Author:		XXX*/
/* Create date: 2017-06-06 */
/* Description:	波次下发，分配复核台和暂存区*/
/*  算法主要规则	

1. 优先级
2. 补货优先，先生成移库单
3. 根据复核台限定，分配复核台，优先剩余工作量大的单据，按单据明细算
4. a. 根据承运方式，再根据优先级别找到暂存区，根据客户线路，找到暂存区， 再根据业务类型找到暂存区
   b. 如果复核台限定有暂存区，在限定的暂存区域中查找
   c. 没有启用虚拟暂存区的时候，暂存区只能只用使用一次，必须要等做物流配送单后，解除锁定
   d. 启用虚拟暂存区的时候，暂存区可以分配多次次，不进行锁定，但是需要记录任务量，
      在做物流配送单后减少任务量，优先配送任务量小的暂存区

 思路：先根据优先级对为分配的单据排序，然后根据循环单据依次分配复核台，暂存区
	注意3，4的条件要同时满足，然后再对满足条件的设定优先级

*/
/* =============================================*/

CREATE PROCEDURE TS_X_AutoAssignDesk 
	/*@billid int = 0,		--订单id */
	/*@billtype int = 0,		-- 单据类型*/
	@nRet int output		/* 返回值，成功返回0，失败返回-1，错误返回-2*/
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @Gspbillid INT
	DECLARE @s_id INT /*仓库*/
	DECLARE @nNewBillID int 	
	DECLARE @bNestedFlag INT	
	DECLARE @nYId INT
	DECLARE @detailCount INT  /*单据明细*/
	declare @icount int   /*循环计数*/
	declare @doubleCheck int   /*双人签字属性*/
	declare @sa_id int   /*库区id*/
	declare @RoadID int   /*路线*/
	declare @ywType int  /*业务类型*/
	declare @TrafficType int  /*承运方式*/
	declare @PrioRity int  /*优先级	*/
	declare @did int  /*业务类型*/
	declare @hid int  /*承运方式*/
	declare @jobs int  /*优先级	*/
	declare @succ bit  /*判断是否分配成功*/
	declare @succHold bit  /*判断是否找到暂存区*/
	
	SET @nRet = 0
	/*
	IF @@TRANCOUNT > 0
	BEGIN
		SET @bNestedFlag = 1
		SAVE TRAN CREATEBILL
	END
	ELSE
	BEGIN
		SET @bNestedFlag = 0
		BEGIN TRAN CREATEBILL
	END
	*/
		 		 		 
		/*定义几个比较小的表变量 */
		/*满足条件的复核台*/
		declare @tmpDesk TABLE (
			level  int,  /*设置排序优先级*/
			did     int,   /*复核台id*/
			hid     int,   /*暂存区id*/
			s_id	int,   /*仓库id*/
			jobs    int   /*剩余工作量	*/
			)
			
		/*满足条件的暂存区*/
		declare @tmpHold TABLE (
			level  int,  /*设置排序优先级*/
			hid     int,   /*暂存区id*/
			jobs    int   /*剩余工作量	*/
			)

		/*查询出待处理单据*/
		declare billCur cursor for
		select Gspbillid,i.S_id,i.sa_id,i.doubleCheck,
				ISNULL(CASE WHEN i.Ybilltype IN (52, 152, 150, 161, 163,516,517,564) 
				THEN cy.RoadID ELSE cc.RoadID END,0) AS RoadID,  
				CASE WHEN i.Ybilltype IN (14) THEN 1  /*销售 */
					 WHEN i.Ybilltype IN (154) THEN 2  /*门店配送*/
					 WHEN i.Ybilltype IN (561) THEN 3 ELSE 4 END AS ywType,  /*采购退回*/
				case i.TrafficType when '自提' THEN 1 WHEN '企业配送' THEN 2 WHEN '委托运输' THEN 3 ELSE 0 END as TrafficType,
				PrioRity,detailcount
		from gspbillidx i LEFT OUTER JOIN
			dbo.clients AS cc ON i.C_id = cc.client_id LEFT OUTER JOIN
			dbo.company AS cy ON i.C_id = cy.company_id 			       					       					       
		where billtype in (541)	and ((DeskId = 0) or (HoldId = 0)) and BillStates <> 15		
		order by PrioRity desc, BillDate asc		 /*优先级   			   */
		open billCur
		
		fetch next from billCur into @Gspbillid,@s_id,@sa_id,@doubleCheck,@RoadID,@ywType,@TrafficType,@PrioRity,@detailCount  /*循环分配复核台*/
		while @@FETCH_STATUS=0 
		begin				
			set @succ = 0
			
			if @sa_id = 0
				select top 1 @sa_id = l.sa_id from gspbilldetail g,location l where Gspbill_id = @Gspbillid and g.Location_id = l.loc_id
			/*满足条件的复核台，放入临时表*/
			delete from @tmpDesk /*清除数据*/
			insert @tmpDesk(level,did,hid,s_id,jobs)
			select ISNULL(h.priority,999) level,cb.ID,ISNULL(a1.AreaHoldGspID,0),cb.S_id,(cb.WorkNum - cb.jobNum) as jobs from WMSCheckBaseInfo cb left OUTER JOIN WMSCheckAHG a1 on cb.ID = a1.CheckID and a1.Type = 2 and a1.Deleted = 0 /*暂存区*/
											  /*left OUTER JOIN WMSCheckAHG a2 on cb.ID = a2.CheckID and a2.Type = 3 and a2.Deleted = 0  --gsp属性*/
											  left OUTER JOIN WMSCheckAHG a3 on cb.ID = a3.CheckID and a3.Type = 1 and a3.Deleted = 0  /*库区*/
											  left  JOIN WMSHold h on a1.AreaHoldGspID = h.ID  /*暂存区表*/
			where cb.Deleted = 0 and ISNULL(cb.doubleCheck,@doubleCheck) = @doubleCheck and ISNULL(a3.AreaHoldGspID,@sa_id) = @sa_id
				  and (cb.WorkNum - cb.jobNum) > @detailCount     /*复核台工作量过来*/
				  and cb.S_id = @s_id     /*复核台仓库   */
				  and isnull(h.S_id,@s_id) = @s_id and isnull(h.Deleted,0) = 0   /*暂存区仓库*/
				  and ISNULL(h.LockStatus,0) = 0  /*未锁定状态*/
				  and ((ISNULL(h.jobNum,0) < ISNULL(h.MaxBillNum,9999) or ISNULL(h.ifHold,1) = 1))   /*暂存区是否足够*/
				  and (@RoadID = 0 or ISNULL(h.RoadID,0) = 0 or ISNULL(h.RoadID,0) = @RoadID)  /*路线*/
				  and (isnull(h.billtype,0) in (0,@ywType))   /*业务类型*/
				  and ISNULL(h.CyFs,0) in (0,@TrafficType)	 /*承运方式*/
				  and ISNULL(h.priority,0) <=@PrioRity       /*优先级*/
				  
			/*满足条件的暂存区，放入临时表，主要是针对没有关联暂存区的复核台使用*/
			delete from @tmpHold /*清除数据*/
			insert @tmpHold(level,hid,jobs)
			select top 1 h.priority level,h.ID,(h.MaxBillNum - h.jobNum) as jobs 
			from	WMSHold h   /*暂存区表*/
			where  (h.S_id = @s_id or h.S_id = 0) and h.Deleted = 0   /*暂存区仓库*/
				  and h.LockStatus = 0  /*未锁定状态*/
				  and (h.jobNum < h.MaxBillNum or h.ifHold = 1)   /*暂存区是否足够*/
				  and ((@RoadID = 0 or ISNULL(h.RoadID,0) = 0 or ISNULL(h.RoadID,0) = @RoadID))  /*路线*/
				  and (isnull(h.billtype,0) in (0,@ywType))   /*业务类型*/
				  and ISNULL(h.CyFs,0) in (0,@TrafficType)	 /*承运方式*/
				  and ISNULL(h.priority,0) <=@PrioRity       /*优先级*/
				  
			if not exists (select 1 from @tmpDesk)
			begin
				insert into WMSBillLog(billid,billtype,BillNumber,ActionDate,Comment)
				select Gspbillid,billtype,BillNumber,GETDATE(),'分配复核台失败' as Comment from gspbillidx where Gspbillid = @Gspbillid		 
			end
			else if not exists (select 1 from @tmpHold)
			begin
				insert into WMSBillLog(billid,billtype,BillNumber,ActionDate,Comment)
				select Gspbillid,billtype,BillNumber,GETDATE(),'分配暂存区失败' as Comment from gspbillidx where Gspbillid = @Gspbillid	
			end
			else
			begin	  
				/*计算剩余工作量*/
				/*update @tmpDesk set jobs = cb.jobs from (select ID,(WorkNum-jobNum) as jobs from WMSCheckBaseInfo) cb where @tmpDesk.did = cb.ID */
					  
				/*update @tmpDesk set level = 100   --设置优先级*/
				/*为了保险起见，这儿还是使用游标遍历，理论上是只需要取第一条也可以，所以正常情况是只会循环一次*/
				declare DeskCur cursor for
				select did,hid,jobs from @tmpDesk where jobs >= @detailCount order by level desc,jobs desc 
				open DeskCur	
				fetch next from DeskCur into @did,@hid,@jobs	
				
				while  @@FETCH_STATUS=0 and @succ = 0
				begin
					if @did > 0 and @hid > 0 
					begin
						/*表示复核台和暂存区都满足条件*/
						/*直接更新单据字段*/
						update gspbillidx set DeskId = @did ,HoldId = @hid where Gspbillid = @Gspbillid
						
						/*回算工作量*/
						update WMSCheckBaseInfo set jobNum = jobNum + @detailCount where ID = @did
						update WMSHold set jobNum = jobNum + 1 where ID = @hid
						set @succ = 1   /*	分配完成*/
					end
					else if @did > 0 and @hid <= 0   /*需要循环所有满足条件的暂存区*/
					begin
						/*这儿不需要循环，直接取第一个即可
						set @succHold = 0
						declare WMSHoldCur cursor for
						select hid,jobs from @tmpHold order by level desc,jobs desc 
						open WMSHoldCur	
						fetch next from WMSHoldCur into @hid,@jobs
						while  @@FETCH_STATUS=0 and @succHold = 0*/
						select top 1 @hid = hid from @tmpHold 
						if @hid > 0
						begin
							update gspbillidx set DeskId = @did ,HoldId = @hid where Gspbillid = @Gspbillid	
							/*回算工作量*/
							update WMSCheckBaseInfo set jobNum = jobNum + @detailCount where ID = @did
							update WMSHold set jobNum = jobNum + 1 where ID = @hid
							set @succ = 1   /*	分配完成*/
						end
					end	
					
					fetch next from DeskCur into @did,@hid,@jobs	
				end
				if @succ = 0
				begin
					if @did <= 0
						insert into WMSBillLog(billid,billtype,BillNumber,ActionDate,Comment)
						select Gspbillid,billtype,BillNumber,GETDATE(),'分配复核台失败' as Comment from gspbillidx where Gspbillid = @Gspbillid
					else if @hid <= 0
						insert into WMSBillLog(billid,billtype,BillNumber,ActionDate,Comment)
						select Gspbillid,billtype,BillNumber,GETDATE(),'分配暂存区失败' as Comment from gspbillidx where Gspbillid = @Gspbillid	
				end
				close DeskCur   /*关闭游标*/
				deallocate DeskCur
			end					
			
			fetch next from billCur into @Gspbillid,@s_id,@sa_id,@doubleCheck,@RoadID,@ywType,@TrafficType,@PrioRity,@detailCount  /*循环分配复核台		*/
		end
		close billCur   /*关闭游标*/
		deallocate billCur
		
	if @@ERROR > 0
		set @nRet = -1
												
								
	/*IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END*/
	RETURN @nRet

ERROR:
	/*IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL*/

	RETURN -1
	

END
GO
