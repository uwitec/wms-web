

CREATE PROCEDURE Ts_X_GetvtLogisticsGspPropertProductsNew(@BillIdList varchar(200))
AS
BEGIN
	SELECT d.p_id, c.gspflag AS GspId, c.GSPPropert, c.otcflag, c.OTCType
	FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
	        FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
			) c
			INNER JOIN (
					SELECT DISTINCT p_id
					FROM   (   SELECT d.P_id
							   FROM GSPbilldetail d INNER JOIN GSPbillidx b ON d.Gspbill_id = b.Gspbillid
							   WHERE b.Gspbillid in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@BillIdList)) 
						    ) e
            ) d
            ON  c.product_id = d.p_id 
END
GO
