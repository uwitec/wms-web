
CREATE	PROCEDURE [Ts_L_UpdateRegion]
	(@region_id	[int],
	 @name	[varchar](80),
	 @serial_number 	[varchar](26),
	 @Comment	[varchar](256),
         @szpinyin	[varchar](20) 
         )

AS
if exists(select * from region  where serial_number=@serial_number and [region_id]<> @region_id and deleted =0)
begin
	RAISERROR('编号重复！不能添加！！',16,1)
	return -2
end

UPDATE [region] 

SET      [name]	         = @name,
	 [serial_number] = @serial_number,
	 [Comment]	 = @Comment,
         [pinyin]        = @szpinyin

WHERE 
	( [region_id]	 = @region_id)
GO
