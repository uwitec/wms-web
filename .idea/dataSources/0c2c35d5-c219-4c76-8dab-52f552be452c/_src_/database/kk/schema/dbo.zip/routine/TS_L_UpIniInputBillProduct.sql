
/*
期初库存录入单商品货位、最近进价、零售价更新
add by luowei 20123-08-03
Falg ： 1、表示更新，0、不更新
*/


create procedure TS_L_UpIniInputBillProduct
(
  @bill_id int,   
  @LocationFlag int = 0,    /*货位*/
  @RecpriceFlag int = 0,    /*最近进价*/
  @RetialPriceFlag int = 0  /*零售价*/
)
as
begin
  declare @p_id int ,@s_id int,@l_id int,@y_id int,@unit_id int,@unittype int
  declare @recprice NUMERIC(25,8),@retailprice NUMERIC(25,8)
  declare product_cursor cursor for select p_id,ss_id,location_id,y_id,price,retailprice,unitid 
  from storemanagebill where bill_id = @bill_id
  
  OPEN product_cursor
  
  fetch next from product_cursor into @p_id,@s_id,@l_id,@y_id,@recprice,@retailprice,@unit_id
  

  WHILE @@FETCH_STATUS = 0
  begin
      /*---判断单位类型 add by luowei 2014-01-15*/
	  if exists(select 1 from products where product_id = @p_id and unit1_id = @unit_id)
	  set @unittype = 1
	  if exists(select 1 from products where product_id = @p_id and unit2_id = @unit_id)
	  set @unittype = 2
	  if exists(select 1 from products where product_id = @p_id and unit3_id = @unit_id)
	  set @unittype = 3
	  if exists(select 1 from products where product_id = @p_id and unit4_id = @unit_id)
	  set @unittype = 4
	  
    if @LocationFlag = 1 AND @l_id <> 0
    begin
      if exists(select 1 from LocationTrace where l_id = @l_id and s_id = @s_id and Y_ID = @y_id and billtype = 0)
         update LocationTrace set rectime = GETDATE(),p_id=@p_id/*l_id = @l_id*/
         where l_id = @l_id and s_id = @s_id and Y_ID = @y_id and billtype = 0
      else  
      insert into LocationTrace(p_id,s_id,l_id,billtype,Y_ID) values (@p_id,@s_id,@l_id,0,@y_id)
    end
    
    if exists(select 1 from company where company_id = @y_id and swarajPrice = 1 )
    begin
	  if @RecpriceFlag = 1 AND @recprice <> 0
	  begin
	    if exists(select 1 from PosPrice where p_id = @p_id and u_id = @unit_id and Y_ID = @y_id and unittype  = @unittype) 
		  update PosPrice set recprice = @recprice where p_id = @p_id and u_id = @unit_id and Y_ID = @y_id and unittype  = @unittype
		else
		  insert into PosPrice(p_id,u_id,recprice,Y_ID,unittype) values (@p_id,@unit_id,@recprice,@y_id,@unittype)  
      end		  
		
	  if @RetialPriceFlag = 1 and @retailprice <> 0
	  begin
	    if exists(select 1 from PosPrice where p_id = @p_id and u_id = @unit_id and Y_ID = @y_id and unittype  = @unittype) 
		  update PosPrice set retailprice = @retailprice where p_id = @p_id and u_id = @unit_id and Y_ID = @y_id and unittype  = @unittype
		else
		  insert into PosPrice(p_id,u_id,retailprice,Y_ID,unittype) values (@p_id ,@unit_id ,@retailprice,@y_id,@unittype)  
      end		  
    end
    else
    begin
      if @RecpriceFlag = 1 and @recprice <> 0
		update Price set recprice = @recprice where p_id = @p_id and u_id = @unit_id and unittype  = @unittype  
		
	  if @RetialPriceFlag = 1 and @retailprice <> 0
		update Price set retailprice = @retailprice where p_id = @p_id and u_id = @unit_id and unittype  = @unittype 
    end
    fetch next from product_cursor into @p_id,@s_id,@l_id,@y_id,@recprice,@retailprice,@unit_id
  end
  
CLOSE product_cursor
DEALLOCATE product_cursor

end
GO
