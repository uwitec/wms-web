

create proc ts_c_ConvertTranBill
/*with encryption*/
as
set nocount on
declare @billid int,@posguid varchar(50),@LocalPosguid varchar(50),@nY_id int
declare @LocalS_id int,@localinputman int,@localauditman int,@localeid int
declare @locationid int,@smbid int,@pid int,@sinid int,@soutid int ,@cid int, @nSin_id int
declare @BillType int, @newBillType int
declare @nZBSid int, @nZBEid int, @nYType int

/*select @LocalPosguid=sysvalue from sysconfig where [sysname]='GUID'*/
exec ts_getsysvalue 'Y_ID',@nY_id out

exec ts_getsysvalue 'GUID',@LocalPosguid out

/*select @LocalS_id=sysvalue from sysconfig where [sysname]='LocalSid'*/
exec ts_getsysvalue 'LocalSid',@LocalS_id out, @nY_id

/*select @localinputman=sysvalue from sysconfig where [sysname]='LocalInputman'*/
exec ts_getsysvalue 'LocalInputman',@localinputman out, @nY_id

/*select @localauditman=sysvalue from sysconfig where [sysname]='LocalAuditman'*/
exec ts_getsysvalue 'LocalAuditman',@localauditman out, @nY_id

/*select @localeid=sysvalue from sysconfig where [sysname]='LocalEid'*/
exec ts_getsysvalue 'LocalEid',@localeid out, @nY_id
exec ts_getsysvalue 'ZBSid',@nZBSid out
exec ts_getsysvalue 'ZBEid',@nZBEid out
select @nYType = Ytype from company where company_id = @nY_id
/*if @nYType= 2 and (@nZBSid = 0 or @nZBSid = 0) return 0*/
if @localeid =0 or @LocalS_id = 0 return 0
 
truncate table buymanagebilldts

/*总部发货单转收货单*/
	declare ConvertCur cursor for
	select billid,posguid,billtype
	from billdtsidxIN
	where billtype in (150, 152)
	
	open convertcur
	
	fetch next from convertcur into @billid,@posguid, @BillType
	
	while @@fetch_status=0
	begin
	    if @BillType = 150 
	      set @newBillType = 160
	    else if @BillType = 152
	      set @newBillType = 162
	    else set @newBillType = 0 
	      
		if @posguid<>@LocalPosguid 
		begin
			delete from billdtsidxIN where billid=@billid
			delete from salemanagebilldtsIN where bill_id=@billid
		end
		else 
		begin
                    select @nSin_id = sin_id from billdtsidxIN where billid  = @billid	

                    if exists(select 1 from storages where y_id = @nY_id and storage_id = @nSin_id ) and (@nYType <> 2)
                       set @LocalS_id = @nSin_id
		    
			insert into BuymanagebilldtsIN(smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,RowGuid,RowE_ID,YcostPrice,YGUID,
				Y_ID, instoretime)
			select smb_id,bill_id, p_id, batchno, quantity, discountprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxMoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, @LocalS_id, 0, 0, supplier_id, commissionflag, 
				comment,unitid,taxrate,0,total,iotag,InvoiceTotal ,thqty,newprice,0,aoid,RowGuid,@localeid,YcostPrice,YGUID,@nY_id, instoretime
			from SalemanagebilldtsIN where bill_id=@billid and p_id > 0
			order by smb_id
			
	
			update billdtsidxIN set billtype=@newBillType, sout_id=@LocalS_id, sin_id=@LocalS_id,c_id=Y_ID,ssmoney=0,billstates='3',Y_ID = @nY_id,
                                              jsye =ysmoney, jsflag = '0', inputman = @localinputman, auditman = @localauditman, e_id = @localeid
			where billid=@billid
			
			/*if @nYType = 2 */
			  /*update billdtsidxIN set sout_id=@nZBSid where billid=@billid												*/

			/*可以使用默认货位代替货位跟踪功能, 货位跟踪应控制，否则零售单上传后不能过账*/
			/*declare LocCur cursor for*/
			/*select smb_id,p_id,ss_id*/
			/*from BuymanagebilldtsIN*/
			/*where bill_id=@billid*/
			
			/*open LocCur*/
			
			/*fetch next from LocCur into @smbid,@pid,@LocalS_id*/
			
			/*while @@fetch_status=0*/
			/*begin*/
			/*	select @locationid=0*/
			
			/*	select @locationid=l_id from locationtrace where p_id=@pid and s_id=@LocalS_id and billtype = @newBillType and Y_ID = @nY_id*/
			
				/*if @locationid<>0 update BuymanagebilldtsIN set location_id=@locationid where smb_id=@smbid*/
		
				/*fetch next from LocCur into @smbid,@pid,@LocalS_id*/
			/*end*/
			/*close LocCur*/
			/*deallocate LocCur*/

		end
		fetch next from convertcur into @billid,@posguid, @BillType
	end

	close convertcur
	deallocate convertcur
GO
