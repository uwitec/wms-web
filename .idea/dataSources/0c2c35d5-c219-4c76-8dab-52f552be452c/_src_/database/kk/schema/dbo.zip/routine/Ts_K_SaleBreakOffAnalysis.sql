

CREATE PROCEDURE Ts_K_SaleBreakOffAnalysis(@Begin DATETIME, @End DATETIME, @YId INT, @SupplierId INT, @EId INT, @Factory VARCHAR(100), @PriceType INT, @CgId INT, @szID VARCHAR(3000))
AS
BEGIN
	/*zjx--2017-04-25--处理（新）自定义类别*/
    DECLARE @info_ID INT 
    DECLARE @ColName VARCHAR(100)
    DECLARE @szSql varchar(2000)
    DECLARE @classid varchar(100)
    CREATE TABLE #PORDUCTS ([p_id] [int] NOT NULL DEFAULT(0))
    if @szID<>'' 
    begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
            /*zjx.通过选择自定义类别id的字符串获取class_ID字符串串*/
			SELECT @classid = dbo.GetCateClassids(@szID)  
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
            /*根据所选择的类别ID找出所关联的商品*/
		    set @szSql =  'INSERT INTO #PORDUCTS(p_id) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @ColName + 
			' in (select type  from DecodeStr(''' +@classid +'''))'  
		    exec (@szSql)
    end
    else
    begin
        INSERT INTO #PORDUCTS(p_id)
		SELECT  product_id FROM vw_Products	
    end
	 
	 SELECT k.PId, k.BreakOffDate, k.BreakOffCount, k.RecPrice, k.EName, k.Price,
	        k.serial_number, k.name, k.alias, k.[standard], k.permitcode, k.makearea, k.UnitName, k.Factory,
	        k.SupplierName, k.FristPurchaseDate, k.LastPurchaseDate, k.SaleFreq, k.AvgSaleDay, 
	        CASE WHEN k.Price = 0 THEN 0.00 ELSE ((k.Price - k.RecPrice) * 100 / k.Price) END AS MlRate,
	        (k.Price * k.BreakOffCount * k.AvgSaleDay) AS GuessTotal, 
	        CASE WHEN k.Price = 0 THEN 0.000 ELSE (k.Price * k.BreakOffCount * k.AvgSaleDay) * ((k.Price - k.RecPrice) / k.Price) END AS GuessMl
		FROM (
			SELECT b.PId, b.BreakOffDate, b.BreakOffCount, ISNULL(r.recprice, 0.00) AS RecPrice, ISNULL(e.name, '') AS EName,
				   CASE @PriceType WHEN 0 THEN ISNULL(r.retailprice, 0.00) WHEN 1 THEN ISNULL(r.price1, 0.00) WHEN 2 THEN ISNULL(r.price2, 0.00) 
								   WHEN 3 THEN ISNULL(r.price3, 0.00) WHEN 4 THEN ISNULL(r.price4, 0.00) WHEN 5 THEN ISNULL(r.gpprice, 0.00) 
								   WHEN 6 THEN ISNULL(r.glprice, 0.00) WHEN 7 THEN ISNULL(r.specialprice, 0.00)
								   WHEN 8 THEN ISNULL(r.recprice, 0.00) WHEN 9 THEN ISNULL(r.lowprice, 0.00) END AS Price,
				   p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea, u.name AS UnitName, p.Factory, 
				   dbo.GetSaleBreakOffAnalysisInfo(0, @YId, b.PId, @Begin, @End, b.BreakOffCount) AS SupplierName,
				   dbo.GetSaleBreakOffAnalysisInfo(1, @YId, b.PId, @Begin, @End, b.BreakOffCount) AS FristPurchaseDate,
				   dbo.GetSaleBreakOffAnalysisInfo(2, @YId, b.PId, @Begin, @End, b.BreakOffCount) AS LastPurchaseDate,
				   CAST(dbo.GetSaleBreakOffAnalysisInfo(3, @YId, b.PId, @Begin, @End, b.BreakOffCount) AS INT) AS SaleFreq,
				   CAST(dbo.GetSaleBreakOffAnalysisInfo(4, @YId, b.PId, @Begin, @End, b.BreakOffCount) AS NUMERIC(25,8)) AS AvgSaleDay 
				FROM (
					SELECT a.p_id AS PId, MIN(a.[datetime]) AS BreakOffDate, COUNT(*) AS BreakOffCount 
						FROM (
							SELECT p.[datetime], p.p_id FROM PerStockData p 
							WHERE p.y_id = @YId AND p.[datetime] BETWEEN @Begin AND @End
							GROUP BY p.[datetime], p.p_id HAVING SUM(p.qty) = 0
					) a GROUP BY a.p_id
			) b INNER JOIN products p ON b.PId = p.product_id
				INNER JOIN #PORDUCTS pp ON p.product_id = pp.p_id
				INNER JOIN unit u ON p.unit1_id = u.unit_id
				LEFT JOIN price r ON p.product_id = r.p_id AND p.unit1_id = r.u_id
				LEFT JOIN productbalance i ON p.product_id = i.p_id AND i.Y_id = @YId
				LEFT JOIN employees e ON i.Emp_id = e.emp_id
			WHERE (@Factory = '' OR p.Factory LIKE '%' + @Factory + '%') AND (ISNULL(i.Emp_id, 0) = @EId OR @EId = 0) AND 
			      (ISNULL(i.Supplier_id, 0) = @SupplierId OR @SupplierId = 0)
		) k
	drop table #PORDUCTS
END
GO
