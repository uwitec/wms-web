
CREATE FUNCTION DaysThisMonth( @d  DateTime)
RETURNS INT AS  
BEGIN 
  DECLARE @yy INT,  @mm INT
  SET @yy = DATEPART(yyyy, @d)
  SET @mm = DATEPART(mm, @d)
  RETURN dbo.DaysPerMonth( @yy, @mm)
END
GO
