











CREATE VIEW dbo.vw_c_storebrrowini
AS
SELECT dbo.storebrrowini.p_id, ISNULL(SUM(dbo.storebrrowini.quantity), 0) AS quantity, 
      ISNULL(SUM(dbo.storebrrowini.costtotal), 0) AS costtotal,
      dbo.storebrrowini.commissionflag, dbo.clients.class_id AS cclass_id, 
      dbo.products.class_id AS pclass_id, isnull(Y.Class_ID,'')YClass_ID,isnull(Y.[name],'')Yname
FROM dbo.storebrrowini LEFT OUTER JOIN
      dbo.products  ON dbo.storebrrowini.p_id = dbo.products.product_id LEFT OUTER JOIN
      dbo.clients   ON dbo.storebrrowini.c_id = dbo.clients.client_id    LEFT OUTER JOIN
      dbo.Company Y ON dbo.storebrrowini.Y_id = Y.Company_id 
GROUP BY dbo.storebrrowini.p_id, dbo.storebrrowini.commissionflag, dbo.clients.class_id, 
      dbo.products.class_id,Y.Class_ID,Y.[name]
GO
