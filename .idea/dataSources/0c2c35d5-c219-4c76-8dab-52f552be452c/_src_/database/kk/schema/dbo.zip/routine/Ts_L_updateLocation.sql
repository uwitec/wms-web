








CREATE PROCEDURE [Ts_L_updateLocation]
	(@loc_id	[int],
	 @s_id		[int],
	 @loc_code	[varchar](30),
	 @loc_name	[varchar](30),
	 @loc_comment	[varchar](20),
     @slf_id        int ,
     @loctype		int,
     @said			int
)

AS UPDATE [location] 

SET  [s_id]	 = @s_id,
	 [loc_code]	 = @loc_code,
	 [loc_name]	 = @loc_name,
	 [loc_comment]	 = @loc_comment ,
     [Shelfid]       = @slf_id,
     loctype=@loctype, 
     sa_id = @said
 
WHERE 
	( [loc_id]	 = @loc_id)
GO
