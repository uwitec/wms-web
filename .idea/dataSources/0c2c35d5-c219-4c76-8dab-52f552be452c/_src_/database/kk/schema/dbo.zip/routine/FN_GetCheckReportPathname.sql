/* =============================================*/
/* Author:		yh*/
/* Create date: 2014-11-20*/
/* Description:	合并检验报告路径*/
/* =============================================*/
CREATE FUNCTION dbo.FN_GetCheckReportPathname
(
  @p_id int,
  @batchno varchar(100),
  @c_id int
)
returns varchar(1000)
AS
BEGIN
	/* Declare the return variable here*/
	declare @Pathname varchar(1000); 
    select @Pathname=ISNULL(@Pathname + ',', '')+Pathname from medreport where p_id = @p_id and batchno = @batchno and c_id = @c_id
	
	RETURN @Pathname

END
GO
