


/*合同查询
@cMode=0 以单据日期筛选
	    =1 以过帐日期筛选

********************************************/
CREATE   PROCEDURE TS_C_QrPriceIdx
(	@Begindate DATETIME,
	@EndDate   DATETIME,
	@nBillType INT = 0,
	@nP_id	   INT,
    @nYClassid VARCHAR(50) = '',
    @nloginEID INT = 0,
    @nRClassid VARCHAR(60) = ''
)
AS
/*Params Ini begin*/
if @nBillType is null  SET @nBillType = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @nRClassid is null  SET @nRClassid = ''
/*Params Ini end*/
SET NOCOUNT ON
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
   end   

/*---职员授权*/

    DECLARE @Y TABLE ([ClassID] VARCHAR(60))
    IF @nYClassid <> '' 
    BEGIN
        INSERT INTO @Y
        SELECT DISTINCT b.class_id FROM company a, region b 
        WHERE a.region_id = b.region_id AND a.class_id = @nYClassid	
    END
    
    declare @y_id int /*存放查询调价的分支机构*/
    select @y_id=company_id from company where class_id = @nYClassid
    
    
    SELECT CONVERT(DATETIME,'2999-01-01',20) AS OrderValidDate,'' as TranfStates,
	       b.billid,b.billtype,b.billdate,b.billnumber, b.billstates,
	       isnull(b.inputman,'') as inputman , isnull(b.auditman,'') as auditman,
	       isnull(b.note,'') as note,isnull(b.SUMmary,'') as SUMmary,0.0000 AS quantity,
           0.0000 AS ysmoney,0.0000 AS ssmoney,0.0000 as araptotal,0.00 AS taxrate,
           CAST(0 AS NUMERIC(25,8)) AS ComeQty,
           CAST(0 AS NUMERIC(25,8)) AS UnComeQty,
	       CAST(0 AS DATETIME) AS auditdate,
		   billname=CASE b.billtype	WHEN 140 THEN '价格调整单' END,
	       isnull(b.ename,'') AS employeename,
	       isnull(b.auditmanname,'') AS auditmanname,
	       isnull(b.inputmanname,'') AS inputmanname,
	       ' ' AS accountname,
	       isnull(b.departmentname,'') AS departmentname,
	       isnull(b.regionname,'')  AS regionname,
	       ' ' AS cname,
	       isnull(vp.serial_number,'') as serial_number,isnull(vp.name,'') as name,
	       isnull(vp.standard,'') as standard,isnull(vp.makearea,'') as makearea,ISNULL(u.name,' ') AS unitname1,
	       vp.product_id,
	       a.retailprice,a.price1,a.price2,a.price3,a.price4,a.glprice,a.gpprice,a.specialprice,a.recprice,a.lowprice,
	       '' as Posid,	 
	       CASE WHEN b.region_id > 0 THEN '' ELSE '' END AS PosName,
	       isnull((select top 1 barcode from barcode where p_id=vp.product_id order by barcode_id),' ')barcode,
           a.oldretailprice,(a.retailprice-a.oldretailprice) as diffretailprice,0 as printcount,'' as sendcname
    FROM   vw_c_priceidx b
           RIGHT JOIN pricebill a ON  b.billid = a.bill_id
           LEFT JOIN products vp ON  vp.product_id = a.p_id
           LEFT JOIN unit u ON  a.unitid = u.unit_id
          /* LEFT JOIN Company s ON  b.posid = s.Company_ID */
    WHERE ((b.posid like +'%,'+ cast(@y_id as varchar) )or(b.posid like cast(@y_id as varchar) +',%') or (b.posid like cast(@y_id as varchar)) or (b.posid like '%,'+cast(@y_id as varchar)+',%') ) and /*过滤机构*/
           b.billtype = @nBilltype AND b.billdate BETWEEN @Begindate AND @EndDate AND (@nP_id = 0 OR a.p_id = @nP_id) AND 
          (@employeestable = 0 OR ((b.eclass_id = '') OR (EXISTS(SELECT u.psc_id FROM userauthorize u 
                                                                 WHERE u.e_id=@nloginEID AND u.Type = 'E' AND b.eclass_id LIKE u.psc_id + '%')))) AND
          (@CompanyTable = 0 OR ((@nYClassID = '') OR (EXISTS(SELECT u.psc_id FROM userauthorize u 
                                                               WHERE u.e_id=@nloginEID AND u.Type = 'Y' AND b.PosClass_id LIKE u.psc_id+'%')))) AND
          (@nRClassid = '' OR b.regclass_id LIKE @nRClassid + '%')/* AND*/
          /*(b.regclass_id IN (SELECT ClassID FROM @Y))*/
GO
