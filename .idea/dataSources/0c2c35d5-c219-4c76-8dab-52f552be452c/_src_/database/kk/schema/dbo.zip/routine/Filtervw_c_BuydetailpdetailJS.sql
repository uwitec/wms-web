
CREATE FUNCTION Filtervw_c_BuydetailpdetailJS(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     pd.pd_id, pd.billid, pd.p_id, pd.s_id, pd.quantity, pd.price, pd.total, 
		           CASE WHEN dbo.A_GetSubLimit(2, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costprice ELSE 0 END AS costprice, 
		           CASE WHEN dbo.A_GetSubLimit(2, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costtotal ELSE 0 END AS costtotal, pd.taxprice, pd.taxtotal, pd.batchno, pd.makedate, 
							  pd.validdate, pd.commissionflag, pd.supplier_id, pd.location_id, pd.storetype, pd.price_id, pd.order_id, pd.unitid, pd.smb_id, pd.comment, pd.jsprice, 
							   pd.class_id,pd.sclass_id,pd.sname,pd.AOID, pd.pdY_id,pd.standard,pd.makearea,pd.pname,
							  pd.locname,pd.suppliername,pd.Reclass_id,pd.Rename,pd.factory,pd.costtaxprice,pd.costtaxrate,pd.costtaxtotal
		FROM         dbo.vw_c_BuyDetailpDetailJS AS pd INNER JOIN
							  dbo.products AS p ON pd.p_id = p.product_id
GO
