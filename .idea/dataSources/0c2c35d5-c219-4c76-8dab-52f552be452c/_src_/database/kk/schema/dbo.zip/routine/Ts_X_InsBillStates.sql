
CREATE       PROCEDURE [Ts_X_InsBillStates]
 (  @mode VARCHAR(10) = '',					/*B单据主表P明细表*/
	@bill_id [int] = 0 				/* 单据id*/
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/

if @mode = null set @mode = 0
if @bill_id = null set @bill_id = 0


if @bill_id > 0 
begin
	if exists(select 1 from BillStates where Bill_id=@bill_id and SeachType=@mode)  /*更新*/
	begin
       update BillStates set [delete] = 0 where Bill_id=@bill_id and SeachType=@mode
	end
	else
	begin
	  INSERT INTO [BillStates] 
		  (
			[bill_id] ,			
			[seachType] ,		
			[delete]		
		  )
		 
	  VALUES 
		 (
			@bill_id ,			
			@mode ,				
			0
		  )
    end
  return @@ROWCOUNT
end
GO
