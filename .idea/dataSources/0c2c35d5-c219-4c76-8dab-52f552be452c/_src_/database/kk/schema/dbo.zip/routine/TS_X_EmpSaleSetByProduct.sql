
/* 查看职员月销售完成情况  按商品
  xxx 2015-01-30
*/

create procedure TS_X_EmpSaleSetByProduct
(
  @szbegindate varchar(20),  /*通过开始，结束时间来确定时间区域*/
  @szenddate varchar(20),
  @Eclass_id varchar(30) = '', /*职员class_id*/
  @OperatorID int              /*操作员id*/
)

as
begin
/*----------授权控制----------------------*/
declare @ClientTable int, @Companytable int,@employeestable int 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*----------授权控制结束-------------------*/

declare @c_id int
declare @e_id int
declare @y_id int
 
 /* 
if @YClass_id = ''
  set @y_id = 0
else
  select @y_id = company_id from company where class_id = @YClass_id*/
  
if @Eclass_id = '' 
  set @e_id = 0 
else
  select @e_id = emp_id from employees where class_id = @Eclass_id      


  /*---------------创建临时表用于存储需要的结构---------------*/
  create table #tmp
               (
                /* e_id int,	--职员
                 class_id varchar(60),
                 [职员|名称] varchar(100),
                 [职员|隶属机构]   varchar(50),
                 [职员|部门] varchar(100),
                 [职员|联系电话] varchar(100), */
                 p_id int,	/*商品*/
                 [商品|名称] varchar(200),
                 [商品|通用名]   varchar(200),
                 [商品|规格] varchar(200),
                 [商品|产地] varchar(200)           
               )
   declare @vardatedeff int  /*时间差变量*/
   declare @monthvalue varchar(20)
   declare @month varchar(50)  /*月份列名称*/
   declare @sql varchar(500)
   
   set @vardatedeff = 0
   set @monthvalue = 0
   set @monthvalue = @szbegindate
   set @sql = ''
   set @month = ''
   set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差*/
       
   while(@vardatedeff>0)
   begin
     set @month = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月' /*得到年月份列*/
     set @sql =' ALTER TABLE #tmp Add ['+@month+'|数量额度'+'] NUMERIC(25,8) not NULL default(0) 
			     ALTER TABLE #tmp Add ['+@month+'|完成数量'+'] NUMERIC(25,8) not NULL default(0) 
			     ALTER TABLE #tmp Add ['+@month+'|数量完成比率'+'] NUMERIC(25,8) not NULL default(0) 
			     ALTER TABLE #tmp Add ['+@month+'|金额额度'+'] NUMERIC(25,8) not NULL default(0)  
			     ALTER TABLE #tmp Add ['+@month+'|完成金额'+'] NUMERIC(25,8) not NULL default(0)
			     ALTER TABLE #tmp Add ['+@month+'|金额完成比率'+'] NUMERIC(25,8) not NULL default(0)'
     exec (@sql)
     /*print @sql*/
     set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20)  
     set @vardatedeff = @vardatedeff -1
   end
   /*-将查询的商品全部类别插入临时表中*/
   /*e_id,class_id,[职员|名称],[职员|隶属机构],[职员|部门],[职员|联系电话],*/
   insert #tmp(p_id,[商品|名称],[商品|通用名],[商品|规格],[商品|产地]) 
   select product_id,name,alias,standard,makearea from  products p
   where p.deleted = 0 order by  product_id
   
   /*----------获取选择时间段内的职员销售情况-----------------*/
  SELECT product_id as p_id,sm.RowE_id as e_id,ISNULL(sm.MMdate,'') AS MMdate,
		 ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
		 ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
		 ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
		 ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
		 ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
		 ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0) AS [SendTotal],
		 ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

		 ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
		 ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
		 (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as NUMERIC(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

    INTO  #t
	from
	(
	   select product_id,name,alias,standard,makearea from products p 
	   where p.deleted = 0  
	   ) as pd
	LEFT JOIN
	(SELECT YPD.p_id,YPD.[RowE_ID],YPD.MMdate,
	        ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]  ELSE -YPD.[QUANTITY] END), 0) AS [QUANTITY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TAXTOTAL]  ELSE -YPD.[TAXTOTAL] END), 0) AS [TAXTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TOTALMONEY] ELSE  -YPD.[TOTALMONEY] END),0) AS [SALETOTAL],
		
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0) AS [SENDQTY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDCOSTTOTAL]  ELSE -YPD.[SENDCOSTTOTAL] END),0) AS [SENDCOSTTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY  ELSE -YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY END),0) AS [SENDTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]*YPD.[COSTPRICE]  ELSE -YPD.[QUANTITY]*YPD.[COSTPRICE] END), 0) AS [COSTTOTAL]
       FROM  
         (SELECT sm.RowE_id,sm.p_id,sm.quantity,costprice,totalmoney,taxtotal,
                 sm.SendQTY,sm.SendCostTotal,B.billtype,SUBSTRING(convert(varchar(20),b.billdate,20),1,7) as MMdate   
            FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数                 */
            LEFT JOIN billidx   b  on sm.bill_id=b.billid
            LEFT JOIN Products  p  on p.product_id=SM.p_id
            LEFT JOIN employees RE on re.emp_id=SM.RowE_id
            LEFT JOIN storages  S  on S.storage_id=SM.ss_id
            LEFT JOIN Clients   C  on B.c_id=c.client_id
            LEFT JOIN employees E  on b.inputman=E.emp_id 
            LEFT JOIN Company   Y  on Y.Company_id=b.y_id            
            WHERE ([Billdate] BETWEEN   @szbegindate AND  @szenddate) and 
                  B.[billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and
                  [Billstates]=0 AND aoid in (0,5) and p_id>0 and
                  (@e_id = 0 or sm.RowE_id= @e_id) 
          
         )YPD
       GROUP BY YPD.p_id,YPD.[ROWE_ID], YPD.MMdate
       ) SM on pd.product_id = sm.p_id
       GROUP BY product_id, RowE_id,sm.MMdate
       having (@e_id = 0 or RowE_id = @e_id)
       ORDER BY p_id,e_id, SM.MMdate
            		  
	/*********************end**********************/
	
	
	declare @upmonth varchar(20)
	declare @upYear varchar(20)
	declare @monthsetTotal varchar(50)
	declare @monthsetqty varchar(50)		
	declare @monthqty varchar(50)
	declare @monthTotal varchar(50)
	declare @monthqtyRata varchar(50)
	declare @monthmoneyRata varchar(50)
	
	declare @monthTotalValue numeric(18,2)	
	declare @upsql varchar(500)
	
	set @monthvalue = @szbegindate
	set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差            */
	while(@vardatedeff>0)
	begin
	  set @upYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'
	  if LEN(convert(varchar(10),DATEPART(MM,@monthvalue))) =1 
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+'0'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	  else
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	      
	  set @monthsetqty = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|数量额度'  /*得到月份列*/
	  set @monthsetTotal = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|金额额度' /*得到月份列*/
	  set @monthqty = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|完成数量'  /*得到月份列*/
	  set @monthTotal = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|完成金额' /*得到月份列*/
	  	  
	  set @monthqtyRata =  convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|数量完成比率' /*得到月份列*/
	  set @monthmoneyRata =  convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|金额完成比率' /*得到月份列*/
	  /*取设置的对应值select * from employeesSalesTotal*/
      
	  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 1
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.OneM, ['+@monthsetTotal+'] = e.OneT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	    /*select @monthsetqty = OneM, @monthsetTotal = OneT  from employeesSeting WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 2
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.twoM, ['+@monthsetTotal+'] = e.twoT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	 else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 3		
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.threeM, ['+@monthsetTotal+'] = e.threeT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	 else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 4  
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.fourM, ['+@monthsetTotal+'] = e.fourT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 5
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.fiveM, ['+@monthsetTotal+'] = e.fiveT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 6
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.sixM, ['+@monthsetTotal+'] = e.sixT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 7
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.sevenM, ['+@monthsetTotal+'] = e.sevenT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 8
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.eightM, ['+@monthsetTotal+'] = e.eightT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 9
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.nineM, ['+@monthsetTotal+'] = e.nineT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 10
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.tenM, ['+@monthsetTotal+'] = e.tenT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 11
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.elenM, ['+@monthsetTotal+'] = e.elenT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear ='''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
	else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 12
	  begin
		set @upsql = 'update #tmp set ['+@monthsetqty+'] = e.twentyM, ['+@monthsetTotal+'] = e.twentyT from employeesSeting e where e.e_id = ' + convert(varchar(10),@e_id)+ ' and e.OneYear = '''+@upYear+''' and e.p_id = #tmp.p_id' /*+ CHAR(39)+@upYear+CHAR(39) +*/
	    exec(@upsql)
	  end
		/*END--取设置的对应值*/

	  /*select * from #t */
	  /*select * from #tmp*/
	  set @upsql = 'update #tmp set ['+@monthqty+'] = #t.[SendQTY],['+@monthTotal+'] = #t.[SendTotal]  from #t where #t.p_id = #tmp.p_id and #t.MMdate ='+CHAR(39)+@upmonth+CHAR(39)
	/*  print @upsql*/
	  exec(@upsql)
	
	/* update #tmp set @monthcolset= #t.[TaxTotal],@monthcolTotal =  (cast( @monthsetValue  as NUMERIC(25,8))) from #t where #t.e_id = #tmp.e_id and #t.MMdate =@upmonth*/
	  /****更新比率（注意未设置额度的就不能算比率）*****/	  
	  set @upsql = 'update #tmp set ['+@monthqtyRata+'] = ['+@monthqty+']*1.0/['+@monthsetqty+']  from #t where #t.p_id = #tmp.p_id and #t.MMdate ='+CHAR(39)+@upmonth+CHAR(39) + '  and ['+@monthsetqty+'] > 0'
	  /*print @upsql*/
	  exec(@upsql)	

	  set @upsql = 'update #tmp set ['+@monthmoneyRata+'] = ['+@monthTotal+']*1.0/['+@monthsetTotal+']  from #t where #t.p_id = #tmp.p_id and #t.MMdate ='+CHAR(39)+@upmonth+CHAR(39) + '  and ['+@monthsetTotal+'] > 0'
/*	  print @upsql*/
	  exec(@upsql)
	  /****更新比率（注意未设置额度的就不能算比率）*****/	  
	  set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20) 
	  set @vardatedeff = @vardatedeff -1
	end  
		
	SELECT * FROM #tmp
    drop table #tmp
    drop table #t            
end
GO
