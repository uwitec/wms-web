


CREATE VIEW dbo.VW_C_WlMx
AS
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(vp.pname, '') AS comment, 0 AS a_id, abs(vp.quantity) AS quantity, 
      vp.taxprice AS taxprice, jdmoney = CASE WHEN vb.billtype IN (10, 21, 112, 53,210,221) 
      THEN abs(isnull(vp.taxtotal, 0)) ELSE - (abs(isnull(vp.taxtotal, 0))) END, vb.c_id, 
      vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,vp.comment as pcomment
FROM vw_c_billidx vb, VW_L_pDetailBySMBM vp
WHERE vb.billid = vp.billid AND vb.billtype IN (10, 11, 20, 21, 112, 122, 53, 54,210,211,220,221) AND 
      vb.billstates = '0' and vp.aoid=0
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.clientname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN vb.billtype IN (10, 21, 112, 53,210,221) THEN - abs(isnull(va.jdmoney, 0)) 
      ELSE abs(isnull(va.jdmoney, 0)) END, vb.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype IN (10, 11, 20, 21, 112, 122,53,54,210,211,220,221) AND 
     ((LEFT(va.aclass_id, 12) IN ('000001000003', '000001000004'))or(LEFT(va.aclass_id, 18) IN ('000004000003000004')) or (LEFT(va.aclass_id, 12) IN ('000001000009', '000002000005')) ) AND 
      vb.billstates = '0'
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.accountname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN vb.billtype IN (81, 62) THEN abs(isnull(va.jdmoney, 0)) 
      ELSE - (abs(isnull(va.jdmoney, 0))) END, vb.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype IN (61, 62, 80, 81) AND ((LEFT(va.aclass_id, 12) 
      NOT IN ('000001000005', '000002000001', '000001000003', '000001000004')) ) AND 
      vb.billstates = '0'
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.accountname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN vb.billtype IN (81, 62) THEN - abs(isnull(va.jdmoney, 0)) 
      ELSE (abs(isnull(va.jdmoney, 0))) END, vb.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype IN (61, 62, 80, 81) AND ((LEFT(va.aclass_id, 12) 
      IN ('000001000003', '000001000004'))or(LEFT(va.aclass_id, 18)  IN ('000004000003000004')) or (LEFT(va.aclass_id, 12)  IN ('000001000009', '000002000005')) ) AND vb.billstates = '0'
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.clientname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN vb.billtype IN (24, 25, 66, 67) THEN - (isnull(va.jdmoney, 0)) 
      ELSE va.jdmoney END, va.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype IN (64, 65, 66, 67, 16, 17, 24, 25) AND 
      ((va.aclass_id IN ('000001000005', '000002000001')) )AND vb.billstates = '0'
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.clientname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN vb.billtype IN (15, 23,170) THEN  (isnull(va.jdmoney, 0)) 
      ELSE -(isnull(va.jdmoney, 0)) END, va.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype IN (15, 23,170) AND 
      ((va.aclass_id NOT IN ('000001000005', '000002000001')) or (LEFT(va.aclass_id, 12)  IN ('000001000009', '000002000005')) ) AND vb.billstates = '0'
UNION ALL
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.clientname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      jdmoney = CASE WHEN va.aclass_id = '000002000001' THEN - (isnull(va.jdmoney, 0)) 
      ELSE (isnull(va.jdmoney, 0)) END, va.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va
WHERE vb.billid = va.billid AND vb.billtype = 90 AND va.aclass_id IN ('000001000005', 
      '000002000001') AND vb.billstates = '0'
UNION All
SELECT vb.billid, vb.billdate, vb.billnumber, vb.billtype, vb.inputman, vb.billstates, vb.E_ID,
      isnull(va.clientname, '') AS comment, va.a_id, 0 AS quantity, 0 AS taxprice, 
      isnull(va.jdmoney, 0) As jdmoney, 
      va.c_id, vb.note AS dcomment,vb.Y_id,vb.YClass_id,vb.CClass_id,vb.jsye,'' as pcomment
FROM vw_c_billidx vb, vw_c_adetail va 
WHERE vb.billid = va.billid AND vb.billtype = 185 AND va.aclass_id= '000001000005' AND vb.billstates = '0'
GO
