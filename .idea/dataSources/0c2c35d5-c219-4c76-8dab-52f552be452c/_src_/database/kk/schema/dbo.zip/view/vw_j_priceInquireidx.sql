
CREATE  VIEW dbo.vw_j_priceInquireidx AS 
SELECT dbo.priceInquireidx.*, isnull(dbo.clients.name, '') as cname, 
       isnull(dbo.employees.name, '') as ename, isnull(dbo.clients.class_id, '') as cclass_id, 
      isnull(dbo.employees.class_id, '') as eclass_id, isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(Y.class_id,'') as YClass_id,
      isnull(Y.[name],'') as Yname
from dbo.priceInquireidx left outer join
      dbo.clients on dbo.priceInquireidx.c_id = dbo.clients.client_id left outer join
      dbo.employees on dbo.priceInquireidx.e_id = dbo.employees.emp_id
      left outer join employees emp on dbo.priceInquireidx.inputman=emp.emp_id
      left outer join employees empa on dbo.priceInquireidx.auditman=empa.emp_id
      left outer join department dep on dbo.priceInquireidx.department_id=dep.departmentid
      left outer join region reg on dbo.priceInquireidx.region_id=reg.region_id
      left outer join COMPANY  Y  on Y.Company_id=dbo.priceInquireidx.Y_id
GO
