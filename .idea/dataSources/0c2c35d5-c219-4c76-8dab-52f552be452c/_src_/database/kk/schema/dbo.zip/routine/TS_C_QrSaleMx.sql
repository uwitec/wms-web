

/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/
/*0 采购批次明细表*/
/*1 销售批次明细表*/
CREATE PROCEDURE [TS_C_QrSaleMx]
(	@BeginDate 		VARCHAR(10)='',
	@EndDate	 	  VARCHAR(10)='',
	@szCClass_ID	VARCHAR(30)='',
        @szEClass_id  varchar(30)='',
        @szInputman		varchar(30)='',
	@nPID			    INT=0,
	@nSortType		INT=0,
        @nYClassid                 varchar(50)='',
        @nloginEID               int=0,
        @isaddDate              int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
    @szregionid    int=0,   /*片区ID*/
    @strBusinessType varchar(50) = '0'     

)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_id is null  SET @szEClass_id = ''
if @szInputman is null  SET @szInputman = ''
if @nPID is null  SET @nPID = 0
if @nSortType is null  SET @nSortType = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @strBusinessType is null set @strBusinessType = '0'
/*--片区ID*/
declare @regid1 int,@regid2 int
select @regid1=@szregionid,@regid2=@regid1
if @regid1=0 set @regid2=2147483647

set @strBusinessType = @strBusinessType+',5'

/*Params Ini end*/
SET NOCOUNT ON
/*DECLARE*/
  /*@SQLScript VARCHAR(8000)*/
  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),@szsql2      varchar(8000)
  Declare @isfinally int

  Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@Filteemployees  varchar(8000),@FilteStore   varchar(8000),
                                                                 @Filteemployees2 varchar(8000)
       
  select  @FilteClient='',@FilteCompany='',@Filteemployees ='',@FilteStore ='',
                                           @Filteemployees2=''
  IF @szCClass_ID='' SET @szCClass_ID='%%'
  ELSE SET @szCClass_ID=@szCClass_ID+'%'

  IF @szEClass_ID='' SET @szEClass_ID='%%'
  ELSE SET @szEClass_ID=@szEClass_ID+'%'

  IF @szInputman='' SET @szInputman='%%'
  ELSE SET @szInputman=@szInputman+'%'

  if OBJECT_ID('tempdb..##BuyMX ') is not null
		drop table ##BuyMx
  if OBJECT_ID('tempdb..##SaleMX') is not null
		drop table ##SaleMx

  if OBJECT_ID('tempdb..#Clienttable') is not null
    drop table #Clienttable 
  create table #Clienttable([id] int) 
  if OBJECT_ID('tempdb..#Companytable') is not null
    drop table #Companytable 
  create table #Companytable([id] int)
  if OBJECT_ID('tempdb..#employeestable') is not null
    drop table #employeestable 
  create table #employeestable([id] int)
  if OBJECT_ID('tempdb..#storagestable') is not null
    drop table #storagestable 
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

  IF @nSortType IN (0, 2) GOTO ProductBuyMx/*采购清单*/
  ELSE 
  IF @nSortType IN (1, 3) GOTO ProductSaleMx/*销售清单*/
  GOTO SUCCEE

ProductBuyMx:
BEGIN

SELECT * into  ##BuyMX from 
			(select VS.[Smb_ID],
			VS.[Bill_ID],
			VB.[Billdate],
			VB.[Billnumber],
			VB.[Billstates],
			VB.[Ename],
			VB.[Billtype],
			VB.[Inputman],
			VB.[Auditman],
			VB.[invoicetype],
			VB.B_CustomName1,
			VB.B_CustomName2,
			VB.B_CustomName3,	
			P.[product_id] as P_id,
			P.[Code],
			P.[Name] AS [PName],                 
			P.[Standard],
			P.[Makearea],
			P.[Medtype],
			P.Custompro1, P.Custompro2, P.Custompro3, P.Custompro4, P.Custompro5,
			P.[Unitname1] AS [Unitname],
			p.tc1,
			p.tc2,
			p.tcmoney,
			isnull(VP.e_name,'') e_name ,
			isnull(VP.C_Name,'') c_name ,
			VS.[Validdate],
			VS.[Batchno],
			case when VB.[Billtype] in (21,25,221) THEN -VS.totalmoney ELSE VS.totalmoney END AS [totalmoney],
			dbo.Decimalbits(2,cast(VS.totalmoney/VS.quantity as NUMERIC(25,8)))[Discountprice],
			VS.[Taxrate]*100 AS [Taxrate],
			cast(VS.[Taxtotal]/VS.quantity as NUMERIC(25,8)) AS [Taxprice],
			VS.comment,
			isnull(Vb.[cname],'')suppliername,
			CASE WHEN VB.[Billtype] in (21,25,221) THEN -VS.Taxmoney ELSE VS.Taxmoney END AS [Taxmoney],
			CASE WHEN VB.[Billtype] in (21,25,221) THEN -VS.[Quantity] ELSE VS.[Quantity] END AS [Quantity],
			CASE WHEN VB.[Billtype] in (21,25,221) THEN -VS.[Taxtotal] ELSE VS.[Taxtotal] END AS [Taxtotal],
			CASE WHEN VB.[Billtype] in (21,25,221) THEN -VS.[SendQTY] ELSE VS.[SendQTY] END AS [SendQTY],
			CASE WHEN VB.[Billtype] in (21,25,221) THEN dbo.Decimalbits(3,-VS.[SendCostTotal]) 
			ELSE dbo.Decimalbits(3,VS.[SendCostTotal]) END AS [SendCostTotal]
			,0 as mltotal,
			vb.c_id,
			vs.Y_id,
			vs.RowE_id,isnull(vs.factory,'') as factory,
		    CASE WHEN VB.[Billtype] in (21,25,221) THEN -VS.[CostTaxtotal] ELSE VS.[CostTaxtotal] END AS [CostTaxtotal],
			cast(VS.[costtaxtotal]/VS.quantity as NUMERIC(25,8)) AS [CostTaxprice],
			vs.costtaxrate*100 as costtaxrate,
			p.Alias as alias,
			p.Comment as pcomment
	  FROM (select bm.*,isnull(Y.class_id,'')YClass_id,isnull(RE.Class_id,'')REClass_id,isnull(RE.[name],'')Ename,
	         isnull(f.AccountComment,'') as factory
                from buymanagebill bm   
                left join company   Y  on Y.company_id=Bm.Y_id
                left join employees RE on RE.emp_id=Bm.RowE_id    
                left join basefactory f on bm.factoryid=f.CommID
                where bm.p_id>0 and aoid in(select szTYPE from DecodeToStr(@strBusinessType)) and (@nPid=0 or p_id=@nPid)
               ) VS
                 
                INNER JOIN 
               (select a.*,isnull(E.class_id,'')InputmanClass_id, isnull(E1.[name],'')Ename,isnull(C.Class_id,'')CClass_id,isnull(C.[name],'')Cname, 
                (case a.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end) as invoicetype
                from BillIDX a
                LEFT JOIN employees E on E.emp_id=a.Inputman
                LEFT JOIN employees E1 on E1.emp_id=a.e_id
                LEFT JOIN Clients   C on c.Client_ID=a.c_id
                /*20,220,221,222,21,24,25,122*/
                WHERE (a.[Billtype] IN (20,21,24,25,35,122,220,221,222) AND
                a.[Billdate] BETWEEN @BeginDate AND @EndDate) and billstates=0 
                and a.region_id>=@regid1 and a.region_id<=@regid2
               )VB
               ON VS.[Bill_ID]=VB.[BillID]
	       LEFT JOIN VW_C_Products P  ON P.[Product_ID]=VS.[P_ID]
	       LEFT JOIN vw_productbalance VP ON VP.p_id = VS.p_id and VP.Y_id = VS.Y_ID 
               where  vs.Reclass_id like @szEClass_id
                  and (@nYClassid='' OR VS.Yclass_id like @nYclassID+'%')
                  and vb.[Cclass_ID] LIKE @szCClass_ID
                  and vb.inputmanclass_id like @szInputman 
      )  a             
           	where          ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))   
                       AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                       AND  ((@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
	               ORDER BY a.[Billdate],a.billnumber

	SELECT 
	CASE WHEN (GROUPING([Smb_ID])=1)  THEN 0  ELSE ISNULL([Smb_ID]        ,'UNKNOW') END AS [Smb_ID],
	CASE WHEN (GROUPING([Bill_ID])=1) THEN 0  ELSE ISNULL([Bill_ID]       ,'UNKNOW') END AS [BillID],
	CASE WHEN (GROUPING([Bill_ID])=1) THEN -1 ELSE ISNULL(MAX([Billtype]) ,'UNKNOW') END AS [Billtype],
		MAX([Billdate])      AS [Billdate],
		MAX([Billnumber])    AS [Billnumber],
		MAX([Code])          AS [Code],
		MAX(B_CustomName1)   as B_CustomName1,
		MAX(B_CustomName2)   as B_CustomName2,
		MAX(B_CustomName3)   as B_CustomName3,
		MAX([Pname])         AS [Pname],
		MAX([Standard])      AS [Standard],
		MAX([Billstates])    AS [Billstates],
		MAX([Makearea])      AS [Makearea],
		MAX([Medtype])       AS [Medtype],
		MAX(Custompro1) as Custompro1, MAX(Custompro2) as Custompro2, 
		MAX(Custompro3) as Custompro3, Max(Custompro4) as Custompro4, 
		Max(Custompro5) as Custompro5,	
		MAX([Ename])         AS [Ename],
		MAX([Inputman])      AS [Inputman],
		MAX([Auditman])      AS [Auditman],
		MAX([Validdate])     AS [Validdate],
		MAX([Batchno])       AS [Batchno],
		MAX([Unitname])      AS [Unitname],
		MAX(TC1)	         AS [TC1],
		MAX(TC2)	         AS [TC2],
		MAX(TCMONEY)	     AS [TC3],
		MAX([Taxrate])       AS [Taxrate],
		/*MAX([Taxprice])      AS [Taxprice],*/
		dbo.Decimalbits(4,MAX([Taxprice])) AS [Taxprice],
		MAX(comment)         AS [comment],
		ISNULL(MAX(e_name), '') AS [e_name],
		ISNULL(MAX(C_Name), '') AS [C_Name],
		/*cast((case when sum(quantity)=0 then 0 else abs(sum(totalmoney)/sum(quantity)) end) as NUMERIC(25,8)) AS [Discountprice],*/
		dbo.Decimalbits(2,(case when sum(quantity)=0 then 0 else abs(sum(totalmoney)/sum(quantity)) end)) AS [Discountprice],
		MAX(suppliername)    AS [suppliername],
		SUM([Quantity])      AS [Quantity],
		SUM([Taxmoney])      AS [Taxmoney],
		/*SUM([Taxtotal])      AS [Taxtotal],*/
		dbo.Decimalbits(3,SUM([Taxtotal]))      AS [Taxtotal],
		ISNULL(SUM([SendQTY]),0)   AS [SendQTY],
		/*ISNULL(SUM([SendCostTotal]),0)   AS [SendCostTotal],*/
		dbo.Decimalbits(3,ISNULL(SUM([SendCostTotal]),0)) AS [SendCostTotal],
		cast(0 as NUMERIC(25,8)) as mltotal,
		MAX([invoicetype])   AS [invoicetype],
		max(factory) as factory,
		SUM(costtaxtotal) as costtaxtotal,
		MAX([costtaxrate])       AS [costtaxrate],
		dbo.Decimalbits(2,(case when sum(quantity)=0 then 0 else abs(sum(costtaxtotal)/sum(quantity)) end)) AS [costtaxprice],
		MAX(alias)	     AS [alias],
		MAX(pcomment)	 AS [pcomment]
		FROM ##BuyMX
		GROUP BY [Bill_ID], [Smb_ID] WITH ROLLUP
		ORDER BY [Billdate],billnumber
	DROP TABLE ##BuyMX 
  GOTO SUCCEE
end
ProductSaleMx:
BEGIN 

  SELECT * into  ##SaleMX from 
     (select    VS.[Smb_ID],
				VS.[Bill_ID],
				VB.[Billdate],
				VB.[Billnumber],
				VB.[Billstates],
				VB.[Ename],
				VB.[Billtype],
				VB.[Inputman],
				VB.[Auditman],
				VB.[invoicetype],
			    VB.B_CustomName1,
			    VB.B_CustomName2,
			    VB.B_CustomName3,
				P.[product_id] as P_id,
				P.[Code],
				P.[Name] AS [PName],                 
				P.[Standard],
				P.[Makearea],
				P.[Medtype],
				P.Custompro1, P.Custompro2, P.Custompro3, P.Custompro4, P.Custompro5,
				P.[Unitname1] AS [Unitname],
				p.tc1,
				p.tc2,
				p.tcmoney,
				isnull(VP.e_name,'') e_name ,
				isnull(VP.C_Name,'') c_name ,
				VS.[Validdate],
				VS.[Batchno],
				case when VB.[Billtype] in(11,13,17,211) THEN -VS.[totalmoney] ELSE VS.[totalmoney] END AS [totalmoney],
				cast(VS.totalmoney/VS.quantity as NUMERIC(25,8))[Discountprice],
				VS.[Taxrate]*100 AS [Taxrate],
				cast(VS.[Taxtotal]/VS.quantity as NUMERIC(25,8)) AS [Taxprice],
				VS.comment,
				vb.cname as suppliername,
				CASE WHEN VB.[Billtype] in(11,13,17,211) THEN -VS.[Taxmoney] ELSE VS.[Taxmoney] END AS [Taxmoney],
				CASE WHEN VB.[Billtype] in(11,13,17,54,211) THEN -VS.[Quantity] ELSE VS.[Quantity] END AS [Quantity],
				CASE WHEN VB.[Billtype] in(11,13,17,54,211) THEN -VS.[Taxtotal] ELSE VS.[Taxtotal] END AS [Taxtotal],
				CASE WHEN VB.[Billtype] in(11,13,17,54,211) THEN -VS.[SendQTY] ELSE VS.[SendQTY] END AS [SendQTY],
				CASE WHEN VB.[Billtype] in(11,13,17,54,211) THEN -VS.[SendCostTotal] ELSE VS.[SendCostTotal] END AS [SendCostTotal],
				CASE WHEN VB.[billtype] in(11,13,17,54) THEN -(vs.taxtotal - VS.costtaxtotal)  ELSE (vs.taxtotal - VS.costtaxtotal)  END As mltotal, 
				vb.c_id,
				vs.Y_id,
				vs.RowE_id,isnull(vs.factory,'') as  factory,
				CASE WHEN VB.[Billtype] in(11,13,17,54,211) THEN -VS.[costtaxtotal] ELSE VS.[costtaxtotal] END AS [costtaxtotal],
				cast(VS.[costtaxtotal]/VS.quantity as NUMERIC(25,8)) AS [CostTaxprice],
				vs.costtaxrate*100 as costtaxrate,
				p.Alias as alias,
				p.Comment as pcomment
	  FROM (select sm.*,f.AccountComment as factory,isnull(Y.class_id,'')YClass_id,isnull(RE.Class_id,'')REClass_id
                FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数    */
                left join basefactory f on sm.factoryid=f.CommID
                left join company   Y  on Y.company_id=sm.Y_id
                left join employees RE on RE.emp_id=sm.RowE_id    
                where sm.p_id>0 and aoid in (0,5,6,7) and (@nPid=0 or p_id=@nPid)
               ) VS
                 
                INNER JOIN 
               (select a.*,isnull(E.class_id,'')InputmanClass_id,isnull(E1.[name],'')Ename,isnull(C.Class_id,'')CClass_id,isnull(C.[name],'')Cname, 
                (case a.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end) as invoicetype
                from BillIDX a
                LEFT JOIN employees E  on E.emp_id=a.Inputman
                LEFT JOIN Clients   C  on c.Client_ID=a.c_id
	            LEFT JOIN employees E1 on E1.emp_id=a.e_id
                WHERE  a.[Billtype] IN (10, 11,12,13, 16, 17, 112,53,54,210,211,212)
                 AND (a.[Billdate] BETWEEN @BeginDate AND @EndDate) and billstates=0
                 and a.region_id>=@regid1 and a.region_id<=@regid2
               )VB
               ON VS.[Bill_ID]=VB.[BillID]
	       LEFT JOIN VW_C_Products P  ON P.[Product_ID]=VS.[P_ID]
	       LEFT JOIN vw_productbalance vp ON vp.p_id = VS.p_id and vp.Y_id= VS.Y_ID 
               where  vs.Reclass_id like @szEClass_id
                  and (@nYClassid='' OR VS.Yclass_id like @nYclassID+'%')
                  and vb.[Cclass_ID] LIKE @szCClass_ID
                  and vb.inputmanclass_id like @szInputman                            
      )  a
      where 
                  ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))  
             AND  ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
             AND  ((@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  
     ORDER BY a.[Billdate],a.billnumber           

		SELECT 
		CASE WHEN (GROUPING([Smb_ID])=1)  THEN 0  ELSE ISNULL([Smb_ID]        ,'UNKNOW') END AS [Smb_ID],
		CASE WHEN (GROUPING([Bill_ID])=1) THEN 0  ELSE ISNULL([Bill_ID]       ,'UNKNOW') END AS [BillID],
		CASE WHEN (GROUPING([Bill_ID])=1) THEN -1 ELSE ISNULL(MAX([Billtype]) ,'UNKNOW') END AS [Billtype],
		MAX([Billdate])      AS [Billdate],
		MAX([Billnumber])    AS [Billnumber],
		MAX([Code])          AS [Code],
		MAX(B_CustomName1)   as B_CustomName1,
		MAX(B_CustomName2)   as B_CustomName2,
		MAX(B_CustomName3)   as B_CustomName3,
		MAX([Pname])         AS [Pname],
		MAX([Standard])      AS [Standard],
		MAX([Billstates])    AS [Billstates],
		MAX([Makearea])      AS [Makearea],
		MAX([Medtype])       AS [Medtype],
		MAX(Custompro1) as Custompro1, MAX(Custompro2) as Custompro2, 
		MAX(Custompro3) as Custompro3, Max(Custompro4) as Custompro4, 
		Max(Custompro5) as Custompro5,
		MAX([Ename])         AS [Ename],
		MAX([Inputman])      AS [Inputman],
		MAX([Auditman])      AS [Auditman],
		MAX([Validdate])     AS [Validdate],
		MAX([Batchno])       AS [Batchno],
		MAX([Unitname])      AS [Unitname],
		MAX(TC1)	     AS [TC1],
		MAX(TC2)	     AS [TC2],
		MAX(TCMONEY)	     AS [TC3],
		MAX([Taxrate])       AS [Taxrate],
		MAX([Taxprice])      AS [Taxprice],
		MAX([comment])	     AS [comment],
		ISNULL(MAX([e_name]), '') As [e_name],
		ISNULL(MAX([C_Name]), '') As [C_Name],
		MAX(suppliername)    AS [suppliername],
		cast((case when sum(quantity)=0 then 0 else abs(sum(totalmoney)/sum(quantity)) end) as NUMERIC(25,8)) AS [Discountprice],
		SUM([Quantity])      AS [Quantity],
		SUM([Taxmoney])      AS [Taxmoney],
		SUM([Taxtotal])      AS [Taxtotal],
		ISNULL(SUM([SendQTY]),0)   AS [SendQTY],
		ISNULL(SUM([SendCostTotal]),0)   AS [SendCostTotal],
		cast(ISNUll(SUM(mltotal),0) as NUMERIC(25,8)) AS mltotal,
		MAX([invoicetype])   AS [invoicetype],
		max(factory) as factory,
		MAX([costtaxrate])       AS [costtaxrate],
		SUM(costtaxtotal) as costtaxtotal,
		cast((case when sum(quantity)=0 then 0 else abs(sum(costtaxtotal)/sum(quantity)) end) as NUMERIC(25,8)) AS [costtaxprice],
		MAX(alias)	     AS [alias],
		MAX(pcomment)	 AS [pcomment]
		FROM ##SaleMX
		GROUP BY [Bill_ID], [Smb_ID] WITH ROLLUP
		ORDER BY [Billdate],billnumber
	
	DROP TABLE ##SaleMX
  GOTO SUCCEE
END

SUCCEE:  RETURN 0
GO
