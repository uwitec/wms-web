

CREATE VIEW [VW_J_Invoice]
AS

  select
    /*发票主表 */
    ividx.[id] as invoiceid, 	 ividx.invoicedate,		ividx.invoiceno, 	
    case invoicebilltype when 0 then ividx.invoicetotal else -ividx.invoicetotal end as invoicetotal,
    ividx.invoice,		 ividx.c_id, 			isnull(c.class_id, '')   as Cclass_id,
    isnull(c.[name], '') as CName,				ividx.departmentid,     isnull(d.[name], '') as DName,				
    ividx.inputman, 		isnull(e1.class_id, '') as inputmanClass_id,
    isnull(e1.[name], '') as inputmanname,			ividx.auditman,		
    isnull(e2.class_id, '') as auditmanClass_id,		isnull(e2.[name], '')  as  auditmanname,
    ividx.states, 		 ividx.invoicetype,        	ividx.jsflag, 		ividx.InvoiceBilltype,
    ividx.ReAuditFlag, 		 ividx.summary,		        ividx.comment,		ividx.invoiceGuid,
    /*发票明细表*/
    isnull(iv.[id], 0) as IVDetailID, 	 			isnull(iv.billid, 0) as billid, 			
    isnull(iv.smb_id, 0) as smb_id, 		                iv.billguid,		iv.RowGuid,
    isnull(iv.p_id, 0) as p_id,					isnull(iv.quantity, 0) as quantity,
    isnull(iv.total, 0) as total,				isnull(iv.YKQuantity, 0) as YKQuantity,
    isnull(iv.yktotal, 0) as YKTotal,				
    isnull((case invoicebilltype when 0 then iv.CurrQuantity else -iv.CurrQuantity end), 0) as  CurrQuantity,
    isnull((case invoicebilltype when 0 then iv.CurrTotal else -iv.CurrTotal end), 0) as CurrTotal, 			
    isnull(bi.billdate, '1900-01-01') as billdate,
    isnull(bi.billnumber, '') as billnumber,			isnull(bi.billtype, 0) as billtype,
    isnull(bi.e_id, 0) as  BillE_id,				isnull(bi.auditman, 0) as billauditman,
    isnull(bi.inputman, 0) as BillInputMan,			isnull(bi.EName, '') as BillEName,
    isnull(bi.EClass_id, '') as BillEClass_id, 			isnull(bi.inputManName, '') as BillInputManName,
    isnull(bi.InputManClass_ID, '')  as BillInputManClass_ID,   isnull(bi.AuditManName, '') as BillAuditManName,
    isnull(bi.AuditManClass_ID, '') as BillAuditManClass_ID,	isnull(bi.ysmoney, 0) as ysmoney,
    isnull(bi.ssmoney, 0) as  ssmoney,				isnull(bi.quantity, 0) as BillQuantity,
    isnull(bi.BillStates, 0) as BillStates,		        isnull(bi.jsye, 0) as jsye,
    isnull(bi.note, '') as BillNote, 				isnull(bi.Summary, '') as BillSummary,
    isnull(bi.jsInvoiceTotal, 0) as jsInvoiceTotal, 		isnull(p.serial_number, '') as  PSerial_number,
    isnull(p.[name], '') as PName,				isnull(p.Standard, '') as PStandard,
    isnull(p.modal, '') as  PModal,				isnull(p.MakeArea, '') as PMakeArea,
    isnull(P.TradeMark, '') as PTradeMark, 			isnull(p.alias, '') as PAlias, 
    isnull(p.Class_id, '') as PClass_id,			isnull(p.Parent_id, '') as PParent_id,
    isnull(p.Unit1_id, 0) as Unit1_ID,				isnull(p.Unit2_id, 0) as Unit2_ID,
    isnull(p.Unit3_id, 0) as Unit3_ID,				isnull(p.Unit4_id, 0) as Unit4_ID,
    isnull(p.Unit1Name, '') as Unit1Name,			isnull(p.Unit2Name, '') as Unit2Name,
    isnull(p.Unit3Name, '') as Unit3Name,                       isnull(p.Unit4Name, '') as Unit4Name

    from invoiceidx ividx
    left join invoice iv on  ividx.[id] = iv.invoiceid
    left join VW_X_BillIDX bi on  iv.billid = bi.billid
    left join employees e1 on ividx.inputman = e1.emp_id 
    left join employees e2 on ividx.auditman = e2.emp_id
    left join department d on ividx.departmentid = d.departmentid
    left join vw_clients c on ividx.c_id = c.client_id
    left join vw_products p on iv.p_id = p.product_id
GO
