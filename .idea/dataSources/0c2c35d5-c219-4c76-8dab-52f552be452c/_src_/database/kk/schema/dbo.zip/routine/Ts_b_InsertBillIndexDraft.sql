
CREATE		proc Ts_b_InsertBillIndexDraft
(
@nRET	int output,
@nVchCode int,
@nTableTag int,
@billid  int,
@billdate  datetime,
@billnumber  varchar(30),
@billtype  smallint,
@a_id  int,
@c_id  int,
@e_id  int,
@sout_id  int,
@sin_id  int,
@auditman  int,
@inputman  int,
@ysmoney  NUMERIC(25,8),
@ssmoney  NUMERIC(25,8),
@quantity  NUMERIC(25,8),
@taxrate  NUMERIC(25,8),
@period  smallint,
@billstates  char(1),
@order_id  int,
@department_id	int,
@Y_ID	int,     /*表头机构 editcompany 对应ID*/
@region_id  int,
@auditdate  datetime,
@skdate  datetime,
@jsye  NUMERIC(25,8),
@jsflag  char(1),
@note  varchar(8000),/*当是商品调价单的时候存入posid字段*/
@summary  varchar(256),
@invoice int,
@invoiceNO varchar(50),
@invoiceTotal NUMERIC(25,8),
@businesstype int,
@araptotal NUMERIC(25,8),
@GatheringMan int,
@SendQTY NUMERIC(25,8),
@VIPCardID int =0,
@begindate datetime=0,
@enddate   datetime=0,
@begintime datetime=0,
@endtime   datetime=0,
@xq	       varchar(7)='1111111',
@CURY_ID   int=0,             /*当前录单机构ID*/
@B_CustomName1 varchar(100)='',
@B_CustomName2 varchar(100)='',
@B_CustomName3 varchar(100)='',
@sendC_Id   int=0,
@WHOLEQTY   int=0,
@PARTQTY    int=0,
@DPdate  datetime='1900-01-01',
@WT_ID      int=0,
@CYDW varchar(80) ='',
@CYFS varchar(60) ='',
@QYTime datetime = '1900-01-01',
@OrderValidDate datetime = '1900-01-01',
@QualityAudit  int = 0,
@QualityAuditDate  Datetime = '1900-01-01',
@financeAudit  int = 0,
@financeAuditDate  Datetime = '1900-01-01',
@FollowNumber varchar(80) ='',
@TicketDate	varchar(80) ='1900-01-01',
@BalanceMode INT = -1,
@PRIORITY    int =0 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @VIPCardID is null  SET @VIPCardID = 0
if @begindate is null  SET @begindate = 0
if @enddate is null  SET @enddate = 0
if @begintime is null  SET @begintime = 0
if @endtime is null  SET @endtime = 0
if @xq is null  SET @xq = '1111111'
if @CURY_ID is null  SET @CURY_ID = 0
if @B_CustomName1 is null  SET @B_CustomName1 = ''
if @B_CustomName2 is null  SET @B_CustomName2 = ''
if @B_CustomName3 is null  SET @B_CustomName3 = ''
if @sendC_Id is null  SET @sendC_Id = 0
if @WHOLEQTY is null  SET @WHOLEQTY = 0
if @PARTQTY is null  SET @PARTQTY = 0
if @WT_ID is null   set @WT_ID = 0
if @CYDW is null set @CYDW = ''
if @CYFS is null set @CYFS = ''
if @QYTime is null set @QYTime = '1900-01-01' 
if @OrderValidDate is null set @OrderValidDate = '1900-01-01' 
if @QualityAudit is null set @QualityAudit = 0
if @QualityAuditDate is null set   @QualityAuditDate= '1900-01-01'
if (@QualityAudit > 0) and (@QualityAuditDate < 100) 
   set @QualityAuditDate = GETDATE()
if @financeAudit is null set @financeAudit = 0
if @financeAuditDate is null set   @financeAuditDate= '1900-01-01'
if (@financeAudit > 0) and (@financeAuditDate < 100) 
   set @financeAuditDate = GETDATE()
if (@DPdate is null) or (@DPdate < '1900-01-01')   set @DPdate='1900-01-01'   
if @FollowNumber is null set @FollowNumber=''
if @TicketDate	is null set @TicketDate ='1900-01-01'
/*Params Ini end*/

SET NOCOUNT ON
SET @nRET = -1

/*mixb修改*/
/*批发流程单据不写 SendQty*/
/*    210;           //  销售单*/
/*    211;           //  销售退货单*/
/*    220;           //  采购单*/
/*    221;           //  采购退货单*/
declare @nCurY_ID int
set @nCurY_ID =@CurY_ID

if @auditdate  <10 set @auditdate=0
if @skdate  <10 set @skdate=0

if @billtype in (220,221,210,211)
begin
  set @SendQTY=0
end
/*--------- 存草稿时检查是否有其他人已审核此草稿 add by luowei 2013-10-23*/
/* 审核时间不一致的视为已被审核过*/
if (@billtype not in(14, 22, 26, 12, 13, 240, 243, 244, 250, 251, 26, 187, 108, 154)) and (@nVchCode <> 0) and exists(select 1 from billdraftidx where billid = @nVchCode and billstates = '3' and auditdate <> @auditdate)
begin
  raiserror('本单已被审核，保存失败！',16,1)
  return 0
end 
if (@billtype in(14, 22, 26)) and (@nVchCode <> 0) and exists(select 1 from orderidx where billid = @nVchCode and billstates = '3' and auditdate <> @auditdate)
begin
  raiserror('本单已被审核，保存失败！',16,1)
  return 0
end 


/*客户需求:采购入库单文件导出, 入库单文件导入，成本调价、过账, 历史单据打开报错*/
if @billtype in (38, 41, 42, 43, 48, 49, 51)
begin
  set @c_id=0
end

/*销售出库单里增加会员卡积分功能 */
if @billtype in (10,11,210,211)
begin
  select @vipCardID=card_id from clients where client_id = @c_id 
end


/* 启用标准流程后不再控制采购入库单、销售出库单*/
if @billtype in (10,20) and (not exists(select 1 from sysconfigtmp where sysname = 'GspStandardProcess' and sysvalue = '1'))
begin
  declare @szGspAlert varchar(300),@szCheckValid varchar(10)

  set @szCheckValid='0'

	exec ts_getsysvalue 'GspFlowControl',@szCheckValid output 

  if @szCheckValid='1'
  begin
    exec ts_c_qrgspcheck @c_id,@szGspAlert output
    if @szGspAlert<>'' 
    begin
      raiserror(@szGspAlert,16,1)
      return 0
    end
  end
  /*-启用超出范围存草稿时,销售出库单不检测往来单位信用额度 add by luowei 2012-12-28*/
  if not (exists(select 1 from sysconfigtmp where sysname = 'AllowSaveDraft' and sysvalue = '1') and (@billtype = 10))
  begin
	  declare @nCheckRet int
	  set @nCheckRet =0
	  exec ts_j_checkCreditPost @billid, @billtype, @nCheckRet output, 1, @jsye, @CURY_ID, @c_id, @e_id
	  if @nCheckRet=-23
	  begin
		  raiserror('往来单位超出信用额度!',16,1)
		  return 0
	  end
	  if @nCheckRet=-24
	  begin
		  raiserror('职员超出信用额度!',16,1)
		  return 0
	  end 
  end
end
  /*Wsj--tfsbug41520 2016.10.08  控制超过信用额度不允许下订单*/
  if exists(select 1 from clients where client_id = @c_id and OrderCredit = 1) and (@billtype = 14)
  begin
	  declare @nOrderCheckRet int
	  set @nOrderCheckRet =0
	  exec ts_j_checkCreditPost @billid, @billtype, @nOrderCheckRet output, 1, @jsye, @CURY_ID, @c_id, @e_id
	  if @nOrderCheckRet=-23	 
	  begin
		  raiserror('往来单位超出信用额度不允许下订单!',16,1)
		  return 0
	  end
  end

IF @nVchCode =0
BEGIN
  IF @BILLTYPE in(14,22,26,108, 154)
  INSERT INTO ORDERIDX
  (
  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
  ysmoney  ,ssmoney ,quantity , taxrate	,period  ,billstates,order_id ,department_id,
  region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye, invoice, Y_ID, 
  WT_ID, TrafficCompany, TrafficType, SendTime, orderValiddate, GatheringMan, sendc_id, BusinessType, BalanceMode,B_CustomName1,B_CustomName2,B_CustomName3,
  PRIORITY
  )
  VALUES
  (
  @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
  @inputman,@ysmoney  ,@ssmoney  ,@quantity , @taxrate  ,@period	,@billstates,@order_id ,
  @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,@invoice, @CURY_ID, 
  @WT_ID, @CYDW, @CYFS, @QYTime, @OrderValidDate, @GatheringMan, @sendC_Id, @businesstype, @BalanceMode,@B_CustomName1,@B_CustomName2,@B_CustomName3,
  @PRIORITY
  )

  ELSE
  IF (@BILLTYPE in(12,13,244))and (@nTableTag  in( 5,25,40))
  begin
  INSERT INTO RETAILBILLIDX
  (
  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
  ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
  region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice, InvoiceNO,vipCardID,invoicetotal, Y_ID
  )
  VALUES
  (
  @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
  @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates,@order_id ,
  @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
  0, @invoiceNO, @vipCardID,@invoicetotal, @CURY_ID)
  end
  ELSE
  IF (@BILLTYPE in(52,57))and (@nTableTag  in( 7,17))

  INSERT INTO TranIDX
  (
  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
  ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,posid,
  region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY, Y_ID,
  CenterAuditMan, CenterAuditDate,[GUID]
  )
  VALUES
  (
  @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
  @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id , @department_id,@CURY_ID,
  @region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
  @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY, @CURY_ID,
  @QualityAudit, @QualityAuditDate,@B_CustomName3)
  
  ELSE
  IF @nTableTag  in( 9,19)
  INSERT INTO PriceIDX
  (
  billdate ,billnumber, billtype, e_id, auditman, inputman, period  ,billstates, order_id , department_id,
  region_id ,auditdate ,note  ,summary, posid, Y_ID
  )
  VALUES
  (
  @billdate ,@billnumber,@billtype, @e_id,@auditman, @inputman,@period	,@billstates ,@order_id ,@department_id,
  @region_id ,@auditdate ,''  ,@summary, @note, @CURY_ID 
  )

  /*---------服装移植----------------------- 积分兑换单*/
  else if @Billtype in (149)
  begin
  INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
    ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
    region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,
    GatheringMan,SendQTY,vipCardID,Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id, QualityAudit, QualityAuditDate,
    financeAudit,financeAuditDate, BalanceMode
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@a_id,0,@e_id,@sout_id,@sin_id,@auditman,
    @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id , @department_id,
    @region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye, @invoice ,@invoiceNO,@invoiceTotal, @businesstype,
    @GatheringMan,@SendQTY,@vipCardID, @CURY_ID,@B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id, @QualityAudit, @QualityAuditDate,
    @financeAudit,@financeAuditDate, @BalanceMode)
  end
  /*---------服装移植----------------------- 储值单*/
  else if @BillType in (148)
  begin
  INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
    ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
    region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,
    GatheringMan,SendQTY,vipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id, QualityAudit, QualityAuditDate,
    financeAudit,financeAuditDate, BalanceMode
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
    @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id ,@department_id,
    @region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
    @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY,@vipCardID, @CURY_ID,@B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id, @QualityAudit, @QualityAuditDate,
    @financeAudit,@financeAuditDate, @BalanceMode
    )
  end
  else if @BillType in (18,27)/*报价单*/
  begin
  INSERT INTO PRICEINQUIREIDX
    (
     billdate, billnumber, billtype , c_id,  e_id,   auditman,  inputman,
     period, billstates,  order_id, department_id, posid,  region_id,
     auditdate, note, summary, araptotal, begindate, endDate, Y_id 
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@c_id,@e_id,@auditman,@inputman,
    @period	,@billstates ,@order_id,@department_id,@Y_id, @Region_id, 
    @auditdate ,@note,@summary ,@araptotal, @begindate,@enddate,@CURY_ID)
  end
   else if @BillType in (34,44) /*返利获利单*/
  begin
  INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,c_id,e_id,sout_id,sin_id,auditman,inputman,
    period  ,billstates,
    auditdate ,note  ,summary ,begindate,enddate,Y_id,
    B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id, 
    financeAudit,financeAuditDate, BalanceMode      
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@c_id,@e_id,@sout_id,@sin_id,@auditman,@inputman,
    @period	,@billstates ,
    @auditdate ,@note,@summary ,@begindate,@enddate,@CURY_ID,
    @B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id, @financeAudit,@financeAuditDate, @BalanceMode)
  end
  else if @BillType = 187 /*商品缺货单*/
  begin
  INSERT INTO ZeroStockIDX
    (
    billdate ,billnumber,billtype,c_id,e_id,auditman,inputman,quantity,
    period  ,billstates,department_id,region_id, auditdate,note, summary, Y_ID
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@c_id,@e_id,@auditman,@inputman,@quantity,
    @period	,@billstates ,@department_id, @region_id,@auditdate,@note,@summary ,@CURY_ID
    )
  end  
  else if @BillType in (240, 243)	/*挂号单诊，治费用单*/
  begin
    INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
    ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
    region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
    B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,RetailDate,financeAudit,financeAuditDate, BalanceMode
    )
    VALUES
    (
    convert(varchar, @billdate, 2),@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
    @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id ,
    @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
    @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY,@vipCardID, @CURY_ID,
    @B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id, @billdate, @financeAudit,@financeAuditDate, @BalanceMode)
  END
  ELSE IF @BillType in(157)
  begin
     INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
    ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
    region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
    B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,WHOLEQTY,PARTQTY,QualityAudit, QualityAuditDate,financeAudit,financeAuditDate, BalanceMode,GUID
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
    @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id ,
    @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
    @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY,@vipCardID, @CURY_ID,
    @B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id,@WHOLEQTY,@PARTQTY, @QualityAudit, @QualityAuditDate, @financeAudit,@financeAuditDate, @BalanceMode,@FollowNumber) 
  end
  ELSE begin   
    INSERT INTO BillDraftidx
    (
    billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
    ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
    region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
    B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,WHOLEQTY,PARTQTY,QualityAudit, QualityAuditDate,financeAudit,financeAuditDate, BalanceMode
    )
    VALUES
    (
    @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
    @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id ,
    @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
    @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY,@vipCardID, @CURY_ID,
    @B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id,@WHOLEQTY,@PARTQTY, @QualityAudit, @QualityAuditDate, @financeAudit,@financeAuditDate, @BalanceMode)
  end;

  IF @@ROWCOUNT=1
  begin
    SET @nRET = @@IDENTITY
    IF @billtype in (14, 154, 157)
		EXEC TS_H_BillTraceAct 0, @nRET, @billtype, 0, @billtype, 1, 1
    if @BillType in (44) /*后继版本加控制，在不需要的时候不插入此表*/
	begin								
		insert msgcenter([msgtype],[billid],[billtype])
		values
		(1,@nRET,@BillType)
	end

    /*解决零售单过账出错后出现非法记录　2010.10.21 zjilin*/
    IF (@BILLTYPE in(12,13))and (@nTableTag  in( 5,25))
      delete retailbill where bill_id = @nRET
      
  if @BILLTYPE = 244
	update Registered set PresState = 1 where Reg_ID = @order_id
  end
END
ELSE
IF @nVchCode = -7
BEGIN
	/*门店机构请货单提交到总部保存处理，总部存在相同GUID表示已上传过*/
	IF (@BILLTYPE in(52))and (@nTableTag  in(7,17))
	BEGIN
	  IF NOT EXISTS(SELECT billid FROM TranIdx WHERE billtype = 52 AND [GUID] = @B_CustomName3)
		  INSERT INTO TranIDX
		  (
		  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
		  ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,posid,
		  region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY, Y_ID,
		  CenterAuditMan, CenterAuditDate,[GUID],UpCenterdate
		  )
		  VALUES
		  (
		  @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
		  @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id , @department_id,@CURY_ID,
		  @region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
		  @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY, @CURY_ID,
		  @QualityAudit, @QualityAuditDate, @B_CustomName3,GETDATE())
	END
	IF @@ROWCOUNT=1
		SET @nRET = @@IDENTITY
END
ELSE
IF @nVchCode = -157
BEGIN
   /*Wsj-2017-03-09-机构店间调拨单直接提交到总部进行保存*/
  IF (@BILLTYPE in(157))
  BEGIN
     IF NOT EXISTS(SELECT billid FROM BillDraftidx WHERE billtype = 157 AND [GUID] = @FollowNumber)
     BEGIN
     INSERT INTO BillDraftidx
     (
     billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
     ysmoney  ,ssmoney  ,araptotal,quantity , taxrate	,period  ,billstates,order_id ,department_id,
     region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_ID,
     B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id,WHOLEQTY,PARTQTY,QualityAudit, QualityAuditDate,financeAudit,financeAuditDate, BalanceMode,GUID
     )
     VALUES
     (
     @billdate ,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,
     @inputman,@ysmoney  ,@ssmoney  ,@araptotal,@quantity , @taxrate  ,@period	,@billstates ,@order_id ,
     @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
     @invoice ,@invoiceNO,@invoiceTotal, @businesstype,@GatheringMan,@SendQTY,@vipCardID, @CURY_ID,
     @B_CustomName1,@B_CustomName2,@B_CustomName3,@sendC_Id,@WHOLEQTY,@PARTQTY, @QualityAudit, @QualityAuditDate, @financeAudit,@financeAuditDate, @BalanceMode,@FollowNumber)     
     END
     IF @@ROWCOUNT=1
     BEGIN
       SET @nRET = @@IDENTITY
	   EXEC TS_H_BillTraceAct 0, @nRET, @BILLTYPE, 0, @BILLTYPE, 1, 1     
     END
  END
END
ELSE
BEGIN
	/* 检测草稿是否还在*/
	IF @BILLTYPE in (14, 22, 26, 108, 154)
	BEGIN
		IF (NOT EXISTS(SELECT * FROM orderidx WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF @BILLTYPE in (12, 13) 
	BEGIN
		IF (NOT EXISTS(SELECT * FROM RETAILBILLIDX WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF @BILLTYPE in (52, 57) 
	BEGIN
		IF (NOT EXISTS(SELECT * FROM TranIdx WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF @nTableTag in(9, 19) 
	BEGIN
		IF (NOT EXISTS(SELECT * FROM PriceIdx WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF @nTableTag in(20) 
	BEGIN
		IF (NOT EXISTS(SELECT * FROM PRICEINQUIREIDX WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF @nTableTag in(39) 
	BEGIN
		IF (NOT EXISTS(SELECT * FROM ZeroStockIDX WHERE billid = @nVchCode))
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END
	ELSE
	IF NOT EXISTS(SELECT * FROM billdraftidx WHERE billid = @nVchCode)
	BEGIN
		BEGIN
			raiserror('单据已被删除！', 16, 1)
			return 0
		END
	END

	DECLARE @SQL VARCHAR(8000)
	IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
	BEGIN
		SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nVchCode AS VARCHAR(50)) + ', ' + CAST(@billtype AS VARCHAR(10)) + ', 0'
		EXEC(@SQL)
	END
	
  IF @nTableTag =0
  DELETE FROM buymanageBilldrf  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag  in (1,35)
  begin
    /*if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') */
   /* begin*/
	  /*--删除拣货单明细*/
	/* delete from salemanagebilldrf where bill_id in (*/
	/*   select billid from billdraftidx where order_id = @nVchCode and billtype = 254*/
	/* )*/
	 /*---删除拣货单主表*/
	/* delete from billdraftidx where order_id = @nVchCode and billtype = 254*/
	 /*---删除原单明细*/
	/* DELETE FROM salemanageBilldrf  WHERE BILL_ID=@nVchCode*/
   /*  end*/
   /* else*/
    DELETE FROM salemanageBilldrf  WHERE BILL_ID=@nVchCode
  end
  ELSE IF @nTableTag =2
  DELETE FROM storemanageBilldrf  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =3
  DELETE FROM financebilldrf  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =4
  DELETE FROM ORDERBILL  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag in(5,25)
  DELETE FROM RETAILBILL  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =6
  DELETE FROM GoodsCheckBillDrf  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =7
  DELETE FROM TranBill  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =8
  DELETE FROM TranManageBillDrf  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =9
  DELETE FROM PriceBill  WHERE BILL_ID=@nVchCode
  ELSE IF @nTableTag =22
  DELETE FROM ExIntegRalManagebilldrf  WHERE BILLID=@nVchCode
  ELSE IF @nTableTag = 39
  DELETE FROM ZeroStockBill where bill_id = @nVchCode 

  if @BILLTYPE in (15,23,155,165)
  begin
    Delete jsbdetail where skd_bid=@nVchCode and flag=1
    Delete jspdetail where skd_bid=@nVchCode and flag=1
  end

  IF @BILLTYPE in(14,22,26,108, 154)
  UPDATE ORDERIDX SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    a_id =         @a_id,
    c_id =         @c_id,
    e_id =         @e_id,
    sout_id =         @sout_id,
    sin_id =         @sin_id,
    auditman =         @auditman,
    inputman =         @inputman,
    ysmoney =         @ysmoney,
    ssmoney =         @ssmoney,
    quantity =         @quantity,
    taxrate =         @taxrate,
    period =         @period,
    billstates =         @billstates,
    order_id =         @order_id,
    department_id =         @department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    skdate =         @skdate,
    jsflag =         @JSFlag,
    note =         @note,
    summary =         @summary,
    jsye =         @jsye,
    invoice =         @invoice,
    invoiceNO =         @invoiceNO,
    invoiceTotal =         @invoiceTotal,
    businesstype =         @businesstype,
    Y_ID =         @CURY_ID,
    WT_ID =			@WT_ID, 
    TrafficCompany =			@CYDW,
    TrafficType =			@CYFS,
    SendTime =		@QYTime, 
    OrderValidDate = @OrderValidDate,
    GatheringMan   = @GatheringMan,
    SendC_ID  = @sendC_Id,
    B_CustomName1=@B_CustomName1,
    B_CustomName2=@B_CustomName2,
    B_CustomName3=@B_CustomName3,    
    BalanceMode = @BalanceMode,	
    PRIORITY  = @PRIORITY 
  WHERE billid = @nVchCode
  ELSE
  IF (@BILLTYPE in(12,13))and (@nTableTag  in( 5,25))
  UPDATE RETAILBILLIDX SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    a_id =         @a_id,
    c_id =         @c_id,
    e_id =         @e_id,
    sout_id =         @sout_id,
    sin_id =         @sin_id,
    auditman =         @auditman,
    inputman =         @inputman,
    ysmoney =         @ysmoney,
    ssmoney =         @ssmoney,
    araptotal=        @araptotal,
    quantity =         @quantity,
    taxrate =         @taxrate,
    period =         @period,
    billstates =         @billstates,
    order_id =         @order_id,
    department_id =         @department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    skdate =         @skdate,
    jsflag =         @JSFlag,
    note =         @note,
    summary =         @summary,
    jsye =         @jsye,
    invoice =         @invoice,
    invoiceNO =         @invoiceNO,
    invoiceTotal =         @invoiceTotal,
    businesstype =         @businesstype,
    VIPCardID    = @VIPCardID,
    Y_ID =         @CURY_ID,
    guid = newid()
  WHERE billid = @nVchCode
  ELSE
  IF (@BILLTYPE in(52,57))and (@nTableTag  in( 7,17))
  UPDATE TranIDX SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    a_id =         @a_id,
    c_id =         @c_id,
    e_id =         @e_id,
    sout_id =         @sout_id,
    sin_id =         @sin_id,
    auditman =         @auditman,
    inputman =         @inputman,
    ysmoney =         @ysmoney,
    ssmoney =         @ssmoney,
    araptotal=        @araptotal,
    quantity =         @quantity,
    taxrate =         @taxrate,
    period =         @period,
    billstates =         @billstates,
    order_id =         @order_id,
    department_id =         @department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    skdate =         @skdate,
    jsflag =         @JSFlag,
    note =         @note,
    summary =         @summary,
    jsye =         @jsye,
    invoice =         @invoice,
    invoiceNO =         @invoiceNO,
    invoiceTotal =         @invoiceTotal,
    businesstype =         @businesstype,
    gatheringman =         @gatheringman,
    sendQTY =              @sendQTY,
    Y_ID =         @CURY_ID
  WHERE billid = @nVchCode
  ELSE
  IF @nTableTag  in( 9,19)
  UPDATE PriceIDX SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    e_id =         @e_id,
    auditman =         @auditman,
    inputman =         @inputman,
    period =         @period	,
    billstates =         @billstates,
    order_id =         @order_id,
    department_id =         @department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    note =         @note,
    summary =         @summary,
    posid  =       @Y_ID,
    Y_ID =         @CurY_ID
  WHERE billid = @nVchCode
  else
  IF @nTableTag in (20)/*报价单*/
  begin
  UPDATE PRICEINQUIREIDX SET
	billdate = @billdate, 
	billnumber = @billnumber, 
	billtype = @billtype, 
	c_id = @c_id,  
	e_id = @e_id,   
	auditman = @auditman,  
	inputman = @inputman,
    period = @period, 
    billstates = @billstates,  
    order_id = @order_id, 
    department_id = @department_id, 
    posid = @Y_id,  
    region_id = region_id,
    auditdate = auditdate, 
    note = note, 
    summary = summary, 
    araptotal = araptotal, 
    begindate = @begindate, 
    endDate = @endDate, 
    Y_id = @CURY_id
  where billid=@nVchCode
  delete from PriceInquireBill where bill_id=@nVchCode
  end
  ELSE if @nTableTag = 39
  begin
    update ZeroStockIDX set    
      billdate = @billdate,
      billnumber= @billnumber,
      billtype= @billtype,
      c_id= @c_id,
      e_id= @e_id,
      auditman= @auditman,
      inputman= @inputman,
      quantity= @quantity,
      period = @period,      
      billstates= @billstates,
      department_id= @department_id,
      region_id= @region_id, 
      auditdate= @auditdate,
      note= @note, 
      summary= @summary, 
      Y_ID= @CURY_ID 
    where billid=@nVchCode 
  end
  else
  UPDATE BillDraftidx SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    a_id =         @a_id,
    c_id =         @c_id,
    e_id =         @e_id,
    sout_id =         @sout_id,
    sin_id =         @sin_id,
    auditman =         @auditman,
    inputman =         @inputman,
    ysmoney =         @ysmoney,
    ssmoney =         @ssmoney,
    araptotal=        @araptotal,
    quantity =         @quantity,
    taxrate =         @taxrate,
    period =         @period,
    billstates	=         @billstates,
    order_id	=         @order_id,
    VIPCardID   = @VIPCardID,
    department_id =@department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    skdate =         @skdate,
    jsflag =         @JSFlag,
    note =         @note,
    summary =         @summary,
    jsye =         @jsye,
    invoice =         @invoice,
    invoiceNO =         @invoiceNO,
    invoiceTotal =         @invoiceTotal,
    businesstype =         @businesstype,
    gatheringman =         @gatheringman,
    sendQTY =              @sendQTY,
    Y_ID =    		@CURY_ID,
    B_CustomName1 = @B_CustomName1,
    B_CustomName2 = @B_CustomName2,
    B_CustomName3 = @B_CustomName3,
    sendC_Id = @sendC_Id,
    WholeQty = @WHOLEQTY,
    PartQty  = @PARTQTY,
    QualityAudit = @QualityAudit, 
    QualityAuditDate = @QualityAuditDate,
    DPdate = @DPdate,
    financeAudit=@financeAudit,
    financeAuditDate=@financeAuditDate,
    BalanceMode = @BalanceMode
  WHERE billid = @nVchCode

  IF @@ERROR=0
  SET @nRET = @nVchCode

END
GO
