
/******************************************

XXX.2017-05-08 
wms流程的GSP单据查询

********************************************/
CREATE PROCEDURE Ts_X_GSPbillidx
(	
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间*/
	@e_id			int,
	@billtype       int=0,            /*GSP单据类型*/
	@billnumber     varchar(30) ='',  /*单据编号*/
	@Y_id           int=0,  /*业务机构*/
	@c_id           int=0,  /* 往来单位  */
	@cp_id          int=0,  /* 往来机构  */
	@s_id           int=0,   /*仓库ID*/
	@billstates     int=0,   /*单据状态  --如果是14 表示查询拣货单波次下发的查询*/
	@p_id           int=0,     /*商品ID*/
	@yw_type        int=0,  /*--ywtype 业务类型*/
	@orderbill      varchar(30) = '', /*订单编号*/
	@FollowNumber       varchar(30) = '', /*随货通行单编号*/
	@TrafficType       varchar(10) = '',   /*承运方式 */
	@Level          varchar(20) = '',   /*优先级*/
	@eid2           int=0,  /*业务员*/
	@eid3           int=0,  /*收货员*/
	@eid4           int=0  /*验收员*/
)
as
BEGIN
	if @BeginDate is null set @BeginDate = '1901-01-01'
	if @EndDate is null set @EndDate = GETDATE()
	if @billtype is null set @billtype = 0
	if @billnumber is null set @billnumber = ''
	if @Y_id is null set @Y_id = 0
	if @billtype = 563 set @Y_id = 0    /*门店退货申请单需要查询所有门店的数据*/
	if @c_id is null set @c_id = 0
	if @cp_id is null set @cp_id = 0
	if @s_id is null set @s_id = 0
	if @billstates is null set @billstates = 0
	if @p_id is null set @p_id = 0
	if @yw_type is null set @yw_type = 0
	if @orderbill is null set @orderbill = ''
	if @orderbill = '' 
	  set @orderbill = '%%'
	else 
	  set @orderbill = '%' + @orderbill + '%'
	SET @billnumber = '%' + @billnumber + '%'
    
    if @FollowNumber is null set @FollowNumber = ''
	if @FollowNumber = '' 
	  set @FollowNumber = '%%'
	else 
	  set @FollowNumber = '%' + @FollowNumber + '%'

	if @TrafficType is null set @TrafficType = '全部'
	if @Level is null set @Level = ''
	if @eid2 is null set @eid2 = 0
	if @eid3 is null set @eid3 = 0
	if @eid4 is null set @eid4 = 0
	
	
	if @billtype = 44    /*移库单*/
	begin
		
		SELECT  b.billid,b.billid as Gspbillid,b.billdate, b.billnumber,b.billtype,b.Y_ID,b.c_id,
				CAST(datediff(N,b.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,b.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
				b.inputman, isnull(e.name,0) as inputmanname,b.sout_id,isnull(s1.name,'') as sout_name,
				b.sin_id,isnull(s2.name,'') as sin_name,b.quantity,
				sm1.DetailCount as DetailCount, sm2.pgQty as pgQty,
				b.ssmoney as TaxTotal,b.note as comment
		from billdraftidx b
			 left join employees e on b.inputman = e.emp_id
			 left join storages s1 on b.sout_id = s1.storage_id
			 left join storages s2 on b.sin_id = s2.storage_id
			 left join (select bill_id,COUNT(1) as DetailCount from storemanagebilldrf group by bill_id) sm1 on b.billid = sm1.bill_id 
			 left join (
						select bill_id,COUNT(p_id) as pgQty from (
						select bill_id,p_id from storemanagebilldrf group by bill_id,p_id) sm
						group by sm.bill_id 
						) sm2 on b.billid = sm2.bill_id 
		WHERE   (b.billtype = @billtype) AND
				(b.Y_ID = @Y_id or @Y_id = 0) AND
				(b.billnumber LIKE @billnumber) AND
				(@p_id = 0 OR billid IN (SELECT bill_id FROM storemanagebilldrf WHERE P_id = @p_id))
	
	end	
	else if @billtype = 531
	begin 
		
		SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						ISNULL(T3.ename,'') AS auditman,  /*验收人*/
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, ISNULL(T1.ename,'') AS buyman, ISNULL(T2.ename,'') as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName,
						case when g.IsPDA = 1 then 'PDA上架'  when ISNULL(P.printcount, 0) > 0 and g.BillStates < 15 then '已打印' when g.BillStates = 15 then '已入库' else '待处理' end  AS billStatesN, /*billstateText*/
						g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,inbags,
						g.sendcname as SendCName,g.comment,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.PgQty as pgQty, g.DetailCount,g.yxj as Level
						/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
		FROM      dbo.VW_GSPBILLIDX AS g
					LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
					/*需要查询采购人，收货人，验收人的查询*/
					LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
					LEFT JOIN (select * from VW_BILLTRACE where id in 
						( select MAX(id) from DBO.billTrace where billtype in (22,161,163,562) group by billtype,traceGuid)
						 )  T1 ON isnull(T.traceGuid,NEWID())  = T1.traceGuid    /*经手人*/
					LEFT JOIN (select * from VW_BILLTRACE where id in 
						( select MAX(id) from DBO.billTrace where billtype in (511,512,513,514,516,517) group by billtype,traceGuid)
						 )  T2 ON isnull(T.traceGuid,NEWID())  = T2.traceGuid    /*收货人*/
					LEFT JOIN (select * from VW_BILLTRACE where id in 
						( select MAX(id) from DBO.billTrace where billtype in (521,522,523,524) group by billtype,traceGuid)
						 )  T3 ON isnull(T.traceGuid,NEWID())  = T3.traceGuid    /*验收人				 */

		WHERE   (g.BillType = @billtype) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
			AND (@c_id = 0 OR IsCompany = 0 AND C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND C_id = @cp_id)
			AND (@s_id = 0 OR g.S_id = @s_id)  AND (@p_id = 0 OR Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
			AND (@yw_type = 0 OR Ybilltype = @yw_type) AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
			AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
			AND (FollowNumber LIKE @FollowNumber)
			AND ((TrafficType = @TrafficType) or (@TrafficType = '全部'))
			AND ((g.yxj = @Level) or (@Level = ''))
			AND ((T1.inputman = @eid2) or (@eid2 = 0))
			AND ((T2.inputman = @eid3) or (@eid3 = 0))
			AND ((T3.inputman = @eid4) or (@eid4 = 0))
			AND (@billstates = 4 OR (@billstates = 0 AND g.BillStates IN (10,13))  OR (@billstates = 3 AND g.BillStates IN (15))
				OR (@billstates = 2 AND g.IsPDA = 1 ) OR (@billstates = 1 AND ISNULL(P.printcount, 0) > 0 and g.BillStates < 15 ) )
	
	end
	else if @billtype = 541   /*查询拣货单*/
	begin
		if @billstates = 14  /*交领拣货单的查询*/
		begin
		
			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
							g.AUDITER1 AS auditman,
							/*g.AuditTime1, */
							(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
							g.AuditMan2, g.AUDITER1 AS buyman, g.B_CustomName5 as checkman,
							/*g.AuditTime2, */
							(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
							g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
							g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
							g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
							g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
							g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
							CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,inbags,
							g.sendcname as SendCName,
							/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
							CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
							g.comment,g.WholeFlag, g.PickType, g.PrintType,
							g.S_NAME AS sname2,g.yxj as Level,g.PgQty as pgQty, g.DetailCount
							/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
						left join stockArea sa on g.sa_id = sa.sa_id
			WHERE   (BillType = @billtype) AND (BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND  (@p_id = 0 OR Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				AND (@yw_type = 0 OR Ybilltype = @yw_type) AND (YBILLNUMBER LIKE @orderbill) AND (BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.AuditMan1 = @eid2) or (@eid2 = 0))
				AND ((g.B_CustomName4 = @eid3) or (@eid3 = 0))
				AND ((g.InputMan = @eid4) or (@eid4 = 0))	
				AND (G.BillStates <> 15) AND (G.DeskId > 0) and (g.HoldId >0)
		end
		else
		begin

			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
							g.AUDITER1 AS auditman,
							/*g.AuditTime1, */
							(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
							g.AuditMan2, g.AUDITER1 AS buyman, g.B_CustomName5 as checkman,
							/*g.AuditTime2, */
							(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
							g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
							g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
							g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
							g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName,
							 case when g.IsPDA = 1 then 'PDA复核'  when ISNULL(P.printcount, 0) > 0 and g.BillStates < 15 then '复核中' when g.BillStates = 15 then '已复核' else '待复核' end  AS billStatesN, /*billstateText */
							 g.YBillTypeName AS ywtype, 
							g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
							CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,inbags,
							g.sendcname as SendCName,
							/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
							CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
							g.comment,g.WholeFlag, g.PickType, g.PrintType,
							g.S_NAME AS sname2,g.yxj as Level,g.PgQty as pgQty, g.DetailCount
							/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2

			WHERE   (BillType = @billtype) AND (BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR BillStates = @billstates) AND (@p_id = 0 OR Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				AND (@yw_type = 0 OR Ybilltype = @yw_type) AND (YBILLNUMBER LIKE @orderbill) AND (BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.AuditMan1 = @eid2) or (@eid2 = 0))
				AND ((g.B_CustomName4 = @eid3) or (@eid3 = 0))
				AND ((g.InputMan = @eid4) or (@eid4 = 0))
		end
	end
	else if @billtype = 551   /*查询复核单*/
	begin
		
		SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditman,
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, g.AUDITER1 AS buyman, g.B_CustomName5 as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,g.inbags,
						g.sendcname as SendCName,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.yxj as Level,g.PgQty as pgQty, g.DetailCount,
						isnull(gi.BillNumber,'') as Pickbillnumber,
						ISNULL(GI.BillDate,0) AS YBILLDATE
						/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
		FROM      dbo.VW_GSPBILLIDX AS g
					LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
					LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
					LEFT JOIN DBO.billTrace T2 ON T.lastId  = T2.id
					LEFT JOIN GSPbillidx gi on gi.Gspbillid = t2.billId 

		WHERE   (g.BillType = @billtype) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
			AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
			AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR g.Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
			AND (@yw_type = 0 OR g.Ybilltype = @yw_type) AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
			AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
			AND (g.FollowNumber LIKE @FollowNumber)
			AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
			AND ((g.yxj = @Level) or (@Level = ''))
			AND ((g.AuditMan1 = @eid2) or (@eid2 = 0))
			AND ((g.B_CustomName4 = @eid3) or (@eid3 = 0))
			AND ((g.InputMan = @eid4) or (@eid4 = 0))	
			AND (G.BillStates = @billstates or @billstates = 0) 
	end
	else
	begin
		if @yw_type = 0 /*表示全部*/
		begin
			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditman,
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, isnull(g.YE_NAME,'') AS buyman, g.AUDITER1 as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,g.inbags,
						g.sendcname as SendCName,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment as comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.yxj as Level,gd.PgQty as pgQty, g.DetailCount,
						CASE ISNULL(T1.BILLSTATES,-1) WHEN -1 THEN '待验收' WHEN 10  THEN '验收中' END as AcceptStates
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
						LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
						LEFT JOIN (select * from VW_BILLTRACE where id in 
							( select MAX(id) from DBO.billTrace where billtype in (531) group by billtype,traceGuid)
							 )  T1 ON isnull(T.traceGuid,NEWID())  = T1.traceGuid   		
						/*LEFT JOIN GSPbillidx B ON B.BillType = 531 AND (ISNULL(B.BillStates,0) IN (10,12)) AND G.Yguid = B.Yguid*/
						LEFT JOIN (select Gspbill_id,COUNT(1) as PgQty from (select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id) gd
							on g.Gspbillid = gd.Gspbill_id
						
			WHERE   (g.BillType in (511,512,513,514,516,517)) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR g.Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				/*AND (@yw_type = 0 OR g.Ybilltype = @yw_type) */
				AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (g.FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.YE_ID = @eid2) or (@eid2 = 0))
				AND ((g.AuditMan1 = @eid3) or (@eid3 = 0))
				AND ((g.AuditMan2 = @eid4) or (@eid4 = 0))
				AND (ISNULL(T1.BillStates,0) NOT IN (13,15))   /*已经生成上架单的过滤掉*/
		end
		else if @yw_type = 1 /*表示采购*/
		begin
			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditman,
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, isnull(g.YE_NAME,'') AS buyman, g.AUDITER1 as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,g.inbags,
						g.sendcname as SendCName,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.yxj as Level,gd.PgQty as pgQty, g.DetailCount,
						CASE ISNULL(T1.BILLSTATES,-1) WHEN -1 THEN '待验收' WHEN 10  THEN '验收中' END as AcceptStates
						/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
						LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
						LEFT JOIN (select * from VW_BILLTRACE where id in 
							( select MAX(id) from DBO.billTrace where billtype in (531) group by billtype,traceGuid)
							 )  T1 ON isnull(T.traceGuid,NEWID())  = T1.traceGuid    		
						/*LEFT JOIN GSPbillidx B ON B.BillType = 531 AND (ISNULL(B.BillStates,0) IN (10,12)) AND G.Yguid = B.Yguid*/
						LEFT JOIN (select Gspbill_id,COUNT(1) as PgQty from (select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id) gd
							on g.Gspbillid = gd.Gspbill_id
							
			WHERE   (g.BillType in (511,513)) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR g.Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				/*AND (@yw_type = 0 OR g.Ybilltype = @yw_type) */
				AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (g.FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.YE_ID = @eid2) or (@eid2 = 0))
				AND ((g.AuditMan1 = @eid3) or (@eid3 = 0))
				AND ((g.AuditMan2 = @eid4) or (@eid4 = 0))
				AND (ISNULL(T1.BillStates,0) NOT IN (13,15))   /*已经生成上架单的过滤掉*/
		end
		else if @yw_type = 2 /*表示销售退回*/
		begin
			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditman,
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, isnull(g.YE_NAME,'') AS buyman, g.AUDITER1 as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,g.inbags,
						g.sendcname as SendCName,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.yxj as Level,gd.PgQty as pgQty, g.DetailCount,
						CASE ISNULL(T1.BILLSTATES,-1) WHEN -1 THEN '待验收' WHEN 10  THEN '验收中' END as AcceptStates
						/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
						LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
						LEFT JOIN (select * from VW_BILLTRACE where id in 
							( select MAX(id) from DBO.billTrace where billtype in (531) group by billtype,traceGuid)
							 )  T1 ON isnull(T.traceGuid,NEWID())  = T1.traceGuid    /*经手人		*/
						/*LEFT JOIN GSPbillidx B ON B.BillType = 531 AND (ISNULL(B.BillStates,0) IN (10,12)) AND G.Yguid = B.Yguid*/
						LEFT JOIN (select Gspbill_id,COUNT(1) as PgQty from (select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id) gd
							on g.Gspbillid = gd.Gspbill_id
							
			WHERE   (g.BillType in (512,514)) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR g.Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				/*AND (@yw_type = 0 OR g.Ybilltype = @yw_type) */
				AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (g.FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.YE_ID = @eid2) or (@eid2 = 0))
				AND ((g.AuditMan1 = @eid3) or (@eid3 = 0))
				AND ((g.AuditMan2 = @eid4) or (@eid4 = 0))
				AND (ISNULL(T1.BillStates,0) NOT IN (13,15))   /*已经生成上架单的过滤掉*/
		end
		else if @yw_type = 3 /*表示机构退回*/
		begin
			SELECT   g.Gspbillid AS Gspbillid, g.Gspbillid AS billid, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditman,
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, isnull(g.YE_NAME,'') AS buyman, g.AUDITER1 as checkman,
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER as ordbillnumber, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
						CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,g.inbags,
						g.sendcname as SendCName,
						/*datediff(HH,g.BillDate,GETDATE()) as  WaitTime,*/
						CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime,
						g.comment as comment,g.WholeFlag, g.PickType, g.PrintType,
						g.S_NAME AS sname2,g.yxj as Level,gd.PgQty as pgQty, g.DetailCount,
						CASE ISNULL(T1.BILLSTATES,-1) WHEN -1 THEN '待验收' WHEN 10  THEN '验收中' END as AcceptStates
						/*CASE ISNULL(B.Gspbillid,0) WHEN 0 THEN '待验收' ELSE '验收中' END as AcceptStates*/
			FROM      dbo.VW_GSPBILLIDX AS g
						LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
						LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
						LEFT JOIN (select * from VW_BILLTRACE where id in 
							( select MAX(id) from DBO.billTrace where billtype in (531) group by billtype,traceGuid)
							 )  T1 ON isnull(T.traceGuid,NEWID())  = T1.traceGuid    /*经手人		*/
						/*LEFT JOIN GSPbillidx B ON B.BillType = 531 AND (ISNULL(B.BillStates,0) IN (10,12)) AND G.Yguid = B.Yguid*/
						LEFT JOIN (select Gspbill_id,COUNT(1) as PgQty from (select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id) gd
							on g.Gspbillid = gd.Gspbill_id
							
			WHERE   (g.BillType in (516,517)) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
				AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
				AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR g.Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
				/*AND (@yw_type = 0 OR g.Ybilltype = @yw_type) */
				AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)
				AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
				AND (g.FollowNumber LIKE @FollowNumber)
				AND ((g.TrafficType = @TrafficType) or (@TrafficType = '全部'))
				AND ((g.yxj = @Level) or (@Level = ''))
				AND ((g.YE_ID = @eid2) or (@eid2 = 0))
				AND ((g.AuditMan1 = @eid3) or (@eid3 = 0))
				AND ((g.AuditMan2 = @eid4) or (@eid4 = 0))
				AND (ISNULL(T1.BillStates,0) NOT IN (13,15))   /*已经生成上架单的过滤掉*/
				/*AND (ISNULL(B.BillStates,0) IN (0,10,12))   --已经生成上架单的过滤掉*/
		end
	end
end
GO
