
CREATE FUNCTION FilterStorehouseini(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     sh.storehouseini_id, sh.location_id, sh.s_id, sh.p_id, sh.supplier_id, sh.quantity, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costprice ELSE 0 END AS costprice, 
		           CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtotal ELSE 0 END AS costtotal, sh.batchno, sh.makedate, sh.instoretime, 
							  sh.validdate, sh.commissionflag, sh.stopsaleflag, sh.inorder, sh.yhdate, sh.BatchBarCode, sh.Y_ID, sh.scomment,p.IsSplit,sh.taxrate, 
							  CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtaxprice ELSE 0 END AS costtaxprice, 
							  CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtaxtotal ELSE 0 END AS costtaxtotal,  
							  sh.batchprice
		FROM         dbo.storehouseini AS sh INNER JOIN
							  dbo.products AS p ON sh.p_id = p.product_id
GO
