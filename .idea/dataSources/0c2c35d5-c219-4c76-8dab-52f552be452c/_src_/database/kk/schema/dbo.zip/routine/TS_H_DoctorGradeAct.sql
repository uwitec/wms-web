

CREATE PROCEDURE [dbo].[TS_H_DoctorGradeAct]
	/* Add the parameters for the stored procedure here*/
	@Act		int,
	@Id			int,
	@Name		varchar(50),
	@isReg		bit = 0,
	@SPID		int = 0
AS
BEGIN
/*Params Ini begin*/
if @isReg is null  SET @isReg = 0
if @SPID is null  SET @SPID = 0
/*Params Ini end*/
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;

    /* Insert statements for procedure here*/
	if @Act = 0
	begin
		if Exists(select * from doctorGrade where [name] = @name)
		begin
			Raiserror('名称不能重复！', 16, 1)
			return 0
		end
		insert into doctorGrade(
			[name],
			[isreg],
			[SPID]
		) values(
			@name,
			@isReg,
			@SPID
		)
		if @@rowcount > 0
			return @@identity
	end
	else
	if @Act = 1
	begin
		if Exists(select * from doctorGrade where [name] = @name and Gradeid <> @Id)
		begin
			Raiserror('名称不能重复！', 16, 1)
			return 0
		end
		update doctorGrade set
			[name] = @Name,
			[isReg] = @isReg,
			[SPID] = @SPID
		where [Gradeid] = @Id
		return @Id
	end
	if @Act = 2
	begin
		if exists(select * from employees where GradeId = @Id)
		begin
			Raiserror('职称已被使用，不能删除！', 16, 1)
			return 0
		end
		delete from doctorGrade where [Gradeid] = @id
		return @id
	end
END
GO
