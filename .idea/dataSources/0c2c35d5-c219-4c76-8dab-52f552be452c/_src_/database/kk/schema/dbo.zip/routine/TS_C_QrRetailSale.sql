

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

零售报表

********************************************/
CREATE PROCEDURE [TS_C_QrRetailSale]
(	@BeginDate 	  DATETIME=0,
	@EndDate		  DATETIME=0,
	@nE_ID			  INT=0,
	@nInputMan    INT=0,
	@nLocation_ID INT=0,
    @szYClass_id  varchar(50)='',
    @nloginEID    int=0,
    @nPubPosDataMode  int,  /*0 实时账套、1 独立账套、2 离线账套*/
    @bPubOffLine      int   /*分支机构启用离线*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nE_ID is null  SET @nE_ID = 0
if @nInputMan is null  SET @nInputMan = 0
if @nLocation_ID is null  SET @nLocation_ID = 0
if @szYClass_id is null  SET @szYClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
/*SET NOCOUNT ON */
  Declare @Companytable INTEGER,@employeestable integer
  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*IF ((@nPubPosDataMode<>2) or (@bPubOffLine=1)) 
BEGIN
  SELECT 
    P.[Product_ID], P.Serial_Number as [Code], P.[Name], P.[Standard], P.[Makearea],P.[Custompro1],P.[Custompro2],P.[Custompro3],P.[Custompro4],P.[Custompro5],  
    RB.[Batchno],
    ISNULL(U1.[Name], '')[Unitname1],   ISNULL(M.[MT_Name],'')[Medtype], P.[Permitcode],
    ISNULL(L.[Loc_name], '') AS [Loc_name],
	  MAX(E.[Name])  AS [Ename],
    MAX(E1.[Name]) AS [Inputman],
	  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Quantity]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salequantity],
	  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Saletotal],
	  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Quantity]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salebackquantity],
	  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Taxtotal]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salebacktotal],
	  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Saleprice]                                    AS NUMERIC(25,8)) ELSE 0 END) AS [Saleprice],
	  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Saleprice]                                    AS NUMERIC(25,8)) ELSE 0 END) AS [BackSaleprice],
	  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Discountprice]                                AS NUMERIC(25,8)) ELSE 0 END) AS [Discountprice], 
	  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Discountprice]                                AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscountprice],
	--SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Quantity]*(RB.[Saleprice]-RB.[Discountprice]) AS NUMERIC(25,8)) ELSE 0 END) AS [Discounttotal],
	  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Total]-(RB.[Total]*RB.[Discount]) AS NUMERIC(25,8)) ELSE 0 END) AS [Discounttotal],
	--SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Quantity]*(RB.[Saleprice]-RB.[Discountprice]) AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscounttotal]
	  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Total]-(RB.[Total]*RB.[Discount]) AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscounttotal],
          SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) AS [Retailtotal],
         -- SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) ELSE -CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) END) AS [Mltotal],
      dbo.Decimalbits(5,SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) ELSE -CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) END)) AS [Mltotal],   
          CASE WHEN SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) = 0 THEN '0%' ELSE
      CAST(dbo.Decimalbits(5,CAST(SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) ELSE -CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) END) / SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) AS NUMERIC(25,8)) * 100) AS VARCHAR(100)) + '%' END AS MlRate
		  --CAST(SUM(CASE RI.[Billtype] WHEN 12 THEN CAST((RB.[Taxtotal]-RB.Costprice*RB.quantity)*100/RB.taxtotal  AS NUMERIC(25,8)) ELSE -CAST((RB.[Taxtotal]-RB.Costprice*RB.quantity)*100/RB.taxtotal  AS NUMERIC(25,8)) END) AS NUMERIC(25,8)) AS [Mlrate]        
	FROM  Retailbill RB
        LEFT JOIN RetailbillIDX RI ON RB.[Bill_ID]=RI.[BillID] 
        LEFT JOIN CompanY Y        ON Y.Company_id=RI.Y_id             
	LEFT JOIN Products P       ON RB.[P_ID]=P.[Product_ID]
        LEFT JOIN Medtype M        ON P.[Medtype]=M.[MT_ID]  
        LEFT JOIN Unit U1          ON p.[Unit1_ID]=U1.[Unit_ID]
	LEFT JOIN Employees E      ON E.[Emp_ID]=RB.[rowE_ID]
        LEFT JOIN Employees E1     ON E1.[Emp_ID]=RI.[Inputman]
	LEFT JOIN Location L       ON RB.[Location_ID]=L.[Loc_ID]

	WHERE RI.[Billdate] BETWEEN @BeginDate AND @EndDate AND Ri.[Billstates]='0' AND RB.[P_ID]>0 and rb.aoid=0
          and  (@szYClass_id='' or Y.Class_id like @szYClass_id+'%')
          AND  (@nE_ID=0 or RB.[ROwE_ID]=@nE_ID)
          and  (@nInputMan=0 or RI.[Inputman]=@nInputMan)
          AND  (@nLocation_ID=0 or RB.[Location_ID]=@nLocation_ID)
          AND ((@employeestable=0) OR (RB.RowE_id in (select [id] from #employeestable)))
          AND ((@Companytable=0)or (RI.Y_id in (select [id] from #Companytable))) 
        GROUP BY P.[Product_ID], P.[Serial_Number], P.[Name], P.[Standard], P.[Makearea], 
                 RB.[Batchno], U1.[Name], M.[MT_Name], P.[Permitcode], L.[Loc_name],
                 P.[Custompro1],P.[Custompro2],P.[Custompro3],P.[Custompro4],P.[Custompro5]
END ELSE
BEGIN  */
	  SELECT 
		P.[Product_ID], P.Serial_Number as [Code], P.[Name], P.[Standard], P.[Makearea],P.[Custompro1],P.[Custompro2],P.[Custompro3],P.[Custompro4],P.[Custompro5],  
		RB.[Batchno],
		ISNULL(U1.[Name], '')[Unitname1],   ISNULL(M.name,'')[Medtype], P.[Permitcode],
		ISNULL(L.[Loc_name], '') AS [Loc_name],
		  MAX(E.[Name])  AS [Ename],
		MAX(E1.[Name]) AS [Inputman],
		  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Quantity]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salequantity],
		  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Saletotal],
		  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Quantity]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salebackquantity],
		  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Taxtotal]                                     AS NUMERIC(25,8)) ELSE 0 END) AS [Salebacktotal],
		  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Saleprice]                                    AS NUMERIC(25,8)) ELSE 0 END) AS [Saleprice],
		  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Saleprice]                                    AS NUMERIC(25,8)) ELSE 0 END) AS [BackSaleprice],
		  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Discountprice]                                AS NUMERIC(25,8)) ELSE 0 END) AS [Discountprice], 
		  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Discountprice]                                AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscountprice],
		/*SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Quantity]*(RB.[Saleprice]-RB.[Discountprice]) AS NUMERIC(25,8)) ELSE 0 END) AS [Discounttotal],*/
		  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Total]-(RB.[Total]*RB.[Discount]) AS NUMERIC(25,8)) ELSE 0 END) AS [Discounttotal],
		/*SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Quantity]*(RB.[Saleprice]-RB.[Discountprice]) AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscounttotal]*/
		  SUM(CASE RI.[Billtype] WHEN 13 THEN CAST(RB.[Total]-(RB.[Total]*RB.[Discount]) AS NUMERIC(25,8)) ELSE 0 END) AS [Backdiscounttotal],
			  SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) AS [Retailtotal],
		dbo.Decimalbits(5,SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) ELSE -CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) END)) AS [Mltotal],
			  CASE WHEN SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) = 0 THEN '0%' ELSE
	          CAST(dbo.Decimalbits(5,CAST(SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) ELSE -CAST(RB.[Taxtotal]-RB.Costprice*RB.quantity AS NUMERIC(25,8)) END) / SUM(CASE RI.[Billtype] WHEN 12 THEN CAST(RB.[Retailtotal] AS NUMERIC(25,8)) ELSE CAST(-RB.[Retailtotal] AS NUMERIC(25,8)) END) AS NUMERIC(25,8)) * 100) AS VARCHAR(100)) + '%' END AS MlRate
			  /*SUM(CASE RI.[Billtype] WHEN 12 THEN CAST((RB.[Taxtotal]-RB.Costprice*RB.quantity)*100/RB.taxtotal  AS NUMERIC(25,8)) ELSE -CAST((RB.[Taxtotal]-RB.Costprice*RB.quantity)*100/RB.taxtotal  AS NUMERIC(25,8)) END) AS [Mlrate]        */
		FROM  salemanagebill RB
			LEFT JOIN billidx RI ON RB.[Bill_ID]=RI.[BillID] 
			LEFT JOIN CompanY Y        ON Y.Company_id=RI.Y_id             
		    LEFT JOIN Products P       ON RB.[P_ID]=P.[Product_ID]
            left   join 
            (
			    select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	        )m on p.product_id = m.baseinfo_id
			LEFT JOIN Unit U1          ON p.[Unit1_ID]=U1.[Unit_ID] 
		    LEFT JOIN Employees E      ON E.[Emp_ID]=RB.[rowE_ID]
			LEFT JOIN Employees E1     ON E1.[Emp_ID]=RI.[Inputman]
		    LEFT JOIN Location L       ON RB.[Location_ID]=L.[Loc_ID]

		WHERE RI.billtype in (12,13) AND RI.[Retaildate] BETWEEN @BeginDate AND @EndDate AND Ri.[Billstates]='0' AND RB.[P_ID]>0 and rb.aoid=0 			  
			  /*and cldw=0 启用此条件后启用拆零单位则无法在汇总报表查询数据*/
			  and  (@szYClass_id='' or Y.Class_id like @szYClass_id+'%')
			  AND  (@nE_ID=0 or RB.[ROwE_ID]=@nE_ID)
			  and  (@nInputMan=0 or RI.[Inputman]=@nInputMan)
			  AND  (@nLocation_ID=0 or RB.[Location_ID]=@nLocation_ID)
			  AND ((@employeestable=0) OR (RB.RowE_id in (select [id] from #employeestable)))
			  AND ((@Companytable=0)or (RI.Y_id in (select [id] from #Companytable))) 
			GROUP BY P.[Product_ID], P.[Serial_Number], P.[Name], P.[Standard], P.[Makearea], 
					 RB.[Batchno], U1.[Name], M.name, P.[Permitcode], L.[Loc_name],
					 P.[Custompro1],P.[Custompro2],P.[Custompro3],P.[Custompro4],P.[Custompro5]
/*END*/

GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
