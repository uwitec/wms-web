
create procedure TS_L_GetJHBillFoPrint
(
  @billnumber varchar(100)
)
as
begin
  
  declare @count int
  declare @billid int
  declare @szError varchar(100)
  declare @billGUID VARCHAR(100)
  set @count = 0
  set @billid = 0
  SET @billGUID = ''
  
  if exists(select 1 from billdraftidx where billnumber = @billnumber and billtype = 10 and auditman <> 0)
  begin
    select @count = COUNT(billid) from billdraftidx where billnumber = @billnumber and billtype = 10 and auditman <> 0
    if @count > 1
    begin 
      set @szError = '草稿中存在单据编号相同的销售出库单,请检查!' 
	  raiserror(@szError,16,1) 
      return -2 
    end 
    select  @billid =billid from billdraftidx where billnumber = @billnumber and billtype = 10 and auditman <> 0
    
    if exists(select 1 from billdraftidx where order_id = @billid and sendC_id = 0 and billtype = 254)
    begin
      set @szError = '指定的销售出库单存在未复合完成的拣货单,请检查!' 
	  raiserror(@szError,16,1) 
      return -3
    end
    select JHidx.billid,XSidx.billnumber as XSbillnumber,c.name as cname,JHidx.sendC_id,JHidx.WholeQty,JHidx.PartQty,JHidx.B_CustomName3 as locname,
    c.contact_personal,c.phone_number,c.address 
    from billdraftidx JHidx 
    left join billdraftidx XSidx on JHidx.order_id = XSidx.billid
    left join clients c on c.client_id = XSidx.c_id
    where jhidx.order_id = @billid and jhidx.billtype =254 and XSidx.billtype = 10
    
    return 0
    
  end
  else
  begin
	  if exists(select 1 from billidx where billnumber = @billnumber and billtype = 10 and auditman <> 0)
	  begin
		select @count = COUNT(billid) from billidx where billnumber = @billnumber and billtype = 10 and auditman <> 0
		if @count > 1
		begin 
		  set @szError = '历史单据中存在单据编号相同的销售出库单,请检查!' 
		  raiserror(@szError,16,1) 
		  return -2 
		end
		
		SELECT @billGUID = CAST(GUID AS VARCHAR(100)) FROM billidx WHERE billnumber = @billnumber and billtype = 10 and auditman <> 0
		if not exists(select 1 from billdraftidx where InvoiceNO = @billGUID  and billtype = 254)
		begin
		  set @szError = '指定的销售出库单没有找到对应的拣货单,请检查!' 
		  raiserror(@szError,16,1) 
		  return -3
		end
		
		select JHidx.billid,XSidx.billnumber as XSbillnumber,c.name as cname,JHidx.sendC_id,JHidx.WholeQty,JHidx.PartQty,JHidx.B_CustomName3 as locname,
		c.contact_personal,c.phone_number,c.address  
		from billdraftidx JHidx 
        left join billidx XSidx on JHidx.InvoiceNO = XSidx.GUID
        left join clients c on c.client_id = XSidx.c_id
        where jhidx.InvoiceNO = @billGUID and jhidx.billtype =254 and XSidx.billtype = 10
		
	  end	
	  else
	  begin
		  set @szError ='未找到指定的销售出库单,请检查!'
		  raiserror(@szError,16,1) 
		  return -1
	  end 
  end
end
GO
