
CREATE VIEW [dbo].[VW_GSPBILLIDX]
AS
SELECT   i.Gspbillid, i.BillType, i.BillNumber, i.Y_id, i.C_id, i.BillDate, i.InputMan, i.AuditMan1, i.AuditTime1, i.AuditMan2, 
                i.AuditTime2, i.UpauditMan1, i.UpauditMan2, i.TrafficType, i.TrafficTools, i.TrafficTime, i.TempControl, i.SpecTrafficProve, 
                i.SendAddress, i.SendTime, i.TrafficCompany, i.TempControlMode, i.WholeQty, i.PartQty, i.DiscountTotal, i.TaxTotal, 
                i.Ybillid, i.Ybilltype, i.Yguid, i.B_CustomName1, i.B_CustomName2, i.B_CustomName3, i.B_CustomName4, 
                i.B_CustomName5, i.BillStates, i.S_id, y.name AS Y_NAME, ISNULL(CASE WHEN i.Ybilltype IN (52, 152, 150, 161, 163,516,517,564) 
                THEN cy.name ELSE cc.name END, CASE WHEN i.BillType = 564 THEN '所有分支机构' ELSE '' END) AS C_NAME, 
 			    ISNULL(CASE WHEN i.Ybilltype IN (52, 152, 150, 161, 163, 564) THEN cy.communicateaddr ELSE cc.address END, '') AS address,
			    ISNULL(CASE WHEN i.Ybilltype IN (52, 152, 150, 161, 163, 564) THEN cy.manager ELSE cc.contact_personal END, '') AS contact_personal,
			    ISNULL(CASE WHEN i.Ybilltype IN (52, 152, 150, 161, 163, 564) THEN cy.tel ELSE cc.phone_number END, '') AS phone_number,               
                ISNULL(ipt.name, '') AS INPUTER, ISNULL(a1.name, '') AS AUDITER1, 
                ISNULL(a2.name, '') AS AUDITER2, ISNULL(u1.name, '') AS UPAUDITER1, ISNULL(u2.name, '') AS UPAUDITER2, 
                ISNULL(s.name, '') AS S_NAME, i.Note, ISNULL(CASE WHEN i.Ybilltype IN (22, 14, 108, 150, 152, 564) 
                THEN oi.taxrate ELSE bi.taxrate END, 0) AS TaxRate,
                /*zjx--tfs41964--2016-10-20--以前没有原经手人字段，所以从上张单子取，现在加了原经手人字段所以直接从表取不需要去找上张单子*/
                /*ISNULL(CASE WHEN i.Ybilltype IN (22, 14, 108, 150, 152, 564) */
                /*THEN oi.ename ELSE bi.ename END, '') AS YE_NAME, */
                /*ISNULL(CASE WHEN i.Ybilltype IN (22, 14, 108, 150, 152, 564) */
                /*THEN oi.e_id ELSE bi.e_id END, 0) AS YE_ID, */
                ee.name as YE_NAME,
                i.YE_ID as YE_ID,
                ISNULL(CASE WHEN i.Ybilltype IN (22, 14, 108, 150, 152, 564) 
                THEN oi.billnumber ELSE bi.billnumber END, '') AS YBILLNUMBER, ISNULL(CASE WHEN i.Ybilltype IN (22, 14, 108, 150, 
                152, 564) THEN oi.invoice ELSE bi.invoice END, 0) AS invoice, i.financeAudit, i.financeAuditDate, ISNULL(e5.name, '') 
                AS FinanceAuditer,  dbo.FN_GetVchStatesText(i.billstates, i.billtype) as billstateText,
				CASE WHEN i.Ybilltype IN (150, 152, 151, 153,160,161,162,163,523,524, 564) THEN 1 ELSE 0 END AS IsCompany,
				case i.Ybilltype when 10 then '销售退回申请单' when 20 then '采购退出申请单' else ISNULL(v.Comment, '') end AS YBillTypeName,
				i.FollowNumber, i.TicketDate,I.Sendid, i.BalanceMode,i.inbags,isnull(sci.name,'') as SendCname,i.SendC_Id ,
				i.detailcount,i.PgQty,isnull(oi.note,'') as comment,
				CASE WHEN i.Ybilltype IN (14,152,20) then (case i.PrioRity when  0 then '一般' when 1 then '补货' when 2  then '优先'  else '急救' end)  else '' end as yxj,
				i.sa_id,i.HoldId,i.DeskId,I.GUID,
				case isnull(sa.SAPickType,0) when 0 then '纸单' when 1 then '电子标签' else 'PDA' end as PickType,
				case isnull(sa.SAType,0) when  0 then '整货库' else '零货库' end as WholeFlag,
				case isnull(sa.SAPrintType,0) when 0 then '整件标签打印' when 1 then '纸单拣货打印' else '电子标签打印' end as PrintType,
				isnull(sa.name,'') as SaName, ISNULL(wc.Code,'') as deskcode, ISNULL(wh.Code,'') as HoldCode,
				i.IsPDA
FROM      dbo.GSPbillidx AS i INNER JOIN
                dbo.company AS y ON i.Y_id = y.company_id LEFT OUTER JOIN
                dbo.VchType AS v ON i.Ybilltype = v.Vch_ID LEFT OUTER JOIN
                dbo.employees AS ipt ON i.InputMan = ipt.emp_id LEFT OUTER JOIN
                dbo.employees AS a1 ON i.AuditMan1 = a1.emp_id LEFT OUTER JOIN
                dbo.employees AS a2 ON i.AuditMan2 = a2.emp_id LEFT OUTER JOIN
                dbo.employees AS u1 ON i.UpauditMan1 = u1.emp_id LEFT OUTER JOIN
                dbo.storages AS s ON i.S_id = s.storage_id LEFT OUTER JOIN
                dbo.employees AS u2 ON i.UpauditMan2 = u2.emp_id LEFT OUTER JOIN
                dbo.employees AS e5 ON i.financeAudit = e5.emp_id LEFT OUTER JOIN
                dbo.clients AS cc ON i.C_id = cc.client_id LEFT OUTER JOIN
                dbo.company AS cy ON i.C_id = cy.company_id LEFT OUTER JOIN
                dbo.vw_c_orderidx AS oi ON i.Ybillid = oi.billid AND i.Ybilltype IN (22, 14, 108, 150, 152) LEFT OUTER JOIN
                dbo.vw_c_billidx AS bi ON i.Ybillid = bi.billid LEFT OUTER JOIN
                dbo.employees ee on i.YE_ID=ee.emp_id left outer join 
                dbo.clients sci on i.SendC_Id=sci.client_id LEFT OUTER JOIN
                dbo.stockArea sa on i.sa_id = sa.sa_id LEFT OUTER JOIN
                dbo.WMSCheckBaseInfo wc on i.DeskId=wc.ID LEFT OUTER JOIN
                dbo.WMSHold wh on i.HoldId = wh.ID
GO
