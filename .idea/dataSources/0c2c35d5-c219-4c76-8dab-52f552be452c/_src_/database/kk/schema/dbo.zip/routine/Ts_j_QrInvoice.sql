

CREATE	 PROCEDURE [Ts_j_QrInvoice]
	(
	 @nC_ID int = 0,
	 @szName varchar(120) = ''
        )
AS 
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = 0
if @szName is null  SET @szName = ''
/*Params Ini end*/
 if @szName = ''  set @szName = '%%'
 else set @szName = '%' + @szName + '%'

  select iv.*,
         case iv.invoice when 0 then ' '
                      when 1 then '收据' 
 	 	      when 2 then '普票'
 	 	      when 3 then '增值税票'
		      when 4 then '其他'
	 end as invoiceName,
	 case iv.invoiceType when 0 then '销售发票'
                          when 1 then '采购发票' 
 	 	          when 2 then '财务发票'
	 end as invoiceTypeName,
	 case iv.jsflag when 0 then ' '
                     when 1 then '按单' 
 	 	     when 2 then '按行'
	 end as jsFlagName,
    isnull(c.[name],' ') as CName, 		isnull(e1.[name],' ') as InputmanName,		
    isnull(e2.[name],' ') as AuditmanName,      isnull(e3.[name],' ') as ReAuditmanName, 	
    isnull(d.[name], ' ') as depname
    from invoiceidx iv 
    left join Clients c on iv.c_id = c.Client_id
    left join employees e1 on iv.inputman = e1.emp_id
    left join employees e2 on iv.auditman = e2.emp_id 
    left join employees e3 on iv.ReAuditman = e3.emp_id
    left join department d on iv.departmentid = d.departmentid
    where iv.states = 2 and iv.invoiceBilltype = 0 and 
          iv.[id] not in (select orderid from invoiceidx where invoiceBilltype = 1 and states in (0,1,2)) and
          iv.invoiceno like @szName and
          (c_id = @nC_ID or @nC_ID = 0)
GO
