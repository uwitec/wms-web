
/*********************************************
算法说明：按单据计算wt_id, 关联wt_id,按ysmoney统计
数据只有参考意义。
以下情况无法计算正确：
a.期初
b.不按原单采购退货
**********************************************/



CREATE PROCEDURE TS_J_QrWTArAp
( @szParid   	VARCHAR(30)='000000',  /*往来单位*/
  @szPeriod   CHAR(2)='',
  @nWT_ID     int,      /*委托书id*/
  @BeginDate  DATETIME=0,
  @EndDate    DATETIME=0,
  @EClass_id  varchar(30)='',
  @YClass_id  varchar(60)='',
  @nloginEID  int=0,
  @nFindOtherY  int=0,        /*是否查询其他分支机构 :0不查询 1 要查询*/
  @nDetachArap  int=0         /*应收应付是否分开查询 :0不查询 1 要查询 2010-04-14*/

)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParid is null  SET @szParid = '000000'
if @szPeriod is null  SET @szPeriod = ''
if @nWT_ID is null  SET @nWT_ID = 0
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @EClass_id is null  SET @EClass_id = ''
if @YClass_id is null  SET @YClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @nFindOtherY is null  SET @nFindOtherY = 0
if @nDetachArap is null  SET @nDetachArap = 0         /*应收应付是否分开查询 :0不查询 1 要查询 2010-04-14*/
/*Params Ini end*/
SET NOCOUNT ON

  IF @YClass_id in ('','000000') 
    set @YClass_id = '%%'
  else 
    set @YClass_id = @YClass_id+'%'
      
    
  IF @szParid in ('','000000') 
    set @szParid = '%%'
  else
    set @szParid = @szParid+'%'  
        
            
/* 创建中间表计算wt_id*/
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[billidx_wt]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
   create table billidx_wt
    (billid [int] not null default(0),
     wt_id [int] not null default(0)    
    )
end    

declare @maxbillid int

/*计算 采购入库*/
set @maxbillid = 0  
select @maxbillid = MAX(bi.billid) 
  from billidx bi inner join billidx_wt w on bi.billid = w.billid
  where bi.billstates = 0 and bi.billtype  = 20
if @maxbillid is null set @maxbillid =  0
   
   insert into billidx_wt(billid, wt_id) 
    select bi.billid, isnull(o.WT_ID, 0)
      from billidx bi left join orderidx o on bi.order_id = o.billid                  
     where bi.billstates = 0 and bi.billtype  = 20 and bi.billid > @maxbillid 

/*计算 采购退货*/
set @maxbillid = 0    
select @maxbillid = MAX(bi.billid) 
  from billidx bi inner join billidx_wt w on bi.billid = w.billid
  where bi.billstates = 0 and bi.billtype  = 21 and bi.billid > @maxbillid
if @maxbillid is null set @maxbillid =  0
   
   insert into billidx_wt(billid, wt_id) 
    select ct.billid, isnull(o.WT_ID, 0)
      from (select  billid, order_id from billidx where billtype  = 21 and billstates = 0 and billid  > @maxbillid and order_id > 0) ct 
      inner join billidx cg on ct.order_id = cg.billid      
      left join orderidx o on cg.order_id = o.billid                        
     where cg.billtype  = 20

/*计算 采购结算调价*/

set @maxbillid = 0    
select @maxbillid = MAX(bi.billid) 
  from billidx bi inner join billidx_wt w on bi.billid = w.billid
  where bi.billstates = 0 and bi.billtype in (24, 25)
if @maxbillid is null set @maxbillid =  0
   
   insert into billidx_wt(billid, wt_id) 
    select ct.billid, isnull(o.WT_ID, 0)
      from (select  billid, order_id from billidx where billtype in (24,25) and billstates = 0 and billid  > @maxbillid and order_id > 0) ct 
      inner join billidx cg on ct.order_id = cg.billid      
      left join orderidx o on cg.order_id = o.billid                        
     where cg.billtype  = 20

SELECT  wt.WT_ID, wt.saleEName as wtEName, c.[Client_ID], c.[Class_ID], c.[Child_number], c.[Name],
	    c.[Alias], c.[Serial_number], c.[phone_number], c.[address], c.[contact_personal],	    
	    cast(0.0 as NUMERIC(25,8)) AS [Artotal], 
	    sum(Case when bi.billtype in (20, 24) then bi.ysmoney else -bi.ysmoney end) as Aptotal,
	    cast(0.0 as NUMERIC(25,8)) AS [BeginArTotal], 	    
	    sum(Case when (bi.billtype in (20, 24)) and bi.billdate < @BeginDate then bi.ysmoney  
	             when (bi.billtype in (21, 25)) and bi.billdate < @BeginDate then -bi.ysmoney 
	             else 0 end) as [BeginApTotal],
	    cast(0.0 as NUMERIC(25,8)) AS [NowArTotal], 
	    sum(Case when (bi.billtype in (20, 24)) and bi.billdate between @BeginDate and @EndDate then bi.ysmoney  
	             when (bi.billtype in (21, 25)) and bi.billdate between @BeginDate and @enddate then -bi.ysmoney 
	             else 0 end) as [NowApTotal], 	    	    	   	   	    	   	   	    		       	    	    	    	   	   	    	   	          	    	    	   	   	    	   	   	    		    
   	    cast(0.0 as NUMERIC(25,8)) AS [EndArTotal], 	    	    	   	   	    	   	   	    		    
	    sum(Case when (bi.billtype in (20, 24)) and bi.billdate between @BeginDate and @EndDate then bi.ysmoney  
	             when (bi.billtype in (21, 25)) and bi.billdate between @BeginDate and @enddate then -bi.ysmoney 
	             else 0 end) as [NowApTotal], 	    	    	   	   	    	   	   	    		       	    		    
	    sum(Case when (bi.billtype in (20, 24)) and bi.billdate <= @EndDate then bi.ysmoney  
	             when (bi.billtype in (21, 25)) and bi.billdate <= @EndDate then -bi.ysmoney 
	             else 0 end) as [EndApTotal] 	    	    	   	   	    	   	   	    		  	    		        
   from billidx bi
   inner join billidx_wt w on bi.billid = w.billid
   inner join company y on bi.Y_ID = y.company_id
   inner join clients c on bi.c_id = c.client_id
   left join wtorder wt on w.wt_id = wt.WT_ID             
   where bi.billdate between @BeginDate and @EndDate and
         (@nWT_ID = 0 or w.wt_id =@nWT_ID) and 
         c.class_id like @szParid and y.class_id like @YClass_id
   group by  wt.WT_ID, wt.saleEName, c.[Client_ID], c.[Class_ID], c.[Child_number], c.[Name],
	         c.[Alias], c.[Serial_number], c.[phone_number], c.[address], c.[contact_personal]
GO
