
CREATE	  PROCEDURE [Ts_L_InproductsRelat]
   (@product_id	int,
    @glpid   int,
	@name   varchar(80),
	@Atype  int
	)
as  
 declare @cts int
 set @cts=(select count(Exid) from productsRelating where p_id=@product_id and R_pid=@glpid and Atype=@Atype)	
 if  @cts<=0 
 begin
    insert into  productsRelating(p_id,R_pid,P_name,Atype)
	 VALUES
	(
	@product_id,
	@glpid,
    @name,
	@Atype
	)  
 end
GO
