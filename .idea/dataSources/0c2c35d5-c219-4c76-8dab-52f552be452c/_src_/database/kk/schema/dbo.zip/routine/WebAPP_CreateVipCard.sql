



/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_CreateVipCard]
(
	@openid		varchar(100),
    @chvtel	    varchar(30),
    @chvname	varchar(50),
    @chvsex		char(1),
    @chvaddres	varchar(200),
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
select @chvErrMsg=''
if exists(select 1 from vipcard where tel=@chvtel)
begin
	select @chvErrMsg='电话号码已被注册为会员'
	select @chvErrMsg as outMsg,-1 as reCode
	return -1
end

declare @p40 varchar(100),@re int,@CardNo varchar(20),@tempdate datetime,@cardid int,@validdate datetime
declare @C_ID int
set @p40=NULL
/*select @CardNo='8'+@chvtel+'0' --生成的号码最好是13位数字（13位，最后一位是校验码设为0），生成EAN13条形码，识别高，code39,code128如果数字过长，生成的条码过长，手机屏幕无法全部显示*/
select @CardNo=@chvtel
select @tempdate=getdate()
select @validdate=GETDATE()+365
declare @pyin varchar(100) set @pyin = dbo.GetPY(@chvname)
declare @pass binary       set @pass = cast(0 as binary)

declare @Chsex varchar(10)


/*yypeng-升级测试     2016-12-22*/

if @chvsex = '1'
	set @Chsex = '女'
else 
	set @Chsex = '男'

select top 1 @C_ID = ct_id from VIPCardType 

exec @re=TS_M_InsVIPCard 
		 @Tag	      =0, 		/*0:新增 1:修改 2 :修改状态[删除,挂失,停用]  	*/
         @VIPCardID          =0, 
         @CardNo             =@CardNo,
         @Name               =@chvname,
         @sex                =@chvsex,
         @Tel                =@chvtel,
         @BulidDate          =@tempdate,
         @ValidityDate       =@validdate,  
		 @PinYin             =@pyin,
		 @LoginPass          =@pass,
		 @CT_ID              =@C_ID    


if @re=-1
begin
	select @chvErrMsg as outMsg,-1 as reCode
	return -1
end
else
begin
	select @cardid=[VIPCardID] from vipcard where CardNo=@CardNo
	insert into vipcardbind(vipcardid,weixinno) values(@cardid,@openid)	
	
	
	select @CardNo as outMsg,@cardid as reCode/*返回新建会员卡号及ID*/
	return 0
end
GO
