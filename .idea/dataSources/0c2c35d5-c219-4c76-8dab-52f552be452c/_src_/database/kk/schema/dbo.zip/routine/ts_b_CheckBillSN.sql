
CREATE	   proc ts_b_CheckBillSN
(
	@nRet int output,
	@szSN varchar(200),
	@nBillCode INT,
	@nTAG INT
)
/*with encryption*/
AS
SET NOCOUNT ON
SET @nRET = 0
IF @nTAG =0
BEGIN
  IF EXISTS(SELECT BILLID FROM BILLDRAFTIDX WHERE billid<>@nBillCode AND BILLNUMBER=@szSN)  SET @nRET = 1
  ELSE
  IF EXISTS(SELECT BILLID FROM BILLIDX WHERE BillStates='0' and billid<>@nBillCode AND  BILLNUMBER=@szSN)	SET @nRET = 1
  else
  IF EXISTS(SELECT billid FROM tranidx WHERE billid <> @nBillCode AND billnumber = @szSN)  SET @nRET = 1	
END
ELSE
IF @nTAG = 1
BEGIN
  IF EXISTS(SELECT GSPID FROM GSPTABLE WHERE GSPID<>@nBillCode AND  BILLCODE=@szSN)  SET @nRET = 1
END
ELSE
IF @nTAG = 244	/* 检查处方笺 by Huang.Y*/
BEGIN
	if exists(select billid from retailbillidx where billid <> @nbillcode and BILLNUMBER = @szSN) set @nret = 1
END
ELSE
IF @nTAG IN (14, 22)/*销售订单、采购订单*/
BEGIN
	IF EXISTS(SELECT billid FROM orderidx WHERE billid <> @nBillCode AND billnumber = @szSN)  SET @nRET = 1	
END
IF @nTAG IN (18, 27)/*销售报价单、采购报价单*/
BEGIN
	IF EXISTS(SELECT billid FROM priceInquireidx WHERE billid <> @nBillCode AND billnumber = @szSN)  SET @nRET = 1	
END
/*IF @nTAG IN (52)--请货单
BEGIN
	IF EXISTS(SELECT billid FROM tranidx WHERE billid <> @nBillCode AND billnumber = @szSN)  SET @nRET = 1	
END */
ELSE
IF (@nTAG >= 501) AND (@nTAG <= 599)/*此区间为GSP单据类型 by ZK*/
BEGIN
	IF EXISTS(SELECT Gspbillid FROM GSPBillIdx WHERE Gspbillid <> @nBillCode AND billnumber = @szSN)  SET @nRET = 1
END

RETURN 0
GO
