



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

部门费用类统计
算法：先使用临时表的方法查询出需要的明细和科目库
再使用动态的SQL语句查询出数据集
@cPublic       方式
  ‘D’部门费用
  ‘E’职员费用
@szListFlag    列表方式
'A'  全部列表
'P'  部分列表
'L'  分级列表
@szAccountID  科目的ID号
@szEmpID      职员的ID号
@szStartDate  开始时间
@szENDDate    结束时间

最后的修改日期 2003-11-07

********************************************/
CREATE PROCEDURE [Ts_X_AccountExpenseAnalyse]
( @cPublic       VARCHAR(1),
  @szListFlag    VARCHAR(1),
  @szAccountID   VARCHAR(30),
  @szEmpID       VARCHAR(30),
  @szStartDate   DATETIME,
  @szENDDate     DATETIME,
  @OperatorID	 INT = 0,
  @YClass_id  	 VARCHAR(60)=''
)

/*with encryption*/
AS 
/*Params Ini begin*/
if @OperatorID is null  SET @OperatorID = 0
if @YClass_id is null  SET @YClass_id = ''
/*Params Ini end*/
	SET NOCOUNT ON

  DECLARE @SQLScript  VARCHAR(6000)
  DECLARE @SQLFile    VARCHAR(15)
  DECLARE @EXPENSE_ID VARCHAR(30)
  DECLARE @szName     VARCHAR(50)
  DECLARE @lDepartID  INT

  SELECT   @EXPENSE_ID='000004000003'

/*--------------分支机构*/

   DECLARE @Companytable INT,@employeestable INT
   DECLARE @SQLYClassId VARCHAR(200) 

   IF @YClass_id not in ('','000000','%%')    /*增加分支机构查询 */
     SET @SQLYClassId = @YClass_id + '%'
   ELSE SET @SQLYClassId = '%%'    

/*------------------------------授权*/
  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/
/*------------------------------授权*/

  IF  @cPublic='D' GOTO GetDepartment
  IF  @cPublic='E' GOTO GetEmployee

GetDepartment:

/*得到部门的科目发生额*/
  SELECT  YYAD.[Department_Id], YYAD.[Jdmoney], YYAD.[AClass_ID]as class_id INTO #TempDDetail
  FROM
    (SELECT  YAD.[Department_Id], YAD.[Jdmoney],YAD.Y_id,
             isnull(a.[Class_ID],'')AClass_id,isnull(Y.[Class_id],'')YClass_id
    FROM
      (select AD.jdmoney,b.department_id,ad.a_id,ad.Y_id 
       from AccountDetail AD
       left join billidx b  on b.billid=ad.billid
      where b.[Billdate] between @szStartDate and @szENDDate and b.billstates=0
       UNION ALL
       select jdmoney,department_id,a_id,Y_id
       from YAccountDetail 
      where [Billdate] between @szStartDate and @szENDDate and billstates=0
      )YAD
      left join Account a on a.account_id=Yad.a_id
      left join Company Y on Y.Company_id=YAD.Y_id
    )YYAD 
    WHERE LEFT(YYAD.ACLASS_ID,LEN(@EXPENSE_ID))=@EXPENSE_ID 
      AND YYAD.YClass_ID like @SQLYClassId
      AND ((@Companytable=0) or (YYAD.Y_id in (select [id] from #Companytable)))
    

/*得到科目表*/
  IF  @szListFlag='L'
  BEGIN
    SELECT  * INTO #TempAccount
    FROM
      (SELECT  [Account_ID], [Class_ID], [Child_number], [Serial_number], [Name]
      FROM Account
      WHERE LEFT([Class_ID], LEN(@EXPENSE_ID))=@EXPENSE_ID
        and [Parent_ID]=@szAccountID and [DELETEd]<>1 
      ) A
    SELECT  @SQLFile='#TempAccount'
  END
  IF  @szListFlag='A'
  BEGIN
    SELECT  * INTO #TempAccount1
    FROM
      (SELECT  [Account_ID], [Class_ID], [Child_number], [Serial_number], [Name]
      FROM Account
      WHERE LEFT([Class_ID], LEN(@EXPENSE_ID))=@EXPENSE_ID
        and [Child_number]=0 and [DELETEd]<>1 
      ) A
    SELECT  @SQLFile='#TempAccount1'
  END
  IF  @szListFlag='P'
  BEGIN
    SELECT  * INTO #TempAccount2
    FROM
      (SELECT  [Account_ID], [Class_ID], [Child_number], [Serial_number], [Name]
      FROM Account
      WHERE LEFT([Class_ID], LEN(@EXPENSE_ID))=@EXPENSE_ID
        and LEFT([Class_ID], LEN(@szAccountID))=@szAccountID and [DELETEd]<>1
        and [Child_number]=0 
      ) A
    SELECT  @SQLFile='#TempAccount2'
  END

  SELECT  @SQLScript='SELECT  A.[Account_ID], A.[Class_ID], A.[Child_number], 
    A.[Serial_number] AS [科目编号], A.[Name] AS [科目名称], ISNULL(SUM([Jdmoney]), 0) AS [合计]'

/*得到执行的动态的SQL语句*/
  DECLARE My_CURSOR CURSOR FOR 
    SELECT  [DepartmentId], [Name] FROM Department WHERE [DELETEd]<>1 ORDER BY [DepartmentId]
  OPEN My_cursor
  FETCH NEXT FROM My_CURSOR INTO @lDepartID, @szName 
  WHILE @@FETCH_STATUS=0
  BEGIN
        SELECT  @SQLScript=@SQLScript+', SUM(CASE TD.[Department_ID] WHEN '
        	+CAST(@lDepartID AS VARCHAR)+' THEN [Jdmoney] ELSE 0 END) AS ['+@szName+']'			
  	FETCH NEXT FROM My_CURSOR INTO @lDepartID, @szName 
  END

  CLOSE My_cursor
  DEALLOCATE My_cursor
        
  SELECT  @SQLScript=@SQLScript+' FROM	'+@SQLFile+' A
		LEFT join #TempDDetail TD 
		ON LEFT(TD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
		GROUP BY A.[Account_ID], A.[Class_ID], A.[Child_number], A.[Serial_number], A.[Name]
		ORDER BY A.[Account_ID]'
			
/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO Succee

GetEmployee:
/*得到职员的临时表*/
  IF  @szListFlag='L'
  BEGIN
    SELECT  * INTO #TempEmployee
    FROM
      (SELECT  e.[Emp_ID], e.[Class_ID], e.[Child_number], e.[Serial_number], e.[Name],
      ISNULL(d.[Name], '') AS [DName]
      FROM Employees e LEFT join Department d
        ON e.[Dep_ID]=d.[DepartmentId]
      WHERE e.[DELETEd]<>1 and e.[Emp_ID]<>1 /*and e.[Parent_ID]=@szEmpID*/
         AND ((@employeestable=0) OR (Emp_id in (select [id] from #employeestable)))
         AND ((@YClass_id <> '' and e.Y_ID in (select company_id from company where class_id like @SQLYClassId)) or 
              (@YClass_id = '' and e.[Parent_ID]=@szEmpID))      
    ) E
    SELECT  @SQLFile='#TempEmployee'
  END
  IF  @szListFlag='A'
  BEGIN
    SELECT  * INTO #TempEmployee1
    FROM
      (SELECT  e.[Emp_ID], e.[Class_ID], e.[Child_number], e.[Serial_number], e.[Name],
      ISNULL(d.[Name], '') AS [DName]
      FROM Employees e LEFT join Department d
        ON e.[Dep_ID]=d.[DepartmentId]
      WHERE e.[DELETEd]<>1 and e.[Emp_ID]<>1 and e.[Child_number]=0
        AND ((@employeestable=0) OR (EMP_id in (select [id] from #employeestable)))
        AND e.Y_ID in (select company_id from company where class_id like @SQLYClassId)
    ) E
    SELECT  @SQLFile='#TempEmployee1'
  END
  IF  @szListFlag='P'
  BEGIN
    SELECT  * INTO #TempEmployee2
    FROM
      (SELECT  e.[Emp_ID], e.[Class_ID], e.[Child_number], e.[Serial_number], e.[Name],
      ISNULL(d.[Name], '') AS [DName]
      FROM Employees e LEFT join Department d
        ON e.[Dep_ID]=d.[DepartmentId]
      WHERE e.[DELETEd]<>1 and e.[Emp_ID]<>1 
      /*and LEFT([Class_ID], LEN(@szEmpID))=@szEmpID */
      and e.[Child_number]=0
      AND ((@employeestable=0) OR (Emp_id in (select [id] from #employeestable)))      
      AND ((@YClass_id <> '' and e.Y_ID in (select company_id from company where class_id like @SQLYClassId)) or 
              (@YClass_id = '' and LEFT([Class_ID], LEN(@szEmpID))=@szEmpID )) 
    ) E
    SELECT  @SQLFile='#TempEmployee2'
  END

/*得到职员的科目发生额*/
  SELECT  EYAD.[Jdmoney],EYAD.AClass_id,
          EYAD.EClass_id as class_id INTO #TempEDetail
  FROM
    (SELECT  YAD.[Jdmoney],YAD.Y_ID,ISNULL(A.Class_id,'')AClass_id,
             isnull(e.[Class_ID],'')EClass_id,isnull(Y.Class_id,'')YClass_Id
     FROM
      (select AD.jdmoney,b.e_id,ad.a_id,ad.Y_id 
       from AccountDetail AD
       left join billidx b  on b.billid=ad.billid
       where b.[Billdate] between @szStartDate and @szENDDate and b.billstates=0
       UNION ALL
       select jdmoney,e_id,a_id,Y_id
       from YAccountDetail 
       where [Billdate] between @szStartDate and @szENDDate and billstates=0
      )YAD
      left join  Employees e ON E.emp_id=YAD.e_id 
      left join  Account   a ON a.account_id=YAD.a_id
      left join  Company   Y ON Y.Company_id=YAD.Y_id
      where e.Y_ID in (select company_id from company where class_id like @SQLYClassId)
    )EYAD
    WHERE LEFT(EYAD.ACLASS_ID,LEN(@EXPENSE_ID))=@EXPENSE_ID  
      AND EYAD.YClass_ID like @SQLYClassId
      AND ((@Companytable=0)or (EYAD.Y_id in (select [id] from #Companytable)))


/*得到职员的费用*/
  SELECT  @SQLScript='
  SELECT  e.[Emp_ID], e.[Class_ID], e.[Child_number], e.[Serial_number], e.[Name],
    e.[DName], SUM(ISNULL(ad.[Jdmoney], 0)) AS [Jdmoney]
  FROM '+@SQLFile+' e LEFT join #TempEDetail ad
    ON LEFT(ad.[Class_ID], LEN(e.[Class_ID]))=e.[Class_ID]
  GROUP BY e.[Emp_ID], e.[Class_ID], e.[Child_number], e.[Serial_number], e.[Name], e.[DName]
  ORDER BY e.[Emp_ID]'
  /*PRINT @SQLScript*/
  EXEC(@SQLScript) 

  GOTO Succee

Succee:
  RETURN  0
GO
