
/************************************************************
--功能：商品养护类型查询  
--创建人：Zhou JiLin 
--创建时间：2010-12-02  
--最后修改:
参数说明：
**************************************************************/
CREATE  PROCEDURE [dbo].[ts_j_RepMaintain]
(@begindate datetime,
 @enddate datetime,
 @MaintainType int,
 @MaintainDay int,
 @nP_ID int = 0
)
AS 
if @nP_ID > 0
begin
  set @begindate = 0 
  set @enddate =0
  set @MaintainType =-1
  set @MaintainDay =-1
end
   select * 
     from vw_Products 
     where IsSplit=0 and (Inputdate >= @begindate) and 
           (@enddate < 10  or Inputdate <= @enddate) and 
           (@MaintainType = -1 or  MaintainType = @MaintainType) and 
           (@MaintainDay = -1 or MaintainDay = @MaintainDay) and
           (@nP_ID = 0 or product_id = @nP_ID) and deleted = 0 and child_number =0
GO
