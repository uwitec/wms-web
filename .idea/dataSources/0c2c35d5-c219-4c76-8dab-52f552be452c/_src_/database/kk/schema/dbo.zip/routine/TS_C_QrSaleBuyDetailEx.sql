
/* exec TS_C_QrSaleBuyDetailEx '2015-02-01 00:00:00','2015-02-09 00:00:00','','','','','','','','','','','','',1,'000001',2,0,0*/
/******************************************

采购销售明细帐本

********************************************/
CREATE PROCEDURE TS_C_QrSaleBuyDetailEx
( @BeginDate   DATETIME,
 @EndDate     DATETIME,
  @szPName      varchar(300),
  @szStandard   varchar(300),
  @szMakearea   varchar(300),
  @szMedType    varchar(300),
  @szGspflag    varchar(300),
  @szBatchno    varchar(300),
  @szCName      varchar(300),
  @szInputman   varchar(300),/*制单人*/
  @szEname      varchar(300),/*经手人*/
  @szStock      varchar(300),/*仓库*/
  @szDept       varchar(300),/*部门*/
  @szProvider   varchar(300),/*供应商 zhh*/
  @nFlag        INT=0,/*=0 buy;=1 sale;*/
  @nYClassid        Varchar(50)='',
  @nloginEID    int=0,
  @isaddDate    int=0,
  @nRegionid    int=0 
)
/*WITH ENCRYPTION*/
AS
/*Params Ini begin*/
if @nFlag is null  SET @nFlag = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @nRegionid is null  SET @nRegionid = 0
/*Params Ini end*/

  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

  DECLARE @SQLScript VARCHAR(8000),@tablename varchar(50)
  SET NOCOUNT ON
  /*Declare @szwhere varchar(1000)*/
  /*Declare @isfinally int*/
  /*declare @szsql2  varchar(8000)*/


 if @szPName<>'' set @szPName ='%'+@szPName+'%'
 if @szCName<>'' set @szCName ='%'+@szCName+'%'
 if @szStandard<>''  set @szStandard ='%'+@szStandard+'%' 
 if @szMakearea<>''  set @szMakearea ='%'+@szMakearea+'%'
 if @szMedtype<> '' 
 begin 
   set @szMedtype = REPLACE(@szMedtype, '(', '') 
   set @szMedtype = REPLACE(@szMedtype, ')', '') 
 end
 if @szGspFlag<> '' 
 begin 
   set @szGspFlag = REPLACE(@szGspFlag, '(', '') 
   set @szGspFlag = REPLACE(@szGspFlag, ')', '') 
 end
 if @szstock<> '' 
 begin 
   set @szstock = REPLACE(@szstock, '(', '') 
   set @szstock = REPLACE(@szstock, ')', '') 
 end 
 if @szDept<> '' 
 begin 
   set @szDept = REPLACE(@szDept, '(', '') 
   set @szDept = REPLACE(@szDept, ')', '') 
 end 

if @nflag in (0,1)
begin                  
 /*商品出入需要特殊处理 */
	IF @nflag=0
	BEGIN
	  SELECT p.billid,p.billtype,p.billdate,p.billnumber,p.inputman,p.auditman,p.cname,p.cAddress,p.cPhone_Number,
			 p.cContact_Personal,p.ename,p.gname,p.B_CustomName3, p.RowE_id ,p.note,p.summary,p.billstates,
			 ISNULL(p.ename,'')employeename, ISNULL(p.aname,'') AS accountname,
			 p.p_id,p.batchno,(p.totalmoney/p.quantity)price,p.costprice,(p.taxtotal/p.quantity)taxprice,
			 p.validdate,p.makedate, p.[comment],ISNULL(p.ssname,'') AS storagename,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then p.quantity else -p.quantity  end)quantity,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then p.costprice*p.quantity else -p.costprice*p.quantity end)costtotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then p.taxtotal else -p.taxtotal end)taxtotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then p.totalmoney else -p.totalmoney  end)total,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then (P.totalmoney/P.quantity*p.sendQTY) else -(P.totalmoney/P.quantity*p.sendQTY) end)SendTotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then (p.taxtotal-p.costtaxtotal) else -(p.taxtotal-p.costtaxtotal) end) as mltotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222) then p.SendQTY else -p.sendQTY end)SendQTY,
			 ISNULL(p.pname,'') AS productname,
			 ISNULL(p.alias,'') as alias,
			 isnull(p.unitname1,'')unitname1,
			 ISNULL(p.[standard],'') AS [standard], 
			 ISNULL(p.[permitcode],'') AS [permitcode], 
			 ISNULL(p.[medtype],'') AS [medtype], 
			 ISNULL(p.[makearea],'') AS [makearea], 
			 ISNULL(p.[code],'') AS [code], 
			 ISNULL(p.locname,'') AS locationname,
			 ISNULL(p.suppliername,'') AS suppliername,
			 ISNULL(p.e_name,'') As e_name,
			 ISNULL(p.C_Name,'') AS C_Name,
		 inouttype=case p.commissionflag
		   WHEN 0 THEN '一般'
		   WHEN 1 THEN '委托代销'
		   WHEN 2 THEN '受托代销'
		   WHEN 3 THEN '借出'
		   WHEN 4 THEN '借进' end,
		   isnull(p.C_Customname1,'') as cc1,
		   ISNULL(p.C_Customname2,'') as cc2,
		   ISNULL(p.C_Customname3,'') as cc3,
		   ISNULL(p.C_Customname4,'') as cc4,
		   ISNULL(p.C_Customname5,'') as cc5,
		   ISNULL(p.Custompro1,'') as pc1,
		   ISNULL(p.Custompro2,'') as pc2,
		   ISNULL(p.Custompro3,'') as pc3,
		   ISNULL(p.Custompro4,'') as pc4,
		   ISNULL(p.Custompro5,'') as pc5,
		   ISNULL(p.regionname,'') as regionname,
		   ISNULL(p.inputname,'') as inputname,p.scomment, p.comment2,isnull(p.factory,'') as factory
	  FROM
		(SELECT YPSM.*,isnull(C.[name],'')Cname,isnull(C.[address],'')CAddress,isnull(C.[Phone_Number],'')CPhone_Number,
				isnull(C.Contact_Personal,'')cContact_Personal,isnull(RE.[name],'')ename,isnull(RE.class_id,'')REClass_id,
				isnull(IE.class_id,'')InputmanClass_id,isnull(A.[name],'')Aname, isnull(GE.[name],'')gName, isnull(Y.Class_id,'')YClass_id,
				isnull(S.[name],'')SSname,isnull(L.[Loc_name],'')Locname,isnull(Sup.[name],'')Suppliername,isnull(vp.[name],'')Pname,isnull(vp.alias,'') as alias,
				isnull(vp.standard,'')standard,isnull(vp.permitcode,'')permitcode,isnull(vp.makearea,'')makearea,isnull(vp.serial_number,'')code,
				ISNULL(M.name,'')[MedType],isnull(U.[name],'')UnitName1,ISNULL(vb.e_name,'')e_name,ISNULL(vb.C_Name,'')C_Name,
				isnull(rg.name, '') as regionname,
				vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
				c.C_Customname1,c.C_Customname2,c.C_Customname3,c.C_Customname4,c.C_Customname5,IE.name as inputname,f.AccountComment as factory
		 FROM   
			(select sm.p_id,sm.batchno,sm.validdate,sm.makedate,sm.comment,sm.ss_id,sm.RowE_id,sm.quantity,sm.totalmoney,sm.costprice,sm.taxtotal,
					sm.SendQTY,sm.SendCosttotal,sm.costtaxtotal, sm.Location_id,sm.Supplier_id,sm.Commissionflag,sm.scomment, sm.comment2,b.*,
					sm.factoryid
			 from buymanagebill sm
			   INNER JOIN products P on sm.p_id=p.product_id
			   INNER JOIN storages  s on sm.ss_id=s.storage_id
			   Inner JOIN
			   (select billid,billtype,billdate,billstates,billnumber,inputman,a.auditman,c_id,Y_id,a_id,note,summary,a.region_id, a.GatheringMan, a.B_CustomName3
				from billidx a
				  INNER JOIN Clients C   ON c_id=C.client_id
				where  billtype in (20,21,120,121,122,220,221,222,24,25) and  billdate BETWEEN @BeginDate AND @Enddate 
				and  billstates=0  
				and ((@szDept='') or (@szDept<>'' and department_ID in (select [TYPE] from DecodeStr(@szDept))))
	            
				and c.child_number=0 and
			   ((@szCName ='') or ((c.name like @szCname or  c.pinyin like @szCname)))
			   and (@nregionId=0 or a.region_id=@nRegionid)
	           
			   )b ON sm.bill_id=b.billid
			 where sm.p_id>0 and sm.aoid in(0,5) 
			 and (@szProvider='' or sm.Supplier_id=cast(@szProvider as int))
			 and (@szbatchno='' or sm.batchno=@szbatchno)
	         
			 and p.deleted<>1 and p.child_number=0 and 
				 (@szpname ='' or (@szpname <> '' and (p.name like @szPName) or (p.pinyin like @szPName) or (p.serial_number like @szpname)  
				 or (p.Custompro1 like @szpname)  
				 or (p.Custompro2 like @szpname)  
				 or (p.Custompro3 like @szpname)  
				 or (p.Custompro4 like @szpname)  
				 or (p.Custompro5 like @szpname)  
				  )) and
				 (@szStandard ='' or (@szStandard <> '' and (p.[standard] like @szStandard)    
				  )) and
				 (@szMakearea ='' or (@szMakearea <> '' and (p.makearea like @szMakearea)    
				  )) and  
				 (@szMedtype ='' or (@szMedtype <> '' and (p.medtype in (select [TYPE] from DecodeStr(@szMedtype)))    
				  )) and 
				 (@szGspFlag ='' or (@szGspFlag <> '' and (p.gspflag  in (select [TYPE] from DecodeStr(@szGspFlag)))
				  )) 
	              
			 and s.deleted=0 and s.child_number=0 and
					(@szstock='' or (@szstock<>'' and s.storage_id  in (select [TYPE] from DecodeStr(@szstock))))    
	                                  
			 )YPSM 
		 LEFT JOIN Clients   C  ON YPSM.c_id=C.Client_id
		 LEFT JOIN Clients  Sup ON Sup.client_id=YPSM.supplier_id
		 LEFT JOIN storages  S  ON S.storage_id=YPSM.ss_id
		 LEFT JOIN Employees RE ON RE.emp_id=YPSM.RowE_id
		 LEFT JOIN Employees IE ON IE.emp_id=YPSM.inputman
		 LEFT JOIN Employees AE ON AE.emp_id=YPSM.auditman
		 LEFT JOIN Employees GE ON GE.emp_id=YPSM.GatheringMan	 
		 LEFT JOIN Company   Y  ON Y.company_id=YPSM.Y_id
		 LEFT JOIN account   A  ON A.account_id=YPSM.a_id      
		 LEFT JOIN location  L  ON L.loc_id=YPSM.Location_id
		 LEFT JOIN Products vp  ON VP.product_id=YPSM.p_id
		 LEFT JOIN Unit     U   ON VP.[Unit1_ID]=U.[Unit_ID] 
		 left   join 
	     (
			select P_id as baseinfo_id,c.name from ProductCategory pc
            LEFT JOIN customCategory c on PComent3 = c.class_id 
            where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
	     )m on vp.product_id = m.baseinfo_id
		 Left JOIn vw_productbalance vb ON YPSM.p_id=vb.p_id and YPSM.Y_ID=vb.Y_id 
		 left join region rg on rg.region_id=ypsm.region_id
		 left join BaseFactory f on YPSM.FactoryId=f.CommID
		 		 )P
		where  (@nYClassid='' or P.YClass_id like @nYClassid+'%')
		   and (@szInputman='' or P.InputmanClass_id like @szInputman+'%')
		   and (@szEname='' or p.ReClass_id like @szEname+'%')
		order by p.p_id,p.billdate,p.billid
	END
	ELSE
	IF @nflag=1
	BEGIN
	  SELECT 
			 p.billid,p.billtype,p.billdate,p.billnumber,p.inputman,p.auditman,p.cname,p.cAddress,p.cPhone_Number,
			 p.cContact_Personal,p.ename,p.gname,p.B_CustomName3, p.RowE_id ,p.note,p.summary,p.billstates,
			 ISNULL(p.ename,'')employeename,ISNULL(p.aname,'') AS accountname,
			 p.p_id,p.batchno,(p.totalmoney/p.quantity)price,p.costprice,(p.taxtotal/p.quantity)taxprice,
			 p.validdate,p.makedate, p.[comment],ISNULL(p.ssname,'') AS storagename,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then p.quantity else -p.quantity  end)quantity,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then p.costprice*p.quantity else -p.costprice*p.quantity end)costtotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then p.taxtotal else -p.taxtotal end)taxtotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then p.totalmoney else -p.totalmoney  end)total,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then (P.totalmoney/P.quantity*p.sendQTY) else -(P.totalmoney/P.quantity*p.sendQTY) end)SendTotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then (p.taxtotal-p.costtaxtotal) else -(p.taxtotal-p.costtaxtotal) end) as mltotal,
			 (case when p.billtype in (11,13,54,211,20,35,120,122,24,220,222,151,17) then p.SendQTY else -p.sendQTY end)SendQTY,
			 ISNULL(p.pname,'') AS productname,
			 ISNULL(p.alias,'') as alias,
			 isnull(p.unitname1,'')unitname1,
			 ISNULL(p.[standard],'') AS [standard], 
			 ISNULL(p.[permitcode],'') AS [permitcode], 
			 ISNULL(p.[medtype],'') AS [medtype], 
			 ISNULL(p.[makearea],'') AS [makearea], 
			 ISNULL(p.[code],'') AS [code], 
			 ISNULL(p.locname,'') AS locationname,
			 ISNULL(p.suppliername,'') AS suppliername,
			 ISNULL(p.e_name,'') As e_name,
			 ISNULL(p.C_Name,'') AS C_Name,
			 inouttype=case p.commissionflag
						   WHEN 0 THEN '一般'
						   WHEN 1 THEN '委托代销'
						   WHEN 2 THEN '受托代销'
						   WHEN 3 THEN '借出'
						   WHEN 4 THEN '借进' end,
			 isnull(p.C_Customname1,'') as cc1,
			 ISNULL(p.C_Customname2,'') as cc2,
			 ISNULL(p.C_Customname3,'') as cc3,
			 ISNULL(p.C_Customname4,'') as cc4,
			 ISNULL(p.C_Customname5,'') as cc5,
			 ISNULL(p.Custompro1,'') as pc1,
			 ISNULL(p.Custompro2,'') as pc2,
			 ISNULL(p.Custompro3,'') as pc3,
			 ISNULL(p.Custompro4,'') as pc4,
			 ISNULL(p.Custompro5,'') as pc5,
			 ISNULL(p.regionname,'') as regionname,
			 ISNULL(p.inputname,'') as inputname,p.scomment, p.comment2,isnull(p.factory,'') as factory

	  FROM
		(
			SELECT YPSM.*,
			Cname=case when billtype in (150,151) then isnull(yc.name,'') else isnull(C.[name],'') end,
			CAddress=case when billtype in (150,151) then isnull(yc.opaddress,'') else isnull(C.[address],'') end,
			CPhone_Number=case when billtype in (150,151) then isnull(yc.tel,'') else isnull(C.[Phone_Number],'') end,
			cContact_Personal=case when billtype in (150,151) then isnull(yc.manager,'') else isnull(C.Contact_Personal,'') end,
			isnull(RE.[name],'')ename,isnull(RE.class_id,'')REClass_id, isnull(GE.[name],'')gname,
			isnull(IE.class_id,'')InputmanClass_id,isnull(A.[name],'')Aname,isnull(Y.Class_id,'')YClass_id,
			isnull(S.[name],'')SSname,isnull(L.[Loc_name],'')Locname,isnull(Sup.[name],'')Suppliername,isnull(vp.[name],'')Pname,isnull(vp.alias,'')alias,
			isnull(vp.standard,'')standard,isnull(vp.permitcode,'')permitcode,isnull(vp.makearea,'')makearea,isnull(vp.serial_number,'')code,
			ISNULL(M.name,'')[MedType],isnull(U.[name],'')UnitName1,ISNULL(vb.e_name,'')e_name,ISNULL(vb.C_Name,'')C_Name,
			isnull(rg.name, '') as regionname,
			vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			c.C_Customname1,c.C_Customname2,c.C_Customname3,c.C_Customname4,c.C_Customname5,IE.name as inputname,
			isnull(f.AccountComment,'') as factory
			FROM   
			(
				select sm.p_id,sm.batchno,sm.validdate,sm.makedate,sm.comment,sm.ss_id,sm.RowE_id,sm.quantity,sm.totalmoney,sm.costprice,sm.taxtotal,
					sm.SendQTY,sm.SendCosttotal,sm.costtaxtotal, sm.Location_id,sm.Supplier_id,sm.Commissionflag,sm.scomment, sm.comment2,b.*,
					sm.factoryid  as factoryid
				from salemanagebill sm
					INNER JOIN products P on sm.p_id=p.product_id
					INNER JOIN storages  s on sm.ss_id=s.storage_id
					Inner JOIN
					(
						select billid,billtype,billdate,billstates,billnumber,inputman,bi.auditman,c_id,Y_id,a_id,note,summary,bi.region_id,bi.GatheringMan, bi.B_CustomName3
						from billidx bi
						  inner JOIN Clients C   ON bi.c_id=C.client_id
						where billtype in (10,11,12,13,112,53,54,210,211,212,16,17) 
						and billdate BETWEEN @BeginDate AND @Enddate 
						and billstates=0  
						and ((@szDept='') or (@szDept<>'' and department_id in (select [TYPE] from DecodeStr(@szDept))))            
						and c.child_number=0 and
					   ((@szCName ='') or ((c.name like @szCname or  c.pinyin like @szCname)))
					   and (@nregionId=0 or bi.region_id=@nRegionid)
					   union all
						select billid,billtype,billdate,billstates,billnumber,inputman,auditman,c_id,Y_id,a_id,note,summary,bi.region_id,bi.GatheringMan, bi.B_CustomName3
						from billidx bi
						  inner JOIN company C   ON bi.c_id=C.company_id
						where billtype in (150,151) 
						and billdate BETWEEN @BeginDate AND @Enddate 
						and billstates=0  
						and ((@szDept='') or (@szDept<>'' and department_id in (select [TYPE] from DecodeStr(@szDept))))            
						and c.child_number=0 and
					   ((@szCName ='') or ((c.name like @szCname or  c.pinyin like @szCname)))
					   and (@nregionId=0 or bi.region_id=@nRegionid)
					   
					) b ON sm.bill_id=b.billid
				 where sm.p_id>0 and sm.aoid in(0,5) 
				 and (@szProvider='' or sm.Supplier_id= cast(@szProvider as int))
				 and (@szbatchno='' or sm.batchno=@szbatchno)
				 and p.deleted<>1 and p.child_number=0 and 
				 (	
					 @szpname ='' or 
					 (	 @szpname <> '' and (p.name like @szPName) or (p.pinyin like @szPName) or (p.serial_number like @szpname)  
 						 or (p.Custompro1 like @szpname)  
						 or (p.Custompro2 like @szpname)  
						 or (p.Custompro3 like @szpname)  
						 or (p.Custompro4 like @szpname)  
						 or (p.Custompro5 like @szpname)  
					 )	
				 ) 
				and  (@szStandard ='' or (@szStandard <> '' and (p.[standard] like @szStandard))) 
				and	 (@szMakearea ='' or (@szMakearea <> '' and (p.makearea like @szMakearea))) 
				and  (@szMedtype ='' or (@szMedtype <> '' and (p.medtype in (select [TYPE] from DecodeStr(@szMedtype))) )) 
				and  (@szGspFlag ='' or (@szGspFlag <> '' and (p.gspflag  in (select [TYPE] from DecodeStr(@szGspFlag))))) 
				and  s.deleted=0 and s.child_number=0 
				and  (@szstock='' or (@szstock<>'' and s.storage_id  in (select [TYPE] from DecodeStr(@szstock))))
	         
			 )YPSM 
			 LEFT JOIN Clients   C  ON YPSM.c_id=C.Client_id
			 LEFT JOIN Clients  Sup ON Sup.client_id=YPSM.supplier_id
			 LEFT JOIN storages  S  ON S.storage_id=YPSM.ss_id
			 LEFT JOIN Employees RE ON RE.emp_id=YPSM.RowE_id
			 LEFT JOIN Employees IE ON IE.emp_id=YPSM.inputman
			 LEFT JOIN Employees AE ON AE.emp_id=YPSM.auditman
			 LEFT JOIN Employees GE ON GE.emp_id=YPSM.GatheringMan
			 LEFT JOIN Company   Y  ON Y.company_id=YPSM.Y_id
			 LEFT JOIN Company   YC  ON YC.company_id=YPSM.c_id
			 LEFT JOIN account   A  ON A.account_id=YPSM.a_id      
			 LEFT JOIN location  L  ON L.loc_id=YPSM.Location_id
			 LEFT JOIN Products vp  ON VP.product_id=YPSM.p_id
			 LEFT JOIN Unit     U   ON VP.[Unit1_ID]=U.[Unit_ID] 
			 left join basefactory f on f.CommID=YPSM.factoryid
			 left   join 
			 (
			  select P_id as baseinfo_id,c.name from ProductCategory pc
              LEFT JOIN customCategory c on PComent3 = c.class_id 
              where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
			 )m on vp.product_id = m.baseinfo_id
			 Left JOIn vw_productbalance vb ON YPSM.p_id=vb.p_id and YPSM.Y_ID=vb.Y_id 
			 left join region rg on rg.region_id=ypsm.region_id
		)P
		where  (@nYClassid='' or P.YClass_id like @nYClassid+'%')
		   and (@szInputman='' or P.InputmanClass_id like @szInputman+'%')
		   and (@szEname='' or p.ReClass_id like @szEname+'%')   
		order by p.p_id,p.billdate,p.billid
	  
	END 
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  return 0
end


if @nflag=2
begin
  if OBJECT_ID('tempdb..#storehouse') is not null
    drop table #storehouse
    
  select t.* into #storehouse
  from 
     (select S.*,isnull(Y.Class_id,'')YClass_id
      from  FilterStorehouse(@nloginEID) s
      Inner join Company   Y  ON Y.Company_id=S.Y_id
      Inner join storages ss ON s.s_id=ss.storage_id
      Inner join products p on s.p_id = p.product_id
      where 
          p.deleted<>1 and p.child_number=0 and 
         (@szpname ='' or (@szpname <> '' and (p.name like @szPName) or (p.pinyin like @szPName) or (p.serial_number like @szpname)  
          )) and
         (@szStandard ='' or (@szStandard <> '' and (p.[standard] like @szStandard)    
          )) and
         (@szMakearea ='' or (@szMakearea <> '' and (p.makearea like @szMakearea)    
          )) and  
         (@szMedtype ='' or (@szMedtype <> '' and (p.medtype in (select [TYPE] from DecodeStr(@szMedtype)))    
          )) and 
         (@szGspFlag ='' or (@szGspFlag <> '' and (p.gspflag  in (select [TYPE] from DecodeStr(@szGspFlag)))
          )) and
       ss.deleted=0 and ss.child_number=0 and
                (@szstock='' or (@szstock<>'' and ss.storage_id  in (select [TYPE] from DecodeStr(@szstock))))
      
     ) t
  where (@nYClassID='' or t.YClass_id like @nYClassID+'%')
         AND (@szProvider='' or t.Supplier_id= cast(@szProvider as int))  

  select p.* into #price
  from price p,(select p_id,max(lasttime)lasttime from price  Group by p_id)pr
  where  p.p_id=pr.p_id and p.lasttime=pr.lasttime and unittype=1


   select a.product_id as p_id,a.[name] as productname,a.Serial_Number as code,a.alias,a.standard,a.modal,
          ISNULL(a.Custompro1,'') as pc1,  ISNULL(a.Custompro2,'') as pc2, ISNULL(a.Custompro3,'') as pc3,
		  ISNULL(a.Custompro4,'') as pc4,  ISNULL(a.Custompro5,'') as pc5,
          isnull(pr.price1,0)price1,isnull(pr.price2,0)price2,isnull(pr.price3,0)price3,isnull(pr.glprice,0)glprice,
          isnull(pr.gpprice,0)gpprice,isnull(pr.recprice,0)recprice,isnull(pr.retailprice,0)retailprice,
        a.makearea,ISNULL(U1.[Name],'')unitname1,ISNULL(M.name,'')medtype,a.permitcode,
        a.[taxrate], 
        b.quantity,
        b.costtotal,
        b.costprice,
        b.batchno,
        b.validdate,
        b.makedate,
        b.locationname,
        b.suppliername,
        b.storagename,
        b.C_Name,
        b.e_name,
        b.scomment,
        b.pcomment as pcomment, 
        isnull(b.factory,'') as factory
    from (select s.p_id,
                 s.quantity, 
                 s.costtotal,
                 s.batchno,
                 s.validdate,
                 s.makedate,
                 ISNULL(vb.e_name,'')e_name,
                 isnull(vb.C_Name,'')C_Name,
                 isnull(L.[loc_name],'')locationname,
                 isnull(Sup.[name],'')suppliername,
                 isnull(SS.[name],'')storagename,
                 s.costprice,
                 s.scomment,s.factory as factory,p.comment as pcomment 
          from #storehouse s
             INNER JOIN  products p  on p.product_id=s.p_id
             LEFT JOIN   Location  L  on s.Location_id=L.Loc_id
             LEFT JOIN   Clients  sup on sup.Client_id=s.supplier_id
             LEFT JOIN   storages ss  on ss.storage_id=s.s_id
             Left JOIN  vw_productbalance vb ON s.p_id= vb.p_id and s.Y_id = vb.Y_id 
          where (@szbatchno='' or s.batchno=@szbatchno)
         )b
         left join products a  on  (a.product_id=b.p_id)
         left join #price    pr on  pr.p_id = a.product_id
         LEFT JOIN Unit     U1 ON  a.[Unit1_ID]=U1.[Unit_ID]
         left   join 
	     (
			select P_id as baseinfo_id,c.name from ProductCategory pc
            LEFT JOIN customCategory c on PComent3 = c.class_id 
            where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
	     )m on a.product_id = m.baseinfo_id
       where a.child_number=0 and a.deleted<>1 and a.product_id<>1
  order by a.product_id
   

  drop table #storehouse
  drop table #price
 
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  return 0
end
GO
