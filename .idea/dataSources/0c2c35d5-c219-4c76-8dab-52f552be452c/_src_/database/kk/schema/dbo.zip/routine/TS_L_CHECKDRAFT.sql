/**********检查销售出库单是否有价格异常的商品**********/
/***********add by luowei 2012-12-28***************/
/****说明：启用AllowSaveDraft开关时，*******/
/********销售出库单中location_id2 存放价格异常的标示*****/



CREATE  procedure TS_L_CHECKDRAFT
(
   @billid int
)
AS
BEGIN
  declare @nret int
	  set @nret = 0

  select top 1 @nret = mx.location_id2 from salemanagebilldrf mx 
    inner join billdraftidx idx on bill_id = billid
    left join products p on p.product_id = mx.p_id 
    where bill_id = @billid and billtype = 10 and mx.location_id2 <> 0
  
  if @nret is null set @nret = 0
  return @nret 
    
END
GO
