



CREATE  PROCEDURE [Ts_L_InsAccount]
 (@parent_id [varchar](30),
  @name [varchar](80),
  @alias  [varchar](30),
  @serial_number  [varchar](26),
  @Comment [varchar](256),
  @ini_total NUMERIC(25,8),
  @PinYin [varchar](80),
  @RowIndex [int] , /*Wsk add*/
  @szY_id         [int],
  @szYB   [int]
  )

AS 
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int],
  @lAccountid [int],
  @newA_id int
/*合法性检查*/
if exists(select * from Account where serial_number=@serial_number and deleted=0)
begin
 RAISERROR('编号重复！不能添加！！',16,1)
 return -2
end


/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Account')
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*BEGIN TRAN insertBaseAccount*/

/*--------只有一个科目为医保科目*/
if @szYB=1 
begin
  UPDATE [account] set [YBaccount] =0
end

INSERT INTO [account] 
  ( [class_id],
  [parent_id],
  [name],
  [alias],
  [serial_number],
  [Comment],
  [ini_total],
  [PinYin],
  [RowIndex], /*Wsk add*/
  [YBaccount] /*是否是医保科目  */
  ) 
 
VALUES 
 ( @Tempid,
  @parent_id,
  @name,
  @alias,
  @serial_number,
  @Comment,
  0,
  @PinYin,
  @RowIndex,
  @szYB
  )




if @@rowCount=0 
begin
/* rollback tran insertBaseAccount*/
 return -1
end else 
begin
 update Account set child_number=@child_number,child_count=@child_count
 where class_id =@Parent_id

  set @newA_id = @@IDENTITY
/* commit tran insertBaseAccount*/
 
end





IF exists(select * from accountbalance ac  where  ac.a_id=@newA_id and Y_id=@szY_id)
begin
   UPDATE [accountbalance] 
	SET  [ini_total] =@ini_total
        where [a_id]=@newA_id and Y_id=@szY_id
end  
else 
begin
      INSERT  [accountbalance](Y_id,a_id,cur_total,ini_total,total_01,total_02,total_03,total_04,
                            total_05,total_06,total_07,total_08,total_09,total_10,total_11,total_12,
                            bqtotal,sumtotal)
      VALUES(@szY_id,@newA_id,0,@ini_total,0,0,0,0,0,0,0,0,0,0,0,0,0,0) 
end

    return @newA_id
GO
