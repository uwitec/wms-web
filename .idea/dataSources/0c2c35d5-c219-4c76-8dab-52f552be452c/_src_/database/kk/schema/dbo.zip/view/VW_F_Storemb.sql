

CREATE VIEW dbo.VW_F_Storemb
AS
SELECT dbo.TranManagebill.*, ISNULL(storages_2.class_id, '') AS ssclass_id, 
      ISNULL(storages_1.class_id, '') AS sdclass_id, ISNULL(storages_2.name, '') 
      AS ssname, ISNULL(storages_1.name, '') AS sdname, ISNULL(u.name, '') 
      AS unitname, TranManagebill.Quantity*TranManagebill.CostPrice AS CostTotal,
      TranManagebill.RetailTotal AS RetailMoney
FROM dbo.TranManagebill LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.TranManagebill.sd_id = storages_1.storage_id LEFT OUTER JOIN
      dbo.storages storages_2 ON 
      dbo.TranManagebill.ss_id = storages_2.storage_id LEFT OUTER JOIN
      dbo.unit u ON dbo.TranManagebill.unitid = u.unit_id
GO
