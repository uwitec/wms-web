
CREATE proc ts_c_qrStoreAlertByName
(
 @s_id int,
 @begindate datetime,
 @enddate  datetime,
 @isNoPurchase    int=0,
 @isNoSend        int=0,
 @nY_ID			  int=0
)
as
/*Params Ini begin*/
if @isNoPurchase is null  SET @isNoPurchase = 0
if @isNoSend is null  SET @isNoSend = 0
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
set nocount on 

declare @daydiff int
set @daydiff=datediff(day,@begindate,@enddate)
if @daydiff=0 set @daydiff=1

declare @sqlsid varchar(50),@szsql varchar(8000)
declare @sqlNoPurchase varchar(100),@sqlNoSend varchar(100)

if @s_id<>0
Set @sqlsid=' and b.s_id= '+cast(@s_id as varchar(50))
else
SET @sqlsid=''

  
 IF @isNopurchase=0
 begin
   set @sqlNopurchase='+0'
 end
  else
 begin
   set @sqlNopurchase=' +isnull(bm.NopurchaseQTY,0)'
 end
 
  IF @isNosend=0
  begin
    set @sqlNosend='-0'
  end
  else
    set @sqlNosend=' -isnull(sm.NosendQTY,0)'

  SET @szsql='select * into #temp2 from (select p1.*, isnull(pb.c_name, '''') as c_name, isnull(pb.e_name, '''') as e_name, isnull(pb.supplier_id, 0) as supplier_id, 
              isnull(pb.emp_id, 0) as emp_id 
      from vw_Products p1 left join (select * from vw_productbalance where y_id = '+cast(@nY_id as varchar(10))+') pb on p1.product_id = pb.p_id) t where product_id in 
	 (select k.product_id from 
	    (select p.product_id,sum(st.lowlimit) as lowlimit from storelimit st
             left join products p on st.p_id=p.product_id 
             left  join  storelimit stl on st.slid=stl.slid
	     where st.upperlimit>stl.lowlimit and ('+cast(@nY_ID as varchar(50))+'=0 or st.Y_id ='+cast(@nY_ID as varchar(50))+')  and st.s_id=' +cast(@s_id as varchar(50))+
 	     ' group by p.product_id
             ) k
         
         left  join
	 (select p.product_id,isnull(sum(s.quantity),0) as quantity from storelimit l 
	    left join products p on l.p_id=p.product_id
	    left join storehouse s on l.p_id=s.p_id
	    where ('+cast(@nY_ID as varchar(50))+'=0 or s.Y_id ='+cast(@nY_ID as varchar(50))+') and l.s_id='+cast(@s_id as varchar(50))+' group by p.product_id) k1
	  on k.product_id=k1.product_id

	  where k.lowlimit>isnull(k1.quantity,0) 
	 ) and child_number=0 and deleted<>1
 
      select a.*,c.*,isnull(k.qty,0) as qty,isnull(d.buyorderqty,0) as buyorderqty,isnull(e.saleorderqty,0) as saleorderqty,
	isnull(f.daysaleqty,0)/'+cast(@daydiff as varchar(50))+ ' as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,--zh100913
	cast(0 as NUMERIC(25,8)) as alldaysaleqty,ISNULL(g.TraceCName, '''') AS TraceCName, ISNULL(g.TraceEName, '''') AS TraceEName		
	
      from storelimit a inner join #temp2 c on a.p_id=c.product_id
	 
        left join 
	 (select b.p_id,sum(isnull(b.quantity, 0)) as qty
	    from vw_c_storehouse b where ('+cast(@nY_ID as varchar(50))+'=0 or Y_id ='+cast(@nY_ID as varchar(50))+')'+@sqlsid+' group by b.p_id) k 
	  on a.p_id=k.p_id
	
--采购订货数量
	left join 
	 (select isnull(sum(b.quantity-b.comeqty),0) buyorderqty,p_id 
	    from orderidx a,orderbill b where a.billstates=3 and a.billid=b.bill_id and a.billtype=22
	  group by p_id) as d on d.p_id=a.p_id 
	
--销售订货数量
	left join 
	 (select isnull(sum(b.quantity-b.comeqty),0) saleorderqty,p_id 
	    from orderidx a,orderbill b where a.billstates=3 and a.billid=b.bill_id and a.billtype=14
	  group by p_id) as e on e.p_id=a.p_id 
	
--日均销量
	left join
	  (select isnull(sum(-p.quantity),0) daySaleQty,p_id
	     from billidx b,vw_c_pdetail p
	     where b.billid=p.billid and b.billtype in (10,11,12,13) and b.billstates=0 and
             b.billdate between '''+cast(@begindate as varchar(50))+''' and '''+cast(@enddate as varchar(50))+''' group by p_id
	    ) as f on f.p_id=a.p_id
--未到货数量  
        left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from vw_c_buymb
         where  bill_id In (select billid from billidx where billtype=220 and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
--未发货数量  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from vw_c_salemb
         where bill_id IN (select billid from billidx where billtype=210 and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id 
 --最近采购人、最近供货商
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@nY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id 	
 	
	 where  a.lowlimit>isnull(k.qty,0)'+@sqlNopurchase+@sqlNosend+' and a.s_id='+cast(@s_id as varchar(50))+' 
	 drop table #temp2 '

  /*PRINT (@szsql)*/
  EXEC(@szsql)
GO
