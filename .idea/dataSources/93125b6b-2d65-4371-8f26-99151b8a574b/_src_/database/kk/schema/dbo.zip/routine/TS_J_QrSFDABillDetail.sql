
create procedure TS_J_QrSFDABillDetail
 @nMode      int,  /*0 读取表头信息， 1读取监管码列表信息*/
 @nBillid  int
as
begin   
  if @nMode =0
  begin
    declare @EntType varchar(2), @SFDAEntNO varchar(60), @sfdaEntName varchar(100)
    select top 1 @EntType = sysvalue from sysconfig where [sysname] = 'sfdaEntType'
    select top 1 @SFDAEntNO = sysvalue from sysconfig where [sysname] = 'SFDAEntNO'
    select top 1 @sfdaEntName = sysvalue from sysconfig where [sysname] = 'sfdaEntName'
    if @EntType is null set @EntType = ''
    if @SFDAEntNO is null set @SFDAEntNO = ''
    if @sfdaEntName is null set @sfdaEntName = ''
    
    IF @EntType = '4'
    BEGIN
    	/*零售*/
    	SELECT bi.billnumber AS billid, ISNULL(e1.name, '') AS OperIcName,
    		    CASE WHEN bi.billtype IN (20) THEN '102102'                 /*102 零售采购入库*/
    		         WHEN bi.billtype IN (160, 162) THEN '107107'           /*107 零售分店供应入库*/
    			  	 WHEN bi.billtype IN (41) THEN '205205'                 /*205 零售企业销毁出库单*/
    			   	 WHEN bi.billtype IN (13) THEN '103F'                   /*103 零售个人退货入库*/
    	             WHEN bi.billtype IN (11, 151, 153) THEN '103Z'         /*103 零售机构退货入库*/
    				 WHEN bi.billtype IN (12) THEN '321321'                 /*321 零售出库*/
					 WHEN bi.billtype IN (21, 161, 163) THEN '202202'       /*202 零售退货出库*/
					 WHEN bi.billtype IN (10, 150, 152) THEN '209209'       /*209 零售总店供应出库*/
				END AS DataType,		
				@EntType AS entType, 0 AS DrugType, CONVERT(VARCHAR(20), bi.auditdate, 20) AS billInOutDate,		
				CASE WHEN bi.billtype in(20, 13, 11) THEN ISNULL(c1.name, '')
					 WHEN bi.billtype in(151, 153, 160, 162) THEN ISNULL(Y1.name, '')           
					 WHEN bi.billtype in(21, 41, 10, 150, 152, 12) THEN @sfdaEntName 	
				END AS EntSeqNoSend,
				ISNULL(CASE WHEN bi.billtype in(20, 13, 11, 151, 153) THEN @sfdaEntName
				            WHEN bi.billtype in(21, 41, 10,12) THEN ISNULL(c1.name, '')
				            WHEN bi.billtype in(150, 152) THEN ISNULL(Y1.name, '')           
			           END, '') AS EntSeqNoRecv,	  
			    CASE WHEN bi.billtype in(20, 13, 11, 12) THEN ISNULL(c1.partnerSeqNo, '')
				     WHEN bi.billtype in(151, 153, 160, 162) THEN ISNULL(Y1.partnerSeqNo, '')           
				     WHEN bi.billtype in(21, 41, 10, 150, 152) THEN @SFDAEntNO
			    END AS partnerIdSend,	  
			    ISNULL(CASE WHEN bi.billtype in(20, 11, 151, 153) THEN @SFDAEntNO
				            WHEN bi.billtype in(21, 41, 10) THEN ISNULL(c1.partnerSeqNo, '')
				 		    WHEN bi.billtype in(12, 13) THEN ''
				            WHEN bi.billtype in(150, 152) THEN ISNULL(Y1.partnerSeqNo, '')           
			           END, '') AS partnerIdRecv,	 
			    '1' AS CustomerIDType,	           
			    ISNULL(gsp.IDNumber, '') AS CustomerID,	           	   		 
			    '' AS ReturnCase,	     	  
			    '' AS DestoryCase,      
			    '' AS DestructionExecutor,  
			    '' AS DestrExecutorCID,   
			    '' AS DestructionSupervisor,  	   
			    '4' AS destorytype,                        
			    '6' AS returntype                        		   		
			FROM billidx bi 
				LEFT JOIN employees e1 on bi.e_id = e1.emp_id
				LEFT JOIN clients c1 on bi.c_id= c1.client_id
				LEFT JOIN company y1 on bi.c_id = y1.company_id
				LEFT JOIN GSPCompy gsp on bi.billid = gsp.Gspbill_id
		WHERE bi.billid = @nBillid
    END
    ELSE           
    BEGIN
		select bi.billnumber as billid, ISNULL(e1.name, '')  as OperIcName,
			   Case when bi.billtype in (20) then '102'     /*采购入库：102*/
					when bi.billtype in (13, 11, 151, 153) then '103'		 /*退货入库：103*/
					when bi.billtype in (21) then '202'		 /*退货出库：202 	*/
					when bi.billtype in (41) then '205'     /*销毁出库：205*/
					when bi.billtype in (10, 150, 152) then '209'		 /*供应出库：209*/
					WHEN BI.billtype in (12) then '321'      /*零售出库：321*/
				end as DataType, 
			   @EntType as enttype,  0 as DrugType,  CONVERT(varchar(20), bi.auditdate, 20) as billInOutDate,           
			   case  when bi.billtype in(20, 13, 11) then isnull(c1.name, '')
				 when bi.billtype in(151, 153) then isnull(Y1.name, '')           
				 when bi.billtype in(21, 41, 10, 150, 152, 12) then @sfdaEntName
			   end AS EntSeqNoSend,	  /*发货单位名称	String 	否*/
			   isnull(case  when bi.billtype in(20, 13, 11, 151, 153) then @sfdaEntName
				 when bi.billtype in(21, 41, 10,12) then isnull(c1.name, '')
				 when bi.billtype in(150, 152) then isnull(Y1.name, '')           
			   end, '') AS EntSeqNoRecv,	  /*收货单位名称	String 	否*/
			   case  when bi.billtype in(20, 13, 11, 12) then isnull(c1.partnerSeqNo, '')
				 when bi.billtype in(151, 153) then isnull(Y1.partnerSeqNo, '')           
				 when bi.billtype in(21, 41, 10, 150, 152) then @SFDAEntNO
			   end AS partnerIdSend,	  /*发货单位编号	String 	否*/
			   isnull(case  when bi.billtype in(20, 11, 151, 153) then @SFDAEntNO
				 when bi.billtype in(21, 41, 10) then isnull(c1.partnerSeqNo, '')
				 when bi.billtype in(12, 13) then ''
				 when bi.billtype in(150, 152) then isnull(Y1.partnerSeqNo, '')           
			   end, '') AS partnerIdRecv,	  /*收货单位编号	String 	否*/
			   '1' as CustomerIDType,	  /*证件类型	String	否/是           */
			   isnull(gsp.IDNumber, '') as CustomerID,	              /*证件号	String	否/是		   		 */
			   '' as ReturnCase,	     /*退货原因	String	否/是		  */
			   '' as DestoryCase,     /*销毁原因	String	否/是*/
			   '' as DestructionExecutor,  /*销毁执行人	String	否/是*/
			   '' as DestrExecutorCID,   /*销毁执行人证件号	String	否/是*/
			   '' as DestructionSupervisor,  /*销毁监督人	String	否/是 		   */
			   '4'  as destorytype,                        
			   '6' as returntype   /*退货类型                        		   		                       */
		  from billidx bi 
		  left join employees e1 on bi.e_id = e1.emp_id
		  left join clients c1 on bi.c_id= c1.client_id
		  left join company y1 on bi.c_id = y1.company_id
		  left join GSPCompy gsp on bi.billid = gsp.Gspbill_id
		  where bi.billid = @nBillid	
    END
  end
  else if @nMode =1 
  begin  
    select distinct sd.sfda_code as DataCode, p.commodityCode  as ProductCode 
      from Sfda_Detail sd 
      inner join Sfda_List sl on sd.sfda_code = sl.sfda_code
      left join products p on sl.P_Id = p.product_id
      where sd.billid = @nBillid
  end
   									        						  
end
GO
