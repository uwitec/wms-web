





CREATE	VIEW dbo.vw_c_salembdrf
AS
SELECT dbo.salemanagebilldrf.*, 
ISNULL(P.[Name]  ,'') AS [PName],         
ISNULL(P.[Class_ID]  ,'') AS [PClass_ID],
isnull(storages_2.class_id,'') AS ssclass_id, 
isnull(storages_1.class_id,'') AS sdclass_id, 
isnull(storages_2.name,'') AS ssname, 
isnull(storages_1.name,'') AS sdname,
isnull(u.name,'') as unitname,
isnull(l.loc_name,'') as locname,
isnull(c.[name],'') as suppliername,
isnull(E.class_id,'') as REclass_ID,
isnull(E.[name],'') as REname
FROM dbo.salemanagebilldrf
    LEFT JOIN Products P  ON salemanagebilldrf.[P_ID]=P.[Product_ID] 
    LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.salemanagebilldrf.sd_id = storages_1.storage_id 
      LEFT OUTER JOIN
      dbo.storages storages_2 ON dbo.salemanagebilldrf.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON dbo.salemanagebilldrf.unitid = u.unit_id
      LEFT OUTER JOIN
      location l on dbo.salemanagebilldrf.location_id=l.loc_id
      LEFT OUTER JOIN
      clients c on dbo.salemanagebilldrf.supplier_id=c.client_id
      LEFT OUTER JOIN
      employees E ON salemanagebilldrf.RowE_id=E.emp_id
where dbo.salemanagebilldrf.aoid in(0,5)
GO
