

CREATE PROCEDURE ts_M_InsAccountComment 
(
  @Accountcomment varchar(100),
  @ClassFlag int
)
AS
/*处理单据自定义属性 -1:自定义属性1; -2:自定义属性2; -3:自定义属性3*/

if (@Accountcomment='') return 0
if (@ClassFlag>=0) return 0

if NOT EXISTS(select * from AccountComment where ClassFlag=@ClassFlag  
	and AccountComment=@Accountcomment)
BEGIN
    INSERT INTO [AccountComment](AccountComment,Code,ClassFlag,pinyin)
    VALUES(@Accountcomment,'',@ClassFlag,'')
END
GO
