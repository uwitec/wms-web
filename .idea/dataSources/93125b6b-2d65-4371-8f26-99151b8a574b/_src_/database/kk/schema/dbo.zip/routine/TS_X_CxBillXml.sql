

/* xxx: 2016-01-20*/

CREATE PROCEDURE [dbo].[TS_X_CxBillXml] 
	@Act	    int = 0,             /* 操作：0 添加/编辑 1 审核/反审核/删除/终止  3 查询*/
	@billid     int = 0,                 /* 单据ID*/
	@Yidstr     varchar(200) = '',   /* 机构id串*/
	@yType      int = 0,             /* 机构选择类型 0,表示类别 1,表示机构id*/
	@auditman   int = 0,             /* 审核人*/
	@inputman   int = 0,             /* 录入人*/
	@billstate  int = 0,             /* 单据状态*/
	@billdate   datetime = 0,        /* 录入日期*/
	@auditdate  datetime = 0,        /* 审核日期*/
	@begindate  datetime = 0,        /* 开始日期*/
	@enddate    datetime = 0,        /* 结束日期*/
	@billtype   int = 0,			 /* 单据类型*/
	@xmlStr     xml = '',
	@Comment    varchar(1000) = '',   /* 备注*/
	@billidStr  varchar(200) = '0',   /* 多选时候单据id串*/
	@CxName     varchar(500) = '',    /*方案名称*/
	@nRET     int output	
	
AS
BEGIN
	/*Params Ini begin*/
	if @Act is null  SET @Act = 0
	if @billid is null  SET @billid = 0
	if @Yidstr is null  SET @Yidstr = ''
	if @yType is null  SET @yType = 0
	if @auditman is null  SET @auditman = 0
	if @inputman is null  SET @inputman = 0
	if @billstate is null  SET @billstate = 0
	if @billdate is null  SET @billdate = 0
	if @auditdate is null  SET @auditdate = 0
	if @begindate is null  SET @begindate = 0
	if @enddate is null  SET @enddate = 0
	if @billtype is null  SET @billtype = 12
	if @billdate is null  SET @billdate = 0
	if @comment is null  SET @comment = ''
	if @billidStr is null set @billidStr = '0'

	/*Params Ini end*/

	SET NOCOUNT ON;
	
	SET @nRET = -1
	
	if @Act = 0
	begin
		if @billid = 0
		begin
			insert into CxXml(
					Yidstr,   /* 机构id串*/
					yType  ,             /* 机构选择类型*/
					auditman ,             /* 审核人*/
					inputman ,             /* 录入人*/
					billstate ,             /* 单据状态*/
					billdate  ,        /* 录入日期*/
					auditdate ,        /* 审核日期*/
					begindate  ,        /* 开始日期*/
					enddate ,        /* 结束日期*/
					billtype ,			 /* 单据类型*/
					xmlStr ,
					name,			/*方案名称*/
					comment    /* 备注*/
			) values(
					@Yidstr ,   /* 机构id串*/
					@yType  ,             /* 机构选择类型*/
					@auditman ,             /* 审核人*/
					@inputman ,             /* 录入人*/
					@billstate ,             /* 单据状态*/
					@billdate ,        /* 录入日期*/
					@auditdate ,        /* 审核日期*/
					@begindate ,        /* 开始日期*/
					@enddate ,        /* 结束日期*/
					@billtype ,			 /* 单据类型*/
					@xmlStr  ,
					@CxName,     /*方案名称*/
					@comment    /* 备注*/
			)
			SET @nRET = @@IDENTITY
		end
		else
		begin
			update CxXml set        
					Yidstr=@Yidstr,  
					yType=@yType ,         
					auditman=@auditman,         
					inputman=@inputman,         
					billstate=@billstate,          
					/*billdate=@billdate,       */
					auditdate=@auditdate,       
					begindate=@begindate,       
					enddate=@enddate,       
					billtype=@billtype,			
					xmlStr=@xmlStr,
					name = @CxName,
					comment=@comment  
			where billid = @billid
		
		  if @billdate > 0
		    update CxXml set billdate=@billdate where billid = @billid   
			
			SET @nRET =@billid
		end
		/*delete from CxBillNew where billid = @billid   --这儿删除最新的促销表中对应单据的明细*/
	end
	else
	if @act = 1
	begin
		/* 物理删除*/
		if @billstate = 1
		begin
			delete from CxXml where billid in (select szTYPE from DecodeToStr(@billidStr))    /*= @billid*/
			set @nRET = 1
			return
		end
		if @billstate in (2, 5)
		begin
			set @auditman = 0
			set @auditdate = 0
		end
		else
		if @billstate in (3)
		begin
			set @auditdate = getdate()
		end
		update CxXml set 
			[auditman] = @auditman,
			[billstate] = @billstate,
			[auditdate] = @auditdate
		where billid in (select szTYPE from DecodeToStr(@billidStr))		
		SET @nRET =1
	end
	else if @act = 3 
	begin
      select billId, isnull(Yidstr,'0') as sYID, cx.yType, inputman, billdate, auditman, auditdate, billState, 
			BeginDate, EndDate, BeginTime, EndTime, billtype, xmlStr,cx.name as cxname, cx.Comment, cx.ModifyDate,
      		case when cx.Yidstr = '' then '所有机构'  when cx.Yidstr = '0' then '所有机构' 
      		when cx.Ytype = 1 then ISNULL(dbo.MergeCompany(0,cx.Yidstr,0),'')
      		when cx.Ytype = 0 then ISNULL(dbo.MergeCompany(1,cx.Yidstr,0),'') else '' end as szCompany,
      		isnull(E1.name,'') as inputmanname,isnull(E2.name,'') as auditmanname,
			 dbo.FN_GetVchStatesText(cx.billState, 0) AS billstatesname from CxXml cx
          LEFT JOIN Employees E1 ON cx.inputman = E1.emp_id
          LEFT JOIN Employees E2 ON cx.auditman = E2.emp_id
          LEFT JOIN company c ON cx.auditman = c.company_id
        where ((cx.begindate <= @enddate AND cx.enddate >= @begindate) or (@billid > 0 and billId = @billid) )
              AND ((@Yidstr = '') or (@Yidstr = '0') 
					or (cx.Yidstr = '') or (cx.Yidstr = '0') 
					or ((cx.Ytype = 1) and (charindex(','+@Yidstr+',',','+cx.Yidstr+',') > 0))
					or ((cx.Ytype = 0) and (dbo.MergeCompany(2,cx.Yidstr,CAST(@Yidstr as int)) = '1')))
	  return @nRET
	end
	
	return @nRET
END
GO
