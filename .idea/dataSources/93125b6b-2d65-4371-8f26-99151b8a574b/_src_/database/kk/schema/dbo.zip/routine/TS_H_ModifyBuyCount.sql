
/* =============================================*/
/* Author:  Huang.Y*/
/* Create date: 2011-4-13*/
/* Description: 更改商品采购次数*/
/* =============================================*/
CREATE PROCEDURE TS_H_ModifyBuyCount 
 @billid  int
AS
BEGIN
 SET NOCOUNT ON;

 declare @nBillType int
 declare @nCount int
 select @nBillType = billtype, @nCount = case billstates when '0' then 1 when '1' then -1 else 0 end from billidx where billid = @billid
 
 if @nBillType in(20, 220)
 begin
  update products set buycount = buycount + @nCount where product_id in (SELECT     b.p_id
   FROM         dbo.billidx AS i INNER JOIN
                      dbo.buymanagebill AS b ON i.billid = b.bill_id
   WHERE     (i.billtype IN (20, 220)) AND (i.billid = @billid) AND (b.p_id > 0))
 end
 else
 if @nBillType in(21, 221)
 begin
  update products set buycount = buycount - @nCount where product_id in (SELECT     b.p_id
   FROM         dbo.billidx AS i INNER JOIN
                      dbo.buymanagebill AS b ON i.billid = b.bill_id
   WHERE     (i.billtype IN (21, 221) AND b.orgbillid > 0) AND (i.billid = @billid) AND (b.p_id > 0))
 end
END
GO
