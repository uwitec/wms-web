
/******************************************
XXX. 2016-11-16
商品取 productdetail 表中的最近五个批次

********************************************/
CREATE  PROCEDURE  TS_X_ProductBatchByproductdetail
( @nP_id      	INT,
  @nS_id      	INT = 0,
  @nY_id      	INT = 0
)   
/*with encryptiON      */
AS
/*Params Ini begin*/
if @nP_id is null  SET @nP_id = 0
if @nS_id is null  SET @nS_id = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

SET NOCOUNT ON


    SELECT top 5 s.pd_id AS batchid,abs(s.quantity) quantity, abs(s.quantity) as salequantity,abs(s.costtotal) costtotal,
	s.costprice,s.batchno,s.makedate,s.validdate,0 as commissionflag,0  AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
	ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
	CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
	isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
	,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
	, s.batchprice, '' as scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
	isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,abs(isnull(s.costtaxtotal,0)) as costtaxtotal,
	isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
	FROM ( select MAX(pd_id) pd_id , PD.p_id , PD.batchno, PD.supplier_id, PD.location_id, PD.validdate, PD.makedate,
					PD.costprice, PD.instoretime,PD.Y_ID, PD.batchprice,PD.BatchBarCode,
					PD.s_id, PD.costtaxprice, PD.factoryid,PD.taxrate,
					ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory,
					SUM(pd.quantity) as quantity,SUM(pd.costtotal)as costtotal ,SUM(pd.costtaxtotal) as costtaxtotal
					from productdetail  pd
				LEFT JOIN Company Y ON pd.Y_id=Y.Company_id    
				left join basefactory r on pd.factoryid=r.CommID  
			GROUP BY  PD.p_id , PD.batchno, PD.supplier_id, PD.location_id, PD.validdate, PD.makedate,
					PD.costprice, PD.instoretime,PD.Y_ID,  PD.batchprice,PD.BatchBarCode,
					PD.s_id, PD.costtaxprice, PD.factoryid,PD.taxrate,Y.Class_id ,y.name,r.AccountComment
	)s 
	LEFT JOIN  clients c ON s.supplier_id=c.client_id
	LEFT JOIN locatiON l ON s.location_id=l.loc_id
	/*LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
	ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
	AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
	AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid */
	LEFT JOIN  products p ON s.P_ID=p.product_ID
	LEFT JOIN ForbiddenBatch FB 
	ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
	LEFT JOIN storages ss on s.s_id=ss.storage_id
	left JOin  customCategory cu ON p.TaxRate = cu.id
	WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)  /*and (ss.qualityFlag=0)*/
			and ss.WholeFlag<>3
			and (ss.Y_ID=@nY_id or @nY_id = 0)
	ORDER BY s.pd_id DESC
GO
