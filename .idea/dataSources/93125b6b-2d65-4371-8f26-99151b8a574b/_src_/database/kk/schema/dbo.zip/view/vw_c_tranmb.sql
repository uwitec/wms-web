
CREATE VIEW dbo.vw_c_tranmb
AS
SELECT dbo.TranManagebill.*, ISNULL(storages_2.class_id, '') AS ssclass_id, 
      ISNULL(storages_1.class_id, '') AS sdclass_id, ISNULL(storages_2.name, '') 
      AS ssname, ISNULL(storages_1.name, '') AS sdname, ISNULL(u.name, '') 
      AS unitname, ISNULL(p.name, '') AS Pname, ISNULL(p.class_id, '') AS PClass_ID, 
      ISNULL(dbo.clients.name, '') AS suppliername,
      isnull(l.loc_name,'') as locname,
      isnull(E.class_id,'') as REclass_ID,
      isnull(E.[name],'') as REname
FROM dbo.TranManagebill LEFT OUTER JOIN
      dbo.clients ON 
      dbo.TranManagebill.supplier_id = dbo.clients.client_id LEFT OUTER JOIN
      dbo.products p ON dbo.TranManagebill.p_id = p.product_id LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.TranManagebill.sd_id = storages_1.storage_id LEFT OUTER JOIN
      dbo.storages storages_2 ON 
      dbo.TranManagebill.ss_id = storages_2.storage_id LEFT OUTER JOIN
      dbo.unit u ON dbo.TranManagebill.unitid = u.unit_id       LEFT OUTER JOIN
      location l on dbo.TranManagebill.location_id=l.loc_id  LEFT OUTER JOIN
      employees E ON TranManagebill.RowE_id=E.emp_id
WHERE (dbo.TranManagebill.AOID = 0)
GO
