








CREATE	procedure Ts_Comm
as
set nocount on
declare
  @vtSale int, /* 2;*/
  @vtSaleBack int, /* 4;*/
  @vtBuy   int,/* 6;*/
  @vtBuyBack   int,/* 8;*/
  @vtRetail   int,/* 10;*/
  @vtRetailBack   int,/* 12;*/
  @vtBuyOrder	int,/* 14;*/
  @vtSaleOrder	 int,/* 16;*/

   @vtGathering   int,/* 20;*/
   @vtPayment	int,/* 22;*/
   @vtAccount	int,/* 24;*/

   @vtLend   int,/* 30;*/
   @vtLendBack	 int,/* 32;*/
   @vtLendSale	 int,/*= 34;*/

   @vtBorrow   int,/*= 40;*/
   @vtBorrowBack   int,/*= 42;*/
   @vtBorrowBuy   int,/*= 44;*/

   @vtProduce	int,/*= 50;*/
   @vtLost   int,/*= 52;*/
   @vtOverflow	 int,/*= 54;*/
   @vtAdjustPrice   int,/*= 56;*/
   @vtTransfer	 int,/*= 58;*/
   @vtTransfer_Price   int,/* = 60;*/

   @vtCashExpense   int,/*= 70;*/
   @vtExpense	int,/*= 72;*/
   @vtOtherIncome   int,/*= 74;*/
   @vtMoney   int,/*= 76;*/

   @vtGive   int,/*= 80;*/
   @vtGain   int,/*= 82;*/

   @vtAR_Add   int,/*= 86;*/
   @vtAR_Reduce   int,/*= 88;*/

   @vtAP_Add   int,/*= 90;*/
   @vtAP_Reduce   int,/*= 92;*/

   @vtCash_Add	 int,/*= 96;*/
   @vtCash_Reduce   int,/*= 98;*/

   @vtFixedBuy	 int,/*= 100;*/
   @vtFixedSale   int,/*= 102;*/
   @vtFixedDepreciation   int,/*= 104;*/

   @vtExpenseHappen   int,/*= 110;*/
   @vtExpenseAmortize	int,/*= 112;*/

   @vtSendGoods   int,/*= 120;*/
   @vtSendBack	 int,/*= 122;*/
   @vtSendSettle   int,/*= 124;*/
   @vtSendPrice   int,/*= 126;*/

   @vtCommission   int,/*= 130;*/
   @vtCommBack	 int,/*= 132;*/
   @vtCommSettle   int,/*= 134;*/
   @vtCommPrice   int,/*= 136;*/

   @vtReCommission   int,/*= 140;*/
   @vtReCommBack   int,/*= 142;*/
   @vtReCommSettle   int,/*= 144;*/
   @vtReCommPrice   int,/*= 146;*/

   @vtCommRecive   int,/*= 150;*/
   @vtCommPayment   int/*= 152;*/


	declare @Asset_Id int,		/*2	【资产合计】*/
		@Products_Id int,	/*3	『库存商品总值合计』*/
		@FixedAsset_id int,	/*4	『固定资产合计』*/
		@FixedAsset1_id int,	/*5	 固定资产__甲*/
		@Cash_id int,		/*6	 现    金*/
					/*7	『全部银行存款合计』*/
					/*8	银行户头_1*/
		@Artotal_Id int,		/*9	『应收款合计』*/
		@Lendout_Id int ,	/*10	『借出商品』*/
		@Dt_Expens_Id int,	/* 11	待摊费用*/
		@Wt_Comm_Id int,		/*12	委托代销商品*/
		@St_Comm_Id int,		/*13	受托代销商品*/
					/*14	【负债合计】*/
		@Aptotal_Id int,		/*15	『应付帐款合计』*/
		@Brrowin_Id int,		/*16	『借入商品』*/
		@Dxtotal_Id int,		/*17	代销商品款*/
					/*18	应交税金*/
					/*19	【收入类】*/
		@SaleIncome_Id int	/*20	『销售收入』*/
					/*21	『商品类收入』*/
/*		Product_22	商品报溢收入
		
		23	商品获赠收入
		24	成本调价收入
		25	进货退货差价
		26	变价调拨差价
		27	商品拆装差价
		28	借转进货结算与成本差
		29	受托代销结算差价
		30	『其它收入』
		31	调帐收入
		32	利息收入
		33	其它....
		34	【支出类】
		35	『销售成本』
		36	『商品类支出』
		37	商品报损
		38	商品赠出
		39	『费用合计』
		40	调帐亏损
		41	固定资产折旧
		42	其它....
		43	【所有者权益】
		44	实收资本
		45	资本公积
		46	盈余公积
		47	本年利润
		48	利润分配
		49	【利润】
		54	进项税
		55	销项税
*/

	select	@Asset_Id=2		/*	【资产合计】*/
	select	@Products_Id=3		/*	『库存商品总值合计』*/
	select	@FixedAsset_id=4	/*	『固定资产合计』*/
	select	@Cash_id=6		/*	 现    金*/
					/*7	『全部银行存款合计』*/
					/*8	银行户头_1*/
	select	@Artotal_Id=9		/*9	『应收款合计』*/
	select	@Lendout_Id=10		/*10	『借出商品』*/
	select	@Dt_Expens_Id=11	/* 11	待摊费用*/
	select	@Wt_Comm_Id=12		/*12	委托代销商品*/
	select	@St_Comm_Id=13		/*13	受托代销商品*/
					/*14	【负债合计】*/
	select	@Aptotal_Id=15		/*15	『应付帐款合计』*/
	select	@Brrowin_Id=16		/*16	『借入商品』*/
	select	@Dxtotal_Id=17		/*17	代销商品款*/
					/*18	应交税金*/
					/*19	【收入类】*/
	select	@SaleIncome_Id=20	/*20	『销售收入』*/
GO
