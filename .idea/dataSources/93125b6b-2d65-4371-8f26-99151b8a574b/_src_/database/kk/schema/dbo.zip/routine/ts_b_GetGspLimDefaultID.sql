


CREATE PROCEDURE ts_b_GetGspLimDefaultID
(
@nGspLim int,
@nRet int out
)
/*with encryption*/
 AS
SET @nRet = 0
SELECT @nRet = e_id FROM gspaudit WHERE GSP_AuditLimit = @nGspLim
GO
