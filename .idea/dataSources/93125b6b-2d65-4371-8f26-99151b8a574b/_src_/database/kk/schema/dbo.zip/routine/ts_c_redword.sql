
create   procedure ts_c_redword
(
	@nBillId numeric(10,0),
	@nReturnNumber int output,
	@calcFlag int = 0
)
/*with encryption*/
as

if not exists(select * from billidx where billid = @nBillId and transflag = 0)
begin
	set @nReturnNumber = -400
	return 0
end

/*Params Ini begin*/
if @calcFlag is null  SET @calcFlag = 0
/*Params Ini end*/
/*set nocount on*/
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 

	/*变量定义*/
declare @nBillType smallint,@nP_Id int,@tBillDate datetime,@szDate varchar(10),@cBillstates char(1)
declare @nNewBillId int,@szBillGuid varchar(50),@szPname varchar(200), @szNewBillGuid varchar(50)
declare @szRAISERROR varchar(500)
declare @VipCardid int, @y_id int, @DY_id int, @OrderBillid int
set @szBillGuid=''
select @nBilltype=billtype,@tBillDate=billdate,@cBillstates=billstates,@szBillGuid=GUID, @y_id =y_id, @DY_id = c_id from billidx where billid=@nBillId
select @szNewBillGuid = newid()

declare @Intergral NUMERIC(25,8)
declare @saleIntegral NUMERIC(25,8)
declare @money NUMERIC(25,8)
declare @salemoney NUMERIC(25,8)
declare @INTEGRALMONEY NUMERIC(25,8) 
declare @PriceType int
declare @posdatamode varchar(2)
                                                              
declare @isbank int,@isIntergral int,@isSpecialPriceIntegral int,@isPromotionIntegral int,@isYeIntegral int
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
declare @saleIntegralYE NUMERIC(25,8)
declare @ctid int
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @RemainderMoney NUMERIC(25,8)
declare @NewReadId int
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8), @isZBZT int, @nSourceIntegral int, @nSourceIntegralYE NUMERIC(25,8)
/*变量定义end*/


if @cBillstates='1' or @cBillstates='4' 
begin
	set @nReturnNumber=-101
	return
end


/*非本期单据不允许红冲*/
DECLARE @nPeriod INT
IF EXISTS(SELECT 1 FROM sysconfig WHERE [sysname] = 'AccountPeriod' AND y_id = @y_id)
    SELECT @nPeriod = CAST(sysvalue as int) from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id
ELSE 
	SET @nPeriod = 1

IF NOT EXISTS(SELECT 1 FROM billidx WHERE billid = @nBillId AND period = @nPeriod)
BEGIN
	SET @nReturnNumber = -2
	SET @szRAISERROR='此单据非本期单据，不能红冲！'
	RAISERROR (@szRAISERROR, 16, 1)
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	RETURN
END

/* 机构发货类单据检测是否存在已审核机构入库验收单*/
IF @nBillType IN(150, 152)
BEGIN
	IF EXISTS(SELECT * FROM GSPbillidx WHERE billtype = 523 AND Ybillid = @nBillId AND BillStates > 10)
	BEGIN
		set @nReturnNumber=-100
		set @szRAISERROR='对方已收货，不能做红字反冲！'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	END
	ELSE
		/* 删除未审核验收单*/
		DELETE FROM GSPbillidx WHERE BillType = 523 AND Ybillid = @nBillId
END

/* 机构收货退货类单据检测是否存在已审核机构退货验收单*/
IF @nBillType IN(161, 163)
BEGIN
	IF EXISTS(SELECT * FROM GSPbillidx WHERE billtype = 524 AND Ybillid = @nBillId AND BillStates > 10)
	BEGIN
		set @nReturnNumber=-100
		set @szRAISERROR='对方已收货，不能做红字反冲！'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	END
	ELSE
		/* 删除未审核验收单*/
		DELETE FROM GSPbillidx WHERE BillType = 524 AND Ybillid = @nBillId
END
if exists (select 1 from jsbdetail where xsd_bid=@nBillId and flag=0) or exists (select 1 from jspdetail where xsd_bid=@nBillId and flag=0)
begin
		set @nReturnNumber=-310
		set @szRAISERROR='本张单据已结算，不能做红字反冲！'+char(10)+'请先红冲相应的结算单据!'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return

end

set @posdatamode=0
select @posdatamode=sysvalue from sysconfig where sysname='PosDataMode' and Y_ID=0


if exists(select * from sysconfig  where [sysname] = 'YClassid' and [sysvalue] = '000001' and Y_ID = 0)
  set @isZBZT = 1
else 
  set @isZBZT = 0
  
/*
  为什么不能红冲？
if @nBilltype in (184,185)
begin
		set @nReturnNumber=-184
		set @szRAISERROR='不能红冲【返利单】和【获利单】'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
end
*/
if @nbilltype in (12,13,148,149)
begin
      select @ctid=v.ct_id,@money=v.RemainderMoney,@Vipcardid=v.Vipcardid,@isbank=v.isbank,
             @isSpecialPriceIntegral=isSpecialPriceIntegral,@isPromotionIntegral=isPromotionIntegral,@isYeIntegral=isYeIntegral,
             /*特殊商品参与积分                              特价商品是否累加未兑换积分金额                           是否统计积分余额*/
             @order=b.billnumber,@isIntergral=V.isIntegral,@INTEGRALMONEY=v.INTEGRALMONEY,@Intergral=v.Integral,
             @nSourceIntegral = b.integral, @nSourceIntegralYE = b.integralye
             /*,@saleIntegral=cast(isnull((case when v.INTEGRALMONEY=0 then 0 else b.ysmoney/v.INTEGRALMONEY end),0) as int)*/
             /*,@saleIntegralYE=isnull((case when v.INTEGRALMONEY=0 then 0 else b.ysmoney -cast(b.ysmoney/v.INTEGRALMONEY as int)*v.INTEGRALMONEY end),0)*/
             from billidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid
    
   select @RemainderMoney=isnull(abs(sum(jdmoney)),0) from vw_c_ADetail where billid=@nBillId and aclass_id='000002000006' 
   if @nbilltype in (12,13)
   begin
     select @saleIntegral=isnull(totalItg,0),@saleIntegralYE=isnull(0,0) from Integralidx where bill_id=@nBillId
     select @salemoney=isnull(SUM(taxtotal),0) from salemanagebill where bill_id=@nBillId
   end
   else if @nBillType in (149)
   select @salemoney=isnull(SUM(IntegRalTotal),0) from ExIntegRalManagebill where billid=@nBillId
   else
   if @nBillType in (148)
    select @salemoney=isnull(SUM(jftotal),0) from financebill where bill_id=@nBillId
end

if @nbilltype=12 
begin           
        if (@isIntergral=1) and (@Vipcardid is not null) and  (@Intergral<@saleIntegral)
        begin
               set @nReturnNumber=-12
	       SET TRANSACTION ISOLATION LEVEL READ COMMITTED
               return
        end
        /*--医保结算不能红冲*/
	if exists (select distinct  a.billid from accountdetail a,account b where b.ybaccount=1 and   a.a_id=b.account_id and a.billid=@nbillid )
	begin
		set @nReturnNumber=-1201
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED

		return
	end
end

if @nbilltype=13 
begin
        if (@isbank=1) and (@Vipcardid is not null) and  (@money<@RemainderMoney)
        begin
               set @nReturnNumber=-13
	       SET TRANSACTION ISOLATION LEVEL READ COMMITTED
               return
        end
end

/*判断是否有冲价单据*/
if @nBilltype=10
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=16 and billstates='0')
	begin
		set @nReturnNumber=-110
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED

		return
	end
end
if @nBilltype=11
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=17 and billstates='0')
	begin
		set @nReturnNumber=-111
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end
if @nBilltype=20
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=24 and billstates='0')
	begin
		set @nReturnNumber=-120
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end
if @nBilltype=104
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=106 and billstates='0')
	begin
		set @nReturnNumber=-122
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end

if @nBilltype=21
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=25 and billstates='0')
	begin
		set @nReturnNumber=-121
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end
/*对于已经收，发货的采购单和销售单应控制不允许红冲！ */
if @nBilltype=210
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=212 and billstates='0')
	begin
		set @nReturnNumber=-210
		set @szRAISERROR='本张单据存在发货单据，不能做红字反冲！'+char(10)+'请先红冲相应的发货单据!'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end

if @nBilltype=220
begin
	if exists (select * from billidx where order_id = @nbillid and billtype=222 and billstates='0')
	begin
		set @nReturnNumber=-220
		set @szRAISERROR='本张单据存在收货单据，不能做红字反冲！'+char(10)+'请先红冲相应的收货单据!'
		RAISERROR (@szRAISERROR, 16, 1)
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return
	end
end

if @nbilltype=148
begin
       if @money<@salemoney
       begin
              set @nReturnNumber=-148
              SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	      return
       end
end
/****************************/

begin tran 
/*1复制原单据	*/
if @nbilltype<>141
begin
    /*----------生成红字单据----------*/	
	/*销售类单据*/
	if @nBilltype in (10,11,12,13,16,17,32,110,111,112,210,212,211,150,151,152,153,106,107) 
	/*销售出库单,销售出库退货,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,销售单,发货单,销售退货单*/
	begin
		insert into billidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate, integral, integralYE,WholeQty,PartQty)
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,-integral, -integralYE,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,
				jsprice,AOID,invoice,invoiceno,PriceType,SendQTY,SendCosttotal,RowGuid,RowE_ID,YCostPrice,
				YGuid,Instoretime,Y_id,cxtype,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,
		  jsprice,AOID,invoice,invoiceno,PriceType,SendQTY,SendCosttotal,newid(),RowE_ID,YCostPrice,
		  YGuid,Instoretime,Y_id,cxtype,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal
		FROM dbo.salemanagebill
	 	where bill_id=@nBillid	
	end
	/*销售类单据*/
	
	/*挂号单*/
	else if @nBillType = 240
	begin
		insert into billidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate, integral, integralYE,WholeQty,PartQty)
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,-integral, -integralYE,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,
				jsprice,AOID,invoice,invoiceno,PriceType,SendQTY,SendCosttotal,RowGuid,RowE_ID,YCostPrice,
				YGuid,Instoretime,Y_id,cxtype,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,
		  jsprice,AOID,invoice,invoiceno,PriceType,SendQTY,SendCosttotal,newid(),RowE_ID,YCostPrice,
		  YGuid,Instoretime,Y_id,cxtype,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal
		FROM dbo.salemanagebill
	 	where bill_id=@nBillid
	 	
	 	insert into registered(Patient_id,Doctor_id,RegWorkPlan,RegDate,bill_id,Emp_ID,comment) 
	 	select Patient_ID,Doctor_ID,RegWorkPlan,RegDate,@nNewBillId,Emp_ID,Comment
		from registered	where Bill_ID = @nBillid
		
	 insert into Registerbill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,total,invoicetotal,thqty,newprice,orgbillid,aoid,
	       PriceType, RowGuid, RowE_id, Y_ID, InStoreTime, cxType,Conclusion)
	select @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,total,invoicetotal,thqty,newprice,orgbillid,aoid,
	       PriceType, RowGuid, RowE_id, Y_ID, InStoreTime, cxType,Conclusion
	       from Registerbill where bill_id = @nBillId  			
	end
	/*挂号单*/
	
	/*采购类单据*/
	else if @nBilltype in (20,21,24,25,35,120,121,122,220,222,221,160,161,162,163,104,105) 
	/*采购入库单,采购入库退货单,受托代销收货,受托代销退货,受托代销结算,采购单,收货单,采购退货单*/
	begin
		insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty) 
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
			      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,invoice,invoiceno,jsprice,AOID,PriceType,SendQTY,SendCosttotal,RowE_ID,YCostPrice,RowGuid,YGuid,Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
	      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,invoice,invoiceno,jsprice,AOID,PriceType,SendQTY,SendCosttotal,RowE_ID,YCostPrice,newid(),YGuid,Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal
		FROM dbo.buymanagebill where bill_id=@nBillid	
	end
	/*采购类单据*/
        
        if @nBilltype = 161
          delete tasklistup where TranFlag <> 2 and billguid = @szBillGuid and TableType = 'B'
        if @nBilltype = 150
          delete tasklist where TranFlag = 1 and billid = @nBillId
	
	/*库存类单据*/
	else if @nBilltype in (30,31,33,34,38,40,41,42,43,44,45,46,47,48,49,51,39)
	/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
	begin
		insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty) 
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty
		FROM billidx 
		where billid=@nBillId
	
		select @nNewBillId=@@identity
	

		insert into storemanagebill(
						bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
			     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,thqty,newprice,orgbillid,aoid,SendQTY,SendCosttotal,RowE_ID,RowGuid,Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
	         makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,thqty,newprice,orgbillid,aoid,SendQTY,SendCosttotal,RowE_ID,newid(),Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal
		FROM storemanagebill
		where bill_id=@nBillid	
	end
	/*库存类单据*/
	
	/*库存盘点单*/
	else if @nBilltype =50
	/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
	begin
		insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty) 
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into GoodsCheckbill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
			      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			      comment,unitid,taxrate,order_id,total,aoid,RowGuid,Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
	      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	      comment,unitid,taxrate,order_id,total,aoid,newid(),Instoretime,Y_id,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal
		FROM GoodsCheckbill where bill_id=@nBillid	
	end
	/*库存盘点单*/
	
	/*钱流单据*/
	else if @nBilltype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,87,88,146,147,148,155,165,170,171,172,173,174,184,185)
	/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买,会员储值单*/
	begin
		insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate) 
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into financebill(bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal,RowGuid,Y_id,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @nNewBillId,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal,newid(),Y_id,factoryid,costtaxrate,costtaxprice,costtaxtotal
		FROM financebill
		where bill_id=@nBillid	
	end
	/*钱流单据*/
	else if 
	@nBilltype in (53,54,55,56)
	/*配送类单据*/
	begin
		insert into billidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty)
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
		
		insert into tranmanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,invoice,invoiceno,aoid,pricetype,SendQTY,SendCosttotal,RowE_ID,RowGuid,Y_id,Instoretime,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	      	totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	      	qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	      	comment,unitid,taxrate,order_id,total,iotag,invoice,invoiceno,aoid,pricetype,SendQTY,SendCosttotal,RowE_ID,newid(),Y_id,Instoretime,batchbarcode,scomment,batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal
		FROM dbo.tranmanagebill
	 	where bill_id=@nBillid	
	end 
	/*配送类单据*/
        else if 
        @nbilltype in (149)
        begin
                insert into billidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty)
		SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
	      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,@szNewBillGuid,invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,EndDate,WholeQty,PartQty
		FROM billidx where billid=@nBillId
	
		select @nNewBillId=@@identity
                
                Insert into ExIntegRalManagebill (billid,p_id,u_id,s_id,ColorID,SizeID,quantity,costprice,costTotal,price,TotalMoney,IntegralMoney,IntegRalTotal,status,comment,RowTag,Aoid,batchno,
                makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal,rowguid,Y_id,Instoretime,factoryid,costtaxrate,costtaxprice,costtaxtotal)
                select @nNewBillId,p_id,u_id,s_id,ColorID,SizeID,quantity,costprice,costTotal,price,TotalMoney,IntegralMoney,IntegRalTotal,status,comment,RowTag,Aoid,batchno,
                makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal,newid(),Y_id,Instoretime,factoryid,costtaxrate,costtaxprice,costtaxtotal
                from ExIntegRalManagebill where billid=@nbillid

        end
        /*积分兑换*/

/*-------------------------------*/


/*---------生成红字明细帐----------*/
	if exists(select 1 from productdetail where billid=@nbillid) 
	begin
		insert into productdetailtmp(BillId,p_id,s_id,quantity,price,total,costprice,costtotal,taxprice,taxtotal,batchno,
                makedate,validdate,commissionflag,supplier_id,location_id,storetype,price_id,order_id,unitid,smb_id,oldcommissionflag,AOID,jsPrice,RowE_ID,rowguid,SendQTY,SendCostTotal,retailtotal,Y_id,Instoretime,cxtype,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		select @nNewBillId,p_id,s_id,-quantity,price,-total,costprice,-costtotal,taxprice,-taxtotal,batchno,
                makedate,validdate,commissionflag,supplier_id,location_id,storetype,price_id,order_id,unitid,smb_id,oldcommissionflag,AOID,jsPrice,RowE_ID,newid(),-SendQTY,-SendCostTotal,-retailtotal,Y_id,Instoretime,cxtype,batchbarcode,scomment,batchprice,factoryid, costtaxprice,costtaxrate,-costtaxtotal
		from productdetail 
		where billid=@nBillid
		if @@rowcount=0 goto error
	end


	if exists(select 1 from accountdetail where billid=@nbillid) 
	begin
		insert into accountdetailtmp(billid,a_id,c_id,jdmoney, jdflag, rowguid,y_id) 
		select @nNewBillId,a_id,c_id,-jdmoney,jdflag, newid(),y_id
		from accountdetail 
		where billid=@nBillId
		if @@rowcount=0 goto error
	end
select @NewReadId=@nNewBillId
/*-------------------------------*/

/*--------------反算--------------*/

	exec ts_c_AuditP @nNewBillId,@nP_Id out,@nReturnNumber out,1 /*商品登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 
	begin
		if @nReturnNumber=-1 and @nP_id<>0
		begin
			select @szPname=[name]+'  规格:'+standard from products where product_id=@np_id
		end
		goto error
	end

	exec ts_c_AuditA @nNewBillId,@nReturnNumber out,1 /*科目登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error

	select @szDate=convert(varchar(10),@tbilldate,20)
	update billidx set billstates=4,billdate=convert(varchar(10),GetDate(),20),auditdate=GetDate(),note='红字反冲:'+@szDate+' '+note where billid=@nNewBillId
	update billidx set billstates=1 where billid=@nbillid 
        
    exec ts_c_deletetmpdetail @nNewBillid /*删除过账临时表*/
       
	if @nBilltype in (12,13)
	begin
         /* insert VipDetail (billid,billdate,cardid,p_id,pos_id,quantity,price,total,costtotal,discounttotal,guid,aoid,Y_ID)*/
          /*select a.billid,a.billdate,a.order_id,b.p_id,a.posid,-b.quantity,b.taxprice,-b.taxtotal,-b.costtotal,-b.total,newid(),b.aoid,a.Y_ID*/
         /* from billidx a,productdetail b*/
         /* where a.billid=b.billid and a.billid=@nNewBillid and a.order_id<>0*/

		 /* 先处理积分流水*/
		 DECLARE @nLastIntegral NUMERIC(25,8)
		 DECLARE @nItgIdx INT
		 /*select TOP 1 @nLastIntegral = PtotalItg + totalItg FROM Integralidx WHERE VIPCardID = @Vipcardid ORDER BY billid DESC*/
		 select @nLastIntegral = Integral from VIPCard WHERE VIPCardID = @Vipcardid 

		 /* 写入积分主表*/
		 INSERT Integralidx (bill_id, VIPCardID, I_id, Itgmode, totalItg, totalye, ljtotalye, billdate, remake, PtotalItg)
		 SELECT @nNewBillId, VIPCardID, I_id, Itgmode, -@saleIntegral, 0, 0, CONVERT(VARCHAR(10), GETDATE(), 120), '红字反冲', @nLastIntegral
		 FROM Integralidx WHERE bill_id = @nBillId
		 SET @nItgIdx = @@IDENTITY
		 

		 /* 写入积分明细表*/
		INSERT Integraldetail (billid, smb_id, totalmoney, baseItg, Itgrate, totalItg, remake)
		SELECT @nItgIdx, SB2.smb_id, ID.totalmoney, ID.baseItg, -ID.Itgrate, -ID.totalItg, ID.remake
		FROM salemanagebill SB1
		INNER JOIN salemanagebill SB2
		ON SB1.YGuid = SB2.YGuid AND SB1.smb_id <> SB2.smb_id
		INNER JOIN Integraldetail ID
		ON SB1.smb_id = ID.smb_id
		WHERE SB1.bill_id = @nBillId

        delete retailmerge where newbillguid=@szBillGuid and draft=0

		select @nNewBillid=0
		select @nNewBillId=billid from retailbillidx where guid=@szBillGuid
		if @nNewBillid<>0
		begin
			delete from retailbillidx where billid=@nNewBillId
			delete from retailbill where bill_id=@nNewBillId
		end
        
           if @nbilltype=12 and @Vipcardid>0
           begin
             if @isIntergral=1
               begin
                update Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
                select @modIntergral=-@saleIntegral
                select @nowIntergral=@Intergral-@saleIntegral
               end
               else
               begin  
                  select @nowIntergral=0 /* from vipcard where Vipcardid=@Vipcardid*/
                  select @modIntergral=0
               end

             if ((@isbank=1) and (@isZBZT=0 )) or (@posdatamode<>1) /*离线模式总部帐套红冲含有储值卡的零售单时，不增加储值金额  zc 2011-12-18修改*/
             begin
               update Vipcard set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid
               select @nowmoney=@money+@RemainderMoney,@modmoney=@RemainderMoney
             end
             else
             begin
               select @nowmoney=0 /*from vipcard where vipcardid=@Vipcardid*/
               select @modmoney=0
             end  

            if (@isbank=1) or (@isIntergral=1)
            update Vipcard set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1 where Vipcardid=@Vipcardid  
            select @ntag=19
            select @comment='红冲零售单：【'+@order+'】'
           end

           if @nbilltype=13 and @Vipcardid>0
           begin

             if @isIntergral=1
             begin
                update Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
                select @modIntergral=-@saleIntegral
                select @nowIntergral=@Intergral-@saleIntegral
             end
             else 
             begin
               select @nowIntergral=Integral from Vipcard where Vipcardid=@Vipcardid
               select @modIntergral=0
             end

             if (@isbank=1) and (@isZBZT=0 ) /*总部帐套红冲含有储值卡的零售单时，不增加储值金额  zc 2011-12-18修改  */
             begin
                update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid
                select @nowmoney=@money-@RemainderMoney,@modmoney=-@RemainderMoney
             end
             else
             begin
                select @nowmoney=0/* from vipcard where vipcardid=@Vipcardid*/
                select @modmoney=0
             end
           
           if (@isbank=1) or (@isIntergral=1) 
           update Vipcard set TotalBuyMoney=TotalBuyMoney+@salemoney,BuyCount=BuyCount+1  where Vipcardid=@Vipcardid
           select @ntag=20 
           select @comment='红冲零售退货单：【'+@order+'】'
           end
 	end

        if @nbilltype in (148)
        begin
          
          update Vipcard set SaveMoney=SaveMoney-@salemoney,RemainderMoney=RemainderMoney-@salemoney where Vipcardid=@Vipcardid
          
          select @nowmoney=RemainderMoney,@nowIntergral=Integral from Vipcard where Vipcardid=@Vipcardid
          select @modmoney=@salemoney,@modIntergral=0

          select @ntag=21
          select @comment='红冲储值单：【'+@order+'】'
        end

       if @nbilltype in (149) 
       begin 
          if (@calcFlag <> 149)/*因为红冲积分兑换单是直接连接总部进行红冲，故在上传红冲兑换单据时，不用处理红冲积分 add by luowei 2013-08-21*/
          begin
            update Vipcard set Integral=isnull(Integral,0)+@salemoney,SwapIntegral=isnull(SwapIntegral,0)-@salemoney where Vipcardid=@Vipcardid
            /*在积分兑换单中，SSMONEY就是兑换的积分。*/
          end
          select @nowmoney=RemainderMoney,@nowIntergral=Integral from Vipcard where Vipcardid=@Vipcardid
          select @modmoney=0,@modIntergral=@salemoney

          select @ntag=22
          select @comment='红冲积分兑换单：【'+@order+'】'
       end


       if @nbilltype in (12,13,148,149) and @Vipcardid>0/*更新会员日志*/
       begin
         exec TS_L_InsVIPCardLog @ntag,'','',@Vipcardid,@nowIntergral,@modIntergral,@nowmoney,@modmoney,0,@comment 
       end

    /*特殊处理150，减去在途库存*/
    if  @nBillType = 150
    begin
      if exists(select 1 from company where company_id = @DY_id and posdatamode = 1 and class_id <> '000001')
      exec TS_j_UpdateSendStock @nbillid, 150, -1
    end
    
end

	if @nBilltype in (161,163)
	begin
	    SELECT * FROM buymanagebill B WHERE B.bill_id = @nNewBillId
		UPDATE GSPbilldetail SET ThQty = CASE WHEN ISNULL(GSPbilldetail.ThQty,0) + ISNULL(B.quantity,0) >= ISNULL(GSPbilldetail.Yqty,0) THEN ISNULL(GSPbilldetail.ThQty,0) + ISNULL(B.quantity,0) ELSE ISNULL(GSPbilldetail.Yqty,0) END 
		FROM GSPBILLIDX G,buymanagebill B WHERE GSPbilldetail.Gspbill_id = G.Gspbillid AND G.BillType = 523 AND G.BillStates = 13 AND B.bill_id = @nNewBillId  AND GSPbilldetail.YrowGuid = B.YGuid
	end

if @nBilltype=141
begin 
    /*期初库存录入单独立账套开账后不能红冲 */
    if exists(select 1 from company where company_id = @y_id and posdatamode = 1 and class_id <> '000001')
      if exists(select 1 from Companybalance where y_id = @y_id and OpenAccount = 1)
      begin
        set @nReturnNumber = -141
        goto error
      end 
    
	exec @nReturnNumber=ts_c_AuditIniBill @nBillId,@y_id, @nP_Id out,@nReturnNumber out,1
	if @@error<>0 goto error
	if @nReturnNumber<>0 
  begin
    if @nReturnNumber=-1 and @nP_id<>0
    begin
      select @szPname=[name]+'  规格:'+standard from products where product_id=@np_id
    end
    goto error
  end
	update billidx set billstates=1 where billid=@nbillid 
end

/* 红冲后修改采购次数 // Huang.Y*/
EXEC TS_H_ModifyBuyCount @nBillId

/* 红冲后扣减促销已售数量*/
 /*if @nBilltype in(10, 210, 12)*/
	/*update CxBillNew set sale = sale - x.quantity*/
	/*from(select cxguid, quantity from salemanagebill where bill_id = @nBillId) x*/
	/*where CxBillNew.guid = x.CxGuid*/

/* 重置原单传输标志*/
	update billidx set transflag = 0 where billid = @nBillId
	
/* 红冲零售单产生的报溢单*/
if @nBillType = 12
begin
    if exists(select billid from billidx where billtype = 42 and order_id = @nBillId)
	begin
	    select @nBillId = billid from billidx where billtype = 42 and order_id = @nBillId
	    if @nBillId > 0
	    	exec ts_c_redword @nBillId, @nReturnNumber output
	end
end

if @@trancount<>0 commit tran 
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
return 0

error:
	if @@trancount<>0 rollback tran 

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
    if @nReturnNumber = -141
    begin
      set @nReturnNumber=-1
	  raiserror('当前机构已经开账，期初库存录入单不能红冲，请盘点处理！',16,1)
	  return -1
    end
	set @nReturnNumber=-1
	raiserror('商品【%s】出现负库存,不能对本单据进行红字反冲。请尝试使用单行红字反冲！',16,1,@szPname)
	return -1

if @@trancount<>0 commit tran 

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
return 0
GO
