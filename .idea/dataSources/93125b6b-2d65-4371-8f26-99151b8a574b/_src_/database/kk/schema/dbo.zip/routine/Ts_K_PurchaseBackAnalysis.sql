

CREATE PROCEDURE Ts_K_PurchaseBackAnalysis(
	@Begin               DATETIME, 
	@End                 DATETIME, 
	@YId                 INT, 
	@PId                 INT, 
	@SupplierId          INT, 
	@Factory             VARCHAR(100), 
	@EId                 INT, 
	@CgId                INT, 
	@szID                VARCHAR(7000),     /*选择的商品类别id串*/
    @CCgId               INT, 
	@szCID               VARCHAR(7000),      /*选择的机构类别id串*/
	@strBusinessType     varchar(50)
)
AS
BEGIN
	DECLARE @BaseType INT
	set @strBusinessType = @strBusinessType+',5'
	
  /*新自定义类别的解析，获取过滤的商品id*/
    DECLARE @PColName VARCHAR(100)
    set @PColName = ''
    CREATE TABLE #TmpP ([Pid] [int] NOT NULL DEFAULT(0))
    IF @szID = ''
    	INSERT INTO #TmpP(PId)
		SELECT  product_id FROM vw_Products
    ELSE 
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @Pclassid varchar(100)
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szID))
    
	  SELECT @Pclassid = dbo.GetCateClassids(@szID)
    
      IF @Pclassid IS NULL SET @Pclassid = ''
      IF LEN(@Pclassid) > 0
      SET @Pclassid = LEFT(@Pclassid,LEN(@Pclassid)-1)
    
      set @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')  
      set @PszSql =  'INSERT INTO #TmpP(pid) ' +
		'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @PColName + 
		' in (select type  from DecodeStr(''' +@Pclassid +'''))'  
	  exec (@PszSql)        
    END
	
    /*新自定义类别的解析，获取过滤的单位id*/
    DECLARE @CColName VARCHAR(100)
    set @CColName = ''
    CREATE TABLE #TmpC ([Cid] [int] NOT NULL DEFAULT(0))
    IF @szCID = ''
    	INSERT INTO #TmpC(Cid)
		SELECT client_id FROM vw_Clients     
    ELSE 
    BEGIN   
      DECLARE @Cinfo_ID INT
      DECLARE @Cclassid varchar(100)
      DECLARE @CszSql varchar(2000)
      SELECT @Cinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szCID))
    
	  SELECT @Cclassid = dbo.GetCateClassids(@szCID)
    
      IF @Cclassid IS NULL SET @Cclassid = ''
      IF LEN(@Cclassid) > 0
      SET @Cclassid = LEFT(@Cclassid,LEN(@Cclassid)-1)
    
      set @cColName = dbo.GetColName(@Cinfo_ID,'ClientCategory')  
      set @CszSql =  'INSERT INTO #TmpC(Cid) ' +
		'select c.Client_id from Clients c,ClientCategory cc where c.Client_id = cc.C_id and cc.' + @CColName + 
		' in (select type  from DecodeStr(''' +@Cclassid +'''))'  
	  exec (@CszSql)        
    END
	
	SELECT s.p_id AS PId, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea, u.name AS UnitName, p.Factory, 
	       b.billnumber, s.instoretime, b.billdate, s.taxmoney,
	       CAST(DATEDIFF(DAY, s.instoretime, GETDATE()) AS INT) AS StockCycle, ISNULL(bb.quantity, 0.00) AS PurchaseQty,
	       CASE WHEN s.makedate < 10 THEN '' ELSE CONVERT(varchar(100), s.makedate, 23) END AS MakeDate, s.batchno, 
	       CASE WHEN s.validdate < 10 THEN '' ELSE CONVERT(varchar(100), s.validdate, 23) END AS ValidDate,
	       s.quantity, s.buyprice, s.total, s.taxrate * 100 AS taxrate, s.taxprice, s.taxtotal, 
	       CASE WHEN ISNULL(bb.quantity, 0.00) <> 0 THEN ROUND(s.quantity * 100 / ISNULL(bb.quantity, 0.00), 2) ELSE 0 END AS BackRate,  
	       e.name AS EName, CASE WHEN b.billtype IN (21) THEN c.name ELSE y.name END AS SupplierName,
	       ISNULL(g.ReturnReason, s.comment) AS BackReason, s.supplier_id
	INTO #TMP
		FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		               INNER JOIN products p ON s.p_id = p.product_id
		               INNER JOIN unit u ON p.unit1_id = u.unit_id
		               INNER JOIN employees e ON b.e_id = e.emp_id
		               LEFT JOIN clients c ON s.supplier_id = c.client_id
		               LEFT JOIN company y ON b.c_id = y.company_id
		               INNER JOIN #TmpP pp ON s.p_id = pp.PId
		               LEFT JOIN buymanagebill bb ON s.orgbillid = bb.smb_id
		               LEFT JOIN (SELECT b.YrowGuid, b.ReturnReason
		                            FROM gspbillidx a INNER JOIN gspbilldetail b ON a.Gspbillid = b.Gspbill_id 
		                          WHERE a.BillType = 561 and b.YrowGuid <> '00000000-0000-0000-0000-000000000000' GROUP BY b.YrowGuid, b.ReturnReason) g ON s.YGuid = g.YrowGuid
	WHERE b.billtype IN (21, 221) AND b.billstates = 0 AND b.billdate BETWEEN @Begin AND @End AND
	      b.Y_ID = @YId AND (@EId = 0 OR @EId = b.e_id) AND (@SupplierId = 0 OR @SupplierId = s.supplier_id) AND
	      (@PId = 0 OR @PId = s.p_id) AND (@Factory = '' OR p.Factory LIKE '%' + @Factory + '%')
	      and ((bb.AOID is null) or (bb.AOID in(select szTYPE from DecodeToStr(@strBusinessType)))) /*不调原单时bb.AOID is null*/
	      
    
    SELECT * FROM #TMP WHERE supplier_id in (select distinct cid from #TmpC) or supplier_id = 0  
END
GO
