create procedure TS_j_QrSFDACodeList
  @piatsCode varchar(100)
    
as

begin   

   declare @smb_id int 
     select top 1  @smb_id = smb_id from SFDA_SingleCodeRelation where piatsCode = @piatsCode
   if @smb_id is null set @smb_id =0
   select * from SFDA_SCRCodeInfoList where smb_id = @smb_id
 
end
GO
