/************************************************************

--功能：生成 clientsbalance, companybalance, accountbalance初始数据  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_MakeBalance
	(
	 @Y_ID int
    )
AS 

/*companybalance*/
if not exists(select * from Companybalance where y_id = @Y_ID and c_id =0)
  insert into Companybalance(y_id, c_id, Openaccount) values(@Y_ID, 0, 0)

insert into companybalance(y_id, c_id) 
  select @Y_ID, company_id 
    from company
    where child_number = 0 and deleted <> 1 and company_id <> @Y_ID and
          company_id not in (select c_id from companybalance where y_id = @Y_ID) 
   
/*clientsbalance*/
insert into clientsbalance(y_id, c_id) 
  select @Y_ID, client_id 
    from clients
    where child_number = 0 and deleted <> 1 and
          client_id not in (select c_id from clientsbalance where y_id = @Y_ID) 

/*accountbalance*/

insert into accountbalance(y_id, a_id) 
  select @Y_ID, account_id 
    from account
    where account_id not in (select a_id from accountbalance where y_id = @Y_ID) 

if not exists(select * from MonthSettleInfo where Y_ID = @Y_ID)
  insert into monthsettleinfo([MonthName],BeginDate, period, y_id) 
    values('本期', cast(cast(GETDATE() as varchar(10)) as datetime), 1, @Y_ID)
GO
