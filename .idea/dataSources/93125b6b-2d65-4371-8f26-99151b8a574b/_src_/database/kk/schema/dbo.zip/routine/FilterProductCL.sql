CREATE FUNCTION FilterProductCL(@Y_ID int)
RETURNS  table 
AS  
  RETURN 
       (SELECT distinct TOP 100 PERCENT  ISNULL(u1.name, '') AS Unit1Name,
       ISNULL(WholeU.name, '') AS WholeUnitName, ISNULL(z.medtype, '') 
	        AS MedName, ' ' AS MedCode,ISNULL(pc.pc_name, '') 
	        AS PcName, ISNULL(pc.pc_code, '') AS PcCode,
			p.AuditStates,p.BulidNo,p.ChemName,p.ControlYard,p.Custompro1,p.Custompro2,p.Custompro3,
			p.Custompro4,p.Custompro5,p.EngName,p.Factory,p.GMP,p.GMPNo,p.GMPvaliddate,
			p.Gross,p.IfZYCheck,p.Incrate,p.Inputdate,p.Inputman,p.Integral,p.IsClientDiscount,
			p.IsSplit,p.IsValuedProduct,p.LTTime,p.LastUpDate,p.LastUpdateman,p.LatinName,
	        p.MaintainDay,p.MaintainType,p.ModifyDate,p.NoneQuantity,
			p.OTCType,p.PackStd,p.PerCodevalid,p.PosYhDay,p.PrintClass,p.ProREP_Data,
			p.ProREP_No,p.Profit,p.RegisterNo,p.Registervalid,p.RowIndex,p.SR2_id,p.SR_id,
			p.StorageCon,p.StoreCondition,p.TC1,p.TC2,isnull(q.TaxRate,0) as TaxRate,p.TcCost,p.TransTimes,p.TransToYJ,
			p.WholeUnit_id,p.alert,p.alias,p.auditComment,p.auditMan,p.basicMedication,
			p.buycount,p.child_count,p.child_number,p.class_id,p.cldw,p.cljg,p.comment,p.costmethod,
			p.deduct,p.deleted,p.factoryc_id,p.firstcheck,p.gspflag,p.hsbl,p.ifIntegral,p.ifdiscount,
			p.incRate2,p.incRate3,p.isCheckReport,p.makearea,isnull(z.id,0) as medtype,p.modal,p.name,p.otcflag,
			p.pack,p.parent_id,p.permitcode,p.pinyin,p.protectprice,isnull(r.id,0) as r_id,p.rate2,p.rate3,
			p.rate4,p.serial_number,p.sfcl,p.standard,p.tcmoney,p.trademark,p.cldw as unit1_id,p.unit2_id,p.StandardCode, p.CloudCode,
			p.unit3_id,p.unit4_id,p.validcheck,p.validday,p.validmonth,p.product_id,isnull(q.id,0) as taxrateid,
	        ISNULL(u3.name, '') AS Unit4Name, ISNULL(u0.name, '') AS Unit2Name, ISNULL(u2.name, '')  AS Unit3Name, 
	        p.AloneLocation,IsAloneLocation=case p.AloneLocation when 0 then '否' when 1 then '是' end,
	        p.LocationRequirement,LocationRequirementName=case p.LocationRequirement when 0 then '非常容易' when 1 then '容易' 
	        when 2 then '一般' when 3 then '较困难' when 4 then '困难' end,
	        p.SaleUnitMultiplex, IsSaleUnitMultiplex=case p.SaleUnitMultiplex when 0 then '否' when 1 then '是' end,
	        p.DefaultBuyUnit,p.DefaultSaleUnit,ISNULL(u6.name,'') as DefaultBuyUnitName,ISNULL(u7.name,'') as DefaultSaleUnitName,	        
	        p.serial_number AS code, ISNULL(pr.retailprice, 0) AS retailprice, 
	        cast(ISNULL(p.cljg, 0)as numeric(25,8)) AS recprice, ISNULL(p.cljg, 0) AS price1, 
	        ISNULL(p.cljg, 0) AS price2, ISNULL(p.cljg, 0) AS price3, ISNULL(p.cljg, 0) AS price4, 
	        ISNULL(p.cljg, 0) AS glprice, ISNULL(p.cljg, 0) AS gpprice, 
	        ISNULL(p.cljg, 0) AS Specialprice, ISNULL(p.cljg, 0) AS Lowprice, 
	        ISNULL(pb.c_name, '') AS C_Name, ISNULL(pb.E_name, '') AS E_Name, 
	        ISNULL(pb.locationid, 0) as locationid, ISNULL(pb.wholeloc, 0) as wholeloc,
	        ISNULL(pb.singleloc, 0) as singleloc, ISNULL(pb.supplier_id, 0) as supplier_id,
	        ISNULL(pb.emp_id, 0) as emp_id,
	        CASE ISNULL(P.LastUpDate,0) WHEN '1900-01-01' THEN ISNULL(P.INPUTDATE,0) ELSE ISNULL(P.LastUpDate,0) END as Updatetime,
	        otcbz=case p.otcflag
	        when 0 then '否'  when 1 then '是'
	        end  ,
	        StatusName=case p.deleted
	        when 0 then '正常'  when 1 then '删除'  when 2 then '停购'  when 3 then '停售'  when 4 then '停用' when 5 then '停配'
	        end  ,
	        isnull(r.RangeName,'')rName,isnull(g.gspPropert,'')gspPropert
	        ,(case p.OTCType when 0 then '甲类'when 1 then '乙类'when 2 then '[无]' else '' end)OTCName
	        ,(case p.MaintainType when 0 then '一般养护'when 1 then'重点养护' when 2 then '不养护' end) Maintain
	        ,(case p.firstCheck when 0 then '否'  when 1 then '是'end)szFirst
	        ,(case p.gmp when 0 then '否'  when 1 then '是'end)szGmp
	        ,ISNULL(pb.locname,'') AS Locname,isnull(Wloc.loc_name,'') as WLocname
	        ,ISNULL(SLoc.loc_name,'') as SLocname
	        ,(case when exists(select * from sysconfig where sysname='UseSameCostMethod' and sysvalue =1) then
	          (case when (select sysvalue from sysconfig where sysname='CostMethod') = 0 then '移动加权'
	                when (select sysvalue from sysconfig where sysname='CostMethod') = 1 then '先进先出'
	                when (select sysvalue from sysconfig where sysname='CostMethod') = 2 then '后进先出'
	                when (select sysvalue from sysconfig where sysname='CostMethod') = 3 then '手工指定' end)
	          else      
	          (case when costmethod = 0 then '移动加权'
	                when costmethod = 1 then '先进先出'
	                when costmethod = 2 then '后进先出'
	                when costmethod = 3 then '手工指定' end) end) as costmethodname        
	        ,ISNULL(SR.[name],'') as SRname,ISNULL(SR2.[name],'') as SRname2,
                ifalert= case p.alert when 0 then '是' when 1 then '否'end,
            (case when wholeUnit_id = unit2_id then rate2
				 when wholeUnit_id = unit3_id then rate3
				 when wholeUnit_id = unit4_id then rate4
				 else 1 end)  as WholeRate,
			(case ifIntegral when 0 then '否' else '是' end) as 	ifIntegralstr, 
			(case ifdiscount when 0 then '否' else '是' end) as 	ifdiscountstr, 
			(case basicMedication when 0 then '否' else '是' end) as IfbasicMedication,
			(Case protectprice when 0 then '否' else '是' end) as protectpriceStr,
			case when p.TransTimes >0 then '已上报' else '未上报' end  AS Transcount,
			Trans= case p.TransToYJ when 0 then '否'  when 1 then '是' end,     
			CYard= case p.ControlYard when 0 then '否'  when 1 then '是'end,
			(Case p.AuditStates when 1 then '已审核' else '未审核' end) as AuditStatesStr,
			(case p.AuditStates when 1 then ISNULL(st.AuditEName, '') else '' end) as AuditEName,
			(Case p.AuditStates when 1 then ISNULL(st.AuditDate, '') else '' end) as AuditDate,
			CAST(CASE p.StoreCondition WHEN 2 THEN 1 ELSE 0 END AS INT) AS Iscold,
			CAST(ISNULL(g.doubleCheck, 0) AS INT) AS Isspec,
			ISNULL(p.LTTime, 0) as isCheckLT,ISNULL(u5.name, '') AS UnitNameCL,
			ISNULL(pe.gnzz,'') as gnzz,
			ISNULL(pe.lcsl,0) as lcsl,
			StoreConditionName = (Case p.StoreCondition when 0 then '常温' when 1 then '阴凉' when 2 then '冷链' else '' end),
			isnull(p.fztaxrate,'') as fztaxrate,p.taxrateflcode  as taxrateflcode,p.Z_ZNumber as Z_ZNumber,p.Z_ZBillDate as Z_ZBillDate,
			isnull(pe.syts,0) as syts/*使用天数  */
       FROM   dbo.unit u0  RIGHT OUTER JOIN
	      dbo.products p LEFT OUTER JOIN
	      dbo.Unit WholeU on p.WholeUnit_id=WholeU.Unit_id left outer join
	      dbo.unit u3 ON p.unit4_id = u3.unit_id LEFT OUTER JOIN
	      dbo.unit u5 ON p.cldw = u5.unit_id LEFT OUTER JOIN
	      dbo.unit u2 ON p.unit3_id = u2.unit_id ON u0.unit_id = p.unit2_id LEFT OUTER JOIN
	      dbo.PrintClass pc ON p.PrintClass = pc.pc_id LEFT OUTER JOIN
	      dbo.unit u1 ON p.cldw = u1.unit_id LEFT OUTER JOIN
	      dbo.unit u6 ON p.DefaultBuyUnit = u6.unit_id LEFT OUTER JOIN
	      dbo.unit u7 ON p.DefaultSaleUnit = u7.unit_id LEFT OUTER JOIN	      
              (SELECT p_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, 
               specialprice, lowprice
               FROM price
               WHERE unittype = 1) pr ON pr.p_id = p.product_id
	      left join 
	         VW_Range r on r.product_id=p.product_id
          left join productsExtend pe on p.product_id = pe.p_id
            left join 
	        vw_medtype z on z.product_id=p.product_id
          left join 
            VW_TaxRate  q on q.product_id=p.product_id
	      left join gspPropert g on g.gspid=p.gspFlag 
	      left join (select PB.p_id, PB.locationid, PB.WholeLoc, PB.SingleLoc, PB.Supplier_id, PB.Emp_id, PB.Y_id,c.[name] as C_name,e.[name] as E_name,Loc.[loc_name] as Locname
                         from productbalance PB
                         left join clients c on pb.supplier_id=c.client_id
                         left join employees e on  pb.emp_id=e.emp_id
                         left join Location Loc on  Pb.locationid=Loc.loc_id 
                         where pb.Y_id=@Y_ID   
                         ) pb on pb.p_id=p.product_id 
	      left join Location WLoc on WLoc.loc_id=pb.wholeLoc 
	      left join Location SLoc on SLoc.loc_id=pb.singleLoc
	      left join saleRange SR  on SR.[ID]=p.SR_ID
	      left join SaleRange2 SR2 on SR2.[ID]=P.SR2_ID
	      left join (
	                    select magbillid,e.name as AuditEName,updatedate as AuditDate 
	                    from  sysTnotes st left join employees e on updateman = e.emp_id 
	                    where billtype = 0 
	                    and exists(select 1 from 
	                                    (
	                                      select max(nid) as nid, magbillid,max(updatedate) as sysTnotes from  sysTnotes  
                                          where notes = '【审核】' and billtype = 0 group by magbillid 
	                                    ) st1 where st.nid = st1.nid )
	                 ) st on p.product_id = st.magbillid

WHERE (p.deleted <> 1)
ORDER BY p.class_id
)
GO
