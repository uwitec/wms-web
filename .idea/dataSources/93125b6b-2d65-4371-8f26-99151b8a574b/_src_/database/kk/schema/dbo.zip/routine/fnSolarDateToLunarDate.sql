/*select * from TBSolarData*/
/*sp_help TBSolarData     */
/*前4位，代表了闰月是大月还是小月（因此，只有当年是闰年时才有意义）。1表示闰月为大月30天，0表示闰月为小月29天。*/
/*中间12位，每位代表一个月，为1则为大月，为0则为小月。*/
/*最后4位，代表闰年的闰月月份，0表示没有闰月（即该年不是闰年）。首4位要与末4位搭配使用。 */
CREATE FUNCTION dbo.fnSolarDateToLunarDate ( @solarDate DATETIME )
RETURNS NVARCHAR(50)
AS
    BEGIN
        IF ( @solarDate < '1900-01-31' )
            OR ( @solarDate > '2049-12-31' )
            OR ( @solarDate IS NULL )
            RETURN N'超出计算范围！合法范围(1900.01.31 - 2049.12.31)'  
            
        DECLARE @OffsetDay INT      
        DECLARE @RefDataOf150Years INT      
        DECLARE @i INT     
        DECLARE @binaryMask INT      
        DECLARE @DayNumOfLunarYear INT      
        DECLARE @DayNumOfLunarMonth INT      
        DECLARE @LeapMonth INT  
        DECLARE @mleap1 INT    
        DECLARE @DayNumOfLunarLeapMonth INT          
        DECLARE @temp INT      
        DECLARE @LunarYear NVARCHAR(10)     
        DECLARE @LunarMonth NVARCHAR(10)      
        DECLARE @LunarDay NVARCHAR(10)  
        DECLARE @chinesenum NVARCHAR(10)         
        DECLARE @outputdate NVARCHAR(30)  
  
       /*保证传进来的日期不带时间           */
        SET @solarDate = CAST(@solarDate AS CHAR(10))              /*去掉阳历参数中的时间部分，保留年月日*/
        SET @OffsetDay = DATEDIFF(DAY, '1900-01-30', @solarDate)   /*计算阳历与农历起始日的差异天数 */
 /*-------------------------------------    */
  /*确定农历年开始      */
        SET @i = 1900           
        WHILE @OffsetDay > 0
            BEGIN      
                SET @DayNumOfLunarYear = 348     /*假设每个月都是小月，29*12=348天 */
                SELECT  @RefDataOf150Years = dataint
                    FROM TBSolarData
                    WHERE yearid = @i            
    /*传回农历年的总天数  */
                           /*实际数据：xxxx  xxxx  xxxx xxxx  xxxx     */
                SET @binaryMask = 32768     /*二进制：0000 1000 0000 0000 0000  */
                WHILE @binaryMask > 8         /*二进制：0000 0000 0000 0000 1000*/
                    BEGIN      
                        IF @RefDataOf150Years & @binaryMask > 0  /*位与运算，计算中间的12位，得到有多少个大月   */
                            SET @DayNumOfLunarYear = @DayNumOfLunarYear + 1      
                        SET @binaryMask = @binaryMask / 2     /*右移运算    */
                    END   
       
    /*传回农历年闰哪个月(1-12) , 没闰传回 0      */
                SET @LeapMonth = @RefDataOf150Years & 15 /*二进制：0000 0000 0000 0000 1111     */
    
    /*传回农历年闰月的天数 ,加在年的总天数上      */
                IF @LeapMonth > 0   /*有闰月存在，说明当年是闰年   */
                    BEGIN      
                        IF @RefDataOf150Years & 65536 > 0               /*二进制：0001 0000 0000 0000 0000   --检测闰月是大月还是小月*/
                            SET @DayNumOfLunarLeapMonth = 30      
                        ELSE
                            SET @DayNumOfLunarLeapMonth = 29           
                        SET @DayNumOfLunarYear = @DayNumOfLunarYear
                            + @DayNumOfLunarLeapMonth  /*得到全年天数    */
                    END 
                IF @OffsetDay <= @DayNumOfLunarYear
                    BREAK      
                SET @OffsetDay = @OffsetDay - @DayNumOfLunarYear 
                SET @i = @i + 1      
            END   
     
  /*确定农历年结束        */
        SET @LunarYear = @i 
/*--------------------------------------       */
  /*确定农历月开始      */
        SET @i = 1      
        SELECT  @RefDataOf150Years = dataint
            FROM TBSolarData
            WHERE yearid = @LunarYear    
  /*判断那个月是闰月      */
        SET @LeapMonth = @RefDataOf150Years & 15  /*二进制：0000 0000 0000 0000 1111      */
        WHILE @OffsetDay > 0
            BEGIN      
    /*判断闰月      */
                SET @DayNumOfLunarMonth = 0      
                IF ( @LeapMonth > 0
                     AND @i = ( @LeapMonth + 1 )
                   )      
    /*是闰年，有闰*/
                    BEGIN      
                        SET @i = @i - 1      
                        SET @mleap1 = @LeapMonth              
      /*传回农历年闰月的天数      */
                        IF @RefDataOf150Years & 65536 > 0   /*计算闰月的大小   */
                            SET @DayNumOfLunarMonth = 30      
                        ELSE
                            SET @DayNumOfLunarMonth = 29      
                    END      
                ELSE      
    /*不是闰年，无闰月      */
                    BEGIN      
                        SET @binaryMask = 1      
                        SET @temp = 65536      /*二进制：0001 0000 0000 0000 0000   --检测每个月是大月还是小月*/
                        WHILE @binaryMask <= @i
                            BEGIN          
                                SET @temp = @temp / 2     
                                SET @binaryMask = @binaryMask + 1      
                            END      
     
                        IF @RefDataOf150Years & @temp > 0      /*说明当月是大月*/
                            SET @DayNumOfLunarMonth = 30      
                        ELSE
                            SET @DayNumOfLunarMonth = 29      
                    END         
                IF @OffsetDay <= @DayNumOfLunarMonth
                    BREAK  
                SET @OffsetDay = @OffsetDay - @DayNumOfLunarMonth      
                SET @i = @i + 1      
            END                
   
  /*确定农历月结束        */
        SET @LunarMonth = @i    
     
  /*确定农历日        */
        SET @LunarDay = LTRIM(@OffsetDay) 
/*-----------------------------------------------------          */
        /*输出年*/
        SET @chinesenum = N'〇一二三四五六七八九十'   
        WHILE LEN(@LunarYear) > 0
            SELECT  @outputdate = ISNULL(@outputdate, '')
                    + SUBSTRING(@chinesenum, LEFT(@LunarYear, 1) + 1, 1),
                    @LunarYear = STUFF(@LunarYear, 1, 1, '') /*1990*/
        /*输出月            */
        SET @outputdate = @outputdate + N'年' + CASE @mleap1
                                                 WHEN @LunarMonth THEN N'闰'
                                                 ELSE ''
                                               END
        IF CAST(@LunarMonth AS INT) < 10
            SET @outputdate = @outputdate + CASE @LunarMonth
                                              WHEN 1 THEN N'正'
                                              ELSE SUBSTRING(@chinesenum,
                                                             LEFT(@LunarMonth,
                                                              1) + 1, 1)
                                            END
        ELSE
            IF CAST(@LunarMonth AS INT) >= 10
                SET @outputdate = @outputdate + CASE @LunarMonth
                                                  WHEN 10 THEN N'十'
                                                  WHEN 11 THEN N'十一'
                                                  ELSE N'十二'
                                                END 
        SET @outputdate = @outputdate + N'月'
        /*-输出日*/
        IF CAST(@LunarDay AS INT) < 10
            SET @outputdate = @outputdate + N'初' + SUBSTRING(@chinesenum,
                                                             LEFT(@LunarDay, 1)
                                                             + 1, 1)
        ELSE
            IF @LunarDay BETWEEN 10 AND 19
                SET @outputdate = @outputdate + CASE @LunarDay
                                                  WHEN 10 THEN N'初十'
                                                  ELSE N'十'
                                                       + SUBSTRING(@chinesenum,
                                                              RIGHT(@LunarDay,
                                                              1) + 1, 1)
                                                END
            ELSE
                IF @LunarDay BETWEEN 20 AND 29
                    SET @outputdate = @outputdate + CASE @LunarDay
                                                      WHEN 20 THEN N'二十'
                                                      ELSE N'廿'
                                                    END + CASE @LunarDay
                                                            WHEN 20 THEN N''
                                                            ELSE SUBSTRING(@chinesenum,
                                                              RIGHT(@LunarDay,
                                                              1) + 1, 1)
                                                          END
                ELSE
                    SET @outputdate = @outputdate + N'三十'
        RETURN @outputdate
    END
GO
