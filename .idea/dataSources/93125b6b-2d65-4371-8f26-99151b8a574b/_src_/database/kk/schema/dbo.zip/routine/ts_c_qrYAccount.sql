
CREATE	proc ts_c_qrYAccount

(	
	@szParid		varchar(20),
	@cFlag		char(2),
	@szPeriod	char(2),
    @szLoginID      int,
	@nEid			int
)
as
set nocount on

declare @YID INT
declare @nlen int

set @nlen = LEN(@szParid) + 6

select @YID=@szLoginID 

	/*exec ts_L_TempBillToYPDetail*/
	
	if @YID IN (2, 0)
	begin
		select a.account_id,a.[name],a.parent_id,a.child_number,a.class_id,a.serial_number,
			(select isnull( sum(case @szPeriod 
				when '' 	then b.cur_total
				when 'c' 	then b.cur_total
				when '01' then b.total_01
				when '02' then b.total_02
				when '03' then b.total_03
				when '04' then b.total_04
				when '05' then b.total_05
				when '06' then b.total_06
				when '07' then b.total_07
				when '08' then b.total_08
				when '09' then b.total_09
				when '10' then b.total_10
				when '11' then b.total_11
				when '12' then b.total_12
				else b.ini_total end)
										,0)  
				   from 
				(select a.class_id,a.deleted,cast(ab.total_01 as NUMERIC(25,8)) as total_01,total_02=cast(ab.total_02 as NUMERIC(25,8)) ,
				total_03=cast(ab.total_03 as NUMERIC(25,8)) , total_04=cast(ab.total_04 as NUMERIC(25,8)),
						total_05=cast(ab.total_05 as NUMERIC(25,8)) , total_06=cast(ab.total_06 as NUMERIC(25,8)),
				total_07=cast(ab.total_07 as NUMERIC(25,8)) , total_08=cast(ab.total_08 as NUMERIC(25,8)),
				total_09=cast(ab.total_09 as NUMERIC(25,8)) , total_10=cast(ab.total_10 as NUMERIC(25,8)),
				total_11=cast(ab.total_11 as NUMERIC(25,8)) , total_12=cast(ab.total_12 as NUMERIC(25,8)),
				cur_total= cast(ab.cur_total as NUMERIC(25,8)),ini_total=cast(ab.ini_total as NUMERIC(25,8)) 
				from accountBalance ab ,account a 
				where a.account_id=ab.a_id and (@YID = 0 OR ab.Y_id=@YID) and ab.a_id in (select account_id from dbo.AuthorizeAccount(@nEid))) b
			where left(b.class_id,len(a.class_id))=a.class_id and b.deleted=0) as 'total' 
		from account a 
		where a.parent_id=@szParid and sysflag=@cFlag and a.deleted=0 and a.account_id in (select account_id from dbo.AuthorizeAccount(@nEid))
	end
	else
	begin
		SELECT   account_id, name, parent_id, child_number, AC.class_id, serial_number, ISNULL(AB.total, 0) AS total
		FROM
		(SELECT * FROM dbo.account
		WHERE   (parent_id = @szParid) AND (sysflag = @cFlag) AND (deleted = 0) and account_id in (select account_id from dbo.AuthorizeAccount(@nEid))) AC
		LEFT JOIN
		(SELECT   d.a_id, d.total, a.class_id
		FROM      (SELECT   a_id, SUM(jftotal) AS total
                 FROM      dbo.financebilldrf
                 WHERE   (bill_id IN
                                     (SELECT   billid
                                      FROM      dbo.billdraftidx
                                      WHERE   (billtype = 158) AND (billstates = '3') AND (c_id = @YID) and a_id in (select account_id from dbo.AuthorizeAccount(@nEid))))
                 GROUP BY a_id) AS d INNER JOIN
                dbo.account AS a ON d.a_id = a.account_id
		) AB ON AC.class_id = (LEFT(AB.class_id, LEN(AC.class_id)))
	end
GO
