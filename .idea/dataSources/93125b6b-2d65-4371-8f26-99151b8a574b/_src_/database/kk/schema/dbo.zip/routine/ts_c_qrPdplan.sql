
/*
创建人：
创建时间：
功能说明：
参数说明：
　　　　　@nMode 0: 查询， 1：新建计划 2:删除计划
最后修改: zhoujilin 2010-10-28 增加PDA 盘点
*/
create proc ts_c_qrPdplan
(
  @begindate  varchar(10),
  @enddate    varchar(10),
  @nk_id      int,
  @nUsePDA    int,
  @nNoBatch   int,
  @ne_id      int,
  @nY_ID	  int,
  @nKQ_ID     int=0,
  @nQY_ID     int=0,
  @nMode      int
)
/*with encryption*/
as
set nocount on 
declare @szsql varchar(1000),@nNewBillid int

if @nMode=0
begin
  set @szsql='select pdidx,billdate,inputman,k_id,billstates,Y_ID,UsePDA,NoBatch,Guid,TransFlag,KQ_ID,QY_ID,
				 sname,ename,isnull(f.[name],'''') as kqname,isnull(g.[name],'''') as qyname,UsePDA
				 from 
				 (
				  select pdidx,billdate,inputman,k_id,billstates,p.Y_ID,UsePDA,NoBatch,Guid,TransFlag,KQ_ID,QY_ID
				  ,s.[name] as sname,e.[name] as ename
					   from pdplanidx p,storages s,employees e                                               
				  where p.inputman=e.emp_id and p.k_id=s.storage_id
				  ) a  left join stockArea f on a.kq_id=f.sa_id
					   left join WMSRegion g on a.qy_id=g.id  
					   where y_id = '+ CAST(@nY_ID as varchar(10))
  
  set @szsql=@szsql+' and convert(varchar(10),billdate,21) >='+char(39)+@begindate+char(39)+' and convert(varchar(10),billdate,21)<='+char(39)+@enddate+char(39)
  
  if @nk_id<>0 
  set @szsql=@szsql+' and p.k_id ='+cast(@nk_id as varchar)
  
  if @ne_id<>0
  set @szsql=@szsql+' and p.inputman ='+cast(@ne_id as varchar)
  
 
  exec (@szsql)
  return 0
end else
if @nMode=1
begin
  if exists (select * from pdplanidx where billstates='3' and k_id=@nk_id and Y_Id = @nY_ID)
  begin
    raiserror ('该仓库存在没有完成的盘点计划 ，不能新建盘点计划！',16,1)
    return  -1
  end
  begin tran pdplan
  
  insert pdplanidx(billdate,inputman,k_id,billstates, Y_Id, UsePDA, NoBatch,KQ_ID,QY_ID)
  values
  (convert(varchar,GetDate(),20),@ne_id,@nk_id,'3', @nY_ID, @nUsePDA, @nNoBatch,@nKQ_ID,@nQY_ID)		/*时间精确到时分秒*/
  if @@rowcount=0 goto error  

  set @nNewBillid=@@identity
  
  if @nNoBatch =1
  begin
	  insert 
	  pdplan(pdidx,location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,yhdate, 
	         Y_ID,costtaxprice, costtaxrate, costtaxtotal, factoryid)
	  select 1,0,a.s_id,p_id,0,sum(quantity),case SUM(quantity) when 0 then SUM(costtotal) else CAST((SUM(costtotal)/SUM(quantity)) AS NUMERIC(25,8))  end,
			 sum(costtotal),'',0,0,0,0,0,0,0,Y_ID,case SUM(quantity) when 0 then SUM(costtaxtotal) else CAST((SUM(costtaxtotal)/SUM(quantity)) AS NUMERIC(25,8))  end, 
			 taxrate,sum(costtaxtotal), factoryid
	  from storehouse a left join stockArea b on a.s_id=b.s_id
	                    left join WMSRegion c on b.sa_id=c.Store_KQ_ID
	  where a.s_id=@nk_id and (b.sa_id=@nKQ_ID or @nKQ_ID=0)  
	        and (c.ID=@nQY_ID or @nQY_ID=0) 
	  group by a.s_id, p_id, Y_ID,taxrate, factoryid
  end 
  else 
  begin
	  insert 
	  pdplan(pdidx,location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,yhdate, 
	         Y_ID, batchprice, scomment, batchbarcode,costtaxprice, costtaxrate, costtaxtotal, factoryid)
	  select @nNewBillid,location_id,a.s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,yhdate,
	         Y_ID, batchprice, scomment, batchbarcode,costtaxprice, taxrate, costtaxtotal, factoryid
	  from storehouse a left join stockArea b on a.s_id=b.s_id
	                    left join WMSRegion c on b.sa_id=c.Store_KQ_ID
	  where a.s_id=@nk_id and (b.sa_id=@nKQ_ID or @nKQ_ID=0)  
	        and (c.ID=@nQY_ID or @nQY_ID=0) 
  end  	  
  if @@error<>0 goto error
  commit tran pdplan
  return 0
error:
  rollback tran pdplan
  return -1  
end else
if @nMode=2
begin
  begin tran delpdplan
    delete from goodscheckbilldrf where bill_id in (select billid from billdraftidx where billtype=58 and order_id=@ne_id and Y_ID = @nY_ID)
    delete from billdraftidx where billtype=58 and order_id=@ne_id and Y_ID = @nY_ID  
    delete from pdplanidx where pdidx=@ne_id
    delete from pdplan where pdidx=@ne_id
  commit tran delpdplan
  return 0
end
GO
