Create procedure Ts_t_SelFlQuery
(@nRpid int,
 @nmode int
 )                     
AS
if @nmode=1 
begin
  select rp.*,c.name,e.name as ename  from RebehoofProtocol rp left join clients c on rp.c_id=c.client_id
  left join employees e on rp.inputman=e.emp_id   where id=@nRpid 
end else
if @nmode=2
begin
  select distinct fp.id,c.client_id,c.serial_number,c.name,c.alias,isnull(r.name,'')rname ,c.contact_personal,c.address from flprovider fp 
  left join Clients c on fp.C_id=c.client_id 
  left join Region r on c.region_id=r.region_id  where RP_id=@nRpid 
end else
if @nmode=3
begin
  select isnull(p.product_id,0)Product_id,isnull(p.name,'')name,fl.quantity,fl.price,fl.BuyTotal,fl.BackTotal,fl.[Month],fl.beginTime,
  fl.EndTime ,fl.intendTime,fl.Fljsmode,
  DATEDIFF(DAY,fl.alarmTime,fl.EndTime)alarmtime,fl.FLModulus,fl.Formula,fl.id,fl.saleqty
  from FLCondition fl left join products p on fl.P_id=p.product_id  where RP_id=@nRpid 
end
GO
