
CREATE PROCEDURE TS_H_BillToXml 
	@BillId int, 
	@BillType int,
	@type int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF @BillType BETWEEN 501 AND 599
	BEGIN
		update GSPbillidx set note=replace(note,CHAR(1),' ') WHERE gspbillid = @BillId
		update GSPbillidx set note=replace(note,CHAR(2),' ') WHERE gspbillid = @BillId
		update GSPbillidx set note=replace(note,CHAR(4),' ') WHERE gspbillid = @BillId		
		
		INSERT INTO BillHistory(billId, billType, IdxContent, DetailContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			(SELECT * FROM GSPbillidx WHERE BillType = @BillType AND GSPbillid = @BillId FOR XML AUTO, TYPE, ROOT),
			(SELECT * FROM GSPbilldetail WHERE GSPbill_id = @BillId FOR XML AUTO, TYPE, ROOT),
		GETDATE(),
		@type,
		(SELECT guid FROM GSPbillidx WHERE GSPbillid = @BillId)
	END
	
	ELSE IF @BillType IN (10, 11, 16, 17, 110, 111, 112, 113, 210, 211, 212, 150, 151, 152, 153)
	BEGIN
		update billdraftidx set note=replace(note,CHAR(1),' '),summary=replace(summary,CHAR(1),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(2),' '),summary=replace(summary,CHAR(2),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(4),' '),summary=replace(summary,CHAR(4),' ') WHERE billid = @BillId		
		
		INSERT INTO BillHistory(billId, billType, IdxContent, DetailContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			(SELECT * FROM billdraftidx WHERE BillType = @BillType AND billid = @BillId FOR XML AUTO, TYPE, ROOT),
			(SELECT * FROM salemanagebilldrf WHERE bill_id = @BillId FOR XML AUTO, TYPE, ROOT),
		GETDATE(),
		@type,
		(SELECT guid FROM billdraftidx WHERE billid = @BillId)
	END
	
	ELSE IF @BillType IN (20, 21, 24, 25, 120, 121, 122, 123, 160, 161, 162, 163, 220, 221, 222)
	BEGIN
		update billdraftidx set note=replace(note,CHAR(1),' '),summary=replace(summary,CHAR(1),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(2),' '),summary=replace(summary,CHAR(2),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(4),' '),summary=replace(summary,CHAR(4),' ') WHERE billid = @BillId		
		
		INSERT INTO BillHistory(billId, billType, IdxContent, DetailContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			(SELECT * FROM billdraftidx WHERE BillType = @BillType AND billid = @BillId FOR XML AUTO, TYPE, ROOT),
			(SELECT * FROM buymanagebilldrf WHERE bill_id = @BillId FOR XML AUTO, TYPE, ROOT),
		GETDATE(),
		@type,
		(SELECT guid FROM billdraftidx WHERE billid = @BillId)
	END	
	
	ELSE IF @BillType IN (30, 31, 33, 34, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 100, 101, 141)
	BEGIN
		update billdraftidx set note=replace(note,CHAR(1),' '),summary=replace(summary,CHAR(1),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(2),' '),summary=replace(summary,CHAR(2),' ') WHERE billid = @BillId
		update billdraftidx set note=replace(note,CHAR(4),' '),summary=replace(summary,CHAR(4),' ') WHERE billid = @BillId		
		
		INSERT INTO BillHistory(billId, billType, IdxContent, DetailContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			(SELECT * FROM billdraftidx WHERE BillType = @BillType AND billid = @BillId FOR XML AUTO, TYPE, ROOT),
			(SELECT * FROM storemanagebilldrf WHERE bill_id = @BillId FOR XML AUTO, TYPE, ROOT),
		GETDATE(),
		@type,
		(SELECT guid FROM billdraftidx WHERE billid = @BillId)
	END	
	
	ELSE IF @BillType IN (14,22)
	BEGIN
		update orderidx set note=replace(note,CHAR(1),' '),summary=replace(summary,CHAR(1),' ') WHERE billid = @BillId
		update orderidx set note=replace(note,CHAR(2),' '),summary=replace(summary,CHAR(2),' ') WHERE billid = @BillId
		update orderidx set note=replace(note,CHAR(4),' '),summary=replace(summary,CHAR(4),' ') WHERE billid = @BillId
		
		INSERT INTO BillHistory(billId, billType, IdxContent, DetailContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			(SELECT * FROM orderidx WHERE BillType = @BillType AND billid = @BillId FOR XML AUTO, TYPE, ROOT),
			(SELECT * FROM orderbill WHERE bill_id = @BillId FOR XML AUTO, TYPE, ROOT),
		GETDATE(),
		@type,
		(SELECT guid FROM orderidx WHERE billid = @BillId)
	END		
	
	ELSE IF @BillType BETWEEN 2000 AND 3000
	BEGIN
		INSERT INTO BillHistory(billId, billType, IdxContent, modifyDate, type, guid)
		SELECT @BillId, @BillType, 
			   (SELECT GspID, GspType, BillCode, BillE, BillDate, comment, CheckState, batchno, Sign, GSPVer, guid, szid, Y_ID, IFUpLoad, checkFlag, P_ID, szid2, BillId, BillType,
			           convert(VARBINARY(Max),convert(varchar(Max),GspText)) GspText
			     FROM GspTable 
			     WHERE GspID = @BillId 
			     FOR XML AUTO,BINARY BASE64, ROOT
			   ),
		GETDATE(),
		@type,
		(SELECT guid FROM GspTable WHERE gspid = @BillId)
	END		
END
GO
