

/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_DeptTypeAct] 
	/* Add the parameters for the stored procedure here*/
	@Act	int,
	@Id		int,
	@Name	varchar(50),
	@Exam	bit = 0
AS
BEGIN
/*Params Ini begin*/
if @Exam is null  SET @Exam = 0
/*Params Ini end*/
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;

    /* Insert statements for procedure here*/
	if @Act = 0
	begin
		if Exists(select * from departmentType where [name] = @Name)
		begin
			raiserror('类型名称已经存在！', 16, 1)
			return 0
		end
		insert into departmentType(
			[name],
			[isexam]
		)
		values(
			@Name,
			@Exam
		)
		if @@rowcount > 0
			return @@identity
		else
			return 0
	end
	else
	if @Act = 1
	begin
		if Exists(select * from departmentType where [name] = @Name and [type_id] <> @id)
		begin
			raiserror('类型名称已经存在！', 16, 1)
			return 0
		end
		update departmentType set
			[name] = @Name,
			[isexam] = @Exam
		where [type_id] = @Id
		return @Id
	end
	else
	if @Act = 2
	begin
		if Exists(select * from department where [type_id] = @Id)
		begin
			raiserror('科室类型已被使用，不能删除！', 16, 1)
			return 0
		end
		delete from departmenttype where [type_id] = @Id
		return @Id
	end
END
GO
