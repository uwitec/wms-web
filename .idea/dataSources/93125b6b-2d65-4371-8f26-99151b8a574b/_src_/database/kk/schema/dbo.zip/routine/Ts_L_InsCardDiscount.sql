








CREATE PROCEDURE [Ts_L_InsCardDiscount]
	(@cd_id 	[int],
	 @AutoID	[numeric],
	 @begintotal	NUMERIC(25,8),
	 @endtotal	NUMERIC(25,8),
	 @discount	[numeric](8,4),
	 @comment	[varchar](50))

AS 
if @cd_id=0 
begin
	INSERT INTO [carddiscount] 
		 ([AutoID],
		 [begintotal],
		 [endtotal],
		 [discount],
		 [comment]) 
	 
	VALUES 
		(@AutoID,
		 @begintotal,
		 @endtotal,
		 @discount,
		 @comment)
end else
begin
	UPDATE [carddiscount] 
	
	SET	 [AutoID]	 = @AutoID,
		 [begintotal]	 = @begintotal,
		 [endtotal]	 = @endtotal,
		 [discount]	 = @discount,
		 [comment]	 = @comment 
	
	WHERE 
		( [cd_id]	 = @cd_id)

end
GO
