
CREATE PROCEDURE [dbo].[ts_g_UpLoad]
  @LoginNumber VARCHAR(50)
AS
BEGIN
  /*库存*/
  SELECT p.Custompro5,SUM(st.quantity) qty,GETDATE() UpdateTime,@LoginNumber ERP_ID,p.name  
    INTO #TmpDB
    FROM storehouse st INNER JOIN products p ON st.p_id = p.product_id  
   WHERE p.Custompro5 <> ''
   GROUP BY p.Custompro5,p.name
 
  DELETE FROM HZ_KCB
  INSERT INTO HZ_KCB(YPBH, KCSL, UPDATETIME, PSQYBH)
    SELECT Custompro5,qty,UpdateTime,ERP_ID FROM #TmpDB 
   
  
  /*物流信息*/
  SELECT w.BH, w.GDDATE, w.ERPSHDH, w.CKDATE, w.WLXX, w.SDDATE, w.ERPUPDATETIME, @LoginNumber PSQYBH
    INTO #TmpWLB
    FROM WLB w LEFT JOIN HZ_WLB hz ON w.bh = hz.bh
  WHERE IsNull(w.ERPUpdateTime,0) <> IsNull(hz.ERPUpdateTime,0)
    
  DELETE FROM HZ_WLB WHERE BH IN (SELECT BH FROM #TmpWLB)
  INSERT INTO HZ_WLB(BH, GDDATE, ERPSHDH, CKDATE, WLXX, SDDATE, ERPUPDATETIME, PSQYBH)
    SELECT BH, GDDATE, ERPSHDH, CKDATE, WLXX, SDDATE, ERPUPDATETIME, PSQYBH FROM #TmpWLB
    
  DROP TABLE #TmpWLB  
     
END
GO
