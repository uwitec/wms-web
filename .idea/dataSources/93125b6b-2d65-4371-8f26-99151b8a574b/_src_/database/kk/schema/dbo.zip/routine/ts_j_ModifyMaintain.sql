
/************************************************************
--功能：批量修改药品养护类型   
--创建人：Zhou JiLin 
--创建时间：2010-12-02  
--最后修改:
参数说明：
 @nRet 返回值说明　
 0:执行成功
       -1:执行失败，发生异常
**************************************************************/
CREATE  PROCEDURE [dbo].[ts_j_ModifyMaintain]
 (
   @begindate datetime = 0,
    @enddate datetime = 0,   
   @nMaintaintype int,  
      @nMaintainDay int,   
      @nP_ID int,  
      @nMyMaintaintype int,    
      @nMyMaintainDay int,   
      @nMyPosMaintainday int,           
   @nRet int output
        )
AS 
   set @nRet = -1 
   if OBJECT_ID('tempdb..#modifyPMaintain') is not null
     drop table #modifyPMaintain
     
 if @nP_ID > 0
 begin
   set @begindate = 0 
   set @enddate =0
   set @nMaintainType =-1
   set @nMaintainDay =-1
 end
 
   select product_id, MaintainType, MaintainDay, PosYhDay,
          MaintainType as newMaintainType, MaintainDay as newMaintainDay, 
          PosYhDay as newPosYhDay
      into #modifyPMaintain 
     from Products 
     where (Inputdate >= @begindate) and 
           (@enddate < 10  or Inputdate <= @enddate) and 
           (@nMaintainType = -1 or  MaintainType = @nMaintainType) and 
           (@nMaintainDay = -1 or MaintainDay = @nMaintainDay) and
           (@nP_ID = 0 or product_id = @nP_ID) and deleted = 0 and child_number =0
           
    if @nMyMaintaintype > -1
    begin
      update products set MaintainType = @nMyMaintaintype 
       where product_id in (select product_id from #modifyPMaintain)
      update #modifyPMaintain set newMaintainType = @nMyMaintaintype
    end  
        
    if @nMyMaintainDay > -1
    begin
      update products set MaintainDay = @nMyMaintainDay 
       where product_id in (select product_id from #modifyPMaintain)
      update #modifyPMaintain set newMaintainday = @nMyMaintainDay
    end  
    
    if @nMyPosMaintainday > -1
    begin
      update products set PosYhDay = @nMyPosMaintainday 
       where product_id in (select product_id from #modifyPMaintain)
      update #modifyPMaintain set newposyhday = @nMyPosMaintainday
    end  
    insert into ProductMaintainHis(P_ID, OldMaintainType, NewMaintainType, OldMaintainDay, 
                NewMaintainDay, OldPosYhDay, NewPosYhDay, modifydate)
    select product_id,  MaintainType, newMaintainType,  MaintainDay,  newMaintainDay,
           PosYhDay, newPosYhDay, GETDATE()
      from #modifyPMaintain
      
     if @@ERROR = 0 set @nRet= 0 
   
  return @nRet
GO
