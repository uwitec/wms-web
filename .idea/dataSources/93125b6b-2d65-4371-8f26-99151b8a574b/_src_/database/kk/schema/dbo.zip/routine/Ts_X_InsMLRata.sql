
CREATE       PROCEDURE [Ts_X_InsMLRata]
 (  @ml_id int = 0,	
	@code varchar(20) ,
	@name  varchar(30),
	@pinyin  varchar(30),
	@minValue  [numeric](8, 2),
	@maxValue  [numeric](8, 2)
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
if @ml_id = 0 /*增加*/
  begin
	if exists(select 1 from mlRataRoom where code=@code)/*合法性检查*/
	begin
	 RAISERROR('编号重复！不能添加！！',16,1)
	 return -2
	end

	if exists(select 1 from mlRataRoom where name=@name)
	begin
	 RAISERROR('名称重复！不能添加！！',16,1)
	 return -2
	end


	INSERT INTO [mlRataRoom]
	([code] ,
	[name] ,
	[pinyin] ,
	[minValue] ,
	[maxValue] 
	  )	 
	VALUES 
	 (@code ,
	@name ,
	@pinyin ,
	@minValue ,
	@maxValue 
	  )
  end
 else
 begin
   update mlRataRoom set code = @code, name = @name, pinyin = @pinyin, 
                         minValue = @minValue, maxValue = @maxValue where ml_id = @ml_id
 end
 
 
 
if @@rowCount>0 
begin
 return @@identity
end
GO
