


CREATE PROCEDURE [dbo].[TS_G_MsgRule]
  @Rule INT
AS
BEGIN
  /*会员生日  500个*/
  IF @Rule = 1
  BEGIN
    SELECT TOP 500 * FROM VIPCard
     WHERE Tel <> ''
       AND substring(CONVERT(varchar(10),dateadd([DAY],-1,birthday),20),6,10) = substring(CONVERT(varchar(10),GETDATE(),20),6,10)
       AND VipCardID NOT IN (SELECT VipCardID
                         FROM SendDetail 
                        WHERE States = 1
                          AND year(InputDatetime) = YEAR(GETDATE())
                      )  	
  	
  	
  END
  
  /*长期用药提醒  500个*/
  IF @Rule = 6
  BEGIN
  	
	SELECT pe.p_id,pe.syts,pe.lcsl,p.name
	INTO #products
	FROM products p INNER JOIN productsExtend pe ON p.product_id = pe.p_id 
	WHERE syts > 0 AND lcsl > 0 
 
    /*select * from #products   drop table #products*/
	SELECT TOP 500
		   b.VIPCardID, 
	      v.Name VipName,v.Tel,
		   s.p_id,
		   tmp.name,
		   s.quantity,
		   s.RowGuid
	  FROM salemanagebill s INNER JOIN billidx b ON s.bill_id = b.billid
							INNER JOIN #products tmp ON s.p_id = tmp.p_id 
							INNER JOIN VIPCard v ON b.VIPCardID = v.VIPCardID 
	  WHERE s.Rowguid NOT IN (SELECT SendID FROM SendDetail)
		AND b.billstates = 0 AND b.billtype IN (12)
		AND v.Tel <> ''
		AND s.quantity >= tmp.lcsl
		AND DATEDIFF(DD,GETDATE(),DATEADD(DD, tmp.syts * s.quantity, b.billdate)) = 2 	
  	  	
  END  
END
GO
