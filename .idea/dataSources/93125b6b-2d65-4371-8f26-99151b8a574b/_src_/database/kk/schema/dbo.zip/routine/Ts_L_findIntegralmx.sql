Create  procedure Ts_L_findIntegralmx
(              
	@datestart   varchar(20),      /*开始日期*/
	@dateend     varchar(20),      /*结束日期*/
	@c_id        int,              /*会员卡ID*/
	@atype       int,              /* 1 主表数据  2 明细数据 */
	@y_id        int			   /*消费机构*/
)  
AS	

if @y_id is null set @y_id = 0

declare @cid1 int,@cid2 int
if @c_id=0  set  @cid1=0
else 
	set @cid1=@c_id
select @cid2=@cid1
if @cid1=0 set @cid2=2147483647  
 
if @atype = 1
begin
	select b.billid as id,a.VIPCardID,a.CardNo,a.Name,a.Tel,a.Address,b.billdate,
		b.ptotalItg,b.totalItg,(b.ptotalItg+b.totalItg) as Integral ,c.name as cname
	from VIPCard a,Integralidx b  
		left join billidx i on b.bill_id = i.billid 
		left join company c on i.Y_ID = c.company_id 
	where a.VIPCardID=b.VIPCardID  
		and b.billdate>=@datestart and b.billdate<=@dateend 
		and b.VIPCardID>=@cid1 and b.VIPCardID<=@cid2
		and (@y_id = 0 or i.Y_ID = @y_id)
end
else
begin
	SELECT   c.billid AS id, c.smb_id, 
		CASE WHEN a.p_id < 0 THEN '' ELSE b.serial_number END AS serial_number, 
		CASE WHEN a.p_id < 0 and isnull(c.remake,'') <>'扣除抵现金额的积分' THEN '积分抵现' when a.p_id < 0 then  isnull(c.remake,'')  ELSE b.name END AS name, 
		CASE WHEN a.p_id < 0 THEN '' ELSE b.alias END AS alias, 
		CASE WHEN a.p_id < 0 THEN '' ELSE b.makearea END AS makearea,
		CASE WHEN a.p_id < 0 THEN '' ELSE f.AccountComment END AS factoryname,  
		CASE WHEN a.p_id < 0 THEN '' ELSE b.standard END AS standard, c.totalmoney, c.baseItg, c.Itgrate, c.totalItg
	FROM      dbo.products AS b RIGHT OUTER JOIN
		dbo.salemanagebill AS a INNER JOIN
		dbo.Integralidx AS d INNER JOIN
		dbo.Integraldetail AS c ON d.billid = c.billid ON a.smb_id = c.smb_id ON b.product_id = a.p_id
		INNER JOIN billidx i on d.bill_id = i.billid 
		left join basefactory f on b.factoryc_id=f.CommID
	WHERE   (d.billdate >= @datestart) AND (d.billdate <= @dateend) AND (d.VIPCardID >= @cid1) AND (d.VIPCardID <= @cid2)
			and (@y_id = 0 or i.Y_ID = @y_id)
	ORDER BY id
end
GO
