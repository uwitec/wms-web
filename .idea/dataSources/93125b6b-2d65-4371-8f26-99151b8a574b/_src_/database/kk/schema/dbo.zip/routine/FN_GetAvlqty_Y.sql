
/* =============================================*/
/* Author:		*/
/* Create date: 2015.6.25*/
/* Description:	取得商品机构可开数量*/
/* =============================================*/
CREATE FUNCTION FN_GetAvlqty_Y 
(
	@PId int = 0,
	@YId int = 0
)
RETURNS numeric(25,8)
AS
BEGIN
	DECLARE @Qty numeric(25,8)
	SELECT @Qty = SUM(quantity) 
		FROM (SELECT quantity, Y_ID FROM dbo.fn_GetAvlQty(@PId, 0, '', 1)) a 
	WHERE a.Y_ID = @YId
	
	IF @Qty IS NULL
		SET @Qty = 0.00
	RETURN @Qty
END
GO
