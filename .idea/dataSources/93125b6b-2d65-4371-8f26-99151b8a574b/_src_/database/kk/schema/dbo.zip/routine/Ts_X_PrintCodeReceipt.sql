
create proc [dbo].[Ts_X_PrintCodeReceipt]
(
  @szbillid   VARCHAR(30) = '' /*条件(单据的id串)*/
)

AS

select P_id,P.name AS p_NAME,P.standard,GD.Batchno,P.Factory,isnull(GB.C_id,0) as C_id,gb.C_NAME,SUM(CheckQty) QTY 
		from GSPbilldetail gd 
		LEFT JOIN VW_GSPBILLIDX gb ON gd.Gspbill_id = gb.Gspbillid  
		LEFT JOIN products P ON GD.P_id = P.product_id  
		where billtype = 551  
		AND gd.Gspbill_id in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@szbillid))
		AND P.StoreCondition = 2
		group by P_id,P.name,P.standard,GD.Batchno,P.Factory,GB.C_id,gb.C_NAME
GO
