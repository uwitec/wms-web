
/******************************************

销售排行榜(按月份统计)

创建日期 2012-10-17

作者：yanrui
---单据类型
---select * from VchType where  Vch_ID in
---(10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211,212)
--  10,12,16,32,53,210
--  -11,13,17,54,211
********************************************/
CREATE PROCEDURE ts_c_qrSaleSortMonth
(	
    @BeginDate 	    DATETIME,/*开始时间*/
	@EndDate	 	DATETIME,/*结束时间*/
	@szC_ID     	int=0,/*客户ID*/
	@szE_ID	        int=0,/*经手人ID  ---2*/
	@szSS_ID	    int=0,/*库房ID*/
	@szP_ID	        int=0,/*产品ID*/
	@szInput_ID	    int=0,/*制单人ID*/
	@nLocation_Id   INT=0,/*货位ID*/
    @nY_id          int=0,/*机构  ---7*/
    @szDp_ID	    int=0,/*部门ID*/
    @szregion_id    int=0, /*片区 */
    @billtype       int=0, /*查询类型:0商品1客户2部门3职员4片区5仓库6货位7机构8供应商   */
    @nLargess       int=0, /*0 不统计赠品， 1 统计赠品*/
    @nbilltype      varchar(200), /*单据类型 (10,11,12,13,16,17,150,151,152,153)*/
    @szIDE          varchar(8000),  /*过滤客户类别*/
    @szIDP          varchar(8000),   /*过滤商品类别*/
    @MonthSum       int=0  /*0不按月度统计，1按月度统计     */
)
as
begin
  create  table #tmp 
  (
   Atype     varchar(10),
   billtype  int,
   e_id      int,
   inputman  int,
   region_id int,
   billdate  DATETIME,   
   jfrq      int,
   c_id      int,
   Y_ID      int,
   sout_id   int,
   bill_id   int,
   ss_id     int,
   quantity      numeric(25,8),
   costprice     numeric(25,8),
/*  totalcost     numeric(25,8),*/
/*   totalmoney    numeric(25,8),*/
   costtaxtotal  numeric(25,8),
   taxtotal      numeric(25,8),
   mlMoney       numeric(25,8),
   p_id          int,
   location_id   int,
   supplier_id   int,
   department_id int,
   Factory varchar(200)  
  )
/*--初始化参数*/
/*机构ID*/
declare  @y_id1 int,@y_id2 int 
select @y_id1=@nY_id,@y_id2=@y_id1
if @y_id1=0 select @y_id2=2147483647
/*经手人ID*/
declare  @e_id1 int,@e_id2 int 
select @e_id1=@szE_ID,@e_id2=@e_id1
if @e_id1=0 select @e_id2=2147483647
/*-*/
 Create table #jfrqtmp(szjfrq varchar(10)) 


  /*新自定义类别的解析，获取过滤的商品id*/
    DECLARE @PColName VARCHAR(100)
    set @PColName = ''
    CREATE TABLE #TmpP ([Pid] [int] NOT NULL DEFAULT(0))
    IF @szIDP <> ''
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @Pclassid varchar(100)
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szIDP))
    
	  SELECT @Pclassid = dbo.GetCateClassids(@szIDP)
    
      IF @Pclassid IS NULL SET @Pclassid = ''
      IF LEN(@Pclassid) > 0
      SET @Pclassid = LEFT(@Pclassid,LEN(@Pclassid)-1)
    
      set @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')  
      set @PszSql =  'INSERT INTO #TmpP(pid) ' +
		'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @PColName + 
		' in (select type  from DecodeStr(''' +@Pclassid +'''))'  
	  exec (@PszSql)        
    END
	
    /*新自定义类别的解析，获取过滤的单位id*/
    DECLARE @CColName VARCHAR(100)
    set @CColName = ''
    CREATE TABLE #TmpC ([Cid] [int] NOT NULL DEFAULT(0))
    IF @szIDE <> ''
    BEGIN   
      DECLARE @Cinfo_ID INT
      DECLARE @Cclassid varchar(100)
      DECLARE @CszSql varchar(2000)
      SELECT @Cinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szIDE))
    
	  SELECT @Cclassid = dbo.GetCateClassids(@szIDE)
    
      IF @Cclassid IS NULL SET @Cclassid = ''
      IF LEN(@Cclassid) > 0
      SET @Cclassid = LEFT(@Cclassid,LEN(@Cclassid)-1)
    
      set @cColName = dbo.GetColName(@Cinfo_ID,'ClientCategory')  
      set @CszSql =  'INSERT INTO #TmpC(Cid) ' +
		'select c.Client_id from Clients c,ClientCategory cc where c.Client_id = cc.C_id and cc.' + @CColName + 
		' in (select type  from DecodeStr(''' +@Cclassid +'''))'  
	  exec (@CszSql)        
    END


  IF @nLargess = 0
  BEGIN
		insert into #tmp(Atype,billtype,e_id,inputman,region_id,billdate,jfrq,c_id,Y_ID,sout_id,bill_id,ss_id,quantity,costprice,costtaxtotal,taxtotal,mlMoney,
	   p_id,location_id,supplier_id,department_id,Factory)
	   select '1',y.billtype,y.e_id,y.inputman,y.region_id,y.billdate,
	   y.jfrq,
	   y.c_id,y.Y_ID,y.sout_id,y.bill_id,y.ss_id,
	   y.quantity, 
	   y.costprice,  
/*	   y.totalcost,   */
/*	   y.totalmoney,*/
	   y.costtaxtotal,
	   y.taxtotal,
	   y.mlMoney,
	   y.p_id,y.location_id,y.supplier_id,y.department_id,y.Factory
	 from
	 (
	   select a.billtype,b.RowE_id as e_id,a.inputman,a.region_id,a.billdate,
	   convert(int,CONVERT(varchar(6),a.billdate,112)) as jfrq,
	   a.c_id,a.Y_ID,a.sout_id,b.bill_id,b.ss_id,
	   /*b.quantity,*/
	   /*(b.quantity*b.costprice) as totalcost,*/
	   /*b.totalmoney,*/
	   (case when a.billtype IN (10,12,16,150,152) then b.quantity else -b.quantity end)quantity, 
	   b.costprice,  
	   (case when a.billtype IN (10,12,16,150,152) then (b.quantity*b.costprice) else -(b.quantity*b.costprice) end) totalcost,   
	   (case when a.billtype IN (10,12,16,150,152) then b.totalmoney else -b.totalmoney end)totalmoney,
	   (case when a.billtype IN (10,12,16,150,152) then b.costtaxtotal else -b.costtaxtotal end)costtaxtotal,
	   (case when a.billtype IN (10,12,16,150,152) then b.taxtotal else -b.taxtotal end)taxtotal,
	   (case when a.billtype IN (10,12,16,150,152) then taxtotal-costtaxtotal else -(taxtotal-costtaxtotal) end) as mlMoney,
	   b.p_id,b.location_id,b.supplier_id,a.department_id,isnull(c.AccountComment,'') as Factory 
	   from billidx a left join salemanagebill b on a.billid=b.bill_id
	        left join BaseFactory c on c.CommID = b.factoryid
	         where b.p_id>0 
			 and b.aoid in (0,5) and a.billstates=0
			 and a.billtype in (select szTYPE from DecodeToStr(@nbilltype))
			 /*and a.billtype in(10,11,12,13,16,17,32,53,54,210,211,212)*/
			 and a.billdate>=@BeginDate and a.billdate<=@EndDate
			 and ((@nY_id = 0) or (a.Y_ID = @nY_id))
			 and ((@szE_ID = 0) or (b.RowE_id = @szE_ID))
			 and ((@szInput_ID = 0) or (a.inputman = @szInput_ID))
			 and ((@szSS_ID = 0) or (b.ss_id = @szSS_ID))
			 and ((@nLocation_Id = 0) or (b.location_id = @nLocation_Id))
			 and ((@szIDE = '') or (a.c_id in (select Cid from #TmpC))) /*过滤客户类别*/
			 and ((@szIDP = '') or (b.p_id in (select Pid from #TmpP))) /*过滤商品类别  */
			 /*and a.Y_ID>=@y_id1  and a.Y_ID<=@y_id2*/
			 /*and a.e_id>=@e_id1  and a.e_id<=@e_id2*/
			 
	  ) y	
  END
  ELSE
  BEGIN
		insert into #tmp(Atype,billtype,e_id,inputman,region_id,billdate,jfrq,c_id,Y_ID,sout_id,bill_id,ss_id,quantity,costprice,costtaxtotal,taxtotal,mlMoney,
	   p_id,location_id,supplier_id,department_id,Factory)
	   select '1',y.billtype,y.e_id,y.inputman,y.region_id,y.billdate,
	   y.jfrq,
	   y.c_id,y.Y_ID,y.sout_id,y.bill_id,y.ss_id,
	   y.quantity, 
	   y.costprice,  
/*	   y.totalcost,   */
/*	   y.totalmoney,*/
	   y.costtaxtotal,
	   y.taxtotal,
	   y.mlMoney,
	   y.p_id,y.location_id,y.supplier_id,y.department_id,y.Factory
	 from
	 (
	   select a.billtype,b.RowE_id as e_id,a.inputman,a.region_id,a.billdate,
	   convert(int,CONVERT(varchar(6),a.billdate,112)) as jfrq,
	   a.c_id,a.Y_ID,a.sout_id,b.bill_id,b.ss_id,
	   /*b.quantity,*/
	   /*(b.quantity*b.costprice) as totalcost,*/
	   /*b.totalmoney,*/
	   (case when a.billtype IN (10,12,16,150,152) then b.quantity else -b.quantity end)quantity, 
	   b.costprice,  
	   (case when a.billtype IN (10,12,16,150,152) then (b.quantity*b.costprice) else -(b.quantity*b.costprice) end)totalcost,   
	   (case when a.billtype IN (10,12,16,150,152) then (CASE WHEN b.aoid = 7 THEN 0 ELSE b.totalmoney END) else -(CASE WHEN b.aoid = 7 THEN 0 ELSE b.totalmoney END) end)totalmoney,
	   (case when a.billtype IN (10,12,16,150,152) then b.costtaxtotal else -b.costtaxtotal end)costtaxtotal,
	   (case when a.billtype IN (10,12,16,150,152) then (case when b.AOID = 7 then 0 else b.taxtotal end ) else -(Case when b.aoid = 7 then 0 else  b.taxtotal end) end)taxtotal,
	   (case when a.billtype IN (10,12,16,150,152) then taxtotal-costtaxtotal else -(taxtotal-costtaxtotal) end) as mlMoney,
	   b.p_id,b.location_id,b.supplier_id,a.department_id,isnull(c.AccountComment,'') as Factory
	   from billidx a left join salemanagebill b on a.billid=b.bill_id
	        left join BaseFactory c on c.CommID = b.factoryid 
	         where b.p_id>0 
			 and b.aoid in (0,5,7) and a.billstates=0
			 and a.billtype in (select szTYPE from DecodeToStr(@nbilltype))
			 /*and a.billtype in(10,11,12,13,16,17,32,53,54,210,211,212)*/
			 and a.billdate>=@BeginDate and a.billdate<=@EndDate
			 and ((@nY_id = 0) or (a.Y_ID = @nY_id))
			 and ((@szE_ID = 0) or (b.RowE_id = @szE_ID))
			 and ((@szInput_ID = 0) or (a.inputman = @szInput_ID))
			 and ((@szSS_ID = 0) or (b.ss_id = @szSS_ID))
			 and ((@nLocation_Id = 0) or (b.location_id = @nLocation_Id))
			 and ((@szIDE = '') or (a.c_id in (select Cid from #TmpC))) /*过滤客户类别*/
			 and ((@szIDP = '') or (b.p_id in (select Pid from #TmpP))) /*过滤商品类别 */
			 /*and a.Y_ID>=@y_id1  and a.Y_ID<=@y_id2*/
			 /*and a.e_id>=@e_id1  and a.e_id<=@e_id2*/
	  ) y	
  END
  
if @MonthSum = 1 /*按月度统计*/
begin
 /*---生成计费月份*/
 insert into #jfrqtmp
 select distinct jfrq  from  #tmp where Atype='1'  order by jfrq

 /*--按照商品合计*/
 /**/
 if @billtype =0
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq,Factory)
   select '2',p_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq,Factory
   from #tmp
   where Atype='1'
   group by p_id,jfrq,Factory
 end
 if @billtype =1
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',c_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by c_id,jfrq   
   order by jfrq 
 end 
 if @billtype =2
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',department_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by department_id,jfrq   
 end 
 if @billtype =3
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',e_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by e_id,jfrq   
 end  
 if @billtype =4
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',region_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by region_id,jfrq   
 end 
 if @billtype =5
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',ss_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by ss_id,jfrq   
 end 
 if @billtype =6
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',location_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by location_id,jfrq   
 end 
 if @billtype =7
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',Y_ID,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by Y_ID,jfrq   
 end
 if @billtype =8
 begin
   insert into #tmp(Atype,p_id,quantity,costtaxtotal,taxtotal,mlMoney,jfrq)
   select '2',supplier_id,SUM(quantity) as quantity,
   /*SUM(totalcost) as totalcost,*/
   /*SUM(totalmoney)as totalmoney,*/
   SUM(costtaxtotal) as costtaxtotal,SUM(taxtotal) as taxtotal,
   SUM(mlMoney) as mlMoney,jfrq
   from #tmp
   where Atype='1'
   group by supplier_id,jfrq   
 end 
 /*---*/
 delete #tmp where Atype='1' 
 /*-----------------------生成计费月份字段   WITH VALUES*/
 
 declare @iFor int,@A_rows int 
 declare @col varchar(80)
 declare @SQL varchar(5000)
 declare @SSQL varchar(5000)
 declare @MSQL varchar(5000)
 set @SSQL=''
 set @MSQL=''
 declare curAlter scroll cursor for
 select szjfrq from #jfrqtmp
 open curAlter
 set @iFor = 0
 set @A_rows=@@cursor_rows
 while @iFor < @A_rows
 begin
   fetch next from curAlter into @col
   /*---数量*/
   set @SQL=' ALTER  TABLE  #tmp  ADD  '+'[A'+@col+']'+'  numeric(25,8) NOT NULL DEFAULT 0   '
   set @SSQL=@SSQL+',[A'+@col+']'
   set @MSQL=@MSQL+',SUM([A'+@col+'])'
   exec(@SQL) 
   /*修改数据   */
    set @SQL=' update #tmp set [A'+@col+']=b.quantity  from  #tmp a,(select P_ID,jfrq,quantity from #tmp  '
    set @SQL=@SQL+' where jfrq='+@col+ ') b ' 
    set @SQL=@SQL+' where a.p_id=b.p_id and a.jfrq='+@col
  /* select @SQL */
   exec(@SQL) 
   /*select * from #tmp*/
   /*---成本金额*/
   set @SQL=' ALTER  TABLE  #tmp  ADD  '+'[B'+@col+']'+'  numeric(25,8) NOT NULL DEFAULT 0   '
   set @SSQL=@SSQL+',[B'+@col+']'
   set @MSQL=@MSQL+',SUM([B'+@col+'])'
   exec(@SQL) 
   /*修改数据*/
   set @SQL=' update #tmp set [B'+@col+']=b.costtaxtotal  from  #tmp a,(select P_ID,jfrq,costtaxtotal from #tmp  '
   set @SQL=@SQL+' where jfrq='+@col+ ') b ' 
   set @SQL=@SQL+' where a.p_id=b.p_id and a.jfrq='+@col
   exec(@SQL)    
   /*---销售金额 */
   set @SQL=' ALTER  TABLE  #tmp  ADD  '+'[C'+@col+']'+'  numeric(25,8) NOT NULL DEFAULT 0   '
   set @SSQL=@SSQL+',[C'+@col+']'
   set @MSQL=@MSQL+',SUM([C'+@col+'])'
   exec(@SQL) 
   /*修改数据*/
   set @SQL=' update #tmp set [C'+@col+']=b.taxtotal  from  #tmp a,(select P_ID,jfrq,taxtotal from #tmp  '
   set @SQL=@SQL+' where jfrq='+@col+ ') b ' 
   set @SQL=@SQL+' where a.p_id=b.p_id and a.jfrq='+@col
   exec(@SQL)
   /*--毛利*/
   set @SQL=' ALTER  TABLE  #tmp  ADD  '+'[D'+@col+']'+'  numeric(25,8) NOT NULL DEFAULT 0   '
   set @SSQL=@SSQL+',[D'+@col+']'
   set @MSQL=@MSQL+',SUM([D'+@col+'])'
   exec(@SQL) 
   /*set @SQL=' update #tmp set [D'+@col+']='+'([C'+@col+']-[B'+@col+'])' +'from  #tmp '*/
   set @SQL=' update #tmp set [D'+@col+']=b.mlMoney from  #tmp a,(select P_ID,jfrq,mlMoney from #tmp  '
   set @SQL=@SQL+' where jfrq='+@col+ ') b '
   set @SQL=@SQL+' where a.p_id=b.p_id and a.jfrq='+@col 
   exec(@SQL)
   /*--毛利率*/
   set @SQL=' ALTER  TABLE  #tmp  ADD  '+'[E'+@col+']'+'  numeric(25,8) NOT NULL DEFAULT 0   '
   set @SSQL=@SSQL+',[E'+@col+']'
   set @MSQL=@MSQL+',SUM([E'+@col+'])'
   exec(@SQL)     
   set @SQL=' update #tmp set [E'+@col+']='+'([D'+@col+']/[C'+@col+']*100)' +'from  #tmp where [C'+@col+']<>0'
   exec(@SQL)   
  
   set @iFor = @iFor + 1
 end 
 DEALLOCATE curAlter
 /**/
 /*-生成条件*/
 if @SSQL<>''
 begin
   set @SQL=' insert into #tmp(p_id,Factory'+@SSQL+')'
   set @SQL=@SQL+' select p_id,Factory'+@MSQL+' from #tmp group by p_id,Factory'
   /*select @SQL*/
   exec(@SQL)
 end 
 delete #tmp  where Atype='2'
 /*--查询*/
 if @billtype =0
 begin
   set @SQL='  select 0 as serialno,b.serial_number as code,b.name,b.[standard],b.makearea,a.Factory'+@SSQL
   set @SQL=@SQL+'  from #tmp a left join products b on a.p_id=b.product_id order by a.p_id'
 end
 if @billtype =1
 begin
   set @SQL='  select  0 as serialno,b.serial_number as  code,b.name,b.contact_personal,b.[address]'+@SSQL
   set @SQL=@SQL+'  from #tmp a,vw_Clients b where a.p_id=b.client_id order by a.p_id'
 end 
 if @billtype =2
 begin
   set @SQL='  select  0 as serialno,b.serial_number as  code,b.name'+@SSQL
   set @SQL=@SQL+'  from #tmp a,department b where a.p_id=b.departmentId order by a.p_id'
 end 
 if @billtype =3
 begin
   set @SQL='  select  0 as serialno,b.serial_number as  code,b.name,b.[address],b.phone'+@SSQL
   set @SQL=@SQL+'  from #tmp a,employees b where a.p_id=b.emp_id order by a.p_id'
 end 
 if @billtype =4
 begin
   set @SQL='  select 0 as serialno,b.serial_number as  code,b.name'+@SSQL
   set @SQL=@SQL+'  from #tmp a,Region b where a.p_id=b.region_id order by a.p_id'
 end
 if @billtype =5
 begin
   set @SQL='  select  0 as serialno,b.serial_number as  code,b.name'+@SSQL
   set @SQL=@SQL+'  from #tmp a,storages b where a.p_id=b.storage_id order by a.p_id'
 end 
 if @billtype =6
 begin
   set @SQL='  select   0 as serialno,b.loc_code as  code,b.loc_name as name,c.name as ck_name'+@SSQL
   set @SQL=@SQL+'  from #tmp a,location b,storages c  where a.p_id=b.loc_id  and b.s_id=c.storage_id order by c.storage_id,a.p_id'
 end 
 if @billtype =7
 begin
   set @SQL='  select  0 as serialno,b.serial_number as  code,b.name'+@SSQL
   set @SQL=@SQL+'  from #tmp a,company b where a.p_id=b.company_id order by a.p_id'
 end 
 if @billtype =8
 begin
   set @SQL='  select 0 as serialno,b.name,b.contact_personal,b.[address],phone_number'+@SSQL
   set @SQL=@SQL+'  from #tmp a,clients b where a.p_id=b.client_id order by a.p_id'
 end   
 /*-------------------*/
/* print @SQL*/
 exec(@SQL) 
end
else  /*不按月度统计 @MonthSum = 0 */
begin
   if @billtype = 0 /*按商品*/
   begin
     select 0 as serialno,p.serial_number as code,p.name,p.[standard],p.makearea,a.Factory,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from
     (select p_id,Factory,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll
      from #tmp group by p_id,Factory) a left join products p on a.p_id = p.product_id order by a.p_id
   end
   if @billtype = 1 /*按客户*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,b.contact_personal,b.address,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select c_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll
      from #tmp group by c_id) a left join vw_Clients b on a.c_id = b.client_id order by a.c_id
   end
     
   if @billtype = 2 /*按部门*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select department_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll      
      from #tmp group by department_id) a left join department b on a.department_id = b.departmentId order by a.department_id
   end
   if @billtype = 3 /*按职员*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,b.address,b.phone,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select e_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll     
      from #tmp group by e_id) a left join employees b on a.e_id = b.emp_id  order by a.e_id
   end 
     
   if @billtype = 4 /*按片区*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select region_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll     
      from #tmp group by region_id) a left join Region b on a.region_id = b.region_id order by a.region_id
   end 
     
   if @billtype = 5 /*按仓库*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select ss_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll      
      from #tmp group by ss_id) a left join storages b on a.ss_id = b.storage_id order by a.ss_id  
   end 
     
   if @billtype = 6 /*按货位*/
   begin
     select 0 as serialno,b.loc_code as code,b.loc_name as name,c.name as ck_name,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select location_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll      
      from #tmp group by location_id) a left join location b on a.location_id = b.loc_id 
                                        left join storages c on c.storage_id = b.s_id  order by c.storage_id,a.location_id
   end  
    
   if @billtype = 7 /*按机构*/
   begin
     select 0 as serialno,b.serial_number as code,b.name,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select Y_ID,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll      
      from #tmp group by Y_ID) a left join company b on a.Y_ID = b.company_id  order by a.Y_ID
   end 
   
   if @billtype = 8 /*按供应商*/
   begin
     select 0 as serialno,b.name,b.contact_personal,b.address,b.phone_number,a.quantity,a.costtaxtotal,a.taxtotal,a.ml,a.mll from 
     (select supplier_id,isnull(SUM(quantity),0) as quantity,isnull(SUM(costtaxtotal),0) as costtaxtotal,
      isnull(SUM(taxtotal),0) as taxtotal,
      isnull(SUM(mlMoney),0) as ml,
      ((isnull(SUM(taxtotal),0)-isnull(SUM(costtaxtotal),0))*100)/nullif(ISNULL(sum(taxtotal),0),0) as mll     
      from #tmp group by supplier_id) a left join vw_Clients b on a.supplier_id = b.client_id order by a.supplier_id  
   end    
end 
 drop table #tmp
 drop table #jfrqtmp 
end
GO
