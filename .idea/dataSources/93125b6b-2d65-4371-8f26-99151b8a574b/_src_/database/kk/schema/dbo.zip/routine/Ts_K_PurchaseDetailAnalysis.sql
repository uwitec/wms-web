

CREATE PROCEDURE Ts_K_PurchaseDetailAnalysis(
	@Begin                DATETIME, 
	@End                  DATETIME, 
	@YId                  INT, 
	@PId                  INT, 
	@SupplierId           INT, 
	@Factory              VARCHAR(100), 
	@EId                  INT, 
	@CgId                 INT, 
	@szID                 VARCHAR(3000),
    @CCgId                 INT, 
	@szCID                 VARCHAR(3000),
	@nloginEID int = 0,     /*当前登陆职员*/
	@strBusinessType varchar(50) = '0'
)
AS
BEGIN
	DECLARE @BaseType INT
	DECLARE @ClassId VARCHAR(30)
	Declare @Companytable INTEGER
	
	set @strBusinessType = @strBusinessType+',5'
	create table #Companytable([id] int)
	

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

	
  /*新自定义类别的解析，获取过滤的商品id*/
    DECLARE @PColName VARCHAR(100)
    set @PColName = ''
    CREATE TABLE #TmpP ([Pid] [int] NOT NULL DEFAULT(0))
    IF @szID = ''
       INSERT INTO #TmpP(PId) SELECT product_id FROM vw_Products
    ELSE
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @Pclassid varchar(100)
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szID))
    
	  SELECT @Pclassid = dbo.GetCateClassids(@szID)
    
      IF @Pclassid IS NULL SET @Pclassid = ''
      IF LEN(@Pclassid) > 0
      SET @Pclassid = LEFT(@Pclassid,LEN(@Pclassid)-1)
    
      set @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')  
      set @PszSql =  'INSERT INTO #TmpP(pid) ' +
		'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @PColName + 
		' in (select type  from DecodeStr(''' +@Pclassid +'''))'  
	  exec (@PszSql)        
    END
	
    /*新自定义类别的解析，获取过滤的单位id*/
    DECLARE @CColName VARCHAR(100)
    set @CColName = ''
    CREATE TABLE #TmpC ([Cid] [int] NOT NULL DEFAULT(0))
    IF @szCID = ''
       INSERT INTO #TmpC(Cid) SELECT client_id FROM vw_Clients
    ELSE
    BEGIN   
      DECLARE @Cinfo_ID INT
      DECLARE @Cclassid varchar(100)
      DECLARE @CszSql varchar(2000)
      SELECT @Cinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szCID))
    
	  SELECT @Cclassid = dbo.GetCateClassids(@szCID)
    
      IF @Cclassid IS NULL SET @Cclassid = ''
      IF LEN(@Cclassid) > 0
      SET @Cclassid = LEFT(@Cclassid,LEN(@Cclassid)-1)
    
      set @cColName = dbo.GetColName(@Cinfo_ID,'ClientCategory')  
      set @CszSql =  'INSERT INTO #TmpC(Cid) ' +
		'select c.Client_id from Clients c,ClientCategory cc where c.Client_id = cc.C_id and cc.' + @CColName + 
		' in (select type  from DecodeStr(''' +@Cclassid +'''))'  
	  exec (@CszSql)        
    END
	
	SELECT s.smb_id AS KeyId, s.p_id AS PId, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea,p.comment, u.name AS UnitName, ISNULL(f.AccountComment, '') AS Factory, 
	       b.billnumber, s.instoretime,
	       CASE WHEN s.makedate < 10 THEN '' ELSE CONVERT(varchar(100), s.makedate, 23) END AS MakeDate, s.batchno, 
	       CASE WHEN s.validdate < 10 THEN '' ELSE CONVERT(varchar(100), s.validdate, 23) END AS ValidDate,
	       s.quantity,s.buyprice, s.total, s.taxrate * 100 AS taxrate, s.taxprice, s.taxtotal,  
	       e.name AS EName, CASE WHEN b.billtype IN (20) THEN c.name ELSE y.name END AS SupplierName 
		FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		               INNER JOIN products p ON s.p_id = p.product_id
		               INNER JOIN unit u ON p.unit1_id = u.unit_id
		               INNER JOIN employees e ON b.e_id = e.emp_id
		               LEFT JOIN clients c ON s.supplier_id = c.client_id
		               LEFT JOIN company y ON b.c_id = y.company_id
		               INNER JOIN #TmpP pp ON s.p_id = pp.PId
		               INNER JOIN #TmpC cc ON s.supplier_id = cc.CId
		               LEFT JOIN BaseFactory f ON s.factoryid = f.CommID
	WHERE b.billtype IN (20,35,220) AND b.billstates = 0 
	      AND s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
	      AND b.billdate BETWEEN @Begin AND @End AND
	      b.Y_ID = @YId AND (@EId = 0 OR @EId = b.e_id) AND (@SupplierId = 0 OR @SupplierId = s.supplier_id) AND
	      (@PId = 0 OR @PId = s.p_id) AND (@Factory = '' OR p.Factory LIKE '%' + @Factory + '%')
	      and ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable)))
END
GO
