
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

/*商品授权判断 add by yh 2014-10-08*/
if exists(select * from userauthorize where type='p' and e_id=@UserId)
begin
  select @userP_id=id from userauthorize where type='p' and e_id=@UserId 
  if (@userP_id<>1 )  and (Upper(@TableName)='PRODUCTS')
  begin
   set  @szWhere=@szWhere+' and ((product_id in (select id from userauthorize where type=''p'' and e_id='+cast(@UserId as varchar(20)) 
                 +')) or (parent_id in (select class_id from products where product_id in (select id from userauthorize where type=''p'' '+
                 'and e_id='+cast(@UserId as varchar(20)) +'))))';
  end
end
/*查询正常商品时过滤拆零后的商品 add by luowei 2013-06-06*/

 if (Upper(@TableName)='PRODUCTS') and (CHARINDEX('IsSplit',@szWhere) <= 0) 
   set @szWhere = @szWhere + ' and IsSplit = 0 '  


/*机构ID*/
/* declare @nY_ID int*/
/* set @nY_ID=0*/
/* select @nY_ID=isnull(sysvalue,0) from sysconfig where sysname='Y_ID'*/
/**/
if upper(@tablename) = 'SPECIALPRODUCTS'
begin
  exec ts_L_SelProducts_SPECIALPRODUCTS @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
else
if UPPER(@TableName)='ProductBlacklist'/*-商品黑名单*/
begin
  exec ts_L_SelProducts_ProductBlacklist @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
else
if Upper(@TableName)='GLPRODUCTS'
begin
  exec ts_L_SelProducts_GLPRODUCTS @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
else
if Upper(@TableName)='PRODUCTS'
begin
  exec ts_L_SelProducts_PRODUCTS @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end

IF UPPER(@TableName) = 'EMPLOYEES'
BEGIN
  exec ts_L_SelProducts_EMPLOYEES @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
END

if Upper(@TableName)='REGION'
begin
  exec ts_L_SelProducts_REGION @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end



if Upper(@TableName)='CLIENTS'
begin
  exec ts_L_SelProducts_CLIENTS @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
if Upper(@TableName)='STORAGES'
begin
  exec ts_L_SelProducts_STORAGES @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
if Upper(@TableName)='ACCOUNT'
begin
  exec ts_L_SelProducts_ACCOUNT @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end

if Upper(@tablename)='COMPANY'
begin
  exec ts_L_SelProducts_COMPANY @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end


if UPPER(@TableName)='XJPRODUCTS'  
begin

  exec ts_L_SelProducts_XJPRODUCTS @TableName,@Parent_id,@szWhere,@E_id,@szListFlag,@nShowStatus,@nFilterY,@nY_id,@UserId
end
GO
