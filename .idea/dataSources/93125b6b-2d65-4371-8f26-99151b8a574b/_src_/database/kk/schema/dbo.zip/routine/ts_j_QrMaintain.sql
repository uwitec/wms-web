
CREATE PROCEDURE [dbo].[ts_j_QrMaintain] 
(
  @nSid int,
  @nPid int,
  @szPClassid varchar(50),
  @nLid int,
  @nNearValid int, /*近效期商品*/
  @nKeyProduct int,/*重点养护品种*/
  @nFirst int, /*首营品种*/
  @nMaintain int, /*最近一次的重点养护品种确认表  */
  @szGspPropert varchar(200),
  @nMedType int, /*剂型*/
  @dQty NUMERIC(25,8)    /*库存数量*/
)

AS  
 
  SELECT p.code, p.Unit3Name, 
      p.Unit2Name, p.Unit4Name, 
      p.LatinName, p.ChemName, 
      p.EngName, p.medtype, p.pinyin, 
      p.makearea, p.trademark, 
      p.permitcode, p.modal, p.standard, 
      p.alias, p.name, p.serial_number, 
      p.class_id, p.product_id, s.batchno, 
      p.Posyhday, 
      s.makedate, s.validdate,s.location_id,
      SUM(s.costtotal) AS costtotal, SUM(s.costprice) AS costPrice, 
      SUM(s.quantity) AS quantity, p.MedName, 
      p.Unit1Name, s.s_id, s.yhdate, 
      s.instoretime, s.supplier_id, ISNULL(c.name, 'abc') 
      AS CName, p.MaintainType, p.MaintainDay, 
      p.validmonth, p.validday, p.gspflag, 
      ISNULL(st.name, 'abc') AS sName,p.Factory, p.StorageCon,
      p.PackStd
FROM dbo.vw_Products p INNER JOIN
      dbo.storehouse s ON 
      p.product_id = s.p_id LEFT OUTER JOIN
      dbo.storages st ON s.s_id = st.storage_id LEFT OUTER JOIN
      dbo.clients c ON s.supplier_id = c.client_id           
      where ((@nPid <> 0 and left(p.Class_id, len(@szPClassid)) = @szPClassid) or (@nPid = 0)) and
            ((@nSid <> 0 and s.s_id= @nSid) or (@nSid = 0)) and 
            ((@nLid <> 0 and s.location_id = @nLid) or (@nLid = 0)) and
            ((@nMedType > 0 and p.medtype = @nMedType) or (@nMedType <= 0)) and
            ((@dQty <>0 and s.quantity >= @dQty) or (@dQty=0)) and          
            (p.gspflag in (select [TYPE] from dbo.decodestr(@szGspPropert))) and
				((@nFirst<>0 and p.firstcheck = 1) or (@nKeyProduct <> 0 and p.MaintainType = 1) or
				 (@nMaintain<>0 and p.product_id in (select p_id from GspMaintainP)) or
				 (@nNearValid <>0 and s.validdate <= (getdate() + 183)) and s.validdate > 5)				                                                 
GROUP BY p.code, p.Unit3Name, 
      p.Unit2Name, p.Unit4Name, 
      p.LatinName, p.ChemName, 
      p.EngName, p.medtype, p.pinyin, 
      p.makearea, p.trademark, 
      p.permitcode, p.modal, p.standard, 
      p.alias, p.name, p.serial_number, 
      p.class_id, p.product_id, s.batchno, 
      p.Posyhday, 
      s.makedate, s.validdate, p.MedName, 
      p.Unit1Name, s.s_id, s.yhdate, 
      s.instoretime, s.supplier_id, c.name, 
      p.MaintainType, p.MaintainDay, 
      p.validmonth, p.validday, p.gspflag, 
      st.name,p.Factory,s.location_id, p.StorageCon,
      p.PackStd
GO
