
CREATE	  PROCEDURE [Ts_L_InUpProductsExt]
   (@product_id	int,
	@sfcl   int,
	@cldw   int,
	@hsbl int ,
	@cljg NUMERIC(18,2) ,
	@lcsl int,
	@syts int,
	@zzl  int,
	@qhsl int,
	@psjs  int,
	@zycf nvarchar(200),
	@gnzz nvarchar(200),
	@yfyl nvarchar(200),
	@cu nvarchar(50),
	@ku nvarchar(50),
	@gu nvarchar(50),
	@mzu nvarchar(50),
	@cu1 nvarchar(50),
	@ku1 nvarchar(50),
	@gu1 nvarchar(50),
	@mzu1 nvarchar(50),
	@cu2 nvarchar(50),
	@ku2 nvarchar(50),
	@gu2 nvarchar(50),
	@mzu2 nvarchar(50),
	@cu3 nvarchar(50),
	@ku3 nvarchar(50),
	@gu3 nvarchar(50),
	@mzu3 nvarchar(50)
	)
as  
	set @product_id = ABS(@product_id)
 declare @cts int
 set @cts=(select count(Exid) from productsExtend where p_id=@product_id)	
 if  @cts>0 
 begin
    UPDATE [productsExtend] 
	SET  
    sfcl=@sfcl,
	cldw=@cldw,
	hsbl=@hsbl,
	cljg=@cljg,
	lcsl=@lcsl,
	syts=@syts,
	zzl=@zzl,
	qhsl=@qhsl,
	psjs=@psjs,
	zycf=@zycf ,
	gnzz=@gnzz ,
	yfyl=@yfyl ,
	cu=@cu ,
	ku=@ku ,
	gu=@gu ,
	mzu=@mzu ,
	cu1=@cu1 ,
	ku1=@ku1,
	gu1=@gu1 ,
	mzu1=@mzu1 ,
	cu2=@cu2 ,
	ku2=@ku2 ,
	gu2=@gu2 ,
	mzu2=@mzu2 ,
	cu3=@cu3 ,
	ku3=@ku3 ,
	gu3=@gu3 ,
	mzu3=@mzu3 
    WHERE  ( P_id = @product_id)           
 end
 else
 begin
    insert into  productsExtend 
	(
	p_id,
    sfcl,
	cldw,
	hsbl,
	cljg,
	lcsl,
	syts,
	zzl,
	qhsl,
	psjs,
	zycf,
	gnzz,
	yfyl,
	cu,
	ku,
	gu,
	mzu,
	cu1,
	ku1,
	gu1,
	mzu1,
	cu2,
	ku2,
	gu2,
	mzu2,
	cu3,
	ku3,
	gu3,
	mzu3
	)
	VALUES
	(
	@product_id,
    @sfcl,
	@cldw,
	@hsbl,
	@cljg,
	@lcsl,
	@syts,
	@zzl,
	@qhsl,
	@psjs,
	@zycf ,
	@gnzz ,
	@yfyl ,
	@cu ,
	@ku ,
	@gu ,
	@mzu ,
	@cu1 ,
	@ku1,
	@gu1 ,
	@mzu1 ,
	@cu2 ,
	@ku2 ,
	@gu2 ,
	@mzu2 ,
	@cu3 ,
	@ku3 ,
	@gu3 ,
	@mzu3
	)  
 end
 
 if @sfcl = 1 
 begin
   declare @pclass_id varchar(100)
   select @pclass_id =class_id  from products where Custompro1 in (select class_id from products where product_id = @product_id)
   if not exists(select 1 from products where class_id = @pclass_id and IsSplit = 1)
   begin
   declare  @tempId  varchar(30),
   @child_number  int,
   @child_count int,
   @newP_id  int,
   @SplitP_id int,
   @Parent_id varchar(30)
   
   set @SplitP_id = 0
      
   select @Parent_id = parent_id from products where product_id = @product_id
/*取得ID号*/
	select @tempid=classid,@child_number=childnumber,@child_count=childCount 
	from Getid(@Parent_id,'Products')
	if @@rowcount=0
	begin
	 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
	 return-1
	end
   
      /*-写入拆零后的商品信息(使用Custompro1存储原单class_id)*/
	  insert products(class_id,parent_id,child_number,child_count,serial_number,name,alias,standard,
					modal,permitcode,trademark,makearea,unit1_id,rate2,validmonth,validday,comment,
					deleted,pinyin,firstcheck,validcheck,otcflag,medtype,costmethod,EngName,ChemName,
					LatinName,deduct,OTCType,GMP,Gross,MaintainType,MaintainDay,r_id,PackStd,StorageCon,
					TaxRate,BulidNo,RegisterNo,tcmoney,TC1,TC2,Profit,ifIntegral,factory,TcCost,PosYhDay,
					PrintClass,WholeUnit_id,Inputdate,Inputman,factoryc_id,alert,Registervalid,Custompro1,
					PerCodevalid,AuditStates,IsSplit)
					select @tempid,parent_id,0,0,serial_number,name,alias,standard,
					modal,permitcode,trademark,makearea,productsExtend.cldw,rate2,validmonth,validday,comment,
					0,pinyin,firstcheck,validcheck,otcflag,medtype,costmethod,EngName,ChemName,
					LatinName,deduct,OTCType,GMP,Gross,MaintainType,MaintainDay,r_id,PackStd,StorageCon,
					TaxRate,BulidNo,RegisterNo,tcmoney,TC1,TC2,Profit,ifIntegral,factory,TcCost,PosYhDay,
					PrintClass,WholeUnit_id,Inputdate,Inputman,factoryc_id,alert,Registervalid,class_id,
					PerCodevalid,1,1 from products,productsExtend where p_id = product_id and  product_id = @product_id
	
	  set @SplitP_id = @@IDENTITY	  		
	/*-更新child_number\@child_count				*/
	update products set child_number=@child_number,child_count=@child_count
     where class_id =@Parent_id		
    /*-写入价格信息*/
    delete price where p_id = @SplitP_id and unittype = 1
	insert into price(p_id,u_id,retailprice,unittype) values (@SplitP_id,@cldw,@cljg,1)
     					
   end
   else
   begin
	   declare @class_id varchar(100)
	   select @class_id = class_id from products where Custompro1 in (select class_id from products where  product_id = @product_id) and IsSplit = 1
       update products set unit1_id = @cldw  where class_id = @class_id and IsSplit = 1
       /*更新价格*/
       declare @clp_id int 
       select @clp_id =product_id  from products where class_id = @class_id and IsSplit = 1
       
       delete price where p_id = @clp_id and unittype = 1
	   insert into price(p_id,u_id,retailprice,unittype) values (@clp_id,@cldw,@cljg,1)
   end
 end	            
	
        
/*return @product_Id*/
GO
