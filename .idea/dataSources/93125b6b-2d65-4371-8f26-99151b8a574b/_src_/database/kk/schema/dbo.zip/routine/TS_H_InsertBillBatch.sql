
CREATE PROCEDURE TS_H_InsertBillBatch 
	@BillID int = 0,
	@BillType int = 0,
	@IsDraft int = 1	/* 暂不启用*/
AS
BEGIN
	SET NOCOUNT ON;
	/* 批次要素*/
	DECLARE @PID VARCHAR(10)			/* 商品*/
	DECLARE @SID1 VARCHAR(10)			/* 仓库1*/
	DECLARE @SID2 VARCHAR(10)			/* 仓库2*/
	DECLARE @LID1 VARCHAR(10)			/* 货位1*/
	DECLARE @LID2 VARCHAR(10)			/* 货位2*/
	DECLARE @YID1 VARCHAR(10)			/* 机构*/
	DECLARE @YID2 VARCHAR(10)			/* 机构*/
	DECLARE @SUPID VARCHAR(10)			/* 供应商*/
	DECLARE @COMMFLAG VARCHAR(10)		/* 代销*/
	DECLARE @MAKEDATE VARCHAR(20)		/* 生产日期*/
	DECLARE @VALIDDATE VARCHAR(20)		/* 效期*/
	DECLARE @INSTORETIME VARCHAR(20)	/* 入库时间*/
	DECLARE @BATCHNO VARCHAR(80)		/* 批号*/
	DECLARE @COSTPRICE1 VARCHAR(30)		/* 成本价1*/
	DECLARE @COSTPRICE2 VARCHAR(30)		/* 成本价2*/
	DECLARE @FID VARCHAR(10)			/* 生产厂家*/
	DECLARE @TAXRATE VARCHAR(10)		/* 税率*/

	DECLARE @MD5 BINARY(16)

	/* 批次要素无关*/
	DECLARE @SMBID INT
	DECLARE @INORDER SMALLINT
	DECLARE @SENDFLAG INT
	DECLARE @BATCHBARCODE VARCHAR(30)
	DECLARE @SCOMMENT VARCHAR(80)
	DECLARE @BATCHPRICE FLOAT

	DECLARE @ACCOUNTYID INT

	SELECT @ACCOUNTYID = sysvalue FROM sysconfig WHERE sysname = 'Y_ID'

	DECLARE @MD5IN BINARY(16)
	DECLARE @MD5OUT BINARY(16)

	IF @BillType < 500
	BEGIN
		IF @BillType IN (14, 22, 26, 154, 108)
		BEGIN
			DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
				AND accountYid = @ACCOUNTYID

			DECLARE CURORDER CURSOR FOR
				SELECT p_id, ss_id, sd_id, location_id, location_id2, O.Y_ID, I.c_id, supplier_id, 
					commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
					CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
					CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
				FROM OrderBill O INNER JOIN orderidx I ON O.bill_id = I.billid
				WHERE bill_id = @BillID AND O.p_id > 0
			OPEN CURORDER
			FETCH NEXT FROM CURORDER INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
				@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
				@TAXRATE, @SMBID, @COSTPRICE2
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
					+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
				IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
					INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
						makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
						scomment, batchprice, factoryid, taxrate) 
					VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
						@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
						'', 0, @FID, @TAXRATE)

				SET @MD5IN = 0X0
				SET @MD5OUT = 0X0
				IF @BillType IN (14, 154)
					SET @MD5OUT = @MD5
				ELSE
					SET @MD5IN = @MD5

				/* 双仓库单据再次处理*/
				IF @BillType IN (154)
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID2 + @LID2 + @YID2 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE2 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID2, @SID2, @PID, @SUPID, @COSTPRICE2, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID2, 0, '',
							'', 0, @FID, @TAXRATE)
					SET @MD5IN = @MD5
				END

				INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
				VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

				FETCH NEXT FROM CURORDER INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
			END
			CLOSE CURORDER
			DEALLOCATE CURORDER
		END
		ELSE
		IF @BillType IN (10, 11, 150, 151, 152, 153)
		BEGIN
			IF @IsDraft = 1
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM salemanagebilldrf B INNER JOIN billdraftidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (10, 150, 152)
						SET @MD5OUT = @MD5
					ELSE
						SET @MD5IN = @MD5

					/* 双仓库单据再次处理*/
					IF @BillType IN (150, 152)
					BEGIN
						SET @MD5 = HASHBYTES('MD5', @PID + @SID2 + @LID2 + @YID2 + @SUPID + @COMMFLAG + @MAKEDATE
							+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE2 + @FID + @TAXRATE)
						IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
							INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
								makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
								scomment, batchprice, factoryid, taxrate) 
							VALUES(@MD5, @LID2, @SID2, @PID, @SUPID, @COSTPRICE2, @BATCHNO,
								@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID2, 0, '',
								'', 0, @FID, @TAXRATE)
						SET @MD5IN = @MD5
					END

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
			ELSE
			IF @IsDraft = 0
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM salemanagebill B INNER JOIN billidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (10, 150, 152)
						SET @MD5OUT = @MD5
					ELSE
						SET @MD5IN = @MD5

					/* 双仓库单据再次处理*/
					IF @BillType IN (150, 152)
					BEGIN
						SET @MD5 = HASHBYTES('MD5', @PID + @SID2 + @LID2 + @YID2 + @SUPID + @COMMFLAG + @MAKEDATE
							+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE2 + @FID + @TAXRATE)
						IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
							INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
								makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
								scomment, batchprice, factoryid, taxrate) 
							VALUES(@MD5, @LID2, @SID2, @PID, @SUPID, @COSTPRICE2, @BATCHNO,
								@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID2, 0, '',
								'', 0, @FID, @TAXRATE)
						SET @MD5IN = @MD5
					END

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
		END
		ELSE
		IF @BillType IN (12, 13)
		BEGIN
			IF @IsDraft = 1
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, 0 AS location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM RetailBill B INNER JOIN retailbillidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (12)
						SET @MD5OUT = @MD5
					ELSE
						SET @MD5IN = @MD5

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
			ELSE
			IF @IsDraft = 0
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, 0 AS location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM salemanagebill B INNER JOIN billidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (12)
						SET @MD5OUT = @MD5
					ELSE
						SET @MD5IN = @MD5

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
		END
		ELSE
		IF @BillType IN (20, 21, 160, 161, 162, 163)
		BEGIN
			IF @IsDraft = 1
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, 0 AS location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM buymanagebilldrf B INNER JOIN billdraftidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (20, 160, 162)
						SET @MD5IN = @MD5
					ELSE
						SET @MD5OUT = @MD5

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
			ELSE
			IF @IsDraft = 0
			BEGIN
				DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
					AND accountYid = @ACCOUNTYID

				DECLARE CURSB CURSOR FOR
					SELECT p_id, ss_id, sd_id, location_id, 0 AS location_id2, B.Y_ID, I.c_id, supplier_id, 
						commissionflag, CONVERT(VARCHAR(20), makedate, 120), CONVERT(VARCHAR(20), validdate, 120), 
						CONVERT(VARCHAR(20), Instoretime, 120), batchno, CAST(costprice AS NUMERIC(18, 4)), factoryid, 
						CAST(costtaxrate AS numeric(18, 4)), smb_id, CAST(discountprice AS numeric(18, 4))
					FROM buymanagebill B INNER JOIN billidx I ON B.bill_id = I.billid
					WHERE bill_id = @BillID AND B.p_id > 0
				OPEN CURSB
				FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
					@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
					@TAXRATE, @SMBID, @COSTPRICE2
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
						+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
					IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
						INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
							makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
							scomment, batchprice, factoryid, taxrate) 
						VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
							@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
							'', 0, @FID, @TAXRATE)

					SET @MD5IN = 0X0
					SET @MD5OUT = 0X0
					IF @BillType IN (20, 160, 162)
						SET @MD5IN = @MD5
					ELSE
						SET @MD5OUT = @MD5

					INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
					VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

					FETCH NEXT FROM CURSB INTO @PID, @SID1, @SID2, @LID1, @LID2, @YID1, @YID2, @SUPID, 
						@COMMFLAG, @MAKEDATE, @VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, 
						@TAXRATE, @SMBID, @COSTPRICE2
				END
				CLOSE CURSB
				DEALLOCATE CURSB
			END
		END
	END
	ELSE
	BEGIN
		DELETE FROM billBatch WHERE bill_id = @BillID AND billType = @BillType AND BillStates = @IsDraft
			AND accountYid = @ACCOUNTYID

		DECLARE CURGSP CURSOR FOR
			SELECT p_id, s_id, location_id, Y_ID, supplier_id, CommisionFlag, CONVERT(VARCHAR(20), makedate, 120),
				CONVERT(VARCHAR(20), validdate, 120), CONVERT(VARCHAR(20), Instoretime, 120), batchno, 
				CAST(costprice AS numeric(18, 4)), factoryid, CAST(costtaxrate AS numeric(18, 4)), Gspsmb_id
			FROM GSPbilldetail WHERE Gspbill_id = @BillID
		OPEN CURGSP
		FETCH NEXT FROM CURGSP INTO @PID, @SID1, @LID1, @YID1, @SUPID, @COMMFLAG, @MAKEDATE,
			@VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, @TAXRATE, @SMBID
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @MD5 = HASHBYTES('MD5', @PID + @SID1 + @LID1 + @YID1 + @SUPID + @COMMFLAG + @MAKEDATE
				+ @VALIDDATE + @INSTORETIME + @BATCHNO + @COSTPRICE1 + @FID + @TAXRATE)
			IF NOT EXISTS(SELECT * FROM BatchInfo WHERE md5 = @MD5)
				INSERT INTO BatchInfo(md5, location_id, s_id, p_id, supplier_id, costprice, batchno, 
					makedate, instoretime, validdate, commissionflag, inorder, Y_ID, SendFlag, BatchBarCode, 
					scomment, batchprice, factoryid, taxrate) 
				VALUES(@MD5, @LID1, @SID1, @PID, @SUPID, @COSTPRICE1, @BATCHNO,
					@MAKEDATE, @INSTORETIME, @VALIDDATE, @COMMFLAG, 0, @YID1, 0, '',
					'', 0, @FID, @TAXRATE)

			SET @MD5IN = 0X0
			SET @MD5OUT = 0X0
			IF @BillType IN (541, 551, 561, 563, 564)
				SET @MD5OUT = @MD5
			ELSE
				SET @MD5IN = @MD5

			INSERT INTO billBatch(bill_id, smb_id, billType, billStates, batchIn, batchOut, accountYid)
			VALUES(@BillID, @SMBID, @BillType, @IsDraft, @MD5IN, @MD5OUT, @ACCOUNTYID)

			FETCH NEXT FROM CURGSP INTO @PID, @SID1, @LID1, @YID1, @SUPID, @COMMFLAG, @MAKEDATE,
				@VALIDDATE, @INSTORETIME, @BATCHNO, @COSTPRICE1, @FID, @TAXRATE, @SMBID
		END
		CLOSE CURGSP
		DEALLOCATE CURGSP
	END
END
GO
