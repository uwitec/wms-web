


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
单品快速查询
最后的修改日期 2003-12-5
@lMode 方式 0 ：商品 1 ：单位 2 ：职员
@P_ID  商品的ID号
@B_ID  单位的ID号
@E_ID  职员的ID号
********************************************/
CREATE PROCEDURE TS_X_BaseQuickSearch
( @lMode      INT,
  @P_ID       INT,
  @C_ID       INT,
  @E_ID       INT,
  @lBillNum   INT,
  @BeginDate  DATETIME,
  @EndDate    DATETIME,
  @szYClass_id  varchar(20)=''
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szYClass_id is null  SET @szYClass_id = ''
/*Params Ini end*/

  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(5000)
  declare @SQLScriptP VARCHAR(5000)
  declare @SQLScriptC VARCHAR(5000)
  declare @SQLScriptE VARCHAR(5000)
  IF @szYClass_id='' select @szYClass_id='%%' else select @szYClass_id=@szYClass_id+'%'
  GOTO GetMain

GetMain:
  /*modify by luowei 2011-12-01: 将单据条数过滤移到统计中，避免因过滤后数的单据为非销售与进货类单据而查询不出数据*/
  IF @E_ID>1
  SELECT  @SQLScript='SELECT  * INTO ##TempTable  
    FROM 
    (SELECT  * FROM VW_C_BillIDX
    WHERE [E_ID] = '+CAST(@E_ID AS VARCHAR)+' AND Yclass_id like '+char(39)+@szYClass_id+char(39)+'
    ) A'
  ELSE
  SELECT  @SQLScript='SELECT  * INTO ##TempTable
    FROM 
    (SELECT  * FROM VW_C_BillIDX
     WHERE Yclass_id like '+char(39)+@szYClass_id+char(39)+'
    ) A'
  EXEC (@SQLScript)
    /*print(@SQLScript)*/

    IF  @lMode=0 GOTO GetProducts
  IF  @lMode=1 GOTO GetClients
  IF  @lMOde=2 GOTO GetEmployees

GetProducts:
/*-modify by luowei 2011-12-01 :根据单据类型显示出各个类型的单据张数***begin******/
/*统计销售*/
  SELECT  '售价' AS [pricetype], vb.[BillID], vb.[BillType], vb.[BillDate], 
  vb.[BillNumber], vb.[Note], vb.[ename], vp.[price], vp.taxprice,  vb.[inputman], 
  sum(ISNULL(CASE WHEN vp.[quantity]>0 THEN vp.[quantity] END, 0)) AS [inqty], 
  sum(ISNULL(CASE WHEN vp.[quantity]<0 THEN -vp.[quantity] END, 0)) AS [outqty],
  sum((CASE WHEN vp.[quantity]>=0 THEN vp.[total]
  WHEN vp.[quantity]<0 THEN -vp.[total] END)) AS [total],
  sum((CASE WHEN vp.[quantity]>=0 THEN vp.[taxtotal]
  WHEN vp.[quantity]<0 THEN -vp.[taxtotal] END)) AS [taxtotal] 
  INTO #TMS FROM VW_C_Pdetail vp, ##TempTable vb
  WHERE vp.[P_ID]=@P_ID and vp.[BillID]=vb.[BillID] 
  and vb.[Billtype] IN (10, 11, 12, 13, 112, 32)
  group by vb.[BillID], vb.[BillType], vb.[BillDate],vb.[BillNumber], 
           vb.[Note], vb.[ename], vp.[price], vb.[inputman], vp.taxprice 
  ORDER BY VB.BILLID DESC

/*统计进货*/
  SELECT  '进价' AS [pricetype], vb.[BillID], vb.[BillType], vb.[BillDate], 
  vb.[BillNumber], vb.[Note], vb.[ename], vp.[price], vp.taxprice , vb.[inputman],
  sum(ISNULL(CASE WHEN vp.[quantity]>0 THEN vp.[quantity] END, 0)) AS [inqty], 
  sum(ISNULL(CASE WHEN vp.[quantity]<0 THEN -vp.[quantity] END, 0)) AS [outqty],
  sum((CASE WHEN vp.[quantity]>=0 THEN vp.[total]
  WHEN vp.[quantity]<0 THEN -vp.[total] END)) AS [total], 
  sum((CASE WHEN vp.[quantity]>=0 THEN vp.[taxtotal]
  WHEN vp.[quantity]<0 THEN -vp.[taxtotal] END)) AS [taxtotal] 
  INTO #TMB FROM VW_C_Pdetail vp, ##TempTable vb
  WHERE vp.[P_ID]=@P_ID and vp.[BillID]=vb.[BillID] 
  and vb.[Billtype] IN (20, 21, 122, 35) 
  group by vb.[BillID], vb.[BillType], vb.[BillDate],vb.[BillNumber], 
           vb.[Note], vb.[ename], vp.[price], vb.[inputman], vp.taxprice 
  ORDER BY VB.BILLID DESC
  
  SET @SQLScriptP =
     'SELECT TOP '+CAST(@lBillNum AS VARCHAR)+' * FROM #TMS 
      UNION ALL
      SELECT TOP '+CAST(@lBillNum AS VARCHAR)+' * FROM #TMB'
  EXEC(@SQLScriptP)
  DROP TABLE #TMS
  DROP TABLE #TMB
  /*-modify by luowei 2011-12-01 :根据单据类型显示出各个类型的单据张数***end*****    */
  GOTO Succee

GetClients:

 set @SQLScriptC =
/*各种进销类单据和收付款单据*/
  'SELECT  top '+CAST(@lBillNum AS VARCHAR)+'  vb.[BillID], vb.[BillType], vb.[BillDate], vb.[BillNumber], vb.[Note], 
   vb.[ename], vb.[inputman], vb.[ysmoney] AS [total]
   FROM ##TempTable vb
   WHERE vb.[C_ID]='+cast(@C_ID as VARCHAR)+' 
   and vb.[Billtype] IN (10, 11, 12, 13, 112, 30, 31, 32, 20, 21, 122, 33, 34, 35, 15, 23)'
   
   EXEC(@SQLScriptC)
  
  GOTO Succee

GetEmployees:

  SET @SQLScriptE =
/*收付款单据和费用类单据*/
  'SELECT top '+CAST(@lBillNum AS VARCHAR)+'  vb.[BillID], vb.[BillType], vb.[BillDate], vb.[BillNumber], vb.[Note], 
   vb.[ename], vb.[inputman], vb.[ysmoney] AS [total]
   FROM   ##TempTable vb
   WHERE vb.[E_ID]='+CAST(@E_ID as VARCHAR)+' 
   and vb.[Billtype] IN (15, 23, 60, 61)'
   
   EXEC(@SQLScriptE)

  GOTO Succee

Succee:
  Drop table ##TempTable
  RETURN  0
GO
