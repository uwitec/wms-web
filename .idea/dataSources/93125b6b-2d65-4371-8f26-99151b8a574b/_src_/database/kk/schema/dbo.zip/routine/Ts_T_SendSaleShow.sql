/************************************************************
--过程名称：Ts_T_SendSaleShow
--功能：显示销售出库单和销售出库退货单
--创建人：LUO XIAOTIAN 
--创建时间：2010-12-06  
--最后修改:


参数说明：
		   

备注：
**************************************************************/
create proc [dbo].[Ts_T_SendSaleShow]
( @BeginDate  [datetime], 
  @EndDate    [datetime],
  @BillCode   varchar(20),
  @Emp        int,
  @Sendid     int,
  @Customer   int,
  @nMode      int,
  @nRoadid    int,
  @nSendCid   INT,	/* 配送单位*/
  @nCompanyId INT = 0,
  @TrafficType VARCHAR(30) = '[全部]', /*承运方式*/
  @OrderBY int = 0	/*排序方式（0按默认，1按往来单位）*/
)
as
if @Sendid=0
begin
 if @nMode=0 
 begin
	select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,
	       /*bd.wholeqty*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) as wholeqty,
	       /*bd.partqty,*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end) as partqty,
	       bd.cname,
	       ((Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) +
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end)) as TotalPack,
	       /*bd.wholeqty+bd.partqty as TotalPack,*/
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
	       billname=case bd.billtype 
			when 10 then '销售出库单' 
			when 11 then '销售出库退货单'  
			when 212 then '发货单'  
			when 21 then '采购入库退货单'
			when 150 then '机构发货单'
			when 152 then '自营店发货单'
			end,
		   ysmoney=Case  when bd.billtype in(10,21,212,150,152) then bd.ysmoney else -bd.ysmoney end,
		   quantity=Case when bd.billtype in (10,21,212,150,152) then bd.quantity else -bd.quantity end,
		   Pcount=Case when bd.billtype in (10,212,150,152) then s.Pcount 
		               when bd.billtype in (21) then s1.Pcount  else '' end,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		   isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   ISNULL(jhqty.lhqty,0)  as lhqty
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj, bd.arTotal, bd.apTotal,
		   CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	into #t
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					  left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  buymanagebill group by bill_id )s1 on bd.billid=s1.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    		      	
   			     left join /*--关联拣货单的整货与零货件数 add by luowei 2013-05-21*/
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(summary as int) as lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and CAST(a.InvoiceNO AS uniqueidentifier)=b.GUID and a.billtype=254 
					 ) c group by InvoiceNO
    			 ) JHQTY on cast(JHQTY.InvoiceNO as uniqueidentifier) = bd.GUID
    			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID 
    			 LEFT JOIN orderidx o ON bd.order_id = o.billid  			 
	where  bd.billtype in (10, 11, 212, 21, 150, 152) 
	      and (@Customer=0 or (bd.c_id=@Customer and bd.billtype not in (150, 152))) 
	      and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
	      and (@nCompanyId = 0 or (bd.c_id = @nCompanyId and bd.billtype in (150, 152)))
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
		  and (@nRoadid=0 or bd.roadid=@nRoadid)
		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
		       or @TrafficType = '[全部]' or RTRIM(LTRIM(o.TrafficType)) = '0' or RTRIM(LTRIM(o.TrafficType)) = '')
    order by bd.szOrderNum
        
    select * into #tmp from (
	select * from #t
	union all
	select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,
	       /*bd.wholeqty*/
	       (Case  when bd.billtype in(16) then bd.wholeqty else -bd.wholeqty end) as wholeqty,
	       /*bd.partqty,*/
	       (Case  when bd.billtype in(16) then bd.partqty else -bd.partqty end) as partqty,
	       bd.cname,
	       ((Case  when bd.billtype in(16) then bd.wholeqty else -bd.wholeqty end) +
	       (Case  when bd.billtype in(16) then bd.partqty else -bd.partqty end)) as TotalPack,
	       /*bd.wholeqty+bd.partqty as TotalPack,*/
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
	       billname=case bd.billtype 
			when 16 then '销售结算调价' 
			when 17 then '销售退货结算调价'  
			end,
		   ysmoney=Case  when bd.billtype in(16) then bd.ysmoney else -bd.ysmoney end,
		   quantity=Case when bd.billtype in (16) then bd.quantity else -bd.quantity end,s.Pcount,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		   0 as lj,0 as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,21,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   0  as lhqty,0 as gspzj,0 as gsplj,0 as gsphj, bd.arTotal, bd.apTotal,
		   CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    			
	where  bd.billtype in (16, 17) and exists(select 1 from #t where #t.billid = bd.order_id)/*bd.order_id in (select billid from #t)*/
	) T
    order by szOrderNum
    
    if @OrderBY = 0 
    begin
		select #tmp.*,persontotal.ystotal, ISNULL(pc.printcount, 0) AS printcount from #tmp 
		left join 
		(
		  select sum(ysmoney) as ystotal,cContact_personal from #tmp group by cContact_personal
		) persontotal on #tmp.cContact_personal = persontotal.cContact_personal
		left join vw_c_printcount pc on #tmp.billid = pc.Rep_ID
		order by szOrderNum
	end
	else
	begin
		select #tmp.*,persontotal.ystotal, ISNULL(pc.printcount, 0) AS printcount from #tmp 
		left join 
		(
		  select sum(ysmoney) as ystotal,cContact_personal from #tmp group by cContact_personal
		) persontotal on #tmp.cContact_personal = persontotal.cContact_personal
		left join vw_c_printcount pc on #tmp.billid = pc.Rep_ID
		order by c_id	
	end

 end else
 if @nMode=1
 begin
   select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,bd.wholeqty,bd.partqty,bd.cname,bd.wholeqty+bd.partqty as TotalPack,
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
          billname='销售出库单',
		  bd.ysmoney,bd.quantity as quantity,s.Pcount,
		  e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		  isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		  (case when bd.billtype in (11,21,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   ISNULL(jhqty.lhqty,0)  as lhqty, ISNULL(pc.printcount, 0) AS printcount
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj, bd.arTotal, bd.apTotal,
		   CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    			 
   			     left join 
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj  ,cast(summary as int) as lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and CAST(a.InvoiceNO AS uniqueidentifier)=b.GUID and a.billtype=254 
					 ) c group by InvoiceNO
    			 ) JHQTY on cast(JHQTY.InvoiceNO as uniqueidentifier) = bd.GUID
    			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID    
				 left join vw_c_printcount pc on bd.billid = pc.Rep_ID
				 LEFT JOIN orderidx o ON bd.order_id = o.billid
	where  bd.billtype = 10 and (@Customer=0 or bd.c_id=@Customer ) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
		  and (@nRoadid=0 or bd.roadid=@nRoadid)
		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
			or @TrafficType = '[全部]')
    order by bd.szOrderNum
 end else
 if @nMode=2
  begin
    select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,-(bd.wholeqty) as wholeqty,-(bd.partqty) as partqty,bd.cname,-(bd.wholeqty+bd.partqty) as TotalPack,
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
           billname='销售出库退货单',
		   -(bd.ysmoney) as ysmoney,-(bd.quantity) as quantity,s.Pcount,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,21,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   0 as lhqty, 0 as lj, 0 as zj, ISNULL(pc.printcount, 0) AS printcount, bd.arTotal, bd.apTotal,
		   CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
				 left join vw_c_printcount pc on bd.billid = pc.Rep_ID
				 LEFT JOIN orderidx o ON bd.order_id = o.billid
	where  bd.billtype = 11 and (@Customer=0 or bd.c_id=@Customer ) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
   		  and (@nRoadid=0 or bd.roadid=@nRoadid)
   		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
   				or @TrafficType = '[全部]') 
	order by bd.szOrderNum
 end else
 if @nMode=3
 begin
    select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,bd.wholeqty,bd.partqty,bd.cname,bd.wholeqty+bd.partqty as TotalPack,
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
           billname='发货单',
		   bd.ysmoney,bd.quantity as quantity,s.Pcount,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,21,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   0 as lhqty, ISNULL(pc.printcount, 0) AS printcount, bd.arTotal, bd.apTotal,
		   CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
				 left join vw_c_printcount pc on bd.billid = pc.Rep_ID
				 LEFT JOIN orderidx o ON bd.order_id = o.billid
	where  bd.billtype = 212 and (@Customer=0 or bd.c_id=@Customer ) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
   		  and (@nRoadid=0 or bd.roadid=@nRoadid)
   		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
				or @TrafficType = '[全部]')
	order by bd.szOrderNum
 END
ELSE 
if @nMode=4
BEGIN
	select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,
	       /*bd.wholeqty*/
	       (Case  when bd.billtype in(10,21,212) then bd.wholeqty else -bd.wholeqty end) as wholeqty,
	       /*bd.partqty,*/
	       (Case  when bd.billtype in(10,21,212) then bd.partqty else -bd.partqty end) as partqty,
	       bd.cname,
	       ((Case  when bd.billtype in(10,21,212) then bd.wholeqty else -bd.wholeqty end) +
	       (Case  when bd.billtype in(10,21,212) then bd.partqty else -bd.partqty end)) as TotalPack,
	       /*bd.wholeqty+bd.partqty as TotalPack,*/
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
	       billname='采购入库退货单',
		   ysmoney=Case  when bd.billtype in(10,21,212) then bd.ysmoney else -bd.ysmoney end,
		   quantity=Case when bd.billtype in (10,21,212) then bd.quantity else -bd.quantity end,
		   Pcount=Case when bd.billtype in (10,212) then s.Pcount 
		               when bd.billtype in (21) then s1.Pcount  else '' end,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		   isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   ISNULL(jhqty.lhqty,0)  as lhqty
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj
			, bd.arTotal, bd.apTotal,
			CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  buymanagebill group by bill_id )s1 on bd.billid=s1.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    		      	
   			     left join /*--关联拣货单的整货与零货件数 add by luowei 2013-05-21*/
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(summary as int) as lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and CAST(a.InvoiceNO AS uniqueidentifier)=b.GUID and a.billtype=254 
					 ) c group by InvoiceNO
    			 ) JHQTY on cast(JHQTY.InvoiceNO as uniqueidentifier) = bd.GUID
    			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID  
    			 LEFT JOIN orderidx o ON bd.order_id = o.billid      			 
	where  bd.billtype =21 and (@Customer=0 or bd.c_id=@Customer) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
		  and (@nRoadid=0 or bd.roadid=@nRoadid)
		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
			or @TrafficType = '[全部]')
    order by bd.szOrderNum	
END
else
if @nMode=5
BEGIN
	select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,
	       /*bd.wholeqty*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) as wholeqty,
	       /*bd.partqty,*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end) as partqty,
	       bd.cname,
	       ((Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) +
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end)) as TotalPack,
	       /*bd.wholeqty+bd.partqty as TotalPack,*/
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
	       billname='自营店发货单',
		   ysmoney=Case  when bd.billtype in(10,21,212,150,152) then bd.ysmoney else -bd.ysmoney end,
		   quantity=Case when bd.billtype in (10,21,212,150,152) then bd.quantity else -bd.quantity end,s.Pcount,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		   isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   ISNULL(jhqty.lhqty,0)  as lhqty
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj
			, bd.arTotal, bd.apTotal,
			CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    		      	
   			     left join /*--关联拣货单的整货与零货件数 add by luowei 2013-05-21*/
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(summary as int) as lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and CAST(a.InvoiceNO AS uniqueidentifier)=b.GUID and a.billtype=254 
					 ) c group by InvoiceNO
    			 ) JHQTY on cast(JHQTY.InvoiceNO as uniqueidentifier) = bd.GUID
     			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID   
    			 LEFT JOIN orderidx o ON bd.order_id = o.billid   			 
	where  bd.billtype =152 and (@nCompanyId=0 or bd.c_id=@nCompanyId) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
		  and (@nRoadid=0 or bd.roadid=@nRoadid)
		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
			or @TrafficType = '[全部]')	
    order by bd.szOrderNum	
END
ELSE
if @nMode=6
BEGIN
	select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,
	       /*bd.wholeqty*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) as wholeqty,
	       /*bd.partqty,*/
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end) as partqty,
	       bd.cname,
	       ((Case  when bd.billtype in(10,21,212,150,152) then bd.wholeqty else -bd.wholeqty end) +
	       (Case  when bd.billtype in(10,21,212,150,152) then bd.partqty else -bd.partqty end)) as TotalPack,
	       /*bd.wholeqty+bd.partqty as TotalPack,*/
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
	       billname='机构发货单',
		   ysmoney=Case  when bd.billtype in(10,21,212,150,152) then bd.ysmoney else -bd.ysmoney end,
		   quantity=Case when bd.billtype in (10,21,212,150,152) then bd.quantity else -bd.quantity end,s.Pcount,
		   e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
		   isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
		   (case when bd.billtype in (11,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
		   ISNULL(jhqty.lhqty,0)  as lhqty
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj
			, bd.arTotal, bd.apTotal,
			CAST('' AS VARCHAR(100)) AS consignee, CAST('' AS VARCHAR(100)) AS relationPhone, CAST('' AS VARCHAR(100)) AS paymentMode, 
		   CAST('' AS VARCHAR(100)) AS ArriveStation, CAST('' AS VARCHAR(100)) AS ArriveCustomer, 0 AS TransportationType, 
		   0 AS TransportationHour, 0 AS TransportationLimit, CAST('' AS VARCHAR(100)) AS Signfor, CAST('' AS VARCHAR(100)) AS SignforNote, 0 AS DeviceTemperature_Begin,
		   0 AS ConditionTemperature_Begin, 0 AS ConditionTemperature_End, 0 AS DeviceTemperature_End, CAST('' AS VARCHAR(100)) AS DetectTemperature, 
		   0 AS AffirmTemperature, 0 AS ProcessTemperature, CAST('' AS VARCHAR(100)) AS Discharge, 0 AS Transportation_States
	from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
					 left join employees e1 on  bd.e_id=e1.emp_id
					 left join employees e2 on  bd.inputman=e2.emp_id 
					 left join employees e3 on  bd.auditman=e3.emp_id 
					 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    		      	
   			     left join /*--关联拣货单的整货与零货件数 add by luowei 2013-05-21*/
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(summary as int) as lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and CAST(a.InvoiceNO AS uniqueidentifier)=b.GUID and a.billtype=254 
					 ) c group by InvoiceNO
    			 ) JHQTY on cast(JHQTY.InvoiceNO as uniqueidentifier) = bd.GUID
    			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID  
    			 LEFT JOIN orderidx o ON bd.order_id = o.billid    			 
	where  bd.billtype =150 and (@nCompanyId=0 or bd.c_id=@nCompanyId) and (@nSendCid = 0 or bd.sendC_id = @nSendCid)
		  and bd.billdate between @BeginDate and @EndDate 
		  and (@BillCode='' or bd.billnumber like @BillCode+'%')
		  and (@Emp=0 or bd.e_id=@Emp)  and bd.sendid=0 and bd.billstates=0
		  and (@nRoadid=0 or bd.roadid=@nRoadid)
		  AND ((CASE WHEN RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(o.TrafficType, '[全部]'))) END) = @TrafficType 
			or @TrafficType = '[全部]')
    order by bd.szOrderNum	
END	
end
else
begin
  select bd.c_id,bd.billid,bd.billtype,bd.billdate,bd.auditdate,bd.billnumber,bd.WholeQty,bd.partqty,bd.cname,bd.wholeqty+bd.partqty as TotalPack,
	       bd.szOrderNum,isnull(sr.roadcomment,'') roadcomment,isnull(sr.roadname,'') roadname,bd.order_id,
       billname=case bd.billtype 
			when 10 then '销售出库单' 
			when 11 then '销售出库退货单'  
			when 212 then '发货单'  
			when 21 then '采购入库退货单'
			when 150 then '机构发货单'
			when 152 then '自营店发货单'
			end,
       bd.ysmoney,bd.quantity,s.Pcount,
       e1.name as eName,e2.name as inputmanname,e3.name as auditmanname,bd.note,y1.loc_name as locname,
       isnull(JHQTY.lj,0) as lj,isnull(JHQTY.zj,0) as zj,bd.B_CustomName1,bd.B_CustomName2,bd.B_CustomName3,
       (case when bd.billtype in (11,21,24,25,54,211,221) then -bd.jsye else bd.jsye end) as jsye,
		   bd.caddress, bd.ccontact_personal, bd.cphone_number, bd.C_Customname1, bd.C_Customname2, bd.C_Customname3, bd.C_Customname4, bd.C_Customname5,
	   ISNULL(jhqty.lhqty,0) lhqty, ISNULL(pc.printcount, 0) AS printcount
		   ,ISNULL(GSPJHQTY.gspzj,0)  as gspzj
		   ,ISNULL(GSPJHQTY.gsplj,0)  as gsplj
		   ,(ISNULL(GSPJHQTY.gspzj,0)+ISNULL(GSPJHQTY.gsplj,0))  as gsphj, bd.arTotal, bd.apTotal,
		   sm.consignee, sm.relationPhone, sm.paymentMode,
		   sm.ArriveStation, sm.ArriveCustomer, sm.TransportationType,
		   sm.TransportationHour, sm.TransportationLimit, sm.Signfor, sm.SignforNote, sm.DeviceTemperature_Begin,
		   sm.ConditionTemperature_Begin, sm.ConditionTemperature_End, sm.DeviceTemperature_End,
		   sm.DetectTemperature, sm.AffirmTemperature, sm.ProcessTemperature, sm.Discharge,
		   sm.Transportation_States, sm.comment
       from  vw_c_billidx bd left join (select  count(DISTINCT p_id ) as Pcount,bill_id  from  salemanagebill group by bill_id )s on bd.billid=s.bill_id
                 left join employees e1 on  bd.e_id=e1.emp_id
                 left join employees e2 on  bd.inputman=e2.emp_id 
                 left join employees e3 on  bd.auditman=e3.emp_id  
                 left join Sendmangebill Sm on bd.billid =Sm.billid 
    			 left join SendRoad sr on bd.roadid=sr.RoadID
    			 left join (select loc_id,loc_name from  location where loctype=1)  y1 on bd.VIPCardID=y1.loc_id
    			 left join 
    			 (
    			   select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
					(
					   select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(a.summary as int) lhqty
					   from  billdraftidx a,(select GUID from  billidx)  b 
					   where a.InvoiceNO<>'' and InvoiceNO=convert(varchar(50),b.GUID) and a.billtype=254
					 ) c group by InvoiceNO
    			 ) JHQTY on JHQTY.InvoiceNO = bd.GUID    			 
    			 left join /*--GSP关联拣货单的整货与零货件数 add by yanrui 2014-02-13*/
    			(   select GUID,SUM(c.gspzj) as gspzj,SUM(c.gsplj) as gsplj
    			   from  
					(
					 select GUID,isnull(WholeQty,0) as gspzj,isnull(PartQty,0) as gsplj
					 from  GSPbillidx 
					 where billtype=551
					 ) c group by GUID
    			 ) GSPJHQTY on GSPJHQTY.guid = bd.GUID  
 				 left join vw_c_printcount pc on bd.billid = pc.Rep_ID
      where Sm.sendid=@Sendid             
    order by bd.szOrderNum
 end
GO
