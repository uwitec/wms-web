

CREATE proc ts_c_qrStop
as
set nocount on 
select s.*,isnull(s.MedName,'') mt_name,s.code as barcode 
from vw_c_storehouse s /*left join medtype mt on s.medtype=mt.mt_id */  
where s.stopsaleflag=1  /*直接取customCategory值,不需再join medtype  -Wsj-tfsbug44505-2016-12-28 修改。*/
order by s.pname,s.sname,s.locname
GO
