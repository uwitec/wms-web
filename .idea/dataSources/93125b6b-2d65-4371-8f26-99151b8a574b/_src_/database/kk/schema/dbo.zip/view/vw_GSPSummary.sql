

CREATE VIEW dbo.vw_GSPSummary
AS
SELECT GSPID, GSPType, BillCode, BillE, BillDate, Comment, CheckState, [sign], GspVer, 
      checkCase = CASE CheckState WHEN 0 THEN '' WHEN 2 THEN '√' WHEN 1 THEN '⊙'
       END, dbguid,clientname,gsptext,
      CGspType = CASE Gsptype WHEN 2200 THEN '进货品种审核表' WHEN 2201 THEN '本企业经营进口品种一览表'
       WHEN 2202 THEN '首营企业审批表' WHEN 2203 THEN '首营品种审批表' WHEN 2204 THEN
       '药品采购进货计划表' WHEN 2205 THEN '药品购进记录' WHEN 2206 THEN '药品进货情况质量评审表'
       WHEN 2220 THEN '药品到货请验单' WHEN 2221 THEN '药品验收抽样记录' WHEN 2222
       THEN '购进药品验收记录' WHEN 2223 THEN '退回药品验收记录' WHEN 2224 THEN '药品验收抽（送）验单'
       WHEN 2225 THEN '药品检验报告书' WHEN 2226 THEN '化验室检品登记表' WHEN 2227
       THEN '药品检验卡' WHEN 2228 THEN '化验原始记录' WHEN 2229 THEN '计量器具管理台帐'
       WHEN 2235 THEN '强制检定工作计量器具定期检定记录卡' WHEN 2236 THEN '非强制检定计量器具检定记录卡'
       WHEN 2237 THEN '精密仪器使用记录' WHEN 2238 THEN '滴定液配制及标化记录' WHEN
       2239 THEN '滴定液标签' WHEN 2240 THEN '上年度药品进货批次汇总表' WHEN 2241 THEN
       '年度药品抽验批次汇总表' WHEN 2242 THEN '年度药品抽验质量汇总表' WHEN 2243 THEN
       '验收入库通知单' WHEN 2244 THEN '药品到货拒收报告单' WHEN 2245 THEN '药品入库记录'
       WHEN 2246 THEN '购进药品退出记录' WHEN 2247 THEN '不合格药品报废销毁审批表' WHEN
       2248 THEN '不合格药品报表' WHEN 2249 THEN '不合格药品报损审批表' WHEN 2250 THEN
       '不合格药品报废销毁记录' WHEN 2251 THEN '不合格药品台帐' WHEN 2252 THEN '注射剂澄明度检查记录'
       WHEN 2260 THEN '顾客资格审核表' WHEN 2261 THEN '定单确认表' WHEN 2262 THEN
       '药品销售记录' WHEN 2263 THEN '药品直调验收记录' WHEN 2264 THEN '销出药品追回记录'
       WHEN 2265 THEN '药品不良反应报告表' WHEN 2270 THEN '库内存放品种一览表' WHEN
       2271 THEN '近效期药品标志牌' WHEN 2272 THEN '已销出药品退(换)货审批表' WHEN 2273
       THEN '已销药品退货通知单' WHEN 2274 THEN '销出药品退回记录' WHEN 2275 THEN '中药材/饮片在库养护记录表'
       WHEN 2276 THEN '库存药品养护检查记录' WHEN 2277 THEN '药品停售通知单' WHEN 2278
       THEN '药品质量复检通知单' WHEN 2279 THEN '药品养护质量报表' WHEN 2280 THEN '药品养护档案卡'
       WHEN 2281 THEN '解除停售通知单' WHEN 2282 THEN '近效期药品催销月报表' WHEN 2283
       THEN '养护设备使用记录' WHEN 2285 THEN '药品出库复核记录' WHEN 2286 THEN '药品入出库结存卡'
       WHEN 2290 THEN '企业员工花名册' WHEN 2291 THEN '从事质量管理和检查验收工作人员'
       WHEN 2292 THEN '从事养护、保管和销售工作人员' WHEN 2293 THEN '就业准入岗位工作人员'
       WHEN 2294 THEN '质量管理、检查验收与养护等专业工作人员' WHEN 2295 THEN '直接接触药品人员'
       WHEN 2296 THEN '直接接触药品人员体检表' WHEN 2297 THEN '健康检查汇总表' WHEN
       2298 THEN '个人健康档案表' WHEN 2299 THEN '培训申请单' WHEN 2300 THEN '年度GSP培训计划表'
       WHEN 2301 THEN '个人GSP培训记录' WHEN 2302 THEN '培训记录统计表' WHEN 2303
       THEN 'GSP培训效果调查表' WHEN 2320 THEN '供货企业一览表' WHEN 2321 THEN '购货单位一览表'
       WHEN 2322 THEN '经营品种一览表' WHEN 2323 THEN '药品质量档案' WHEN 2324 THEN
       '药品质量查询便函' WHEN 2325 THEN '药品质量查询登记表' WHEN 2326 THEN '药品经营质量管理征询意见书'
       WHEN 2327 THEN '质量事故处理记录' WHEN 2328 THEN '质量事故报表' WHEN 2329 THEN
       '质量申诉处理单' WHEN 2330 THEN '用户访问意见处理单' WHEN 2331 THEN '药品质量信息反馈单'
       WHEN 2332 THEN '信息传递反馈单' WHEN 2333 THEN '信息联系处理单' WHEN 2334 THEN
       '质量信息报表' WHEN 2335 THEN '质量信息执行情况记录' WHEN 2336 THEN '实施情况自查评审表'
       WHEN 2340 THEN '安全卫生检查记录' WHEN 2341 THEN '库房温湿度记录表' WHEN 2342
       THEN '设施设备一览表' WHEN 2343 THEN '设施设备一览表' WHEN 2344 THEN '设施设备一览表'
       WHEN 2345 THEN '设施设备一览表' WHEN 2346 THEN '设施设备一览表' WHEN 2347 THEN
       '设施设备一览表' WHEN 2348 THEN '设施设备一览表' WHEN 2349 THEN '设施设备一览表'
       WHEN 2350 THEN '设施设备一览表' WHEN 2351 THEN '设施设备一览表' WHEN 2352 THEN
       '测量临控仪器设备履历卡' WHEN 2353 THEN '中药标本目录表' WHEN 2354 THEN '中药饮片分装品种一览表'
       WHEN 2305 THEN '员工个人培训教育档案' WHEN 2306 THEN '员工个人培训教育档案2' WHEN
       2304 THEN '员工培训考核表' WHEN 2208 THEN '购进药品退货通知单' WHEN 2254 THEN
       '不合格药品处理情况汇总分析' WHEN 2255 THEN '中药饮片装斗复核记录' WHEN 2266 THEN
       '售后药品质量问题追踪表' WHEN 2267 THEN '批发药品与服务满意度征询表' WHEN 2269
       THEN '重点养护药品品种确定表' WHEN 2284 THEN '养护设备检修维护记录' WHEN 2502
       THEN '药品储存养护信息汇总分析报告' WHEN 2337 THEN '合格供货方档案表' WHEN 2338
       THEN '内部质量管理体系审核报告' WHEN 2339 THEN '问题改进和措施跟踪记录' WHEN 2400
       THEN '药品拆零登记表' WHEN 2401 THEN '处方药调配销售记录' WHEN 2287 THEN '陈列药品质量检查记录'
       WHEN 2256 THEN '中药材中药饮片验收记录' WHEN 2257 THEN '非药品验收记录' 
       WHEN 2258 THEN '不合格药品报告确认单' WHEN 2259 THEN '药品拒收台帐' 
       WHEN 2288 THEN '已购药品退(换)货审批表' WHEN 2619 THEN '药品直调采购记录'
	   WHEN 2620 THEN '药品直调销售记录' WHEN 2621 THEN '销出药品召回记录'
END
FROM dbo.GspSummary
GO
