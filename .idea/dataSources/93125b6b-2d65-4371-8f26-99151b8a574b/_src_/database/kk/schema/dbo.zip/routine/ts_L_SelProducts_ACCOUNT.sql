
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_ACCOUNT
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

/*
   '000001000001'; 『库存商品总值合计』
   '000001000005';『应收款合计』
   '000002000001';『应付帐款合计』
   '000001000003';现 金
   'CASHBANK'; 
   '000001000004';银行
   '000004000002000001'; //商品报损
   '000003000002000001'; //商品报溢收入
  '000003000002000005'; //变价调拨差价
   '000003000002000003'; //成本调价收入
   '000003000002000006'; //商品拆装差价

   '000004000001'; //『销售成本』
  '000003000001'; //『销售收入』
   '000003000002000004'; //进货退货差价
  '000004000003000002'; //固定资产折旧
   '000001000007'; //待摊费用
   '000003'; //【收入类】
  '000003000003'; //其他收入
  '000004'; //【支出类】
  '000004000003'; // 其他费用
  '000001'; //【资产合计】
  '000002'; //【负债合计】
   '000002000004000002'; //应交增值税销项税金
  '000002000004000001'; //应交增值税进项税金
   '000005'; //【所有者权益】
  '000003000003000001'; //调帐收入
   '000004000003000001'; //调帐亏损
   '000001000002'; //固定资产合计
  '000005000006'; //【利润】
*/
/*创建机构会计科目*/
exec ts_c_CreateBalance @nY_Id,0
	
 if @szWhere = 'STOREMONEY'
 begin
         select * 
	  from vw_AccountBalance
	  where (Class_ID='000004000003000007' or sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0 and
                class_id not in( '000002000005','000001000009' ,'000001000004009999','000001009999')
                and deleted=0  and Y_ID=@nY_ID
		and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
   return 0
 END
 if @szWhere = 'STOREMONEYNEW'
 begin
         select * 
	  from vw_AccountBalance
	  where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0 and
                class_id not in( '000002000005','000001000009' ,'000001000004009999','000001009999')
                and deleted=0  and Y_ID=@nY_ID
   return 0
 end
 if @szWhere ='CASHBANK' 
 begin
         select y_id, a_id, cur_total, ini_total, total_01, total_02, total_03, total_04, total_05, total_06, total_07, total_08, total_09, total_10, total_11, total_12, bqtotal, 
                      sumtotal, ModifyDate, ACCOUNT_ID, CLASS_ID, '000001000004' as PARENT_ID, CHILD_NUMBER, CHILD_COUNT, NAME, ALIAS, SERIAL_NUMBER, COMMENT, SYSFLAG, 
                      SYSROW, DELETED, PINYIN, CASHAUDIT, DIRECTION, RowIndex,YBaccount 
   from vw_AccountBalance
   where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0 and
                class_id not in ( '000002000005' , '000001000009', '000001000004009999','000001009999')
                and deleted=0  and Y_ID=@nY_ID
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
   return 0
 end
 if @szWhere ='CASHBANKPR' 
 begin
   select y_id, a_id, cur_total, ini_total, total_01, total_02, total_03, total_04, total_05, total_06, total_07, total_08, total_09, total_10, total_11, total_12, bqtotal, 
                      sumtotal, ModifyDate, ACCOUNT_ID, CLASS_ID, '000001000004' as PARENT_ID, CHILD_NUMBER, CHILD_COUNT, NAME, ALIAS, SERIAL_NUMBER, COMMENT, SYSFLAG, 
                      SYSROW, DELETED, PINYIN, CASHAUDIT, DIRECTION, RowIndex,YBaccount 
   from vw_AccountBalance
   where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0  and
                class_id not in ('000001000009','000001000004009999','000001009999') and deleted=0
		and Y_ID=@nY_ID
     and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
  return 0
 end
 if @szWhere ='CASHBANKPP' 
 begin
   select y_id, a_id, cur_total, ini_total, total_01, total_02, total_03, total_04, total_05, total_06, total_07, total_08, total_09, total_10, total_11, total_12, bqtotal, 
                      sumtotal, ModifyDate, ACCOUNT_ID, CLASS_ID, '000001000004' as PARENT_ID, CHILD_NUMBER, CHILD_COUNT, NAME, ALIAS, SERIAL_NUMBER, COMMENT, SYSFLAG, 
                      SYSROW, DELETED, PINYIN, CASHAUDIT, DIRECTION, RowIndex,YBaccount 
   from vw_AccountBalance
   where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0  and
                class_id not in  ('000002000005','000001000004009999','000001009999') and deleted=0
		and Y_ID=@nY_ID
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
   return 0
 end
 if @szWhere ='PREAP' 
 begin
   select * 
   from vw_AccountBalance
   where  Child_number=0  and class_id =  '000001000009' and deleted=0  and Y_ID=@nY_ID
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
   return 0
 end
 if @szWhere ='PREAR' 
 begin
   select * 
   from vw_AccountBalance
   where Child_number=0  and class_id = '000002000005' and deleted=0  and Y_ID=@nY_ID
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
   return 0
 end
  
 if @szWhere<>''
 begin
   if CHARINDEX('Like',@szWhere) > 0
   begin 
     set @sql = 'select distinct * from vw_AccountBalance where DELETED = 0 and child_number = 0 
                 and Y_ID = '+CAST(@nY_ID as varchar(20))+' and ' + @szWhere
				 + '    and class_id in (select class_id from dbo.AuthorizeAccount(' + cast(@E_id as varchar(10)) + '))'
     exec(@sql)
   end
   else    
   select * 
	  from vw_AccountBalance
	  where Parent_id=@parent_id and left(class_id,len(@szWhere))=@szWhere and deleted=0
		and Y_ID=@nY_ID	
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
 end	
 else
  select * 
  from vw_AccountBalance
  where Parent_id=@parent_id  and deleted=0
	and Y_ID=@nY_ID
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
  return 0
GO
