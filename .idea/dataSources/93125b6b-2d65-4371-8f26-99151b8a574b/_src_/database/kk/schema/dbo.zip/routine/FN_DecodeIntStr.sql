
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-23*/
/* Description:	转换整型为编码后的字符串*/
/* =============================================*/
CREATE FUNCTION FN_DecodeIntStr 
(
	@nOldValue varchar(20)
)
RETURNS bigint
AS
BEGIN
	DECLARE @Result bigint

	DECLARE @CHARLIST CHAR(36)
	DECLARE @nCharCount int
	DECLARE @nLen int
	DECLARE @nCur int
	DECLARE @nTmp bigint

	SET @CHARLIST = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	SET @nCharCount = LEN(@CHARLIST)
	SET @nLen = LEN(@nOldValue)
	SET @nCur = @nLen

	SET @Result = 0
	WHILE @nCur > 0
	begin
		SET @nTmp = dbo.FN_BigIntPower(@nCharCount, @nLen - @nCur)
		SET @Result = @Result + (CHARINDEX(SUBSTRING(@nOldValue, @nCur, 1), @CHARLIST) - 1) * @nTmp
		SET @nCur = @nCur - 1
	end
	/*SET @Result = SUBSTRING(@CHARLIST, @nOldValue + 1, 1) + @Result*/
	/*SET @Result = dbo.PadLeft(@Result, @nLen, '0')*/

	RETURN @Result

END
GO
