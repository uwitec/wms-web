/************************************************************

--功能：读取整零库货位
--创建人：zhoujilin
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_GetWSLoction
	(
	 @p_id int,
	 @y_id int
     )
AS 

declare @wholeLoc int, @singleLoc int,@locationid int, @WLocname varchar(60), @SLocname varchar(60),@locationname varchar(60)

 /*  select @wholeLoc = wholeLoc, @singleLoc = singleLoc,
          @WLocname = WLocname, @SLocname = SLocname 
     from vw_Products where product_id= @p_id
     
  if not exists(select 1 from vw_Location where  loc_id = @wholeLoc and y_id = @y_id)
  begin
    set @wholeLoc = 0
    set @WLocname = ''
  end   
  
  if not exists(select 1 from vw_Location where  loc_id = @singleLoc and y_id = @y_id)
  begin
    set @singleLoc = 0
    set @SLocname = ''
  end  */ 

   select @wholeLoc = wholeLoc, @singleLoc = singleLoc,
          @WLocname = isnull(wl.[loc_name],''), @SLocname = isnull(SL.[loc_name],'') 
         ,@locationid=locationid,@locationname = isnull(l.[loc_name],'')
   from  productbalance pb
   left join location  l on pb.locationid=l.loc_id
   left join location wl on pb.wholeloc=wl.loc_id
   left join location sl on pb.singleLoc=sl.loc_id
   where p_id=@p_id and Y_id=@Y_id
  
 select isnull(@wholeLoc,0) as wholeLoc, isnull(@singleLoc,0) as singleLoc,isnull(@locationid,0) as locationid,
        isnull(@WLocname,'') as WLocname,isnull(@SLocname,'') as SLocname, isnull(@locationname,'') as locationname
GO
