/***********删除按仓库拆分销售出库单草稿生成的相关单据**********/


create procedure TS_L_DelDraftBill
(
  @nbill_id int,
  @nflag int   /*--- flag 0 为处理普通销售出库单 ，1 为处理根据仓库拆分生成的销售出库单*/
)
as
begin
  if @nflag is null set @nflag = 0
  
  if @nflag = 1 
  begin
    /*-------回滚失败删除拆分的销售出库单草稿 add by luowei 2014-01-21*/
	/*---删除生成的明细 */
	delete from salemanagebilldrf where exists(select 1 from billdraftidx where billid = bill_id and billtype = 10 and posid = @nbill_id)
	/*---删除生成的主表*/
	delete from billdraftidx where billtype = 10 and posid = @nbill_id
	
	/*---删除原单 */
	delete from billdraftidx where billid = @nbill_id
	/*---删除原单明细 */
	delete from salemanagebilldrf where bill_id = @nbill_id
	/*update billdraftidx set billstates = 2,auditman = 0 where billid = @nbill_id */
	
  end

  if @nflag = 0 
  begin
	  /*----删除草稿中的拣货单信息*/
	  
	  /*----删除拣货明细*/
	  delete from salemanagebilldrf where exists(select 1 from billdraftidx where billid = bill_id and billtype = 254 and order_id = @nbill_id)
	  /*----删除拣货单主表*/
	  delete from billdraftidx where order_id = @nbill_id and billtype = 254
	  
	  /*----删除销售单明细*/
	  delete from salemanagebilldrf where exists(select 1 from billdraftidx where billid = bill_id and billtype = 10 and billid = @nbill_id)
	  /*----删除销售单主表*/
	  delete from billdraftidx where billid = @nbill_id and billtype = 10 
	  /*update billdraftidx set billstates = 2,auditman = 0 where billid = @nbill_id */
  end
end
GO
