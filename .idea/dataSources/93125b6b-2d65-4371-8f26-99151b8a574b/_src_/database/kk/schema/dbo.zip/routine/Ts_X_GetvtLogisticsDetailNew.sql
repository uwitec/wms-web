
/*
用于读取一张物流单中所有单据包含的商品信息
ADD BY XXX

*/
CREATE PROCEDURE Ts_X_GetvtLogisticsDetailNew(
	@SendId INT,		/*物流单号*/
	@BillId varchar(100) = ''   /*该物流单包含的单据id串*/
	)
AS
BEGIN
	/*DECLARE @BillType INT, @CId INT
	SELECT @BillType = ISNULL(b.billtype, 0), @CId = ISNULL(b.c_id, 0)
	    FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid 
	WHERE s.sendid = @SendId AND s.billid = @BillId  */
	
	SELECT v.name AS P_Name, v.alias AS P_Alias, v.serial_number AS P_Code, v.MedName AS P_MedType, v.[standard] AS P_Standard,
	       v.trademark AS P_Trademark, v.Factory AS P_FACTORY, v.makearea AS P_MakeArea, v.permitcode AS P_PermitCode,
	       CASE WHEN gd.makedate = '1900-01-01' THEN '' ELSE gd.makedate END AS P_makedate, 
	       CASE WHEN gd.validdate = '1900-01-01' THEN '' ELSE gd.validdate END AS P_validity,
	       gd.batchno AS P_serial, v.unit1name AS P_Unit, gd.Yqty AS Qty, gd.Price AS price, gd.total,
	       s.SendTime AS Date_Sale, gb.C_NAME,
	       s.TransportEquipment AS Tran_Tool, sm.DeviceTemperature_Begin AS BeginTmp, sm.AffirmTemperature AS EndTmp, 
	       CASE WHEN sm.ArriveCustomer = '1900-01-01' THEN sm.ArriveStation ELSE sm.ArriveCustomer END AS EndDate,
	       s.TransportationHour AS TrafficTime,  '' AS TempControl, '' AS TempControlMode, s.trafficMode AS TrafficType,
	       ISNULL(g.name, '') AS e_Name, gd.comment, v.StorageCon AS Ycondition,
	       gd.p_id AS P_product_ID, gb.c_id AS c_client_id, s.Driver AS E_Emp_id, v.unit1_id AS P_Unit_id, v.rate2 AS P_Rate2,
	       v.rate3 AS P_Rate3, v.rate4 AS P_Rate4, 0 AS P_UnitType, 0 AS Qty2, v.gspflag AS P_GspFlag, v.validday AS P_ValidDay,
	       v.validmonth AS P_ValidMonth, v.IsCold, v.IsSpec, s.serial_number, s.consign_dep, s.CamionCode, s.consignee,
	       '合格' as qualitystatus, s.Porthole AS Tran_Add, sm.Discharge AS Send_Add,
	       ISNULL(SC.name,'') AS SCNAME_SEND,ISNULL(SC.client_id,0) AS C_CLIENT_ID_SEND
		FROM Sendidx s INNER JOIN Sendmangebill sm ON s.Send_id = sm.sendid 
		               INNER JOIN VW_GSPBILLIDX gb ON sm.billid = gb.Gspbillid
		               INNER JOIN GSPbilldetail gd ON gb.Gspbillid = gd.Gspbill_id 
					   LEFT JOIN vw_Products v ON GD.P_id = v.product_id 
		               LEFT JOIN clients e ON gb.c_id = e.client_id 
		               LEFT JOIN company f ON gb.c_id = f.company_id
		               LEFT JOIN logisticsInfo g ON s.Driver = g.id
		               LEFT JOIN clients sc ON gb.SendC_Id = sc.client_id and sc.jsdw_id > 0   /*XXX.2017-02-15 增加收货方*/
		where gb.BillType = 551 and gb.Sendid = @SendId			
		AND gd.Gspbill_id in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@BillId))  /*不但需要物流单号，还需要原单的单据号（存在单张单据抵达）*/

END
GO
