
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-6-19*/
/* Description:	自动生成下一步单据*/
/* =============================================*/
CREATE PROCEDURE TS_H_AutoCreateNextBill 
	@nBillId int = 0, 
	@nBillType int = 0,
	@nRet int output
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nLastBillType int
	DECLARE @nNewBillType int

	/* 检测是否符合生成新单据的条件*/
	IF @nBillType BETWEEN 501 AND 599
	BEGIN
		IF NOT EXISTS(SELECT * FROM GSPbillidx WHERE Gspbillid = @nBillId AND BillStates = 13)
		BEGIN
			SET @nRet = 9999
			RETURN 0
		END
		SELECT @nLastBillType = Ybilltype FROM GSPbillidx WHERE Gspbillid = @nBillId
	END
	ELSE
	/* 检测是否符合生成新单据的条件*/
	IF @nBillType IN (14, 154)
	BEGIN
		IF NOT EXISTS(SELECT * FROM orderidx WHERE billid = @nBillId AND BillStates = 3)
		BEGIN
			SET @nRet = 9999
			RETURN 0
		END
		/* 机构配送订单从 BusinessType 字段取机构单据类型*/
		IF @nBillType = 154
			SELECT @nLastBillType = CASE BusinessType WHEN 0 THEN 152 ELSE 150 END FROM orderidx WHERE billid = @nBillId
		ELSE
			SELECT @nLastBillType = @nBillType
	END
	ELSE IF @nBillType IN (157)  /*-XXX.2017-05-15 店间调拨单自动生成收货退货单163*/
	BEGIN
		IF NOT EXISTS(SELECT * FROM billdraftidx WHERE BillType = 157 AND billid = @nBillId AND BillStates = 3)
		BEGIN
			SET @nRet = 9999
			RETURN 0
		END	
		SELECT @nLastBillType = @nBillType
	END

	SET @nRet = 9999
	DECLARE curNext cursor for
		SELECT NextVch FROM VchFlow WHERE LastVch = @nLastBillType AND VchType = @nBillType
	OPEN curNext
	FETCH NEXT FROM curNext INTO @nNewBillType
	WHILE @@FETCH_STATUS = 0
	BEGIN
		/* 删除以前生成的单据*/
		IF @nNewBillType BETWEEN 501 AND 599
			DELETE FROM GSPbillidx where Gspbillid in (select billid from billTrace where lastId in 
				(select id from billTrace where billId = @nBillId and billType = @nBillType)
				and billType between 501 and 599) and billtype = @nNewBillType and BillStates not in(13, 15)
		ELSE
			DELETE FROM billdraftidx where billid in (select billid from billTrace where lastId in 
				(select id from billTrace where billId = @nBillId and billType = @nBillType)
				and billType < 255) and billtype = @nNewBillType and billstates = 2
		EXEC TS_H_CreateNewGspBill @nBillId, @nBillType, @nNewBillType, @nRet OUTPUT
		IF @nRet < 0
		BEGIN
			CLOSE curNext
			DEALLOCATE curNext
			RETURN @nRet
		END
		FETCH NEXT FROM curNext INTO @nNewBillType
	END
	CLOSE curNext
	DEALLOCATE curNext
	RETURN 0
END
GO
