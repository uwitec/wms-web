
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-23*/
/* Description:	转换整型为编码后的字符串*/
/* =============================================*/
CREATE FUNCTION FN_EncodeIntStr 
(
	@nOldValue bigint,
	@nLen int
)
RETURNS varchar(20)
AS
BEGIN
	DECLARE @Result varchar(20)

	DECLARE @CHARLIST CHAR(36)
	DECLARE @nCharCount int
	DECLARE @nRest bigint
	SET @CHARLIST = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	SET @nCharCount = LEN(@CHARLIST)

	SET @Result = ''
	WHILE @nOldValue >= @nCharCount
	begin
		SET @nRest= @nOldValue % @nCharCount
		SET @Result = SUBSTRING(@CHARLIST, @nRest + 1, 1) + @Result
		SET @nOldValue = @nOldValue / @nCharCount
	end
	SET @Result = SUBSTRING(@CHARLIST, @nOldValue + 1, 1) + @Result
	SET @Result = dbo.PadLeft(@Result, @nLen, '0')

	RETURN @Result

END
GO
