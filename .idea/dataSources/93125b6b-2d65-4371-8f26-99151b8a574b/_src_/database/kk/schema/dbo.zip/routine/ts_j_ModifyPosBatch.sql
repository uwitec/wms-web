/************************************************************

--功能：手动修改门店上传零售单的批次   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：
 @nRet 返回值说明　
	0:执行成功
       -1:执行失败，发生异常
**************************************************************/

CREATE	 PROCEDURE [ts_j_ModifyPosBatch]
	(
	  @nSmbID int = 0,
 	  @nStorehouseID int = 0
     )
AS 
/*Params Ini begin*/
if @nSmbID is null  SET @nSmbID = 0
if @nStorehouseID is null  SET @nStorehouseID = 0
/*Params Ini end*/
    update Ysalemanagebilldrf set batchno = s.batchno, costprice = s.costprice, makedate = s.makedate, validdate = s.validdate, 
           location_id = s.location_id, commissionflag = s.commissionflag, supplier_id = s.supplier_id, instoretime = s.instoretime
      from Ysalemanagebilldrf ys, storehouse s where ys.smb_id = @nSmbID and s.storehouse_id = @nStorehouseID and
           s.p_id = s.p_id and ys.ss_id = s.s_id and ys.Y_ID = s.Y_ID
GO
