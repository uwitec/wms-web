
CREATE FUNCTION FilterVW_C_Storehouse(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     sh.storehouse_id, sh.location_id, sh.s_id, sh.p_id, sh.supplier_id, sh.quantity, 
		                      CASE WHEN dbo.A_GetPriceLimit(@E_ID, 1) = 1 THEN sh.price1 ELSE 0 END AS price1,
		                      CASE WHEN dbo.A_GetPriceLimit(@E_ID, 2) = 1 THEN sh.price2 ELSE 0 END AS price2,
		                      CASE WHEN dbo.A_GetPriceLimit(@E_ID, 3) = 1 THEN sh.price3 ELSE 0 END AS price3,
		                      CASE WHEN dbo.A_GetPriceLimit(@E_ID, 9) = 1 THEN sh.lowprice ELSE 0 END AS lowprice,
		                      CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costprice ELSE 0 END AS costprice, 
		                      CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtaxprice * sh.quantity / (1 + sh.taxrate) ELSE 0 END AS costtotal, 
		                      sh.makedate, sh.instoretime, 
							  sh.validdate, sh.commissionflag, sh.stopsaleflag, sh.inorder, sh.yhdate, sh.ModifyDate, sh.BatchBarCode, sh.Y_ID, sh.SendFlag, sh.scomment, 
							  sh.batchprice,sh.SClassID,sh.YClass_id,PClassID,Pname,sh.Alias,sh.Standard,sh.Makearea,sh.comment,sh.Taxrate,Cname,sh.CclassID,sh.MedName,sh.Medtype,sh.Locname,
							  sh.C_Name,sh.Code,sh.Factory,sh.Name1,sh.Name2,sh.Name3,sh.Name4,sh.Otcflag,sh.Permitcode,sh.Rate2,sh.Rate3,sh.Rate4,sh.RetailTotal,sh.SR2_id,
							  sh.Sname,sh.Validmonth,sh.Yname,sh.batchno,sh.e_name,sh.retailprice,sh.scode, sh.factoryid,
							  CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtaxprice ELSE 0 END AS costtaxprice, 
							  CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sh.costtaxprice * sh.quantity ELSE 0 END AS costtaxtotal
							
		FROM         dbo.VW_C_StoreHouse AS sh INNER JOIN
							  dbo.products AS p ON sh.p_id = p.product_id
GO
