/* select * from dbo.FN_DRPrintText(12,384)*/
CREATE FUNCTION FN_DRPrintText 
(
  @billtype INT,
  @billid INT
)
RETURNS TABLE
AS
  RETURN 
  ( /*零售和对应退货均记录的是零售单id*/
    SELECT TOP 1 ISNULL(b.AAC003,'0') EmpName,ISNULL(b.EmpNum,'0') YBCardNo,a.DR10Num
           ,a.YBMoney,a.CurYBMoney,a.CurYBMoney-a.YBMoney LastMoney,a.CashMoney
    FROM DRBillidx a LEFT JOIN DRYDEmpinfo b
         ON a.EmpNum=b.EmpNum AND a.TCAreaNo=b.YAB003
    WHERE @billtype=12 AND Billid=@billid AND Billtype=12 AND SettleFlag='600' AND Billstates=0
    UNION ALL 
    SELECT TOP 1 ISNULL(b.AAC003,'0') EmpName,ISNULL(b.EmpNum,'0') YBCardNo,a.DR10Num
           ,a.YBMoney,a.CurYBMoney,a.CurYBMoney-a.YBMoney LastMoney,a.CashMoney
    FROM DRBillidx a LEFT JOIN DRYDEmpinfo b
         ON a.EmpNum=b.EmpNum AND a.TCAreaNo=b.YAB003
    WHERE @billtype=13 AND Billid=(SELECT TOP 1 b.bill_id
		  FROM salemanagebill a INNER JOIN salemanagebill b 
			   ON a.orgbillid=b.smb_id
		  WHERE a.bill_id=@billid AND a.p_id>0 AND b.p_id>0) 
          AND Billtype=13 AND SettleFlag='601' AND Billstates=0 
  )
GO
