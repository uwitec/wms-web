
/*复制机构物价*/
create   PROCEDURE ts_L_CopyCompyProce
( @Yid           int,
  @CopyYClassId  varchar(100)        
 )	
AS

 
	
 declare @copyYid int 
 set @copyYid=0
  /*不能复制机构大类,容易出错.*/
 select @copyYid=company_id from company where class_id = @CopyYClassId and child_number=0 and deleted<>1
 if @copyYid=0 
 begin
   RAISERROR('没有找到复制目标机构!!',16,1)
   return -1
 end
 if @Yid=@copyYid 
 begin
   RAISERROR('复制目标机构和源机构相同,不需要复制!!',16,1)
   return -1
 end
 if not Exists(SELECT top 1 price_id FROM PosPrice where Y_ID=@Yid)
 begin
   RAISERROR('"复制物价"内容为空,请重新设置商品物价!!',16,1)
   return -1
 end 
  
begin tran Audit_CopyYPrice
      delete from PosPrice where Y_ID=@copyYid
      
      insert PosPrice([pos_id]
      ,[p_id]
      ,[u_id]
      ,[retailprice]
      ,[recprice]
      ,[price1]
      ,[price2]
      ,[price3]
      ,[price4]
      ,[gpprice]
      ,[glprice]
      ,[specialprice]
      ,[unittype]
      ,[lowprice]
      ,[lastprice]
      ,[lasttime]
      ,[billid]
      ,[Y_ID])	 
      
      SELECT [pos_id]
      ,[p_id]
      ,[u_id]
      ,[retailprice]
      ,[recprice]
      ,[price1]
      ,[price2]
      ,[price3]
      ,[price4]
      ,[gpprice]
      ,[glprice]
      ,[specialprice]
      ,[unittype]
      ,[lowprice]
      ,[lastprice]
      ,GETDATE()
      ,[billid]
      ,@copyYid
  FROM [PosPrice] where Y_ID=@Yid
    
commit tran Audit_CopyYPrice

return 0
GO
