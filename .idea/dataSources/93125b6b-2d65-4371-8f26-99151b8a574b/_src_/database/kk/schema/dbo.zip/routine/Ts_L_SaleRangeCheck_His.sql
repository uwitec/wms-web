

CREATE	PROCEDURE [Ts_L_SaleRangeCheck_His]
	(@C_id 	[int],
	 @sr_id	[int],
	 @IfSelect [int])

AS

set @C_id = ABS(@C_id)

if (@IfSelect=1)
begin
	SELECT TOP 0 * 
	INTO #TC
	FROM [SaleRangeCheck]
	INSERT INTO #TC ( [c_id],[sr_id]) 
	VALUES (@c_id,@sr_id)

	INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
	SELECT @c_id, 'SRC', (SELECT * FROM #TC AS [SaleRangeCheck] FOR XML AUTO, TYPE, ROOT), 1

	DROP TABLE #TC
end
GO
