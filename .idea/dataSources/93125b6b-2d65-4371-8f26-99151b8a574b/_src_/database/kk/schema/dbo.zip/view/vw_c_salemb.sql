





CREATE	VIEW dbo.vw_c_salemb
AS
SELECT dbo.salemanagebill.*, 
ISNULL(P.[Name]  ,'') AS [PName],         
ISNULL(P.[Class_ID]  ,'') AS [PClass_ID],
isnull(storages_2.class_id,'') AS ssclass_id, 
isnull(storages_1.class_id,'') AS sdclass_id, 
isnull(storages_2.name,'') AS ssname, 
isnull(storages_1.name,'') AS sdname,
isnull(u.name,'') as unitname,
isnull(l.loc_name,'') as locname,
isnull(c.[name],'') as suppliername,
isnull(E.class_id,'') as REclass_ID,
isnull(E.[name],'') as REname
FROM dbo.salemanagebill
    LEFT JOIN Products P  ON salemanagebill.[P_ID]=P.[Product_ID] 
    LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.salemanagebill.sd_id = storages_1.storage_id 
      LEFT OUTER JOIN
      dbo.storages storages_2 ON dbo.salemanagebill.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON dbo.salemanagebill.unitid = u.unit_id
      LEFT OUTER JOIN
      location l on dbo.salemanagebill.location_id=l.loc_id
      LEFT OUTER JOIN
      clients c on dbo.salemanagebill.supplier_id=c.client_id
      LEFT OUTER JOIN
      employees E ON salemanagebill.RowE_id=E.emp_id
where dbo.salemanagebill.aoid in(0,5)
GO
