











CREATE VIEW dbo.vw_c_storedxini
AS
SELECT dbo.storedxini.p_id, ISNULL(SUM(dbo.storedxini.quantity), 0) AS quantity, 
      ISNULL(SUM(dbo.storedxini.costtotal), 0) AS costtotal, storedxini.c_id,
      dbo.clients.class_id AS cclass_id, dbo.products.class_id AS pclass_id, 
      dbo.storedxini.commissionflag,
      isnull(Y.Class_id,'')YClass_id,ISNULL(Y.[name],'')Yname,storedxini.Y_id,
       dbo.storedxini.supplier_id
FROM dbo.storedxini 
     LEFT OUTER JOIN   dbo.clients ON dbo.storedxini.c_id = dbo.clients.client_id 
     LEFT OUTER JOIN   dbo.products ON dbo.storedxini.p_id = dbo.products.product_id
     LEFT OUTER JOIN    Company y on storedxini.Y_id=Y.Company_id

GROUP BY dbo.storedxini.p_id, dbo.clients.class_id, dbo.products.class_id, 
      dbo.storedxini.commissionflag,Y.Class_id,Y.[name],storedxini.c_id,storedxini.Y_id,
      dbo.storedxini.supplier_id
GO
