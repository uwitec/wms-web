
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-15*/
/* Description:	插入处方笺详细内容*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_PrescDtlIns]
	@Pres_ID		int,
	@Pdt_ID			int,
	@PdtCount		int,
	@PdtType		int,
	@Comment		varchar(200)
AS
BEGIN
	SET NOCOUNT ON;

	insert into PrescriptionDetail(
		[Pres_ID],
		[Pdt_ID],
		[PdtCount],
		[PdtType],
		[Comment]
	) values(
		@Pres_ID,
		@Pdt_ID,
		@PdtCount,
		@PdtType,
		@Comment
	)
	if @@Rowcount > 0
		Return @@Identity
END
GO
