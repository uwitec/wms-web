
/*
检查"账务信息表"中是否有该机构的记录。没有记录,就插入记录。
*/

CREATE	       PROCEDURE ts_c_CreateBalance
(
	@Y_ID	int,
	@C_id	int
)
/*with encryption*/
AS
/*机构帐务信息表*/
	IF (@Y_ID<>0) 
	BEGIN
		INSERT INTO AccountBalance 
			   (y_id, a_id, cur_total, ini_total,total_01,
		            total_02,total_03, total_04,total_05, total_06,total_07, total_08,
		            total_09,total_10,total_11,total_12, bqtotal,sumtotal)

		SELECT 	    @y_id,account_id, 0, 0, 0, 
			    0, 0, 0, 0,  0, 0,  0, 
			    0, 0, 0, 0,  0, 0
		FROM  Account
		WHERE account_id not in (select a_id from AccountBalance where Y_ID=@Y_ID)
		
	END

/*往来单位合计表*/
	IF (@Y_ID<>0) AND (@C_ID<>0) AND
	   NOT Exists(Select * from ClientsBalance where Y_ID=@Y_ID and C_id=@C_id)
	BEGIN
		    INSERT INTO ClientsBalance
			(Y_id, C_id, credit_total,sklimit,artotal,
		         artotal_ini, aptotal,aptotal_ini,pre_artotal, pre_artotal_ini,
		         pre_aptotal, pre_aptotal_ini)
		    VALUES
			(@Y_id,@C_id,0,  0, 0,
			 0,0,0,0,0,
		         0,0)
	END

/*公司往来合计表*/
	IF (@Y_ID<>0) AND (@C_ID<>0) AND
	   NOT Exists(Select * from Companybalance where Y_ID=@Y_ID and C_id=@C_id)
	BEGIN
		    INSERT INTO Companybalance
			(y_id, c_id, credit_total, sklimit,artotal, artotal_ini,
			 aptotal,aptotal_ini, pre_artotal, pre_artotal_ini,pre_aptotal,
		         pre_aptotal_ini)
		    VALUES(@y_id,@c_id,0,0,0,
		           0,0,0,0,0,0,
		           0)
	END
GO
