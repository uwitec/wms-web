

/*====================================*/
/*卡卷管理*/
/* wt 2015-10-28 11:00*/
/*select name,total,begindate,enddate,typeid,content,endday,useflag from wx_vip_ticket*/
/*====================================*/
CREATE PROCEDURE WebAPP_SetVipticket
(
@id				int,
@chvname		varchar(200),
@chvtotal		numeric(18,2),
@chvtypeid		int,
@chvbegindate	datetime,
@chvenddate		datetime,
@chvday			int,
@chvsaletotal	numeric(18,2),
@chvconent		varchar(255),
@chvcount		int,
@del			int
)
/*$Encode$--*/
AS
declare @chvoutmsg varchar(200)
select @chvoutmsg=''

if @id=-1
begin
	insert into wx_vip_ticket(name,total,begindate,enddate,typeid,content,endday,useflag,givecount)
	values(@chvname,@chvtotal,@chvbegindate,@chvenddate,@chvtypeid,@chvconent,@chvday,@chvsaletotal,@chvcount)
end
else
begin
	if not exists(select 1 from wx_vip_ticket where id=@id)
	begin
		select '没有找到相关信息' as outMsg,-1 as reCode
		return -1
	end

	if @del = 0
		update wx_vip_ticket set 
			name=@chvname,
			total=@chvtotal,
			begindate=@chvbegindate,
			enddate=@chvenddate,
			typeid=@chvtypeid,
			content=@chvconent,
			endday=@chvday,
			useflag=@chvsaletotal,
			givecount=@chvcount
		where id=@id
	else
		update wx_vip_ticket set deleted=1 where id=@id
end
select '操作成功' as outMsg,0 as reCode
return 0
GO
