/************************************************************

--功能：离线版本生成总部数据   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:zch 2012-03-08

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_MakeZBPackage]
	(
	  @nY_ID int = 0
     )

/*with encryption*/
AS 
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/

set nocount on

truncate table productsdts
truncate table barcodedts
truncate table clientsdts
truncate table employeesdts
truncate table VIPCarddts
truncate table companydts
truncate table sysconfigdts
truncate table storagesdts
truncate table cxidxdts
truncate table cxbilldts
truncate table cxtabledts
truncate table storehousedts
truncate table pricedts
truncate table pospricedts
truncate table otherstorehousedts
truncate table accountdts
truncate table locationdts
truncate table tasklistdts
truncate table emplimitexdts
truncate table billdtsidx
truncate table tranmanagebilldts
truncate table storemanagebilldts
truncate table salemanagebilldts
truncate table CxBillIdxDts
truncate table CxBillNewDts


declare @nMaxCount int,@billid int,@posid int

	
	/*只下载变动过的会员卡*/
	select @nMaxCount = ISNULL(maxcount, 0) from DownTimeList where tablename =  'VIPCard' and y_id = @nY_ID
	if @nMaxCount is null set @nMaxCount = 0
    insert into VIPCardDTS(VIPCardID, CardNo, Name, sex, Tel, Birthday, [Address], Comment, IDCard, CT_ID,
           BulidDate, ValidityDate, Pos_Id, E_id, IniMoney, TotalBuyMoney, SaveMoney, IntergralYE,
           IniIntergral, Integral, SwapIntegral, BuyCount, LoginPass, Deleted, Lose, StopUse,
           RemainderMoney, PinYin, [Guid], isLock, Y_ID)
    select VIPCardID, CardNo, Name, sex, Tel, Birthday, [Address], Comment, IDCard, CT_ID,
           BulidDate, ValidityDate, Pos_Id, E_id, IniMoney, TotalBuyMoney, SaveMoney, IntergralYE,
           IniIntergral, Integral, SwapIntegral, BuyCount, LoginPass, Deleted, Lose, StopUse,
           RemainderMoney, PinYin, [Guid], isLock, Y_ID
      from VIPCard
      where CAST(modifydate as  int) > @nMaxCount
      
	exec ts_j_setdowntimelist 'VIPCard', @nY_ID, 0   

	              	
	/*更新统一的系统设置，处理离线版本， 共用系统设置项库只读*/
	  insert into sysconfigdts(sys_id, [sysname], sysvalue, comment, sysflag, Y_ID)
	  select sys_id, [sysname], sysvalue, comment, sysflag, Y_ID 
	    from sysconfig
	    where sysflag =1 or ([sysname] = 'OpenAccount')

     /*下载促销信息*/
		/*促销单*/
     insert into cxidxdts(billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid)
		select billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid
 			from cxidx where billstates <> 2 and cast(cast(enddate as NUMERIC(25,8)) as int) >= cast(cast(GETDATE() as NUMERIC(25,8)) as int)
 			
     insert into cxbilldts(smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment)
		select smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment
		  from CxBill where Bill_ID in (select billid from cxidxdts)	

		/*简单促销*/
     insert into cxtabledts(cxid, p_id, u_id, posid, qty, discount, price, begindate,
              enddate, begintime, endtime, active, Y_ID,xq,priceleveal,lowpricelimit )  
       select cxid, p_id, u_id, posid, qty, discount, price, begindate,
              enddate, begintime, endtime, active, Y_ID,xq,priceleveal,lowpricelimit 
         from cxtable 
         where cast(cast(enddate as NUMERIC(25,8)) as int) >= cast(cast(GETDATE() as NUMERIC(25,8)) as int)

	/* 价格促销单*/
		INSERT INTO dbo.CxBillIdxDts
			(billid, billnumber, e_id, c_id, Y_ID, auditman, inputman, billstate, billdate, auditdate, cp_id, begindate, enddate, begintime, endtime, billtype, cardtype, 
							  weekday, priority, totalmoney, comment, guid, cpname)
		SELECT     billid, billnumber, e_id, c_id, Y_ID, auditman, inputman, billstate, billdate, auditdate, cp_id, begindate, enddate, begintime, endtime, billtype, cardtype, 
							  weekday, priority, totalmoney, comment, guid, cpname
		FROM         dbo.CxBillIdx    where Y_ID = 0 or Y_ID = @nY_ID

		INSERT INTO dbo.CxBillNewDts
			(smb_id, billid, p_id, unit_id, price, discount, lownum, billlimit, totallimit, total, grouptotal, presenttype, groupnum, comment, sale, guid)
		SELECT     smb_id, billid, p_id, unit_id, price, discount, lownum, billlimit, totallimit, total, grouptotal, presenttype, groupnum, comment, sale, guid
		FROM         dbo.CxBillNew where billid in (select billid from CxBillIdxDts)

    /*下载价格      	*/
	select @nMaxCount =  ISNULL(maxcount, 0) from DownTimeList where tablename =  'price' and y_id = @nY_ID
	if @nMaxCount is null set @nMaxCount = 0
	insert into pricedts(price_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, 
	           specialprice, unittype, lowprice, lastprice, lasttime, billid)
	    select price_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, 
	           specialprice, unittype, lowprice, lastprice, lasttime, billid
	      from price
	      where CAST(modifydate as  int) > @nMaxCount
    exec ts_j_setdowntimelist 'price', @nY_ID, 0	      
	
	/*下载门店物价      	*/
	select @nMaxCount = ISNULL(maxcount, 0) from DownTimeList where tablename =  'posprice' and y_id = @nY_ID
	if @nMaxCount is null set @nMaxCount = 0
	insert into PosPricedts(price_id, pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice,
	         specialprice, unittype, lowprice, lastprice, lasttime, billid, y_id)
	  select price_id, pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice,
	         specialprice, unittype, lowprice, lastprice, lasttime, billid, y_id 
	    from PosPrice
	    where (Y_ID = @nY_ID) and  CAST(modifydate as  int) > @nMaxCount
    exec ts_j_setdowntimelist 'posprice', @nY_ID, 0 	    
    

	/*处理离线模式自营店发货单*/
	
	declare @posguid varchar(50)
	if @nY_ID<>0
	begin
		select @posguid=guid from replicationauthorize where posid=@nY_ID
		if @posguid is null 
		begin	
			raiserror('机构没有授权，添加任务失败！',16,1)
			return -1
		end
	end

	if exists(select billid from tasklist where tranflag=1 and billtype in (150, 152) and DY_id=@nY_ID)/*发货单*/
	begin
		/*索引*/
		insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty)
		select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty
			from billidx where billid in (select distinct billid from tasklist where tranflag=1 and billtype in (150, 152) and DY_ID=@nY_ID) and billstates = 0
		/*发货单 select * from salemanagebill*/
		insert into Salemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, location_id2 ,supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,thqty,newprice,orgbillid,aoid,RowGuid,YCostPrice,YGUID,Y_ID,instoretime
			,batchbarcode,scomment,batchprice)
		select smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id,location_id2, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag ,thqty,newprice,0,aoid,RowGuid,YCostPrice,YGUID,Y_ID,instoretime
			,batchbarcode,scomment,batchprice
		from Salemanagebill where bill_id in (select billid from billdtsidx where billtype in (150, 152) and C_ID=@nY_ID)

		declare posguidcur cursor for
		select billid,DY_ID from tasklist 
		where tranflag=1 and billtype in (150, 152) and DY_ID=@nY_ID

		open posguidcur

		fetch next from  posguidcur into @billid,@posid
		while @@fetch_status=0
		begin
			select @posguid=null
			select @posguid=isnull(guid,'') from replicationauthorize where posid=@posid
			if @posguid is null goto error
			update billdtsidx set posguid=@posguid where billid=@billid and billtype in (150, 152)
			fetch next from  posguidcur into @billid,@posid
		end
		close posguidcur
		deallocate posguidcur
		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (150, 152) and DY_ID = @nY_ID 
	end

return 0
error:
	close posguidcur
	deallocate posguidcur
	raiserror('机构没有授权，添加任务失败！',16,1)
	return -1
GO
