

CREATE PROCEDURE ts_M_qrStopSaleDay
(
  @nRet	INT OUTPUT,
  @BillType int,
  @validdate datetime
)
AS

/*近效期商品禁止销售*/

set nocount on 
declare @Day int,@Y_id int,@StopSaleDay INT,@StopSaleBuyMode INT 
SET @Y_id=0
SELECT @Y_id=cast(SysValue as int) FROM SysConfig where UPPER([SysName])='Y_ID'
SELECT @StopSaleDay=cast(SysValue as int) FROM SysConfig where Y_id = @Y_id and UPPER([SysName])='STOPSALEDAY'
if (@StopSaleDay=0) 
begin
        /*没有启用近效期商品禁止销售*/
	/*@StopSaleDay=1 启用近效期商品禁止销售*/
  	select @nRet=0
	return 0
END
SELECT @StopSaleBuyMode=cast(SysValue as int) FROM SysConfig where UPPER([SysName])='STOPSALEBUYMODE'
if (@StopSaleBuyMode <> 1) 
begin
    /*@StopSaleBuyMode=1 提示并不保存*/
  	select @nRet=0
	return 0
end

if not exists(select * from StopSaleDay where BillType=@BillType)
begin
  	select @nRet=0
end else
begin
  	select @Day=[Day] from StopSaleDay where BillType=@BillType
  	if (@Day <> 0) and (@validdate > 10)
            and ( DATEDIFF(day, getdate(), @validdate) < @Day )
    		select @nRet=-1
  	else 
     		select @nRet=0
end


/*select @nRet as nRet*/
GO
