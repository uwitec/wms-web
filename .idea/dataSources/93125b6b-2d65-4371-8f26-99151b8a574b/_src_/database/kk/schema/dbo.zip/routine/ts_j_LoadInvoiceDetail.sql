

CREATE	 PROCEDURE [ts_j_LoadInvoiceDetail]
	(
	 @nInvoiceBillID int = 0,
 	 @nRet int output     /*判断是否有查询数据返回*/
        )
AS 
/*Params Ini begin*/
if @nInvoiceBillID is null  SET @nInvoiceBillID = 0
/*Params Ini end*/

declare @nIVType int
set @nRet = -1
  select @nIVType = invoicetype from invoiceidx where [id] = @nInvoiceBillID 

if @nIVType = 0 goto SaleIV
else if @nIVType = 1 goto BuyIV
else goto FinanceIV

SaleIV:

  select 
        b.billdate, 	b.auditdate,	 b.billnumber,		b.CName, 	b.Note, 
	b.eName, 	 b.inputmanname, 	b.auditmanname, b.BILLSTATES, 
	ysmoney=case when b.billtype in (11,13) then -b.ysmoney else b.ysmoney end,	
	b.billtype,      b.invoice as OrderInvoiceID,
 	iv.CurrTotal,	iv.billid,	 iv.BillGuid,           iv.smb_id,	
	iv.YKTotal,	iv.[id] as InvoiceDetailID,		iv.quantity,	iv.total,	 
	iv.currquantity,		 iv.P_id,		iv.RowGuid, 	iv.YKQuantity,
        isnull(p.Code, ' ') as PCode,	 isnull(p.[name], ' ') as PName,  	isnull(p.standard, ' ') as standard,
	isnull(p.modal,' ') as modal,	 isnull(p.makearea, ' ') as makearea,	isnull(p.MEDNAME, ' ') as MEDTYPE,	
    	isnull(s.batchno, ' ') as batchno,			isnull(s.VALIDDATE, 0) as VALIDDATE,
	isnull((CASE s.unitid
                  WHEN p.unit1_id THEN 1
                  WHEN p.unit2_id THEN p.rate2 
                  WHEN p.unit3_id THEN p.rate3
                  WHEN p.unit4_id THEN p.rate4
                END), 1) AS unitrate,
        isnull((CASE s.unitid
                 WHEN p.unit1_id THEN p.unit1NAME
                 WHEN p.unit2_id THEN p.unit2NAME
                 WHEN p.unit3_id THEN p.unit3NAME
                 WHEN p.unit4_id THEN p.unit4NAME
               END), 0) AS unit,
        isnull(s.unitid, 0) as unit_id,
	isnull(s.Discountprice, 0) as Discountprice, 		isnull(s.Totalmoney, 0) as Totalmoney, 	 
        isnull(s.TaxMoney, 0) as TaxMoney,			isnull(s.taxprice, 0) as taxprice,     
	isnull(s.Comment, ' ') as Comment,			isnull(s.taxTotal,0) as taxtotal,
    	isnull(s.AOID, 0) as AOID,				isnull(s.IOTAG, 0) as IOTAG
    from invoice iv
    left join vw_x_billidx b on iv.billguid = b.guid
    left join salemanagebill s on iv.smb_id = s.smb_id
    left join vw_products p on iv.p_id = p.product_id
    where b.billtype in (10,11,12,13,16,17,18,32,112,210,211,150) and
    	  iv.invoiceid = @nInvoiceBillID

  goto Succes

BuyIV:
  select 
        b.billdate, 	b.auditdate,	 b.billnumber,		b.CName, 	b.Note, 
	b.eName, 	 b.inputmanname, 	b.auditmanname, b.BILLSTATES, 
	ysmoney=case when b.billtype in (21,24,25) then -b.ysmoney else b.ysmoney end,	
	b.billtype,      b.invoice as OrderInvoiceID,
 	iv.CurrTotal,	iv.billid,	 iv.BillGuid,           iv.smb_id,	
	iv.YKTotal,	iv.[id] as InvoiceDetailID,		iv.quantity,	iv.total,	 
	iv.currquantity,		 iv.P_id,		iv.RowGuid, 	iv.YKQuantity,
        isnull(p.Code, ' ') as PCode,	 isnull(p.[name], ' ') as PName,  	isnull(p.standard, ' ') as standard,
	isnull(p.modal,' ') as modal,	 isnull(p.makearea, ' ') as makearea,	isnull(p.MEDNAME, ' ') as MEDTYPE,	
    	isnull(s.batchno, ' ') as batchno,			isnull(s.VALIDDATE, 0) as VALIDDATE,
	isnull((CASE s.unitid
                  WHEN p.unit1_id THEN 1
                  WHEN p.unit2_id THEN p.rate2 
                  WHEN p.unit3_id THEN p.rate3
                  WHEN p.unit4_id THEN p.rate4
                END), 1) AS unitrate,
        isnull((CASE s.unitid
                 WHEN p.unit1_id THEN p.unit1NAME
                 WHEN p.unit2_id THEN p.unit2NAME
                 WHEN p.unit3_id THEN p.unit3NAME
                 WHEN p.unit4_id THEN p.unit4NAME
               END), 0) AS unit,
        isnull(s.unitid, 0) as unit_id,
	isnull(s.Discountprice, 0) as Discountprice, 		isnull(s.Totalmoney, 0) as Totalmoney, 	 
        isnull(s.TaxMoney, 0) as TaxMoney,			isnull(s.taxprice, 0) as taxprice,     
	isnull(s.Comment, ' ') as Comment,			isnull(s.taxTotal,0) as taxtotal,     
    	isnull(s.AOID, 0) as AOID,				isnull(s.IOTAG, 0) as IOTAG
    from invoice iv
    left join vw_x_billidx b on iv.billguid = b.guid
    left join Buymanagebill s on iv.smb_id = s.smb_id
    left join vw_products p on iv.p_id = p.product_id
    where b.billtype in (20,21,24,25,28,35,122,220,221) and
    	  iv.invoiceid = @nInvoiceBillID

  goto Succes


FinanceIV:
select 
        b.billdate, 	b.auditdate,	 b.billnumber,		b.CName, 	b.Note, 
	b.eName, 	 b.inputmanname, 	b.auditmanname, b.BILLSTATES, 
	b.ysmoney,	b.billtype,      b.invoice as OrderInvoiceID,
 	iv.CurrTotal,	iv.billid,	 iv.BillGuid,           iv.smb_id,	
	iv.YKTotal,	iv.[id] as InvoiceDetailID,		iv.quantity,	iv.total,	 
	iv.currquantity,iv.P_id,		iv.RowGuid, 	iv.YKQuantity,
        ' ' as PCode, 	' ' as PName, 	 ' ' as standard,
	' ' as modal,	 ' ' as makearea, ' ' as MEDTYPE,	
    	' ' as batchno,			 0 as VALIDDATE,
	1 AS unitrate,
        0 AS unit,
        0 as unit_id,
	0 as Discountprice, 		0 as Totalmoney, 	 
        0 as TaxMoney,			0 as taxprice,     
	' ' as Comment,			     
    	0 as AOID,			0 as IOTAG
    from invoice iv
    left join vw_x_billidx b on iv.billguid = b.guid
    where b.billtype in (15,23,87,88) and
    	  iv.invoiceid = @nInvoiceBillID
  goto Succes

Succes:
IF @@ROWCOUNT >0 SET @nRET = 1
RETURN 0
GO
