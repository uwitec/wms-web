


CREATE procedure ts_c_BalanceCheck
(
	@nBillid numeric(10,0)
)
/*with encryption*/
as
set nocount on
declare @n1 NUMERIC(25,8),@n2 NUMERIC(25,8),@n3 NUMERIC(25,8),@n4 NUMERIC(25,8),@n5 NUMERIC(25,8)
select @n1=isnull(sum(jdmoney),0) from accountdetailtmp ad,account a where ad.billid=@nbillid and left(a.class_id,6)='000001' and a.account_id=ad.a_id
select @n2=isnull(sum(jdmoney),0) from accountdetailtmp ad,account a where ad.billid=@nbillid and left(a.class_id,6)='000002' and a.account_id=ad.a_id
select @n3=isnull(sum(jdmoney),0) from accountdetailtmp ad,account a where ad.billid=@nbillid and left(a.class_id,6)='000003' and a.account_id=ad.a_id
select @n4=isnull(sum(jdmoney),0) from accountdetailtmp ad,account a where ad.billid=@nbillid and left(a.class_id,6)='000004' and a.account_id=ad.a_id
select @n2=@n2+@n3-@n4
if abs(@n1-@n2)>0.01 return -8

/*return 0*/
GO
