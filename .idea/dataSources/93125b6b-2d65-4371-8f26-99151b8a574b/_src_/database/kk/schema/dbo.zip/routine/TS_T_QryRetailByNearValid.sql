CREATE	 PROCEDURE TS_T_QryRetailByNearValid
(
  @day int = 0,  /*有效期小于多少天*/
  @Y_ID int = 0, /*机构名称*/
  @E_ID int = 0, /*销售员*/
  @PTypeRange varchar(8000)   /*商品类别id */
)

 AS
  /*zjx--2017-04-25--处理（新）自定义类别*/
    DECLARE @info_ID INT 
    DECLARE @ColName VARCHAR(100)
    DECLARE @szSql varchar(2000)
    DECLARE @classid varchar(100)
    CREATE TABLE #PORDUCTS ([p_id] [int] NOT NULL DEFAULT(0))
    if @PTypeRange<>'' 
    begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@PTypeRange))
            /*zjx.通过选择自定义类别id的字符串获取class_ID字符串串*/
		    SELECT @classid = dbo.GetCateClassids(@PTypeRange)  
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
            /*根据所选择的类别ID找出所关联的商品*/
		    set @szSql =  'INSERT INTO #PORDUCTS(p_id) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @ColName + 
			' in (select type  from DecodeStr(''' +@classid +'''))'  
		    exec (@szSql)
    end
   /*近效期销售数据*/
   select s2.instoretime, s2.p_id, s2.supplier_id, s2.batchno, s2.factoryid, s2.ss_id, s2.costprice,
                                   s2.validdate, s2.location_id, s2.commissionflag, s2.Y_ID, s2.makedate, Sum(s2.quantity) qty into #validq
                              from salemanagebill s2 left join billidx i2 on s2.bill_id = i2.billid 
                                where i2.billtype = 12 AND i2.billstates = 0 and s2.p_id > 0
                                                       /*传入天数为0，没有有效的有效期至，均默认查全部，其他查传入的有效期天数内的销售数据*/
                                                       and ((@day = 0) or (ABS(DATEDIFF(YEAR, IsNull(s2.validdate, '1900-01-01'), GetDate())) > 20) or (DATEDIFF(DAY, i2.billdate, s2.validdate) <= @day ))
                                                       and (@Y_ID = 0 or i2.Y_ID = @Y_ID) 
                                                       and (@E_ID = 0 or i2.e_id = @E_ID)
                                 GROUP by s2.instoretime, s2.p_id, s2.supplier_id, s2.batchno, s2.factoryid, s2.ss_id, s2.costprice,
                                          s2.validdate, s2.location_id, s2.commissionflag, s2.Y_ID, s2.makedate 
   /*累计销售数量*/
   select s3.instoretime, s3.p_id, s3.supplier_id, s3.batchno, s3.factoryid, s3.ss_id, s3.costprice,
                                 s3.validdate, s3.location_id, s3.commissionflag, s3.Y_ID, s3.makedate, count(s3.smb_id) cnt, Sum(s3.quantity) qty into #sumSale
                            from salemanagebill s3 left join billidx i3 on s3.bill_id = i3.billid 
                              where i3.billtype = 12 AND i3.billstates = 0 and s3.p_id > 0                                                  
                                                     and (@Y_ID = 0 or i3.Y_ID = @Y_ID) 
                                                     and (@E_ID = 0 or i3.e_id = @E_ID)
                               GROUP by s3.instoretime, s3.p_id, s3.supplier_id, s3.batchno, s3.factoryid, s3.ss_id, s3.costprice,
                                        s3.validdate, s3.location_id, s3.commissionflag, s3.Y_ID, s3.makedate 
   
   SELECT identity(int, 1, 1) as RecNo, i.billnumber, i.billdate, 
           case when s.AOID = 8 then sp.Code else p.Code end as Serial_Number,
            case when s.AOID = 8 then sp.name else p.Name end as PName,
             case when s.AOID = 8 then '' else p.MakeArea end as MakeArea,
              case when s.AOID = 8 then sp.comment else p.Comment end as Comment,   
           YName = (select name from company where company_id = i.Y_ID), 
            case when s.AOID = 8 then sp.alias else p.alias end as alias,
             case when s.AOID = 8 then '' else p.[standard] end as standard,
              case when s.AOID = 8 then '' else bf.AccountComment end as factory,
               case when s.AOID = 8 then sp.UnitName else u.name end as unit,
                s.batchno,s.quantity, 
           /*入库日期在前后20年外的，都默认为无入库日期，包含1900-01-01， 9999-01-01,2999-01-01等*/
          case when s.AOID = 8 then '' else (case when ABS(DATEDIFF(YEAR, IsNull(s.instoretime, '1900-01-01'), GetDate())) <= 20 then convert(varchar(10), s.instoretime, 20) else '-' end) end as instoretime, 
          /*在库天数           */
	      /*(case when ABS(DATEDIFF(YEAR, IsNull(s.instoretime, '1900-01-01'), GetDate())) <= 20 then CAST(DATEDIFF(DAY, s.instoretime, i.billdate) AS VARCHAR) else '-' END) as DayInStore, */
	      /*BUG33968 根据ZJL要求，没有库存，则取该批次最后一次销售日期和进库日期间隔，有库存，则取当前日期和进库日期间隔*/
          (case when ABS(DATEDIFF(YEAR, IsNull(s.instoretime, '1900-01-01'), GetDate())) > 20 then '-' 
                else CAST(DATEDIFF(DAY, s.instoretime, (case when ISNULL(sh.quantity, 0) <= 0 then 
	                                                            (select MAX(x.BillDate) from billidx x inner join salemanagebill y on x.billid = y.bill_id 
                                                                   where s.p_id=y.p_id and s.supplier_id=y.supplier_id and 
                                                                         s.costprice=y.costprice and s.batchno=y.batchno and s.makedate=y.makedate and 
                                                                         s.validdate=y.validdate and s.ss_id=x.sout_id and
                                                                         s.location_id=y.location_id and s.commissionflag = y.commissionflag and
                                                                         s.instoretime=y.instoretime and s.Y_ID = y.Y_ID and
                                                                         s.factoryid = y.factoryid                                                                         
                                                                 )
                                                              else 
                                                                Getdate()
                                                         end) ) AS VARCHAR)                                                                   
           END) as DayInStore, 	                   	      	      	      	      	      
	      /*有效期至*/
	      (case when ABS(DATEDIFF(YEAR, IsNull(s.validdate, '1900-01-01'), GetDate())) <= 20 then convert(varchar(10), s.validdate, 20) else '-' end) as validdate, 
	      /*有效期天数	      */
	      (case when ABS(DATEDIFF(YEAR, IsNull(s.validdate, '1900-01-01'), GetDate())) <= 20 then CAST(DATEDIFF(DAY, getdate(), isnull(s.validdate,'1900-01-01')) AS VARCHAR) else '-' END) as validday, /*在库天数	            */
	      ISNULL(bm.quantity, 0) as buyqty, /*采购数量*/
	      ISNULL(sh.quantity, 0) as stockqty, /*库存数量	    */
	      ISNULL(bm.costprice, 0) as buyprice, /*采购单价*/
	      ISNULL(sh.costtaxtotal, 0) as stocktotal, /*库存金额	      */
	      ISNULL(validq.qty, 0) as validsaleqty, /*近效期销售的数量	      */
	      ISNULL(sumSale.qty, 0) as saleqty, /*累计销售数量*/
	      ISNULL(s.taxtotal, 0) as taxtotal, /*销售金额*/
	      ISNULL(s.taxtotal, 0) - ISNULL(s.costtaxtotal, 0) as profit, /*毛利*/
	      (CASE ISNULL(s.costtaxtotal, 0) when 0 then 100 else (ISNULL(s.taxtotal, 0) - ISNULL(s.costtaxtotal, 0)) * 100/ISNULL(s.costtaxtotal, 0) end) as profitper, /*毛利率*/
	      (CASE ISNULL(bm.quantity, 0) when 0 then 0 else ISNULL(s.quantity, 0)*100/ISNULL(bm.quantity, 0) END) as buysaleper, /*采销比*/
	      ISNULL(sumSale.cnt, 0) as salenum, /*销售次数 */
	      case when s.AOID = 8 then '' else isnull(c.name,'') end as suppname /*供应商*/
   INTO #QryResult
   FROM salemanagebill s left join billidx i on s.bill_id = i.billid 
                         left join dbo.vw_c_products  as p on p.product_id = s.p_id
                         left join VW_H_SpecialProducts as sp on sp.product_id = s.p_id
                         left join unit u on u.unit_id = s.unitid
                         /*供应商 */
                         left join clients c on s.supplier_id=c.client_id  
                         /*生产产家*/
                         left join basefactory bf on s.factoryid = bf.CommID 
                         /*匹配11要素找到库存数量*/
                         left join storehouse sh on s.p_id=sh.p_id and s.supplier_id=sh.supplier_id and 
                                                    s.costprice=sh.costprice and s.batchno=sh.batchno and s.makedate=sh.makedate and 
                                                    s.validdate=sh.validdate and s.ss_id=sh.s_id and
                                                    s.location_id=sh.location_id and s.commissionflag = sh.commissionflag and
                                                    s.instoretime=sh.instoretime and s.Y_ID = sh.Y_ID and
                                                    s.factoryid = sh.factoryid 
                         /*匹配11要素找到采购数量*/
                         left join buymanagebill bm on s.p_id=bm.p_id and s.supplier_id=bm.supplier_id and 
                                                       s.costprice=bm.costprice and s.batchno=bm.batchno and s.makedate=bm.makedate and 
                                                       s.validdate=bm.validdate and s.ss_id=bm.ss_id and
                                                       s.location_id=bm.location_id and s.commissionflag = bm.commissionflag and
                                                       s.instoretime=bm.instoretime and s.Y_ID = bm.Y_ID and
                                                       s.factoryid = bm.factoryid
                         /*近效期销售的数量*/
                         left join 
                           #validq as validq on s.p_id = validq.p_id and s.supplier_id = validq.supplier_id and 
			                              s.costprice = validq.costprice and s.batchno = validq.batchno and s.makedate = validq.makedate and 
			                              s.validdate = validq.validdate and s.ss_id = validq.ss_id and
			                              s.location_id = validq.location_id and s.commissionflag = validq.commissionflag and
			                              s.instoretime = validq.instoretime and s.Y_ID = validq.Y_ID and
			                              s.factoryid = validq.factoryid
			           /*累计销售数量*/
                       left join 
                         #sumSale as sumSale on s.p_id = sumSale.p_id and s.supplier_id = sumSale.supplier_id and 
			                             s.costprice = sumSale.costprice and s.batchno = sumSale.batchno and s.makedate = sumSale.makedate and 
			                             s.validdate = sumSale.validdate and s.ss_id = sumSale.ss_id and
			                             s.location_id = sumSale.location_id and s.commissionflag = sumSale.commissionflag and
			                             s.instoretime = sumSale.instoretime and s.Y_ID = sumSale.Y_ID and
			                             s.factoryid = sumSale.factoryid
			           
   where i.billtype = 12 AND i.billstates = 0 and s.p_id > 0
                         and ((ABS(DATEDIFF(YEAR, IsNull(s.validdate, '1900-01-01'), GetDate())) > 20) /*“有效期至”无效*/
                               or 
                              (ABS(DATEDIFF(YEAR, IsNull(s.validdate, '1900-01-01'), GetDate())) <= 20 and i.billdate <= s.validdate)) /*有效期内*/
                         and (@Y_ID = 0 or i.Y_ID = @Y_ID) and (@E_ID = 0 or i.e_id = @E_ID)
                         and ((@day = 0) or (s.validdate < convert(varchar(10),dateadd(day, @day, getdate()),20) and s.validdate > convert(varchar(10), getdate(), 20))) 
                         and ((@PTypeRange = '') or (p.product_id in (select p_id from #PORDUCTS)))  
   order by i.billdate asc, i.billnumber asc                         
                             
   IF object_id(N'#PORDUCTS', N'U') is not null  
      DROP TABLE #PORDUCTS     
   IF object_id(N'#TmpP', N'U') is not null  
    DROP TABLE #TmpP
    
   SELECT * FROM #QryResult

  IF object_id(N'#QryResult', N'U') is not null  
    DROP TABLE #QryResult
    
    drop table #validq
    drop table #sumSale
GO
