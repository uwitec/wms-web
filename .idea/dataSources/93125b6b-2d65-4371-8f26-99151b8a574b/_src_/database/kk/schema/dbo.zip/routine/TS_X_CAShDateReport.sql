

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

现金银行的日记账
最后的修改日期 2003-11-20
@lMode        方式，备用
@lAccountID   科目的ID号
@lTimeMode    时间的选择方式
@lStartPeriod 开始的期号
@lENDPeriod   结束的期号
@BeginDate 		开始的日期
@EndDate			结束的日期
@lVisable     对方科目的显示
********************************************/
CREATE PROCEDURE [TS_X_CAShDateReport]
(	@lMode        INT,
  @lAccountID   INT,
  @lTimeMode    INT,
  @lStartPeriod INT,
  @lENDPeriod   INT,
  @StartDate 	DATETIME,
  @EndDate	DATETIME,
  @lVisable     INT,
  @OperatorID	INT = 0,
  @YClass_id  	VARCHAR(60)=''
)
/*with encryption*/
AS
/*Params Ini begin*/
if @OperatorID is null  SET @OperatorID = 0
if @YClass_id is null  SET @YClass_id = ''
/*Params Ini end*/
  SET NOCOUNT ON 
  DECLARE @SQLScript  VARCHAR(8000)
  DECLARE @SQLTime		VARCHAR(200)
  DECLARE @SQLName		VARCHAR(50)
  DECLARE @CASH_ID 	  VARCHAR(30)
  DECLARE @BANK_ID 	  VARCHAR(30)
  DECLARE @EMPTY_ID   VARCHAR(10)
  DECLARE @DATA_MODE1 INT
  DECLARE @DATA_MODE2 INT
  DECLARE @BEGINTOtal NUMERIC(25,8)
  
  SELECT  @CASH_ID='000001000003'/*现金*/
  SELECT  @BANK_ID='000001000004'/*全部银行存款合计*/
  SELECT  @DATA_MODE1=1
  SELECT  @DATA_MODE2=2

/*--------------分支机构 */
   DECLARE @Companytable VARCHAR(200)
   DECLARE @SQLYClassId VARCHAR(200) 


   IF @YClass_id not in ('','000000','%%')    /*增加分支机构查询 */
     SET @SQLYClassId = @YClass_id + '%'
   ELSE SET @SQLYClassId = '%%' 

/*------------------------------授权*/
  create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*-------------------------------*/

  SELECT  @SQLScript=''
	SELECT  @SQLTime=''
	SELECT  @SQLName=''
  SELECT  @EMPTY_ID=' '

/*时间段的方式 @SQLTime*/
/*对方科目 @SQLName*/

  SELECT  @BEGINTOtal=isnull(sum([Ini_Total]),0) FROM accountbalance WHERE [a_ID]=@lAccountID
  
  IF  @lTimeMode=@DATA_MODE1
  BEGIN
    SELECT  @BEGINTOtal=@BEGINTOtal+isnull(sum(YAD.[JdMoney]),0)
    FROM 
      (select b.period,ad.a_id,ad.JdMoney
       from accountDetail ad
       left join billidx b ON B.billid=ad.billid
       where billstates = 0
       union
       select period,a_id,Jdmoney from YAccountDetail where billstates = 0
      ) YAD
      WHERE YAD.[Period]<@lStartPeriod and YAD.[A_ID]=@lAccountID

    SELECT  @SQLTime='([Period] between '+CAST(@lStartPeriod AS VARCHAR)
      +' and '+CAST(@lStartPeriod AS VARCHAR)+')' 
  END
  ELSE BEGIN
    SELECT  @BEGINTOtal=@BEGINTOtal+YAD.[JdMoney]
    FROM
      (select b.billdate,ad.a_id,ad.jdmoney
       from accountDetail ad
       left join billidx b ON B.billid=ad.billid
       where billstates = 0
       union
       select billdate,a_id,jdmoney from YAccountDetail where billstates = 0
      ) YAD
      WHERE YAD.[BillDate]<@StartDate and YAD.[A_ID]=@lAccountID

    SELECT  @SQLTime='([BillDate] between '
      +CHAR(39)+CONVERT(VARCHAR(10),@StartDate,20)+CHAR(39)+' and '
      +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'
  END

  IF  @lVisable=@DATA_MODE1
    SELECT  @SQLName='([Serial_number]) AS [Name]'
  ELSE
    SELECT  @SQLName='([Serial_number]+[Name]) AS [Name]'

  
  SELECT  (0) AS [C_id], (0) AS [Y_ID], (0) AS [BillID], @EMPTY_ID AS [BillDate], (0) AS [Period], @EMPTY_ID AS [BillNumber],
    (0) AS [BillStats], @EMPTY_ID AS [Note], (0) AS [BILLTYPE],  (0) AS [INPUTMAN],
    @BEGINTOtal AS [JdMoney],0 as a_id, @lAccountID AS [Account_ID], @EMPTY_ID AS [Class_ID], @EMPTY_ID AS [Name]  
    INTO #TempA


SELECT  @SQLScript=
   'SELECT  DISTINCT  YAD.*, isnull(a.Account_id,0)Account_id,isnull(A.Class_id,'''')Class_id,isnull(A.[name],'''')[name]
    FROM
      (SELECT B.C_ID,B.Y_ID,B.billid,CONVERT(VARCHAR(10), B.[BillDate], 20) AS [BillDate], 
             [Period], [Billnumber], [BillStates], Note, B.[BILLTYPE], B.[INPUTMAN],
             isnull(AD.JDMoney,0)jdmoney,isnull(AD.a_id,0)a_id
       FROM billidx B
       inner JOIN
            (select billid,a_id,isnull(sum(JDMoney),0)JDMoney FROM AccountDetail
             where [A_ID]='+CAST(@lAccountID AS VARCHAR)+' Group by billid,a_id
            )AD
       ON  B.Billid=AD.billid
       WHERE '+@SQLTime+' and  billstates = 0  
       UNION ALL
       SELECT Distinct C_ID,Y_ID,billid,CONVERT(VARCHAR(10), [BillDate], 20) AS [BillDate], 
             [Period], [Billnumber], [BillStates], '' '' as Note, [BILLTYPE], [INPUTMAN],
             JDMoney,a_id
       FROM YAccountDetail
       WHERE a_id='+CAST(@lAccountID AS VARCHAR)+' and '+@SQLTime+' and billstates = 0
       )YAD
       LEFT JOIN
       (SELECT  [Account_ID], [Class_ID], '+@SQLName+'
        FROM Account
        WHERE [DELETEd]<>1 and [Child_number]=0
       )A ON A.[Account_ID]=YAD.[A_ID]
       LEFT JOIN
       Company Y  ON Y.Company_id=YAD.Y_id
       where  Y.Class_ID like ' + char(39) + @SQLYClassId + char(39)+' 
       and (('+@Companytable+'=0) OR (YAD.Y_ID in (select [id] from #Companytable))) 
    UNION 
    SELECT  * FROM #TempA  order by YAD.billdate'

/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO Succee


Succee:

  IF object_id('tempdb..'+@Companytable) IS NOT NULL
     EXEC('drop table tempdb..'+@Companytable)

  RETURN  0
GO
