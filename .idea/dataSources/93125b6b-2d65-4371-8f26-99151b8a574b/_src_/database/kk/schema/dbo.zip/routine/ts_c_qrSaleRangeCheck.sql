

create proc ts_c_qrSaleRangeCheck
(
	@nC_id int,			
	@nP_id int,
	@Type int = 0			/* 0表示往来单位，1表示机构*/
)
/*with encryption*/
as
set nocount on 
declare @iReturn int

select @iReturn=-1

if @Type = 0
begin
	if not exists(select top 1 * from SaleRangeCheck where c_id = @nC_id)
	  select @iReturn=0
	else
	if exists(select 1 from products where product_id=@nP_id and sr_id=0) 
	  select @iReturn=0
	else 
	if exists(select sr.sr_id from SaleRangeCheck sr,products p where sr.sr_id=p.sr_id and p.product_id=@nP_id and sr.c_id=@nC_id) 
	  select @iReturn=0
end
else if @Type = 1
begin
	if not exists(select top 1 * from organRangeCheck where c_id = @nC_id)		/*机构是否选择销售类别*/
	  select @iReturn=0
	else
	if exists(select 1 from products where product_id=@nP_id and sr_id=0)   /*药品是否选择销售类别*/
	  select @iReturn=0
	else 
	if exists(select sr.sr_id from organRangeCheck sr,products p where sr.sr_id=p.sr_id and p.product_id=@nP_id and sr.c_id=@nC_id)  /*有相同存在*/
	  select @iReturn=0
end

select @iReturn as nRet
GO
