

CREATE	   procedure ts_GetSysValue
(
	@szSysName varchar(60),
	@szSysValue varchar(80) output,
	@nY_ID int = 0
)  
/*with encryption*/
AS  
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
SET NOCOUNT ON
SELECT @szSysValue='0'

SELECT @szSysValue=case sysvalue when '' then '0' else ISNULL(sysvalue,'0') end FROM sysconfig WHERE [sysname]=@szSysName  and y_id = @nY_ID

IF @@ROWCOUNT<=0
BEGIN
  IF @szSysName = 'GUID'
  BEGIN
    SET @szSysValue = NEWID()
    EXEC ts_SetSysValue @szSysName, @szSysValue, @nY_ID
  END
  ELSE
    RETURN -1
END

RETURN 0
GO
