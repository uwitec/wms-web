









CREATE	     PROCEDURE [Ts_L_CheckBaseInfo]
	(@TableName	varchar(30),
	 @product_id	varchar(100),
	 @unitid		[int]=0
	 )
AS 
/*Params Ini begin*/
if @unitid is null  SET @unitid = 0
/*Params Ini end*/
declare @child_number	int
/*删除商品信息库*/
if upper(@tableName)='PRODUCTS'
begin
	if @unitid<>0 
	 if exists(select P_id from productdetail where p_id=@product_id and unitid=@unitid)
	    or exists(select P_id from buymanagebill where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from PriceBill where P_id=@product_id and Unitid=@unitid)   /*增加调价单的判断*/
	    or exists(select P_id from Salemanagebill where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from GoodsCheckBill where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from storemanagebill where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from TranManagebill where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from buymanagebilldrf where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from Salemanagebilldrf where P_id=@product_id and Unitid=@unitid)
	    or exists(select P_id from GoodsCheckBillDrf where P_id=@product_id and Unitid=@unitid) 
	    or exists(select P_id from storemanagebilldrf where P_id=@product_id and Unitid=@unitid) 
	    or exists(select P_id from TranManagebillDrf where P_id=@product_id and Unitid=@unitid) 
	    or exists(select P_id from storehouseini 	where P_id in (select product_id from  Products Where P_id=@product_id and unit1_id=@unitid) )	/*库存期初*/
	    or exists(select P_id from storedxini 	where P_id in (select product_id from  Products Where P_id=@product_id and unit1_id=@unitid) )	/*代销库存期初*/
	    or exists(select P_id from storebrrowini 	where P_id in (select product_id from  Products Where P_id=@product_id and unit1_id=@unitid) )	/*借进借出期初*/

	begin
/*		Raiserror('商品单位已经使用！',16,1)*/
		return -4
	end

/*    是否可删除*/
	/*if exists(select P_id from Storehouseini where p_id=@product_id) 
		or exists(select * from dxstorehouseini where p_id=@product_id)
	begin
--		Raiserror('库存已经有此商品！',16,1)
		return -1
	end*/
	
	if exists(select P_id from storehouse where P_id=@product_id) or exists(select P_id from PriceBill where P_id=@product_id )
	begin
/*		Raiserror('库存已经有此商品！',16,1)  这儿增加调价单的判断，做了调价单，单位也不能修改,其它税率这些相同判断的也不能修改*/
		return -2
	end
	/*判断明细这段不知道为什么一直没放出来，现在暂时不放出来时考虑到效率，或许还有当时没放出来的其它原因*/
	/*if exists(select P_id from productdetail where p_id=@product_id)
	begin
--		Raiserror('商品明细已经产生！',16,1)
		return -3
	end*/
end
if upper(@tableName)='EMPLOYEES'
begin
/*-    是否可删除*/
	if exists(select * from billidx where E_id=@product_id) 
	begin
/*		Raiserror('已经有该经手人的单据！',16,1)*/
		return -1
	end
/*	if exists(select * from productdetail where E_id=@product_id)
	begin
		Raiserror('商品明细已经产生不能删除！',16,1)
		return -1
	end*/
end


if upper(@TableName)='CLIENTS'
/* if @unitid = 1    --用于停用往来单位时进行判断*/
begin
        if exists(select * from clientsbalance where C_id=@product_id and (artotal <> 0 or aptotal <> 0))
        return -1     
  

/*-    是否可删除*/
	if exists(select * from billidx where C_id=@product_id  and billtype not in (150,151,155,160,161,165)) 
	begin
/*		Raiserror('已经有该单位的单据！',16,1)*/
		return -1
	end
	if exists(select f.* from financebilldrf f left join billidx b on f.bill_id=b.billid
		  where f.C_id=@product_id and b.billtype not in (150,151,155,160,161,165)) 
	begin
/*		Raiserror('已经有该单位的草稿单据！',16,1)*/
		return -1
	end

	if exists(select a.* from accountdetail a left join billidx b on a.billid=b.billid
		  where a.C_id=@product_id and b.billtype not in (150,151,155,160,161,165))
	begin
/*		Raiserror('科目明细已经产生不能删除！',16,1)*/
		return -1
	end
	if exists(select * from clientsbalance where 
		(artotal_ini<>0 or artotal<>0 or apTotal_ini<>0 or apTotal<>0 
		or pre_ArTotal <> 0 or pre_ArTotal_ini<>0 or pre_ApTotal<>0 or pre_ApTotal_ini<>0) and C_id=@product_id)
	begin
/*		Raiserror('商品明细已经产生不能删除！',16,1)*/
		return -1
	end
 end
if Upper(@TableName)='STORAGES'
begin
/*-    是否可删除*/
	if exists(select * from storehouse where S_id=@product_id) 
	begin
/*		Raiserror('已经有该仓库的单据！',16,1)*/
		return -1
	end
	if exists(select * from productdetail where S_id=@product_id and billid not in(select distinct billid from billidx where billtype in (110, 120)))
	begin
/*		Raiserror('商品明细已经产生！',16,1)*/
		return -1
	end
end
if Upper(@TableName)='ACCOUNT'
begin
/*-    是否可删除*/
	if exists(select * from account where Ini_Total<>0 and account_id=@product_id)
	begin
/*		Raiserror('系统科目！',16,1)*/
		return -1
	end
	if exists(select Sysrow from account where sysrow=1 and account_id=@product_id)
	begin
/*		Raiserror('系统科目！',16,1)*/
		return -1
	end
	if exists(select * from Billidx where a_id=@product_id) 
	begin
/*		Raiserror('已经有该科目的单据！',16,1)*/
		return -1
	end
	if exists(select * from accountdetail where a_id=@product_id)
	begin
/*		Raiserror('科目明细已经产生！',16,1)*/
		return -1
	end
end
if Upper(@TableName)='ProductBlacklist'
begin
  if exists(select 1 from ProductBlacklist where PermitCode= @product_id)
   return -1
end
if Upper(@TableName)='DEPARTMENT'
begin
/*    是否可删除*/
	if exists(select * from Employees where dep_id=@product_id and deleted=0) 
	begin
/*		Raiserror('职员信息中已经有该部门！',16,1)*/
		return -1
	end
end
if Upper(@TableName)='REGION'
begin
/*    是否可删除*/
	if exists(select * from Clients where region_id=@product_id and deleted=0) 
	begin
/*		Raiserror('往来单位信息已经有该片区！',16,1)*/
		return -1
	end
	if exists(select * from company where region_id=@product_id and deleted=0) 
	begin
		/*Raiserror('分支机构信息已经有该片区！',16,1)*/
		return -1
	end
end
if Upper(@TableName)='UNIT'
begin
/*    是否可删除*/
	if exists(select * 
		  from Products 
		  where (unit1_id=@product_id or 
			unit2_id=@product_id or 
			unit3_id=@product_id or 
			unit4_id=@product_id) and deleted<>1 ) 
	begin
/*		Raiserror('商品信息已经有该单位！',16,1)*/
		return -1
	end
end
if Upper(@TableName)='COMPANY'
begin
   if @unitid=1 
   begin 
      if exists(select * from Companybalance where y_id=@product_id and (artotal_ini<>0 or artotal<>0 or apTotal_ini<>0 or apTotal<>0 
		or pre_ArTotal <> 0 or pre_ArTotal_ini<>0 or pre_ApTotal<>0 or pre_ApTotal_ini<>0))
            return -1 
   end
   else
   begin
     if exists(select * from company          where company_id=@product_id and sysflag=1) or 
        exists(select * from billidx          where Y_id=@product_id) or
      exists(select * from Clientsbalance   where Y_id=@product_id  and (artotal_ini<>0 or artotal<>0 or apTotal_ini<>0 or apTotal<>0 
		or pre_ArTotal <> 0 or pre_ArTotal_ini<>0 or pre_ApTotal<>0 or pre_ApTotal_ini<>0)) or
      exists(select * from Companybalance   where Y_id=@product_id  and (artotal_ini<>0 or artotal<>0 or apTotal_ini<>0 or apTotal<>0 
		or pre_ArTotal <> 0 or pre_ArTotal_ini<>0 or pre_ApTotal<>0 or pre_ApTotal_ini<>0)) or
      exists(select * from YAccountDetail   where Y_id=@product_id) or
      exists(select * from YProductdetail   where Y_id=@product_id) or
      /*新建机构,就已初始化表accountbalance.不能对机构分类*/
      /*exists(select * from accountbalance   where Y_id=@product_id) or */
      exists(select * from billdraftidx     where Y_id=@product_id) or
      exists(select * from billdtsidx       where Y_id=@product_id) or
      exists(select * from GspRegister      where Y_id=@product_id) or
      exists(select * from GSPSNStyle       where Y_id=@product_id) or
      exists(select * from GspTable         where Y_id=@product_id) or
      exists(select * from GspTableDts      where Y_id=@product_id) or
      exists(select * from invoiceidx       where Y_id=@product_id) or
      exists(select * from orderidx         where Y_id=@product_id) or
      exists(select * from OtherStorehouse  where Y_id=@product_id) or
      exists(select * from PosPrice         where Y_id=@product_id) or
      exists(select * from PriceIdx         where Y_id=@product_id) or
      exists(select * from PriceIdxDts      where Y_id=@product_id) or
      exists(select * from redhistory       where Y_id=@product_id) or
      exists(select * from retailbillidx    where Y_id=@product_id) or
      exists(select * from storages         where Y_id=@product_id) or
      exists(select * from storebrrow       where Y_id=@product_id) or
      exists(select * from storebrrowini    where Y_id=@product_id) or
      exists(select * from storedx          where Y_id=@product_id) or
      exists(select * from storedxini       where Y_id=@product_id) or
      exists(select * from storehouse       where Y_id=@product_id) or
      exists(select * from storehouseini    where Y_id=@product_id) or
      exists(select * from TranIdx          where Y_id=@product_id) or
      exists(select * from TranIdxDts       where Y_id=@product_id) or
      exists(select * from VIPCard          where Y_id=@product_id) or
      exists(select * from VIPCardDTS       where Y_id=@product_id) or
      exists(select * from VipDetail        where Y_id=@product_id) or
      exists(select * from VipDetailDts     where Y_id=@product_id) 
      begin
		return -1
      end
  end
end

if Upper(@TableName)='CUSTOMCATEGORY'
begin
/*    是否可删除*/

/*	 @product_id	varchar(100),
	 @unitid		[int]=0
	 需要查询出  @product_id 对应的自定义属性的 id
	然后要用动态脚本确定列名称
exec Ts_L_CheckBaseInfo;1 'CustomCategory','498',0
	 */
	declare @cColName varchar(20) 
	declare @szSql varchar(2000)
	declare @class_id varchar(20)
	declare @cate_id int
	declare @len int
	select @cate_id = Category_id,@class_id = class_id from customCategory where id = @product_id
	set @len = LEN(@class_id)
	CREATE TABLE #Tmp ([pid] [int] NOT NULL DEFAULT(0))
	if @unitid in (-1,0)   /*表示商品*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'ProductCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
	/*		Raiserror('该类别已经关联基本资料！',16,1)*/
			return -1
		end
	end
	if @unitid = 1   /*表示往来单位*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'ClientCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.client_id from clients p,ClientCategory c where p.client_id = c.c_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
	/*		Raiserror('该类别已经关联基本资料！',16,1)*/
			return -1
		end
	end
	if @unitid = 2   /*表示机构*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'ProductCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.company_id from Company p,CompanyCategory c where p.company_id = c.y_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
	/*		Raiserror('该类别已经关联基本资料！',16,1)*/
			return -1
		end
	end
	
	IF object_id(N'#Tmp', N'U') is not null  
		DROP TABLE #Tmp  
end

return 0
GO
