




/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/

/*
	报警类型
	0：上限
	1：下限
	2：应收信用额度
	3：超期应收款报警
	4：超期应付款报警
	5：近效期商品报警
	6：失效期商品报警
	7：停售商品报警
	8: 超期销售合同报警
	9：超期采购合同报警
    10:库存养护报警
	11:'Gsp首营企业证照报警'
	12:'会员卡生日报警'
	14:未发生业务往来单位报警
	15:应付信用额度
	16:返利协议报警
	17:无发货商品报警
	18:合格供货方档案报警
	19:商品注册证号及批准文号报警
*/
CREATE proc ts_c_autoalert
(
	@nAlertType   int,
	@nDay         int=0,
	@nS_id        int=0,
    @ISNoPurchase int=0,
    @ISNoSend     int=0,
    @nY_id        int=0
)
/*with encryption*/
as
/*Params Ini begin*/
if @nDay is null  SET @nDay = 0
if @nS_id is null  SET @nS_id = 0
if @ISNoPurchase is null  SET @ISNoPurchase = 0
if @ISNoSend is null  SET @ISNoSend = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/
/*set nocount on */
  Declare @szSQL varchar(8000)
  Declare @szNopurchase varchar(8000),@szNoSend varchar(8000)
  Declare @szNOpurchaseQTY varchar(1000),@szNOSendQTY varchar(1000)
  DECLARE @szSClassId VARCHAR(30)
  /*过滤停止报警的商品信息 add by luowei 2013-01-03*/
  declare @filterProduct varchar(200)
  set @filterProduct = 'and exists(select 1 from products p where p.product_id = sl.p_id and p.alert = 0)'

  IF @ISNoPurchase<>0
   begin
     SET @szNopurchaseQTY=' + isnull(sum(BM.NoPurchaseQTY),0) '
     SET @szNopurchase=' LEFT JOIN (SELECT p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from vw_c_buymb
                         where Y_id='+cast(@nY_id as varchar(10))+' and bill_id In (select billid from billidx where billtype=220) and thqty>SendQTY Group by p_id)BM 
                         ON BM.P_id=st.p_id'
   end
   else
   begin
     SET @szNoPurchaseQTY=' + 0 '
     SET @szNopurchase=''
   end

  IF @ISNosend<>0
   begin
     SET @szNoSendQTY=' - ISNULL(sum(SM.NoSendQTY),0) '
     SET @szNosend=' LEFT JOIN  (SELECT p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from vw_c_salemb
                     where Y_id='+cast(@nY_id as varchar(10))+' and bill_id IN (select billid from billidx where billtype=210) and thqty>SendQTY Group by p_id)SM
                     on SM.p_id=ST.p_id'
   end
     else
   begin
     SET @szNosendQTY=' - 0 '
     SET @szNosend=''
   end
   
if @nAlertType=0
begin
	 if @nS_id=0 
       SET @szSQL='select '+'''库存上限报警 '''+'as alerttype,count(*) as alternumber 
	 from storelimit sl where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>0 and sl.s_id= '+ cast(@nS_id as varchar(50))+' and sl.UpperLimit<(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st '+@szNopurchase+@szNosend +'  where st.Y_id='+cast(@nY_id as varchar(10))+' and sl.p_id=st.p_id)
       '
     ELSE
     BEGIN
       IF EXISTS(SELECT * FROM storages s WHERE s.storage_id = @nS_id AND s.child_number = 0) 
       BEGIN
       	  /*仓库选择的是单个库*/
		   SET @szSQL='select '+'''库存上限报警 '''+' as alerttype,count(*) as alternumber 
	       from storelimit sl where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>0 and sl.s_id= '+ CAST(@nS_id AS VARCHAR(50))+' and sl.UpperLimit<(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st '+@szNopurchase+@szNosend +' where st.Y_id='+cast(@nY_id as varchar(10))+'  and sl.p_id=st.p_id 
            and s_id='+CAST(@nS_id AS VARCHAR(50))+')'
       END
       ELSE
       BEGIN
       	  /*仓库选择的是类别*/
       	  SELECT @szSClassId = s.class_id + '%' FROM storages s WHERE s.storage_id = @nS_id
       	  SET @szSQL='select '+'''库存上限报警 '''+' as alerttype,count(*) as alternumber 
	                  from storelimit sl where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>0 and sl.s_id= '+ CAST(@nS_id AS VARCHAR(50))+' and sl.UpperLimit<(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st, storages s '+@szNopurchase+@szNosend +' where st.s_id = s.storage_id AND st.Y_id='+cast(@nY_id as varchar(10))+'  and sl.p_id=st.p_id 
              and s.class_id LIKE '''+@szSClassId+''')'
       END	    
     END

 Print(@szSQL)
 EXEC(@szSQL + @filterProduct)

return 0
end

if @nAlertType=1
begin
	if @nS_id=0 
	  SET @szSQL=' select '+'''库存下限报警 '''+' as alerttype,count(*) as alternumber 
		from storelimit sl left join storelimit stl on sl.slid=stl.slid 
                where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>stl.lowlimit and sl.s_id='+cast(@nS_id  as varchar(50))+' and sl.LowLimit>(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st '+@szNopurchase+@szNosend +'  where st.Y_id='+cast(@nY_id as varchar(10))+' and sl.p_id=st.p_id)'
    ELSE
    IF EXISTS(SELECT * FROM storages s WHERE s.storage_id = @nS_id AND s.child_number = 0) 
    BEGIN
       	  /*仓库选择的是单个库     	*/
	  SET @szSQL=' select '+'''库存下限报警 '''+' as alerttype,count(*) as alternumber 
		from storelimit sl left join storelimit stl on sl.slid=stl.slid 
                where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>stl.lowlimit and sl.s_id='+CAST(@nS_id  AS varchar(50))+' and sl.LowLimit>(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st '+@szNopurchase+@szNosend +'  where st.Y_id='+cast(@nY_id as varchar(10))+' and sl.p_id=st.p_id 
                and s_id='+CAST(@nS_id AS VARCHAR(50))+')'
    END
    ELSE
    BEGIN
    	/*仓库选择的是类别*/
    	SELECT @szSClassId = s.class_id + '%' FROM storages s WHERE s.storage_id = @nS_id
    	SET @szSQL=' select '+'''库存下限报警 '''+' as alerttype,count(*) as alternumber 
		from storelimit sl  where sl.Y_id='+cast(@nY_id as varchar(10))+' and sl.upperlimit>sl.lowlimit and sl.s_id='+CAST(@nS_id  AS varchar(50))+' and sl.LowLimit>(select isnull(sum(st.quantity),0) '+@szNopurchaseQTY+@szNoSendQTY+' from storehouse st, storages s '+@szNopurchase+@szNosend +'  where st.s_id = s.storage_id AND  st.Y_id='+cast(@nY_id as varchar(10))+' and sl.p_id=st.p_id 
                and s.class_id LIKE '''+@szSClassId+''')'
    END
 /*Print(@szSQL)*/
 EXEC(@szSQL + @filterProduct)
return 0
end

if @nAlertType=2
begin
	select '应收信用额度报警' as alerttype,count(*) as alternumber from clientsbalance where Y_id=@nY_id and credit_total<=artotal and credit_total<>0
	return 0
end

if @nAlertType=3
begin
	select '超期应收款报警' as alerttype,count(*) as alternumber from billidx where Y_id=@nY_id and billstates='0' and billtype in (10,112) and skdate<dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and skdate>0 and jsye>0
	return 0
end

if @nAlertType=4
begin
	select '超期应付款报警' as alerttype,count(*) as alternumber from billidx where Y_id=@nY_id and billstates='0' and billtype in (20,122) and skdate<dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and skdate>0 and jsye>0
	return 0
end

if @nAlertType=5
begin
	select '近效期商品报警' as alerttype,count(*) as alternumber from storehouse where Y_id=@nY_id and validdate<dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and validdate>convert(varchar(10),getdate(),20)
	and exists(select 1 from products p where p.product_id = p_id and p.alert = 0)
	return 0
end

if @nAlertType=6
begin
	select '失效期商品报警' as alerttype,count(*) as alternumber from storehouse where Y_id=@nY_id and validdate<convert(varchar(10),getdate(),20) and validdate>0
	and exists(select 1 from products p where p.product_id = p_id and p.alert = 0)
	return 0
end

if @nAlertType=7
begin
	select '停售商品报警' as alerttype,count(*) as alternumber from storehouse where Y_id=@nY_id and stopsaleflag=1
	and exists(select 1 from products p where p.product_id = p_id and p.alert = 0)
	return 0
end

if @nAlertType=8
begin
	select '超期销售订单报警' as alerttype,count(*) as alternumber from orderidx  		 	
	where Y_id=@nY_id and billstates='3' and billtype=14 and skdate<=dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and skdate>10 
		
	return 0
end

if @nAlertType=9
begin
	select '超期采购订单报警' as alerttype,count(*) as alternumber from orderidx 		
	where Y_id=@nY_id and billstates='3' and billtype=22 and skdate<=dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and skdate>10 	  
	return 0
end


if @nAlertType=10
begin
	select '近效期商品报警' as alerttype,count(*) as alternumber from storehouse s,vw_c_Alert va 
	where s.Y_id=@nY_id and s.p_id=va.p_id and s.validdate<dateadd(day,va.alertday,convert(varchar(10),getdate(),20)) and s.validdate>convert(varchar(10),getdate(),20)
	and exists(select 1 from products p where p.product_id = s.p_id and p.alert = 0)
	return 0
end

if @nAlertType=11
begin
  if @nS_id<>999
  begin
  	select '库存养护报警' as alerttype,count(*) as alternumber from vw_l_house v 
  	where dateadd(day,maintainday-@nDay,yhdate)<=convert(varchar(10),getdate(),20) and validdate>100 and MaintainDay<>0
  	and exists(select 1 from products p where p.product_id = v.product_id and p.alert = 0)
  	return 0
  end
  else begin
  	select '库存养护报警' as alerttype,count(*) as alternumber from vw_l_house v 
  	where dateadd(day,Posyhday-@nDay,yhdate)<=convert(varchar(10),getdate(),20) and validdate>100 and MaintainDay<>0
  	and exists(select 1 from products p where p.product_id = v.product_id and p.alert = 0)
  	return 0
  end
end

if @nAlertType=12
begin
    select 'Gsp相关证照报警' as alerttype,count(*) as alternumber
    from 
    (select distinct client_id
    from clients c 
    left join  ClientReport2 r on c.client_id = r.c_id and r.CType=0
	left join (select c_id, MIN(validDate) as d5 from wtorder group by c_id) w on c.client_id = w.c_id
	/*left join (select c_id, MIN(validDate) as d11 from GMPIndex group by c_id) gmp on c.client_id = gmp.c_id*/
    where ((isnull(r.validTime,0) < dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and isnull(r.validTime,0)<>0)
     or (isnull(d5,0) < dateadd(day,@nDay,convert(varchar(10),getdate(),20)) and isnull(d5,0)<>0))
    and c.child_number =0 and c.deleted = 0 )a 
	return 0
end

if @nAlertType = 13
begin
  select '会员卡生日报警' as alerttype, count(1) as alternumber
  from Vipcard
  where Lose <> 1 and StopUse <> 1
     and cast(year(GetDate()) as varchar)+'-'+cast(substring(convert(varchar(10), birthday, 20), 6, 5) as varchar) 
     between convert(varchar(10), GetDate(), 20) and convert(varchar(10), GetDate()+@nDay, 20)
  return 0
end

declare @tvch varchar(1000)
declare @Clienttype varchar(100)
if @nAlertType= 14
begin
  select @tvch='1/2'
  select @Clienttype='2'

  if @ISNoPurchase=1 
  begin
    select @tvch=@tvch+',20,21,120,121,122,35,220,221,222'
    select @Clienttype=@Clienttype+',1'
  end

  if @ISNOSend=1
  begin
    select @tvch=@tvch+',10,11,12,13,110,111,112, 32,210,211,212'
    select @Clienttype=@Clienttype+',0'
  end

  if (@tvch='1/2') or (@nDay=0)
  begin 
     select '未发生业务客户' as alerttype,0 as alternumber
  end
  else
  begin
   select @szSQL='select ''未发生业务客户'' as alerttype,count(client_id)as alternumber
    from clients    where deleted=0  and child_count=0 and  csflag in ('+@Clienttype+') and 
         client_id not in (select distinct c_id from billidx where billdate between dateadd(day,'+ cast(-@nDay as varchar(10))+',convert(varchar(10),getdate(),20)) and getdate()
         and billtype in ('+@tvch+') and billstates=0)'
  end

/*PRINT(@szSql)*/
EXEC (@szsql)
end


if @nAlertType=15
begin
	select '应付信用额度报警' as alerttype,count(1) as alternumber from clientsbalance where Y_id=@nY_id and APcredit_total<=aptotal and APcredit_total<>0
	return 0
end

if @nAlertType=16
begin
  select '返利协议报警' as alerttype ,COUNT(1) as alternumber from FLCondition where (alarmTime<getdate() or EndTime<GETDATE()) and alarmTime>0 and 
  FLStates<>2
  return 0
END

IF @nAlertType = 17 
BEGIN
	DECLARE @BeginD    DATETIME
	DECLARE @EndD      DATETIME
	DECLARE @SaleBegin DATETIME
	DECLARE @SaleEnd   DATETIME
	
	SET @BeginD = CAST(CAST(YEAR(GETDATE()) - 1 AS VARCHAR) + '-' + CAST(MONTH(GETDATE()) AS VARCHAR) + '-1' AS DATETIME)
	SET @EndD = CAST(CONVERT(VARCHAR(100), GETDATE(), 23) AS DATETIME)
	SET @SaleBegin = DATEADD(DAY, -@nDay, CAST(CONVERT(VARCHAR(100), GETDATE(), 23) AS DATETIME))
	SET @SaleEnd = CAST(CONVERT(VARCHAR(100), GETDATE(), 23) AS DATETIME)
	
	DECLARE @szSClass_id VARCHAR(50)
	DECLARE @nYClassID   VARCHAR(50)
	
	IF @nS_id = 0 
		SET @szSClass_id = '%%' 
	ELSE 
		SELECT @szSClass_id = Class_id FROM storages WHERE storage_id = @nS_id
	
	IF @ISNoSend = 0
	    SET @nYClassID = '%%'
	 ELSE
	 	SELECT @nYClassID = c.class_id + '%' FROM company c WHERE c.company_id = @ISNoSend
	
	SELECT '无发货商品报警' AS AlertType, COUNT(*) AS AlterNumber 
	FROM (
		SELECT sh.p_id
		FROM   (   SELECT sh.p_id, sh.instoretime, sh.quantity, sh.Costprice, sh.Y_id, sh.s_id, sh.batchno, sh.validdate,
			              ISNULL(Y.Class_id, '')YClass_id, ISNULL(s.Class_id, '')SClass_id   
				   FROM   storehouse sh
					      LEFT JOIN storages s ON  sh.s_id = s.storage_id
						  LEFT JOIN company Y ON  sh.Y_id = Y.company_id
				WHERE  NOT EXISTS
					      (   SELECT p_id, ss_id, batchno
						      FROM   (   SELECT pd.p_id, pd.ss_id, ISNULL(s.Class_id, '')sClass_id, ISNULL(Y.Class_id, '')YClass_id, batchno
							             FROM   (   SELECT sm.p_id, sm.ss_id, b.Y_id, sm.batchno
								                    FROM   salemanagebill sm
									                       LEFT JOIN billidx b ON  b.billid = sm.bill_id
										            WHERE  b.billdate BETWEEN @SaleBegin AND @SaleEnd
											               AND sm.aoid IN (0, 5) AND p_id > 0 AND b.billtype IN (10, 12, 32, 53, 150, 152, 112, 212) AND b.billstates = '0'
												)PD
												LEFT JOIN Company Y ON  Y.Company_id = PD.Y_id
												LEFT JOIN storages S ON  S.storage_id = pd.ss_id
									)sm
							WHERE  YClass_id LIKE @nYClassID AND SClass_id LIKE @szSClass_id AND sh.p_id = sm.p_id /*AND sh.s_id = sm.ss_id --AND sm.batchno = sh.batchno*/
						)
			)sh
			LEFT JOIN Products vp ON  sh.p_id = vp.product_id
			left join VW_MedType  m on vp.product_id = m.product_id
			LEFT JOIN vw_productbalance PB ON  vp.product_id = PB.p_id AND sh.Y_ID = PB.Y_id
		WHERE  Yclass_id LIKE @nYClassID AND sclass_id LIKE @szSClass_id AND (sh.instoretime BETWEEN @BeginD AND @EndD)
		and exists(select 1 from products p where p.product_id = sh.p_id and p.alert = 0)
		GROUP BY
			sh.p_id, vp.class_id, vp.serial_number, vp.name, vp.alias, vp.[standard], vp.modal, vp.permitcode, vp.trademark,
			vp.makearea, vp.pinyin, vp.EngName, vp.ChemName, vp.LatinName, m.medtype, vp.Inputman, vp.InputDate,
			vp.Custompro1, vp.Custompro2, vp.Custompro3, vp.Custompro4, vp.Custompro5, sh.validdate	
	) a
	RETURN 0
END

IF @nAlertType = 18
BEGIN
	SELECT '合格供货方档案报警' AS AlertType, COUNT(*) AS AlterNumber 
	FROM (SELECT c.client_id FROM clients c WHERE c.[deleted] = 0 AND c.child_number = 0 AND c.csflag <> 0 AND c.CreateDate < (GETDATE() - 365)) a 
	LEFT JOIN (SELECT g.szid FROM GspTable g WHERE g.GspType = 2337 AND g.szid > 0) gt 
	ON a.client_id = gt.szid WHERE gt.szid IS NULL
END

IF @nAlertType = 19
BEGIN
  SELECT '商品注册证号及批准文号报警' AS AlertType, COUNT(*) AS AlterNumber
  FROM (select serial_number,name,standard,makearea,MedName,Factory,RegisterNo,Registervalid,permitcode,PerCodevalid from vw_Products
	where child_number = 0 and deleted = 0 and ((PerCodevalid > 10 AND 
	PerCodevalid <DATEADD(DAY,@nDay,GETDATE())) OR (Registervalid > 10 AND  Registervalid< DATEADD(DAY,@nDay,GETDATE())))  ) T
END
IF @nAlertType = 20
BEGIN
  SELECT '商品GMP效期报警' AS AlertType, COUNT(*) AS AlterNumber
  FROM (select serial_number,name,standard,makearea,MedName,Factory,GMPvaliddate,permitcode from vw_Products
	where child_number = 0 and deleted = 0 and (GMPvaliddate <> '1900-01-01' )
		  and (GMPvaliddate <DATEADD(DAY,@nDay,GETDATE()) ) ) T
END
IF @nAlertType = 21
BEGIN
  SELECT '滞销商品报警' AS AlertType, 0 AS AlterNumber
END
GO
