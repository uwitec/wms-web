

CREATE VIEW dbo.vw_c_printcount
AS
SELECT Rep_ID, COUNT(Rep_ID) AS printcount
FROM dbo.PrintDetail
where nflag=0
GROUP BY Rep_ID
GO
