
CREATE FUNCTION FilterSalemanagebill(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     sb.smb_id, sb.bill_id, sb.p_id, sb.batchno, sb.quantity, CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sb.costprice ELSE 0 END AS costprice, sb.saleprice, sb.discount, sb.discountprice, sb.totalmoney, sb.taxprice, 
							  sb.taxtotal, sb.taxmoney, sb.retailprice, sb.retailtotal, sb.makedate, sb.validdate, sb.qualitystatus, sb.price_id, sb.ss_id, sb.sd_id, sb.location_id, 
							  sb.supplier_id, sb.commissionflag, sb.comment, sb.unitid, sb.taxrate, sb.order_id, sb.total, sb.iotag, sb.InvoiceTotal, sb.thqty, sb.newprice, 
							  sb.orgbillid, sb.jsprice, sb.AOID, sb.invoice, sb.invoiceno, sb.BatchBarCode, sb.SendQTY, CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sb.SendCostTotal ELSE 0 END AS SendCostTotal, sb.RowGuid, sb.RowE_id, CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN sb.YCostPrice ELSE '0' END AS YCostPrice, 
							  sb.YGuid, sb.Y_ID, sb.transflag, sb.instoretime, sb.cxType, sb.PriceType, sb.location_id2, sb.comment2, sb.scomment, sb.batchprice, sb.CxGuid, 
							  sb.Conclusion,isnull(f.AccountComment,'') as factory,costtaxprice,costtaxrate,costtaxtotal
		FROM         dbo.products AS p INNER JOIN
							  dbo.salemanagebill AS sb ON p.product_id = sb.p_id
							  left join basefactory f on sb.factoryid=f.CommID
GO
