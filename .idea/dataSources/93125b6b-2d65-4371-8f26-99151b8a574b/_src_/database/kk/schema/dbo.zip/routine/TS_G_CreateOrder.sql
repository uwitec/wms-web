
CREATE PROCEDURE [dbo].[TS_G_CreateOrder] 
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @nInput INT
	DECLARE @DefaultE_ID INT SET @DefaultE_ID = 0
	declare @nBillId int
	declare @nFor int
	declare @sNillNum varchar(36)
	/**/
	DECLARE @c_id INT SET @c_id = 0
	DECLARE @c_code VARCHAR(50) SET @c_code = ''
	DECLARE @c_name VARCHAR(50) SET @c_name = ''
	DECLARE @BH VARCHAR(50) SET @BH = ''
	
	/*默认制单人和经手人*/
	select @nInput = (select IsNull(sysvalue,1) from sysconfig where sysname = 'localinputman' and Y_ID = 2)
	select @DefaultE_ID = (select IsNull(sysvalue,1) from sysconfig where sysname = 'localeid' and Y_ID = 2)

	/* 获取需处理表*/
	declare curSplit scroll cursor for
	select YSDID,YYBH,YYMC,BH from HZ_YSD 
	    where YSDID not in (select InvoiceNO from orderidx where InvoiceNO<>'')
	    GROUP BY YSDID,YYBH,YYMC,BH
	open curSplit
	set @nFor = 0
        declare @count int
        set @count = @@cursor_rows
	while @nFor < @count
	begin
		fetch next from curSplit into @sNillNum,@c_code,@c_name,@BH
        /*检测医院是否存在*/
        SET @c_id = 0 
        SELECT @c_id=IsNull(client_id,0) FROM clients WHERE serial_number = @c_code AND child_count = 0 AND DELETED = 0
        IF @c_id = 0 
        BEGIN
          declare @p int set @p=0
          exec Ts_z_Get_UpdateRowIndex;1 'Clients','000000',@p output
          /*select @p*/
          DECLARE @date VARCHAR(100) SET @date = CONVERT(VARCHAR(10), GETDATE(), 120)
          exec Ts_L_InsClients;1 '000000',@c_code,@c_name,'',0,'','','','','','',0,0,'DW2',0,0,0,0,
                                  0,0,0,0,0,0,0,'','2',0,'','',0,@p,'',0,'','','','',0,@date,
                                  '','','','','',0,0,'','','','','','','','','',2,0,0,'',0,0,0,1        	
          SELECT @c_id=IsNull(client_id,0) FROM clients WHERE serial_number = @c_code
          exec Ts_UpdateClientLic;1 @c_id,'','','','','','','','','','','','',0	
        END  
        
		/* 写入主表*/
		insert into orderidx([billdate]
		  ,[billnumber]
		  ,[billtype]
		  ,[a_id]
		  ,[c_id]
		  ,[e_id]
		  ,[sout_id]
		  ,[sin_id]
		  ,[auditman]
		  ,[inputman]
		  ,[ysmoney]
		  ,[ssmoney]
		  ,[quantity]
		  ,[taxrate]
		  ,[period]
		  ,[billstates]  /**/
		  ,[order_id]
		  ,[department_id]
		  ,[posid]
		  ,[region_id]
		  ,[auditdate]
		  ,[skdate]
		  ,[jsye]
		  ,[jsflag]
		  ,[note]
		  ,[summary]
		  ,[invoice]
		  ,[InvoiceTotal]
		  ,[InvoiceNO]
		  ,[BusinessType]
		  ,[Guid]
		  ,[Y_ID])
		SELECT CONVERT(VARCHAR(10), GETDATE(), 120), '', 14, 0, @c_id, 0, 0, 0, 0, @nInput, 0, 0, 0, 0, 0, '2',
		       -9, 0, 0, 0, '1900-1-1', GETDATE() + 90, 0, 0, '[由集中采购交易系统生成]'+YSDMC, '', 0, 0, YSDID, 0, NEWID(), 2
		from HZ_YSD
		where YSDID = @sNillNum
		
		set @nBillId = @@IDENTITY
		
		/* 写入明细*/
		INSERT INTO [OrderBill]
			   ([bill_id]
			   ,[p_id]
			   ,[batchno]
			   ,[quantity]
			   ,[costprice]
			   ,[saleprice]
			   ,[discount]
			   ,[discountprice]
			   ,[totalmoney]
			   ,[taxprice]
			   ,[taxtotal]
			   ,[taxmoney]
			   ,[retailprice]
			   ,[retailtotal]
			   ,[makedate]
			   ,[validdate]
			   ,[qualitystatus]
			   ,[price_id]
			   ,[ss_id]
			   ,[sd_id]
			   ,[location_id]
			   ,[supplier_id]
			   ,[commissionflag]
			   ,[comment]
			   ,[unitid]
			   ,[taxrate]
			   ,[ComeDate]
			   ,[ComeQty]
			   ,[total]
			   ,[RowGuid]
			   ,[RowE_id]
			   ,[Y_ID]
			   ,[comment2])		
		select @nBillId, p.product_id, '', mx.CGSL, 0, IsNull(mx.CGJG,0), 1, IsNull(mx.CGJG,0), IsNull(mx.CGJG,0) * mx.CGSL
			, IsNull(mx.CGJG,0), IsNull(mx.CGJG,0) * mx.CGSL, 0, ISNULL(c.retailprice, 0), ISNULL(c.retailprice * mx.CGSL, 0)
			, 0, 0, '合格', 0, 0, 0, 0, @c_id, 0, '', p.unit1_id, 0, '1900-1-1', 0, ISNULL(mx.CGJG * mx.CGSL, 0), NEWID(), 0, 2, mx.BH		
		from HZ_DDMX mx INNER JOIN HZ_YSD ysd ON mx.BH = ysd.BH
		                inner join products p on mx.YPBH = p.Custompro5
		                left join price c on p.product_id = c.p_id and p.unit1_id = c.u_id
		where mx.BH = @BH
		
		/* 更新主表金额*/
		update orderidx SET quantity = x.qty, ysmoney = x.total, jsye = x.total
		from (select bill_id, SUM(quantity) AS qty ,SUM(totalmoney) as total from OrderBill where bill_id = @nBillId group by bill_id) x
		where orderidx.billid = x.bill_id
				
		set @nFor = @nFor + 1
		
	end
	DEALLOCATE curSplit
END
GO
