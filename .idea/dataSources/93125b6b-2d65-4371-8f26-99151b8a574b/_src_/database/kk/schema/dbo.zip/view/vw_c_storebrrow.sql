











CREATE VIEW dbo.vw_c_storebrrow
AS
SELECT dbo.storebrrow.p_id, ISNULL(SUM(dbo.storebrrow.quantity), 0) AS quantity, 
      ISNULL(SUM(dbo.storebrrow.costtotal), 0) AS costtotal, 
      dbo.storebrrow.commissionflag, dbo.products.class_id AS pclass_id, 
      dbo.clients.class_id AS cclass_id,isnull(Y.Class_ID,'')YClass_id,isnull(Y.[name],'')Yname
FROM dbo.storebrrow LEFT OUTER JOIN
      dbo.clients ON dbo.storebrrow.c_id = dbo.clients.client_id LEFT OUTER JOIN
      dbo.products ON dbo.storebrrow.p_id = dbo.products.product_id  LEFT OUTER JOIN
      dbo.Company y ON dbo.storebrrow.y_id=Y.company_id

GROUP BY dbo.storebrrow.p_id, dbo.storebrrow.commissionflag, dbo.products.class_id, 
      dbo.clients.class_id,Y.Class_ID,Y.[name]
GO
