/************************************************************

--功能：读取GMP证书关联的剂型信息
--创建人：Zhou JiLin 
--创建时间：2013-11-05  
--最后修改:
--修改说明：

参数说明：
/*Wusj.2017-06-13.TfsBug48242customCategory表中Typeid在917中已无效改为Category_id*/
**************************************************************/
CREATE	 PROCEDURE [ts_j_LoadGMPMedtype]
  ( @ga_id int
  )
AS 

  select m.id as mt_id,'' as mt_code,m.name as  mt_name,Case when GMPmt_id is null then 0 else 1 end as checkedFlag 
    from (select * from customCategory where Category_id=3 and Child_Number=0 and deleted=0) m
    left join  (select mt_id as GMPmt_id from GMPMedtype where ga_id = @ga_id) g
    on m.id = g.GMPmt_id
    
  return 0
GO
