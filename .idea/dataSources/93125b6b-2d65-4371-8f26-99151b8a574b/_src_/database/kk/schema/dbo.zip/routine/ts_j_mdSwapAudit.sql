/************************************************************
--功能：门店调货收货 
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:
参数说明：
 @nRet 返回值说明　
	0:执行成功
       -1:执行失败，发生异常
**************************************************************/
CREATE	 PROCEDURE [dbo].[ts_j_mdSwapAudit]
	(
	 @nbillid int,
	 @nE_ID int
    )
AS 
declare @LocalS_id int, @localinputman int,@localauditman int, @localeid int
declare @Y_ID int, @nnewbillid int
declare @smbid int, @pid int, @locationid int
declare @nP_id int, @nReturnNumber int /*过账用*/
declare @szGUID varchar(60), @nbilltype int, @szEName varchar(60) 
if @nE_ID <= 0 return -1
select @LocalS_id = sin_id, @localinputman = @nE_ID, @localauditman = @nE_ID, @localeid = @nE_ID, @szGUID = GUID,
       @Y_ID = isnull(c_id, 0), @nbilltype = billtype
    from billidx where billid  = @nbillid
if @nbilltype <> 150 return -1
 
if (@LocalS_id is null) or (@LocalS_id = 0) return -1
begin tran SwapAudit
	if exists(select 1 from billdraftidx where order_id = @nbillid and billtype = 160)
	begin
	  select @nnewbillid = billid from billdraftidx where order_id = @nbillid and billtype = 160
	  delete buymanagebill where bill_id = @nnewbillid
	  delete billdraftidx where billid = @nnewbillid
	end 
	  set @nnewbillid = 0
       if exists(select 1 from billidx where order_id = @nbillid and billtype = 160 and billstates = 0) 
       begin
         commit tran SwapAudit
         return 0
       end
	 
	 insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				 ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				 posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
				 SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate) 
	
				select billdate, '', 160, 0, Y_ID, @localEid, @LocalS_id, @LocalS_id, @localauditman, @localinputman, 
				ysmoney, 0, 0, quantity, taxrate, 0, 3, @nbillid, 0, 
				Posid, 0, GETDATE(), 0, ysmoney, 0, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,NEWID(),
				SendQTY,0,jsInvoiceTotal,VIPCardID,C_ID,begindate,Enddate
				from billidx where billid=@nbillid
	
				select @nnewbillid=@@identity
				
	    insert into Buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,RowGuid,RowE_ID,YcostPrice,YGUID,
					Y_ID, instoretime)
			select  @nnewbillid, p_id, batchno, quantity, discountprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxMoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, @LocalS_id, 0, 0, supplier_id, commissionflag, 
					comment,unitid,taxrate, smb_id, total,iotag,InvoiceTotal ,thqty,newprice,0,aoid,RowGuid,@localeid,YcostPrice,YGUID,@Y_id, instoretime
				from Salemanagebill where bill_id=@nbillid /*and p_id > 0*/
				order by smb_id
          if @nnewbillid <= 0
          begin
            ROLLBACK TRAN SwapAudit
            Return -2
          end
        
        exec ts_c_billaudit @nnewbillid, @nP_id, @nReturnNumber, 160
        if @@Error <> 0 
        begin
            ROLLBACK TRAN SwapAudit
            Return -3
        end
        if @nReturnNumber < 0
        begin
            ROLLBACK TRAN SwapAudit
            Return -3
        end
        
        select @szEname = [name] from employees where emp_id = @nE_ID
        update billidx set transflag =1, b_customName3 = @szEname+' '+b_customName3 where billid = @nbillid  
commit tran SwapAudit
Return 0
	
	/* 暂不处理货位跟踪      declare LocCur cursor for
			select smb_id,p_id,ss_id
			from Buymanagebilldrf
			where bill_id=@nnewbillid
			
			open LocCur
				
				fetch next from LocCur into @smbid,@pid,@LocalS_id
				
				while @@fetch_status=0
				begin
					select @locationid=0
				
					select @locationid=l_id from locationtrace where p_id=@pid and s_id=@LocalS_id and billtype = 160 and Y_ID = @Y_id
				
					if @locationid<>0 update Buymanagebilldrf set location_id=@locationid where smb_id=@smbid
			
					fetch next from LocCur into @smbid,@pid,@LocalS_id
				end
			  close LocCur
		    deallocate LocCur
                 if @@ERROR <> 0 Return -1
		  
         */
GO
