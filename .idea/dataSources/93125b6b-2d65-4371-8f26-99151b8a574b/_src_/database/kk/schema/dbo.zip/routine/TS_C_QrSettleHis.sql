


/********************************************************************************************************************************************************************************************************************
往来结算查询
nMode:=0 收款结算查询
nMode:=1 付款结算查询
nMode:=2 全部
cJsFlag='B'	按单结算
cJsFlag='P'	按行结算
*************************************************************************************/
CREATE PROCEDURE TS_C_QrSettleHis
(	@begindate 		    DATETIME,
	@enddate	        DATETIME,
	@szEClass_id 	    VARCHAR(30)='',
	@szIEClass_id   	VARCHAR(30)='',
	@szCClass_id 		VARCHAR(30)='',
	@cJsFlag	    	CHAR(1)='0',
	@nMode			    INT=0,
	@nY_id              varchar(50)='',
	@nloginEID          int=0,
	@isaddDate          int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移	*/
    @szGEClass_id       VARCHAR(30)=''
)
AS 
/*Params Ini begin*/
if @szEClass_id is null  SET @szEClass_id = ''
if @szIEClass_id is null  SET @szIEClass_id = ''
if @szCClass_id is null  SET @szCClass_id = ''
if @cJsFlag is null  SET @cJsFlag = '0'
if @nMode is null  SET @nMode = 0
if @nY_id is null  SET @nY_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @szGEClass_id is null  SET @szGEClass_id = ''
/*Params Ini end*/
 /* SET NOCOUNT ON*/
  DECLARE @SQLScript VARCHAR(8000)
  Declare @isfinally int
  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),
          @szsql2      varchar(8000)

  Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@Filteemployees  varchar(8000),@Filteemployees2  varchar(8000),@FilteStore   varchar(8000)
          
  select  @FilteClient='',@FilteCompany='',@Filteemployees ='',@Filteemployees2 ='',@FilteStore =''   
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
create table #tmp1
 (
        /*Atype  int,*/
        billid  int, 
        billnumber varchar(30),
        billdate   datetime,
        billtype   int,  /*-varchar(30)*/
        invoicetype varchar(30),          
        note       varchar(256),
        summary    varchar(256),
        cname      varchar(100),
        ename      varchar(100),
        inputmanname varchar(100),
        Gatheringmanname varchar(100),
        cclass_id varchar(30),
        eclass_id varchar(30),
        inputmanclass_id varchar(30), 
        Gatheringmanclass_id varchar(30),
        ysmoney NUMERIC(25,8),
        jsye    NUMERIC(25,8),
        jsflag  varchar(10),
        invoictotal    NUMERIC(25,8),
        invoicflag  varchar(10),        
        skdate  datetime,
        Y_id    int,
        inputman int,
        class_id varchar(30),
        e_id     int,
        c_id     int
   )
create table #tmpsum
 (
  billid  int,
  total   NUMERIC(25,8)
 )   
 insert into #tmpsum 
 select billid,SUM(TOTAL)
 from 
 (
 select distinct a.billid,
   Case b.InvoiceBillType 
     when 0 then a.CurrTotal
     when 1 then -a.CurrTotal
     end as TOTAL 
 from  invoice a,invoiceidx b
 where a.invoiceid=b.id and b.states = 2 
 ) c
 group by billid      
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
 
IF @ClientTable<>0     set @FilteClient='and (a.c_id in (select [id]  FROM #Clienttable ))'
IF @Companytable<>0    set @FilteCompany=' and (a.Y_ID in (select [id] from #Companytable ))'
IF @employeestable<>0  set @Filteemployees= ' and (a.e_id in (select [id] from #employeestable))'
IF @storetable<>0      set @FilteStore=' and (a.ss_id in (select [ID] from #storagestable))'

BEGIN             
/*---1 as Atype,*/
SELECT @SQLScript='
  select a.* from    
     (SELECT b.billid,b.billnumber,b.billdate,b.billtype,
	       (case B.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype,
	       b.[note],b.summary,
	       isnull((case when b.billtype not in (150,151,155,160,161,165) then c.[name] else CY.[name] END), '''') as cname,
	       isnull(e.name, '''') as ename,isnull(e1.[name],'''') as inputmanname,isnull(e2.[name],'''') as Gatheringmanname,
	       isnull((case when b.billtype not in (150,151,155,160,161,165) then c.class_id else CY.class_id end), '''') as cclass_id,
	       isnull(e.class_id, '''') as eclass_id, isnull(e1.class_id, '''') as inputmanclass_id, isnull(e2.class_id, '''') as Gatheringmanclass_id,
	       ysmoney=case  when b.billtype in (11,21,24,25,54,211,221) then -b.ysmoney else b.ysmoney end,
	       jsye=case when b.billtype in (11,21,24,25,54,211,221) then -b.jsye else b.jsye end,b.jsflag
	       ,0 as invoictotal,''未开票'' as invoicflag ,b.skdate,b.Y_id,b.inputman,co.class_id,b.e_id,b.c_id
      FROM billidx  b 
	       left join clients c on c.client_id=b.c_id
	       left join company cy on cy.company_id=b.c_id
               left join company co on  co.company_id=b.Y_id 
	       left join employees e on e.emp_id=b.e_id 
	       left join employees e1 on e1.emp_id=b.inputman
	       left join employees e2 on e2.emp_id=b.Gatheringman
	       where  billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
           + CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and Co.class_id like '''+@nY_id+'%'' and  b.billstates=''0''
      )a	
           where billdate>0 '+@FilteClient+@FilteCompany+@Filteemployees
      IF @szEClass_id<>''
			SET @SQLScript=@SQLScript+' 
      AND LEFT(a.eclass_id,LEN('+CHAR(39)+@szEClass_id+CHAR(39)+'))='+CHAR(39)+@szEClass_id+CHAR(39)
      
      IF @szIEClass_id<>''   
                        SET @SQLScript=@SQLScript+' AND LEFT(a.Inputmanclass_id,LEN('+CHAR(39)+@szIEClass_id+CHAR(39)+'))='+CHAR(39)+@szIEClass_id+CHAR(39)

      IF @szCClass_id<>''
			SET @SQLScript=@SQLScript+' AND LEFT(a.cclass_id,LEN('+CHAR(39)+@szCClass_id+CHAR(39)+'))='+CHAR(39)+@szCClass_id+CHAR(39)
	  
	  IF @szGEClass_id<>''
			SET @SQLScript=@SQLScript+' AND LEFT(a.Gatheringmanclass_id,LEN('+CHAR(39)+@szGEClass_id+CHAR(39)+'))='+CHAR(39)+@szGEClass_id+CHAR(39)

      IF @nMode=0
			SET @SQLScript=@SQLScript+' AND a.billtype IN (10,11,16, 17,53,54, 112,210,211)'
      IF @nMode=1
			SET @SQLScript=@SQLScript+' AND a.billtype IN (20,21,24, 25, 122,220,221)'
      IF @nMode=2
			SET @SQLScript=@SQLScript+' AND a.billtype IN (10,11,16, 17,53,54, 20,21,24, 25, 112,122，210，220,211,221)'
      IF @cJsFlag<>'0'
			SET @SQLScript=@SQLScript+' AND a.jsflag='+CHAR(39)+@cJsFlag+CHAR(39)

   /*SET @SQLScript=@SQLScript+' AND a.billstates=''0'''*/
  /*select  @SQLScript	*/
  set  @SQLScript ='  insert into #tmp1 ' +@SQLScript 
  /*print  @SQLScript*/
  EXEC(@SQLScript)

 /*select * from #tmpsum*/
 /*---修改数据*/
 update #tmp1 set invoictotal=b.total
 from #tmp1 a,#tmpsum b
 where a.billid=b.billid
 update #tmp1 set invoicflag='已开票' where abs(invoictotal)>0  

 select *,(ysmoney - invoictotal) as WKToatl  from  #tmp1
END
   drop table #tmp1
   drop table  #tmpsum
   drop table #ClientTable
   drop table #Companytable
   drop table #employeestable
   drop table #storagestable
GO
