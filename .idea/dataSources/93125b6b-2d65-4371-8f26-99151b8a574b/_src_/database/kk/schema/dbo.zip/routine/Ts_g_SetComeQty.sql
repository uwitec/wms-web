
CREATE PROCEDURE Ts_g_SetComeQty
  @bill_id INT
AS
BEGIN
  DECLARE @nFor INT
  DECLARE @nCur INT 
  DECLARE @y_id INT
  DECLARE @p_id INT 
  DECLARE @u_id INT
  DECLARE @qty INT 
  declare Mycur scroll cursor for
  SELECT idx.Y_ID, bill.p_id, bill.unitid, bill.quantity
    FROM billdraftidx idx INNER JOIN buymanagebilldrf bill ON idx.billid = bill.bill_id
   WHERE idx.billtype IN (160,162)
     AND idx.billid = @bill_id
  set @nFor = 0
  open MyCur
  set @nCur = @@CURSOR_ROWS
  while @nFor < @nCur
  BEGIN
      FETCH NEXT from MyCur INTO @y_id,@p_id,@u_id,@qty
  
      DECLARE @nFor2 INT
      DECLARE @nCur2 INT 
      DECLARE @Quantity INT 
      DECLARE @ComeQty INT 
      DECLARE @i INT
      DECLARE @smb_id INT
      declare SubCur scroll cursor for
        SELECT quantity,ComeQty,smb_id FROM tranbill 
          WHERE y_id=@y_id and p_id=@p_id AND unitid=@u_id AND quantity<>ComeQty 
            and bill_id in (select distinct billid from tranidx where billstates = 3 and AuditMan > 0 and jsflag > 0)
      SET @nFor2 = 0
      OPEN SubCur
      SET @nCur2 = @@CURSOR_ROWS
      WHILE @nFor2 < @nCur2
      BEGIN
      	IF @qty <= 0 
      		break
      	FETCH NEXT from SubCur INTO @Quantity,@ComeQty,@smb_id
      	SET @i = @Quantity - @ComeQty
      	IF @qty >= @i
          begin
      		UPDATE tranbill SET ComeQty = Quantity WHERE smb_id = @smb_id 
        	SET @qty = @qty - @i
          end	 
        else
      	  BEGIN
      	  	UPDATE tranbill SET ComeQty = ComeQty + @qty WHERE smb_id = @smb_id 
      	  	SET @qty = 0
      	  end
      	  
      	/*PRINT @Quantity*/
      	set @nFor2 = @nFor2 + 1     	
      END
      DEALLOCATE SubCur
    
    
    
      /*PRINT @p_id*/
      set @nFor = @nFor + 1
  end  
  deallocate MyCur	
	
	
END
GO
