

CREATE	PROCEDURE [Ts_L_ClinicRangeMapping_His]
	(@Info_id 	[int],
	 @Cr_class_id	varchar(1000),
	 @InfoTyp [int],
	 @IsCheck	[int]
	 )

AS
	set @Info_id = ABS(@Info_id)

	declare @Cr_id int
	SET @Cr_id = 0

	select @Cr_id =  cr_id from clinicRange where class_id = @Cr_class_id

	if (@IsCheck = 1)
	begin
		SELECT TOP 0 *
		INTO #T
		FROM clinicRangeMapping		

		INSERT INTO #T (info_id, cr_id, cr_class_id, baseInfoType) 
		VALUES (@Info_id, @Cr_id, @Cr_class_id, @InfoTyp)

		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
		SELECT @Info_id, 'CRM', (SELECT * FROM #T AS clinicRangeMapping FOR XML AUTO, TYPE, ROOT), 1
		DROP TABLE #T
	end
GO
