
create PROCEDURE Ts_T_QryAbnormalActLog
(
  @BillFlag Int, /*查询类别 0--普通操作；1--授权操作*/
  @BeginDate DateTime, /*开始时间*/
  @EndDate DateTime, /*结束时间*/
  @YID Int = 0, /*机构ID*/
  @RecMan Int = 0, /*收银员*/
  @Operator Int = 0, /*操作员*/
  @ActionType VarChar(100) = '全部' /*操作事件*/
)      
 AS  
  SELECT identity(int, 1, 1) as RecNo, a.EID, a.ActionTag, a.VchID, a.PID, a.ActionType, a.OldValue, a.NewValue, 
         a.ActFlag, a.FEID, a.Computer, a.ActionDate, a.Comment,
         b.Name EName, c.Name YName, 
         /*f.Name RecMan, */
         b.Name RecMan, 
         case when @BillFlag = 0 then b.name else l.name end as Operator, 
         g.name PUnit, 
         e.name PName, e.[standard] PStandard, e.Factory PFactory, emp.name AName,e.alias as alias,
         e.serial_number,e.comment as comments,
         e.makearea, 
         (case when a.VchID > 0 then d.billnumber else a.BillNumber end) as BillNumber,          
         OldQty = (Case a.ActionType when '删减数量' then a.OldValue else Null end), 
         QtyUpdated = (Case a.ActionType when '删减数量' then a.NewValue else Null end), 
         OldPrice = (Case a.ActionType when '修改价格' then a.OldValue else Null end), 
         PriceUpdated = (Case a.ActionType when '修改价格' then a.NewValue else Null end), 
         OldDiscount = (Case a.ActionType when '修改折扣' then a.OldValue else Null end), 
         DiscountUpdated = (Case a.ActionType when '修改折扣' then a.NewValue else Null end) into #QryResult
  From AbnormalActLog a Left join employees emp on a.AID = emp.emp_id
                        Left join employees b on a.EID = b.emp_id
                        left join Company c on b.Y_ID = c.company_id
                        left join RetailBillidx d on a.VchID = d.billid
                        left join products e on a.PID = e.product_id  
                        Left join employees f on d.e_id = f.emp_id
                        left join employees l on l.emp_id = a.FEID                      
                        left join unit g on e.unit1_id = g.unit_id
  where 1=1 
    and a.ActFlag = @BillFlag
    and a.ActionDate between cast(@begindate as varchar(10)) and cast(@enddate as varchar(10))
    and (@YID = 0 or c.company_id = @YID)
    /*and (@RecMan = 0 or d.inputman = @RecMan)  --Wsj--tfsbug43124--2016-11-23 修改*/
    and (@RecMan = 0 or a.AID = @RecMan)
    and (@Operator = 0 or a.EID = @Operator)
    and (@ActionType = '全部' or a.ActionType = @ActionType)  
  
  SELECT * FROM #QryResult
  DROP TABLE #QryResult
    
/*营业员是经手人，收银员是制单人 */
/*营业员e_id, 收银员inputman*/
GO
