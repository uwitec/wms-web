create procedure [dbo].[ts_e_VipCardInputManGlFx]
  @BeginDate  DateTime, /*开始时间*/
  @EndDate    DateTime, /*结束时间*/
  @IfAllCheck int=0,    /*所有时间 0代表不选择所有时间，1代表选择所有时间*/
  @Y_id       int=0,    /*机构ID*/
  @Inputid    int=0,    /*收银员ID（制单人）*/
  @SyCS       int=0,    /*会员收银次数*/
  @GlD        numeric(25,8)     /*关联度*/
as
begin
 if @IfAllCheck=0
 begin
   select ISNULL(cardno,'') as cardno,ISNULL(vipcardtypename,'') as vipcardtypename,ISNULL(People,'') as People,
           ISNULL(sex,'') as sex,ISNULL(age,'') as age,ISNULL(tel,'') as tel,ISNULL(SaleCs,'') as SaleCs,
           ISNULL(GlSaleCs,'') as GlSaleCs,ISNULL(glsalecszb,'') as glsalecszb,
           ISNULL(vipsaletotal,'') as vipsaletotal,ISNULL(glvipsstotal,'') as glvipsaletotal,
           ISNULL(glsaletotalzb,'') as glsaletotalzb,ISNULL(a.Ename,'') as Ename,
           isnull(a.zretailtotal,0)-isnull(a.sstotal,0) as vipyhtotal,
           isnull(a.glretailtotal,0)-isnull(a.glvipsstotal,0) as glvipyhtotal,
           isnull((((isnull(a.glretailtotal,0)-isnull(a.glvipsstotal,0))*1.00)/(nullif((isnull(a.zretailtotal,0)-isnull(a.sstotal,0)),0)*1.00))*100,0)  as glyhsaletotalzb
   from 
   (
     select isnull(cardno,'') as cardno,ISNULL(b.Name,'') as vipcardtypename,
			ISNULL(a.Name,'') as People,ISNULL(a.sex,'') as sex, 
			abs(DATEDIFF(day,getdate(),a.Birthday)/365) as age,
			ISNULL(a.Tel,'') as tel,isnull(c.SaleCs,0) as SaleCs,
			isnull(d.GlSaleCs,0) as GlSaleCs,
			isnull(((isnull(d.GlSaleCs,0)*1.00)/(nullif(ISNULL(c.SaleCs,0),0)*1.00))*100,0)  as glsalecszb,
			isnull(e.vipsaletotal,0) as vipsaletotal,
			isnull(h.glvipsstotal,0) as glvipsaletotal,
			isnull(((isnull(h.glvipsstotal,0)*1.00)/(nullif(ISNULL(e.vipsaletotal,0),0)*1.00))*100,0)  as glsaletotalzb,
			isnull(g.sstotal,0) as sstotal,isnull(h.glvipsstotal,0) as glvipsstotal,
			ISNULL(i.zretailtotal,0) as zretailtotal,
			ISNULL(j.glretailtotal,0) as glretailtotal,
			ISNULL(k.Ename,'') as Ename
        from 
        (
          select * from VIPCard 
        ) a 
        left join VIPCardType b on a.CT_ID=b.ct_id
        left join (
                    select distinct  b.name as Ename,a.VIPCardID,a.e_id  from retailbillidx  a left join employees b  
                            on e_id=b.emp_id     /*XXX.2017-06-20 应该用group by的字段来关联 */
                            where VIPCardID<>0 and billtype =12   and (a.Y_ID=@Y_id or @Y_id=0) and
                            convert(varchar(10),billdate ,21) between @BeginDate and @EndDate 
                            and billstates=0
                   ) k on a.VIPCardID=k.VIPCardID 
        left join 
        (
          select COUNT(VIPCardID)  as SaleCs, VIPCardID from retailbillidx where VIPCardID<>0 and billtype =12 and 
                 convert(varchar(10),billdate ,21) between @BeginDate and @EndDate  and (Y_ID=@Y_id or @Y_id=0)  and billstates=0
                 group by VIPCardID               
        )c on k.VIPCardID=c.VIPCardID 
        left  join
        (
          select COUNT(VIPCardID)  as GlSaleCs, VIPCardID,e_id from retailbillidx where VIPCardID<>0 and billtype =12  and billstates=0
          and (inputman=@Inputid or @Inputid=0)  
          and  (Y_ID=@Y_id or @Y_id=0) and
          convert(varchar(10),billdate ,21) between @BeginDate and @EndDate 
          group by VIPCardID,e_id
        ) d on k.VIPCardID=d.VIPCardID and k.e_id=d.e_id
        left join 
        (
          select sum(b.taxtotal) as vipsaletotal,a.VIPCardID,e_id from retailbillidx a inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12  and  convert(varchar(10),billdate ,21) between @BeginDate and @EndDate and (a.Y_ID=@Y_id or @Y_id=0)  
                       and billstates=0
                 group by a.VIPCardID,e_id
        )e on  k.VIPCardID=e.VIPCardID and k.e_id=e.e_id
        left join 
        (
          select sum(ssmoney) as sstotal,a.VIPCardID,e_id from retailbillidx a 
                 where VIPCardID<>0 and billtype =12  and 
                  convert(varchar(10),billdate ,21) between @BeginDate and @EndDate  and (Y_ID=@Y_id or @Y_id=0)  
                  and billstates=0
                 group by a.VIPCardID,e_id
        )g on  k.VIPCardID=g.VIPCardID and k.e_id=g.e_id
        left join
        (
           select sum(ssmoney) as glvipsstotal,a.VIPCardID,e_id from retailbillidx a 
                 where VIPCardID<>0 and billtype =12   and (inputman=@Inputid or @Inputid=0)  and  (Y_ID=@Y_id or @Y_id=0) and 
                        convert(varchar(10),billdate ,21) between @BeginDate and @EndDate  and billstates=0
                 group by a.VIPCardID,e_id
        )h on k.VIPCardID=h.VIPCardID and k.e_id=h.e_id
        left join 
        (
          select sum(b.retailtotal) as zretailtotal,a.VIPCardID,e_id from retailbillidx a inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12  and  convert(varchar(10),billdate ,21) between @BeginDate and @EndDate and (a.Y_ID=@Y_id or @Y_id=0)  
                       and billstates=0
                 group by a.VIPCardID,e_id
        )i on  k.VIPCardID=i.VIPCardID  and k.e_id=i.e_id
        left join 
        (
          select sum(b.retailtotal) as glretailtotal,a.VIPCardID,e_id from retailbillidx a inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12  and  convert(varchar(10),billdate ,21) between @BeginDate and @EndDate and (a.Y_ID=@Y_id or @Y_id=0)
                      and (inputman=@Inputid or @Inputid=0) and billstates=0
                 group by a.VIPCardID,e_id
        )j on  k.VIPCardID=j.VIPCardID and k.e_id=j.e_id
        where (GlSaleCs>=@SyCS  or @SyCS=0) 
      ) a where (glsalecszb>=@GlD or @GlD=0.00)
  end
  else
  begin
     select ISNULL(cardno,'') as cardno,ISNULL(vipcardtypename,'') as vipcardtypename,ISNULL(People,'') as People,
           ISNULL(sex,'') as sex,ISNULL(age,'') as age,ISNULL(tel,'') as tel,ISNULL(SaleCs,'') as SaleCs,
           ISNULL(GlSaleCs,'') as GlSaleCs,ISNULL(glsalecszb,'') as glsalecszb,
           ISNULL(vipsaletotal,'') as vipsaletotal,ISNULL(glvipsstotal,'') as glvipsaletotal,
           ISNULL(glsaletotalzb,'') as glsaletotalzb,ISNULL(a.Ename,'') as Ename,
           isnull(a.zretailtotal,0)-isnull(a.sstotal,0) as vipyhtotal,
           isnull(a.glretailtotal,0)-isnull(a.glvipsstotal,0) as glvipyhtotal,
           isnull((((isnull(a.glretailtotal,0)-isnull(a.glvipsstotal,0))*1.00)/(nullif((isnull(a.zretailtotal,0)-isnull(a.sstotal,0)),0)*1.00))*100,0)  as glyhsaletotalzb
   from 
   (
     select isnull(cardno,'') as cardno,ISNULL(b.Name,'') as vipcardtypename,
			ISNULL(a.Name,'') as People,ISNULL(a.sex,'') as sex, 
			abs(DATEDIFF(day,getdate(),a.Birthday)/365) as age,
			ISNULL(a.Tel,'') as tel,isnull(c.SaleCs,0) as SaleCs,
			isnull(d.GlSaleCs,0) as GlSaleCs,
			isnull(((isnull(d.GlSaleCs,0)*1.00)/(nullif(ISNULL(c.SaleCs,0),0)*1.00))*100,0)  as glsalecszb,
			isnull(e.vipsaletotal,0) as vipsaletotal,
			isnull(h.glvipsstotal,0) as glvipsaletotal,
			isnull(((isnull(h.glvipsstotal,0)*1.00)/(nullif(ISNULL(e.vipsaletotal,0),0)*1.00))*100,0)  as glsaletotalzb,
			isnull(g.sstotal,0) as sstotal,isnull(h.glvipsstotal,0) as glvipsstotal,
			ISNULL(i.zretailtotal,0) as zretailtotal,
			ISNULL(j.glretailtotal,0) as glretailtotal,
			ISNULL(k.Ename,'') as Ename
        from 
        (
          select * from VIPCard 
        ) a 
        left join VIPCardType b on a.CT_ID=b.ct_id
        left join (
                    select distinct  b.name as Ename,a.VIPCardID,a.e_id  from retailbillidx  a left join employees b  
                            on e_id=b.emp_id
                            where VIPCardID<>0 and billtype =12   and (a.Y_ID=@Y_id or @Y_id=0) and billstates=0
                   ) k on a.VIPCardID=k.VIPCardID 
        left join 
        (
          select COUNT(VIPCardID)  as SaleCs, VIPCardID from retailbillidx where VIPCardID<>0 and billtype =12 and 
                 convert(varchar(10),billdate ,21) between @BeginDate and @EndDate  and (Y_ID=@Y_id or @Y_id=0)  and billstates=0
                 group by VIPCardID              
        )c on k.VIPCardID=c.VIPCardID
        left  join
        (
          select COUNT(VIPCardID)  as GlSaleCs, VIPCardID,e_id from retailbillidx where VIPCardID<>0 and billtype =12  and billstates=0
          and (inputman=@Inputid or @Inputid=0)  
          and  (Y_ID=@Y_id or @Y_id=0) 
          group by VIPCardID,e_id
        ) d on k.VIPCardID=d.VIPCardID and k.e_id=d.e_id
        left join 
        (
          select sum(b.taxtotal) as vipsaletotal,a.VIPCardID,e_id from retailbillidx a inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12  and (a.Y_ID=@Y_id or @Y_id=0)  
                       and billstates=0
                 group by a.VIPCardID,e_id
        )e on  k.VIPCardID=e.VIPCardID and k.e_id=e.e_id
        left join 
        (
          select sum(ssmoney) as sstotal,a.VIPCardID,e_id from retailbillidx a 
                 where VIPCardID<>0 and billtype =12  and 
                  (Y_ID=@Y_id or @Y_id=0)  
                  and billstates=0
                 group by a.VIPCardID,e_id
        )g on  k.VIPCardID=g.VIPCardID and k.e_id=g.e_id
        left join
        (
           select sum(ssmoney) as glvipsstotal,a.VIPCardID,e_id from retailbillidx a 
                 where VIPCardID<>0 and billtype =12   and (inputman=@Inputid or @Inputid=0)  and  (Y_ID=@Y_id or @Y_id=0) and 
                          billstates=0
                 group by a.VIPCardID,e_id
        )h on k.VIPCardID=h.VIPCardID and k.e_id=h.e_id
        left join 
        (
          select sum(b.retailtotal) as zretailtotal,a.VIPCardID,e_id from retailbillidx a 
                 inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12  and (a.Y_ID=@Y_id or @Y_id=0)  
                       and billstates=0
                 group by a.VIPCardID,e_id
        )i on  k.VIPCardID=i.VIPCardID  and k.e_id=i.e_id
        left join 
        (
          select sum(b.retailtotal) as glretailtotal,a.VIPCardID,e_id from retailbillidx a 
                 inner  join retailbill b on a.billid=b.bill_id
                 where billtype =12 and (a.Y_ID=@Y_id or @Y_id=0)
                      and (inputman=@Inputid or @Inputid=0) and billstates=0
                 group by a.VIPCardID,e_id
        )j on  k.VIPCardID=j.VIPCardID and k.e_id=j.e_id
        where (GlSaleCs>=@SyCS  or @SyCS=0) 
      ) a where (glsalecszb>=@GlD or @GlD=0.00)
  end
end
GO
