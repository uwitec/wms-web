

CREATE proc ts_j_MerageTransBill
( @BeginDate varchar(100),
  @EndDate varchar(100),
  @nFlag int,   /*1.按经手人合并 2.按制单人合并  3.按经手人制单人合并*/
  @nRet  int output
)
as
set nocount on

declare @nNewBillId int, @nCount int, @nSS_ID int, @nSD_ID int, @nY_ID int
declare @dTotal NUMERIC(25,8)

set @nret=-1 

begin tran c1

    declare covertbill cursor local scroll for
	select distinct sout_id, sin_Id, y_id
	from billidx 
	where billdate between @BeginDate and @EndDate
		  and billtype = 44 and billstates='0' and summary <> '已合并' 	
	open covertbill

	fetch next from covertbill into @nSS_ID, @nSD_ID, @nY_ID

	while @@FETCH_STATUS=0
	begin

	/*将需要修改billid 写入临时表*/
    if OBJECT_ID('tempdb..#MtransTmp') is not null
	  drop table #MtransTmp
	  
	select billid into #MtransTmp from billidx
	where billdate between @BeginDate and @EndDate
		  and  billtype = 44 and billstates='0' and summary <> '已合并' and sout_id  = @nSS_ID 
		  and  sin_id  =@nSD_ID and Y_ID =@nY_ID
		  
    select @nCount =@@ROWCOUNT		  
	
    select @nNewBillId= isnull(MAX(billid), 0) from #MtransTmp
        
    
    if (@nNewBillId > 0)      
    begin
      if @nCount >1 
      begin	
           select @dTotal = SUM(costtotal)
             from storemanagebill
             where bill_id in (select billid from #MtransTmp)                							  		
		  /*处理storemanagebill*/
		   update storemanagebill set bill_id = @nNewBillId  
		   where bill_id in (select billid from #MtransTmp where billid <> @nNewBillId)
		  /*处理productdetail*/
		  update productdetail  set billid  = @nNewBillId
			where billid in (select billid from #MtransTmp where billid <> @nNewBillId)
		  /*删除多余billidx*/
		  delete billidx where billid in (select billid from #MtransTmp where billid <> @nNewBillId)
		  /*增加合标识*/
		  update billidx set note = '已合并'+note, summary= '已合并', ysmoney =@dTotal, ssmoney =@dTotal where billid = @nNewBillId
		  if @@ERROR <> 0  goto error  
	  end 
	  else begin
	    update billidx set note = '已合并'+note, summary= '已合并' where billid = @nNewBillId
	    if @@ERROR <> 0  goto error  
	  end	  		  
     end
     
  
    
    fetch next from covertbill into @nSS_ID, @nSD_ID, @nY_ID
	end
	
	
	close covertbill
	deallocate covertbill
    set @nRet = 0
commit tran c1  
      
return 0
  
error:
  rollback tran c1
  close covertbill
  deallocate covertbill
  set @nret=-1
  RAISERROR('单据合并失败.',16,1)
  return -1
GO
