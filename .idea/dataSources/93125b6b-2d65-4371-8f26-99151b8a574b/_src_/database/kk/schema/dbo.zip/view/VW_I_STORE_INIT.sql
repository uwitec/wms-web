

/*1.表  i_store_init (导入期初库存账)*/
CREATE VIEW VW_I_STORE_INIT
AS


SELECT 

	1 as id   				/*//numeric(18, 0)  identity,(自增列)生成导入值时?        */
	,ISNULL(R.RangeName,' ') as cat_name     	/*//varchar(20)     not null,(药品大类)取值：西药、中成药、中草药、材料、保健品、器械)*/
	,' ' as item_search 			/*//varchar(20)         null,(项目化学名称检索码)*/
	,ISNULL(P.ChemName,' ') as item_name    /*//varchar(60)     not null,(项目化学名称)*/
	,ISNULL(P.serial_number,' ') as trade_search 	/*//varchar(20)         null,(项目商品名称检索码)*/
	,ISNULL(P.Name,' ')as trade_name   		/*//varchar(60)         null,(项目商品名称)*/
	,ISNULL(m.medtype,' ') as jx_name        /*//varchar(16)         null,(剂型名称)取值见下面附1.剂型名称一览*/
	,ISNULL(P.standard,' ') as standard     /*//varchar(50)         null,(规格)*/
	,ISNULL(U.NAME,' ') as unit         	/*//varchar(10)     not null,(单位)*/
	,' 'as mfr_search   			/*//varchar(10)         null,(厂家检索码)*/
	,ISNULL(P.Factory,' ') as mfr_name     	/*//varchar(40)     not null,(厂家名) */
	,ISNULL(P.PermitCode,' ') as wenhao	/*//varchar(50)     not null,(批准文号)*/
	,' ' as is_import    			/*//char(1)             null,(1 进口 0 非进口)*/
	,ISNULL(R.RangeName,' ') as rang_name    	/*//varchar(60)     not null,(产品范围)取值见下面附2.产品所属范围名称一览*/
	,ISNULL(SH.BATCHNO,' ') as ypph         /*//varchar(30)         null,(药品批号)*/
	,ISNULL(SH.validdate,' ')  as validate  /*//datetime            null,(有效期)*/
	,ISNULL(SH.QUANTITY,' ') as num         /*//decimal(10, 3)  not null,(数量)*/
	,ISNULL(SH.COSTPRICE,' ') as price      /*//decimal(10, 3)      null,(价格)*/
	,' ' as usercode     			/*//varchar(10)     not null,(操作员编号)*/

FROM STOREHOUSEINI 	SH
INNER JOIN PRODUCTS 	P	ON	P.PRODUCT_ID = SH.P_ID	
left   join VW_Range r on p.product_id = r.product_id
left   join VW_MedType  m on p.product_id = m.product_id
LEFT JOIN UNIT		U	ON	P.UNIT1_ID = U.UNIT_ID
GO
