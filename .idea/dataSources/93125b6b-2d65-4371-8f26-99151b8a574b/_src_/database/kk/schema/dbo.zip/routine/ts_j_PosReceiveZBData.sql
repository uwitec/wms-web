/************************************************************

--功能：离线版本接收总部数据   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_PosReceiveZBData

AS 

declare @nY_ID int
  select top 1 @nY_ID = cast(sysvalue as int)   from sysconfig where [sysname] = 'Y_ID'

  BEGIN TRANSACTION	imzbdata
    /*导入vipcard*/
    delete VIPCard where VIPCardID in (select VIPCardID from VIPCarddts)
    
	insert into VIPCard(VIPCardID, CardNo, Name, sex, Tel, Birthday, [Address], Comment, IDCard, CT_ID,
           BulidDate, ValidityDate, Pos_Id, E_id, IniMoney, TotalBuyMoney, SaveMoney, IntergralYE,
           IniIntergral, Integral, SwapIntegral, BuyCount, LoginPass, Deleted, Lose, StopUse,
           RemainderMoney, PinYin, [Guid], isLock, Y_ID)
    select VIPCardID, CardNo, Name, sex, Tel, Birthday, [Address], Comment, IDCard, CT_ID,
           BulidDate, ValidityDate, Pos_Id, E_id, IniMoney, TotalBuyMoney, SaveMoney, IntergralYE,
           IniIntergral, Integral, SwapIntegral, BuyCount, LoginPass, Deleted, Lose, StopUse,
           RemainderMoney, PinYin, [Guid], isLock, Y_ID
    from VIPCarddts
    
	update sysconfig set sysvalue = t.sysvalue 
	from sysconfig s, sysconfigdts t where s.[sysname] = t.[sysname] and s.y_id = t.y_id 
	      
	delete sysconfigdts from sysconfig s, sysconfigdts t where s.[sysname] = t.[sysname] and s.y_id = t.y_id  
	  
	if exists(select 1 from sysconfigdts)    
	  
	insert into sysconfig([sysname], sysvalue, comment, sysflag, Y_ID)
	select [sysname], sysvalue, comment, sysflag, Y_ID 
	from sysconfigdts 
	    
	truncate table cxidx
	truncate table cxbill
	 
	 
	 /*SET IDENTITY_INSERT cxidx on--关闭自增加列控制*/
	     
     insert into cxidx(billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,[guid])
		select billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			billid, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,[guid]
 			from cxidxdts
 			
    /*SET IDENTITY_INSERT cxidx OFF  			*/
 			
     insert into cxbill(bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment)
		select bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment
		  from CxBilldts
		  update CxBill set Bill_ID = bi.billid from cxbill mx, cxidx bi where mx.Bill_ID = bi.period
		  update cxidx set period = 0
		  
     truncate table cxtable
     
     insert into cxtable(p_id, u_id, posid, qty, discount, price, begindate,
              enddate, begintime, endtime, active, Y_ID,xq,priceleveal,lowpricelimit  )  
       select p_id, u_id, posid, qty, discount, price, begindate,
              enddate, begintime, endtime, active, Y_ID,xq,priceleveal,lowpricelimit  
         from cxtabledts
   
    delete price from price p, pricedts t where p.p_id = t.p_id and p.u_id =t.u_id 
          		 	
	insert into price(p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, 
	           specialprice, unittype, lowprice, lastprice, lasttime, billid)
	select p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, 
	           specialprice, unittype, lowprice, lastprice, lasttime, billid
	from pricedts
	
	delete pospricedts where Y_ID  <> @nY_ID      
	delete PosPricedts where Y_ID=0
	
	delete posprice from posprice p, pospricedts t 
	where p.p_id = t.p_id and p.u_id =t.u_id and p.Y_ID = t.Y_ID
	      	
	insert into PosPrice(pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice,
	         specialprice, unittype, lowprice, lastprice, lasttime, billid, y_id)
	select pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice,
	         specialprice, unittype, lowprice, lastprice, lasttime, billid, y_id 
	from PosPricedts where Y_ID=@nY_ID
	    
               
    update sysconfig set sysvalue = cast(GETDATE() as varchar) where [sysname] = 'LastDownTime'
    update sysconfig set sysvalue = '0' where [sysname] = 'DownSuccess'  
     
     
     
    /*删除已经下传过的配送单据 */
    delete salemanagebilldts from billdtsidx a,billidx b,salemanagebilldts c
    where a.billid=c.bill_id and  a.GUID=b.GUID  and b.billstates=0 
    
    delete billdtsidx from billdtsidx a,billidx b
    where a.GUID=b.GUID and b.billstates=0 


    
	declare @billid int,@posguid varchar(50),@LocalPosguid varchar(50)
	declare @LocalS_id int,@localinputman int,@localauditman int,@localeid int
	declare @locationid int,@smbid int,@pid int,@sinid int,@soutid int ,@cid int, @nSin_id int
	declare @BillType int, @newBillType int
	declare @nZBSid int, @nZBEid int, @nYType int,@nnewbillid int,@npid int,@nret int

	/*select @LocalPosguid=sysvalue from sysconfig where [sysname]='GUID'*/
	exec ts_getsysvalue 'Y_ID',@nY_id out

	exec ts_getsysvalue 'GUID',@LocalPosguid out

	/*select @LocalS_id=sysvalue from sysconfig where [sysname]='LocalSid'*/
	exec ts_getsysvalue 'LocalSid',@LocalS_id out, @nY_id

	/*select @localinputman=sysvalue from sysconfig where [sysname]='LocalInputman'*/
	exec ts_getsysvalue 'LocalInputman',@localinputman out, @nY_id

	/*select @localauditman=sysvalue from sysconfig where [sysname]='LocalAuditman'*/
	exec ts_getsysvalue 'LocalAuditman',@localauditman out, @nY_id

	/*select @localeid=sysvalue from sysconfig where [sysname]='LocalEid'*/
	exec ts_getsysvalue 'LocalEid',@localeid out, @nY_id
	exec ts_getsysvalue 'ZBSid',@nZBSid out
	exec ts_getsysvalue 'ZBEid',@nZBEid out
	select @nYType = Ytype from company where company_id = @nY_id
	/*if @nYType= 2 and (@nZBSid = 0 or @nZBSid = 0) return 0*/
	if @localeid =0 or @LocalS_id = 0 return 0
	 

	/* 导入价格促销单*/
	declare @nCxId int
	declare @nNewId int
	delete from CxBillIdx where guid not in(select guid from CxBillIdxDts)
	delete from CxBillNew where billid not in (select billid from CxBillIdx)
	
	update CxBillIdx set billstate = x.billstate
	from (select guid, billstate from CxBillIdxDts)x
	where CxBillIdx.guid = x.guid
	
	declare curCx cursor for
	select billid from CxBillIdxDts where guid not in(select guid from CxBillIdx)
	open curCx
	fetch next from curCx into @nCxId
	while @@fetch_status = 0
	begin
		INSERT INTO dbo.CxBillIdx
			(billnumber, e_id, c_id, Y_ID, auditman, inputman, billstate, billdate, auditdate, cp_id, begindate, enddate, begintime, endtime, billtype, cardtype, 
							  weekday, priority, totalmoney, comment, guid, cpname)
		SELECT     billnumber, e_id, c_id, Y_ID, auditman, inputman, billstate, billdate, auditdate, cp_id, begindate, enddate, begintime, endtime, billtype, cardtype, 
							  weekday, priority, totalmoney, comment, guid, cpname
		FROM         dbo.CxBillIdxDts where billid = @nCxId

		set @nNewId = @@IDENTITY

		INSERT INTO dbo.CxBillNew
			(billid, p_id, unit_id, price, discount, lownum, billlimit, totallimit, total, grouptotal, presenttype, groupnum, comment, sale, guid)
		SELECT     @nNewId, p_id, unit_id, price, discount, lownum, billlimit, totallimit, total, grouptotal, presenttype, groupnum, comment, sale, guid
		FROM         dbo.CxBillNewDts where billid = @nCxId

		fetch next from curCx into @nCxid
	end

	close curCx
	deallocate curCx

  COMMIT TRANSACTION	imzbData


    
	/*总部物价库调整*/
	select distinct p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid
	into #pricettt1
	from price

	truncate table price

	insert price 
		  (p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid)
	select p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid
	from  #pricettt1

	drop table #pricettt1


	/*门店物价库调整*/
	select distinct p_id,pos_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid,Y_ID
	into #pricettt2
	from PosPrice


	truncate table Posprice

	insert PosPrice 
		  (pos_id,p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid,y_id)
	select pos_id,p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,lowprice,lastprice,lasttime,billid,y_id
	from  #pricettt2

	drop table #pricettt2

    delete PosPrice where Y_ID = 0


	truncate table buymanagebilldts
	declare @szErrBillNo varchar(1000),@billnumber varchar(30)
	
	set @szErrBillNo='' 
	set @billnumber=''

	/*总部发货单转收货单*/
		declare ConvertCur cursor for
		select billid,posguid,billtype,billnumber
		from billdtsidx
		where billtype in (150, 152)
		
		open convertcur
		
		fetch next from convertcur into @billid,@posguid, @BillType,@billnumber
		
		while @@fetch_status=0
		begin
			if @BillType = 150 
			  set @newBillType = 160
			else if @BillType = 152
			  set @newBillType = 162
			else set @newBillType = 0 
		      
			if @posguid<>@LocalPosguid 
			begin
				delete from billdtsidx where billid=@billid
				delete from salemanagebilldts where bill_id=@billid
			end
			else 
			begin
				select @nSin_id = sin_id from billdtsidx where billid  = @billid	

				if exists(select 1 from storages where y_id = @nY_id and storage_id = @nSin_id ) and (@nYType <> 2)
				set @LocalS_id = @nSin_id
				
				update billdtsidx set billtype=@newBillType, sout_id=@LocalS_id, sin_id=@LocalS_id,c_id=Y_ID,ssmoney=0,billstates='3',Y_ID = @nY_id,
												  jsye =ysmoney, jsflag = '0', inputman = @localinputman, auditman = @localauditman, e_id = @localeid
				where billid=@billid
				
				insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
				SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate,WholeQty,PartQty) 

				select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney,araptotal, quantity, taxrate, 0, billstates, order_id, department_id, 
				Posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,guid,
				SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate,Enddate,WholeQty,PartQty
				from billdtsidx where billid=@billid
				
				select @nnewbillid=@@identity
			    
				insert into BuymanagebillDrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney,		taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus,	price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,	taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,sendQty,SendCostTotal,
                RowGuid,RowE_id,YcostPrice,	  YGUID,Y_ID,	instoretime,comment2)
				select @nnewbillid, p_id, batchno, quantity, discountprice, saleprice, discount, discountprice, 
				totalmoney,		taxprice, taxtotal, taxMoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus,	price_id, @LocalS_id, 0, location_id2, supplier_id, commissionflag, 
				comment,unitid,	taxrate, 0,      total,iotag,InvoiceTotal ,thqty,newprice,0,	   aoid,quantity,totalmoney,
				RowGuid,@localeid,YcostPrice, YGUID,@nY_id, instoretime,comment2
				from Salemanagebilldts where bill_id=@billid and p_id > 0
				order by smb_id
				
				exec ts_c_BillAudit @nnewbillid,@npid out,@nret out ,@newBillType
				if @nret<>0 
				begin
				    delete from buymanagebilldrf where bill_id=@nnewbillid
				    delete from billdraftidx where billid=@nnewbillid
					set @szErrBillNo=@szErrBillNo+@billnumber+char(10)
				end
			end
			fetch next from convertcur into @billid,@posguid, @BillType,@billnumber
		end

		close convertcur
		deallocate convertcur


truncate table tasklistdts
truncate table otherstorehousedts
truncate table productsdts
truncate table barcodedts
truncate table clientsdts
truncate table employeesdts
truncate table VIPCarddts
truncate table companydts
truncate table storagesdts
truncate table locationdts
truncate table accountdts
truncate table sysconfigdts
truncate table cxidxdts
truncate table CxBilldts
truncate table cxtabledts
truncate table storehousedts
truncate table pricedts
truncate table pospricedts
truncate table OtherStorehousedts
truncate table billdtsidx
truncate table Salemanagebilldts
truncate table cxbillidxdts
truncate table cxbillnewdts

if @szErrBillNo<>''
begin
	declare @szRAISERROR varchar(2000)

	set @szRAISERROR='包含下列单据编号的自营店发货单下载失败，请联系总部重新下载！'+char(10)+@szErrBillNo
	update sysconfigtmp set comment=@szRAISERROR where sysname='PosReceviceDataInfo'
end else
begin
	update sysconfigtmp set comment='' where sysname='PosReceviceDataInfo'
end

return 0
GO
