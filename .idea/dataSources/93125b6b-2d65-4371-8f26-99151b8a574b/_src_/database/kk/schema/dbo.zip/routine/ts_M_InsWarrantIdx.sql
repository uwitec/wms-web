
CREATE PROCEDURE [dbo].[ts_M_InsWarrantIdx] 
(
@nRET int output,
@Type int ,/*1.销售凭证 2.调拨凭证 3.报损凭证4.报溢凭证 5.采购凭证*/
@Summary  varchar(500) ='',/*摘要*/
@BillCount int=0 ,
@YsMoney NUMERIC(25,8) =0,/*应收帐款*/
@MoneyTotal NUMERIC(25,8) =0,/*销售收入*/
@TaxTotal NUMERIC(25,8)=0,/*销售税额*/
@CostTotal NUMERIC(25,8)=0,/*销售成本*/
@Profit NUMERIC(25,8)=0,/*利润率*/
@WarrantNO varchar(100)=''/*凭证号*/
)
AS
set @nRET=-1

INSERT INTO [WarrantIdx]
      ([Type], [Summary], [BillCount], [YsMoney], [MoneyTotal], [TaxTotal], [CostTotal], [Profit], [Deleted], [WarrantNO])
VALUES(@Type,  @Summary,  @BillCount,  @YsMoney,  @MoneyTotal,  @TaxTotal,  @CostTotal,  @Profit,  0, @WarrantNO)

IF @@ROWCOUNT=1
  set @nRET = @@IDENTITY
GO
