
CREATE  PROCEDURE  TS_L_CTIntegralANDDiscountOther
(   @CTid  int,
    @tabletype  int,/*0 查询特殊商品积分；1 查询特殊商品兑换积分；2 查询特殊商品折扣*/
    @pclassid  varchar(50),
    @IntegralMoney  NUMERIC(25,8)    output
)
AS
   declare @szsql varchar(8000)
   declare @Pcid varchar(100)
   declare @money NUMERIC(25,8)


if @tabletype=0              
select @money=isnull(a.IntegralMoney,-1)  from (select T.* , P.Class_id from  CTIntegralOther T Left join Products P On T.p_id=P.product_id
        where T.ct_id=@CTid and p.deleted=0)a where a.Class_id=@pclassid
else
if @tabletype=1
select @money=isnull(a.ExchangeIntegral,-1)  from (select T.* , P.Class_id from  CTExchangeIntegral T Left join Products P On T.p_id=P.product_id
        where T.ct_id=@CTid and p.deleted=0)a where a.Class_id=@pclassid
else
if @tabletype=2 
select @money=isnull(a.Discount,-1)  from (select T.* , P.Class_id from  CTDiscountOther T Left join Products P On T.p_id=P.product_id
        where T.ct_id=@CTid and p.deleted=0)a where a.Class_id=@pclassid      
      

   if isnull(@money,-1)<=0
   begin
      select @Pcid=left(@Pclassid,len(@Pclassid)-6)
      
      if isnull(@Pcid, '')<>''
        exec TS_L_CTIntegralANDDiscountOther @CTid , @tabletype , @pcid , @Integralmoney out
      else 
        select @Integralmoney=-1 
   end
   else
   begin
    select @IntegralMoney=@money     
   end
GO
