
CREATE VIEW dbo.VW_H_ExamPatients
AS
SELECT     dbo.Patients.PatientID, dbo.Patients.Name, dbo.Patients.sex, dbo.Patients.Tel, dbo.Patients.Birthday, dbo.Patients.Job, dbo.Patients.Address, 
                      dbo.Patients.Comment, dbo.Patients.IDCard, dbo.Patients.BulidDate, dbo.Patients.Pos_Id, dbo.Patients.Deleted, dbo.Patients.PinYin, 
                      dbo.Patients.Guid, dbo.Patients.ModifyDate, dbo.Patients.isVIP, dbo.Patients.VIP_ID, ISNULL(Registered.regDate, '1900-1-1') AS regDate, 
                      ISNULL(Registered.count, 0) AS Count, dbo.employees.name AS PosName, dbo.GetAge(dbo.Patients.Birthday, GETDATE()) AS Age
                      ,isnull(VIPCard.CardNo,'') as CardNo 
FROM         dbo.Patients INNER JOIN
                      dbo.employees ON dbo.Patients.Pos_Id = dbo.employees.emp_id LEFT OUTER JOIN
                          (SELECT     Patient_ID, MAX(RegDate) AS regDate, COUNT(*) AS count
                            FROM          dbo.Registered AS Registered_1
                            GROUP BY Patient_ID) AS Registered ON dbo.Patients.PatientID = Registered.Patient_ID
           LEFT JOIN  VIPCard on  VIPCard.VIPCardID=dbo.Patients.VIP_ID           
WHERE     (dbo.Patients.Deleted = 0)
GO
