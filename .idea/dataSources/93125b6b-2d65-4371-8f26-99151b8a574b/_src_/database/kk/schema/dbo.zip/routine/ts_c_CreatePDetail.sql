/*-----------------------
-产生商品明细账
-----------------------*/

create    procedure [dbo].[ts_c_CreatePDetail]
(
	@nBillId numeric(10,0)
)
/*with encryption*/
as
set nocount on
/*const define*/
DECLARE
  @vtBuyDirectMid     int,/* 104;                  //  直调药品采购单（中间商）*/
  @vtBuyDirectGet     int,/* 105;                  //  直调药品采购单（收货方）*/
  @vtSaleDirectMid    int,/* 106;                  //  直调药品销售单（中间商）*/
  @vtSaleDirectSend   int,/* 107;                  //  直调药品销售单（发货方）*/
	
  @vtSale 				  int,/*= 10;                     销售出库单*/
  @vtSaleAccount    	  int,/*= 210;		  //   销售单*/
  @vtSaleBack 		  int,/* = 11;                  //  销售出库退货单*/
  @vtSaleAccountBack 	  int,/* 211;                  //  销售退货单*/
  @vtSend            	  int,/*= 212;                  //  发货单*/
  @vtRetail  				int,/*= 12;                   //  零售单*/
  @vtRetailBack  		int,/*= 13;                   //  零售退货单*/
  @vtSaleOrder 		  int,/* = 14;                  //  销售定单*/
  @vtGathering 			int,/* = 15;                  //  收款单*/
  @vtYSend 	    int,/*= 150;                     //  机构发货单*/
  @vtYSendBack      int,/*= 151;                 //  机构发货退货单*/
  @vtYSelfSend 	    int,/*= 152;                     //  自营店发货单*/
  @vtYSelfSendBack      int,/*= 153;                 //  自营店发货退货单*/
  @vtYGathering     int,/*= 155;                //  机构收款单*/

  @vtBuy 			 			int,/*20;                        //  进货单*/
  @vtBuyAccount     int,/* 220;                  //  采购单*/
  @vtBuyBack  		  int,/*= 21;                    //  进货退货单*/
  @vtBuyAccountBack int,/* 221;                   //  采购退货单*/
  @vtReceive 	    int,/* 222;                   //  收货单*/
  @vtBuyOrder 			int,/* = 22;                   //  进货定单*/
  @vtPayment  			int,/*= 23;                    //  付款单*/
  @vtYReceive       int,/*= 160;                  //  机构收货单*/
  @vtYReceiveBack   int,/*= 161;              //  机构收货退货单*/
  @vtYSelfReceive       int,/*= 162;                  //自营店收货单*/
  @vtYSelfReceiveBack   int,/*= 163;              //  自营店收货退货单*/
  @vtYPayment       int,/*= 165;                  //  机构付款单*/

  @vtLend  				  int,/*= 30;                   //  借出单*/
  @vtLendBack  			int,/*= 31;                   //  借出还回单*/
  @vtLendSale  			int,/*= 32;                   //  借出转销售单*/
  @vtBorrow  				int,/* 33;                    //  借进单*/
  @vtBorrowBack  		int,/* 34;                    //  借进还出单*/
  @vtBorrowBuy  		int,/* 35;                    //  借进转进货单*/

  @vtCleanPack          INT,/*38                   //清斗单*/
  @vtScattered          INT,/*39                   //零售拆零单  */
  @vtProduce  			int,/* 40;                  //  组装单*/
  @vtLost  			  	int,/* 41;                  //  报损单*/
  @vtOverflow  			int,/* 42;                  //  报溢单*/
  @vtAdjustPrice  	int,/* 43;                  //  调价单*/
  @vtTransfer  			int,/* 44;                  //  调拨单*/
  @vtTransfer_Price int,/* 45;                  //  变价调拨单*/
  @vtGive  				  int,/* 46;                  //  赠送单*/
  @vtGain  				  int,/* 47;                  //  获赠单*/
  @vtInLib          int,/*48			             	//  入库单*/
  @vtOutLib         int,/*49			            	//  出库单*/
  @vtGoodsCheck 		int,/*50;                 	//  库存盘点单*/
  @vtBatchAdjust		int,/*51;//库存批次调整单*/


  @vtTranOut 		int,/*53//总部配送出库单*/
  @vtTranOutBack 	int,/*54//总部配送退货单*/
  @vtTranIn 		int,/*55//门店配送入库单*/
  @vtTranInBack 	int,/*56//门店配送退货单*/

  @vtCashExpense  	int,/* 60;                  //  现金费用单*/
  @vtExpense  			int,/* 61;                  //  费用单*/
  @vtOtherIncome  	int,/* 62;                  //  其它收入单*/
  @vtMoney  				int,/* 63;                  //  现金转帐单*/
  @vtAR_Add  				int,/* 64;                  //  应收增加*/
  @vtAR_Reduce  		int,/* 65;                  //  应收减少*/
  @vtAP_Add  				int,/* 66;                  //  应付增加*/
  @vtAP_Reduce  		int,/* 67;                  //  应付减少*/
  @vtCash_Add  			int,/* 68;                  //  资金增加*/
  @vtCash_Reduce  	int,/* 69;                  //  资金减少*/

  @vtFixedBuy  			int,/* 80;                  //  固定资产购置*/
  @vtFixedSale  		int,/* 81;                  //  固定资产变卖*/
  @vtFixedDepreciation  int,/* 82;              //  固定资产折旧*/
  @vtExpenseHappen  		int,/* 83;              //  待摊费用发生*/
  @vtExpenseAmortize  	int,/* 84;              //  待摊费用摊销*/

  @vtAccount  				  int,/* 90;              //  会计凭证*/

  @vtSendGoods  				int,/* 100;             //  发货单*/
  @vtSendBack  				  int,/* 101;             //  发货退货单*/
  @vtSendSettle  				int,/* 102;             //  发货结算单*/
  @vtSendPrice  				int,/* 103;             //  发货调价单*/

  @vtCommission  				int,/* 110;             //  委托代销单*/
  @vtCommBack  				  int,/* 111;             //  委托代销退货单*/
  @vtCommSettle  				int,/* 112;             //  委托代销结算单*/
  @vtCommPrice  				int,/* 113;             //  委托代销调价*/
  @SaleDiscount			int,/*销售折让*/

  @vtReCommission  			int,/* 120;             //  受托代销单*/
  @vtReCommBack  				int,/* 121;             //  受托代销退货单*/
  @vtReCommSettle  			int,/* 122;             //  受托代销结算单*/
  @vtReCommPrice  			int,/* 123;             //  受托代销调价*/

  @vtCommRecive  				int,/* 130;             //  库外入库单*/
  @vtCommPayment  			int,/* 131;             //  库外出库单*/
  @vtVipIntegralExChange                int /* 149          //  会员卡积分兑换单*/

  select
  @vtBuyDirectMid     = 104,                  /*  直调药品采购单（中间商）*/
  @vtBuyDirectGet     = 105,                  /*  直调药品采购单（收货方）*/
  @vtSaleDirectMid    = 106,                  /*  直调药品销售单（中间商）*/
  @vtSaleDirectSend   = 107,                  /*  直调药品销售单（发货方）*/
  @vtSale 				  = 10,                   /*  销售出库单*/
  @vtSaleAccount    = 210,	            /*   销售单*/
  @vtSaleBack 		  = 11,                   /*  销售出库退货单*/
  @vtSaleAccountBack = 211,                 /*  销售退货单*/
  @vtSend 	     = 212,                 /*  发货单*/
  @vtRetail  				= 12,                   /*  零售单*/
  @vtRetailBack  		= 13,                   /*  零售退货单*/
  @vtSaleOrder 		  = 14,                   /*  销售定单*/
  @vtGathering 			= 15,                   /*  收款单*/
  @vtYSend 	     = 150,                 /*//  机构发货单*/
  @vtYSendBack       = 151,                 /*//  机构发货退货单*/
  @vtYSelfSend 	     = 152,                 /*//  自营店发货单*/
  @vtYSelfSendBack       = 153,                 /*//  自营店发货退货单*/
  @vtYGathering      = 155,                 /*//  机构收款单*/

  @vtBuy            = 20,                   /*  进货单*/
  @vtBuyAccount       = 220,                   /*  采购单*/
  @vtBuyBack  		  = 21,                   /*  进货退货单*/
  @vtBuyAccountBack   = 221,                    /*  采购退货单*/
  @vtReceive          = 222,                   /*  收货单*/
  @vtBuyOrder 			= 22,                   /*  进货定单*/
  @vtPayment  			= 23,                   /*  付款单*/
  @vtYReceive       = 160,                  /*//  机构收货单*/
  @vtYReceiveBack   = 161,                  /*//  机构收货退货单*/
  @vtYSelfReceive       = 162,                  /*//  自营店收货单*/
  @vtYSelfReceiveBack   = 163,                  /*//  自营店收货退货单*/
  @vtYPayment       = 165,                  /*//  机构付款单*/


  @vtLend  				  = 30,                   /*  借出单*/
  @vtLendBack  			= 31,                   /*  借出还回单*/
  @vtLendSale  			= 32,                   /*  借出转销售单*/
  @vtBorrow  				= 33,                   /*  借进单*/
  @vtBorrowBack  		= 34,                   /*  借进还出单*/
  @vtBorrowBuy  		= 35,                   /*  借进转进货单*/

  @vtScattered          = 39,                   /*零售拆零单*/
  @vtCleanPack          =38,                   /*清斗单*/
  @vtProduce  			= 40,                   /*  组装单*/
  @vtLost  			  	= 41,                   /*  报损单*/
  @vtOverflow  			= 42,                   /*  报溢单*/
  @vtAdjustPrice  	= 43,                   /*  调价单*/
  @vtTransfer  			= 44,                   /*  调拨单*/
  @vtTransfer_Price = 45,                   /*  变价调拨单*/
  @vtGive  				  = 46,                   /*  赠送单*/
  @vtGain  				  = 47,                   /*  获赠单*/
  @vtInLib          = 48,			             	/*  入库单*/
  @vtOutLib         = 49,			          		/*  出库单*/
  @vtGoodsCheck			=	50,										/*	库存盘点单*/
  @vtBatchAdjust    =51,
  @vtTranOut 		=53,/*//总部配送出库单*/
  @vtTranOutBack 	=54,/*//总部配送退货单*/
  @vtTranIn 		=55,/*//门店配送入库单*/
  @vtTranInBack 	=56,/*//门店配送退货单*/
  

  @vtCashExpense  	= 60,                   /*  现金费用单*/
  @vtExpense  			= 61,                   /*  费用单*/
  @vtOtherIncome  	= 62,                   /*  其它收入单*/
  @vtMoney  				= 63,                   /*  现金转帐单*/
  @vtAR_Add  				= 64,                   /*  应收增加*/
  @vtAR_Reduce  		= 65,                   /*  应收减少*/
  @vtAP_Add  				= 66,                   /*  应付增加*/
  @vtAP_Reduce  		= 67,                   /*  应付减少*/
  @vtCash_Add  			= 68,                   /*  资金增加*/
  @vtCash_Reduce  	= 69,                   /*  资金减少*/

  @vtFixedBuy  			= 80,                   /*  固定资产购置*/
  @vtFixedSale  		= 81,                   /*  固定资产变卖*/
  @vtFixedDepreciation  = 82,               /*  固定资产折旧*/
  @vtExpenseHappen  		= 83,               /*  待摊费用发生*/
  @vtExpenseAmortize  	= 84,               /*  待摊费用摊销*/

  @vtAccount  				  = 90,               /*  会计凭证*/

  @vtSendGoods  				= 100,              /*  发货单*/
  @vtSendBack  				  = 101,              /*  发货退货单*/
  @vtSendSettle  				= 102,              /*  发货结算单*/
  @vtSendPrice  				= 103,              /*  发货调价单*/

  @vtCommission  				= 110,              /*  委托代销单*/
  @vtCommBack  				  = 111,              /*  委托代销退货单*/
  @vtCommSettle  				= 112,              /*  委托代销结算单*/
  @vtCommPrice  				= 113,              /*  委托代销调价*/

  @vtReCommission  			= 120,              /*  受托代销单*/
  @vtReCommBack  				= 121,              /*  受托代销退货单*/
  @vtReCommSettle  			= 122,              /*  受托代销结算单*/
  @vtReCommPrice  			= 123,              /*  受托代销调价*/

  @vtCommRecive  				= 130,              /*  库外入库单*/
  @vtCommPayment  			= 131,               /*  库外出库单*/
  @vtVipIntegralExChange                = 149           /* 会员卡积分兑换单*/

	select  @SaleDiscount=account_id from account where class_id='000004000003000004'
	if @SaleDiscount is null goto error 

/*变量定义*/
	declare @nBillType smallint,@tBillDate datetime,@szBillNumber varchar(20),@nA_id int,@nC_id int,@nP_id int,@nE_id int,@nSs_id int,@nSd_id int,@nPrice_id int,@dDiscountPrice NUMERIC(25,8),@nSout_id int,@nUnitId int,@nOrderid int
	declare @nAuditMan int,@nInputMan int,@dYsMoney NUMERIC(25,8),@dSsMoney NUMERIC(25,8),@dQuantity NUMERIC(25,8),@dSalePrice NUMERIC(25,8),@dBuyPrice NUMERIC(25,8),@dCostPrice NUMERIC(25,8),@dCostTotal NUMERIC(25,8)
	declare @dDiscount numeric(3,2),@dTotalMoney NUMERIC(25,8),@dTaxPrice NUMERIC(25,8),@dTaxTotal NUMERIC(25,8),@dTaxMoney NUMERIC(25,8)
	declare @dRetailPrice NUMERIC(25,8),@dRetailTotal NUMERIC(25,8),@tMakeDate datetime,@tValidDate datetime,@nLocation_Id int,@nSupplier_Id int,@nLocation_id2 int
	declare @nCommissionflag tinyint,@szComment varchar(60),@szBatchNo varchar(30),@cCostMethod char(1),@nStoreType tinyint
        declare @RowGuid uniqueidentifier, @RowE_ID int
	declare @direction bit,@dJfTotal money,@dDfTotal money,@nPriceId int,@nInOutFlag smallint,@cUseSameCostMethod varchar(10),@nCostMethod varchar(1)
	declare @smb_id numeric(10,0),@dtotal NUMERIC(25,8),@dJsprice NUMERIC(25,8), @SendQTY NUMERIC(25,8), @SendCostTotal NUMERIC(25,8), @retailtotal NUMERIC(25,8)
	declare @cUseBuyPriceTrace smallint, @cUseSalePriceTrace smallint, @nPriceTrace smallint, @dPrice NUMERIC(25,8) /*lcb*/
        declare @OldCommissionflag int
	declare @y_id int
	declare @tInStoreTime DateTime, @Cxtype int, @retailPrice NUMERIC(25,8), @thQty NUMERIC(25,8)
	declare @batchbarcode varchar(80),@scomment varchar(80),@batchprice NUMERIC(25,8),@factoryid int,@taxrate NUMERIC(25,8),@costtaxrate NUMERIC(25,8),@costtaxprice NUMERIC(25,8),@costtaxtotal NUMERIC(25,8)
 	select @nBillType=0,@nA_id =0,@nC_id =0,@nP_id=0,@nE_id=0,@nSs_id =0,@nSd_id =0,@nPrice_id =0,@dDiscountPrice =0,
	@dYsMoney=0,@nAuditMan =0,@nInputMan=0,@dYsMoney =0,@dSsMoney =0,@dQuantity =0,@dSalePrice=0,@dBuyPrice =0,@dCostPrice =0,@taxrate=0,@factoryid=0,
	@dDiscount =1,@dTotalMoney =0,@dTaxPrice =0,@dTaxTotal =0,@dTaxMoney =0,@dRetailPrice =0,@dRetailTotal =0,@nLocation_Id=0,@nSupplier_Id=0,
	@nCommissionflag=0,@szComment='',@szBatchNo='',@cCostMethod='0',@nStoreType=0, @RowE_ID = 0,
	@direction=0,@dJfTotal=0,@dDfTotal=0,@dCostTotal=0,@y_id=0
	declare @cSpecifySubgroup char(1) /*仓库是否绑定分支机构*/
	
	/*45, 152单据使用*/
	declare @dUnitRate numeric(18,6)

	/*-----成本核算------------*/
	declare @SINGLE    	char(1) /*个别记价*/
	select 	@SINGLE     ='3'
	/*-------------------*/

  /*--------得到成本核算法*/
	exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
	if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
		exec ts_getsysvalue 'CostMethod',@nCostMethod out
    
    set @cSpecifySubgroup=0
    exec ts_getsysvalue 'SpecifySubgroup',@cSpecifySubgroup out /*仓库是否绑定分支机构，如果绑定了，同价调拨要重读y_id*/


	declare @dDoubleZero NUMERIC(25,8)
	set @dDoubleZero=0.001

/*变量定义end*/

/*取表头信息*/
	select @nBillType=BillType,@tBillDate=BillDate,@nA_id=a_id,@nC_id=c_id,@nE_id=e_id,@nSout_id=sout_id,
	@dYsMoney=ysmoney,@dSsMoney=SsMoney,@y_id=y_id from BillIdx where billid=@nBillId
	
	
/*lcb begin*/
	SET @cUseBuyPriceTrace=0
	SET @cUseSalePriceTrace=0
	SET @nPriceTrace=0

	if @nBillType in (@vtBuy,@vtReCommSettle)
	exec ts_getsysvalue 'UseBuyTrace',@cUseBuyPriceTrace out 
	else
	if @nBillType in (@vtSale,@vtSaleAccount,@vtCommSettle,@vtTranOut)
	exec ts_getsysvalue 'UseSaleTrace',@cUseSalePriceTrace out 

	if (@cUseBuyPriceTrace=1) or(@cUseSalePriceTrace=1) exec ts_getsysvalue 'PriceTrace',@nPriceTrace out 
/*lcb end*/
	/*----仓库类型-------------*/
	/*库存余量库类型 0:Normal 1:代销 2:借进借出*/
	select @nStoreType=0
	if @nBilltype in (@vtCommission,@vtCommBack,@vtCommSettle,@vtCommPrice,@vtReCommission,@vtReCommBack,
  @vtReCommSettle,@vtReCommPrice)
    select @nStoreType=1
	if @nBilltype in (@vtLend,@vtLendBack,@vtLendSale,@vtBorrow,@vtBorrowBack,@vtBorrowBuy)
    select @nStoreType=2
	/*-------------------------*/

	declare @aoid	int,
          @businesstype int,
          @Give_NoCost int,/**/
          @Give_Cost   int, /*辅助业务标示*/
          @Sale_NoCost int

	select @Give_NoCost=6,/*无成本赠送*/
         @Give_Cost=7,   /*有成本赠送*/
				 @Sale_NoCost=5  /*零成本转销售*/



	/*------------------------------销售出库单,零售,销售单,发货单,机构发货单------------------------------*/
	if @nBilltype in (@vtSale,@vtRetail,@vtSaleAccount,@vtSend,@vtYSend, @vtSaleDirectSend, @vtSaleDirectMid) 
	begin
		declare crSaleManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id, a.saleprice,a.jsprice,a.aoid, a.RowGuid, a.RowE_id,a.SendQTY, a.SendCostTotal, a.retailtotal,a.InStoreTime,a.thqty,a.cxtype, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,costtaxtotal
		from salemanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id and a.p_id>0
		order by a.smb_id
		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal,@tInStoreTime,@thQty, @cxType, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			if @aoid <> 8 and @nBilltype<>@vtSaleAccount /*--财务销售单不产生productDetail*/
            begin
				/*出库反号*/
				select @dQuantity		=-@dQuantity
				select @dTotalMoney	=-@dTotalMoney
				select @dTaxTotal		=-@dTaxTotal
	            select @SendQty		 =-@SendQty
                select @SendCostTotal		=-@SendCostTotal 
	            select @retailtotal     =-@retailtotal
	            select @costtaxtotal    =-@costtaxtotal

				if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
/*			--if @cCostmethod<>@SINGLE select @dCostPrice=0*/

				if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
					select @nStoreType=3	/*库外库，商品成本为零*/
				else				
					select @nStoreType=0	/*正常库*/
			
				if @RowGuid is null  SET @RowGuid = newid()

				insert into productdetailtmp      
		 		([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, cxType, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)
				values
				(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @Cxtype, @retailPrice, @thQty,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)

				if @@rowcount=0 goto errorsale
		    end

		    if @aoid=0 and @nBillType in (@vtSale,@vtCommSettle,@vtTranOut,@vtSaleAccount) and @cUseSalePriceTrace=1 and (@nPriceTrace=1 or @nBillType=@vtSaleAccount)
				exec ts_c_SaleBuyPriceTrace;1 'S',@smb_id
		    if @aoid=0 and @nBillType = @vtYSend exec ts_c_SaleBuyPriceTrace;1 'Y',@smb_id  	

		    fetch next from crsalemanager
		    into @np_id,@szbatchno,@dquantity,@dcostprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,@nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@norderid,@szComment,
		      @npriceid,@ncommissionflag,@ccostmethod,@smb_id, @dPrice,@dJsprice,@aoid,@RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal ,@tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager

		delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------销售出库单,零售,销售单,发货单----------------------------------------*/


	/*------------------------------销售出库退货单,零售退货, 机构发货退货单------------------------------*/
	if @nBilltype in (@vtSaleBack,@vtRetailBack,@vtYSendBack, @vtYSelfSendBack) 
	begin
		declare crSaleManager cursor for 

		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
	    	a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.jsprice,a.aoid, a.RowGuid, a.RowE_id, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.cxType, a.retailprice,a.y_id,
	    	a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from salemanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id and a.p_id>0
		order by a.smb_id
		
		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@aoid, @RowGuid, @RowE_id, @SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/
			if @RowGuid is null SET @RowGuid = newid()

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],[price_id],unitid,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nPriceid,@nUnitid,@smb_id,@szComment,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorsale

		      fetch next from crSaleManager
		      into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@aoid, @RowGuid, @RowE_id, @SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager
/*---------   张海修改，多账户处理移动到ts_c_createADetail*/
		/*
		if exists(select * from salemanagebilltmp where bill_id=@nbillid and p_id<0)
		begin
			insert into accountdetail 
		 	([billid],[a_id],[c_id],jdmoney)			
			select 
			@nBillId,abs(P_id),@nC_id,-total from salemanagebill where bill_id=@nbillid and p_id<0 order by smb_id
			if @@rowcount=0 goto errorsale
		end  */
		delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------销售出库退货单,零售退货--------------------------------*/

	/*------------------------------委托代销发货-------------------------------------*/
	if @nBilltype in (@vtCommission) 
	begin
		declare crSaleManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.Unitid,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.cxType, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from salemanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			select @OldCommissionflag=@nCommissionFlag

			insert into productdetailtmp
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,oldcommissionflag,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dDiscountPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionflag,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@dJsprice,@OldCommissionflag,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id,@tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,-@costtaxtotal)
			if @@rowcount=0 goto errorsale

			insert into productdetailtmp
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,OldCommissionflag,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,0,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,1,@nSupplier_id,0,@nStoreType,@nUnitid,0,@szComment,@dJsprice,@OldCommissionflag,@SendQTY, @SendCostTotal, @retailtotal, @y_id,@tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)
			if @@rowcount=0 goto errorsale


		      fetch next from crSaleManager
		      into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager
    delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------委托代销发货--------------------------*/

	/*------------------------------委托代销退货-------------------------------------*/
	if @nBilltype in (@vtCommBack) 
	begin
		declare crSaleManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.cxType, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from salemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			set @oldcommissionflag=0      
			if @cCostmethod=@SINGLE /*取得原商品属性*/
			begin
				select @OldCommissionflag=isnull(OldCommissionFlag,0) from storedx 
				where p_id=@nP_Id and c_id=@nC_id and  abs(costprice-@dCostPrice)<=@dDoubleZero and batchno=@szBatchNo and supplier_id=@nSupplier_id and commissionflag=@nCommissionflag
				and validdate=@tValidDate and makedate=@tMakeDate and quantity>=@dQuantity and InStoreTime=@tInStoreTime and factoryid=@factoryid
			end

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,oldcommissionflag,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,-@dQuantity,@dDiscountPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,1,@nSupplier_id,0,@nStoreType,@nUnitid,0,@szComment,@dJsprice,@oldcommissionflag,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorsale

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,Oldcommissionflag,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)	
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,0,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@OldCommissionflag,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@dJsprice,@OldCommissionflag,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)
			if @@rowcount=0 goto errorsale

		      fetch next from crsalemanager
		      into @np_id,@szbatchno,@dquantity,@dcostprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,@nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@szcomment,
		      @npriceid,@ncommissionflag,@ccostmethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager
    delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------委托代销退货----------------------------*/


	/*------------------------------委托代销结算---------------------------*/
	if @nBilltype in (@vtCommSettle)
	begin
		declare crSaleManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
		a.Price_id,a.commissionflag,b.costmethod,a.smb_id, a.saleprice,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime,a.thQty, a.cxType, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from salemanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,@thQty, @cxType, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
		    select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 
            select @costtaxtotal    =-@costtaxtotal	

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			  set @oldcommissionflag=0      
			  if @cCostmethod=@SINGLE /*取得原商品属性*/
			  begin
				select @OldCommissionflag=isnull(OldCommissionFlag,0) from storedx 
				where p_id=@nP_Id and c_id=@nC_id and  abs(costprice-@dCostPrice)<=@dDoubleZero and batchno=@szBatchNo and supplier_id=@nSupplier_id and commissionflag=@nCommissionflag
				and validdate=@tValidDate and makedate=@tMakeDate and quantity>=@dQuantity and InStoreTime=@tInStoreTime and factoryid=@factoryid
			  end

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,oldcommissionflag,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,1,@nSupplier_id,0,@nStoreType,@nUnitId,@smb_id,@szComment,@dJsprice,@oldcommissionflag,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @cxType, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorsale

			if @nBillType in (@vtSale,@vtCommSettle,@vtTranOut)and @cUseSalePriceTrace=1 and @nPriceTrace=1
				exec ts_c_SaleBuyPriceTrace;1 'S',@smb_id

		      fetch next from crSaleManager
		      into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @cxType, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager
    delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------委托代销结算------------------------------*/


	/*------------------------------采购入库单,采购单,收货单,机构收货单------------------------------*/
	if @nBilltype in (@vtBuy,@vtBuyAccount,@vtReceive,@vtYReceive,@vtYSelfReceive, @vtBuyDirectGet, @vtBuyDirectMid)
	begin
		declare crBuyManager cursor for   
		select a.p_id,a.batchno,a.quantity,a.buyprice,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
		a.price_id,a.commissionflag,b.costmethod,a.smb_id, a.buyprice,a.jsprice,a.aoid, a.RowGuid, a.RowE_id, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id and a.p_id>0
		order by a.smb_id
		
		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dCostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal,@tInStoreTime, @thQty, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
            if @nBilltype<>@vtBuyAccount    /*财务采购单不产生productDetail*/
             begin
				if @aoid=@Give_NoCost
					select @nStoreType=3	/*库外库，商品成本为零*/
				else				
					select @nStoreType=0	/*正常库*/
							if @RowGuid is null set @RowGuid = newid() 

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

				insert into productdetailtmp 
		 		([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
				values
				(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostprice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
				if @@rowcount=0 goto errorbuy
			end

			if @aoid=0 and @nBillType in (@vtBuy,@vtReCommSettle) and @cUseBuyPriceTrace=1 and @nPriceTrace=1
			exec ts_c_SaleBuyPriceTrace;1 'B',@smb_id
	
			fetch next from crBuyManager
			into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dCostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
			     @nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			     @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
		delete from buymanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------采购入库单,采购单,收货单------------------------------*/



	/*------------------------------采购退货,机构收货退货单------------------------------*/
	if @nBilltype in (@vtBuyBack,@vtYReceiveBack, @vtYSelfReceiveBack)
	begin
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.buyprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.price_id,a.commissionflag,b.costmethod,a.smb_id,a.jsprice,a.aoid, a.RowGuid, a.RowE_id, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id and a.p_id>0
		order by a.smb_id
		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 
	        select @retailtotal      =-@retailtotal
	        select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			if @RowGuid is null set @RowGuid = newid()

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@szComment,@dJsprice,@aoid, @RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
			fetch next from crBuyManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
	    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@aoid,@RowGuid, @RowE_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
	    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
    delete from buymanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*------------------------------采购退货------------------------------*/

	/*----------------------------受托代销收货单--------------------------*/
	if @nBilltype in (@vtReCommission)
	begin
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.buyprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.price_id,a.commissionflag,b.costmethod,a.smb_id, a.buyprice,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin   

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,2,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)
			if @@rowcount=0 goto errorbuy

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,2,@nSupplier_id,0,@nStoreType,@nUnitid,0, @szComment,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
			if @nBillType in (@vtBuy,@vtReCommSettle) and @cUseBuyPriceTrace=1 and @nPriceTrace=1
				exec ts_c_SaleBuyPriceTrace;1 'B',@smb_id

		      fetch next from crbuymanager
		      into @np_id,@szbatchno,@dquantity,@dbuyprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,@nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@szComment,
		      @npriceid,@ncommissionflag,@ccostmethod,@smb_id, @dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
    delete from buymanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------受托代销收货单--------------------------*/

	/*----------------------------受托代销退货单--------------------------*/
	if @nBilltype in (@vtReCommBack)
	begin
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.discountprice,a.costprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.price_id,a.commissionflag,b.costmethod,a.smb_id,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@ddiscountprice,@dcostprice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 	
            select @retailtotal      =-@retailtotal 
            select @costtaxtotal    =-@costtaxtotal                      
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@ddiscountprice,@dTotalMoney,@dCostprice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,2,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostprice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,2,@nSupplier_id,0,@nStoreType,@nUnitid,0,@szComment,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @y_id,@tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
			fetch next from crBuyManager
			into @nP_id,@szBatchNo,@dQuantity,@ddiscountprice,@dcostprice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@szComment,
	    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
	    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
    delete from buymanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------受托代销退货单--------------------------*/

	/*----------------------------受托代销结算单--------------------------*/
	if @nBilltype in (@vtReCommSettle)
	begin
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.price_id,a.commissionflag,b.costmethod,a.smb_id, a.buyprice,a.jsprice, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.taxrate,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dcostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id ,@dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 	             
            select @retailtotal      =@retailtotal           
            select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			
			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,jsprice,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,2,@nSupplier_id,0,@nStoreType,@nUnitId,@smb_id,@szComment,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
			if @nBillType in (@vtBuy,@vtReCommSettle) and @cUseBuyPriceTrace=1 and @nPriceTrace=1
				exec ts_c_SaleBuyPriceTrace;1 'B',@smb_id

		      fetch next from crBuyManager
		      into @nP_id,@szBatchNo,@dQuantity,@dcostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id, @dPrice,@dJsprice,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@taxrate,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
    delete from buymanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------受托代销结算单--------------------------*/

	/*----------------------------报损单----------------------------------*/
	if @nBilltype in (@vtLost,@vtCleanPack)/*还有清斗单*/
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.costtotal,a.makedate,a.validdate,
		a.price_id,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.Unitid,a.smb_id,a.comment,a.aoid, 
		a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@dCostTotal,@tMakeDate,@tValidDate,
		@nPriceid,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,@szComment,@aoid,
		@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 	
            select @retailtotal      =-@retailtotal
            select @costtaxtotal    =-@costtaxtotal
			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
/*			--if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],[price_id],unitid,smb_id,comment,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values                             /*以前价格等值默认为0，LK修改*/
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dbuyPrice,@dTotalMoney,@dCostPrice,@dCostTotal,@dbuyPrice,@dTotalMoney,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nPriceid,@nUnitid,@smb_id,@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@dCostTotal,@tMakeDate,@tValidDate,
			@nPriceid,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,@szComment,@aoid,
			@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------报损单----------------------------------*/

	/*----------------------------报溢单----------------------------------*/
	if @nBilltype in (@vtOverflow)
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.costtotal,a.price,a.totalmoney,a.makedate,a.validdate,
		a.price_id,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.unitid,a.smb_id,a.comment,a.aoid, 
		a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dCostTotal,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nPriceid,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,@szComment,@aoid,
		@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)
			values                              /*以前价格等值默认为0, LK修改*/
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dCostPrice,@dCostTotal,@dBuyPrice,@dTotalMoney,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)
			if @@rowcount=0 goto errorstore 
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dCostTotal,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nPriceid,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,@szComment,@aoid,
			@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------报溢单----------------------------------*/

	
	/*----------------------------成本调价单------------------------------*/
	if @nBilltype in (@vtAdjustPrice)
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.unitid,a.smb_id, 
		a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
		@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dBuyPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dBuyPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,-@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@dBuyPrice * (1 + @costtaxrate),@costtaxrate,@dTotalMoney * (1 + @costtaxrate))
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
			@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
		delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------成本调价单------------------------------*/
	
	
	/*----------------------------同价调拨单------------------------------*/
	if @nBilltype=@vtTransfer
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.orgbillid,a.aoid, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,order_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@nOrderid,@aoid,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore
            
            
			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSd_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSd_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id2,@nStoreType,@nUnitid,-@smb_id,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------同价调拨单------------------------------*/


	/*----------------------------变价调拨单------------------------------*/
	if @nBilltype=@vtTransfer_Price
	begin
		

		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.orgbillid,a.aoid, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			select @dUnitRate=case 
				when @nUnitid=unit2_id then rate2 
				when @nUnitid=unit3_id then rate3 
				when @nUnitid=unit4_id then rate4
				else 1
				end from products where product_id=@np_id 

			if @dUnitRate is null or @dUnitRate=0 set @dUnitRate=1
					       	
			 

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,order_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id,InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@nOrderid,@aoid,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore

            
			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @y_id=y_id from storages where storage_id=@nSd_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSd_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dBuyPrice/@dUnitRate,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id2,@nStoreType,@nUnitid,-@smb_id,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------变价调拨单------------------------------*/
	
	/*----------------------------自营店发货单------------------------------*/
	if @nBilltype=@vtYSelfSend
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.saleprice,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.location_id2,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.orgbillid,a.aoid, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal, a.RowE_id, a.taxprice, a.taxtotal
		from salemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nLocation_id2, @nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal, @RowE_ID, @dTaxPrice, @dTaxTotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			select @dUnitRate=case 
				when @nUnitid=unit2_id then rate2 
				when @nUnitid=unit3_id then rate3 
				when @nUnitid=unit4_id then rate4
				else 1
				end from products where product_id=@np_id 

			if @dUnitRate is null or @dUnitRate=0 set @dUnitRate=1
					       	
			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,order_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id,InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal, ROWE_id)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@costtaxprice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@nOrderid,@aoid,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal, @RowE_ID)			
			if @@rowcount=0 goto errorstore
            /*xzdong-2016-10-12-TFS-ZD41512-自营店发货单过账时在storehouse表中不插入152类型的记录*/
            if exists(select 1 from company where posdatamode=0 and company_id=(select y_id from storages where storage_id=@nSd_id and deleted=0))
            begin

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
				select @nC_id=y_id from storages where storage_id=@nSd_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal, ROWE_id)			
			values
			(@nBillId,@nP_id,@nSd_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dBuyPrice/@dUnitRate,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id2,@nStoreType,@nUnitid,-@smb_id,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @nC_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@dtaxprice,@costtaxrate,@dTaxTotal, @RowE_ID)			
			if @@rowcount=0 goto errorstore
			end
			if @aoid=0 exec ts_c_SaleBuyPriceTrace;1 'Y',@smb_id 
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nLocation_id2,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@nOrderid,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal,@RowE_ID, @dTaxPrice, @dTaxTotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from salemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------自营店发货单------------------------------*/
	
	
	/*----------------------------拆装单----------------------------------*/
	if @nBilltype in (@vtScattered, @vtProduce)
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.iotag,a.unitid,a.smb_id,
		a.location_id2, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nInOutFlag,@nUnitid,@smb_id,
		@nLocation_id2,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			if @nInOutFlag=0/*出库*/
			begin
				insert into productdetailtmp 
			 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
				values
				(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dDiscountPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)
				if @@rowcount=0 goto errorstore
			end else
			begin
				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSd_id and deleted=0
			
				insert into productdetailtmp 
			 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
				values
				(@nBillId,@nP_id,@nSd_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dBuyPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id2,@nStoreType,@nUnitid,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
				if @@rowcount=0 goto errorstore
			end
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nInOutFlag,@nUnitid,@smb_id,
			@nLocation_id2,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------拆装单----------------------------------*/

	/*----------------------------库存批次调整单----------------------------------*/
	if @nBilltype=@vtBatchAdjust
	begin
    declare @n1 int,@n2 int
    set @n1=0
    set @n2=0
		
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.iotag,a.unitid,a.smb_id,
		a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nInOutFlag,@nUnitid,@smb_id,
		@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			if @nInOutFlag=0/*出库*/
			begin
				insert into productdetailtmp 
			 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)
				values
				(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dDiscountPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
				if @@rowcount=0 goto errorstore
				set @n1=@n1+1
			end else
			begin
				insert into productdetailtmp 
			 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
				values
				(@nBillId,@nP_id,@nSs_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dCostPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)
				if @@rowcount=0 goto errorstore
				set @n2=@n2+1
			end
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nInOutFlag,@nUnitid,@smb_id,
			@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,@thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 

		if @n1<>@n2 goto errorstore

		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------库存批次调整单----------------------------------*/

	
	/*----------------------------入库单----------------------------------*/
	if @nBilltype=@vtInLib
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.unitid,a.smb_id,
		a.comment,a.aoid, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
		@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dBuyPrice,@dTotalMoney,@dCostPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)	
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
			@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------入库单----------------------------------*/
	
	/*----------------------------出库单----------------------------------*/
	if @nBilltype=@vtOutLib
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.unitid,a.smb_id,
		a.comment,a.aoid, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.thQty, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
		@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,aoid,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dDiscountPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@szComment,@aoid,-@SendQTY, -@SendCostTotal, -@retailtotal, @y_id, @tInStoreTime, @thQty, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore

			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nUnitid,@smb_id,
			@szComment,@aoid,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @thQty, @retailprice,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------出库单----------------------------------*/

	/*----------------------------库存盘点单------------------------------*/
	if @nBilltype=@vtGoodsCheck
	begin 
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.buyprice,a.costprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.taxmoney,a.unitid,a.price_id,a.commissionflag,b.costmethod,a.smb_id,
		a.aoid, a.InStoreTime, a.retailprice,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from GoodsCheckbill a,products b where a.bill_id=@nbillid and a.p_id=b.product_id and a.taxmoney<>0
		order by a.smb_id
		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dcostprice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@dTaxMoney,@nUnitid,@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,
		@aoid, @tInStoreTime, @retailprice,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
		    /*zjx-2017-06-12--48580--处理盘点单含税成本金额写入到productdetail表中错误*/
            set @costtaxtotal=(@dTaxMoney*@costtaxprice)
			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,aoid, y_id, InStoreTime, retailprice,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dTaxMoney,@dBuyPrice,@dTotalMoney,@dcostprice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitid,@smb_id,@aoid, @y_id, @tInStoreTime, @retailprice,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
		      fetch next from crBuyManager
					into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dcostprice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,
					@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@dTaxMoney,@nUnitid, @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,
					@aoid, @tInStoreTime, @retailprice,@y_id,
					@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
		return 0
	end
	/*----------------------------库存盘点单-----------------------------*/

	/*----------------------------总部配送出库单-----------------------------*/
  	if @nBilltype=@vtTranOut 		
	begin
		declare crTranManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,a.Price_id,a.commissionflag,b.costmethod,a.smb_id,
		a.SalePrice,a.aoid, a.InStoreTime, a.retailprice, a.thqty,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Tranmanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crTranManager
		fetch next from crTranManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,
		@dPrice,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney		=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal	
            select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
/*			--if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,aoid,y_id, InStoreTime, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@aoid,@y_id, @tInStoreTime, @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errortran

			if @aoid=0 and @nBillType in (@vtSale,@vtCommSettle,@vtTranOut)and @cUseSalePriceTrace=1 and @nPriceTrace=1
				exec ts_c_SaleBuyPriceTrace;1 'S',@smb_id

		      fetch next from crTranManager
		      into @np_id,@szbatchno,@dquantity,@dcostprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,
		      @nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@norderid,@szComment,@npriceid,@ncommissionflag,@ccostmethod,@smb_id,
		      @dPrice,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crTranManager
		deallocate crTranManager
    delete from Tranmanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------总部配送出库单-----------------------------*/

	/*----------------------------总部配送退货单-----------------------------*/
  	if @nBilltype=@vtTranOutBack 		
	begin
		declare crTranManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.aoid, a.InStoreTime, a.retailprice, a.thqty,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Tranmanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crTranManager
		fetch next from crTranManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],[price_id],unitid,smb_id,comment,aoid,y_id, InStoreTime, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nPriceid,@nUnitid,@smb_id,@szComment,@aoid,@y_id, @tInStoreTime, @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errortran

		      fetch next from crTranManager
		      into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitid,@nOrderid,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crTranManager
		deallocate crTranManager
		delete from Tranmanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------总部配送退货单-----------------------------*/

	/*----------------------------门店配送入库单-----------------------------*/
  	if @nBilltype=@vtTranIn 		
	begin
		declare crTranManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.aoid, a.InStoreTime, a.retailprice, a.thqty,a.y_id,
    		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Tranmanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crTranManager
		fetch next from crTranManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,aoid,y_id, InStoreTime, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@aoid,@y_id, @tInStoreTime, @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errortran
	
		      fetch next from crTranManager
		      into @nP_id,@szBatchNo,@dQuantity,@dBuyPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@aoid, @tInStoreTime, @retailprice, @thqty,@y_id,
		      @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crTranManager
		deallocate crTranManager
    delete from Tranmanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------门店配送入库单-----------------------------*/


	/*----------------------------门店配送退货单-----------------------------*/
  	if @nBilltype=@vtTranInBack 		
	begin
		declare crTranManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
    	a.Price_id,a.commissionflag,b.costmethod,a.smb_id,a.aoid, a.InStoreTime,a.y_id,
    	a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Tranmanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crTranManager
		fetch next from crTranManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@aoid, @tInStoreTime,@y_id,
    		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney		=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal	
            select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
/*			--if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			if @aoid=@Give_NoCost
				select @nStoreType=3	/*库外库，商品成本为零*/
			else				
				select @nStoreType=0	/*正常库*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,aoid,y_id, InStoreTime,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@aoid,@y_id, @tInStoreTime,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errortran

  		    fetch next from crTranManager
			into @np_id,@szbatchno,@dquantity,@dcostprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,@nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@norderid,@szComment,
			@npriceid,@ncommissionflag,@ccostmethod,@smb_id,@aoid, @tInStoreTime,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crTranManager
		deallocate crTranManager
		delete from Tranmanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------门店配送退货单-----------------------------*/


	/*----------------------------借出单-----------------------------*/
  	if @nBilltype=@vtLend  
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.retailprice, a.thqty,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,3,@nSupplier_id,0,@nStoreType,@nUnitid,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
		delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------借出单-----------------------------*/


	/*----------------------------借出还回单-----------------------------*/
  	if @nBilltype=@vtLendBack  	/*= 31;                   //  借出还回单*/
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime,a.retailprice, a.thqty,a.y_id,a.factoryid,
		a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
		@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,3,@nSupplier_id,0,@nStoreType,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,0,@nSupplier_id,@nLocation_id,0,@nUnitid, 0, @szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
			@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------借出还回单-----------------------------*/


	/*----------------------------借出转销售单-----------------------------*/
  	if @nBilltype=@vtLendSale  	/*= 32;                   //  借出转销售单*/
	begin
		declare crSaleManager cursor for
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.order_id,a.comment,
    		a.Price_id,a.commissionflag,b.costmethod,a.smb_id, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime, a.cxtype,
    	    a.retailprice, a.thqty,a.y_id,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from salemanagebilltmp a,products b 
		where a.bill_id=@nbillid and a.p_id=b.product_id 
		order by a.smb_id

		open crSaleManager
		fetch next from crSaleManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@nOrderid,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @cxtype, @retailprice, 
    		@thqty,@y_id,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 	
            select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
/*			--if @cCostmethod<>@SINGLE select @dCostPrice=0*/
			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,order_id,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, cxtype, retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,3,@nSupplier_id,0,@nStoreType,@nUnitId,@nOrderid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @cxtype, @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorsale


		      fetch next from crsalemanager
		      into @np_id,@szbatchno,@dquantity,@dcostprice,@ddiscountprice,@dtotalmoney,@dtaxprice,@dtaxtotal,@tmakedate,@tvaliddate,@nss_id,@nsd_id,@nlocation_id,@nsupplier_id,@nunitid,@norderid,@szComment,
		      @npriceid,@ncommissionflag,@ccostmethod,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,
		      @cxtype, @retailprice, @thqty,@y_id,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
		close crSaleManager
		deallocate crSaleManager
    delete from salemanagebilltmp where bill_id=@nbillid

		return 0
	end
	/*----------------------------借出转销售单-----------------------------*/


	/*----------------------------借进单-----------------------------*/
  	if @nBilltype=@vtBorrow  	/* 33;                    //  借进单*/
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.retailprice, a.thqty,a.y_id,a.factoryid
		,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
		@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,4,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,4,@nSupplier_id,0,@nStoreType,@nUnitid,0,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime, @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
			@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
		delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------借进单-----------------------------*/


	/*----------------------------借进还出单-----------------------------*/
  	if @nBilltype=@vtBorrowBack  	/* 34;                    //  借进还出单*/
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment, a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime, a.retailprice, a.thqty,a.y_id,a.factoryid,
		a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
		@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 	
            select @costtaxtotal    =-@costtaxtotal
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSout_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,4,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,4,@nSupplier_id,0,@nStoreType,@nUnitid,0, @szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore
	
			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,  @retailprice, @thqty,@y_id,@factoryid,
			@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
		delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------借进还出单-----------------------------*/

	/*----------------------------借进转进货单-----------------------------*/
  	if @nBilltype=@vtBorrowBuy  	/*  借进转进货单*/
	begin
		declare crBuyManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.discountprice,a.totalmoney,a.taxprice,a.taxtotal,a.makedate,a.validdate,a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.unitid,a.comment,
    		a.price_id,a.commissionflag,b.costmethod,a.smb_id, a.SendQTY, a.SendCostTotal, a.retailtotal, a.InStoreTime,  a.retailprice, 
    		a.thqty,a.y_id,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from buymanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id

		open crBuyManager
		fetch next from crBuyManager
		into @nP_id,@szBatchNo,@dQuantity,@dcostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
    		@nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,  @retailprice, 
    		@thqty,@y_id,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin
			/*出库反号*/
			select @dQuantity		=-@dQuantity
			select @dTotalMoney	=-@dTotalMoney
			select @dTaxTotal		=-@dTaxTotal
			select @SendQty		 =-@SendQty
            select @SendCostTotal		=-@SendCostTotal 
            select @costtaxtotal    =-@costtaxtotal
	
			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetail 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nC_id,@dQuantity,@dDiscountPrice,@dTotalMoney,@dCostPrice,0,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,4,@nSupplier_id,0,@nStoreType,@nUnitId,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorbuy
	
		      fetch next from crBuyManager
		      into @nP_id,@szBatchNo,@dQuantity,@dcostprice,@dDiscountPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@tMakeDate,@tValidDate,@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nUnitId,@szComment,
		      @nPriceId,@nCommissionflag,@cCostMethod,@smb_id,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, 
		      @retailprice, @thqty,@y_id,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end
	
		close crBuyManager
		deallocate crBuyManager
		delete from buymanagebilltmp where bill_id=@nbillid
		return 0

	end
	/*----------------------------借进转进货单-----------------------------*/


	/*----------------------------赠送单-----------------------------*/
  	if @nBilltype=@vtGive  
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment,a.SendQTY, a.SendCostTotal, a.retailmoney, a.InStoreTime,  a.retailprice, a.thqty,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime, @retailprice, @thqty,@y_id,@factoryid,
		@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,-@dQuantity,@dCostPrice,-@dTotalMoney,@dCostPrice,0,@dTaxPrice,-@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)			
			if @@rowcount=0 goto errorstore


			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,  @retailprice, @thqty,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
    delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------赠送单-----------------------------*/


	/*----------------------------获赠单-----------------------------*/
  	if @nBilltype=@vtGain  
	begin
		declare crStoreManager cursor for 
		select a.p_id,a.batchno,a.quantity,a.costprice,a.price,a.totalmoney,a.makedate,a.validdate,
		a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,b.costmethod,a.location_id2,a.unitid,a.smb_id,
		a.comment, a.SendQTY, a.SendCostTotal, a.retailmoney, InStoreTime,  retailprice, thqty,a.y_id,
		a.batchbarcode,a.scomment,a.batchprice,a.factoryid,a.costtaxprice,a.costtaxrate,a.costtaxtotal
		from Storemanagebilltmp a,products b where a.bill_id=@nbillid and a.p_id=b.product_id
		order by a.smb_id
		
		open crStoreManager
		fetch next from crStoreManager
		into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
		@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
		@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,  @retailprice, @thqty,@y_id,
		@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		while @@fetch_status=0
		begin

			if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
				select @cCostMethod=@nCostmethod
			/*if @cCostmethod<>@SINGLE select @dCostPrice=0*/

				if @cSpecifySubgroup='0' /*仓库是否绑定分支机构，=0 绑定 如果绑定了，同价调拨要重读y_id */
					select @y_id=y_id from storages where storage_id=@nSs_id and deleted=0
			insert into productdetailtmp 
		 	([billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],unitid,smb_id,comment,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime,  retailprice, thqty,batchbarcode,scomment,batchprice,Factoryid,costtaxprice,costtaxrate,costtaxtotal)			
			values
			(@nBillId,@nP_id,@nSs_id,@dQuantity,@dCostPrice,@dTotalMoney,@dCostPrice,@dTotalMoney,@dTaxPrice,@dTaxTotal,@szBatchno,@tMakeDate,@tValidDate,@nCommissionFlag,@nSupplier_id,@nLocation_id,0,@nUnitid,@smb_id,@szComment,@SendQTY, @SendCostTotal, @retailtotal, @y_id, @tInStoreTime,  @retailprice, @thqty,@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal)			
			if @@rowcount=0 goto errorstore


			fetch next from crStoreManager
			into @nP_id,@szBatchNo,@dQuantity,@dCostPrice,@dBuyPrice,@dTotalMoney,@tMakeDate,@tValidDate,
			@nSs_id,@nSd_id,@nLocation_id,@nSupplier_id,@nCommissionflag,@cCostMethod,@nLocation_id2,@nUnitid,@smb_id,
			@szComment,@SendQTY, @SendCostTotal, @retailtotal, @tInStoreTime,@retailprice, @thqty,@y_id,
			@batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
		end 
	
		close crStoreManager
		deallocate crStoreManager
		delete from Storemanagebilltmp where bill_id=@nbillid
		return 0
	end
	/*----------------------------获赠单-----------------------------*/


 /*---------------------------会员卡积分兑换单BEGIN----------服装移植----------------------*/
 if @nBillType in (@vtVipIntegralExChange)
 begin
   declare @dIntegralMoney NUMERIC(25,8), @dIntegralTotal NUMERIC(25,8)
   select @nStoreType=0 /*正常库*/

   declare crIntegralEx Cursor for
   select P_id,u_id,s_id,quantity,Costprice,CostTotal,
	  IntegralMoney,IntegRalTotal,comment,IntegralMoney,IntegRalTotal,smb_id,
	  AOID,batchno,	makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal, InStoreTime,factoryid,
	  costtaxprice,costtaxrate,costtaxtotal
   from ExIntegRalManagebill where billid=@nbillid and quantity>0 and status=0
   order by smb_id

   open crIntegralEx
   fetch next from crIntegralEx
   into @nP_id,          @nUnitId,        @nSs_id,          @dQuantity,    @dCostPrice,  @dCostTotal,
        @dIntegralMoney, @dIntegralTotal,  @szComment,   @dSaleprice,   @dTotalmoney,  @smb_id,
        @aoid,@szbatchno,@tmakedate,@tvaliddate,@nlocation_id,@nsupplier_id,@ncommissionflag,@SendQTY, @SendCostTotal,
	@tInStoreTime,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
   while @@fetch_status=0
   begin
   /*XXX.2017-03-30  积分兑换单可选零成本赠品商品*/
   	if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
		select @nStoreType=3	/*库外库，商品成本为零*/
	else				
		select @nStoreType=0	/*正常库*/
		
     insert into productdetailtmp 
             (billid,       p_id,       s_id,      quantity,     price,       total,          Costprice,    CostTotal,    TaxPrice,
              TaxTotal,     storetype,  unitid,    smb_id,       comment,     AOID,batchno,	makedate,validdate,location_id,supplier_id,commissionflag,SendQTY, SendCostTotal, y_id, InStoreTime,Factoryid,costtaxprice,costtaxrate,costtaxtotal)
     values  (@nbillid,     @nP_id,     @nSs_id,   -@dQuantity,  @dSaleprice, -@dTotalmoney,  @dCostPrice,  -@dCostTotal,  @dSaleprice,
              -@dTotalmoney,@nStoreType,@nUnitId,  @smb_id,      @szComment,  @aoid,@szbatchno,@tmakedate,@tvaliddate,@nlocation_id,@nsupplier_id,@ncommissionflag,@SendQTY, @SendCostTotal, @y_id, @tInStoreTime,@factoryid,@costtaxprice,@costtaxrate,-@costtaxtotal)
     if @@rowcount=0 goto errorIntegralEx

    /* Select @pd_id = @@identity
     insert into productdetailTMP
             (pd_id,        billid,       p_id,       s_id,      quantity,     price,       total,          Costprice,    CostTotal, 
              TaxPrice,     TaxTotal,     storetype,  unitid ,   comment,      AOID)
     values  (@pd_id,       @nbillid,     @nP_id,     @nSs_id,   -@dQuantity,  @dSaleprice, -@dTotalmoney,  @dCostPrice,  -@dCostTotal,
              @dSaleprice,  -@dTotalmoney,@nStoreType,@nUnitId,   @szComment,  @AOID) 

     if @@rowcount=0 goto errorIntegralEx   *//*zhh屏蔽，不知作何用途*/

     fetch next from crIntegralEx
     into @nP_id,          @nUnitId,        @nSs_id,          @dQuantity,    @dCostPrice,@dCostTotal,
          @dIntegralMoney, @dIntegralTotal,  @szComment,   @dSaleprice,   @dTotalmoney,  @smb_id,
          @aoid,@szbatchno,@tmakedate,@tvaliddate,@nlocation_id,@nsupplier_id,@ncommissionflag,@SendQTY, @SendCostTotal, 
	  @tInStoreTime,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
   end
   close crIntegralEx
   deallocate crIntegralEx
   return 0
 end
 /*---------------------------会员卡积分兑换单END----------------------------------*/

success:
	return 0

errorsale:
	close crSaleManager
	deallocate crSaleManager
	return -1

errorbuy:
		close crBuyManager
		deallocate crBuyManager
		return -1
errorstore:
		close crStoreManager
		deallocate crStoreManager
		return -1
errortran:
		close crTranManager
		deallocate crTranManager
		return -1
errorIntegralEx:
		  close crIntegralEx
		  deallocate crIntegralEx
		  return -1
error:
	return -1
GO
