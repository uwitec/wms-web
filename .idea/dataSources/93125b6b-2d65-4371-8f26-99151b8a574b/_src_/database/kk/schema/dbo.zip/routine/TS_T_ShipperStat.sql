/******************************************
发货人做单数据量统计报表
*******************************************/
create  PROCEDURE TS_T_ShipperStat
(  @BeginDate  DATETIME=0,
   @EndDate    DATETIME=0,
   @E_id        int,/*varchar(30)='',*/
   @szlistflag   char(1)='',
   @parent_id   varchar(36)='000000'
)
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szlistflag is null  SET @szlistflag = ''
if @parent_id is null  SET @parent_id = '000000'
/*Params Ini end*/

if @E_id=''
begin
 if @szListFlag='L'  goto ListLeavel  /*分级显示*/
 if @szListFlag='A'  goto ListAll     /*全部列表*/
 if @szListFlag='P'  goto ListPart    /*部分列表 */
declare @ChildNumber  int,
        @sql varchar(1000)
ListLeavel: 
  select e.name as name,e.serial_number as serial_number,e.phone as phone,e.[address] as [address],e.[child_number] as child_number,e.[class_id] as class_id,
 (case when e.child_number<>0 then
  (select count(1) from billidx b,employees em 
      where billtype in (10,53,44,45,49,110,212,150)and billdate BETWEEN @BeginDate and @EndDate and b.e_id=em.emp_id and e.class_id=em.parent_id and billstates='0'
  )else (select count(1) from billidx b
      where   billtype in (10,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0' 
  )end) as billCount,
  (case when e.child_number<>0 then
   (select count(1) from billidx b,employees em
       where   billtype=21 and billdate BETWEEN @BeginDate and @EndDate  and b.e_id=em.emp_id and e.class_id=em.parent_id and billstates='0'
   )else (select count(1) from billidx b
       where  billtype=21 and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
   )end) as billthcount, 
   (case when e.child_number <>0 then
   (select count(1)  from salemanagebill sm, billidx b ,employees em
      where  b.billtype in (10,21,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and sm.bill_id=b.billid and sm.RowE_id=em.emp_id and e.class_id=em.parent_id and billstates='0' 
    )else (select count(1)  from salemanagebill sm, billidx b 
      where b.billtype in (10,21,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and sm.RowE_id=e.emp_id  and sm.bill_id=b.billid and billstates='0' 
    )end) as listcount
   from  employees e
  where e.deleted<>1 and e.parent_id like @parent_id 
return 0 
ListAll:
  select e.name as name,e.serial_number as serial_number,e.phone as phone,e.[address] as [address],e.[child_number] as child_number,e.[class_id] as class_id, 
  (select count(1) from billidx b where  billtype in (10,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
  ) as billCount,
  (select count(1) from billidx b
       where  billtype=21 and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
   ) as billthcount,
  (select count(1)  from salemanagebill sm, billidx b where b.billtype in (10,21,53,44,45,49,110,212,150)  and b.billdate BETWEEN @BeginDate and @EndDate and sm.RowE_id=e.emp_id  and sm.bill_id=b.billid and billstates='0' 
    )as listcount
   from  employees e where  e.deleted<>1 and e.child_number=0
return 0 
ListPart:
  select e.name as name,e.serial_number as serial_number,e.phone as phone,e.[address] as [address],e.[child_number] as child_number,e.[class_id] as class_id, 
   (select count(1) from billidx b where  billtype in (10,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
  ) as billCount,
  (select count(1) from billidx b
       where  billtype=21 and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
   ) as billthcount,
  (select count(1)  from salemanagebill sm, billidx b where b.billtype in (10,21,53,44,45,49,110,212,150)  and b.billdate BETWEEN @BeginDate and @EndDate and sm.RowE_id=e.emp_id  and sm.bill_id=b.billid and billstates='0' 
    )as listcount
   from  employees e where e.deleted<>1 and Parent_id like @parent_id and e.child_number=0 
return 0 
end else
begin
 select e.name as name,e.serial_number as serial_number,e.phone as phone,e.[address] as [address],e.[child_number] as child_number,e.[class_id] as class_id, 
   (select count(1) from billidx b where  billtype in (10,53,44,45,49,110,212,150) and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
  ) as billCount,
(select count(1) from billidx b
       where  billtype=21 and billdate BETWEEN @BeginDate and @EndDate and b.e_id=e.emp_id and billstates='0'
   ) as billthcount,
  (select count(1)  from salemanagebill sm, billidx b where b.billtype in (10,21,53,44,45,49,110,212,150)  and b.billdate BETWEEN @BeginDate and @EndDate and sm.RowE_id=e.emp_id  and sm.bill_id=b.billid and billstates='0' 
    )as listcount
   from  employees e where emp_id=@E_id and e.deleted<>1
 end
GO
