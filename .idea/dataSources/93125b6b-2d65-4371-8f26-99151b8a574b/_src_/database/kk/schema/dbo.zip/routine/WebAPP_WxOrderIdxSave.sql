




/*保存订单表头*/
/*
问题：
制单人如何确认？
在ERP系统中如何处是货到付款，还是其它支付方式？
订单中运费如何处理--运费这块还未处理
*/
CREATE PROCEDURE [WebAPP_WxOrderIdxSave]
(
    @BillID		int,
    @y_id		int,
    @billnumber varchar(20),
    @openid		varchar(50),
    @qty		numeric(18,2),
    @total		numeric(18,2),
    @aname		varchar(50),
    @express	varchar(50),         /*货运单位，*/
    @express_fee	numeric(18,2),   /*运费*/
    @phone_number	varchar(50),
    @contact_personal	varchar(50),
    @address	varchar(255),
    @wxid		int,/*对应微信后台生成的订单的ID，保存方便后面进行查询*/
    @RetMessage varchar(200) out
)

/*$Encode$--*/

AS
select @RetMessage='操作成功'

/*制单人*/
declare @inputman int
select @inputman=0
/*单据时间*/
declare @billdate datetime
select @billdate=convert(VARCHAR(10),getdate(),20)

declare @ssmoney numeric(18,2)
select @ssmoney=0

 declare @a_id int,@c_id int,@e_id int,@sout_id int,@sin_id int,@auditman int
 select @a_id=0,@c_id=0,@e_id=0,@sout_id=0,@sin_id=0,@auditman=0
 
 select @c_id = SysValue from sysconfig where sysname = 'ws_client'
 select @e_id = SysValue,@inputman=SysValue from sysconfig where sysname = 'ws_employee'
 select @sout_id  = SysValue ,@sin_id = SysValue from sysconfig where sysname  = 'ws_storage'

 
 
 declare @account_id int set @account_id = 0
 if @aname<>''
 begin
   select @account_id = account_id from account where [name]=@aname
 end
 if @account_id>0 set @a_id=-100
 declare @guid uniqueidentifier
 select @guid = NEWID() 
 
INSERT INTO ORDERIDX
  (
  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
  ysmoney  ,ssmoney  ,quantity , taxrate	,period  ,billstates,order_id,department_id,
  posid  ,region_id ,auditdate ,skdate  ,jsflag  ,summary ,jsye, 
  invoice,y_id,/*phone_number,contact_personal,[address],*/
  B_CustomName1,B_CustomName2,B_CustomName3,
  note,
  [guid],hytotal
  )
  VALUES
  (
  @billdate ,@billnumber,14,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,@inputman,
  @total  ,@ssmoney  ,@qty , 0  ,0	,'2',@wxid ,0,
  0  ,0 ,getdate() ,@billdate  ,''  ,'' ,@total,
  0,@y_id,
  @phone_number,@contact_personal,@address,
  'weixin',
  @guid , @express_fee)

  select @BillID=@@IDENTITY
  
  if @BillID>0
  begin 
    if @account_id>0 /*如果存在支付时，将科目写入 orderbill*/
    begin       
       insert into orderbill(bill_id,p_id,batchno,total)
       select @BillID,-@account_id,'',(@total+@express_fee)
    end  
     
    insert into onlineorderidx(billdate,express,express_fee,phone_number,contact_personal,dzhi,wxid,
                               order_billid,order_guid,order_billtype,orderdate)
    select @billdate,@express,@express_fee,@phone_number,@contact_personal,@address,@wxid,
                               @BillID,@guid,14,GETDATE()
  end
   

if @@error<>0 
begin
	select @RetMessage = '操作发生错误'
	select @RetMessage as outMsg,-1 as reCode
	return -1
end
else
begin
	select @RetMessage as outMsg,@BillID as reCode
	return @BillID
end
GO
