
CREATE			  proc Ts_b_LoadBillIndex
(
@nRET	int output,
@billtype  int,
@billid  int,
@nTableTag int
)
/*with encryption*/
AS

/*
  vtYSend = 150;                     //  机构发货单
  vtYSendBack = 151;                 //  机构发货退货单
  vtYGathering = 155;                //  机构收款单
  vtYReceive = 160;                  //  机构收货单
  vtYReceiveBack = 161;              //  机构收货退货单
  vtYPayment = 165;                  //  机构付款单
*/

SET NOCOUNT ON
SET @nRET = -1

declare @bStoragesmanage int
set @bStoragesmanage = 0
select @bStoragesmanage = sysvalue from sysconfigtmp where sysname = 'storagesmanage'

IF @nTableTag IN(500, 510)
BEGIN
	SELECT *, Gspbillid AS BILLID, 0 AS A_ID, '' AS A_NAME, InputMan AS E_ID, S_id AS SOUT_ID, S_id AS SIN_ID,
		AuditMan1 AS AUDITMAN, AUDITER1 AS AUDITER, TaxTotal as ysmoney, 0 as ssmoney, PartQty as quantity,
		0 as period, Ybillid as order_id, 0 as department_id, 0 as region_id, AuditTime1 as auditdate,
		'1900-1-1' as skdate, TaxTotal as jsye, '' as jsflag, '' as summary, '' as invoiceno, 0 as invoicetotal,
		0 as businesstype, 0 as araptotal, 0 as Gatheringman, '' as GatheringName, 0 as sendqty, 0 as vipcardid,
		'1900-1-1' as begindate, '1900-1-1' as enddate, GETDATE() as begintime, GETDATE() as endtime, '' as xq,
		Y_id as cury_id, 0 as sendc_id, 0 as wt_id, '' as cydw, '' as cyfs, '1900-1-1' as qytime, '1900-1-1' as ordervaliddate,
		0 as qualityaudit, '1900-1-1' as qualityauditdate, '' as qualityauditer, INPUTER as e_name, S_NAME as s_name2,
		'' as d_name, '' as z_name, '' as sendc_name, '' as wt_ename,'' AS DPDATE,FollowNumber,TicketDate,balancemode,0 as priority
	FROM VW_GSPBILLIDX
	WHERE Gspbillid = @billid
END
ELSE
IF @nTableTag in (0,1,2,3,6,8,34,35,22)
BEGIN
   IF @billtype not in(150,151,152,153,155,160,161,162,163,165,171,172,173,174)  
	SELECT	b.*,
	  isnull(a.a_name,'') AS a_name,
	  isnull(c.c_name,'') AS c_name,
	  isnull(e.e_name,'') AS inputer,
	  isnull(s.s_name,'') AS s_name,
	  isnull(d.d_name,'') AS d_name,
	  isnull(s2.s_name,'') AS s_name2,
	  isnull(e1.e_name,'') AS e_name,
	  isnull(e2.e_name,'') AS auditer,
	  ISNULL(e3.e_name,'') AS GatheringName,
	  '' as Z_NAME,
	  isnull(pos.posname,'')  as POS_NAME,
	  isnull(Y.Name,'') as Y_NAME ,
          getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,isnull(sc.c_name,'') AS sendc_name,B.WholeQty,B.PartQty,case when dpdate <'1900-01-01' then '1900-01-01' else dpdate end as dpdate, 
	  0 as WT_ID, '' AS WT_EName,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
	  ISNULL(e4.e_name,'') AS QualityAuditer, ISNULL(e5.e_name,'') AS financeAuditer,
	  QualityAudit as QualityAudit,  QualityAuditDate as QualityAuditDate , financeAudit as financeAudit,  financeAuditDate as financeAuditDate,
	  FollowNumber,TicketDate,0 as priority 
	FROM BillDraftidx b
	/*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, vw_b_dept d*/
	/*     ,vw_b_employee e1,vw_b_employee e2,vw_b_employee e3 ,vw_b_pos pos,Company Y --, vw_b_region z*/
	/*     ,vw_b_client sc*/
	inner join vw_b_employee e on b.inputman = e.e_id
	inner join vw_b_employee e1 on b.e_id = e1.e_id
	left  join vw_b_employee e2 on b.auditman = e2.e_id
	left  join vw_b_employee e3 on b.gatheringMan =e3.e_id
	left  join vw_b_employee e4 on b.qualityaudit =e4.e_id
	left  join vw_b_employee e5 on b.financeAudit =e5.e_id
	left  join vw_b_account a   on b.a_id = a.a_id
    left  join vw_b_client  c   on	b.c_id = c.c_id 
    left  join vw_b_storage s   on b.sout_id = s.s_id
    left  join vw_b_storage s2  on b.sin_id = s2.s_id
    left  join vw_b_dept d      on b.department_id = d.d_id
    left  join vw_b_pos pos     on b.PosID = pos.PosID
    left  join Company Y        on b.Y_ID = Y.Company_ID
    left  join vw_b_client sc   on b.sendc_ID = sc.c_ID
	WHERE b.billid = @billid
	/*
	AND b.inputman = e.e_id
	AND b.e_id = e1.e_id
	AND b.auditman *= e2.e_id
	AND b.gatheringMan *=e3.e_id
	AND b.a_id *= a.a_id
	AND b.c_id *= c.c_id
	AND b.sout_id *= s.s_id
	AND b.sin_id *= s2.s_id
	AND b.department_id *= d.d_id
	AND b.PosID *= pos.PosID
	AND b.Y_ID *= Y.Company_ID
	AND b.sendc_ID *= sc.c_ID
	*/
   ELSE
	SELECT	b.*,
	  isnull(a.a_name,'') AS a_name,
	  isnull(c.name,'') AS c_name,
	  isnull(e.e_name,'') AS inputer,
	  isnull(s.s_name,'') AS s_name,
	  isnull(d.d_name,'') AS d_name,
	  isnull(s2.s_name,'') AS s_name2,
	  isnull(e1.e_name,'') AS e_name,
	  isnull(e2.e_name,'') AS auditer,
	  ISNULL(e3.e_name,'') AS GatheringName,
	  '' as Z_NAME,
	  isnull(pos.posname,'')  as POS_NAME,
	  isnull(Y.Name,'') as Y_NAME ,
          getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,isnull(sc.c_name,'') AS sendc_name,B.WholeQty,B.PartQty,case when dpdate <'1900-01-01' then '1900-01-01' else dpdate end as dpdate, 
	  0 as WT_ID, '' AS WT_EName,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
	  ISNULL(e4.e_name,'') AS QualityAuditer, ISNULL(e5.e_name,'') AS financeAuditer,
	  QualityAudit as QualityAudit,  QualityAuditDate as QualityAuditDate , financeAudit as financeAudit,  financeAuditDate as financeAuditDate,
	  FollowNumber,TicketDate,0 as priority
	FROM BillDraftidx b
	/*, vw_b_account a, Company c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, vw_b_dept d,*/
	/*vw_b_employee e1,*/
	/*vw_b_employee e2,vw_b_employee e3 ,vw_b_pos pos --, vw_b_region z*/
	/*     ,Company Y,vw_b_client sc*/
	inner join vw_b_employee e  on     b.inputman = e.e_id
	inner join vw_b_employee e1 on     b.e_id = e1.e_id
	left  join vw_b_employee e2   on b.auditman = e2.e_id
	left  join vw_b_employee e3   on b.GatheringMan=e3.e_id
	left  join vw_b_employee e4 on b.qualityaudit =e4.e_id
	left  join vw_b_employee e5 on b.financeAudit =e5.e_id
	left  join vw_b_account a   on b.a_id = a.a_id
	left  join Company c        on b.c_id = c.company_id
	left  join vw_b_storage s   on b.sout_id = s.s_id
	left  join vw_b_storage s2   on b.sin_id = s2.s_id
	left  join vw_b_dept d   on b.department_id = d.d_id
	left  join vw_b_pos pos   on b.PosID = pos.PosID
	left  join Company Y   on b.Y_ID = Y.Company_ID
	left  join vw_b_client sc   on b.sendc_ID = sc.c_ID
	WHERE b.billid = @billid
	/*
	AND b.inputman = e.e_id
	AND b.e_id = e1.e_id
	AND b.auditman *= e2.e_id
	And b.GatheringMan*=e3.e_id
	AND b.a_id *= a.a_id
	AND b.c_id *= c.company_id
	AND b.sout_id *= s.s_id
	AND b.sin_id *= s2.s_id
	AND b.department_id *= d.d_id
	AND b.PosID *= pos.PosID
	AND b.Y_ID *= Y.Company_ID
	AND b.sendc_ID *= sc.c_ID
	*/
END
ELSE

IF @nTableTag in (4,14)
SELECT	b.TrafficCompany as CYDW, b.TrafficType as CYFS, case when SendTime<'1900-01-01' then '1900-01-01' else SendTime end as QYTime,b.*,0 as araptotal,
  isnull(a.a_name,'') AS a_name,
  isnull(c.c_name,'') AS c_name,
  isnull(sc.c_name,'') AS sendc_name,
  isnull(e.e_name,'') AS inputer,
  isnull(s.s_name,'') AS s_name,
  isnull(d.d_name,'') AS d_name,
  isnull(s2.s_name,'') AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  isnull(pos.posname,'')  as POS_NAME,
  0 as GatheringMan,0 as SendQTY,
  0 as vipcardid,
  isnull(Y.Name,'') as Y_NAME  ,
  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0,' ' as sendc_name,0 as WholeQty,0 as PartQty,
	  '' as GATHERINGName,
  ISNULL(wt.saleEName , '') AS WT_EName,  
  0 as QualityAudit,  '1900-01-01' as QualityAuditDate , 0 as financeAudit,  '1900-01-01' as financeAuditDate ,'' as QualityAuditer,'' as FinanceAuditer,
  '1900-1-1' as dpdate,'' as FollowNumber,'1900-01-01' as TicketDate,	
  B_CustomName1,B_CustomName2,B_CustomName3,b.balancemode,b.priority	
 FROM orderidx b
/*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, */
/*vw_b_dept d,vw_b_employee e1,vw_b_employee e2 ,vw_b_pos pos --, vw_b_region z*/
/*     ,Company Y*/
 inner join vw_b_employee e  on  b.inputman = e.e_id
 left  join vw_b_employee e1 on b.e_id = e1.e_id
 left  join vw_b_employee e2 on b.auditman = e2.e_id
 left  join vw_b_account a   on b.a_id = a.a_id
 left  join vw_b_client  c   on b.c_id = c.c_id
 left  join vw_b_client  sc   on b.SendC_ID = sc.c_id
 left  join vw_b_storage s   on b.sout_id = s.s_id
 left  join vw_b_storage s2  on b.sin_id = s2.s_id
 left  join vw_b_dept d      on b.department_id = d.d_id
 left  join vw_b_pos pos     on b.PosID = pos.PosID
 left  join Company Y        on b.Y_ID = Y.Company_ID
 left  join wtorder wt       on b.WT_ID = wt.WT_ID
 WHERE b.billid = @billid
/*
AND b.inputman = e.e_id
AND b.e_id *= e1.e_id
AND b.auditman *= e2.e_id
AND b.a_id *= a.a_id
AND b.c_id *= c.c_id
AND b.sout_id *= s.s_id
AND b.sin_id *= s2.s_id
AND b.department_id *= d.d_id
AND b.PosID *= pos.PosID
AND b.Y_ID *= Y.Company_ID
*/

ELSE

IF @nTableTag in (5,25,40,50)
SELECT	b.*,
  isnull(a.a_name,'') AS a_name,
  isnull(c.c_name,'') AS c_name,
  isnull(e.e_name,'') AS inputer,
  isnull(s.s_name,'') AS s_name,
  isnull(d.d_name,'') AS d_name,
  isnull(s2.s_name,'') AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  isnull(pos.posname,'')  as POS_NAME,
  0 as GatheringMan,0 as SendQTY,
  isnull(Y.Name,'') as Y_NAME  ,
  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0,' ' as sendc_name,0 as WholeQty, 0 as PartQty,
  CAST('1900-01-01' as datetime) as dpdate,
   0 as WT_ID,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
   '' AS QualityAuditer,'' as FinanceAuditer,
   0 AS QualityAudit, '1900-01-01' AS QualityAuditDate,
   0 AS FinanceAudit, '1900-01-01' AS FinanceAuditDate,
   '' as FollowNumber,'1900-01-01' as TicketDate,-1 as balancemode,0 as priority	  	 	  
 FROM RetailBillIdx b
 /*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, */
 /*vw_b_storage s2, vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_pos pos  --, vw_b_region z*/
 /*    ,Company Y*/
 inner join vw_b_employee e   on  b.inputman = e.e_id
 inner join vw_b_employee e1  on b.e_id = e1.e_id
 left  join vw_b_employee e2  on b.auditman = e2.e_id
 left  join vw_b_account a  on b.a_id = a.a_id
 left  join vw_b_client  c  on b.c_id = c.c_id
 left  join vw_b_storage s  on b.sout_id = s.s_id
 left  join vw_b_storage s2  on b.sin_id = s2.s_id
 left  join vw_b_dept d     on b.department_id = d.d_id
 left  join vw_b_pos pos    on b.PosID = pos.PosID
 left  join Company Y      on b.Y_ID = Y.Company_ID
 WHERE b.billid = @billid
/*
AND b.inputman = e.e_id
AND b.e_id = e1.e_id
AND b.auditman *= e2.e_id
AND b.a_id *= a.a_id
AND b.c_id *= c.c_id
AND b.sout_id *= s.s_id
AND b.sin_id *= s2.s_id
AND b.department_id *= d.d_id
AND b.PosID *= pos.PosID
AND b.Y_ID *= Y.Company_ID
*/
 
ELSE

IF @nTableTag in (28)
SELECT	b.*,
  isnull(a.a_name,'') AS a_name,
  isnull(c.c_name,'') AS c_name,
  isnull(e.e_name,'') AS inputer,
  isnull(s.s_name,'') AS s_name,
  isnull(d.d_name,'') AS d_name,
  isnull(s2.s_name,'') AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  isnull(pos.posname,'')  as POS_NAME,
  0 as GatheringMan,0 as SendQTY,
  isnull(Y.Name,'') as Y_NAME  ,
  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0,' ' as sendc_name,0 as WholeQty, 0 as PartQty,
   0 as WT_ID,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
   '' AS QualityAuditer, '' as FinanceAuditer,0 AS FinanceAudit, '1900-01-01' AS FinanceAuditDate,
     0 AS QualityAudit, '1900-01-01' AS QualityAuditDate, GUID as YGuid,
  CAST('1900-01-01' as datetime) as dpdate, '' as FollowNumber,'1900-01-01' as TicketDate,-1 as balancemode,0 as priority
     
 FROM sf_RetailBillidx b
 /*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, */
 /*vw_b_storage s2, vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_pos pos  --, vw_b_region z*/
 /*    ,Company Y*/
 left join vw_b_employee e   on  b.inputman = e.e_id
 left join vw_b_employee e1  on b.e_id = e1.e_id
 left  join vw_b_employee e2  on b.auditman = e2.e_id
 left  join vw_b_account a  on b.a_id = a.a_id
 left  join vw_b_client  c  on b.c_id = c.c_id
 left  join vw_b_storage s  on b.sout_id = s.s_id
 left  join vw_b_storage s2  on b.sin_id = s2.s_id
 left  join vw_b_dept d     on b.department_id = d.d_id
 left  join vw_b_pos pos    on b.PosID = pos.PosID
 left  join Company Y      on b.Y_ID = Y.Company_ID
 WHERE b.billid = @billid 
 
ELSE

IF @nTableTag in (7,17)
SELECT	b.*,
  '' AS a_name,
  (case  when b.billtype in (150,151,152,153,155,160,161,152,153,165) then isnull(Y.name,'') else isnull(c.name,'') end) AS c_name,
  isnull(e.e_name,'') AS inputer,
  '' AS s_name,
  isnull(d.d_name,'') AS d_name,
  '' AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  isnull(pos.posname,'')  as POS_NAME,
  0 as vipcardid,
  isnull(Y.Name,'') as Y_NAME  ,
  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',CASE WHEN b.billtype = 52 THEN b.[GUID] ELSE '' END AS B_CustomName3,sendC_Id=0,' ' as sendc_name,0 as WholeQty,0 as PartQty,
	  CAST('1900-01-01' as datetime) as dpdate,
   0 as WT_ID, '' AS WT_EName,  '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
   ISNULL(e6.name, '') AS QualityAuditer, '' as FinanceAuditer,0 AS FinanceAudit, '1900-01-01' AS FinanceAuditDate,
   0 AS QualityAudit, '1900-01-01' AS QualityAuditDate,	  	    
   '' as FollowNumber,'1900-01-01' as TicketDate,-1 AS balancemode,0 as priority	  		  
 FROM TranIdx b
  /*,  Company  c, vw_b_employee e,  vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_pos pos*/
  /*   ,Company Y*/
 inner join vw_b_employee e    on b.inputman = e.e_id
 inner join vw_b_employee e1   on b.e_id = e1.e_id
 left  join vw_b_employee e2   on b.auditman = e2.e_id
 left  join Company  c         on b.c_id = c.Company_ID
 left  join vw_b_dept d        on b.department_id = d.d_id
 left  join vw_b_pos pos       on b.PosID = pos.PosID
 left  join Company Y          on b.Y_ID = Y.Company_ID
 left join employees e6		on b.CenterAuditMan = e6.emp_id
 WHERE b.billid = @billid
/*
AND b.inputman = e.e_id
AND b.e_id = e1.e_id
AND b.auditman *= e2.e_id
AND b.c_id *= c.Company_ID
AND b.department_id *= d.d_id
AND b.PosID *= pos.PosID
AND b.Y_ID *= Y.Company_ID
*/
ELSE
IF @nTableTag in (9,19)
SELECT	b.*, 
  0 as a_id,0 as c_id,0 as sout_id,0 as sin_id,0 as ysmoney,0 as ssmoney,0 as araptotal,0 as quantity,0 as taxrate,'' as skdate,0 as jsye,0 as jsflag,0 as invoice,'' as invoiceno,0 as invoicetotal,0 as businesstype,
  '' AS a_name,
  '' AS c_name,
  isnull(e.e_name,'') AS inputer,
  '' AS s_name,
  isnull(d.d_name,'') AS d_name,
  '' AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  '' as POS_NAME,
  0 as GatheringMan,0 as SendQTY,
  0 as vipcardid,
  posid as Y_NAME  ,
  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0,' ' as sendc_name,0 as WholeQty,0 as PartQty,
	  CAST('1900-01-01' as datetime) as dpdate,
   0 as WT_ID, '' AS WT_EName,  '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
   '' AS QualityAuditer, '' as FinanceAuditer,0 AS FinanceAudit, '1900-01-01' AS FinanceAuditDate,
   0 AS QualityAudit, '1900-01-01' AS QualityAuditDate,	  	   	  	  	  
   '' as FollowNumber,'1900-01-01' as TicketDate,-1 as balancemode,0 as priority	  		  	  
 FROM PriceIdx b
 /*,  vw_b_employee e,  vw_b_dept d,vw_b_employee e1,vw_b_employee e2 ,Company Y*/
 inner join vw_b_employee e    on b.inputman = e.e_id
 inner join vw_b_employee e1    on b.e_id = e1.e_id
 left  join vw_b_employee e2   on b.auditman = e2.e_id
 left  join vw_b_dept d   on b.department_id = d.d_id
 /*left  join Company Y        on b.PosID = Y.Company_ID*/
 WHERE b.billid = @billid
/*
AND b.inputman = e.e_id
AND b.e_id = e1.e_id
AND b.auditman *= e2.e_id
AND b.department_id *= d.d_id
AND b.PosID *= Y.Company_ID
*/ 
ELSE
IF @nTableTag in (20)
SELECT	b.*, 
  -1 AS balancemode,
  0 as a_id,0 as c_id,0 as sout_id,0 as sin_id,0 as ysmoney,0 as ssmoney,0 as araptotal,0 as quantity,0 as taxrate,'' as skdate,0 as jsye,0 as jsflag,0 as invoice,'' as invoiceno,0 as invoicetotal,0 as businesstype,
  '' AS a_name,
  isnull(c.[name],'') AS c_name,
  isnull(e.e_name,'') AS inputer,
  '' AS s_name,
  isnull(d.d_name,'') AS d_name,
  '' AS s_name2,
  isnull(e1.e_name,'') AS e_name,
  isnull(e2.e_name,'') AS auditer,
  '' AS GatheringName,
  '' as Z_NAME,
  isnull(pos.posname,'')  as POS_NAME,
  0 as GatheringMan,0 as SendQTY,
  0 as vipcardid,
  isnull(Y.Name,'') as Y_NAME  ,
  getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0,' ' as sendc_name,0 WholeQty,0 PartQty,
  CAST('1900-01-01' as datetime) as dpdate,
   0 as WT_ID,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
   '' AS QualityAuditer, 0 as QualityAudit,  '1900-01-01' as QualityAuditDate, 0 as financeAudit,'1900-01-01' as financeAuditDate,'' as FinanceAuditer,
   '' as FollowNumber,'1900-01-01' as TicketDate,0 as priority	  		  	  
 FROM PriceInquireIdx b
 /*,  vw_b_employee e,  vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_pos pos*/
 /*    ,Company Y,Clients C*/
 inner join vw_b_employee e    on b.inputman = e.e_id
 inner join vw_b_employee e1    on b.e_id = e1.e_id
 left  join vw_b_employee e2   on  b.auditman = e2.e_id
 left  join vw_b_dept d   on b.department_id = d.d_id
 left  join vw_b_pos pos   on b.PosID = pos.PosID
 left  join Company Y   on b.Y_ID = Y.Company_ID
 inner  join Clients C   on b.c_id=c.Client_id
WHERE b.billid = @billid
/*
AND b.inputman = e.e_id
AND b.e_id = e1.e_id
AND b.auditman *= e2.e_id
AND b.department_id *= d.d_id
AND b.PosID *= pos.PosID
AND b.Y_ID *= Y.Company_ID
and b.c_id=c.Client_id
*/
else
IF @nTableTag in (39,49)
	SELECT	b.billid,b.billdate,b.billnumber,b.billtype,b.a_id,b.e_id,b.c_id,b.auditman,
                b.inputman,b.period,b.billstates,b.posid, b.Y_id,b.region_id,b.auditdate,b.note,
                b.summary,cast(0 as NUMERIC(25,8)) as ArAptotal, b.Y_ID as CURY_id,
                0 as ifintegral, 0 as integral, newid() as guid,
         b.order_id, b.department_id,
	     b.sout_id,b.sin_id, cast(0 as NUMERIC(25,8)) as ysmoney,
	     cast(0 as NUMERIC(25,8)) as ssmoney, b.quantity,  0 as taxrate, 
	     '' as skdate,0 as jsye,0 as jsflag,0 as invoice,'' as invoiceno,0 as invoicetotal,0 as businesstype,
	  '' AS a_name,
	  isnull(c.c_name,'') AS c_name,
	  isnull(e.e_name,'') AS inputer,
	  '' AS s_name,
	  '' AS d_name,
	  '' AS s_name2,
	  isnull(e1.e_name,'') AS e_name,
	  isnull(e2.e_name,'') AS auditer,
	  '' AS GatheringName,
	  '' as Z_NAME,
	  ''  as POS_NAME,
	  0 as GatheringMan,0 as SendQTY,
	  0 as vipcardid,
	  isnull(Y.Name,'') as Y_NAME  ,
	  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
		  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',sendC_Id=0 ,' ' as sendc_name,0 as WholeQty,0 as PartQty,
	  CAST('1900-01-01' as datetime) as dpdate,
	0 as WT_ID, '' AS WT_EName,  '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
	'' AS QualityAuditer, 0 as QualityAudit,  '1900-01-01' as QualityAuditDate, 0 as financeAudit,'1900-01-01' as financeAuditDate,'' as FinanceAuditer,
	'' as FollowNumber,'1900-01-01' as TicketDate,-1 as balancemode,0 as priority	  	  
	FROM ZeroStockIDX b
	/*, vw_b_client  c, vw_b_employee e,vw_b_employee e1,vw_b_employee e2 */
	/*	 ,Company Y*/
	inner join vw_b_employee e    on b.inputman = e.e_id
	left  join vw_b_employee e1 on b.e_id = e1.e_id
	left  join vw_b_employee e2 on b.auditman = e2.e_id
	left  join vw_b_client  c on b.c_id = c.c_id
	left  join Company Y on b.Y_ID = Y.Company_ID
	WHERE b.billid = @billid
	/*
	AND b.inputman = e.e_id
	AND b.e_id *= e1.e_id
	AND b.auditman *= e2.e_id
	AND b.c_id *= c.c_id
	AND b.Y_ID *= Y.Company_ID
	*/
else
BEGIN
   IF @billtype not in(150,151,152,153,155,160,161,162,163,165) 
	SELECT	CASE WHEN @bStoragesmanage = 1 AND @billtype = 10 THEN ISNULL(JHQTY.zj, 0) ELSE b.WholeQty END AS WholeQty, 
	CASE WHEN @bStoragesmanage = 1 AND @billtype = 10 THEN ISNULL(JHQTY.lhqty, 0) ELSE b.PartQty END AS PartQty, 
	CASE WHEN @bStoragesmanage = 1 AND @billtype = 10 THEN ISNULL(JHQTY.lj, 0) ELSE getdate() END AS endtime,
	b.billid, b.billdate, b.billnumber, b.billtype, b.a_id, b.c_id, b.e_id, b.sout_id, b.sin_id, b.auditman, b.inputman,
	b.ysmoney, b.ssmoney, b.quantity, b.taxrate, b.period,b.billstates, b.order_id,b.department_id, b.posid, b.region_id, 
	b.auditdate, b.skdate, b.jsye, b.jsflag, b.note, b.summary, b.invoice, b.transcount, b.lasttranstime, b.GUID, 
	b.InvoiceTotal, b.InvoiceNO, b.BusinessType,b.ArAptotal, b.SendQTY, b.GatheringMan, b.VIPCardID, b.jsInvoiceTotal, 
	b.Y_ID, b.transflag, b.begindate, b.Enddate, b.integral, b.integralYE, b.B_CustomName1, b.B_CustomName2, 
    b.B_CustomName3, b.ImportJscw, b.JscwGuid, b.RetailDate, b.sendC_id, b.Sendid, b.WholeQty, b.PartQty, b.QualityAudit, 
    b.QualityAuditDate, b.YGuid, b.financeAudit,b.financeAuditDate, b.FollowNumber, b.TicketDate,
	  isnull(a.a_name,'') AS a_name,
	  isnull(c.c_name,'') AS c_name,
	  isnull(e.e_name,'') AS inputer,
	  isnull(s.s_name,'') AS s_name,
	  isnull(d.d_name,'') AS d_name,
	  isnull(s2.s_name,'') AS s_name2,
	  isnull(e1.e_name,'') AS e_name,
	  isnull(e2.e_name,'') AS auditer,
	  isnull(e3.e_name,'') AS GatheringName,
	  '' as Z_NAME,
	  isnull(pos.posname,'')  as POS_NAME,
	  isnull(Y.Name,'') as Y_NAME ,
          getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,isnull(sc.c_name,'') AS sendc_name,b.WholeQty,b.PartQty,	  
	  0 as WT_ID, '' AS WT_EName,  '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
	  ISNULL(e4.e_name, '') AS QualityAuditer,isnull(e5.e_name,'') as FinanceAuditer,financeAudit AS FinanceAudit, financeAuditDate AS FinanceAuditDate,
	  QualityAudit AS QualityAudit, QualityAuditDate AS QualityAuditDate,	  	   	  	  
	  FollowNumber,TicketDate,case when dpdate <'1900-01-01' then '1900-01-01' else dpdate end as dpdate,b.balancemode,0 as priority
	FROM BillIdx b
	/*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, */
	/*vw_b_storage s2, vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_employee e3 ,vw_b_pos pos --, vw_b_region z*/
	/*    ,Company Y,vw_b_client sc*/
	inner join  vw_b_employee e on  b.inputman = e.e_id
	inner join  vw_b_employee e1 on b.e_id = e1.e_id
	left  join  vw_b_employee e2 on  b.auditman = e2.e_id
	left  join  vw_b_employee e3 on b.GatheringMan = e3.e_id
	left  join vw_b_employee e4 on b.qualityaudit =e4.e_id
	left  join vw_b_employee e5 on b.financeAudit =e5.e_id
	left  join  vw_b_account a  on b.a_id = a.a_id
	left  join  vw_b_client  c on b.c_id = c.c_id
	left  join  vw_b_storage s on b.sout_id = s.s_id
	left  join  vw_b_storage s2 on b.sin_id = s2.s_id
	left  join  vw_b_dept d on b.department_id = d.d_id
	left  join  vw_b_pos pos on b.PosID = pos.PosID
	left  join  Company Y on b.Y_ID = Y.Company_ID
	left  join  vw_b_client sc on b.sendc_ID = sc.c_ID	
	left join 
	        (
          select InvoiceNO,SUM(c.zj) as zj,SUM(c.lj) as lj,SUM(c.lhqty) as lhqty from  
     (
        select a.InvoiceNO, a.WholeQty,(isnull(a.WholeQty,0)-isnull(a.InvoiceTotal,0)) as zj, isnull(a.InvoiceTotal,0) as lj ,cast(summary as int) as lhqty
        from  billdraftidx a,(select GUID from  billidx)  b 
        where a.InvoiceNO<>'' and a.InvoiceNO=convert(varchar(50),b.GUID) and a.billtype=254 
      ) c group by InvoiceNO
        ) JHQTY on JHQTY.InvoiceNO = b.GUID

	WHERE b.billid = @billid
	/*
	AND b.inputman = e.e_id
	AND b.e_id = e1.e_id
	AND b.auditman *= e2.e_id
	AND b.GatheringMan *= e3.e_id
	AND b.a_id *= a.a_id
	AND b.c_id *= c.c_id
	AND b.sout_id *= s.s_id
	AND b.sin_id *= s2.s_id
	AND b.department_id *= d.d_id
	AND b.PosID *= pos.PosID
	AND b.Y_ID *= Y.Company_ID
	AND b.sendc_ID *= sc.c_ID
	*/
   ELSE
	SELECT	b.billid, b.billdate, b.billnumber, b.billtype, b.a_id, b.c_id, b.e_id, b.sout_id, b.sin_id, b.auditman, b.inputman,
	b.ysmoney, b.ssmoney, b.quantity, b.taxrate, b.period,b.billstates, b.order_id,b.department_id, b.posid, b.region_id, 
	b.auditdate, b.skdate, b.jsye, b.jsflag, b.note, b.summary, b.invoice, b.transcount, b.lasttranstime, b.GUID, 
	b.InvoiceTotal, b.InvoiceNO, b.BusinessType,b.ArAptotal, b.SendQTY, b.GatheringMan, b.VIPCardID, b.jsInvoiceTotal, 
	b.Y_ID, b.transflag, b.begindate, b.Enddate, b.integral, b.integralYE, b.B_CustomName1, b.B_CustomName2, 
    b.B_CustomName3, b.ImportJscw, b.JscwGuid, b.RetailDate, b.sendC_id, b.Sendid, b.WholeQty, b.PartQty, b.QualityAudit, 
    b.QualityAuditDate, b.YGuid, b.financeAudit,b.financeAuditDate, b.FollowNumber, b.TicketDate,
	  isnull(a.a_name,'') AS a_name,
	  isnull(c.name,'') AS c_name,
	  isnull(e.e_name,'') AS inputer,
	  isnull(s.s_name,'') AS s_name,
	  isnull(d.d_name,'') AS d_name,
	  isnull(s2.s_name,'') AS s_name2,
	  isnull(e1.e_name,'') AS e_name,
	  isnull(e2.e_name,'') AS auditer,
	  isnull(e3.e_name,'') AS GatheringName,
	  '' as Z_NAME,
	  isnull(pos.posname,'')  as POS_NAME,
	  isnull(Y.Name,'') as Y_NAME  ,
          getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
	  CURY_ID=b.Y_ID,isnull(sc.c_name,'') AS sendc_name,b.WholeQty,b.PartQty,
	  0 as WT_ID, '' AS WT_EName,  '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
	  isnull(e4.e_name,'') AS QualityAuditer,isnull(e5.e_name,'') AS FinanceAuditer,financeAudit AS FinanceAudit, financeAuditDate AS FinanceAuditDate,
	  QualityAudit AS QualityAudit, QualityAuditDate AS QualityAuditDate,	  	   	  	 
	  FollowNumber,TicketDate,case when dpdate <'1900-01-01' then '1900-01-01' else dpdate end as dpdate,b.balancemode,0 as priority
	FROM BillIdx b
	/*, vw_b_account a, Company  c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, */
	/*vw_b_dept d,vw_b_employee e1,vw_b_employee e2,vw_b_employee e3 ,vw_b_pos pos --, vw_b_region z*/
	/*    ,Company Y,vw_b_client sc*/
	inner join vw_b_employee e    on b.inputman = e.e_id
	inner join vw_b_employee e1    on b.e_id = e1.e_id
	left join vw_b_employee e2    on b.auditman = e2.e_id
	left join vw_b_employee e3    on b.GatheringMan = e3.e_id
	left  join vw_b_employee e4 on b.qualityaudit =e4.e_id
	left  join vw_b_employee e5 on b.financeAudit =e5.e_id
	left join vw_b_account a    on b.a_id = a.a_id
	left join Company  c    on b.c_id = c.Company_id
	left join vw_b_storage s    on b.sout_id = s.s_id
	left join vw_b_storage s2    on b.sin_id = s2.s_id
	left join vw_b_dept d    on b.department_id = d.d_id
	left join vw_b_pos pos    on b.PosID = pos.PosID
	left join Company Y    on b.Y_ID = Y.Company_ID
	left join vw_b_client sc    on b.sendc_ID = sc.c_ID	
	WHERE b.billid = @billid
	/*
	AND b.inputman = e.e_id
	AND b.e_id = e1.e_id
	AND b.auditman *= e2.e_id
	AND b.GatheringMan *= e3.e_id
	AND b.a_id *= a.a_id
	AND b.c_id *= c.Company_id
	AND b.sout_id *= s.s_id
	AND b.sin_id *= s2.s_id
	AND b.department_id *= d.d_id
	AND b.PosID *= pos.PosID
	AND b.Y_ID *= Y.Company_ID
	AND b.sendc_ID *= sc.c_ID
	*/
END

IF @@ROWCOUNT=1
SET @nRET = 0
GO
