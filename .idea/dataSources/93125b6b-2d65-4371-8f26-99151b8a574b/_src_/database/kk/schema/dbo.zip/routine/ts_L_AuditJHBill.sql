
create procedure ts_L_AuditJHBill
  @billid   int,
  @billst   int,  
  @WholeQty int,
  @PartQty  int,
  @shr      int,
  @locID    int=0,
  @locname  varchar(100)=''  ,
  @lhQty int=0
as
begin
    /*--获取复核前的信息 add by luowei 2014-01-22*/
    declare @nSaleBillId int
    /*-获取idx复核前信息*/
    declare @idx_WholeQty int
    declare @idx_InvoiceTotal int 
    declare @idx_integralYE int
    declare @idx_summary int
    
    select   @idx_WholeQty = isnull(WholeQty,0),@idx_InvoiceTotal = isnull(InvoiceTotal,0),@idx_integralYE = isnull(integralYE,0), @idx_summary= isnull(summary,'') from billdraftidx where billid=@billid 
    /*-获取拣货信息表*/
    declare @jhinfo_loc_id int
    declare @jhinfo_loc_name varchar(20)
    declare @jhinfo_wholeQty int
    declare @jhinfo_partQty int
    declare @jhinfo_packedQty int
    declare @jhinfo_totalQty int
    declare @jhinfo_startNum int
    
    select @nSaleBillId = saleBillId from JHBillInfo where jhBillId = @billid
    select @jhinfo_loc_id= isnull(loc_id,0),@jhinfo_loc_name =isnull(loc_name,'')  from JHBillInfo where saleBillId = @nSaleBillId
    select  @jhinfo_startNum= isnull(startNum,0),@jhinfo_wholeQty= isnull(wholeQty,0), @jhinfo_partQty= isnull(partQty,0), @jhinfo_packedQty = isnull(packedQty,0) from JHBillInfo where jhBillId = @billid
    
    /*--写入复核信息*/
    exec ts_Y_jhprocedure @billid,5,@WholeQty,@PartQty,@shr,@locID,@locname,@lhQty
  
    /*--判断是否所有拣货单都已经复核都完成*/
    if exists(select distinct a.billid,a.VIPCardID,a.order_id from billdraftidx a,(select distinct order_id from billdraftidx where billtype=254 and billid= @billid) b  
    where a.order_id=b.order_id and a.billtype <> 44 and quantity <> 0 and a.VIPCardID <> 6)
    begin
	  return 1  /*复核完成*/
    end
    else
    begin
      declare @bill_id int
      declare @nP_id int
      declare @nReturnNumber int
      set @nP_id = 0
      select @bill_id = billid from billdraftidx i where exists(select 1 from billdraftidx where billid = @billid and i.billid = order_id and order_id <> 0) and i.billtype = 10
      EXECUTE ts_c_BillAudit @bill_id,@nP_id output,@nReturnNumber output,10   /*-过账销售出库单*/
      
      if @nReturnNumber <> 0 
		begin
		/***********过账失败能复核完成，由客户手工调整单据过账 modify by luowei 2014-02-18**********/
		  /*-------回滚复核信息*/
		/*select @nSaleBillId = saleBillId from JHBillInfo where jhBillId = @billid
		update  billdraftidx  set VIPCardID=5,WholeQty=@idx_WholeQty,InvoiceTotal=@idx_InvoiceTotal,integralYE=@idx_integralYE,summary=@idx_summary
		 where billid=@billid 
		----写入发货货位
		update billdraftidx set B_CustomName1='',B_CustomName2=''
		where billtype=254 and order_id=(select order_id from billdraftidx where billid=@billid)
		and B_CustomName1<>''
		-- 删除复核表
		delete from checkidx where billid = @billid
		-- 更新拣货信息表
		-- 当前单据数量
		update JHBillInfo set loc_id = @jhinfo_loc_id, loc_name = @jhinfo_loc_name where saleBillId = @nSaleBillId
		update JHBillInfo set wholeQty = @jhinfo_wholeQty, partQty = @jhinfo_partQty, packedQty = @jhinfo_packedQty where jhBillId = @billid
		-- 销售出库单合计数量
		update JHBillInfo set totalQty = 0 where saleBillId = @nSaleBillId
		
		-- 装箱起始计数
		update JHBillInfo set startNum = @jhinfo_startNum where jhBillId = @billid
	*/	  
	  declare @pname varchar(50)
	  declare @ErrorMsg varchar(100)
	  if @nP_id <> 0 
	  select @pname = name from products where product_id = @nP_id
	  
	  if @nReturnNumber = -100 set @ErrorMsg = '销售出库单单据日期小于本期开始日期'
	  if @nReturnNumber = -101 set @ErrorMsg = '本张单据里包含结算金额大于结算余额的业务单据'
	  if @nReturnNumber = -1   set @ErrorMsg = '商品【'+@pname+'】出现负库存导致不能过帐！'
	  if @nReturnNumber = -3   set @ErrorMsg = '单据中有商品数量为零，不能过帐'
	  if @nReturnNumber = -5   set @ErrorMsg =   '商品【'+@pname+'】无成本价，不能过帐'
	  if @nReturnNumber = -6   set @ErrorMsg = '异常错误。'
	  if @nReturnNumber = -8 set @ErrorMsg = '本张单据产生的会计凭证不平，不能过帐！'
	  if @nReturnNumber = -9 set @ErrorMsg = '存在已删除的商品，不能过帐！'
	  if @nReturnNumber = -10 set @ErrorMsg = '存在已删除的仓库，不能过帐！'
	  if @nReturnNumber = -11 set @ErrorMsg = '存在已删除的职员，不能过帐！'
	  if @nReturnNumber = -12 set @ErrorMsg = '存在已删除的往来单位，不能过帐!'
	  if @nReturnNumber = -13 set @ErrorMsg = '存在已删除的会计科目，不能过帐!'
	  if @nReturnNumber = -14 set @ErrorMsg = '存在已删除的货位，不能过帐!'
	  if @nReturnNumber = -15 set @ErrorMsg = '存在计量单位已删除的商品，不能过帐!'
	  if @nReturnNumber = -23 set @ErrorMsg = '超出往来单位信用额度，不能过帐!'
	  if @nReturnNumber = -24 set @ErrorMsg = '超出职员信用额度，不能过帐!'
	  update billdraftidx set note = note + '【'+@ErrorMsg+'】' where billid = @bill_id
	  raiserror(@ErrorMsg,16,1)
	  return -2	  
	end
 	return 0
    end
end
GO
