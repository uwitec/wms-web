


CREATE   TRIGGER  UpdateThqty ON [dbo].[salemanagebilldrf] 
FOR INSERT
AS

declare @smb_id int

select @smb_id=smb_id from inserted
update salemanagebilldrf set thqty=quantity,newprice=taxprice where smb_id=@smb_id
GO
