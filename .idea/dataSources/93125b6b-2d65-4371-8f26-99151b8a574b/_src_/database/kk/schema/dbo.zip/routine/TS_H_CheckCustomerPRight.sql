
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-9*/
/* Description:	检查商品区域客户授权*/
/* =============================================*/
CREATE PROCEDURE TS_H_CheckCustomerPRight 
	@P_ID		int,
	@C_ID		int
AS
BEGIN
	SET NOCOUNT ON;

	if exists(SELECT 0 from productcustomright where c_id = @c_id and p_id = @p_id)
		return 0
	else
	if exists(SELECT     0
		FROM         dbo.ProductCustomRight AS r INNER JOIN
							  dbo.clients AS c ON r.c_id = c.client_id
		WHERE     (r.p_id = @P_ID) AND (r.c_id IN
								  (SELECT     client_id
									FROM          dbo.clients
									WHERE      (client_id <> @C_ID) AND (region_id =
															   (SELECT     region_id
																 FROM          dbo.clients AS clients_1
																 WHERE      (client_id = @C_ID))))))
		return -1
	else
		return 0
END
GO
