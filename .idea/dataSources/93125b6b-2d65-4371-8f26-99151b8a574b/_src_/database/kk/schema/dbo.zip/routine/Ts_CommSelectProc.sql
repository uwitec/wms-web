

CREATE PROCEDURE Ts_CommSelectProc
(    @TbName varchar(30),
    @szWhere varchar(800),
    @eid     int=0)
as
/*Params Ini begin*/
if @eid is null  SET @eid = 0
/*Params Ini end*/
declare @sql [varchar](5000)

if (Upper(@TbName)='DEPARTMENT') or (Upper(@TbName)='REGION') 
begin
      if Upper(@TbName)='DEPARTMENT' and (exists(select * from userauthorize u where u.e_id=@eid and u.Type='D')) AND @eid<>0
      begin 
        if @szwhere<>'' set @szwhere=' and '+@szwhere 
        set @sql='select * from department D Inner join userauthorize u ON D.departmentId=u.psc_id 
                   where (u.type = ''D'') AND (u.e_id = '+cast(@eid as varchar(50))+') '+isnull(@szwhere,'')
         
      end
      else 
      if Upper(@TbName)='REGION' and (exists(select * from userauthorize u where u.e_id=@eid and u.Type='R')) AND @eid<>0
      begin
        if @szwhere<>'' set @szwhere=' and '+@szwhere 
        set @sql='select * from Region R Inner join userauthorize u ON R.region_id=u.psc_id 
                   where (u.type = ''R'') AND (u.e_id = '+cast(@eid as varchar(50))+') '+isnull(@szwhere,'')
      end
      else
      begin
        if @szWhere =''  
	  select @sql='select * from '+@Tbname
        else   
	  select @sql='select * from '+@Tbname+' where '+@szWhere
      end       
end
else if (Upper(@TbName)='PDA_MACHINE')
begin
  select @sql = 'select mid, PDANO, demo, CAST(password as varchar(20)) as PassWord, pdaguid from pda_machine'
end 
else if (Upper(@TbName)='GSPCOMMENT')
begin
  select @sql='select * from '+@Tbname + ' where ' + @szWhere +' order by inputdate, smb_id'
end 
else begin
    if @szWhere =''  
	select @sql='select * from '+@Tbname
    else   
	select @sql='select * from '+@Tbname+' where '+@szWhere
end
/*print(@sql)*/
  exec (@sql)    
if @@rowCount=0 
	return 0
else return 1
GO
