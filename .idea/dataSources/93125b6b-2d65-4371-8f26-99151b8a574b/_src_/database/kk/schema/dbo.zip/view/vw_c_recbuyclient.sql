

CREATE VIEW dbo.vw_c_recbuyclient
AS
SELECT *
FROM (SELECT P.[Product_ID],pd.buyprice as recprice, c.[name] AS [ClientName], c.phone_number
        FROM products p,
                  (SELECT a.*
                 FROM buypricehis a,
                           (SELECT p_id, MAX(modifydate) AS modifydate
                          FROM buypricehis
                          GROUP BY p_id) b
                 WHERE a.p_id = b.p_id AND a.modifydate = b.modifydate) AS PD, 
              Clients C
        WHERE P.[Child_Number] = 0 AND p.Deleted <> 1 AND pd.c_id = c.client_id AND 
              pd.p_id = p.product_id) BM
GO
