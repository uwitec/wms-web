/************************************************************

--功能：更新往来单位证照有效期   
--创建人：zhoujiling
--创建时间：2009-3-14  
--最后修改: 2010-3-24

参数说明：--d1许可证有限期 ,d2营业执照有限期,d5委托有效期限,d8质量认证证书与编号有限期,d9组织机构代码证有限期,d10 Gsp/GMP证有限期,d12,d13,d14,d15,d16 自定义证书1，2，3，4，5有效期

**************************************************************/

CREATE	 PROCEDURE [ts_UpdateClientLic]
	(
          @C_ID int =0,
          @D1 varchar(30)= '',  
          @D2 varchar(30)='',
          @D5 varchar(30)='',
          @D8 varchar(30)='',
          @D9 varchar(30)='', 
   	      @D10 varchar(30)='',
 	      @D11 varchar(30)='',
          @D12 varchar(30)='',
          @D13 varchar(30)='',
          @D14 varchar(30)='',
          @D15 varchar(30)='',
          @D16 varchar(30)='',
          @D17 varchar(30)='',
          @D18 varchar(30)='',
          @D19 varchar(30)='',
          @D20 varchar(30)='',
          @D21 varchar(30)='',
          @Ctype smallint 
        )
AS 
/*Params Ini begin*/
if @C_ID is null  SET @C_ID = 0
if @D1 is null  SET @D1 = ''
if @D2 is null  SET @D2 = ''
if @D5 is null  SET @D5 = ''
if @D8 is null  SET @D8 = ''
if @D9 is null  SET @D9 = ''
if @D10 is null  SET @D10 = ''
if @D11 is null  SET @D11 = ''
if @D12 is null  SET @D12 = ''
if @D13 is null  SET @D13 = ''
if @D14 is null  SET @D14 = ''
if @D15 is null  SET @D15 = ''
if @D16 is null  SET @D16 = ''
if @D17 is null  SET @D17 = ''
if @D18 is null  SET @D18 = ''
if @D19 is null  SET @D19 = ''
if @D20 is null  SET @D20 = ''
if @D21 is null  SET @D21 = ''
/*Params Ini end*/

declare  @D1Date datetime, @D2Date datetime, @D5Date datetime, @D8Date datetime, @D9Date datetime, @D10Date datetime, @D11Date datetime, @D12Date datetime, @D13Date datetime, @D14Date datetime, @D15Date datetime, @D16Date datetime 
DECLARE @D17Date DATETIME, @D18Date DATETIME, @D19Date DATETIME, @D20Date DATETIME, @D21Date DATETIME
if @D1 <> ''  set @D1Date = cast(@d1 as datetime) else set @D1Date = 0
if @D2 <> ''  set @D2Date = cast(@d2 as datetime) else set @D2Date = 0
if @D5 <> ''  set @D5Date = cast(@d5 as datetime) else set @D5Date = 0
if @D8 <> ''  set @D8Date = cast(@d8 as datetime) else set @D8Date = 0
if @D9 <> ''  set @D9Date = cast(@d9 as datetime) else set @D9Date = 0
if @D10 <> ''  set @D10Date = cast(@d10 as datetime) else set @D10Date = 0
if @D11 <> ''  set @D11Date = cast(@d11 as datetime) else set @D11Date = 0
if @D12 <> ''  set @D12Date = cast(@d12 as datetime) else set @D12Date = 0
if @D13 <> ''  set @D13Date = cast(@d13 as datetime) else set @D13Date = 0
if @D14 <> ''  set @D14Date = cast(@d14 as datetime) else set @D14Date = 0
if @D15 <> ''  set @D15Date = cast(@d15 as datetime) else set @D15Date = 0
if @D16 <> ''  set @D16Date = cast(@d16 as datetime) else set @D16Date = 0
if @D17 <> ''  set @D17Date = cast(@d17 as datetime) else set @D17Date = 0
if @D18 <> ''  set @D18Date = cast(@d18 as datetime) else set @D18Date = 0
if @D19 <> ''  set @D19Date = cast(@d19 as datetime) else set @D19Date = 0
if @D20 <> ''  set @D20Date = cast(@d20 as datetime) else set @D20Date = 0
if @D21 <> ''  set @D21Date = cast(@d21 as datetime) else set @D21Date = 0

if exists(select 1 from gspalert where c_id = @C_Id and CType = @Ctype)
  update gspalert
     set d1 = @D1Date,
         d2 = @D2Date,
         d5 = @D5Date,
         d8 = @D8Date,
         d9 = @D9Date,
         d10 = @D10Date,
         d11 = @D11Date,
         d12 = @D12Date,
         d13 = @D13Date,
         d14 = @D14Date,
         d15 = @D15Date,
         d16 = @D16Date,
         d17 = @D17Date,
         d18 = @D18Date,
         d19 = @D19Date,
         d20 = @D20Date,
         d21 = @D21Date
        
  where  c_id = @C_ID and CType = @Ctype

else
  insert into gspalert(c_id, d1, d2, d5, d8, d9, d10, d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,CType) 
         values(@c_id, @d1date, @d2date, @d5date, @d8date, @d9date, @d10date, @d11date,@d12date,
                @d13date,@d14date,@d15date,@d16date,@d17date,@d18date,@d19date,@d20date,@D21Date,@Ctype) 

return 0
GO
