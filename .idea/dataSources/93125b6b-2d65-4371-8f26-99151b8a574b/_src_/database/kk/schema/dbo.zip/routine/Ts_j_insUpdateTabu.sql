

CREATE	PROCEDURE [Ts_j_insUpdateTabu]
	(@tabuid 	[int],	
	 @Code	[varchar](50),
	 @Name	[varchar](80),
	 @comment[varchar](200),
	 @szP_ID [varchar](800),
	 @e_id [int])

AS 
	 declare @TabuidTmp int;  
	 if @tabuid = 0
	 begin
	   /*添加*/
	   insert into TabuIndex(serial_number, name, comment, inputman, inputdate)
			values (@Code, @Name, @comment, @e_id, GETDATE()) 
	   set @TabuidTmp = @@IDENTITY
	   if @TabuidTmp > 0 
		 insert into TabuMx(Tabu_ID, p_id)    
			  select @TabuidTmp, CAST(sztype as int)  from dbo.DecodeToStr(@szP_ID)
	                    
	 end 
	 if @tabuid >0 
	 begin
	   /*修改*/
	   update TabuIndex
		  set serial_number = @Code, name = @Name, comment = @comment
		where Tabu_ID = @tabuid   
	   delete TabuMx where Tabu_ID = @tabuid
	   insert into TabuMx(Tabu_ID, p_id)    
			  select @Tabuid, CAST(sztype as int)  from dbo.DecodeToStr(@szP_ID)
	     
	 end
GO
