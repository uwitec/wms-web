
CREATE proc ts_j_InvoiceSelectDetail
(
@nBillID int,
@nInvoiceType int, /*0,销售类，１采购类　（调价结算类、财务类不支持按行开发票）*/
@nRet int output
)
/*with encryption*/
AS
SET NOCOUNT ON

SET @nRET = -1

IF @nInvoiceType = 1
begin
  select  P.CODE as PCODE,	P.[NAME] as PNAME,	P.STANDARD,	P.MODAL,	P.MEDNAME AS MEDTYPE,
  	  b.batchno,		b.VALIDDate,		b.Comment,	b.quantity, 	b.taxprice, 	b.taxtotal, 
	  b.smb_id, 		b.AOID,			b.iotag,	b.unitid,	b.bill_id as billid,
	  b.P_ID,		P.MAKEAREA,           	b.Discountprice,b.Totalmoney,	b.TaxMoney,

  	  CASE b.unitid
               WHEN p.unit1_id THEN 1
               WHEN p.unit2_id THEN p.rate2 
               WHEN p.unit3_id THEN p.rate3
               WHEN p.unit4_id THEN p.rate4
          END AS unitrate,
          CASE b.unitid
               WHEN p.unit1_id THEN p.unit1NAME
               WHEN p.unit2_id THEN p.unit2NAME
               WHEN p.unit3_id THEN p.unit3NAME
               WHEN p.unit4_id THEN p.unit4NAME
          END AS unit,
    	  bi.billdate,	bi.auditdate,	bi.billnumber,			bi.Cname,
          bi.billstates,		bi.Ename,			billname=ISNULL(vt.Comment, ''), 		
          bi.invoice as orderinvoiceid, bi.note,			
    	  bi.inputmanname,		bi.auditManName,
 	  bi.inputman,			bi.auditman,
          bi.guid as billGuid,		bi.billtype as billtype,
         /*case  bi.invoice when 0 then ' ' 	when 1 then '收据' */
		/*	  when 2 then '普票' 	when 3 then '增值税票' */
			/*  when 4 then '其他' */
        /* end as orderinvoice,*/
	 isnull(iv.YKQuantity, 0) as YKQuantity,  	isnull(iv.YKTotal, 0) as YKTotal	  

   from buymanagebill b 
    left join vw_x_billidx bi  on b.bill_id = bi.billid
    left join vw_products p on b.p_id = p.product_id
	left join VchType vt on bi.billtype = vt.Vch_ID
    left join 
	       (select  billid, smb_id, 
	               sum(CurrQuantity) as YKQuantity,  
                       sum(CurrTotal)  as YKTotal
                 from vw_j_invoice
                 where states = 2 and billid = @nBillID
                 group by billid, smb_id
	       )  iv   on  b.bill_id = iv.billid and b.smb_id = iv.smb_id
   /* left join billtypename bname on bi.billtype = bname.billtype*/
    WHERE b.bill_id= @nBillID AND bi.Billstates=0 and
          abs(b.quantity) > abs(isnull(iv.YKQuantity, 0)) and b.aoid in (0,8)
    order by b.smb_id 
IF @@ROWCOUNT >0 SET @nRET = 1
end

IF @nInvoiceType = 0
begin
  select  P.CODE as PCODE,	P.[NAME] as PNAME,	P.STANDARD,	P.MODAL,	P.MEDNAME AS MEDTYPE,
  	  b.batchno,		b.VALIDDate,		b.Comment,	b.quantity, 	b.taxprice, 	b.taxtotal, 
	  b.smb_id, 		b.AOID,			b.iotag,	b.unitid,	b.bill_id as billid,
	  b.P_ID,		P.MAKEAREA,		b.Discountprice,b.Totalmoney,	b.TaxMoney,
  	  CASE b.unitid
               WHEN p.unit1_id THEN 1
               WHEN p.unit2_id THEN p.rate2 
               WHEN p.unit3_id THEN p.rate3
               WHEN p.unit4_id THEN p.rate4
          END AS unitrate,
          CASE b.unitid
               WHEN p.unit1_id THEN p.unit1NAME
               WHEN p.unit2_id THEN p.unit2NAME
               WHEN p.unit3_id THEN p.unit3NAME
               WHEN p.unit4_id THEN p.unit4NAME
          END AS unit,
    	  bi.billdate,	bi.auditdate,	bi.billnumber,			bi.Cname,
          bi.billstates,		bi.Ename,			billname=ISNULL(vt.Comment, ''), 		
          bi.invoice as orderinvoiceid, bi.note,			
    	  bi.inputmanname,		bi.auditManName,
 	  bi.inputman,			bi.auditman,
          bi.guid as billGuid,		bi.billtype as billtype,
       /*  case  bi.invoice when 0 then '' 	when 1 then '收据' */
	/*		  when 2 then '普票' 	when 3 then '增值税票' */
	/*		  when 4 then '其他' */
       /*  end as orderinvoice,*/
	 isnull(iv.YKQuantity, 0) as YKQuantity,  	isnull(iv.YKTotal, 0) as YKTotal	  

    from salemanagebill b 
    left join vw_x_billidx bi  on b.bill_id = bi.billid
    left join vw_products p on b.p_id = p.product_id
	left join VchType vt on bi.billtype = vt.Vch_ID
    left join 
	       (select  billid, smb_id, 
	               sum(CurrQuantity) as YKQuantity,  
                       sum(CurrTotal)  as YKTotal
                 from vw_j_invoice
                 where states = 2 and billid = @nBillID
                 group by billid, smb_id
	       )  iv   on  b.bill_id = iv.billid and b.smb_id = iv.smb_id
   /* left join billtypename bname on bi.billtype = bname.billtype*/
    WHERE b.bill_id= @nBillID AND bi.Billstates=0 and
          abs(b.quantity) > abs(isnull(iv.YKQuantity, 0)) and b.aoid in (0,8)
    order by b.smb_id 
IF @@ROWCOUNT >0 SET @nRET = 1
end 

return 0
GO
