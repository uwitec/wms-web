




/*往来对账明细查询*/
CREATE PROCEDURE [WebAPP_CleintQryDetail]
(
    @c_id		int,
    @begindate	datetime,
    @enddate	datetime,
    @page		int,
    @weixinno	varchar(50),
    @chvErrMsg		varchar(100) output
)

/*$Encode$--*/

AS
select @chvErrMsg=''
/*select @begindate='2013-07-01'*/
select a.a_id,a.jdmoney,a.c_id,i.billnumber,i.billdate,i.ysmoney,i.jsye,i.billtype,
i.ssmoney 
from accountdetail a
inner join Billidx i on a.billid=i.billid
where a.a_id in (9,15) and i.billstates='0' 
and i.billdate>=@begindate
and i.billdate<=@enddate
and a.c_id=@c_id

declare @artotal decimal(19,2),@aptotal decimal(19,2)
select @artotal=0,@aptotal=0

if @page=0
begin
	select @artotal=sum(a.jdmoney) from accountdetail a
	inner join Billidx i on a.billid=i.billid
	where a.a_id=9 and i.billstates='0' 
	and i.billdate>=@begindate
	and i.billdate<=@enddate
	and a.c_id=@c_id
	
	select @aptotal=sum(a.jdmoney) from accountdetail a
	inner join Billidx i on a.billid=i.billid
	where a.a_id=15 and i.billstates='0' 
	and i.billdate>=@begindate
	and i.billdate<=@enddate
	and a.c_id=@c_id
end

select isnull(@artotal,0) as artotal,isnull(@aptotal,0) as aptotal,isnull(@artotal,0)-isnull(@aptotal,0) as araptotal

return 0
GO
