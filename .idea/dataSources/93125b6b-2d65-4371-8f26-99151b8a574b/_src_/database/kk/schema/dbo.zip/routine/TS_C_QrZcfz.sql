

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*
查询科目的资产负债表、利润表和平衡表及其它会计科目表

*/
CREATE PROCEDURE [TS_C_QrZcfz]
(	
  @StoredProcMode INT=0,
  @lMode          INT=0,
  @lBeginPeriod   INT=1,
  @lEndPeriod     INT=1, 
  @BeginDate      DATETIME=0,
  @EndDate        DATETIME=0,
  @OperatorID	  INT = 0,
  @YClass_id  	  VARCHAR(60)='',
  @nCompanyarap   int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @StoredProcMode is null  SET @StoredProcMode = 0
if @lMode is null  SET @lMode = 0
if @lBeginPeriod is null  SET @lBeginPeriod = 1
if @lEndPeriod is null  SET @lEndPeriod = 1
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @OperatorID is null  SET @OperatorID = 0
if @YClass_id is null  SET @YClass_id = ''
if @nCompanyarap is null  SET @nCompanyarap = 0
/*Params Ini end*/
  /*SET NOCOUNT ON*/
  DECLARE @TABLE_ZCFZ      INT
  DECLARE @TABLE_ZCFZPH    INT
  DECLARE @TABLE_JYQK      INT
  DECLARE @TABLE_ZCFZINI   INT
  DECLARE @dProductsIni    NUMERIC(25,8)
  DECLARE @dTotalApIni     NUMERIC(25,8)
  DECLARE @dYTotalApIni    NUMERIC(25,8)
  DECLARE @dTotalArIni     NUMERIC(25,8)
  DECLARE @dYTotalArIni    NUMERIC(25,8)
  DECLARE @dProductsWtIni  NUMERIC(25,8)
  DECLARE @dProductsStIni  NUMERIC(25,8)
  DECLARE @dBorrowIni      NUMERIC(25,8)
  DECLARE @dLendIni        NUMERIC(25,8)
  DECLARE @lSysPeriod      INT
  DECLARE @PerArIni        NUMERIC(25,8)
  DECLARE @YPerArIni       NUMERIC(25,8)
  DECLARE @PerApIni        NUMERIC(25,8)
  DECLARE @YPerApIni       NUMERIC(25,8)
  DECLARE @nYID		       INT

/*--------------分支机构*/
   DECLARE @Companytable INT,@ClientTable INT
   DECLARE @SQLYClassId VARCHAR(200) 
   
   set @nYID=0
   SELECT @nYID =isnull(company_id,0) from company where Class_id=@YClass_id
 
   IF @YClass_id not in ('','000000','%%')    /*增加分支机构查询 */
   BEGIN
     SET @SQLYClassId = @YClass_id + '%'
   END
   ELSE SET @SQLYClassId = '%%' 

/*------------------------------授权*/
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*------------------------------授权*/

/*得到按期号方式查询的时间段*/
  IF @lMode=0
  BEGIN
    SELECT @lSysPeriod=[Sysvalue] FROM SysConfig WHERE [Sysname]='AccountPeriod'
    IF @lBeginPeriod=0 SELECT @lBeginPeriod=@lSysPeriod
    IF @lEndPeriod=0   SELECT @lEndPeriod=@lSysPeriod
    IF @lBeginPeriod>@lEndPeriod SELECT @lEndPeriod=@lBeginPeriod
  
    IF @lBeginPeriod>@lSysPeriod
      SELECT @BeginDate=GetDate()
    ELSE 
      SELECT @BeginDate=ISNULL([BeginDate], 0) FROM MonthSettleInfo WHERE [Period]=@lBeginPeriod

    IF @lEndPeriod>@lSysPeriod 
      SELECT @EndDate=GetDate()
    ELSE 
      SELECT @EndDate=ISNULL([EndDate], GetDate()) FROM MonthSettleInfo WHERE [Period]=@lEndPeriod

    IF @BeginDate>@EndDate SELECT @EndDate=GetDate()
  END

  set @begindate=convert(varchar(10),@begindate,20)
  set @enddate=convert(varchar(10),@enddate,20)

  SELECT @TABLE_ZCFZ      =0
  SELECT @TABLE_ZCFZPH    =1
  SELECT @TABLE_JYQK      =2
  SELECT @TABLE_ZCFZINI   =3

  IF @StoredProcMode=@TABLE_ZCFZ     GOTO QuerySubjectAllTabel
  IF @StoredProcMode=@TABLE_ZCFZPH   GOTO QuerySubjectAllTabel
  IF @StoredProcMode=@TABLE_JYQK     GOTO QuerySubjectAllTabel
  IF @StoredProcMode=@TABLE_ZCFZINI  GOTO QuerySubjectZcfzIni
  ELSE GOTO SUCCEE

/****************************************
得到科目的期初、发生、期末和当前的余额表
****************************************/
QuerySubjectAllTabel:


      
      select 
      sum(a.beginartotal) as beginartotal,
      sum(a.beginaptotal) as beginaptotal,
      sum(a.endartotal) as endartotal,
      sum(a.endaptotal) as endaptotal
      into #arap
      from
      (
            SELECT 
            a.[Class_ID],
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))>0 THEN SUM(CB.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))<0 THEN -SUM(CB.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))>0 THEN SUM(CB.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))<0 THEN -SUM(CB.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal]
            FROM 
              (SELECT Class_id,Client_id FROM Clients WHERE [Child_Number]=0 AND [Deleted]<>1
                        AND ((@ClientTable=0) or (client_id in (select [id] from #Clienttable)))
              )a
               
               INNER JOIN 
                 (select cb.C_ID,isnull(SUM( CB.artotal_ini),0) artotal_ini,isnull(sum(cb.aptotal_ini),0) aptotal_ini/*,ISNULL(Y.Class_id,'')YClass_id,y.superior_id, y.yType*/
                    From ClientsBalance cb
                     Left join Company Y ON Y.Company_id=CB.Y_id
                   where ((@Companytable=0)or (cb.Y_id in (select [id] from #Companytable))) 
                          and (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
                   group by cb.C_ID
                 )CB  ON a.Client_id = CB.C_id 
                 
               LEFT JOIN
                 (
						SELECT 
						[CClass_ID] AS Class_id,
						ISNULL(SUM(CASE WHEN [AClass_ID]='000001000005' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginArTotal], 
						ISNULL(SUM(CASE WHEN [AClass_ID]='000002000001' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginApTotal],
	                   
						ISNULL(SUM(CASE WHEN [AClass_ID]='000001000005' AND [BillDate]<=@EndDate THEN [JdMoney] END), 0) AS [EndArTotal], 
						ISNULL(SUM(CASE WHEN [AClass_ID]='000002000001' AND [BillDate]<=@EndDate THEN [JdMoney] END), 0) AS [EndApTotal]
						FROM (
							 SELECT YAD.*,isnull(C.Class_id,'')CClass_id,isnull(YAD.Class_id,'')AClass_id,
									isnull(Y.Class_id,'')YClass_id,y.superior_id,y.yType
							 FROM    
								(SELECT AD.c_id,B.billid,ad.a_id,AD.Y_id,B.billdate,ad.jdmoney,a.class_id
								  FROM AccountDetail AD
								  inner JOIN Billidx B ON B.billid=AD.billid
								  inner join account a on ad.a_id=a.account_id
								  WHERE billtype not in (150,151,155,160,161,165) and b.billdate<=@EndDate and B.Billstates='0'
								  and a.class_id in ('000001000005','000002000001')
								)YAD  
								LEFT  JOIN clients C ON YAD.c_id = C.client_id
								LEFT  JOIN Company Y ON YAD.y_id = Y.Company_id
								where (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
							  )bb

					   WHERE ((@Companytable=0)or (bb.Y_id in (select [id] from #Companytable))) 
						 AND ((@ClientTable=0) or (bb.c_id in (select [id] from #Clienttable)))
						 /*and  bb.YClass_id like @SQLYClassId  */
						 and  (@nYID=0 or (bb.Y_ID=@nYID or (bb.superior_id=@nYID and bb.yType=1) ) )                  
					   GROUP BY [CClass_ID]

                   ) b
                  ON a.[Class_ID]=b.[Class_ID] 
            /*WHERE CB.YClass_ID like @SQLYClassId    */
           /* WHERE (@nYID=0 or (CB.Y_ID=@nYID or (CB.superior_id=@nYID and CB.yType=1) ) )  */
            GROUP BY a.[Class_ID]
      ) a
      

      
/*  处理机构与机构之间的内部应收应付账款  */     
      select 
      sum(a.beginartotal) as beginartotal,
      sum(a.beginaptotal) as beginaptotal,
      sum(a.endartotal) as endartotal,
      sum(a.endaptotal) as endaptotal
      into #Yarap
      from
      (
            SELECT 
            a.[Class_ID],
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))>0 THEN SUM(CB.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))<0 THEN -SUM(CB.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))>0 THEN SUM(CB.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
            ISNULL(CASE WHEN SUM(CB.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-CB.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))<0 THEN -SUM(CB.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-CB.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal]
            FROM 
              (SELECT Class_id,Company_id FROM Company WHERE [Child_Number]=0 AND [Deleted]<>1
                        AND ((@Companytable=0) or (Company_id in (select [id] from #Companytable)))
              )a
               
               INNER JOIN 
                 (select CB.* ,ISNULL(Y.Class_id,'')YClass_id,y.superior_id,y.Ytype
                    From CompanyBalance cb
                     Left join Company Y ON Y.Company_id=CB.Y_id
                   where ((@Companytable=0)or (cb.Y_id in (select [id] from #Companytable)))
                     and (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
                 )CB  ON a.Company_id = CB.C_id 
                 
               LEFT JOIN
                 (SELECT 
                    [CClass_ID] AS Class_id, Y_id,
                    ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginArTotal], 
                    ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginApTotal],
                   
                    ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<=@EndDate THEN [JdMoney] END), 0) AS [EndArTotal], 
                    ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<=@EndDate THEN [JdMoney] END), 0) AS [EndApTotal]
                    FROM (
                         SELECT YAD.*,isnull(C.Class_id,'')CClass_id,isnull(YAD.Class_id,'')AClass_id,
                                isnull(Y.Class_id,'')YClass_id,y.superior_id,y.Ytype
                         FROM    
                            (SELECT AD.c_id,B.billid,ad.a_id,ad.Y_id,B.billdate,ad.jdmoney,a.class_id
                              FROM AccountDetail AD
                              LEFT JOIN Billidx B ON B.billid=AD.billid
                              inner join account a on a.account_id=ad.a_id
                              WHERE billtype  in (150,151,155,160,161,165,171,172,173,174) and  B.Billstates='0' and b.billdate<=@EndDate     
                              and a.class_id in ('000001000010', '000002000007')
                            )YAD  
                            LEFT  JOIN clients C ON YAD.c_id = C.client_id
                            LEFT  JOIN Company Y ON YAD.y_id = Y.Company_id
                            where (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
                          )bb

                   WHERE ((@Companytable=0)or (bb.Y_id in (select [id] from #Companytable)))
                     AND ((@ClientTable=0) or (bb.c_id in (select [id] from #Clienttable)))
                     and (@nYID=0 or (bb.y_id=@nYID or (bb.superior_id=@nYID and bb.yType=1) ) )  
                   GROUP BY [CClass_ID],Y_id

                   ) b
                  ON a.[Class_ID]=b.[Class_ID] and cb.Y_id=b.Y_id
            /*WHERE CB.YClass_ID like @SQLYClassId       */
            WHERE (@nYID=0 or (cb.y_id=@nYID or (cb.superior_id=@nYID and cb.yType=1) ) ) 
            GROUP BY a.[Class_ID]
      ) a
            
/*  update #arap set beginartotal=ISNULL(ISNULL(beginartotal,0)+ ISNULL((select beginartotal from #Yarap),0),0),
                   beginaptotal=ISNULL(ISNULL(beginaptotal,0)+ ISNULL((select beginaptotal from #Yarap),0),0),
                   endartotal  =ISNULL(ISNULL(endartotal,0)+ ISNULL((select endartotal from #Yarap),0),0),
                   endaptotal  =ISNULL(ISNULL(endaptotal,0)+ ISNULL((select endaptotal from #Yarap),0),0)
*/               
               
  
  SELECT * INTO #TempSubjectAllTable 
  FROM(
      SELECT A.[Account_ID], A.[Class_ID],
      SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
      SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
      SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
      SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
      SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
      FROM Account A 
         LEFT JOIN 
       /*得到科目的明细发生额*/
         (
            SELECT A.[Class_ID], 
            SUM(ISNULL(ADB.[JDMoney], 0)+ISNULL(AB.[Ini_Total], 0)) AS [BeginJDMoney],
            CAST((SUM(ISNULL(ADM.[JDMoney], 0))) as numeric(18,8)) AS [CurJDMoney],
            SUM(ISNULL(AB.[Ini_Total], 0)+ISNULL(ADB.[JDMoney], 0)+ISNULL(ADM.[JDMoney], 0)) AS [EndJDMoney],
            SUM(ISNULL(AB.[Ini_Total], 0)) AS [IniTotal],
            SUM(ISNULL(AB.[Cur_Total], 0)) AS [CurTotal]
            FROM (select * from Account where [Deleted]=0 AND [Child_number]=0)A 
            LEFT JOIN (select AB.*,ISNUll(Y.Class_id,'')YClass_id,y.superior_id,y.yType from AccountBalance AB
                       LEFT JOIN Company Y ON Y.Company_id=AB.Y_id
                       where ((@Companytable=0)or (AB.Y_id in (select [id] from #Companytable))) 
                       and (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
                      )AB  ON A.Account_id = AB.A_id 
            LEFT JOIN 
            /*得到期初的金额*/
            (select YAD.a_id,YAD.Y_id,sum(YAD.jdmoney)jdmoney  
             from
               (select ad.a_id,b.c_id,ad.jdmoney,b.Y_id,isnull(Y.Class_id,'')YClass_id,
                y.superior_id,y.yType
                from AccountDetail ad
                left join billidx B ON B.billid=ad.billid
                left join Company Y ON B.Y_id=Y.Company_id
                where B.billdate<@Begindate  and B.billstates=0
                and (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
               )YAD 
             WHERE    ((@Companytable=0)or (YAD.Y_id in (select [id] from #Companytable))) 
                   AND ((@ClientTable=0) or (YAD.c_id in (select [id] from #Clienttable)))
                   /*AND  (YAD.YClass_ID like @SQLYClassId)	     */
                   and (@nYID=0 or (YAD.y_id=@nYID or (YAD.superior_id=@nYID and YAD.yType=1) ) )  
             Group by YAD.a_id,YAD.Y_id
            )ADB
            ON A.[Account_ID]=ADB.[A_ID] and ab.Y_id=adb.Y_id
            
            LEFT JOIN
            /*得到期中的金额*/
            (select YAD.a_id,YAD.Y_id,sum(YAD.Jdmoney)Jdmoney  
             from
               (select ad.a_id,b.c_id,ad.jdmoney,b.Y_id,isnull(Y.Class_id,'')YClass_id,
                y.superior_id,y.yType
                from AccountDetail ad
                left join billidx B ON B.billid=ad.billid
                left join Company Y ON B.Y_id=Y.Company_id
                where   B.billdate between @Begindate and @Enddate and B.billstates=0
                and (@nYID=0 or (Y.company_id=@nYID or (y.superior_id=@nYID and y.yType=1) ) )
               )YAD 
             WHERE 
                  /*YAD.YClass_ID like @SQLYClassId)	    */
                   (@nYID=0 or (YAD.y_id=@nYID or (YAD.superior_id=@nYID and YAD.yType=1) ) )       
                   AND ((@Companytable=0)or (YAD.Y_id in (select [id] from #Companytable))) 
                   AND ((@ClientTable=0) or (YAD.c_id in (select [id] from #Clienttable)))
             Group by YAD.a_id,YAD.Y_id
             ) ADM
            ON A.[Account_ID]=ADM.[A_ID] and ab.Y_id=ADM.Y_id

            /*WHERE (AB.YClass_ID like @SQLYClassId)*/
            WHERE (@nYID=0 or (AB.y_id=@nYID or (AB.superior_id=@nYID and AB.yType=1) ) )
            GROUP BY A.[Class_ID]
         ) AD
         ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
         WHERE A.[Deleted]=0 AND A.[Child_Number]=0
         GROUP BY A.[Account_ID], A.[Class_ID]
   ) A
  
   update #TempSubjectAllTable 
   set   
   BeginJDMoney=(select beginartotal from #arap),
   CurJDMoney=(select endartotal-beginartotal from #arap),
   EndJDMoney=(select endartotal from #arap)
   where class_id='000001000005'

   update #TempSubjectAllTable 
   set   
   BeginJDMoney=(select beginartotal from #Yarap),
   CurJDMoney=(select endartotal-beginartotal from #Yarap),
   EndJDMoney=(select endartotal from #Yarap)
   where class_id='000001000010'

   update #TempSubjectAllTable 
   set   
   BeginJDMoney=(select beginaptotal from #arap),
   CurJDMoney=(select endaptotal-beginaptotal from #arap),
   EndJDMoney=(select endaptotal from #arap)
   where class_id='000002000001'

   update #TempSubjectAllTable 
   set   
   BeginJDMoney=(select beginaptotal from #Yarap),
   CurJDMoney=(select endaptotal-beginaptotal from #Yarap),
   EndJDMoney=(select endaptotal from #Yarap)
   where class_id='000002000007'

/*计算利润*/
  DECLARE @dBeginIncom     NUMERIC(25,8)
  DECLARE @dBeginExpense   NUMERIC(25,8)
  DECLARE @dIncom          NUMERIC(25,8)
  DECLARE @dExpense        NUMERIC(25,8)
  DECLARE @dEndIncom       NUMERIC(25,8)
  DECLARE @dEndExpense     NUMERIC(25,8)
  DECLARE @dIniIncom       NUMERIC(25,8)
  DECLARE @dIniExpense     NUMERIC(25,8)
  DECLARE @dCurIncom       NUMERIC(25,8)
  DECLARE @dCurExpense     NUMERIC(25,8)
  
  if @nCompanyarap=1
  begin
	SELECT @dBeginIncom=SUM(ISNULL([BeginJDMoney],0)),
	@dIncom=SUM(ISNULL([CurJDMoney], 0)),
	@dEndIncom=SUM(ISNULL([EndJDMoney], 0)),
	@dIniIncom=SUM(ISNULL([IniTotal], 0)),
	@dCurIncom=SUM(ISNULL([CurTotal], 0))
	FROM #TempSubjectAllTable WHERE LEFT([Class_ID], 6)='000003' 
  

	SELECT @dBeginExpense=SUM(ISNULL([BeginJDMoney],0)),
	@dExpense=SUM(ISNULL([CurJDMoney], 0)),
	@dEndExpense=SUM(ISNULL([EndJDMoney], 0)),
	@dIniExpense=SUM(ISNULL([IniTotal], 0)),
	@dCurExpense=SUM(ISNULL([CurTotal], 0))
	FROM #TempSubjectAllTable WHERE LEFT([Class_ID], 6)='000004'
  end
  else 
  begin
	SELECT @dBeginIncom=SUM(ISNULL([BeginJDMoney],0)),
	@dIncom=SUM(ISNULL([CurJDMoney], 0)),
	@dEndIncom=SUM(ISNULL([EndJDMoney], 0)),
	@dIniIncom=SUM(ISNULL([IniTotal], 0)),
	@dCurIncom=SUM(ISNULL([CurTotal], 0))
	FROM #TempSubjectAllTable WHERE LEFT([Class_ID], 6)='000003' and Class_id <> '000003000004'
  

	SELECT @dBeginExpense=SUM(ISNULL([BeginJDMoney],0)),
	@dExpense=SUM(ISNULL([CurJDMoney], 0)),
	@dEndExpense=SUM(ISNULL([EndJDMoney], 0)),
	@dIniExpense=SUM(ISNULL([IniTotal], 0)),
	@dCurExpense=SUM(ISNULL([CurTotal], 0))
	FROM #TempSubjectAllTable WHERE LEFT([Class_ID], 6)='000004' and Class_id <> '000004000004'
  end     

  UPDATE #TempSubjectAllTable
  SET [BeginJDMoney]=ISNULL(@dBeginIncom-@dBeginExpense, 0),
      [CurJDMoney]=ISNULL(@dIncom-@dExpense, 0),
      [EndJDMoney]=ISNULL(@dEndIncom-@dEndExpense, 0),
      [IniTotal]=ISNULL(@dIniIncom-@dIniExpense, 0),
      [CurTotal]=ISNULL(@dCurIncom-@dCurExpense, 0)
  WHERE [Account_ID]=47
  
/*清除利润，需要自动计算*/
  UPDATE #TempSubjectAllTable
  SET [BeginJDMoney] = 0,
      [CurJDMoney]   = 0,
      [EndJDMoney]   = 0,
      [IniTotal]     = 0,
      [CurTotal]     = 0
  WHERE [Account_ID]=49

  IF @StoredProcMode=@TABLE_ZCFZ     GOTO QuerySubjectZcfz
  IF @StoredProcMode=@TABLE_ZCFZPH   GOTO QuerySubjectZcfzPH
  IF @StoredProcMode=@TABLE_JYQK     GOTO QuerySubjectJyqk

/****************************************
资产负债表树性表 
****************************************/
QuerySubjectZcfz:
  
  if @nCompanyarap=1 
  begin
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN  #TempSubjectAllTable AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND LEFT(A.[Class_ID], 6) IN ('000001', '000002')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  end
  else
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN  (select * from #TempSubjectAllTable A where A.class_id not in ('000001000010','000002000007')) AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND LEFT(A.[Class_ID], 6) IN ('000001', '000002') and A.class_id not in ('000001000010','000002000007')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID] 

  GOTO SUCCEE

/****************************************
资产负债表平衡表
****************************************/
QuerySubjectZcfzPH:

  
  if @nCompanyarap=1
  begin 
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN  #TempSubjectAllTable AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND (LEFT(A.[Class_ID], 6) IN ('000001', '000002')
	OR (A.[Class_ID] IN ('000005', '000005000001', '000005000004', '000005000006')))
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  end
  else 
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN (select * from #TempSubjectAllTable A where A.class_id not in ('000001000010','000002000007')) AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND (LEFT(A.[Class_ID], 6) IN ('000001', '000002')
	OR (A.[Class_ID] IN ('000005', '000005000001', '000005000004', '000005000006'))) and A.class_id not in ('000001000010','000002000007')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]

  GOTO SUCCEE

/****************************************
利润报表
****************************************/
QuerySubjectJyqk:

  if @nCompanyarap=1
  begin
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN  #TempSubjectAllTable AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND (LEFT(A.[Class_ID], 6) IN ('000003', '000004')
	OR (A.[Class_ID] IN ('000005000004')))
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  end
  else 
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	SUM(ISNULL(AD.[BeginJDMoney],0)) AS [BeginJDMoney],
	SUM(ISNULL(AD.[CurJDMoney]  ,0)) AS [CurJDMoney],
	SUM(ISNULL(AD.[EndJDMoney]  ,0)) AS [EndJDMoney],
	SUM(ISNULL(AD.[IniTotal]    ,0)) AS [IniTotal],
	SUM(ISNULL(AD.[CurTotal]    ,0)) AS [CurTotal]
	FROM Account A
	LEFT JOIN  (select * from #TempSubjectAllTable A where A.Class_id not in ('000003000004','000004000004')) AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND (LEFT(A.[Class_ID], 6) IN ('000003', '000004')
	OR (A.[Class_ID] IN ('000005000004'))) and A.Class_id not in ('000003000004','000004000004')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  GOTO SUCCEE


/****************************************
期初资产负债表
****************************************/
QuerySubjectZcfzIni:

	/*本机构ID*/
	declare @nY_ID int
	set @nY_ID=0
	/*select @nY_ID=isnull(sysvalue,0) from sysconfig where sysname='Y_ID'
        IF @nY_ID=0 
        BEGIN 
          RAISERROR ('请在系统设置中设置"分支机构"!',16,1)
          RETURN -1
        END*/
   if @YClass_id<>''
        Select @nY_ID=isnull(Company_id,0) from Company where Class_id =@YClass_id

   if @nY_id=0 set @nY_id=2

	SELECT @dProductsIni=ISNULL(SUM(B.[Costtotal]),0) FROM Products A,StoreHouseIni B
	WHERE A.[Product_ID]=B.[P_ID] AND A.[Deleted]<>1 AND B.Y_ID=@nY_ID
  
	SELECT @dProductsWtIni=ISNULL(SUM(B.[Costtotal]),0) FROM Products A,StoreDxIni B
	WHERE A.[Product_ID]=B.[P_ID] AND A.[Deleted]<>1 AND B.[commissionflag]=1 AND B.Y_ID=@nY_ID/*委托代销商品*/
  
	SELECT @dProductsStIni=ISNULL(SUM(B.[Costtotal]),0) FROM Products A,StoreDxIni B
	WHERE A.[Product_ID]=B.[P_ID] AND A.[Deleted]<>1 AND B.[commissionflag]=2 AND B.Y_ID=@nY_ID/*受托代销商品*/
  
	SELECT @dTotalApIni=ISNULL(SUM(CB.[Aptotal_ini]),0),@PerArIni=ISNULL(SUM(CB.[pre_artotal_ini]),0) FROM ClientsBalance CB
	LEFT JOIN Clients C  ON C.Client_ID=CB.C_ID
	WHERE CB.Y_ID=@nY_ID AND C.[Deleted]<>1

	SELECT @dTotalArIni=ISNULL(SUM(CB.[Artotal_ini]),0),@PerApIni=ISNULL(SUM(CB.[pre_aptotal_ini]),0) FROM ClientsBalance CB
        LEFT JOIN Clients C  ON C.Client_ID=CB.C_ID
        WHERE   CB.Y_ID=@nY_ID AND C.[Deleted]<>1

	SELECT @dYTotalApIni=ISNULL(SUM(CB.[Aptotal_ini]),0),@YPerArIni=ISNULL(SUM(CB.[pre_artotal_ini]),0) FROM CompanyBalance CB
	LEFT JOIN Company Y  ON Y.Company_ID=CB.Y_ID
	WHERE  CB.Y_ID=@nY_ID AND Y.[Deleted]<>1 

	SELECT @dYTotalArIni=ISNULL(SUM(CB.[Artotal_ini]),0),@YPerApIni=ISNULL(SUM(CB.[pre_aptotal_ini]),0) FROM CompanyBalance CB
        LEFT JOIN Company Y  ON Y.Company_ID=CB.Y_ID
        WHERE  CB.Y_ID=@nY_ID AND Y.[Deleted]<>1 
  
  
	SELECT @dBorrowIni=ISNULL(SUM(B.[Costtotal]),0) FROM Products A, StoreBrrowIni B
	WHERE A.[Product_ID]=B.[P_ID] AND A.[Deleted]<>1 AND B.[commissionflag]=4 AND B.Y_ID=@nY_ID/*借进商品*/
  
	SELECT @dLendIni=ISNULL(SUM(B.[Costtotal]),0) FROM Products A, StoreBrrowIni B
	WHERE A.[Product_ID]=B.[P_ID] AND A.[Deleted]<>1 AND B.[commissionflag]=3 AND B.Y_ID=@nY_ID/*借出商品*/
  
	UPDATE AccountBalance SET [Ini_Total]=@dProductsIni   WHERE   Y_ID=@nY_ID AND [A_ID]=3/*期初库存*/
    UPDATE AccountBalance SET [Ini_Total]=@dTotalArIni    WHERE Y_ID=@nY_ID AND [A_ID]=9  /*期初应收*/
	UPDATE AccountBalance SET [Ini_Total]=@dTotalApIni    WHERE  Y_ID=@nY_ID AND [A_ID]=15/*期初应付*/
	UPDATE AccountBalance SET [Ini_Total]=@dProductsWtIni WHERE  Y_ID=@nY_ID AND [A_ID]=12/*委托代销商品*/
	UPDATE AccountBalance SET [Ini_Total]=@dProductsStini WHERE  Y_ID=@nY_ID AND [A_ID]=17/*受托代销商品款*/
	UPDATE AccountBalance SET [Ini_Total]=@dBorrowIni     WHERE  Y_ID=@nY_ID AND [A_ID]=16/*借进商品*/
	UPDATE AccountBalance SET [Ini_Total]=@dLendIni       WHERE  Y_ID=@nY_ID AND [A_ID]=10/*借出商品*/
    UPDATE AccountBalance SET [Ini_Total]=@PerApIni+@YPerApIni   WHERE [A_ID]=60 AND Y_ID=@nY_ID/*预付*/
    UPDATE AccountBalance SET [Ini_Total]=@PerArIni+@YPerArIni   WHERE [A_ID]=61 AND Y_ID=@nY_ID/*预收*/
    UPDATE AccountBalance SET [Ini_Total]=@dYTotalArIni       WHERE Y_ID=@nY_ID AND [A_ID]=69 /*内部应收*/
    UPDATE AccountBalance SET [Ini_Total]=@dYTotalApIni       WHERE Y_ID=@nY_ID AND [A_ID]=70 /*内部应付  */

  if @nCompanyarap=1
  begin 
	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [BeginJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [CurJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [EndJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [IniTotal],
	ISNULL(SUM(AD.[CurTotal]), 0) AS [CurTotal]
	FROM Account A 
	LEFT JOIN
	/*得到科目的余额*/
	(  SELECT A.[Class_ID], SUM(AB.[Ini_Total]) AS [CurTotal]
	FROM AccountBalance AB LEFT JOIN Account A ON AB.A_ID=A.ACCOUNT_ID
	WHERE A.[Deleted]=0 AND A.[Child_number]=0 AND AB.Y_ID=@nY_ID
	GROUP BY A.[Class_ID]   )  AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND LEFT(A.[Class_ID], 6) IN ('000001', '000002')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  end
  else 
  	SELECT A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [BeginJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [CurJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [EndJDMoney],
	CAST(SUM(0) AS NUMERIC(18, 8)) AS [IniTotal],
	ISNULL(SUM(AD.[CurTotal]), 0) AS [CurTotal]
	FROM Account A 
	LEFT JOIN
	/*得到科目的余额*/
	(  SELECT A.[Class_ID], SUM(AB.[Ini_Total]) AS [CurTotal]
	FROM AccountBalance AB LEFT JOIN Account A ON AB.A_ID=A.ACCOUNT_ID
	WHERE AB.Y_ID=@nY_ID AND A.[Child_number]=0 AND A.[Deleted]=0 AND AB.A_ID NOT IN (69,70)
	GROUP BY A.[Class_ID]   )  AD
	ON LEFT(AD.[Class_ID], LEN(A.[Class_ID]))=A.[Class_ID]
	WHERE A.[Deleted]=0 AND LEFT(A.[Class_ID], 6) IN ('000001', '000002') AND A.CLASS_ID NOT IN ('000001000010','000002000007')
	GROUP BY A.[Account_ID], A.[Class_ID], A.[Serial_number], A.[Name], A.[Child_Number]
	ORDER BY A.[Class_ID]
  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
