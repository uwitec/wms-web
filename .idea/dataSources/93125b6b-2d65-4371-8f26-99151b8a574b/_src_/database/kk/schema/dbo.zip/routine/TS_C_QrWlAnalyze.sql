


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
--mode=0 明细
--mode=1 汇总
********************************************/
CREATE PROCEDURE [TS_C_QrWlAnalyze]
(	@Begindate DATETIME=0,
	@Enddate   DATETIME=0,
	@nC_ID	   INT=0,
	@Mode      INT=0,
	@IniTotal  NUMERIC(25,8) OUTPUT,
        @nYClassid varchar(100)='',
        @nloginEID int=0,
        @isaddDate int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = 0
if @Enddate is null  SET @Enddate = 0
if @nC_ID is null  SET @nC_ID = 0
if @Mode is null  SET @Mode = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
DECLARE
	@szSql      VARCHAR(8000),
	@ArTotal_Id VARCHAR(30),	/*9	『应收款合计』*/
	@ApTotal_Id VARCHAR(30),	/*15『应付帐款合计』*/
	@dTempTotal NUMERIC(25,8)
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
  Declare @isfinally int

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
/*---分支机构授权*/

SELECT
  @ArTotal_ID ='000001000005',/*9	『应收款合计』*/
	@ApTotal_ID ='000002000001' /*15『应付帐款合计』*/

IF @isaddDate=1
BEGIN
/*暂时不处理*/
select 1
END
ELSE
BEGIN
	
	/*取起始时间段内的变化量*/
	SELECT @dtemptotal=ISNULL(SUM(CASE A.[AClass_ID] WHEN @Artotal_ID THEN A.[JDmoney] ELSE -A.[JDmoney] END), 0) FROM VW_C_ADetail A, VW_C_BillIDX B
 
	WHERE A.[BillID]=B.[BillID] AND B.[Billdate]<@Begindate AND A.[AClass_ID] IN (@Artotal_ID, @Aptotal_ID) 
        AND A.[C_ID]=@nC_ID AND B.[Billstates]='0'
        AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id  like u.psc_id+'%'))))
        AND B.Billtype not in (150,151,155,160,161,165) and (@nYClassID='' OR B.Yclass_id like @nYClassID+'%')
	
        /*取期初余额*/
	SELECT @iniTotal=ISNULL(SUM(cb.artotal_ini)-SUM(cb.aptotal_ini),0) FROM vw_L_Clientsbalance cb
        WHERE [C_ID]=@nC_ID
            AND (@ClientTable=0 or ((cb.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and cb.cclass_id  like u.psc_id+'%'))))
	    AND (@CompanyTable=0 or ((cb.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and cb.Yclass_id like u.psc_id+'%'))))
	    AND (@nYClassID='' OR cb.Yclass_id like @nYClassID+'%')

	
	SELECT @Initotal=@Initotal+@dTemptotal
	
	IF @Mode=0
	BEGIN
	SELECT
              VW.[BillID],  VW.[Billdate], VW.[Billnumber], VW.[Billtype], VW.[Billstates],
              VW.[Comment], VW.[A_ID],     VW.[Quantity],   VW.[Taxprice] ,
              (case when vw.billtype in (15,23) then -VW.[JDmoney] else VW.[JDmoney] end)[JDmoney],
            /*  VW.[JDmoney],*/
              VW.[C_ID],    VW.[Inputman], VW.[pcomment] as Dcomment,   VW.[E_ID],cast(0 as NUMERIC(25,8)) as jsye
	FROM VW_C_WLMX VW 
	WHERE (VW.[Billdate] BETWEEN @Begindate AND @Enddate) AND VW.[C_ID]=@nC_ID AND (@nYClassID='' OR VW.Yclass_id like @nYClassID+'%')
                AND (@ClientTable=0 or ((VW.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and VW.cclass_id  like u.psc_id+'%'))))
 		ORDER BY VW.[Billdate], VW.[BillID], VW.[Comment], VW.[A_ID]
	END
        ELSE BEGIN
	SELECT 
	      c.[BillID],
	      c.[Billdate],
	      c.[Billnumber],
	      c.[Billtype],
	      c.[Billstates],
	      c.[Comment],
	      c.[A_ID],
	      c.[C_ID],
	      c.[Inputman],
	      c.[Dcomment],
	      c.[E_ID],
	      c.[Quantity],
	      c.[Taxprice],
	      c.[JDmoney],
	     /* c.[JDmoney],*/
	      c.jsye	
	     from 
	    (
	     select 
	      VW.[BillID],
	      MAX(VW.[Billdate])   AS [Billdate],
	      MAX(VW.[Billnumber]) AS [Billnumber],
	      MAX(VW.[Billtype])   AS [Billtype],
	      MAX(VW.[Billstates]) AS [Billstates],
	     /* MAX(VW.[Comment])    AS [Comment],*/
	     dbo.MergeStr(BillID)  AS [Comment],
	      MAX(VW.[A_ID])       AS [A_ID],
	      MAX(VW.[C_ID])       AS [C_ID],
	      MAX(VW.[Inputman])   AS [Inputman],
	      MAX(VW.[Dcomment])   AS [Dcomment],
	      MAX(VW.[E_ID])       AS [E_ID],
	      SUM(VW.[Quantity])   AS [Quantity],
	      cast(CASE WHEN SUM(VW.[Quantity])<>0 THEN SUM(VW.[JDMoney])/SUM(VW.[Quantity]) ELSE 0 END  as NUMERIC(25,8))  AS [Taxprice],
	      SUM(case when vw.billtype in (15,23) then -VW.[JDmoney] else VW.[JDmoney] end)    AS [JDmoney],
	     /* SUM(VW.[JDmoney])    AS [JDmoney],*/
	      cast(MAX(VW.jsye) as NUMERIC(25,8))    AS jsye
	 FROM VW_C_WLMX VW 
	 WHERE (VW.[Billdate] BETWEEN @Begindate AND @Enddate) AND VW.[C_ID]=@nC_ID AND (@nYClassID='' OR VW.Yclass_id like @nYClassID+'%')
           AND 
          (
            @ClientTable=0 
            or (
                (VW.cclass_id='') 
                  or 
                   (exists
                     (select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and VW.cclass_id  like u.psc_id+'%'
                      )
                    )
                )
           )
		GROUP BY VW.[BillID]
	 ) c 	
	 ORDER BY c.[Billdate],c.[BillID],c.[Comment],c.[A_ID]
	END

END

  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
