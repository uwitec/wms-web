




CREATE	PROCEDURE [ts_W_NoSaleClientAlert] 
( 
 @szwhere  varchar(1000)=''
)
AS
/*Params Ini begin*/
if @szwhere is null  SET @szwhere = ''
/*Params Ini end*/
declare @sql varchar(8000)          
   set @sql='select *  from clients Where Child_Number=0 and '+@szWhere
   exec (@sql)
   /*print(@sql)*/
   return 0
GO
