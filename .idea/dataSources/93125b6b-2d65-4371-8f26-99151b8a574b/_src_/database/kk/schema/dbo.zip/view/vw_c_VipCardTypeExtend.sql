create view dbo.vw_c_VipCardTypeExtend
as
   select I_id,IntegralMoney, BackIntNeedMoney, 
   Integralmode=(case Integralmode when 0 then '累积积分' 
       when 1 then '按单积分' 
       when 2 then '按天积分'  else '' end),
   memberbl,birthdaybl,Specialbl,discountbl,  
   daymode=(case daymode when 0 then '公历天' 
       when 1 then '农历天' 
       when 2 then '按星期'  else '' end),
   dmstr,cnamestr,cardnamestr,deleted,validmonth,casevalid,ismoneyup,moneyup,moneyupC_id,
   moneyupC_name,isIntegralup,Integralup,IntegralupC_id,
   IntegralupC_name,Integralupkc,isautoup,remake 
   from  VipCardTypeExtend  
   where deleted=0
GO
