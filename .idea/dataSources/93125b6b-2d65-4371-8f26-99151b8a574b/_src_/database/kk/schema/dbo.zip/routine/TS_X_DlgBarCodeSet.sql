
/******************************************
电子秤设置
********************************************/
CREATE PROCEDURE [TS_X_DlgBarCodeSet] 
( @lMode     INT=0,
  @lID       INT=0,
  @szName    VARCHAR(60)='',
  @szCode    VARCHAR(60)='',
  @szConfig  VARCHAR(2000)='',
  @lTag      INT=0,
  @CodeLen   INT=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @lMode is null  SET @lMode = 0
if @lID is null  SET @lID = 0
if @szName is null  SET @szName = ''
if @szCode is null  SET @szCode = ''
if @szConfig is null  SET @szConfig = ''
if @lTag is null  SET @lTag = 0
if @CodeLen is null  SET @CodeLen = 0
/*Params Ini end*/
	SET NOCOUNT ON
  IF @lMode=0 GOTO ReadData
  IF @lMode=1 GOTO AddData
  IF @lMode=2 GOTO ModData
  IF @lMode=3 GOTO DelData
ReadData:
  IF @lID IN (0)
  BEGIN
    SELECT * FROM ElecBalance
  END
  ELSE
  BEGIN
    SELECT * FROM ElecBalance WHERE [ID]=@lID
  END
  GOTO SUCCEE
AddData:
  INSERT INTO ElecBalance([Name], [MarkCode], [Config], [Tag], [CodeLength])
  VALUES(@szName, @szCode, @szConfig, @lTag, @CodeLen)
  GOTO SUCCEE
ModData:
  UPDATE ElecBalance
  SET [Name]=@szName, [MarkCode]=@szCode, [Config]=@szConfig, 
    [Tag]=@lTag, [CodeLength]=@CodeLen
  WHERE [ID]=@lID
  GOTO SUCCEE
DelData:
  DELETE FROM ElecBalance WHERE [ID]=@lID 
  GOTO SUCCEE
SUCCEE:
  RETURN 0
  
  
SET QUOTED_IDENTIFIER OFF
GO
