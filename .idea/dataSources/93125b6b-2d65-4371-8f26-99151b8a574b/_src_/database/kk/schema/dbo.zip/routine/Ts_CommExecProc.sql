








CREATE PROCEDURE Ts_CommExecProc 
(	@szSql	varchar(3000)
)
AS

exec (@szSql)

if @@rowcount=0 
	return 0 
else 
	return 1
GO
