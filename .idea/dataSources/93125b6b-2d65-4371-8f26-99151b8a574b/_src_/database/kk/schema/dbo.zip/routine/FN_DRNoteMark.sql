
CREATE FUNCTION FN_DRNoteMark 
(
  @billid INT
)
RETURNS VARCHAR(100)
AS
BEGIN
  DECLARE @Result VARCHAR(100),@y_id INT,@ybmoney NUMERIC(18,4),@taxmoney NUMERIC(18,4),@billtype INT,@note VARCHAR(500)  
  SET @Result=''
  IF EXISTS(SELECT TOP 1 1 FROM sysconfigtmp WHERE sysname='yzshebao' AND sysvalue='3')
  BEGIN
    SELECT @ybmoney=0,@taxmoney=0,@billtype=0,@note=''
    SELECT @y_id=Y_ID,@taxmoney=ysmoney,@billtype=billtype,@note=note FROM billidx WHERE billid=@billid
    IF @billtype=12 AND 
       EXISTS(SELECT 1 FROM sysconfigtmp WHERE sysname='yzshebao' AND (Y_id=@y_id OR Y_id=0) AND sysvalue='3')
    BEGIN 
      SELECT @ybmoney=YBMoney+TCMoney FROM DRBillidx WHERE Billid=@billid AND Billtype=12 AND SettleFlag='600'
      IF @ybmoney=0 
         SET @Result='全部品种非刷社保支付'
      ELSE IF ABS(@taxmoney-@ybmoney)>0.01  
         SET @Result='部分品种刷社保支付'
      ELSE 
         SET @Result='全部品种刷社保支付'
      SET @Result=CASE WHEN @note<>'' THEN @note+',' ELSE '' END+@Result
    END 
  END   

  RETURN @Result

END
GO
