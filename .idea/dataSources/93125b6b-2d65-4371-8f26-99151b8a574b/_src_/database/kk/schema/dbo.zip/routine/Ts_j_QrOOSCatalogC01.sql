
/*缺货分析　按商品汇总，表格3*/
/*最近5次进价*/

CREATE	       PROCEDURE Ts_j_QrOOSCatalogC01
(
	@szfactory  varchar(100)= '%',  	
	@PClassID   VARCHAR(30) = '%',
	@CClassID   VARCHAR(30) = '%',
	@YClassID   VARCHAR(30) = '%',    /*暂不使用*/
	@BeginDate  DATETIME,  
	@EndDate    DATETIME
)
/*with encryption*/
AS

   if @szfactory = ''  set @szfactory = '%%' else  set @szfactory = @szfactory +'%'
   if @PClassID = ''  set @PClassID = '%%'   else  set @PClassID = @PClassID +'%' 
   if @CClassID = ''  set @CClassID = '%%'	 else  set @CClassID = @CClassID +'%'
   if @YClassID = ''  set @YClassID = '%%'   else  set @YClassID = @YClassID +'%'


	SELECT c.class_id, c.serial_number, c.name as Cname, c.alias, o.ClientId, c.contact_personal, c.phone_number,
           COUNT(1) as OOSCount, /*缺货笔数*/
           COUNT(Case when Inflag = 1 then 1 end) as DisposeCount, /*处理笔数*/
           COUNT(Case when Inflag = 0 then 1 end) as NODisposecount,/*未处理笔数*/
           COUNT(Case when Inflag = 2 then 1 end) as StopDisposecount,/*终止笔数*/
           COUNT(Case when InDisposeflag = 1 then 1 end) as Buycount,/*计划购入笔数*/
           COUNT(Case when InDisposeflag = 2 then 1 end) as NoQtycount, /*暂无货笔数*/
           COUNT(Case when OutDisposeflag <> 0 then 1 end) as Salecount /*已开票笔数                                                              */
    FROM OOSCatalog o INNER JOIN vw_products p ON o.ProductId = p.product_id                                                                                                                                                          
                      inner join clients c on o.ClientId = c.client_id
                      /*inner join company y on o.CompanyId = y.company_id                     				   					   										                   									                   */
    WHERE o.[Deleted] = 0 AND p.[deleted] = 0 AND p.factory like @szfactory and
          o.InputDate BETWEEN @BeginDate AND @EndDate and 
          p.class_id LIKE @PClassID AND ISNULL(c.class_id, '') LIKE @CClassID /*AND ISNULL(y.class_id, '') LIKE @YClassID */
                              
    group by c.class_id, c.serial_number, c.name, c.alias, o.ClientId, c.contact_personal, c.phone_number
GO
