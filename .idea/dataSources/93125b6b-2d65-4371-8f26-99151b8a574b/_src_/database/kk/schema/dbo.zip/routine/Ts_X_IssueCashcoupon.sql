Create  procedure Ts_X_IssueCashcoupon 
  ( @bill_id  int,             /*单据ID*/
    @CxGuid uniqueidentifier    /*使用代金券促销的guid*/
  )  

AS	

    declare @typeid varchar(100)   /*代金券类型id*/
	declare @NOCount  int /*代金券位数		*/
	declare @TypeName varchar(100)/*券类型名 */
	declare @total NUMERIC(25,8)  /*面额、*/
	declare @begindate datetime /*启用时间*/
	declare @validDate datetime  /*有效期、*/
	declare @quantity  int /*发行数量、	*/
	declare @inputMan  int /*制作人、*/
	declare @Createdate  datetime /*发行时间、	*/
	declare @flag int /*状态    0 启用，1, 删除, 2, 停用, 3 作废  */
	declare @vipcardid int   /*绑定的会员卡、    */
	declare @limitTotal NUMERIC(25,8) /*限额（如设置商品类别，则按类别限额*/
	declare @Limitflag  int/*限额属性  0 整, 1 商品,  2类别*/
	declare @multiFlag  int	 
	declare @CashNo  VARCHAR(20)   /*代金券号码*/
  
 /*
 if exists (select 1 from billidx b,salemanagebill s where  b.billid = @bill_id and b.billid = s.bill_id
											and s.CxGuid in (select guid from CxDetail where cp_id = 130)  --这儿判断是否应用了代金券的
			)   */

	if exists ( select * from billidx where billid = @bill_id)  /*单据存在*/
	begin
		select @typeid = p_id from CxDetail where guid = @CxGuid	
		if @typeid is null set @typeid = 0
		if @typeid >0 
		begin
			select  @TypeName = TypeName,@NOCount = bitcount, @total = total, @begindate = begindate, @validDate = validDate,@quantity = quantity,
					 @limitTotal = limitTotal,@multiFlag = Limitflag,@multiFlag = MultiFlag from cashcoupontype  where typeid = @typeid
		
		set @flag = 0 /*默认为启用*/
		set @Createdate = GETDATE()
		set @quantity = 1
		select @vipcardid = VIPCardID,@inputMan = inputman from billidx where billid = @bill_id
		if @vipcardid is null
			set @vipcardid = 0  
		
		/*发行代金券	*/
		exec TS_j_insCashCoupon @NOCount,@TypeName,@total,@begindate,@validDate,@quantity,@inputMan,@Createdate,@flag,@vipcardid,@limitTotal,@Limitflag,@multiFlag,@typeid
		
		if @@ROWCOUNT > 0 
		begin
			select @CashNo = CashNO from cashcoupon where ccid in (
			select MAX(ccid) ccid from cashcoupon where typeid = @typeid and flag = @flag and  inputMan = @inputMan 
			)		
		    update billidx set CashNo = @CashNo where billid = @bill_id  /*把发放的代金券号码更新到单据*/
		   
		end
	
	end	
end
GO
