/************************************************************

--功能：反日结   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_ReDayAccount]
  (
   @nID int=0  
  )
  
AS
/*Params Ini begin*/
if @nID is null  SET @nID = 0
/*Params Ini end*/

IF EXISTS(SELECT 1 FROM DayAccount WHERE id = @nID AND transflag <> 0)
BEGIN
	RAISERROR('日结记录已传输，不允许反日结！', 16, 1)
	RETURN 0
END

if @nID < 1 return 0

    update dayaccount set ifDayAccount = 0 where ifDayAccount <> 0 and [id] = @nID
    IF @@ROWCOUNT <> 0
		update billidx    set transcount=-@nID where transcount=@nID
   /* update UPBillList set DCFlag = 0 where mdDA_ID = @nID*/
GO
