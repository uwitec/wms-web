
CREATE PROCEDURE [dbo].[TS_T_GetTodayRetailCx]
	@Y_ID		int,	
	@CardID		int = -1	
AS
BEGIN
  SET NOCOUNT ON;
  declare @nFirstDay int
  set @nFirstDay = @@DATEFIRST
  set datefirst 1
  
  DECLARE @ctByPrice INT, 
          @ctByGroup INT, 
          @ctByEnoughQty INT, 
          @ctByEnoughMoney INT, 
          @ctByEnoughPG INT, 
          @ctByAdditional INT, 
          @ctByPDiscount INT, 
          @ctByFDiscount INT, 
          @ctByCDiscount INT, 
          @ctByAllDsicount INT, 
          @ctByEnoughRec INT, 
          @ctByAddPrice INT   
  SET @ctByPrice = 10       /*价格促销*/
  SET @ctByGroup = 20       /*组合促销*/
  SET @ctByEnoughQty = 30   /*满量赠*/
  SET @ctByEnoughMoney = 40 /*满额赠*/
  SET @ctByEnoughPG = 50    /*满品规赠*/
  SET @ctByAdditional = 60  /*增量促销*/
  SET @ctByPDiscount = 70   /*商品折扣*/
  SET @ctByFDiscount = 80   /*厂家折扣*/
  SET @ctByCDiscount = 90   /*类别折扣*/
  SET @ctByAllDsicount = 100/*全场折扣*/
  SET @ctByEnoughRec = 110  /*满立减*/
  SET @ctByAddPrice = 120   /*加价购   */
	
  IF @CardID IS NULL SET @CardID = -1
  DECLARE @VBirthday VARCHAR(10), @VBirBeginD VARCHAR(10), @VBirEndD VARCHAR(10), @VBirBeginW VARCHAR(10), @VBirEndW VARCHAR(10), 
          @VBirBeginM VARCHAR(10), @VBirEndM VARCHAR(10)
  DECLARE @CTID INT /*会员卡类型*/
  IF @CardID <= 0 SET @CTID = -1
  IF @CardID > 0
  BEGIN
    /*本年度生日 */
    SELECT @VBirthday = CAST(DATEPART(YYYY, GETDATE()) AS VARCHAR) + '-' + CAST(DATEPART(MM, Birthday) AS VARCHAR) + '-' + CAST(DATEPART(DD, Birthday) AS VARCHAR),
      @CTID = CT_ID FROM VIPCard WHERE VIPCardID = @CardID   
    /*当天     */
    SET @VBirBeginD = @VBirthday 
    SET @VBirEndD = @VBirthday    
    /*当周*/
    SET @VBirBeginW = DATEADD(WK, DATEDIFF(WK, 0, @VBirthday), 0) 
    SET @VBirEndW = DATEADD(WK, DATEDIFF(WK, 0, @VBirthday), 6)           
    /*当月*/
    SET @VBirBeginM = Convert(VARCHAR(100), dateadd(mm, datediff(mm, 0, @VBirthday), 0), 23) 
    SET @VBirEndM = Convert(VARCHAR(100), dateadd(ms, -3, dateadd(mm, datediff(m, 0, @VBirthday) + 1, 0)), 23)
  END   
  
  /*今日农历天*/
  DECLARE @LunarDay VARCHAR(10) 
  /*SELECT @LunarDay = SUBSTRING(LunarDate, CharIndex('月', LunarDate) + 1, 2) FROM TBLunarData WHERE SolarDate = Convert(VARCHAR(100), GETDATE(), 23)*/
  /*-计算农历天  XXX.2017-01-09  这个用函数计算*/
  SELECT  @LunarDay = SUBSTRING(dbo.fn_GetLunar(GETDATE(),''), CharIndex('月', dbo.fn_GetLunar(GETDATE(),'')) + 1, 2) 

  /*XXX.2017-04-20 新自定义类别下过滤不满足该机构的促销*/
		declare @i int 
		DECLARE @cColName VARCHAR(100) 
		DECLARE @szSql VARCHAR(2000) 
		DECLARE @ColIds VARCHAR(200) 
		CREATE TABLE #ids ([R_id] [int] NOT NULL DEFAULT(0))  /*返回该机构有自定义类别属性的属性号*/
		set @i = 0  
		set @ColIds = '' 
	
	   set @i = 1 
		while @i <= 50  
		begin 
			set @cColName = dbo.GetColName(@i,'CompanyCategory') 
            SET @szSql =   
			'IF EXISTS (
				select p.company_id from Company p,CompanyCategory c where p.company_id = c.Y_id and c.'+@cColName +   
				 '<> '''') 
			insert into #ids(R_id) values(' +cast(@i as varchar) +')'	

				print @szSql
			EXEC (@szSql)	
			set @i = @i + 1 
		end 

	
  /*提取符合条件的促销方案			*/
  /*SELECT TOP 1 XMLID into #cxBill FROM CxDetail cx*/
  SELECT XMLID into #cxBill FROM CxDetail cx
    WHERE cx.billstate = 3 
      AND ( ((cx.Ytype <= 0) and (cx.YIDs = '')) OR (',' + cx.YIDs + ',' LIKE '%,' + CAST(@Y_ID AS varchar) + ',%')
			or cx.Ytype in (select Ytype from CxDetail x,customCategory c where x.Ytype > 0 and x.Ytype = c.id and c.Category_id in (select R_id from #ids ))
			) /*新自定义类别下处理过滤掉非本机构的促销     */
     
      AND ((@CTID = -1) OR (cx.cardtype = '-1') OR (CharIndex(',' + CAST(@CTID AS VARCHAR) + ',', ',' + cx.cardtype + ',') > 0)) /*会员卡类型                  */
      AND (cx.begindate <= GETDATE()) AND (DATEADD(d, 1, cx.enddate) > GETDATE())  /*开始结束日期*/
      AND ( (cx.cxDayType = 0) /*不指定促销日*/
        OR ((cx.cxDayType = 1) AND (CharIndex(',' + CAST(DATEPART(DD, GETDATE()) AS VARCHAR) + ',', ',' + cx.GreCalendars + ',') > 0))  /*公历         */
        OR ((cx.cxDayType = 2) AND (CharIndex(',' + @LunarDay + ',', ',' + cx.CHNCalendars + ',') > 0)) /*农历*/
        OR ((cx.cxDayType = 3) AND (CharIndex(',' + CAST(DATEPART(DW, GETDATE()) AS VARCHAR) + ',', ',' + cx.WeekDays + ',') > 0)) /*星期几*/
        OR ((cx.cxDayType = 4))) /*AND (@CardID > 0) AND (((cx.VIPBirthdayType = 0) AND (Convert(VARCHAR(100), GETDATE(), 23) = @VBirBeginD))*/
                               /*                    OR ((cx.VIPBirthdayType = 1) AND (@VBirBeginW <= GETDATE() AND DATEADD(D, 1, @VBirEndW) > GETDATE()))*/
                               /*                    OR ((cx.VIPBirthdayType = 2) AND (@VBirBeginM <= GETDATE() AND DATEADD(D, 1, @VBirEndM) > GETDATE())))))   --会员生日*/
							/*这儿cx.cxDayType = 4的时候永远为false*/
    ORDER BY XMLID DESC    
       
  DECLARE @RecNo INT, @cp_id INT  
  
  /*从厂家类别中提取商品  */
  SELECT identity(int, 1, 1) as RecNo, cx.billid, cx.XMLID, cx.SchemeName, cx.guid, cx.billtype, cx.billstate, cx.Ytype, cx.YIDs, cx.cardtype, cx.begindate, cx.enddate, cx.cxDayType, cx.GreCalendars, 
                      cx.CHNCalendars, cx.WeekDays, cx.VIPBirthdayType, cx.VIPBuyTimeLmt, cx.VIPBuyMPB, cx.cp_id, cx.RowFlag, cx.PGQtyPerBillLmt, cx.UseSamePre, cx.UseSameDisc, 
                      cx.InOtherNotSel, cx.discountType, cx.GroupNum, cx.InGroupNum, cx.GroupQty, cx.LowQty, cx.HighQty, cx.ValueSet, cx.SelType, cx.p_id, cx.PGLmtFlag, cx.BeginTime, 
                      cx.EndTime, cx.unit_id, cx.price, cx.PriceType, cx.discount, cx.lownum, cx.billlimit, cx.cardlimit, cx.CardLimitDay, cx.daylimit, cx.cxLimit, cx.Itgrate, cx.presenttype, p.product_id PID, p.unit1_id U_ID, (cx.cp_id * 1000 + cx.XMLID) CPID INTO #Factory 
    FROM CxDetail cx INNER JOIN products p on cx.p_id = p.factoryc_id
      WHERE cx.XMLID IN (SELECT DISTINCT XMLID FROM #cxBill) AND cx.SelType = 2
      
  /*处理按厂家提取商品后的组合编号  */
  DECLARE cur_Factory CURSOR FOR SELECT RecNo, cp_id FROM #Factory WHERE 1=1
  OPEN cur_Factory
  FETCH NEXT FROM cur_Factory INTO @RecNo, @cp_id
  WHILE @@FETCH_STATUS = 0
  BEGIN
    /*仅厂家折扣需要重排组合编号*/
    IF @cp_id = @ctByFDiscount
      UPDATE #Factory SET GroupNum = @RecNo WHERE RecNo = @RecNo
    FETCH NEXT FROM cur_Factory INTO @RecNo, @cp_id
  END 
  CLOSE cur_Factory
  DEALLOCATE cur_Factory
  
  
  /*xxx.2017-04-26 新的自定义类别处理读取促销明细*/
  
  /*
	DECLARE @szsql varchar(MAX)
	declare @cColName VARCHAR(20)
	declare @i int
	set @i = 1 
	set @szsql = ''
	while @i <= 50
	begin	
		set @cColName = dbo.GetColName(@i,'ProductCategory') 
		IF @i = 50
			set @szsql = @szsql +
			'select x.* from 			
			(select cx.*,c.Category_id,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = '+CAST(@i AS VARCHAR) +') x
			inner join ProductCategory p on x.class_id =  left(p.'+ @cColName +',LEN(x.class_id))' 
		
		ELSE
			set @szsql = @szsql +
			'select x.* from 			
			(select cx.*,c.Category_id,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = '+CAST(@i AS VARCHAR) +') x
			inner join ProductCategory p on x.class_id =  left(p.'+ @cColName +',LEN(x.class_id))' 
			+ 'UNION ALL   '
			
	  set @i = @i +1
	end

	PRINT @szsql
	EXEC(@szsql) 
  */
  
   SELECT identity(int, 1, 1) as RecNo, tmp.billid, tmp.XMLID, tmp.SchemeName, tmp.guid, tmp.billtype, tmp.billstate, tmp.Ytype, tmp.YIDs, tmp.cardtype, tmp.begindate, tmp.enddate, tmp.cxDayType, tmp.GreCalendars, 
                      tmp.CHNCalendars, tmp.WeekDays, tmp.VIPBirthdayType, tmp.VIPBuyTimeLmt, tmp.VIPBuyMPB, tmp.cp_id, tmp.RowFlag, tmp.PGQtyPerBillLmt, tmp.UseSamePre, tmp.UseSameDisc, 
                      tmp.InOtherNotSel, tmp.discountType, tmp.GroupNum, tmp.InGroupNum, tmp.GroupQty, tmp.LowQty, tmp.HighQty, tmp.ValueSet, tmp.SelType, tmp.p_id, tmp.PGLmtFlag, tmp.BeginTime, 
                      tmp.EndTime, tmp.unit_id, tmp.price, tmp.PriceType, tmp.discount, tmp.lownum, tmp.billlimit, tmp.cardlimit, tmp.CardLimitDay, tmp.daylimit, tmp.cxLimit, tmp.Itgrate, tmp.presenttype,
					  tmp.PID, p.unit1_id as U_ID, tmp.CPID
   INTO #Custom 
     
  from (
 
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 1 ) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent1],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 2) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent2],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 3) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent3],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 4) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent4],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 5) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent5],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 6) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent6],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 7) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent7],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 8) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent8],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 9) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent9],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 10) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent10],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 11) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent11],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 12) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent12],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 13) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent13],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 14) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent14],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 15) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent15],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 16) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent16],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 17) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent17],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 18) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent18],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 19) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent19],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 20) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent20],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 21) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent21],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 22) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent22],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 23) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent23],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 24) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent24],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 25) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent25],LEN(x.class_id))	

		UNION ALL
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 26) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent26],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 27) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent27],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 28) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent28],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 29) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent29],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 30) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent30],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 31) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent31],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 32) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent32],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 33) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent33],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 34) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent34],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 35) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent35],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 36) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent36],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 37) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent37],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 38) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent38],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 39) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent39],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 40) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent40],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 41) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent41],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 42) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent42],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 43) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent43],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 44) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent44],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 45) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent45],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 46) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent46],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 47) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent47],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 48) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent48],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 49) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent49],LEN(x.class_id))	
		UNION ALL	
		select x.*,p.p_id PID, 0 as U_ID, (x.cp_id * 1000 + X.XMLID) CPID from 			
				(select cx.*,c.class_id from CxDetail cx ,customCategory c where cx.p_id = c.id and cx.SelType = 1 and c.Category_id = 50) x
				inner join ProductCategory p on x.class_id =  left(p.[PComent50],LEN(x.class_id))	

	
  ) tmp
  left join products p on tmp.PID = p.product_id
  
 /*       
  --从自定义类别提取商品
  SELECT identity(int, 1, 1) as RecNo, cx4.*, cm4.baseinfo_id PID, P.unit1_id U_ID, (cx4.cp_id * 1000 + cx4.XMLID) CPID INTO #Custom 
    FROM CxDetail cx4 INNER JOIN 
    (
      SELECT cx3.billid, cm3.baseinfo_id FROM customCategoryMapping cm3 INNER JOIN 
      (    
        SELECT cx2.billid, cm2.id FROM customCategory cm2 INNER JOIN 
        (    
          SELECT cx1.billid, cm1.class_id 
            FROM CxDetail cx1 LEFT JOIN customCategory cm1 ON cx1.p_id = cm1.id 
              WHERE cx1.XMLID IN (SELECT DISTINCT XMLID FROM #cxBill) AND cx1.SelType = 1 and cm1.deleted = 0    
        ) cx2 ON cm2.class_id LIKE cx2.class_id + '%' WHERE cm2.deleted = 0
      ) cx3 on cm3.category_id = cx3.id WHERE cm3.deleted = 0 and cm3.BaseTypeid = 0 --XXX. 这儿需要加上商品的类型条件（0表示商品）
    ) cm4 ON cx4.billid = cm4.billid 
    LEFT JOIN products p on cm4.baseinfo_id = p.product_id
  */
  /*XXX. bug——42712 剔除重复的商品项 2016-11-14 */
  DELETE FROM #Custom WHERE RecNo NOT IN (
	SELECT MAX(RecNo) from #Custom group by XMLID,cp_id,RowFlag,GroupNum,InGroupNum,SelType,PID,unit_id,presenttype,CPID
	) 
  
  /*处理提取商品后的组合编号*/
  DECLARE cur_custom CURSOR FOR SELECT RecNo, cp_id FROM #Custom WHERE 1=1
  OPEN cur_custom
  FETCH NEXT FROM cur_custom INTO @RecNo, @cp_id
  WHILE @@FETCH_STATUS = 0
  BEGIN
    /*仅类别折扣需要重排组合编号*/
    IF @cp_id = @ctByCDiscount
      UPDATE #Custom SET GroupNum = @RecNo WHERE RecNo = @RecNo
    FETCH NEXT FROM cur_custom INTO @RecNo, @cp_id
  END 
  CLOSE cur_custom
  DEALLOCATE cur_custom
    
  /*汇总商品*/
  SELECT  cx.* into #FinalData FROM
  (
    /*商品    */
    SELECT 0 as RecNO,billid, XMLID, SchemeName, guid, billtype, billstate, Ytype, YIDs, cardtype,begindate, enddate, cxDayType, GreCalendars, 
                      CHNCalendars, WeekDays, VIPBirthdayType, VIPBuyTimeLmt, VIPBuyMPB, cp_id, RowFlag, PGQtyPerBillLmt, UseSamePre, UseSameDisc, 
                      InOtherNotSel, discountType, GroupNum, InGroupNum, GroupQty,LowQty, HighQty, ValueSet, SelType, p_id, PGLmtFlag, BeginTime, 
                      EndTime, unit_id, price, PriceType, discount, lownum, billlimit, cardlimit, CardLimitDay, daylimit, cxLimit, Itgrate, presenttype, p_id PID, unit_id as U_ID, (cp_id * 1000 + XMLID) CPID FROM CxDetail 
      WHERE XMLID IN (SELECT DISTINCT XMLID FROM #cxBill) AND (SelType = 0 or SelType = 3)
    UNION ALL
    /*自定义类别        */
    SELECT * FROM #Custom WHERE 1=1
    UNION ALL 
    /*厂家*/
    SELECT * FROM #Factory WHERE 1=1    
  ) cx
  WHERE 1=1 Order by cx.CPID ASC, cx.GroupNum ASC, cx.GroupQty DESC, cx.LowQty ASC, cx.PID ASC    
  
	/*XXX. BUG_43374  剔除重复的促销方案 （价格促销限量的时候只能执行最新的一种促销方案） 2016-12-05*/
	/*这儿处理价格促销，可以用billid 来唯一标识*/
  DELETE FROM #FinalData WHERE billid NOT IN (
	SELECT MAX(billid) from #FinalData where cp_id = 10 group by cp_id,PID,unit_id)
	AND cp_id = 10  
  
  /*处理满量赠统一买赠*/
  DECLARE @GroupNum int 
  DECLARE cur_ctByEnoughQty CURSOR FOR SELECT Distinct GroupNum FROM #FinalData where cp_id = @ctByEnoughQty and RowFlag = 0 and UseSamePre = 1
  OPEN cur_ctByEnoughQty
  FETCH NEXT FROM cur_ctByEnoughQty INTO @GroupNum
  WHILE @@FETCH_STATUS = 0
  BEGIN
    /*复制满量赠统一买赠赠品，并更改组合编号   */
    IF @GroupNum > 0     
      INSERT INTO #FinalData            
        (RecNO, billid, XMLID, SchemeName, [GUID], billtype, billstate, Ytype, YIDs, cardtype, begindate, enddate, cxDayType,  
         GreCalendars, CHNCalendars, WeekDays, VIPBirthdayType, VIPBuyTimeLmt, VIPBuyMPB, cp_id, RowFlag, PGQtyPerBillLmt, 
         UseSamePre, UseSameDisc, InOtherNotSel,  discountType, GroupNum, InGroupNum, GroupQty, LowQty, HighQty, ValueSet, 
         SelType, p_id, PGLmtFlag, BeginTime, EndTime, unit_id, price, PriceType, discount, lownum, billlimit, cardlimit, 
         CardLimitDay, daylimit, cxLimit, Itgrate, presenttype, PID, U_ID, CPID)                                      
      SELECT RecNO, billid, XMLID, SchemeName, [GUID], billtype, billstate, Ytype, YIDs, cardtype, begindate, enddate, cxDayType, 
         GreCalendars, CHNCalendars, WeekDays, VIPBirthdayType, VIPBuyTimeLmt, VIPBuyMPB, cp_id, RowFlag, PGQtyPerBillLmt, 
         UseSamePre, UseSameDisc, InOtherNotSel,  discountType, @GroupNum, InGroupNum, GroupQty, LowQty, HighQty, ValueSet, 
         SelType, p_id, PGLmtFlag, BeginTime, EndTime, unit_id, price, PriceType, discount, lownum, billlimit, cardlimit, 
         CardLimitDay, daylimit, cxLimit, Itgrate, presenttype, PID, U_ID, CPID
      FROM #FinalData WHERE cp_id = @ctByEnoughQty and RowFlag = 1 and UseSamePre = 1 and GroupNum = 0   
    
    FETCH NEXT FROM cur_ctByEnoughQty INTO @GroupNum
  END 
  CLOSE cur_ctByEnoughQty
  DEALLOCATE cur_ctByEnoughQty
  /*处理完后，删除原有的统一买赠赠品*/
  DELETE #FinalData WHERE cp_id = @ctByEnoughQty and RowFlag = 1 and UseSamePre = 1 and GroupNum = 0
  /*XXX.2016-11-29  对商品折扣的价格类型处理（兼容独立物价）*/
  if exists(select 1 from company where company_id = @Y_ID and swarajPrice = 1)
  begin
	  update #FinalData  set price = case PriceType when 0 then pp.retailprice when 1 then pp.price1 
							when 2 then pp.price2 when 3 then pp.price3
							when 4 then pp.price4 when 5 then pp.gpprice
							when 6 then pp.glprice end  from (select * from PosPrice where Y_ID = @Y_ID) pp  
	  where #FinalData.cp_id = 70 and #FinalData.p_id = pp.p_id
  end
  
  /*所有处理步骤结束后，返回数据集*/
  /*SELECT * FROM #FinalData*/
  
  /*考虑几个限量*/
  SELECT RecNO, billid, XMLID, SchemeName, [GUID], billtype, billstate, Ytype, YIDs, cardtype, begindate, enddate, cxDayType,  
         GreCalendars, CHNCalendars, WeekDays, VIPBirthdayType, VIPBuyTimeLmt, VIPBuyMPB, cp_id, RowFlag, PGQtyPerBillLmt, 
         UseSamePre, UseSameDisc, InOtherNotSel,  discountType, GroupNum, InGroupNum, GroupQty, LowQty, HighQty, ValueSet, 
         SelType, p_id, PGLmtFlag, BeginTime, EndTime, unit_id, price, PriceType, discount, lownum, Itgrate, presenttype, 
         ISNULL(PID, 0) PID, ISNULL(U_ID, 0) U_ID, CPID,
         billlimit, cardlimit, CardLimitDay, 
         (Case when cx.daylimit = 0 then 0 
               else 
               (Case when ISNULL((cx.daylimit - ISNULL(cx.cxTodaySale,0)), 0) <= 0 then -1 else ISNULL((cx.daylimit - ISNULL(cx.cxTodaySale,0)), 0) end)
          end) daylimit,           
         (Case when cx.cxLimit = 0 then 0
               else
               (case when ISNULL((cx.cxLimit - ISNULL(cx.cxSale,0)), 0) <= 0 then -1 else ISNULL((cx.cxLimit - ISNULL(cx.cxSale,0)), 0) end)
          end) cxLimit
  FROM 
  (
  SELECT * FROM #FinalData FD 
  LEFT JOIN /*每日限量  */
  (
  SELECT b.CxGuid BLGUID, ISNULL(SUM(b.quantity), 0) cxTodaySale from salemanagebill b inner join billidx i on b.bill_id = i.billid  
    WHERE 1=1 /*AND b.CxGuid = @cxGuid 		        */
	  and (i.billdate BETWEEN CONVERT(varchar(10), Getdate(), 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59') 
	  and i.billstates = 0 and i.billtype in (10, 210, 12) 
      and (i.Y_ID = @Y_ID)
    GROUP BY B.CxGuid
  ) BL ON FD.guid = BL.BLGUID
  /* 
  LEFT JOIN   --每卡限量，因本PRO现有设计逻辑没有卡，卡限量暂缓 
  (
  SELECT ISNULL(SUM(b.quantity), 0) cxTodaySale from salemanagebill b INNER JOIN billidx i on b.bill_id = i.billid -- 每卡限量
		                                                              INNER JOIN cxDetail x on b.cxGuid = x.Guid
			      WHERE 1=1 --AND b.CxGuid = @cxGuid 
			        AND ((x.CardLimitDay = 0) or 
			             ((x.cardlimitDay > 0) and (i.billdate BETWEEN CONVERT(varchar(10), Getdate() - X.CardLimitDay + 1, 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59'))) 
			        AND i.billstates = 0 and i.billtype in (10, 210, 12) and i.VIPCardID = @vipCard	
  ) CL on 			        
  */   	
  LEFT JOIN /* 活动限量*/
  (		        
  SELECT b.CxGuid ALGUID, ISNULL(SUM(b.quantity), 0) cxSale from salemanagebill b inner join billidx i on b.bill_id = i.billid 
    WHERE 1=1 /*AND b.CxGuid = @cxGuid */
	  AND i.billstates = 0 and i.billtype in (10, 210, 12) and b.Y_ID = @Y_ID	
	  GROUP BY B.CxGuid		      
  ) AL on FD.guid = AL.ALGUID
  ) cx   
  Order by cx.CPID ASC, cx.GroupQty DESC,cx.GroupNum ASC, cx.LowQty ASC, cx.PID ASC    
  
  /*XXX.2016-12-30  bug_44501 这儿排序的优先级让满*赠数量 大于组合编号，实现最优的促销方式         				  */
 
  set datefirst @nFirstDay 
   
  /*删除临时表*/
  IF object_id(N'#Custom', N'U') is not null  
    DROP TABLE #Custom
  IF object_id(N'#Factory', N'U') is not null  
    DROP TABLE #Factory
  IF object_id(N'#cxBill', N'U') is not null  
    DROP TABLE #cxBill 
  IF object_id(N'#FinalData', N'U') is not null  
    DROP TABLE #FinalData   
  IF object_id(N'#ids', N'U') is not null  
    DROP TABLE #ids   
                                                                           		        
END
GO
