/**************************************************************
记录签到信息
**************************************************************/

create proc WebAPP_SignIn
(
  @userid int=0,
  @e_id INT=0,  
  @ename varchar(60)='',
  @longitude varchar(20)='',
  @latitude varchar(20)='',
  @address varchar(200)='',
  @typeflag int=1, --1上班 2下班  0  查询打卡记录
  @comment  varchar(100)='',
  @starttime varchar(10)='',
  @endtime varchar(10)='',
  @params VARCHAR(100),  
  @RetMessage varchar(200) out
)
as
BEGIN
	IF @typeflag IN (1,2)
	BEGIN
		set @RetMessage = '操作成功'
		  INSERT INTO TeenySoftMaster.dbo.WebAPP_SignIn(userid,e_id,ename,longitude,latitude,StreetAddress,Typeflag,comment,CreateTime)
		  select @userid,@e_id,@ename,@longitude,@latitude,@address,@typeflag,@comment,getdate()
		  IF @@ERROR>0
		  BEGIN
		  RETURN -1
  			set @RetMessage = '签到失败'
		  END
		  RETURN 1
	END
	ELSE IF @typeflag IN (0)
	BEGIN
		SELECT longitude,latitude,StreetAddress AS address,CreateTime AS time,Typeflag AS type FROM TeenySoftMaster.dbo.WebAPP_SignIn 
		WHERE e_id=@e_id 
		AND (ISNULL(@starttime,'')='' OR CONVERT(VARCHAR(10),CreateTime,120)>=CONVERT(VARCHAR(20),@starttime,120))
		AND (ISNULL(@endtime,'')='' OR CONVERT(VARCHAR(10),CreateTime,120)<=CONVERT(VARCHAR(10),@endtime,120))
		ORDER BY CreateTime DESC
	END
  
end
GO
