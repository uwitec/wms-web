CREATE procedure [dbo].[ts_y_qrClientYw]
( 
    @szListFlag		VARCHAR(1)='L',        /*分级显示*/
    @szParent_ID	VARCHAR(30)='',   /*产品父类ID */
    @nloginEID      int=0,
	@BeginDate   	VARCHAR(30),/*开始时间*/
	@EndDate	    VARCHAR(30),/*结束时间 */
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szEClass_ID	VARCHAR(30)='',/*经手人ID*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人IDs*/
	@szSClass_ID	VARCHAR(30)='',/*库房ID*/
	@nLocation_Id   VARCHAR(30)='',        /*货位ID*/
	@Department_ID  varchar(30)='',/*部门*/
	@szRClass_id   varchar(50) = '', /*片区 */
	@nYClassid     varchar(100)=''
)
/*with encryption*/
as
/*Params Ini begin*/
if @szCClass_id is null  SET @szCClass_id = '%%'
if @szCClass_id =''  SET @szCClass_id = '%%'
if @szEClass_id is null  SET @szEClass_id = '%%'
if @szEClass_id ='' SET @szEClass_id = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szParent_id =''  SET @szParent_id = '000000'
if @szListflag is null  SET @szListflag = 'L'
if @szListflag =''  SET @szListflag = 'L'

if @nYClassid is null  SET @nYClassid = ''


if @nloginEID is null  SET @nloginEID = 0
declare  @nRegion_id int
set @nRegion_id=isnull((select region_id from Region where class_id=@szRClass_id),0)

declare @e_id int,@inputman int,@bst int
/*set @e_id     =isnull((select emp_id from employees where class_id=@szEClass_ID),0)*/
set  @e_id=CONVERT(int,isnull(@szEClass_ID,0))
set @inputman =isnull((select emp_id from employees where class_id=@szInputClass_ID),0)

/*Params Ini end*/

set nocount on
declare @szsql varchar(8000),@szsql2 varchar(8000)
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
create table #t1
     ( 
      billid        int ,
      billdate      datetime,
      billtype      int,
      a_id          int,
      c_id          int,
      e_id          int,
      inputman      int,
      billstates    varchar(2),
      region_id     int,
      Y_ID          int
      )
create table #t2
     (
      class_id        varchar(100) ,
      client_id       int,
      name            varchar(100) , 
      beginArTotal    NUMERIC(25,8),
      beginApTotal    NUMERIC(25,8),
      endArTotal      NUMERIC(25,8),
      endApTotal      NUMERIC(25,8),
      nowArTotal      NUMERIC(25,8),
      nowApTotal      NUMERIC(25,8),
      saleTotal       NUMERIC(25,8),
      totalmoney      NUMERIC(25,8),
      taxmoney        NUMERIC(25,8),
      SendTotal       NUMERIC(25,8),
      costtotal       NUMERIC(25,8),
      hkTotal         NUMERIC(25,8),
      artotal         NUMERIC(25,8),
      aptotal         NUMERIC(25,8),
      arlimit         NUMERIC(25,8),
      aplimit         NUMERIC(25,8),
      contact_personal varchar(100) ,
      ename            varchar(100) ,
      serial_number    varchar(100) ,
      child_number     varchar(100) ,
      cename           varchar(100) ,
      regionname       varchar(100) ,
      clienttypename   varchar(100) ,
      alias            varchar(100) ,
      feeTotal        NUMERIC(25,8),
      otherTotal      NUMERIC(25,8),
      ttotalmoney     NUMERIC(25,8),
      tcosttotal      NUMERIC(25,8)
      )
if  @e_id =0 and @inputman=0 
begin
   insert into #t1 
   select billid,billdate,billtype,a_id,c_id,e_id,inputman,billstates,region_id,Y_ID
   from billidx where  billstates='0'
   set @bst=0
end 
if  @e_id =0 and @inputman<>0 
begin
   insert into #t1 
   select billid,billdate,billtype,a_id,c_id,e_id,inputman,billstates,region_id,Y_ID
   from billidx  where inputman=@inputman and billstates='0'
   set @bst=1
end 
if  @e_id <>0 and @inputman=0 
begin
   insert into #t1 
   select billid,billdate,billtype,a_id,c_id,e_id,inputman,billstates,region_id,Y_ID
   from billidx  where e_id=@e_id and billstates='0'
   set @bst=2
end
if  @e_id <>0 and @inputman<>0 
begin
   insert into #t1 
   select billid,billdate,billtype,a_id,c_id,e_id,inputman,billstates,region_id,Y_ID
   from billidx  where e_id=@e_id and inputman=@inputman and billstates='0'
   set @bst=3
end    
  
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


  Declare  @AR_ID   VARCHAR(30), @AP_ID   VARCHAR(30)
  SELECT @AR_ID='000001000005', @AP_ID='000002000001'

		declare @nCid int
		declare @nClassLen int
		if @szListflag = 'P'
			set @nClassLen = 30
		else
		if @szListflag = 'L'
		begin
			if @szParent_id in ('', '000000')
				set @nClassLen = 6
			else
				set @nClassLen = LEN(@szParent_id) + 6
		end
		
		select @nCid = client_id from clients where class_id = @szCClass_id
		select company_id into #tmpYid from company where deleted = 0 and class_id like @nYClassid + '%' and (@Companytable = 0 OR company_id in (select ID from #Companytable))     
		if @szListflag = 'A'
		begin
		 insert into #t2 
         SELECT     e.class_id, e.emp_id AS client_id, e.name, CASE WHEN ISNULL(ini.jd, 0) > 0 THEN ini.jd ELSE 0 END AS beginArTotal, 
                      CASE WHEN ISNULL(ini.jd, 0) < 0 THEN - ini.jd ELSE 0 END AS beginApTotal, CASE WHEN ISNULL(ed.jd, 0) > 0 THEN ed.jd ELSE 0 END AS endArTotal, 
                      CASE WHEN ISNULL(ed.jd, 0) < 0 THEN - ed.jd ELSE 0 END AS endApTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) > 0 THEN ISNULL(ed.jd, 0) 
                      - ISNULL(ini.jd, 0) ELSE 0 END AS nowArTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) < 0 THEN ISNULL(ini.jd, 0) - ISNULL(ed.jd, 0) 
                      ELSE 0 END AS nowApTotal, ISNULL(sl.sale, 0) AS saleTotal, ISNULL(sd.totalmoney, 0) AS totalmoney, ISNULL(sd.taxmoney, 0) AS taxmoney, 
                      CAST(ISNULL(sd.SendTotal, 0) AS NUMERIC(25,8)) AS SendTotal, ISNULL(sd.SendCostTotal, 0) AS costtotal, ISNULL(hk.jdmoney, 0) AS hkTotal, e.artotal, 
                      e.aptotal, e.arlimit, e.aplimit, ' ' AS contact_personal, ' ' AS ename, e.serial_number, e.child_number, ' ' AS cename, ' ' AS regionname, 
                      ' ' AS clienttypename, e.alias, ISNULL(fe.fee, 0) AS feeTotal, ISNULL(ot.other, 0) AS otherTotal
                      ,ISNULL(sd.ttotalmoney, 0) AS ttotalmoney, ISNULL(sd.tSendCostTotal, 0) AS tcosttotal
                      FROM         dbo.employees AS e LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, i.e_id
                            FROM          /*-dbo.billidx AS i INNER JOIN*/
                                             #t1 AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   dbo.employees AS e ON i.e_id = e.emp_id
                                                   /*INNER JOIN dbo.employees AS e1 ON i.inputman = e1.emp_id*/
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate < @BeginDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))
                                                 /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                   )
                            GROUP BY i.e_id) AS ini ON e.emp_id = ini.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, i.e_id
                            FROM          /*dbo.billidx AS i INNER JOIN*/
                                            #t1 AS i INNER JOIN       
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   dbo.employees AS e ON i.e_id = e.emp_id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate <= @EndDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))
                                                 /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                   )
                            GROUP BY i.e_id) AS ed ON e.emp_id = ed.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS sale, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   /*dbo.billidx AS i ON ad.billid = i.billid*/
                                                   #t1 AS i ON ad.billid = i.billid
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billdate >= @BeginDate AND  i.billdate <= @EndDate) AND 
                                                   (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (ad.a_id = 20) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))
                                                 /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                   )
                            GROUP BY i.e_id) AS sl ON e.emp_id = sl.e_id LEFT OUTER JOIN
                          (SELECT     e_id, SUM(totalmoney * dir) AS totalmoney, SUM(taxmoney * dir) AS taxmoney, SUM(SendQTY * dir) AS SendQTY, SUM(SendTotal * dir) 
                                                   AS SendTotal, SUM(SendCostTotal * dir) AS SendCostTotal,
                                                   SUM(totalmoney * tdir) AS ttotalmoney ,SUM(SendCostTotal * tdir) AS tSendCostTotal
                            FROM          (SELECT     i.e_id, sb.totalmoney, sb.taxmoney, sb.SendQTY, sb.totalmoney / sb.quantity * sb.SendQTY AS SendTotal, sb.SendCostTotal, 
                                                                           CASE WHEN i.billtype IN (10,12,16,112,53,212) THEN 1 ELSE 0 END AS dir,
                                                                           CASE WHEN i.billtype IN (11,13,15,17,32,54)   THEN -1 ELSE 0 END AS tdir
                                                    FROM           #t1 AS i INNER JOIN /*dbo.billidx AS i INNER JOIN*/
                                                                           salemanagebill AS sb ON i.billid = sb.bill_id
                                                    WHERE      (i.billtype IN (10, 11, 12, 13, 15, 16, 17, 32, 112, 53, 54, 212)) 
                                                              /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                                AND (i.billdate >= @BeginDate AND i.billdate <= @EndDate) AND (sb.p_id > 0) AND 
                                                                           (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))) AS snd
                            GROUP BY e_id) AS sd ON e.emp_id = sd.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS jdmoney, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid
                            WHERE      (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account
                                                         WHERE      (account_id = 6) OR
                                                                                (class_id LIKE '000001000004%'))) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND 
                                                   (i.billdate >= @BeginDate AND i.billdate  <= @EndDate) AND 
                                                   (@szCClass_id IN ('%%','') or i.c_id = @nCid) 
                                               /*    and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                    AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id)
                            GROUP BY i.e_id) AS hk ON e.emp_id = hk.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS fee, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_2
                                                         WHERE      (class_id LIKE '000004000003%'))) 
                                                                 /*   and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                                    AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid))
                            GROUP BY i.e_id) AS fe ON e.emp_id = fe.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS other, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) 
                                      /* and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                       AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_1
                                                         WHERE      (class_id LIKE '000003000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid))
                            GROUP BY i.e_id) AS ot ON e.emp_id = ot.e_id
                      WHERE     (e.emp_id > 1) AND (e.deleted = 0) AND (e.child_number = 0) 
                     order by e.emp_id
		end
		else
		begin
			select * into #tmpEidL from getsubnodes(@szParent_id, 'L', 'E', 0)
			select * into #tmpEidP from getsubnodes(@szParent_id, 'P', 'E', 0)
			
			select top 0 0 as emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted into #tmpE from employees
			if @szListflag = 'L'
				insert into #tmpE select emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted from employees where emp_id in (select id from #tmpEidL)
			else
			if @szListflag = 'P'
				insert into #tmpE select emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted from employees where emp_id in (select id from #tmpEidP)
	        insert into #t2 			
	         SELECT     e.class_id, e.emp_id AS client_id, e.name, CASE WHEN ISNULL(ini.jd, 0) > 0 THEN ini.jd ELSE 0 END AS beginArTotal, 
						  CASE WHEN ISNULL(ini.jd, 0) < 0 THEN - ini.jd ELSE 0 END AS beginApTotal, CASE WHEN ISNULL(ed.jd, 0) > 0 THEN ed.jd ELSE 0 END AS endArTotal, 
						  CASE WHEN ISNULL(ed.jd, 0) < 0 THEN - ed.jd ELSE 0 END AS endApTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) > 0 THEN ISNULL(ed.jd, 0) 
						  - ISNULL(ini.jd, 0) ELSE 0 END AS nowArTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) < 0 THEN ISNULL(ini.jd, 0) - ISNULL(ed.jd, 0) 
						  ELSE 0 END AS nowApTotal, ISNULL(sl.sale, 0) AS saleTotal, ISNULL(sd.totalmoney, 0) AS totalmoney, ISNULL(sd.taxmoney, 0) AS taxmoney, 
						  CAST(ISNULL(sd.SendTotal, 0) AS NUMERIC(25,8)) AS SendTotal, ISNULL(sd.SendCostTotal, 0) AS costtotal, ISNULL(hk.jdmoney, 0) AS hkTotal, rp.artotal, 
						  rp.aptotal, e.arlimit, e.aplimit, ' ' AS contact_personal, ' ' AS ename, e.serial_number, e.child_number, ' ' AS cename, ' ' AS regionname, 
						  ' ' AS clienttypename, e.alias, ISNULL(fe.fee, 0) AS feeTotal, ISNULL(ot.other, 0) AS otherTotal
						  ,ISNULL(sd.ttotalmoney, 0) AS ttotalmoney, ISNULL(sd.tSendCostTotal, 0) AS tcosttotal
	        FROM         (select * from #tmpE) AS e LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, Left(e.class_id, @nClassLen) as class_id
                            FROM          #t1 AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) 
                                      /* and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman) */
                                       AND (ad.a_id IN (9, 15)) AND (i.billdate < @BeginDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY Left(e.class_id, @nClassLen)) AS ini ON e.class_id = ini.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, Left(e.class_id, @nClassLen) as class_id
                            FROM          #t1 AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) 
                                       /* and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                        AND (ad.a_id IN (9, 15)) AND (i.billdate <= @EndDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY Left(e.class_id, @nClassLen)) AS ed ON e.class_id = ed.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS sale, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) 
                                      /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                        AND (i.billdate >= @BeginDate AND i.billdate <=@EndDate) AND 
                                                   (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (ad.a_id = 20) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY Left(e.class_id, @nClassLen)) AS sl ON e.class_id = sl.class_id LEFT OUTER JOIN
                          (SELECT     class_id, SUM(totalmoney * dir) AS totalmoney, SUM(taxmoney * dir) AS taxmoney, SUM(SendQTY * dir) AS SendQTY, SUM(SendTotal * dir) 
                                                   AS SendTotal, SUM(SendCostTotal * dir) AS SendCostTotal
                                                   ,SUM(totalmoney * tdir) AS ttotalmoney ,SUM(SendCostTotal * tdir) AS tSendCostTotal
                            FROM          (SELECT     Left(e.class_id, @nClassLen) as class_id, sb.totalmoney, sb.taxmoney, sb.SendQTY, sb.totalmoney / sb.quantity * sb.SendQTY AS SendTotal, sb.SendCostTotal, 
                                                                           CASE WHEN i.billtype IN (10,12,16,112,53,212) THEN 1 ELSE 0 END AS dir,
                                                                           CASE WHEN i.billtype IN (11,13,15,17,32,54) THEN -1 ELSE 0 END AS tdir
                                                    FROM          #t1 AS i INNER JOIN
                                                                           salemanagebill AS sb ON i.billid = sb.bill_id INNER JOIN
																		   #tmpEidP AS e ON i.e_id = e.id
                                                    WHERE      (i.billtype IN (10, 11, 12, 13, 15, 16, 17, 32, 112, 53, 54, 212)) 
                                                           /*    and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                                AND (i.billdate >=@BeginDate AND i.billdate <=@EndDate) AND (sb.p_id > 0) AND
                                                                           (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))) AS snd
                            GROUP BY class_id) AS sd ON e.class_id = sd.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS jdmoney, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account
                                                         WHERE      (account_id = 6) OR
                                                                                (class_id LIKE '000001000004%'))) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND 
                                                   (i.billdate >= @BeginDate AND i.billdate <= @EndDate) AND 
                                                   (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') 
                                                 /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                                   AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id)
                            GROUP BY Left(e.class_id, @nClassLen)) AS hk ON e.class_id = hk.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS fee, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid)
                                      /* and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                       AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_2
                                                         WHERE      (class_id LIKE '000004000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND
                                                         (i.billdate >= @BeginDate AND i.billdate <= @EndDate)
                            GROUP BY Left(e.class_id, @nClassLen)) AS fe ON e.class_id = fe.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS other, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   #t1 AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid)
                                     /*  and (i.e_id=0 or i.e_id=@e_id) and (i.inputman =0 or i.inputman=@inputman)*/
                                        AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_1
                                                         WHERE      (class_id LIKE '000003000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND
                                                         (i.billdate >= @BeginDate AND i.billdate <= @EndDate)
                            GROUP BY Left(e.class_id, @nClassLen)) AS ot ON e.class_id = ot.class_id LEFT OUTER JOIN
                           (SELECT     Left(e.class_id, @nClassLen) as class_id, CASE WHEN SUM(aptotal) - SUM(artotal) > 0 THEN SUM(aptotal) - SUM(artotal) ELSE 0 END AS aptotal, CASE WHEN SUM(aptotal) - SUM(artotal) < 0 THEN SUM(artotal) - SUM(aptotal) ELSE 0 END AS artotal
							FROM         dbo.employees i INNER JOIN #tmpEidP AS e ON i.emp_id = e.id
							GROUP BY Left(e.class_id, @nClassLen)) AS rp ON e.class_id = rp.class_id
	         WHERE     (e.emp_id > 1) AND (e.deleted = 0)  
	        
	        order by e.emp_id  
  end
  declare @sSql varchar(800)
  set @sSql='  select name as 经手人,beginArTotal as 期初应收金额,beginApTotal as 期初应付金额,endArTotal as 期末应收金额,endApTotal as 期末应付金额,
  nowArTotal as 本期应收金额,nowApTotal as 本期应付金额,saleTotal as 销售收入,--,totalmoney 
  taxmoney as 税额,SendTotal as 已发销售金额,costtotal as 已发成本金额, isnull((SendTotal-costtotal),0) as 销售毛利,
  -ttotalmoney as  退货金额,-tcosttotal as 退货成本,abs(isnull((ttotalmoney-tcosttotal),0)) as 退货毛利,
  hkTotal as 回款金额,artotal as 应收金额,aptotal as 应付金额,
   feeTotal as 费用合计,otherTotal as 其他收入,convert(numeric(18,2),(SendTotal+ttotalmoney-otherTotal)) as 本期创收,
   arlimit as 应收上限,aplimit as 应付上限  '
  if @bst=0 /*全部  经手人 制单人*/
      set @sSql=@sSql+' from  #t2'  
  if @bst>0 
    set @sSql=@sSql+' from  #t2   where client_id in(select distinct  e_id from #t1) '   
  exec(@sSql)
  drop table #t1
  drop table #t2
  drop table #Clienttable
  drop table #Companytable
  drop table #employeestable
GO
