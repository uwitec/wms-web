


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

查询、修改和删除内部结算商品的价格

********************************************/
CREATE PROCEDURE [TS_X_RepProductJSPrice]
( @lMode        INT=0,
  @nID          INT=0, 
  @lProductID   INT=0,
  @lClientID    INT=0,
  @lStorageID   INT=0,
  @lEmployeeID  INT=0,
  @dJSPrice     NUMERIC(25,8)=0,
  @dLowPrice    NUMERIC(25,8)=0,
  @dSalePrice   NUMERIC(25,8)=0,
  @szPassword   VARCHAR(20)='',
  @szComment    VARCHAR(200)='',
  @ModfilyDate  datetime
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @lMode is null  SET @lMode = 0
if @nID is null  SET @nID = 0
if @lProductID is null  SET @lProductID = 0
if @lClientID is null  SET @lClientID = 0
if @lStorageID is null  SET @lStorageID = 0
if @lEmployeeID is null  SET @lEmployeeID = 0
if @dJSPrice is null  SET @dJSPrice = 0
if @dLowPrice is null  SET @dLowPrice = 0
if @dSalePrice is null  SET @dSalePrice = 0
if @szPassword is null  SET @szPassword = ''
if @szComment is null  SET @szComment = ''
if @ModfilyDate is null  SET @ModfilyDate = GETDATE()
if @ModfilyDate='' set @ModfilyDate= GETDATE()
/*Params Ini end*/

	SET NOCOUNT ON
  IF @lMode=0 GOTO QueryClientJSPrice
  IF @lMode=1 GOTO AddClientJSPrice
  IF @lMode=2 GOTO ModClientJSPrice
  IF @lMode=3 GOTO DelClientJSPrice
  IF @lMode=4 GOTO AddClientJSPrice
  IF @lMode=5 GOTO ModStorageJSPrice
  IF @lMode=6 GOTO DelStorageJSPrice
  IF @lMode=7 GOTO QueryProductJSPrice
  IF @lMode=8 GOTO ModProductJSPrice
  IF @lMode=9 GOTO DelProductJSPrice


/**************************************************************
查询单位
**************************************************************/
QueryClientJSPrice:

  SELECT * FROM VW_X_UnionClient
  GOTO SUCCEE

/**************************************************************
添加单位
**************************************************************/
AddClientJSPrice:

  IF EXISTS(SELECT [ID] FROM UnionClient WHERE [S_ID]=@lStorageID)
    GOTO ERROR101
  ELSE BEGIN
    INSERT INTO UnionClient([C_ID], [S_ID], [PassWord], [Comment])
    VALUES(@lClientID, @lStorageID, CAST(@szPassword AS VARBINARY), @szComment) 
  END
  
  GOTO SUCCEE

/**************************************************************
修改单位密码
**************************************************************/
ModClientJSPrice:

  UPDATE UnionClient
  SET [Password]=CAST(@szPassword AS VARBINARY)
  WHERE [C_ID]=@lClientID
  GOTO SUCCEE

/**************************************************************
删除单位
**************************************************************/
DelClientJSPrice:

  DELETE FROM UnionClient WHERE [C_ID]=@lClientID
  DELETE FROM UnionPrice WHERE [C_ID]=@lClientID
  GOTO SUCCEE


/**************************************************************
修改仓库备注
**************************************************************/
ModStorageJSPrice:

  UPDATE UnionClient
  SET [Comment]=@szComment
  WHERE [C_ID]=@lClientID AND [S_ID]=@lStorageID
  GOTO SUCCEE

/**************************************************************
删除仓库
**************************************************************/
DelStorageJSPrice:

  DELETE FROM UnionClient WHERE [C_ID]=@lClientID AND [S_ID]=@lStorageID
  GOTO SUCCEE

/**************************************************************
查询商品的结算价
**************************************************************/
QueryProductJSPrice:

  SELECT P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Alias], 
  P.[Standard], P.[PermitCode], P.[Makearea], P.[Medtype], P.[Unitname1], 
  ISNULL(U.[ID]       ,0) AS [ID], 
  ISNULL(U.[JsPrice]  ,0) AS [JSPrice], 
  ISNULL(U.[LowPrice] ,0) AS [LowPrice], 
  ISNULL(U.[SalePrice],0) AS [SalePrice]
  FROM VW_C_Products P 
  LEFT JOIN
  (SELECT [ID], [P_ID], [JsPrice], [LowPrice], [SalePrice] FROM UnionPrice WHERE [C_ID]=@lClientID) U
  ON U.[P_ID]=P.[Product_ID] 
  WHERE P.[Deleted]<>1 AND P.[Child_Number]=0

  GOTO SUCCEE


/**************************************************************
修改商品的结算价
**************************************************************/
ModProductJSPrice:

  IF NOT EXISTS(SELECT [ID] FROM UnionPrice WHERE [C_ID]=@lClientID AND [P_ID]=@lProductID AND [ID]=@nID)
  BEGIN
    INSERT INTO UnionPrice([C_ID], [P_ID], [Leveal], [JsPrice], [LowPrice], [SalePrice], [E_ID], [ModifyDate])
    VALUES(@lClientID, @lProductID, 0, @dJSPrice, @dLowPrice, @dSalePrice, @lEmployeeID, @ModfilyDate)
  END
  ELSE BEGIN
    UPDATE UnionPrice
    SET [JsPrice]=@dJSPrice,
        [LowPrice]=@dLowPrice,
        [SalePrice]=@dSalePrice,
        [E_ID]=@lEmployeeID,
        [ModifyDate]=@ModfilyDate
    WHERE [C_ID]=@lClientID AND [P_ID]=@lProductID AND [ID]=@nID
  END

  GOTO SUCCEE

/**************************************************************
删除商品的结算价
**************************************************************/
DelProductJSPrice:

  DELETE FROM UnionPrice WHERE [ID]=@nID
  GOTO SUCCEE

Succee:
  RETURN  0

ERROR101:
  Return -101
GO
