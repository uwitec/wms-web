

CREATE  PROCEDURE [Ts_L_InsOrUpdateComPany]
 (@company_id int,
  @parent_id [varchar](30),
  @serial_number [varchar](26),
  @name [varchar](80),
  @alias  [varchar](30),
  @pinyin [varchar](80),
  @bank  varchar(2000),
  @opaddress  varchar(50),
  @communicateaddr  varchar(50),
  @postcode  varchar(50),
  @tel  varchar(50),
  @manager  varchar(50),
  @email  varchar(50),
  @comment  varchar(50),
  @RowIndex [int],
  @credit_total [numeric],
  @sklimit [numeric],
  @artotal NUMERIC(25,8),
  @artotal_ini NUMERIC(25,8),
  @aptotal NUMERIC(25,8),
  @aptotal_ini NUMERIC(25,8),
  @pre_artotal NUMERIC(25,8),
  @pre_artotal_ini NUMERIC(25,8),
  @pre_aptotal NUMERIC(25,8),
  @pre_aptotal_ini NUMERIC(25,8),
  @Ytype         int,
  @Yprefix       varchar(50),
  @superior_id   int,
  @Ifindependence bit,  
  @Y_id           int,
  @IncRate       NUMERIC(25,8),
  @posdatamode   int, 
  @swarajPrice  int,
  
  @ent_type     smallint,
  @city_id       varchar(80),
  @city_name     varchar(120),
  @boro_id       varchar(80),
  @boro_name     varchar(120),
  @licence_no     Varchar(80),
  @consignBook_no varchar(80),
  @GSPNo         varchar(80),
  @organCard_no  varchar(80),
  @BusinessLicence_no varchar(80),
  @MassConfer_no  varchar(80),
  @GMPNo          varchar(80),
  @Cer_CustomNO1  varchar(120),
  @Cer_CustomNO2  varchar(120),
  @Cer_CustomNO3  varchar(120),
  @Cer_CustomNO4  varchar(120),
  @Cer_CustomNO5  varchar(120),
  @Regionid       int,
  @payoff int,
  @ShopMaster int,
  @IncRateMode int,
  @nSendPriceType int,
  @sendBillType int,
  @FCategoryStr  varchar(100),/*自定义类别字符串 */
  @BalanceMode INT,            /*结算方式*/
  @tax_number varchar(60),    /*税号*/
  @RoadId    int/*配送线路*/
 )
AS 
declare  @tempId  varchar(30),
         @child_number  [int],
         @child_count [int],
         @newid int,
         @com_id int,
         /*@szY_ID int,*/
         @isopenData int


IF @company_id<=0 
begin
/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'company')
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*BEGIN TRAN insertBaseClient*/

INSERT INTO Company(class_id,
             parent_id,
             serial_number,
             [name],
             alias,
             PinYin,
             deleted,
             bank,
             opaddress,
             communicateaddr,
             postcode,
             tel,
             manager,
             email,
             comment,
             StartUse,
             prefix,
             sysflag,
             RowIndex,
             Ytype,
             superior_id,
	         Ifindependence,
             IncRate,
             posdatamode,
             swarajPrice,
			 ent_type,
			 city_id,
			 city_name,
			 boro_id,
			 boro_name,
			 licence_no,
		 	 consignBook_no,
			 GSPNo,
			 organCard_no,
			 BusinessLicence_no,
			 MassConfer_no,
			 GMPNo,
			 Cer_CustomNO1,
			 Cer_CustomNO2,
			 Cer_CustomNO3,
			 Cer_CustomNO4,
			 Cer_CustomNO5,
			 region_id,
			 payoff,
			 shopmaster,
			 incRateMode,
			 sendpricetype,
			 sendBillType,
			 BalanceMode,
			 tax_number
 )
VALUES 
 (@tempId,
  @parent_id,
  @serial_number,
  @name,
  @alias,
  @pinyin,
  0,
  @bank,
  @opaddress,
  @communicateaddr,
  @postcode,
  @tel,
  @manager ,
  @email,
  @comment,
  0,
  @Yprefix,
  0,
  @RowIndex,
  @Ytype,
  @superior_id,
  @Ifindependence,
  @IncRate,
  @posdatamode,
  @swarajPrice,
  @ent_type,     
  @city_id,       
  @city_name,     
  @boro_id,       
  @boro_name,     
  @licence_no,    
  @consignBook_no,
  @GSPNo,         
  @organCard_no,  
  @BusinessLicence_no,
  @MassConfer_no, 
  @GMPNo,         
  @Cer_CustomNO1, 
  @Cer_CustomNO2, 
  @Cer_CustomNO3, 
  @Cer_CustomNO4, 
  @Cer_CustomNO5,
  @Regionid,
  @payoff,
  @ShopMaster,
  @IncRateMode,
  @nSendPriceType,
  @sendBillType,
  @BalanceMode,
  @tax_number
  )

    if @@rowCount=0 
    begin
      return -1
    end 
    else 
    begin
      update Company set child_number=@child_number,child_count=@child_count
      where class_id = @Parent_id
      set @newid=@@IDENTITY
      /*添加机构辅助表，主要用于WMS，配送路线*/
      insert into WMSCompany(Company_ID,RoadID)
      values(@newid,@RoadId)
      /*-处理自定义类别*/
	   /*update  customCategoryMapping set deleted=1 where category_id=0 */
	   /*update customCategoryMapping set baseinfo_id=@newid where baseinfo_id=0 and BaseTypeid=2 and id in (select  szTYPE from  DecodeToStr(@FCategoryStr)) and deleted=0*/
       
        if exists(select 1 from companybalance where c_id =0 and y_id =@superior_id and openaccount = 1) and (@Ytype = 1)
        begin
          if exists(select 1 from companybalance where y_id = @newid and c_id = 0)
            update companybalance set openaccount =1 where y_id = @newid and c_id = 0
          else
            insert into companybalance(y_id, c_Id, openaccount)
              values(@newid, 0, 1)

          if exists(select 1 from sysconfig where y_id = @newid and [sysname] = 'openaccount')
            update sysconfig set sysvalue = '1' where y_id = @newid and [sysname] = 'openaccount'
          else
            insert into sysconfig([sysname], sysvalue, y_id)
              values('openaccount', '1', @newid)
                    
        end  
    end
end else
begin

update Company set  serial_number=@serial_number,
					 [name]=@name,
					 alias=@alias,
					 PinYin=@pinyin,
					 bank=@bank,
					 opaddress=@opaddress,
					 communicateaddr=@communicateaddr,
					 postcode=@postcode,
					 tel=@tel,
					 manager=@manager,
					 email=@email,
					 comment=@comment,
					 Ytype=@Ytype,
					 prefix=@Yprefix,
					 superior_id=@superior_id,
					 Ifindependence=@Ifindependence,
					 IncRate=@IncRate,
				     posdatamode = @posdatamode,
				     swarajPrice = @swarajPrice,
				     ent_type   =        @ent_type,     
					 city_id=			 @city_id,       
					 city_name=			 @city_name,     
					 boro_id=			 @boro_id,       
					 boro_name=			 @boro_name,     
					 licence_no=		 @licence_no,    
					 consignBook_no=	 @consignBook_no,
					 GSPNo=				 @GSPNo,         
					 organCard_no=		 @organCard_no,  
					 BusinessLicence_no= @BusinessLicence_no,
					 MassConfer_no=		 @MassConfer_no, 
					 GMPNo=				 @GMPNo,         
					 Cer_CustomNO1=		 @Cer_CustomNO1, 
					 Cer_CustomNO2=		 @Cer_CustomNO2, 
					 Cer_CustomNO3=		 @Cer_CustomNO3, 
					 Cer_CustomNO4=		 @Cer_CustomNO4, 
					 Cer_CustomNO5=		 @Cer_CustomNO5,
					 region_id    =      @Regionid,
					 sendpricetype  =    @nSendPriceType, 				     
					 payoff = @payoff,
					 shopmaster  = @shopmaster,
					 incRateMode = @IncRateMode,
					 sendBillType = @sendBillType,
					 BalanceMode  = @BalanceMode,
					 tax_number  = @tax_number
       where company_id=@company_id
 if @@rowcount<>0 
 begin
    /*--用于修改的时候这个时候辅助表没有该机构所以插入一行当前修改的机构ID*/
    if not exists (select * from WMSCompany where Company_ID =@company_id)
    begin
       insert into WMSCompany(Company_ID,RoadID) values(@company_id,0) 
    end
    update WMSCompany set RoadID=@RoadId where Company_ID=@company_id
 end
 set   @newid=@company_id
end

select @isopenData = isnull(openaccount, 0) from companybalance where y_id = @newid and c_id =0


	if exists(select * from Companybalance where Y_id=@Y_id and c_id=@newid)
	begin
          if @isopenData=0 
          begin
            UPDATE dbo.Companybalance
	
	    SET	 [artotal]		= @artotal_ini,
		 [aptotal]		    = @aptotal_ini,
		 [pre_artotal]	    = @pre_artotal_ini,
		 [pre_aptotal]	    = @pre_aptotal_ini,
         [artotal_ini]		= @artotal_ini,
		 [aptotal_ini]		= @aptotal_ini,
		 [pre_artotal_ini]	= @pre_artotal_ini,
		 [pre_aptotal_ini]	= @pre_aptotal_ini
	         
	    WHERE 
		( [c_id]		= @newid  AND
	          Y_id      = @Y_id)  
           end


           UPDATE dbo.Companybalance
	
	    SET	 
                 [credit_total] 	= @credit_total,
		 [sklimit]		= cast(@sklimit as int)
	         
	    WHERE 
		( [c_id]		= @newid  AND
	          Y_id      = @Y_id)   
	end
	else
	begin  
	
	INSERT Companybalance(Y_id,C_ID,credit_total,sklimit,artotal,artotal_ini,aptotal,aptotal_ini,pre_artotal,
	                 pre_artotal_ini,pre_aptotal,pre_aptotal_ini)
	  VALUES(@Y_id,@newid,@credit_total,cast(@sklimit as int),@artotal_ini,@artotal_ini,@aptotal_ini,@aptotal_ini,@pre_artotal_ini,
	                 @pre_artotal_ini,@pre_aptotal_ini,@pre_aptotal_ini)
	end 
if not exists(select 1 from companybalance where y_Id = @newid and c_id = 0)
 begin 
      if @Ytype=1 and (exists (select 1 from Companybalance where y_id=@superior_id and c_id=0 and openAccount=1)) 
      begin
        select @com_id = company_id from company where serial_number=@serial_number
        INSERT Companybalance(Y_id,C_ID, Openaccount) VALUES(@newid,0, 1)
        Insert sysconfig([sysname],[sysvalue],[comment],[sysflag],[Y_ID])
        values('OpenAccount',1,'',0,@com_id)
      end
     else
    INSERT Companybalance(Y_id,C_ID, Openaccount) VALUES(@newid,0, 0)
 end

return @newid
GO
