
/*nReturnNumber
－100：单据日期小于本期开始日期
 -101: 本张单据里包含结算金额大于结算余额的业务单据,可能的原因是业务单据已被其他人结算
	-1: 负库存
	-2:
	-3: 数量为零
	-4: 期初不能修改
	-5: 无成本价
  -6: 异常错误
  -7: 已经开帐，数据不能修改
	-8: 会计凭证不平
	-9：商品已删除
	-10：仓库已删除
	-11：职员已删除
	-12：往来单位已删除
	-13: 会计科目已删除
	-14: 货位已删除
	-15：商品单位已删除

	-21:退货数量大于原单数量
	-22:未指定当前机构
*/
CREATE  procedure ts_c_YBillAudit
(
	@nBillId int,
	@nP_id int output,
	@nReturnNumber int output,
	@nVchtype int
)
/*with encryption*/
as
set nocount on

declare @nTempPid int,@szBillNumber varchar(20),@szProductName varchar(60),@nNewBillId int
declare @nC_id int,@nE_id int,@tBillDate datetime,@tBeginDate datetime,@tAuditDate datetime
declare @nDep_id int,@nRegion_id int,@nPeriod int,@cBillState char(1),@nBilltype int,@cJsFlag char(1)
declare @totalmoney NUMERIC(25,8),@billguid varchar(50)
declare @Y_id int,@billdateAudit int


select @nC_id=c_id,@nE_id=e_id,@tBillDate=billdate,@cBillState=billstates,@nBilltype=billtype,@szBillNumber=billnumber,@cJsFlag=jsflag,@Y_id=Y_id,@billguid=guid  from Ybilldraftidx where billid=@nBillid


select @tBeginDate=begindate from MonthSettleInfo where monthname='本期' and Y_id=@Y_id
if exists(select 1 from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id)
  select @nPeriod=cast(sysvalue as int) from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id
else set @nPeriod = 1

/*日结单据不需要判断*/
/*if @tBillDate<@tBeginDate */
/*begin */
/*	select @nReturnNumber=-100*/
/*	return 0*/
/*end*/


SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 

begin tran Audit_A

	select @nRegion_id=region_id from clients where client_id=@nC_id
	select @nDep_id=dep_id from employees where emp_id=@nE_id
	if @nRegion_id is null select @nRegion_id=0
	if @nDep_id is null select @nDep_id=0

    
    truncate table salemanagebilltmp
	exec @nReturnNumber=ts_c_YDraftToHis @nBillId,@nNewBillId output/*从草稿库拷贝到历史单据库*/
	if @nReturnNumber<>0 goto error
	update Ybilldraftidx set billstates=4 where billid=@nBillid /*防止重新扣减积分，扣减积分是在删除ybilldraftidx的触发器里面执行*/
	delete from ybilldraftidx where billid=@nBillid /*删除原草稿单据*/
	delete from ysalemanagebilldrf where bill_id=@nBillid
    
	/*exec ts_getsystmpvalue 'billdateAudidate',2,@billdateAudit out*/
    
    Select @tAuditDate=getdate()
	
	/*IF ISNULL(@billdateAudit,0)=0*/
	  update billidx set billstates='0',period=@nPeriod,AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	  where BillId=@nNewBillId
	/*ELSE*/
      /*update billidx set billstates='0',period=@nPeriod,billdate=left(@tAuditDate,10),AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id*/
	  /*where BillId=@nNewBillId*/

	if @@error<>0 goto error
	
	exec @nReturnNumber=ts_c_CreatePDetail @nNewBillId /*产生商品明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error

	exec ts_c_AuditP @nNewBillId,@nP_Id out,@nReturnNumber out /*商品登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error

	exec @nReturnNumber=ts_c_CreateADetail @nNewBillId /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error

	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 
	begin 
		rollback tran Audit_A
		update ybilldraftidx set transflag = @nReturnNumber where billid = @nBillid
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return -1
	end
	
	exec ts_c_AuditA @nNewBillId,@nReturnNumber out /*科目登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
	exec ts_c_deletetmpdetail @nNewBillid
	
	if @np_id=0 set @nP_id=@nNewBillid
		
	commit tran Audit_A
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	
	return 0


error:

        
	rollback tran Audit_A
        update ybilldraftidx set transflag = @nReturnNumber where billid = @nBillid
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	return 0
GO
