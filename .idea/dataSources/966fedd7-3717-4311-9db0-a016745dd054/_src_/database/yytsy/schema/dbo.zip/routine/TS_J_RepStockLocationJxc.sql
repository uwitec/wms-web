CREATE PROCEDURE [TS_J_RepStockLocationJxc]
(
@StoredProcMode     INT=0,                   /*0仓库进销存  1 货位进销存*/
@szS_ID	 VARCHAR(36)='',
@Loc_id         INT=0,
@szP_ID	 VARCHAR(36)='',
@BeginDate 	 DATETIME=0,
@EndDate	 DATETIME=0, 
@OperatorID	 INT=1,
@nYClassid      varchar(100)='',
@nloginEID      int=0
)
AS 
/*
修改：ZhongFP	2017-09-03	性能优化
调用：
*/
BEGIN
	SET NOCOUNT ON 
	
	/*Params Ini begin*/
	if @StoredProcMode is null  SET @StoredProcMode = 0
	if @szS_ID is null  SET @szS_ID = ''
	if @Loc_id is null  SET @Loc_id = 0
	if @szP_ID is null  SET @szP_ID = ''
	if @BeginDate is null  SET @BeginDate = 0
	if @EndDate is null  SET @EndDate = 0
	if @OperatorID is null  SET @OperatorID = 1
	if @nYClassid is null  SET @nYClassid = ''
	if @nloginEID is null  SET @nloginEID = 0
	/*Params Ini end*/
	 
	DECLARE @szLoc_id VARCHAR(10)
	
	create table #Companytable(Company_id int)
	create table #storagestable(storage_id INT, WholeFlag INT)
	
	
	
	/*---分支机构授权*/
	  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
		  or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
	   BEGIN
		  Insert #Companytable (Company_id) 
		  SELECT Company_id 
		  FROM Company C 
		  WHERE @nYClassid='' OR C.class_id=@nYClassid
	   end
	   else
	   BEGIN
		  Insert #Companytable (Company_id) 
		  SELECT Company_id 
		  FROM Company C 
		  WHERE exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
				AND @nYClassid='' OR C.class_id=@nYClassid
	   end
	/*---分支机构授权*/
	
	/*---仓库授权*/
	   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
		  or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
	   BEGIN
		 Insert #storagestable (storage_id, WholeFlag) 
		  SELECT C.storage_id, C.WholeFlag
		  FROM storages C 
		  WHERE @szS_ID='' OR C.class_id=@szS_ID
	   end
	   else
	   begin 
		  Insert #storagestable (storage_id, WholeFlag) 
		  SELECT C.storage_id, C.WholeFlag
		  FROM storages C 
		  WHERE exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
				AND @szS_ID='' OR C.class_id=@szS_ID
	   end
	/*---仓库授权*/
	 
	 
	/*合并到#storagestable和#Companytable*/
	/*declare @nP int*/
	/*declare @nS int*/
	/*declare @nY int*/
	/*set @nP = 0*/
	/*set @nS = 0*/
	/*set @nY = 0*/
	/*select @nP = product_id from products where class_id = @szP_ID*/
	/*select @nS = storage_id from storages where class_id = @szS_ID*/
	/*select @nY = company_id from company where class_id = @nYClassid*/
	
	
	/*商品过滤*/
	SELECT product_id INTO #product_id FROM products WHERE @szP_ID='' OR class_id=@szP_ID
	
	
	
	
	SELECT d.storetype, d.s_id, d.location_id, SUM(d.quantity) AS BQty, SUM(d.costtotal) AS BTotal
	INTO #pdb
	FROM productdetail AS d
		INNER JOIN  dbo.billidx AS i ON d.billid = i.billid
		INNER JOIN #storagestable S ON d.s_id = S.storage_id
		INNER JOIN #Companytable C ON d.Y_ID = C.Company_id
		INNER JOIN #product_id P ON d.p_id = P.product_id
	WHERE i.billstates = '0'
		AND i.billtype<>51/*zjx--tfs46327--2017-03-10--不统计库存批次调整单*/
		AND (i.billdate < @BeginDate)	
	GROUP BY d.storetype, d.s_id, d.location_id
	
	
	
	SELECT i.billtype, d.s_id, d.location_id, d.AOID, d.quantity AS Qty, d.costtotal AS Cost, s.WholeFlag
	INTO #pddata
	FROM billidx AS i
		INNER JOIN productdetail AS d ON d.billid = i.billid			
		INNER JOIN #storagestable S ON d.s_id = S.storage_id
		INNER JOIN #Companytable C ON d.Y_ID = C.Company_id
		INNER JOIN #product_id P ON d.p_id = P.product_id
	WHERE (i.billstates = '0') 
		AND i.billtype<>51
		AND (i.billdate BETWEEN @BeginDate AND @EndDate) 
		AND (d.storetype IN(0, 3))
	
	
	
	IF @StoredProcMode=0  GOTO StockJxc
	IF @StoredProcMode=1  GOTO LocationJxc
	
	
	StockJxc:
	SELECT     0 AS SerialNo, - 1 AS LOC_ID, ' ' AS LOC_CODE, ' ' AS Loc_name, ' ' AS Loc_comment, s.storage_id AS Storage_ID, 
			  s.class_id AS Class_ID, s.parent_id AS Parent_ID, s.child_number AS Child_number, s.child_count AS Child_Count, s.serial_number AS Serial_number, 
			  s.name AS Name, s.alias AS Alias, CASE s.Flag WHEN 0 THEN '配送中心仓库' WHEN 1 THEN '自营店' WHEN 2 THEN '加盟店' END AS sType, 
			  s.Comment AS Comment, 
			  CAST(ISNULL(ss.BQty, 0) AS numeric(25,8)) AS BQty, CAST(ISNULL(ss.BTotal, 0) AS numeric(25,8)) AS BTotal, CAST(ISNULL(ls.BLQTY, 0) 
			  AS numeric(25,8)) AS BLQTY, CAST(ISNULL(bq.CQty, 0) AS numeric(25,8)) AS CQty, CAST(ISNULL(bq.CTotal, 0) AS numeric(25,8)) AS CTotal, CAST(ISNULL(bq.XTQty, 0) AS numeric(25,8)) 
			  AS XTQty, CAST(ISNULL(bq.XTTotal, 0) AS numeric(25,8)) AS XTTotal, CAST(ISNULL(bq.CHIQty, 0) AS numeric(25,8)) AS CHIQty, CAST(ISNULL(bq.CHITotal, 0) AS numeric(25,8)) 
			  AS CHITotal, CAST(ISNULL(bq.SHIQty, 0) AS numeric(25,8)) AS SHIQty, CAST(ISNULL(bq.SHITotal, 0) AS numeric(25,8)) AS SHITotal, CAST(ISNULL(bq.STQty, 0) AS numeric(25,8)) 
			  AS STQty, CAST(ISNULL(bq.STTotal, 0) AS numeric(25,8)) AS STTotal, CAST(ISNULL(bq.WTTQty, 0) AS numeric(25,8)) AS WTTQty, CAST(ISNULL(bq.WTTTotal, 0) AS numeric(25,8)) 
			  AS WTTTotal, CAST(ISNULL(bq.JJQty, 0) AS numeric(25,8)) AS JJQty, CAST(ISNULL(bq.JJTotal, 0) AS numeric(25,8)) AS JJTotal, CAST(ISNULL(bq.JCHQty, 0) AS numeric(25,8)) 
			  AS JCHQty, CAST(ISNULL(bq.JCHTotal, 0) AS numeric(25,8)) AS JCHTotal, CAST(ISNULL(bq.BYQty, 0) AS numeric(25,8)) AS BYQty, CAST(ISNULL(bq.BYTotal, 0) AS numeric(25,8)) 
			  AS BYTotal, CAST(ISNULL(bq.TJIQty, 0) AS numeric(25,8)) AS TJIQty, CAST(ISNULL(bq.TJITotal, 0) AS numeric(25,8)) AS TJITotal, CAST(ISNULL(bq.BJIQty, 0) AS numeric(25,8)) 
			  AS BJIQty, CAST(ISNULL(bq.BJITotal, 0) AS numeric(25,8)) AS BJITotal, CAST(ISNULL(bq.HZQty, 0) AS numeric(25,8)) AS HZQty, CAST(ISNULL(bq.HZTotal, 0) AS numeric(25,8)) 
			  AS HZTotal, CAST(ISNULL(bq.RKQty, 0) AS numeric(25,8)) AS RKQty, CAST(ISNULL(bq.RKTotal, 0) AS numeric(25,8)) AS RKTotal, CAST(ISNULL(bq.YCQty, 0) AS numeric(25,8)) 
			  AS YCQty, CAST(ISNULL(bq.YCTotal, 0) AS numeric(25,8)) AS YCTotal, CAST(ISNULL(bq.YXTQty, 0) AS numeric(25,8)) AS YXTQty, CAST(ISNULL(bq.YXTTotal, 0) AS numeric(25,8)) 
			  AS YXTTotal, CAST(ISNULL(bq.YCHIQty, 0) AS numeric(25,8)) AS YCHIQty, CAST(ISNULL(bq.YCHITotal, 0) AS numeric(25,8)) AS YCHITotal, CAST(ISNULL(bq.YSHIQty, 0) 
			  AS numeric(25,8)) AS YSHIQty, CAST(ISNULL(bq.YSHITotal, 0) AS numeric(25,8)) AS YSHITotal, CAST(ISNULL(bq.YRKQty, 0) AS numeric(25,8)) AS YRKQty, 
			  CAST(ISNULL(bq.YRKTotal, 0) AS numeric(25,8)) AS YRKTotal, CAST(ISNULL(bq.AllIQty, 0) AS numeric(25,8)) AS AllIQty, CAST(ISNULL(bq.AllITotal, 0) AS numeric(25,8)) AS AllITotal, 
			  CAST(ISNULL(bq.LCQty, 0) AS numeric(25,8)) AS LCQty, CAST(ISNULL(bq.LXTQty, 0) AS numeric(25,8)) AS LXTQty, CAST(ISNULL(bq.LCHIQty, 0) AS numeric(25,8)) AS LCHIQty, 
			  CAST(ISNULL(bq.LSHIQty, 0) AS numeric(25,8)) AS LSHIQty, CAST(ISNULL(bq.LBYQty, 0) AS numeric(25,8)) AS LBYQty, CAST(ISNULL(bq.LTJIQty, 0) AS numeric(25,8)) AS LTJIQty, 
			  CAST(ISNULL(bq.LRKQty, 0) AS numeric(25,8)) AS LRKQty, CAST(ISNULL(bq.LAllIQty, 0) AS numeric(25,8)) AS LAllIQty, CAST(ISNULL(bq.XQty, 0) AS numeric(25,8)) AS XQty, 
			  CAST(ISNULL(bq.XTotal, 0) AS numeric(25,8)) AS XTotal, CAST(ISNULL(bq.CTQty, 0) AS numeric(25,8)) AS CTQty, CAST(ISNULL(bq.CTTotal, 0) AS numeric(25,8)) AS CTTotal, 
			  CAST(ISNULL(bq.SHOQty, 0) AS numeric(25,8)) AS SHOQty, CAST(ISNULL(bq.SHOTotal, 0) AS numeric(25,8)) AS SHOTotal, CAST(ISNULL(bq.CHOQty, 0) AS numeric(25,8)) 
			  AS CHOQty, CAST(ISNULL(bq.CHOTotal, 0) AS numeric(25,8)) AS CHOTotal, CAST(ISNULL(bq.WTQty, 0) AS numeric(25,8)) AS WTQty, CAST(ISNULL(bq.WTTotal, 0) AS numeric(25,8)) 
			  AS WTTotal, CAST(ISNULL(bq.STTQty, 0) AS numeric(25,8)) AS STTQty, CAST(ISNULL(bq.STTTotal, 0) AS numeric(25,8)) AS STTTotal, CAST(ISNULL(bq.JCQty, 0) AS numeric(25,8)) 
			  AS JCQty, CAST(ISNULL(bq.JCTotal, 0) AS numeric(25,8)) AS JCTotal, CAST(ISNULL(bq.JJHQty, 0) AS numeric(25,8)) AS JJHQty, CAST(ISNULL(bq.JJHTotal, 0) AS numeric(25,8)) 
			  AS JJHTotal, CAST(ISNULL(bq.BSQty, 0) AS numeric(25,8)) AS BSQty, CAST(ISNULL(bq.BSTotal, 0) AS numeric(25,8)) AS BSTotal, CAST(ISNULL(bq.TJOQty, 0) AS numeric(25,8)) 
			  AS TJOQty, CAST(ISNULL(bq.TJOTotal, 0) AS numeric(25,8)) AS TJOTotal, CAST(ISNULL(bq.BJOQty, 0) AS numeric(25,8)) AS BJOQty, CAST(ISNULL(bq.BJOTotal, 0) AS numeric(25,8)) 
			  AS BJOTotal, CAST(ISNULL(bq.ZSQty, 0) AS numeric(25,8)) AS ZSQty, CAST(ISNULL(bq.ZSTotal, 0) AS numeric(25,8)) AS ZSTotal, CAST(ISNULL(bq.CKQty, 0) AS numeric(25,8)) 
			  AS CKQty, CAST(ISNULL(bq.CKTotal, 0) AS numeric(25,8)) AS CKTotal, CAST(ISNULL(bq.YXQty, 0) AS numeric(25,8)) AS YXQty, CAST(ISNULL(bq.YXTotal, 0) AS numeric(25,8)) 
			  AS YXTotal, CAST(ISNULL(bq.YCTQty, 0) AS numeric(25,8)) AS YCTQty, CAST(ISNULL(bq.YCTTotal, 0) AS numeric(25,8)) AS YCTTotal, CAST(ISNULL(bq.YSHOQty, 0) 
			  AS numeric(25,8)) AS YSHOQty, CAST(ISNULL(bq.YSHOTotal, 0) AS numeric(25,8)) AS YSHOTotal, CAST(ISNULL(bq.YCHOQty, 0) AS numeric(25,8)) AS YCHOQty, 
			  CAST(ISNULL(bq.YCHOTotal, 0) AS numeric(25,8)) AS YCHOTotal, CAST(ISNULL(bq.AllOQty, 0) AS numeric(25,8)) AS AllOQty, CAST(ISNULL(bq.AllOTotal, 0) AS numeric(25,8)) 
			  AS AllOTotal, CAST(ISNULL(bq.LXQty, 0) AS numeric(25,8)) AS LXQty, CAST(ISNULL(bq.LCTQty, 0) AS numeric(25,8)) AS LCTQty, CAST(ISNULL(bq.LSHOQty, 0) AS numeric(25,8)) 
			  AS LSHOQty, CAST(ISNULL(bq.LCHOQty, 0) AS numeric(25,8)) AS LCHOQty, CAST(ISNULL(bq.LBSQty, 0) AS numeric(25,8)) AS LBSQty, CAST(ISNULL(bq.LTJOQty, 0) 
			  AS numeric(25,8)) AS LTJOQty, CAST(ISNULL(bq.LCKQty, 0) AS numeric(25,8)) AS LCKQty, CAST(ISNULL(bq.LAllOQty, 0) AS numeric(25,8)) AS LAllOQty,
			  CAST(ISNULL(CASE WHEN s.WholeFlag = 3 THEN BQty ELSE 0 END, 0) AS numeric(25,8)) AS ClBQty,
			  CAST(ISNULL(CASE WHEN s.WholeFlag = 3 THEN BTotal ELSE 0 END, 0) AS numeric(25,8)) AS ClBTotal,
			  CAST(ISNULL(bq.ClRkQty, 0) AS numeric(25,8)) AS ClRkQty,CAST(ISNULL(bq.ClRkCost, 0) AS numeric(25,8)) AS ClRkCost,CAST(ISNULL(bq.ClXTQty, 0) AS numeric(25,8)) AS ClXTQty,
			  CAST(ISNULL(bq.ClXTTotal, 0) AS numeric(25,8)) AS ClXTTotal,CAST(ISNULL(bq.ClLXTQty, 0) AS numeric(25,8)) AS ClLXTQty,CAST(ISNULL(bq.ClYXTQty, 0) AS numeric(25,8)) AS ClYXTQty,
			  CAST(ISNULL(bq.ClYXTTotal, 0) AS numeric(25,8)) AS ClYXTTotal,CAST(ISNULL(bq.ClXQty, 0) AS numeric(25,8)) AS ClXQty,CAST(ISNULL(bq.ClXTotal, 0) AS numeric(25,8)) AS ClXTotal,
			  CAST(ISNULL(bq.CLLXQTY, 0) AS numeric(25,8)) AS CLLXQTY,CAST(ISNULL(bq.CLYXQTY, 0) AS numeric(25,8)) AS CLYXQTY,CAST(ISNULL(bq.CLYXTOTAL, 0) AS numeric(25,8)) AS CLYXTOTAL,
			  CAST(ISNULL(bq.CLDCKQTY, 0) AS numeric(25,8)) AS CLDCKQTY,CAST(ISNULL(bq.CLDCKCOST, 0) AS numeric(25,8)) AS CLDCKCOST
	FROM    (SELECT s_id, SUM(BQty) AS BQty, SUM(BTotal) AS BTotal
			   FROM  (SELECT s_id, SUM(quantity) AS BQty, SUM(costtotal) AS BTotal
					   FROM storehouseini SHI (NOLOCK)
							INNER JOIN #storagestable S ON SHI.s_id=S.storage_id
							INNER JOIN #Companytable C ON SHI.Y_ID=C.Company_id
							INNER JOIN #product_id P ON SHI.p_id=P.product_id
					   GROUP BY s_id
						   UNION ALL
					   SELECT p.s_id, SUM(p.BQty) AS BQty, SUM(p.BTotal) AS BTotal FROM #pdb p WHERE p.storetype=0 GROUP BY p.s_id
					) AS l
			   GROUP BY s_id
			) AS ss 
				RIGHT OUTER JOIN
				  (SELECT     ST.storage_id, ST.class_id, ST.parent_id, ST.child_number, ST.child_count, 
							ST.name, ST.alias, ST.serial_number, ST.Comment, ST.flag, ST.PinYin, ST.deleted, ST.ModifyDate, 
							ST.RowIndex, ST.WholeFlag, ST.Y_ID
					FROM    storages ST (NOLOCK)
							INNER JOIN #storagestable S ON ST.storage_id=S.storage_id
							INNER JOIN #Companytable C ON ST.Y_ID=C.Company_id
					WHERE   ST.deleted = 0
							AND ST.child_number = 0
					) AS s ON ss.s_id = s.storage_id 
				LEFT OUTER JOIN
				  (SELECT   s_id, SUM(BLQTY) AS BLQTY
					FROM    (SELECT OSHI.s_id, SUM(OSHI.quantity) AS BLQTY
							 FROM OtherStorehouseini OSHI (NOLOCK)
							 WHERE OSHI.AOID = 5
							 GROUP BY OSHI.s_id
								UNION ALL
							 SELECT  p.s_id, SUM(p.BQty) AS BLQty FROM #pdb p WHERE p.storetype=3 GROUP BY p.s_id
							) AS l_1
					GROUP BY s_id
					) AS ls ON s.storage_id = ls.s_id 
				LEFT OUTER JOIN
				  (SELECT     s_id, SUM(CQty) AS CQty, SUM(CTotal) AS CTotal, SUM(XTQty) AS XTQty, SUM(XTTotal) AS XTTotal, SUM(CHIQty) AS CHIQty, 
						   SUM(CHITotal) AS CHITotal, SUM(SHIQty) AS SHIQty, SUM(SHITotal) AS SHITotal, SUM(STQty) AS STQty, SUM(STTotal) AS STTotal, 
						   SUM(WTTQty) AS WTTQty, SUM(WTTTotal) AS WTTTotal, SUM(JJQty) AS JJQty, SUM(JJTotal) AS JJTotal, SUM(JCHQty) AS JCHQty, 
						   SUM(JCHTotal) AS JCHTotal, SUM(BYQty) AS BYQty, SUM(BYTotal) AS BYTotal, SUM(TJIQty) AS TJIQty, SUM(TJITotal) AS TJITotal, 
						   SUM(BJIQty) AS BJIQty, SUM(BJITotal) AS BJITotal, SUM(HZQty) AS HZQty, SUM(HZTotal) AS HZTotal, SUM(RKQty) AS RKQty, 
						   SUM(RKTotal) AS RKTotal, SUM(YCQty) AS YCQty, SUM(YCTotal) AS YCTotal, SUM(YXTQty) AS YXTQty, SUM(YXTTotal) AS YXTTotal, 
						   SUM(YCHIQty) AS YCHIQty, SUM(YCHITotal) AS YCHITotal, SUM(YSHIQty) AS YSHIQty, SUM(YSHITotal) AS YSHITotal, SUM(YRKQty) 
						   AS YRKQty, SUM(YRKTotal) AS YRKTotal, SUM(AllIQty) AS AllIQty, SUM(AllITotal) AS AllITotal, SUM(LCQty) AS LCQty, SUM(LXTQty) 
						   AS LXTQty, SUM(LCHIQty) AS LCHIQty, SUM(LSHIQty) AS LSHIQty, SUM(LBYQty) AS LBYQty, SUM(LTJIQty) AS LTJIQty, SUM(LRKQty) 
						   AS LRKQty, SUM(LAllIQty) AS LAllIQty, SUM(XQty) AS XQty, SUM(XTotal) AS XTotal, SUM(CTQty) AS CTQty, SUM(CTTotal) AS CTTotal, 
						   SUM(SHOQty) AS SHOQty, SUM(SHOTotal) AS SHOTotal, SUM(CHOQty) AS CHOQty, SUM(CHOTotal) AS CHOTotal, SUM(WTQty) AS WTQty, 
						   SUM(WTTotal) AS WTTotal, SUM(STTQty) AS STTQty, SUM(STTTotal) AS STTTotal, SUM(JCQty) AS JCQty, SUM(JCTotal) AS JCTotal, 
						   SUM(JJHQty) AS JJHQty, SUM(JJHTotal) AS JJHTotal, SUM(BSQty) AS BSQty, SUM(BSTotal) AS BSTotal, SUM(TJOQty) AS TJOQty, 
						   SUM(TJOTotal) AS TJOTotal, SUM(BJOQty) AS BJOQty, SUM(BJOTotal) AS BJOTotal, SUM(ZSQty) AS ZSQty, SUM(ZSTotal) AS ZSTotal, 
						   SUM(CKQty) AS CKQty, SUM(CKTotal) AS CKTotal, SUM(YXQty) AS YXQty, SUM(YXTotal) AS YXTotal, SUM(YCTQty) AS YCTQty, 
						   SUM(YCTTotal) AS YCTTotal, SUM(YSHOQty) AS YSHOQty, SUM(YSHOTotal) AS YSHOTotal, SUM(YCHOQty) AS YCHOQty, 
						   SUM(YCHOTotal) AS YCHOTotal, SUM(AllOQty) AS AllOQty, SUM(AllOTotal) AS AllOTotal, SUM(LXQty) AS LXQty, SUM(LCTQty) AS LCTQty, 
						   SUM(LSHOQty) AS LSHOQty, SUM(LCHOQty) AS LCHOQty, SUM(LBSQty) AS LBSQty, SUM(LTJOQty) AS LTJOQty, SUM(LCKQty) 
						   AS LCKQty, SUM(LAllOQty) AS LAllOQty,
						   SUM(ClRkQty) AS ClRkQty,SUM(ClRkCost) AS ClRkCost,SUM(ClXTQty) AS ClXTQty,SUM(ClXTTotal) AS ClXTTotal,SUM(ClLXTQty) AS ClLXTQty,
						   SUM(ClYXTQty) AS ClYXTQty,SUM(ClYXTTotal) AS ClYXTTotal,SUM(ClXQty) AS ClXQty,SUM(ClXTotal) AS ClXTotal,SUM(CLLXQTY) AS CLLXQTY,
						   SUM(CLYXQTY) AS CLYXQTY,SUM(CLYXTOTAL) AS CLYXTOTAL,SUM(CLDCKQTY) AS CLDCKQTY,SUM(CLDCKCOST) AS CLDCKCOST
					FROM	(SELECT     s_id,CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS CQty, 
								CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS CTotal, 
								CASE WHEN BillType IN (11, 13) AND AOID = 0 AND qty > 0 AND WholeFlag <> 3 THEN qty ELSE 0 END AS XTQty, 
								CASE WHEN BillType IN (11, 13) AND AOID = 0 AND qty > 0 AND WholeFlag <> 3 THEN cost ELSE 0 END AS XTTotal,                                                                           
								0 AS CHIQty, 0 AS CHITotal, 0 AS SHIQty, 0 AS SHITotal, 
								CASE WHEN BillType IN (120) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS STQty, 
								CASE WHEN BillType IN (120) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS STTotal, 
								CASE WHEN BillType IN (111) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS WTTQty, 
								CASE WHEN BillType IN (111) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS WTTTotal, 
								0 AS JJQty, 0 AS JJTotal, 0 AS JCHQty, 0 AS JCHTotal, 
								CASE WHEN BillType IN (42, 50) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS BYQty, 
								CASE WHEN BillType IN (42, 50) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS BYTotal, 
								CASE WHEN BillType IN (44) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS TJIQty, 
								CASE WHEN BillType IN (44) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS TJITotal, 
								CASE WHEN BillType IN (45) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS BJIQty, 
								CASE WHEN BillType IN (45) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS BJITotal, 
								0 AS HZQty, 0 AS HZTotal, 
								CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS RKQty, 
								CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS RKTotal, 
								CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 7 AND qty > 0 THEN qty ELSE 0 END AS YCQty, 
								CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 7 AND qty > 0 THEN cost ELSE 0 END AS YCTotal, 
								CASE WHEN BillType IN (11, 13) AND AOID = 7 AND qty > 0 AND WholeFlag <> 3 THEN qty ELSE 0 END AS YXTQty, 
								CASE WHEN BillType IN (11, 13) AND AOID = 7 AND qty > 0 AND WholeFlag <> 3 THEN cost ELSE 0 END AS YXTTotal,                                                  
								0 AS YCHIQty, 0 AS YCHITotal, 0 AS YSHIQty, 0 AS YSHITotal, 
								CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 7 AND qty > 0 THEN qty ELSE 0 END AS YRKQty, 
								CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 7 AND qty > 0 THEN cost ELSE 0 END AS YRKTotal, 
								CASE WHEN BillType IN (20, 11, 13, 28, 18, 120, 111, 33, 31, 42, 50, 44, 45, 47, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (0, 7) AND qty > 0 THEN qty ELSE 0 END AS AllIQty, 
								CASE WHEN BillType IN (20, 11, 13, 28, 18, 120, 111, 33, 31, 42, 50, 44, 45, 47, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (0, 7) AND qty > 0 THEN cost ELSE 0 END AS AllITotal, 
								CASE WHEN BillType IN (20, 222, 151, 160, 153, 162) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LCQty, 
								CASE WHEN BillType IN (11, 13) AND AOID IN (6, 8) AND qty > 0 AND WholeFlag <> 3 THEN qty ELSE 0 END AS LXTQty,                                                   
								0 AS LCHIQty, 0 AS LSHIQty, 
								CASE WHEN BillType IN (42, 50) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LBYQty, 
								CASE WHEN BillType IN (44, 45) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LTJIQty, 
								CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LRKQty, 
								CASE WHEN BillType IN (20, 11, 13, 28, 18, 42, 50, 44, 45, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LAllIQty, 
								CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 0 AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS XQty, 
								CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 0 AND qty < 0 AND WholeFlag <> 3 THEN - cost ELSE 0 END AS XTotal,
								CASE WHEN BillType IN (21) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS CTQty, 
								CASE WHEN BillType IN (21) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS CTTotal, 
								0 AS SHOQty, 0 AS SHOTotal, 0 AS CHOQty, 0 AS CHOTotal, 
								CASE WHEN BillType IN (110) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS WTQty, 
								CASE WHEN BillType IN (110) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS WTTotal, 
								CASE WHEN BillType IN (121) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS STTQty, 
								CASE WHEN BillType IN (121) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS STTTotal, 
								0 AS JCQty, 0 AS JCTotal, 0 AS JJHQty, 0 AS JJHTotal, 
								CASE WHEN BillType IN (41, 50) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS BSQty, 
								CASE WHEN BillType IN (41, 50) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS BSTotal, 
								CASE WHEN BillType IN (44) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS TJOQty, 
								CASE WHEN BillType IN (44) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS TJOTotal, 
								CASE WHEN BillType IN (45) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS BJOQty, 
								CASE WHEN BillType IN (45) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS BJOTotal, 
								0 AS ZSQty, 0 AS ZSTotal, 
								CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56, 149) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS CKQty, 
								CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56, 149) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS CKTotal, 
								CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 7 AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS YXQty, 
								CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 7 AND qty < 0 AND WholeFlag <> 3 THEN - cost ELSE 0 END AS YXTotal,                                                                        
								CASE WHEN BillType IN (21) AND AOID = 7 AND qty < 0 THEN - qty ELSE 0 END AS YCTQty, 
								CASE WHEN BillType IN (21) AND AOID = 7 AND qty < 0 THEN - cost ELSE 0 END AS YCTTotal, 
								0 AS YSHOQty, 0 AS YSHOTotal, 0 AS YCHOQty, 0 AS YCHOTotal, 
								CASE WHEN BillType IN (10, 12, 21, 18, 28, 110, 121, 30, 34, 41, 50, 44, 45, 46, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 149, 39) AND AOID IN (0, 7) AND qty < 0 THEN - qty ELSE 0 END AS AllOQty, 
								CASE WHEN BillType IN (10, 12, 21, 18, 28, 110, 121, 30, 34, 41, 50, 44, 45, 46, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 149, 39) AND AOID IN (0, 7) AND qty < 0 THEN - cost ELSE 0 END AS AllOTotal, 
								CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID IN (6, 8) AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS LXQty,
								CASE WHEN BillType IN (21) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LCTQty, 
								0 AS LSHOQty, 0 AS LCHOQty, 
								CASE WHEN BillType IN (41, 50) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LBSQty, 
								CASE WHEN BillType IN (44, 45) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LTJOQty, 
								CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LCKQty, 
								CASE WHEN BillType IN (10, 12, 21, 18, 28, 41, 50, 44, 45, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 39) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LAllOQty,
								CASE WHEN BillType IN (39) AND Qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClRkQty,
								CASE WHEN BillType IN (39) AND Qty > 0 AND WholeFlag = 3 THEN Cost ELSE 0 END AS ClRkCost,
								CASE WHEN BillType IN (13) AND AOID = 0 AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClXTQty,
								CASE WHEN BillType IN (13) AND AOID = 0 AND qty > 0 AND WholeFlag = 3 THEN cost ELSE 0 END AS ClXTTotal,
								CASE WHEN BillType IN (13) AND AOID IN (6, 8) AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClLXTQty,
								CASE WHEN BillType IN (13) AND AOID = 7 AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClYXTQty,
								CASE WHEN BillType IN (13) AND AOID = 7 AND qty > 0 AND WholeFlag = 3 THEN cost ELSE 0 END AS ClYXTTotal,
								CASE WHEN BillType IN (12) AND AOID = 0 AND Qty < 0 AND WholeFlag = 3 THEN - Qty ELSE 0 END AS ClXQty,
								CASE WHEN BillType IN (12) AND AOID = 0 AND Qty < 0 AND WholeFlag = 3 THEN - Cost ELSE 0 END AS ClXTotal,
								CASE WHEN BillType IN (12) AND AOID IN (6, 8) AND qty < 0 AND WholeFlag = 3 THEN - qty ELSE 0 END AS ClLXQty,
								CASE WHEN BillType IN (12) AND AOID = 7 AND qty < 0 AND WholeFlag = 3 THEN - qty ELSE 0 END AS ClYXQty, 
								CASE WHEN BillType IN (12) AND AOID = 7 AND qty < 0 AND WholeFlag = 3 THEN - cost ELSE 0 END AS ClYXTotal,
								CASE WHEN BillType IN (39) AND Qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS CldCkQty,
								CASE WHEN BillType IN (39) AND Qty < 0 AND WholeFlag <> 3 THEN - Cost ELSE 0 END AS CldCkCost
							/*FROM (SELECT i.billtype, d.s_id, d.AOID, d.quantity AS Qty, d.costtotal AS Cost, s.WholeFlag*/
							/*		FROM billidx AS i*/
							/*			INNER JOIN productdetail AS d ON d.billid = i.billid*/
							/*			LEFT join storages s ON s.storage_id = d.s_id*/
							/*		WHERE (i.billstates = '0') */
							/*			AND (i.billdate BETWEEN @BeginDate AND @EndDate) */
							/*			AND (d.storetype IN(0, 3))*/
							/*			AND (@nP = 0 OR d.p_id = @nP) 														*/
							/*			AND (@nS = 0 OR d.s_id = @nS) */
							/*			AND (@nY = 0 OR d.Y_ID = @nY)*/
							/*			AND (@Storetable = 0 OR d.s_id in(select storage_id from #storagestable))*/
							/*			AND (@Companytable = 0 OR d.Y_ID in(select Company_id from #Companytable))*/
							--			and i.billtype<>51/*zjx--tfs46327--2017-03-10--不统计库存批次调整单*/
							--			/*and s.WholeFlag <> 3*/
							--		/*GROUP BY i.billtype, d.s_id, d.AOID*/
							/*	) AS x*/
							FROM #pddata x
					) AS a GROUP BY s_id
					) AS bq ON s.storage_id = bq.s_id
			ORDER BY Class_ID
			
			
			
			
	  GOTO SUCCEE   
	LocationJxc:
	SELECT     0 AS SerialNo, s.loc_id AS LOC_ID, s.loc_code AS LOC_CODE, s.loc_name AS Loc_name, s.loc_comment AS Loc_comment, s.storage_id AS Storage_ID, 
			  s.class_id AS Class_ID, s.parent_id AS Parent_ID, s.child_number AS Child_number, s.child_count AS Child_Count, s.serial_number AS Serial_number, 
			  s.name AS Name, s.alias AS Alias, CASE s.Flag WHEN 0 THEN '配送中心仓库' WHEN 1 THEN '自营店' WHEN 2 THEN '加盟店' END AS sType, 
			  s.Comment AS Comment, CAST(ISNULL(ss.BQty, 0) AS numeric(25,8)) AS BQty, CAST(ISNULL(ss.BTotal, 0) AS numeric(25,8)) AS BTotal, CAST(ISNULL(ls.BLQTY, 0) 
			  AS numeric(25,8)) AS BLQTY, CAST(ISNULL(bq.CQty, 0) AS numeric(25,8)) AS CQty, CAST(ISNULL(bq.CTotal, 0) AS numeric(25,8)) AS CTotal, CAST(ISNULL(bq.XTQty, 0) AS numeric(25,8)) 
			  AS XTQty, CAST(ISNULL(bq.XTTotal, 0) AS numeric(25,8)) AS XTTotal, CAST(ISNULL(bq.CHIQty, 0) AS numeric(25,8)) AS CHIQty, CAST(ISNULL(bq.CHITotal, 0) AS numeric(25,8)) 
			  AS CHITotal, CAST(ISNULL(bq.SHIQty, 0) AS numeric(25,8)) AS SHIQty, CAST(ISNULL(bq.SHITotal, 0) AS numeric(25,8)) AS SHITotal, CAST(ISNULL(bq.STQty, 0) AS numeric(25,8)) 
			  AS STQty, CAST(ISNULL(bq.STTotal, 0) AS numeric(25,8)) AS STTotal, CAST(ISNULL(bq.WTTQty, 0) AS numeric(25,8)) AS WTTQty, CAST(ISNULL(bq.WTTTotal, 0) AS numeric(25,8)) 
			  AS WTTTotal, CAST(ISNULL(bq.JJQty, 0) AS numeric(25,8)) AS JJQty, CAST(ISNULL(bq.JJTotal, 0) AS numeric(25,8)) AS JJTotal, CAST(ISNULL(bq.JCHQty, 0) AS numeric(25,8)) 
			  AS JCHQty, CAST(ISNULL(bq.JCHTotal, 0) AS numeric(25,8)) AS JCHTotal, CAST(ISNULL(bq.BYQty, 0) AS numeric(25,8)) AS BYQty, CAST(ISNULL(bq.BYTotal, 0) AS numeric(25,8)) 
			  AS BYTotal, CAST(ISNULL(bq.TJIQty, 0) AS numeric(25,8)) AS TJIQty, CAST(ISNULL(bq.TJITotal, 0) AS numeric(25,8)) AS TJITotal, CAST(ISNULL(bq.BJIQty, 0) AS numeric(25,8)) 
			  AS BJIQty, CAST(ISNULL(bq.BJITotal, 0) AS numeric(25,8)) AS BJITotal, CAST(ISNULL(bq.HZQty, 0) AS numeric(25,8)) AS HZQty, CAST(ISNULL(bq.HZTotal, 0) AS numeric(25,8)) 
			  AS HZTotal, CAST(ISNULL(bq.RKQty, 0) AS numeric(25,8)) AS RKQty, CAST(ISNULL(bq.RKTotal, 0) AS numeric(25,8)) AS RKTotal, CAST(ISNULL(bq.YCQty, 0) AS numeric(25,8)) 
			  AS YCQty, CAST(ISNULL(bq.YCTotal, 0) AS numeric(25,8)) AS YCTotal, CAST(ISNULL(bq.YXTQty, 0) AS numeric(25,8)) AS YXTQty, CAST(ISNULL(bq.YXTTotal, 0) AS numeric(25,8)) 
			  AS YXTTotal, CAST(ISNULL(bq.YCHIQty, 0) AS numeric(25,8)) AS YCHIQty, CAST(ISNULL(bq.YCHITotal, 0) AS numeric(25,8)) AS YCHITotal, CAST(ISNULL(bq.YSHIQty, 0) 
			  AS numeric(25,8)) AS YSHIQty, CAST(ISNULL(bq.YSHITotal, 0) AS numeric(25,8)) AS YSHITotal, CAST(ISNULL(bq.YRKQty, 0) AS numeric(25,8)) AS YRKQty, 
			  CAST(ISNULL(bq.YRKTotal, 0) AS numeric(25,8)) AS YRKTotal, CAST(ISNULL(bq.AllIQty, 0) AS numeric(25,8)) AS AllIQty, CAST(ISNULL(bq.AllITotal, 0) AS numeric(25,8)) AS AllITotal, 
			  CAST(ISNULL(bq.LCQty, 0) AS numeric(25,8)) AS LCQty, CAST(ISNULL(bq.LXTQty, 0) AS numeric(25,8)) AS LXTQty, CAST(ISNULL(bq.LCHIQty, 0) AS numeric(25,8)) AS LCHIQty, 
			  CAST(ISNULL(bq.LSHIQty, 0) AS numeric(25,8)) AS LSHIQty, CAST(ISNULL(bq.LBYQty, 0) AS numeric(25,8)) AS LBYQty, CAST(ISNULL(bq.LTJIQty, 0) AS numeric(25,8)) AS LTJIQty, 
			  CAST(ISNULL(bq.LRKQty, 0) AS numeric(25,8)) AS LRKQty, CAST(ISNULL(bq.LAllIQty, 0) AS numeric(25,8)) AS LAllIQty, CAST(ISNULL(bq.XQty, 0) AS numeric(25,8)) AS XQty, 
			  CAST(ISNULL(bq.XTotal, 0) AS numeric(25,8)) AS XTotal, CAST(ISNULL(bq.CTQty, 0) AS numeric(25,8)) AS CTQty, CAST(ISNULL(bq.CTTotal, 0) AS numeric(25,8)) AS CTTotal, 
			  CAST(ISNULL(bq.SHOQty, 0) AS numeric(25,8)) AS SHOQty, CAST(ISNULL(bq.SHOTotal, 0) AS numeric(25,8)) AS SHOTotal, CAST(ISNULL(bq.CHOQty, 0) AS numeric(25,8)) 
			  AS CHOQty, CAST(ISNULL(bq.CHOTotal, 0) AS numeric(25,8)) AS CHOTotal, CAST(ISNULL(bq.WTQty, 0) AS numeric(25,8)) AS WTQty, CAST(ISNULL(bq.WTTotal, 0) AS numeric(25,8)) 
			  AS WTTotal, CAST(ISNULL(bq.STTQty, 0) AS numeric(25,8)) AS STTQty, CAST(ISNULL(bq.STTTotal, 0) AS numeric(25,8)) AS STTTotal, CAST(ISNULL(bq.JCQty, 0) AS numeric(25,8)) 
			  AS JCQty, CAST(ISNULL(bq.JCTotal, 0) AS numeric(25,8)) AS JCTotal, CAST(ISNULL(bq.JJHQty, 0) AS numeric(25,8)) AS JJHQty, CAST(ISNULL(bq.JJHTotal, 0) AS numeric(25,8)) 
			  AS JJHTotal, CAST(ISNULL(bq.BSQty, 0) AS numeric(25,8)) AS BSQty, CAST(ISNULL(bq.BSTotal, 0) AS numeric(25,8)) AS BSTotal, CAST(ISNULL(bq.TJOQty, 0) AS numeric(25,8)) 
			  AS TJOQty, CAST(ISNULL(bq.TJOTotal, 0) AS numeric(25,8)) AS TJOTotal, CAST(ISNULL(bq.BJOQty, 0) AS numeric(25,8)) AS BJOQty, CAST(ISNULL(bq.BJOTotal, 0) AS numeric(25,8)) 
			  AS BJOTotal, CAST(ISNULL(bq.ZSQty, 0) AS numeric(25,8)) AS ZSQty, CAST(ISNULL(bq.ZSTotal, 0) AS numeric(25,8)) AS ZSTotal, CAST(ISNULL(bq.CKQty, 0) AS numeric(25,8)) 
			  AS CKQty, CAST(ISNULL(bq.CKTotal, 0) AS numeric(25,8)) AS CKTotal, CAST(ISNULL(bq.YXQty, 0) AS numeric(25,8)) AS YXQty, CAST(ISNULL(bq.YXTotal, 0) AS numeric(25,8)) 
			  AS YXTotal, CAST(ISNULL(bq.YCTQty, 0) AS numeric(25,8)) AS YCTQty, CAST(ISNULL(bq.YCTTotal, 0) AS numeric(25,8)) AS YCTTotal, CAST(ISNULL(bq.YSHOQty, 0) 
			  AS numeric(25,8)) AS YSHOQty, CAST(ISNULL(bq.YSHOTotal, 0) AS numeric(25,8)) AS YSHOTotal, CAST(ISNULL(bq.YCHOQty, 0) AS numeric(25,8)) AS YCHOQty, 
			  CAST(ISNULL(bq.YCHOTotal, 0) AS numeric(25,8)) AS YCHOTotal, CAST(ISNULL(bq.AllOQty, 0) AS numeric(25,8)) AS AllOQty, CAST(ISNULL(bq.AllOTotal, 0) AS numeric(25,8)) 
			  AS AllOTotal, CAST(ISNULL(bq.LXQty, 0) AS numeric(25,8)) AS LXQty, CAST(ISNULL(bq.LCTQty, 0) AS numeric(25,8)) AS LCTQty, CAST(ISNULL(bq.LSHOQty, 0) AS numeric(25,8)) 
			  AS LSHOQty, CAST(ISNULL(bq.LCHOQty, 0) AS numeric(25,8)) AS LCHOQty, CAST(ISNULL(bq.LBSQty, 0) AS numeric(25,8)) AS LBSQty, CAST(ISNULL(bq.LTJOQty, 0) 
			  AS numeric(25,8)) AS LTJOQty, CAST(ISNULL(bq.LCKQty, 0) AS numeric(25,8)) AS LCKQty, CAST(ISNULL(bq.LAllOQty, 0) AS numeric(25,8)) AS LAllOQty,
			  CAST(ISNULL(CASE WHEN s.WholeFlag = 3 THEN BQty ELSE 0 END, 0) AS numeric(25,8)) AS ClBQty,
			  CAST(ISNULL(CASE WHEN s.WholeFlag = 3 THEN BTotal ELSE 0 END, 0) AS numeric(25,8)) AS ClBTotal,
			  CAST(ISNULL(bq.ClRkQty, 0) AS numeric(25,8)) AS ClRkQty,CAST(ISNULL(bq.ClRkCost, 0) AS numeric(25,8)) AS ClRkCost,CAST(ISNULL(bq.ClXTQty, 0) AS numeric(25,8)) AS ClXTQty,
			  CAST(ISNULL(bq.ClXTTotal, 0) AS numeric(25,8)) AS ClXTTotal,CAST(ISNULL(bq.ClLXTQty, 0) AS numeric(25,8)) AS ClLXTQty,CAST(ISNULL(bq.ClYXTQty, 0) AS numeric(25,8)) AS ClYXTQty,
			  CAST(ISNULL(bq.ClYXTTotal, 0) AS numeric(25,8)) AS ClYXTTotal,CAST(ISNULL(bq.ClXQty, 0) AS numeric(25,8)) AS ClXQty,CAST(ISNULL(bq.ClXTotal, 0) AS numeric(25,8)) AS ClXTotal,
			  CAST(ISNULL(bq.CLLXQTY, 0) AS numeric(25,8)) AS CLLXQTY,CAST(ISNULL(bq.CLYXQTY, 0) AS numeric(25,8)) AS CLYXQTY,CAST(ISNULL(bq.CLYXTOTAL, 0) AS numeric(25,8)) AS CLYXTOTAL,
			  CAST(ISNULL(bq.CLDCKQTY, 0) AS numeric(25,8)) AS CLDCKQTY,CAST(ISNULL(bq.CLDCKCOST, 0) AS numeric(25,8)) AS CLDCKCOST
	FROM    (SELECT location_id, SUM(BQty) AS BQty, SUM(BTotal) AS BTotal
			 FROM (SELECT SHI.location_id, SUM(SHI.quantity) AS BQty, SUM(SHI.costtotal) AS BTotal
				   FROM storehouseini SHI (NOLOCK)
						INNER JOIN #storagestable S ON SHI.s_id=S.storage_id
						INNER JOIN #Companytable C ON SHI.Y_ID=C.Company_id
						INNER JOIN #product_id P ON SHI.p_id=P.product_id
				   GROUP BY location_id
						UNION ALL
				   SELECT p.location_id, SUM(p.BQty) AS BQty, SUM(p.BTotal) AS BTotal FROM #pdb p WHERE p.storetype=0 GROUP BY p.location_id
				   ) AS l
			   GROUP BY location_id
			   ) AS ss 
			   RIGHT OUTER JOIN
			   (SELECT * FROM
					(SELECT ST.storage_id, ST.class_id, ST.parent_id, ST.child_number, ST.child_count, 
							ST.name, ST.alias, ST.serial_number, ST.Comment, ST.flag, ST.PinYin, ST.deleted, ST.ModifyDate, 
							ST.RowIndex, ST.WholeFlag, ST.Y_ID
					 FROM storages ST (NOLOCK)
							INNER JOIN #storagestable S ON ST.storage_id=S.storage_id
							INNER JOIN #Companytable C ON ST.Y_ID=C.Company_id
					 WHERE ST.deleted = 0
							AND ST.child_number = 0
					) AS s
					inner join (select loc_code, loc_comment, loc_id, loc_name, s_id from location where deleted = 0) l2 on s.storage_id = l2.s_id
				) as s ON ss.location_id = s.loc_id 
				LEFT OUTER JOIN
				  (SELECT   location_id, SUM(BLQTY) AS BLQTY
					FROM    (SELECT OSHI.location_id, SUM(OSHI.quantity) AS BLQTY
							 FROM OtherStorehouseini OSHI (NOLOCK)
							 WHERE OSHI.AOID = 5
							 GROUP BY OSHI.location_id
								UNION ALL
							 SELECT  p.location_id, SUM(p.BQty) AS BLQty FROM #pdb p WHERE p.storetype=3 GROUP BY p.location_id
							) AS l_1
					GROUP BY location_id
					) AS ls ON s.loc_id = ls.location_id 
					LEFT OUTER JOIN
				  (SELECT     location_id, SUM(CQty) AS CQty, SUM(CTotal) AS CTotal, SUM(XTQty) AS XTQty, SUM(XTTotal) AS XTTotal, SUM(CHIQty) AS CHIQty, 
						   SUM(CHITotal) AS CHITotal, SUM(SHIQty) AS SHIQty, SUM(SHITotal) AS SHITotal, SUM(STQty) AS STQty, SUM(STTotal) AS STTotal, 
						   SUM(WTTQty) AS WTTQty, SUM(WTTTotal) AS WTTTotal, SUM(JJQty) AS JJQty, SUM(JJTotal) AS JJTotal, SUM(JCHQty) AS JCHQty, 
						   SUM(JCHTotal) AS JCHTotal, SUM(BYQty) AS BYQty, SUM(BYTotal) AS BYTotal, SUM(TJIQty) AS TJIQty, SUM(TJITotal) AS TJITotal, 
						   SUM(BJIQty) AS BJIQty, SUM(BJITotal) AS BJITotal, SUM(HZQty) AS HZQty, SUM(HZTotal) AS HZTotal, SUM(RKQty) AS RKQty, 
						   SUM(RKTotal) AS RKTotal, SUM(YCQty) AS YCQty, SUM(YCTotal) AS YCTotal, SUM(YXTQty) AS YXTQty, SUM(YXTTotal) AS YXTTotal, 
						   SUM(YCHIQty) AS YCHIQty, SUM(YCHITotal) AS YCHITotal, SUM(YSHIQty) AS YSHIQty, SUM(YSHITotal) AS YSHITotal, SUM(YRKQty) 
						   AS YRKQty, SUM(YRKTotal) AS YRKTotal, SUM(AllIQty) AS AllIQty, SUM(AllITotal) AS AllITotal, SUM(LCQty) AS LCQty, SUM(LXTQty) 
						   AS LXTQty, SUM(LCHIQty) AS LCHIQty, SUM(LSHIQty) AS LSHIQty, SUM(LBYQty) AS LBYQty, SUM(LTJIQty) AS LTJIQty, SUM(LRKQty) 
						   AS LRKQty, SUM(LAllIQty) AS LAllIQty, SUM(XQty) AS XQty, SUM(XTotal) AS XTotal, SUM(CTQty) AS CTQty, SUM(CTTotal) AS CTTotal, 
						   SUM(SHOQty) AS SHOQty, SUM(SHOTotal) AS SHOTotal, SUM(CHOQty) AS CHOQty, SUM(CHOTotal) AS CHOTotal, SUM(WTQty) AS WTQty, 
						   SUM(WTTotal) AS WTTotal, SUM(STTQty) AS STTQty, SUM(STTTotal) AS STTTotal, SUM(JCQty) AS JCQty, SUM(JCTotal) AS JCTotal, 
						   SUM(JJHQty) AS JJHQty, SUM(JJHTotal) AS JJHTotal, SUM(BSQty) AS BSQty, SUM(BSTotal) AS BSTotal, SUM(TJOQty) AS TJOQty, 
						   SUM(TJOTotal) AS TJOTotal, SUM(BJOQty) AS BJOQty, SUM(BJOTotal) AS BJOTotal, SUM(ZSQty) AS ZSQty, SUM(ZSTotal) AS ZSTotal, 
						   SUM(CKQty) AS CKQty, SUM(CKTotal) AS CKTotal, SUM(YXQty) AS YXQty, SUM(YXTotal) AS YXTotal, SUM(YCTQty) AS YCTQty, 
						   SUM(YCTTotal) AS YCTTotal, SUM(YSHOQty) AS YSHOQty, SUM(YSHOTotal) AS YSHOTotal, SUM(YCHOQty) AS YCHOQty, 
						   SUM(YCHOTotal) AS YCHOTotal, SUM(AllOQty) AS AllOQty, SUM(AllOTotal) AS AllOTotal, SUM(LXQty) AS LXQty, SUM(LCTQty) AS LCTQty, 
						   SUM(LSHOQty) AS LSHOQty, SUM(LCHOQty) AS LCHOQty, SUM(LBSQty) AS LBSQty, SUM(LTJOQty) AS LTJOQty, SUM(LCKQty) 
						   AS LCKQty, SUM(LAllOQty) AS LAllOQty,
						   SUM(ClRkQty) AS ClRkQty,SUM(ClRkCost) AS ClRkCost,SUM(ClXTQty) AS ClXTQty,SUM(ClXTTotal) AS ClXTTotal,SUM(ClLXTQty) AS ClLXTQty,
						   SUM(ClYXTQty) AS ClYXTQty,SUM(ClYXTTotal) AS ClYXTTotal,SUM(ClXQty) AS ClXQty,SUM(ClXTotal) AS ClXTotal,SUM(CLLXQTY) AS CLLXQTY,
						   SUM(CLYXQTY) AS CLYXQTY,SUM(CLYXTOTAL) AS CLYXTOTAL,SUM(CLDCKQTY) AS CLDCKQTY,SUM(CLDCKCOST) AS CLDCKCOST
					FROM	(SELECT     location_id,         
								CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS CQty, 
							   CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS CTotal, 
							   CASE WHEN BillType IN (11, 13) AND AOID = 0 AND qty > 0 AND WholeFlag <> 3 THEN qty ELSE 0 END AS XTQty, 
							   CASE WHEN BillType IN (11, 13) AND AOID = 0 AND qty > 0 AND WholeFlag <> 3 THEN cost ELSE 0 END AS XTTotal, 
							   0 AS CHIQty, 0 AS CHITotal, 0 AS SHIQty, 0 AS SHITotal, 
							   CASE WHEN BillType IN (120) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS STQty, 
							   CASE WHEN BillType IN (120) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS STTotal, 
							   CASE WHEN BillType IN (111) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS WTTQty, 
							   CASE WHEN BillType IN (111) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS WTTTotal, 
							   0 AS JJQty, 0 AS JJTotal, 0 AS JCHQty, 0 AS JCHTotal, 
							   CASE WHEN BillType IN (42, 50) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS BYQty, 
							   CASE WHEN BillType IN (42, 50) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS BYTotal, 
							   CASE WHEN BillType IN (44) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS TJIQty, 
							   CASE WHEN BillType IN (44) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS TJITotal, 
							   CASE WHEN BillType IN (45) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS BJIQty, 
							   CASE WHEN BillType IN (45) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS BJITotal, 
							   0 AS HZQty, 0 AS HZTotal, 
							   CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 0 AND qty > 0 THEN qty ELSE 0 END AS RKQty, 
							   CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 0 AND qty > 0 THEN cost ELSE 0 END AS RKTotal, 
							   CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 7 AND qty > 0 THEN qty ELSE 0 END AS YCQty, 
							   CASE WHEN BillType IN (20, 222, 151, 152, 160, 153, 162) AND AOID = 7 AND qty > 0 THEN cost ELSE 0 END AS YCTotal, 
							   CASE WHEN BillType IN (11, 13) AND AOID = 7 AND qty > 0 AND WholeFlag <> 3 THEN qty ELSE 0 END AS YXTQty, 
							   CASE WHEN BillType IN (11, 13) AND AOID = 7 AND qty > 0 AND WholeFlag <> 3 THEN cost ELSE 0 END AS YXTTotal, 
							   0 AS YCHIQty, 0 AS YCHITotal, 0 AS YSHIQty, 0 AS YSHITotal, 
							   CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 7 AND qty > 0 THEN qty ELSE 0 END AS YRKQty, 
							   CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID = 7 AND qty > 0 THEN cost ELSE 0 END AS YRKTotal, 
							   CASE WHEN BillType IN (20, 11, 13, 28, 18, 120, 111, 33, 31, 42, 50, 44, 45, 47, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (0, 7) AND qty > 0 THEN qty ELSE 0 END AS AllIQty, 
							   CASE WHEN BillType IN (20, 11, 13, 28, 18, 120, 111, 33, 31, 42, 50, 44, 45, 47, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (0, 7) AND qty > 0 THEN cost ELSE 0 END AS AllITotal, 
							   CASE WHEN BillType IN (20, 222, 151, 160, 153, 162) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LCQty, 
							   CASE WHEN BillType IN (11, 13) AND AOID IN (6, 8) AND qty > 0  AND WholeFlag <> 3 THEN qty ELSE 0 END AS LXTQty, 
							   0 AS LCHIQty, 0 AS LSHIQty, 
							   CASE WHEN BillType IN (42, 50) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LBYQty, 
							   CASE WHEN BillType IN (44, 45) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LTJIQty, 
							   CASE WHEN BillType IN (130, 43, 40, 48, 51, 54, 55) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LRKQty, 
							   CASE WHEN BillType IN (20, 11, 13, 28, 18, 42, 50, 44, 45, 130, 43, 40, 48, 51, 54, 55, 222, 151, 152, 160, 153, 162, 39) AND AOID IN (6, 8) AND qty > 0 THEN qty ELSE 0 END AS LAllIQty, 
							   CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 0 AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS XQty, 
							   CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 0 AND qty < 0 AND WholeFlag <> 3 THEN - cost ELSE 0 END AS XTotal, 
							   CASE WHEN BillType IN (21) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS CTQty, 
							   CASE WHEN BillType IN (21) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS CTTotal, 
							   0 AS SHOQty, 0 AS SHOTotal, 0 AS CHOQty, 0 AS CHOTotal, 
							   CASE WHEN BillType IN (110) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS WTQty, 
							   CASE WHEN BillType IN (110) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS WTTotal, 
							   CASE WHEN BillType IN (121) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS STTQty, 
							   CASE WHEN BillType IN (121) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS STTTotal, 
							   0 AS JCQty, 0 AS JCTotal, 0 AS JJHQty, 0 AS JJHTotal, 
							   CASE WHEN BillType IN (41, 50) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS BSQty, 
							   CASE WHEN BillType IN (41, 50) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS BSTotal, 
							   CASE WHEN BillType IN (44) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS TJOQty, 
							   CASE WHEN BillType IN (44) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS TJOTotal, 
							   CASE WHEN BillType IN (45) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS BJOQty, 
							   CASE WHEN BillType IN (45) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS BJOTotal, 
							   0 AS ZSQty, 0 AS ZSTotal, 
							   CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56, 149) AND AOID = 0 AND qty < 0 THEN - qty ELSE 0 END AS CKQty, 
							   CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56, 149) AND AOID = 0 AND qty < 0 THEN - cost ELSE 0 END AS CKTotal, 
							   CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 7 AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS YXQty, 
							   CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID = 7 AND qty < 0 AND WholeFlag <> 3 THEN - cost ELSE 0 END AS YXTotal, 
							   CASE WHEN BillType IN (21) AND AOID = 7 AND qty < 0 THEN - qty ELSE 0 END AS YCTQty, 
							   CASE WHEN BillType IN (21) AND AOID = 7 AND qty < 0 THEN - cost ELSE 0 END AS YCTTotal, 
							   0 AS YSHOQty, 0 AS YSHOTotal, 0 AS YCHOQty, 0 AS YCHOTotal, 
							   CASE WHEN BillType IN (10, 12, 21, 18, 28, 110, 121, 30, 34, 41, 50, 44, 45, 46, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 149, 39) AND AOID IN (0, 7) AND qty < 0 THEN - qty ELSE 0 END AS AllOQty, 
							   CASE WHEN BillType IN (10, 12, 21, 18, 28, 110, 121, 30, 34, 41, 50, 44, 45, 46, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 149, 39) AND AOID IN (0, 7) AND qty < 0 THEN - cost ELSE 0 END AS AllOTotal, 
							   CASE WHEN BillType IN (10, 12, 212, 150, 161, 152, 163) AND AOID IN (6, 8) AND qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS LXQty, 
							   CASE WHEN BillType IN (21) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LCTQty, 
							   0 AS LSHOQty, 0 AS LCHOQty, 
							   CASE WHEN BillType IN (41, 50) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LBSQty, 
							   CASE WHEN BillType IN (44, 45) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LTJOQty, 
							   CASE WHEN BillType IN (131, 43, 40, 49, 51, 53, 56) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LCKQty, 
							   CASE WHEN BillType IN (10, 12, 21, 18, 28, 41, 50, 44, 45, 131, 43, 40, 49, 51, 53, 56, 212, 150, 161, 152, 163, 39) AND AOID IN (6, 8) AND qty < 0 THEN - qty ELSE 0 END AS LAllOQty,
							   CASE WHEN BillType IN (39) AND Qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClRkQty,
							   CASE WHEN BillType IN (39) AND Qty > 0 AND WholeFlag = 3 THEN Cost ELSE 0 END AS ClRkCost,
							   CASE WHEN BillType IN (13) AND AOID = 0 AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClXTQty,
							   CASE WHEN BillType IN (13) AND AOID = 0 AND qty > 0 AND WholeFlag = 3 THEN cost ELSE 0 END AS ClXTTotal,
							   CASE WHEN BillType IN (13) AND AOID IN (6, 8) AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClLXTQty,
							   CASE WHEN BillType IN (13) AND AOID = 7 AND qty > 0 AND WholeFlag = 3 THEN qty ELSE 0 END AS ClYXTQty,
							   CASE WHEN BillType IN (13) AND AOID = 7 AND qty > 0 AND WholeFlag = 3 THEN cost ELSE 0 END AS ClYXTTotal,
							   CASE WHEN BillType IN (12) AND AOID = 0 AND Qty < 0 AND WholeFlag = 3 THEN - Qty ELSE 0 END AS ClXQty,
							   CASE WHEN BillType IN (12) AND AOID = 0 AND Qty < 0 AND WholeFlag = 3 THEN - Cost ELSE 0 END AS ClXTotal,
							   CASE WHEN BillType IN (12) AND AOID IN (6, 8) AND qty < 0 AND WholeFlag = 3 THEN - qty ELSE 0 END AS ClLXQty,
							   CASE WHEN BillType IN (12) AND AOID = 7 AND qty < 0 AND WholeFlag = 3 THEN - qty ELSE 0 END AS ClYXQty, 
							   CASE WHEN BillType IN (12) AND AOID = 7 AND qty < 0 AND WholeFlag = 3 THEN - cost ELSE 0 END AS ClYXTotal,
							   CASE WHEN BillType IN (39) AND Qty < 0 AND WholeFlag <> 3 THEN - qty ELSE 0 END AS CldCkQty,
							   CASE WHEN BillType IN (39) AND Qty < 0 AND WholeFlag <> 3 THEN - Cost ELSE 0 END AS CldCkCost                    
							FROM    #pddata x
							) AS a
					GROUP BY location_id) AS bq ON s.loc_id = bq.location_id
				ORDER BY Class_ID, s.loc_id
				
				
	  GOTO SUCCEE   
	SUCCEE:
	  RETURN 0
END
GO
