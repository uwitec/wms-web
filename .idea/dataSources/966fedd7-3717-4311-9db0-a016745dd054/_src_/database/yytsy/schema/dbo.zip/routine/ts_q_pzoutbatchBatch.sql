

CREATE proc ts_q_pzoutbatchBatch
(
	@begindate datetime,
	@enddate   datetime,
        @nbilltype int
)
/*with encryption*/
as
set nocount on 
declare @nBillid int,@nReturnNumber int
declare @a int 
declare @b int
if @nbilltype=0 
begin
 select @a=min(billtype),@b=max(billtype) from billidx
end
else 
begin
set @a=@nbilltype
set @b=@nbilltype
end
truncate table Kpzout
begin tran
declare pzoutbatch cursor for
select billid from billidx 
where (billdate between @BeginDate and @EndDate) and billstates='0' and (billtype between @a and @b)
open pzoutbatch
fetch next from pzoutbatch into @nBillId
while @@fetch_status=0
begin
	exec @nReturnNumber=ts_q_kpzout @nBillid
	if @nReturnNumber=-1 goto error
	fetch next from pzoutbatch into @nBillId
end

close pzoutbatch
deallocate pzoutbatch

commit tran
return 0
error:
rollback tran
return -1
GO
