/************************************************************
--过程名称：Ts_X_SendPrintPageShow
--功能：按选择单据id串计算往来单位的发货量
--创建人：XXX
--创建时间：2015-04-14 
**************************************************************/
create proc [dbo].[Ts_X_SendPrintPageShow]
(
  @szbillid   VARCHAR(2000) = '' /*条件(单据的id串)*/
)

as

select cb.*,pc.StoreCondition from 
	(
	  select g.C_id,g.C_NAME,g.address,g.contact_personal,g.phone_number,SUM(WholeQty+PartQty) as Qty,
			  sum(g.WholeQty) as WholeQty, sum(g.PartQty) as PartQty, sum(GD.Total) as Total,0 as ScatQty,COUNT(C_id) as billqty from 
			 (select SUM(Total) as Total,Gspbill_id from dbo.GSPbilldetail group by Gspbill_id
			 ) gd left join dbo.VW_GSPBILLIDX AS g  on gd.Gspbill_id = g.Gspbillid	
			 where (g.BillType = 551) and 
			        g.Gspbillid in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@szBillid))
					group by g.C_id,g.C_NAME,g.address,g.contact_personal,g.phone_number	
   ) as cb
	left join 
	 (SELECT C_id,MAX(StoreCondition) as StoreCondition FROM 
	(select P_id,C_id, CASE WHEN StoreCondition = 2 THEN 1 ELSE 0 END AS StoreCondition from GSPbilldetail gd LEFT JOIN GSPbillidx gb ON gd.Gspbill_id = gb.Gspbillid  
											LEFT JOIN products P ON GD.P_id = P.product_id  
		where billtype = 551  
		AND gd.Gspbill_id in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@szBillid))
		group by P_id,C_id,P.StoreCondition)
	 AS PS
	 GROUP by C_id) as pc
	 
	 on cb.C_id = pc.C_id
GO
