
/******************************************
系统公告查询
********************************************/
CREATE PROCEDURE [Ts_T_AfficheQry]
(   
  @BeginDate DATETIME,
  @EndDate   DATETIME,
  @EID       INT,
  @YID       INT,
  @Title     VarChar(100),
  @Content   VarChar(8000),
  @QFlag     INT,  /*查询方式：0--查全部，1--只查未读*/
  @CallFlag  INT   /*调取方式：0--手动查询，1--自动查询（仅限门店，仅查未读）*/
)
AS
  SET NOCOUNT ON
  
  DECLARE @szEID VARCHAR(10), @szYID VARCHAR(10), @szTitle VARCHAR(100), @szContent VARCHAR(1000)
  
  IF @EID <= 0 SELECT @szEID = '%%' ELSE SELECT @szEID = CAST(@EID AS VARCHAR)
  IF @YID <= 0 SELECT @szYID = '%%' ELSE SELECT @szYID = CAST(@YID AS VARCHAR)
  IF @Title = '' SELECT @szTitle = '%%' ELSE SELECT @szTitle = '%' + @Title + '%'
  IF @Content = '' SELECT @szContent = '%%' ELSE SELECT @szContent = '%' + @Content + '%'

  if @CallFlag = 0 
    SELECT a.ID, a.EID, isnull(b.name,'') EName, a.YID, isnull(c.name,'') YName, a.AffDate, a.AffTitle, a.AffTitle AffTitle1, a.AffContent, a.AffContentNew
      FROM AfficheRec a Left join Employees b on a.EID = b.emp_id
                        Left join company c on a.YID = c.company_id
      WHERE DFlag = 0 
        and a.AffDate BETWEEN @BeginDate AND @EndDate + 1  
        AND a.EID LIKE @szEID 
        /*AND a.YID like @szYID*/
        and a.AffTitle like @szTitle 
        and AffContent like @szContent
        /*查全部；或者查本机构未读*/
        and ((@QFlag  = 0) or ((@QFlag = 1) and (a.ID not in (select DIstinct ID from AfficheReadRec where R_YID = @YID))))
  else if @CallFlag = 1 
    SELECT a.ID, a.EID, isnull(b.name,'') EName, a.YID, isnull(c.name,'') YName, a.AffDate, a.AffTitle, a.AffTitle AffTitle1, a.AffContent, a.AffContentNew         
      FROM AfficheRec a Left join Employees b on a.EID = b.emp_id
                        Left join company c on a.YID = c.company_id
      WHERE DFlag = 0 
        /*AND a.YID like @szYID        */
        /*查全部；或者查本机构未读*/
        and ((@QFlag  = 0) or ((@QFlag = 1) and (a.ID not in (select DIstinct ID from AfficheReadRec where R_YID = @YID))))
          
  RETURN  0
GO
