
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-03-28*/
/* Description:	获取指定单据的表头基本信息*/
/* =============================================*/
CREATE PROCEDURE TS_H_QrBillIdxInfo 
	@nBillId int = 0, 
	@nBillType int = 0,
	@nDraft int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF @nDraft = 0
	BEGIN
		SELECT     i.billnumber, e.name, v.Comment, i.billid, i.billtype, ISNULL(s.name, '') AS sname, y.name AS yname, ISNULL(CASE WHEN i.billtype BETWEEN 150 AND 
							  169 THEN c2.name ELSE c.name END, '') AS cname, i.GUID
		FROM         dbo.billidx AS i INNER JOIN
				dbo.employees AS e ON i.e_id = e.emp_id INNER JOIN
				dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
				dbo.company AS y ON i.Y_ID = y.company_id LEFT OUTER JOIN
				dbo.company AS c2 ON i.c_id = c2.company_id LEFT OUTER JOIN
				dbo.clients AS c ON i.c_id = c.client_id LEFT OUTER JOIN
				dbo.storages AS s ON i.sout_id = s.storage_id
		WHERE I.billid = @nBillId AND I.billtype = @nBillType
	END
	ELSE
	IF @nDraft = 1
	BEGIN
		/* 订单、计划*/
		IF @nBillType IN (14, 22, 26, 154)
		BEGIN
			SELECT     i.billnumber, e.name, v.Comment, i.billid, i.billtype, ISNULL(s.name, '') AS sname, y.name AS yname, ISNULL(case billtype when 154 then c2.name else c.name end, '') AS cname, i.Guid
			FROM         dbo.orderidx AS i INNER JOIN
					dbo.employees AS e ON i.e_id = e.emp_id INNER JOIN
					dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
					dbo.company AS y ON i.Y_ID = y.company_id LEFT OUTER JOIN
					dbo.company AS c2 ON i.c_id = c2.company_id LEFT OUTER JOIN
					dbo.clients AS c ON i.c_id = c.client_id LEFT OUTER JOIN
					dbo.storages AS s ON i.sout_id = s.storage_id
			WHERE I.billid = @nBillId AND I.billtype = @nBillType
		END
		ELSE
		/* GSP单据*/
		IF @nBillType BETWEEN 501 AND 599
		BEGIN
			SELECT     i.billnumber, e.name, v.Comment, i.Gspbillid AS billid, i.billtype, ISNULL(s.name, '') AS sname, y.name AS yname, ISNULL(CASE WHEN i.ybilltype BETWEEN 150 AND 
								  169 THEN c2.name ELSE c.name END, '') AS cname, i.Guid
			FROM         dbo.GSPbillidx AS i INNER JOIN
					dbo.employees AS e ON i.InputMan = e.emp_id INNER JOIN
					dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
					dbo.company AS y ON i.Y_ID = y.company_id LEFT OUTER JOIN
					dbo.company AS c2 ON i.c_id = c2.company_id LEFT OUTER JOIN
					dbo.clients AS c ON i.c_id = c.client_id LEFT OUTER JOIN
					dbo.storages AS s ON i.S_id = s.storage_id
			WHERE I.Gspbillid = @nBillId AND I.billtype = @nBillType
		END
		ELSE
		BEGIN
			SELECT     i.billnumber, e.name, v.Comment, i.billid, i.billtype, ISNULL(s.name, '') AS sname, y.name AS yname, ISNULL(CASE WHEN i.billtype BETWEEN 150 AND 
								  169 THEN c2.name ELSE c.name END, '') AS cname, i.GUID
			FROM         dbo.billdraftidx AS i INNER JOIN
					dbo.employees AS e ON i.e_id = e.emp_id INNER JOIN
					dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
					dbo.company AS y ON i.Y_ID = y.company_id LEFT OUTER JOIN
					dbo.company AS c2 ON i.c_id = c2.company_id LEFT OUTER JOIN
					dbo.clients AS c ON i.c_id = c.client_id LEFT OUTER JOIN
					dbo.storages AS s ON i.sout_id = s.storage_id
			WHERE I.billid = @nBillId AND I.billtype = @nBillType
		END
	END
END
GO
