
CREATE PROCEDURE Ts_L_InsELabelCfg 
@Loc_id		int,
@ELabelCodeH	int,
@ELabelCodeL	int,
@StyleH 	varchar(7),
@StyleL 	varchar(7)
AS

declare  @id int 
set @id=-1
select  @id = id from ELabelCfg where Loc_id = @Loc_id

if  @id=-1
begin
	INSERT INTO ELabelCfg ( Loc_id, ELabelCodeH,ELabelCodeL, StyleH, StyleL)
	VALUES(@Loc_id, @ELabelCodeH, @ELabelCodeL,@StyleH, @StyleL )
end
else
begin
	UPDATE ELabelCfg
	SET   Loc_id=@Loc_id, ELabelCodeH=@ELabelCodeH,ELabelCodeL=@ELabelCodeL
	      ,StyleH=@StyleH, StyleL=@StyleL
	WHERE id=@id 
end
GO
