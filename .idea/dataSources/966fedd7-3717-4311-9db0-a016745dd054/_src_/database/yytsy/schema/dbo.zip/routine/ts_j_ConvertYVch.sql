/************************************************************

--功能：转换机构收发货单  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：
 @nRet 返回值说明　
	0:执行成功
       -1:执行失败，发生异常
**************************************************************/

CREATE	 PROCEDURE [ts_j_ConvertYVch]
	(
	 @nbillid int,
	 @nbilltype int
    )
AS 

declare @nRet int

declare @LocalS_id int, @localinputman int,@localauditman int,@localeid int
declare @CenterSid int, @CenterInputman int, @CenterAuditman int, @CenterEid int, @Y_ID int, @nnewbillid int
declare @smbid int, @pid int, @locationid int
declare @nP_id int, @nReturnNumber int /*过账用*/
declare @szGUID varchar(60)
declare @szSN varchar(200)

select @Y_ID = isnull(c_id, 0) from billidx where billid = @nbillid

exec ts_getsysvalue 'LocalSid',@LocalS_id out, @Y_id
exec ts_getsysvalue 'LocalInputman',@localinputman out, @Y_ID
exec ts_getsysvalue 'LocalAuditman',@localauditman out, @Y_ID
exec ts_getsysvalue 'LocalEid',@localeid out, @Y_ID
exec ts_getsysvalue 'CenterSid',@CenterSid out, @Y_ID
exec ts_getsysvalue 'CenterInputman',@CenterInputman out, @Y_ID
exec ts_getsysvalue 'CenterAuditman',@CenterAuditman out,@Y_ID
exec ts_getsysvalue 'CenterEid',@CenterEid out, @Y_ID


  select @LocalS_id = sin_id, @localinputman = inputman, @localauditman = auditman, @localeid = e_id, @szGUID = GUID
    from billidx where billid  = @nbillid


if @nbilltype = 163
begin

	
	if exists(select 1 from billdraftidx where billtype =153 and order_id = @nbillid)
	  return -9

	exec TS_H_CreateBillSN 153, 1, null, @CenterEid, @Centerinputman, @szSN output

	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				 ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
				 posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
				 SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate,ZBAuditMan,ZBAuditDate) 
	
				select billdate, @szSN, 153, 0, Y_ID, @CenterEid, @CenterSid, @CenterSid, @Centerauditman, @Centerinputman, 
				ysmoney, 0, 0, quantity, taxrate, 0, 3, billid, 0, 2,
				Posid, 0, GETDATE(), 0, ysmoney, 0, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,NEWID(),
				SendQTY,0,jsInvoiceTotal,VIPCardID,C_ID,begindate,Enddate,ZBAuditMan,ZBAuditDate
	
				from billidx where billid=@nbillid
	
				select @nnewbillid = @@identity

	insert into salemanagebillDrf(bill_id, p_id, batchno,quantity, costprice,saleprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
			     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,taxrate,order_id, total, iotag,
			     InvoiceTotal,thqty,newprice,orgbillid,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,sendcosttotal,Rowguid,RowE_id, YcostPrice,YGUID, Y_ID, instoretime,BatchBarCode,scomment,batchprice)
		select   @nnewbillid, p_id, batchno,quantity, YCostprice,buyprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
			     makedate, validdate, qualitystatus, price_id, @CenterSid, 0, 0, supplier_id, commissionflag, comment,unitid,taxrate,0, total, iotag,
			     InvoiceTotal,0,newprice,smb_id,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,SendQty*Ycostprice,newid(),@CenterEid, YcostPrice,YGUID,@Y_ID, instoretime,BatchBarCode,scomment,batchprice
		from buymanagebill where bill_id=@nbillid /*and p_id > 0*/
		order by smb_id
		
		declare LocCur cursor for
		select smb_id,p_id
		from salemanagebilldrf
		where bill_id=@nnewbillid
		
		open LocCur
			
		fetch next from LocCur into @smbid,@pid
			
		while @@fetch_status=0
		begin
			select @locationid=0
			select @locationid=l_id from locationtrace where p_id=@pid and s_id=@CenterSid and Y_ID = @Y_ID
			
			update salemanagebilldrf set location_id=@locationid where smb_id=@smbid and Y_ID = @Y_ID
		
			fetch next from LocCur into @smbid,@pid
		end
		close LocCur
		deallocate LocCur
	
end

else if @nbilltype = 150
begin
	 if exists(select 1 from billidx where order_id = @nbillid and billtype = 160 and billstates = 0)
	   return 0
	 if exists(select 1 from billdraftidx where order_id = @nbillid and billtype = 160)  
	   return 0
	   
	exec TS_H_CreateBillSN 150, 1, null, @CenterEid, @Centerinputman, @szSN output

	 insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				 ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				 posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
				 SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate,ZBAuditMan,ZBAuditDate) 
	
				select billdate, @szSN, 160, 0, Y_ID, @localEid, @LocalS_id, @LocalS_id, @localauditman, @localinputman, 
				ysmoney, 0, 0, quantity, taxrate, 0, 3, @nbillid, 0, 
				Posid, 0, GETDATE(), 0, ysmoney, 0, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,NEWID(),
				SendQTY,0,jsInvoiceTotal,VIPCardID,C_ID,begindate,Enddate,ZBAuditMan,ZBAuditDate
				from billidx where billid=@nbillid
	
				select @nnewbillid=@@identity
				
	    insert into Buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,RowGuid,RowE_ID,YcostPrice,YGUID,
					Y_ID, instoretime,BatchBarCode,scomment,batchprice)
			select  @nnewbillid, p_id, batchno, quantity, discountprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxMoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, @LocalS_id, 0, 0, supplier_id, commissionflag, 
					comment,unitid,taxrate, smb_id, total,iotag,InvoiceTotal ,thqty,newprice,0,aoid,RowGuid,@localeid,YcostPrice,YGUID,@Y_id, instoretime,
					BatchBarCode,scomment,batchprice
				from Salemanagebill where bill_id=@nbillid /*and p_id > 0*/
				order by smb_id
				
	
	      declare LocCur cursor for
			select smb_id,p_id,ss_id
			from Buymanagebilldrf
			where bill_id=@nnewbillid
			
			open LocCur
				
				fetch next from LocCur into @smbid,@pid,@LocalS_id
				
				while @@fetch_status=0
				begin
					select @locationid=0
				
					select @locationid=l_id from locationtrace where p_id=@pid and s_id=@LocalS_id and billtype = 160 and Y_ID = @Y_id
				
					if @locationid<>0 update Buymanagebilldrf set location_id=@locationid where smb_id=@smbid
			
					fetch next from LocCur into @smbid,@pid,@LocalS_id
				end
			  close LocCur
		    deallocate LocCur
		  
		
	    if @@ERROR <> 0 Return -1

end else if @nbilltype = 161
begin
	exec TS_H_CreateBillSN 151, 1, null, @CenterEid, @Centerinputman, @szSN output

	 insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				 ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
				 posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
				 SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate,ZBAuditMan,ZBAuditDate) 
	
				select billdate, @szSN, 151, 0, Y_ID, @CenterEid, @CenterSid, @CenterSid, @Centerauditman, @Centerinputman, 
				ysmoney, 0, 0, quantity, taxrate, 0, 3, 0, 0, 2,
				Posid, 0, GETDATE(), 0, ysmoney, 0, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,NEWID(),
				SendQTY,0,jsInvoiceTotal,VIPCardID,C_ID,begindate,Enddate,ZBAuditMan,ZBAuditDate
				from billidx where billid=@nbillid
	
				select @nnewbillid=@@identity
	
		insert into salemanagebillDrf(bill_id, p_id, batchno,quantity, costprice,saleprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
				     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,taxrate,order_id, total, iotag,
				     InvoiceTotal,thqty,newprice,orgbillid,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,sendcosttotal,Rowguid,RowE_id, YcostPrice,YGUID, Y_ID, instoretime,
				     BatchBarCode,scomment,batchprice)
			select   @nnewbillid, p_id, batchno,quantity, YCostprice,buyprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
				     makedate, validdate, qualitystatus, price_id, @CenterSid, 0, 0, supplier_id, commissionflag, comment,unitid,taxrate,0, total, iotag,
				     InvoiceTotal,0,newprice,0,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,SendQty*Ycostprice,newid(),@CenterEid, YcostPrice,YGUID,@Y_ID, instoretime,
				     BatchBarCode,scomment,batchprice
			from buymanagebill where bill_id=@nbillid /*and p_id > 0*/
			order by smb_id
			
			declare LocCur cursor for
			select smb_id,p_id
			from salemanagebilldrf
			where bill_id=@nnewbillid
			
			open LocCur
				
			fetch next from LocCur into @smbid,@pid
				
			while @@fetch_status=0
			begin
				select @locationid=0
				select @locationid=l_id from locationtrace where p_id=@pid and s_id=@CenterSid and Y_ID = @Y_ID
				
				update salemanagebilldrf set location_id=@locationid where smb_id=@smbid and Y_ID = @Y_ID
			
				fetch next from LocCur into @smbid,@pid
			end
			close LocCur
			deallocate LocCur
				
			/*exec ts_c_updatecostprice @billid,'stodts'*/
			/*分支机构手工录入退货单时,入库成本价库库退货价*/
	        update salemanagebilldrf
	          set costprice = discountprice, sendCosttotal= sendQty*discountprice
		      where bill_id = @nnewbillid and costprice = 0   

end

  return 0
GO
