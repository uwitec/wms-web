

CREATE	  PROCEDURE [Ts_L_InsPrice]
	(@Price_id	[int],
	 @p_id	[int],
	 @u_id	[smallint],
	 @retailprice	NUMERIC(25,8),
	 @price1	NUMERIC(25,8),
	 @price2	NUMERIC(25,8),
	 @price3	NUMERIC(25,8),
	 @price4	NUMERIC(25,8),
	 @gpprice	NUMERIC(25,8),
	 @glprice	NUMERIC(25,8),
	 @specialprice	NUMERIC(25,8),
	 @recPrice	NUMERIC(25,8),
	 @unitType	TinyInt,
	 @LowPrice	NUMERIC(25,8),
	 @DbName	[varchar](30)='PRICE',
	 @POSID		[int]=0)
AS 
/*Params Ini begin*/
if @DbName is null  SET @DbName = 'PRICE'
if @POSID is null  SET @POSID = 0
/*Params Ini end*/
if @dbName='PRICE' 
begin
	if Exists(select Price_id from price where P_id=@p_id and UnitType=@Unittype)
	begin
		if @u_id=0 
		delete from price where P_id=@p_id and UnitType=@Unittype
		else
		UPDATE [price] 
		
		SET  [p_id]	 = @p_id,
			 [u_id]  = @u_id,
			 [retailprice]	 = @retailprice,
			 [price1]	 = @price1,
			 [price2]	 = @price2,
			 [price3]	 = @price3,
			 [price4]	 = @price4,
			 [gpprice]	 = @gpprice,
			 [glprice]	 = @glprice,
			 [specialprice]  = @specialprice ,
			 [recPrice]	 = @recPrice,
			 [unittype]	 = @UnitType,
			 [lowPrice]	 = @LowPrice
		WHERE 
			(P_id=@p_id) and (UnitType=@Unittype)
	end else
	begin
		INSERT INTO [price] 
			 ( [p_id],
			 [u_id],
			 [retailprice],
			 [price1],
			 [price2],
			 [price3],
			 [price4],
			 [gpprice],
			 [glprice],
			 [specialprice],
			 [recPrice],
			 [UnitType],
			 [lowPrice]) 
		 
		VALUES 
			( @p_id,
			 @u_id,
			 @retailprice,
			 @price1,
			 @price2,
			 @price3,
			 @price4,
			 @gpprice,
			 @glprice,
			 @specialprice,
			 @recPrice,
			 @unitType,
			 @LowPrice)
	end
end
if @dbName='POSPRICE'
begin
	if Exists(select Price_id from Posprice where P_id=@p_id and UnitType=@Unittype and Y_id=@posid)
	begin
		if @u_id=0 
		delete from PosPrice where P_id=@p_id and UnitType=@Unittype and Y_id=@posid
		else
		UPDATE [Posprice] 
		
		SET  	 [p_id]	 = @p_id,
			 [u_id]  = @u_id,
			 [Y_id]	=@Posid,
			 [retailprice]	 = @retailprice,
			 [price1]	 = @price1,
			 [price2]	 = @price2,
			 [price3]	 = @price3,
			 [price4]	 = @price4,
			 [gpprice]	 = @gpprice,
			 [glprice]	 = @glprice,
			 [specialprice]  = @specialprice ,
			 [recPrice]	 = @recPrice,
			 [unittype]	 = @UnitType,
			 [lowPrice]	 = @LowPrice
		WHERE 
			(P_id=@p_id) and (UnitType=@Unittype) and (Y_id=@posid)
	end else
	begin
		INSERT INTO [Posprice] 
			 ( [p_id],
			 [u_id],
			 [Y_id],
			 [retailprice],
			 [price1],
			 [price2],
			 [price3],
			 [price4],
			 [gpprice],
			 [glprice],
			 [specialprice],
			 [recPrice],
			 [UnitType],
			 [lowPrice]) 
		 
		VALUES 
			( @p_id,
			 @u_id,
			 @posid,
			 @retailprice,
			 @price1,
			 @price2,
			 @price3,
			 @price4,
			 @gpprice,
			 @glprice,
			 @specialprice,
			 @recPrice,
			 @unitType,
			 @LowPrice)
	end

/*写入机构"复制物价"临时表	*/
	if Exists(select Price_id from PospriceTmp where P_id=@p_id and UnitType=@Unittype and Y_id=@posid)
	begin
		if @u_id=0 
		delete from PosPriceTmp where P_id=@p_id and UnitType=@Unittype and Y_id=@posid
		else
		UPDATE [PospriceTmp] 
		
		SET  	 [p_id]	 = @p_id,
			 [u_id]  = @u_id,
			 [Y_id]	=@Posid,
			 [retailprice]	 = @retailprice,
			 [price1]	 = @price1,
			 [price2]	 = @price2,
			 [price3]	 = @price3,
			 [price4]	 = @price4,
			 [gpprice]	 = @gpprice,
			 [glprice]	 = @glprice,
			 [specialprice]  = @specialprice ,
			 [recPrice]	 = @recPrice,
			 [unittype]	 = @UnitType,
			 [lowPrice]	 = @LowPrice
		WHERE 
			(P_id=@p_id) and (UnitType=@Unittype) and (Y_id=@posid)
	end else
	begin
		INSERT INTO [PospriceTmp] 
			 ( [p_id],
			 [u_id],
			 [Y_id],
			 [retailprice],
			 [price1],
			 [price2],
			 [price3],
			 [price4],
			 [gpprice],
			 [glprice],
			 [specialprice],
			 [recPrice],
			 [UnitType],
			 [lowPrice]) 
		 
		VALUES 
			( @p_id,
			 @u_id,
			 @posid,
			 @retailprice,
			 @price1,
			 @price2,
			 @price3,
			 @price4,
			 @gpprice,
			 @glprice,
			 @specialprice,
			 @recPrice,
			 @unitType,
			 @LowPrice)
	end
	
end
GO
