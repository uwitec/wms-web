
CREATE PROCEDURE Ts_t_FLQuery(
    @RP_id INT /*协议id*/
)
AS 
	SELECT c.name AS cname,
	       ISNULL(p.product_id, 0)product_id,
	       ISNULL(p.class_id, '000000')class_id,
	       ISNULL(p.serial_number, '') AS pserial,
	       ISNULL(p.name, '')NAME,
	       ISNULL(p.alias, '') AS palias,
	       ISNULL(p.[standard], '')[standard],
	       ISNULL(p.Factory, '')Factory,
	       ISNULL(p.child_number, 0)child_number,
	       fl.id,
	       fl.FlCondition,
	       fl.FlSjQty,
	       fl.FlSaleSjQty,
	       fl.FlSJBuyTotal,
	       fl.FlSJBackTotal,
	       fl.flStates,
	       fl.beginTime,
	       fl.EndTime,
	       fl.Formula,
	       fl.GuessTotal,
	       fl.Flmoney,
	       States = CASE fl.FLStates
	                     WHEN 0 THEN '未完成'
	                     WHEN 1 THEN '完成'
	                     WHEN 2 THEN '已返利'
	                END,
	       ISNULL(p.[makearea], '') as [makearea]
	FROM   FLCondition fl
	       INNER JOIN products p
	            ON  fl.P_id = p.product_id
	       INNER JOIN clients c
	            ON  c.client_id = fl.C_id
	WHERE  (@RP_id = 0 OR fl.RP_id = @RP_id)
GO
