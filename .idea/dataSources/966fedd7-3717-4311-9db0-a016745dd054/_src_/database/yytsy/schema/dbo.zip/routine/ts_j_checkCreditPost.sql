
/*nReturnNumber
	-23:超出往来单位信用额度
	-24:超出职员信用额度
	-25:超出机构收款期限
*/
CREATE  procedure ts_j_checkCreditPost
(
	@nBillId int,
	@nVchtype int,
	@nReturnNumber int output,
	@nMode int =0,
	@jsye NUMERIC(25,8) =0, 
	@ny_id int = 0,
	@nC_id int =0,
	@nE_ID int = 0 
)
/*with encryption*/
as
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
if @jsye is null  SET @jsye = 0
if @ny_id is null  SET @ny_id = 0
if @nC_id is null  SET @nC_id = 0
if @nE_ID is null  SET @nE_ID = 0
/*Params Ini end*/
set nocount on
  declare @nCCredit int, @nECredit int, @nControlAPCredit int, @E_ID int, @C_ID int, @Y_ID int
  declare @dArCredit NUMERIC(25,8), @dAPCredit NUMERIC(25,8), @dECredit NUMERIC(25,8), @dEApCredit NUMERIC(25,8), @dEArtotal NUMERIC(25,8), @dEApTotal NUMERIC(25,8) 
  declare @djsye NUMERIC(25,8), @dArtotal NUMERIC(25,8), @dAptotal NUMERIC(25,8), @dDraftJE NUMERIC(25,8), @dEDraftJE NUMERIC(25,8)
    
  set @nReturnNumber = 0
  
    IF @nVchtype = 150 /* 检查机构收款期限*/
    BEGIN
    	DECLARE @bPubCompanyCredit INT
		SELECT @bPubCompanyCredit = CAST(sysvalue AS INT) FROM sysconfig WHERE [sysname] = 'PubCompanyCredit' and Y_ID = 0
		IF @bPubCompanyCredit = 1 
		BEGIN
			DECLARE @nLimit INT
			DECLARE @YId INT
			SELECT TOP 1 @YId = c.c_id, @nLimit = ISNULL(c.sklimit, 0)
			  FROM Companybalance c 
			WHERE c.c_id IN (SELECT b.c_id FROM billdraftidx b WHERE b.billid = @nBillId) 
			IF @nLimit > 0
			BEGIN
				DECLARE @LastBillDate DATETIME
				DECLARE @drafBillDate DATETIME
				
				SELECT TOP 1 @LastBillDate = ISNULL(b.billdate, 999999) 
				FROM billidx b WHERE b.c_id = @YId AND b.billtype = 150 AND b.billstates = 0 AND b.jsye > 0 ORDER BY b.billid DESC
				
				SELECT @drafBillDate  = b.billdate FROM billdraftidx b WHERE b.billid = @nBillId
				SET @LastBillDate = @LastBillDate + @nLimit
				
				IF @LastBillDate < @drafBillDate 
				BEGIN
					SET @nReturnNumber = -25
					RETURN 0
				END
			END
		END		
    END
    
  if @nVchtype not in (10,14,20, 210) return 0
  set @dDraftJE = 0
  set @dEDraftJE = 0
  
  if @nMode =1 and @nVchtype in (10,14,20) 
  begin
    if @jsye = 0 return 0
    set @E_ID = @nE_ID
    set @C_ID = @nC_id
    set @Y_ID = @ny_id
    set @djsye = @jsye
    if exists(select 1 from sysconfigTmp where sysname = 'checkClientsDraftCredit' and sysvalue = '0') /*检查往来单位信用额度是否包含草稿 add by luowei 2013-05-23*/
    select @dDraftJE = isnull(SUM(jsye),0) from billdraftidx where billtype in (10,14) and billid  <> @nBillId and c_id = @nC_id
    if exists(select 1 from sysconfigTmp where sysname = 'checkEmployeesDraftCredit' and sysvalue = '0') /*检查往来单位信用额度是否包含草稿 add by luowei 2013-05-23*/
    select @dEDraftJE =isnull(SUM(jsye),0) from billdraftidx where billtype in (10,14) and billid  <> @nBillId and c_id = @nC_id and e_id = @nE_ID
  end   
  else
    select @E_ID = e_id, @C_ID = c_id, @Y_ID = Y_ID, @djsye = jsye from billdraftidx where billid  = @nBillId
  
  select  @dArCredit =  credit_total, @dAPCredit= apcredit_total, @dArtotal = artotal, @dAptotal = aptotal from Clientsbalance where Y_id = @Y_ID and C_ID = @C_ID
  
  select @nControlAPCredit = CAST(sysvalue as int) from sysconfig where [sysname] = 'ControlAPCredit' and Y_ID = 0
  
  if @nControlAPCredit = 1 set @dArtotal = @dArtotal - @dAptotal
  if @nVchtype = 10 and @dArCredit > 0
  begin
    if @dArCredit < (@dArtotal+@djsye + @dDraftJE)
    begin
      set @nReturnNumber = -23
      return 0
    end    
  end
  
  if @nVchtype = 20 and @dAPCredit > 0
  begin
    if @dAPCredit < (@dArtotal+@djsye + @dDraftJE)
    begin
      set @nReturnNumber = -23
      return 0
    end    
  end
  
  if @nVchtype = 14 and @dArCredit > 0
  begin
    if @dArCredit < (@dArtotal+@djsye + @dDraftJE)
    begin
      set @nReturnNumber = -23
      return 0
    end    
  end
  
  select @dECredit= arlimit, @dEApCredit = aplimit, @dEArtotal= artotal,  @dEApTotal = aptotal from employees where emp_id = @E_ID
  
  if @dECredit > 0
  begin
    if @dECredit < (@dEArtotal + @djsye + @dEDraftJE)
    begin
      set @nReturnNumber = -24
      return 0
    end
  end
  
  set @nReturnNumber = 0
  return 0
GO
