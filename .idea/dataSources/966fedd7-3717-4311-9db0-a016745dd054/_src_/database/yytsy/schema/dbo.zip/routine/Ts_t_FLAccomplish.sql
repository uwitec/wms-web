
CREATE PROCEDURE Ts_t_FLAccomplish(@nid INT = 0)
AS
/*Params Ini begin*/
if @nid is null  SET @nid = 0
/*Params Ini end*/
	DECLARE @id          INT,
	        @npid        INT,
	        @pri         NUMERIC(25,8),
	        @jsmode      INT,
	        @Rp_id       INT,
	        @month       VARCHAR(100),
	        @quantity    INT,
	        @total       NUMERIC(25,8),
	        @batotal     NUMERIC(25,8),
	        @begintime   DATETIME,
	        @endtime     DATETIME,
	        @relation    VARCHAR(6),
	        @FLModulus   NUMERIC(25,8),
	        @Qty         NUMERIC(25,8),	/*到达返利标准的实际采购数量*/
	        @bmoney      NUMERIC(25,8),	/*到达返利标准的实际采购金额（含税）*/
	        @hmoney      NUMERIC(25,8),	/*到达返利标准的实际回款金额*/
	        @Tmoney      NUMERIC(25,8),	/*到达返利标准的实际采购金额（不含税）*/
	        
	        @taxprice    NUMERIC(25,8),	/*限定采购价要达到返利协议要求的价格*/
	        @limMonth    VARCHAR(100),	/*限定采购的月份要在返利协议要求的月份*/
	        @flMoney     NUMERIC(25,8),/*返利金额*/
	                                /*@limQty      NUMERIC(25,8),    --限定采购数量要达到返利协议要求的数量*/
	                                /*@limhmoney   NUMERIC(25,8),    --回款金额要达到返利协议要求的金额  */
	                                /*@limbmoney   NUMERIC(25,8)     --限定采购金额达到返利协议要求的金额*/
			@SQty        NUMERIC(25,8),
			@SaleQty     INT            /*销售数量*/
	DECLARE conditplish CURSOR  
	FOR
	    SELECT id, price, [Month], begintime, endtime, P_id, Flrelation,
	           quantity, BuyTotal, BackTotal, Fljsmode, Rp_id, FLModulus, SaleQty                                                                                  
	    FROM   FLCondition
	    WHERE  (Rp_id = @nid OR @nid = 0) AND (FLStates <> 2)
	OPEN conditplish
	FETCH NEXT FROM conditplish INTO @id,@pri,@month,@begintime,@endtime,@npid,@relation,
									 @quantity, @total,@batotal,@jsmode,@Rp_id,@FLModulus, @SaleQty                                                                                                                                                                                                              
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    SET @Qty = 0 
	    SET @bmoney = 0.00
	    SET @hmoney = 0.00
	    SET @Tmoney = 0.00
	    SET @taxprice = 0.00
	    SET @flMoney = 0.00
	    SET @limMonth = '1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12'
	    SET @SQty = 0
	    
	    SELECT @hmoney = ISNULL(ABS(SUM(a.jdmoney)), 0)
	    FROM   accountdetail a
	           INNER JOIN billidx b ON  a.billid = b.billid
	    WHERE  a.jdmoney < 0
	           AND a.a_id IN (SELECT account_id
	                          FROM   account
	                          WHERE  parent_id LIKE '000001000004%'
	                             OR  account_id = 6)
	           AND a.c_id IN (SELECT c_id
	                          FROM   flprovider
	                          WHERE  Rp_id = @Rp_id)
	           AND b.billdate BETWEEN @begintime AND @endtime AND b.billstates = 0 
	    
	    IF SUBSTRING(@relation, 2, 1) = '1' /*按价格返利（限定采购价要达到返利协议要求的价格）*/
	    BEGIN
	        SET @taxprice = @pri
	    END
	    ELSE
	    BEGIN
	        SET @taxprice = 0
	    END
	    IF SUBSTRING(@relation, 5, 1) = '1' /*按月份返利（限定采购的月份要在返利协议要求的月份）*/
	    BEGIN
	        SET @limMonth = @month
	    END
	    ELSE
	    BEGIN
	        SET @limMonth = '1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12'
	    END
	    
	    SELECT @Qty = ISNULL(SUM(CASE WHEN bd.billtype IN (20, 220) THEN bm.quantity ELSE -bm.quantity END), 0),
	           @bmoney = ISNULL(SUM(CASE WHEN bd.billtype IN (20, 220) THEN bm.taxtotal ELSE -bm.taxtotal END), 0),
	           @Tmoney = ISNULL(SUM(CASE WHEN bd.billtype IN (20, 220) THEN bm.totalmoney ELSE -bm.totalmoney END), 0)
	    FROM   buymanagebill bm LEFT JOIN billidx bd ON  bm.bill_id = bd.billid
	    WHERE  bd.c_id IN (SELECT c_id FROM flprovider WHERE Rp_id = @Rp_id)
	           AND bm.p_id IN (SELECT p_id FROM flCdetail WHERE fc_id = @id)
	           AND bd.billdate BETWEEN @begintime AND @endtime AND bd.billstates = 0
	           AND bd.billtype IN (20, 21, 220, 221) AND bm.taxprice >= @taxprice
	           AND MONTH(bd.billdate) IN (SELECT [TYPE] FROM DecodeStr(@limMonth))
	           
	    SELECT @SQty = ISNULL(SUM(CASE WHEN bd.billtype IN (10, 12) THEN bm.quantity ELSE -bm.quantity END), 0)
	    FROM   Salemanagebill bm LEFT JOIN billidx bd ON  bm.bill_id = bd.billid
	    WHERE  bm.supplier_id IN (SELECT c_id FROM flprovider WHERE Rp_id = @Rp_id)
	           AND bm.p_id IN (SELECT p_id FROM flCdetail WHERE fc_id = @id)
	           AND bd.billdate BETWEEN @begintime AND @endtime AND bd.billstates = 0
	           AND bd.billtype IN (10, 11, 12, 13) AND bm.taxprice >= @taxprice
	           AND MONTH(bd.billdate) IN (SELECT [TYPE] FROM DecodeStr(@limMonth))       
	    
	    SET @flMoney = CASE @jsmode
	                        WHEN 1 THEN @Tmoney * @FLModulus
	                        WHEN 2 THEN @bmoney * @FLModulus
	                        WHEN 3 THEN @hmoney * @FLModulus
	                        WHEN 4 THEN @total * @FLModulus
	                        WHEN 5 THEN @batotal * @FLModulus
	                        WHEN 6 THEN @Qty * @FLModulus
	                        WHEN 7 THEN @SQty * @FLModulus
	                        ELSE 0.00
	                   END
	    
	    IF SUBSTRING(@relation, 1, 1) = '1' /*按数量（限定采购数量要达到返利协议要求的数量）*/
	    BEGIN
	        IF @SQty < @SaleQty
	        BEGIN
	            SET @flMoney = 0
	        END
	    END
	    
	    IF SUBSTRING(@relation, 3, 1) = '1' /*按购进金额（限定采购金额达到返利协议要求的金额）*/
	    BEGIN
	        IF @bmoney < @total
	        BEGIN
	            SET @flMoney = 0
	        END
	    END
	    
	    IF SUBSTRING(@relation, 4, 1) = '1' /*按回款金额（回款金额要达到返利协议要求的金额）*/
	    BEGIN
	        IF @hmoney < @batotal
	        BEGIN
	            SET @flMoney = 0
	        END
	    END
	    
	    IF SUBSTRING(@relation, 6, 1) = '1' /*按销售数量（限定销售数量要达到返利协议要求的数量）*/
	    BEGIN
	        IF @SQty < @SaleQty
	        BEGIN
	            SET @flMoney = 0
	        END
	    END
	    
	    UPDATE FLCondition
	    SET    FlSjQty = @Qty,
	           FlsjBuytotal = @bmoney,
	           FlSJBackTotal = @hmoney,
	           Flmoney = @flMoney,
	           FlSaleSjQty = @SQty
	    WHERE  id = @id AND FLStates <> 2
	    
	    UPDATE FLCondition
	    SET    FLStates = 1
	    WHERE  @Qty <> 0 AND FlStates = 0 AND id = @id  
	    
	    UPDATE RebehoofProtocol
	    SET    states = 1
	    WHERE  id = @Rp_id AND states = 0
	           AND EXISTS (SELECT 1 FROM FlCondition WHERE FlStates IN (1, 2) AND id = @id)
	           
	    FETCH NEXT FROM conditplish INTO @id,@pri,@month,@begintime,@endtime,@npid, @relation,
									     @quantity,@total,@batotal,@jsmode,@Rp_id,@FLModulus, @SaleQty
	END
	CLOSE conditplish
	DEALLOCATE conditplish
GO
