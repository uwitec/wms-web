











CREATE VIEW dbo.vw_Price
AS
SELECT ISNULL(dbo.unit.name, '') AS UnitName, dbo.price.*
FROM dbo.price LEFT OUTER JOIN
      dbo.unit ON dbo.price.u_id = dbo.unit.unit_id
GO
