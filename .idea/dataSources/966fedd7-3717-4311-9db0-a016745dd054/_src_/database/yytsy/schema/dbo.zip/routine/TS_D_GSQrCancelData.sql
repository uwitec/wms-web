
create procedure TS_D_GSQrCancelData
@GSDDNo VARCHAR(30)='' /*定点编号*/
as 
  SET NOCOUNT ON 
  
  DECLARE @TGSP_id INT,@Return VARCHAR(8000) 
  SET @Return=''
  SELECT @TGSP_id=MAX(GSP_id) FROM GSProductMap WHERE GSDDNo=@GSDDNo 
  
  SELECT p_id,GSP_id  
  INTO #ProductMap 
  FROM GSProductMap
  WHERE GSDDNo=@GSDDNo AND GSP_id>0 AND GSP_id<=@TGSP_id AND IsUp=0
  
  SELECT b.billid,b.p_id
  INTO #ProductMap_1
  FROM #ProductMap a INNER JOIN GSProductMap b 
       ON a.p_id=b.p_id AND b.IsUp=1 AND b.IsDel=0 
  WHERE b.GSP_id<=@TGSP_id
  /*将同一商品多个已上传的直接删除,只保留一个*/
  UPDATE R SET  
  IsDel=2
  FROM GSProductMap R INNER JOIN #ProductMap_1 CI 
       ON R.billid=CI.billid
       LEFT JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap_1 GROUP BY p_id
       ) M ON CI.billid=M.billid
  WHERE M.billid IS NULL 
  
  UPDATE R SET  
  IsDel=3
  FROM GSProductMap R
       INNER JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap_1 GROUP BY p_id
       ) CI ON R.billid=CI.billid
       
  SELECT @Return=@Return+R.serial_number+'|'+R.serial_number_y+'|'+R.name_Y+'|'+R.UnitName+'|'+R.standard+'|$'
  FROM GSProductMap R
       INNER JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap_1 GROUP BY p_id
       ) CI ON R.billid=CI.billid
       
  IF EXISTS(SELECT 1 FROM #ProductMap_1 GROUP BY p_id HAVING COUNT(1)=1)
     SET @Return=LEFT(@Return,LEN(@Return)-1)
       
  UPDATE GSTransNum SET TGSP_id=@TGSP_id WHERE GSDDNo=@GSDDNo       
    
  SELECT @Return 
  
  DROP TABLE #ProductMap
  DROP TABLE #ProductMap_1
GO
