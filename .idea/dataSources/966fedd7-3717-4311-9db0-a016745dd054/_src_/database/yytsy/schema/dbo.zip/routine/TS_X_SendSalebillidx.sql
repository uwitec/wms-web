
/******************************************
复核单查询（物流配送）
作者：XXX
创建日期 2015-04-11
********************************************/
CREATE PROCEDURE TS_X_SendSalebillidx
(	
    @nmode			int = 0 ,   /*0表示全部查询，1表示只查待配送的,2表示配送中的，3表示完成*/
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间*/
	@e_id			int,         /*经手人*/
	@billtype       int=0,       /*GSP单据类型*/
	@billnumber     varchar(30) ='',  /*单据编号*/
	@Y_id           int=0,  /*业务机构*/
	@c_id           int=0,  /* 往来单位*/
	@nSendC_id      int=0,   /*收货方	  */
	@cp_id          int=0,  /* 往来机构  */
	@s_id           int=0,   /*仓库ID*/
	@billstates     int=0,   /*单据状态*/
	@SendRoad		int=0,   /*配送线路*/
	@TrafficType    varchar(30) = '', /*承运方式*/
	@TrafficCompany varchar(30) = '',     /*承运单位  TrafficCompany*/
	@DriverID        int=0,				/*驾驶员*/
	@yw_type        int=0,  /*-- 业务类型*/
	@p_id           int=0,     /*商品ID*/
	@orderbill      varchar(30) = '', /*订单编号	*/
	@billid         int=0     /*单据id 在启用wms 流程的时候使用*/
)
as
BEGIN
	if @billtype is null set @billtype = 0
	if @billnumber is null set @billnumber = ''
	if @Y_id is null set @Y_id = 0
	if @billtype = 563 set @Y_id = 0    /*门店退货申请单需要查询所有门店的数据*/
	if @c_id is null set @c_id = 0
	if @cp_id is null set @cp_id = 0
	if @s_id is null set @s_id = 0
	if @billstates is null set @billstates = 0
	if @SendRoad is null set @SendRoad = 0
	if @p_id is null set @p_id = 0
	if @yw_type is null set @yw_type = 0
	if @TrafficCompany is null set @TrafficCompany = ''
	if @orderbill is null set @orderbill = ''
	if @DriverID is null set @DriverID = 0
	if @nSendC_id is null set @nSendC_id = 0
	if @billid is null set @billid = 0     /*处理在启用wms情况下，扫描订单编号*/

	/*SET @billnumber = '%' + @billnumber + '%'*/
	
	if @billid > 0
	begin
		SELECT   g.Gspbillid AS billId, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditmanN1name, 
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, g.AUDITER2 AS auditmanN2name, 
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						 g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						 g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, o.ysmoney as TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN,g.Ybilltype, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,g.TicketDate,
						case when @nmode =2 then SL.TrafficType when g.Ybilltype =20 then isnull(CT.TrafficType,'') else  isnull(o.TrafficType,'') end as TrafficType,
						case when @nmode = 2 then SL.consign_dep when g.Ybilltype =20 then isnull(CT.TrafficCompany,'') else isnull(o.TrafficCompany,'') end as TrafficCompany,
						ISNULL(SL.Driver,'') AS Drivername,
						CAST(isnull((o.ysmoney -gd.TaxTotal),0) AS numeric(18,2)) as SYMoney,isnull(g.s_id,0) s_id, 
						case isnull(E.name,'')  when '' then isnull(g.YE_NAME,'') else e.name end   AS ename,
						Case when g.Sendid = 0 then '待配送' when ISNULL(s.Transportation_States,0) = 2 then '配送完成' else '配送中' end as PSState,
						sp.isSpecial,sc.StoreCondition,g.SendCName
		FROM      dbo.VW_GSPBILLIDX AS g
					LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
					LEFT JOIN orderidx O ON g.Yguid = o.Guid
					LEFT JOIN (select Y_id, yguid,Ybillid,SUM(TaxTotal) as TaxTotal from (
								select gb.Y_id,  Gspsmb_id,Ybillid,yguid,case when gb.BillStates = 15 then isnull(CheckQty * TaxPrice,0) else 0 end as TaxTotal  from GSPbilldetail gt 
								left join GSPbillidx gb on gt.Gspbill_id = gb.Gspbillid )
								tmp
								group by Ybillid,yguid,Y_id ) 
								gd on gd.yguid = o.Guid and gd.Y_id=o.Y_ID
					/*LEFT JOIN SendRoad sr on g.roadid=sr.RoadID*/
					LEFT JOIN (select billid,max(isSpecial) as isSpecial from(
									select gsp.Gspbill_id as billid,CASE WHEN /*gspflag=2*/p.isspec = 1 THEN 1 ELSE 0 END AS isSpecial from GSPbilldetail gsp 
									left join vw_Products p on gsp.P_id=p.product_id 
									) gd group by billid 
								)sp ON g.Gspbillid = sp.billid /*特殊药品*/
					LEFT JOIN (select billid,max(StoreCondition) as StoreCondition from(
									select gd.Gspbill_id as billid, CASE WHEN StoreCondition = 2 THEN 1 ELSE 0 END AS StoreCondition from GSPbilldetail gd  
									LEFT JOIN products P ON GD.P_id = P.product_id 
									)gd group by billid  
							   )sc ON g.Gspbillid = sc.billid/*含冷链药品*/
					LEFT JOIN employees E ON O.e_id=E.emp_id  
					LEFT JOIN Sendmangebill s ON s.billid = g.Gspbillid
					LEFT JOIN (select Send_id,sb.Driver as DriverID,sb.TrafficType,sb.consign_dep,lo.Driver from Sendidx sb LEFT JOIN logisticsInfo Lo on lo.id = sb.Driver)
							SL ON SL.Send_id = G.Sendid
					LEFT JOIN (SELECT Yguid,max(TrafficType) TrafficType,max(TrafficCompany) TrafficCompany,max(TrafficTime) TrafficTime FROM gspbillidx WHERE BillType = 561 group by Yguid
							   ) CT on g.Yguid = ct.Yguid   /*采购退出申请单特殊处理*/
		WHERE   g.Gspbillid = @billid
	end
	else
	begin

		SELECT   g.Gspbillid AS billId, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
						g.AUDITER1 AS auditmanN1name, 
						/*g.AuditTime1, */
						(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
						g.AuditMan2, g.AUDITER2 AS auditmanN2name, 
						/*g.AuditTime2, */
						(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
						 g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
						 g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, o.ysmoney as TaxTotal, g.BillStates, 
						g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
						g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN,g.Ybilltype, g.YBillTypeName AS ywtype, 
						g.YBILLNUMBER, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,g.TicketDate,
						case when @nmode =2 then SL.TrafficType when g.Ybilltype =20 then isnull(CT.TrafficType,'') else  isnull(o.TrafficType,'') end as TrafficType,
						case when @nmode = 2 then SL.consign_dep when g.Ybilltype =20 then isnull(CT.TrafficCompany,'') else isnull(o.TrafficCompany,'') end as TrafficCompany,
						ISNULL(SL.Driver,'') AS Drivername,
						CAST(isnull((o.ysmoney -gd.TaxTotal),0) AS numeric(18,2)) as SYMoney,isnull(g.s_id,0) s_id, 
						case isnull(E.name,'')  when '' then isnull(g.YE_NAME,'') else e.name end   AS ename,
						Case when g.Sendid = 0 then '待配送' when ISNULL(s.Transportation_States,0) = 2 then '配送完成' else '配送中' end as PSState,
						sp.isSpecial,sc.StoreCondition,g.SendCName
		FROM      dbo.VW_GSPBILLIDX AS g
					LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
					LEFT JOIN orderidx O ON g.Yguid = o.Guid
					LEFT JOIN (select Y_id, yguid,Ybillid,SUM(TaxTotal) as TaxTotal from (
								select gb.Y_id, Gspsmb_id,Ybillid,yguid,case when gb.BillStates = 15 then isnull(CheckQty * TaxPrice,0) else 0 end as TaxTotal  from GSPbilldetail gt 
								left join GSPbillidx gb on gt.Gspbill_id = gb.Gspbillid )
								tmp
								group by Ybillid,yguid, Y_id) 
								gd on gd.yguid = o.Guid and gd.Y_id=o.Y_ID
					/*LEFT JOIN SendRoad sr on g.roadid=sr.RoadID*/
					LEFT JOIN (select billid,max(isSpecial) as isSpecial from(
									select gsp.Gspbill_id as billid,CASE WHEN /*gspflag=2*/p.isspec = 1 THEN 1 ELSE 0 END AS isSpecial from GSPbilldetail gsp 
									left join vw_Products p on gsp.P_id=p.product_id 
									) gd group by billid 
								)sp ON g.Gspbillid = sp.billid /*特殊药品*/
					LEFT JOIN (select billid,max(StoreCondition) as StoreCondition from(
									select gd.Gspbill_id as billid, CASE WHEN StoreCondition = 2 THEN 1 ELSE 0 END AS StoreCondition from GSPbilldetail gd  
									LEFT JOIN products P ON GD.P_id = P.product_id 
									)gd group by billid  
							   )sc ON g.Gspbillid = sc.billid/*含冷链药品*/
					LEFT JOIN employees E ON O.e_id=E.emp_id  
					LEFT JOIN Sendmangebill s ON s.billid = g.Gspbillid
					LEFT JOIN (select Send_id,sb.Driver as DriverID,sb.TrafficType,sb.consign_dep,lo.Driver from Sendidx sb LEFT JOIN logisticsInfo Lo on lo.id = sb.Driver)
							SL ON SL.Send_id = G.Sendid
					LEFT JOIN (SELECT Yguid,max(TrafficType) TrafficType,max(TrafficCompany) TrafficCompany,max(TrafficTime) TrafficTime FROM gspbillidx WHERE BillType = 561 group by Yguid
							   ) CT on g.Yguid = ct.Yguid   /*采购退出申请单特殊处理*/
		WHERE   (g.BillType = @billtype) AND (g.BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
			AND (@nmode = 0 or (@nmode = 1 and g.Sendid = 0) or (@nmode = 2 and s.Transportation_States < 2) or (@nmode = 3 and s.Transportation_States = 2)) 
			AND (@c_id = 0 OR IsCompany = 0 AND g.C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND g.C_id = @cp_id)
			AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR g.BillStates = @billstates) AND (@p_id = 0 OR Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
			AND (@yw_type = 0 OR Ybilltype = @yw_type)   
			/*AND (YBILLNUMBER LIKE @orderbill) AND (g.BillNumber LIKE @billnumber)  --*/
			AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(0))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(0)))
			AND (@TrafficType = '' or @TrafficType= '[全部]' 
				OR (@nmode = 2 and charindex(@TrafficType, isnull(SL.TrafficType,'')) > 0 ) 
				or (@nmode <> 2 and  charindex(@TrafficType, isnull(o.TrafficType,'')) > 0) 
				or (@nmode <> 2 and g.Ybilltype =20 and  charindex(@TrafficType, isnull(CT.TrafficType,'')) > 0) 
				or (@nmode <> 2 and (isnull(o.TrafficType,'')= '' and g.Ybilltype <>20 and charindex('自提',@TrafficType) > 0) or charindex(@TrafficType, isnull(o.TrafficType,'')) > 0))  /*方式为空的默认为自提*/
			AND (IsCompany = 0 AND g.C_id IN (SELECT c_id from SendRoadCheck where RoadID = @SendRoad group by c_id) or @SendRoad = 0)
			AND (@e_id = 0 or O.e_id = @e_id)
			AND (@TrafficCompany = '' OR g.TrafficCompany = @TrafficCompany)   /*承运单位*/
			AND (@DriverID = 0 OR SL.DriverID = @DriverID) /*驾驶员	*/
			AND (@nSendC_id = 0 or g.SendC_id = @nSendC_id ) /*收货方*/
			order by g.C_id
		
	end
end
GO
