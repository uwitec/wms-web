




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
应收账款、应付账款
********************************************/
CREATE PROCEDURE [dbo].[TS_H_RepArApQuery] 
( @szParid   	VARCHAR(30)='000000',
  @szListFlag CHAR(1)='L',
  @BeginDate  DATETIME=0,
  @EndData    DATETIME=0,
  @nE_ID      INT=0,
  @szYClass_id varchar(50)
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParid is null  SET @szParid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @BeginDate is null  SET @BeginDate = 0
if @EndData is null  SET @EndData = 0
if @nE_ID is null  SET @nE_ID = 0
/*Params Ini end*/
SET NOCOUNT ON

DECLARE
  @SQLScript VARCHAR(8000),@SQLFilterY VARCHAR(200),
  @SQLTemp   VARCHAR(200), @SQLYClassId VARCHAR(200),
  @AR_ID     VARCHAR(30),
  @AP_ID     VARCHAR(30),
  @szTable   VARCHAR(10),
  @SONNUM    INT,
  @CTable varchar(100),		/*往来单位授权*/
  @Companytable varchar(100),		/*分支机构授权*/
  @szY_ID		varchar(100),
  @EClass_id varchar(30),
  @YClass_id varchar(30),
  @nloginEID int,
  @nDetachArap int,
  @szPeriod   CHAR(2)
  
  set @szPeriod = ''

  
  set @YClass_id = @szYClass_id
  set @nloginEid = @nE_ID
    
  SET @SQLFilterY='' SET @SQLYClassId='' /*SET @SQLFilterE='' */

  select @EClass_id = ''
  select @nDetachArap = sysvalue from sysconfig where sysname = 'ControlAPCredit'

  if @EClass_id='' set @EClass_id='%%' else set @EClass_id=@EClass_id+'%'  /*增加经手人查询*/

  IF @YClass_id not in ('','000000','%%')    /*增加分支机构查询 */
  BEGIN
     /*SET @SQLYClassId = ' and YClass_ID like '''+@YClass_id+'%'''*/
     SELECT @szY_ID =cast(company_id as varchar(100)) from company where Class_id=@YClass_id
     SET @SQLYClassId = ' and (Y_id='+@szY_ID+' or (superior_id='+@szY_ID+' and yType=1) )'
  END
  ELSE SET @SQLYClassId = ' ' 

/*---------增加授权控制---------------------*/
  create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      SET @SQLFilterY = ' and (Y_id in (select [id] from #Companytable))'
   end
/*---分支机构授权*/
/*---------增加授权控制  完成---------------------*/

  IF NOT (EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c') 
     OR EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c' and u.psc_id='000000') )
    SET @szTable='Clients'
  ELSE BEGIN
    SELECT * INTO ##Client FROM
    (SELECT  [client_id], [class_id], [parent_id], [child_number], [child_count], [serial_number], [name], [alias], 
             [region_id], [phone_number], [address], [zipcode], [contact_personal], [tax_number], [acount_number],
             [credit_total], [pinyin], [pricemode], [sklimit], [artotal], [artotal_ini], [aptotal], [aptotal_ini],
             [pre_artotal], [pre_artotal_ini], [pre_aptotal], [pre_aptotal_ini], [firstcheck], [comment], [csflag], 
             [deleted], [ProtocolDate], [GMPNo], [GSPNo], [Cetype], [ModifyDate], [RowIndex], [IncRate], [licence_no], 
             [ent_type], [city_id], [city_name], [boro_id], [boro_name],U.* FROM Clients C
		INNER JOIN Userauthorize U ON C.[Class_ID] LIKE (U.[Psc_ID]+'%')
		WHERE U.[Type]='c' AND U.[E_ID]=@nloginEID) C
    SET @szTable='##Client'
  END

  SELECT @AR_ID='000001000005', @AP_ID='000002000001'
  SELECT @SONNUM=[Child_Number] FROM Clients WHERE [Class_ID]=@szParid

  IF @SONNUM>0
  BEGIN
    IF @szListFlag='L'  SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Parent_ID]='+CHAR(39)+@szParID+CHAR(39)
    IF @szListFlag='A' 	SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Child_number]=0'
    IF @szListFlag='P' 	SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Child_number]=0 AND LEFT(a.[Class_ID], LEN('+CHAR(39)+@szParID+CHAR(39)+'))='+CHAR(39)+@szParID+CHAR(39)  
  END
  ELSE
  BEGIN
    SELECT @SQLTemp='a.[Class_ID]='+CHAR(39)+@szParID+CHAR(39)
  END

  IF @szPeriod=''
  BEGIN

    SET @SQLScript = 'SELECT YD.*,isnull(E.Class_id,'''')EClass_id,isnull(Y.Class_id,'''')YClass_id,
              isnull(A.Class_id,'''')AClass_id,isnull(C.Class_id,'''')CClass_id,Y.superior_id,Y.YType
  FROM
   (SELECT ad.BILLID,ad.[JdMoney],ad.c_id,b.e_id, ad.a_id,b.Y_id,b.billdate,b.billtype,
   CASE WHEN b.BillType IN (10,12,32,53,112,210) THEN b.ysmoney WHEN B.BillType IN (11,13,54,211) THEN -b.ysmoney ELSE 0 END AS [SaleTotal],
   CASE WHEN B.BillType IN (16,17) THEN B.ysmoney ELSE 0 END AS [SaleAdjustTotal],
   CASE WHEN B.BillType IN (10,21,12,25,32,112,16,15,53,54,210) THEN B.ssmoney ELSE 0 END AS [GatherTotal],
   CASE WHEN B.BillType IN (20,35,122,220) THEN B.ysmoney WHEN B.BillType IN (21,221) THEN -B.ysmoney ELSE 0 END AS [BuyTotal],
   CASE WHEN B.BillType IN (24,25) THEN -B.ysmoney ELSE 0 END AS [BuyAdjustTotal],
   CASE WHEN B.BillType IN (20,11,13,17,24,35,122,23,220) THEN B.ssmoney ELSE 0 END AS [PayTotal]
    FROM AccountDetail ad 
         LEFT JOIN billidx B ON B.billid=ad.billid
    where billtype not in (150,151,155,160,161,165) and B.billstates=0
   )YD
   LEFT JOIN employees E ON YD.e_id=E.emp_id
   LEFT JOIN Company   Y ON YD.Y_id=Y.company_id
   LEFT JOIN Clients   C ON YD.C_ID=C.client_id
   LEFT JOIN Account   A ON YD.a_id=A.account_id
  )AD
  WHERE [AClass_ID] IN ('''+@AR_ID+''', '''+@AP_ID+''')
    and AD.eclass_id like '''+@EClass_id+''''


    SELECT @SQLScript='(SELECT CClass_id as [Class_ID], Y_id,
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate]<'''
        +CONVERT(VARCHAR(10),@BeginDate,20)+''' THEN [JdMoney] END), 0) AS [BeginArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate]<'''
        ++CONVERT(VARCHAR(10),@BeginDate,20)+''' THEN [JdMoney] END), 0) AS [BeginApTotal],

      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [NowArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [NowApTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' AND [BillType] IN (64,65) THEN [JdMoney] END), 0) AS [ArChangeTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' AND [BillType] IN (66,67) THEN [JdMoney] END), 0) AS [ApChangeTotal], 

      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate]<='''
        +CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [EndArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate]<='''
        ++CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [EndApTotal],
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN SaleTotal else 0 end), 0) as saletotal,
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN SaleAdjustTotal else 0 end), 0) as SaleAdjustTotal,
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN GatherTotal else 0 end), 0) as GatherTotal,
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN BuyTotal else 0 end), 0) as BuyTotal,
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN BuyAdjustTotal else 0 end), 0) as BuyAdjustTotal,
		ISNULL(SUM(case when billdate between '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN PayTotal else 0 end), 0) as PayTotal
      FROM (' + @SQLScript +  @SQLFilterY +  @SQLYClassId + 
      ' GROUP BY [CClass_ID], Y_id)'
  END
  ELSE 
    SELECT @SQLScript='(SELECT C.[Class_ID], y.Class_id as [YClass_ID],
      (0) AS [BeginArTotal], (0) AS [BeginApTotal],
      sum(CB.[ArTotal_Ini]) AS [NowArTotal], sum(CB.[ApTotal_Ini]) AS [NowApTotal],
      (0) AS [EndArTotal], (0) AS [EndApTotal] FROM ClientsBalance CB 
      left join clients c on cb.[C_ID]=c.[CLIENT_ID]
      left join company Y ON Y.[Company_id]=CB.[Y_ID] '
      /*+ (case when @YClass_id not in ('','000000','%%') then ' Where Y.Class_ID like '''+@YClass_id+'%''' else ''end )*/
      + (case when @YClass_id not in ('','000000','%%') then ' Where (Y.company_id= '+@szY_ID+' or y.superior_id='+@szY_ID+' and yType=1) )' else ''end )
      + ' group by c.[Class_ID],y.Class_id ) '

  if @nDetachArap=0
  begin  
	  SELECT @SQLScript='SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],
	    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
	    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	    ISNULL(SUM(b.[Archangetotal]), 0) AS [Archangetotal], 
	    ISNULL(SUM(b.[Apchangetotal]), 0) AS [Apchangetotal],
	    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal],
	    ISNULL(SUM(b.[saletotal]), 0) AS [saletotal],
	    ISNULL(SUM(b.[SaleAdjustTotal]), 0) AS [SaleAdjustTotal],
	    ISNULL(SUM(b.[GatherTotal]), 0) AS [GatherTotal],
	    ISNULL(SUM(b.[BuyTotal]), 0) AS [BuyTotal],
	    ISNULL(SUM(b.[BuyAdjustTotal]), 0) AS [BuyAdjustTotal],
	    ISNULL(SUM(b.[PayTotal]), 0) AS [PayTotal]
	    FROM '+@szTable+' a 
	    LEFT JOIN (
	    SELECT a.[Class_ID],
	    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])>0 THEN SUM(a.[Artotal]-a.[Aptotal]) ELSE 0 END, 0) AS [Artotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])<0 THEN -(SUM(a.[Artotal]-a.[Aptotal])) ELSE 0 END, 0) AS [Aptotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
	    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])>0 THEN SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowArTotal], 
	    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])<0 THEN -SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowApTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal],
	    ISNULL(CASE WHEN SUM(b.[ArChangeTotal]-b.[ApChangetotal])>0 THEN SUM(b.[ArChangetotal]-b.[ApChangetotal]) ELSE 0 END, 0) AS [ArChangetotal], 
	    ISNULL(CASE WHEN SUM(b.[ArChangetotal]-b.[ApChangetotal])<0 THEN -(SUM(b.[ArChangetotal]-b.[ApChangetotal])) ELSE 0 END, 0) AS [ApChangetotal], 
	    ISNULL(SUM(b.[saletotal]), 0) AS [saletotal],
	    ISNULL(SUM(b.[SaleAdjustTotal]), 0) AS [SaleAdjustTotal],
	    ISNULL(SUM(b.[GatherTotal]), 0) AS [GatherTotal],
	    ISNULL(SUM(b.[BuyTotal]), 0) AS [BuyTotal],
	    ISNULL(SUM(b.[BuyAdjustTotal]), 0) AS [BuyAdjustTotal],
	    ISNULL(SUM(b.[PayTotal]), 0) AS [PayTotal]
	    FROM (select * from ( select c.class_id,y.class_id as YClass_id,
				  c.Child_Number,c.Deleted,cb.* ,Y.superior_id,Y.YType
			          FROM ClientsBalance cb 
				  left join clients c on cb.c_id = c.client_id
				  left join company y on y.company_id = cb.y_id 
				) aa
	          WHERE [Child_Number]=0 AND [Deleted]<>1 ' + @SQLFilterY + @SQLYClassId +
	    ' ) a LEFT JOIN'
	    +@SQLScript+' b
	    ON a.[Class_ID]=b.[Class_ID] and b.Y_id=a.Y_id  GROUP BY a.[Class_ID]) b
	    ON LEFT(b.[Class_ID], LEN(a.[Class_ID]))=a.[Class_ID]
	    WHERE '+@SQLTemp+' 
	    GROUP BY a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name], a.[Alias], 
	    a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal]'
  end
  else 
	  SELECT @SQLScript='SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],
	    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
	    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	    ISNULL(SUM(b.[Archangetotal]), 0) AS [Archangetotal], 
	    ISNULL(SUM(b.[Apchangetotal]), 0) AS [Apchangetotal],
	    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal],
	    ISNULL(SUM(b.[saletotal]), 0) AS [saletotal],
	    ISNULL(SUM(b.[SaleAdjustTotal]), 0) AS [SaleAdjustTotal],
	    ISNULL(SUM(b.[GatherTotal]), 0) AS [GatherTotal],
	    ISNULL(SUM(b.[BuyTotal]), 0) AS [BuyTotal],
	    ISNULL(SUM(b.[BuyAdjustTotal]), 0) AS [BuyAdjustTotal],
	    ISNULL(SUM(b.[PayTotal]), 0) AS [PayTotal]
	    FROM '+@szTable+' a 
	    LEFT JOIN (
	    SELECT a.[Class_ID],
	    ISNULL(SUM(a.[Artotal]), 0) AS [Artotal], 
	    ISNULL(SUM(a.[Aptotal]), 0) AS [Aptotal], 
	    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)), 0) AS [BeginArTotal], 
	    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[BeginApTotal], 0)), 0) AS [BeginApTotal], 
	    ISNULL(SUM(b.[NowArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[NowApTotal]), 0) AS [NowApTotal], 
	    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)), 0) AS [EndArTotal], 
	    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[EndApTotal], 0)), 0) AS [EndApTotal],
	    ISNULL(SUM(b.[saletotal]), 0) AS [saletotal],
	    ISNULL(SUM(b.[SaleAdjustTotal]), 0) AS [SaleAdjustTotal],
	    ISNULL(SUM(b.[GatherTotal]), 0) AS [GatherTotal],
	    ISNULL(SUM(b.[BuyTotal]), 0) AS [BuyTotal],
	    ISNULL(SUM(b.[BuyAdjustTotal]), 0) AS [BuyAdjustTotal],
	    ISNULL(SUM(b.[PayTotal]), 0) AS [PayTotal],
	    ISNULL(SUM(b.[ArChangetotal]), 0) AS [ArChangetotal], 
	    ISNULL(SUM(b.[ApChangetotal]), 0) AS [ApChangetotal] 
	    FROM (select * from ( select c.class_id,y.class_id as YClass_id,
				  c.Child_Number,c.Deleted,cb.* ,y.superior_id,Y.YType
			          FROM ClientsBalance cb 
				  left join clients c on cb.c_id = c.client_id
				  left join employees e on cb.e_id=e.emp_id  
				  left join company y on y.company_id = cb.y_id 
				) aa
	          WHERE [Child_Number]=0 AND [Deleted]<>1 ' + @SQLFilterY + @SQLYClassId +
	    ' ) a LEFT JOIN'
	    +@SQLScript+' b
	    ON a.[Class_ID]=b.[Class_ID] and b.Y_id=a.Y_id  GROUP BY a.[Class_ID]) b
	    ON LEFT(b.[Class_ID], LEN(a.[Class_ID]))=a.[Class_ID]
	    WHERE '+@SQLTemp+' 
	    GROUP BY a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name], a.[Alias], 
	    a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal]'

/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO SUCCEE


SUCCEE:
  IF EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c') 
	   OR EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c' and u.psc_id='000000')
     DROP TABLE [dbo].[##Client]

  RETURN 0
GO
