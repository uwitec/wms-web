
/* exec TS_D_GSTransNum '1234567890123457'*/
CREATE PROCEDURE TS_D_GSDownDate
@GSDDNo VARCHAR(30),
@TransCode VARCHAR(10)
AS
  DECLARE @ReturnStr VARCHAR(50),@ReadDate DATETIME
  IF NOT EXISTS(SELECT 1 FROM GSTransNum WHERE GSDDNo=@GSDDNo)
  BEGIN
    INSERT INTO GSTransNum
      (GSDDNo,TransNum)
    SELECT @GSDDNo,0
  END    
  SELECT @ReadDate=CASE WHEN @TransCode='8106' THEN NoticeDate 
                        WHEN RIGHT(@TransCode,1)='1' THEN ReadDate01 
                        WHEN RIGHT(@TransCode,1)='2' THEN ReadDate02 
                        WHEN RIGHT(@TransCode,1)='3' THEN ReadDate03 
                        WHEN RIGHT(@TransCode,1)='4' THEN ReadDate04 
                        WHEN RIGHT(@TransCode,1)='5' THEN ReadDate05                         
                   ELSE GETDATE()
                   END
  FROM GSTransNum 
  WHERE GSDDNo=@GSDDNo
  
  SET @ReturnStr=CONVERT(VARCHAR(30),@ReadDate,121)
  SET @ReturnStr=LEFT(REPLACE(REPLACE(REPLACE(@ReturnStr,'-',''),' ',''),':',''),14)
  
  IF @TransCode LIKE '1300%'
  BEGIN 
	UPDATE GSTransNum SET ReadDate01=GETDATE() WHERE GSDDNo=@GSDDNo AND RIGHT(@TransCode,1)='1'
	UPDATE GSTransNum SET ReadDate02=GETDATE() WHERE GSDDNo=@GSDDNo AND RIGHT(@TransCode,1)='2'
	UPDATE GSTransNum SET ReadDate03=GETDATE() WHERE GSDDNo=@GSDDNo AND RIGHT(@TransCode,1)='3'
	UPDATE GSTransNum SET ReadDate04=GETDATE() WHERE GSDDNo=@GSDDNo AND RIGHT(@TransCode,1)='4'
	UPDATE GSTransNum SET ReadDate05=GETDATE() WHERE GSDDNo=@GSDDNo AND RIGHT(@TransCode,1)='5'
  END
  UPDATE GSTransNum SET NoticeDate=GETDATE() WHERE GSDDNo=@GSDDNo AND @TransCode='8106'
   
  SELECT @ReturnStr
GO
