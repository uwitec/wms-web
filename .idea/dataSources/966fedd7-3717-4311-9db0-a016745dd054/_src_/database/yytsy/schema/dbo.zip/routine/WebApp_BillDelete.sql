CREATE proc WebApp_BillDelete
 (
   @intuserid  int,
   @billid INT=0,
   @params VARCHAR(100), --预留接口
   @RetMessage varchar(200) out
 )
--$encode$--
as
 BEGIN
 	DECLARE @resnewbillid INT,@newbillid INT,@billtype int
 	SELECT @newbillid=wab.drfbillid,@billtype=wab.billtype FROM WebApp_Billidx wab WHERE wab.billid=@billid
 	DELETE FROM WebApp_Billidx WHERE billid=@billid
 	DELETE FROM WebAPP_BillDrf WHERE billid=@billid
 	DELETE FROM WebAPP_BillAccount WHERE billid=@billid
 	
 	exec @resnewbillid=WebAPP_BillAutoDelete @intuserid,@newbillid, @billtype,@params,@RetMessage=@RetMessage out
		IF @resnewbillid<0
			RETURN -1;
	RETURN @resnewbillid;
 END
GO
