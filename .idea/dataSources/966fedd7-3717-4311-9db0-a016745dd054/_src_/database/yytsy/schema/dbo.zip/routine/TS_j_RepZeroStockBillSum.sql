
/********************************************/
CREATE PROCEDURE TS_j_RepZeroStockBillSum
(	@nC_ID			INT = 0,
	@nPEID			INT = 0, /*商品基本资料中主采购员*/
	@nEID			int = 0 ,
	@nInputMan      INT = 0,
	@szPClassID     varchar(50) = '000000',
	@nY_ID          int,
	@nQrMode		INT=0,    /*0 有基本资料 1 无基本资料*/
	@begindate      datetime = 0,
	@EndDate		datetime = 0,
	@CurY_ID		int = 0, /*当前登录机构   */
    @nLoginEid      INT=0
)
AS
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = 0
if @nPEID is null  SET @nPEID = 0
if @nEID is null  SET @nEID = 0 
if @nInputMan is null  SET @nInputMan = 0
if @szPClassID is null  SET @szPClassID = '000000'
if @nQrMode is null  SET @nQrMode = 0
if @begindate is null  SET @begindate = 0
if @EndDate is null  SET @EndDate = 0
if @CurY_ID is null  SET @CurY_ID = 0
if @nLoginEid is null  SET @nLoginEid = 0
/*Params Ini end*/
SET NOCOUNT ON
if @szPClassID = '' or @szPClassID = '000000' 
  set @szPClassID = '%%'
else set @szPClassID = @szPClassID +'%'  

if @nQrMode = 0
begin                            
	select 	   
		  p.[Product_ID], P.[Class_ID],p.[Child_Number],p.[Name],p.[Code],
		  p.[AliAS],p.[standard],p.[Modal],p.[Makearea],P.[Rate2],p.[Rate3],p.[Rate4],
		  p.[Deduct],p.tc1,p.tc2,p.tcmoney,p.UnitName1,p.UnitName2,p.UnitName3,p.UnitName4,
		  p.[Factory],p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
		  p.Custompro3,p.Custompro4,p.Custompro5, pr.retailprice, pr.glprice, pr.gpprice, pr.price1,
		  pr.price2, pr.price3, pr.recprice, pr.specialprice,
		  p.peid, p.pename,
		  mx.quantity, mx.ComeQty, mx.quantity-mx.ComeQty as uncomeqty 		  
	  from  
		ZeroStockBill mx
		inner join (select vp.* , ISNULL(pb.peid, 0) as peid, ISNULL(pename, '') as pename
		              from vw_c_Products vp 
		              left join (select Emp_id as peid, e_name as pename, p_id from vw_productbalance where Y_id= @CurY_ID) pb 
		                      on vp.Product_ID = pb.p_id
		              where vp.Class_ID like  @szPClassID) p 
		        on mx.p_id = p.Product_ID
		inner join ZeroStockIDX bi on mx.bill_id = bi.billid 
		left join
		( 
		    select * from price  where unittype=1
		 ) pr on mx.p_id= pr.p_id and mx.unitid = pr.u_id
	  where 
		mx.aoid = 0 and p.Deleted = 0 and p.Child_number =0  and (@nPEID =0 or p.peid = @nPEID) and
		(@nC_ID =0 or bi.c_id = @nC_ID) and (@nEID =0  or bi.e_id= @nEID) and 
		(@nInputMan=0 or bi.inputman = @nInputMan) and bi.billdate between @begindate and @EndDate
		and (@nY_ID = 0 or bi.Y_ID=@nY_ID) 
		          
end 
else begin
  select 	   
		  0 as [Product_ID], '' as [Class_ID],0 as [Child_Number],mx.pname as [Name], '' as[Code],
		  '' as [AliAS],mx.[Pstandard]  as [standard], '' as [Modal],   mx.PMakearea as [Makearea],
		  cast(0 AS NUMERIC(25,8)) as [Rate2], cast(0 AS NUMERIC(25,8)) as [Rate3], cast(0 AS NUMERIC(25,8)) as [Rate4], 
		  cast(0 AS numeric(8,4)) as [Deduct], cast(0 AS NUMERIC(25,8)) as tc1, cast(0 AS NUMERIC(25,8)) as tc2,
		  cast(0 AS NUMERIC(25,8)) as tcmoney,'' UnitName1, '' UnitName2,'' UnitName3, '' UnitName4,
		  '' [Factory],'' Inputman, GETDATE() as InputDate, '' Custompro1, '' Custompro2,
		  '' Custompro3, '' Custompro4, ''Custompro5, cast(0 AS NUMERIC(25,8)) as retailprice, cast(0 AS NUMERIC(25,8))glprice, 
		  cast(0 AS NUMERIC(25,8)) gpprice, cast(0 AS NUMERIC(25,8)) price1, cast(0 AS NUMERIC(25,8)) price2, 
		  cast(0 AS NUMERIC(25,8)) price3, cast(0 AS NUMERIC(25,8)) recprice, cast(0 AS NUMERIC(25,8)) specialprice, 		
		  0 peid, '' pename,
		  mx.quantity, mx.ComeQty, mx.quantity-mx.ComeQty as uncomeqty 		  
	  from  
		ZeroStockBill mx
		inner join ZeroStockIDX bi on mx.bill_id = bi.billid 
	  where 
		mx.aoid = 1 and
		(@nC_ID =0 or bi.c_id = @nC_ID) and (@nEID =0  or bi.e_id= @nEID) and 
		(@nInputMan=0 or bi.inputman = @nInputMan) and bi.billdate between @begindate and @EndDate
		and (@nY_ID = 0 or bi.Y_ID=@nY_ID) 

end              
   
  RETURN 0
GO
