/************************************************************

--功能：读取GMP证书关联的剂型范围的字符串

**************************************************************/

CREATE function [GetGMPMedString]
  ( @ga_id int
  )
  returns nvarchar(2000)
AS 

  begin
	declare @returnStr nvarchar(2000)
	declare @mid smallint
	declare @mname varchar(50)
	declare @checkedFlag smallint
	set @returnStr = ''
	declare @curGMP cursor
	set @curGMP = cursor for
	  select m.id as mt_id,m.name as  mt_name , Case when GMPmt_id is null then 0 else 1 end as checkedFlag 
		from customCategory m
		left join  (select mt_id as GMPmt_id from GMPMedtype where ga_id = @ga_id) g
		on m.id = g.GMPmt_id
  open @curGMP
	FETCH next from @curGmp into @mid,@mname,@checkedFlag  
	  while @@FETCH_STATUS = 0
	  begin
	    if @checkedFlag = 1 
	    begin
	      if @returnStr = ''
		    set @returnStr =  @mname
		  else
		    set @returnStr = @returnStr +',' + @mname 
		end
		fetch next from @curGmp into @mid,@mname,@checkedFlag    
	  end 
  close @curgmp
  deallocate @curgmp
  
  return @returnStr
 end
GO
