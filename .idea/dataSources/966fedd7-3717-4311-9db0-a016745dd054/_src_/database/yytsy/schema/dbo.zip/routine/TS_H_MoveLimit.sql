/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014.06.14*/
/* Description:	权限搬移*/
/* =============================================*/
CREATE PROCEDURE TS_H_MoveLimit 
	@nOldLim int = 0,
	@nNewLim int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @bLim binary(1)
	DECLARE @nEmp int
	DECLARE @iFor int
	DECLARE @ptrval binary(16)
	DECLARE @iLen int

	BEGIN TRAN

	declare curMove scroll cursor for
	SELECT emp_id FROM employees
	OPEN curMove

	set @iFor = 0
	while @iFor < @@cursor_rows
	begin
		fetch next from curMove into @nEmp
		SELECT @iLen = DATALENGTH(LIM) FROM employees WHERE emp_id = @nEmp
		IF @iLen > @nNewLim AND @iLen > @nOldLim
		BEGIN
			SELECT @bLim = CAST(SUBSTRING(LIM, @nOldLim + 1, 1) AS binary) FROM employees WHERE emp_id = @nEmp
			SELECT @ptrval = TEXTPTR(lim) FROM employees where emp_id = @nEmp
			UPDATETEXT employees.lim @ptrval @nNewLim 1 @bLim;
			SET @bLim = 0x0
			UPDATETEXT employees.lim @ptrval @nOldLim 1 @bLim;
		END
		set @iFor = @iFor + 1
	END
	DEALLOCATE curMove
	COMMIT TRAN
END
GO
