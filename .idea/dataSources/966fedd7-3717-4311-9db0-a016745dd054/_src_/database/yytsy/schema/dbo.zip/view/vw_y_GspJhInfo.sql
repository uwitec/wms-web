

create view dbo.vw_y_GspJhInfo
as
  select a.BillNumber,a.Gspbillid,a.C_id,
    isnull((case when a.Ybilltype not in (150,151,152,153,155,160,161,162,163,165) then c.[name] else d.[name] END), '') as name,
    isnull((case when a.Ybilltype not in (150,151,152,153,155,160,161,162,163,165) then c.address else d.opaddress end),'') as Address,
    isnull((case when a.Ybilltype not in (150,151,152,153,155,160,161,162,163,165) then c.contact_personal else d.manager end), '') as Contact_personal,
    isnull((case when a.Ybilltype not in (150,151,152,153,155,160,161,162,163,165) then c.phone_Number else d.tel end), '') as Phone_Number,    
    b.totalQty,b.wholeQty,b.partQty,b.startNum,b.endNum
  from  GSPbillidx a
  inner join GspJhInfo b on a.Gspbillid=b.jhBillId 
  LEFT  join clients   c on a.C_id=c.client_id
  LEFT  join company   d on a.C_id=D.company_id
GO
