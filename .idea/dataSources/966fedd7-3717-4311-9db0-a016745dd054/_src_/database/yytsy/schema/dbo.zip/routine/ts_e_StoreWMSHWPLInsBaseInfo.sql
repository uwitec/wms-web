create procedure ts_e_StoreWMSHWPLInsBaseInfo
 @QY_id  integer=0,/*区域ID*/
 @BeginCode varchar(100),/*起始编号*/
 @LocationType     integer=0,/*货架类型*/
 @PickEasy   integer=0,/*挑选难易程度*/
 @stockpilePgNum integer=0,/*可以存放品规数*/
 @nRet       int OUTPUT,
 @NewHwCode  varchar(100) OUTPUT
as
declare @s_id integer
declare @KQ_id integer
declare @Hwcodestr varchar(2000)
declare @EndCode varchar(2000)
declare @i  integer
select @s_id=b.s_id,@KQ_id=b.sa_id from WMSRegion a left join stockArea b on a.Store_KQ_ID=b.sa_id where a.ID=@QY_id
begin
   select @Hwcodestr=dbo.GetWMSHWCode(1,@BeginCode) 
   set @i=0
   while @i=0 
   begin
      if exists (select 1 from location  where loc_code =@Hwcodestr and deleted=0)
      begin
        select @Hwcodestr=dbo.GetWMSHWCode(1,@Hwcodestr)  
      end
      else
      begin
        set @i=1
      end
   end
   set @NewHwCode=@Hwcodestr
   if not  exists (select 1 from location  where loc_code =@BeginCode and deleted=0)
   begin 
       insert into  location(s_id,loc_code,loc_name,Regionid,LocationType,PickEasy,stockpilePgNum,sa_id)
	   values(@s_id,@BeginCode,@BeginCode,@QY_id,@LocationType,@PickEasy,@stockpilePgNum,@KQ_id)
	   set  @nRet= @@IDENTITY
   end
   else
   begin
      set @EndCode=@Hwcodestr
      if not  exists (select 1 from location  where loc_code =@EndCode and deleted=0)
      begin 
           insert into  location(s_id,loc_code,loc_name,Regionid,LocationType,PickEasy,stockpilePgNum,sa_id)
		   values(@s_id,@EndCode,@EndCode,@QY_id,@LocationType,@PickEasy,@stockpilePgNum,@KQ_id)
		   set  @nRet= @@IDENTITY
      end
   end
end
GO
