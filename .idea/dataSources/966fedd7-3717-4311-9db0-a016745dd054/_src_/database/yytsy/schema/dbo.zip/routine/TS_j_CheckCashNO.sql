
/* =============================================*/
/* Author:		zjilin	*/
/* Create date: 2013-05-27*/
/* Description:	检查代金券位数是否足够生成*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_j_CheckCashNO] 	
	@NOCount  int, /*代金券位数		*/
	@quantity  int /*发行数量		*/
AS

if @NOCount < 8 
  return -8

if @quantity <1
  return -1  
  
declare @i int, @nSeed bigint, @nRecCount bigint
set @i =1
set @nSeed = 1
while @i < @NOcount
begin
  set @nSeed = @nSeed*10
  set @i = @i + 1
end

select  @nRecCOUNT = count(1) from Cashcoupon where LEN(CashNO) = @NOCount
if (@nSeed-@nRecCOUNT-1) < @quantity
  Return -1
else
  Return 0
GO
