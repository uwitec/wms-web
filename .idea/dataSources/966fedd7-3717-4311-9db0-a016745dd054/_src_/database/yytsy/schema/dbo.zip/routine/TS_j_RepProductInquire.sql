
/********************************************/
CREATE PROCEDURE TS_j_RepProductInquire
(	@nMode			int,   /*0 销售 1 采购*/
	@nC_ID			INT = 0,
	@nEID			int = 0 ,
	@nInputMan      INT = 0,
	@szPClassID     varchar(50) = '000000',
	@nY_ID          int,
	@nQrMode		INT=0,    /*0 全部 1 有效 2 无效*/
	@begindate      datetime = 0,
	@EndDate		datetime = 0,
	@ValidEndDate   datetime = 0,   
    @nLoginEid      INT=0
)
AS
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = 0
if @nEID is null  SET @nEID = 0 
if @nInputMan is null  SET @nInputMan = 0
if @szPClassID is null  SET @szPClassID = '000000'
if @nQrMode is null  SET @nQrMode = 0
if @begindate is null  SET @begindate = 0
if @EndDate is null  SET @EndDate = 0
if @ValidEndDate is null  SET @ValidEndDate = 0
if @nLoginEid is null  SET @nLoginEid = 0
/*Params Ini end*/
SET NOCOUNT ON
if @szPClassID = '' or @szPClassID = '000000' 
  set @szPClassID = '%%'
else set @szPClassID = @szPClassID +'%'  

declare @dToday datetime
set @dToday = CAST(CAST(getdate() as varchar(10)) as datetime) 


   select 
		  bi.[BillID],   bi.[Billtype], bi.[Billdate], bi.[Billnumber], bi.[Billstates],
		  bi.[Inputman], bi.[Auditman], bi.[Note],     bi.[Summary],    bi.[Auditdate],
		  bi.[begindate], bi.[Enddate],  
		  [Billname]=CASE bi.[Billtype]
		  WHEN 18 THEN '销售报价单'
		  WHEN 27 THEN '采购报价单'
		  END,
		  bi.[Ename]          AS [Employeename],
		  bi.[Auditmanname]   AS [Auditmanname],
		  bi.[Inputmanname]   AS [Inputmanname],
		  bi.[Departmentname] AS [Departmentname],
		  bi.[Regionname]     AS [Regionname],
		  bi.[Cname],
		  mx.price,  pr.retailprice, p.[Product_ID], P.[Class_ID],p.[Child_Number],p.[Name],p.[Code],
		  p.[AliAS],p.[standard],p.[Modal],p.[Makearea],p.[Rate2],p.[Rate3],p.[Rate4],
		  p.[Factory],p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
		  p.Custompro3,p.Custompro4,p.Custompro5
   from (select pb.*, u.name as UnitName
           from priceinquirebill pb left join unit u on pb.unitid = u.unit_id
           where pb.y_id = @nY_ID and pb.p_id in (select product_id from products where class_id like @szPClassID)
         ) mx
   inner join (  select *
                 from vw_j_priceInquireidx    
                 where y_id = @nY_ID and billdate between @begindate and @EndDate and billstates  = 3 and
                       ((@nC_ID =0 and c_id in (select client_id from AuthorizeClients(@nLoginEid))) or c_id = @nC_ID) and
                       ((@nMode = 0 and billtype = 18) or (@nMode = 1 and billtype = 27)) and
                       ((@nEID = 0 and e_id in (select emp_id from AuthorizeEmployees(@nLoginEid))) or e_id = @nEID) and (@nInputMan = 0 or InputMan = @nInputMan) and
                       ((@nQrMode = 0 ) or (@nQrMode = 1 and endDate >= @dToday) or (@nQrMode = 2 and endDate < @dToday)) and
                       ((@ValidEndDate < 5) or ((@ValidEndDate >5 and endDate < @ValidEndDate)))
              ) bi on mx.bill_id = bi.billid
   left join (select * 
               from vw_Products  /*FilterProduct(@nY_ID)*/
               where class_id like @szPClassID
              ) as p on mx.p_id = p.product_id         
   left join price pr on pr.p_id = mx.p_id and mx.unitid = pr.u_id
  RETURN 0
GO
