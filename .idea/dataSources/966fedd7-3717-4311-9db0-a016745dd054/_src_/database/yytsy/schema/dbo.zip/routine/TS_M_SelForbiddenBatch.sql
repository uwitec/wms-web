
/*禁采/禁销批次表 */
CREATE PROCEDURE TS_M_SelForbiddenBatch
(
	@fbType		int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @fbType is null  SET @fbType = 0
/*Params Ini end*/

/*DECLARE @SQL varchar(8000)*/

SELECT     F.fb_id, ISNULL(F.PermitCode, '') AS PermitCode, ISNULL(F.BatchNo, '') AS BatchNo, F.InputMan, F.InputTime, ISNULL(F.note, '') AS note, 
                      ISNULL(E.name, '') AS InputManName, ISNULL(F.fbType, 0) AS fbType, F.PName, F.P_ID, CAST(ISNULL(MAX(s.stopsaleflag * 1), 0) AS Bit) 
                      AS StopSale
FROM         dbo.ForbiddenBatch AS F LEFT OUTER JOIN
                      dbo.storehouse AS s ON F.BatchNo = s.batchno AND F.P_ID = s.p_id LEFT OUTER JOIN
                      dbo.employees AS E ON F.InputMan = E.emp_id
WHERE			F.fbType = @fbType
GROUP BY F.fb_id, ISNULL(F.PermitCode, ''), ISNULL(F.BatchNo, ''), F.InputMan, F.InputTime, ISNULL(F.note, ''), ISNULL(E.name, ''), ISNULL(F.fbType, 0), 
                      F.PName, F.P_ID
GO
