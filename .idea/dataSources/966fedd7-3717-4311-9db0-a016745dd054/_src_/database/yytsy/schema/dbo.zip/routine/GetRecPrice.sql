








CREATE	  FUNCTION GetRecPrice(@nPId int,@nUid int)  
RETURNS  numeric(25,8)
AS  
BEGIN 
	declare @dRecPrice numeric(25,8)
	select @dRecPrice=isnull(recprice,0) from price where p_id=@nPId and unittype=1 
	if @dRecPrice is null select @dRecPrice=0
	return(@dRecPrice)
END
GO
