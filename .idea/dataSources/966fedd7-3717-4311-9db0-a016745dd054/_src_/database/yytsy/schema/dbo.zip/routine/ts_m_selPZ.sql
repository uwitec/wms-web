

CREATE PROCEDURE [ts_m_selPZ]
(	@BeginDate		DATETIME=0,
	@EndDate		DATETIME=0,
	@nC_ID			INT=0,
    @nBillType      INT=0,
    @szInvoiceNo    varchar(100)=''
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nC_ID is null  SET @nC_ID = 0
if @nBillType is null  SET @nBillType = 0
if @szInvoiceNo is null  SET @szInvoiceNo = ''
/*Params Ini end*/
SET NOCOUNT ON

SELECT  DISTINCT 
        b.billID, b.billtype, b.billdate, b.billstates, b.billnumber, b.skdate,
        b.inputman, b.auditman, b.GatheringMan, b.note, b.SUMmary, b.quantity, 
        ysmoney=case  when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.ysmoney else b.ysmoney end, b.ssmoney, b.araptotal, b.taxrate, b.auditdate, 
        b.[sout_id], b.[sin_id],
        (case when b.billtype in (122,112) then ' ' else b.[ssname] end)ssname ,
        (case when b.billtype in (122,112) then ' ' else b.[sdname] end)sdname,
        CASE WHEN b.billtype IN (44, 45) THEN b.ssname when b.billtype in (171,172,173,174) Then '''' ELSE b.cname END AS cname,
    		b.ename AS employeename, 
    		b.auditmanname,
    		b.inputmanname,
    		b.aname AS accountname,
    		b.departmentname,
    		b.regionname,
		b.GatheringManName,
        isnull(p.printcount,0) as printcount,
        b.Y_id ,b.guid,InvoiceNo=ISNULL(invoiceidx.invoiceno,'')
FROM vw_c_billidx b 
left join productdetail pd ON b.billid=pd.billid  
left join vw_c_printcount p on b.billid=p.Rep_id
left join invoice on invoice.billid=b.billid
left join invoiceidx on invoiceidx.id=invoice.invoiceid
WHERE b.billdate between @BeginDate and  @EndDate
   and ((@nC_ID=0) or  (b.c_id=@nC_ID) )
   and b.billstates=0
   and ((@nBillType=0 and b.billtype in (10,11,12,13,16,17,210,211, 20,21,24,25,220,221)  ) 
        or (b.billtype= @nBillType)  )
   and ((@szInvoiceNo='') or (invoiceidx.InvoiceNo like @szInvoiceNo+'%'))
GO
