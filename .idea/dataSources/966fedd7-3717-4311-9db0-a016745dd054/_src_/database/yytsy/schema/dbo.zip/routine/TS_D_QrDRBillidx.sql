

CREATE procedure TS_D_QrDRBillidx
@BeginDate	DATETIME,
@EndDate	DATETIME,
@nMode INT, /* 0 未确认单据 1 全部单据*/
@OperatorNo INT /*当前登记id*/
AS 
    
    select a.*, 
		   Case when a.billtype  = 12 then '零售单'  
				WHEN a.billtype  = 13 then '零售退货单' 
		   ELSE '' 
		   END billtypename,
		   Case when a.Billstates  = 3 and a.billid = 0 and  a.SettleFlag not in ('600', '601') then '药易通未记账,将取消' 
				when a.Billstates  = 3 and a.billid > 0 AND  a.SettleFlag not in ('600', '601') then '药易通已记账,将确认' 
		   else '正常' 
		   END BillstatesName,         
		   Case when a.SettleFlag  = '11' then '普通购药未确认'  
				WHEN a.SettleFlag  = '600' then '确认结算' 
				when a.SettleFlag  = '13' then '慢性病购药未确认'    
				WHEN a.SettleFlag  = '601' then '取消结算'
				when a.SettleFlag  = '501' then '结算退费未确认'   
		   ELSE ''
		   END SettleFlagName,
		   ISNULL(b.name,'') EmpName                   
    from DRBillidx a LEFT JOIN employees b 
         ON a.OperatorNo=b.emp_id
    where (
            (@nMode=1 AND a.billdate>=@BeginDate AND a.billdate<@EndDate+1) 
            OR (@nMode=0 AND a.SettleFlag NOT IN ('600','601'))  
          )
          AND (@OperatorNo=1 OR a.OperatorNo=@OperatorNo OR a.OperatorNo=0)
    order BY a.DRbillid DESC
GO
