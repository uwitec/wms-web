

CREATE PROCEDURE ts_l_insEditRet 
	@Returnid 	int,
        @nC_id     	int,
	@nP_id     	int,
        @ReturnMode	int,
	@SNo		varchar(30),
        @Name        	varchar(50),
	@begindate	datetime,
	@endDate	datetime,
	@ReturnPrice	NUMERIC(25,8),
	@SaleQty	NUMERIC(25,8),
	@returnRate	NUMERIC(25,8),
	@tag		Smallint,
	@comment	varchar(60),
    @y_id       int
AS

if @returnid=0 
begin
        if exists (select * from Returnstd where (SNO =@SNo or retName =@Name))
        begin
           RAISERROR('返利获利编码重复或者名称重复！', 16, 1)
           RETURN -1  
        end
	insert into Returnstd 
        (c_id,p_id,returnmode,sno,retname,begindate,enddate,returnprice,saleqty,returnRate,tag,comment,y_id) 
	values
	(@nc_id,@np_id,@returnmode,@sno,@name,@begindate,@enddate,@returnprice,@saleqty,@returnRate,@tag,@comment,@y_id)
end else
begin
	if @returnid>0
	begin
	update returnstd set
        c_id=@nC_id,p_id=@np_id,returnmode=@returnmode,sno=@sno,retname=@name,
	 begindate=@begindate,enddate=@enddate,returnprice=@returnprice,
 	 saleqty=@saleQty,returnRate=@returnRate,tag=@tag,comment=@comment,y_id=@y_id
        where returnid=@returnid
	end else
	begin
	  if exists(select top 1 ret_id from ReturnBill where ret_id=abs(@returnid))
 	     or exists(select top 1 ret_id from ReturnBilldrf where ret_id=abs(@returnid))
          begin
 		RAISERROR ('单据已经使用该标准,不允许删除!', 16, 1)
		return -1
	  end
	  delete from returnstd where returnid=abs(@returnid)
	end
end
GO
