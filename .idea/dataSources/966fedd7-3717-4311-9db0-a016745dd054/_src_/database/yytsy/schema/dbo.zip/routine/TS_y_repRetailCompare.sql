
/* 功能：门店零售比较统计
  
*/

CREATE PROCEDURE TS_y_repRetailCompare
( 
	@sPbegindate varchar(20),   /*上期开始时间*/
	@sPenddate   varchar(20),   /*上期结束时间*/
	@sbegindate  varchar(20),   /*本期开始时间*/
	@senddate    varchar(20),   /*本期结束时间*/
	@JAsvalue     int = 0,
	@JAevalue     int = 0,
	@JBsvalue     int = 0,
	@JBevalue     int = 0,
	@JCsvalue     int = 0,
	/*@JCevalue     int = 0,*/
	@MAsvalue     int = 0,
	@MAEvalue     int = 0,
	@MBsvalue     int = 0,
	@MBEvalue     int = 0,
	@MCsvalue     int = 0,
	/*@MCEvalue     int = 0,*/
	@CAsvalue     int = 0,	
	@CAEvalue     int = 0,
	@CBsvalue     int = 0,	
	@CBEvalue     int = 0,	
	@CCsvalue     int = 0	
	/*@CCEvalue     int = 0		  	*/
)
AS
BEGIN
      create table #temp  /*-本期数据*/
             ( 
               Atype      int,
               billid     int,
               billdate   datetime,
               billtype   int,
               Y_ID       int,
               region_id  int,
               quantity   NUMERIC(25,8),
               costprice  NUMERIC(25,8),
               totalmoney NUMERIC(25,8),
               daycount   int,
               ml         NUMERIC(25,8),               
               ksl        int,  /*销售单据数量*/
               lks        numeric(18,2), /*所有单据数量*/
               yxsl       int , /*销售单据数量-退货单据数量*/
               zml        NUMERIC(25,8),
               mlR        numeric(18,2), /*毛利率*/
               zje        NUMERIC(25,8),
               jeavg      numeric(18,2),/*-日均零售*/
               mlavg      numeric(18,2),/*-日均毛利*/
               lksavg     numeric(18,2),/*-日均来客数*/
               Kprice     numeric(18,2),/*-客单价*/
               zsl        numeric(18,2),
               jegx       varchar(10),
               mlgx       varchar(10),
               lkgx       varchar(10),
               taxtotal   NUMERIC(25,8),    
               costtaxtotal  NUMERIC(25,8),
               btaxtotal   NUMERIC(25,8),    
               bcosttaxtotal  NUMERIC(25,8)
              )
      create table #tempP  /*-上期数据*/
             ( 
               Atype      int,
               billid     int,
               billdate   datetime,
               billtype   int,
               Y_ID       int,
               region_id  int,
               quantity   NUMERIC(25,8),
               costprice  NUMERIC(25,8),
               totalmoney NUMERIC(25,8),
               daycount   int,
               ml         NUMERIC(25,8),               
               ksl        int,  /*销售单据数量*/
               lks        numeric(18,2), /*所有单据数量*/
               yxsl       int , /*销售单据数量-退货单据数量*/
               zml        NUMERIC(25,8),
               mlR        numeric(18,2), /*毛利率*/
               zje        NUMERIC(25,8),
               jeavg      numeric(18,2),/*-日均零售*/
               mlavg      numeric(18,2),/*-日均毛利*/
               lksavg     numeric(18,2),/*-日均来客数*/
               Kprice     numeric(18,2),/*-客单价*/
               zsl        numeric(18,2),
               taxtotal   NUMERIC(25,8),    
               costtaxtotal  NUMERIC(25,8),
               staxtotal   NUMERIC(25,8),    
               scosttaxtotal  NUMERIC(25,8)
              ) 
       create table #tempL  /*-汇总数据*/
             ( 
               Atype      int,
               Y_ID       int,
               region_id  int, 
               Pzje       NUMERIC(25,8) DEFAULT 0 ,/*上期金额*/
               zje        NUMERIC(25,8) DEFAULT 0,/*本期金额*/
               addR       numeric(18,2) DEFAULT 0,/*金额增长率*/
               Pzml       NUMERIC(25,8) DEFAULT 0,/*上期毛利*/
               PmlR        numeric(18,2) DEFAULT 0, /*上期毛利率*/
               Pmlavg      numeric(18,2) DEFAULT 0,/*上期日均毛利*/
               zml        NUMERIC(25,8)  DEFAULT 0,/*本期毛利           */
               mlR        numeric(18,2)  DEFAULT 0, /*本期毛利率*/
               mlavg      numeric(18,2)  DEFAULT 0,/*-本期日均毛利             */
               Pjeavg      numeric(18,2) DEFAULT 0,/*上期日均零售*/
               jeavg      numeric(18,2)  DEFAULT 0,/*-本期日均零售*/
               Pksl        numeric(18,2) DEFAULT 0,/*上期客数量*/
               ksl         numeric(18,2) DEFAULT 0, /*本期客数量*/
               Plks        numeric(18,2) DEFAULT 0,/*上期来客数*/
               lks        numeric(18,2) DEFAULT 0, /*本期来客数*/
               lksaddR    numeric(18,2) DEFAULT 0,/*来客数增长率*/
               Plksavg     numeric(18,2) DEFAULT 0,/*-上期日均来客数*/
               lksavg     numeric(18,2) DEFAULT 0, /*-本期日均来客数*/
               PKprice     numeric(18,2) DEFAULT 0,/*-上期客单价*/
               Kprice     numeric(18,2) DEFAULT 0,/*-本期客单价*/
               kdjaddR    numeric(18,2) DEFAULT 0,/*-客单价增长率*/
               jeavgaddR     numeric(18,2) DEFAULT 0,/*日均零售增长率*/
               lksavgaddR    numeric(18,2) DEFAULT 0,/*日均来客数增长率*/
               mlavgaddR     numeric(18,2) DEFAULT 0,/*日均毛利增长率*/
               jegx       varchar(10) DEFAULT '',
               mlgx       varchar(10) DEFAULT '',
               lkgx       varchar(10) DEFAULT '',
               btaxtotal   NUMERIC(25,8) DEFAULT 0,    
               bcosttaxtotal  NUMERIC(25,8) DEFAULT 0,
               staxtotal   NUMERIC(25,8) DEFAULT 0,    
               scosttaxtotal  NUMERIC(25,8) DEFAULT 0
              )  
  /*-------提取数据*/
  /*-本期数据            */
  insert into #temp(Atype,billid,billdate,billtype,Y_ID,region_id,quantity,costprice,totalmoney,ml,taxtotal,costtaxtotal)
  select 1,a.billid,a.billdate,a.billtype,a.Y_ID,a.region_id,b.quantity,b.costprice,b.totalmoney,
  (taxtotal-costtaxtotal) as ml,b.taxtotal,b.costtaxtotal 
  from billidx  a,salemanagebill b
  where a.billdate>=@sbegindate and  a.billdate<=@senddate
        and b.p_id>0 and a.billid=b.bill_id and a.billstates=0 and b.AOID=0
        and a.billtype in (12,13)
  /*-*/
  update #temp set ml=-ml,totalmoney=-totalmoney,taxtotal=-taxtotal,costtaxtotal=-costtaxtotal
  where  billtype in(13)   
  /*本期客数量*/
  insert into #temp(Atype,Y_ID,region_id,ksl) 
  select 2,a.Y_ID,a.region_id,COUNT(a.Y_ID)
  from 
    ( 
      select distinct  billid,Y_ID,region_id
      from #temp
    ) a  
  group by a.Y_ID,a.region_id
  /*来客数*/
  update #temp set lks=b.lks
  from #temp c,
  (
    select a.Y_ID,a.region_id,COUNT(a.Y_ID) as lks
    from 
     ( 
      select distinct  billid,Y_ID,region_id
      from #temp where billtype in(12)
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id   and c.region_id=b.region_id and Atype=2
  /*-yxsl  销售单据数量-退货单据数量*/
  update #temp set yxsl=lks
  where Atype=2
  /*-*/
  update #temp set yxsl=lks-b.ths
  from #temp c,
  (
    select a.Y_ID,a.region_id,COUNT(a.Y_ID) as ths
    from 
     ( 
      select distinct  billid,Y_ID,region_id
      from #temp where billtype in(13)
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id   and c.region_id=b.region_id and Atype=2
  /*有效天数*/
  update #temp set daycount=b.ts
  from #temp c,
  (
    select a.Y_ID,a.region_id,COUNT(billdate) as ts
    from 
     ( 
      select distinct  billdate,Y_ID,region_id
      from #temp 
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id and c.region_id=b.region_id and Atype=2  
  /*-毛利,金额,数量*/
  /*insert into #temp(Atype,Y_ID,region_id,zml,zje,zsl)*/
  update #temp set zml=b.zml,zje=b.zje,zsl=b.zsl,btaxtotal=b.btaxtotal,bcosttaxtotal=b.bcosttaxtotal
  from #temp c,
  (
    select Y_ID,region_id,SUM(ml) as zml,SUM(totalmoney) as zje,SUM(quantity) as zsl,sum(costtaxtotal) as bcosttaxtotal,
           sum(taxtotal) as btaxtotal
    from #temp
    group by  Y_ID,region_id
  ) b
  where c.Y_ID=b.Y_ID and c.region_id=b.region_id and c.Atype=2
  /*-贡献度  A,B,C类*/
  update #temp  set jegx=b.jegx,mlgx=b.mlgx,lkgx=B.lkgx
  from  #temp a,
  (
    select Y_ID,region_id,
    (Case  
     when zje>=@JAsvalue and zje<=@JAevalue then 'A'
     when zje>@JBsvalue and zje<=@JBevalue then 'B'
     when zje>@JCsvalue then  'C'
     else
       ''
     end 
     ) AS jegx,
    (Case  
     when zml>=@MAsvalue and zml<=@MAevalue then 'A'
     when zml>@MBsvalue and zml<=@MBevalue then 'B'
     when zml>@MCsvalue then  'C'
     else
       ''
     end 
     ) AS mlgx,
    (Case  
     when lks>=@CAsvalue and lks<=@CAEvalue then 'A'
     when lks>@CBsvalue and lks<=@CBEvalue then 'B'
     when lks>@CCsvalue then  'C'
     else
       ''
     end 
     ) AS lkgx     
  from  #temp  where Atype=2
  )b
  where a.Y_ID=b.Y_ID and a.region_id=b.region_id and a.Atype=2
  /*---日均零售,日均毛利,日均来客数,客单价,毛利率*/
  update #temp set jeavg=(zje/daycount),mlavg=(zml/daycount),lksavg=(lks/daycount),Kprice=(zje/yxsl),mlR=((zml/zje)*100)  
  where yxsl<>0 and daycount<>0 and yxsl<>0 and Atype=2
  /*-----------------------上期数据*/
  insert into #tempP(Atype,billid,billdate,billtype,Y_ID,region_id,quantity,costprice,totalmoney,ml,taxtotal,costtaxtotal)
  select 1,a.billid,a.billdate,a.billtype,a.Y_ID,a.region_id,b.quantity,b.costprice,b.totalmoney,
  (taxtotal-costtaxtotal) as ml,b.taxtotal,b.costtaxtotal 
  from billidx  a,salemanagebill b
  where a.billdate>=@sPbegindate and  a.billdate<=@sPenddate
        and b.p_id>0 and a.billid=b.bill_id and a.billstates=0 and b.AOID=0
        and a.billtype in (12,13)
  /*-*/
  update #tempP set ml=-ml,totalmoney=-totalmoney,taxtotal=-taxtotal,costtaxtotal=-costtaxtotal
  where  billtype in(13)   
  /*本期客数量*/
  insert into #tempP(Atype,Y_ID,region_id,ksl) 
  select 2,a.Y_ID,a.region_id,COUNT(a.Y_ID)
  from 
    ( 
      select distinct  billid,Y_ID,region_id
      from #tempP
    ) a  
  group by a.Y_ID,a.region_id
  /*来客数*/
  update #tempP set lks=b.lks
  from #tempP c,
  (
    select a.Y_ID,a.region_id,COUNT(a.Y_ID) as lks
    from 
     ( 
      select distinct  billid,Y_ID,region_id
      from #tempP where billtype in(12)
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id   and c.region_id=b.region_id and Atype=2
  /*-yxsl  销售单据数量-退货单据数量*/
  update #tempP set yxsl=lks
  where Atype=2
  /*-*/
  update #tempP set yxsl=lks-b.ths
  from #tempP c,
  (
    select a.Y_ID,a.region_id,COUNT(a.Y_ID) as ths
    from 
     ( 
      select distinct  billid,Y_ID,region_id
      from #tempP where billtype in(13)
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id   and c.region_id=b.region_id and Atype=2
  /*有效天数*/
  update #tempP set daycount=b.ts
  from #tempP c,
  (
    select a.Y_ID,a.region_id,COUNT(billdate) as ts
    from 
     ( 
      select distinct  billdate,Y_ID,region_id
      from #tempP 
      ) a
      group by a.Y_ID,a.region_id
   ) b 
  where c.Y_ID=b.Y_id and c.region_id=b.region_id and Atype=2  
  /*-毛利,金额,数量*/
  update #tempP set zml=b.zml,zje=b.zje,zsl=b.zsl,staxtotal=b.staxtotal,scosttaxtotal=b.scosttaxtotal
  from #tempP c,
  (
    select Y_ID,region_id,SUM(ml) as zml,SUM(totalmoney) as zje,SUM(quantity) as zsl,
           SUM(taxtotal) as staxtotal,SUM(costtaxtotal) as scosttaxtotal
    from #tempP
    group by  Y_ID,region_id
  ) b
  where c.Y_ID=b.Y_ID and c.region_id=b.region_id and c.Atype=2
  /*---日均零售,日均毛利,日均来客数,客单价,毛利率*/
  update #tempP set jeavg=(zje/daycount),mlavg=(zml/daycount),lksavg=(lks/daycount),Kprice=(zje/yxsl),mlR=((zml/zje)*100)  
  where yxsl<>0 and daycount<>0 and yxsl<>0 and Atype=2
  /*--------------------------------------返回查询结果*/
  delete #temp where Atype=1
  delete #tempP where Atype=1  
  /*--所有机构和片区*/
  insert into  #tempL(Atype,Y_ID,region_id)
  select distinct  '1',Y_ID,region_id from #tempP
  union
  select distinct  '1',Y_ID,region_id from #temp
  /*-本期*/
  update #tempL set zje=b.zje,zml=b.zml,mlR=b.mlR,mlavg=b.mlavg,jeavg=b.jeavg,
  ksl=b.ksl,lks=b.lks,lksavg=b.lksavg,Kprice=b.Kprice,jegx=b.jegx,mlgx=b.mlgx,lkgx=b.lkgx,
  btaxtotal=b.btaxtotal,bcosttaxtotal=b.bcosttaxtotal
  from #tempL a,
  (
    select Y_ID,region_id,zje,zml,mlR,mlavg,jeavg,ksl,lks,lksavg,Kprice,jegx,mlgx,lkgx,
    btaxtotal,bcosttaxtotal
    from #temp 
  ) b
  where a.Y_ID=b.Y_ID and a.region_id=b.region_id
  /*-上期*/
  update #tempL set Pzje=b.zje,Pzml=b.zml,PmlR=b.mlR,Pmlavg=b.mlavg,Pjeavg=b.jeavg,
  Pksl=b.ksl,Plks=b.lks,Plksavg=b.lksavg,PKprice=b.Kprice,
  staxtotal=b.staxtotal,scosttaxtotal=b.scosttaxtotal
  from #tempL a,
  (
     select Y_ID,region_id,zje,zml,mlR,mlavg,jeavg,ksl,lks,lksavg,Kprice,taxtotal,costtaxtotal,
            staxtotal,scosttaxtotal
    from #tempP 
  ) b
  where a.Y_ID=b.Y_ID and a.region_id=b.region_id  
  /*--计算数据*/
  /*金额增长率*/
  update #tempL set addR=((zje-Pzje)/Pzje)*100 where Pzje<>0 
  /*来客数增长率*/
  update #tempL set lksaddR=((lks-plks)/plks)*100 where plks<>0 
  /*-客单价增长率*/
  update #tempL set kdjaddR=((Kprice-PKprice)/PKprice)*100 where PKprice<>0 
  /*-日均零售增长率*/
  update #tempL set jeavgaddR=((jeavg-Pjeavg)/Pjeavg)*100 where Pjeavg<>0 
  /*--日均来客数增长率*/
  update #tempL set lksavgaddR=((lksavg-Plksavg)/Plksavg)*100 where Plksavg<>0
  /*日均毛利增长率*/
  update #tempL set mlavgaddR=((mlavg-Pmlavg)/Pmlavg)*100 where Pmlavg<>0
  
  select b.name as Yname,c.name as Rname,a.* 
  from #tempL a
  left join company b on a.Y_ID=b.company_id
  left join Region  c on a.region_id=c.region_id
  order by a.Y_ID,a.region_id
  
  
  drop table  #temp 
  drop table  #tempP 
  drop table  #tempL  
END
GO
