


CREATE PROCEDURE [ts_L_insCardtype]
	(@CTypeId	[numeric], /*0:Add  >0: update   <0: delete*/
	 @TypeName	[varchar](20),
	 @Discount	[numeric](8,4),
	 @Comment	[varchar](50),
	 @AutoDiscount	[char](1))

AS 

/*-----------------------------------------*/
if @Ctypeid=0
	INSERT INTO [cardtype] 
		 ([TypeName],
		 [Discount],
		 [Comment],
		 [AutoDiscount]) 
	 
	VALUES 
		(@TypeName,
		 @Discount,
		 @Comment,
		 @AutoDiscount)

/*-----------------------------------------*/

if @Ctypeid>0
begin
	UPDATE [cardtype] 
	
	SET	 [TypeName]	 = @TypeName,
		 [Discount]	 = @Discount,
		 [Comment]	 = @Comment,
		 [AutoDiscount]  = @AutoDiscount 
	
	WHERE 
		( [CTypeId]	 = @CTypeId)
/*如果修改该表中的"折扣",就自动修改会员卡的"折扣"数字。*/
        UPDATE  Membercard set  [Discount]	 = @Discount  
        WHERE   ( [DiscountType]	 = @CTypeId)
end

/*-----------------------------------------*/
if @Ctypeid<0
	delete from [cardtype] 	
	WHERE 
		( [CTypeId]	 = abs(@CTypeId))
GO
