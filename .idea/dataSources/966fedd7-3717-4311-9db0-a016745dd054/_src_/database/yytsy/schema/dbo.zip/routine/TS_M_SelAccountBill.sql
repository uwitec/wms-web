


CREATE  PROCEDURE TS_M_SelAccountBill
(
	@BillNumber 	varchar(100)='',
	@BillType 	varchar(1000),            	/*被调用的单据类型*/
        @BeginDate      datetime,
        @EndDate      	datetime,         
        @IfDraft        int=0,            		/*0:从草稿中选择单据 2: 零售单*/
        @BillStates     int=0,             		/*单据状态*/
        @WHERE		varchar(3000),
        @nloginEID     int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BillNumber is null  SET @BillNumber = ''
if @IfDraft is null  SET @IfDraft = 0
if @BillStates is null  SET @BillStates = 0
/*Params Ini end*/

DECLARE @SQLScript VARCHAR(8000)
DECLARE @TableName VARCHAR(100)
declare @ManageBillStr varchar(100)
Declare @Storetable  INTEGER
create table #storagestable([id] int)

/*采购销售单(财务收款,业务开单),从草稿中选择单据,BillStates=8*/
/*采购销售单退货 :从billidx表中选择单据,billstates=0*/
/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      set @Storetable=1
   end
IF (@IfDraft=1)
BEGIN
	SET @TableName  = 'BILLDRAFTIDX'
	set @ManageBillStr = 'drf'
END
ELSE 
IF @IfDraft = 2
BEGIN
	SET @TableName  = 'RETAILBILLIDX'
	set @ManageBillStr = ''
END
ELSE
BEGIN
	SET @TableName  = 'BILLIDX'
	set @ManageBillStr = ''
END


/*-XXX.2016-12-29 bug_44520 调处方笺的时候也需要单据模糊查询*/
/*if @BillType = '244'
	SET @BillNumber = char(39)+'%%'+char(39)
else*/
	SET @BillNumber = char(39)+'%'+@BillNumber+'%'+char(39)

IF (@WHERE<>'')  SET @WHERE=' and '+ @WHERE

IF @BillType = '244'
	SET @SQLScript = '		SELECT isnull(SaleQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin,G.CardNo 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as SaleQty from RetailBill group by Bill_ID) SQ ON SQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		LEFT JOIN VW_H_ExamPatients G ON B.region_id=G.PatientID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		/*+'	OR G.CardNo Like '	+ @BillNumber*/
		+' 	)	'
		+ @WHERE
		+' order by billdate'
ELSE
IF @BillType = '20,222' /*采购入库退货单按原单退货*/
	SELECT  @SQLScript='
		SELECT isnull(BuyQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as BuyQty from BuymanageBill'+@ManageBillStr+' WHERE thqty > 0 group by Bill_ID) BQ ON BQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' order by billdate'
ELSE
if @BillType ='20,220' 
        SELECT  @SQLScript='
		SELECT isnull(SaleQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin,ISNULL(A.Name,'''') as auditmanname,
		ISNULL(i.Name,'''') as inputmanname
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as SaleQty from salemanageBill'+@ManageBillStr+' 
		             where (('+cast(@Storetable as varchar(8000))+'=0) or (ss_id in (select [id] from #storagestable))) 
		   group by Bill_ID) SQ ON SQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		left join Employees     A on b.auditman=A.Emp_ID
		left join Employees     i on b.inputman =i.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' UNION ALL 
		SELECT isnull(BuyQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin,ISNULL(A.Name,'''') as auditmanname,
		ISNULL(i.Name,'''') as inputmanname 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as BuyQty from BuymanageBill'+@ManageBillStr+' 
		 where (('+cast(@Storetable as varchar(8000))+'=0)or (ss_id  in (select [id] from #storagestable))) 
		group by Bill_ID) BQ ON BQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		left join Employees     A on b.auditman=A.Emp_ID
		left join Employees     i on b.inputman =i.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' order by billdate'
ELSE
if @BillType ='10,210' 
        SELECT  @SQLScript='
		SELECT isnull(SaleQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin,ISNULL(A.Name,'''') as auditmanname,
		ISNULL(i.Name,'''') as inputmanname 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as SaleQty from salemanageBill'+@ManageBillStr+' 
		             where (('+cast(@Storetable as varchar(8000))+'=0) or (ss_id in (select [id] from #storagestable))) 
		   group by Bill_ID) SQ ON SQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		left join Employees     A on b.auditman=A.Emp_ID
		left join Employees     i on b.inputman =i.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' UNION ALL 
		SELECT isnull(BuyQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin,ISNULL(A.Name,'''') as auditmanname,
		ISNULL(i.Name,'''') as inputmanname 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as BuyQty from BuymanageBill'+@ManageBillStr+' 
		 where (('+cast(@Storetable as varchar(8000))+'=0)or (ss_id  in (select [id] from #storagestable))) 
		group by Bill_ID) BQ ON BQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		left join Employees     A on b.auditman=A.Emp_ID
		left join Employees     i on b.inputman =i.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' order by billdate'
ELSE
	    SELECT  @SQLScript='
		SELECT isnull(SaleQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as SaleQty from salemanageBill'+@ManageBillStr+' 
		   group by Bill_ID) SQ ON SQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' UNION ALL 
		SELECT isnull(BuyQty,0) as Qty,B.*,ISNULL(C.Name,'''') as CName,ISNULL(c.PinYin,'''') as CPinYin,
		ISNULL(E.Name,'''') as employeename,ISNULL(E.PinYin,'''') as EPinYin 
		FROM  '+ @TableName +'  B 
		inner JOIN (select Bill_ID,sum(quantity)as BuyQty from BuymanageBill'+@ManageBillStr+' 
		group by Bill_ID) BQ ON BQ.Bill_ID=B.BillID
			LEFT JOIN Clients 	C ON B.C_ID=C.Client_ID
		LEFT JOIN Employees 	E ON B.E_ID=E.Emp_ID
		WHERE   B.BillType in (' + @BillType +')'
			+' and  B.BillStates='  + cast(@BillStates as varchar(50))
		+' and B.BillDate BETWEEN  ' + char(39) + cast(@BeginDate as varchar(50)) + char(39) 
		+' 		     and   ' + char(39) + cast(@EndDate as varchar(50)) + char(39) 
		+' and ( '
		+'	   B.BillNumber Like '	+ @BillNumber
		+'	OR C.Name Like '	+ @BillNumber
		+'	OR C.PinYin Like '	+ @BillNumber
		+'	OR E.Name Like '	+ @BillNumber
		+'	OR E.PinYin Like '	+ @BillNumber
		+' 	)	'
		+ @WHERE
		+' order by billdate'
/*Print(@SQLScript)*/
EXEC(@SQLScript)
GO
