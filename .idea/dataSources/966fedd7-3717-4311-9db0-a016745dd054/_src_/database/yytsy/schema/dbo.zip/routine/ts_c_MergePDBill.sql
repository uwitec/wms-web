
create proc ts_c_MergePDBill
(
	@nInputMan 	int,
	@nS_id 		int,
	@nDelDraft	int=1
)
/*with encryption*/
as
/*Params Ini begin*/
if @nDelDraft is null  SET @nDelDraft = 1
/*Params Ini end*/
set nocount on 
declare @nNewBillId int,@szMergeMan varchar(20),@szSName varchar(20),@tBilldate varchar(10),@szNote varchar(300)
declare @dYkTotal NUMERIC(25,8)
declare @cUseSameCostMethod char(1),@nCostMethod char(1),@pdconvert int
declare @Y_ID		int
declare @nStoreFlag int /* 仓库类型 1 自营店*/
/**/
	declare @dDoubleZero NUMERIC(25,8)
	set @dDoubleZero=0.001
/*2005-06-28 zc modify 解决小数位数带来的误差。*/

select top 1 @Y_ID=b.Y_ID from pdidx p,billdraftidx b where p.billid=b.billid and b.billstates='3' and b.billtype=50

select @szMergeMan=name from employees where emp_id=@nInputMan
select @szSName=name, @nStoreFlag = flag from storages where storage_id = @nS_id
select @tBillDate=convert(varchar(10),GetDate(),20)
select @szNote='【合并盘点单】  '+'日期： '+@tBillDate+'   合并人：'+@szMergeMan

if not exists(select 1 from pdidx) return -2


	exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
	if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
		exec ts_getsysvalue 'CostMethod',@nCostMethod out


	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[goodtemp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	drop table [dbo].[goodtemp]

begin tran mergepdbill

/*合并选中的盘点单草稿*/

	if @cUseSameCostMethod='1' 
	begin
		if @nCostMethod in ('0','1','2') 
		begin
			select p_id,ss_id,aoid,y_id,max(batchno) as batchno,costprice=case sum(quantity) when 0 then 0 else sum(total)/sum(quantity) end ,max(location_id) as location_id,max(supplier_id) as supplier_id,
			max(commissionflag) as commissionflag,max(discountprice) discountprice,max(discount) as discount,max(taxprice) as taxprice,
			max(makedate) as makedate,max(validdate) as validdate,max(sd_id) as sd_id,0 as unitid,buyprice=case sum(quantity) when 0 then 0 else sum(total)/sum(quantity) end,max(retailprice) as retailprice,
			0 as taxrate,0 as order_id,0 as totalmoney,sum(quantity) as quantity,sum(total) as total, max(instoretime) as instoretime,
			costtaxprice=case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end,
			MAX(costtaxrate) as costtaxrate, SUM(costtaxtotal) as costtaxtotal, MAX(factoryid) as factoryid
			into goodtemp
			from goodscheckbilldrf where bill_id in (select distinct p.billid from pdidx p,billdraftidx b where p.billid=b.billid and b.billstates='3' and b.billtype=50) 
			group by p_id,ss_id,aoid,y_id
			if @@error<>0 goto error
		end else 
		if @nCostMethod in ('3','4')
		begin
			/*先注释掉，此处会导致门店合并盘点单只管批号*/
			/*if @nStoreFlag = 1*/
			/*begin*/
			/*	SELECT   p_id, ss_id, AOID, Y_ID, batchno, AVG(costprice) AS costprice, 0 AS location_id, 0 AS supplier_id, 0 AS commissionflag, */
			/*					SUM(discountprice) AS discountprice, MAX(discount) AS discount, SUM(taxprice) AS taxprice, MAX(makedate) */
			/*					AS makedate, MAX(validdate) AS validdate, MAX(sd_id) AS sd_id, 0 AS unitid, MAX(buyprice) AS buyprice, */
			/*					MAX(retailprice) AS retailprice, 0 AS taxrate, 0 AS order_id, 0 AS totalmoney, SUM(quantity) AS quantity, SUM(total) */
			/*					AS total, MAX(instoretime) AS instoretime*/
			/*	into goodtemp*/
			/*	FROM      dbo.GoodsCheckBillDrf*/
			/*	WHERE   (bill_id IN*/
			/*						(SELECT DISTINCT p.billid*/
			/*						 FROM      dbo.pdidx AS p INNER JOIN*/
			/*										 dbo.billdraftidx AS b ON p.billid = b.billid*/
			/*						 WHERE   (b.billstates = '3') AND (b.billtype = 50)))*/
			/*	GROUP BY p_id, ss_id, AOID, Y_ID, batchno*/
			/*	if @@error <> 0 goto error*/
			/*end*/
			/*else*/
			begin
				select p_id,ss_id,aoid,y_id,batchno,costprice,location_id,supplier_id,commissionflag,max(discountprice) discountprice,max(discount) as discount,max(taxprice) as taxprice,
				makedate as makedate,validdate as validdate,max(sd_id) as sd_id,0 as unitid,max(buyprice) as buyprice,max(retailprice) as retailprice,
				0 as taxrate,0 as order_id,0 as totalmoney,sum(quantity) as quantity,sum(total) as total, instoretime, costtaxprice, costtaxrate, 
				sum(costtaxtotal) as costtaxtotal, factoryid
				into goodtemp
				from goodscheckbilldrf where bill_id in (select distinct p.billid from pdidx p,billdraftidx b where p.billid=b.billid and b.billstates='3' and b.billtype=50) 
				group by p_id,ss_id,aoid,y_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate, instoretime, costtaxprice,
				costtaxrate, factoryid
				if @@error<>0 goto error
			end
		end
	end else
	begin
		select * into goodtemp 
		from (
			select g.p_id,g.ss_id,g.aoid,g.y_id,g.batchno,g.costprice,g.location_id,g.supplier_id,g.commissionflag,max(g.discountprice) discountprice,max(g.discount) as discount,max(g.taxprice) as taxprice,
			g.makedate as makedate,g.validdate as validdate,max(g.sd_id) as sd_id,0 as unitid,max(g.buyprice) as buyprice,max(g.retailprice) as retailprice,
			0 as taxrate,0 as order_id,0 as totalmoney,sum(g.quantity) as quantity,sum(g.total) as total, g.instoretime as instoretime, costtaxprice, costtaxrate, 
				sum(costtaxtotal) as costtaxtotal, factoryid
			from goodscheckbilldrf g,products p where g.bill_id in (select distinct p.billid from pdidx p,billdraftidx b where p.billid=b.billid and b.billstates='3' and b.billtype=50) 
			and g.p_id=p.product_id and p.costmethod in ('3','4') and p.deleted<>1
			group by g.p_id,g.ss_id,g.aoid,g.y_id,g.batchno,g.costprice,g.location_id,g.supplier_id,g.commissionflag,g.makedate,g.validdate, g.instoretime, costtaxprice,
				costtaxrate, factoryid
			union 
			select g.p_id,g.ss_id,g.aoid,g.y_id, max(g.batchno) batchno,max(g.costprice) costprice,max(g.location_id) location_id,
			max(g.supplier_id) supplier_id,max(g.commissionflag) commissionflag,max(g.discountprice) discountprice,
			max(g.discount) as discount,max(g.taxprice) as taxprice,
			max(g.makedate) as makedate,max(g.validdate) as validdate,max(g.sd_id) as sd_id,0 as unitid,max(g.buyprice) as buyprice,max(g.retailprice) as retailprice,
			0 as taxrate,0 as order_id,0 as totalmoney,sum(g.quantity) as quantity,sum(g.total) as total, MAX(g.instoretime) as instoretime,
			costtaxprice=case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end,
			MAX(costtaxrate) as costtaxrate, SUM(costtaxtotal) as costtaxtotal, MAX(factoryid) as factoryid
			from goodscheckbilldrf g,products p where g.bill_id in (select distinct p.billid from pdidx p,billdraftidx b where p.billid=b.billid and b.billstates='3' and b.billtype=50) 
			and g.p_id=p.product_id and p.costmethod in ('0','1','2') and p.deleted<>1
			group by g.p_id,g.ss_id,g.aoid,g.y_id
		     ) b

		if @@error<>0 goto error
	end

/*生成表头文件*/

	insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,Y_ID,ZBAuditMan,ZBAuditDate)
	values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'2',@Y_ID,0,'1900-01-01')
	if @@error<>0 goto error

	select @nNewBillId=@@identity
	
	insert goodscheckbilldrf (bill_id,p_id,y_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
	discount,taxprice,makedate,validdate,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,aoid, instoretime,
	costtaxprice, costtaxrate, costtaxtotal, factoryid)
	select @nNewBillId,p_id,y_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
	discount,taxprice,makedate,validdate,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,aoid, instoretime,
	costtaxprice, costtaxrate, costtaxtotal, factoryid
	from goodtemp
	if @@error<>0 goto error

  /*调整大单位报溢的成本价格*/
  update goodscheckbilldrf set costprice=cast(total/quantity as NUMERIC(25,8)) where taxprice=0 and quantity>0 and bill_id=@nNewBillId

  /*调整计量单位为基本单位*/
	update goodscheckbilldrf set unitid=b.u_id,buyprice=total/quantity,retailprice=b.retailprice from goodscheckbilldrf gc,price b
	where gc.p_id=b.p_id and b.unittype=1 and gc.bill_id=@nNewBillId and gc.quantity<>0 
	if @@error<>0 goto error

	update goodscheckbilldrf set totalmoney=quantity-taxprice,taxtotal=(quantity-taxprice)*costprice,taxmoney=quantity-taxprice,
	total=quantity*costprice,retailtotal=retailprice*(quantity-taxprice)
	where bill_id=@nNewBillId
	if @@error<>0 goto error

	
	set @dYkTotal=0
	select @dYkTotal=isnull(abs(sum(taxtotal)),0) from goodscheckbilldrf	
	where bill_id=@nNewBillId and taxtotal>0
	
	update billdraftidx set ysmoney=@dYkTotal,ssmoney=@dYkTotal,billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
	where billid=@nNewBillId 
	if @@error<>0 goto error


	update billdraftidx set note='已经合并到盘点单  '+'【PD'+right(cast(100000000+@nNewBillId as varchar),8)+'】  ' where billid in (select billid from pdidx)
	if @@error<>0 goto error
  
  set @pdconvert=@nNewBillId

	if @nDelDraft=1 
	begin
		delete from goodscheckbilldrf where bill_id in (select billid from pdidx)
		delete from billdraftidx where billid in (select billid from pdidx)
	end
	truncate table pdidx


/*生成未盘点商品表*/

	select @szNote='【未盘点商品】  '+'日期： '+@tBillDate+'   合并人：'+@szMergeMan

	select * into #storehouse from storehouse where s_id=@ns_id

/*删除已经盘点商品*/
	if @cUseSameCostMethod='1' 
	begin
		if @nCostMethod in ('0','1','2') 
		begin
			delete from #storehouse from #storehouse s,goodtemp g 
			where s.p_id=g.p_id and g.aoid in (0,7)
		end else
		begin
			/*if @nStoreFlag = 1*/
			/*begin*/
			/*	delete from #storehouse from*/
			/*	goodtemp g where #storehouse.p_id = g.p_id and #storehouse.batchno = g.batchno*/
			/*end*/
			/*else*/
			begin
				delete from #storehouse from #storehouse s,goodtemp g 
				where s.p_id=g.p_id and abs(s.costprice-g.costprice)<=@dDoubleZero and s.batchno=g.batchno and s.location_id=g.location_id and s.supplier_id=g.supplier_id and s.makedate=g.makedate and s.validdate=g.validdate and g.aoid in (0,7) and s.instoretime = g.instoretime
			end
		end
	end else
	begin
		delete from #storehouse from #storehouse s,goodtemp g ,products p
		where s.p_id=g.p_id and s.p_id=p.product_id and (s.costprice-g.costprice)<=@dDoubleZero and s.batchno=g.batchno and s.location_id=g.location_id 
			and s.supplier_id=g.supplier_id and s.makedate=g.makedate and s.validdate=g.validdate and s.instoretime = g.instoretime 
			and s.factoryid = g.factoryid
		and p.costmethod in ('3','4') and g.aoid in (0,7)
		delete from #storehouse from #storehouse s,goodtemp g ,products p
		where s.p_id=g.p_id and s.p_id=p.product_id and p.costmethod in ('0','1','2') and g.aoid in (0,7)
	end


	if exists(select 1 from #storehouse)
	begin
		select 0 as smb_id,0 as bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.costprice as buyprice,0 as discount,b.quantity as discountprice,0 as totalmoney, b.costtotal as total,
		  b.quantity as taxprice,0 as taxtotal,0 as taxmoney,0 as retailprice,0 as retailtotal,b.makedate,b.validdate, b.y_id, b.instoretime, ' ' as qualitystatus, b.storehouse_id as order_id,
		  0 as price_id, b.s_id, b.s_id as s_id2, b.location_id as l_id , b.supplier_id as b_id, b.commissionflag, ' ' as comment, 0 as unitid,0 as taxrate,b.location_id as l_id2, 0 as iotag,
		  p.code,p.name,p.standard,p.modal,p.makearea, p.permitcode, p.trademark,p.medtype,
		  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validday, p.costmethod,
		  p.unit1_id, p.unit2_id, p.unit3_id, p.unit4_id, p.otcflag,p.alias,
		  0 as invoicetotal,
		  0 as comedate,
		  0 as comeqty,
		  ' ' as sn,
		  ' ' as vendor,
		  costtaxprice, taxrate as costtaxrate, costtaxtotal, factoryid
		into #storehoustemp from #storehouse b,vw_b_products p ,vw_b_storage  s 
		where b.stopsaleflag = 0 and b.p_id=p.p_id and b.s_id=s.s_id 

	/*生成表头文件*/
	
		insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,Y_ID,ZBAuditMan,ZBAuditDate)
		values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'2',@Y_ID,0,'1900-01-01')
		if @@error<>0 goto error
	
		select @nNewBillId=@@identity
		
		insert goodscheckbilldrf (bill_id,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
		discount,taxprice,makedate,validdate,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,Y_ID, instoretime,
		costtaxprice, costtaxrate, costtaxtotal, factoryid)
		select @nNewBillId,p_id,batchno,costprice,l_id,b_id,commissionflag,discountprice,
		discount,taxprice,makedate,validdate,s_id,s_id2,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,Y_ID, instoretime,
		costtaxprice, costtaxrate, costtaxtotal, factoryid
		from #storehoustemp
		if @@rowcount=0 goto error
	/*	
		update goodscheckbilldrf set totalmoney=quantity-taxprice,taxtotal=(quantity-taxprice)*costprice,taxmoney=quantity-taxprice,
		total=quantity*costprice,retailtotal=retailprice*(quantity-taxprice)
		where bill_id=@nNewBillId
		if @@error<>0 goto error
		
		set @dYkTotal=0
		select @dYkTotal=isnull(abs(sum(taxtotal)),0) from goodscheckbilldrf	
		where bill_id=@nNewBillId and taxtotal<0
	*/	
		update billdraftidx set billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
		where billid=@nNewBillId 
		if @@error<>0 goto error
	
		update goodscheckbilldrf set unitid=b.u_id,buyprice=total/quantity from goodscheckbilldrf gc,price b
  	where gc.p_id=b.p_id and b.unittype=1 and gc.bill_id=@nNewBillId and gc.quantity<>0
		if @@error<>0 goto error
	end


	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[goodtemp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	drop table [dbo].[goodtemp]

commit tran mergepdbill
return @pdconvert

error:
rollback tran mergepdbill
return -1
GO
