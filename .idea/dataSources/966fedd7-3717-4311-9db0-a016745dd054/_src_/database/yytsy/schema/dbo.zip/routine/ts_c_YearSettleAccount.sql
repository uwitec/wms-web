

create   procedure ts_c_YearSettleAccount
(
@nPubY_ID int,
@DelGSP int
)
/*with eccrypt*/
as

/*年结存*/

declare @Y_ID int, @szYClassID varchar(30), @nRet int
exec ts_GetSysValue 'Y_id',@Y_ID OUT
select @szYClassID = sysvalue from sysconfig where upper([sysname]) = 'YCLASSID'

exec ts_j_MakeBalance @nPubY_ID


if OBJECT_ID('temp..#yidtmp') is not null
  drop table #yidtmp
select  cast(0 as int) as Y_ID into #yidtmp

/*所有自营店和总部一起结存*/
if @nPubY_ID = @Y_ID
begin
  insert into #yidtmp(Y_ID) select company_id from company where company_id = @nPubY_ID or (superior_id = @nPubY_ID and Ytype = 1 and company_id in (select y_id from Companybalance where c_id = 0 and OpenAccount = 1) )
end
else
  insert into #yidtmp(Y_ID) select @nPubY_ID

begin tran 
	if exists (select top 1 * from accountbalance)
	begin
	    update accountbalance set ini_total=cur_total  where  y_id in (select y_id from #yidtmp)
		/*if @@rowcount=0 goto error*/
	end
	if exists (select top 1 * from clientsbalance)
	begin
	 	update clientsbalance set artotal_ini=artotal,aptotal_ini=aptotal,pre_artotal_ini=pre_artotal,pre_aptotal_ini=pre_aptotal where  y_id in (select y_id from #yidtmp)
		if @@rowcount=0 goto error
        end
	if exists (select top 1 * from clientsbalance)
	begin
	  	update companybalance set artotal_ini=artotal,aptotal_ini=aptotal,pre_artotal_ini=pre_artotal,pre_aptotal_ini=pre_aptotal where  y_id in (select y_id from #yidtmp)
		if @@rowcount=0 goto error
	end
	
	/*2010.10.12 增加删除草稿中非法数据begin*/
	delete buymanagebilldrf where bill_id > (select MAX(billid) from billdraftidx)
    delete salemanagebilldrf where bill_id > (select MAX(billid) from billdraftidx)
    delete storemanagebilldrf where bill_id > (select MAX(billid) from billdraftidx)
    delete GoodsCheckBillDrf where bill_id > (select MAX(billid) from billdraftidx)	
    /*2010.10.12 增加删除草稿中非法数据end*/
    	
 	delete storehouseini where y_id in (select y_id from #yidtmp)
    /*delete storezeroini where Y_ID = @nPubY_ID --药易通未使用storezero*/
 	delete storedxini where y_id in (select y_id from #yidtmp)
 	delete storebrrowini where y_id in (select y_id from #yidtmp)
 	delete OtherStorehouseini where y_id in (select y_id from #yidtmp)
    
	insert into storehouseini(location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,Y_ID,batchbarcode ,scomment ,batchprice,costtaxprice,costtaxtotal,taxrate,factoryid) 
	select location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,Y_ID,batchbarcode ,scomment ,batchprice,costtaxprice,costtaxtotal,taxrate,factoryid from storehouse where y_id in (select y_id from #yidtmp)
	
	insert into storedxini(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,Y_ID,batchbarcode ,scomment ,batchprice,costtaxprice,costtaxtotal,taxrate,factoryid) 
	select location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,Y_ID,batchbarcode ,scomment ,batchprice,costtaxprice,costtaxtotal,taxrate,factoryid from storedx where y_id in (select y_id from #yidtmp)
	
	insert into storebrrowini(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,Y_ID,costtaxprice,costtaxtotal,taxrate,factoryid) 
	select location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,Y_ID,costtaxprice,costtaxtotal,taxrate,factoryid from storebrrow where y_id in (select y_id from #yidtmp)


        insert into OtherStoreHouseini(p_id,quantity,Y_ID) 
        select p_id,quantity,Y_ID from OtherStoreHouse where y_id in (select y_id from #yidtmp)



 if @nPubY_ID = @Y_ID
 begin 
 	delete from users 			where e_id in (select emp_id from employees where deleted=1 and child_number=0)
    delete from accountbalance  where y_id in (select y_id from #yidtmp) and a_id in (select account_id from account where deleted=1)
 	delete from account  		where deleted=1
 	delete from products        where deleted=1        
    delete from Clientsbalance  where y_id in (select y_id from #yidtmp) and c_id in (select client_id from clients where deleted=1)
 	delete from clients    	    where deleted=1
 	delete from employees 		where deleted=1
 	delete from storages		where deleted=1
	delete from department		where deleted=1
	delete from region			where deleted=1
	/*delete from medtype			where deleted=1*/
	delete from unit			where deleted=1
    delete from Companybalance	where y_id in (select y_id from #yidtmp) and c_id in (select company_id from company where deleted=1)

	truncate table billdraftidx
	truncate table buymanagebilldrf
	truncate table salemanagebilldrf
	truncate table storemanagebilldrf
	truncate table financebilldrf
	truncate table tranmanagebilldrf
	truncate table jspdetail
	truncate table jsbdetail
	truncate table GoodsCheckBilldrf	
	truncate table billidx
	truncate table salemanagebill
	truncate table buymanagebill
	truncate table storemanagebill
	truncate table tranmanagebill
	truncate table financebill
	truncate table GoodsCheckBill
	truncate table productdetail
    truncate table YProductDetail
	truncate table accountdetail
   	truncate table Yaccountdetail
	truncate table orderidx
	truncate table orderbill
	truncate table retailbillidx
 	truncate table retailbill
 	truncate table OrderDraft
 	truncate table GSPDraft
 
	truncate table yretailbillidx
	truncate table yretailbill
	truncate table ybilldraftidx
	truncate table ysalemanagebilldrf
	truncate table dayaccount
    truncate table dayaccountdetail


 	truncate table storehouse
 	truncate table Otherstorehouse
    truncate table storezero
 	truncate table storedx
 	truncate table storebrrow
	truncate table jspdetail
	truncate table jsbdetail
	truncate table jbdetail
	truncate table jkdetail
	truncate table tranidx
	truncate table tranbill
	truncate table tasklist
 	truncate table tasklistup
	truncate table AutoGoodsCheck
    truncate table pdplanidx
    truncate table pdplan
    truncate table checkidx
    truncate table redhistory
    truncate table retailmerge
    truncate table dayaccount
    truncate table dayaccountdetail
  
	truncate table PrintDetail
	truncate table ExIntegRalManagebill/*清除积分兑换单*/
	truncate table ExIntegRalManagebilldrf
	truncate table invoiceidx
	truncate table invoice 
	truncate table VIPLog
	truncate table UpBillList
	
	truncate table PaymentBill
	truncate table PaymentIdx	
	truncate table VipDetail
	truncate table systemlog
	truncate table MsgHistory
	TRUNCATE TABLE Integralidx
	TRUNCATE TABLE Integraldetail
		
	delete from YSendCostPriceHis where smb_id not in
	(select distinct yc.smb_id from  
	   YSendCostPriceHis  yc 
	   inner join storehouse s  on yc.p_id =s.p_id and yc.supplier_id = s.supplier_id and
	   yc.costprice = s.costprice and yc.batchno = s.batchno and yc.makedate = s.makedate and
	   yc.instoretime = s.instoretime and yc.validdate = s.validdate and yc.commissionflag = s.commissionflag
	)
		
end 
else
begin
	delete billdraftidx where Y_ID = @nPubY_ID
	delete buymanagebilldrf where Y_ID = @nPubY_ID
	delete salemanagebilldrf where Y_ID = @nPubY_ID
	delete storemanagebilldrf where Y_ID = @nPubY_ID
	delete financebilldrf where Y_ID = @nPubY_ID
	delete tranmanagebilldrf where Y_ID = @nPubY_ID
	delete jspdetail where Y_ID = @nPubY_ID
	delete jsbdetail where Y_ID = @nPubY_ID
	delete GoodsCheckBilldrf where Y_ID = @nPubY_ID

	delete billidx where Y_ID = @nPubY_ID
	delete salemanagebill where Y_ID = @nPubY_ID
	delete buymanagebill where Y_ID = @nPubY_ID
	delete storemanagebill where Y_ID = @nPubY_ID
	delete tranmanagebill where Y_ID = @nPubY_ID
	delete financebill where Y_ID = @nPubY_ID
	delete GoodsCheckBill where Y_ID = @nPubY_ID
	delete productdetail where Y_ID = @nPubY_ID
    delete YProductDetail where Y_ID = @nPubY_ID
	delete accountdetail where Y_ID = @nPubY_ID
    delete Yaccountdetail where Y_ID = @nPubY_ID
	delete orderidx where Y_ID = @nPubY_ID
	delete orderbill where Y_ID = @nPubY_ID
	delete retailbillidx where Y_ID = @nPubY_ID
 	delete retailbill where Y_ID = @nPubY_ID

    delete yretailbillidx where Y_ID = @nPubY_ID
	delete yretailbill where Y_ID = @nPubY_ID
	delete ybilldraftidx where Y_ID = @nPubY_ID
	delete ysalemanagebilldrf where Y_ID = @nPubY_ID

 	delete storehouse where Y_ID = @nPubY_ID
    delete storezero where Y_ID = @nPubY_ID
    delete Otherstorehouse where y_id = @nPubY_ID
 	delete storedx where Y_ID = @nPubY_ID
 	delete storebrrow where Y_ID = @nPubY_ID
	delete jspdetail where Y_ID = @nPubY_ID
	delete jsbdetail where Y_ID = @nPubY_ID
	delete jbdetail where Y_ID = @nPubY_ID
	delete jkdetail where Y_ID = @nPubY_ID
	delete tranidx where Y_ID = @nPubY_ID
	delete tranbill where Y_ID = @nPubY_ID
	delete tasklist where Y_ID = @nPubY_ID
 	delete tasklistup where Y_ID = @nPubY_ID
	delete AutoGoodsCheck where Y_ID = @nPubY_ID
    delete pdplanidx where Y_ID = @nPubY_ID
	delete pdplan where Y_ID = @nPubY_ID
	/*delete checkidx where Y_ID = @nPubY_ID */
	delete redhistory where Y_ID = @nPubY_ID  
	/*delete retailmerge  */
	delete ExIntegRalManagebill where Y_ID = @nPubY_ID/*清除积分兑换单*/
	delete ExIntegRalManagebilldrf where Y_ID = @nPubY_ID
	delete invoiceidx where Y_ID = @nPubY_ID 
	delete invoice where Y_id = @nPubY_ID 
	delete  PaymentBill where Y_id = @nPubY_ID 
    delete  PaymentIdx  where Y_id = @nPubY_ID
    delete  Integralidx where Y_ID = @nPubY_ID
	delete  Integraldetail where Y_ID = @nPubY_ID
end
    truncate table buymanagebilltmp
	truncate table salemanagebilltmp
	truncate table storemanagebilltmp
 	truncate table tranmanagebilltmp

    truncate table sendidx
    truncate table sendmangebill
    truncate table msgcenter
	truncate table productdetailtmp
	truncate table accountdetailtmp
	truncate table BillLog
	truncate table Sfda_Detail
	truncate table RetailBillidx_Sfda
	truncate table Sfda_List
	truncate table GspMaintainPlan
	truncate table GSPbillidx
	truncate table GSPbilldetail
	truncate table billtrace
	truncate table PerDayData /*删除每日销量*/
	truncate table PerStockData /*删除每日库存*/
	truncate table HistoryStorehouse  /*删除历史库存*/
	
				
/*	删除业务表 */
	TRUNCATE TABLE billidx_dts
	TRUNCATE TABLE salemanagebill_dts
	TRUNCATE TABLE buymanagebill_Dts
	TRUNCATE TABLE financebill_Dts 
	TRUNCATE TABLE storemanagebill_Dts
	TRUNCATE TABLE goodscheckbill_Dts
	TRUNCATE TABLE tranmanagebill_Dts 
	truncate table productdetail_dts
	truncate table accountdetail_dts
	truncate table retailbillidx_dts
	truncate table retailbill_dts	
	truncate table ExIntegRalManagebill_dts
	/*删除草稿中间表*/
	TRUNCATE TABLE billDraftidx_dts
	TRUNCATE TABLE salemanagebilldrf_dts
	TRUNCATE TABLE financebilldrf_dts
	TRUNCATE TABLE GSPCompy_dts	
	/*删除会员积分表*/
	TRUNCATE TABLE Integralidx_dts
	TRUNCATE TABLE Integraldetail_dts

	
	IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
		truncate table billhistory
	
  if @nPubY_ID = @Y_ID
    if @DelGSP=1 delete from GspTable where  Gsptype not in (2202,2203,2260) and y_id in (select y_id from #yidtmp) /*zhh 清除GSP--LK 090104再加该三种统计*/
	update account set cur_total=0,total_01=0,total_02=0,total_03=0,total_04=0,total_05=0,total_06=0,total_07=0,total_08=0,total_09=0,total_10=0,total_11=0,total_12=0
	if @@rowcount=0 goto error
	if exists (select top 1 * from accountbalance)
	begin	
		update accountbalance set cur_total=0,total_01=0,total_02=0,total_03=0,total_04=0,total_05=0,total_06=0,total_07=0,total_08=0,total_09=0,total_10=0,total_11=0,total_12=0 where  y_id in (select y_id from #yidtmp)
		  
		/*if @@rowcount=0 goto error*/
		update accountbalance Set ini_total=0 where y_id in (select y_id from #yidtmp) and a_id in (select account_id from account where class_id='000005000006')/*当年利润置零*/
		
		
		/*if @@rowcount=0 goto error*/
		update accountbalance Set ini_total=0 where  y_id in (select y_id from #yidtmp) and a_id in (select account_id from account where left(class_id,6)='000003' or left(class_id,6)='000004')/*收入类，支出类置零*/
		
		
		/*if @@rowcount=0 goto error*/
	end
 	update clients set artotal=0,aptotal=0
	if @@rowcount=0 goto error
	if exists (select top 1 * from clientsbalance where y_id in (select y_id from #yidtmp))
	begin
	 	update clientsbalance set artotal=0,aptotal=0,pre_artotal=0, pre_aptotal =0  where y_id in (select y_id from #yidtmp)

		if @@rowcount=0 goto error
	end
	if exists (select top 1 * from companybalance where y_id in (select y_id from #yidtmp))
	begin
	        update companybalance set artotal=0,aptotal=0,pre_artotal=0, pre_aptotal =0 where y_id in (select y_id from #yidtmp)
            update companybalance set openaccount=0 where y_id in (select y_id from #yidtmp) and c_id=0
		if @@rowcount=0 goto error
	end
	
	
 	delete from monthsettleinfo where monthname<>'本期' and y_id in (select y_id from #yidtmp)
 	update monthsettleinfo set begindate=convert(varchar(10),getdate(),20),period=1 where monthname='本期' and y_id in (select y_id from #yidtmp)
	/*if @@rowcount=0 goto error*/
    /*-zjx--2016-12-27---tfs44408---年结存保存GSP记录，开账后重新生成当遇到BILLID相同的时候会把年结存保存的GSP记录删掉*/
	UPDATE GspTable SET billId=0 WHERE billdate<(SELECT TOP 1 begindate FROM monthsettleInfo WHERE monthName='本期' AND period=1 AND Y_ID=@nPubY_ID) AND billid<>0	
	if @nPubY_ID = @Y_ID
	begin
	  Update VipCard Set IniIntergral=Integral/*更新会员卡初始积分	 */
	 /* if @@rowcount=0 goto error*/
	  update billsnstyle set sncount=0  
	  update sysconfig set sysvalue=0 where [sysname]='billsncount' 
	  update gspsnstyle set sncount=0
	  update sysconfig set sysvalue=0 where [sysname]='gspsncount' 
	end 
	
	update sysconfig set sysvalue='1' where [sysname]='AccountPeriod' and y_id in (select y_id from #yidtmp)
	  /*if @@rowcount=0 goto error*/
 	update sysconfig set sysvalue='0' where [sysname]='OpenAccount' and y_id in (select y_id from #yidtmp)
 	   	
       if @szYClassID <> '000001'
       if exists(select 1 from company where company_id = @Y_ID and Ytype <> 1)
         insert into tasklistup(taskdate,Y_ID, BillGuid, OperType,tranType,TGuid)
            select getdate(), 0, sysValue, -99,0,newid() from sysconfig where upper([sysname]) = 'GUID'
      
      if exists(select * from tasklistUp where Y_ID = @nPubY_ID and OperType = -100 and TranType = 0)
         delete tasklistup where Y_ID = @nPubY_ID and OperType = -100 and TranType = 0 
  
  if @nPubY_ID = @Y_ID
  begin         
    declare UpdateUseFlag cursor for
	  select posid from  ReplicationAuthorize
	  open UpdateUseFlag
	  fetch next from UpdateUseFlag into @Y_ID
	  while @@FETCH_STATUS=0	
	  begin 
	    exec @nRet = ts_j_GetUseTag @Y_Id
	    update ReplicationAuthorize set UseTag = @nRet
	    fetch next from UpdateUseFlag into @Y_ID
	  end	
	  close UpdateUseFlag
    deallocate UpdateUseFlag
  end   
                    
commit tran 
  if OBJECT_ID('temp..#yidtmp') is not null
    drop table #yidtmp
  return 0 
  
error:
begin
   rollback tran 
   if OBJECT_ID('temp..#yidtmp') is not null
    drop table #yidtmp
   return -1
end
GO
