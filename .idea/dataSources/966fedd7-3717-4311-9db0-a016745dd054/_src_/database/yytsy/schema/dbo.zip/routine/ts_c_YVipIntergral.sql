
/******************************************************/
/*功能：用于处理独立账套时零售类单据过账处理会员卡积分*/
/*参数说明:*/
/*创建人：周继林*/
/*创建时间：2011-02-15*/
/*最后修改人：*/
/*最后修改时间:*/
/*最后修改修改说明：*/
/******************************************************/


CREATE  procedure ts_c_YVipIntergral
(
	@nBillId int,
	@nbilltype int
)
/*with encryption*/
as
set nocount on

/*declare @nbillID numeric(10,0)*/

declare @isbank int,@isIntergral int,@Vipcardid int,@iscxIntegral int
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
declare @saleIntegralYE NUMERIC(25,8)
declare @money NUMERIC(25,8)
declare @ctid int
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8)
declare @saleIntegral NUMERIC(25,8),@salemoney NUMERIC(25,8)
declare @RemainderMoney NUMERIC(25,8)
declare @INTEGRALMONEY NUMERIC(25,8)
declare @Intergral NUMERIC(25,8), @billIntergral NUMERIC(25,8), @billIntergralYE NUMERIC(25,8)
declare @isSpecialPriceIntegral int,@isPromotionIntegral int,@isYeIntegral int, @PriceType int,@Cxtype int
declare @StoreMoney_ID int
declare @nY_id int, @isZBZT int, @billguid varchar(50) 
select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/

if @nbilltype in (12,13)
begin
      select @ctid=v.ct_id,@money=v.RemainderMoney,@salemoney=b.ssmoney,@Vipcardid=v.Vipcardid,@isbank=v.isbank,
             @isSpecialPriceIntegral=isSpecialPriceIntegral,@isPromotionIntegral=isPromotionIntegral,@isYeIntegral=ISYEINTEGRAL,
             /*特殊商品参与积分                              特殊商品累计未兑换积分金额                积分余额累计*/
             @iscxIntegral=V.IsCxIntegral,@IntegralYE=v.IntergralYE , @CTintegral = v.INTEGRALMONEY,
             @order=b.billnumber,@isIntergral=V.isIntegral,@INTEGRALMONEY=v.INTEGRALMONEY,@Intergral=v.Integral,@nY_id=b.Y_id,
             @billguid = [GUID], @billIntergral = b.integral, @billIntergralYE = b.integralYE
             from billdraftidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid
      if @isbank = 1 return 0        
    
      if @isIntergral=1 and @Vipcardid>0
      begin         
         select @saleIntegral= @billIntergral
         if @isYeIntegral =1
         begin
           if @nbilltype = 12
           begin
             select @saleIntegral = @saleIntegral + cast((@billIntergralYE + @IntegralYE)/@CTintegral as int) 
             select @saleIntegralYE = @billIntergralYE - (@saleIntegral - @billIntergral)*@CTintegral
             select @modIntergral = @saleIntegral
           end
           else if @nbilltype = 13
           begin
             select @saleIntegralYE = @IntegralYE + @billIntergralYE
             select @modIntergral = @saleIntegral
             if @saleIntegralYE <0 
             begin
               select @modIntergral = @modIntergral -1
               select @saleIntegralYE = @saleIntegralYE + @CTIntegral
             end          
           end                       
         end else 
         begin
             select @modIntergral = @saleIntegral
         end
         select @saleIntegralYE = ISNULL(@saleIntegralYE, 0)
         if @nbilltype = 12
			update VIPCard set Integral = Integral + @modIntergral, IntergralYE = @saleIntegralYE,TotalBuyMoney=TotalBuyMoney+@salemoney,buycount=buycount+1 where VIPCardID  =@Vipcardid                        
         if @nbilltype = 13
			update VIPCard set Integral = Integral + @modIntergral, IntergralYE = @saleIntegralYE,TotalBuyMoney=TotalBuyMoney-@salemoney,buycount=buycount-1 where VIPCardID  =@Vipcardid                        
     end
end

SET QUOTED_IDENTIFIER ON
GO
