


CREATE VIEW DBO.VW_X_StoreHouseIni
AS
SELECT 
  SH.*, 
  P.[Serial_Number] AS [Code], P.[Name] AS [PName], P.[Class_ID] AS [PClass_ID],
  P.[MakeArea], tx.TaxRate as ptaxrate, P.[Validmonth], P.[Permitcode],
  P.[Alias], P.[Standard], m.id as [Medtype], P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod],
  P.[Modal], P.[TradeMark], P.[PinYin], 
  ISNULL(C.[Name]     ,'') AS [CName],     ISNULL(C.[Class_ID]  ,'') AS [CClass_ID], 
  ISNULL(S.[Name]     ,'') AS [SName],     ISNULL(S.[Class_ID]  ,'') AS [SClass_ID],
  ISNULL(U1.[Name]    ,'') AS [UnitName1], ISNULL(U2.[Name]     ,'') AS [UnitName2], 
  ISNULL(U3.[Name]    ,'') AS [UnitName3], ISNULL(U4.[Name]     ,'') AS [UnitName4],
  ISNULL(M.medtype  ,'') AS [MedName],   ISNULL(L.[Loc_Name]  ,'') AS [LocName],
  ISNULL(Y.[Class_ID] ,'') AS YClass_ID,  ISNULL(Y.[Name]      ,'') AS YName
FROM StoreHouseIni SH
  LEFT JOIN Storages S ON SH.[S_ID]=S.[Storage_ID] 
  LEFT JOIN Location L ON SH.[Location_ID]=L.[Loc_ID] 
  LEFT JOIN Clients C  ON SH.[Supplier_ID]=C.[Client_ID] 
  LEFT JOIN Products P ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN Unit U1    ON U1.[Unit_ID]=P.[Unit1_ID]
  LEFT JOIN Unit U2    ON U2.[Unit_ID]=P.[Unit2_ID]
  LEFT JOIN Unit U3    ON U3.[Unit_ID]=P.[Unit3_ID]
  LEFT JOIN Unit U4    ON U4.[Unit_ID]=P.[Unit4_ID]
  left join VW_MedType m on p.product_id = m.product_id
  LEFT JOIN Company Y  ON SH.Y_ID=Y.Company_ID
  left join VW_TaxRate tx on p.product_id = tx.product_id
WHERE (P.[Deleted]<>1) AND (S.[Deleted]=0)
GO
