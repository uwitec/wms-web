-- =============================================
-- Author:	<杨林>
-- Create date: <2015-07-02>
-- Description:	<手机版应收应付查询>
-- =============================================
CREATE procedure [dbo].[WebApp_QueryOtherInfo]
(
  @itag int = 0,
  @Params VARCHAR(400)--预留接口进行后期特殊版本传值
  --@datetype int = 0 --日期类型
)
as
begin
  /*
  @itag = 0 :最大数量查询
  @itag = 1 :综合日报
  @itag = 2 :库存仓库汇总表
  @itag = 3 :进销日报
  @itag = 4 :应收汇总
  @itag = 5 :现金银行余额表
  @itag = 6 :当日收付款日报
  @itag = 7 :当日应收应付日报
  @itag = 8 :应付排行
  @itag = 9 :应收排行  
  */
  /*-- 最大数量查询*/
   declare @bDate datetime,@eDate datetime,@emp_id int,@classid varchar(60)
   select @bDate  = dbo.webapp_get_param(@Params, 'bDate', default, default)
   select @eDate  = dbo.webapp_get_param(@Params, 'eDate', default, default)
   select @emp_id = dbo.webapp_get_param(@Params, 'emp_id', default, default)
   select @classid = dbo.webapp_get_param(@Params, 'classid', default, default)
   DECLARE @y_id INT 
   SET @y_id = 0
   SELECT @y_id = dbo.webapp_get_param(@Params, 'y_id', default, default)
   SET @y_id = 2 --yyt调试用，正式发须去掉
   
  if @itag = 0  
  begin
   declare @begindate datetime,@enddate datetime
   declare @monthbegindate datetime,@quarterbegindate datetime   
   declare @i int  set @i =0
   declare @year  int , @month int
         
--当日:
   --while @i<=2 
 --  begin 
     -- if  @i = 0
        select @begindate = getdate(),@enddate=getdate() 
      --else if @i = 1 begin --当月        
        select  @year  = datepart (year, getdate()),@month = datepart (month, getdate())
        select @monthbegindate = cast(cast(@year as varchar(4))+'-'+right('0'+cast(@month as varchar(2)),2)+'-01' as datetime)
       -- select @enddate= getdate()
     -- end else if @i =2 begin  --本季度
        select  @year  = datepart (year, getdate()),@month = datepart (month, getdate())

        if @month in (1,2,3) set @month = 1
        else if @month in (4,5,6) set @month = 4
        else if @month in (7,8,9) set @month = 7
        else if @month in (10,11,12) set @month = 10
        select @quarterbegindate = cast(cast(@year as varchar(4))+'-'+right('0'+cast(@month as varchar(2)),2)+'-01' as datetime)
        select @enddate= getdate()
		--end

    --按商品名称统计
	select main.flag, isnull(a.tag,'采购商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_数量Max' TAG, a.qty,a.total,p.name,'1' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(20,21) and b.billstates =0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union ALL   
	select main.flag, isnull(a.tag,'采购商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_金额Max' TAG,a.qty,a.total,p.name,'2' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union ALL 
	--按往来单位统计
	select main.flag, isnull(a.tag,'采购单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_数量Max' TAG, a.qty,a.total,c.name,'3' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'采购单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_金额Max' TAG,a.qty,a.total,c.name,'4' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by total desc) a on 1=1 
	union all
	--按商品名称统计
	select main.flag, isnull(a.tag,'销售商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_数量Max' TAG,a.qty,a.total,p.name,'5' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(10,11,12,13) and b.billstates=0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'销售商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_金额Max' TAG,a.qty,a.total,p.name,'6' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(10,11,12,13) and b.billstates=0 
         and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union all
	--按往来单位统计
	select main.flag, isnull(a.tag,'销售单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
        from (select 1 as flag) as main 
                left join (select top 1 '销售单位_数量Max' TAG,a.qty,a.total,c.name,'7' idx
   	                     from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                              from productdetail d inner join billidx b on b.billid=d.billid
	                             where b.billtype in(10,11,12,13) and b.billstates=0 
                                       and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
 	                             group by c_id) a inner join clients c on c.client_id=a.c_id
	                            order by qty desc) a on 1=1 
	union all
	select main.flag, isnull(a.tag,'销售单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
          from (select 1 as flag) as main 
          left join  (select top 1 '销售单位_金额Max' TAG,a.qty,a.total,c.name,'8' idx
 	                from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                         from productdetail d inner join billidx b on b.billid=d.billid
	                        where b.billtype in(10,11,12,13) and b.billstates=0 
                                  and convert(varchar(10),billdate,20) between convert(varchar(10),@begindate,20) and  convert(varchar(10),@enddate,20)
   	                        group by c_id) a 
                       inner join clients c on c.client_id=a.c_id
 	               order by total desc) a on 1=1
 	               --本月榜首
 	select main.flag, isnull(a.tag,'采购商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_数量Max' TAG,a.qty,a.total,p.name,'1' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(20,21) and b.billstates =0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'采购商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_金额Max' TAG, a.qty,a.total,p.name,'2' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union all
	--按往来单位统计
	select main.flag, isnull(a.tag,'采购单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_数量Max' TAG, a.qty,a.total,c.name,'3' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'采购单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_金额Max' TAG, a.qty,a.total,c.name,'4' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by total desc) a on 1=1 
	union all
	--按商品名称统计
	select main.flag, isnull(a.tag,'销售商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_数量Max' TAG,a.qty,a.total,p.name,'5' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(10,11,12,13) and b.billstates=0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'销售商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_金额Max' TAG, a.qty,a.total,p.name,'6' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(10,11,12,13) and b.billstates=0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union all
	--按往来单位统计
	select main.flag, isnull(a.tag,'销售单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
        from (select 1 as flag) as main 
                left join (select top 1 '销售单位_数量Max' TAG, a.qty,a.total,c.name,'7' idx
   	                     from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                              from productdetail d inner join billidx b on b.billid=d.billid
	                             where b.billtype in(10,11,12,13) and b.billstates=0 
                                       and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
 	                             group by c_id) a inner join clients c on c.client_id=a.c_id
	                            order by qty desc) a on 1=1 
	union all
	select main.flag, isnull(a.tag,'销售单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
          from (select 1 as flag) as main 
          left join  (select top 1 '销售单位_金额Max' TAG, a.qty,a.total,c.name,'8' idx
 	                from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                         from productdetail d inner join billidx b on b.billid=d.billid
	                        where b.billtype in(10,11,12,13) and b.billstates=0 
                                  and convert(varchar(10),billdate,20) between convert(varchar(10),@monthbegindate,20) and  convert(varchar(10),@enddate,20)
   	                        group by c_id) a 
                       inner join clients c on c.client_id=a.c_id
 	               order by total desc) a on 1=1
 	               --本季榜首
 		select main.flag, isnull(a.tag,'采购商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_数量Max' TAG,a.qty,a.total,p.name,'1' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(20,21) and b.billstates =0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'采购商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购商品_金额Max' TAG, a.qty,a.total,p.name,'2' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union all
	--按往来单位统计
	select main.flag, isnull(a.tag,'采购单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_数量Max' TAG,a.qty,a.total,c.name,'3' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'采购单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 0 as flag) as main left join
	(select top 1 '采购单位_金额Max' TAG, a.qty,a.total,c.name,'4' idx
	from  (select sum(d.quantity) qty,sum(d.taxtotal) total,c_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(20,21) and b.billstates =0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
	group by c_id) a inner join clients c on c.client_id=a.c_id
	order by total desc) a on 1=1 
	union all
	--按商品名称统计
	select main.flag, isnull(a.tag,'销售商品_数量Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_数量Max' TAG, a.qty,a.total,p.name,'5' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
			from productdetail d inner join billidx b on b.billid=d.billid
			where b.billtype in(10,11,12,13) and b.billstates=0 
                          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
			group by P_id) a 
			inner join products p on p.product_id=a.p_id
	order by qty desc) a on 1=1
	union all
	select main.flag, isnull(a.tag,'销售商品_金额Max') as tag,isnull(a.qty,0.00)as qty,
	isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'')
	as idx from (select 1 as flag) as main left join
	(select top 1 '销售商品_金额Max' TAG,a.qty,a.total,p.name,'6' idx
	from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,p_id
	from productdetail d inner join billidx b on b.billid=d.billid
	where b.billtype in(10,11,12,13) and b.billstates=0 
          and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
	group by P_id) a inner join products p on p.product_id=a.p_id
	order by total desc) a on 1=1
	union all
	--按往来单位统计
	select main.flag, isnull(a.tag,'销售单位_数量Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
        from (select 1 as flag) as main 
                left join (select top 1 '销售单位_数量Max' TAG,a.qty,a.total,c.name,'7' idx
   	                     from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                              from productdetail d inner join billidx b on b.billid=d.billid
	                             where b.billtype in(10,11,12,13) and b.billstates=0 
                                       and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
 	                             group by c_id) a inner join clients c on c.client_id=a.c_id
	                            order by qty desc) a on 1=1 
	union all
	select main.flag, isnull(a.tag,'销售单位_金额Max') as tag,isnull(a.qty,0.00)as qty,
	       isnull(a.total,0.00)as total,isnull(a.name,'无')as name,isnull(a.idx,'') as idx 
          from (select 1 as flag) as main 
          left join  (select top 1 '销售单位_金额Max' TAG,a.qty,a.total,c.name,'8' idx
 	                from  (select sum(-d.quantity) qty,sum(-d.taxtotal) total,c_id
	                         from productdetail d inner join billidx b on b.billid=d.billid
	                        where b.billtype in(10,11,12,13) and b.billstates=0 
                                  and convert(varchar(10),billdate,20) between convert(varchar(10),@quarterbegindate,20) and  convert(varchar(10),@enddate,20)
   	                        group by c_id) a 
                       inner join clients c on c.client_id=a.c_id
 	               order by total desc) a on 1=1
     --set @i = @i + 1
   -- end

    return 0
  end


  /*--综合日报*/
  else if @itag = 1 
  begin
   select cur_total,class_id,cast(name as nvarchar) name,cast(alias as nvarchar) alias
	from account 
	where  class_id='000001000003' or class_id='000001000001'
	group by cur_total,class_id,name,alias 
	union
	select sum(cur_total) cur_total,'000001000004' class_id,cast('银行' as nvarchar) name, cast('银行' as nvarchar) alias 
	from account 
	where parent_id like '000001000004%'
       /*当日收付款日报*/
      select '付款' as name,
	       isnull(cast(sum(-jdmoney) as numeric(18,4)),0.0)  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and (ac.class_id ='000001000003' or ac.class_id like '000001000004%')  --现金及银行付款
	   and b.billstates = '0' and b.billtype in (20,21,24,25,28,35,122/*,60,61*/,23)
	  and convert(varchar(10),b.billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	--  group by ac.class_id
	union
	select '收款' as name,
	--       ac.class_id,
	       isnull(cast(sum(jdmoney) as numeric(18,4)),0.0)  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and (ac.class_id ='000001000003' or ac.class_id like '000001000004%')  --现金及银行收款
	   and b.billstates = '0' and b.billtype in (12,13,10,11,18,16,17,112,32,15,62)
	   and convert(varchar(10),b.billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	--  group by ac.class_id  
	
	/*进销日报*/
	select cast('当日采购' as nvarchar) as [name],
	  isnull(sum(quantity),0) qty,
	  isnull(sum(total),0) discounttotal,
	  isnull(sum(taxtotal),0) taxtotal
	from vw_x_pdetail
	where billid in 
	   (select billid from vw_x_billidx 
	   where billtype in (20,21,24,25,28,35,122) 
	    and convert(varchar(10),billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	    and billstates=0)
	union
	select cast('当日销售' as nvarchar) as [name],
	  isnull(sum(-quantity),0) qty,
	  isnull(sum(-total),0) discounttotal,
	  isnull(sum(-taxtotal),0) taxtotal
	from vw_x_pdetail
	where billid in 
	   (select billid from vw_x_billidx 
	   where billtype in (12,13,10,11,18,16,17,112,32) 
	    and convert(varchar(10),billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	    and billstates=0)
   return 0
  end
 
  /*库存仓库汇总表*/
  else if @itag = 2
  begin
  
   declare @p_id int ,@standard varchar(100)
   select @p_id  = dbo.webapp_get_param(@Params, 'p_id', default, default)
   select @standard  = dbo.webapp_get_param(@Params, 'standard', default, default)
   select @standard = '%'+@standard+'%'
   select s.[name] as '仓库',
       cast(sum(h.quantity) as numeric(18,2)) as  '合计数量',
       cast(sum(h.costtotal) as numeric(18,2)) as  '合计金额'
	from storehouse h,storages s 
	where h.s_id=s.storage_id and s.deleted=0 and s.child_number=0
	and h.p_id in (select product_id from Products where (@p_id=0 or product_id=@p_id) and (@standard='%%' or standard like @standard))
	group by s.[name],h.s_id
    return 0
  end
 
  /*进销日报
  else if @itag = 3 
  begin
	select cast('当日采购' as nvarchar) as [name],
	  isnull(sum(quantity),0) qty,
	  isnull(sum(total),0) discounttotal,
	  isnull(sum(taxtotal),0) taxtotal
	from vw_x_pdetail
	where billid in 
	   (select billid from vw_x_billidx 
	   where billtype in (20,21,24,25,28,35,122) 
	    and convert(varchar(10),billdate,20) =convert(varchar(10),getdate(),20)
	    and billstates=0)
	union
	select cast('当日销售' as nvarchar) as [name],
	  isnull(sum(-quantity),0) qty,
	  isnull(sum(-total),0) discounttotal,
	  isnull(sum(-taxtotal),0) taxtotal
	from vw_x_pdetail
	where billid in 
	   (select billid from vw_x_billidx 
	   where billtype in (12,13,10,11,18,16,17,112,32) 
	    and convert(varchar(10),billdate,20) =convert(varchar(10),getdate(),20)
	    and billstates=0)
        return 0 
  end*/

  /*应收汇总*/
  else if @itag = 4
  begin
  declare  @serial_number varchar(30),
		   @basicname varchar(60),
		   @basicPY varchar(30),
		   @c_id int,
		   @d_id int
  select @serial_number  = dbo.webapp_get_param(@Params, 'basiccode', default, default)
  select @basicname = dbo.webapp_get_param(@Params, 'basicname', default, default)
  select @basicPY = dbo.webapp_get_param(@Params, 'BasicPY', default, default)
  select @c_id = dbo.webapp_get_param(@Params, 'c_id', default, default)--应收应付汇总
  select @d_id = dbo.webapp_get_param(@Params, 'd_id', default, default)--应收应付汇总  
 declare @OperatorID int
  declare @limit int set @limit=dbo._GetSubLimit(@OperatorID,887,0)
  declare @szCurrentParentID	VARCHAR(250)
  declare @CClassID VARCHAR(250)
  set @OperatorID=1
  set @szCurrentParentID='000000'
  set @CClassID='000000'
  
  DECLARE @SQLScript VARCHAR(7800),
          @SQLTemp   VARCHAR(2000), 
          @AR_ID     VARCHAR(30), 
          @AP_ID     VARCHAR(30), 
          @Sonnum INT,
          @AllAr float,
          @AllAp float,
          @SQLJoin   VARCHAR(2000)         
  IF @CClassID = ''   SELECT @CClassID = '000000'
  IF @CClassID ='000' SELECT @CClassID = ''
	   
  SELECT @AR_ID=[Class_ID],@AllAr=[cur_total] FROM Account WHERE [Account_ID]=9
  SELECT @AP_ID=[Class_ID],@AllAp=[cur_total] FROM Account WHERE [Account_ID]=15


  if @szCurrentParentID in ('','%%','%','000000') and len(@CClassID)>6
     or  len(@CClassID)- len(@szCurrentParentID)>=12
    set @szCurrentParentID = left(@CClassID,len(@CClassID)-6)



  declare @sztype varchar(1000)
--   if @arap = 0 select @sztype = '0,1,2'
--   else if @arap = 1 select @sztype = '0,2'
--   else if @arap = 2 select @sztype = '1,2'
  --往来单位权限表
  if exists(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#cLimit')) drop table #cLimit  
  create table #cLimit
 (
   client_id int
  )
  insert into #climit
  select client_id  from dbo.AuthorizeClients(@OperatorID) where (@CClassID='000000' or class_id like @CClassID+'%')
  union 
  select 0 as client_id

 -- select * from #climit
  select @sztype = '0,1,2'

  
 
    DECLARE @nLen int,
            @szAClassID varchar(30)

    IF @CClassID NOT IN('','%%','000000') AND @szCurrentParentID IN ('','%%','000000') 
    SELECT @szCurrentParentID=LEFT(@CClassID,LEN(@CClassID) -6)
    IF @szCurrentParentID in ('', '%%') SELECT @szCurrentParentID='000000'
    IF @CClassID in ('000000','') select @CClassID = ''
    IF @szCurrentParentID = '000000' SELECT @nLen = 6 ELSE  SELECT @nLen = len(@szCurrentParentID) + 6 
    --IF @ArAp = 1 SELECT @szAClassID = @AR_ID ELSE if @ArAp = 2 SELECT @szAClassID = @AP_ID else goto SUCCEE   

   -- declare @nA_ID int  select @nA_ID = account_id from account where class_id = @szAClassID
    

	if exists(select * from tempdb.dbo.sysobjects where id = object_id('tempdb.dbo.#temp_ar')) drop table #temp_ar 	
 	if exists(select * from tempdb.dbo.sysobjects where id = object_id('tempdb.dbo.#temp_ar1')) drop table #temp_ar1          	
        	         

         
	        	         
	SELECT mx.[CClass_ID] AS [Class_ID],
               YsTotal = sum(CASE WHEN mx.A_ID = 9 THEN mx.jdMoney else cast(0.0 as float) end),
               YfTotal = sum(CASE WHEN mx.A_ID = 15 THEN mx.jdMoney else cast(0.0 as float) end)
             into  #temp_ar1
         FROM vw_c_ADetail mx,billidx bi    
        WHERE mx.A_ID in (9,15)
          and mx.billid = bi.billid
          and bi.billstates = '0'
          --and (@CClassID='' or mx.CClass_ID like @CClassID +'%')
	  and (@c_id=0 or mx.c_id=@c_id)
                    
        GROUP BY mx.[CClass_ID]
		
          SELECT distinct 
				c.name as cname,
                 sum(ISNULL(c.artotal_ini,0) + ISNULL(d.[YsTotal],0) ) as [Artotal],
                 sum(ISNULL(c.aptotal_ini,0) + ISNULL(d.[YfTotal],0) ) as [Aptotal],
				 sum(isnull(ad.artotal_ini,0)) as artotal_ini,--已收金额
		     sum(ISNULL(ad.aptotal_ini,0)) as aptotal_ini--已付金额
	   FROM (
                  select [Client_ID], [Class_ID],child_number,serial_number, pinyin,  [Name],sum(a.artotal_ini) as artotal_ini,sum(a.aptotal_ini) as aptotal_ini
                  FROM Clientsbalance a,vw_Clients c
                   where a.c_id =c.client_id and c.deleted<>1
                     and c.Client_id in (select client_id from #climit)
	  	     --and (@c_id=0 or Client_ID=@c_id)
                     
                    group by [Client_ID], [Class_ID],   [Name],serial_number,child_number,pinyin
                 union all 
				 select client_id,class_id,child_number,serial_number,pinyin,name,sum(artotal_ini) as artotal_ini,sum(aptotal_ini) as aptotal_ini 
				 from Clients
				 where   Client_id in (select client_id from #climit)
				 group by client_id, class_id,name,serial_number,child_number,pinyin
               ) C

			    left  join (select  ad.c_id,
				          isnull(sum(case when idx.billtype in (10,11,18,16,17,112,32,15,62,64,67) then ad.jdmoney else 0 end),0.0) as artotal_ini,--已收金额
		                  isnull(sum(case when idx.billtype in (20,21,28,24,25,122,35,23,61,65,66) then -ad.jdmoney else 0 end),0.0) AS aptotal_ini 
						  from vw_c_ADetail ad
	                                  join billidx idx on 
	                                    ad.billid=idx.billid and idx.billtype in (10,11,18,16,17,112,32,15,
	                                                               20,21,28,24,25,122,35,23,61,62,64,65,66,67) and idx.billstates=0
	                                  and (AClass_ID='000001000003' or AClass_ID like '000001000004%')	
									  group by ad.c_id                                  
	       ) ad on c.client_id = ad.c_id
                LEFT JOIN #temp_ar1 d on C.Class_id = d.Class_ID
		--LEFT JOIN Department d2 on d.department_id = d2.departmentid
		where c.child_number=0 and c.client_id in (select client_id from dbo.AuthorizeClients(@emp_id))--做了往来单位授权的，不查询未授权的往来单位
	and c.class_id like  @classid+'%' 
	and (@c_id=0 or c.client_id = @c_id)
	and ((@serial_number='' or  c.serial_number like '%'+@serial_number+'%') or 
        (@basicname='' or c.name  like '%'+@serial_number+'%')or 
        (@basicPY='' or c.pinyin like '%'+@serial_number+'%'))
		group by c.name
    return 0
  end

  /*现金银行余额表*/
  else if @itag = 5
  begin
	select 1 as 'NO.',cast('期初' as nvarchar) Rowtype,
	       (select ini_total from Account where class_id='000001000003') cash,(select sum(ini_total)
	  from Account where parent_id like '000001000004%') bank
	union
	select 2 as 'NO.',cast('收入' as nvarchar) Rowtype,
	       (select isnull(sum(jdmoney),0)
	        from accountdetail d,account a 
	        where a_id=account_id and a.class_id='000001000003'  and jdmoney>0
	        group by name) as Cash,
	       (select isnull(sum(jdmoney),0)
	        from accountdetail d,account a 
	        where a_id=account_id and a.parent_id like '000001000004%' and jdmoney>0) bank  
	
	union
	select 3 as 'NO.',cast('支出' as nvarchar) Rowtype,
	       isnull((select isnull(sum(-jdmoney),0)
	        from accountdetail d,account a 
	        where a_id=account_id and a.class_id='000001000003'  and jdmoney<0
	        group by name),0.0) as Cash,
	       isnull((select isnull(sum(-jdmoney),0)
	        from accountdetail d,account a 
	        where a_id=account_id and a.parent_id like '000001000004%' and jdmoney<0),0.0) bank  
	union        
	select 4 as 'NO.',cast('余额' as nvarchar) Rowtype,
	      (select cur_total from Account where class_id='000001000003') cash,
	      (select sum(cur_total) from Account where parent_id like '000001000004%') bank

   return 0
  end 
  
  /*当日收付款日报*/
 /* else if @itag = 6 
  begin
	 select '付款' as name,
	--       ac.class_id,
	       isnull(cast(sum(abs(jdmoney)) as numeric(18,4)),0.0)  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and (ac.class_id ='000001000003' or ac.class_id like '000001000004%')  --现金及银行付款
	   and b.billstates = '0' and b.billtype in (20,21,24,25,28,35,122,60,61,23)
	   and convert(varchar(10),b.billdate,20)=convert(varchar(10),getdate(),20)
	--  group by ac.class_id
	union
	select '收款' as name,
	--       ac.class_id,
	       isnull(cast(sum(jdmoney) as numeric(18,4)),0.0)  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and (ac.class_id ='000001000003' or ac.class_id like '000001000004%')  --现金及银行收款
	   and b.billstates = '0' and b.billtype in (12,13,10,11,18,16,17,112,32,15,62)
	   and convert(varchar(10),b.billdate,20)=convert(varchar(10),getdate(),20)
	--  group by ac.class_id

   return 0
  end*/
  
  /*当日应收应付日报*/
  else if @itag = 7 
  begin
	 select ac.name,
	       ac.alias,
	       ac.class_id,
	       cast(sum(jdmoney) as numeric(18,4))  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and (ac.class_id ='000001000005' or ac.class_id ='000002000001')  --应收/应付账款科目
	   and b.billstates = '0'
	   and convert(varchar(10),b.billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	  group by ac.alias,ac.class_id,ac.[name]
          /*应付排行*/
        select c.name,a.total,c.class_id from (select top 10 a.c_id,cast(sum(jdmoney) as numeric(18,4))  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and ac.class_id ='000002000001'
	   and b.billstates = '0'
	   and convert(varchar(10),b.billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	  group by a.c_id) a 
	  left join clients c on c.client_id=a.c_id
		where c.child_number=0 and c.deleted=0 
	  order by a.total desc
     
	 /*应收排行*/
	select c.name,a.total,c.class_id from (select top 10 a.c_id,cast(sum(jdmoney) as numeric(18,4))  as total       
	  from [accountdetail] a,billidx b,account ac
	  where a.billid=b.billid and a.a_id=ac.account_id 
	   and ac.class_id ='000001000005'
	   and b.billstates = '0'
	   and convert(varchar(10),b.billdate,20) between convert(varchar(10),@bDate,20) and convert(varchar(10),@eDate,20)
	  group by a.c_id) a 
	  left join clients c on c.client_id=a.c_id
		where c.child_number=0 and c.deleted=0 
	  order by a.total desc
        return 0 
  end

  /*应付排行
  else if @itag = 8
  begin
      select top 10 name,aptotal as total 
	from clients c 
	where c.child_number=0 and c.deleted=0 
	order by c.aptotal desc
      return 0
  end */

 /*应收排行
  else if @itag = 9
  begin
   select top 10 c.name,c.artotal as total
     from clients c 
     where c.child_number=0 and c.deleted=0 
     order by c.artotal desc
   return 0
  end */
end
GO
