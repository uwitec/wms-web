
create  procedure ts_c_drafttohis
(
	@nbillid numeric(10,0),
	@nnewbillid numeric(10,0) output
)
/*with encryption*/
as
set nocount on

declare @bUserElabel char(1)
set @bUserElabel='0'
exec ts_getsysvalue 'ELabel',@bUserElabel out


/*变量定义*/
declare @nbilltype smallint /*单据类型*/
declare @nBillYId int	/* 单据机构*/
declare @nPosDataMode int	/* 机构数据传输模式*/
declare @nAccountYid int	/* 当前帐套机构*/
select @nbilltype=billtype, @nBillYId = Y_ID from billdraftidx where billid=@nbillid
select @nPosDataMode = posdatamode from company where company_id = @nBillYId
select @nAccountYid = sysvalue from sysconfig where sysname = 'Y_ID'

/*定义单据明细*/
declare 
	@p_id             int, 
	@batchno          varchar(20), 
	@quantity         NUMERIC(25,8), 
	@costprice        NUMERIC(25,8), 
	@saleprice        NUMERIC(25,8), 
	@discount         NUMERIC(25,8), 
	@discountprice    NUMERIC(25,8), 
	@totalmoney       NUMERIC(25,8), 
	@taxprice         NUMERIC(25,8), 
	@taxtotal         NUMERIC(25,8), 
	@taxmoney         NUMERIC(25,8), 
	@retailprice      NUMERIC(25,8), 
	@retailtotal      NUMERIC(25,8), 
	@makedate         datetime, 
	@validdate        datetime, 
	@qualitystatus    varchar(20), 
	@price_id         int, 
	@ss_id            int, 
	@sd_id            int, 
	@location_id      int, 
	@supplier_id      int, 
	@commissionflag   tinyint, 
	@comment          varchar(255),
	@unitid           int,
	@taxrate          NUMERIC(25,8),
	@order_id         int,
	@total            NUMERIC(25,8),
	@iotag            smallint,
	@invoicetotal     NUMERIC(25,8),
	@thqty            NUMERIC(25,8),
	@newprice         NUMERIC(25,8),
	@orgbillid        int,
	@sizeid           int,
	@colorid          int,
	@status           int,
	@invoice          int,
	@invoiceno        varchar(50),
	@jsprice          NUMERIC(25,8),
	@groupid          int,
	@draftrowid       int,
	@aoid             int,
	@businesstype     int,
	@rowtag           tinyint,
	@sm_id           int,
	@err_count       int,
	@SendQTY	 NUMERIC(25,8),/*已发货数量 */
	@SendCostTotal	 int,/*已发货成本金额*/
	@PriceType	 int,/*价格类型*/
	@RowGuid	 uniqueidentifier, /*行GUID*/
	@RowE_id	 int , /*明细行经手人*/
	@YCostPrice 	 varchar(50), /*机构收发货成本单价*/
	@YGUID           uniqueidentifier,
	@Y_ID    	 int ,
	@InStoreTime    datetime,
	@CxType			int,
	
	/*同价配送、自营店发货单入货货位*/
	@price         NUMERIC(25,8),
    @costtotal     NUMERIC(25,8),
    @retailmoney   NUMERIC(25,8),
    @location_id2  int,
    @comment2      varchar(200),
    @scomment  varchar(80),
    @batchbarcode varchar(80),
    @batchprice NUMERIC(25,8),
	@cxGuid uniqueidentifier,
	@cxSale NUMERIC(25,8),
	@Conclusion VARCHAR(200), /*质量结论*/
	@Factoryid int,            /*生产厂家id*/
	@costtaxprice NUMERIC(25,8), /*成本含税单价*/
	@costtaxrate NUMERIC(25,8),/*成本含税税率*/
	@costtaxtotal NUMERIC(25,8)/*成本含税金额*/
	declare @vipCard int	/* 会员卡号*/

	set @cxSale = 0

	declare @nSaleBackUseOldInput int /* 销售退单使用原单制单人*/

	exec ts_GetSystmpValue 'SaleBackUseOldInput', 0, @nSaleBackUseOldInput output
	
/*变量定义end*/
select @err_count = 0
/*销售类单据*/
if @nbilltype in (10,11,12,13,16,17,110,111,112,32,210,212,211,150,151,152,153,240,243,106,107) 
/*销售,销售退货,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,销售单,销售退货单,发货单,机构发货单,机构发货退货单，挂号单，诊治费用单*/
begin
/*插入表头*/
/*------------------------zhh添加，如果发货单存在未分配的行，返回-999999999*/
	if exists(select costprice from salemanagebilldrf where bill_id=@nbillid and costprice=999999999)  
		return -999999999
/*----------------------------------------------------------------------*/
	/* 无明细抛出异常*/
	if not exists(select * from salemanagebilldrf where bill_id = @nbillid and p_id > 0)
		return -6
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID ,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,RetailDate,WholeQty,PartQty, 
		QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate)
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID ,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,RetailDate,WholeQty,PartQty, 
		QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity
 
	select @vipCard = VipCardID from billdraftidx where billid = @nbillid
	
 declare salebillcurr cursor for
	 select p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID,INVOICENO,Y_ID, InStoreTime, cxtype, location_id2, comment2
	       ,batchbarcode,scomment,batchprice, cxGuid, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal
	 from dbo.salemanagebilldrf
	 where bill_id=@nbillid 
         order by smb_id
 open salebillcurr
 fetch next FROM  salebillcurr
 into  @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
       @newprice         , @orgbillid 	     , @jsprice          , @aoid             ,  @SendQTY	  , @SendCostTotal    ,         

       @PriceType	 , @RowGuid	     , @RowE_id		 , @YCostPrice       ,  @YGUID            , @INVOICENO        ,
       @Y_ID		 , @InStoreTime  , @CxType		 , @location_id2	 ,  @comment2,
       @batchbarcode,@scomment,@batchprice, @cxGuid  , @Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
while(@@fetch_status = 0)
begin
    if @YGUID is null set @YGUID = @RowGuid
    
	insert into salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID,INVOICENO, Y_ID, InStoreTime, cxType, location_id2, comment2,
	       batchbarcode,scomment,batchprice, cxGuid, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	select @nnewbillid,
           @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid             ,  @SendQTY	  , @SendQTY*@costprice,
 	       @PriceType	 , @RowGuid	     , @RowE_id  	 , @YCostPrice       ,  @YGUID		  ,@INVOICENO         ,
           @Y_ID		 , @InStoreTime  , @CxType		 , @location_id2	 ,  @comment2,
           @batchbarcode,@scomment,@batchprice, @cxGuid  , @Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
     
    select @sm_id =@@identity
    select @err_count = @err_count + @@error

	insert into salemanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType, location_id2,
	       batchbarcode,scomment,batchprice, CxGuid, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	select @nnewbillid,
           @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid 	     ,  @sm_id            ,
           @SendQTY	         , @SendQTY*@costprice, @PriceType	 , @RowGuid	     ,  @RowE_id          , @YCostPrice       ,
           @YGUID	         , @Y_ID    	      , @InStoreTime , @CxType		 ,  @location_id2,
           @batchbarcode,@scomment,@batchprice, @cxGuid, @Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
        
	/* 检测促销数量*/
	if (@cxGuid <> 0x0) AND (@nbilltype NOT IN (13))/*零售退货单不检测促销数量*/
	begin
		/* 实时连接全部检测，离线模式只在门店账套检测*/
		IF (@nPosDataMode = 0) OR ((@nAccountYid > 1) AND (@nPosDataMode = 1))    /*XXX.2017-08-17 考虑实时总部单体做零售单的情况*/
		BEGIN
		  /*限量检测仅限于价格促销和组合促销，并且无大类厂家等，仅限于商品*/
		  IF EXISTS(SELECT * FROM CxDetail WHERE guid = @cxGuid AND cp_id IN (10, 20))
		  BEGIN				  
		    DECLARE @cxTodaySale NUMERIC(25,8)		       		  		  
		    /*每日限量		    		    		    		    		    		    		    */
		    if @nBillYId > 1 and @nPosDataMode = 1
	        begin
			  SELECT @cxTodaySale = ISNULL(SUM(b.quantity), 0) from salemanagebill b inner join billidx i on b.bill_id = i.billid 
		        WHERE b.CxGuid = @cxGuid 		        
		          and (i.billdate BETWEEN CONVERT(varchar(10), Getdate(), 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59') 
		          and i.billstates = 0 and i.billtype in (10, 210, 12) 
				  and (i.Y_ID = @nBillYId)
		    end
		    else
		    begin
			  SELECT @cxTodaySale = ISNULL(SUM(b.quantity), 0) from salemanagebill b inner join billidx i on b.bill_id = i.billid 
		        WHERE b.CxGuid = @cxGuid 
		          and (i.billdate BETWEEN CONVERT(varchar(10), Getdate(), 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59') 
		          and i.billstates = 0 and i.billtype in (10, 210, 12) 
		    end
		   /*xxx.2016-12-02  每日限量做单位的换算  */
		    IF EXISTS(SELECT 0 FROM CxDetail c left join products p on c.p_id = p.product_id
			   WHERE (guid = @cxGuid) AND (@quantity + @cxTodaySale > case when c.unit_id = p.unit1_id then daylimit 
					when c.unit_id = p.unit2_id then daylimit* p.rate2
					when c.unit_id = p.unit3_id then daylimit* p.rate3
					when c.unit_id = p.unit4_id then daylimit* p.rate4 end
					) and (daylimit > 0))
		    BEGIN
		      set @err_count = 35000000 + @p_id
			  break
		    END
		    /* 每卡限量		    		     		    		    		    		    		    */
			IF @vipCard > 0
			BEGIN
			  IF @nBillYId > 2 and @nPosDataMode = 1
			  /*XXX.  bug-41433 限量要考虑退货的情况，应该减去退货的部分*/
				select @cxTodaySale = ISNULL(SUM(qty), 0) from
				(SELECT ISNULL(SUM(b.quantity), 0) as qty from salemanagebill b INNER JOIN billidx i on b.bill_id = i.billid 
		                                                                               INNER JOIN cxDetail x on b.cxGuid = x.Guid
			      WHERE b.CxGuid = @cxGuid 
			        AND ((x.CardLimitDay = 0) or 
			             ((x.cardlimitDay > 0) and (i.billdate BETWEEN CONVERT(varchar(10), Getdate() - X.CardLimitDay + 1, 120) and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59'))) 
			        AND i.billstates = 0 and i.billtype in (10, 210, 12) and i.VIPCardID = @vipCard 
			        AND i.Y_ID = @nBillYId		
			    union all
				SELECT ISNULL(SUM(-b.quantity), 0) as qty from salemanagebill b INNER JOIN billidx i on b.bill_id = i.billid 
		                                                                               INNER JOIN cxDetail x on b.cxGuid = x.Guid
			      WHERE b.CxGuid = @cxGuid 
			        AND ((x.CardLimitDay = 0) or 
			             ((x.cardlimitDay > 0) and (i.billdate BETWEEN CONVERT(varchar(10), Getdate() - X.CardLimitDay + 1, 120) and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59'))) 
			        AND i.billstates = 0 and i.billtype in (11,13,211) and i.VIPCardID = @vipCard 
			        AND i.Y_ID = @nBillYId	
			   ) t   			         
			  ELSE
				select @cxTodaySale = ISNULL(SUM(qty), 0) from (
				SELECT ISNULL(SUM(b.quantity), 0) as qty from salemanagebill b INNER JOIN billidx i on b.bill_id = i.billid 
		                                                                               INNER JOIN cxDetail x on b.cxGuid = x.Guid
			      WHERE b.CxGuid = @cxGuid 
			        AND ((x.CardLimitDay = 0) or 
			             ((x.cardlimitDay > 0) and (i.billdate BETWEEN CONVERT(varchar(10), Getdate() - X.CardLimitDay + 1, 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59'))) 
			        AND i.billstates = 0 and i.billtype in (10, 210, 12) and i.VIPCardID = @vipCard 	
			   union all
				SELECT ISNULL(SUM(-b.quantity), 0) as qty from salemanagebill b INNER JOIN billidx i on b.bill_id = i.billid 
		                                                                               INNER JOIN cxDetail x on b.cxGuid = x.Guid
			      WHERE b.CxGuid = @cxGuid 
			        AND ((x.CardLimitDay = 0) or 
			             ((x.cardlimitDay > 0) and (i.billdate BETWEEN CONVERT(varchar(10), Getdate() - X.CardLimitDay + 1, 120)and CONVERT(varchar(10), Getdate(), 120) + ' 23:59:59'))) 
			        AND i.billstates = 0 and i.billtype in (11,13,211) and i.VIPCardID = @vipCard 			        
			    )t    
			 /*xxx.2016-12-02  每卡限量做单位的换算       			            			 */
			  IF EXISTS(SELECT 0 FROM CxDetail c left join products p on c.p_id = p.product_id
			   WHERE (guid = @cxGuid) AND (@quantity + @cxTodaySale > case when c.unit_id = p.unit1_id then cardlimit 
					when c.unit_id = p.unit2_id then cardlimit* p.rate2
					when c.unit_id = p.unit3_id then cardlimit* p.rate3
					when c.unit_id = p.unit4_id then cardlimit* p.rate4 end
					) and (cardlimit > 0))
			  BEGIN
				SET @err_count = 35000000 + @p_id
				BREAK
			  END
			END
		    /*xxx.2016-12-02  每单限量做单位的换算 		  */
		    IF EXISTS(SELECT 0 FROM CxDetail c left join products p on c.p_id = p.product_id
			   WHERE (guid = @cxGuid) AND (@quantity  > case when c.unit_id = p.unit1_id then billlimit 
					when c.unit_id = p.unit2_id then billlimit* p.rate2
					when c.unit_id = p.unit3_id then billlimit* p.rate3
					when c.unit_id = p.unit4_id then billlimit* p.rate4 end
					) and (billlimit > 0))		/*zjx--tfs46702--20170401--处理价格促销.设置每卡限量，没有超出限量，零售收款提示超出限量，不能过账		    		    		    		    		    		    */
			BEGIN
			  SET @err_count = 35000000 + @p_id
			  BREAK
			END
		    /* 活动限量	*/
		    /*XXX. 活动限量也存在相同问题，一起修改， 限量要考虑退货的情况，应该减去退货的部分*/
		    select @cxSale = ISNULL(SUM(qty), 0) from	(    		    		    
			SELECT ISNULL(SUM(b.quantity), 0) as qty from salemanagebill b inner join billidx i on b.bill_id = i.billid 
			  WHERE b.CxGuid = @cxGuid 
				AND i.billstates = 0 and i.billtype in (10, 210, 12) and b.Y_ID = @Y_ID
			union all
			SELECT ISNULL(SUM(-b.quantity), 0) as qty from salemanagebill b inner join billidx i on b.bill_id = i.billid 
			  WHERE b.CxGuid = @cxGuid 
				AND i.billstates = 0 and i.billtype in (11,13,211) and b.Y_ID = @Y_ID
			)t  
			/*xxx.2016-12-02  活动限量做单位的换算 */
            IF EXISTS(SELECT 0 FROM CxDetail c left join products p on c.p_id = p.product_id
			   WHERE (guid = @cxGuid) AND (@quantity + @cxSale > case when c.unit_id = p.unit1_id then cxLimit 
					when c.unit_id = p.unit1_id then cxLimit* p.rate2
					when c.unit_id = p.unit1_id then cxLimit* p.rate3
					when c.unit_id = p.unit1_id then cxLimit* p.rate4 end
					) and (cxLimit > 0))	
            BEGIN
			  SET @err_count = 35000000 + @p_id
			  BREAK
			END		    		    		   		    		       
		  END
		END
	end

    select @err_count = @err_count + @@error
    if @err_count <> 0 break
	
	/*if @nbilltype = 243	--诊治费用单 // 诊治费用单保存时单据类型变为零售单，此段代码无用*/
	/*insert into RetailClinicbill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, */
	/*       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, */
	/*       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, */
	/*       comment,unitid,taxrate,total,invoicetotal,thqty,newprice,orgbillid,aoid,*/
	/*       PriceType, RowGuid, RowE_id, Y_ID, InStoreTime, cxType)*/
	/*select @nnewbillid,*/
 /*          @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,*/
	/*       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,*/
	/*       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,*/
	/*       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,*/
	/*       @taxrate          , @total            ,  @invoicetotal     , @thqty            ,*/
	/*       @newprice         , @orgbillid        , @aoid             ,*/
 /*	       @PriceType	 , @RowGuid	     , @RowE_id  	 ,*/
 /*          @Y_ID		 , @InStoreTime  , @CxType*/

	/*else*/
	if @nbilltype = 240	/*挂号单*/
	 insert into Registerbill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,total,invoicetotal,thqty,newprice,orgbillid,aoid,
	       PriceType, RowGuid, RowE_id, Y_ID, InStoreTime, cxType)
	select @nnewbillid,
               @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @total            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @aoid             ,
 	       @PriceType	 , @RowGuid	     , @RowE_id  	 ,
           @Y_ID		 , @InStoreTime  , @CxType

		if @bUserElabel='1' and @nbilltype=10 exec ts_c_AddElalbeTask @nnewbillid,@nbilltype,@sm_id,@location_id,@batchno,@quantity

     fetch next FROM  salebillcurr
	 into  @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid             ,  @SendQTY	  , @SendCostTotal    ,
  	       @PriceType	 , @RowGuid	     , @RowE_id          , @YCostPrice       ,  @YGUID		  , @INVOICENO        ,
           @Y_ID		 , @InStoreTime, @Cxtype		 , @Location_id2     , @comment2
           ,@batchbarcode,@scomment,@batchprice, @cxGuid, @Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
           
end
close salebillcurr
deallocate salebillcurr

if @nbilltype = 243
	delete from retailclinicbilldrf where bill_id = @nBillID
else if @nbilltype = 240
	delete from registerbilldrf where bill_id = @nBillID

if (@nSaleBackUseOldInput = 1) and (@nbilltype = 11)
begin
	if exists(select 0 from billidx where billid = @nnewbillid and GatheringMan > 0)
		update billidx set inputman = GatheringMan where billid = @nnewbillid
end
	
UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

if @err_count = 0
    return 0
else
if @err_count > 35000000
	return @err_count
else
    return -1

end
/*销售类单据*/

/*采购类单据*/
if @nbilltype in (20,21,24,25,120,121,122,35,220,222,221,160,161,162, 163,104,105) 
/*采购,采购退货,受托代销收货,受托代销退货,受托代销结算,采购单,采购退货单,收货单,机构收货单,机构收货退货单*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from buymanagebilldrf where bill_id = @nbillid and p_id > 0)
		return -6
  /*更新请货单的明细数量 gongq*/
  IF @nbilltype IN (160,162)
    EXEC Ts_g_SetComeQty @nbillid

 declare @buyprice NUMERIC(25,8)

/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty, DPdate, 
				QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty, DPdate, 
				QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity
	
	declare buybillcurr cursor for
	select p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
        totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
        qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
        comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,
        SendQTY,SendCostTotal,PriceType, RowGuid, RowE_ID , YCostPrice, YGUID, INVOICENO, Y_ID, InStoreTime, comment2
        ,batchbarcode,scomment,batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal
	from dbo.buymanagebilldrf where bill_id=@nbillid 
	order by smb_id
	Open buybillcurr
	fetch next from buybillcurr into
        @p_id           , @batchno   , @quantity , @costprice, @buyprice     , @discount     , @discountprice  , 
        @totalmoney     , @taxprice  , @taxtotal , @taxmoney , @retailprice  , @retailtotal  , @makedate       , @validdate, 
        @qualitystatus  , @price_id  , @ss_id    , @sd_id    , @location_id  , @supplier_id  , @commissionflag , 
        @comment        , @unitid    , @taxrate  , @order_id , @total,@iotag , @invoicetotal , @thqty          , @newprice,@orgbillid,@jsprice  , 
		@aoid           , @SendQTY	         , @SendCostTotal,@PriceType , @RowGuid	     , @RowE_id        , @YCostPrice  	,@YGUID,  @INVOICENO,
        @Y_ID           , @InStoreTime   , @comment2,
        @batchbarcode,@scomment,@batchprice, @Conclusion,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
	while(@@fetch_status = 0)
	begin 	
	    if @YGUID is null set @YGUID = @RowGuid
	
		insert into buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,SendQTY,SendCostTotal,PriceType, 
	       RowGuid, RowE_id, YCostPrice,YGUID,INVOICENO,Y_ID, InStoreTime, comment2
	       ,batchbarcode,scomment,batchprice,Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		select @nnewbillid, 
	        @p_id           , @batchno   , @quantity , @costprice, @buyprice     , @discount     , @discountprice  , 
	        @totalmoney     , @taxprice  , @taxtotal , @taxmoney , @retailprice  , @retailtotal  , @makedate       , @validdate, 
	        @qualitystatus  , @price_id  , @ss_id    , @sd_id    , @location_id  , @supplier_id  , @commissionflag , 
	        @comment        , @unitid    , @taxrate  , @order_id , @total,@iotag , @invoicetotal , @thqty          , @newprice,@orgbillid,@jsprice  , @aoid,
            @SendQTY        , @SendQTY*@costprice ,@PriceType    , @RowGuid      , @RowE_id      , @YCostPrice     ,@YGUID, @INVOICENO, 
            @Y_ID		, @InStoreTime, @comment2,
            @batchbarcode,@scomment,@batchprice,@Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
        select @sm_id =@@identity
        select @err_count = @err_count + @@error

		if @bUserElabel='1' and @nbilltype=20 exec ts_c_AddElalbeTask @nnewbillid,@nbilltype,@sm_id,@location_id,@batchno,@quantity

		insert into buymanagebilltmp(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid, smb_id,SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice,YGUID, Y_ID, InStoreTime,
	       batchbarcode,scomment,batchprice,Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		select @nnewbillid, 
	        @p_id           , @batchno   , @quantity , @costprice, @buyprice     , @discount     , @discountprice  , 
	        @totalmoney     , @taxprice  , @taxtotal , @taxmoney , @retailprice  , @retailtotal  , @makedate       , @validdate, 
	        @qualitystatus  , @price_id  , @ss_id    , @sd_id    , @location_id  , @supplier_id  , @commissionflag , 
	        @comment        , @unitid    , @taxrate  , @order_id , @total,@iotag , @invoicetotal , @thqty          , @newprice,@orgbillid,@jsprice  ,@aoid   , @sm_id,
            @SendQTY        , @SendQTY*@costprice ,@PriceType    , @RowGuid      , @RowE_id      , @YCostPrice     , @YGUID,
            @Y_ID		, @InStoreTime,
            @batchbarcode,@scomment,@batchprice,@Conclusion,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
        select @err_count = @err_count + @@error
        if @err_count <> 0 break
		fetch next from buybillcurr into
	        @p_id           , @batchno   , @quantity , @costprice, @buyprice     , @discount     , @discountprice  , 
	        @totalmoney     , @taxprice  , @taxtotal , @taxmoney , @retailprice  , @retailtotal  , @makedate       , @validdate, 
	        @qualitystatus  , @price_id  , @ss_id    , @sd_id    , @location_id  , @supplier_id  , @commissionflag , 
	        @comment        , @unitid    , @taxrate  , @order_id , @total,@iotag , @invoicetotal , @thqty          , @newprice,@orgbillid,@jsprice  , @aoid,
            @SendQTY        , @SendCostTotal,@PriceType, @RowGuid, @RowE_id      , @YCostPrice   , @YGUID	       , @INVOICENO ,
            @Y_ID           , @InStoreTime, @comment2  ,
            @batchbarcode,@scomment,@batchprice,@Conclusion,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal

end
 close buybillcurr
 deallocate buybillcurr
UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1
	IF @nbilltype IN (20)
	BEGIN
		UPDATE DeliveryBillPicInfo 
			SET IsDraft = 0, BillId = @nnewbillid
		WHERE BillId = @nbillid AND IsDraft = 1 AND BillType = @nbilltype
	END
 if @err_count = 0
   return 0
 else
   return -1
end
/*采购类单据*/

/*库存类单据*/
if @nbilltype in (30,31,33,34,40,38,39,41,42,43,44,45,46,47,48,49,51,141)
/*借出单,借出还回单,借转销售单,零售拆零单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单,期初库存录入单,请斗单*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from storemanagebilldrf where bill_id = @nbillid and p_id > 0)
		return -6
	/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag, 
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID,Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, 
				QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag, 
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, 
				QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity

 declare tranbillcurr cursor for
	select p_id           , batchno   , quantity      , price        , totalmoney , costprice  , costtotal    , retailprice  , retailmoney,
	       makedate       , validdate , qualitystatus , price_id     , ss_id      , sd_id      , location_id  , supplier_id  ,  
	       commissionflag , comment   , unitid        , location_id2 , iotag      , total      , invoicetotal , thqty        , newprice,
	       orgbillid      ,  aoid     , SendQTY        , SendCostTotal, RowGuid   , RowE_id    , Y_ID         , InStoreTime,
	       batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal
	 from storemanagebilldrf
	 where bill_id=@nbillid 
 open tranbillcurr
 fetch next from tranbillcurr into
	       @p_id           , @batchno   , @quantity      , @price        , @totalmoney , @costprice  , @costtotal    , @retailprice  , @retailmoney,
	       @makedate       , @validdate , @qualitystatus , @price_id     , @ss_id      , @sd_id      , @location_id  , @supplier_id  ,  
	       @commissionflag , @comment   , @unitid        , @location_id2 , @iotag      , @total      , @invoicetotal , @thqty        , @newprice,
	       @orgbillid      , @aoid      , @SendQTY       , @SendCostTotal, @RowGuid    , @RowE_id    , @Y_ID         , @InStoreTime,
	       @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
 while(@@fetch_status = 0) 
 begin
	 insert into storemanagebill(bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
	      makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, 
	      commissionflag, comment,unitid,location_id2,iotag,total,invoicetotal,thqty,newprice,
	      orgbillid,aoid,SendQTY,SendCostTotal, RowGuid, RowE_id, Y_ID, InStoreTime,
	      batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	 select @nnewbillid, 
	        @p_id           , @batchno   , @quantity      , @price        , @totalmoney , @costprice  , @costtotal    , @retailprice  , @retailmoney,
	        @makedate       , @validdate , @qualitystatus , @price_id     , @ss_id      , @sd_id      , @location_id  , @supplier_id  ,  
	        @commissionflag , @comment   , @unitid        , @location_id2 , @iotag      , @total      , @invoicetotal , @thqty        , @newprice,
	        @orgbillid      , @aoid      , @SendQTY       , @SendQTY*@costprice         , @RowGuid    , @RowE_id	  , @Y_ID         , @InStoreTime,
	        @batchbarcode,@scomment,@batchprice,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
	        select @sm_id =@@identity
	        select @err_count = @err_count + @@error
	        
	        
	 if @nbilltype <> 141 
	 begin       
		 insert into storemanagebilltmp(bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
			  makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, 
			  commissionflag, comment,unitid,location_id2,iotag,total,invoicetotal,thqty,newprice,
			  orgbillid,aoid, smb_id,SendQTY,SendCostTotal, RowGuid, RowE_id, Y_ID, InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		 select @nnewbillid, 
				@p_id           , @batchno   , @quantity      , @price        , @totalmoney , @costprice  , @costtotal    , @retailprice  , @retailmoney,
				@makedate       , @validdate , @qualitystatus , @price_id     , @ss_id      , @sd_id      , @location_id  , @supplier_id  ,  
				@commissionflag , @comment   , @unitid        , @location_id2 , @iotag      , @total      , @invoicetotal , @thqty        , @newprice,
				@orgbillid      , @aoid      , @sm_id         , @SendQTY      , @SendQTY*@costprice	  , @RowGuid	  , @RowE_id      , @Y_ID    , @InStoreTime,
				@batchbarcode,@scomment,@batchprice,@Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
			select @err_count = @err_count + @@error
			if @err_count <> 0 break
	 end		


	 fetch next from tranbillcurr into
		       @p_id           , @batchno   , @quantity      , @price        , @totalmoney , @costprice  , @costtotal    , @retailprice  , @retailmoney,
		       @makedate       , @validdate , @qualitystatus , @price_id     , @ss_id      , @sd_id      , @location_id  , @supplier_id  ,  
		       @commissionflag , @comment   , @unitid        , @location_id2 , @iotag      , @total      , @invoicetotal , @thqty        , @newprice,
		       @orgbillid      , @aoid      , @SendQTY       , @SendCostTotal, @RowGuid	   , @RowE_id    , @Y_ID         , @InStoreTime,
		       @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
 end/*while*/
 close tranbillcurr
 deallocate tranbillcurr
UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

 if @err_count = 0 
   return 0
 else
   return -1
end
/*库存类单据*/

if @nbilltype=50
/*库存盘点单*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from GoodsCheckBillDrf where bill_id = @nbillid and p_id > 0)
		return -6
	/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	    ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid, Y_ID,
        B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, QualityAudit, QualityAuditDate, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid, Y_ID,
	    B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, QualityAudit, QualityAuditDate, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity
	insert into goodscheckbill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
      	totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      	qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      	comment,unitid,taxrate,order_id,total,aoid, RowGuid, Y_ID, InStoreTime,
      	batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	select @nnewbillid, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
      	totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      	qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      	comment,unitid,taxrate,order_id,total,aoid, RowGuid, Y_ID , InStoreTime,
      	batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal
	from goodscheckbilldrf where bill_id=@nbillid	
	order by smb_id
	UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

	return	0
end
/*库存盘点单*/

/*积分兑换单*/
if @nbilltype=149
begin  /* select * from billidx*/
	/* 无明细抛出异常*/
	if not exists(select * from ExIntegRalManagebilldrf where billid = @nbillid)
		return -6
	/*插入表头*/
	 insert into billidx(billdate,     billnumber,     billtype,      a_id,         c_id,          e_id,         sout_id,      sin_id,
	                     auditman,     inputman,       ysmoney,       ssmoney,      quantity,      taxrate,      period,       billstates,
	                     order_id,     department_id,  posid,         region_id,    auditdate,     skdate,       jsye,         jsflag,
	                     note,         summary,        invoice,       transcount,   lasttranstime, invoicetotal, invoiceno,    businesstype,  transflag,
	                     guid,         ARAPTOTAL,      VIPCardID, 	  Y_ID,         B_CustomName1, B_CustomName2,B_CustomName3,sendC_ID, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate) 
	 select cast(cast(billdate as varchar(10)) as datetime), billnumber,    billtype,     a_id,      c_id,         e_id,        sout_id,     sin_id,
	                    auditman,                            inputman,      ysmoney,      ssmoney,   quantity,     taxrate,     period,      billstates,
	                    order_id,                            department_id, posid,        region_id, auditdate,    skdate,      jsye,        jsflag,
	                    note,                                summary,       invoice,      transcount,lasttranstime,invoicetotal,invoiceno,   businesstype,  transflag,
	                    guid,          ARAPTOTAL,            VIPCardID,     Y_ID,         B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate
	 from billdraftidx where billid=@nbillid
	/* select * from  ExIntegRalManagebilldrf*/
	 select @nnewBillid=@@identity
	 insert into ExIntegRalManagebill
	       (billid,       p_id,      u_id,           s_id,          colorID,      SizeID,      quantity,
	        CostPrice,    CostTotal, IntegralMoney,  IntegralTotal, status,       Comment,     RowTag,      AOID,batchno,	makedate,	validdate,	location_id,
           supplier_id,		commissionflag,		SendQTY ,		SendCostTotal,     Y_ID	   , InStoreTime,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	 select @nnewBillid,  p_id,      u_id,           s_id,          colorID,      SizeID,      quantity,    
	        CostPrice,    CostTotal, IntegralMoney,  IntegralTotal, status,       Comment,     RowTag,      AOID,batchno,	makedate,	validdate,	location_id,
           supplier_id,		commissionflag,		SendQTY ,		SendCostTotal,     Y_ID    , InStoreTime,factoryid,costtaxprice,costtaxrate,costtaxtotal
	 from ExIntegRalManagebilldrf 
	 where billid=@nbillid
	 order by smb_id
	UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

	return 0
end
/*积分兑换单*/

/*钱流单据*/
if @nbilltype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,87,88,147,146,148,155,165,170,171,172,173,174)
/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from financebilldrf where bill_id = @nbillid)
		return -6
	/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, QualityAudit, QualityAuditDate, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,QualityAudit, QualityAuditDate, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity
	insert into financebill(bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,invoicetotal, RowGuid, Y_ID)
	select @nnewbillid,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,invoicetotal, RowGuid, Y_ID
	from financebilldrf 
	where bill_id=@nbillid	
	order by smb_id
	UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

	return	0
end
/*钱流单据*/


if @nbilltype in (184,185)
/*返利获利单据*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from ReturnBilldrf where bill_id = @nbillid)
		return -6
	/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID,begindate, Enddate,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID, begindate,Enddate,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, YGuid, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity
	insert into ReturnBill(bill_id,ret_id,P_id, SaleQty, SaleTotal, RetTotal,total, comment)
	select @nnewbillid,ret_id,p_id, SaleQty, SaleTotal, RetTotal,Total, comment
	from ReturnBilldrf 
	where bill_id=@nbillid	
	order by smb_id
	UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

	return	0
end
/*返利获利单据*/

if @nbilltype in (53,54,55,56) 
/*配送*/
begin
	/* 无明细抛出异常*/
	if not exists(select * from tranmanagebilldrf where bill_id = @nbillid)
		return -6
	/*插入表头*/
	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID, QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate) 
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, transflag,
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
                SendQTY,GatheringMan,VipCardID, Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,QualityAudit, QualityAuditDate, YGuid,FollowNumber,TicketDate, BalanceMode,ZBAuditMan,ZBAuditDate
	from billdraftidx where billid=@nbillid
	
	select @nnewbillid=@@identity

 declare tranbillcurr cursor for
	select p_id           , batchno   , quantity     , costprice , saleprice   , discount     , discountprice , 
	       totalmoney     , taxprice  , taxtotal     , taxmoney  , retailprice , retailtotal  , makedate      , validdate, 
	       qualitystatus  , price_id  , ss_id        , sd_id     , location_id , supplier_id  , commissionflag, 
	       comment        , unitid    , taxrate      , order_id  , total,iotag , invoicetotal , thqty         , newprice ,
	       orgbillid      , aoid      , SendQTY      , SendCostTotal, RowGuid  , RowE_id      , Y_ID  	  , InStoreTime,
	       batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal
	 from dbo.tranmanagebilldrf
         where bill_id=@nbillid 
 open tranbillcurr
 fetch next from tranbillcurr into
	       @p_id           , @batchno   , @quantity     , @costprice , @saleprice   , @discount     , @discountprice , 
	       @totalmoney     , @taxprice  , @taxtotal     , @taxmoney  , @retailprice , @retailtotal  , @makedate      , @validdate, 
	       @qualitystatus  , @price_id  , @ss_id        , @sd_id     , @location_id , @supplier_id  , @commissionflag, 
	       @comment        , @unitid    , @taxrate      , @order_id  , @total       , @iotag        , @invoicetotal , @thqty         , @newprice ,
	       @orgbillid      , @aoid      , @SendQTY      , @SendCostTotal, @RowGuid  , @RowE_id      , @Y_ID 	, @InStoreTime,
	       @batchbarcode	,@scomment	,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal
 while(@@fetch_status = 0)
 begin
	 insert into tranmanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,aoid,
           SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, InStoreTime,
           batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
	 select @nnewbillid, 
	        @p_id           , @batchno   , @quantity     , @costprice , @saleprice   , @discount     , @discountprice , 
	        @totalmoney     , @taxprice  , @taxtotal     , @taxmoney  , @retailprice , @retailtotal  , @makedate      , @validdate, 
	        @qualitystatus  , @price_id  , @ss_id        , @sd_id     , @location_id , @supplier_id  , @commissionflag, 
	        @comment        , @unitid    , @taxrate      , @order_id  , @total       , @iotag        , @invoicetotal , @thqty         , @newprice ,
	        @orgbillid      , @aoid      , @SendQTY      , @SendQTY*@costprice	 , @RowGuid	 , @RowE_id      , @Y_ID	, @InStoreTime,
	        @batchbarcode,@scomment,@batchprice,@factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
        select @sm_id =@@identity
        select @err_count = @err_count + @@error
		insert into tranmanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,aoid, smb_id,SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, InStoreTime,
	       batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		select @nnewbillid, 
	        @p_id           , @batchno   , @quantity     , @costprice , @saleprice   , @discount     , @discountprice , 
	        @totalmoney     , @taxprice  , @taxtotal     , @taxmoney  , @retailprice , @retailtotal  , @makedate      , @validdate, 
	        @qualitystatus  , @price_id  , @ss_id        , @sd_id     , @location_id , @supplier_id  , @commissionflag, 
	        @comment        , @unitid    , @taxrate      , @order_id  , @total       , @iotag        , @invoicetotal , @thqty         , @newprice ,
	        @orgbillid      , @aoid      , @sm_id        , @SendQTY   , @SendQTY*@costprice		 , @RowGuid	 , @RowE_id       , @Y_ID 	, @InStoreTime,
	        @batchbarcode	,@scomment	,@batchprice     , @Factoryid,@costtaxprice,@costtaxrate,@quantity*@costtaxprice
        
        select @err_count = @err_count + @@error
        
        if @err_count <> 0 break
 		
 		fetch next from tranbillcurr into
	       @p_id           , @batchno   , @quantity     , @costprice , @saleprice   , @discount     , @discountprice , 
	       @totalmoney     , @taxprice  , @taxtotal     , @taxmoney  , @retailprice , @retailtotal  , @makedate      , @validdate, 
	       @qualitystatus  , @price_id  , @ss_id        , @sd_id     , @location_id , @supplier_id  , @commissionflag, 
	       @comment        , @unitid    , @taxrate      , @order_id  , @total       , @iotag        , @invoicetotal  , @thqty         , @newprice ,
	       @orgbillid      , @aoid      , @SendQTY      , @SendCostTotal 		, @RowGuid	, @RowE_id       , @Y_ID 	  , @InStoreTime,
	       @batchbarcode	,@scomment	, @batchprice   , @Factoryid,@costtaxprice,@costtaxrate,@costtaxtotal

 end/*while*/
 close tranbillcurr
 deallocate tranbillcurr
	UPDATE billTrace SET billId = @nnewbillid, isDraft = 0 WHERE billId = @nbillid AND billType = @nbilltype AND isDraft = 1

 if @err_count = 0
   return 0
 else
   return -1
end
/*销售类单据*/
GO
