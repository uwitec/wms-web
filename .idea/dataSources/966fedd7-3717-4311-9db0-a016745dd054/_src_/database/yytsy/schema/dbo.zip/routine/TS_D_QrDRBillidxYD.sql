

CREATE procedure TS_D_QrDRBillidxYD
@OperatorNo INT,
@BATCHNO VARCHAR(30),
@Up  INT /*0查本地 1查中心  */
AS
  
  SET NOCOUNT ON 
  IF @Up=0
  BEGIN 
	SELECT a.OperatorNo,a.BATCHNO,a.DR10Num,a.EmpNum,a.InvoiceNo,a.SettleFlag,
		   a.BillTotal,a.CashMoney,a.YBMoney,a.TCMoney,
		   b.billnumber,
		   Case when a.billtype  = 12 then '零售单'  
				WHEN a.billtype  = 13 then '零售退货单' 
		   ELSE '' 
		   END billtypename,
		   Case when a.Billstates  = 3 and a.billid = 0 and a.SettleFlag not in ('600', '601') then '药易通未记账,将取消' 
				when a.Billstates  = 3 and a.billid > 0 and a.SettleFlag not in ('600', '601') then '药易通已记账,将确认' 
		   else '正常' 
		   END BillstatesName,         
		   Case when a.SettleFlag  = '11' then '普通购药未确认'  
				WHEN a.SettleFlag  = '600' then '确认结算' 
				when a.SettleFlag  = '13' then '慢性病购药未确认'    
				WHEN a.SettleFlag  = '601' then '取消结算'
				when a.SettleFlag  = '501' then '结算退费未确认'   
		   ELSE ''
		   END SettleFlagName          
	FROM DRBillidx a LEFT JOIN billidx b 
		 ON a.Billid=b.Billid 
	WHERE a.OperatorNo=@OperatorNo AND a.BATCHNO=@BATCHNO 
	      AND ((a.Billtype=12 AND a.SettleFlag<>'601') or a.Billtype=13) 
	ORDER BY a.DRbillid
  END
  ELSE 
  BEGIN  
	SELECT OperatorNo,BATCHNO,DR10Num,EmpNum,InvoiceNo,SettleFlag,
		   BillTotal,CashMoney,YBMoney,TCMoney,SendSerialNo,TCAreaNo,
		   Case when billtype  = 12 then '零售单'  
				WHEN billtype  = 13 then '零售退货单' 
		   ELSE '' 
		   END billtypename,
		   '正常' AS BillstatesName,
		   Case WHEN SettleFlag  = '600' then '确认结算'  
				WHEN SettleFlag  = '601' then '取消结算'
		   ELSE ''
		   END SettleFlagName 	              
	FROM DRBillidxTemp
	WHERE OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO 
	ORDER BY DRbillid
  END
GO
