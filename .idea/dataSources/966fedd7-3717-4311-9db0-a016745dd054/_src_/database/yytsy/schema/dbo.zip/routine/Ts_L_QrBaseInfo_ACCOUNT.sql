
create PROCEDURE Ts_L_QrBaseInfo_ACCOUNT
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

 if @szWhere ='CASHBANK'
  select * 
  from vw_ACCOUNT
  where  (Child_Number=0)
   and ([Name] like @szName or serial_number like @szName or 
   PinYin like @szName)  and (sysflag=1 or left(parent_id,12) ='000001000004') and deleted=0
   and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
 else
 if @szwhere='STOREMONEY'
  select * 
  from vw_ACCOUNT
  where  (Child_Number=0)
   and ([Name] like @szName or serial_number like @szName or 
   PinYin like @szName) and deleted=0
   and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
 else if @szWhere ='CASHBANKPR' 
   select * 
   from vw_ACCOUNT
   where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0  
     and class_id not in ('000001000009','000001000004009999','000001009999') and deleted=0
     and ([Name] like @szName or serial_number like @szName or PinYin like @szName)
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
else if @szWhere ='CASHBANKPP' 
   select * 
   from vw_ACCOUNT
   where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0  
     and class_id not in  ('000002000005','000001000004009999','000001009999') and deleted=0
     and ([Name] like @szName or serial_number like @szName or PinYin like @szName)
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
else if @szWhere ='PREAP' 
   select * 
   from vw_ACCOUNT
   where  Child_number=0  and class_id =  '000001000009' and deleted=0  
      and ([Name] like @szName or serial_number like @szName or PinYin like @szName)
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
else if @szWhere ='PREAR' 
   select * 
   from vw_ACCOUNT
   where Child_number=0  and class_id = '000002000005' and deleted=0  
     and ([Name] like @szName or serial_number like @szName or PinYin like @szName)
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
else
 if @szWhere<>''
  select * 
  from vw_ACCOUNT
  where  (Child_Number=0)
   and ([Name] like @szName or serial_number like @szName or 
   PinYin like @szName) and Parent_id=@szWhere and deleted=0
    and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
else
  select * 
  from vw_ACCOUNT
  where  (Child_Number=0)
   and ([Name] like @szName or serial_number like @szName or 
   PinYin like @szName) and deleted=0
   and class_id in (select class_id from dbo.AuthorizeAccount(@E_id))
GO
