
/* 功能：销售决策查询 按机构汇总
  
*/

CREATE PROCEDURE TS_J_RepSale01
( 
	@szbegindate varchar(12),   /*开始时间*/
	@szenddate   varchar(12),   /*结束时间*/
	@dateMode  int		   /*1 月 2 季度 3 年		*/
)

AS


/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @OpenDate  datetime    /*开账日期*/
   declare @sumArea NUMERIC(25,8)
                      
   if @szbegindate <> ''
     set @begindate = CAST((@szbegindate+ '-01') as datetime)
     
   if @szenddate <> ''
     set @enddate = CAST((@szenddate+ '-01') as datetime)      
   set @enddate = dateadd(mm,1,@enddate) 
   set @enddate = @enddate -1 
      
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @begindate
   if @begindate <  @OpenDate
     set @begindate = cast((cast(datepart(yyyy, @OpenDate) as varchar(4)) + '-' + cast(datepart(MM, @OpenDate) as varchar(2)) + '-' + '01') as datetime)
                      
/*创建日期分段表，标识，时间跨度*/
/*创建返回信息表*/
/*计算返回值*/

if OBJECT_ID('tempdb..#SplitDate' ) is not null 
  drop table #SplitDate
create table #splitDate
			 ( dateid int IDENTITY,   /*分隔日期后标识*/
			   FlagName varchar(50),  /*分隔后标识名称，例按年 2013 按月201306 按季度2013二季度*/
			   yyyy     varchar(10),  /*所属于年 */
			   qqq		varchar(10),  /*所属季度			   */
			   mm		varchar(10),  /*所属月			   			   	     */
			   begindate datetime,    /*本段分隔的开始时间*/
			   enddate   datetime,    /*本段分隔的结束时间*/
			   daycount  int		  /*本段分隔的天数统计	  */
			  )  
			  
			  			          
if OBJECT_ID('tempdb..#qrSale01' ) is not null 
  drop table #qrSale01
create table #qrSale01
             ( dateid int,
               y_id   int,           /*分支机构                            */
               SaleQty NUMERIC(25,8),		 /*数量*/
               Saletotal NUMERIC(25,8),		 /*含税金额	*/
               BackQty NUMERIC(25,8),        /*退货数量 not show*/
               BackTotal NUMERIC(25,8),      /*退货金额 not show*/
               costtotal NUMERIC(25,8),      /*成本金额*/
			   profit 	 NUMERIC(25,8), 	 /*毛利*/
			   geustCount  int,		 /*来客数*/
			   gesutPrice  NUMERIC(25,8),	 /*客单价*/
			   gesutpQty   int,		 /*品种数	*/
			   profitRate  NUMERIC(25,8), 	 /*毛利率										 */
               backRate NUMERIC(25,8),		 /*退货率*/
               SaleUpRate NUMERIC(25,8),     /*增长率*/
               GrowthRate NUMERIC(25,8),     /*成长率*/
			   centiareRate NUMERIC(25,8),	 /*商品面积分析度*/
			   PerSaleRate  NUMERIC(25,8),	 /*商品人均销售比*/
			   PerProlificacy NUMERIC(25,8), /*商品人均生产力*/
			   iniQty     NUMERIC(25,8),    /*各门店期初库存*/
			   beginQty   NUMERIC(25,8),    /*期初库存*/
			   OverQty    NUMERIC(25,8),    /*期末库存*/
			   CrossRate  NUMERIC(25,8),	/*交叉比*/
			   PClassRate NUMERIC(25,8), 	/*商品机构构成比*/
			   AreaUseRate NUMERIC(25,8),   /*销售卖场使用率*/
			   FieldingRate NUMERIC(25,8),  /*卖场人员守备率*/
			   saleGrowthRate NUMERIC(25,8), /*销售营业成长率*/
			   profitGrowthRate NUMERIC(25,8),  /*销售毛利成长率     	                                                                                                        */
			   Empcount  int,    /*员工数*/
			   SumTotal  NUMERIC(25,8),   /*按期合计*/
			   total     NUMERIC(25,8),    /*不含税金额*/
			   costtaxtotal NUMERIC(25,8)  /*含税成本金额*/
              )  

declare @nMinDateid int, @nMaxDateid int, @splitBegindate datetime,  @splitEnddate datetime, @nDateid int

 
if @dateMode = 1 goto repMonth    /*按月查询*/
if @dateMode = 2 goto repquarter  /*按季度查询*/
if @dateMode = 3 goto repYear     /*按年查询*/

repMonth:
/*取月begindate*/

set @begindate = DATEADD(MM, -1, @begindate)

insert into #SplitDate(begindate)
   select    
     dateadd(mm,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(mm,number,@begindate)<=@enddate
/*计算其他时间列     */
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+cast(DATEPART(MM, begindate) as varchar(2))+'月',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = DATEPART(MM, begindate)
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1
  goto rep

repquarter:
/*取季度begindate*/
set @begindate = DATEADD(QQ, -1, @begindate) /*需要计算到选择时间段的上一期*/

insert into #SplitDate(begindate)
   select    
     dateadd(QQ,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(QQ,number,@begindate)<=@enddate
/*计算其他时间列*/
	update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+ cast(DATEPART(QQ, begindate) as varchar(2))+'季度',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = 0	
	update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
	select @nMaxDateid = MAX(dateid) from #splitDate
    update #splitDate set enddate = @enddate where dateid = @nMaxDateid
    update #splitDate set daycount = cast((enddate - begindate) as Int)+1 	
    
  goto rep

repYear:
  /*取年begindate*/

set @begindate = DATEADD(YYYY, -1, @begindate) /*需要计算到选择时间段的上一期*/
  
insert into #SplitDate(begindate)
   select    
     dateadd(YYYY,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(YYYY,number,@begindate)<=@enddate
/*计算其他时间列*/
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年',
						yyyy = DATEPART(YYYY, begindate), qqq = 0, mm=0	
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1										
  
  goto rep
  
  
rep:
      /*初始化#qrSale01表*/
  insert into #qrSale01(dateid, y_id)
     select sp.dateid, y.company_id from #splitDate sp
     cross join company y 
     where y.child_number = 0 and y.company_id > 1 and y.deleted = 0
            
 
  /*销售数量   --销售金额  --退货数量  --退货金额  --销售成本金额*/
          
  update s1 set s1.SaleQty = t1.SaleQty, s1.Saletotal = t1.Saletotal, 
				 s1.BackQty = t1.backQty, s1.BackTotal = t1.backTotal,
				 s1.costtotal=t1.costtotal,s1.total=t1.total,s1.costtaxtotal=t1.costtaxtotal      
    from  #qrSale01 s1,  
         (select sp.dateid, bi.Y_ID, 
					 sum(case  when bi.billtype in(10, 12) then mx.quantity else 0 end) as SaleQty, 
                     sum(case  when bi.billtype in(10, 12) then mx.taxtotal else 0  end) as Saletotal,
                     sum(case  when bi.billtype in(10, 12) then mx.costtaxtotal else 0  end) as costtaxtotal,
                     sum(case  when bi.billtype in(10, 12) then mx.total else 0  end) as total,
                     sum(case  when bi.billtype in(10, 12) then mx.costprice*mx.quantity else 0  end) as costtotal,
                     sum(case  when bi.billtype in(11, 13) then mx.quantity else 0 end) as backQty, 
                     sum(case  when bi.billtype in(11, 13) then mx.taxtotal else 0  end) as backTotal                        
       from billidx bi
       inner join salemanagebill mx on bi.billid = mx.bill_id 
       left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate
       where bi.billtype in (10,11,12,13) and bi.billstates = 0 and bi.billdate between @begindate and @enddate 
             and mx.AOID = 0 and mx.p_id > 0
       group by sp.dateid, bi.Y_ID) t1
    where s1.dateid = t1.dateid and s1.y_id = t1.Y_ID  
                
    
   /*来客数  品种数   */
   update s1 set gesutpQty = t1.pqty, geustCount = geustCount
    from  #qrSale01 s1,  
         (select sp.dateid, bi.Y_ID, 
					 COUNT(p_id) as pqty, COUNT(bill_id) as guestCount
       from billidx bi
       inner join salemanagebill mx on bi.billid = mx.bill_id 
       left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate
       where bi.billtype in (10,11,12,13) and bi.billstates = 0 and bi.billdate between @begindate and @enddate 
             and mx.AOID = 0 and mx.p_id > 0
       group by sp.dateid, bi.Y_ID) t1
    where s1.dateid = t1.dateid and s1.y_id = t1.Y_ID     
     
   
   /*清除null 避免计算出错   */
   update #qrSale01 set SaleQty = 0			where SaleQty is null
   update #qrSale01 set Saletotal = 0		where Saletotal is null
   update #qrSale01 set total = 0	     	where total is null
   update #qrSale01 set BackQty = 0			where BackQty is null
   update #qrSale01 set BackTotal = 0		where BackTotal is null					   					          
   update #qrSale01 set costtotal = 0		where costtotal is null
   update #qrSale01 set gesutpQty = 0		where gesutpQty is null
   update #qrSale01 set geustCount = 0		where geustCount is null        
   update #qrSale01 set costtaxtotal = 0    where costtaxtotal is null   
   update #qrSale01 set GrowthRate = 0		where GrowthRate is null  	   					   					          					   					             
    /*客单价 */
   update #qrSale01 set gesutPrice = Saletotal/geustCount where  geustCount <> 0   
   
   /*毛利   毛利率*/
   update #qrSale01 set profit = Saletotal - costtaxtotal
   update #qrSale01 set profitRate = profit/Saletotal*100 where Saletotal <> 0            
     
/*销售退货率	退货总数量/采购总数量 分母为0返回空     */
   update #qrSale01 set backRate = BackQty/SaleQty*100 where SaleQty <> 0
   
/*销售增长率	(本期采购额-上期采购额)/上期采购额*/


  /*成长率*/
     update q1 set GrowthRate = (q1.Saletotal-q2.Saletotal)/q2.Saletotal*100 
       from #qrSale01 q1, #qrSale01 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.y_id=q2.y_id
  /*员工数*/
     update s1 set empcount = t1.empcount
        from #qrSale01 s1, 
             (select Y_ID, COUNT(emp_id) as empcount 
               from employees 
               where child_number =0 and deleted = 0
               group by y_id) t1
        where s1.y_id = t1.Y_ID                              
       
  /*商品面积分析度*/
      update s1 set centiareRate = s1.Saletotal/t1.centiare
        from #qrSale01 s1, 
             company t1
        where s1.y_id = t1.company_id and t1.centiare <> 0                              
      
  /*商品人均销售比*/
      update #qrSale01 set empcount = 0 where Empcount is null
      update #qrsale01 set PerSaleRate = Saletotal/empcount where Empcount <> 0            
  /*商品人均生产力*/
      update #qrSale01 set profit = 0 where profit is null
      update #qrSale01 set PerProlificacy = profit/Empcount where Empcount <> 0     
      
  /*计算所有期初， 本期期初库存、本期期末库存*/
    update s1 set iniQty = t1.quantity
        from #qrSale01 s1,             
			  (select Y_ID, sum(quantity) quantity
				  from 
				  storehouseini
				  group by Y_ID
			   ) t1
	    where s1.y_id = t1.Y_ID
    
  
    update s1 set beginQty = t1.beginQty
        from #qrSale01 s1,             
			  (select sp.dateid, pd.Y_ID, sum(pd.quantity) as beginQty
				  from 
				  billidx bi
				  inner join productdetail pd on bi.billid = pd.billid
				  left join  #splitDate sp on bi.billdate < sp.begindate      
				  group by sp.dateid, pd.Y_ID
			   ) t1
	    where s1.dateid =t1.dateid and s1.y_id = t1.Y_ID
	   
	 update s1 set OverQty = t1.OverQty
        from #qrSale01 s1,             
			  (select sp.dateid, pd.Y_ID, sum(pd.quantity) as OverQty
				  from 
				  billidx bi
				  inner join productdetail pd on bi.billid = pd.billid
				  left join  #splitDate sp on bi.billdate < (sp.enddate + 1)      
				  group by sp.dateid, pd.Y_ID
			   ) t1
	    where s1.dateid =t1.dateid and s1.y_id = t1.Y_ID  		   			   	  		                       		   			   	  		                        
  /*交叉比*/
      update #qrSale01 set iniQty = 0 where iniQty is null
      update #qrSale01 set beginQty = 0 where beginQty is null
      update #qrSale01 set OverQty = 0 where OverQty is null
      update #qrSale01 set profitRate = 0 where profitRate is null
            
      update #qrSale01 set beginQty = iniQty +beginQty, OverQty = iniQty + OverQty
      update #qrSale01 set CrossRate = profitRate*(SaleQty/(beginQty+OverQty)/2) where beginQty+OverQty <> 0                 	  	
  
  /*商品机构构成比*/
    update q1 set q1.sumtotal = q2.sumtotal 
      from #qrSale01 q1,
            (select dateid, SUM(Saletotal) sumtotal
              from #qrSale01
              group by dateid)q2 
       where q1.dateid = q2.dateid     
    update #qrSale01 set sumtotal = 0 where SumTotal is null    
    update #qrSale01 set pclassrate=Saletotal/SumTotal*100 where SumTotal <> 0    
                    
  /*销售卖场使用率*/

    select @sumArea =  isnull(SUM(centiare), 0) from company 
    if @sumArea <> 0
    update q1 set AreaUseRate =  y.centiare/@sumArea*100
      from #qrSale01 q1,
           company y
      where q1.y_id = y.company_id 
                                      
  /*卖场人员守备率*/
    update q1 set FieldingRate =  y.centiare/q1.Empcount*100
      from #qrSale01 q1,
           company y
      where q1.y_id = y.company_id and q1.Empcount <>0    
  /*销售营业成长率*/
     update q1 set saleGrowthRate = q1.Saletotal/q2.Saletotal*100 
       from #qrSale01 q1, #qrSale01 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0  and q1.y_id=q2.y_id          
  /*销售毛利成长率*/
     update q1 set profitGrowthRate = q1.profit/q2.profit*100 
       from #qrSale01 q1, #qrSale01 q2   
     where q1.dateid = q2.dateid + 1 and q2.profit <> 0   and q1.y_id=q2.y_id                                                               								                  
   
  goto  repend


repend:
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int     
   
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'
               
   select @nMinDateid = MIN(dateid)  from #SplitDate
      
   select  /*b.dateid,  b.y_id, */
		   dbo.DecimalQrValue(@nSL, b.SaleQty) SaleQty,  dbo.DecimalQrValue(@ntotal,b.Saletotal) Saletotal,  
		   dbo.DecimalQrValue(@ntotal,b.total) total,
		   dbo.DecimalQrValue(@ntotal,b.costtaxtotal) CostTaxTotal,
		   /*dbo.DecimalQrValue(@nSL,b.BackQty) BackQty,  */
		   /*dbo.DecimalQrValue(@ntotal,b.BackTotal) BackTotal,  dbo.DecimalQrValue(@ntotal,b.costtotal) costtotal,  */
		   dbo.DecimalQrValue(@ntotal,b.profit) profit,  b.geustCount,  
		   dbo.DecimalQrValue(@nDJ,b.gesutPrice) gesutPrice, b.gesutpQty,  dbo.DecimalQrValue(@nOther,b.profitRate) profitRate,  dbo.DecimalQrValue(@nOther,b.backRate) backRate,	
		   dbo.DecimalQrValue(@nOther,b.SaleUpRate) SaleUpRate,   dbo.DecimalQrValue(@nOther,b.GrowthRate) GrowthRate, dbo.DecimalQrValue(@nOther,b.centiareRate) centiareRate,  dbo.DecimalQrValue(@nOther,b.PerSaleRate) PerSaleRate,  
		   dbo.DecimalQrValue(@ntotal,b.PerProlificacy) PerProlificacy,  
		   /*dbo.DecimalQrValue(@nSL,b.iniQty) iniQty, dbo.DecimalQrValue(@nSL,b.beginQty) beginQty, dbo.DecimalQrValue(@nSL,b.OverQty) OverQty, */
		   dbo.DecimalQrValue(@nOther,b.CrossRate) CrossRate,  dbo.DecimalQrValue(@nOther,b.PClassRate) PClassRate,  dbo.DecimalQrValue(@nOther,b.AreaUseRate) AreaUseRate,  dbo.DecimalQrValue(@nOther,b.FieldingRate) FieldingRate,
		   dbo.DecimalQrValue(@nOther,b.saleGrowthRate) saleGrowthRate, dbo.DecimalQrValue(@nOther,b.profitGrowthRate) profitGrowthRate,  
		   /*b.Empcount,   dbo.DecimalQrValue(@nTotal,b.SumTotal) SumTotal,*/
		   sd.FlagName, 
		   /*sd.yyyy, sd.qqq, sd.mm, sd.begindate, sd.enddate, sd.daycount,*/
          y.name  as yname        
     from  #qrSale01 b 
     left join #SplitDate sd on b.dateid = sd.dateid 
     left join company y on b.y_id = y.company_id 
     where sd.dateid >  @nMinDateid
     order by sd.mm, y.class_id            
   return 0
GO
