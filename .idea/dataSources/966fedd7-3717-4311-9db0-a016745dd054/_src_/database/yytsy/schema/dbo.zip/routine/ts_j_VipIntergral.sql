
CREATE  procedure ts_j_VipIntergral
(
	@nBillId int,
	@nbilltype int 
)
/*with encryption*/
as
set nocount on

/*declare @nbillID numeric(10,0)*/


declare @isbank int,@isIntergral int,@Vipcardid int
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
declare @saleIntegralYE NUMERIC(25,8)
declare @money NUMERIC(25,8)
declare @ctid int
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8)
declare @saleIntegral NUMERIC(25,8),@salemoney NUMERIC(25,8)
declare @RemainderMoney NUMERIC(25,8)
declare @INTEGRALMONEY NUMERIC(25,8)
declare @Intergral NUMERIC(25,8)
declare @isSpecialPriceIntegral int,@isPromotionIntegral int,@isYeIntegral int, @PriceType int
declare @StoreMoney_ID int
declare @billguid varchar(40), @y_id int
select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/
select @billguid = guid, @Y_id = Y_ID from billidx where billid = @nBillId 

if @nbilltype in (12,13)
begin
      select @ctid=v.ct_id,@money=v.RemainderMoney,@salemoney=b.ssmoney,@Vipcardid=v.Vipcardid,@isbank=v.isbank,
             @isSpecialPriceIntegral=isSpecialPriceIntegral,@isPromotionIntegral=isPromotionIntegral,@isYeIntegral=isYeIntegral,
             /*特殊商品参与积分                              促销商品参与积分                           是否统计积分余额      */
             @order=b.billnumber,@isIntergral=V.isIntegral,@INTEGRALMONEY=v.INTEGRALMONEY,@Intergral=v.Integral
             from billidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid

      select @RemainderMoney=abs(isnull(sum(total),0)) from salemanageBill where bill_id=@nBillId and p_id=-@StoreMoney_ID 

      if @isIntergral=1 and @Vipcardid>0
      begin 
        select   @saleIntegral=0 ,   @saleIntegralYE=0

        declare saleIntegral cursor 
        for select PClass_ID,sum(totalmoney)totalmoney,PriceType from vw_c_salemb where bill_id=@nBillId and p_id>0 Group by Pclass_id,PriceType
        open saleIntegral
        fetch next from saleIntegral into @Pclassid,@totalmoney,@PriceType
        while @@fetch_status=0
        begin
           if (@PriceType=7 and  @isSpecialPriceIntegral=0)
           begin
              SELECT  @SALEINTEGRAL=ISNULL(@SALEINTEGRAL,0)+0 
              SELECT  @SALEINTEGRALYE=ISNULL(@SALEINTEGRALYE,0)+0
           end           
           else
           begin
               exec TS_L_CTIntegralANDDiscountOther @ctid,0,@Pclassid,@CTIntegral out
           
               if @CTintegral<=0
               begin
	          select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@INTEGRALMONEY) as int) 
	          select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@INTEGRALMONEY as int)*@INTEGRALMONEY)
               end
               else
               begin	
	          select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@CTintegral) as int) 
	          
                  if @isPromotionIntegral=1
                    select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@CTintegral as int)*@CTintegral)
                  else
                    select  @saleIntegralYE=isnull(@saleIntegralYE,0)+0

               end
           end
           fetch next from saleIntegral into @Pclassid,@totalmoney,@PriceType
        end
        close saleIntegral
        DEALLOCATE  saleIntegral
     end
end



if @nbilltype in (12) and @Vipcardid>0
begin
    if @isIntergral=1
    begin
       if @isYeIntegral=0
       begin
         /*update  Vipcard set Integral=Integral+@saleIntegral  where VipCardid=@Vipcardid*/
	 if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
	   update  VIPIntergral set Integral=Integral+@saleIntegral  where VipCardid=@Vipcardid and billid = @nbillid
         else
           insert into VIPIntergral(billid,billtype, vipcardid, ct_id, integral, billguid, y_id) 
                values(@nBillId, @nBilltype, @Vipcardid, @ctid, @saleIntegral, @billguid,@y_id)
         select @nowIntergral=@Intergral+@saleIntegral,@modIntergral=@saleIntegral
       end
       else
       begin 
         /*update  Vipcard set Integral=Integral+@saleIntegral,IntergralYE=IntergralYE+@saleIntegralYE where VipCardid=@Vipcardid*/
         if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
	    update  VIPIntergral set Integral=Integral+@saleIntegral,IntergralYE=IntergralYE+@saleIntegralYE where VipCardid=@Vipcardid and billid = @nbillid
         else 
            insert into VIPIntergral(billid,billtype, vipcardid, ct_id, integral, IntergralYE, billguid, y_id) 
                values(@nBillId, @nBilltype, @Vipcardid, @ctid, @saleIntegral, @saleIntegralYE,@billguid, @y_id)

         select @IntegralYE=IntergralYE from Vipcard where Vipcardid=@Vipcardid                              

         if cast((@IntegralYE/@INTEGRALMONEY) as int)>0  
         begin 
           /*update Vipcard set Integral=Integral+cast((@IntegralYE/@INTEGRALMONEY) as int),IntergralYE=(@IntegralYE-cast(@IntegralYE/@INTEGRALMONEY as int)*@INTEGRALMONEY) where Vipcardid=@Vipcardid*/
           if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
	     update VIPIntergral set Integral=Integral+cast((@IntegralYE/@INTEGRALMONEY) as int),IntergralYE=(@IntegralYE-cast(@IntegralYE/@INTEGRALMONEY as int)*@INTEGRALMONEY) where Vipcardid=@Vipcardid and billid = @nbillid
           else
             insert into VIPIntergral(billid,billtype, vipcardid, ct_id, integral, IntergralYE, billguid,y_id) 
               values(@nBillId, @nBilltype, @Vipcardid, @ctid, cast((@IntegralYE/@INTEGRALMONEY) as int), (@IntegralYE-cast(@IntegralYE/@INTEGRALMONEY as int)*@INTEGRALMONEY), @billguid, @y_id)
           select @nowIntergral=Integral from Vipcard where VipCardid=@Vipcardid
           select @modIntergral=@saleIntegral+cast((@IntegralYE/@INTEGRALMONEY) as int)
         end
         else
         begin
           select @nowIntergral=@Intergral+@saleIntegral,@modIntergral=@saleIntegral/*更新会员卡日志用  */
         end
       end
    end
    else
    begin  
      select @nowIntergral=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modIntergral=0
    end

    if (@isbank=1) 
    begin
      /*update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid*/
      if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
        update VIPIntergral set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid and billid = @nbillid
      else
        insert into VIPIntergral(billid,billtype, vipcardid, ct_id, RemainderMoney, billguid, y_id) 
           values (@nBillId, @nBilltype, @Vipcardid, @ctid, -@RemainderMoney, @billguid, @y_id)  
      select @nowmoney=@money-@RemainderMoney,@modmoney=-@RemainderMoney
    end
    else
    begin
      select @nowmoney=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modmoney=0
    end  

    if (@isbank=1) or (@isIntergral=1)
    begin
      /*update Vipcard set TotalBuyMoney=TotalBuyMoney+@salemoney,BuyCount=BuyCount+1 where Vipcardid=@Vipcardid */
      if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
	update VIPIntergral set TotalBuyMoney=TotalBuyMoney+@salemoney,BuyCount=BuyCount+1 where Vipcardid=@Vipcardid  and billid = @nbillid
      else
        insert into VIPIntergral(billid,billtype, vipcardid, ct_id, TotalBuyMoney, BuyCount,billguid, y_id) 
           values (@nBillId, @nBilltype, @Vipcardid, @ctid,@salemoney, 1, @billguid, @y_id)  
    end
    select @ntag=15
    select @comment='零售单：【'+@order+'】'

    exec ts_SetSysValue 'VIPIntegral',@modIntergral,@Y_id/*在sys中记录本次消费积分，在打印小票的时候取出。*/
end

if @nbilltype in (13) and @Vipcardid>0
begin

	if @isIntergral=1
	begin
	  if @isYeIntegral=0 
          begin
            /*update  Vipcard set Integral=Integral-@saleIntegral where VipCardid=@Vipcardid*/
	    if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
              update  VIPIntergral set Integral=Integral-@saleIntegral where VipCardid=@Vipcardid and billid = @nbillid
            else         
	      insert into VIPIntergral(billid,billtype, vipcardid, ct_id, Integral, billguid, y_id) 
                values (@nBillId, @nBilltype, @Vipcardid, @ctid,-@saleIntegral, @billguid, @y_id)  
          end 
          else begin          
            /*update  Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid*/
            if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
              update  VIPIntergral set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid and billid = @nbillid
            else
	      insert into VIPIntergral(billid,billtype, vipcardid, ct_id, Integral, IntergralYE, billguid, y_id) 
                values (@nBillId, @nBilltype, @Vipcardid, @ctid,-@saleIntegral, -@saleIntegralYE, @billguid, @y_id)  
          end
          select @nowIntergral=@Intergral-@saleIntegral,@modIntergral=@saleIntegral

          select @IntegralYE=IntergralYE from Vipcard where Vipcardid=@Vipcardid       

          if @IntegralYE<0
          begin
            select @OrverYE=@IntegralYE

            while @IntegralYE<0 
            begin
              select @IntegralYE=@IntegralYE+@INTEGRALMONEY
              select @OrverIntegral=isnull(@OrverIntegral,0)+1
            end

            /*update Vipcard set Integral=Integral-@OrverIntegral,IntergralYE=@OrverYE+@INTEGRALMONEY*@OrverIntegral where Vipcardid=@Vipcardid*/
           if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
             update VIPIntergral set Integral=Integral-@OrverIntegral,IntergralYE=@OrverYE+@INTEGRALMONEY*@OrverIntegral where Vipcardid=@Vipcardid and billid = @nbillid
           else
             insert into VIPIntergral(billid,billtype, vipcardid, ct_id, Integral, IntergralYE, billguid, y_id) 
                values (@nBillId, @nBilltype, @Vipcardid, @ctid,-@OrverIntegral, @OrverYE+@INTEGRALMONEY*@OrverIntegral, @billguid, @y_id)

            select @nowIntergral=@nowIntergral-@OrverIntegral,@modIntergral=@modIntergral+@OrverIntegral
          end
          select @modIntergral=-@modIntergral
	end
	else 
	begin
	  select @nowIntergral=0/* from Vipcard where Vipcardid=@Vipcardid*/
	  select @modIntergral=0
	end
	
	if (@isbank=1)   
	begin
          if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
            update VIPIntergral set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid and billid = @nbillid 
          else
            insert into VIPIntergral(billid,billtype, vipcardid, ct_id, RemainderMoney, billguid, y_id) 
                values (@nBillId, @nBilltype, @Vipcardid, @ctid, @RemainderMoney, @billguid, @y_id) 
	  /*update Vipcard set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid*/
	  select @nowmoney=@money+@RemainderMoney,@modmoney=@RemainderMoney
	end
	else
	begin
	  select @nowmoney=0 /*from vipcard where vipcardid=@Vipcardid*/
	  select @modmoney=0
	end
	
	if (@isbank=1) or (@isIntergral=1) 
        begin
          if exists(select * from VIPIntergral where billid = @nbillid and vipcardid =@Vipcardid)
            update VIPIntergral set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1  where Vipcardid=@Vipcardid and billid = @nbillid
          else
            insert into VIPIntergral(billid,billtype, vipcardid, ct_id, TotalBuyMoney, BuyCount, billguid, y_id) 
                values (@nBillId, @nBilltype, @Vipcardid, @ctid, -@salemoney, -1, @billguid, @y_id)  
	  /*update Vipcard set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1  where Vipcardid=@Vipcardid*/
	end
        select @ntag=16 
	select @comment='零售退货单：【'+@order+'】'

end



if  @Vipcardid>0
  exec TS_L_InsVIPCardLog @ntag,'','',@Vipcardid,@nowIntergral,@modIntergral,@nowmoney,@modmoney,0,@comment 

return 0

SET QUOTED_IDENTIFIER ON
GO
