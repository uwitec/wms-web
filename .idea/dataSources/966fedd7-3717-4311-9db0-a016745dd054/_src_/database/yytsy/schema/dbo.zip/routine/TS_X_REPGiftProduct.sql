
/* 查看赠品数量
  xxx 2015-02-09
*/

create procedure TS_X_REPGiftProduct
( @nmode int = 0,				/*0表示是查询总量，1表示查询单品明细*/
  @szbegindate varchar(20),  /*开始时间*/
  @szenddate varchar(20),	/*结束时间*/
  @p_id int,				/*商品id*/
  @OperatorID int              /*操作员id*/
)

as
begin

if @nmode = 0
  begin
	select name as pname,p.alias,p.standard,gp.p_id,gp.AOID,ISNULL(gp.QTY,0) as qty,isnull(ps.SENDQTY,0) as SendQTY,
			(ISNULL(gp.QTY,0) - isnull(ps.SENDQTY,0)) as syQty,
		 Case when gp.AOID = 7 then '有成本赠品' when gp.AOID = 6 then  '零成本赠品' end as Aotype from 
	 (select p_id,AOID,SUM(QTY) as QTY from giftProducts 
		  where left(convert(varchar(60),insertTime,21),10) between @szbegindate and @szenddate
		  and (p_id = @p_id or @p_id = 0)
		  group by p_id,AOID
	 ) gp
	 full outer join (
 		SELECT YPD.p_id,YPD.AOID,
				ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (53,150,152)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0) AS [SENDQTY]
				/*ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (54,151,153)  THEN YPD.[SENDCOSTTOTAL]  ELSE -YPD.[SENDCOSTTOTAL] END),0) AS [SENDCOSTTOTAL],*/
				/*ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (54,151,153)  THEN YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY  ELSE -YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY END),0) AS [SENDTOTAL],*/
				/*ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (54,151,153)  THEN YPD.[QUANTITY]*YPD.[COSTPRICE]  ELSE -YPD.[QUANTITY]*YPD.[COSTPRICE] END), 0) AS [COSTTOTAL]*/
		   FROM  
			 (SELECT b.billid,sm.p_id,sm.quantity,costprice,totalmoney,taxtotal,
					 sm.SendQTY,sm.SendCostTotal,B.billtype,AOID  
				FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数                 */
				LEFT JOIN billidx   b  on sm.bill_id=b.billid
				LEFT JOIN Products  p  on p.product_id=SM.p_id           
				WHERE ([Billdate] BETWEEN   @szbegindate AND  @szenddate) and 
					  B.[billtype] IN (53,54,150,151,152,153) and
					  [Billstates]=0 AND aoid in (6,7) and p_id>0 
					  and (@p_id = 0 or p_id= @p_id)
					 /* and b.Y_ID = 2*/
			 )YPD
			 group by YPD.p_id,YPD.AOID
	 ) as ps on gp.p_id = ps.p_id and gp.AOID = ps.AOID
	 left join products p on gp.p_id = p.product_id
  end
  
else if @nmode = 1
  begin
	select insertTime,P.name AS pname,p.alias,p.standard,e.name as ename,emp_id as inputman,ps.p_id,ps.AOID,ISNULL(ps.QTY,0) as qty,
		 Case when ps.AOID = 7 then '有成本赠品' when ps.AOID = 6 then  '零成本赠品' end as Aotype,Typename from 
	 (select insertTime ,p_id,AOID,inputMan,convert(NUMERIC(25,8),SUM(QTY)) as QTY, '赠品录入' as Typename from giftProducts 
		  where left(convert(varchar(60),insertTime,21),10) between @szbegindate and @szenddate
		  and (p_id = @p_id or @p_id = 0)
		  group by p_id,AOID,insertTime,inputMan
	 union all
 		SELECT YPD.billdate as insertTime,YPD.p_id,YPD.AOID,YPD.e_id AS inputMan,
				ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (53,150,152)  THEN -YPD.[SENDQTY]  ELSE  YPD.[SENDQTY]  END), 0) AS QTY,
			    YPD.Comment as Typename
		   FROM  
			 (SELECT b.billid,sm.p_id,sm.quantity,costprice,totalmoney,taxtotal,
					 sm.SendQTY,sm.SendCostTotal,B.billtype,AOID,b.billdate,b.e_id,v.Comment  
				FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数                  */
				LEFT JOIN billidx   b  on sm.bill_id=b.billid
				LEFT JOIN Products  p  on p.product_id=SM.p_id 
				LEFT JOIN VchType  V  on b.billtype = v.Vch_ID          
				WHERE ([Billdate] BETWEEN   @szbegindate  AND  @szenddate) and 
					  B.[billtype] IN (53,54,150,151,152,153) and
					  [Billstates]=0 AND aoid in (6,7) and p_id>0 
					  and (@p_id = 0 or p_id= @p_id)
					 /* and b.Y_ID = 2*/
			 )YPD
			 group by YPD.p_id,YPD.AOID,YPD.billdate,YPD.e_id,YPD.Comment
	 ) as ps
	 left join products p on ps.p_id = p.product_id
	 left join employees e on ps.inputMan = e.emp_id
  end

end
GO
