

CREATE   PROCEDURE ts_c_UPBillAuditA 
(
	@nBillId int,
	@nReturnNumber int output
)

AS

	declare @nA_id int,@nC_id int,@nE_id int,@dTotal NUMERIC(25,8),@nBillType int,@szPeriod varchar(2)
	declare 
		@ArTotal_Id 		int,				/*9	『应收款合计』*/
		@ApTotal_Id 		int,					/*15	『应付帐款合计』*/
		@nY_ID			int				/*机构ID*/
	select	@ArTotal_Id		=9			/*9	『应收款合计』*/
	select	@ApTotal_Id		=15			/*15	『应付帐款合计』*/
		
	select @nY_ID=Y_ID,@nA_id = a_id,@nC_id = c_id,@dTotal =jdmoney,@nBillType =billtype,@nE_id =e_id
	from accountdetailUPtmp p where p.billid=@nBillId 

    exec ts_c_ModifyA @nBillType,@nA_id,@nC_id,@nE_id,'',@dTotal,@nReturnNumber output,@nY_ID
	if @nReturnNumber<>0 
	goto error
	    
	return 0

error:
	return -1
GO
