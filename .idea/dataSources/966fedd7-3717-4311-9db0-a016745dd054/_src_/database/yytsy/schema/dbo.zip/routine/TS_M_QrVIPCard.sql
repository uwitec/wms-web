
CREATE PROCEDURE TS_M_QrVIPCard
  @CardNo  	varchar(20) ='',
  @SqlWhere     varchar(500) =''
/*with encryption*/
AS
/*Params Ini begin*/
if @CardNo is null  SET @CardNo = ''
if @SqlWhere is null  SET @SqlWhere = ''
/*Params Ini end*/

DECLARE @SQL varchar(8000)

SET @SQL='SELECT * FROM vw_M_VipCard  '
	+'    WHERE CardNo = ' + CHAR(39) + @CardNo + CHAR(39)
        + @SqlWhere



/*PRINT(@SQL)*/
EXEC (@SQL)
GO
