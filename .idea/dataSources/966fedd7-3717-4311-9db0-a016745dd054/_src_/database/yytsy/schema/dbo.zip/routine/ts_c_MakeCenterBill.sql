

create proc ts_c_MakeCenterBill
(
	@nPosid    		int=0/*机构id号  zjilin 2009-04-19修改,处理分公司业务*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @nPosid is null  SET @nPosid = 0
/*Params Ini end*/
set nocount on

declare @posguid varchar(50),@billid int,@posid int,@s_id int

truncate table billdtsidx
truncate table tranmanagebilldts
truncate table storemanagebilldts
truncate table salemanagebilldts
truncate table priceidxdts
truncate table pricebilldts
truncate table cxidxdts
truncate table cxbilldts
truncate table tasklistdts

if @nPosid<>0
begin
	select @posguid=guid from replicationauthorize where posid=@nposid
	if @posguid is null 
	begin	
		raiserror('机构没有授权，添加任务失败！',16,1)
		return -1
	end
end

update tasklist set tranflag = 2 where billtype in (150, 152) and tranflag = 1 and DY_ID not in(select posid from ReplicationAuthorize) 

begin tran CreateCenterBill

if @nPosid=0 /*总部传盘方式*/
begin
	if exists(select billid from tasklist where tranflag=1 and billtype in (150,152))/*公司发货单*/
	begin
		/*索引    select * from billidx  select * from salemanagebill  */
		insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty)
		select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty
			from billidx where billid in (select distinct billid from tasklist where tranflag=1 and billtype in (150, 152)) and billstates = 0
		/*发货单*/
	
		insert into Salemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,thqty,newprice,orgbillid,aoid,RowGuid,YCostPrice,YGUID,Y_ID, instoretime,batchbarcode,scomment,batchprice)
		select smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag ,thqty,newprice,0,aoid,RowGuid,YCostPrice,YGUID,Y_ID, instoretime,batchbarcode,scomment,batchprice
		from Salemanagebill where bill_id in (select billid from billdtsidx where billtype in (150, 152))
		order by smb_id

		
		declare posguidcur cursor for
		select billid,DY_ID from tasklist 
		where tranflag=1 and billtype in (150, 152) and dy_id > 0

		open posguidcur

		fetch next from  posguidcur into @billid,@posid
		while @@fetch_status=0
		begin
			select @posguid=null
			select @posguid=guid from replicationauthorize where posid=@posid
			if @posguid is null goto error
			update billdtsidx set posguid=@posguid where billid=@billid and billtype in (150,152)
			fetch next from  posguidcur into @billid,@posid
		end
		close posguidcur
		deallocate posguidcur
		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (150, 152)
	end

	/*调价通知单*/

	if exists(select billid from tasklist where tranflag=1 and billtype=140)/*调价单据*/
	begin
		/*索引*/
		insert into priceidxdts(billid,billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid, Y_ID)
		select billid,billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid,Y_ID
 			from priceidx where billid in (select distinct billid from tasklist where tranflag=1 and billtype in (140)) and billstates = 3
		/*调价单*/
		insert into pricebilldts([id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,y_id,oldretailprice)
		select [id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,Y_Id,oldretailprice
		from pricebill where bill_id in (select billid from priceidxdts where billtype in(140))
		order by [id]

		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (140)
	end
	
	/*促销类单据180,181,182,183*/
	if exists(select billid from tasklist where tranflag=1 and billtype in (180,181,182,183) and billstates = 3)/*促销单据*/
	begin
	  insert into cxidxdts(billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid)
		select billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid
 			from cxidx where billid in (select billid from tasklist where tranflag=1 and billtype in (180,181,182,183) and  billstates = 3) and billstates = 3

     insert into cxbilldts(smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment)
		select smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment
		  from CxBill where Bill_ID in (select billid from cxidxdts)			   				   			
 					
      declare posguidcur cursor for
		select billid,DY_ID from tasklist 
		where tranflag=1 and billtype in (180, 181, 182, 183) and billstates = 3 and dy_id > 0

		open posguidcur

		fetch next from  posguidcur into @billid,@posid
		while @@fetch_status=0
		begin
			select @posguid=null
			if @posid > 0
			begin
			  select @posguid=guid from replicationauthorize where posid=@posid
			  if @posguid is not null
			  update cxidxdts set posguid=@posguid where billid=@billid
			end 	
			fetch next from  posguidcur into @billid,@posid
		end
		close posguidcur
		deallocate posguidcur
		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (180, 181, 182, 183) and billstates = 3
	end
	/*离线方式处理促销停用*/
	/*if exists(select billid from tasklist where tranflag <> 3 and billtype in (180,181,182,183) and billstates = 5 and tranType = 0)--停用促销*/
	/*begin*/
	/*  insert into tasklistDts(tsid, billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates)*/
	/*    select tsid, billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates */
	/*      from  tasklist*/
	/*      where tranflag <> 3 and billtype in (180,181,182,183) and billstates = 5 and tranType = 0*/
	/*  update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (180, 181, 182, 183) and billstates = 5 and tranType = 0    */
    /*end 	*/
end

if @nPosid<>0 /*远程登录     select * FROM TASKLIST*/
begin
	if exists(select billid from tasklist where tranflag=1 and billtype in (150, 152) and DY_id=@nposid)/*发货单*/
	begin
		/*索引*/
		insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty)
		select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,SendQty,Y_ID,begindate,Enddate,WholeQty,PartQty
			from billidx where billid in (select distinct billid from tasklist where tranflag=1 and billtype in (150, 152) and DY_ID=@nPosid) and billstates = 0
		/*发货单 select * from salemanagebill*/
		insert into Salemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,thqty,newprice,orgbillid,aoid,RowGuid,YCostPrice,YGUID,Y_ID,instoretime
			,batchbarcode,scomment,batchprice)
		select smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag ,thqty,newprice,0,aoid,RowGuid,YCostPrice,YGUID,Y_ID,instoretime
			,batchbarcode,scomment,batchprice
		from Salemanagebill where bill_id in (select billid from billdtsidx where billtype in (150, 152) and C_ID=@nPosid)

		declare posguidcur cursor for
		select billid,DY_ID from tasklist 
		where tranflag=1 and billtype in (150, 152) and DY_ID=@nPosid

		open posguidcur

		fetch next from  posguidcur into @billid,@posid
		while @@fetch_status=0
		begin
			select @posguid=null
			select @posguid=isnull(guid,'') from replicationauthorize where posid=@posid
			if @posguid is null goto error
			update billdtsidx set posguid=@posguid where billid=@billid and billtype in (150, 152)
			fetch next from  posguidcur into @billid,@posid
		end
		close posguidcur
		deallocate posguidcur
		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (150, 152) and DY_ID = @nposid 
	end

	/*调价通知单*/
	if exists(select billid from tasklist where tranflag=1 and billtype=140 and (DY_ID in (@nposid,0) or DY_ID in (select company_id from company where superior_id = @nposid)))/*调价单据*/
	begin
		/*索引 select * from pricebill*/
		insert into priceidxdts(billid,billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid,y_id)
		select billid,billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid,y_id
 			from priceidx where billid in (
 			                               select billid from tasklist 
 			                                 where tranflag=1 and billtype in (140) and
 			                                       (DY_ID in (@nposid,0) or DY_ID in (select company_id from company where superior_id = @nposid)) 
 			                               ) and 
 			                    billstates = 3
		/*调价单*/
		insert into pricebilldts([id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,y_id, oldretailprice)
		select [id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,Y_Id,oldretailprice
		from pricebill where bill_id in (select billid from priceidxdts where billtype in(140))
		order by [id]

		update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (140) and (DY_ID = @nposid or DY_ID in (select company_id from company where superior_id = @nposid))
	end
	/**/
		/*促销类单据180,181,182,183*/
	if exists(select billid from tasklist where tranflag=1 and billtype in (180,181,182,183) and billstates = 3 and (DY_ID in (@nposid,0) or DY_ID in (select company_id from company where superior_id = @nposid)))/*调价单据*/
	begin
	  insert into cxidxdts(billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid)
		select billid,billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid
 			from cxidx where billid in (select billid from tasklist 
 			                              where tranflag=1 and billtype in (180,181,182,183) and  billstates = 3  and 
 			                                    (DY_ID in (@nposid,0) or DY_ID in (select company_id from company where superior_id = @nposid))
 			                            ) 
 			                 and billstates = 3

      insert into cxbilldts(smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment)
		select smb_id, bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment
		  from CxBill where Bill_ID in (select billid from cxidxdts)			   				   			
	  update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 
	    where tranflag=1 and billtype in (180, 181, 182, 183) and billstates = 3 and 
	          (DY_ID = @nposid or DY_ID in (select company_id from company where superior_id = @nposid))
	end
	/*在线方式，单独处理促销停用*/
end


commit tran CreateCenterBill
return 0
error:
	close posguidcur
	deallocate posguidcur
	rollback tran CreateCenterBill
	raiserror('机构没有授权，添加任务失败！',16,1)
	return -1
GO
