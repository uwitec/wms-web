
/* 功能：销售决策查询 按商品查询
  
*/

CREATE PROCEDURE TS_J_RepSale03
( 
	@szbegindate varchar(12),   /*开始时间*/
	@szenddate   varchar(12),   /*结束时间*/
	@dateMode  int,		   /*1 月 2 季度 3 年*/
	@cg_id     int = 0,        /*选择类别组*/
	@szID      varchar(3000),  /*类别id*/
	@y_id      int =0,		    /*分支机构id*/
	@p_id      int=0,           /*商品id*/
	@s_id	   int = 0,			/*仓库*/
	@loc_id	   int = 0,			/*货位*/
	@e_id      int = 0,			/*经手人*/
	@c_id	   int = 0,          /*往来单位(客户)*/
	@supplier_id int = 0		/*供应商	*/
)


AS

/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @opendate  datetime    /*开账时间*/
   declare @cgClassid varchar(12)  /*类别组classid*/
   if @szID<>'' 
   begin 
       /*zjx.通过选择自定义类别id的字符串获取class_ID*/
	   select   class_id into #Categoryclassid from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
   end             
   if @szbegindate <> ''
     set @begindate = CAST((@szbegindate+ '-01') as datetime)
     
   if @szenddate <> ''
     set @enddate = CAST((@szenddate+ '-01') as datetime)      
   set @enddate = dateadd(mm,1,@enddate) 
   set @enddate = @enddate -1 
   
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @begindate
   if @begindate <  @OpenDate
     set @begindate = cast((cast(datepart(yyyy, @OpenDate) as varchar(4)) + '-' + cast(datepart(MM, @OpenDate) as varchar(2)) + '-' + '01') as datetime)

/*创建日期分段表，标识，时间跨度*/
/*创建需要查询的商品表，关联了类别组的商品*/
/*创建新品表*/
/*创建返回信息表*/
/*创建表根据类别组取的各级类别名*/
/*计算返回值*/



if OBJECT_ID('tempdb..#SplitDate' ) is not null 
  drop table #SplitDate
create table #splitDate
			 ( dateid int IDENTITY,   /*分隔日期后标识*/
			   FlagName varchar(50),  /*分隔后标识名称，例按年 2013 按月201306 按季度2013二季度*/
			   yyyy     varchar(10),  /*所属于年 */
			   qqq		varchar(10),  /*所属季度			   */
			   mm		varchar(10),  /*所属月			   			   	     */
			   begindate datetime,    /*本段分隔的开始时间*/
			   enddate   datetime,    /*本段分隔的结束时间*/
			   daycount  int		  /*本段分隔的天数统计	  */
			  )  
			  
if OBJECT_ID('tempdb..#QrProducts' ) is not null 
  drop table #QrProducts
create table #QrProducts
 			( p_id int, 			  
 			  billid int,
 			  billtype int,
 			  billdate datetime,
 			  costprice NUMERIC(25,8),
 			  quantity NUMERIC(25,8),
 			  taxprice NUMERIC(25,8),
 			  taxtotal    NUMERIC(25,8), 			 
 			  retailTotal NUMERIC(25,8),
 			  total       NUMERIC(25,8),
 			  costtaxtotal NUMERIC(25,8) 			   			   			   			 
 			 )  
 			 
if OBJECT_ID('tempdb..#QrStoreini' ) is not null 
  drop table #QrStoreini
create table #QrStoreini
 			( p_id int, 			   			  
 			  quantity NUMERIC(25,8) 			  
 			 ) 
 			 
if OBJECT_ID('tempdb..#QrPDetail' ) is not null 
  drop table #QrPDetail
create table #QrPDetail
 			( 
 			  billdate datetime,
 			  p_id int, 			   			  
 			  quantity NUMERIC(25,8) 			  
 			 ) 
 			   			  			  	 			 			  				  			  
			     
if OBJECT_ID('tempdb..#qrSale03' ) is not null 
  drop table #qrSale03
create table #qrSale03
             ( dateid int,
               p_id  int,            /*商品id                                          */
               SaleQty NUMERIC(25,8),		 /*数量*/
               CostTotal NUMERIC(25,8),       /*成本金额*/
               Saletotal NUMERIC(25,8),		 /*销售含税金额               							*/
               BackQty NUMERIC(25,8),        /*退货数量 not show*/
               BackTotal NUMERIC(25,8),      /*退货金额 not show */
			   profit 	 NUMERIC(25,8),		 /*毛利*/
			   profitRate  NUMERIC(25,8), 	 /*毛利率*/
			   CrossRate  NUMERIC(25,8),	 /*交叉比*/
			   SaleUpRate NUMERIC(25,8),	 /*增长率*/
			   GrowthRate NUMERIC(25,8),	 /*成长率			   			   */
			   backRate NUMERIC(25,8),		 /*退货率*/
			   saleGrowthRate NUMERIC(25,8), /*销售营业成长率*/
			   profitGrowthRate NUMERIC(25,8), /*销售毛利成长率*/
			   iniQty  NUMERIC(25,8), 
			   beginQty NUMERIC(25,8),
			   OverQty NUMERIC(25,8),
			   total     NUMERIC(25,8),    /*不含税金额*/
			   costtaxtotal NUMERIC(25,8)  /*含税成本金额				    									                                                                                                                      */
              )
               
if OBJECT_ID('tempdb..#qrcustomGory' ) is not null 
  drop table #qrcustomGory
create table #qrcustomGory
		   ( cg_id int,
			 p_id int,
		     c1name varchar(80),
		     c2name varchar(80),
		     c3name varchar(80),
		     c1class_id varchar(12),
		     c2class_id varchar(12),
		     c3class_id varchar(12),
		     c1id int,
		     c2id int,
		     c3id int		     		    		     		   
		   )	               

declare @nMinDateid int, @nMaxDateid int, @splitBegindate datetime,  @splitEnddate datetime, @nDateid int

/*初始化#QrProducts*/
insert into #QrProducts(p_id, billid, billtype, billdate, quantity, taxprice, taxtotal, retailTotal, costprice,total,costtaxtotal) 	 
   select mx.p_id, mx.bill_id, bi.billtype, bi.billdate, mx.quantity, mx.taxprice, mx.taxtotal, mx.retailtotal,mx.costprice,mx.total,mx.costtaxtotal
     from billidx  bi
     inner join salemanagebill mx on bi.billid = mx.bill_id
     where  (bi.billdate between @begindate and @enddate) and
	        (@s_id = 0 or mx.ss_id = @s_id) and
	        (@loc_id = 0 or mx.location_id = @loc_id) and
	        (@e_id = 0 or bi.e_id = @e_id) and
	        (@c_id = 0 or bi.c_id = @c_id) and
	        (@y_id=0  or mx.Y_ID = @y_id)  and
	        (@supplier_id=0  or mx.supplier_id = @supplier_id)  and
	        bi.billtype in (10, 11, 12, 13) and
	        bi.billstates = 0 and mx.AOID = 0 and
	        mx.p_id > 0
	        
insert into #QrStoreini(p_id, quantity) 	 
   select p_id, quantity
     from storehouseini
    where  
	        (@s_id = 0 or s_id = @s_id) and
	        (@loc_id = 0 or location_id = @loc_id) and	        	        
	        (@y_id=0  or Y_ID = @y_id)  and
	        (@supplier_id=0  or supplier_id = @supplier_id)

insert into #QrPDetail(billdate, p_id, quantity) 	 
   select bi.billdate, pd.p_id, pd.quantity
     from productdetail pd
     inner join billidx bi on pd.billid =bi.billid
    where  
	        (@s_id = 0 or pd.s_id = @s_id) and
	        (@loc_id = 0 or pd.location_id = @loc_id) and	        	        
	        (@y_id=0  or pd.Y_ID = @y_id)  and
	        (@supplier_id=0  or pd.supplier_id = @supplier_id)	        	        	        	        
	        	        	        	        	        	        
                    
if @dateMode = 1 goto repMonth    /*按月查询*/
if @dateMode = 2 goto repquarter  /*按季度查询*/
if @dateMode = 3 goto repYear     /*按年查询*/

repMonth:
/*取月begindate*/

set @begindate = DATEADD(MM, -1, @begindate)

insert into #SplitDate(begindate)
   select    
     dateadd(mm,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(mm,number,@begindate)<=@enddate
/*计算其他时间列     */
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+cast(DATEPART(MM, begindate) as varchar(2))+'月',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = DATEPART(MM, begindate)
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1
  
  
                     								                    
  goto  rep


repquarter:
/*取季度begindate*/
set @begindate = DATEADD(QQ, -1, @begindate) /*需要计算到选择时间段的上一期*/

insert into #SplitDate(begindate)
   select    
     dateadd(QQ,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(QQ,number,@begindate)<=@enddate
/*计算其他时间列*/
	update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+ cast(DATEPART(QQ, begindate) as varchar(2))+'季度',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = 0	
	update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
	select @nMaxDateid = MAX(dateid) from #splitDate
    update #splitDate set enddate = @enddate where dateid = @nMaxDateid
    update #splitDate set daycount = cast((enddate - begindate) as Int)+1 	
    
  goto rep

repYear:
  /*取年begindate*/

set @begindate = DATEADD(YYYY, -1, @begindate) /*需要计算到选择时间段的上一期*/
  
insert into #SplitDate(begindate)
   select    
     dateadd(YYYY,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(YYYY,number,@begindate)<=@enddate
/*计算其他时间列*/
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年',
						yyyy = DATEPART(YYYY, begindate), qqq = 0, mm=0	
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1										

  goto Rep
  
rep: 
   /*初始化#qrSale03表*/
  insert into #qrSale03(dateid, p_id)
     select sp.dateid, mx.p_Id  
      from #splitDate sp
      cross join (select distinct p_id as p_Id from #QrProducts) mx
      order by sp.dateid, mx.p_Id
       
                 
  /*销售数量   --销售金额  --退货数量  --退货金额  --销售成本金额                 */
  
  update s1 set s1.SaleQty = t1.SaleQty, s1.Saletotal = t1.Saletotal, 
				 s1.BackQty = t1.backQty, s1.BackTotal = t1.backTotal,
				 s1.CostTotal = t1.costtotal,s1.total=t1.total,s1.costtaxtotal=t1.costtaxtotal          
    from  #qrSale03 s1,      
         (select    sp.dateid, p.p_id, 
					 sum(case  when p.billtype in(10, 12) then p.quantity else 0 end) as SaleQty, 
                     sum(case  when p.billtype in(10, 12) then p.taxtotal else 0  end) as Saletotal,
                     sum(case  when p.billtype in(10, 12) then p.costprice*p.quantity else 0  end) as costtotal,
                     sum(case  when p.billtype in(11, 13) then p.quantity else 0 end) as backQty, 
                     sum(case  when p.billtype in(11, 13) then p.taxtotal else 0  end) as backTotal,
                     sum(case  when p.billtype in(10, 12) then p.total else 0  end) as total,
                     sum(case  when p.billtype in(10, 12) then p.costtaxtotal else 0  end) as costtaxtotal                                    
       from #QrProducts  p
       left join #splitDate sp on  p.billdate between sp.begindate and sp.enddate            
       group by sp.dateid, p.p_id) t1                     
    where s1.dateid = t1.dateid and s1.p_id = t1.p_id                  
           
   
   /*清除null 避免计算出错   */
   update #qrSale03 set SaleQty = 0			where SaleQty is null
   update #qrSale03 set Saletotal = 0		where Saletotal is null
   update #qrSale03 set BackQty = 0			where BackQty is null
   update #qrSale03 set BackTotal = 0		where BackTotal is null					   					          
   update #qrSale03 set costtotal = 0		where costtotal is null
     
   /*毛利   毛利率*/
   update #qrSale03 set profit = Saletotal - costtaxtotal
   update #qrSale03 set profitRate = profit/Saletotal*100 where Saletotal <> 0            
     
/*销售退货率	退货总数量/采购总数量 分母为0返回空     */
   update #qrSale03 set backRate = BackQty/SaleQty*100 where SaleQty <> 0
   
/*销售增长率	本期销售额/上期采购额*/
   update q1 set SaleUpRate = q1.Saletotal/q2.Saletotal*100 
       from #qrSale03 q1, #qrSale03 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.p_id = q2.p_id 

  /*成长率*/
     update q1 set GrowthRate = (q1.Saletotal-q2.Saletotal)/q2.Saletotal*100 
       from #qrSale03 q1, #qrSale03 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.p_id = q2.p_id
            
  /*计算所有期初， 本期期初库存、本期期末库存*/
    update s1 set iniQty = t1.quantity
        from #qrSale03 s1,             
			  (select p_id, sum(quantity) quantity
				  from #QrStoreini
				  group by p_id 
			   ) t1
	    where s1.p_id = t1.p_id
     
    update s1 set beginQty = t1.beginQty
        from #qrSale03 s1,             
			  (select sp.dateid, pd.p_id, sum(pd.quantity) as beginQty
				  from #QrPDetail pd				  
				  left join  #splitDate sp on pd.billdate < sp.begindate      
				  group by sp.dateid, pd.p_id
			   ) t1
	    where s1.dateid =t1.dateid and s1.p_id = t1.p_id
	   
	 update s1 set OverQty = t1.OverQty
        from #qrSale03 s1,             
			  (select sp.dateid, pd.p_id,  sum(pd.quantity) as OverQty
				  from #QrPDetail pd				 
				  left join  #splitDate sp on pd.billdate < (sp.enddate + 1)      
				  group by sp.dateid, pd.p_id
			   ) t1
	    where s1.dateid =t1.dateid and s1.p_id = t1.p_id
  /*交叉比*/
      update #qrSale03 set iniQty = 0 where iniQty is null
      update #qrSale03 set beginQty = 0 where beginQty is null
      update #qrSale03 set OverQty = 0 where OverQty is null
      update #qrSale03 set profitRate = 0 where profitRate is null
            
      update #qrSale03 set beginQty = iniQty +beginQty, OverQty = iniQty + OverQty
      update #qrSale03 set CrossRate = profitRate*(SaleQty/(beginQty+OverQty)/2) where beginQty+OverQty <> 0                 	  	    
                    
  /*销售营业成长率*/
     update q1 set saleGrowthRate = q1.Saletotal/q2.Saletotal*100 
       from #qrSale03 q1, #qrSale03 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.p_id = q2.p_id            
  /*销售毛利成长率*/
     update q1 set profitGrowthRate = q1.profit/q2.profit*100 
       from #qrSale03 q1, #qrSale03 q2   
     where q1.dateid = q2.dateid + 1 and q2.profit <> 0 and q1.p_id =q2.p_id
     
     goto repend       
  
repend:
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int       
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'    
   
   select @cgClassid = class_id from customCategory where  id = @cg_id  
   
    DECLARE @PColName VARCHAR(100)
    SET @PColName = ''
    CREATE TABLE #TmpP (
    [class_id] [varchar](100) NOT NULL DEFAULT(''),    
    [baseinfo_id] [int] NOT NULL DEFAULT(0),
    [id] [int]  NOT NULL DEFAULT(0),
    [name] [varchar](200) NOT NULL DEFAULT('')
    )
    IF @cg_id = 0
      INSERT INTO #TmpP(class_id,baseinfo_id,id,name) 
      SELECT '',product_id,0,'' FROM products WHERE deleted = 0 AND class_id <> '000000' 
    ELSE
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id FROM customCategory WHERE class_id  = @cgClassid    
      SET @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')
      SET @PszSql = ' INSERT INTO #TmpP(class_id,baseinfo_id,id,name) '
                + ' select isnull(cc.class_id,''''),p.product_id as baseinfo_id,isnull(cc.id,0),isnull(cc.name,'''') from products p ' 
                + ' left join ProductCategory pc on p.product_id = pc.P_id '
                + ' left join customCategory cc on pc.' + @PColName + ' = cc.class_id where ' + @PColName + ' in (select class_id from #Categoryclassid)'
	  EXEC (@PszSql)        
    END  
   
   insert into #qrcustomGory(cg_id, p_id, c1name, c2name, c3name, c1id, c2id, c3id, c1class_id, c2class_id, c3class_id)   
   select cg.id, cm.baseinfo_id, isnull(c1.name, ''), isnull(c2.name, ''), isnull(c3.name, ''),
          isnull(c1.id, 0), isnull(c2.id, 0), isnull(c3.id, 0),
          isnull(c1.class_id, ''), isnull(c2.class_id, ''), isnull(c3.class_id, '')             
     from #TmpP  cm
     inner join customCategory cg on cm.class_id = cg.class_id
     left join  customCategory c1 on LEFT(cg.class_id, 4) = c1.class_id and LEN(c1.class_id) =4
     left join  customCategory c2 on LEFT(cg.class_id, 6) = c2.class_id and LEN(c2.class_id) =6
     left join  customCategory c3 on LEFT(cg.class_id, 8) = c3.class_id and LEN(c3.class_id) =8 
     where cg.baseType =0 and left(cg.class_id, 2) = @cgClassid and 
		   cg.id in (select CAST(szTYPE as Int) from dbo.DecodeToStr(@szID))
      
   select @nMinDateid = MIN(dateid)  from #SplitDate
   select  /*b.dateid, */
		   dbo.DecimalQrValue(@nSL, b.SaleQty) SaleQty,  dbo.DecimalQrValue(@ntotal,b.Saletotal) Saletotal,
		     dbo.DecimalQrValue(@ntotal,b.total) total,
		     dbo.DecimalQrValue(@ntotal,b.costtaxtotal) CostTaxTotal,
		     /*dbo.DecimalQrValue(@nSL,b.BackQty) BackQty,  */
		   /*dbo.DecimalQrValue(@ntotal,b.BackTotal) BackTotal,  */
		   dbo.DecimalQrValue(@ntotal,b.costtotal) costtotal,  dbo.DecimalQrValue(@ntotal,b.profit) profit, 
		   dbo.DecimalQrValue(@nOther,b.profitRate) profitRate,  dbo.DecimalQrValue(@nOther,b.backRate) backRate,	
		   dbo.DecimalQrValue(@nOther,b.SaleUpRate) SaleUpRate,   dbo.DecimalQrValue(@nOther,b.GrowthRate) GrowthRate,  
		   /*dbo.DecimalQrValue(@nSL,b.iniQty) iniQty, dbo.DecimalQrValue(@nSL,b.beginQty) beginQty, dbo.DecimalQrValue(@nSL,b.OverQty) OverQty, */
		   dbo.DecimalQrValue(@nOther,b.CrossRate) CrossRate,  
		   dbo.DecimalQrValue(@nOther,b.saleGrowthRate)saleGrowthRate, dbo.DecimalQrValue(@nOther,b.profitGrowthRate) profitGrowthRate,     
		  sd.FlagName, b.p_id, cg.c1name, cg.c2name, cg.c3name 
		  /*sd.yyyy, sd.qqq, sd.mm, sd.begindate, sd.enddate, sd.daycount,*/
          /*p.Code, p.Name, p.Standard, p.MakeArea, p.Factory, p.MedType, p.Unit1Name, p.Inputdate,*/
          /*p.StorageCon, p.C_Name, p.E_Name, p.packstd, cg.cg_id,*/
          /*cg.c1id, cg.c2id, cg.c3id, cg.c1class_id, cg.c2class_id, cg.c3class_id*/
     from  #qrSale03 b 
     inner join  #qrcustomGory cg on b.p_id = cg.p_id 
     left join #SplitDate sd on b.dateid = sd.dateid  
     left join  FilterProduct(2) p on b.p_id = p.Product_ID 
                    
     where sd.dateid >  @nMinDateid and (@p_id  = 0 or b.p_id =@p_id)           
     
   return 0
GO
