

CREATE VIEW vw_tabu
AS
SELECT t.*, isnull(e.name , '') as inputmanName
FROM dbo.TabuIndex t 
left join employees e on t.inputman = e.emp_id
GO
