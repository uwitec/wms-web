
/* exec TS_D_GetInvoicePic 20,194775*/
CREATE procedure TS_D_GetInvoicePic
@Billtype INT,/*单据类型*/
@Billid INT/*单据id       */
AS
  SET NOCOUNT ON 
  
  SELECT Supplier_id,P_id,Batchno
  INTO #InvoicePic
  FROM GSPbilldetail
  WHERE 0=1
  
  IF @Billtype=551  
  BEGIN
    INSERT INTO #InvoicePic 
    (Supplier_id,P_id,Batchno)
    SELECT DISTINCT Supplier_id,P_id,Batchno    
    FROM GSPbilldetail
    WHERE Gspbill_id=@Billid
  END  
  ELSE IF @Billtype=10
  BEGIN
    INSERT INTO #InvoicePic 
    (Supplier_id,P_id,Batchno)
    SELECT DISTINCT Supplier_id,P_id,Batchno    
    FROM salemanagebill
    WHERE bill_id=@Billid
  END  
  ELSE IF @Billtype=20
  BEGIN
    INSERT INTO #InvoicePic 
    (Supplier_id,P_id,Batchno)
    SELECT DISTINCT Supplier_id,P_id,Batchno    
    FROM buymanagebill
    WHERE bill_id=@Billid
  END  
 /*
    RepNo//发票号码
    p_id//invoiceidx.id,若=0为多余数据,1天前的数据是可以删除的
    c_name//往来单位id
    rpn_id//666存的就是发票图片
    repname//往来单位名称+','+发票金额
 */
  SELECT DISTINCT b.Pathname
  FROM #InvoicePic a INNER JOIN PicReport b 
       ON b.rpn_id=666 AND b.p_id>0 AND a.Supplier_id=b.c_name
       INNER JOIN invoice d 
       ON b.p_id=d.invoiceid
       INNER JOIN buymanagebill e
       ON d.billid=e.bill_id AND (d.smb_id=0 OR d.smb_id=e.smb_id)
          AND a.p_id=e.p_id AND a.Batchno=e.batchno

  DROP TABLE #InvoicePic
GO
