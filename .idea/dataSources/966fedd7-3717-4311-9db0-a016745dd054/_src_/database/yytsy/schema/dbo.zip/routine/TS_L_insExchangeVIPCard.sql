
/*换卡*/
CREATE      procedure TS_L_insExchangeVIPCard
  @VipCardid  int,
  @OldCardNo varchar(50),
  @NewCardNo varchar(50),
  @Comment varchar(200),
  @e_id int
as /*select * from ExchangeVIPCard*/
begin
  declare @OldCardID int,
          @Msg varchar(50)

   IF exists(select VIPcardid from Vipcard where VIPcardid=@VipCardid)
    begin
      Return @VipCardid
    end

  if exists(select * from VIPCard where CardNo=@NewCardNo and Deleted<>1) 
  begin
    set @Msg = '已经存在这个会员卡号【'+@NewCardNo+'】'
    raiserror(@Msg,16,1)
    return -1
  end

  select @OldCardID=VIPCardID from VIPCard where CardNo=@OldCardNo
  begin tran
  Declare @NewID int
    IF  @VipCardid<=0 
    select @NewID=IsNull(Max(VIPCardID),0)+1 from VIPCard
    else
    select @NewID=@VIPCardID

   
  update Vipcard set Vipcardid=@newid,CardNo=@NewCardNo where Vipcardid=@OldCardid

  insert into VIPCard(  VIPCardID,
                        CardNo,    
                        Name,
                        PinYin,
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
						Y_ID,
                        IniMoney,
                        TotalBuyMoney,
                        SaveMoney,
                        IntergralYE,
                        IniIntergral,
                        Integral,
                        SwapIntegral,
                        BuyCount,
			Deleted,
			Lose,
			StopUse,
			RemainderMoney,
                        LoginPass,
                        islock)
                        
                select  @OldCardid,
                        @OldCardNo,
                        Name,
                        PinYin,
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
						Y_ID,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
			Deleted,
			Lose,
			/*1,*/
			2, /*换卡操作，停用标志改为2，管控为永久锁定，不能再次启用或者更改*/
			0,
                        LoginPass,
                        islock
                   from VIPCard  
                  where VIPCardID=@newid
                   

  insert into ExchangeVIPCard(OldVIPCardID,NewVIPCardID,Comment,ExchangeDate,e_id)
              values(@OldCardID,@NewID,@Comment,convert(varchar(10),GetDate(),20),@e_id)
/*   update VIPCard */
/*      set StopUse=1,*/
/*          IniMoney=0,TotalBuyMoney=0,SaveMoney=0,IntergralYE=0,IniIntergral=0,*/
/*          Integral=0,SwapIntegral=0,BuyCount=0,RemainderMoney=0 */
/*    where VIPCardID=@OldCardID */



  IF @@ERROR=0
    COMMIT TRAN
  ELSE
    ROLLBACK TRAN

    return @NewID
end
GO
