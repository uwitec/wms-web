
/* exec TS_D_GSTransNum '1234567890123457'*/
CREATE PROCEDURE TS_D_InsGSProducts
@serial_number	varchar(20),
@name	varchar(100),
@EngName	varchar(300),
@SFLB	varchar(3),
@OTC	varchar(3),
@SFXMDJ	varchar(3),
@pinyin	varchar(50),
@MedTypeUnit	varchar(20),
@YNZJBS	varchar(3),
@GSDDNo	varchar(20),
@IsSP	varchar(3),
@MedType	varchar(3),
@SYPC	varchar(100),
@YF	varchar(200),
@WBZJM	varchar(50),
@UnitName	varchar(20),
@standard	varchar(100),
@price	varchar(14),
@FactoryName	varchar(100),
@permitcode	varchar(100),
@BeginDate	varchar(14),
@EndDate	varchar(14),
@Memo	varchar(100),
@ZDYCode	varchar(10),
@GJCode	varchar(20),
@XZSYFW	varchar(300),
@ZXYSDJ	varchar(3),
@ZXYYDJ	varchar(3),
@GSSYBZ	varchar(3),
@SYSYBZ	varchar(3),
@YLSYBZ	varchar(3),
@JMSYBZ	varchar(3),
@LXSYBZ	varchar(3),
@YbDate	varchar(14),
@YXBZ	varchar(3),
@TCAreaNo	varchar(6)
AS
  SET NOCOUNT ON  
  
  IF @serial_number IS NULL SET @serial_number=''
  IF @name IS NULL SET @name=''
  IF @EngName IS NULL SET @EngName=''
  IF @SFLB IS NULL SET @SFLB=''
  IF @OTC IS NULL SET @OTC=''
  IF @SFXMDJ IS NULL SET @SFXMDJ=''
  IF @pinyin IS NULL SET @pinyin=''
  IF @MedTypeUnit IS NULL SET @MedTypeUnit=''
  IF @YNZJBS IS NULL SET @YNZJBS=''
  IF @GSDDNo IS NULL SET @GSDDNo=''
  IF @IsSP IS NULL SET @IsSP=''
  IF @MedType IS NULL SET @MedType=''
  IF @SYPC IS NULL SET @SYPC=''
  IF @YF IS NULL SET @YF=''
  IF @WBZJM IS NULL SET @WBZJM=''
  IF @UnitName IS NULL SET @UnitName=''
  IF @standard IS NULL SET @standard=''
  IF @price IS NULL SET @price=''
  IF @FactoryName IS NULL SET @FactoryName=''
  IF @permitcode IS NULL SET @permitcode=''
  IF @BeginDate IS NULL SET @BeginDate=''
  IF @EndDate IS NULL SET @EndDate=''
  IF @Memo IS NULL SET @Memo=''
  IF @ZDYCode IS NULL SET @ZDYCode=''
  IF @GJCode IS NULL SET @GJCode=''
  IF @XZSYFW IS NULL SET @XZSYFW=''
  IF @ZXYSDJ IS NULL SET @ZXYSDJ=''
  IF @ZXYYDJ IS NULL SET @ZXYYDJ=''
  IF @GSSYBZ IS NULL SET @GSSYBZ=''
  IF @SYSYBZ IS NULL SET @SYSYBZ=''
  IF @YLSYBZ IS NULL SET @YLSYBZ=''
  IF @JMSYBZ IS NULL SET @JMSYBZ=''
  IF @LXSYBZ IS NULL SET @LXSYBZ=''
  IF @YbDate IS NULL SET @YbDate=''
  IF @YXBZ IS NULL SET @YXBZ=''
  IF @TCAreaNo IS NULL SET @TCAreaNo=''

  IF NOT EXISTS(SELECT 1 FROM GSProducts WHERE serial_number=@serial_number)
  BEGIN
    INSERT INTO GSProducts
	(serial_number,name,EngName,SFLB,OTC,SFXMDJ,pinyin,MedTypeUnit,YNZJBS,GSDDNo
	  ,IsSP,MedType,SYPC,YF,WBZJM,UnitName,standard,price,FactoryName,permitcode
	  ,BeginDate,EndDate,Memo,ZDYCode,GJCode,XZSYFW,ZXYSDJ,ZXYYDJ,GSSYBZ,SYSYBZ
	  ,YLSYBZ,JMSYBZ,LXSYBZ,YbDate,YXBZ,TCAreaNo)
	SELECT @serial_number,@name,@EngName,@SFLB,@OTC,@SFXMDJ,@pinyin,@MedTypeUnit,@YNZJBS,@GSDDNo
	  ,@IsSP,@MedType,@SYPC,@YF,@WBZJM,@UnitName,@standard,@price,@FactoryName,@permitcode
	  ,@BeginDate,@EndDate,@Memo,@ZDYCode,@GJCode,@XZSYFW,@ZXYSDJ,@ZXYYDJ,@GSSYBZ,@SYSYBZ
	  ,@YLSYBZ,@JMSYBZ,@LXSYBZ,@YbDate,@YXBZ,@TCAreaNo
  END 
  ELSE 
  BEGIN
    UPDATE GSProducts SET  
	serial_number=@serial_number
	,name=@name
	,EngName=@EngName
	,SFLB=@SFLB
	,OTC=@OTC
	,SFXMDJ=@SFXMDJ
	,pinyin=@pinyin
	,MedTypeUnit=@MedTypeUnit
	,YNZJBS=@YNZJBS
	,GSDDNo=@GSDDNo
	,IsSP=@IsSP
	,MedType=@MedType
	,SYPC=@SYPC
	,YF=@YF
	,WBZJM=@WBZJM
	,UnitName=@UnitName
	,standard=@standard
	,price=@price
	,FactoryName=@FactoryName
	,permitcode=@permitcode
	,BeginDate=@BeginDate
	,EndDate=@EndDate
	,Memo=@Memo
	,ZDYCode=@ZDYCode
	,GJCode=@GJCode
	,XZSYFW=@XZSYFW
	,ZXYSDJ=@ZXYSDJ
	,ZXYYDJ=@ZXYYDJ
	,GSSYBZ=@GSSYBZ
	,SYSYBZ=@SYSYBZ
	,YLSYBZ=@YLSYBZ
	,JMSYBZ=@JMSYBZ
	,LXSYBZ=@LXSYBZ
	,YbDate=@YbDate
	,YXBZ=@YXBZ
	,TCAreaNo=@TCAreaNo
    WHERE serial_number=@serial_number
  END
GO
