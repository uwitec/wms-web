CREATE PROCEDURE dbo.WebAPPTS_X_RepClientWlmx
(
  @BeginDate DATETIME=0,--开始时间
  @EndDate   DATETIME=0,--结束时间
  @szCClass_ID VARCHAR(30)='',--往来单位classID
  @SumMode    INT=0,--0分单明细,1按单据汇总T3的设置其他产品线没有可以不管此参数
  @OperatorID int = 0, --用户ID
  @Params varchar(200)--扩展参数	
)
AS 
BEGIN
  IF @BeginDate IS NULL SET @BeginDate = 0
  IF @EndDate IS NULL SET @EndDate = 0
  IF @szCClass_ID IS NULL SET @szCClass_ID = ''
  IF @SumMode IS NULL SET @SumMode = 0
  IF @OperatorID IS NULL SET @OperatorID = 0
  IF @Params IS NULL SET @Params = '' 	
  
  IF @szCClass_ID = '000000' SET @szCClass_ID = ''
  
  DECLARE @y_id INT 
  SET @y_id = 0
  select @y_id = dbo.webapp_get_param(@Params, 'y_id', default, default)
  SET @y_id = 2 --yyt调试用，正式发须去掉
  DECLARE @apid INT, @arid int 
  SELECT @arid = a.account_id FROM account a WHERE a.class_id = '000001000005' ---应收合计ID
  SELECT @apid = a.account_id FROM account a WHERE a.class_id = '000002000001' ---应付合计ID
  
  SELECT z.Cnumber,z.cname,z.billdate,z.auditdate,z.billnumber,z.artotaladd,z.aptotaladd,z.artotalbalance,
         ISNULL(y.name, '') AS YName   --yyt机构名称
    FROM (                                                                             --
  SELECT 
    isnull(a.Cnumber, '') Cnumber,   --往来单位编号
    isnull(a.CName, '') CName,    --往来单位名称
    isnull(a.billdate, '1900-01-01') billdate,  --单据日期
    isnull(a.auditdate, '1900-01-01') auditdate,  --单据过账日期
    isnull(a.billnumber, '') billnumber,   --单据编号
    a.y_id,
    isnull(sum(a.artotalAdd), 0) artotalAdd,  --应收增加
    isnull(sum(a.aptotalAdd), 0) aptotalAdd,   --应付增加
    isnull(sum(a.artotalBalance), 0) artotalBalance  ---余额
  FROM (
	  SELECT '' Cnumber, '此前余额' CName, '1900-01-01' billdate, '1900-01-01' auditdate, '' billnumber, 
	    0 artotalAdd, 0 aptotalAdd,  
	    SUM(CASE WHEN a.a_id = @arid THEN a.jdmoney WHEN a.a_id = @apid THEN -a.jdmoney ELSE 0 END) artotalBalance,0 AS Y_ID	     
	  FROM billidx b, accountdetail a, dbo.AuthorizeClients(@OperatorID) c
	  WHERE b.billid = a.billid 
		AND b.c_id = c.client_id
		AND a.a_id IN (@apid, @arid)
		AND b.Y_ID = a.Y_ID
		AND (b.Y_ID = @y_id OR @y_id = 0) 
		AND b.billstates = '0' 
		AND b.billdate < @BeginDate
		AND (@szCClass_ID = '' OR (c.class_id =@szCClass_ID))
	  GROUP BY b.Y_ID
	  UNION ALL
	  SELECT c.serial_number Cnumber, NAME Cname, b.billdate, b.auditdate, b.billnumber,
		sum(CASE WHEN a.a_id = @arid THEN a.jdmoney ELSE 0 END) artotalAdd,
		sum(CASE WHEN a.a_id = @apid THEN a.jdmoney ELSE 0 END) aptotalAdd,
		0 artotalBalance,b.Y_ID
	  FROM billidx b, accountdetail a, dbo.AuthorizeClients(@OperatorID) c 
	  WHERE b.billid = a.billid 
		AND b.c_id = c.client_id
		AND a.a_id IN (@apid, @arid)
		AND b.Y_ID = a.Y_ID
		AND (b.Y_ID = @y_id OR @y_id = 0) 
		AND b.billstates = '0' 
		AND b.billdate BETWEEN @BeginDate AND @EndDate
		AND (@szCClass_ID = '' OR (c.class_id =@szCClass_ID))
	  GROUP BY b.y_id,c.serial_number, NAME, b.billdate, b.billnumber, c.client_id, b.auditdate
  ) a GROUP BY a.y_id,a.Cnumber, a.CName, a.billdate, a.auditdate, a.billnumber 
  ) z LEFT JOIN company y ON z.y_id = y.company_id ORDER BY z.auditdate  
END
GO
