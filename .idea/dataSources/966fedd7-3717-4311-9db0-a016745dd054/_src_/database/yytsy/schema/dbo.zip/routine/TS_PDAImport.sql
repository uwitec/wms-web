
CREATE  PROCEDURE [dbo].[TS_PDAImport]    
AS     
  declare @billid int,    
          @billdate varchar(30),    
          @billtype int,    
          @c_id int,    
          @e_id int,    
          @s_id int,    
          @a_id int,    
          @d_id int,    
          @billno varchar(100),    
          @ysTotal NUMERIC(25,8),    
          @quantity NUMERIC(25,8),    
          @ssTotal NUMERIC(25,8),    
          @summary varchar(100),    
          @PDANo varchar(100),    
          @InputMan int,    
          @GUID varchar(100),    
          @y_id int,    
          @PdplanIdx int,    
          @PDAGUID VARCHAR(40),
          @TransFlag INT  
  declare @ID int, @bybatched bit  
  
   SET @PdplanIdx=0 set @y_id=0            
      
      /*SELECT * FROM pda_billdraftidx*/
  delete pda_billdraftidx where PDAGUID not in (select pdaguid from pda_machine)    
  delete pda_billdetail where billid not in (select billid from pda_billdraftidx)    
    /*  
  if OBJECT_ID('tempdb..#PDAStore') is not null    
   drop table #PDAStore  */  
                  
  declare cur1 cursor for    
    select *     
      from pda_billdraftidx   
     where guid not in(select guid from billdraftidx where billtype = 58) and billtype = 50     
  open cur1    
  fetch next from cur1 into @billid,@billdate,@billtype,@c_id,@e_id,@s_id,@a_id,@d_id,    
                            @billno,@ysTotal,@quantity,@ssTotal,@summary,@PDANo,@InputMan,@GUID,@y_id,@PDAGUID,@TransFlag   
  /*@bybatched  */
  while (@@fetch_status=0)     /*select * from pdplanidx  exec TS_PDAImport */
  begin    
    select @PdplanIdx = IsNull(pdidx,0), @y_id = IsNull(Y_Id,0)     
      from pdplanidx where  billstates = 3 and k_id = @s_id     
    IF @PdplanIdx = 0
      RETURN    
    /*插入主表          */
		insert into billdraftidx(billdate,billnumber,billtype,a_id,c_id,e_id,sin_id,sout_id,auditman,    
			ysmoney,ssmoney,quantity,order_id,     
			department_id,note,billstates,InputMan,JSFlag,guid,Y_ID,ZBAuditMan,ZBAuditDate)    
		values(@billdate,@billno,58,@a_id,@c_id,@e_id,@s_id,@s_id,@e_id,     
			@ysTotal,@ssTotal,@quantity,@PdplanIdx,    
			@d_id,@summary+'-PDA导入',3,@InputMan,0,@GUID, @y_id,0,'1900-01-01')    
		set @ID=@@IDENTITY    
    /*插入明细表   */
		insert into goodscheckbilldrf(bill_id,p_id,unitid,quantity,buyprice,total,batchno,    
			discount,taxtotal,ss_id,supplier_id,CostPrice,    
			discountprice, /*库存数量    */
			totalmoney,    /*盈亏数量    */
			taxprice,      /*库存基本数量    */
			taxmoney, makedate, validdate, bybatch, location_id, commissionflag, Y_ID, instoretime)      /*盈亏基本数量    */
		select @ID,bill.p_id,bill.u_id,bill.BQuantity,price,bill.total,bill.batchno, /*增加批号*/    
			1,bill.total,@s_id, bill.supplier_id,price, 
			ISNULL(info.quantity, 0) / bill.rate, 
			bill.Quantity - ISNULL(info.quantity, 0) / bill.rate, 
			ISNULL(info.quantity, 0), 
			bill.BQuantity - ISNULL(info.quantity, 0), bill.makedate, bill.validdate, bill.bybatch,bill.location_id,   
			bill.commissionflag, @y_id, bill.instoretime
		from pda_billdetail bill 
		         left join (SELECT d.* FROM pdplanidx idx INNER JOIN pdplan d ON idx.pdidx = d.pdidx WHERE idx.billstates=3 AND 
idx.k_id=@s_id) info 
                                                    on bill.p_id = info.p_id  
			                                           and bill.makedate= info.makedate  
			                                           and bill.validdate = info.validdate  
			                                           and bill.batchno = info.batchno  
			                                           and bill.costprice = info.costprice 
			                                           and bill.supplier_id = info.supplier_id
			                                           and bill.commissionflag = info.commissionflag
			                                           and bill.location_id = info.location_id
			                                           and bill.instoretime = info.instoretime
			                                           and @y_id = info.Y_ID 	
		where billid=@billid     
			and bill.bybatch = 1
			  
              
		insert into goodscheckbilldrf(bill_id,p_id,unitid,quantity,buyprice,total,batchno,    
			discount,taxtotal,ss_id,supplier_id,CostPrice,    
			discountprice, /*库存数量    */
			totalmoney,    /*盈亏数量    */
			taxprice,      /*库存基本数量    */
			taxmoney, makedate, validdate, bybatch, location_id, commissionflag, Y_ID)      /*盈亏基本数量    */
		select @ID,bill.p_id,bill.u_id,bill.Bquantity,price,bill.total,'', /*增加批号*/   
			1,bill.total,@s_id,@c_id,bill.price,    
			ISNULL(info.quantity, 0) / bill.rate, 
			bill.Quantity - ISNULL(info.quantity, 0) / bill.rate,  
			ISNULL(info.quantity, 0), 
			bill.Bquantity - ISNULL(info.quantity, 0), '1899-12-30', '1899-12-30', bill.bybatch,bill.location_id,   
			bill.commissionflag, @y_id     			 
		from pda_billdetail bill /*left join (select * from pda_batchinfo where s_id = @s_id) info  */
		                          /*      on bill.p_id = info.p_id*/
			                     /*left join (select SUM(quantity) as qty, p_id from storehouse where p_id in(select distinct p_id from pda_billdetail) and s_id = @s_id and stopsaleflag = 0 group by p_id) sq*/
		                         /*       on bill.p_id = sq.p_id*/
		                         LEFT JOIN (SELECT d.p_id,SUM(d.quantity) quantity FROM pdplanidx idx INNER JOIN pdplan d ON idx.pdidx = d.pdidx WHERE idx.billstates=3 AND idx.k_id=@s_id GROUP BY d.p_id) info ON bill.p_id = info.p_id       
		where billid=@billid
			and bill.bybatch = 0
                
                
        fetch next from cur1 into @billid,@billdate,@billtype,@c_id,@e_id,@s_id,@a_id,@d_id,    
                            @billno,@ysTotal,@quantity,@ssTotal,@summary,@PDANo,@InputMan,@GUID,@y_id,@PDAGUID,@TransFlag   
  end     
  close cur1    
  deallocate cur1    
      
    /*新增按批次盘点功能. begin  */
    
  declare  @PDAStore table  
 (p_id int,  
  ss_id varchar(30),  
  quantity numeric(18,2),  
  costprice money,  
  makedate datetime,  
  validdate datetime,  
  batchno varchar(30),  
  bybatch bit,  
  location_id varchar(20),   
  commissionflag int,  
  Y_ID varchar(30),  
  supplier_id varchar(30))   
     
 /* Insert @PDAStore(p_id, ss_id, quantity, costprice, makedate, validdate, batchno)  
  select p_id, ss_id, SUM(quantity) quantity    
    from GoodsCheckBillDrf     
   where bill_id in (select billid from billdraftidx where billtype = 58 and order_id = @PdplanIdx and bybatch=0)    
   group by p_id, ss_id */  
      
     
   Insert @PDAStore(p_id, ss_id, quantity, costprice, makedate, validdate,   
   batchno, bybatch, location_id, commissionflag, Y_ID, supplier_id)  
  select p_id, ss_id, SUM(quantity) quantity,  costprice, makedate, validdate,   
   batchno, bybatch,location_id, commissionflag, Y_ID, supplier_id  
    from GoodsCheckBillDrf     
   where bill_id in (select billid from billdraftidx where billtype = 58 and order_id = @PdplanIdx)    
   group by p_id, ss_id, costprice, makedate, validdate, batchno,  
  bybatch , location_id, commissionflag, Y_ID, supplier_id  
     
     
         
       
      
  insert into PdPlan(pdidx, p_id, inputdate, quantity,spQuantity,PYQuantity,PkQuantity, s_id,PDFlag, Y_ID, costprice, makedate, validdate, batchno)    
    select @PdplanIdx, p_id, GETDATE(), 0, quantity, quantity, 0, ss_id, 1, @y_id, costprice, makedate, validdate, batchno  
      from @PDAStore store where   not exists(Select p_id From PdPlan pd   
       where store.costprice = pd.costprice   
         and store.makedate = pd.makedate  
         and store.validdate = pd.validdate  
         and store.batchno = pd.batchno  
         and store.p_id = pd.p_id  
         and pd.pdidx = @PdplanIdx)  
        
 /*  insert into PdPlan(pdidx, p_id, inputdate, quantity,spQuantity,PYQuantity,PkQuantity, s_id,PDFlag, Y_ID)    
    select @PdplanIdx, p_id, GETDATE(), 0, quantity, quantity, 0, ss_id, 1, @y_id     
      from #PDAStore store where p_id not in (select p_id from PdPlan where pdidx = @PdplanIdx)    
   
 */  
    
    /*新增按批次盘点功能. end  */
       
  update PdPlan set spQuantity = t.quantity, PDFlag = 1    
    from PdPlan pd, @PDAStore t    
   where pd.pdidx= @PdplanIdx and pd.p_id = t.p_id  and pd.quantity <> 0 and t.bybatch = 0   
     
    update PdPlan set spQuantity = t.quantity, PDFlag = 1    
    from PdPlan pd, @PDAStore t    
   where pd.pdidx= @PdplanIdx and pd.p_id = t.p_id    
     and pd.quantity <> 0   
     and t.bybatch = 1    
     and pd.costprice = t.costprice  
     and pd.makedate = t.makedate  
     and pd.validdate = t.validdate  
     and pd.batchno= t.batchno  
          
  update PdPlan set PYQuantity = spQuantity - quantity   
 where pdidx = @PdplanIdx and spQuantity-quantity > 0  and quantity <> 0  and PDFlag = 1
      
  update PdPlan set PKQuantity = Quantity - spquantity   
 where pdidx = @PdplanIdx and Quantity-spquantity > 0  and PDFlag = 1    
       
 /*if OBJECT_ID('tempdb..#PDAStore') is not null    
   drop table #PDAStore    
   */    
return 0
GO
