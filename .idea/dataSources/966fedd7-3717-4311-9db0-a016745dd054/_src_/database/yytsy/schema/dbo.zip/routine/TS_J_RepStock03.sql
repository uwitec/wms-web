
/* 功能：库存决策查询-明细
  
*/

CREATE PROCEDURE TS_J_RepStock03
( 
	@szbegindate datetime,   /*开始时间*/
	@szenddate   datetime,   /*结束时间	*/
	@cg_id     int = 0,        /*选择类别组*/
	@szID      varchar(3000),  /*类别id*/
	@y_id      int =0,		    /*分支机构id*/
	@p_id      int=0,           /*商品id*/
	@s_id	   int = 0,			/*仓库	*/
	@supplier_id int = 0		/*供应商	*/
)

AS

/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @opendate  datetime    /*开账时间*/
   declare @cgClassid varchar(12)  /*类别组classid*/
   declare @dayCount int, @curDate datetime
             
   set @enddate = @szenddate
   
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @szbegindate
   if @szbegindate <  @OpenDate
     set @begindate = @OpenDate
    else 
     set @begindate = @szenddate
   
  set @dayCount = CAST((CAST(@enddate as NUMERIC(25,8))- cast(@begindate as NUMERIC(25,8))+1)  as int)
  
  set @curDate = cast(FLOOR(CAST(getdate() as NUMERIC(25,8))) as datetime) 
                   
/*创建日期分段表，标识，时间跨度*/
/*创建需要查询的商品表，关联了类别组的商品*/
/*创建新品表*/
/*创建返回信息表*/
/*创建表根据类别组取的各级类别名*/
/*计算返回值*/

			  
if OBJECT_ID('tempdb..#QrProducts' ) is not null 
  drop table #QrProducts
create table #QrProducts
 			( p_id int) 			 			   			  			 			   			  			 
			     
if OBJECT_ID('tempdb..#qrStock03' ) is not null 
  drop table #qrStock03
create table #qrStock03
             (
               p_id  int,            /*商品id                 */
			   costtotal NUMERIC(25,8),	/*库存成本总金额*/
			   retailtotal NUMERIC(25,8), /*库存预估零售总金额*/
			   upperlimit NUMERIC(25,8), /*库存上限*/
			   lowlimit NUMERIC(25,8), /*库存下限*/
			   Quantity NUMERIC(25,8),  /*当前库存数量*/
			   buyOrderQuantity NUMERIC(25,8), /*采购订单未完成数量*/
			   saleOrderQuantity NUMERIC(25,8), /*销售订单未完成数量*/
			   SaleDay NUMERIC(25,8), /*可销天数*/
			   AvgSaleQty NUMERIC(25,8), /*日均销数*/
			   StoreDay int,     /*在库天数*/
			   OutDay   int,	/*断货天数*/
			   BackRate NUMERIC(25,8),  /*商品期间回转率*/
			   BackDay  NUMERIC(25,8), /*商品期间回转天数*/
			   velocity NUMERIC(25,8),/*商品周转率*/
			   wasteRate NUMERIC(25,8), /*商品损耗率*/
			   AvgStoreTotal NUMERIC(25,8), /*平均存货额*/
			   saleQty      NUMERIC(25,8),  /*销售数量*/
			   saleTotal    NUMERIC(25,8),  /*销售额*/
			   sxDay        NUMERIC(25,8),    /*实际销售天数*/
			   LastsaleDay  datetime,  /*最后一次销售时间 */
			   pkQty        NUMERIC(25,8),  /*盘亏数量*/
			   pkTotal      NUMERIC(25,8),  /*盘亏金额*/
			   retailprice  NUMERIC(25,8),  /*零售价*/
			   iniStoreTotal NUMERIC(25,8), /*期初存货额*/
			   OverStoreTotal NUMERIC(25,8),	/*期末存货额*/
			   costtaxtotal NUMERIC(25,8)/*库存含税成本总金额			   		   			  			   			              			    									                                                                                                                      */
              )
               
if OBJECT_ID('tempdb..#qrcustomGory' ) is not null 
  drop table #qrcustomGory
create table #qrcustomGory
		   ( p_id int,
		     c1name varchar(80),
		     c2name varchar(80),
		     c3name varchar(80),
		     c1class_id varchar(12),
		     c2class_id varchar(12),
		     c3class_id varchar(12),
		     c1id int,
		     c2id int,
		     c3id int		     		    		     		   
		   )			   		   
		   
insert into #QrProducts(p_id)
           select product_id from products 
            where child_number = 0 and class_id <> '000000' and deleted <> 1 and  IsSplit = 0 and
                  ((@p_id = 0) or (product_id = @p_id))
                                                       		                  
      	        	        	       	        	        	        	        	        	                            
   /*初始化#qrSale03表*/
  insert into #qrStock03(p_id)
     select p_Id  
      from #QrProducts
      
       
/*库存成本总金额*/
/*当前库存数量*/
  update #qrStock03 set costtotal = t.costtotal, Quantity = t.quantity,costtaxtotal=t.costtaxtotal
         from  #qrStock03 qr, 
               (select s.p_id, SUM(costtotal) as costtotal, SUM(quantity) as quantity,SUM(costtaxtotal) as costtaxtotal  
                  from storehouse s 
                  inner join  #QrProducts p on s.p_id = p.p_id
                  where  ((@y_id = 0) or (s.Y_ID = @y_id))   and	
						 ((@s_id = 0) or (s.s_id = @s_id)) and	   
	                     ((@supplier_id = 0) or (s.supplier_id = @supplier_id))  
                  group by s.p_id)t
			where qr.p_id = t.p_id                  
  
 /*零售价*/
  update #qrStock03 set retailprice= t.retailprice  
      from  #qrStock03 qr, 
               (select pr.p_id, MAX(retailprice) as retailprice                              
                  from price pr
                  inner join  #QrProducts p on pr.p_id = p.p_id
                  where  pr.unittype =1 
                  group by pr.p_id)t
		where qr.p_id = t.p_id                  
                                             
/*库存预估零售总金额*/
 update #qrStock03 set retailprice = 0 where  retailprice is null
 update #qrStock03 set Quantity = 0 where Quantity is null
 update #qrStock03 set retailtotal = retailprice * Quantity

/*库存上限、库存下限*/
	update #qrStock03 set upperlimit = t.upperlimit, lowlimit = t.lowlimit
         from  #qrStock03 qr, 
               (select s.p_id, SUM(UpperLimit) as upperlimit, SUM(LowLimit) as lowlimit  
                  from StoreLimit s 
                  inner join  #QrProducts p on s.p_id = p.p_id
                  where  ((@y_id = 0) or (s.Y_ID = @y_id))   and	
						 ((@s_id = 0) or (s.s_id = @s_id))	   	                     
                  group by s.p_id)t
			where qr.p_id = t.p_id                  

/*采购订单未完成数量*/
/*销售订单未完成数量*/

   update #qrStock03 set buyOrderQuantity = t.buyOrderQuantity, saleOrderQuantity = t.saleOrderQuantity
         from  #qrStock03 qr, 
               (select mx.p_id, sum(case bi.billtype when 22 then (mx.quantity - mx.ComeQty) else 0 end) as  buyOrderQuantity,
						 sum(case bi.billtype when 14 then (mx.quantity - mx.ComeQty) else 0 end) as  saleOrderQuantity           
				   from OrderBill mx
				   inner join orderidx bi on mx.bill_id = bi.billid
				   where bi.billtype in (22, 14) and bi.billstates = '3' and 
						 ((@y_id = 0) or bi.Y_ID  = @y_id) and         
						 ((@supplier_id = 0) or  (mx.supplier_id = @supplier_id)) 
				   group by mx.p_id
                     )t
			where qr.p_id = t.p_id                     
                     
                     
/*销售额、销售数量*/

   update #qrStock03 set saleQty = t.quantity, saleTotal = t.taxtotal
         from  #qrStock03 qr, 
               (
				   select mx.p_id, sum(-mx.taxtotal) as taxtotal, sum(-mx.quantity) as quantity
					 from  productdetail mx 
					 inner join billidx bi on mx.billid  = bi.billid
					 where bi.billtype in (10, 11, 12, 13) and
						   bi.billdate between @szbegindate and @szenddate and
						   bi.billstates = 0 and AOID = 0 and 
						   ((@y_id = 0) or (mx.Y_ID = @y_id)) and
						   ((@s_id = 0) or (mx.s_id = @s_id)) and
						   ((@p_id = 0) or (mx.p_id = @p_id)) and
						   ((@supplier_id =0) or(mx.supplier_id = @supplier_id))
					  group by mx.p_id                   
                     )t
			where qr.p_id = t.p_id                                                                                           

/*盘亏数量*/
/*盘亏金额  */
        update #qrStock03 set pkQty = t.pkquantity, pkTotal = t.pktotal
         from  #qrStock03 qr, 
               (    select tmp.p_id, sum(tmp.pkquanity) as pkquantity, SUM(tmp.pkTotal) as pktotal
						from
					   (select mx.p_id, mx.quantity as pkquanity, mx.costtotal as pkTotal
					   from billidx bi
					   inner join storemanagebill mx  on bi.billid = mx.bill_id
					   where bi.billtype = 41 and 
											   bi.billdate between @szbegindate and @szenddate and
											   bi.billstates = 0 and AOID = 0 and 
											   ((@y_id = 0) or (mx.Y_ID = @y_id)) and
											   ((@s_id = 0) or (mx.ss_id = @s_id)) and
											   ((@p_id = 0) or (mx.p_id = @p_id)) and
											   ((@supplier_id =0) or(mx.supplier_id = @supplier_id))						    
					   union all
					   select mx.p_id, mx.totalmoney as pkquanity, mx.taxtotal as pktototal
					   from billidx bi
					   inner join goodscheckbill mx  on bi.billid = mx.bill_id
					   where bi.billtype = 50 and 
											   bi.billdate between @szbegindate and @szenddate and
											   bi.billstates = 0 and AOID = 0 and 
											   ((@y_id = 0) or (mx.Y_ID = @y_id)) and
											   ((@s_id = 0) or (mx.ss_id = @s_id)) and
											   ((@p_id = 0) or (mx.p_id = @p_id)) and
											   ((@supplier_id =0) or(mx.supplier_id = @supplier_id))
					   ) tmp
					   group by tmp.p_id					  
                     )t
				where qr.p_id = t.p_id                                                                      
                   					                                                                          
/*在库天数*/

            update #qrStock03 set StoreDay = t.storeday
         from  #qrStock03 qr, 
               (
				 select s.p_id, cast((@curDate-MIN(instoretime)) as int) as storeday
                  from storehouse s 
                  inner join  #QrProducts p on s.p_id = p.p_id
                  where  ((@y_id = 0) or (s.Y_ID = @y_id))   and	
						 ((@s_id = 0) or (s.s_id = @s_id)) and	   
	                     ((@supplier_id = 0) or (s.supplier_id = @supplier_id))	                     
	                      
	              group by s.p_id
                     )t
			where qr.p_id = t.p_id                        
                    
/*断货天数*/
      update #qrStock03 set LastsaleDay = t.lastsaleDay
         from  #qrStock03 qr, 
               (
				   select mx.p_id, MAX(bi.billdate) as lastsaleDay
					 from  salemanagebill mx 
					 inner join billidx bi on mx.bill_id  = bi.billid
					 where bi.billtype in (10, 11, 12, 13) and
						   bi.billdate between @szbegindate and @szenddate and
						   bi.billstates = 0 and AOID = 0 and 
						   ((@y_id = 0) or (mx.Y_ID = @y_id)) and
						   ((@s_id = 0) or (mx.ss_id = @s_id)) and
						   ((@p_id = 0) or (mx.p_id = @p_id)) and
						   ((@supplier_id =0) or(mx.supplier_id = @supplier_id))
					  group by mx.p_id                   
                     )t  
             where qr.p_id = t.p_id    
                               
      update #qrStock03 set Quantity = 0 where Quantity is null
     
     /*最后一次销售时间为空的，取本期开始时间*/
      DECLARE @BEGIN DATETIME
      SELECT top 1 @BEGIN = BeginDate FROM MonthSettleInfo WHERE Y_ID = @y_id AND MonthName = '本期'
      if @BEGIN is null
		SELECT top 1 @BEGIN = BeginDate FROM MonthSettleInfo WHERE Y_ID = 0 AND MonthName = '本期'  
		
 	  update #qrStock03 set LastsaleDay	=@BEGIN where LastsaleDay IS null
 
                                     
      update #qrStock03 set OutDay = cast((@curDate - LastsaleDay) as Int)  where Quantity = 0 and LastsaleDay is not null       
       
      /* select LastsaleDay from  #qrStock03                                               */

/*日均销数 可销天数*/
    /*取的实际销售天数  总天数－断货天数*/
      update #qrStock03 set OutDay = 0 where OutDay is null
      update #qrStock03 set sxDay = @dayCount - OutDay where LastsaleDay is not null
      update #qrStock03 set sxDay = 0 where sxDay is null
      update #qrStock03 set AvgSaleQty = saleQty/sxDay where sxDay <> 0
      update #qrStock03 set SaleDay= Quantity/AvgSaleQty where AvgSaleQty <> 0
      
                  

/*计算所有期初， 本期期初库存、本期期末库存*/
     update #qrStock03 set iniStoreTotal = t.iniTotal
         from  #qrStock03 qr, 
               (
				   select p_id, SUM(costtotal) as iniTotal from 
					(
					select p_id, costtotal 
					  from storehouseini
					  where ((@p_id = 0) or (p_id = @p_id))  and   
						   ((@y_id = 0) or (Y_ID = @y_id))   and	
						   ((@s_id = 0) or (s_id = @s_id)) and	   
						   ((@supplier_id = 0) or (supplier_id = @supplier_id))      
					union all 
					select pd.p_id, pd.costtotal
					  from productdetail pd
						   inner join billidx bi on pd.billid = bi.billid
					  where bi.billdate < @begindate and
						   ((@p_id = 0) or (pd.p_id = @p_id))  and   
						   ((@y_id = 0) or (pd.Y_ID = @y_id))   and	
						   ((@s_id = 0) or (pd.s_id = @s_id)) and	   
						   ((@supplier_id = 0) or (pd.supplier_id = @supplier_id))) tmp
					 group by tmp.p_id                                   
                     )t  
             where qr.p_id = t.p_id     

        
        update #qrStock03 set OverStoreTotal = t.OverTotal
         from  #qrStock03 qr, 
               (
				   select p_id, SUM(costtotal) as OverTotal from 
					(
					select p_id, costtotal 
					  from storehouseini
					  where ((@p_id = 0) or (p_id = @p_id))  and   
						   ((@y_id = 0) or (Y_ID = @y_id))   and	
						   ((@s_id = 0) or (s_id = @s_id)) and	   
						   ((@supplier_id = 0) or (supplier_id = @supplier_id))      
					union all 
					select pd.p_id, pd.costtotal
					  from productdetail pd
						   inner join billidx bi on pd.billid = bi.billid
					  where bi.billdate <= @enddate and
						   ((@p_id = 0) or (pd.p_id = @p_id))  and   
						   ((@y_id = 0) or (pd.Y_ID = @y_id))   and	
						   ((@s_id = 0) or (pd.s_id = @s_id)) and	   
						   ((@supplier_id = 0) or (pd.supplier_id = @supplier_id))) tmp
					 group by tmp.p_id                                   
                     )t  
             where qr.p_id = t.p_id                               
                
/*平均存货额*/
      update #qrStock03 set iniStoreTotal = 0 where iniStoreTotal is null
      update #qrStock03 set OverStoreTotal = 0 where OverStoreTotal is null
      update #qrStock03 set AvgStoreTotal = (iniStoreTotal+OverStoreTotal)/2
/*商品期间回转率*/
      update #qrStock03 set BackRate = (saleTotal/AvgStoreTotal)*100 where AvgStoreTotal <> 0           
/*商品期间回转天数*/
      update #qrStock03 set BackRate = 0 where BackRate is null
      update #qrStock03 set BackDay = @dayCount/BackRate*100 where BackRate <> 0
/*商品周转率*/
      update #qrStock03 set velocity= (saleTotal/@dayCount)/AvgStoreTotal*100 where AvgStoreTotal <> 0

/*商品损耗率	*/
      update #qrStock03 set pkTotal = 0 where pkTotal is null
      update #qrStock03 set wasteRate = pkTotal/(pkQty*retailprice)*100 where pkQty <> 0 and retailprice <> 0
      
      
/*处理Null*/
       update #qrStock03 set costtotal				=0 where	costtotal						IS null
       update #qrStock03 set retailtotal			=0 where	retailtotal						IS null
       update #qrStock03 set upperlimit				=0 where	upperlimit						IS null
       update #qrStock03 set lowlimit				=0 where	lowlimit						IS null
       update #qrStock03 set Quantity				=0 where	Quantity						IS null	
       update #qrStock03 set buyOrderQuantity		=0 where	buyOrderQuantity				IS null
       update #qrStock03 set saleOrderQuantity		=0 where	saleOrderQuantity				IS null
       update #qrStock03 set SaleDay				=0 where	SaleDay							IS null
       update #qrStock03 set AvgSaleQty				=0 where	AvgSaleQty						IS null
       update #qrStock03 set StoreDay				=0 where	StoreDay						IS null
	   update #qrStock03 set OutDay					=0 where	OutDay							IS null
       update #qrStock03 set BackRate				=0 where	BackRate						IS null
	   update #qrStock03 set BackDay				=0 where	BackDay							IS null
	   update #qrStock03 set velocity				=0 where	velocity						IS null
	   update #qrStock03 set wasteRate				=0 where	wasteRate						IS null	
	   update #qrStock03 set AvgStoreTotal			=0 where	AvgStoreTotal					IS null
	   update #qrStock03 set saleQty				=0 where	saleQty							IS null
	   update #qrStock03 set saleTotal				=0 where	saleTotal						IS null
	   update #qrStock03 set sxDay					=0 where	sxDay							IS null
	   update #qrStock03 set LastsaleDay	        =0 where    LastsaleDay                     IS null
	   update #qrStock03 set pkQty					=0 where	pkQty							IS null
	   update #qrStock03 set pkTotal				=0 where	pkTotal							IS null
	   update #qrStock03 set retailprice			=0 where	retailprice						IS null
	   update #qrStock03 set iniStoreTotal			=0 where	iniStoreTotal					IS null
	   update #qrStock03 set OverStoreTotal			=0 where	OverStoreTotal					IS null
	   update #qrStock03 set costtaxtotal			=0 where	costtaxtotal					IS null
						 						 											 
/*repend				 */
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int       
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'    
   
   select @cgClassid = class_id from customCategory where  id = @cg_id
  
  
    DECLARE @PColName VARCHAR(100)
    set @PColName = ''
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @Pclassid varchar(100)
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@szID))
    
	  SELECT @Pclassid = dbo.GetCateClassids(@szID)
    
      IF @Pclassid IS NULL SET @Pclassid = ''
      IF LEN(@Pclassid) > 0
      SET @Pclassid = LEFT(@Pclassid,LEN(@Pclassid)-1)
    
      set @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')  
      set @PszSql =  'INSERT INTO #qrcustomGory(p_id, c1name, c2name, c3name, c1id, c2id, c3id, c1class_id, c2class_id, c3class_id) ' 
		+ ' select p.product_id, isnull(c1.name, ''''), isnull(c2.name, ''''), isnull(c3.name, ''''),'
        + ' isnull(c1.id, 0), isnull(c2.id, 0), isnull(c3.id, 0),'
        + ' isnull(c1.class_id, ''''), isnull(c2.class_id, ''''), isnull(c3.class_id, '''') from products p '
        + ' inner join ProductCategory c on p.product_id = c.P_id '
        + ' left join  customCategory c1 on LEFT(c.' + @PColName + ', 4) = c1.class_id and LEN(c1.class_id) =4 '
        + ' left join  customCategory c2 on LEFT(c.' + @PColName + ', 6) = c2.class_id and LEN(c2.class_id) =6 '
        + ' left join  customCategory c3 on LEFT(c.' + @PColName + ', 8) = c3.class_id and LEN(c3.class_id) =8 '
        + ' where p.product_id = c.P_id and c.' + @PColName  
		+ ' in (select type  from DecodeStr(''' +@Pclassid +''')) AND p.deleted = 0'  
	  exec (@PszSql)        
    END
  		       
   select 
           b.p_id,
           isnull(cg.c1name, '') as c1name, isnull(cg.c2name, '') as c2name, isnull(cg.c3name, '') as c3name, 
		   dbo.DecimalQrValue(@ntotal, b.costtotal) costtotal,
		   dbo.DecimalQrValue(@ntotal, b.costtaxtotal) costtaxtotal, 
		   dbo.DecimalQrValue(@ntotal,b.retailtotal) retailtotal, 		  
		   dbo.DecimalQrValue(@nOther,b.upperlimit) upperlimit,  dbo.DecimalQrValue(@nOther,b.lowlimit) lowlimit, 
		   dbo.DecimalQrValue(@nSL,b.Quantity) Quantity,  dbo.DecimalQrValue(@nSL,b.buyOrderQuantity) buyOrderQuantity,			   
		   dbo.DecimalQrValue(@nSL,b.saleOrderQuantity) saleOrderQuantity,  	
		   dbo.DecimalQrValue(@nOther,b.SaleDay) SaleDay,  
		   dbo.DecimalQrValue(@nSL, b.AvgSaleQty)AvgSaleQty, b.StoreDay,
		   dbo.DecimalQrValue(@nOther, b.BackRate)BackRate, b.OutDay,
		   dbo.DecimalQrValue(@nOther, b.BackDay)BackDay,  dbo.DecimalQrValue(@nOther, b.velocity)velocity, 
		   dbo.DecimalQrValue(@nOther, b.wasteRate)wasteRate		   		       
		  
     from  #qrStock03 b      
     inner join  #qrcustomGory cg on b.p_id = cg.p_id                
     inner join  FilterProduct(2) p on b.p_id = p.Product_ID      
     order by p.class_id, p.RowIndex     
     
   return 0
GO
