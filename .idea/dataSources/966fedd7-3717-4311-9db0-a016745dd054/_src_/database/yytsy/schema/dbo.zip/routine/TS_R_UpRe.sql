
/*********************************************************************************************************************************/

/*功 能：用于查询当天24小时内零销商品的数量（Qty），金额（Total）*/
/* 编写日期 ：2007－03－22*/
/* 修改日期 ：           */
/* 编写者  ：           */

/**********************************************************************************************************************************/
/* zhh修改，退货为负数 07.10.10*/

CREATE PROCEDURE [dbo].[TS_R_UpRe]
(
@eClass_id VARCHAR(50), 
@inputman_id VARCHAR(50),
@BeginDate DATETIME,
@EndDate   DATETIME,
@szParid VARCHAR(60),/*列表显示时传递的参数*/
@szListFlag  VARCHAR(1),   /*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
@nYClassid        varchar(100)='',
@nloginEID        int=0,
@nPubPosDataMode  int,  /*0 实时账套、1 独立账套、2 离线账套*/
@bPubOffLine      int   /*分支机构启用离线*/
)
/*WITH ENCRYPTION*/
AS
/*Params Ini begin*/
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/



/*IF @szPClass_ID NOT IN('','%%','000000') AND @szCurrentParentID IN ('','%%','000000') */
/*SELECT @szCurrentParentID=LEFT(@szPClass_ID,LEN(@szPClass_ID) -6)*/

Declare @Companytable INTEGER,@employeestable integer

set @enddate=dateadd(day,1,@enddate)
IF @szParid in ('', '%%') SELECT @szParid='000000'

IF @eClass_id IN ('','000000')  SET @eClass_id='%%' 
ELSE SET @eClass_id = @eClass_id + '%'

IF @inputman_id IN ('','000000')  SET @inputman_id='%%' 
ELSE SET @inputman_id = @inputman_id + '%'

IF @nYClassid IN ('','000000')  SET @nYClassid='%%' 
ELSE SET @nYClassid = @nYClassid + '%'


  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


IF @szListFlag='L'  GOTO ListLeavel /*分级列表*/
IF @szListFlag='A'  GOTO ListAll    /*全部列表*/
IF @szListFlag='P'  GOTO ListPart   /*部分列表*/


ListLeavel:
 
BEGIN
  IF (@nPubPosDataMode<>2) or (@bPubOffLine=1)
  BEGIN
	SELECT a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark, isnull(AccountComment,'') as makearea,
		   a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
	F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
	F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
	F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
	F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
	F3qty=  SUM(case b.datep when 3 then qty else 0 end),
	F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
	F4qty=  SUM(case b.datep when 4 then qty else 0 end),
	F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
	F5qty=  SUM(case b.datep when 5 then qty else 0 end),
	F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
	F6qty=  SUM(case b.datep when 6 then qty else 0 end),
	F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
	F7qty=  SUM(case b.datep when 7 then qty else 0 end),
	F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
	F8qty=  SUM(case b.datep when 8 then qty else 0 end),
	F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
	F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
	F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
	F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
	F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
	F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
	F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
	F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
	F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
	F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
	F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
	F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
	F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
	F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
	F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
	F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
	F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
	F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
	F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
	F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
	F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
	F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
	F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
	F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
	F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
	F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
	F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
	F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
	F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
	F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
	F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
	F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
	F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
	FQTY=ISNULL(SUM(B.QTY),0),
	FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
	retailtotal =ISNULL(SUM(b.retailtotal),0) 
	FROM 
	vw_c_products a LEFT JOIN
	(
	SELECT a.class_id,DATEPART(hh,c.billdate) AS datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
		   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal 
	FROM products a,(select c.billdate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
					   from Retailbillidx c  
						 left join Company  Y  ON Y.Company_id=c.Y_id
						 left join employees e on c.inputman=e.emp_id
					 where c.BillDate BETWEEN @BeginDate AND @EndDate and Billstates=0
					 )c,

		 (select b.bill_id,b.p_id,b.RowE_id,b.quantity,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from Retailbill b
				left join employees e on b.Rowe_id=e.emp_id
		  where aoid in (0,5))b
	WHERE b.bill_id=c.billid 
	AND a.Product_id=b.P_id 
	AND b.RowEClass_id like  @eClass_id
	AND c.inputmanclass_id like @inputman_id
	AND c.Yclass_id like @nYClassid
	AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
	AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
	GROUP BY a.class_id,DATEPART(hh,c.billdate),c.billtype,b.retailtotal
	) b
	ON a.class_id=LEFT(b.class_id,LEN(a.class_id))
	left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家*/
	WHERE a.parent_id=@szParid and deleted=0 and a.product_id<>1
	GROUP BY  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
			 a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5
  END ELSE
  BEGIN
    
	SELECT a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,isnull(f.AccountComment,'') as makearea,
			   a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
		F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
		F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
		F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
		F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
		F3qty=  SUM(case b.datep when 3 then qty else 0 end),
		F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
		F4qty=  SUM(case b.datep when 4 then qty else 0 end),
		F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
		F5qty=  SUM(case b.datep when 5 then qty else 0 end),
		F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
		F6qty=  SUM(case b.datep when 6 then qty else 0 end),
		F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
		F7qty=  SUM(case b.datep when 7 then qty else 0 end),
		F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
		F8qty=  SUM(case b.datep when 8 then qty else 0 end),
		F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
		F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
		F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
		F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
		F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
		F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
		F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
		F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
		F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
		F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
		F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
		F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
		F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
		F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
		F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
		F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
		F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
		F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
		F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
		F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
		F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
		F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
		F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
		F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
		F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
		F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
		F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
		F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
		F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
		F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
		F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
		F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
		F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
		FQTY=ISNULL(SUM(B.QTY),0),
		FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
		retailtotal =ISNULL(SUM(b.retailtotal),0) 
		FROM 
		vw_c_products a LEFT JOIN
		(
		SELECT a.class_id,DATEPART(hh,c.Retaildate) AS datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
			   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal
		FROM products a,(select c.Retaildate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
						   from billidx c  
							 left join Company  Y  ON Y.Company_id=c.Y_id
							 left join employees e on c.inputman=e.emp_id
						 where c.Retaildate BETWEEN @BeginDate AND @EndDate and Billstates=0 and billtype in (12,13)
						 )c,

			 (select b.bill_id,b.p_id,b.RowE_id,b.quantity,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from SaleManageBill b
					left join employees e on b.Rowe_id=e.emp_id
					left join billidx  bi on b.bill_id=bi.billid
			  where aoid in (0,5)
			    and bi.Retaildate BETWEEN @BeginDate AND @EndDate and bi.Billstates=0 and bi.billtype in (12,13)
			  )b
		WHERE b.bill_id=c.billid 
		AND a.Product_id=b.P_id 
		AND b.RowEClass_id like  @eClass_id
		AND c.inputmanclass_id like @inputman_id
		AND c.Yclass_id like @nYClassid
		AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
		AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
		GROUP BY a.class_id,DATEPART(hh,c.Retaildate),c.billtype,b.retailtotal
		) b
		ON a.class_id=LEFT(b.class_id,LEN(a.class_id))
		left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家*/
		WHERE a.parent_id=@szParid and deleted=0 and a.product_id<>1
		GROUP BY  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
				 a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5
  END
END
RETURN


ListAll:

BEGIN
  IF (@nPubPosDataMode<>2) or (@bPubOffLine=1)
  BEGIN
	SELECT a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,isnull(f.AccountComment,'') as makearea,
		   a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
	F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
	F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
	F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
	F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
	F3qty=  SUM(case b.datep when 3 then qty else 0 end),
	F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
	F4qty=  SUM(case b.datep when 4 then qty else 0 end),
	F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
	F5qty=  SUM(case b.datep when 5 then qty else 0 end),
	F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
	F6qty=  SUM(case b.datep when 6 then qty else 0 end),
	F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
	F7qty=  SUM(case b.datep when 7 then qty else 0 end),
	F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
	F8qty=  SUM(case b.datep when 8 then qty else 0 end),
	F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
	F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
	F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
	F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
	F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
	F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
	F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
	F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
	F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
	F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
	F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
	F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
	F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
	F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
	F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
	F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
	F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
	F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
	F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
	F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
	F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
	F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
	F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
	F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
	F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
	F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
	F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
	F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
	F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
	F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
	F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
	F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
	F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
	FQTY=ISNULL(SUM(B.QTY),0),
	FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
	retailtotal =ISNULL(SUM(b.retailtotal),0) 
	FROM 
	vw_c_products a LEFT JOIN
	(
	SELECT b.p_id,datepart(hh,c.billdate) as datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
		   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal
	/*sum(b.quantity) qty,sum(b.taxtotal) taxtotal*/
	FROM products a,(select c.billdate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
					   from Retailbillidx c  
						 left join Company  Y  ON Y.Company_id=c.Y_id
						 left join employees e on c.inputman=e.emp_id
					 where c.BillDate BETWEEN @BeginDate AND @EndDate and Billstates=0
					 )c,

		 (select b.bill_id,b.p_id,b.RowE_id,b.quantity,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from Retailbill b
				left join employees e on b.Rowe_id=e.emp_id
		  where aoid in (0,5))b

	WHERE b.bill_id=c.billid 
	AND a.product_id=b.p_id 
	AND b.RowEClass_id like  @eClass_id
	AND inputmanclass_id like @inputman_id
	AND c.Yclass_id like @nYClassid
	AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
	AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
	GROUP BY p_id,datepart(hh,c.billdate),c.billtype,b.retailtotal
	) b
	ON a.product_id=b.p_id
	left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家*/
	where a.child_number=0 and a.product_id<>1 and deleted=0
	GROUP BY a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
			a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5
  END ELSE
  BEGIN
    
		SELECT a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,isnull(f.AccountComment,'') as makearea,
			   a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
		F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
		F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
		F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
		F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
		F3qty=  SUM(case b.datep when 3 then qty else 0 end),
		F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
		F4qty=  SUM(case b.datep when 4 then qty else 0 end),
		F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
		F5qty=  SUM(case b.datep when 5 then qty else 0 end),
		F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
		F6qty=  SUM(case b.datep when 6 then qty else 0 end),
		F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
		F7qty=  SUM(case b.datep when 7 then qty else 0 end),
		F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
		F8qty=  SUM(case b.datep when 8 then qty else 0 end),
		F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
		F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
		F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
		F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
		F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
		F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
		F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
		F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
		F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
		F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
		F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
		F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
		F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
		F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
		F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
		F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
		F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
		F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
		F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
		F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
		F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
		F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
		F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
		F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
		F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
		F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
		F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
		F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
		F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
		F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
		F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
		F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
		F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
		FQTY=ISNULL(SUM(B.QTY),0),
		FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
		retailtotal =ISNULL(SUM(b.retailtotal),0) 
		FROM 
		vw_c_products a LEFT JOIN
		(
		SELECT b.p_id,datepart(hh,c.Retaildate) as datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
			   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal
		/*sum(b.quantity) qty,sum(b.taxtotal) taxtotal*/
		FROM products a,(select c.Retaildate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
						   from BillIDX c  
							 left join Company  Y  ON Y.Company_id=c.Y_id
							 left join employees e on c.inputman=e.emp_id
						 where c.Retaildate BETWEEN @BeginDate AND @EndDate and Billstates=0 and c.BillType in (12,13)
						 )c,

			 (select b.bill_id,b.p_id,b.quantity,b.RowE_id,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from SaleManageBill b
					left join employees e on b.Rowe_id=e.emp_id
					left join BillIDX bi on b.bill_id=bi.billid 			
			  where aoid in (0,5)
			    and bi.Retaildate BETWEEN @BeginDate AND @EndDate and Billstates=0 and bi.BillType in (12,13)
			  )b

		WHERE b.bill_id=c.billid 
		AND a.product_id=b.p_id 
		AND b.RowEClass_id like  @eClass_id
		AND inputmanclass_id like @inputman_id
		AND c.Yclass_id like @nYClassid
		AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
		AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
		GROUP BY p_id,datepart(hh,c.Retaildate),c.billtype,b.retailtotal
		) b
		ON a.product_id=b.p_id
		left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家*/
		where a.child_number=0 and a.product_id<>1 and deleted=0
		GROUP BY a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
				a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5
			
  END
END
RETURN


ListPart:

BEGIN
  IF (@nPubPosDataMode<>2) or (@bPubOffLine=1)
  BEGIN
	SELECT  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,isnull(f.AccountComment,'') as makearea,
			a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
	F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
	F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
	F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
	F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
	F3qty=  SUM(case b.datep when 3 then qty else 0 end),
	F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
	F4qty=  SUM(case b.datep when 4 then qty else 0 end),
	F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
	F5qty=  SUM(case b.datep when 5 then qty else 0 end),
	F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
	F6qty=  SUM(case b.datep when 6 then qty else 0 end),
	F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
	F7qty=  SUM(case b.datep when 7 then qty else 0 end),
	F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
	F8qty=  SUM(case b.datep when 8 then qty else 0 end),
	F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
	F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
	F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
	F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
	F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
	F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
	F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
	F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
	F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
	F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
	F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
	F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
	F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
	F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
	F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
	F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
	F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
	F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
	F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
	F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
	F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
	F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
	F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
	F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
	F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
	F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
	F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
	F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
	F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
	F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
	F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
	F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
	F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
	FQTY=ISNULL(SUM(B.QTY),0),
	FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
	retailtotal =ISNULL(SUM(b.retailtotal),0) 
	FROM 
	vw_c_products a LEFT JOIN
	(
	SELECT b.p_id,datepart(hh,c.billdate) as datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
		   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal
	FROM  products a,(select c.billdate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
					   from Retailbillidx c  
						 left join Company  Y  ON Y.Company_id=c.Y_id
						 left join employees e on c.inputman=e.emp_id
					 where c.BillDate BETWEEN @BeginDate AND @EndDate and Billstates=0
					 )c,

		 (select b.bill_id,b.p_id,b.quantity,b.RowE_id,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from Retailbill b
				left join employees e on b.Rowe_id=e.emp_id
		  where aoid in (0,5))b
	WHERE b.bill_id=c.billid 
	AND a.product_id=b.p_id 
	AND b.RowEClass_id like  @eClass_id
	AND inputmanclass_id like @inputman_id
	AND c.Yclass_id like @nYClassid
	AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
	AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
	GROUP BY p_id,datepart(hh,c.billdate),c.billtype,b.retailtotal
	) b
	ON a.product_id=b.p_id
	left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家	*/
	WHERE LEFT(a.class_id,LEN(@szParid))=@szParid and child_number=0 and deleted=0 and product_id<>1
	GROUP BY  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
			  a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5
  END ELSE
  BEGIN
   
		SELECT  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,isnull(f.AccountComment,'') as makearea,
				a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5,
		F1qty=  SUM(CASE b.datep when 1 then qty else 0 end),
		F1total=SUM(CASE b.datep when 1 then taxtotal else 0 end),
		F2qty=  SUM(CASE b.datep when 2 then qty else 0 end),
		F2total=SUM(CASE b.datep when 2 then taxtotal else 0 end),
		F3qty=  SUM(case b.datep when 3 then qty else 0 end),
		F3total=SUM(case b.datep when 3 then taxtotal else 0 end),
		F4qty=  SUM(case b.datep when 4 then qty else 0 end),
		F4total=SUM(case b.datep when 4 then taxtotal else 0 end),
		F5qty=  SUM(case b.datep when 5 then qty else 0 end),
		F5total=SUM(case b.datep when 5 then taxtotal else 0 end),
		F6qty=  SUM(case b.datep when 6 then qty else 0 end),
		F6total=SUM(case b.datep when 6 then taxtotal else 0 end),
		F7qty=  SUM(case b.datep when 7 then qty else 0 end),
		F7total=SUM(case b.datep when 7 then taxtotal else 0 end),
		F8qty=  SUM(case b.datep when 8 then qty else 0 end),
		F8total=SUM(case b.datep when 8 then taxtotal else 0 end),
		F9qty=  SUM(case b.datep when 9 then qty else 0 end) ,
		F9total=SUM(case b.datep when 9 then taxtotal else 0 end), 
		F10qty= SUM(case b.datep when 10 then qty else 0 end) ,
		F10total=SUM(case b.datep when 10 then taxtotal else 0 end), 
		F11qty=  SUM(case b.datep when 11 then qty else 0 end) ,
		F11total=SUM(case b.datep when 11 then taxtotal else 0 end), 
		F12qty=  SUM(case b.datep when 12 then qty else 0 end ),
		F12total=SUM(case b.datep when 12 then taxtotal else 0 end), 
		F13qty=  SUM(case b.datep when 13 then qty else 0 end) ,
		F13total=SUM(case b.datep when 13 then taxtotal else 0 end), 
		F14qty=  SUM(case b.datep when 14 then qty else 0 end) ,
		F14total=SUM(case b.datep when 14 then taxtotal else 0 end) ,
		F15qty=  SUM(case b.datep when 15 then qty else 0 end) ,
		F15total=SUM(case b.datep when 15 then taxtotal else 0 end) ,
		F16qty=  SUM(case b.datep when 16 then qty else 0 end) ,
		F16total=SUM(case b.datep when 16 then taxtotal else 0 end) ,
		F17qty=  SUM(case b.datep when 17 then qty else 0 end) ,
		F17total=SUM(case b.datep when 17 then taxtotal else 0 end) ,
		F18qty=  SUM(case b.datep when 18 then qty else 0 end) ,
		F18total=SUM(case b.datep when 18 then taxtotal else 0 end),
		F19qty=  SUM(CASE b.datep WHEN 19 THEN qty ELSE 0 END),
		F19total=SUM(CASE b.datep WHEN 19 THEN taxtotal ELSE 0 END),
		F20qty=  SUM(CASE b.datep WHEN 20 THEN qty ELSE 0 END),
		F20total=SUM(CASE b.datep WHEN 20 THEN taxtotal ELSE 0 END),
		F21qty=  SUM(CASE b.datep WHEN 21 THEN qty ELSE 0 END),
		F21total=SUM(CASE b.datep WHEN 21 THEN taxtotal ELSE 0 END),
		F22qty=  SUM(CASE b.datep WHEN 22 THEN qty ELSE 0 END),
		F22total=SUM(CASE b.datep WHEN 22 THEN taxtotal ELSE 0 END),
		F23qty=  SUM(CASE b.datep WHEN 23 THEN qty ELSE 0 END),
		F23total=SUM(CASE b.datep WHEN 23 THEN taxtotal ELSE 0 END),
		F24qty=  SUM(CASE b.datep WHEN 0 THEN qty ELSE 0 END),
		F24total=SUM(CASE b.datep WHEN 0 THEN taxtotal ELSE 0 END),
		FQTY=ISNULL(SUM(B.QTY),0),
		FTOTAL=ISNULL(SUM(B.TAXTOTAL),0),
		retailtotal =ISNULL(SUM(b.retailtotal),0) 
		FROM 
		vw_c_products a LEFT JOIN
		(
		SELECT b.p_id,datepart(hh,c.retaildate) as datep,sum(case c.billtype when 12 then b.quantity when 13 then -b.quantity else 0 end) qty,sum(case c.billtype when 12 then b.taxtotal when 13 then -b.taxtotal else 0 end) taxtotal,
			   SUM(CASE c.billtype when 12 then b.retailtotal  when 13 then  -b.retailtotal ELSE  0 END) as retailtotal
		FROM  products a,(select c.Retaildate,c.billid,c.billtype,c.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(e.Class_id,'')InputmanClass_id
						   from BillIdx c  
							 left join Company  Y  ON Y.Company_id=c.Y_id
							 left join employees e on c.inputman=e.emp_id
						 where c.Retaildate BETWEEN @BeginDate AND @EndDate and Billstates=0 and billtype in(12,13)
						 )c,

			 (select b.bill_id,b.p_id,b.quantity,b.RowE_id,b.retailtotal,b.taxtotal,b.Y_id,isnull(E.class_id,'')RowEClass_id from salemanagebill b
					left join employees e on b.Rowe_id=e.emp_id
					left join BillIdx bi on b.bill_id=bi.billid 
			  where aoid in (0,5)
			    and bi.Retaildate BETWEEN @BeginDate AND @EndDate and Billstates=0 and bi.BillType in (12,13)
			  )b
		WHERE b.bill_id=c.billid 
		AND a.product_id=b.p_id 
		AND b.RowEClass_id like  @eClass_id
		AND inputmanclass_id like @inputman_id
		AND c.Yclass_id like @nYClassid
		AND ((@employeestable=0) OR (b.RowE_id in (select [id] from #employeestable)))
		AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
		GROUP BY p_id,datepart(hh,c.Retaildate),c.billtype,b.retailtotal
		) b
		ON a.product_id=b.p_id
		left join BaseFactory f on f.CommID = a.factoryc_id   /*Wusj.2017-06-12 Tfs48570 直接取商品资料的生产厂家		*/
		WHERE LEFT(a.class_id,LEN(@szParid))=@szParid and child_number=0 and deleted=0 and product_id<>1
		GROUP BY  a.product_id,a.class_id,a.child_number,a.[name],a.alias,a.standard,a.modal,a.permitcode,a.trademark,f.AccountComment,
				  a.comment,a.pinyin,a.TaxRate,a.unitname1,a.code,a.medtype,a.custompro1,a.custompro2,a.custompro3,a.custompro4,a.custompro5  
	
	  
  END		  
END
	RETURN 0
GO
