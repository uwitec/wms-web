CREATE PROCEDURE Ts_K_ChangevtLogisticsStates(
	@Send_id INT,		/*物流单据号*/
	@Transportation_States INT,  /*状态*/
	@Time DATETIME,		/*时间 */
	@IsSelf INT,  
	@szBillid varchar(500)  /*明细单billid的字符组*/
	/*@Bill_Id INT			--明细单id*/
	)				
AS
BEGIN
	IF @Transportation_States = 1
	BEGIN
		UPDATE Sendidx SET Transportation_States = 1/*, SendTime = @Time*/ WHERE Send_id = @Send_id
		UPDATE Sendmangebill SET Transportation_States = 1 WHERE sendid = @Send_id
		RETURN @@ROWCOUNT
	END
	ELSE
	IF @Transportation_States = 2
	BEGIN
		DECLARE @ArriveStation DATETIME, @ArriveCustomer DATETIME
		SET @ArriveStation = @Time
		SET @ArriveCustomer = @Time
		/*
		IF @IsSelf < 0 --小于零自己运输，大于等于零第三方承运
			SET @ArriveCustomer = @Time	
		ELSE
			SET @ArriveStation = @Time
		*/
		/**/
		if @szBillid <> ''
		begin
			DECLARE @BillType INT, @CId INT
			DECLARE @DeviceTemperature_End NUMERIC(25,8), @ConditionTemperature_End NUMERIC(25,8), 
					@AffirmTemperature NUMERIC(25,8), @ProcessTemperature varchar(200)
			DECLARE @Signfor VARCHAR(30), @SignforNote VARCHAR(100), @Comment VARCHAR(100)  
			      
			/*取出保存在主表下的抵达信息*/
			SELECT TOP 1/* @BillType = ISNULL(b.billtype, 0), @CId = ISNULL(b.c_id, 0),*/
				   @DeviceTemperature_End = DeviceTemperature_End, @ConditionTemperature_End = ConditionTemperature_End, 
				   @AffirmTemperature = AffirmTemperature, @ProcessTemperature = ProcessTemperature,
				   @Signfor = Signfor, @SignforNote = SignforNote, @Comment = Comment 			
				FROM Sendmangebill s /*INNER JOIN billidx b ON s.billid = b.billid */
			WHERE s.sendid = @Send_id AND s.billid in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@szBillid))
			/*select DeviceTemperature_Begin,ConditionTemperature_Begin from Sendmangebill*/
			/*更新一起抵达的*/
			UPDATE Sendmangebill SET /*DeviceTemperature_End = @DeviceTemperature_End, 
									 ConditionTemperature_End = @ConditionTemperature_End,
									 AffirmTemperature = @AffirmTemperature, 
									 ProcessTemperature = @ProcessTemperature, Signfor = @Signfor,
									 SignforNote = @SignforNote, Comment = @Comment, */
									 ArriveCustomer = @ArriveCustomer, ArriveStation = @ArriveStation,
									 Transportation_States= 2 
			WHERE sm_id IN (SELECT s.sm_id
							  FROM Sendmangebill s INNER JOIN GSPbillidx g ON s.billid = g.Gspbillid 
							WHERE s.sendid = @Send_id AND g.BillType = 551 AND 
								  s.billid in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@szBillid))
								  /*g.C_id = @CId AND s.billid = @Bill_Id*/
			)
		end
		else
		begin
		  update Sendmangebill set Transportation_States= 2
		  
		  where sendid = @Send_id
		end
		
		IF NOT EXISTS(SELECT 1 FROM Sendmangebill s WHERE s.sendid = @Send_id AND s.Transportation_States <> 2)
	    BEGIN
	    	/*明细全部抵达更新单据主表抵达标识*/
	    	UPDATE Sendidx SET Transportation_States = 2,ArriveCustomer = @Time, ArriveStation = @Time  WHERE Send_id = @Send_id   /*把最后一张单据抵达的时间作为物流单抵达时间*/
	    	RETURN @@ROWCOUNT
	    END
		RETURN 0
	END
	ELSE
		RETURN -1
END
GO
