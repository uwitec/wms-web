






create proc ts_c_viptotal
as
set nocount on

select * into #cardtemp
from vipdetaildts

delete #cardtemp from vipdetail a,#cardtemp b where a.guid=b.guid

begin tran vip
/*----*/

DECLARE @ID int
DECLARE tmp_Cursor CURSOR FOR
SELECT [ID] FROM #cardtemp
OPEN  tmp_Cursor
FETCH NEXT FROM tmp_Cursor INTO  @ID
WHILE @@FETCH_STATUS = 0
BEGIN
    
   insert vipdetail(billid,billdate,cardid,p_id,pos_id,quantity,price,total,guid,costtotal,discounttotal,aoid)
   select billid,billdate,cardid,p_id,pos_id,quantity,price,total,guid,costtotal,discounttotal,aoid
   from #cardtemp  where id=@ID
   FETCH NEXT FROM tmp_Cursor INTO  @ID
END

CLOSE tmp_Cursor
DEALLOCATE tmp_Cursor
/*------*/
/*
   if @dBaseTotal<>0
   begin
      update membercard 
      set buytotal=buytotal+b.total,integral=(m.intergraltotal+b.total)/@dBAseTotal,SaveTotal=SaveTotal-b.dTotal 
      from membercard m,(select cardid,sum(total) total from #cardtemp group by cardid) b
      where m.cardid=b.cardid
   end else
   begin
      update membercard 
      set buytotal=buytotal+b.total,SaveTotal=SaveTotal-b.dTotal 
      from membercard m,(select cardid,sum(total) total from #cardtemp group by cardid) b
      where m.cardid=b.cardid
   end
*/
commit tran vip
	return 0
error:
	rollback tran  vip
	return -1 




/*
  declare @nCardId int,@dTotal NUMERIC(25,8)

	declare @dBaseTotal NUMERIC(25,8)


	select @dBaseTotal=isnull(sysvalue,0) from sysconfig where [sysname]='VIPIntegral'

	declare viptotal cursor for
	select cardid,sum(total) as total from #cardtemp
  group by cardid

	open viptotal

begin tran vip

  insert vipdetail(billid,billdate,cardid,p_id,pos_id,quantity,price,total,guid,costtotal,discounttotal)
  select billid,billdate,cardid,p_id,pos_id,quantity,price,total,guid,costtotal,discounttotal
  from #cardtemp

	
	fetch next from viptotal into @nCardId,@dTotal
	while @@FETCH_STATUS=0	
	begin
		if exists(select cardid from membercard where cardid=@nCardId)
		begin
			update membercard set buytotal=buytotal+@dTotal,intergraltotal=intergraltotal+@dTotal,SaveTotal=SaveTotal-@dTotal where cardid=@nCardId
			if @@rowcount=0  goto error
			if @DbaseTotal<>0 
			begin
				update membercard set  integral=intergraltotal/@dBAseTotal where cardid=@nCardid
				if @@rowcount=0  goto error
			end
		end
		fetch next from viptotal into @nCardId,@dTotal
	end	

commit tran vip
	close viptotal
	deallocate viptotal
	return 0
error:
	close viptotal
	deallocate viptotal
	rollback tran  vip
	return -1 


*/
GO
