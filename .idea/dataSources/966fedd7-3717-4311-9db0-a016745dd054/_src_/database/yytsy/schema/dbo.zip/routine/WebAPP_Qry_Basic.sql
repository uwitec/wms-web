/**************************************************************
app基本资料查询选择
**************************************************************/
create proc WebAPP_Qry_Basic
(
  @intuserid  int,
  @chvparams  varchar(400)='',
  @retmessage varchar(200) out
)
--$encode$--
as

select @retmessage = '操作成功'
--解析扩展参数
declare @datatype varchar(60)
declare @parid varchar(60)
declare @value varchar(60)
declare @extfilter varchar(1000)
declare @sqlscript varchar(8000)

declare @vipcode varchar(30),
        @vippass varchar(30),
        @serial_number varchar(30),
        @classid varchar(60),
        @basicname varchar(60),
        @s_id INT,
        @y_id INT,
        @c_id INT,
        @c_type varchar(30),
        @barcode varchar(100),--条码
        @billtype int,--单据类型可以根据此条件来返回不同单据需要的不同会计凭证信息
                      --服装中销售订单类型为14
        @loadtype varchar(2)--基本资料加载类型：a加载父节点返回两张表b加载子节点(滚动加载)c进行精确条码查询只有商品支持

select @parid = dbo.webapp_get_param(@chvparams, 'parid', default, default)
select @value = dbo.webapp_get_param(@chvparams, 'value', default, default)
select @datatype = upper(dbo.webapp_get_param(@chvparams, 'datatype', default, default))
select @vipcode  = dbo.webapp_get_param(@chvparams, 'vipcode', default, default)
select @vippass  = dbo.webapp_get_param(@chvparams, 'vippass', default, default)
--select @serial_number  = dbo.webapp_get_param(@chvparams, 'serial_number', default, default)
select @serial_number  = dbo.webapp_get_param(@chvparams, 'basiccode', default, default)
select @classid  = dbo.webapp_get_param(@chvparams, 'classid', default, default)
select @basicname  = dbo.webapp_get_param(@chvparams, 'basicname', default, default)
select @loadtype  = dbo.webapp_get_param(@chvparams, 'loadtype', default, default)
select @barcode  = dbo.webapp_get_param(@chvparams, 'barcode', default, default)
select @billtype  = dbo.webapp_get_param(@chvparams, 'billtype', default, default)
select @s_id  = dbo.webapp_get_param(@chvparams, 's_id', default, default)
select @y_id  = dbo.webapp_get_param(@chvparams, 'y_id', default, default)
select @c_id  = dbo.webapp_get_param(@chvparams, 'c_id', default, default)
select @c_type  = dbo.webapp_get_param(@chvparams, 'c_type', default, default)
select @billtype=isnull(@billtype,0)

--最近进价权限控制是采用 成本价查看权限
  declare @permission int
  select @permission=permission 
    from WebAPP_UserRight
   where UserID = @intuserid
     and Data_id = (select MenuID from TeenySoftMaster.dbo.WebAPP_Menus where MenuCode = 'sp_costprice') --库存成本查看权限
----     
--授权begin
declare @emp_id int 
select @emp_id = e_id from Users where user_id = @intuserid
--end
if (@datatype=upper('products')) --商品选择
      begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin        
			select c.product_id as id, class_id as classid,serial_number as code, [name] as NAME,
			--CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			CASE WHEN len(class_id)=6 then 0 WHEN len(class_id)=12 then 1 ELSE 2 END AS child
			from products c 
			where product_id>1 and len(class_id)<=18 --and stopuse=0 
			and [deleted]=0 and child_number>0 --and child_count>0
			--AND c.[property]=0
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
    		declare @CostMethod int,@UseSameCostMethod int,@AverBatchNoAndlocation int
    		select @CostMethod=s.sysvalue from sysconfig s where s.sysname='CostMethod'
    		select @UseSameCostMethod=s.sysvalue from sysconfig s where s.sysname='UseSameCostMethod'
    		select @AverBatchNoAndlocation=s.sysvalue from sysconfig s where s.sysname='AverBatchNoAndlocation'
    		
    	    if exists(select 1 from tempdb.dbo.sysobjects where id=OBJECT_ID('tempdb.dbo.#tmpprice')) drop table #tmpprice
    	    create table #tmpprice
    	    (p_id int,
    	     unit_id int,
    	     price numeric(18,4)
    	    )
    	    
    	    if @billtype in (14,10,11)
    	    begin
    	      insert into #tmpprice(p_id,unit_id,price)
    	      select p_id,unit_id,saleprice from salepricehis where c_id=@c_id --AND next_c_id=0
    	    end else
    	    if @billtype in (22,20,21)
    	    begin
    	      insert into #tmpprice(p_id,unit_id,price)
    	      select p_id,unit_id,buyprice from buypricehis where c_id=@c_id --AND next_c_id=0
    	    end
    	    declare @pricemode int
    	    select @pricemode = pricemode from clients where client_id=@c_id
    	   -- if @billtype in (20,21,22) set @pricemode = 0
--查询商品
    	   
    	    --select p_id,unit_id,saleprice from salepricehis where c_id=@c_id
    		SELECT distinct product_id as id, serial_number as code, p.[name] as name ,class_id as classid,
                        u.[name] AS unit,--单位名称
                        unit1_id as unitid,
			isnull(modal,'') AS type,--商品类型
			isnull(p.standard,'') AS standard,--规格型号
			isnull(p.makearea,'') as makearea,--产地
 			ISNULL(p.Factory, '') AS Factory, --YYT生产厂家 
 			ISNULL(p.permitcode, '') AS permitcode, --YYT批准文号
 			'' AS photo, --图片
			--c.retailprice AS price,--零售价  --基本资料显示用
			--0 AS defaultprice,--默认价格  --基本资料显示用
			case when ISNULL(t.price,0.0)>0.0 then ISNULL(t.price,0.0)
			     else (case when @pricemode=0 then 0.0
			                when @pricemode=1 then c.retailprice
			                when @pricemode=2 then c.price1
			                when @pricemode=3 then c.price2
			                when @pricemode=4 then c.price3
			                when @pricemode=5 then c.price4  --会员价
			                when @pricemode=6 then c.gpPrice --价格4
			                when @pricemode=7 then c.glPrice --价格5
                            when @pricemode=8 then c.specialPrice --特价
                            when @pricemode=9 then (case @permission when 0 then 0 when 1 then c.recprice end ) --最近进价                           		                
			                else 0.0 end)			          
			     end as defaultprice,    
				1 AS discount,--默认折扣
				(case when ISNULL(t.price,0.0)>0.0 then ISNULL(t.price,0.0)
			     else (case when @pricemode=0 then 0.0
			                when @pricemode=1 then c.retailprice
			                when @pricemode=2 then c.price1
			                when @pricemode=3 then c.price2
			                when @pricemode=4 then c.price3
			                when @pricemode=5 then c.price4  --会员价
			                when @pricemode=6 then c.gpPrice --价格4
			                when @pricemode=7 then c.glPrice --价格5
                            when @pricemode=8 then c.specialPrice --特价
                            when @pricemode=9 then (case @permission when 0 then 0 when 1 then c.recprice end ) --最近进价                           		                
			                else 0.0 end)			          
			     end) * 1 AS discountprice ,--折后价 
			ISNULL(s.costprice,0) AS costprice,--成本单价
			c.retailprice AS retailprice,--零售价此处必须返回两个相同字段  --单据选择价格用
			--c.recprice AS recprice,--最近进价
			case @permission when 0 then 0 when 1 then c.recprice end as recprice,--最近进价 (权限控制)
			c.specialprice AS specialprice,--特价
			c.lowprice AS lowprice,--最低价
			c.lowprice AS retaillowprice,--最低零售价
			0.0 AS price6,--售价6
			c.glPrice AS price5,--售价5
			c.gpPrice AS price4,--售价4
			c.price4 AS vipprice,--会员价
			c.price3,--售价3
			c.price2,--售价2
			c.price1--售价1
			,ISNULL(s.storage,0) AS storage--库存
			,p.costmethod,
			case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
			else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
			1 AS child             
                  from products p
                  join unit u on p.unit1_id=u.unit_id   
                  join price c on p.product_id=c.p_id and unittype=1
                  left join #tmpprice t on p.product_id=t.p_id and p.unit1_id=t.unit_id
                  --left join medtype  m on p.medtype=m.mt_id                  
    		      LEFT JOIN barcode pb ON pb.P_ID=c.p_id 
    			  LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,avg(s.costprice) AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) s ON s.p_id=p.product_id
    		where product_id>1 and p.child_number=0 				
			  and ((@basicname='' or p.[name] like '%'+@basicname+'%') or 
                  (@serial_number='' or serial_number like '%'+@serial_number+'%') or 
                  (@serial_number='' or p.pinyin like '%'+@serial_number+'%')
			   or (@barcode='' or pb.BarCode like '%'+@barcode+'%') 
			   or (@barcode='' or p.serial_number like '%'+@barcode+'%')         
				)
			 and (@classid='' or p.class_id like ''+@classid+'%')
			 --商品停用分为三种状态，2停止使用、4停止销售、3停止采购
			 and (@billtype in (0,1010) or (@billtype in(10,11,14) AND p.deleted in (0,3)) or (@billtype in(20,21,22) AND p.deleted in (0,4))
				 )	and p.deleted <> 1 	
          order by product_id
    	END
    	ELSE IF upper(@loadtype)='C'--常规加载
    	BEGIN
    		select distinct p.product_id as id, serial_number as code, p.[name] as name ,
                        u.[name] AS unit,--单位名称
                        unit1_id as unitid,
			isnull(modal,'') AS type,--商品类型
			isnull(p.standard,'') AS standard,--规格型号
 			ISNULL(p.Factory, '') AS Factory, --YYT生产厂家 
 			ISNULL(p.permitcode, '') AS permitcode, --YYT批准文号
 			'' AS photo, --图片
			--c.retailprice AS price,--零售价  --基本资料显示用
			0 AS defaultprice,--默认价格  --基本资料显示用
				1 AS discount,--默认折扣
			0 AS discountprice ,--折后价 
			ISNULL(s.costprice,0) AS costprice,--成本单价
			c.retailprice AS retailprice,--零售价此处必须返回两个相同字段  --单据选择价格用
			--c.recprice AS recprice,--最近进价
			case @permission when 0 then 0 when 1 then c.recprice end as recprice,--最近进价 (权限控制)
			c.specialprice AS specialprice,--特价
			c.lowprice AS lowprice,--最低价
			c.lowprice AS retaillowprice,--最低零售价
			0.0 AS price6,--售价6
			0.0 AS price5,--售价5
			0.0 AS price4,--售价4
			c.price4 AS vipprice,--会员价
			c.price3,--售价3
			c.price2,--售价2
			c.price1--售价1
			,ISNULL(s.storage,0) AS storage--库存
			,p.costmethod                 
                 from products p
                  join unit u on p.unit1_id=u.unit_id   
                  join price c on p.product_id=c.p_id and unittype=1
                  --left join medtype  m on p.medtype=m.mt_id                  
    		      LEFT JOIN barcode pb ON pb.P_ID=c.p_id 
			      LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,avg(s.costprice) AS costprice FROM Storehouse s where s.s_id=@s_id  GROUP BY s.p_id) s ON s.p_id=p.product_id
    		where product_id>1 AND p.child_number=0    
			AND (@barcode='' or pb.BarCode like '%'+@barcode+'%') 
			and (@barcode='' or p.serial_number like '%'+@barcode+'%')
			 --商品停用分为三种状态，2停止使用、4停止销售、3停止采购
			 and (@billtype in (0,1010) or (@billtype in(10,11,14) AND p.deleted in (0,3)) or (@billtype in(20,21,22) AND p.deleted in (0,4))
				 )					 			
    	END
    end
	--select product_id as _id, serial_number as _code, name as _name from products where product_id>1
    else if (@datatype=upper('clients')) --往来单位选择
    begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select client_id as id, class_id as classid,serial_number as code, name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child from clients 
			where client_id>1 and len(class_id)<=12 --and stopuse=0 
			and [deleted]=0 and child_number>0-- and child_count>0
			and client_id in (select client_id from dbo.AuthorizeClients(@emp_id))
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
			-- --查询e_id
			--declare @e_id int
			--select @e_id=e_id from users where user_id=@intuserid
			
    		select client_id as id, serial_number as code, name as name,c.address as adress,0 as posID,c.class_id as classid,
    		0 AS csflag 
    		from clients c
    		
			where client_id>1 and child_number=0 
             and c.[deleted]=0
			 and ((@basicname='' or c.[name] like '%'+@basicname+'%') or 
                  (@serial_number='' or c.serial_number like '%'+@serial_number+'%') or 
                  (@serial_number='' or c.pinyin like '%'+@serial_number+'%'))
			 and (@classid='' or c.class_id like ''+@classid+'%')
			 and (@billtype=0 or c.deleted<>2)--开单时停用的往来单位不显示
			 and ((@billtype in (10,11,14) and c.csflag in (0,2)) or (@billtype in (20,21,22) and c.csflag in (1,2))
			      or (@billtype not in (10,11,14,20,21,22)))
			 and client_id in (select client_id from dbo.AuthorizeClients(@emp_id))--做了往来单位授权的，不查询未授权的往来单位
            order by c.client_id
    	end
    end
else if (@datatype=upper('company')) --机构|门店
       begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select c.c_id as id, class_id as classid,c_code as code, c_name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			  from WebAPP_VW_Clients c 
			where c_id=0 and len(class_id)<=12 and c_type=0 --and stopuse=0 
			and [deleted]=0 and c_code>0 --and child_count>0
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
   
			SELECT c.company_id AS id, c.serial_number AS code, c.name, c.company_id AS POSID
			  FROM company c 
			WHERE c.[deleted] = 0 AND c.child_number = 0 AND
			      (c.serial_number LIKE '%'+@basicname+'%' OR c.name LIKE '%'+@basicname+'%' OR c.PinYin LIKE '%'+@basicname+'%')
			
    	end
	
	END
else if (@datatype=upper('storage')) --仓库选择
    begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select c.storage_id as id, class_id as classid,serial_number as code, name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			from storages c 
			where storage_id>1 and len(class_id)<=12
			and [deleted]=0 and child_number>0 --and child_count>0
			and c.storage_id in (select storage_id from dbo.AuthorizeStorage(@emp_id))
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
    		select storage_id as id, serial_number as code, name as name from storages 
			where storage_id>1 and child_number=0 
			--and child_count=0 
			and [deleted]=0
			and ((@basicname='' or [name] like '%'+@basicname+'%') or 
                             (@serial_number='' or serial_number like '%'+@serial_number+'%') or 
                             (@serial_number='' or pinyin like '%'+@serial_number+'%'))
			and (@classid='' or class_id like ''+@classid+'%')
			and storage_id in (select storage_id from dbo.AuthorizeStorage(@emp_id))
                        order by storage_id
    	end
    end
	--select storage_id as _id, serial_number as _code, name as _name from storages where storage_id>1
else if (@datatype=upper('department')) --部门选择
     begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select c.departmentid as id, '000000' as classid,serial_number as code, name as name,
			0 AS child
			from department c 
			where departmentid=0 
			and [deleted]=0
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
    		select departmentid as id, serial_number as code, name as name from department 
			where departmentid>0 
             and [deleted]=0
			 and ((@basicname='' or [name] like '%'+@basicname+'%') or 
                             (@serial_number='' or serial_number like '%'+@serial_number+'%'))
             order by departmentid
           
    	end
    end                             
	--select department_id as _id, serial_number as _code, name as _name from department where department_id>1
else if (@datatype=upper('employees')) --职员选择
    begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select c.emp_id as id, class_id as classid,serial_number as code, name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			from employees c 
			where emp_id>1 and len(class_id)<=12  --and stopuse=0
			and [deleted]=0 and child_number>0 --and child_count>0
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
    		select emp_id as id, serial_number as code, name as name from employees 
			where emp_id>1 and child_number=0 
			--and child_count=0 
			and [deleted]=0  --and stopuse=0
			and ((@basicname='' or [name] like '%'+@basicname+'%') or 
                             (@serial_number='' or serial_number like '%'+@serial_number+'%') or 
                             (@serial_number='' or pinyin like '%'+@serial_number+'%'))
			and (@classid='' or class_id like ''+@classid+'%')
                        order by emp_id
    	end
    end              
	--select emp_id as _id, serial_number as _code, name as _name from employees where emp_id>1
else if (@datatype=upper('onlineemployee')) --在线职员选择
     begin
        select e.emp_id as _id, e.serial_number as _code, e.name as _name, isnull(d.name,'') as d_name, e.phone,indate,'' as img
        FROM employees  e
         left join users su ON su.e_id=e.emp_id
         left join department d on e.dep_id=d.departmentId
         where e.deleted=0 
           and (@serial_number='' or e.serial_number like '%'+@serial_number+'%' or  e.pinyin like '%'+@serial_number+'%')
           
     end
else if (@datatype=upper('vipcard')) --会员
begin
   select vipcardid as _id ,cardno as _code, name  as _name , remaindermoney --储值余额
    from vipcard 
   where cardno=@vipcode 
     and (cast(loginpass as varchar(30))='tspass' or cast(loginpass as varchar(30))=@vippass)  
end 
else if (@DataType=upper('account')) --银行科目
      BEGIN
    	IF @LoadType='A'--进行基本资料层级关系加载
    	BEGIN
    		--加载一二级表格
			SELECT c.account_id as id, class_id as classid,serial_number as code, name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			FROM account c 
			where account_id>1 AND len(class_id)<=12
			AND  (@BillType=0 OR (class_id LIKE '000001000003' OR class_id LIKE '000001000004%'))--不同产品，可在此处根据单据类型返回会计凭证科目
			AND [deleted]=0 AND child_number>0
    	END
    	ELSE IF @LoadType='B'--常规加载
    	BEGIN
    		select account_id as id, serial_number as code, name as name from account 
			where account_id>1 AND child_number=0 
			AND [deleted]=0  
			AND  (@BillType=0 or (class_id LIKE '000001000003' OR class_id LIKE '000001000004%'))
			AND (NAME LIKE '%'+@BasicName+'%' OR serial_number LIKE '%'+@Serial_Number+'%' OR PinYin like '%'+@Serial_Number+'%')
			AND class_id LIKE ''+@Classid+'%' ORDER BY account_id
    	END
    END
  else if (@DataType=upper('banlanceaccount')) --银行科目--T3结算单据使用,结算科目
   select account_id as _id, serial_number as _code,[name] as _name 
    from account where deleted=0 and child_number=0 
     and class_id like '000001000004%' and [name]<>'在线支付' order by class_id
  else if (@DataType=upper('shop')) --门店
   begin
    	if upper(@loadtype)='A'--进行基本资料层级关系加载
    	begin
    		--加载一二级表格
			select c.c_id as id, class_id as classid,c_code as code, c_name as name,
			CASE WHEN len(class_id)=6 then 0 ELSE 1 END AS child
			  from WebAPP_VW_Clients c 
			where c_id=0 and len(class_id)<=12 and c_type=0 --and stopuse=0 
			and [deleted]=0 and c_code>0 --and child_count>0
    	end
    	else if upper(@loadtype)='B'--常规加载
    	begin
   
			SELECT c.company_id AS id, c.serial_number AS code, c.name, c.company_id AS POSID
			  FROM company c 
			WHERE c.[deleted] = 0 AND c.child_number = 0 AND
			      (c.serial_number LIKE '%'+@basicname+'%' OR c.name LIKE '%'+@basicname+'%' OR c.PinYin LIKE '%'+@basicname+'%')
			
    	end
	
	END
  else if(@datatype=upper('unit'))--单位
  begin
	select name,unit_id as id from unit where Deleted =0 
	and (@basicname='' or name like '%'+@basicname+'%')
  end
  --else if(@datatype=upper('pricename'))--价格名称
  --begin
  --select newname as name, case when isnull(fieldname,'')='gpprice' then 'price4' when isnull(fieldname,'')='glprice' then 'price5' when isnull(fieldname,'')='price4' then 'vipprice' else isnull(fieldname,'') end
  --as price from Fieldcfgrec where tablename = 'price'
  --end
GO
