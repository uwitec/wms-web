
/* =============================================*/
/* Author:		XXX*/
/* Create date: 2017-06-02 */
/* Description:	自动生成拣货单,规则为第五条*/
/*  算法主要规则	

1. 优先级
2. 补货优先，先生成移库单
3. 根据复核台限定，分配复核台，优先剩余工作量大的单据，按单据明细算
4. a. 根据承运方式，再根据优先级别找到暂存区，根据客户线路，找到暂存区， 再根据业务类型找到暂存区
   b. 如果复核台限定有暂存区，在限定的暂存区域中查找
   c. 没有启用虚拟暂存区的时候，暂存区只能只用使用一次，必须要等做物流配送单后，解除锁定
   d. 启用虚拟暂存区的时候，暂存区可以分配多次次，不进行锁定，但是需要记录任务量，
      在做物流配送单后减少任务量，优先配送任务量小的暂存区

5. 默认根据库区分单，生成拣货单。
    a. 先计算出整货数量、零货数量
    b. 优先找满足总数量的最小库存的同一仓库，按照整货数量、零货数量对应库区分单，
       b1. 批配货位的原则：按照从少到多的货位进行分配
       b2. 零货不足，优先拆零整货数最少的货位
       b3. 计算零货货位规则和入库规则相同
    c. 同一仓库不能满足时，按照从少到多的库存的仓库进行分配


第一步:在订单审核时候生成拣货单，在拣货单上增加一个状态，用来标识是否已经分配过(可以通过暂存区和复核台字段来判断)
		优先级调度也通过修改订单关联的拣货单来实现
		
第二步:在交领拣货单，波次下发的时候计算暂存区和复核台

*/
/* =============================================*/

CREATE PROCEDURE TS_X_AutoNewPickBill 
	@billid int = 0,		/*订单id */
	@billtype int = 0,		/* 单据类型*/
	@nRet int output		/* 返回值，成功返回0，失败返回-1，错误返回-2*/
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @nSmbId INT
	DECLARE @s_id INT /*仓库*/
	DECLARE @nNewBillID int 
	declare @movebillid int  /*移库单id*/
	DECLARE @yGuid uniqueidentifier
	DECLARE @pid int
	DECLARE @r_id int
	DECLARE @Loc_id int
	DECLARE @Batchno varchar(100)
	DECLARE @WholeQty NUMERIC(25,8)
	DECLARE @PartQty NUMERIC(25,8)
	DECLARE @outQty NUMERIC(25,8)
	DECLARE @InceptQty NUMERIC(25,8)
	DECLARE @kQty NUMERIC(25,8)
	DECLARE @WholeRate int
	DECLARE @StoreCondition int
	DECLARE @nEid int
	DECLARE @FResultId_BillAudit INT
	DECLARE @FVchCode_BillAudit INT /*草稿自动过账使用*/
	DECLARE @nYId INT, @nTmpBillId INT
	DECLARE @detailCount INT
	DECLARE @bNestedFlag INT
	
	DECLARE @costprice NUMERIC(25,8)
	DECLARE @costtaxprice NUMERIC(25,8)
	DECLARE @makedate datetime
	DECLARE @Instoretime datetime
	DECLARE @validdate datetime 
	DECLARE @factoryid INT
	DECLARE @supplier_id INT	
	DECLARE @taxrate NUMERIC(10,4)
	DECLARE @y_id INT
	DECLARE @AOID INT
	declare @tmpWqty NUMERIC(25,8),@tmpPqty NUMERIC(25,8)  /*满足条件的总数量*/
	declare @sqty NUMERIC(25,8)  /*满足条件的仓库总数量*/
	declare @oldl_id int,@newl_id int  /*移库货位*/
	declare @mx_id int   /*分配的批次id*/
	declare @nPickSID int 
	declare @nPickSaID int
	declare @szBillnumber varchar(30)
	DECLARE @cUseSalePriceTrace INT /*售价跟踪*/
	declare @level_sid int   /*分配优先级仓库*/
	declare @moves_sid int   /*移库的仓库*/
	declare @icount int   /*循环计数*/
	declare @TagGspbill int  /*打印标签单号*/
	declare @TagGspsmb_id int /*打印标签明细号*/
	declare @TagWholeQty int /*打印标签整货数量*/
	declare @TagWholeRate int /*标签包含数量*/
	declare @Tagyid int /*单据机构*/
	declare @idex int /*计数*/
	
/*	select top 1 @nYNDZ001=CAST(sysvalue as Int) from sysconfigtmp where [sysname] = 'yndz001'
	if 	@nYNDZ001 is null set @nYNDZ001 = 0	
	
*/
	SET @nRet = -1
	
	IF @@TRANCOUNT > 0
	BEGIN
		SET @bNestedFlag = 1
		SAVE TRAN CREATEBILL
	END
	ELSE
	BEGIN
		SET @bNestedFlag = 0
		BEGIN TRAN CREATEBILL
	END
	
		if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
			drop table #tmpDetail
		create table #tmpDetail
		 (
		  smbid     int,   /*对应的订单明细id*/
		  smxid     int,   /*库存明细id*/
		  s_id		int,   /*仓库id*/
		  l_id      int,   /*货位id*/
	/*	  r_id      int,   --剂型id*/
		  qty     int,		/*-分配数量*/
		  sflag    int		/*整，零货类型	*/
		 )
		 
		if  OBJECT_ID('tempdb..#tmpMoveS') IS NOT NULL
			drop table #tmpMoveS
		create table #tmpMoveS
		 (
		  smbid     int,   /*对应的订单明细id*/
		  smxid     int,   /*库存明细id*/
		  pid       int,
		  oldl_id      int,   /*原货位*/
		  newl_id      int,   /*现货位*/
		  qty     int		/*-暂时留着备用	，默认为1 整货*/
		 )
		 		 
		/*定义几个比较小的表变量 */
		declare @tmpstorehouse TABLE (
			level  int,  /*设置排序优先级*/
			smx_id int,
			PID int,
			s_id int,
			Loc_id int,
			SAType int,   /*0表示整货*/
			qty NUMERIC(25,8)		
			)

		if (@billtype = 14) or (@billtype = 154) /*销售订单,机构配送订单*/
		begin
			/*更新没有仓库id的明细行，如果选择了仓库，则明细都按仓库拣货，反正则需要分配仓库											*/
			update OrderBill set ss_id = bi.sout_id 
				from OrderBill mx, orderidx bi 
				where mx.bill_id= bi.billid and bi.billid = @billid and mx.ss_id = 0

			DELETE FROM GSPBILLDETAIL WHERE GSPBILL_ID IN (SELECT Gspbillid FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype AND BillStates = 10)
			DELETE FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype AND BillStates = 10
			IF EXISTS(SELECT * FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype)
				GOTO ERROR
				
			select @nEid = e_id from orderidx where billid = @billid	
			/*按库区生拣货单	*/
			/*if exists(select 1 from sysconfigtmp where sysname = 'StoreWMS' and sysvalue = 1)		--放到调用的地方去判断	
			begin  */

				/*先生成拣货单明细，注意需要用库存减去未完成的拣货单的数量，再来分配货位*/
				declare DetailCur cursor for
					select smb_id,p_id,batchno,quantity,costprice,costtaxprice,makedate,Instoretime,validdate,y_id,supplier_id,factoryid,taxrate,ss_id,AOID/*,location_id 选择合并了货位批次*/
					from OrderBill					       					       					       
					where bill_id = @billid							   			   
				open DetailCur
				
				fetch next from DetailCur into @nSmbId,@pid,@batchno,@outQty,@costprice,@costtaxprice,
						@makedate,@Instoretime,@validdate,@y_id,@supplier_id,@factoryid,@taxrate,@s_id,@AOID/*,@loc_id*/
				while @@FETCH_STATUS=0
				begin				
					
					IF @AOID IN (6)   /*-对零成本商品特殊处理*/
					begin
						set @WholeQty = 0    /*拣货整货数量*/
						set @PartQty = @outQty  /*拣货零货数量*/
						
						/*读取满足条件，循环库存*/
							delete from @tmpstorehouse /*清除数据*/
							insert @tmpstorehouse(level,smx_id,PID,s_id,Loc_id,SAType,qty)
							select 999,OtherStorehouse_id,s.p_id,s.s_id,s.location_id,sa.SAType,(s.quantity - isnull(d.qty,0)) as qty
							from OtherStorehouse s left OUTER JOIN
								(select gd.P_id,gd.batchno,gd.CostPrice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,SUM(gd.PickQty) as qty from gspbilldetail gd,gspbillidx g 
								where gd.Gspbill_id = g.Gspbillid and g.BillType = 541 and BillStates = 13 and gd.aoid in (6)
								group by gd.P_id,gd.batchno,gd.CostPrice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id
								
							) d on s.p_id = d.P_id and s.batchno = d.Batchno and s.costprice = d.CostPrice  and 
								s.makedate = d.MakeDate and s.instoretime = d.InstoreTime and s.validdate = d.Validdate and s.location_id = d.Location_id and 
								s.Y_ID = d.Y_id and s.supplier_id = d.Supplier_id 
							left join
								location l on s.location_id = l.loc_id
							left join stockArea sa on l.sa_id = sa.sa_id						 					       					       					       
							where s.p_id = @pid and /*s.batchno = @batchno and s.costprice = @costprice and  
								s.makedate = @MakeDate and s.instoretime = @InstoreTime and s.validdate = @Validdate and --s.location_id = @loc_id and 
								*/s.Y_ID = @Y_id /*and s.supplier_id = @Supplier_id  and*/
								/*(s.s_id = @s_id or @s_id = 0)	*/
							order by (s.quantity - isnull(d.qty,0)) desc					   			   
				
						select @tmpPqty = SUM(qty) from @tmpstorehouse 
						if @tmpPqty is null set @tmpPqty = 0	
						
						if @outQty > @tmpPqty
						begin
							raiserror('赠品数量不足！',16,1)
							GOTO ERRORA
						end
						/*找到满足数量的最小数量的仓库*/
						select top 1 @level_sid = t.s_id from 
						(
							select s_id,sum(qty) as sqty  from @tmpstorehouse
							group by s_id 
						) t  where t.sqty > @outQty  order by sqty
						
						if isnull(@level_sid,0) > 0
							update @tmpstorehouse set level = 100 where s_id = @level_sid   /*设置优先级*/
							
						begin
							declare storehousePCur cursor for
							select smx_id,s_id,loc_id,qty from @tmpstorehouse  order by level,qty
							open storehousePCur	
							fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty	
							/*插入分配的赠品*/
							while @PartQty > 0 and @@FETCH_STATUS=0
							begin
								if @kQty >= @PartQty
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@PartQty ,1	
									set @PartQty = 0   /*	分配完成*/
								end
								else
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@kQty ,1	
									set @PartQty = @PartQty -@kQty   /*	剩余分配数量*/
									
									fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty					
								end		
							end
							if @PartQty > 0
							begin
								raiserror('分配赠品失败',16,1)
								GOTO ERRORA1	
							end
							close storehousePCur   /*关闭游标*/
							deallocate storehousePCur					
						
						end	
							
					
					end
					else
					begin
						select @WholeRate = WholeRate from vw_Products where product_id = @pid
						set @WholeQty = floor(@outQty/@WholeRate)     /*拣货整货数量*/
						set @PartQty = @outQty - @WholeQty*@WholeRate  /*拣货零货数量*/
						
						/*读取满足条件，循环库存*/
							delete from @tmpstorehouse /*清除数据*/
							insert @tmpstorehouse(level,smx_id,PID,s_id,Loc_id,SAType,qty)
							select 999,storehouse_id,s.p_id,s.s_id,s.location_id,sa.SAType,(s.quantity - isnull(d.qty,0)) as qty
							from storehouse s left OUTER JOIN
								(select gd.P_id,gd.batchno,gd.CostPrice,gd.costtaxprice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,gd.factoryid,gd.TaxRate,SUM(gd.PickQty) as qty from gspbilldetail gd,gspbillidx g 
								where gd.Gspbill_id = g.Gspbillid and g.BillType = 541 and BillStates = 13
								group by gd.P_id,gd.batchno,gd.CostPrice,gd.costtaxprice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,gd.factoryid,gd.TaxRate
								/*union all   --在现有的设计模式下，不需要考虑同一单出现同个商品批次的多条明细，所以不需要考虑分配临时表的数量*/
								
							) d on s.p_id = d.P_id and s.batchno = d.Batchno and s.costprice = d.CostPrice and s.costtaxprice = d.costtaxprice and 
								s.makedate = d.MakeDate and s.instoretime = d.InstoreTime and s.validdate = d.Validdate and s.location_id = d.Location_id and 
								s.Y_ID = d.Y_id and s.supplier_id = d.Supplier_id and s.factoryid = d.factoryid and s.taxrate = d.TaxRate 
							left join
								location l on s.location_id = l.loc_id
							left join stockArea sa on l.sa_id = sa.sa_id						 					       					       					       
							where s.p_id = @pid and s.batchno = @batchno and s.costprice = @costprice and s.costtaxprice = @costtaxprice and 
								s.makedate = @MakeDate and s.instoretime = @InstoreTime and s.validdate = @Validdate and /*s.location_id = @loc_id and */
								s.Y_ID = @Y_id and s.supplier_id = @Supplier_id and s.factoryid = @factoryid and s.taxrate = @TaxRate and
								(s.s_id = @s_id or @s_id = 0)
								/*and sa.SAType = 0   --整货区	*/
							order by (s.quantity - isnull(d.qty,0)) desc					   			   
											
						select @tmpWqty = SUM(qty) from @tmpstorehouse where SAType = 0	 /*整货	*/
						if @tmpWqty is null set @tmpWqty = 0
								
						select @tmpPqty = SUM(qty) from @tmpstorehouse where SAType = 1  /*零货*/
						if @tmpPqty is null set @tmpPqty = 0
						/*@sqty，@outQty*/
						/*找到满足数量的最小数量的仓库*/
						select top 1 @level_sid = t.s_id from 
						(
							select s_id,sum(wqty) as wqty,sum(pqty) as pqty,sum(wqty +pqty) as sqty  from 
							(
								select s_id,case SAType when 0 then SUM(qty) else 0 end wqty,
										case SAType when 1 then SUM(qty) else 0 end pqty from @tmpstorehouse  group by s_id,SAType
							) st group by s_id 
						) t  where t.wqty > @WholeQty * @WholeRate /*and t.pqty > @PartQty*/ and t.sqty > @outQty  order by sqty
						
						if isnull(@level_sid,0) > 0
							update @tmpstorehouse set level = 100 where s_id = @level_sid   /*设置优先级*/
						
						
						if @PartQty > @tmpPqty /*需要生成移库单，做移库单处理*/
						begin										
							if exists (select  1  from @tmpstorehouse where SAType = 0)
							begin													
								select top 1 @mx_id = smx_id,@moves_sid = s_id, @oldl_id = Loc_id from @tmpstorehouse where SAType = 0 order by qty
							end
							else
							begin
								raiserror('整货区已经没货了',16,1)
								GOTO ERRORA
							end 
							set @newl_id = null  /*这儿考虑到拆零优先不改变仓库，增加一个嵌套循环*/
							set @icount = 0
							while @icount < 2
							begin
								if ISNULL(@newl_id,0) >0
									break
								if exists (select  1  from @tmpstorehouse where SAType = 1)
									select top 1 @newl_id = Loc_id,@s_id = s_id from @tmpstorehouse where SAType = 1 and ((s_id = @moves_sid) or (@moves_sid = 0)) order by qty 
								else if exists (select  1  from productdetail p,location l,stockArea sa where p_id = @pid and p.location_id = l.loc_id and l.sa_id = sa.sa_id and sa.SAType = 1 and ((p.s_id = @moves_sid) or (@moves_sid = 0)))  /*找历史货位*/
									select top 1 @newl_id = p.location_id,@s_id = l.s_id from productdetail p,location l,stockArea sa where p_id = @pid and p.location_id = l.loc_id and l.sa_id = sa.sa_id and sa.SAType = 1 and ((p.s_id = @moves_sid) or (@moves_sid = 0)) order by pd_id desc
								else
								begin
									select @r_id = r_id from vw_Products where product_id = @pid
									select top 1 @newl_id = Loc_id,@s_id = l.s_id from location l,stockArea s,WMSMedtype m where l.sa_id = s.sa_id and l.loc_id = m.StoreQYHWID and m.Flag = 2 and m.MedtypeID = @r_id and ((l.s_id = @moves_sid) or (@moves_sid = 0)) order by m.Quantity
								end
								
								set @icount = @icount + 1
								set @moves_sid = 0  /*不在整货仓库找*/
							end
							
							if @newl_id is null
							begin
								raiserror('零货货位不存在',16,1)
								GOTO ERRORA
							end	
							else
							begin
								/*分配一个满足条件的零货货位*/
								insert into #tmpMoveS(smbid,smxid,pid,oldl_id,newl_id,qty)
								select @nSmbId,@mx_id,@pid,@oldl_id,@newl_id,ceiling(@PartQty/@WholeRate) *@WholeRate 
								
								update @tmpstorehouse set qty = qty-ceiling(@PartQty/@WholeRate) *@WholeRate  where smx_id = @mx_id 
							end
							/*插入分配成功的零货*/
							insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
							select @nSmbId,@mx_id,@s_id,@newl_id,@PartQty ,1	
						end
						else   /*循环零货库*/
						begin
							declare storehousePCur cursor for
							select smx_id,s_id,loc_id,qty from @tmpstorehouse	where SAType = 1 order by level,qty
							open storehousePCur	
							fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty	
							/*插入分配的零货*/
							while @PartQty > 0 and @@FETCH_STATUS=0
							begin
								if @kQty >= @PartQty
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@PartQty ,1	
									set @PartQty = 0   /*	分配完成*/
								end
								else
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@kQty ,1	
									set @PartQty = @PartQty -@kQty   /*	剩余分配数量*/
									
									fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty					
								end		
							end
							if @PartQty > 0
							begin
								raiserror('分配零货失败',16,1)
								GOTO ERRORA1	
							end
							/*--插入分配成功的零货
							insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
							select @nSmbId,@mx_id,@s_id,@Loc_id,@newl_id,@PartQty ,1	
							*/
							close storehousePCur   /*关闭游标*/
							deallocate storehousePCur					
						
						end
							
						declare storehouseCur cursor for
						select smx_id,s_id,loc_id,qty from @tmpstorehouse	where SAType = 0 order by level,qty
						open storehouseCur	
						fetch next from storehouseCur into @mx_id,@s_id,@loc_id,@kQty	
						/*插入分配的整货*/
						while @WholeQty > 0 and @@FETCH_STATUS=0
						begin
							if @kQty >= @WholeQty * @WholeRate
							begin
								insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
								select @nSmbId,@mx_id,@s_id,@Loc_id,@WholeQty * @WholeRate ,0	 /*这儿写整货的基本单位数*/
								set @WholeQty = 0   /*	分配完成*/
							end
							else
							begin
								
								insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
								select @nSmbId,@mx_id,@s_id,@Loc_id,floor(@kQty/@WholeRate)*@WholeRate ,0	
								set @WholeQty = (@WholeQty -floor(@kQty/@WholeRate))/**@WholeRate   --	剩余分配数量*/
								
								fetch next from storehouseCur into @mx_id,@s_id,@loc_id,@kQty					
							end		
						end
						if @WholeQty > 0
						begin
							raiserror('分配整货不足',16,1)
							GOTO ERRORA2	
						end
						/*--插入分配成功的零货
						insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
						select @nSmbId,@mx_id,@s_id,@Loc_id,@newl_id,@PartQty ,1	
						*/
						close storehouseCur   /*关闭游标*/
						deallocate storehouseCur
	
					end	
					/*下一行商品*/
					fetch next from DetailCur into @nSmbId,@pid,@batchno,@outQty,@costprice,@costtaxprice,
						@makedate,@Instoretime,@validdate,@y_id,@supplier_id,@factoryid,@taxrate,@s_id,@AOID/*,@loc_id						*/
				end
				close DetailCur
				deallocate DetailCur	
			/*end			*/
			/*-处理完了商品拣货拆分行 end*/
			/*-下一步，对拆分完成的临时表进行分单生成拣货单和 移库单*/
			/*-1. 生成移库单*/
			/*select * from #tmpMoveS*/
			/*select * from #tmpDetail*/
			
			if exists(select 1 from #tmpMoveS )
			begin
				select @Y_id = Y_ID from orderidx where billid = @billid			
				exec TS_H_CreateBillSN 44, 1, null, @nEid, 0, @szBillnumber output, @Y_id

				INSERT INTO BillDraftidx
					(
					billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
					ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
					department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
					jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id,ZBAuditMan,ZBAuditDate
					)
				select top 1
					convert(varchar(10),GETDATE(),121) ,@szBillnumber,44,0,0,@nEid,oldl_id,newl_id,0,@nEid,
					0 as costtotal  ,0 as costtotal  ,0,0 , 0  ,0	,2 ,0 ,  /*状态为未审核2*/
					0,0  ,0 ,0 ,0  ,0,'自动拆零'  ,'' ,
					0,0 ,'',0, 0,0,1*@WholeRate,0,@Y_id,0,'1900-01-01'
				from #tmpMoveS

				SET  @movebillid=@@IDENTITY
				
				INSERT INTO storemanageBilldrf
					(
					 bill_id  ,p_id  ,batchno  ,quantity  ,costprice,costtotal  ,price ,totalmoney  ,retailprice  ,
					 retailmoney  ,makedate  ,validdate  ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,
					 commissionflag  ,comment  ,unitid ,location_id2, qualitystatus,iotag, total, invoiceTotal , 
					  OrgBillID,Aoid,SendQTY,SendCostTotal,Y_id, instoretime, BatchBarCode, scomment, batchprice,
					 FactoryId,costtaxprice,costtaxrate,costtaxtotal 
					)
				select 
					 @movebillid  ,s.p_id  ,s.batchno  ,t.qty  ,s.costprice,s.costprice * t.qty ,s.costprice,s.costprice * t.qty  ,0  ,
					 0 , s.makedate  ,s.validdate  ,0	,s.s_id ,l.s_id  ,t.oldl_id  ,s.supplier_id  ,
					 s.commissionflag ,'自动拆零'	,p.unit1_id ,t.newl_id, '合格',0, s.costprice * t.qty, 0 ,
					 0,0,t.qty,s.costprice * t.qty,s.Y_ID, s.instoretime, s.BatchBarCode, s.scomment, s.batchprice,
					 s.factoryid,s.costtaxprice,s.taxrate,s.costtaxprice *t.qty
				 from #tmpMoveS t left join storehouse s on t.smxid = s.storehouse_id
				 left join location l on t.newl_id = l.loc_id
				 left join products p on t.pid = p.product_id
				 
				IF @@ROWCOUNT=0
				begin
					raiserror('生成移库单失败',16,1)
					GOTO ERROR
				end
				
				/*更新表头*/
				update BillDraftidx set ysmoney = sm.costtaxtotal ,ssmoney =sm.costtaxtotal  ,araptotal = sm.costtaxtotal,quantity = sm.quantity,
						sout_id = sm.sout_id,sin_id = sm.sin_id 
				from (select bill_id,sum(costtaxtotal) as costtaxtotal,sum(costtaxtotal) as araptotal,sum(quantity) as quantity,MAX(ss_id) as sout_id, MAX(sd_id) as sin_id from storemanageBilldrf where bill_id = @movebillid group by bill_id ) sm 
				where BillDraftidx.billid = sm.bill_id and BillDraftidx.billid = @movebillid
				

/*
				--自动过账
				if (@draft = 0)
				begin 
					EXECUTE ts_c_BillAudit @@movebillid,@nP_id output,@nReturnNumber output,44
					IF @nReturnNumber<>0 Goto SysError
				end
				*/
				/*增加单据编号计数*/
				update BillSNStyle  set SNCount=SNCount+1 where billtype=44 and Y_ID=@Y_id	
			
			end
			/*-2.生成拣货单，按库区拆分*/
			if not exists(select 1 from #tmpDetail )
			begin
				raiserror('生成拣货单失败',16,1)
				GOTO ERROR	
			end
			
			declare CreatePickBilCurl cursor for
			select distinct mx.s_id, isnull(l.sa_id, 0) as pickSaid 
			from /*orderbill*/#tmpDetail mx
				  left join location l on mx.l_id = l.loc_id					       					       					       
			group by mx.s_id,l.sa_id							   			   
			open CreatePickBilCurl
			
			fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID
			while @@FETCH_STATUS=0
			begin	
				set @nNewBillID = 0
				EXEC TS_H_CreateBillSN 541, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nYId
		      
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
								GUID, Note, BalanceMode,YE_ID,SendC_Id,sa_id)									     
						SELECT   541, @szBillNumber, Y_id, c_id, GETDATE(),  CASE WHEN auditman > 0 THEN auditman WHEN e_id > 0 THEN e_id ELSE inputman END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman, 0, traffictype, '', '', 0, '', sendtime, 
								trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, case when billtype = 154 then 152 else billtype end as ybilltype , [guid], 
								b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, @nPickSID, 0, 
								[Guid], Note, BalanceMode,e_id,SendC_ID,@nPickSaID
					FROM      dbo.orderidx
					WHERE billid = @billid					   
					SELECT @nNewBillID = @@IDENTITY
					
					
					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
		   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxrate,costtaxprice,costtaxtotal,oldorderqty,oldorderunit,
								OldOrderUnitid,OldOrderUnitrate,WholeQty,PartQty)
						SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.qty, o.qty, 0, 0, 0, 
									o.qty, 0, 0, 0, o.qty, o.taxprice as Ytaxprice, o.saleprice as saleprice, o.discountprice as DiscountPrice, 
									o.taxprice as taxprice, 0, o.saleprice * o.qty, 
									o.discount, o.discountprice*o.qty, o.TaxRate,(o.taxprice -o.saleprice)*o.qty , o.taxprice*o.qty, 0, '', '', '', 
									'', '', '', '', '', o.ns_id, o.nl_id, o.supplier_id, o.instoretime, o.qty, 
									o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID, '', o.smb_id, 
									o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.qty, NEWID(),factoryid,costtaxrate,costtaxprice,o.qty*o.costtaxprice,
								   case  when o.unitid= p.unit2_id then  o.quantity/p.rate2
									      when o.unitid= p.unit3_id  then  o.quantity/p.rate3
									      when o.unitid= p.unit4_id  then  o.quantity/p.rate4
									      else  o.quantity  end as oldorderqty,u.name,
							       o.unitid,case  when o.unitid= p.unit2_id then p.rate2
									      when o.unitid= p.unit3_id  then p.rate3
									      when o.unitid= p.unit4_id  then p.rate4
									      else  0    end as unitrate,
								  case o.sflag  when 0 then round(o.qty / p.WholeRate,0) else 0 end as WholeQty,
								  case o.sflag  when 1 then o.qty else 0 end as PartQty
						FROM      
						      ( select mx.*,t.l_id as nl_id,t.s_id as ns_id,t.qty as qty,t.sflag, ISNULL(l.sa_id, 0) as pickSaID from dbo.OrderBill mx 
						         left join #tmpDetail t on mx.smb_id = t.smbid
						         left join location l on t.l_id = l.loc_id
						         where mx.bill_id = @billid and isnull(l.sa_id,0) = @nPickSaID and isnull(t.s_id,0) = @nPickSID) o
						left join unit u on o.unitid=u.unit_id
						inner join vw_Products p on o.p_id = p.product_id							
						WHERE o.pickSaID = @nPickSAID
						order by o.smb_id
						
						IF EXISTS (select 1 from stockArea WHERE sa_id = @nPickSaID AND SAPrintType = 0)  /*如果是整货打印*/
						begin
							declare CreatTagCurl cursor for
							select Gspbill_id,Gspsmb_id,g.Y_id,CEILING(gd.WholeQty) as WholeQty,p.WholeRate from gspbilldetail gd, GSPBILLIDX g ,vw_Products p
							where Gspbill_id = @nNewBillID and gd.Gspbill_id = g.Gspbillid	and gd.p_id = p.product_id					       					       					       							   			   
							open CreatTagCurl
							
							fetch next from CreatTagCurl into @TagGspbill,@TagGspsmb_id,@Tagyid,@TagWholeQty,@TagWholeRate
														
							while @@FETCH_STATUS = 0 
							begin
								set @idex = 0
								while @TagWholeQty > 0
								begin
									insert into GSPWholeTag(billid,smb_id,qty,idex,billtype,y_id,Tag)
									select @TagGspbill,@TagGspsmb_id,@TagWholeRate,@idex,0,@Tagyid,DBO.GetWholeTag()
								
									set @TagWholeQty = @TagWholeQty -1	
									set @idex = @idex + 1
								end
								
								fetch next from CreatTagCurl into @TagGspbill,@TagGspsmb_id,@Tagyid,@TagWholeQty,@TagWholeRate
							end
							CLOSE CreatTagCurl
							DEALLOCATE CreatTagCurl

						end						
						
						update GSPbillidx set detailcount = gd.dcount, DiscountTotal = sDiscountTotal,TaxTotal = sTaxTotal
						from (select Gspbill_id,COUNT(1) as dcount,SUM(TaxTotal) as sTaxTotal,SUM(DiscountTotal) as sDiscountTotal from gspbilldetail where Gspbill_id = @nNewBillID group by Gspbill_id ) gd 
						where GSPbillidx.Gspbillid = gd.Gspbill_id and GSPbillidx.Gspbillid = @nNewBillID
						
						UPDATE GSPbillidx SET PgQty = gd.PgQty from (select Gspbill_id,COUNT(1) as PgQty from 
							(select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id
							) gd WHERE Gspbillid = @nNewBillID AND BillType = 541 AND GSPbillidx.Gspbillid = gd.Gspbill_id 

						EXEC TS_H_BillTraceAct 0, @nNewBillID, 541, @billid, @billtype, 1, 0  /*单据追踪*/
						
						set @nRet = @nNewBillID
					END
					ELSE
					begin
						raiserror('生成拣货单明细失败',16,1)
						GOTO ERROR	
					end					
					fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID 
			end		
			if @billtype = 154 
			begin
				SET @cUseSalePriceTrace = 0
				exec ts_getsysvalue 'UseSaleTrace', @cUseSalePriceTrace OUT	
				declare @TraceSmbId int
				
				IF @cUseSalePriceTrace = 1
				BEGIN
					/*售价跟踪打开，机构配送订单刷新售价跟踪表数据*/
					DECLARE WritePriceTraceCur CURSOR FOR
						SELECT   o.smb_id
						FROM  (  select mx.*, ISNULL(l.sa_id, 0) as pickSaID from dbo.OrderBill mx 
								 left join location l on mx.location_id = l.loc_id
								 where mx.bill_id = @billid ) o
						inner join vw_Products p on o.p_id = p.product_id							
					OPEN WritePriceTraceCur
	                FETCH NEXT FROM WritePriceTraceCur INTO @TraceSmbId
					WHILE @@FETCH_STATUS=0
					BEGIN	
					  EXEC ts_c_SaleBuyPriceTrace;1 'S', @TraceSmbId, @billtype
					  FETCH NEXT FROM WritePriceTraceCur INTO @TraceSmbId
					END
					CLOSE WritePriceTraceCur
			        DEALLOCATE WritePriceTraceCur   	
				END				
	
				/*机构配送订单审核后更新请货单的完成数量*/
				update tranbill  set ComeQty = ComeQty + B.quantity from (select orgbillid,sum(quantity) as quantity from  OrderBill where bill_id= @billid group by orgbillid ) B  where tranbill.smb_id = B.orgbillid
				/*再更新请货单的状态*/
				update tranidx set billstates = 0 where billid not in (select bill_id from tranbill where ComeQty < quantity group by bill_id)			
			end
			close CreatePickBilCurl
			deallocate CreatePickBilCurl
		end 	
		/*销售订单生成拣货单end*/
		else
		/*采购退出申请单生成拣货单begin*/
		if (@billtype = 561) 
		begin	
				
			/*更新没有仓库id的明细行，如果选择了仓库，则明细都按仓库拣货，反之则需要分配仓库											*/
			update gspbilldetail set S_id = bi.S_id 
				from gspbilldetail mx, gspbillidx bi 
				where mx.Gspbill_id= bi.Gspbillid and bi.Gspbillid = @billid 

			DELETE FROM GSPBILLDETAIL WHERE GSPBILL_ID IN (SELECT Gspbillid FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype AND BillStates = 10)
			DELETE FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype AND BillStates = 10
			IF EXISTS(SELECT * FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @billid AND Ybilltype = @billtype)
				GOTO ERROR
				
			select @nEid = AuditMan1 from gspbillidx where gspbillid = @billid	
			/*按库区生拣货单	*/
			/*if exists(select 1 from sysconfigtmp where sysname = 'StoreWMS' and sysvalue = 1)			*/
			begin  

				/*先生成拣货单明细，注意需要用库存减去未完成的拣货单的数量，再来分配货位*/
				declare DetailCur cursor for
					select Gspsmb_id,p_id,batchno,ApplicantQty,costprice,costtaxprice,makedate,Instoretime,validdate,y_id,supplier_id,factoryid,taxrate,s_id,AOID/*,location_id 选择合并了货位批次*/
					from gspbilldetail					       					       					       
					where Gspbill_id = @billid							   			   
				open DetailCur
				
				fetch next from DetailCur into @nSmbId,@pid,@batchno,@outQty,@costprice,@costtaxprice,
						@makedate,@Instoretime,@validdate,@y_id,@supplier_id,@factoryid,@taxrate,@s_id,@AOID/*,@loc_id*/
				while @@FETCH_STATUS=0
				begin		
				
				IF @AOID IN (6)   /*-对零成本商品特殊处理*/
					begin
						set @WholeQty = 0    /*拣货整货数量*/
						set @PartQty = @outQty  /*拣货零货数量*/
						
						/*读取满足条件，循环库存*/
							delete from @tmpstorehouse /*清除数据*/
							insert @tmpstorehouse(level,smx_id,PID,s_id,Loc_id,SAType,qty)
							select 999,OtherStorehouse_id,s.p_id,s.s_id,s.location_id,sa.SAType,(s.quantity - isnull(d.qty,0)) as qty
							from OtherStorehouse s left OUTER JOIN
								(select gd.P_id,gd.batchno,gd.CostPrice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,SUM(gd.PickQty) as qty from gspbilldetail gd,gspbillidx g 
								where gd.Gspbill_id = g.Gspbillid and g.BillType = 541 and BillStates = 13 and gd.aoid in (6)
								group by gd.P_id,gd.batchno,gd.CostPrice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id
								
							) d on s.p_id = d.P_id and s.batchno = d.Batchno and s.costprice = d.CostPrice  and 
								s.makedate = d.MakeDate and s.instoretime = d.InstoreTime and s.validdate = d.Validdate and s.location_id = d.Location_id and 
								s.Y_ID = d.Y_id and s.supplier_id = d.Supplier_id 
							left join
								location l on s.location_id = l.loc_id
							left join stockArea sa on l.sa_id = sa.sa_id						 					       					       					       
							where s.p_id = @pid and /*s.batchno = @batchno and s.costprice = @costprice and  
								s.makedate = @MakeDate and s.instoretime = @InstoreTime and s.validdate = @Validdate and --s.location_id = @loc_id and 
								*/s.Y_ID = @Y_id /*and s.supplier_id = @Supplier_id  and*/
								/*(s.s_id = @s_id or @s_id = 0)	*/
							order by (s.quantity - isnull(d.qty,0)) desc					   			   
				
						select @tmpPqty = SUM(qty) from @tmpstorehouse 
						if @tmpPqty is null set @tmpPqty = 0	
						
						if @outQty > @tmpPqty
						begin
							raiserror('赠品数量不足！',16,1)
							GOTO ERRORA
						end
						/*找到满足数量的最小数量的仓库*/
						select top 1 @level_sid = t.s_id from 
						(
							select s_id,sum(qty) as sqty  from @tmpstorehouse
							group by s_id 
						) t  where t.sqty > @outQty  order by sqty
						
						if isnull(@level_sid,0) > 0
							update @tmpstorehouse set level = 100 where s_id = @level_sid   /*设置优先级*/
							
						begin
							declare storehousePCur cursor for
							select smx_id,s_id,loc_id,qty from @tmpstorehouse  order by level,qty
							open storehousePCur	
							fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty	
							/*插入分配的赠品*/
							while @PartQty > 0 and @@FETCH_STATUS=0
							begin
								if @kQty >= @PartQty
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@PartQty ,1	
									set @PartQty = 0   /*	分配完成*/
								end
								else
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@kQty ,1	
									set @PartQty = @PartQty -@kQty   /*	剩余分配数量*/
									
									fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty					
								end		
							end
							if @PartQty > 0
							begin
								raiserror('分配赠品失败',16,1)
								GOTO ERRORA1	
							end
							close storehousePCur   /*关闭游标*/
							deallocate storehousePCur					
						
						end					
					end
					else
					begin		
				
						select @WholeRate = WholeRate from vw_Products where product_id = @pid
						set @WholeQty = floor(@outQty/@WholeRate)     /*拣货整货数量*/
						set @PartQty = @outQty - @WholeQty*@WholeRate  /*拣货零货数量*/
						
						/*读取满足条件，循环库存*/
						/*declare storehouseCur cursor for*/
							delete from @tmpstorehouse /*清除数据*/
							insert @tmpstorehouse(level,smx_id,PID,s_id,Loc_id,SAType,qty)
							select 999 as level,storehouse_id,s.p_id,s.s_id,s.location_id,sa.SAType,(s.quantity - isnull(d.qty,0)) as qty
							from storehouse s left OUTER JOIN
								(select gd.P_id,gd.batchno,gd.CostPrice,gd.costtaxprice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,gd.factoryid,gd.TaxRate,SUM(gd.PickQty) as qty from gspbilldetail gd,gspbillidx g 
								where gd.Gspbill_id = g.Gspbillid and g.BillType = 541 and BillStates = 13
								group by gd.P_id,gd.batchno,gd.CostPrice,gd.costtaxprice,gd.MakeDate,gd.InstoreTime,gd.Validdate,gd.Location_id,
								gd.Y_id,gd.S_id,gd.Supplier_id,gd.factoryid,gd.TaxRate
							) d on s.p_id = d.P_id and s.batchno = d.Batchno and s.costprice = d.CostPrice and s.costtaxprice = d.costtaxprice and 
								s.makedate = d.MakeDate and s.instoretime = d.InstoreTime and s.validdate = d.Validdate and s.location_id = d.Location_id and 
								s.Y_ID = d.Y_id and s.supplier_id = d.Supplier_id and s.factoryid = d.factoryid and s.taxrate = d.TaxRate 
							left join
								location l on s.location_id = l.loc_id
							left join stockArea sa on l.sa_id = sa.sa_id						 					       					       					       
							where s.p_id = @pid and s.batchno = @batchno and s.costprice = @costprice and s.costtaxprice = @costtaxprice and 
								s.makedate = @MakeDate and s.instoretime = @InstoreTime and s.validdate = @Validdate and /*s.location_id = @loc_id and */
								s.Y_ID = @Y_id and s.supplier_id = @Supplier_id and s.factoryid = @factoryid and s.taxrate = @TaxRate and
								(s.s_id = @s_id or @s_id = 0)
								/*and sa.SAType = 0   --整货区	*/
							order by (s.quantity - isnull(d.qty,0)) desc					   			   
											
						select @tmpWqty = SUM(qty) from @tmpstorehouse where SAType = 0	 /*整货*/
						if @tmpWqty is null set @tmpWqty = 0
										
						select @tmpPqty = SUM(qty) from @tmpstorehouse where SAType = 1  /*零货*/
						if @tmpPqty is null set @tmpPqty = 0
						
						/*找到满足数量的最小数量的仓库*/
						select top 1 @level_sid = t.s_id from 
						(
							select s_id,sum(wqty) as wqty,sum(pqty) as pqty,sum(wqty +pqty) as sqty  from 
							(
								select s_id,case SAType when 0 then SUM(qty) else 0 end wqty,
										case SAType when 1 then SUM(qty) else 0 end pqty from @tmpstorehouse  group by s_id,SAType
							) st group by s_id 
						) t  where t.wqty > @WholeQty * @WholeRate /*and t.pqty > @PartQty*/ and t.sqty > @outQty  order by sqty
						
						if isnull(@level_sid,0) > 0
							update @tmpstorehouse set level = 100 where s_id = @level_sid   /*设置优先级*/
						
						
						if @PartQty > @tmpPqty /*需要生成移库单，做移库单处理*/
						begin										
							if exists (select  1  from @tmpstorehouse where SAType = 0)
							begin													
								select top 1 @mx_id = smx_id,@moves_sid = s_id, @oldl_id = Loc_id from @tmpstorehouse where SAType = 0 order by qty
							end
							else
							begin
								raiserror('整货区已经没货了',16,1)
								GOTO ERRORA
							end 
							set @newl_id = null  /*这儿考虑到拆零优先不改变仓库，增加一个嵌套循环*/
							set @icount = 0
							while @icount < 2
							begin
								if ISNULL(@newl_id,0) >0
									break
								if exists (select  1  from @tmpstorehouse where SAType = 1)
									select top 1 @newl_id = Loc_id,@s_id = s_id from @tmpstorehouse where SAType = 1 and ((s_id = @moves_sid) or (@moves_sid = 0)) order by qty 
								else if exists (select  1  from productdetail p,location l,stockArea sa where p_id = @pid and p.location_id = l.loc_id and l.sa_id = sa.sa_id and sa.SAType = 1 and ((p.s_id = @moves_sid) or (@moves_sid = 0)))  /*找历史货位*/
									select top 1 @newl_id = p.location_id,@s_id = l.s_id from productdetail p,location l,stockArea sa where p_id = @pid and p.location_id = l.loc_id and l.sa_id = sa.sa_id and sa.SAType = 1 and ((p.s_id = @moves_sid) or (@moves_sid = 0)) order by pd_id desc
								else
								begin
									select @r_id = r_id from vw_Products where product_id = @pid
									select top 1 @newl_id = Loc_id,@s_id = l.s_id from location l,stockArea s,WMSMedtype m where l.sa_id = s.sa_id and l.loc_id = m.StoreQYHWID and m.Flag = 2 and m.MedtypeID = @r_id and ((l.s_id = @moves_sid) or (@moves_sid = 0)) order by m.Quantity
								end
								
								set @icount = @icount + 1
								set @moves_sid = 0  /*不在整货仓库找*/
							end
							
							if @newl_id is null
							begin
								raiserror('零货货位不存在',16,1)
								GOTO ERRORA
							end	
							else
							begin
								/*分配一个满足条件的零货货位*/
								insert into #tmpMoveS(smbid,smxid,pid,oldl_id,newl_id,qty)
								select @nSmbId,@mx_id,@pid,@oldl_id,@newl_id,ceiling(@PartQty/@WholeRate) *@WholeRate 
								
								update @tmpstorehouse set qty = qty-ceiling(@PartQty/@WholeRate) *@WholeRate  where smx_id = @mx_id 
							end
							/*插入分配成功的零货*/
							insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
							select @nSmbId,@mx_id,@s_id,@newl_id,@PartQty ,1	
						end
						else   /*循环零货库*/
						begin
							declare storehousePCur cursor for
							select smx_id,s_id,loc_id,qty from @tmpstorehouse	where SAType = 1 order by level,qty
							open storehousePCur	
							fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty	
							/*插入分配的整货*/
							while @PartQty > 0 and @@FETCH_STATUS=0
							begin
								if @kQty >= @PartQty
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@PartQty ,1	
									set @PartQty = 0   /*	分配完成*/
								end
								else
								begin
									insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
									select @nSmbId,@mx_id,@s_id,@Loc_id,@kQty ,1	
									set @PartQty = @PartQty -@kQty   /*	剩余分配数量*/
									
									fetch next from storehousePCur into @mx_id,@s_id,@loc_id,@kQty					
								end		
							end
							if @PartQty > 0
							begin
								raiserror('分配零货失败',16,1)
								GOTO ERRORA1	
							end
							
							close storehousePCur   /*关闭游标*/
							deallocate storehousePCur					
						
						end
							
						declare storehouseCur cursor for
						select smx_id,s_id,loc_id,qty from @tmpstorehouse	where SAType = 0 order by level,qty
						open storehouseCur	
						fetch next from storehouseCur into @mx_id,@s_id,@loc_id,@kQty	
						/*插入分配的整货*/
						while @WholeQty > 0 and @@FETCH_STATUS=0
						begin
							if @kQty >= @WholeQty * @WholeRate
							begin
								insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
								select @nSmbId,@mx_id,@s_id,@Loc_id,@WholeQty *@WholeRate ,0	
								set @WholeQty = 0   /*	分配完成*/
							end
							else
							begin
								
								insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
								select @nSmbId,@mx_id,@s_id,@Loc_id,floor(@kQty/@WholeRate)*@WholeRate ,0	
								set @WholeQty = (@WholeQty -floor(@kQty/@WholeRate))/**@WholeRate   --	剩余分配数量*/
								
								fetch next from storehouseCur into @mx_id,@s_id,@loc_id,@kQty					
							end		
						end
						if @WholeQty > 0
						begin
							raiserror('分配整货不足',16,1)
							GOTO ERRORA2	
						end
						/*--插入分配成功的零货
						insert into #tmpDetail(smbid,smxid,s_id,l_id,qty,sflag)
						select @nSmbId,@mx_id,@s_id,@Loc_id,@newl_id,@PartQty ,1	
						*/
						close storehouseCur   /*关闭游标*/
						deallocate storehouseCur
						
					end	
					/*下一行商品*/
					fetch next from DetailCur into @nSmbId,@pid,@batchno,@outQty,@costprice,@costtaxprice,
						@makedate,@Instoretime,@validdate,@y_id,@supplier_id,@factoryid,@taxrate,@s_id,@AOID/*,@loc_id	*/
				end
				close DetailCur
				deallocate DetailCur	
			end			
			/*-处理完了商品拣货拆分行 end*/
			/*-下一步，对拆分完成的临时表进行分单生成拣货单和 移库单*/
			/*-1. 生成移库单*/
			if exists(select 1 from #tmpMoveS )
			begin
				select @Y_id = Y_ID from orderidx where billid = @billid
				
				exec TS_H_CreateBillSN 44, 1, null, @nEid, 0, @szBillnumber output, @Y_id

				INSERT INTO BillDraftidx
					(
					billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
					ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
					department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
					jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id,ZBAuditMan,ZBAuditDate
					)
				select top 1
					convert(varchar(10),GETDATE(),121) ,@szBillnumber,44,0,0,@nEid,oldl_id,newl_id,0,@nEid,
					0 as costtotal  ,0 as costtotal  ,0,0 , 0  ,0	,2 ,0 ,  /*状态为未审核2*/
					0,0  ,0 ,0 ,0  ,0,'自动拆零'  ,'' ,
					0,0 ,'',0, 0,0,1*@WholeRate,0,@Y_id,0,'1900-01-01'
				from #tmpMoveS

				SET  @movebillid=@@IDENTITY
				
				INSERT INTO storemanageBilldrf
					(
					 bill_id  ,p_id  ,batchno  ,quantity  ,costprice,costtotal  ,price ,totalmoney  ,retailprice  ,
					 retailmoney  ,makedate  ,validdate  ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,
					 commissionflag  ,comment  ,unitid ,location_id2, qualitystatus,iotag, total, invoiceTotal , 
					  OrgBillID,Aoid,SendQTY,SendCostTotal,Y_id, instoretime, BatchBarCode, scomment, batchprice,
					 FactoryId,costtaxprice,costtaxrate,costtaxtotal 
					)
				select 
					 @movebillid  ,s.p_id  ,s.batchno  ,t.qty  ,s.costprice,s.costprice * t.qty ,s.costprice,s.costprice * t.qty  ,0  ,
					 0 , s.makedate  ,s.validdate  ,0	,s.s_id ,l.s_id  ,t.oldl_id  ,s.supplier_id  ,
					 s.commissionflag ,'自动拆零'	,p.unit1_id ,t.newl_id, '合格',0, s.costprice * t.qty, 0 ,
					 0,0,t.qty,s.costprice * t.qty,s.Y_ID, s.instoretime, s.BatchBarCode, s.scomment, s.batchprice,
					 s.factoryid,s.costtaxprice,s.taxrate,s.costtaxprice *t.qty
				 from #tmpMoveS t left join storehouse s on t.smxid = s.storehouse_id
				 left join location l on t.newl_id = l.loc_id
				 left join products p on t.pid = p.product_id
				 
				IF @@ROWCOUNT=0
				begin
					raiserror('生成移库单失败',16,1)
					GOTO ERROR
				end
				
				/*更新表头			*/
				update BillDraftidx set ysmoney = sm.costtaxtotal ,ssmoney =sm.costtaxtotal  ,araptotal = sm.costtaxtotal,quantity = sm.quantity,
						sout_id = sm.sout_id,sin_id = sm.sin_id 
				from (select bill_id,sum(costtaxtotal) as costtaxtotal,sum(costtaxtotal) as araptotal,sum(quantity) as quantity,MAX(ss_id) as sout_id, MAX(sd_id) as sin_id from storemanageBilldrf where bill_id = @movebillid group by bill_id ) sm 
				where BillDraftidx.billid = sm.bill_id and BillDraftidx.billid = @movebillid
				

/*
				--自动过账
				if (@draft = 0)
				begin 
					EXECUTE ts_c_BillAudit @@movebillid,@nP_id output,@nReturnNumber output,44
					IF @nReturnNumber<>0 Goto SysError
				end
				*/
				/*增加单据编号计数*/
				update BillSNStyle  set SNCount=SNCount+1 where billtype=44 and Y_ID=@Y_id	
			
			end
			/*-2.生成拣货单，按库区拆分*/
			if not exists(select 1 from #tmpDetail )
			begin
				raiserror('生成拣货单失败',16,1)
				GOTO ERROR	
			end

			declare CreatePickBilCurl cursor for
			select distinct mx.s_id, isnull(l.sa_id, 0) as pickSaid 
			from /*gspbilldetail*/#tmpDetail mx
				  left join location l on mx.l_id = l.loc_id					       					       					       
			group by mx.s_id,l.sa_id							   			   
			open CreatePickBilCurl
			
			fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID
			while @@FETCH_STATUS=0
			begin	select * from gspbillidx
				set @nNewBillID = 0
				EXEC TS_H_CreateBillSN 541, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nYId
		      
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
								GUID, Note,FollowNumber, BalanceMode,YE_ID,SendC_Id,sa_id)									     
						SELECT   541, @szBillNumber, Y_id, c_id, GETDATE(), CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END as inputman, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, 10, s_id, TrafficTime, 
								[GUID], Note, FollowNumber, BalanceMode,YE_ID,SendC_Id,@nPickSaID
					FROM      dbo.GSPbillidx
					WHERE Gspbillid = @billid					   
					SELECT @nNewBillID = @@IDENTITY
					
					IF @nNewBillID > 0
					BEGIN
							
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal,WholeQty,PartQty)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, t.qty, t.qty, uneligibleqty, inceptqty, refuseqty, 
									t.qty, CheckQty, sampleqty, t.qty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, price* t.qty, 
									discount, DiscountPrice*t.qty, mx.TaxRate, (TaxPrice-price)* t.qty, TaxPrice*t.qty, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, t.S_id, t.l_id, supplier_id, instoretime, t.qty, 
									BatchBarCode, Batchcomment, batchprice, mx.Iscold, mx.Isspec, mx.Comment, mx.Comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostPrice*t.qty, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxprice*t.qty,
								  case t.sflag  when 0 then round(t.qty / p.WholeRate,0) else 0 end as WholeQty ,
								  case t.sflag  when 1 then t.qty else 0 end as PartQty
						FROM     dbo.gspbilldetail mx 
						         left join #tmpDetail t on mx.Gspsmb_id = t.smbid
						         left join location l on t.l_id = l.loc_id
						         left join vw_Products p on mx.P_id = p.product_id
						         where mx.Gspbill_id = @billid and isnull(l.sa_id,0) = @nPickSaID and isnull(t.s_id,0) = @nPickSID
						order by mx.Gspsmb_id
						
						IF EXISTS (select 1 from stockArea WHERE sa_id = @nPickSaID AND SAPrintType = 0)  /*如果是整货打印*/
						begin
							declare CreatTagCurl cursor for
							select Gspbill_id,Gspsmb_id,g.Y_id,CEILING(gd.WholeQty) as WholeQty,p.WholeRate from gspbilldetail gd, GSPBILLIDX g ,vw_Products p
							where Gspbill_id = @nNewBillID and gd.Gspbill_id = g.Gspbillid	and gd.p_id = p.product_id				       					       					       							   			   
							open CreatTagCurl
							
							fetch next from CreatTagCurl into @TagGspbill,@TagGspsmb_id,@Tagyid,@TagWholeQty,@TagWholeRate
							
							while @@FETCH_STATUS = 0 
							begin
								set @idex = 0
								while @TagWholeQty > 0
								begin
									
									insert into GSPWholeTag(billid,smb_id,qty,idex,billtype,y_id,Tag)
									select @TagGspbill,@TagGspsmb_id,@TagWholeRate,@idex,0,@Tagyid,DBO.GetWholeTag()
								
									set @TagWholeQty = @TagWholeQty -1	
									set @idex = @idex + 1
								end
								
								fetch next from CreatTagCurl into @TagGspbill,@TagGspsmb_id,@Tagyid,@TagWholeQty,@TagWholeRate
							end
							CLOSE CreatTagCurl
							DEALLOCATE CreatTagCurl

						end
						
						update GSPbillidx set detailcount = gd.dcount, DiscountTotal = sDiscountTotal,TaxTotal = sTaxTotal
						from (select Gspbill_id,COUNT(1) as dcount,SUM(TaxTotal) as sTaxTotal,SUM(DiscountTotal) as sDiscountTotal from gspbilldetail where Gspbill_id = @nNewBillID group by Gspbill_id ) gd 
						where GSPbillidx.Gspbillid = gd.Gspbill_id and GSPbillidx.Gspbillid = @nNewBillID
						
						UPDATE GSPbillidx SET PgQty = gd.PgQty from (select Gspbill_id,COUNT(1) as PgQty from 
							(select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id
							) gd WHERE Gspbillid = @nNewBillID AND BillType = 541 AND GSPbillidx.Gspbillid = gd.Gspbill_id 

						EXEC TS_H_BillTraceAct 0, @nNewBillID, 541, @billid, @billtype, 1, 0  /*单据追踪*/
						
						set @nRet = @nNewBillID
					END
					ELSE
					begin
						raiserror('生成拣货单明细失败',16,1)
						GOTO ERROR	
					end					
					fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID 
			end	
			
			close CreatePickBilCurl
			deallocate CreatePickBilCurl
		end 
		/*采购退出申请单 end				*/
								
	IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END
	RETURN @nRet

ERROR:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	if  OBJECT_ID('tempdb..#tmpMoveS') IS NOT NULL
		drop table #tmpMoveS

	RETURN @nRet
	
ERRORA:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	if  OBJECT_ID('tempdb..#tmpMoveS') IS NOT NULL
		drop table #tmpMoveS
		
	close DetailCur
	deallocate DetailCur
	RETURN @nRet
	
ERRORA1:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	if  OBJECT_ID('tempdb..#tmpMoveS') IS NOT NULL
		drop table #tmpMoveS
		
	close storehousePCur   /*关闭游标*/
	deallocate storehousePCur	
	
	close DetailCur
	deallocate DetailCur
	RETURN @nRet
	
ERRORA2:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	if  OBJECT_ID('tempdb..#tmpMoveS') IS NOT NULL
		drop table #tmpMoveS
		
	close storehouseCur   /*关闭游标*/
	deallocate storehouseCur
	
	close DetailCur
	deallocate DetailCur
	RETURN @nRet
END
GO
