/************************************************************

--功能：委托书查询   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_CheckWtorder
	(
      @C_ID int = 0,
      @P_id int = 0
     )
AS 
/*Params Ini begin*/
if @C_ID is null  SET @C_ID = 0
if @P_id is null  SET @P_id = 0
/*Params Ini end*/
declare @nRet int, @factoryC_Id int, @mt_id int, @dtToday datetime
set @dtToday =CAST( cast(GETDATE() as varchar(10)) as datetime)

set @nRet = -1
if @c_id = 0 or @P_id = 0 set @nRet = -2
select @factoryC_Id = factoryc_id, @mt_id = medtype from products where product_id = @P_id
if (@mt_id>0) 
 and (@factoryC_Id = @C_ID) 
 and exists(select 1 from gspalert where c_id = @C_ID and mt_id = @mt_id and CType = 0)
begin
  if not exists(select 1 from gspalert where c_id = @C_ID and mt_id = @mt_id and D10 >= @dtToday and CType = 0)
  begin
    set @nRet = -3
    goto pend
  end  
end  else
begin
  set @nRet = 0
end
 
/*不在此处判断委托书*/
/*if exists(select 1 from wtorder where c_id = @C_ID and p_id = @P_id)*/
/*begin*/
/*  if exists(select 1 from wtorder where c_id = @C_ID and p_id = @P_id and validdate >=@dtToday)*/
/*    set @nRet = 0*/
/*  else*/
/*    set @nRet = -4*/
/*end else */
/*begin*/
/*  set @nRet = 0*/
/*end*/
pend:
 return @nRet
GO
