
/*/* 功能：会员综合分布表*/
/* 2013-07-09  add by  yanrui  */
--*/

CREATE PROCEDURE TS_y_RepVIPCardDistributing
( 	
	@bdate   varchar(20) ='', /*生日*/
	@Y_id    int =0         /*机构ID  	*/
)
AS
BEGIN
  /*初始化输入条件*/
  declare @bmonth1 int,@bmonth2 int,@bday1 int,@bday2 int
  declare @Yid1 int,@Yid2 int
  select  @Yid1=@Y_id,@Yid2=@Yid1
  if @Yid1=0 set @Yid2=2147483647
  if @Bdate='' 
  begin
    set @bmonth1=0
    set @bmonth2=12
    set @bday1=0
    set @bday2=31
  end
  else
  begin
    set @bday1=DAY(@bdate)
    set @bday2=@bday1
    set @bmonth1=Month(@bdate)
    set @bmonth2=@bmonth1      
  end
  /**/
 CREATE TABLE #t1
  (	
    VIPCardID int , 
    Yname  varchar(200),
    sex varchar(10),
    ename varchar(200),
    ct_Type varchar(200),
    cname   varchar(200),
    isBank varchar(20),
    isIntegral varchar(20),
    age int ,
    Cmonth int ,
    LastSaleMd varchar(200),/*最后消费门店*/
    lastsaledate datetime,
    BuyCount int ,
    TotalBuyMoney NUMERIC(25,8),
    ljIntegral int ,
    Integral int ,
    SaveMoney NUMERIC(25,8),
    RemainderMoney NUMERIC(25,8),
    showLose varchar(20),
    showStopUse varchar(20),
    showislock varchar(20),
    height NUMERIC(25,8),
    cweight NUMERIC(25,8),
    bloodtype varchar(20),
    Education varchar(20),
    saleday   int,
    VName varchar(20),
	CardNo varchar(60),
	Tel varchar(80),
	BuildDate datetime,
	Y_id  int,
	GenerallySaleCompay varchar(100)/*经常消费门店*/
  )
 CREATE TABLE #t2
  (	
    VIPCardID     INT,
    sDatetime     datetime
  )
 CREATE TABLE #t3
  (	
    VIPCardID     INT,
    sDatetime     datetime,
    sMdName       varchar(100)
  )
  CREATE TABLE #t4
  (	
    VIPCardID     INT,
    SumSaleCs     int,
    GenerallySaleCompay varchar(100)/*经常消费门店 */
  )
  /*写入临时表 */
  insert into #t1
  select  a.VIPCardID,e.name,a.sex,d.name as ename,
          case c.ct_Type when 0 then '无' when 1 then '会员卡' when 2 then '打折卡' end as ct_Type,
          c.name,
          case c.isBank when 0 then'否' when 1 then '是' end as isBank,
          case c.isIntegral when 0 then '否' when 1 then '是' end as isIntegral,
          dbo.GetAge(a.Birthday,GETDATE()) as age,
          ceiling(datediff(MM,a.BulidDate,GETDATE())) as Cmonth, 
          f.name as LastSaleMd, 
          b.billdate as lastsaledate,
          a.BuyCount,a.TotalBuyMoney,(a.Integral+a.SwapIntegral) as ljIntegral,
          a.Integral,a.SaveMoney,RemainderMoney,
  		 (case when a.Lose=0 then '否' else '是' end)showLose,
		 (case when a.StopUse=0 then '否' else '是' end)showStopUse,
		 (case when a.islock=0 then '否' else '是' end)showislock,
		 a.height,a.[weight],a.bloodtype,a.Education,-1,
		 a.Name as VName, a.CardNo, a.Tel, a.BulidDate,b.Y_ID,
		 '' as GenerallySaleCompay
  from VIPCard a
  left join  billidx b     on a.VIPCardID=b.VIPCardID 
  left join  VIPCardType c on a.CT_ID=c.ct_id 
  left join  employees   d on a.E_id =d.emp_id 
  left join  company     e on a.Y_ID =e.company_id
  left join  company     f on b.Y_ID =f.company_id
  where a.Y_ID>=@Yid1 and  a.Y_ID<=@Yid2 
        and (Month(a.Birthday))>=@bmonth1 and (Month(a.Birthday))<=@bmonth2
        and (DAY(a.Birthday))  >=@bday1   and (DAY(a.Birthday))  <=@bday2
        and a.Deleted=0
  /*-最后消费日期     */
  insert into #t2  
  select distinct  VIPCardID,MAX(lastsaledate) 
  from #t1
  group by VIPCardID
  /*-消费最多的门店*/
  insert into #t4  
  select a.VIPCardID,a.SumSaleCs,c.LastSaleMd from
	(
	   select MAX(SumSaleCs) as SumSaleCs,VIPCardID from 
			  (
				  select  VIPCardID,COUNT(Y_id)  as SumSaleCs,Y_id,LastSaleMd
				  from #t1 
				  where LastSaleMd<>''
				  group by Y_id,LastSaleMd,VIPCardID
			   )a group by VIPCardID
	) a
	inner join
	(
			  select  VIPCardID, COUNT(Y_id)  as SumSaleCs,ISNULL(LastSaleMd,'') as LastSaleMd,Y_id
			  from #t1  
			  where LastSaleMd<>'' 
			  group by Y_id,LastSaleMd,VIPCardID 
	) c  on a.VIPCardID = c.VIPCardID and a.SumSaleCs = c.SumSaleCs
         order by c.LastSaleMd
  /*-修改最多消费门店*/
  update #t1 set GenerallySaleCompay=b.GenerallySaleCompay from #t1 a,#t4 b where a.VIPCardID=b.VIPCardID
  /*-最后消费门店 */
  insert into #t3  
  select distinct  VIPCardID,MAX(lastsaledate),ISNULL(LastSaleMd,'')  
  from #t1
  group by VIPCardID,LastSaleMd
  /*修改最后消费日期数据*/
  update #t1 set lastsaledate=b.sDatetime,saleday=(ceiling(datediff(dd,b.sDatetime,GETDATE())))
  from #t1 a,#t2 b
  where a.VIPCardID=b.VIPCardID
  /*修改最后消费门店数据*/
  update #t1 set LastSaleMd=b.sMdName
  from #t1 a,#t3 b
  where a.VIPCardID=b.VIPCardID and a.lastsaledate=b.sDatetime
  /*返回结果*/
  select distinct 
    CAST(0 as bit) as checked, 
    VIPCardID ,
    Yname, 
    sex ,
    ename ,
    ct_Type ,
    cname,
    isBank ,
    isIntegral ,
    /*age,*/
    (
    Case 
    when age>=0 and age<10 then   '0--10岁'
    when age>=10 and age<15 then  '10--15岁'
    when age>=15 and age<20 then  '15--20岁'
    when age>=20 and age<25 then  '20--25岁'
    when age>=25 and age<30 then  '25--30岁'
    when age>=30 and age<35 then  '30--35岁'
    when age>=35 and age<40 then  '35--40岁'
    when age>=40 and age<45 then  '40--45岁'
    when age>=45 and age<50 then  '45--50岁'
    when age>=50 and age<55 then  '50--55岁'
    when age>=55 and age<60 then  '55--60岁'
    when age>=60 and age<65 then  '60--65岁'
    when age>=65 and age<70 then  '65--70岁'
    when age>=70            then  '70岁以上'
    else 
      ''
    end ) ageqj,
    /*Cmonth ,*/
    (
    Case 
    when Cmonth >=0  and Cmonth <1 then   '不足1月'
    when Cmonth >=1  and Cmonth <3 then   '1--3月'
    when Cmonth >=3  and Cmonth <6 then   '3--6月'
    when Cmonth >=6  and Cmonth <12 then  '6--12月'
    when Cmonth >=12 and Cmonth <24 then  '1年--2年'
    when Cmonth >=24 and Cmonth <36 then  '2年--3年'
    when Cmonth >=36 and Cmonth <48 then  '3年--4年'
    when Cmonth >=48 and Cmonth <60 then  '4年--5年'
    when Cmonth >=60 and Cmonth <72 then  '5年--6年'
    when Cmonth >=72 and Cmonth <84 then  '6年--7年'
    when Cmonth >=84 and Cmonth <96 then  '7年--8年'
    when Cmonth >=96 and Cmonth <108 then '8年--9年'
    when Cmonth >=108 and Cmonth <120 then '9年--10年'
    when Cmonth >=120                 then '10年以上'
    else 
      ''
    end ) Cmonthqj,
    /*lastsaledate , */
    (
      Case 
      when  saleday>=0  and  saleday<7 then '1周以内'
      when  saleday>=7  and  saleday<30 then '1周--1月'
      when  saleday>=30 and  saleday<90 then '1月--3月'
      when  saleday>=90 and  saleday<180 then '3月--6月'
      when  saleday>=180 and  saleday<365 then '6月--1年'
      when  saleday>=365  then '1年以上'
      else
         ''
      end
     ) lastsale,
    BuyCount ,
    TotalBuyMoney ,
    ljIntegral,
    Integral ,
    SaveMoney ,
    RemainderMoney,
    showLose ,
    showStopUse ,
    showislock ,
    height ,
    cweight ,
    bloodtype ,
    Education,
	VName,
	CardNo,
	Tel,
	LastSaleMd, 
	lastsaledate,
	BuildDate,
	GenerallySaleCompay
   from #t1
   order by VIPCardID
 
   drop table #t1
   drop table #t2
   drop table #t3
   drop table #t4
END
GO
