














CREATE	VIEW dbo.vw_L_BillIDX
AS
SELECT b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype,b.c_id,b.inputman, b.y_id,
      billname = CASE b.billtype WHEN 10 THEN '销售出库单' WHEN 11 THEN '销售出库退货单' WHEN
       12 THEN '零售单' WHEN 13 THEN '零售退货单' WHEN 14 THEN '销售定单' WHEN 15 THEN
       '收款单' WHEN 20 THEN '采购入库单' WHEN 21 THEN '采购入库退货单' WHEN 22 THEN '进货定单'
       WHEN 23 THEN '付款单' WHEN 30 THEN '借出单' WHEN 31 THEN '借出还回单' WHEN
       32 THEN '借出转销售单' WHEN 33 THEN '借进单' WHEN 34 THEN '借进还出单' WHEN 35
       THEN '借进转进货单' WHEN 40 THEN '组装单' WHEN 41 THEN '报损单' WHEN 42 THEN
       '报溢单' WHEN 43 THEN '调价单' WHEN 44 THEN '调拨单' WHEN 45 THEN '变价调拨单'
       WHEN 46 THEN '赠送单' WHEN 47 THEN '获赠单' WHEN 48 THEN '入库单' WHEN 49 THEN
       '出库单' WHEN 60 THEN '现金费用单' WHEN 61 THEN '费用单' WHEN 62 THEN '其它收入单'
       WHEN 63 THEN '现金转帐单' WHEN 64 THEN '应收增加' WHEN 65 THEN '应收减少' WHEN
       66 THEN '应付增加' WHEN 67 THEN '应付减少' WHEN 68 THEN '资金增加' WHEN 69 THEN
       '资金减少' WHEN 80 THEN '固定资产购置' WHEN 81 THEN '固定资产变卖' WHEN 82 THEN
       '固定资产折旧' WHEN 83 THEN '待摊费用发生' WHEN 84 THEN '待摊费用摊销' WHEN 90
       THEN '会计凭证' WHEN 100 THEN '发货单' WHEN 101 THEN '发货退货单' WHEN 102 THEN
       '发货结算单' WHEN 103 THEN '发货调价单' WHEN 110 THEN '委托代销单' WHEN 111 THEN
       '委托代销退货单' WHEN 112 THEN '委托代销结算单' WHEN 113 THEN '委托代销调价' WHEN
       120 THEN '受托代销单' WHEN 121 THEN '受托代销退货单' WHEN 122 THEN '受托代销结算单'
       WHEN 123 THEN '受托代销调价' WHEN 130 THEN '库外入库单' WHEN 131 THEN '库外出库单'
       WHEN 53 THEN '配送出库单' WHEN 54 THEN '配送出库退货单' WHEN 55 THEN '配送出库退货单'
       WHEN 56 THEN '配送入库退货单' WHEN 151 THEN '机构发货退货单' WHEN 152 THEN '自营店发货单' 
       WHEN 150 THEN '机构发货单' WHEN 162 THEN '自营店收货单' WHEN 160 THEN '机构收货单' 
       WHEN 161 THEN '机构收货退货单' WHEN 163 THEN '自营店收货退货单'
       ELSE '' END, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.e_id), '') AS employeename, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.auditman), '') AS auditmanname, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.inputman), '') AS inputmanname, isnull
          ((SELECT [name]
          FROM account a
          WHERE a.account_id = b.a_id), '') AS accountname, isnull
          ((SELECT [name]
          FROM department d
          WHERE d .departmentid = b.department_id), '') AS departmentname, isnull
          ((SELECT [name]
          FROM region r
          WHERE r.region_id = b.region_id), '') AS regionname
FROM billidx b, productdetail pd
WHERE b.billid = pd.billid AND b.billstates = '0'
GROUP BY b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype, b.e_id, b.auditman, 
      b.inputman, b.a_id, b.department_id, b.region_id,b.c_id,b.y_id
union

SELECT b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype,b.c_id,b.inputman,b.y_id, 
      billname = CASE b.billtype WHEN 210 THEN '销售单' WHEN 211 THEN '销售退货单' WHEN
       212 THEN '发货单'  ELSE '' END, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.e_id), '') AS employeename, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.auditman), '') AS auditmanname, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.inputman), '') AS inputmanname, isnull
          ((SELECT [name]
          FROM account a
          WHERE a.account_id = b.a_id), '') AS accountname, isnull
          ((SELECT [name]
          FROM department d
          WHERE d .departmentid = b.department_id), '') AS departmentname, isnull
          ((SELECT [name]
          FROM region r
          WHERE r.region_id = b.region_id), '') AS regionname
FROM billidx b, salemanagebill pd
WHERE b.billid = pd.bill_id AND b.billstates = '0' and b.billtype in (210,211,212)
GROUP BY b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype, b.e_id, b.auditman, 
      b.inputman, b.a_id, b.department_id, b.region_id,b.c_id,b.y_id
union
SELECT b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype,b.c_id,b.inputman,b.y_id, 
      billname = CASE b.billtype WHEN 220 THEN '采购单' WHEN 211 THEN '采购退货单' WHEN
       212 THEN '收货单'  ELSE '' END, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.e_id), '') AS employeename, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.auditman), '') AS auditmanname, isnull
          ((SELECT [name]
          FROM employees e
          WHERE e.emp_id = b.inputman), '') AS inputmanname, isnull
          ((SELECT [name]
          FROM account a
          WHERE a.account_id = b.a_id), '') AS accountname, isnull
          ((SELECT [name]
          FROM department d
          WHERE d .departmentid = b.department_id), '') AS departmentname, isnull
          ((SELECT [name]
          FROM region r
          WHERE r.region_id = b.region_id), '') AS regionname
FROM billidx b,buymanagebill pd
WHERE b.billid = pd.bill_id AND b.billstates = '0' and b.billtype in (220,221,222)
GROUP BY b.billid, b.billdate, b.billstates, b.billnumber, b.note, b.summary, b.quantity, b.sin_id,b.sout_id,
      b.ysmoney, b.ssmoney,b.araptotal, b.taxrate, b.auditdate, b.billtype, b.e_id, b.auditman, 
      b.inputman, b.a_id, b.department_id, b.region_id,b.c_id,b.y_id
GO
