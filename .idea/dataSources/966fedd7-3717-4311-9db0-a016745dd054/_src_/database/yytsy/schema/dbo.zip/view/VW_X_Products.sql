


CREATE  VIEW DBO.VW_X_Products
AS
SELECT PRO.[Product_ID], PRO.[Class_ID], PRO.[Parent_ID], PRO.[Child_number], PRO.[Child_Count], 
      PRO.[Name], PRO.[Alias], PRO.[Standard], PRO.[Modal], PRO.[PermitCode], PRO.[TradeMark], 
      PRO.[MakeArea], PRO.[Rate2], PRO.[Rate3], PRO.[Rate4], PRO.[ValidMonth], PRO.[ValidDay], 
      PRO.[Comment], PRO.[Deleted], PRO.[FirstCheck], PRO.[Pinyin], PRO.[ValidCheck], PRO.[OTCFlag], 
      PRO.[GSPFlag],PRO.[Deduct], PRO.[Costmethod],CAST(tx.TaxRate AS NUMERIC(18, 4)) as [TaxRate], pro.EngName,
      pro.ChemName,pro.LatinName,pro.PackStd,pro.StorageCon,pro.RegisterNo,pro.BulidNo,
      pro.Factory, 
      /*PRO.[Serial_Number] AS [Code], */
       PRO.[Serial_Number] AS [Code], 
      ISNULL(U1.[Name], '')  AS UnitName1, 
      ISNULL(U2.[Name], '')  AS UnitName2, 
      ISNULL(U3.[Name], '')  AS UnitName3, 
      ISNULL(U4.[Name], '')  AS UnitName4, 
      ISNULL(M.medtype,'') AS [Medtype],
      isnull(pc.[Pc_Name],'') as PcName,
      PRO.Custompro1,PRO.Custompro2,PRO.Custompro3,PRO.Custompro4,PRO.Custompro5,
      PRO.Inputdate,PRO.Inputman,
      r.RangeName as rname
FROM ProductS PRO 
	  left join VW_MedType m on pro.product_id = m.product_id
      LEFT JOIN Unit U1       ON PRO.[Unit1_ID]=U1.[Unit_ID]
      LEFT JOIN Unit U2       ON PRO.[Unit2_ID]=U2.[Unit_ID]
      LEFT JOIN Unit U3       ON PRO.[Unit3_ID]=U3.[Unit_ID]
      LEFT JOIN Unit U4       ON PRO.[Unit4_ID]=U4.[Unit_ID]
	  left   join VW_Range r on PRO.product_id = r.product_id
      Left join PrintClass pc on pro.[PrintClass]=pc.[pc_ID]
      left   join VW_TaxRate tx on PRO.product_id = tx.product_id

WHERE PRO.[Deleted] <>1 and pro.IsSplit = 0
GO
