

CREATE VIEW dbo.vw_Storage
AS
  SELECT s.*,s.Y_ID as SY_ID, isnull(y.[name],'') as SY_name,isnull(Y.Class_ID,'') as YClass_ID,
      sType = CASE s.Flag WHEN 0 THEN '配送中心仓库' WHEN 1 THEN '自营店' when 2 then '加盟店' END
   ,(case WholeFlag when 1 then '整货库' when 2 then '零货库' when 3 then '零售拆零库' else '[无]' end) as wholeFlagName,
   isnull(X.name,'') as Fzr_name,isnull(X1.name,'') as Bgy_name, 
   CASE s.StoreCondition WHEN 0 THEN '常温' WHEN 1 THEN '阴凉' WHEN 2 THEN '冷藏' ELSE '' END AS StoreConditionS,
   CASE s.QualityFlag WHEN 0 THEN '合格品库' WHEN 1 THEN '不合格品库' WHEN 2 THEN '待退厂库' ELSE '' END AS QualityFlagS
FROM dbo.storages s  left join company y ON s.Y_ID=y.company_id
left join  employees X  on  X.emp_id=s.Fzr_ID
left join  employees X1 ON  X1.emp_id=s.Bgy_ID
WHERE S.deleted = 0
GO
