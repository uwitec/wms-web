
CREATE VIEW dbo.vw_L_YProductdetail
AS

  SELECT YP.* ,
  invoicetype=(
  case YP.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end), 
  isnull((case when YP.billtype not in (150,151,155,160,161,165) then c.class_id else CY.class_id end), '')CClass_ID,      
  ISNULL((case when YP.billtype not in (150,151,155,160,161,165) then c.[name] else CY.[name] END), '') as Cname, 
  ISNULL((case when YP.billtype not in (150,151,155,160,161,165) then c.address else CY.opaddress end),'') as cAddress, 
  ISNULL((case when YP.billtype not in (150,151,155,160,161,165) then c.Phone_Number else CY.tel end), '') as cPhone_Number,
  ISNULL((case when YP.billtype not in (150,151,155,160,161,165) then c.Contact_Personal else CY.manager end), '') as cContact_personal,
  ISNULL(E.class_id,'')EClass_ID,        ISNULL(E.[name],'')Ename,
  ISNULL(AE.class_id,'')Auditmanclass_id,ISNULL(AE.[name],'')Auditmanname,
  ISNULL(IE.class_id,'')Inputmanclass_id,ISNULL(IE.[name],'')Inputmanname,      
  ISNULL(D.[name],'')Departname,
  ISNULL(R.[name],'')Regionname,
  ISNULL(Y.class_id,'')Yclass_ID, ISNULL(Y.[name],'')Yname,
  ISNULL(P.class_id,'')Pclass_ID, ISNULL(P.[name],'')Pname,
  ISNULL(S.Class_id,'')Sclass_ID, ISNULL(s.[name],'')Sname,
  ISNULL(SL.class_id,'')supplierClass_ID,ISNULL(SL.[name],'')suppliername,
  ISNULL(L.loc_name,'')locname,
  ISNULL(RE.class_id,'')REClass_ID,ISNULL(RE.[name],'')REname,
  ISNULL(U.[NAME],'')unitname

  FROM  YProductdetail YP
  
   LEFT OUTER JOIN  clients    c  ON YP.C_id=c.client_id
   LEFT OUTER JOIN  employees  E  ON YP.e_id=E.emp_id
   LEFT OUTER JOIN  employees  AE ON YP.auditman=AE.emp_id
   LEFT OUTER JOIN  employees  IE ON YP.inputman=IE.emp_id
   LEFT OUTER JOIN  department D  ON YP.department_id=D.departmentId
   LEFT OUTER JOIN  Region     R  ON YP.region_id=R.region_id
   LEFT OUTER JOIN  Company    Y  ON YP.Y_id=Y.company_id
   LEFT OUTER JOIN  products   P  ON YP.p_id=P.product_id
   LEFT OUTER JOIN  storages   S  ON YP.s_id=S.storage_id
   LEFT OUTER JOIN  clients    SL ON YP.supplier_id=SL.client_id
   LEFT OUTER JOIN  location   L  ON YP.location_id=L.loc_id
   LEFT OUTER JOIN  employees  RE ON YP.RowE_id=RE.emp_id
   LEFT OUTER JOIN  unit       U  ON YP.unitid=U.unit_id
   LEFT OUTER JOIN  Company    CY on YP.C_id=CY.company_id
GO
