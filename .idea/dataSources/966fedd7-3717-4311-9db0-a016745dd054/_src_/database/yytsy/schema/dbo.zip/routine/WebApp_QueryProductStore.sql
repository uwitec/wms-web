/*单品库存查询*/
CREATE proc WebApp_QueryProductStore
(@s_id int = 0, 
 @p_id int = 0,


 @RetMessage varchar(200) out 
)
as
begin
  declare @User_id int, @permission int,@e_id int,@standard varchar(100)
  --select @User_id = dbo.webapp_get_param(@Params, 'user_id', default, default)
  --select @standard = dbo.webapp_get_param(@Params, 'standard', default, default)
  select @standard = '%' + @standard + '%'
  select @permission=permission 
    from WebAPP_UserRight
   where UserID = @User_id
     and Data_id = (select MenuID from TeenySoftMaster.dbo.WebAPP_Menus where MenuCode = 'sp_costprice') --库存成本查看权限
  select @e_id = e_id from Users where user_id=@User_id

  select @RetMessage = '操作成功'
  
    select k.serial_number as kcode,  --仓库编号
           k.[name] as sname,         --仓库名称
           p.serial_number as pcode,  --商品编号
           p.[name] as pname,         --商品名称
           p.alias as alias,         --yyt商品通用名
           p.standard,                --商品规格
           p.Modal,					  --商品型号
           p.Medtype,                 --商品类型 
           p.makearea,                --yyt
           p.Factory,                 --yyt 
           p.permitcode,              --yyt
           p.Unit1Name as unitname,
           p.Unit2Name as unitname2,--换算单位名称二
           p.Unit3Name as unitname3,--换算单位名称三
           p.Unit4Name as unitname4,--换算单位名称四
           p.Rate2 as Rate2,--换算比例二
           p.Rate3 as Rate3,--换算比例上
           p.Rate4 as Rate4,--换算比例四   
           s.quantity,                --数量 
           case when @permission=0 then 0 else s.costprice END AS costprice,               --成本单价 
           case when @permission=0 then 0 else s.costtotal END AS costtotal,               --成本金额
           ISNULL(s.batchno,'') AS bacthno,
           ISNULL(c1.name,'') as supplier_name,
			CONVERT(VARCHAR(10),s.validdate,120) AS validate,
			CONVERT(VARCHAR(10),s.makedate,120) AS makedate,
           ISNULL(l.loc_name,'') AS location_name,
           CASE WHEN s.commissionflag=1 THEN '受托' when s.commissionflag=2 THEN '委托' else '' end as commissionflagname,
           y.name AS YName   --yyt
      from storehouse s 
       INNER JOIN company y ON s.Y_ID = y.company_id
       join vw_products p on s.p_id=p.product_id
       join storages k on s.s_id=k.storage_id
		 LEFT JOIN clients c1 ON c1.client_id=s.supplier_id
		 LEFT JOIN location l ON l.loc_id=s.location_id
     where (@s_id=0 or s.s_id=@s_id)
       and (@p_id=0 or s.p_id=@p_id)    
       --and (@standard='%%' or p.standard like @standard)
       --and s.s_id in (select storage_id from dbo.AuthorizeStorage(@e_id))--仓库授权
end
GO
