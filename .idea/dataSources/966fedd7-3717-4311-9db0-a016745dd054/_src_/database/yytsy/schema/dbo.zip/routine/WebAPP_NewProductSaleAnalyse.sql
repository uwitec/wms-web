/**************************************************************
app_yyt最近新品查询
**************************************************************/
create proc WebAPP_NewProductSaleAnalyse
(
  @chvparams  varchar(400) = '',
  @retmessage varchar(200) OUT
)
--$encode$--
as
BEGIN
	--DECLARE @a VARCHAR(200)
    --EXEC WebAPP_NewProductSaleAnalyse;1 'y_id=2;mode=2;class_id=001561',@a
	
	IF object_id(N'#NewProduct', N'U') is not null
		Drop Table #NewProduct
	
	CREATE TABLE #NewProduct 
	(
		product_id     INT NULL DEFAULT(0) , 
		serial_number  VARCHAR(60) NULL DEFAULT('') ,
		NAME           VARCHAR(200) NULL DEFAULT('') ,
		[standard]     VARCHAR(100) NULL DEFAULT('') ,
		permitcode     VARCHAR(100) NULL DEFAULT('') ,
		Factory     VARCHAR(100) NULL DEFAULT('') ,
		makearea     VARCHAR(100) NULL DEFAULT('')
	)
	
	SET @retmessage = '操作成功'

	DECLARE @YId      INT,              --机构ID
	        @Mode     INT,              --0 15天；1 30天；2 90天
			@Begin    VARCHAR(100),
			@End      VARCHAR(100),
			@Class_Id VARCHAR(60)       --商品类别Id

	SET @YId = dbo.webapp_get_param(@chvparams, 'y_id', default, default)
	SET @Mode = dbo.webapp_get_param(@chvparams, 'mode', default, default)
	SET @Class_Id = dbo.webapp_get_param(@chvparams, 'class_id', default, default)
	
	IF @Mode = 0
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -15, GETDATE()) AS DATETIME), 23)
	ELSE
	IF @Mode = 1
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -30, GETDATE()) AS DATETIME), 23)
	ELSE
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -90, GETDATE()) AS DATETIME), 23)
	SET @End = CONVERT(VARCHAR(100), GETDATE(), 23)
	
	INSERT INTO #NewProduct(product_id, serial_number, NAME, [standard], permitcode, Factory, makearea)
	SELECT d.product_id, d.serial_number, d.name + '(' + CAST(DATEDIFF(DAY, e.InStoreTime, GETDATE()) AS VARCHAR) + '天前)' AS Name,
	       d.[standard], d.permitcode, d.Factory, d.makearea 
		FROM (
			SELECT p.product_id, p.serial_number, p.name, p.[standard], p.permitcode, p.Factory, p.makearea
			  FROM products p 
			WHERE LEFT(P.[Class_ID], LEN(@Class_Id))=@Class_Id AND p.child_number = 0	
		) d INNER JOIN (
			SELECT a.P_Id, a.InStoreTime 
				FROM ProductFirstInStoreTime a 
			WHERE a.Y_Id = 2 AND a.InStoreTime > @Begin	
		) e ON d.product_id = e.P_Id  
		 
    --返回的数据集
	SELECT p.serial_number,                            --编码
		   p.name,                                     --商品名
		   p.[standard],                               --规格 
		   p.permitcode,		                       --批准文号
		   p.makearea,                                 --产地
		   p.Factory,                                  --生产厂家 
		   a.quantity,                                 --数量 
		   a.taxtotal,                                 --金额
		   (a.taxtotal - a.costtaxtotal) AS taxtotalMl --毛利
	FROM (
		SELECT s.p_id, 
			   SUM(CASE WHEN b.billtype IN (10, 12, 150, 152) THEN s.quantity ELSE -s.quantity END) AS quantity, 
			   SUM(CASE WHEN b.billtype IN (10, 12, 150, 152) THEN s.taxtotal ELSE -s.taxtotal END) AS taxtotal,
			   SUM(CASE WHEN b.billtype IN (10, 12, 150, 152) THEN (1+s.taxrate)* s.taxtotal ELSE -(1+s.taxrate)* s.taxtotal END) AS costtaxtotal
			FROM billidx b, salemanagebill s    
		WHERE b.[BillID]=s.[Bill_ID] AND b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.[BillDate] BETWEEN @Begin AND @End AND 
			  b.[BillStates]='0' AND (b.Y_id = @YId or @YId=0) AND s.p_id > 0 AND s.aoid IN (0, 5) GROUP BY s.p_id	
	) a INNER JOIN #NewProduct p ON a.p_id = p.product_id
	ORDER BY (a.taxtotal - a.costtaxtotal) DESC
	
	IF object_id(N'#NewProduct', N'U') is not null
		Drop Table #NewProduct	
END
GO
