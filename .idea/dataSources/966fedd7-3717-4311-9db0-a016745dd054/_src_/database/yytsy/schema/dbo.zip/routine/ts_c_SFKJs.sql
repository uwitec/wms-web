





















/*@cflag	='0' 	缺省*/
/*	 			='B' 	按单结算*/
/*				='P' 	按行结算*/
/*@cMode 	='0': 结算 '1'：红冲*/
create    PROCEDURE ts_c_SFKJs
(
	@nBillId 		numeric(18,0),/*收付款单id号*/
	@nBillType 	numeric(10,0),
	@cFlag 		varchar(1),
	@cMode   		varchar(1)           
)
/*with encryption*/
AS
set nocount on
declare @dJsMoney NUMERIC(25,8),@nXsd_id numeric(18,0),@jsId numeric(10,0),@xsdp_id NUMERIC(25,8),
				@nDetailid numeric(10,0),/*单据明细id*/
				@dYetotal NUMERIC(25,8), /*余额*/
				@dQuantity NUMERIC(25,8),/*本次结算数量*/
				@dYjQuantity NUMERIC(25,8),/*已结数量*/
				@dWjQuantity NUMERIC(25,8),/*未结数量*/
				@dWjTotal NUMERIC(25,8),/*未结金额*/
				@dYjTotal NUMERIC(25,8),/*已结金额*/
				@jsTotal NUMERIC(25,8),/*本次结算金额*/
				@vchtype int,
				@oldjsTotal NUMERIC(25,8) /*记录本次结算金额*/


/**/
	declare @dDoubleZero NUMERIC(25,8)
	set @dDoubleZero=0.001
/*2005-06-28 zc modify 解决小数位数带来的误差。*/


if @cFlag='B'/*按单结算*/
begin
	declare jsye cursor for
	select jsid,xsd_bid,jstotal,billtype
	from jsbdetail where skd_bid=@nBillId and flag=0

	open jsye
	fetch next from jsye into @jsid,@nxsd_id,@djsmoney,@vchtype
	while @@fetch_status=0
	begin
	    set @oldjsTotal = @djsmoney
		if @vchtype not in (16,17,116,117,24,25) set @djsmoney=abs(@djsmoney) 
		else if  @vchtype in (24,25) set @djsmoney=-@djsmoney
		if @cMode='1' 
		begin
			select @djsmoney=-@djsmoney
			delete from jsbdetail  where jsid=@jsid
			if not exists (select * from jsbdetail where xsd_bid=@nxsd_id and flag=0)	set @cflag='0' 
		end

		select @dyetotal=jsye from billidx where billid=@nxsd_id
        
        /*Wsj-2017-03-24tfsbug 45803收款单余额问题。*/
        if (@nBillType in(15)) and (@dyetotal < 0.00) and (@oldjsTotal < 0.00)
        begin
          set @djsmoney = -@djsmoney
        end
        
		if @cMode='0' and abs(@dyetotal)<abs(@djsmoney)
		begin
			if abs(abs(@dyetotal)-abs(@djsmoney))>@dDoubleZero goto error1 else set @dyetotal=@djsmoney
		end

		update billidx set jsye=@dyetotal-@djsmoney,jsflag=@cflag where billid=@nxsd_id
		select @dYjTotal=isnull(sum(jstotal),0) from jsbdetail where xsd_bid=@nxsd_id and billtype=@vchtype and flag=0
		update jsbdetail set remaintotal=@dyetotal where jsid=@jsid
		fetch next from jsye into @jsid,@nxsd_id,@djsmoney,@vchtype
	end
	close jsye
	deallocate jsye
	return 0
end

if @cflag='P' /*按行结算*/
begin
  declare @cqty NUMERIC(25,8)   /*结算后的数量*/
  declare @qty NUMERIC(25,8)   /*单据明细数量*/
  declare jsye cursor for
  select jsid,xsd_bid,jstotal,quantity,detail_id,billtype
  from jspdetail where skd_bid=@nbillid and flag=0

  open jsye
  fetch next from jsye into @jsid,@nxsd_id,@djsmoney,@dQuantity,@xsdp_id,@vchtype
  while @@fetch_status=0
  begin
	  if @vchtype not in (16,17,116,117,24,25) set @djsmoney=abs(@djsmoney) 
	  else if @vchtype in (24,25) set @djsmoney=-@djsmoney

		if @cmode='1' 
		begin
			select @djsmoney=-@djsmoney
			delete from jspdetail where jsid=@jsid
			if not exists (select * from jspdetail where xsd_bid=@nxsd_id and flag=0) set @cflag='0' 
		end

		select @dyetotal=jsye from billidx where billid=@nxsd_id

			
		if @cMode='0'  and abs(@dyetotal)<abs(@djsmoney) 
		begin
			if abs(abs(@dyetotal)-abs(@djsmoney))>@dDoubleZero goto error1 
			else set @dyetotal=@djsmoney
		end 

		/*对按行结算每行还单独检查*/
        if @cqty = null set @cqty = 0
        if @qty = null set @qty = 0		
		SELECT @cqty = isnull(SUM(quantity),0) FROM jspdetail j WHERE xsd_bid =@nxsd_id and detail_id = @xsdp_id and j.Flag =0 
		select @qty = isnull(SUM(quantity),0) from (
			 select bill_id,smb_id,quantity from salemanagebill where bill_id = @nxsd_id and smb_id = @xsdp_id
			 union all
			 select bill_id,smb_id,quantity from buymanagebill where bill_id = @nxsd_id and smb_id = @xsdp_id
			) d 

        
        if abs(@cqty)-abs(@qty) >@dDoubleZero  goto error1   /*按行结算判断每行的量是否超过*/

		update billidx set jsye=@dyetotal-@djsmoney,jsflag=@cflag where billid=@nxsd_id
		select @dYjQuantity=isnull(sum(quantity),0) from jspdetail where detail_id=@xsdp_id and billtype=@vchtype and flag=0
		update jspdetail set yj_quantity=@dYjQuantity where jsid=@jsid

		fetch next from jsye into @jsid,@nxsd_id,@djsmoney,@dQuantity,@xsdp_id,@vchtype
	end
	close jsye
	deallocate jsye
	return 0
end

return 0


error1:
	close jsye
	deallocate jsye
	return -101
GO
