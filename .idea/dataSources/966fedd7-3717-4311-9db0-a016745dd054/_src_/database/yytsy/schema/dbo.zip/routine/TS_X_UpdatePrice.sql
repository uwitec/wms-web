



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*************************************************************************************

根据商品的单位之间的换算关系，用基本单位单价*数量换算比例=其它单位单价
参数
@lMode 0 如果其它单位单价已经存在，就不进行计算
@lMode 1 不管其它单位单价是否存在，全部重新计算

执行方法：可以用外挂执行，可以在SQL查询分析器中执行 EXEC TS_X_UpdatePrice 0

*************************************************************************************/
CREATE PROCEDURE TS_X_UpdatePrice
(  @lMode   INT=1,
   @cMode   VARCHAR(10)='', /*暂时不用*/
   @szParID VARCHAR(30)=''  /*暂时不用*/
)
AS
/*Params Ini begin*/
if @lMode is null  SET @lMode = 1
if @cMode is null  SET @cMode = ''
if @szParID is null  SET @szParID = ''
/*Params Ini end*/
  SET NOCOUNT ON

  DECLARE @P_ID INT, @lUnit2 INT, @lUnit3 INT, @lUnit4 INT, 
    @UnitRate2 NUMERIC(25,8), @UnitRate3 NUMERIC(25,8), @UnitRate4 NUMERIC(25,8),
    @Price2_ID INT, @Price3_ID INT, @Price4_ID INT,
    @Price1 NUMERIC(25,8), @Price2 NUMERIC(25,8), @Price3 NUMERIC(25,8), @Price4 NUMERIC(25,8),
    @RetailPrice NUMERIC(25,8), @RecPrice NUMERIC(25,8), @Gpprice NUMERIC(25,8), @Glprice NUMERIC(25,8),
    @Specialprice NUMERIC(25,8), @Lowprice NUMERIC(25,8)

BEGIN TRAN UpDatePrice
  IF @lMode=1 DELETE FROM Price WHERE [Unittype]<>1 

  DECLARE CurBill CURSOR SCROLL FOR
   SELECT [Product_ID] FROM Products WHERE [Deleted]<>1
	OPEN CurBill
	FETCH NEXT FROM CurBill INTO @P_ID
	WHILE @@FETCH_STATUS=0
  BEGIN
    SELECT @lUnit2=ISNULL([Unit2_ID], 0), @UnitRate2=ISNULL([Rate2], 0), 
    @lUnit3=ISNULL([Unit3_ID], 0), @UnitRate3=ISNULL([Rate3], 0),
    @lUnit4=ISNULL([Unit4_ID], 0), @UnitRate4=ISNULL([Rate4], 0)
    FROM Products WHERE [Product_ID]=@P_ID

/*修改单价2*/
    IF @lUnit2<>0 AND @UnitRate2<>0
    BEGIN
      SELECT @Price1=ISNULL([Price1], 0), @Price2=ISNULL([Price2], 0), @Price3=ISNULL([Price3], 0),
        @Price4=ISNULL([Price4], 0), @RetailPrice=ISNULL([RetailPrice], 0), 
        @RecPrice=ISNULL([RecPrice], 0), @Gpprice=ISNULL([Gpprice], 0), @Glprice=ISNULL([Glprice], 0),
        @Specialprice=ISNULL([Specialprice], 0), @Lowprice=ISNULL([Lowprice], 0) 
      FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=1
      SELECT @Price2_ID=ISNULL([Price_ID], 0) FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=2

      IF @Price2_ID=0 OR @Price2_ID IS NULL
      BEGIN
        INSERT INTO Price([P_ID], [U_ID], [RetailPrice], [RecPrice], [Price1],
          [Price2], [Price3], [Price4], [Gpprice], [Glprice],
          [Specialprice], [Lowprice], [Unittype])
        VALUES (@P_ID, @lUnit2, 
        ISNULL(@RetailPrice*@UnitRate2 , 0), ISNULL(@RecPrice*@UnitRate2 , 0), 
        ISNULL(@Price1*@UnitRate2 , 0), ISNULL(@Price2*@UnitRate2 , 0), 
        ISNULL(@Price3*@UnitRate2 , 0), ISNULL(@Price4*@UnitRate2 , 0), 
        ISNULL(@Gpprice*@UnitRate2 , 0), ISNULL(@Glprice*@UnitRate2 , 0), 
        ISNULL(@Specialprice*@UnitRate2 , 0), ISNULL(@Lowprice*@UnitRate2 , 0), 
        2)
      END
      ELSE
      BEGIN
        UPDATE Price
        SET [P_ID]=@P_ID, [U_ID]=@lUnit2,
        [RetailPrice]=ISNULL(@RetailPrice*@UnitRate2 , 0),  [RecPrice]=ISNULL(@RecPrice*@UnitRate2 , 0),
        [Price1]=ISNULL(@Price1*@UnitRate2 , 0),  [Price2]=ISNULL(@Price2*@UnitRate2 , 0),
        [Price3]=ISNULL(@Price3*@UnitRate2 , 0),  [Price4]=ISNULL(@Price4*@UnitRate2 , 0),
        [Gpprice]=ISNULL(@Gpprice*@UnitRate2 , 0),  [Glprice]=ISNULL(@Glprice*@UnitRate2 , 0),
        [Specialprice]=ISNULL(@Specialprice*@UnitRate2 , 0),  [Lowprice]=ISNULL(@Lowprice*@UnitRate2 , 0),
        [Unittype]=2
        WHERE [Price_ID]=@Price2_ID
      END
    END

/*修改单价3*/
    IF @lUnit3<>0 AND @UnitRate3<>0
    BEGIN
      SELECT @Price1=ISNULL([Price1], 0), @Price2=ISNULL([Price2], 0), @Price3=ISNULL([Price3], 0),
        @Price4=ISNULL([Price4], 0), @RetailPrice=ISNULL([RetailPrice], 0), 
        @RecPrice=ISNULL([RecPrice], 0), @Gpprice=ISNULL([Gpprice], 0), @Glprice=ISNULL([Glprice], 0),
        @Specialprice=ISNULL([Specialprice], 0), @Lowprice=ISNULL([Lowprice], 0) 
      FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=1
      SELECT @Price3_ID=ISNULL([Price_ID], 0) FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=3

      IF @Price3_ID=0 OR @Price3_ID IS NULL
      BEGIN
        INSERT INTO Price([P_ID], [U_ID], [RetailPrice], [RecPrice], [Price1],
          [Price2], [Price3], [Price4], [Gpprice], [Glprice],
          [Specialprice], [Lowprice], [Unittype])
        VALUES (@P_ID, @lUnit3, 
        ISNULL(@RetailPrice*@UnitRate3 , 0), ISNULL(@RecPrice*@UnitRate3 , 0), 
        ISNULL(@Price1*@UnitRate3 , 0), ISNULL(@Price2*@UnitRate3 , 0), 
        ISNULL(@Price3*@UnitRate3 , 0), ISNULL(@Price4*@UnitRate3 , 0), 
        ISNULL(@Gpprice*@UnitRate3 , 0), ISNULL(@Glprice*@UnitRate3 , 0), 
        ISNULL(@Specialprice*@UnitRate3 , 0), ISNULL(@Lowprice*@UnitRate3 , 0), 
        3)
      END
      ELSE
      BEGIN
        UPDATE Price
        SET [P_ID]=@P_ID, [U_ID]=@lUnit3,
        [RetailPrice]=ISNULL(@RetailPrice*@UnitRate3 , 0),  [RecPrice]=ISNULL(@RecPrice*@UnitRate3 , 0),
        [Price1]=ISNULL(@Price1*@UnitRate3 , 0),  [Price2]=ISNULL(@Price2*@UnitRate3 , 0),
        [Price3]=ISNULL(@Price3*@UnitRate3 , 0),  [Price4]=ISNULL(@Price4*@UnitRate3 , 0),
        [Gpprice]=ISNULL(@Gpprice*@UnitRate3 , 0),  [Glprice]=ISNULL(@Glprice*@UnitRate3 , 0),
        [Specialprice]=ISNULL(@Specialprice*@UnitRate3 , 0),  [Lowprice]=ISNULL(@Lowprice*@UnitRate3 , 0),
        [Unittype]=3
        WHERE [Price_ID]=@Price3_ID
      END
    END

/*修改单价4*/
    IF @lUnit4<>0 AND @UnitRate4<>0
    BEGIN
      SELECT @Price1=ISNULL([Price1], 0), @Price2=ISNULL([Price2], 0), @Price3=ISNULL([Price3], 0),
        @Price4=ISNULL([Price4], 0), @RetailPrice=ISNULL([RetailPrice], 0), 
        @RecPrice=ISNULL([RecPrice], 0), @Gpprice=ISNULL([Gpprice], 0), @Glprice=ISNULL([Glprice], 0),
        @Specialprice=ISNULL([Specialprice], 0), @Lowprice=ISNULL([Lowprice], 0) 
      FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=1
      SELECT @Price3_ID=ISNULL([Price_ID], 0) FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=3

      SELECT @Price4_ID=ISNULL([Price_ID], 0) FROM Price WHERE [P_ID]=@P_ID AND [Unittype]=4
      IF @Price4_ID=0 OR @Price4_ID IS NULL
      BEGIN
        INSERT INTO Price([P_ID], [U_ID], [RetailPrice], [RecPrice], [Price1],
          [Price2], [Price3], [Price4], [Gpprice], [Glprice],
          [Specialprice], [Lowprice], [Unittype])
        VALUES (@P_ID, @lUnit4, 
        ISNULL(@RetailPrice*@UnitRate4 , 0), ISNULL(@RecPrice*@UnitRate4 , 0), 
        ISNULL(@Price1*@UnitRate4 , 0), ISNULL(@Price2*@UnitRate4 , 0), 
        ISNULL(@Price3*@UnitRate4 , 0), ISNULL(@Price4*@UnitRate4 , 0), 
        ISNULL(@Gpprice*@UnitRate4 , 0), ISNULL(@Glprice*@UnitRate4 , 0), 
        ISNULL(@Specialprice*@UnitRate4 , 0), ISNULL(@Lowprice*@UnitRate4 , 0), 
        4)
      END
      ELSE
      BEGIN
        UPDATE Price
        SET [P_ID]=@P_ID, [U_ID]=@lUnit4,
        [RetailPrice]=ISNULL(@RetailPrice*@UnitRate4 , 0),  [RecPrice]=ISNULL(@RecPrice*@UnitRate4 , 0),
        [Price1]=ISNULL(@Price1*@UnitRate4 , 0),  [Price2]=ISNULL(@Price2*@UnitRate4 , 0),
        [Price3]=ISNULL(@Price3*@UnitRate4 , 0),  [Price4]=ISNULL(@Price4*@UnitRate4 , 0),
        [Gpprice]=ISNULL(@Gpprice*@UnitRate4 , 0),  [Glprice]=ISNULL(@Glprice*@UnitRate4 , 0),
        [Specialprice]=ISNULL(@Specialprice*@UnitRate4 , 0),  [Lowprice]=ISNULL(@Lowprice*@UnitRate4 , 0),
        [Unittype]=4
        WHERE [Price_ID]=@Price4_ID
      END
    END

  	FETCH NEXT FROM CurBill INTO @P_ID
	END
  CLOSE CurBill
  DEALLOCATE CurBill

  
  SELECT * INTO #TempPrice
  FROM (SELECT * FROM Price) Pr
  TRUNCATE TABLE Price
  INSERT INTO Price([P_ID], [U_ID], [RetailPrice], [RecPrice], [Price1],
    [Price2], [Price3], [Price4], [Gpprice], [Glprice],
    [Specialprice], [Lowprice], [Unittype])
  SELECT [P_ID], [U_ID], [RetailPrice], [RecPrice], [Price1],
    [Price2], [Price3], [Price4], [Gpprice], [Glprice],
    [Specialprice], [Lowprice], [Unittype]
  FROM #TempPrice 
  
  DROP TABLE #TempPrice


COMMIT TRAN UpDatePrice

  GOTO SUCCEE

SUCCEE:
 RETURN 0
GO
