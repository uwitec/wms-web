
Create PROCEDURE TS_q_ImportPhoneBook /*导入相关资料到phonebook,来自T3 TS_S_ImportPhoneBook  */
(/*@nType      int = 0,    */
 /*@nID        int = 0,    */
 @Group_id   int = 0,    
 @SourceType int = 0,    
 @SourceID   int = 0
)    
as begin    
  if @SourceType = 1 /*往来单位     */
  begin     
    if Exists(select * from PhoneBook where SourceType = @SourceType and SourceID = @SourceID and Group_id = @Group_id)    
    begin    
        UPDATE PhoneBook SET [Name]       = c.Contact_personal,    
                             [PhoneNo]    = c.Phone_Number,    
                             [ClientName] = c.[Name],    
                             [Email]      = '',    
                             [QQ]         = '',    
                             [Comment]    = c.[Comment]      
          FROM PhoneBook p,Clients c    
         WHERE SourceType = @SourceType     
           and Group_id = @Group_id    
           and SourceID   = @SourceID    
           and p.SourceID = c.Client_ID    
    end else    
    begin    
 INSERT INTO phonebook([Name],PhoneNO,ClientName,Email,QQ,Comment,Group_ID,SourceType,SourceID)    
 SELECT [Contact_personal],phone_number,[Name],'' as Email,'' as QQ,Comment,@Group_ID,@SourceType,Client_ID     
 FROM clients     
 WHERE deleted <> 1 and child_count = 0    
 and Client_ID = @SourceID       
    end    
  end else    
  if @SourceType = 2 /*会员    */
  begin    
    if Exists(select * from PhoneBook where SourceType = @SourceType and SourceID = @SourceID and Group_id = @Group_id)    
    begin    
        UPDATE PhoneBook SET [Name]       = c.[Name],    
                             [PhoneNo]    = c.Tel,    
                             [ClientName] = '',    
                             [Email]      = '',    
                             [QQ]         = '',    
                             [Comment]    = c.[Comment]      
          FROM PhoneBook p,vipcard c     
         WHERE SourceType = @SourceType     
           and Group_id = @Group_id    
           and SourceID   = @SourceID    
           and p.SourceID = c.VipCardID     
    end else    
    begin    
     INSERT INTO phonebook([Name],PhoneNO,ClientName,Email,QQ , Comment,Group_ID ,SourceType ,SourceID)    
     select [Name],[Tel],'' as ClientName,'' as Email,'' as QQ, Comment,@Group_ID,@SourceType,VipCardID    
       from vipcard    
      where VipCardID = @SourceID    
   end    
  end else     
  if @SourceType = 3 /*职员    */
  begin    
    if Exists(select * from PhoneBook where SourceType = @SourceType and SourceID = @SourceID and Group_id = @Group_id)    
    begin    
        UPDATE PhoneBook SET [Name]       = c.[Name],    
                             [PhoneNo]    = c.Phone,    
                             [ClientName] = '',    
                             [Email]      = '',    
                             [QQ]         = '',    
                             [Comment]    = c.[Comment]      
          FROM PhoneBook p,employees c    
         WHERE SourceType = @SourceType     
           and Group_id = @Group_id    
           and SourceID   = @SourceID    
           and p.SourceID = c.emp_ID        
    end else    
    begin    
     INSERT INTO phonebook([Name],PhoneNO,ClientName,Email,QQ       , Comment,Group_ID ,SourceType ,SourceID)    
     select [Name],Phone,'' as ClientName,'' as      EMail,'' as QQ , Comment,@Group_ID,@SourceType,emp_ID     
       from employees    
      where Child_Count = 0 and deleted <> 1    
        and emp_ID = @SourceID    
    end    
  end    
end
GO
