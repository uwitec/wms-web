
/*BUG:销售出库单过帐后在历史单据里面修改单据经手人，查询内部职员业务分析报表，应收金额未统计！ */
CREATE PROCEDURE TS_M_UPDATEClientArAp
(
	@New_E_Id 	int,	/*更新的职员ID*/
	@nBILLID 	int	/*单据ID*/
)
/*with encryption*/
AS

DECLARE @SQL 		varchar(8000)
DECLARE @Bill_E_Id 	int	/*被更新的职员ID*/
DECLARE	@ArTotal	Money
DECLARE	@ApTotal	Money

SELECT 	@Bill_E_Id=Emp_id,
        @ArTotal=CASE when (a.a_id=9)  then a.jdmoney else 0 end,
        @ApTotal=CASE when (a.a_id=15) then a.jdmoney else 0 end FROM Employees e
inner join (select * from billidx b where b.BILLID=@nBILLID) b on e.emp_id=b.e_id
inner join (select * from accountdetail a where a.a_id in (9,15)) a on b.billid=a.billid 


/*更新职员的应收应付金额*/
UPDATE  Employees SET ArTotal=isnull((isnull(ArTotal,0)-isnull(@ArTotal,0)),0),ApTotal=isnull((isnull(ApTotal,0)-isnull(@ApTotal,0)),0)  
WHERE 	Emp_id=@Bill_E_Id

UPDATE  Employees SET ArTotal=isnull((isnull(ArTotal,0)+isnull(@ArTotal,0)),0),ApTotal=isnull((isnull(ApTotal,0)+isnull(@ApTotal,0)),0)  
WHERE 	Emp_id=@New_E_Id


RETURN 0
GO
