
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-11*/
/* Description:	查询职员授权商品总提成*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepEmpDeduct] 
	@BeginDate		datetime,
	@EndDate		datetime,
	@EID			int
AS
BEGIN
	SET NOCOUNT ON;

SELECT     CAST(SUM(totalmoney) AS NUMERIC(25,8)) AS saletotal, name, deduct, SUM(quantity) AS quantity, SUM(costtotal) AS costtotal, SUM(taxtotal) AS taxtotal, 
                      CAST(deduct * SUM(totalmoney) as decimal(18, 8)) AS deducttotal, DepName, emp_id
FROM         (SELECT     CASE d .price WHEN 0 THEN - 1 ELSE 1 END * SUM(b.totalmoney) AS totalmoney, 
                                              CASE d .price WHEN 0 THEN - 1 ELSE 1 END * SUM(b.SendCostTotal) AS costtotal, 
                                              CASE d .price WHEN 0 THEN - 1 ELSE 1 END * SUM(b.taxtotal) AS taxtotal, CASE d .price WHEN 0 THEN - 1 ELSE 1 END * SUM(b.quantity) 
                                              AS quantity, e.name, e.deduct, ISNULL(dbo.department.name, '') AS DepName, e.emp_id
                       FROM          dbo.billidx AS i INNER JOIN
                                              dbo.salemanagebill AS b ON i.billid = b.bill_id RIGHT OUTER JOIN
                                              dbo.EmpDeduct AS d INNER JOIN
                                              dbo.employees AS e ON d.emp_id = e.emp_id LEFT OUTER JOIN
                                              dbo.department ON e.dep_id = dbo.department.departmentId ON b.p_id = d.p_id AND b.bill_id = d.bill_id
							WHERE     (e.emp_id BETWEEN CASE @EID WHEN 0 THEN 0 ELSE @EID END AND CASE @EID WHEN 0 THEN 0x7fffffff ELSE @EID END)AND (i.billdate BETWEEN @BeginDate AND
                       @EndDate) AND (i.billstates NOT IN (1, 4))
						   GROUP BY e.name, d.price, e.deduct, dbo.department.name, e.emp_id) AS p
	GROUP BY name, deduct, DepName, emp_id
END
GO
