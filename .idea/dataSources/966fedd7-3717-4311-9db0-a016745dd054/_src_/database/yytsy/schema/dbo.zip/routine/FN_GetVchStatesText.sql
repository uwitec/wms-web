
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-04-01*/
/* Description:	根据单据状态和单据类型返回文本*/
/* =============================================*/
CREATE FUNCTION FN_GetVchStatesText 
(
	@nState int,
	@nVchType int
)
RETURNS varchar(50)
AS
BEGIN
	DECLARE @Result varchar(50)

	SELECT @Result = stateText FROM VchStates WHERE stateId = @nState AND vchType = @nVchType
	
	IF @Result IS NULL
		SELECT @Result = stateText FROM VchStates WHERE stateId = @nState AND vchType = 0

	IF @Result IS NULL
		SET @Result = @nState

	RETURN @Result
END
GO
