/************************************************************

--功能：添加日结记录   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_AddDayAccount]
  (
   @nRet int output  
  )

AS 

declare @DA_ID int
set @DA_ID = @nRet
set @nRet = -1


declare @minDate datetime, @maxDate datetime, @nDBY_ID int, @szYName varchar(100)
select @minDate = max(enddate)+0.0001 from dayaccount
select @MaxDate = getdate()
if @minDate is null
 set @minDate = cast(cast(@maxDate as varchar(10)) as datetime)
select @nDBY_ID = cast(sysvalue as int) from sysconfig where [sysname] = 'Y_ID' 
select @szYname = [name] from company where company_id = @nDBY_ID


begin tran dayaccount
   /*----已经日结 后又反日结*/
    if @DA_ID > 0 
    begin     
      /*update upbilllist set DCFlag = 1 where mdDA_id <>0 and mdDA_ID = @DA_ID*/
      /*ifDayAccount  = 0*/
      update dayaccount set ifDayAccount  =1 where ifDayAccount <> 1 and [id] = @DA_ID
      update  billidx  set transcount=@DA_ID where transcount=-@DA_ID
      set @nRet = @DA_ID
      commit tran dayaccount
      return 0
    end
/*
    if not exists(select 1 from upbilllist where DCFlag = 0 and mdDA_ID = 0)
    begin
      insert into dayaccount(y_id, begindate, enddate, posRetailQty, posRetailtotal, 
                           posbackQty, posbackTotal,ifValidate,ifDayAccount,guid)

           select @nDBY_ID, @minDate, @MaxDate,0,0,0,0,0,0, newid()
	    if @@Error <> 0
	    begin
	      rollback tran  dayaccount
	      set @nRet = -1
	      return -1
	    end

       set @nRet = @@identity
       commit tran dayaccount
       return 0
    end
*/


    insert into dayaccount(y_id, begindate, enddate, posRetailQty, posRetailtotal, 
                           posbackQty, posbackTotal,ifValidate,ifDayAccount,guid)

           select bi.y_id, min(bi.RetailDate) as begindate, max(bi.RetailDate) as enddate,
                  sum(case bi.billtype when 12 then sm.quantity else 0 end) as PosRetailQty,
                  sum(case bi.billtype when 12 then sm.taxtotal else 0 end) as PosRetailTotal,
                  sum(case bi.billtype when 13 then sm.quantity else 0 end) as PosBackQty,
                  sum(case bi.billtype when 13 then sm.taxtotal else 0 end) as PosBackTotal, 
                  0,0, newid()
             from billidx bi 
             inner join salemanagebill sm on bi.billid = sm.bill_id
            /* inner join UpBillList up on bi.billid = up.mdbillid*/
             where bi.billtype in (12, 13) 
            /* and sm.p_id >0 and up.mdDA_ID = 0 and up.DCFlag = 0 */
             and sm.p_id >0 and  bi.billstates = '0' and sm.AOID<>7
             and bi.transcount=0
             group by  bi.y_id
   
           
    if @@Error <> 0
    begin
      rollback tran  dayaccount
      set @nRet = -1
      return -1
    end

    set @DA_ID = @@identity

     
    if @DA_ID is null set @DA_ID = 0
    
    if @DA_ID = 0
    begin
      rollback tran  dayaccount
      set @nRet = -1
      return -1
    end
    
    if @DA_ID > 0 
      insert into dayaccountdetail(DA_ID, Y_ID, A_ID, Total)
        select @DA_ID, sm.y_id, abs(sm.p_id), sum(case bi.billtype when 12 then sm.Total else -sm.total end) 
          from salemanagebill sm inner join billidx bi 
               on sm.bill_id = bi.billid
             /*  inner join UpBillList up on bi.billid = up.mdbillid*/
          where bi.billtype in (12, 13) 
         /* and sm.p_id < 0 and up.mdDA_ID = 0 */
         /* and up.DCFlag = 0 */
         /* and bi.billstates = '0'*/
            and sm.p_id <0 and  bi.billstates = '0' and sm.AOID<>7
            and bi.transcount=0          
          group by sm.y_id, sm.p_id
   if @@Error <> 0
   begin
     rollback tran  dayaccount
     set @nRet = -1
     return -1
   end

 /*  update UPBillList set mdDA_ID = @DA_ID, DCFlag  = 1 where mdDA_ID = 0*/
/*
--写入 billidx 中的 transcount 
*/   
 update billidx set transcount=@DA_ID
 where billid in
 (select distinct bi.billid
         from billidx bi 
         inner join salemanagebill sm on bi.billid = sm.bill_id
         where bi.billtype in(12, 13)  
         and sm.p_id >0 and  bi.billstates = '0' and sm.AOID<>7
         and bi.transcount=0 )
             
             
   
commit tran dayaccount
set @nRet = @DA_ID
return 0
GO
