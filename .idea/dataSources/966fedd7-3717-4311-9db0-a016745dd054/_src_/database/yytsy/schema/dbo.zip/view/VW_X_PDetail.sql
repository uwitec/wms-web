


CREATE VIEW DBO.VW_X_PDetail
AS

SELECT     pd.[pd_id],
   pd.[billid],
   pd.[p_id], 
   pd.[s_id],
   pd.[quantity],
   pd.[price],
   pd.[total],
   pd.[costprice],
   pd.[costtotal],
   pd.[taxprice],
   pd.[taxtotal],
   pd.[batchno],
   pd.[makedate],
   pd.[validdate],
   pd.[commissionflag],
   pd.[supplier_id],
   pd.[location_id],
   pd.[storetype],
   pd.[price_id],
   pd.[order_id],
   pd.[unitid],
   pd.[smb_id],
   pd.[comment],
   pd.[oldcommissionflag],
   pd.aoid,/*0 as aoid,*/
   pd.[jsprice],
   pd.rowguid,
   pd.RowE_id,
   pd.SendQty,
   pd.SendCostTotal,
   pd.RetailTotal,
   pd.Y_ID, 
ISNULL(dbo.products.class_id,'') AS class_id, 
ISNULL(dbo.storages.class_id,'') AS sclass_id, 
ISNULL(dbo.storages.[name],'') AS sname, 
ISNULL(dbo.products.[name],'') AS pname,products.makearea,products.standard,
ISNULL(l.loc_name,'') AS locname,
ISNULL(cl.[name],'') AS suppliername
FROM productdetail pd
 LEFT OUTER JOIN
       dbo.storages ON pd.s_id = dbo.storages.storage_id 
 LEFT OUTER JOIN
       dbo.products ON pd.p_id = dbo.products.product_id
 LEFT OUTER JOIN
       dbo.location l ON pd.location_id = l.loc_id
 LEFT OUTER JOIN
       dbo.clients cl ON pd.supplier_id = cl.client_id

where pd.aoid in (0, 5)

UNION 

SELECT 
   dbo.salemanagebill.smb_id AS [pd_id],
   dbo.salemanagebill.bill_id AS [billid],
   dbo.salemanagebill.p_id AS [p_id], 
   dbo.salemanagebill.ss_id AS [s_id],
  dbo.salemanagebill.quantity AS [quantity],
   dbo.salemanagebill.saleprice AS [price],
   [total]=case when dbo.billidx.billtype=16 then (-dbo.salemanagebill.totalmoney) else dbo.salemanagebill.totalmoney end,
   dbo.salemanagebill.costprice AS [costprice],
   (0) AS [costtotal],
   dbo.salemanagebill.taxprice AS [taxprice],
   [taxtotal]=case when dbo.billidx.billtype=16 then (-dbo.salemanagebill.taxtotal) else dbo.salemanagebill.taxtotal end,
   dbo.salemanagebill.batchno AS [batchno],
   dbo.salemanagebill.makedate AS [makedate],
   dbo.salemanagebill.validdate AS [validdate],
   dbo.salemanagebill.commissionflag AS [commissionflag],
   dbo.salemanagebill.supplier_id AS [supplier_id],
   dbo.salemanagebill.location_id AS [location_id],
   0 AS [storetype],
   dbo.salemanagebill.price_id AS [price_id],
   dbo.salemanagebill.order_id AS [order_id],
   dbo.salemanagebill.unitid AS [unitid],
   dbo.salemanagebill.smb_id AS [smb_id],
   dbo.salemanagebill.comment AS [comment],
   0 AS  [oldcommissionflag],
   dbo.salemanagebill.aoid,/*0 as aoid,*/
   dbo.salemanagebill.jsprice AS [jsprice],
   salemanagebill.rowguid,
   salemanagebill.RowE_id,
   salemanagebill.SendQty,
   salemanagebill.SendCostTotal,
   salemanagebill.RetailTotal,
   salemanagebill.Y_ID,
    ISNULL(dbo.products.class_id,'') AS class_id, 
    ISNULL(dbo.storages.class_id,'') AS sclass_id, 
    ISNULL(dbo.storages.[name],'') AS sname, 
    ISNULL(dbo.products.[name],'') AS pname,products.makearea,products.standard,
    ('') AS locname,
    ('') AS suppliername

FROM 
   dbo.salemanagebill
   LEFT OUTER JOIN
       dbo.storages ON dbo.salemanagebill.ss_id = dbo.storages.storage_id 
   LEFT OUTER JOIN
       dbo.products ON dbo.salemanagebill.p_id = dbo.products.product_id,
    dbo.billidx
    WHERE dbo.billidx.[billstates]='0' AND dbo.billidx.[billtype] IN (16, 17)
    AND dbo.salemanagebill.bill_id=dbo.billidx.billid and dbo.salemanagebill.aoid in (0, 5)
GO
