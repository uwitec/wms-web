


CREATE  procedure ts_c_OfflineRetailToHis
(
	@nBillId numeric(10,0),
	@nNewBillId numeric(10,0) output
)
/*with encryption*/
as
set nocount on

/*变量定义*/
declare @nBillType smallint /*单据类型*/
declare @szGUID varchar(60)
select @nBilltype=billtype, @szGUID = [GUID] from retailbillidx where billid=@nBillId
/*变量定义end*/

/*销售类单据*/
if @nBilltype in (12,13) 
/*销售,销售退货,零售,零售退货,委托代销发货,委托代销退货,委托代销结算*/
begin

	insert into Yretailbillidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,guid,VIPCardID,invoiceTotal,Y_ID,integral,integralYE)
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney,araptotal, quantity, taxrate, period, '0', order_id, department_id, 
      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,guid,VIPCardID,invoiceTotal,Y_ID,integral,integralYE
	FROM retailbillidx where billid=@nBillId
	if @@rowcount=0 return -1
	select @nNewBillId=@@identity


	insert into Yretailbill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      comment,unitid,taxrate,total,aoid,thqty,PriceType,RowE_ID,Y_ID,InStoreTime,cxType,rowguid,billguid)

	SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      comment,unitid,taxrate,total,aoid,quantity,priceType,RowE_ID,Y_ID,InStoreTime,cxType,rowguid,@szGUID
	FROM retailbill
 	where bill_id=@nBillid	
	if @@rowcount=0 return -1
	
	return	0
end
/*销售类单据*/
GO
