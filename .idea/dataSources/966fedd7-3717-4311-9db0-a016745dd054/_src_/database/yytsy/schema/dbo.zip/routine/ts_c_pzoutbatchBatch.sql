


CREATE proc ts_c_pzoutbatchBatch
(
	@begindate datetime,
	@enddate   datetime
)
/*with encryption*/
as
set nocount on 
declare @nBillid int,@nReturnNumber int
truncate table pzout
begin tran

declare pzoutbatch cursor for
select billid from billidx 
where (billdate between @BeginDate and @EndDate) and billstates='0'

open pzoutbatch
fetch next from pzoutbatch into @nBillId
while @@fetch_status=0
begin
	exec @nReturnNumber=ts_c_pzout @nBillid
	if @nReturnNumber=-1 goto error
	fetch next from pzoutbatch into @nBillId
end

close pzoutbatch
deallocate pzoutbatch

commit tran
return 0
error:
rollback tran
return -1
GO
