




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/****************************************

可用于查询一个时间段内有业务发生的商品的库存状况
参数说明
@nMode      方式
@BeginDate  开始的时间 （请输入如下的格式: '2004-01-01'）
@EndDate    结束的时间 （请输入如下的格式: '2004-12-31'）
@szListFlag 列表方式
@szParID    父亲的ID号


统计的单据类型：所有在ProductDetail中有单据ID号的单据，除以下单据外，成本调价单， 库存批次调整单
****************************************/
CREATE  PROCEDURE [TS_X_QrStoreHouseByDay]
(	@nMode          INT=0,
    @BeginDate      VARCHAR(10)='',
	@EndDate	VARCHAR(10)='',
	@szListFlag 	VARCHAR(1)='L',
	@szParID   	VARCHAR(30)='000000', 
    @nUnitMode      int ,
    @nYClassid      varchar(100)='',
    @nloginEID      int=0
)

/*with encryption*/
AS
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @szParID is null  SET @szParID = '000000'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
  SET NOCOUNT ON
  Declare @Companytable int,@Storetable int, @nY_ID int
  select @nY_ID = isnull(company_id, 0) from company where class_id = @nYClassId and child_number = 0
  if @ny_id is null set @ny_id = 0

  create table #Companytable([id] int)
  create table #storagestable([id] int)

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
declare @RetailPrice int 
exec ts_GetSysValue  'RetailPrice',@RetailPrice out

  IF @szListFlag='L'
  BEGIN
    SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode],P.[Comment], P.[Makearea],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
    isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
    isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity], 
      ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
      ISNULL(SUM(SH.[taxtotal]), 0) AS [taxtotal],
      '''' AS [ClientName],
      '''' AS [Phone_number],
      0.0000  AS [NOsendQTY],
    /*cast(ISNULL((case when @RetailPrice=0 then 0 else sum(case WHEN cast(dbo.GetRetailRate(P.Product_id,@nUnitMode) as NUMERIC(25,8))=0 then 0 else ((ISNULL(P.[RetailPrice],0)*ISNULL(SH.[Quantity],0)) ) end) end),0)as NUMERIC(25,8))AS [RetailTotal],*/
   ISNULL(p.RetailPrice,0)*SUM(SH.[Quantity]) AS [RetailTotal],'' as Factory, p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
   0.0 as cljg,0.0 as clquantity,0.0 as cltotal
    FROM 
      (select P.*,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
           isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
           isnull(pri.[unitname],'') as unitname,   isnull(pb.c_name, '') as C_Name, ISNULL(pb.e_name, '') as ename, 
           ISNULL(pb.Supplier_id, 0) as Supplier_id, ISNULL(pb.Emp_id, 0) as emp_id
           from Vw_C_Products P
           left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE  P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 
       ) P 
    
    LEFT JOIN
    (SELECT [PClassID], 
    ISNULL(SUM([Quantity]), 0) AS [Quantity], 
    ISNULL(SUM([CostTotal]), 0) AS [CostTotal],
    ISNULL(SUM([costtaxtotal]), 0) AS [taxtotal]
    FROM 
    (select * from FilterVW_C_Storehouse(@nloginEID) where (@nYClassID='' or YClass_id like @nYClassID+'%')
     	 and ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
	 and ((@Storetable=0) or (s_id in (select [id] from #storagestable))) 	
     ) SH,
    (	SELECT DISTINCT [P_ID] FROM
	(
	SELECT  VP.[P_ID] FROM
    	(SELECT [BillID], [P_ID] FROM ProductDetail) VP,
    	(SELECT [BillID] FROM BillIDX WHERE [BillDate] BETWEEN @BeginDate AND @EndDate  AND
     	[BillStates]='0' AND [BillType] NOT IN (43, 51)) VB
    	WHERE VB.[BillID]=VP.[BillID]
        )AA
    ) VP
    WHERE SH.[P_ID]=VP.[P_ID]
    GROUP BY [PClassID]) SH
    ON LEFT(SH.[PClassID], LEN(P.[Class_ID]))=P.[Class_ID]
    GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode], P.[Comment], P.[Makearea], P.[UnitName1],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
      p.glprice, p.specialprice,P.IsSplit
  END
  ELSE IF @szListFlag='A'/*由于只现实这段时间内的商品销售记录（没有业务关系的不显示），所以所有商品全部列表现实，不再分级显示。所以只修改该段存储过程*/
  BEGIN
    SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode], P.[Comment], P.[Makearea],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
      (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
      isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
      isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
      isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity], 
      ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
      ISNULL(SUM(SH.[taxtotal]), 0) AS [taxtotal],
      '''' AS [ClientName],
      '''' AS [Phone_number],
      0.0000  AS [NOsendQTY],
     /* cast(ISNULL((case when @RetailPrice=0 then 0 else sum(case WHEN cast(dbo.GetRetailRate(P.Product_id,@nUnitMode) as NUMERIC(25,8))=0 then 0 else ((ISNULL(P.[RetailPrice],0)*ISNULL(SH.[Quantity],0)) ) end) end),0)as NUMERIC(25,8))AS [RetailTotal],*/
        ISNULL(p.RetailPrice,0)*SUM(SH.[Quantity]) AS [RetailTotal],'' as Factory, p.IsSplit,
        0.0 as ZTQuantity,0.0 as ZTtaxtotal,
        0.0 as cljg,0.0 as clquantity,0.0 as cltotal
    FROM 
     (select P.*,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
           isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
           isnull(pri.[unitname],'') as unitname,   isnull(pb.c_name, '') as C_Name, ISNULL(pb.e_name, '') as ename, 
           ISNULL(pb.Supplier_id, 0) as Supplier_id, ISNULL(pb.Emp_id, 0) as emp_id
           from VW_C_Products P
           left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE  [Deleted]<>1 AND [Child_Number]=0 
       ) P 
    
    Inner JOIN
    (
     SELECT VP.[P_id], 
    ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity], 
    ISNULL(SUM(sh.[CostTotal]), 0) AS [CostTotal],
    ISNULL(SUM(SH.[costtaxtotal]), 0) AS [taxtotal]
    FROM 
    (select * from FilterVW_C_Storehouse(@nloginEID) where (@nYClassID='' or YClass_id like @nYClassID+'%')
	 and ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
	and ((@Storetable=0) or (s_id in (select [id] from #storagestable))) 	
     ) SH Right JOIN
    (	SELECT DISTINCT [P_ID] FROM
	(
	SELECT  VP.[P_ID] FROM
    	(SELECT [BillID], [P_ID] FROM ProductDetail) VP,
    	(SELECT [BillID] FROM BillIDX WHERE [BillDate] BETWEEN @BeginDate AND @EndDate  AND
     	[BillStates]='0' AND [BillType] NOT IN (43, 51)) VB
    	WHERE VB.[BillID]=VP.[BillID]
        )AA
    ) VP ON SH.[P_ID]=VP.[P_ID]
    GROUP BY VP.[P_ID]) SH
    ON SH.[P_ID]=P.[product_ID]
    GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode], P.[Makearea], P.[UnitName1],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[Comment], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
      p.glprice, p.specialprice,P.IsSplit
  END
  ELSE
  BEGIN
    SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode], P.[Comment], P.[Makearea],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
     (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
      isnull(P.retailprice,0) as retailprice,isnull(p.recprice,0) as recprice,isnull(p.price1,0) as price1,
      isnull(p.price2,0)      as price2,     isnull(p.price3,0)   as price3,  isnull(p.price4,0) as price4,
      isnull(p.gpprice,0)     as gpprice,    isnull(p.glprice,0)  as glprice, isnull(p.specialprice,0) as specialprice,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity], 
      ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
      ISNULL(SUM(SH.[taxtotal]), 0) AS [taxtotal],
        '''' AS [ClientName],
        '''' AS [Phone_number],
      0.0000  AS [NOsendQTY],
      /* cast(ISNULL((case when @RetailPrice=0 then 0 else sum(case WHEN cast(dbo.GetRetailRate(P.Product_id,@nUnitMode) as NUMERIC(25,8))=0 then 0 else ((ISNULL(P.[RetailPrice],0)*ISNULL(SH.[Quantity],0)) ) end) end),0)as NUMERIC(25,8))AS [RetailTotal],*/
       ISNULL(p.RetailPrice,0)*SUM(SH.[Quantity]) AS [RetailTotal],'' as Factory,P.IsSplit,0.0 as ZTQuantity,
       0.0 as ZTtaxtotal,0.0 as cljg,0.0 as clquantity,0.0 as cltotal
    FROM
     (select P.*,
           isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,isnull(pri.price1,0) as price1,
           isnull(pri.price2,0)      as price2,     isnull(pri.price3,0)   as price3,  isnull(pri.price4,0) as price4,
           isnull(pri.gpprice,0)     as gpprice,    isnull(pri.glprice,0)  as glprice, isnull(pri.specialprice,0) as specialprice,
           isnull(pri.[unitname],'') as unitname,   isnull(pb.c_name, '') as C_Name, ISNULL(pb.e_name, '') as ename, 
           ISNULL(pb.Supplier_id, 0) as Supplier_id, ISNULL(pb.Emp_id, 0) as emp_id
           from VW_C_Products P
           left join (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE  [Deleted]<>1 AND p.[Product_ID]<>1 AND [Child_Number]=0 AND LEFT([Class_ID], LEN(@szParID))=@szParID
       ) P  

    LEFT JOIN
    (SELECT [PClassID], 
    ISNULL(SUM([Quantity]), 0) AS [Quantity], 
    ISNULL(SUM([CostTotal]), 0) AS [CostTotal],
    ISNULL(SUM([costtaxtotal]), 0) AS [taxtotal]
    FROM 
    (select * from FilterVW_C_Storehouse(@nloginEID) where (@nYClassID='' or YClass_id like @nYClassID+'%')
	 and ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
	 and ((@Storetable=0) or (s_id in (select [id] from #storagestable))) 	
     ) SH RIGHT JOIN 
    (	SELECT DISTINCT [P_ID] FROM
	(
	SELECT  VP.[P_ID] FROM
    	(SELECT [BillID], [P_ID] FROM ProductDetail) VP,
    	(SELECT [BillID] FROM BillIDX WHERE [BillDate] BETWEEN @BeginDate AND @EndDate  AND
     	[BillStates]='0' AND [BillType] NOT IN (43, 51)) VB
    	WHERE VB.[BillID]=VP.[BillID]
        )AA
    ) VP ON   SH.[P_ID]=VP.[P_ID]
    GROUP BY [PClassID]) SH
    ON SH.[PClassID]=P.[Class_ID]
    GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Code], P.[Name], P.[Alias], 
      P.[Standard], P.[Modal], P.[Medtype], P.[PermitCode], P.[Makearea], P.[UnitName1],p.[PackStd],  P.[EName],P.emp_id,P.C_NAME,
      P.[Rate2], P.[Rate3], P.[Rate4], P.[Costmethod], P.[Comment], P.[PinYin], P.[TaxRate], P.[Otcflag],
      P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
      P.retailprice,p.recprice,p.price1,  p.price2,    p.price3,   p.price4     ,p.gpprice,
      p.glprice, p.specialprice,P.IsSplit
  END

  GOTO Succee

Succee:
  RETURN 0
GO
