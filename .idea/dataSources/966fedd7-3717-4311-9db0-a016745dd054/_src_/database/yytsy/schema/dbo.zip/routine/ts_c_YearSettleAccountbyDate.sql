

create   procedure ts_c_YearSettleAccountbyDate
(
	@nPubY_ID int,
	@enddate varchar(10),
	@DelGSP int=0,
	@DelGspDate varchar(10),         /*删除gsp报表日期*/
	@DelInvoice int=0,
	@DelInvoiceDate varchar(10),     /*删除发票截止日期*/
	@DelDraft int=0,
	@DelDraftEnddate varchar(10),	 /*删除草稿截止日期*/
	@lcheckbill int=0
)
/*with eccrypt*/
as

/*年结存,按日期结存*/

/*判断是否有日期小于年结存日期的未结算单据，如果有，返回*/
if @lcheckbill=1
	if exists(select 1 from billidx where jsye>0 and billdate<=@enddate and billtype in (10,11,232,211,16,17,20,21,242,221,24,25) and billstates=0) return -10


/*入库时间是否作为批次条件*/
declare @InstoretimeBatch int
set @InstoretimeBatch=0
select @InstoretimeBatch=sysvalue from sysconfigtmp where [sysname] = 'InstoretimeBatch'

declare @Y_ID int, @szYClassID varchar(30), @nRet int
exec ts_GetSysValue 'Y_id',@Y_ID OUT
select @szYClassID = sysvalue from sysconfig where upper([sysname]) = 'YCLASSID'

exec ts_j_MakeBalance @nPubY_ID


if OBJECT_ID('temp..#yidtmp') is not null
  drop table #yidtmp
select  cast(0 as int) as Y_ID into #yidtmp

/*所有自营店和总部一起结存*/
if @nPubY_ID = @Y_ID
begin
  insert into #yidtmp(Y_ID) select company_id from company where company_id = @nPubY_ID or (superior_id = @nPubY_ID and Ytype = 1 and company_id in (select y_id from Companybalance where c_id = 0 and OpenAccount = 1) )
end
else
  insert into #yidtmp(Y_ID) select @nPubY_ID


begin tran yearsettlebydate


	/*2010.10.12 增加删除草稿中非法数据begin*/
	delete buymanagebilldrf where bill_id not in  (select billid from billdraftidx)
    delete salemanagebilldrf where bill_id not in  (select billid from billdraftidx)
    delete storemanagebilldrf where bill_id not in  (select billid from billdraftidx)
    delete GoodsCheckBillDrf where bill_id not in  (select billid from billdraftidx)
    /*2010.10.12 增加删除草稿中非法数据end*/
    	
/*计算新的库存期初余额    	*/
/*计算新的零成本库存期初余额    	*/
/*计算新的代销库存期初余额    	*/

  /*备份期初库存*/
  select * into #storehouseini from storehouseini where Y_ID in (select y_id from #yidtmp) 
  select * into #storedxini from storedxini where Y_ID in (select y_id from #yidtmp) 
  select * into #otherstorehouseini from OtherStorehouseini where Y_ID in (select y_id from #yidtmp) 

  /*计算新的期初资产负债表*/
  declare   @nDetachArap int  /*应收应付是否自动抵扣 =0 自动抵扣 =1 不自动抵扣*/
  select @nDetachArap = sysvalue from sysconfig where sysname = 'ControlAPCredit'
    /*------Some account id*/
    begin
		declare
		@Asset_Id			int,				/*2	【资产合计】*/
		@Products_Id		int,				/*3	『库存商品总值合计』*/
		@FixedAsset_id	int,				/*4	『固定资产合计』*/
		@FixedAsset1_id int,				/*5	 固定资产__甲*/
		@Cash_id				int,				/*6	 现    金*/
																/*7	『全部银行存款合计』*/
																/*8	银行户头_1*/
		@ArTotal_Id		int,				/*9	『应收款合计』*/
		@YArTotal_Id	int,				/*70	『内部应收款』*/
		@Lendout_Id		int ,				/*10	『借出商品』*/
		@Dt_Expens_Id	int,				/* 11	待摊费用*/
		@Wt_Comm_Id		int,				/*12	委托代销商品*/
		@St_Comm_Id		int,				/*13	受托代销商品*/
																/*14	【负债合计】*/
		@ApTotal_Id		int,				/*15	『应付帐款合计』*/
		@YApTotal_Id	int,				/*71	『内部应付款』    */
		@Brrowin_Id		int,				/*16	『借入商品』*/
		@DxTotal_Id		int,				/*17	代销商品款*/
																/*18	应交税金*/
																/*19	【收入类】*/
		@SaleIncome_Id	int					/*20	『销售收入』*/
																/*21	『商品类收入』*/
		/*Product_22	商品报溢收入
		
		23	商品获赠收入
		24	成本调价收入
		25	进货退货差价
		26	变价调拨差价
		27	商品拆装差价
		28	借转进货结算与成本差
		29	受托代销结算差价
		30	『其它收入』
		31	调帐收入
		32	利息收入
		33	其它....
		34	【支出类】
		35	『销售成本』
		36	『商品类支出』
		37	商品报损
		38	商品赠出
		39	『费用合计』
		40	调帐亏损
		41	固定资产折旧
		42	其它....
		43	【所有者权益】
		44	实收资本
		45	资本公积
		46	盈余公积
		47	本年利润
		48	利润分配
		49	【利润】
		54	进项税
		55	销项税
		*/

	select	@Asset_Id			=2				/*	【资产合计】*/
	select	@Products_Id	=3				/*	『库存商品总值合计』*/
	select	@FixedAsset_id=4			/*	『固定资产合计』*/
	select	@Cash_id=6						/*	 现    金*/
																/*7	『全部银行存款合计』*/
																  /*8	银行户头_1*/
	select	@ArTotal_Id		=9				/*9	『应收款合计』*/
	/*select	@YArTotal_Id	=70				--70	『内部应收款』*/
	select	@YArTotal_Id=account_id from account where class_id='000001000010'
	select	@Lendout_Id		=10				/*10	『借出商品』*/
	select	@Dt_Expens_Id	=11			  /*11	待摊费用*/
	select	@Wt_Comm_Id		=12				/*12	委托代销商品*/
	select	@St_Comm_Id		=13				/*13	受托代销商品*/
																  /*14	【负债合计】*/
	select	@ApTotal_Id		=15				/*15	『应付帐款合计』*/
	/*select  @YApTotal_Id	=71			    --71	『内部应付款』*/
	select	@YApTotal_Id=account_id from account where class_id='000002000007'
	select	@Brrowin_Id		=16				/*16	『借入商品』*/
	select	@DxTotal_Id		=17				/*17	代销商品款*/
																  /*18	应交税金*/
																  /*19	【收入类】*/
	select	@SaleIncome_Id=20			  /*20	『销售收入』*/

    declare @Pre_Ar INT,  /*预收科目*/
             @Pre_Ap INT   /*预付科目*/
                
	select @Pre_Ar = Account_ID from Account where Class_Id = '000002000005'
    select @Pre_Ap = Account_ID from Account where Class_Id = '000001000009' 
   end  

  declare @dTotalTemp NUMERIC(25,8),@dTotalArTemp NUMERIC(25,8),@dTotalApTemp NUMERIC(25,8)
  declare @dTotalAr NUMERIC(25,8),@dTotalAp NUMERIC(25,8)
  
  declare @nYSuperior_id int
  select @dTotalTemp=0

  
  
  /*计算clientbalance期末值*/
  begin
	  select b.a_id,b.c_id,b.Y_ID,sum(jdmoney) jdmoney  
	  into #accountbalance
	  from billidx a,accountdetail b,account ac
	  where a.billid=b.billid and a.billstates=0 and a.billtype  not in (150,151,155,160,161,165,171,172,173,174,152,153,162,163)
	  and b.c_id<>0 and a.billdate<=@enddate and b.a_id=ac.account_id
	  and b.a_id in (@ArTotal_Id,@ApTotal_Id,@Pre_Ar,@Pre_Ap)
	  and b.Y_ID in (select y_id from #yidtmp)
	  group by b.a_id,b.c_id,b.Y_ID 
	  
	  /*更新期初值*/
	  update Clientsbalance  set artotal_ini=artotal_ini+isnull(b.jdmoney,0)
	  from Clientsbalance a ,#accountbalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@ArTotal_Id
 	  and a.Y_ID in (select y_id from #yidtmp)


	  update Clientsbalance  set aptotal_ini=aptotal_ini+isnull(b.jdmoney,0)
	  from Clientsbalance a ,#accountbalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@ApTotal_Id
 	  and a.Y_ID in (select y_id from #yidtmp)

	  update Clientsbalance  set pre_artotal_ini=pre_artotal_ini+isnull(b.jdmoney,0)
	  from Clientsbalance a ,#accountbalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@Pre_Ar
 	  and a.Y_ID in (select y_id from #yidtmp)

	  update Clientsbalance  set pre_aptotal_ini=pre_aptotal_ini+isnull(b.jdmoney,0)
	  from Clientsbalance a ,#accountbalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@Pre_Ap
 	  and a.Y_ID in (select y_id from #yidtmp)

	  if @nDetachArap=0 /*应收应付自动冲抵*/
	  begin
		  update Clientsbalance set artotal_ini=artotal_ini-aptotal_ini where aptotal_ini<0 and artotal>=0 and Y_ID in (select y_id from #yidtmp)
		  update Clientsbalance set aptotal_ini=0 where aptotal_ini<0 and Y_ID in (select y_id from #yidtmp)
		  update Clientsbalance set aptotal_ini=aptotal_ini-artotal_ini where artotal_ini<0 and aptotal>=0 and Y_ID in (select y_id from #yidtmp)
		  update Clientsbalance set artotal_ini=0 where artotal_ini<0 and Y_ID in (select y_id from #yidtmp)
	  end
  end
  
  /*计算companybalance期末值*/
    begin
	  select b.a_id,b.c_id,b.Y_ID,isnull(sum(jdmoney),0) jdmoney  
	  into #companybalance
	  from billidx a,accountdetail b,account ac
	  where a.billid=b.billid and a.billstates=0 and a.billtype  in (150,151,155,160,161,165,171,172,173,174,152,153,162,163)
	  and b.c_id<>0 and a.billdate<=@enddate and b.a_id=ac.account_id
	  and b.a_id in (@YArTotal_Id,@YApTotal_Id)
	  and b.Y_ID in (select y_id from #yidtmp)
	  group by b.a_id,b.c_id,b.Y_ID
	  
	  /*更新期初值*/
	  update Companybalance  set artotal_ini=artotal_ini+isnull(b.jdmoney,0)
	  from Companybalance a ,#Companybalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@YArTotal_Id
 	  and a.Y_ID in (select y_id from #yidtmp)

	  update Companybalance  set aptotal_ini=aptotal_ini+isnull(b.jdmoney,0)
	  from Companybalance a ,#companybalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@YApTotal_Id
 	  and a.Y_ID in (select y_id from #yidtmp)

	  update Companybalance  set pre_artotal_ini=pre_artotal_ini+isnull(b.jdmoney,0)
	  from Companybalance a ,#Companybalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@Pre_Ar
 	  and a.Y_ID in (select y_id from #yidtmp)

	  update Companybalance  set pre_aptotal_ini=pre_aptotal_ini+isnull(b.jdmoney,0)
	  from Companybalance a ,#Companybalance b
	  where a.Y_id=b.Y_ID and a.C_ID=b.c_id and b.a_id=@Pre_Ap
 	  and a.Y_ID in (select y_id from #yidtmp)

	  if @nDetachArap=0 /*应收应付自动冲抵*/
	  begin
		  update Companybalance set artotal_ini=artotal_ini-aptotal_ini where aptotal_ini<0 and artotal>=0 and Y_ID in (select y_id from #yidtmp)
		  update Companybalance set aptotal_ini=0 where aptotal_ini<0 and Y_ID in (select y_id from #yidtmp)
		  update Companybalance set aptotal_ini=aptotal_ini-artotal_ini where artotal_ini<0 and aptotal>=0 and Y_ID in (select y_id from #yidtmp)
		  update Companybalance set artotal_ini=0 where artotal_ini<0 and Y_ID in (select y_id from #yidtmp)
	  end
  end
  
  /*计算资产负债表*/
  begin
	  select b.a_id,b.Y_ID,sum(jdmoney) jdmoney 
	  into #adetail
	  from billidx a,accountdetail b
	  where a.billid=b.billid and a.billstates=0 and a.billdate<=@enddate
	  and a.Y_ID in (select y_id from #yidtmp)
	  group by b.a_id,b.Y_ID
	  /*更新期初值*/
	  update accountbalance set ini_total=ini_total+isnull(b.jdmoney,0)
	  from accountbalance a,#adetail b
	  where a.a_id=b.a_id and a.y_id=b.Y_ID
	  and a.Y_ID in (select y_id from #yidtmp)
  end
  

		
  /*---------------------------------------------------------------------------------------------------处理库存*/
  if @InstoretimeBatch=1
  begin  /*暂未处理借进借出*/
  
	/*计算变化 */
  	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,INSTORETIME,sum(a.quantity) quantity,sum(a.costtotal) costtotal
	  INTO #STORECHANGE0
	  FROM PRODUCTDETAIL a,billidx b
	  WHERE a.billid=b.billid and  STORETYPE=0 and a.Y_ID in (select y_id from #yidtmp) and b.billstates=0 and b.billdate<=@enddate
	  group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,INSTORETIME
      if @@ERROR<>0 goto error
      
	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,INSTORETIME,sum(a.quantity) quantity,sum(a.costtotal) costtotal
	  INTO #STOREdxchange0
	  FROM PRODUCTDETAIL a,billidx b
	  WHERE a.billid=b.billid and  STORETYPE=1 and a.Y_ID in (select y_id from #yidtmp) and b.billstates=0 and b.billdate<=@enddate
	  group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,INSTORETIME
      if @@ERROR<>0 goto error
      
      /*计算期末值*/
	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME,sum(a.quantity) quantity,sum(a.costtotal) costtotal
      into #storetotal
      from 
      (
		select P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME, quantity, costtotal
		from storehouseini 
		union all
		select P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME, quantity, costtotal
		from #STORECHANGE0
      ) a
      group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME
      if @@ERROR<>0 goto error

	  SELECT P_ID,c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME,sum(QUANTITY) quantity,sum(COSTTOTAL) costtotal
      into #storedxtotal
      from 
      (
		select P_ID,c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME, quantity, costtotal
		from storedxini 
		union all
		select P_ID,S_ID as c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME, quantity, costtotal
		from #STOREdxchange0
      ) a
      group by P_ID,c_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,INSTORETIME
      if @@ERROR<>0 goto error
      
      update #storetotal set costprice=cast(costtotal/quantity as NUMERIC(25,8)) where quantity<>0
      update #storedxtotal set costprice=cast(costtotal/quantity as NUMERIC(25,8)) where quantity<>0

    /*清除期初库存表*/
 	delete storehouseini where y_id in (select y_id from #yidtmp)
 	delete storedxini where y_id in (select y_id from #yidtmp)
      
    /*插入期初库存*/
	insert into storehouseini(p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,Y_ID) 
	select					  p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,Y_ID 
	from #storetotal
	
	insert into storedxini(p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,Y_ID) 
	select				   p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,Y_ID 
	from #storedxtotal 
    
      
  end else
  begin
	/*计算变化 */
  	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,sum(a.quantity) quantity,sum(a.costtotal) costtotal
	  INTO #STORECHANGE1
	  FROM PRODUCTDETAIL a,billidx b
	  WHERE a.billid=b.billid and  STORETYPE=0 and a.Y_ID in (select y_id from #yidtmp) and b.billstates=0 and b.billdate<=@enddate
	  group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID
      if @@ERROR<>0 goto error
      
	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID,sum(a.quantity) quantity,sum(a.costtotal) costtotal
	  INTO #STOREdxchange1
	  FROM PRODUCTDETAIL a,billidx b
	  WHERE a.billid=b.billid and  STORETYPE=1 and a.Y_ID in (select y_id from #yidtmp) and b.billstates=0 and b.billdate<=@enddate
	  group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,a.Y_ID
      if @@ERROR<>0 goto error
      
      /*计算期末值*/
	  SELECT P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,sum(a.quantity) quantity,sum(a.costtotal) costtotal
      into #storetotal1
      from 
      (
		select P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,quantity, costtotal
		from storehouseini 
		union all
		select P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID, quantity, costtotal
		from #STORECHANGE1
      ) a
      group by P_ID,S_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID
      if @@ERROR<>0 goto error

	  SELECT P_ID,c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID,sum(QUANTITY) quantity,sum(COSTTOTAL) costtotal
      into #storedxtotal1
      from 
      (
		select P_ID,c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID, quantity, costtotal
		from storedxini 
		union all
		select P_ID,S_ID as c_id,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID, quantity, costtotal
		from #STOREdxchange1
      ) a
      group by P_ID,c_ID,COSTPRICE,BATCHNO,MAKEDATE,VALIDDATE,COMMISSIONFLAG,SUPPLIER_ID,Y_ID
      if @@ERROR<>0 goto error
      
      update #storetotal set costprice=cast(costtotal/quantity as NUMERIC(25,8)) where quantity<>0
      update #storedxtotal set costprice=cast(costtotal/quantity as NUMERIC(25,8)) where quantity<>0

    /*清除期初库存表*/
 	delete storehouseini where y_id in (select y_id from #yidtmp)
 	delete storedxini where y_id in (select y_id from #yidtmp)
      
    /*插入期初库存*/
	insert into storehouseini(p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Y_ID) 
	select					  p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Y_ID 
	from #storetotal1
	
	insert into storedxini(p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Y_ID) 
	select				   p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Y_ID 
	from #storedxtotal1   
  end
/*零成本库*/
  begin
	  SELECT a.p_id,a.Y_ID,sum(a.quantity) quantity
	  INTO #otherstore
	  FROM PRODUCTDETAIL a,billidx b
	  WHERE a.billid=b.billid and  a.storetype=3 and a.Y_ID in (select y_id from #yidtmp)  and b.billstates=0 and b.billdate<=@enddate
	  group by a.P_ID,a.Y_ID

      /*计算期末值*/
	  SELECT P_ID,Y_ID,sum(a.quantity) quantity
      into #otherstoretotal
      from 
      (
		select P_ID,Y_ID,quantity
		from otherstorehouseini 
		union all
		select P_ID,Y_ID,quantity
		from #otherstore
      ) a
      group by P_ID,Y_ID
      if @@ERROR<>0 goto error
      
      delete otherstorehouseini where y_id in (select y_id from #yidtmp)
       /*插入期初库存*/
	  insert into otherstorehouseini(p_id,Y_ID,quantity) 
	  select					     p_id,y_id,quantity 
	  from #otherstoretotal
	end
 
 /*----------------------------------------------------------------------------------------------------库存计算完毕   */
  /*处理资产负债表*/
  begin
  	declare @dTotaltempAp NUMERIC(25,8),@dTotaltempAr NUMERIC(25,8),@dAssetTotal NUMERIC(25,8),@dDebtTotal NUMERIC(25,8)
	
	/*库存商品合计*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storehouseini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.y_id in (select y_id from #yidtmp)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Products_Id and y_id = @nPubY_ID  
	if @@error<>0 goto error
	/*受托代销商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storedxini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=2 and s.y_id in (select Y_ID from #yidtmp)
/*	update account set ini_total=@dTotaltemp where account_id=@St_Comm_Id */
/*	if @@error<>0 goto error*/
	update accountbalance set ini_total=@dTotaltemp where a_id=@DxTotal_Id and y_id = @nPubY_ID
	if @@error<>0 goto error
	/*委托代销商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storedxini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=1 and s.y_id in (select Y_ID from #yidtmp)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Wt_Comm_Id and y_id = @nPubY_ID
	if @@error<>0 goto error
	/*--借进商品	
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storebrrowini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=4 and s.y_id in (select Y_ID from #yidtmp)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Brrowin_Id and y_id = @nPubY_ID
	if @@error<>0 goto error
	--借出商品	
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storebrrowini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=3 and s.y_id in (select Y_ID from #yidtmp)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Lendout_Id and y_id = @nPubY_ID
	if @@error<>0 goto error
	*/
	/*应收应付期初资产负债表*/
    /*往来单位	*/
	select @dTotaltempAp=isnull(sum(aptotal_ini),0),@dTotaltempAr=isnull(sum(artotal_ini),0) from clientsbalance 
	where  c_id in (select client_id from clients where deleted<>1 and child_number=0) and y_id = @nPubY_ID
	update accountbalance set ini_total=@dTotaltempAp where a_id=@ApTotal_Id and y_id = @nPubY_ID 
	if @@error<>0 goto error
	update accountbalance set ini_total=@dTotaltempAr where a_id=@ArTotal_Id and y_id = @nPubY_ID 
	if @@error<>0 goto error

	/*资产合计	*/
	select @dAssetTotal=isnull(sum(ini_total),0) from accountbalance where a_id in (select account_id from account where left(class_id,6)='000001' and deleted=0 and child_number=0) and y_id = @nPubY_ID
	if @@error<>0 goto error
	/*负债合计*/
	select @dDebtTotal=isnull(sum(ini_total),0) from accountbalance where a_id in(select account_id from account where left(class_id,6)='000002' and deleted=0 and child_number=0) and y_id =@nPubY_ID
	if @@error<>0 goto error
	/*实收资本=资产－负债*/
	update accountbalance set ini_total=@dAssetTotal-@dDebtTotal where a_id in (select account_id from account where class_id='000005000001') and y_id = @nPubY_ID
	if @@error<>0 goto error

end	  

  drop table #storehouseini
  drop table #storedxini
  drop table #otherstorehouseini



/*计算会员期初积分*/
begin
	if @nPubY_ID = @Y_ID
	begin
	  /*计算会员卡初始积分*/

      select a.VIPCardID,isnull(sum(a.integral),0) integral
      into #vipcard
      from
      (
		  select VIPCardID,isnull(sum(integral),0) integral
		  from billidx 
		  where billstates=0 and billdate<=@enddate and VIPCardID<>0 and billtype in (12,13)
		  group by VIPCardID
		  union all
		  select a.VIPCardID, isnull(sum(-b.IntegRalTotal),0) integral 
		  from billidx a,ExIntegRalManagebill b
		  where a.billid=b.billid and a.billtype=149 and a.billstates=0 and a.billdate<=@enddate
		  group by a.VIPCardID
	  ) a
	  group by a.VIPCardID
	  
	  Update VipCard Set IniIntergral=IniIntergral+isnull(b.integral,0)
	  from VIPCard a,#vipcard b
	  where a.VIPCardID=b.VIPCardID
	  and a.Y_ID in (select y_id from #yidtmp)
	end 
end
                

/*清除历史数据*/
 if @nPubY_ID = @Y_ID  /*总部帐套做年结存*/
 begin 
 	delete from users 			where e_id in (select emp_id from employees where deleted=1 and child_number=0)
    delete from accountbalance  where y_id in (select y_id from #yidtmp) and a_id in (select account_id from account where deleted=1)
 	delete from account  		where deleted=1
 	delete from products        where deleted=1        
    delete from Clientsbalance  where y_id in (select y_id from #yidtmp) and c_id in (select client_id from clients where deleted=1)
 	delete from clients    	    where deleted=1
 	delete from employees 		where deleted=1
 	delete from storages		where deleted=1
	delete from department		where deleted=1
	delete from region			where deleted=1
	/*delete from medtype			where deleted=1*/
	delete from unit			where deleted=1
    delete from Companybalance	where y_id in (select y_id from #yidtmp) and c_id in (select company_id from company where deleted=1)

    /*删除草稿，通过触发器删除明细*/
	delete from billdraftidx          where billdate <= @DelDraftEnddate and Y_ID in (select y_id from #yidtmp)
    /*删除按单结算，按行结算*/
	delete jspdetail from billidx a,jspdetail b			where a.billid=b.xsd_bid and  a.billdate <= @enddate and flag=0 and a.Y_ID in (select y_id from #yidtmp)
	delete jspdetail from billdraftidx a,jspdetail b	where a.billid=b.xsd_bid and  a.billdate <= @enddate and flag=1 and a.Y_ID in (select y_id from #yidtmp)

	delete jsbdetail  from billidx a,jsbdetail b		where a.billid=b.xsd_bid and  a.billdate < =@enddate and flag=0 and a.Y_ID in (select y_id from #yidtmp)
	delete jsbdetail  from billdraftidx a,jsbdetail b	where a.billid=b.xsd_bid and  a.billdate < =@enddate and flag=1 and a.Y_ID in (select y_id from #yidtmp)

    /*删除历史单据*/
    delete salemanagebill       from billidx a, salemanagebill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete buymanagebill        from billidx a, buymanagebill b   where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete storemanagebill      from billidx a, storemanagebill b where a.billid = b.bill_id and a.billdate < @enddate  and a.Y_ID in (select y_id from #yidtmp)
	delete tranmanagebill       from billidx a, tranmanagebill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp) 
	delete financebill          from billidx a, financebill b     where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp) 
	delete GoodsCheckBill       from billidx a, GoodsCheckBill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete productdetail        from billidx a, productdetail b   where a.billid = b.billid  and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete accountdetail        from billidx a, accountdetail b   where a.billid = b.billid  and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete ExIntegRalManagebill from billidx a, ExIntegRalManagebill b where a.billid = b.billid  and billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)/*清除积分兑换单 */
    
	delete from billidx where billdate <= @enddate and Y_ID in (select y_id from #yidtmp) /*最后删除单据索引*/

	delete orderbill            from orderidx a, orderbill b      where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete from orderidx        where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)

	delete retailbill           from retailbillidx a,retailbill b where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete from retailbillidx   where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
    
    /*删除付款计划*/
    delete PaymentBill           from PaymentIdx a,PaymentBill b where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete from PaymentIdx   where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
    
      
    delete tranbill             from tranidx a,tranbill b         where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
	delete from tranidx         where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
	
	/*删除会员积分明细表*/
    delete Integraldetail       from Integralidx a, Integraldetail b where a.billid = b.billid and a.billdate <= @enddate and a.Y_ID in (select y_id from #yidtmp)
    delete from Integralidx     where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
	
    if @DelInvoice=1
    begin
	  delete from  invoiceidx       where invoicedate < @enddate
	  delete invoice from invoiceidx a,invoice b where b.invoiceid=a.id and a.invoicedate < @enddate 
	end

end else
begin                  /*分公司年结存*/

 	delete from users 			where e_id in (select emp_id from employees where deleted=1 and child_number=0)
    delete from accountbalance  where y_id in (select y_id from #yidtmp) and a_id in (select account_id from account where deleted=1)
 	delete from account  		where deleted=1
 	delete from products        where deleted=1        
    delete from Clientsbalance  where y_id in (select y_id from #yidtmp) and c_id in (select client_id from clients where deleted=1)
 	delete from clients    	    where deleted=1
 	delete from employees 		where deleted=1
 	delete from storages		where deleted=1
	delete from department		where deleted=1
	delete from region			where deleted=1
	delete from medtype			where deleted=1
	delete from unit			where deleted=1
    delete from Companybalance	where y_id in (select y_id from #yidtmp) and c_id in (select company_id from company where deleted=1)

    /*删除草稿，通过触发器删除明细*/
	delete from billdraftidx          where billdate <= @enddate and Y_ID= @nPubY_ID
    /*删除按单结算，按行结算*/
	delete jspdetail from billidx a,jspdetail b			where a.billid=b.xsd_bid and  a.billdate <= @enddate and flag=0 and a.Y_ID=@nPubY_ID
	delete jspdetail from billdraftidx a,jspdetail b	where a.billid=b.xsd_bid and  a.billdate <= @enddate and flag=1 and a.Y_ID=@nPubY_ID

	delete jsbdetail  from billidx a,jsbdetail b		where a.billid=b.xsd_bid and  a.billdate < =@enddate and flag=0 and a.Y_ID=@nPubY_ID
	delete jsbdetail  from billdraftidx a,jsbdetail b	where a.billid=b.xsd_bid and  a.billdate < =@enddate and flag=1 and a.Y_ID=@nPubY_ID

    /*删除历史单据*/
    delete salemanagebill       from billidx a, salemanagebill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete buymanagebill        from billidx a, buymanagebill b   where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete storemanagebill      from billidx a, storemanagebill b where a.billid = b.bill_id and a.billdate < @enddate  and a.Y_ID=@nPubY_ID
	delete tranmanagebill       from billidx a, tranmanagebill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete financebill          from billidx a, financebill b     where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete GoodsCheckBill       from billidx a, GoodsCheckBill b  where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete productdetail        from billidx a, productdetail b   where a.billid = b.billid  and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete accountdetail        from billidx a, accountdetail b   where a.billid = b.billid  and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete ExIntegRalManagebill from billidx a, ExIntegRalManagebill b where a.billid = b.billid  and billdate <= @enddate and a.Y_ID=@nPubY_ID/*清除积分兑换单*/

 	delete OrderDraft from OrderDraft d,orderidx o where d.bill_id = o.billid and billdate <= @DelDraftEnddate and o.Y_ID in (select y_id from #yidtmp)
    delete GSPDraft from GSPDraft b,GSPbillidx i where b.bill_id = i.Gspbillid and billdate <= @DelDraftEnddate and i.Y_id in (select y_id from #yidtmp)
    
	delete from billidx where billdate <= @enddate and Y_ID=@nPubY_ID /*最后删除单据索引*/
    /*删除订单*/
	delete orderbill            from orderidx a, orderbill b      where a.billid = b.bill_id and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete from orderidx        where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
    /*删除零售单*/
	delete retailbill           from retailbillidx a,retailbill b where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete from retailbillidx   where billdate <= @enddate and Y_ID in (select y_id from #yidtmp)
    /*删除请货单*/
	delete tranbill             from tranidx a,tranbill b         where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete from tranidx         where billdate <= @enddate and Y_ID=@nPubY_ID
    /*删除付款计划*/
	delete PaymentBill             from PaymentIdx a,PaymentBill b         where a.billid = b.bill_id  and a.billdate <= @enddate and a.Y_ID=@nPubY_ID
	delete from PaymentIdx         where billdate <= @enddate and Y_ID=@nPubY_ID
    
    /*删除会员积分明细表	*/
    delete Integraldetail       from Integralidx a, Integraldetail b    where a.billid = b.billid and a.billdate <= @enddate and a.Y_ID = @nPubY_ID
    delete from Integralidx     where billdate <= @enddate and Y_ID = @nPubY_ID	
	
    /*删除发票 */
    if @DelInvoice=1
    begin
	  delete from  invoiceidx       where invoicedate <= @DelInvoiceDate and Y_ID=@nPubY_ID
	  delete invoice from invoiceidx a,invoice b where b.invoiceid=a.id and a.invoicedate <= @DelInvoiceDate and a.Y_ID=@nPubY_ID
	end
end

/*清除临时表*/
begin
    truncate table buymanagebilltmp
	truncate table salemanagebilltmp
	truncate table storemanagebilltmp
 	truncate table tranmanagebilltmp

    truncate table sendidx
    truncate table sendmangebill
    truncate table msgcenter
	truncate table productdetailtmp
	truncate table accountdetailtmp
	truncate table BillLog
	
				
/*	删除业务表 */
	TRUNCATE TABLE billidx_dts
	TRUNCATE TABLE salemanagebill_dts
	TRUNCATE TABLE buymanagebill_Dts
	TRUNCATE TABLE financebill_Dts 
	TRUNCATE TABLE storemanagebill_Dts
	TRUNCATE TABLE goodscheckbill_Dts
	TRUNCATE TABLE tranmanagebill_Dts 
	truncate table productdetail_dts
	truncate table accountdetail_dts
	truncate table retailbillidx_dts
	truncate table retailbill_dts	
	truncate table ExIntegRalManagebill_dts
	/*删除草稿中间表*/
	TRUNCATE TABLE billDraftidx_dts
	TRUNCATE TABLE salemanagebilldrf_dts
	TRUNCATE TABLE financebilldrf_dts
	TRUNCATE TABLE GSPCompy_dts	
	/*删除会员积分表*/
	TRUNCATE TABLE Integralidx_dts
	TRUNCATE TABLE Integraldetail_dts
	
	delete from Sfda_Detail where billid not in(select billid from billidx)
	delete from RetailBillidx_Sfda where billtype between 1 and 255 and IsDraft = 0 and bill_id in(select billid from billidx where billdate <= @enddate)
	delete from RetailBillidx_Sfda where billtype between 1 and 255 and IsDraft = 1 and bill_id in(select billid from billdraftidx where billdate <= @DelDraftEnddate)
	delete from RetailBillidx_Sfda where billtype between 501 and 599 and bill_id in(select gspbillid from gspbillidx where billdate <= @enddate)
	delete from gspbilldetail where gspbill_id in(select gspbillid from gspbillidx where billdate <= @enddate)
	delete from gspbillidx where billdate <= @enddate
end
/*清除gsp报表*/
	if @nPubY_ID = @Y_ID
		if @DelGSP=1 delete from GspTable where  Gsptype not in (2202,2203,2260) and y_id in (select y_id from #yidtmp) and BillDate<=@DelGspDate
  
commit tran yearsettlebydate
  if OBJECT_ID('temp..#yidtmp') is not null
    drop table #yidtmp
  return 0 
  
error:
begin
   rollback tran yearsettlebydate
   if OBJECT_ID('temp..#yidtmp') is not null
    drop table #yidtmp
   return -1
end
GO
