/************************************************************
--过程名称：Ts_Y_InYbRetail
--功能    ：零售处方上传社保中心，同时写入本地库
--创建人  ：YANRUI 
--创建时间：2013-12-25 
------上传成功后需要回写的项目
  交易流水号|项目单价|审批标记|审批规则|项目费用总额|项目等级|自付比例|
  标准单价|自付金额|自费金额
  a23---a32 
**************************************************************/
CREATE	  PROCEDURE [dbo].[Ts_Y_InYbRetail]
(
 @A0  varchar(18),
 @A1  varchar(20),
 @A2  varchar(30),
 @A3  varchar(20),
 @A4  varchar(20),
 @A5  varchar(50),
 @A6  varchar(20),
 @A7  varchar(20),
 @A8  varchar(3),
 @A9  varchar(20),
 @A10 varchar(20),
 @A11 varchar(20),
 @A12 varchar(20),
 @A13 varchar(20),
 @A14 varchar(20),
 @A15 varchar(20),
 @A16 varchar(20),
 @A17 varchar(20),
 @A18 varchar(20),
 @A19 varchar(20),
 @A20 varchar(20),
 @A21 varchar(20),
 @A22 varchar(3),
 @A23 varchar(20),
 @A24 varchar(20),
 @A25 varchar(10),
 @A26 varchar(10),
 @A27 varchar(20),
 @A28 varchar(3),
 @A29 varchar(20),
 @A30 varchar(20),
 @A31 varchar(20),
 @A32 varchar(20),
 @A33 varchar(3),
 @Aguid varchar(50),
 @Y_ID INT,
 @P_ID INT
)
as
 declare @cts int
 set @cts=(select count(1) from YbRetailinfo where A0=@A0 and Y_ID=@Y_ID and P_ID=@P_ID )	
 if  @cts<=0  
 begin
    insert into YbRetailinfo
    (A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A20,A21,A22,A23,A24,A25,A26,
     A27,A28,A29,A30,A31,A32,A33,Aguid,Y_ID,P_ID)
	 VALUES
    (@A0,@A1,@A2,@A3,@A4,@A5,@A6,@A7,@A8,@A9,@A10,@A11,@A12,@A13,@A14,@A15,@A16,@A17,@A18,@A19,@A20,
    @A21,@A22,@A23,@A24,@A25,@A26,@A27,@A28,@A29,@A30,@A31,@A32,@A33,@Aguid,@Y_ID,@P_ID)  
 end
  else
 begin
  update YbRetailinfo 
    set   A23=@A23,A24=@A24,A25=@A25,A26=@A26,A27=@A27,A28=@A28,A29=@A29,
    A30=@A30,A31=@A31,A32=@A32
   where A0=@A0 and Y_ID=@Y_ID and P_ID=@P_ID
   
 end	            
 /**/
GO
