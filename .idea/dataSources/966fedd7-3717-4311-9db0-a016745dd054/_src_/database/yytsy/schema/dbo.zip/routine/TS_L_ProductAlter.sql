/**********************/
/*****商品信息注册证号和批准文号报警*****/
/*****add by luowei 2013-08-14*****/
/*********************/


create procedure TS_L_ProductAlter
(
  @nAlterDay int
)
as
begin
	select serial_number,name,standard,makearea,MedName,Factory,RegisterNo,Registervalid,permitcode,PerCodevalid from vw_Products
	where child_number = 0 and deleted = 0 and ((PerCodevalid > 10 AND 
	PerCodevalid <DATEADD(DAY,@nAlterDay,GETDATE())) OR (Registervalid > 10 AND  Registervalid< DATEADD(DAY,@nAlterDay,GETDATE())))
end
GO
