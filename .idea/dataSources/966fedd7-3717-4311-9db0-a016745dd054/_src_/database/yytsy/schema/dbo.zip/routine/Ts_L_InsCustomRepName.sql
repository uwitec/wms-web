


CREATE	PROCEDURE Ts_L_InsCustomRepName 
(	@RepID int ,
	@Repname varchar(50),
	@RepParent  varchar(50),
	@RepProc  varchar(50)
)
AS
  
 declare @newClassid  varchar(50),@child_count int,@child_number int
 
  
if @RepID=0
begin

  select @newClassid=classid,@child_number=ChildNumber,@child_count=childCount 
  from Getid(@RepParent,'CUSTOMREP')
	if @@rowcount=0
	begin
	 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
	 return-1
	end
  Insert CustomReport(Class_id,Parent_id,child_number,Child_count,RepName,RepPoc)
  values (@newClassid,@RepParent,0,0,@Repname,@RepProc)	 
  update CustomReport set   child_number=@child_number, Child_count=@Child_count
  where Class_id=@RepParent
end
else
begin
  update  CustomReport  set RepName=@Repname,RepPoc=@RepProc
  where Rid=@RepID
end
GO
