
/************************************************************

--功能：查询未日结的门店   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE  PROCEDURE [ts_j_repNoDayAccountCY]
  ( 
   @enddate datetime
  )
AS 

 select @enddate = cast(cast(@enddate as varchar(10)) as datetime)

  select * from company 
     where company_id not in (select y_id from dayaccount where cast(cast(enddate as varchar(10)) as datetime) = @enddate) and
           child_number = 0 and ytype <> 0 and posdatamode = 1 and deleted=0
GO
