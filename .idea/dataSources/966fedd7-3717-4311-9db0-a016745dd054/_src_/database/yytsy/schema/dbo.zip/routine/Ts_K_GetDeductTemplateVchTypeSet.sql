
CREATE PROCEDURE Ts_K_GetDeductTemplateVchTypeSet(
	@FormulaType  INT = 0	
)
/*with encryption*/
AS
BEGIN
	DECLARE @VchList TABLE (VchType INT)
	IF @FormulaType IN (0, 1, 3, 6, 7)
	BEGIN
		INSERT INTO @VchList(VchType)
		SELECT 10 
		UNION ALL
		SELECT 11
		UNION ALL
		SELECT 12
		UNION ALL
		SELECT 13	
	END
	ELSE
	IF @FormulaType IN (2, 4)
	BEGIN
		/*回款金额提成、回扣毛利提成支持单据类型*/
		INSERT INTO @VchList(VchType)
		SELECT 10 
		UNION ALL
		SELECT 11
	END
	ELSE
	IF @FormulaType IN (8)
	BEGIN
		/*批次提成支持单据类型*/
		INSERT INTO @VchList(VchType)
		SELECT 10 
		UNION ALL
		SELECT 11
		UNION ALL
		SELECT 12
		UNION ALL
		SELECT 13	
		UNION ALL
		SELECT 150
		UNION ALL
		SELECT 151
		UNION ALL
		SELECT 152
		UNION ALL
		SELECT 153
	END	
	ELSE
	IF @FormulaType IN (5)
	BEGIN
		/*工作量提成支持单据类型*/
		INSERT INTO @VchList(VchType)
		SELECT 14
		UNION ALL
		SELECT 541
		UNION ALL
		SELECT 551
		UNION ALL
		SELECT 10 
		UNION ALL
		SELECT 11
		UNION ALL
		SELECT 12
		UNION ALL
		SELECT 13
		UNION ALL
		SELECT 20
		UNION ALL
		SELECT 21
		UNION ALL
		SELECT 511
		UNION ALL
		SELECT 513
		UNION ALL
		SELECT 521
		UNION ALL
		SELECT 522
		UNION ALL
		SELECT 523
		UNION ALL
		SELECT 524
		UNION ALL
		SELECT 531
	END	
	SELECT c.VchType, c.dVchType, v.Comment AS VchName
	FROM   (
	           SELECT a.VchType, ISNULL(d.VchType, -1) AS dVchType
	           FROM   @VchList a
	                  LEFT JOIN (
	                           SELECT VId, VchType, FormulaType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType
	                       ) d
	                       ON  a.VchType = d.VchType
	       ) c
	       INNER JOIN VchType v ON  c.VchType = v.Vch_ID
END
GO
