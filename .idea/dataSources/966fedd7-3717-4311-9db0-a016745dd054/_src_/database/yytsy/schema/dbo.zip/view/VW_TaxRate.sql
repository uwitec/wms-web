



CREATE	    VIEW dbo.VW_TaxRate
AS
	SELECT   p.product_id, CAST(c.name AS numeric(25,8)) AS TaxRate,c.id
	FROM      dbo.products AS p INNER JOIN
					dbo.ProductCategory AS cm ON p.product_id = cm.P_id INNER JOIN
					dbo.customCategory  AS c ON cm.PComent2 = c.class_id
	WHERE  (c.deleted = 0)
		AND c.Child_Number = 0 and  baseType=0 and Category_id=2
GO
