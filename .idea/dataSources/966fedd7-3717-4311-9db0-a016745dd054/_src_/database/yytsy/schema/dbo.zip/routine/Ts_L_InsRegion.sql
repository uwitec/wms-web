
/*select * from region*/
CREATE   PROCEDURE [Ts_L_InsRegion]
 (  
  @parent_id [varchar](30),
  @name [varchar](80),
  @serial_number  [varchar](26),
  @Comment [varchar](256),
  @RowIndex  [int],
  @szpinyin  [varchar](20)
  )

AS 
declare  @tempId  varchar(30),
   @child_number  [int],
   @child_count [int],
   @newRid  int
  /*合法性检查*/
if @RowIndex<=0
 set  @RowIndex=1 
else
  select @RowIndex=Max(rowindex)+1 from Region where parent_id=@parent_id and deleted=0 
if exists(select * from Region  where serial_number=@serial_number and deleted=0)
begin
 RAISERROR('编号重复！不能添加！！',16,1)
 return -2
end

/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Region')

if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end


INSERT INTO [Region] 
  ( [class_id],
  [parent_id],
  [serial_number],
  [name],
  [Comment],
  [Rowindex],
  [Deleted],
  [pinyin]
  ) 
VALUES 
 (@tempid,
  @parent_id,
  @serial_number, 
  @name,
  @Comment,
  @Rowindex,
  0,
  @szpinyin
  )

if @@rowCount=0 

 begin

 return -1

end else 
begin
      update Region set child_number=@child_number,child_count=@child_count
      where class_id =@Parent_id
      
      select @newRid= @@IDENTITY
end
GO
