create procedure ts_e_StoreWMSCheckSelectBaseInfo
 @ID       int=0,  /*复核台id */
 @S_id integer=0,/*仓库ID*/
 @FHTCode varchar(100)='',/*复核台编号*/
 @StopStatus int=0/*停用状态*/
as
begin
  /*-实时计算活动单据数量，统计复核单分配了复核台，但是还没有生成物流配送单的单据数量*/
  update  WMSCheckBaseInfo set BillNum=isnull(b.billnum,0)   from WMSCheckBaseInfo a left join 
               ( 
                select DeskId,COUNT(gspbillid) as billnum from gspbillidx where billtype=551 and DeskId>0  and 
                  gspbillid not in (select billid from Sendmangebill) group by DeskId
               ) b on a.ID=b.DeskId
               
  if @ID<>0
  begin
    	select isnull(a.Code,'') as FHTcode, isnull(a.name,'') as FHTname, isnull(a.PinYin,'') as FHTpy ,a.S_id as Store_id,
    	     a.ID as Store_FHT_id,
    	     isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
			 isnull(a.GroupCode,'') as groupnum,Case a.deleted when 0 then '启用' when 2 then '停用' end as fhtstatus,
			 case a.ifuse when 0 then '否' when 1 then  '是' end as ifuse,
			 isnull(a.BillNum,0) as billnum,isnull(a.WorkNum,'') as worknum,
			 isnull(ContainerNo,'') as trunoversn,case IfHold when 0 then '否' when 1 then '是' end as ifexistarea,
			 isnull(a.PgNum,0) as pgnum,a.LockBillNum as lockbillnum,case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
			 isnull(a.IfHold,0) as IfHold,isnull(a.DoubleCheck,0) as DoubleCheck,
			 case DoubleCheck when 0 then '否' when 1 then '是' end as ifDoubleCheck
			 from WMSCheckBaseInfo a 
				  left join storages b on a.S_id=b.storage_id
			   where a.ID=@ID and a.deleted in (0,2)
  end
  else
  begin
		 if @StopStatus=1 
		 begin
			     select isnull(a.Code,'') as FHTcode, isnull(a.name,'') as FHTname, isnull(a.PinYin,'') as FHTpy ,a.S_id as Store_id,
    				 a.ID as Store_FHT_id,
    				 isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
					 isnull(a.GroupCode,'') as groupnum,Case a.deleted when 0 then '启用' when 2 then '停用' end as fhtstatus,
					 case a.ifuse when 0 then '否' when 1 then  '是' end as ifuse,
					 isnull(a.BillNum,0) as billnum,isnull(a.WorkNum,'') as worknum,
					 isnull(ContainerNo,'') as trunoversn,case IfHold when 0 then '否' when 1 then '是' end as ifexistarea,
					 isnull(a.PgNum,0) as pgnum,a.LockBillNum as lockbillnum,case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
					 isnull(a.IfHold,0) as IfHold,isnull(a.DoubleCheck,0) as DoubleCheck,
			         case DoubleCheck when 0 then '否' when 1 then '是' end as ifDoubleCheck
					 from WMSCheckBaseInfo a 
					  left join storages b on a.S_id=b.storage_id
				   where (a.S_id=@S_id or @S_id=0) and
						 (a.Code like '%'+@FHTCode+'%' or a.name like '%'+@FHTCode+'%') and 
						  a.deleted in (0,2)
		end
		else
		begin
				select isnull(a.Code,'') as FHTcode, isnull(a.name,'') as FHTname, isnull(a.PinYin,'') as FHTpy ,a.S_id as Store_id,
    				 a.ID as Store_FHT_id,
    				 isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
					 isnull(a.GroupCode,'') as groupnum,Case a.deleted when 0 then '启用' when 2 then '停用' end as fhtstatus,
					 case a.ifuse when 0 then '否' when 1 then  '是' end as ifuse,
					 isnull(a.BillNum,0) as billnum,isnull(a.WorkNum,'') as worknum,
					 isnull(ContainerNo,'') as trunoversn,case IfHold when 0 then '否' when 1 then '是' end as ifexistarea,
					 isnull(a.PgNum,0) as pgnum,a.LockBillNum as lockbillnum,case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
					 isnull(a.IfHold,0) as IfHold,isnull(a.DoubleCheck,0) as DoubleCheck,
			         case DoubleCheck when 0 then '否' when 1 then '是' end as ifDoubleCheck
					 from WMSCheckBaseInfo a 
					  left join storages b on a.S_id=b.storage_id
				   where (a.S_id=@S_id or @S_id=0) and
						 (a.Code like '%'+@FHTCode+'%' or a.name like '%'+@FHTCode+'%') and 
						 a.deleted in (0)
		end    
	end                            
end
GO
