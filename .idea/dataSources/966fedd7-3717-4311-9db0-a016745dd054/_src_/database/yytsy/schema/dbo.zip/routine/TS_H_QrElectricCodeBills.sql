
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-5-23*/
/* Description:	查询电子监管码相关单据*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_QrElectricCodeBills] 
	@BeginDate		datetime,			/* 开始日期*/
	@EndDate		datetime,			/* 结束日期*/
	@BillSort		int = 0,			/* 单据类别*/
	@Finish			int = 0,			/* 是否已复核*/
	@YID			int = 2,			/* 当前机构*/
	@BillNumber		varchar(50) = '',	/* 单据编号*/
	@BillID			int = 0				/* 单据 ID*/
AS
BEGIN
/*Params Ini begin*/
if @BillSort is null  SET @BillSort = 0
if @Finish is null  SET @Finish = 0
if @YID is null  SET @YID = 2
if @BillNumber is null  SET @BillNumber = ''
if @BillID is null  SET @BillID = 0
/*Params Ini end*/
	SET NOCOUNT ON;
	
	create table #tmpID(id int)
	
	if @Finish = 1
		insert into #tmpID select billid from Sfda_Detail

	SELECT     billid, convert(varchar(10), billdate, 120) as billdate, billnumber, SendQTY, szEmp, szAudit, szInput, szClient, StoreFlag, ISNULL(code, 0) as code
	FROM         (SELECT     i.billid, i.billdate, i.billnumber, i.SendQTY, e.name AS szEmp, a.name AS szAudit, p.name AS szInput, c.name AS szClient, v.StoreFlag, ct.code
						   FROM          dbo.billidx AS i INNER JOIN
												  dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
												  dbo.employees AS e ON i.e_id = e.emp_id INNER JOIN
												  dbo.employees AS a ON i.auditman = a.emp_id INNER JOIN
												  dbo.employees AS p ON i.inputman = p.emp_id INNER JOIN
												  dbo.clients AS c ON i.c_id = c.client_id LEFT JOIN
												  (SELECT     billid, COUNT(billid) AS code
														FROM         dbo.Sfda_Detail
														GROUP BY billid) ct
												ON i.billid = ct.billid
						   WHERE      (v.SaleBuyFlag > 0) AND (((@BillSort = 0) AND (v.StoreFlag > 0)) OR (v.StoreFlag = @BillSort)) 
									AND (NOT (i.billtype IN (12, 13))) AND (i.Y_ID = @YID) AND (i.billdate BETWEEN 
												  @BeginDate AND @EndDate) AND (v.SendFlag = 0)AND (i.billid NOT IN
                                                  (SELECT id from #tmpID))
                                    AND (i.BillNumber LIKE + '%' + @BillNumber + '%')
                                    AND (@BillID = 0 OR i.billid = @Billid)
						   UNION ALL
						   SELECT     i.billid, i.billdate, i.billnumber, i.SendQTY, e.name AS szEmp, a.name AS szAudit, p.name AS szInput, c.name AS szClient, v.StoreFlag, ct.code
						   FROM         dbo.billidx AS i INNER JOIN
												 dbo.VchType AS v ON i.billtype = v.Vch_ID INNER JOIN
												 dbo.employees AS e ON i.e_id = e.emp_id INNER JOIN
												 dbo.employees AS a ON i.auditman = a.emp_id INNER JOIN
												 dbo.employees AS p ON i.inputman = p.emp_id INNER JOIN
												 dbo.company AS c ON i.c_id = c.company_id LEFT JOIN
												  (SELECT     billid, COUNT(billid) AS code
														FROM         dbo.Sfda_Detail
														GROUP BY billid) ct
												ON i.billid = ct.billid
						   WHERE     (v.SaleBuyFlag > 0) AND (@BillSort = 0 AND v.StoreFlag > 0 OR v.StoreFlag = @BillSort) 
									AND (NOT (i.billtype IN (12, 13))) AND (i.Y_ID = @YID) AND (i.billdate BETWEEN 
												 @BeginDate AND @EndDate) AND (v.SendFlag = 1)AND (i.billid NOT IN
                                                  (SELECT id from #tmpID))
                                    AND (i.BillNumber LIKE + '%' + @BillNumber + '%')
                                    AND (@BillID = 0 OR i.billid = @Billid)
                                                  ) AS t
	ORDER BY billid
	drop table #tmpID
END
GO
