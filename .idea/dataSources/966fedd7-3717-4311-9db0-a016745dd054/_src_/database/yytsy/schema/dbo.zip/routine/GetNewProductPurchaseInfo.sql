
CREATE FUNCTION GetNewProductPurchaseInfo 
(
	@Type              INT,  /*0 获取第一次采购数量；1 获取销售频次；2 日均销量；3 销售天数*/
	@PId               INT,
	@YId               INT,
	@Begin             DATETIME,
	@End               DATETIME
)
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @DayCount INT
	DECLARE @Result VARCHAR(100)
	DECLARE @Tmp numeric(25,8)
	SET @Tmp = 0.00
	
	IF @Type = 0
	BEGIN
		SELECT TOP 1 @Tmp = b.quantity
			FROM  buymanagebill b INNER JOIN billidx c ON b.bill_id = c.billid
		WHERE c.billstates = 0 AND c.billtype IN (20, 160, 162) AND c.Y_ID = 2 AND b.p_id = @PId
		ORDER BY c.billdate
					   
		IF @Tmp IS NULL
			SET @Tmp = 0.00	
		SET @Result = CAST(@Tmp AS VARCHAR(100))
	END
	ELSE
	IF @Type = 1
	BEGIN
		SELECT @Tmp = COUNT(*) 
			FROM (
				SELECT c.billid
					FROM salemanagebill b INNER JOIN billidx c ON b.bill_id = c.billid
				WHERE c.billstates = 0 AND c.billtype IN (10, 12, 150, 152) AND c.Y_ID = @YId AND 
					  b.p_id = @PId AND c.billdate BETWEEN @Begin AND @End
				GROUP BY c.billid
			) a	
		
		IF @Tmp IS NULL
			SET @Tmp = 0.00	
		SET @Result = CAST(CAST(@Tmp AS INT) AS VARCHAR(100))
	END
	ELSE
	IF @Type = 2
	BEGIN
		SELECT @DayCount = COUNT(*) 
			FROM (
				SELECT c.billdate
					FROM salemanagebill b INNER JOIN billidx c ON b.bill_id = c.billid
				WHERE c.billstates = 0 AND c.billtype IN (10, 12, 150, 152) AND c.Y_ID = @YId AND 
					  b.p_id = @PId AND c.billdate BETWEEN @Begin AND @End
				GROUP BY c.billdate
			) a	
		
		IF @DayCount IS NULL
			SET @DayCount = 0
		
		IF @DayCount = 0
		BEGIN
			SET @Result = '0.00'	
		END
		ELSE
		BEGIN
			SELECT @Tmp = SUM(CASE WHEN c.billtype IN (10, 12, 150, 152) THEN b.quantity ELSE -b.quantity END) / @DayCount
				FROM salemanagebill b INNER JOIN billidx c ON b.bill_id = c.billid
			WHERE c.billstates = 0 AND c.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND c.Y_ID = @YId AND 
				  b.p_id = @PId AND c.billdate BETWEEN @Begin AND @End
				
			IF @Tmp IS NULL
				SET @Tmp = 0.00	
				
			SET @Result = CAST(CAST(@Tmp AS INT) AS VARCHAR(100))
		END
	END
	ELSE
	IF @Type = 3
	BEGIN
		SELECT @DayCount = COUNT(*) 
			FROM (
				SELECT c.billdate
					FROM salemanagebill b INNER JOIN billidx c ON b.bill_id = c.billid
				WHERE c.billstates = 0 AND c.billtype IN (10, 12, 150, 152) AND c.Y_ID = @YId AND 
					  b.p_id = @PId AND c.billdate BETWEEN @Begin AND @End
				GROUP BY c.billdate
			) a	
		
		IF @DayCount IS NULL
			SET @DayCount = 0
		
		SET @Result = CAST(CAST(@DayCount AS INT) AS VARCHAR(100))
	END
	ELSE
		SET @Result = ''
		
	
	RETURN @Result	
END
GO
