
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-05-16*/
/* Description:	总部抽取要下传数据*/
/*用途 使用在总部服务端*/
/* =============================================*/
CREATE PROCEDURE [dbo].[Ts_Dt_dts]
(
  @posid  int,
  @Bdtime varchar(20),
  @Edtime varchar(20)
)
AS
BEGIN  
  set nocount on
  begin tran 
  /*----清空数据*/
  truncate table billdtsidx
  truncate table  salemanagebilldts
  truncate table Dtmangedatadts
  /*--写入billdtsidx*/
  insert into billdtsidx
  (
  billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty  
  )
  select billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty
  from billidx
  where c_id=@posid  and billstates=0  and billtype=10 
        and billdate>=@Bdtime and billdate<=@Edtime
  /*--Dtbilldatadts*/
  /*
  truncate table Dtbilldatadts
  insert into Dtbilldatadts
  select a.billid,b.name as cmpname,c.name as empname,d.name as storname,e.name as Y_IDname
  from billdtsidx a
  left join company b    on a.c_id=b.company_id
  left join employees c  on a.e_id=c.emp_id 
  left join storages d   on a.sout_id=d.storage_id
  left join company e    on a.Y_ID=e.company_id
  ----Dtmanagedata
  ------salemanagebilldts
  */  
  insert into salemanagebilldts
  (
   smb_id,bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,totalmoney,
   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,price_id,
   ss_id,sd_id,location_id,supplier_id,commissionflag,comment,unitid,taxrate,order_id,total,iotag,
   InvoiceTotal,thqty,newprice,orgbillid,AOID,jsprice,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
   RowGuid,RowE_id,YCostPrice,YGuid,Y_ID,transflag,instoretime,cxType,location_id2,comment2,BatchBarCode,
   scomment,batchprice,CxGuid  
  )
  select a.smb_id,a.bill_id,a.p_id,a.batchno,a.quantity,a.costprice,a.saleprice,a.discount,a.discountprice,a.totalmoney,
         a.taxprice,a.taxtotal,a.taxmoney,a.retailprice,a.retailtotal,a.makedate,a.validdate,a.qualitystatus,a.price_id,
         a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,a.comment,a.unitid,a.taxrate,a.order_id,a.total,a.iotag,
         a.InvoiceTotal,a.thqty,a.newprice,a.orgbillid,a.AOID,a.jsprice,a.invoice,a.invoiceno,a.PriceType,a.SendQTY,a.SendCostTotal,
         a.RowGuid,a.RowE_id,a.YCostPrice,a.YGuid,a.Y_ID,a.transflag,a.instoretime,a.cxType,a.location_id2,a.comment2,a.BatchBarCode,
         a.scomment,a.batchprice,a.CxGuid
        
  from salemanagebill a , billdtsidx  b
  where a.bill_id=b.billid
  
  insert into Dtmangedatadts
  select a.bill_id,a.smb_id as magbillid,isnull(b.name,'') as proname,isnull(m.name,'') as medname,
  isnull(c.name,'')  as unitname,isnull(b.makearea,''),isnull(b.standard,'') as dstandard,
  b.permitcode,b.validmonth,b.validday, 0 as isvalid,a.RowGuid
  from salemanagebilldts a
  left join products b on a.p_id=b.product_id
  left join unit     c on c.unit_id=b.unit1_id
  left   join 
  (
	select P_id as baseinfo_id,name from ProductCategory p  
	inner join customCategory c on p.PComent3 = c.class_id
	and c.deleted = 0 and Child_Number = 0 and Category_id = 3
   )m on b.product_id = m.baseinfo_id
	  
  commit tran
END
GO
