Create procedure [dbo].[TS_T_HQQty]
( @nSid  int,
  @nY_ID int,
  @nQty  int output
)
AS
Declare @StockQty int,
        @SaleQty int
  if @ny_id is null set @ny_id = 0   
 
 SELECT 
     @StockQty=ISNULL(SUM(SH.[Quantity]), 0) 
  FROM 
       (SELECT ISNULL(SUM(SH.[Quantity]),0)[Quantity]
                 from Storehouse SH
	    WHERE SH.S_id= @nSid
             AND SH.Y_ID =@nY_id  
	  )SH 
/*-zjx--tfs46745---2017-04-01--现在是门店库存上传到总部，所以产品部建议直接用总部库存数量跟门店库存数量进行比较*/
 /*select  @SaleQty=ISNULL(SUM(c.[AllZBRetailQty]),0)  from   
  ( 
		SELECT 	
		[AllZBRetailQty]=(a.ZBRetailQty - a.ZBBackQty)
		FROM 
		(
			SELECT 
			[ZBRetailQty]=sum(case  when   (sm.billtype=12) then sm.quantity else 0 end),
			[ZBBackQty]=sum(case when  (sm.billtype=13) then sm.quantity else 0 end)
			FROM DayAccount DA 
			left join 
			(
				select b.Y_ID,b.billtype,sm.quantity
				from salemanagebill sm
				inner join billidx b on sm.bill_id=b.billid
				where  b.billtype in(12,13) 
				and b.billstates='0' and b.transflag=0 and (@nY_ID=0 or sm.Y_ID=@nY_ID) and sm.p_id>0 and sm.AOID<>7
			) sm on DA.Y_ID=sm.Y_ID
			where (@nY_ID=0 or DA.Y_ID=@nY_ID) and DA.ifValidate=0	
		) a

		union all
		SELECT 
		[AllZBRetailQty]=ISNULL(SUM(b.[Quantity]), 0) 
		FROM 
		(
			SELECT ISNULL(SUM(SH.[Quantity]),0)[Quantity]
                 from Storehouse SH
	         WHERE SH.S_id= @nSid
             AND SH.Y_ID =@nY_id  
		) b
	) c
*/
  select @StockQty/*,@SaleQty*/
   set @nQty=@StockQty/*-@SaleQty*/
   
  return 1
GO
