/************************************************************

--功能：更新会员卡积分   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [TS_j_UpdateVIPCard]
	(
         @VIPCardID int,
         @TotalBuyMoney NUMERIC(25,8),
         @IntergralYE NUMERIC(25,8),
         @Integral int,
         @BuyCount int,
         @RemainderMoney NUMERIC(25,8)
        )
AS 
 
if exists (select 1 from vipcard where vipcardid = @VIPCardID)
begin
  update vipcard set TotalBuyMoney = TotalBuyMoney + @TotalBuyMoney, 
                     IntergralYE = IntergralYE + @IntergralYE,
 	 	     Integral = Integral + @Integral,
  		     BuyCount = BuyCount + @BuyCount,
                     RemainderMoney = RemainderMoney + @RemainderMoney
       where vipcardid = @VIPCardID
  
  if @@error = 0 
    return 0
  else
    return -1
end
 return -1
GO
