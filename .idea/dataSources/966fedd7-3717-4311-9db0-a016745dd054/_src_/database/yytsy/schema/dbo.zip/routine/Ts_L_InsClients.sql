
CREATE  PROCEDURE [Ts_L_InsClients](
@parent_id [varchar](30),          
@serial_number [varchar](26),      
@name [varchar](80),               
@alias [varchar](30),              
@region_id [int],                  
@phone_number [varchar](100),      
@address [varchar](80),            
@zipcode [varchar](10),            
@contact_personal [varchar](20),   
@tax_number [varchar](50),         
@acount_number [varchar](80),      
@credit_total [numeric],           
@APcredit_total [numeric],         
@pinyin [varchar](80),             
@pricemode [smallint],             
@sklimit [smallint],               
@artotal NUMERIC(25,8),           
@artotal_ini NUMERIC(25,8),       
@aptotal NUMERIC(25,8),           
@aptotal_ini NUMERIC(25,8),       
@pre_artotal NUMERIC(25,8),       
@pre_artotal_ini NUMERIC(25,8),   
@pre_aptotal NUMERIC(25,8),       
@pre_aptotal_ini NUMERIC(25,8),   
@firstcheck [bit],                 
@comment [varchar](256),           
@csflag [char](1),                 
@ceType [Tinyint],                 
@GSPNO [varchar](30),              
@GMPNo [varchar](30),              
@incRate NUMERIC(25,8)=1,                
@RowIndex [int],                   /*Wsk add*/
@Licence_no [varchar](512),        /*企业许可证*/
@Ent_type int,                     /*所属类型*/
@City_id [varchar](32),            /*所属市区辖区编码*/
@City_name [varchar](512),         /*所属市区辖区*/
@boro_id [varchar](32),            /*所属县区辖区编码*/
@boro_name [varchar](512),         /*所属县区辖区*/
@e_id int,                         
@createDate varchar(100),          
@C_Customname1 varchar(100),       /*自定义属性1*/
@C_Customname2 varchar(100),       /*自定义属性2*/
@C_Customname3 varchar(100),       /*自定义属性3*/
@C_Customname4 varchar(100),       /*自定义属性4*/
@C_Customname5 varchar(100),       /*自定义属性5*/
@clienttype_id [int],              /*客户类型ID*/
@cardID [int],                     /*会员卡ID*/
@consignBook_no varchar (80),      /*委托书编号*/
@organCard_no varchar (80),        /*组织机构证书编号*/
@BusinessLicence_no varchar (80),  /*营业执照编号*/
@MassConfer_no varchar (128),      
@Cer_CustomNO1 varchar (128),      /*自定义证照编号*/
@Cer_CustomNO2 varchar (128),      
@Cer_CustomNO3 varchar (128),      
@Cer_CustomNO4 varchar (128),      
@Cer_CustomNO5 varchar (128),      
@Y_ID [int],                       /*分支机构ID*/
@ByWayDay [int],                   
@Roadline [int],                   /*配送线路*/
@RoadOrder varchar(5),             /*线路顺序号*/
@OrderCredit [bit],                /*是否允许下订单。0为允许下订单，1为不允许。*/
@discount NUMERIC(25,8),                 
@jsdw_id [int],                    
@ElecCode [bit],                    /* 电子监管码*/
@Quality_Personal VARCHAR(20),      /*质量负责人*/
@Quality_Phone VARCHAR(100),        /*质量负责人电话*/
@QQ VARCHAR(30),                     /*QQ号*/
@ModifyEId      [INT],                /*录入人Id*/
@Cer_CustomNO6 varchar (128),      /*自定义证照编号*/
@Cer_CustomNO7 varchar (128),      
@Cer_CustomNO8 varchar (128),      
@Cer_CustomNO9 varchar (128),      
@Cer_CustomNO10 varchar (128),
@AddressZC varchar (128),
@CreateMan varchar(50),				/* 创建人*/

/*合并8系*/
@zljgPeople  varchar(50),          /*质量机构负责人*/
@zljgphone  varchar(50),             
@cwPeople  varchar(50),            /*财务负责人*/
@cwphone  varchar(50), 
@zlglPeople  varchar(50),          /*质量管理员*/
@zlglphone  varchar(50), 
@storePeople  varchar(50),         /*仓库负责人*/
@storephone  varchar(50),
@FCategoryStr  varchar(100),/*自定义类别字符串 */
@BalanceMode  INT,                  /*结算方式*/
@refEntSeqNo varchar(100),          /*电子监管企业标识*/
@partnerSeqNo varchar(100),          /*电子监管网ID*/
@legalpeople varchar(50),          /*法人代表*/
@legalphone varchar(50),            /*法人代表电话*/
@auditManID int,                    /*审核人ID*/
@auditMan Varchar(50),               /*审核人*/
@CloudCode VARCHAR(60)
)
AS 
/*Params Ini begin*/
if @incRate is null  SET @incRate = 1
/*Params Ini end*/
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int],
  /*@szY_ID int,*/
  @newCid int,
  @AuditStates int
  
  if @auditManID > 0
    set @AuditStates = 1
  else
    set @AuditStates = 0  
/*合法性检查*/
/*if exists(select * from products where )*/
if exists(select * from Clients where serial_number=@serial_number and deleted =0 )
begin
 RAISERROR('编号重复！不能添加！！',16,1)
 return -2
end
/*select * from basefactory*/

/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Clients')


if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*BEGIN TRAN insertBaseClient*/
INSERT INTO [clients] 
  ( [class_id],
  [parent_id],
  [serial_number],
  [name],
  [alias],
  [region_id],
  [phone_number],
  [address],
  [zipcode],
  [contact_personal],
  [tax_number],
  [acount_number],
  [credit_total],
  [pinyin],
  [pricemode],
  [sklimit],
  [artotal],
  [artotal_ini],
  [aptotal],
  [aptotal_ini],
  [pre_artotal],
  [pre_artotal_ini],
  [pre_aptotal],
  [pre_aptotal_ini],
  [firstcheck],
  [comment],
  [csflag],
  [ceType],
  [GSPNo],
  [GMPNo],
  [incrate],
  [RowIndex], /*Wsk add*/
  [Licence_no],          	/*企业许可证*/
  [Ent_type],          		/*所属类型*/
  [City_id],       		/*所属市区辖区编码*/
  [City_name],         		/*所属市区辖区*/
  [boro_id],         		/*所属县区辖区编码*/
  [boro_name],         		/*所属县区辖区*/
  [e_id],
  [createDate],	         
  [C_Customname1],	        /*自定义属性1*/
  [C_Customname2],               /*自定义属性2*/
  [C_Customname3],	        /*自定义属性3*/
  [C_Customname4],	        /*自定义属性4*/
  [C_Customname5],               /*自定义属性5*/
  [clienttype_id],              /*客户类型ID  */
  [card_id],                     /*会员卡ID  */
  [consignBook_no] ,             /*委托书编号*/
  [organCard_no] ,                /*组织机构证书编号*/
  [BusinessLicence_no] ,         /*营业执照编号  TT*/
  [MassConfer_no] ,
  [Cer_CustomNO1] ,
  [Cer_CustomNO2],
  [Cer_CustomNO3],
  [Cer_CustomNO4],
  [Cer_CustomNO5],
  [bywayday],
  [RoadID] ,     
  [szOrdernum],
  [OrderCredit],
  [discount],
  [jsdw_id],
  [ElecCode],
  [Quality_Personal],
  [Quality_Phone],
  [QQ],
  [FirstOperationTime],
  [LastOperationTime],
  [ModifyEId],
  [Cer_CustomNO6],	        /*自定义属性6*/
  [Cer_CustomNO7],          /*自定义属性7*/
  [Cer_CustomNO8],	        /*自定义属性8*/
  [Cer_CustomNO9],	        /*自定义属性9*/
  [Cer_CustomNO10],         /*自定义属性10*/
  [AddressZC], 
  [CreateMan],
  /*合并8*/
  [zljgPeople]
  ,[zljgphone]
  ,[cwPeople]
  ,[cwphone]
  ,[zlglPeople]
  ,[zlglphone]
  ,[storePeople]
  ,[storephone]
  ,[refEntSeqNo]
  ,[partnerSeqNo]
  ,[legalpeople]          /*法人代表   */
  ,[legalphone]           /*法人代表电话*/
  ,[AuditStates]
  , CloudCode
  )
 
VALUES 
 (@tempId,
  @parent_id,
  @serial_number,
  @name,
  @alias,
  @region_id,
  @phone_number,
  @address,
  @zipcode,
  @contact_personal,
  @tax_number,
  @acount_number,
  @credit_total,
  @pinyin,
  @pricemode,
  @sklimit,
  @artotal,
  @artotal_ini,
  @aptotal,
  @aptotal_ini,
  @pre_artotal,
  @pre_artotal_ini,
  @pre_aptotal,
  @pre_aptotal_ini,
  @firstcheck,
  @comment,
  @csflag,
  @ceType,
  @gspNo,
  @gmpNo,
  @incrate,
  @RowIndex,  /*Wsk add*/
  @Licence_no,          	/*企业许可证*/
  @Ent_type,          		/*所属类型*/
  @City_id,       		/*所属市区辖区编码*/
  @City_name,         		/*所属市区辖区*/
  @boro_id,         		/*所属县区辖区编码*/
  @boro_name,         		/*所属县区辖区*/
  @e_id,
  @createDate,
  @C_Customname1,               /*自定义属性1*/
  @C_Customname2,               /*自定义属性2*/
  @C_Customname3,               /*自定义属性3*/
  @C_Customname4,               /*自定义属性4*/
  @C_Customname5,               /*自定义属性5*/
  @clienttype_id,
  @cardID,
  @consignBook_no,             /*委托书编号*/
  @organCard_no,                /*组织机构证书编号*/
  @BusinessLicence_no,         /*营业执照编号  TT*/
  @MassConfer_no,
  @Cer_CustomNO1,
  @Cer_CustomNO2,
  @Cer_CustomNO3,
  @Cer_CustomNO4,
  @Cer_CustomNO5,
  @ByWayDay,
  @Roadline,
  @RoadOrder,
  @OrderCredit,
  @discount,
  @jsdw_id,
  @ElecCode,
  @Quality_Personal,
  @Quality_Phone,
  @QQ,
  '1900-01-01',
  '1900-01-01',
  @ModifyEId,
  @Cer_CustomNO6,
  @Cer_CustomNO7,
  @Cer_CustomNO8,
  @Cer_CustomNO9,
  @Cer_CustomNO10,
  @AddressZC,
  @CreateMan,
  @zljgPeople ,          /*质量机构负责人*/
  @zljgphone ,             
  @cwPeople  ,            /*财务负责人*/
  @cwphone  , 
  @zlglPeople,          /*质量管理员*/
  @zlglphone, 
  @storePeople ,         /*仓库负责人*/
  @storephone,
  @refEntSeqNo,
  @partnerSeqNo,
  @legalpeople,          /*法人代表*/
  @legalphone,            /*法人代表电话*/
  @AuditStates,
  @CloudCode
  )

if @@rowCount=0 

 begin
/* rollback tran insertBaseClient*/
 return -1
end 
else 
begin
  if @jsdw_id >0 
  begin
    declare @nAuditStates int
    select @nAuditStates = AuditStates from clients where client_id = @jsdw_id 
    update clients set AuditStates = @nAuditStates where client_id = @newCid     
  end
        
 update Clients set child_number=@child_number,child_count=@child_count
 where class_id =@Parent_id
/* commit tran insertBaseClient*/
 select @newCid=SCOPE_IDENTITY()/*@@IDENTITY*/
 
    if exists(select 1 from gspalert where c_id = @newCid)
      update gspalert set GmpNO = @GMPNo where c_id = @newCid
    else 
      insert into gspalert(c_id, GmpNO)  values(@newCid, @GMPNo)
    
    declare @nStopClients int
    select @nStopClients = CAST(sysvalue as int) from sysconfig where [sysname] = 'stopClients'
    /*zjx--2017-02-21--tfs45674--处理收货方添加不受系统设置（新增往来单位停用）配置的控制*/
    if @jsdw_id=0
    begin
       if @nStopClients = 1 
          set @nStopClients = 4 
       else 
          set @nStopClients = 0
    end
    else
    begin
        set @nStopClients = 0
    end
 
    update clients set deleted = @nStopClients where client_id = @newCid
    /*-处理自定义类别*/
  /* delete from   customCategoryMapping where category_id=0 
   update customCategoryMapping set baseinfo_id=@newCid where baseinfo_id=0  and BaseTypeid=1
     and id in (select  szTYPE from  DecodeToStr(@FCategoryStr)) and deleted=0*/
  /*exec ts_GetSysValue 'Y_ID',  @szY_ID output*/
    if exists(select * from Clientsbalance where Y_id=@Y_id and c_id=@newCid)
    begin
	UPDATE Clientsbalance 
	
	SET	 [credit_total] 	= @credit_total,

                 [APcredit_total]       = @APcredit_total,

		 [sklimit]		= @sklimit,
		 
		 [artotal_ini]		= @artotal_ini,
		 
		 [aptotal_ini]		= @aptotal_ini,

		 [pre_artotal_ini]	= @pre_artotal_ini,

		 [pre_aptotal_ini]	= @pre_aptotal_ini,
	         [e_id]                 = @e_id,
	     [BalanceMode]      = @BalanceMode
	WHERE 
		( [c_id]		= @newCid  AND
	          Y_id                  = @Y_id)  
	end
	else
	begin
	
	INSERT Clientsbalance(Y_id,C_ID,credit_total,APcredit_total,sklimit,artotal,artotal_ini,aptotal,aptotal_ini,pre_artotal,
	                 pre_artotal_ini,pre_aptotal,pre_aptotal_ini,e_id,operationcount,MoneyProffer,MoneyProffer_ini,MlRateProffer,MlRateProffer_ini,BalanceMode)
	  VALUES(@Y_id,@newCid,@credit_total,@APcredit_total,@sklimit,0,@artotal_ini,0,@aptotal_ini,0,
	                 @pre_artotal_ini,0,@pre_aptotal_ini,@e_id,0,0,0,0,0, @BalanceMode)
    end
  INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes) VALUES(@newCid, 1, @ModifyEId, GETDATE(), '新增往来单位 ' + @name)
  if @auditManID > 0
  begin
     INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes) VALUES(@newCid, 1, @auditManID, GETDATE(), '【审核】')
  end
  if @Ent_type=1 
  begin
    /*zjx--2017-02-27--tfs45863--处理如果添加往来，如果是生产企业，自动写入生产厂家，如果添加收货方则不自动写入生产厂家*/
    if  @jsdw_id=0 
    begin
      /*zjx--2017-03-20--tfs46464--生产厂家.手动录入一个生产厂家，再往里单位资料里添加一个同样名字的生产厂家，生产厂家会有2个同样的*/
      if not exists (select * from basefactory where AccountComment=@name)
      begin
		  insert into basefactory(AccountComment,pinyin)
		  values(@name,@pinyin)
      end
    end
  end
  return @newCid
end
GO
