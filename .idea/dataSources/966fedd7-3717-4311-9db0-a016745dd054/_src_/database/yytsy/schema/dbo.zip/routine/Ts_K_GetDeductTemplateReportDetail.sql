
CREATE PROCEDURE Ts_K_GetDeductTemplateReportDetail(@TId INT, @Begin DATETIME, @End DATETIME)
AS
BEGIN
	DECLARE @Type INT ,@DType INT
	DECLARE @nTempBase NUMERIC(18,4)
	SELECT @Type = ISNULL(s.[Type], 0), @nTempBase = ISNULL(TempBase,0) FROM Deduct_Template s WHERE s.TId = @TId
	SELECT @DType = Type FROM Deduct_Formula where TId = @TId 
	/*'3.25;66.459|94.34#65.3' 返回值格式：3.25张数；66.459行数(提成总基数)；94.34阶段基数；65.3阶段提成额*/
	IF @Type = 0
	BEGIN
		/*职员*/
		
		/*yypeng-TFSBUG40793-2016-09-06-优化存储过程，以后张老师做此类报表时慎用函数，效率很低*/
		/*把方案插入进临时表，减少后面的表关联*/
		select a.type, a.begindate,a.enddate,a.name, b.* 
		into #Formula
		 from Deduct_Formula a inner join Deduct_FormulaDetail b on a.fid =b.fid
		where a.tid = @TId
		
		/*过滤出只是有销售记录的  参与提成的商品与职员的明细，此步骤重点在于减少待会用于函数的记录数，本来30W+的数据变成1W+*/
		if @DType in (0,6,7,8) 
		begin
		 SELECT  bi.p_id, sum(bi.quantity) as quantity ,@TId as TId,d.name,d.type, d.CategoryId, bi.RowE_id as BaseInfoId, d.BeginDate, d.EndDate
				        ,d.rate1,d.rate2,d.rate3,d.rate4,d.BeginNum1,d.BeginNum2,d.BeginNum3,d.BeginNum4,d.EndNum1,d.EndNum2,d.EndNum3,d.EndNum4,e.name as ename
				        
				         into #TempOne
				           FROM   billidx b inner join salemanagebill bi on b.billid = bi.bill_id	
				                            inner join employees e on bi.RowE_id = e.emp_id
				                            inner join #Formula d on bi.p_id = d.categoryid			          
				                WHERE  			                  
				                                     			           
				                  b.billstates = 0	and bi.aoid = 0			                 				                  
				                  AND b.billdate BETWEEN @Begin AND @End				              
				                  AND b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = (select type from Deduct_Formula where TId = @Tid))
				                  and b.e_id in (select BaseInfoId from Deduct_TemplateIds where Tid = @TId)
				                  
				                  group by bi.p_id,d.name,d.type, d.CategoryId, bi.RowE_id, d.BeginDate, 
				                  d.EndDate,d.rate1,d.rate2,d.rate3,d.rate4,d.BeginNum1,d.BeginNum2,d.BeginNum3,d.BeginNum4,
				                  d.EndNum1,d.EndNum2,d.EndNum3,d.EndNum4,e.name
		   
		   	SELECT a.KeyId, a.FName, a.CgName, a.[Type], a.CategoryId, a.BaseInfoId, a.EName,@nTempBase as TempBase, 
		       CASE WHEN a.[Type] = 5 THEN '张数：' + SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) + '；' + 
		                                   '行数：' + SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) 
		       ELSE SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) END AS BaseTotal,
		       SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS BaseTotal,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('|', a.Result1, 0) + 1, (CHARINDEX('#', a.Result1, 0) - 1) - CHARINDEX('|', a.Result1, 0)) AS NUMERIC(25,8)) AS Base1, a.Rate1, 
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) AS Result1, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('|', a.Result2, 0) + 1, (CHARINDEX('#', a.Result2, 0) - 1) - CHARINDEX('|', a.Result2, 0)) AS NUMERIC(25,8)) AS Base2, a.Rate2, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) AS Result2,
		       CAST(SUBSTRING(a.Result3, CHARINDEX('|', a.Result3, 0) + 1, (CHARINDEX('#', a.Result3, 0) - 1) - CHARINDEX('|', a.Result3, 0)) AS NUMERIC(25,8)) AS Base3, a.Rate3, 
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) AS Result3, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('|', a.Result4, 0) + 1, (CHARINDEX('#', a.Result4, 0) - 1) - CHARINDEX('|', a.Result4, 0)) AS NUMERIC(25,8)) AS Base4, a.Rate4, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS Result4, 
		       CAST(SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) AS NUMERIC(25,8)) AS Total1,
		       CAST(SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS NUMERIC(25,8)) AS Total2,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS TcTotal
		    FROM (
				SELECT NEWID() AS KeyId, Name AS FName, dbo.GetDeductTemplateCgName([Type], CategoryId) AS CgName, [Type], CategoryId, 
					   BaseInfoId, EName,
					   Rate1, 
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum1, EndNum1, Rate1, BeginDate, EndDate) AS Result1,
					   Rate2,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum2, EndNum2, Rate2, BeginDate, EndDate) AS Result2,
					   Rate3,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum3, EndNum3, Rate3, BeginDate, EndDate) AS Result3,
					   Rate4,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum4, EndNum4, Rate4, BeginDate, EndDate) AS Result4
					FROM #TempOne
			) a
		 ORDER BY a.BaseInfoId, a.[Type]	                  
				                  
		end 
		if @DType in (1,2,3,4,5)
		begin
			SELECT @TId as TId, a.name,a.type, b.CategoryId, t.BaseInfoId, a.BeginDate, a.EndDate
				   ,b.rate1,b.rate2,b.rate3,b.rate4,b.BeginNum1,b.BeginNum2,b.BeginNum3,b.BeginNum4,b.EndNum1,b.EndNum2,b.EndNum3,b.EndNum4,e.name as ename
				   into #TempTwo FROM  Deduct_Formula a INNER JOIN Deduct_FormulaDetail b ON a.FId = b.FId 
										    INNER JOIN Deduct_TemplateIds t ON a.TId = t.TId
										    INNER JOIN employees e ON t.BaseInfoId = e.emp_id
				  WHERE a.TId = @TId
					SELECT a.KeyId, a.FName, a.CgName, a.[Type], a.CategoryId, a.BaseInfoId, a.EName,@nTempBase as TempBase,
		       CASE WHEN a.[Type] = 5 THEN '张数：' + SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) + '；' + 
		                                   '行数：' + SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) 
		       ELSE SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) END AS BaseTotal,
		       SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS BaseTotal,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('|', a.Result1, 0) + 1, (CHARINDEX('#', a.Result1, 0) - 1) - CHARINDEX('|', a.Result1, 0)) AS NUMERIC(25,8)) AS Base1, a.Rate1, 
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) AS Result1, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('|', a.Result2, 0) + 1, (CHARINDEX('#', a.Result2, 0) - 1) - CHARINDEX('|', a.Result2, 0)) AS NUMERIC(25,8)) AS Base2, a.Rate2, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) AS Result2,
		       CAST(SUBSTRING(a.Result3, CHARINDEX('|', a.Result3, 0) + 1, (CHARINDEX('#', a.Result3, 0) - 1) - CHARINDEX('|', a.Result3, 0)) AS NUMERIC(25,8)) AS Base3, a.Rate3, 
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) AS Result3, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('|', a.Result4, 0) + 1, (CHARINDEX('#', a.Result4, 0) - 1) - CHARINDEX('|', a.Result4, 0)) AS NUMERIC(25,8)) AS Base4, a.Rate4, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS Result4, 
		       CAST(SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) AS NUMERIC(25,8)) AS Total1,
		       CAST(SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS NUMERIC(25,8)) AS Total2,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS TcTotal
		    FROM (
				SELECT NEWID() AS KeyId, Name AS FName, dbo.GetDeductTemplateCgName([Type], CategoryId) AS CgName, [Type], CategoryId, 
					   BaseInfoId, EName,
					   Rate1, 
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum1, EndNum1, Rate1, BeginDate, EndDate) AS Result1,
					   Rate2,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum2, EndNum2, Rate2, BeginDate, EndDate) AS Result2,
					   Rate3,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum3, EndNum3, Rate3, BeginDate, EndDate) AS Result3,
					   Rate4,
					   dbo.GetDeductTemplateTcRate(TId, @Begin, @End, 0, [Type], CategoryId, BaseInfoId, BeginNum4, EndNum4, Rate4, BeginDate, EndDate) AS Result4
					FROM #TempTwo
			) a
		 ORDER BY a.BaseInfoId, a.[Type]	  
		end	
			   			       						
	END
	ELSE
	BEGIN
		/*机构*/
		SELECT a.KeyId, a.FName, a.CgName, a.[Type], a.CategoryId, a.BaseInfoId, a.EName,@nTempBase as TempBase, 
		       CASE WHEN a.[Type] = 5 THEN '张数：' + SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) + '；' + 
		                                   '行数：' + SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) 
		       ELSE SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) END AS BaseTotal,
		       SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS BaseTotal,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('|', a.Result1, 0) + 1, (CHARINDEX('#', a.Result1, 0) - 1) - CHARINDEX('|', a.Result1, 0)) AS NUMERIC(25,8)) AS Base1, a.Rate1, 
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) AS Result1, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('|', a.Result2, 0) + 1, (CHARINDEX('#', a.Result2, 0) - 1) - CHARINDEX('|', a.Result2, 0)) AS NUMERIC(25,8)) AS Base2, a.Rate2, 
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) AS Result2,
		       CAST(SUBSTRING(a.Result3, CHARINDEX('|', a.Result3, 0) + 1, (CHARINDEX('#', a.Result3, 0) - 1) - CHARINDEX('|', a.Result3, 0)) AS NUMERIC(25,8)) AS Base3, a.Rate3, 
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) AS Result3, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('|', a.Result4, 0) + 1, (CHARINDEX('#', a.Result4, 0) - 1) - CHARINDEX('|', a.Result4, 0)) AS NUMERIC(25,8)) AS Base4, a.Rate4, 
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS Result4, 
		       CAST(SUBSTRING(a.Result1, 1, CHARINDEX(';', a.Result1, 0) - 1) AS NUMERIC(25,8)) AS Total1,
		       CAST(SUBSTRING(a.Result1, CHARINDEX(';', a.Result1, 0) + 1, (CHARINDEX('|', a.Result1, 0) - 1) - CHARINDEX(';', a.Result1, 0)) AS NUMERIC(25,8)) AS Total2,
		       CAST(SUBSTRING(a.Result1, CHARINDEX('#', a.Result1, 0) + 1, (LEN(a.Result1)) - CHARINDEX('#', a.Result1, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result2, CHARINDEX('#', a.Result2, 0) + 1, (LEN(a.Result2)) - CHARINDEX('#', a.Result2, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result3, CHARINDEX('#', a.Result3, 0) + 1, (LEN(a.Result3)) - CHARINDEX('#', a.Result3, 0)) AS NUMERIC(25,8)) +
		       CAST(SUBSTRING(a.Result4, CHARINDEX('#', a.Result4, 0) + 1, (LEN(a.Result4)) - CHARINDEX('#', a.Result4, 0)) AS NUMERIC(25,8)) AS TcTotal
		    FROM (
				SELECT NEWID() AS KeyId, a.Name AS FName, dbo.GetDeductTemplateCgName(a.[Type], b.CategoryId) AS CgName, a.[Type], b.CategoryId, 
					   t.BaseInfoId AS BaseInfoId, c.name AS EName,
					   b.Rate1, 
					   dbo.GetDeductTemplateTcRate(a.TId, @Begin, @End, 1, a.[Type], b.CategoryId, t.BaseInfoId, b.BeginNum1, b.EndNum1, b.Rate1, a.BeginDate, a.EndDate) AS Result1,
					   b.Rate2,
					   dbo.GetDeductTemplateTcRate(a.TId, @Begin, @End, 1, a.[Type], b.CategoryId, t.BaseInfoId, b.BeginNum2, b.EndNum2, b.Rate2, a.BeginDate, a.EndDate) AS Result2,
					   b.Rate3,
					   dbo.GetDeductTemplateTcRate(a.TId, @Begin, @End, 1, a.[Type], b.CategoryId, t.BaseInfoId, b.BeginNum3, b.EndNum3, b.Rate3, a.BeginDate, a.EndDate) AS Result3,
					   b.Rate4,
					   dbo.GetDeductTemplateTcRate(a.TId, @Begin, @End, 1, a.[Type], b.CategoryId, t.BaseInfoId, b.BeginNum4, b.EndNum4, b.Rate4, a.BeginDate, a.EndDate) AS Result4			
					FROM Deduct_Formula a INNER JOIN Deduct_FormulaDetail b ON a.FId = b.FId 
										  INNER JOIN Deduct_TemplateIds t ON a.TId = t.TId
										  INNER JOIN company c ON t.BaseInfoId = c.company_id
				WHERE a.TId = @TId	
			) a
		 ORDER BY a.BaseInfoId, a.[Type]
	END
END
GO
