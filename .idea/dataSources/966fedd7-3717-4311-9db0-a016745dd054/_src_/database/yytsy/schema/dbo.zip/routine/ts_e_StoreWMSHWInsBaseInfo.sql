create procedure [dbo].[ts_e_StoreWMSHWInsBaseInfo]
 @QY_id  integer=0,/*区域ID*/
 @HWCode varchar(100)='',/*货位编号*/
 @HWName varchar(100)='',/*货位名称*/
 @LocationType     integer=0,/*货架类型*/
 @PickEasy   integer=0,/*挑选难易程度*/
 @stockpilePgNum [numeric](25,8),/*可以存放品规数*/
 @alreadyPgNum [numeric](25,8),/*已存放品规数*/
 @roadwayCode  varchar(400)='',/*巷道号*/
 @beginrow   [numeric](25,8),/*开始排*/
 @begintier  [numeric](25,8),/*开始层*/
 @begincol   [numeric](25,8),/*开始列*/
 @endrow     [numeric](25,8),/*终止排*/
 @endtier    [numeric](25,8),/*终止层*/
 @endcol     [numeric](25,8),/*终止列*/
 @InsOrUpdate varchar(10)='',/*判断是修改还是新增*/
 @Hw_id      int =0 ,/*货位ID*/
 @TagArea    varchar(400)='',/*电子标签地址*/
 @ControlCode    varchar(400)='',/*控制器编号*/
 @TagTypeId     int =0,/*标签类型ID*/
 @nRet       int OUTPUT,
 @HwCodeZd     varchar(2000) OUTPUT
as
declare @s_id integer
declare @kqid integer
declare @Hwcodestr varchar(2000)
declare @i  integer
select @s_id=b.s_id,@kqid=b.sa_id from WMSRegion a left join stockArea b on a.Store_KQ_ID=b.sa_id where a.ID=@QY_id
begin
 if @InsOrUpdate='Ins'
 begin
   insert into  location(s_id,loc_code,loc_name,Regionid,LocationType,PickEasy,stockpilePgNum,alreadyPgNum,
   roadwayCode,beginrow,begintier,begincol,endrow,endtier,endcol,ElecTronTagArea,ControlCode,TagTypeId,sa_id)
   values(@s_id,@HWCode,@HWName,@QY_id,@LocationType,@PickEasy,@stockpilePgNum,@alreadyPgNum,
   @roadwayCode,@beginrow,@begintier,@begincol,@endrow,@endtier,@endcol,@TagArea,@ControlCode,@TagTypeId,@kqid)
   set  @nRet= @@IDENTITY
   select @Hwcodestr=dbo.GetWMSHWCode(1,@HWCode) 
   set @i=0
   while @i=0 
   begin
      if exists (select 1 from location  where loc_code =@Hwcodestr and deleted=0)
      begin
        select @Hwcodestr=dbo.GetWMSHWCode(1,@Hwcodestr)  
      end
      else
      begin
        set @i=1
      end
   end
   set @HwCodeZd=@Hwcodestr
 end
 else
 begin
   update location  set s_id=@s_id,loc_code=@HWCode,loc_name=@HWName,Regionid=@QY_id,
          LocationType=@LocationType,PickEasy=@PickEasy,stockpilePgNum=@stockpilePgNum,alreadyPgNum=@alreadyPgNum,
   roadwayCode=@roadwayCode,beginrow=@beginrow,begintier=@begintier,begincol=@begincol,endrow=@endrow,
   endtier=@endtier,endcol=@endcol,ElecTronTagArea=@TagArea,ControlCode=@ControlCode,TagTypeId=@TagTypeId,sa_id=@kqid WHERE loc_id=@Hw_id
   IF @@ERROR = 0 
   BEGIN
       set @nRet=1
   END
 end
end
GO
