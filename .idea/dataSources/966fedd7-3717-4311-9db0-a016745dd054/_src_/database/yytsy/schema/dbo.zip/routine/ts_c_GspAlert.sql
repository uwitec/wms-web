CREATE proc ts_c_GspAlert
(
  	@Date  datetime,
	@nDay int=0
)
as
if @nDay is null  SET @nDay = 0
set nocount on 
declare @szSql varchar(8000)
declare @szSql2 varchar(8000)
declare @szSql3 varchar(8000)
declare @repname varchar(512)
declare @cl_id varchar(20)
declare @C_Customname1 varchar(100)
declare @C_Customname2 varchar(100)
declare @C_Customname3 varchar(100)
declare @C_Customname4 varchar(100)
declare @C_Customname5 varchar(100)
declare @szSqlGsp varchar(8000)

select @C_Customname1=sysvalue from SysConfig where sysname = 'C_Customname1'
select @C_Customname2=sysvalue from SysConfig where sysname = 'C_Customname2'
select @C_Customname3=sysvalue from SysConfig where sysname = 'C_Customname3'
select @C_Customname4=sysvalue from SysConfig where sysname = 'C_Customname4'
select @C_Customname5=sysvalue from SysConfig where sysname = 'C_Customname5'

set @szSql = 
'select 
   cast(a.serial_number as nvarchar) as ''编号'',cast(a.[name] as nvarchar)as ''名称'',
   cast(a.alias as nvarchar) as ''简名'',cast(a.phone_number as nvarchar) as ''联系电话'',
   cast(a.address as nvarchar) as ''联系地址'',cast(a.zipcode as nvarchar) as ''邮编'',
   cast(a.contact_personal as nvarchar) as ''联系人'',
   cast(a.RegionName as nvarchar) as ''片区'',
   cast(a.cename as nvarchar) as ''类型'',                  
   cast(a.C_Customname1 as nvarchar) as ['+@C_Customname1+'],cast(a.C_Customname2 as nvarchar) as ['
   +@C_Customname2+'],cast (a.C_Customname3 as nvarchar) as ['+@C_Customname3+'],cast(a.C_Customname4 as nvarchar) as ['
   +@C_Customname4+'],cast(a.C_Customname5 as nvarchar) as ['+@C_Customname5+'],
	   case when w.d5 < 10 then null else w.d5 end ''委托书有效期'',--委托书
	   case when gmp.d11 < 10 then null else gmp.d11 end ''GMP证照有效期'',--GMP证书
   case when r1.validTime = 0 then null else r1.validTime end as ''许可证有效期'',
   case when r2.validTime = 0 then null else r2.validTime end as ''营业执照有效期'',
   case when r3.validTime = 0 then null else r3.validTime end as ''质量保证协议有效期'',
   case when r4.validTime = 0 then null else r4.validTime end as ''组织机构代码证有效期'', 
   case when r5.validTime = 0 then null else r5.validTime end as ''GSP证照有效期'''

set @szSql2 = ''
set @szSql3 = ''
set @szSqlGsp = ''
/*游标循环*/
declare MyCursor cursor
for(select distinct repname, l.cl_id from ClientLicense l left join BindLicense b on l.cl_id=b.cl_id
where l.cl_id > 5 and ent_type <> 5)
open mycursor;
Fetch next from mycursor into @repname, @cl_id;
while @@FETCH_STATUS = 0 
begin
	set @szSql = @szSql + ',case when r'+@cl_id+'.validTime=0 then null else r' + @cl_id+'.validTime end as ' + ''''+cast(@repname as varchar(25))+ '有效期' +''''    /*XXX.2017-02-09 对报表列长度不能大于31 位在这儿进行控制处理*/
	set @szSql2 = @szSql2 + ' left join ClientReport2 r' +@cl_id+' on a.client_id = r'+@cl_id+'.c_id and r'+@cl_id+'.rpn_id='+@cl_id + 'and r' +@cl_id+'.ctype=0'	                  
	set @szSql3 = @szSql3 + ' or (r'+@cl_id+'.validTime < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r'+@cl_id+'.validTime<>0)'		
	
	/*由于出ClientReport2出现重复数据暂时通过Grp分组解决*/
	set @szSqlGsp= @szSqlGsp + ' ,r'+@cl_id+'.validTime';
	
	Fetch next from mycursor into @repname, @cl_id;
end
close mycursor;
deallocate mycursor;
/*print (@szSql)*/
/*print (@szSql2)*/
/*print (@szSql3)*/
set @szSql = @szSql +',cast(a.client_id as nvarchar) as client_id'+
' from vw_Clients a
	left join (select c_id, MIN(validDate) as d5 from wtorder group by c_id) w on a.client_id = w.c_id
	left join (select c_id, MIN(validDate) as d11 from GMPIndex group by c_id) gmp on a.client_id = gmp.c_id
	left join ClientReport2 r1 on a.client_id = r1.c_id and r1.rpn_id=1 and r1.ctype=0 
	left join ClientReport2 r2 on a.client_id = r2.c_id and r2.rpn_id=4 and r2.ctype=0
	left join ClientReport2 r3 on a.client_id = r3.c_id and r3.rpn_id=5 and r3.ctype=0
	left join ClientReport2 r4 on a.client_id = r4.c_id and r4.rpn_id=3 and r4.ctype=0
	left join ClientReport2 r5 on a.client_id = r5.c_id and r5.rpn_id=2 and r5.ctype=0'
+ @szSql2 +
	' where 	((r1.validTime < dateadd(day,'+ convert(varchar,@nDay,0) +',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r1.validTime<>0)
	or	(r2.validTime < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r2.validTime<>0)
	or	(w.d5 < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and w.d5<>0)
	or	(gmp.d11 < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and gmp.d11<>0)
	or	(r3.validTime < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r3.validTime<>0)
	or	(r4.validTime < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r4.validTime<>0)'
+@szSql3+	    
		'or	(r5.validTime < dateadd(day,'+convert(varchar,@nDay,0)+',convert(varchar(10),'+''''+convert(varchar(10),@Date,120)+''''+',20)) and r5.validTime<>0))
		and a.child_number = 0 and a.deleted = 0 
		
		group by serial_number,a.[name],a.alias,a.phone_number,a.address,a.zipcode,a.contact_personal,a.RegionName,a.cename,
		a.C_Customname1,a.C_Customname2,a.C_Customname3 ,a.C_Customname4 ,a.C_Customname5,w.d5,gmp.d11,
		r1.validTime,r2.validTime,r3.validTime,r4.validTime,r5.validTime,a.client_id '+ @szSqlGsp 
		
		/*以上Group by 由于出ClientReport2出现重复数据暂时通过Grp分组解决*/
		       
		      /* print (@szSql)*/
exec (@szSql)
return 0


	/*d1许可证有限期 ,d2营业执照有限期,d5委托书有限期,d8质量认证证书与编号有限期,d9组织机构代码证有限期, d10 GSP有限期 D11 GMP有限期*/
       /*d12，d13,d14,d15,d16自定义证照有限期，*/
GO
