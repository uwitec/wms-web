
/*机构库存分布*/

CREATE PROCEDURE TS_X_RepStorehouseBranchByYid
(
  @c_id	int,					/*供应商id*/
  @fc_id Varchar(500)='',		/*生产厂家  修改为直接传入名称*/
  @pname       Varchar(50)='',	/*商品字段*/
  @HL    Varchar(500)='',		/*货龄*/
  @sxqj  Varchar(500)='',		/*失效区间*/
  @SZPtype  Varchar(1000)='',	/*商品类别字串*/
  @SZCtype  Varchar(1000)='',	/*机构类别字串*/
  @P_ID  INT,					/*商品id*/
  @nloginEID  int = 0,			/*操作员*/
  @ShowByRow int = 0			/*显示方式   0表示按列  1表示按行*/
)
AS

/*Params Ini begin*/

if @c_id is null  SET @c_id = 0
if @fc_id is null  SET @fc_id = ''
if @pname is null  SET @pname = ''
if @HL is null  SET @HL = ''
if @sxqj is null  SET @sxqj = ''
if @SZPtype is null  SET @SZPtype = ''
if @SZCtype is null  SET @SZCtype = ''
if @nloginEID is null  SET @nloginEID = 0

	DECLARE @Products TABLE (PId INT, RetailPrice NUMERIC(25,8))
	IF @pname = '-1'
	BEGIN
		/*根据传入的@P_ID组织数据*/
		INSERT INTO @Products(PId, RetailPrice)
		SELECT p.product_id, ISNULL(a.retailprice, 0.00) 
			FROM products p LEFT JOIN price a ON p.product_id = a.p_id AND p.unit1_id = a.u_id AND a.unittype = 1 
		WHERE p.[deleted] <> 1 AND p.child_number = 0 AND (p.product_id = @P_ID OR @P_ID = 0)
	END
	ELSE
	BEGIN
		/*模糊查询，根据@pname组织数据*/
		INSERT INTO @Products(PId, RetailPrice)
		SELECT p.product_id, ISNULL(a.retailprice, 0.00) 
			FROM products p LEFT JOIN price a ON p.product_id = a.p_id AND p.unit1_id = a.u_id AND a.unittype = 1  
		WHERE p.[deleted] <> 1 AND p.child_number = 0 AND 
		      (p.NAME LIKE '%' + @pname + '%' OR p.alias LIKE '%' + @pname + '%' OR p.pinyin LIKE '%' + @pname + '%' OR p.serial_number LIKE '%' + @pname + '%')
	END
	
  /*新自定义类别的解析，获取过滤的商品id*/
    DECLARE @PColName VARCHAR(100)
    set @PColName = ''
    CREATE TABLE #TmpP ([Pid] [int] NOT NULL DEFAULT(0))
    IF @SZPtype <> ''
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @Pclassid varchar(100)
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@SZPtype))
    
	  SELECT @Pclassid = dbo.GetCateClassids(@SZPtype)
    
      IF @Pclassid IS NULL SET @Pclassid = ''
      IF LEN(@Pclassid) > 0
      SET @Pclassid = LEFT(@Pclassid,LEN(@Pclassid)-1)
    
      set @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')  
      set @PszSql =  'INSERT INTO #TmpP(pid) ' +
		'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @PColName + 
		' in (select type  from DecodeStr(''' +@Pclassid +'''))'  
	  exec (@PszSql)        
    END

    /*新自定义类别的解析，获取过滤的机构id*/
    DECLARE @YColName VARCHAR(100)
    SET @YColName = ''
    CREATE TABLE #TmpY ([Yid] [int] NOT NULL DEFAULT(0))
    IF @SZCtype <> '' 
    BEGIN   
      DECLARE @Yinfo_ID INT
      DECLARE @Yclassid varchar(100)
      DECLARE @YszSql varchar(2000)
      SELECT @Yinfo_ID = Category_id 
      FROM customCategory WHERE ID  in (select type  from DecodeStr(@SZCtype))
    
	SELECT @Yclassid = dbo.GetCateClassids(@SZCtype)
    
      IF @Yclassid IS NULL SET @Yclassid = ''
      IF LEN(@Yclassid) > 0
      SET @Yclassid = LEFT(@Yclassid,LEN(@Yclassid)-1)
    
      set @YColName = dbo.GetColName(@Yinfo_ID,'CompanyCategory')  
      set @YszSql =  'INSERT INTO #TmpY(Yid) ' +
  		'select c.company_id from company c,CompanyCategory yc where c.company_id = yc.Y_id and yc.' + @YColName + 
		' in (select type  from DecodeStr(''' +@Yclassid +'''))'  
  	exec (@YszSql)        
    END    	
/*Params Ini end*/

/*Params Ini end*/

DECLARE @SQL 	VARCHAR(8000)
DECLARE @szS_Id VARCHAR(100)
DECLARE @szYClassID varchar(100)
Declare @Companytable INTEGER,@Storetable integer
create table #Companytable([id] int)
create table #storagestable([id] int)

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

/*货龄条件的转化*/
DECLARE @QJ1 int 
DECLARE @QJ2 int 
DECLARE @QJ3 int
DECLARE @QJ4 int 
DECLARE @QJ5 int 
DECLARE @QJ6 int
DECLARE @QJ7 int 

select @QJ1= CHARINDEX('一个月以内',@HL)
select @QJ2 = CHARINDEX('1-3个月',@HL) 
select @QJ3 = CHARINDEX('3-6个月',@HL) 
select @QJ4 = CHARINDEX('6-12个月',@HL)
select @QJ5 = CHARINDEX('12-24个月',@HL) 
select @QJ6 = CHARINDEX('24-36个月',@HL)    
set @QJ7 = CHARINDEX('36月以上',@HL)
 


/*失效期条件的转化*/
DECLARE @SXQJ1 int 
DECLARE @SXQJ2 int 
DECLARE @SXQJ3 int 
DECLARE @SXQJ4 int 
DECLARE @SXQJ5 int 
DECLARE @SXQJ6 int 
DECLARE @SXQJ7 int 
DECLARE @SXQJ8 int 
DECLARE @SXQJ9 int 

select @SXQJ1 = CHARINDEX('不明确失效期',@sxqj) 
select @SXQJ2 = CHARINDEX('30天内到期',@sxqj) 
select @SXQJ3 = CHARINDEX('30-60天到期',@sxqj)
select @SXQJ4 = CHARINDEX('60-90天到期',@sxqj)  
select @SXQJ5 =  CHARINDEX('90-180天到期',@sxqj)
select @SXQJ6 = CHARINDEX('180-360天到期',@sxqj)    
select @SXQJ7 = CHARINDEX('360-720天到期',@sxqj)
select @SXQJ8 = CHARINDEX('大于720天到期',@sxqj) 
select @SXQJ9 = CHARINDEX('已失效',@sxqj) 


  /*---------------创建临时表用于存储需要的结构---------------*/
  create table #tmp
               (
                 P_id int,	/*商品id*/
                 Pname varchar(200),	/*通用名*/
                 standard varchar(60),  /*规格*/
                 Factory varchar(100),  /*生产厂家		*/
                 UNIT1 varchar(20),		/*单位*/
                 batchno varchar(100),  /*批号*/
                 validdate datetime,    /*效期*/
                 costprice NUMERIC(25,8),  /*成本*/
                 alias varchar(200),    /*商品名*/
                 makedate datetime,     /*生产日期*/
                 pcomment varchar(250), /*商品备注*/
                 supplier_id varchar(100),  /*供应商*/
                 instoretime datetime,  /*入库时间*/
                 makearea varchar(200),  /*产地*/
                 serial_number varchar(200),  /*编码*/
/*                 factoryid varchar(100),  --生产厂家*/
/*                 qty NUMERIC(25,8),				--总数*/
/*                 Total NUMERIC(25,8)    --总金额*/
                  RetailPrice NUMERIC(25,8)
               )             
               
   declare @y_id int  /*机构id*/
   declare @ColName varchar(50)  /*列名称*/
   declare @szY_id varchar(2000) /*	机构id组*/
   declare @szP_id varchar(2000) /*	商品id组*/
   
   set @y_id = 0
   set @sql = ''
   set @ColName = ''
   set @szY_id = ''
   set @szP_id = ''
      
   if @SZCtype = ''   /*通过机构类别查询满足的机构id*/
	 set @szY_id = ''
   else
   begin
     set @szY_id = ''
   end  
   
   if @SZPtype = ''   /*通过商品类别查询满足的商品id*/
	 set @szP_id = ''
   else
   begin
     set @szP_id = ''
   end     
  /* set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  --返回时间差*/

   /*---------插入合计*/
   set @sql =  'ALTER TABLE #tmp Add [qty] NUMERIC(25,8) not NULL default(0)' +
   			   'ALTER TABLE #tmp Add [Total] NUMERIC(25,8) not NULL default(0)' +
   			   'ALTER TABLE #tmp Add [TaxTotal] NUMERIC(25,8) not NULL default(0)' 
			   	
   exec(@sql)   	

   /*---------插入采购员和供应商*/
   set @sql =  'ALTER TABLE #tmp Add [wtoreName] varchar(200) not NULL default('''') ' +
   			   'ALTER TABLE #tmp Add [cname] varchar(200) not NULL default('''')' 
	exec (@sql)	

 if @ShowByRow = 0
 begin
	declare @curComp cursor
	set @curComp = cursor for
	  select company_id as y_id 
		from company m
		where (@szY_id = '' or company_id in (select CAST(szTYPE as int) as y_id from dbo.DecodeToStr(@szY_id))) and class_id <> '000000'
		and company_id in (select Y_ID from storehouse group by Y_ID)

  open @curComp
	FETCH next from @curComp into @y_id  
	  while @@FETCH_STATUS = 0
	  begin
	    if @y_id > 0 
	    begin
		/*插入动态列*/
		select @ColName = name from company where company_id = @y_id
		 set @sql =' ALTER TABLE #tmp Add ['+cast(@y_id as varchar)+'qty'+'] NUMERIC(25,8) not NULL default(0) 
					 ALTER TABLE #tmp Add ['+cast(@y_id as varchar)+'Total'+'] NUMERIC(25,8) not NULL default(0)
					 ALTER TABLE #tmp Add ['+cast(@y_id as varchar)+'TaxTotal'+'] NUMERIC(25,8) not NULL default(0)'  
		 exec (@sql)
		 /*print @sql				*/
		end
		FETCH next from @curComp into @y_id     
	  end 
  close @curComp
  deallocate @curComp 
       		   
 	   	
/*  select * from #tmp 	*/
   /*----------创建临时表 end-----------------*/

	/*先插入所有满足条件的批次*/
   insert #tmp(P_id ,Pname ,standard, Factory ,UNIT1 ,batchno ,validdate ,costprice ,alias,makedate,pcomment,supplier_id ,instoretime,
		  makearea,serial_number,
         [qty],[Total],[TaxTotal],[wtoreName],[cname], RetailPrice) 
   SELECT s.p_id,p.name,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,/*s.costprice*/0,p.alias,s.makedate,rtrim(p.comment) as pcomment,s.supplier_id,/*s.instoretime*/'',   /**/
		  p.makearea,p.Code as serial_number,
		  isnull(SUM(s.quantity),0) as quantity,isnull(SUM(s.quantity* s.costprice),0) as Total,ISNULL(SUM(s.quantity*s.costtaxprice),0) as TaxTotal,
		  ISNULL(e.name,'') as [wtoreName],isnull(c.name,'') as [供应商], a.RetailPrice	
	/* case when s.validdate = '' or s.validdate = 0 then '不确定失效期' when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
		  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
		  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
		  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
		  end as sxq ,s.instoretime,
	 case when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '一个月以内'
		  when cast(DATEADD(DAY,90,s.validdate) as datetime) < GETDATE() then '1-3个月' when cast(DATEADD(DAY,180,s.validdate) as datetime) < GETDATE() then '3-6个月'
		  when cast(DATEADD(DAY,360,s.validdate) as datetime) < GETDATE() then '6-12个月'  when cast(DATEADD(DAY,720,s.validdate) as datetime) < GETDATE() then '12-24个月'
		  when cast(DATEADD(DAY,1080,s.validdate) as datetime) < GETDATE() then '24-36个月' when cast(DATEADD(DAY,1080,s.validdate) as datetime) > GETDATE() then '36个月以上' 
		  end as HL   */   
	 FROM storehouse S INNER JOIN @Products a ON s.p_id = a.PId
	                   left join  vw_b_Products p on s.p_id = p.p_id
					   left join clients c on s.supplier_id = c.client_id
					   left join productbalance pb on p.p_id = pb.p_id
					   left join employees e on pb.Emp_id = e.emp_id
   where (@c_id = 0 or s.supplier_id = @c_id) AND 
		 (@fc_id = '' or p.Factory = @fc_id) AND
		 /*(@P_ID = 0 or s.p_id = @P_ID) AND*/
		 /*(@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND	*/
		 ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
		 ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND 		 
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  
			   )AND 
		 (@SZCtype = '' or S.Y_ID in (select Yid from #TmpY)) AND	
		 (@SZPtype = '' or p.p_id in (select PId from #TmpP))	
   group by s.p_id,p.name,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,s.supplier_id,c.name,p.makearea,p.Code,p.alias,p.comment,s.makedate, a.RetailPrice,e.name /*,s.costprice,s.makedate,s.instoretime*/
/*select * from #tmp*/

/*查询各个机构的数据*/
   SELECT s.p_id,p.name,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,0 as costprice,p.alias as alias,s.makedate as makedate,rtrim(p.comment) as pcomment,s.supplier_id,'' as instoretime,
		  p.makearea,p.Code as serial_number,
		  isnull(SUM(s.quantity),0) as quantity,isnull(SUM(s.quantity* s.costprice),0) as Total,ISNULL(SUM(s.quantity*s.costtaxprice),0) as TaxTotal,
		  ISNULL(e.name,'') as [wtoreName],isnull(c.name,'') as cname,
		  s.Y_ID,cp.name as yname, a.RetailPrice	
		/* case when s.validdate = '' or s.validdate = 0 then '不确定失效期' when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
			  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
			  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
			  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
			  end as sxq ,s.instoretime,
		 case when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '一个月以内'
			  when cast(DATEADD(DAY,90,s.validdate) as datetime) < GETDATE() then '1-3个月' when cast(DATEADD(DAY,180,s.validdate) as datetime) < GETDATE() then '3-6个月'
			  when cast(DATEADD(DAY,360,s.validdate) as datetime) < GETDATE() then '6-12个月'  when cast(DATEADD(DAY,720,s.validdate) as datetime) < GETDATE() then '12-24个月'
			  when cast(DATEADD(DAY,1080,s.validdate) as datetime) < GETDATE() then '24-36个月' when cast(DATEADD(DAY,1080,s.validdate) as datetime) > GETDATE() then '36个月以上' 
			  end as HL */ 
 into #t             
	 FROM storehouse S INNER JOIN @Products a ON s.p_id = a.PId
	                   left join  vw_b_Products p on s.p_id = p.p_id
					   left join clients c on s.supplier_id = c.client_id
					   left join company cp on s.Y_ID = cp.company_id
					   left join productbalance pb on p.p_id = pb.p_id
					   left join employees e on pb.Emp_id = e.emp_id					   
   where (@c_id = 0 or S.supplier_id = @c_id) AND 
		 (@fc_id = '' or p.Factory = @fc_id) AND
		 /*(@P_ID = 0 or s.p_id = @P_ID) AND*/
		 /*(@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND*/
		 ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
		 ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND 	
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  
			   )AND 
		 (@SZCtype = '' or S.Y_ID in (select Yid from #TmpY)) AND	
		 (@SZPtype = '' or p.p_id in (select PId from #TmpP))
   group by s.p_id,p.name,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,s.supplier_id,c.name,S.Y_ID,cp.name,p.makearea,p.Code,p.alias,p.comment,s.makedate, a.RetailPrice ,e.name /*s.costprice,s.makedate,s.instoretime*/
/*	order by p_id,s.validdate					*/

/*select * from #t*/

	declare @curComp2 cursor
	set @curComp2 = cursor for
	  select company_id as y_id 
		from company m 
		where (@szY_id = '' or company_id in (select CAST(szTYPE as int) as y_id from dbo.DecodeToStr(@szY_id))) and class_id <> '000000'
		and company_id in (select Y_ID from storehouse group by Y_ID)

  open @curComp2
	FETCH next from @curComp2 into @y_id  
	  while @@FETCH_STATUS = 0
	  begin
	    if @y_id > 0 
	    begin
		/*更新机构的数据*/
		select @ColName = name from company where company_id = @y_id
		
	    set @sql = 'update #tmp set ['+cast(@y_id as varchar)+'qty'+'] = isnull(#t.quantity,0), ['+cast(@y_id as varchar)+'Total'+'] = isnull(#t.Total,0), ' +
	      ' ['+cast(@y_id as varchar)+'TaxTotal'+'] = isnull(#t.TaxTotal,0) from #t where ' +
	      ' #tmp.p_id = #t.p_id and #tmp.Factory =#t.Factory and #tmp.batchno = #t.batchno and #tmp.validdate = #t.validdate  ' +
	      ' and #tmp.supplier_id = #t.supplier_id  and #tmp.makearea = #t.makearea and #tmp.serial_number = #t.serial_number  ' +  
	      ' and  #t.Y_id = ''' + cast(@y_id as varchar) + ''' and #tmp.[cname] = #t.cname'						 
					   
		 exec (@sql)
		/* print @sql 				*/
		end
		FETCH next from @curComp2 into @y_id     
	  end 
  close @curComp2
  deallocate @curComp2 	  

	SELECT * FROM #tmp
    drop table #tmp
    drop table #t            
 end
 else if @ShowByRow = 1
 begin
   SELECT s.Y_ID,cp.name as yname,cp.serial_number as ycode,	
			s.p_id,p.name as Pname,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,0 as costprice, p.alias as alias,s.makedate as makedate,rtrim(p.comment) as pcomment,s.supplier_id,'' as instoretime,
		  p.makearea,p.Code as serial_number,
		  isnull(SUM(s.quantity),0) as qty,isnull(SUM(s.quantity* s.costprice),0) as Total,ISNULL(SUM(s.quantity*s.costtaxprice),0) as TaxTotal,
		  ISNULL(e.name,'') as [wtoreName],isnull(c.name,'') as cname, a.RetailPrice
		/* case when s.validdate = '' or s.validdate = 0 then '不确定失效期' when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
			  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
			  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
			  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
			  end as sxq ,s.instoretime,
		 case when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '一个月以内'
			  when cast(DATEADD(DAY,90,s.validdate) as datetime) < GETDATE() then '1-3个月' when cast(DATEADD(DAY,180,s.validdate) as datetime) < GETDATE() then '3-6个月'
			  when cast(DATEADD(DAY,360,s.validdate) as datetime) < GETDATE() then '6-12个月'  when cast(DATEADD(DAY,720,s.validdate) as datetime) < GETDATE() then '12-24个月'
			  when cast(DATEADD(DAY,1080,s.validdate) as datetime) < GETDATE() then '24-36个月' when cast(DATEADD(DAY,1080,s.validdate) as datetime) > GETDATE() then '36个月以上' 
			  end as HL */ 
 /*into #tmp2             */
	 FROM storehouse S INNER loop JOIN @Products a ON s.p_id = a.PId
	                   left loop join  vw_b_Products p on s.p_id = p.p_id
					   left loop join clients c on s.supplier_id = c.client_id
					   left loop join company cp on s.Y_ID = cp.company_id
					   left loop  join productbalance pb on s.p_id = pb.p_id and s.Y_ID = pb.Y_id
					   left loop join employees e on pb.Emp_id = e.emp_id				   
   where (@c_id = 0 or S.supplier_id = @c_id) AND 
		 (@fc_id = '' or p.Factory = @fc_id) AND
		 /*(@P_ID = 0 or s.p_id = @P_ID) AND*/
		 /*(@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND*/
		 ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
		 ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND 	
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  
			   )AND 
		 (@SZCtype = '' or S.Y_ID in (select Yid from #TmpY)) AND	
		 (@SZPtype = '' or p.p_id in (select PId from #TmpP))
   group by s.p_id,p.name,p.standard,p.Factory,p.unit1,s.batchno,s.validdate,s.supplier_id,c.name,s.Y_ID,cp.name,cp.serial_number,p.makearea,p.Code,p.alias,p.comment,s.makedate, a.RetailPrice,e.name  /*s.costprice,s.makedate,s.instoretime*/
	order by s.Y_ID,S.p_id,s.validdate	 
 end
GO
