CREATE proc WebApp_OALIST
 (
   @intuserid  int,
   @title VARCHAR(20),
   @params VARCHAR(100)
 )
--$encode$--
as
BEGIN
	SELECT * FROM TeenySoftMaster.dbo.WebAPP_OAMessage
	END
GO
