
CREATE view vw_M_VipCard as
                      						  
SELECT  
	V.[VIPCardID], V.[CardNo], V.[Name], V.[sex], V.[Tel], V.[Birthday], V.[Address], 
	V.[Comment], V.[IDCard], V.[CT_ID],CT.Name AS CTName,
	V.[BulidDate], V.[ValidityDate], 
        V.[Pos_Id], ISNULL(S.[PosName],'')PosName,
	V.[E_id],ISNULL(E.[Name],'')[ENAME], V.[IniMoney], 
	V.[TotalBuyMoney], V.[SaveMoney], V.[IntergralYE], V.[IniIntergral], V.[Integral], 
	V.[SwapIntegral], V.[BuyCount], V.[LoginPass] ,V.Deleted,V.Lose,V.StopUse,V.RemainderMoney,V.ISLOCK,V.Y_id,isnull(Y.name,'')Y_name,
        v.PinYin,V.small,
	CT.CODE, 
	CT.NAME as TypeName, 
	CT.ISBANK, 
	CT.ISINTEGRAL, 
	CT.PRICEMODE, 
	CT.DISCOUNT, 
	CT.INTEGRALMONEY, 
	CT.ISYEINTEGRAL, 
	CT.ISSPECIALPRICEINTEGRAL, 
	CT.ISPROMOTIONINTEGRAL, 
	CT.ISMONEYUP, 
	CT.UPMONEY, 
	CT.MONEYUPCT_ID, 
	CT.ISINTEGRALUP, 
	CT.UPINTEGRAL, 
	CT.INTEGERALUPCT_ID, 
	CT.UPDECINTEGRAL, 
	CT.SAVEDATE, 
	CT.ISPDISCOUNT, 
	CT.ISPINTEGRAL, 
	CT.ISDISCOUNT, 
	CT.ISAUTODISCOUNT,
	ct.IsCxIntegral,
	isnull(sl.todaySale,0) as todaySale,
    ct.IsDrift, v.RetailHint
	FROM [VIPCard] V inner join VIPCardType ct on CT.ct_id=v.ct_id
	LEFT JOIN SHOP		S ON V.Pos_Id=S.PosId 
	LEFT JOIN Employees	E ON E.Emp_Id=V.E_Id
        LEFT JOIN Company       Y ON Y.Company_id=V.Y_id
    left join 
    (
      select VIPCardID,sum(case billtype when 13 then -ysmoney else ysmoney end) as 'todaySale'  from billidx 
	  where billtype in (12,13) and billstates = 0 and billdate = left(convert(varchar,GETDATE(),121),10)
	  and VIPCardID <> 0 
	  group by VIPCardID
    ) sl on sl.VIPCardID = v.VIPCardID   

WHERE   V.Deleted<>1
GO
