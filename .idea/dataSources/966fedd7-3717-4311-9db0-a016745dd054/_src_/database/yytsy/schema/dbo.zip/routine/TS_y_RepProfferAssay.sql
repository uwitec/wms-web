
/* 功能：商品贡献度分析报表
  
*/

CREATE PROCEDURE TS_y_RepProfferAssay
( 
	@szbegindate varchar(20),   /*开始时间*/
	@szenddate   varchar(20),   /*结束时间*/
	@JAsvalue     int = 0,
	@JAevalue     int = 0,
	@JBsvalue     int = 0,
	@JBevalue     int = 0,
	@JCsvalue     int = 0,
	/*@JCevalue     int = 0,*/
	@MAsvalue     int = 0,
	@MAEvalue     int = 0,
	@MBsvalue     int = 0,
	@MBEvalue     int = 0,
	@MCsvalue     int = 0,
	/*@MCEvalue     int = 0,*/
	@CAsvalue     int = 0,	
	@CAEvalue     int = 0,
	@CBsvalue     int = 0,	
	@CBEvalue     int = 0,	
	@CCsvalue     int = 0	
	/*@CCEvalue     int = 0		  	*/
)
AS
BEGIN
      create table #temp
             ( 
               Atype      int,
               billid     int,
               billtype   int,
               p_id       int,
               quantity   numeric(25,8),
               costprice  numeric(25,8),
               totalmoney numeric(25,8),
               ml         numeric(25,8),
               lks        int ,
               zml        numeric(25,8),
               zje        numeric(25,8),
               zsl        numeric(25,8),
               jegx       varchar(10),
               mlgx       varchar(10),
               lkgx       varchar(10),
               costtaxtotal numeric(25,8),
               taxtotal     numeric(25,8)
              ) 
  /*-提取数据            */
  insert into #temp(Atype,billid,billtype,p_id,quantity,costprice,totalmoney,ml,costtaxtotal,taxtotal)
  select  1,a.billid,a.billtype,b.p_id, 
  (case when billtype = 12 then  b.quantity else  -b.quantity end) as quantity, 
  (case when billtype = 12 then  b.totalmoney else -b.totalmoney end) as totalmoney,
  b.costprice,
  (case when billtype = 12 then  (taxtotal-costtaxtotal) else -(taxtotal-costtaxtotal) end ) as ml,
  (case when billtype = 12 then  b.costtaxtotal else -b.costtaxtotal end) as costtaxtotal,
  (case when billtype = 12 then  b.taxtotal else -b.taxtotal end) as taxtotal
  from billidx  a,salemanagebill b  
  where a.billdate>=@szbegindate and  a.billdate<=@szenddate and
         b.p_id>0 and a.billid=b.bill_id and a.billstates=0 and b.AOID=0 and a.billtype in (12,13)
  /*-*/
 /* update #temp set ml=-ml,totalmoney=-totalmoney
  where  billtype in(12)*/
  /*来客数*/
  insert into #temp(Atype,p_id,lks)
  select 2,p_id,COUNT(p_id)
  from #temp
  group by  p_id/*,billid */
  /*-毛利,金额,数量*/
  insert into #temp(Atype,p_id,zml,zje,zsl,costtaxtotal,taxtotal)
  select 3,p_id,SUM(ml),SUM(totalmoney),SUM(quantity),SUM(costtaxtotal),SUM(taxtotal)
  from #temp
  group by  p_id 
  
  insert into #temp(Atype,p_id,lks,zml,zje,zsl,jegx,mlgx,lkgx,costtaxtotal,taxtotal)
  select distinct  4,a.p_id,b.lks,c.zml,c.zje,c.zsl,'','','',c.costtaxtotal,c.taxtotal
  from 
  (select * from #temp where Atype=1) a,
  (select * from #temp where Atype=2) b,
  (select * from #temp where Atype=3) c
   where a.p_id=b.p_id and b.p_id=c.p_id
  
  delete #temp where Atype<>4

  update #temp  set jegx=b.jegx,mlgx=b.mlgx,lkgx=B.lkgx
  from  #temp a,
  (
    select p_id,
    (Case  
     when zje>=@JAsvalue and zje<=@JAevalue then 'A'
     when zje>@JBsvalue and zje<=@JBevalue then 'B'
     when zje>@JCsvalue then  'C'
     else
       ''
     end 
     ) AS jegx,
    (Case  
     when zml>=@MAsvalue and zml<=@MAevalue then 'A'
     when zml>@MBsvalue and zml<=@MBevalue then 'B'
     when zml>@MCsvalue then  'C'
     else
       ''
     end 
     ) AS mlgx,
    (Case  
     when lks>=@CAsvalue and lks<=@CAEvalue then 'A'
     when lks>=@CBsvalue and lks<=@CBEvalue then 'B'
     when lks>=@CCsvalue then  'C'
     else
       ''
     end 
     ) AS lkgx     
  from  #temp
  )b
  where a.p_id=b.p_id
  /*select a.p_id,b.serial_number as code,b.name,c.name as unitname,b.standard,d.mt_name,a.jegx,a.mlgx,a.lkgx,a.lks,a.zml,a.zje,a.zsl*/
  select a.p_id,a.jegx,a.mlgx,a.lkgx,a.lks,a.zml,a.zje,a.zsl,a.costtaxtotal,a.taxtotal
  from #temp a
    
  drop table  #temp    
END
GO
