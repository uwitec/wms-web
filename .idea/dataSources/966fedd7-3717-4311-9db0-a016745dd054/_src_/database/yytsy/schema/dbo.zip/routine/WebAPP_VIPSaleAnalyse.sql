/**************************************************************
app_yyt会员分析查询
**************************************************************/
create proc WebAPP_VIPSaleAnalyse
(
  @Begin      DATETIME = 0,
  @End        DATETIME = 0,
  @chvparams  varchar(400) = '',
  @retmessage varchar(200) OUT
)
--$encode$--
as
BEGIN
	--DECLARE @a VARCHAR(200)
    --EXEC WebAPP_VIPSaleAnalyse;1 '2017-01-19', '2017-05-19', 'y_id=2',@a
	
	IF object_id(N'#BaseData', N'U') is not null
		Drop Table #BaseData
	
	CREATE TABLE #BaseData 
	(
		y_id           INT NULL DEFAULT(0) , 
		VIPCardID      INT NULL DEFAULT(0) ,
		ysMoney        NUMERIC(18, 4) NULL DEFAULT('') ,
		VIPysMoney     NUMERIC(18, 4) NULL DEFAULT('')
	)
	
	SET @retmessage = '操作成功'

	DECLARE @YId INT --机构ID
	        
	SET @YId = dbo.webapp_get_param(@chvparams, 'y_id', default, default)
	
	INSERT INTO #BaseData(y_id, VIPCardID, ysMoney, VIPysMoney)
	SELECT y_id, VIPCardID, 
           CASE WHEN billtype = 12 THEN ysmoney ELSE -ysmoney END AS ysMoney,
           CASE WHEN VIPCardID > 0 THEN (CASE WHEN billtype = 12 THEN ysmoney ELSE -ysmoney END) ELSE 0 END AS VIPysMoney
		FROM billidx 
	WHERE billtype IN (12, 13) AND (y_id = 0 OR 0 = 0) AND billdate BETWEEN @Begin AND @End
	
	--返回的数据集	 
    SELECT y.name AS YName,                        --机构名称
		   y.company_id as y_id,                   --机构id
           d.ysMoney,                              --实收金额
           d.VIPysMoney,                           --会员消费金额
           d.Rate,                                 --会员占比
           ISNULL(e.CardCount, 0) AS NewCardCount  --新增会员数
		FROM (
			SELECT y_id, 
				   SUM(ysMoney) AS ysMoney, 
				   SUM(VIPysMoney) AS VIPysMoney,
				   CASE WHEN SUM(ysMoney) = 0 THEN '0.00%' 
						ELSE CAST(CAST(ROUND(SUM(VIPysMoney) / SUM(ysMoney), 2) AS NUMERIC(18, 2)) * 100 AS VARCHAR) + '%' END AS Rate 
			FROM #BaseData 
			GROUP BY y_id	
		) d 
		LEFT JOIN (
			SELECT a.y_id, COUNT(*) AS CardCount FROM (
				SELECT y_id, VIPCardID FROM #BaseData GROUP BY y_id, VIPCardID) a 
				INNER JOIN (
					SELECT v.VIPCardID FROM VIPCard v WHERE v.BulidDate BETWEEN @Begin AND @End	
				) b ON a.VIPCardID = b.VIPCardID
			GROUP BY a.y_id	
		) e ON d.y_id = e.y_id
		INNER JOIN company y ON d.y_id = y.company_id
		where d.y_id = @YId or @YId = 0
	IF object_id(N'#BaseData', N'U') is not null
		Drop Table #BaseData	
END
GO
