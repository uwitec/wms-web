/*自定义类别查询  zjl 2013-05-08*/
create   PROCEDURE ts_j_SelCustomCategory
(	
    @szParent_id varchar(10),
	@szWhere	varchar(500),
	@nBaseType  int=0,
	@nSelMode	int=0,
	@szclass_id	varchar(200)	
)
AS

if @szclass_id is null set @szclass_id = ''

/*exec ts_j_SelCustomCategory '00','',-1,0*/
set nocount on
declare @Sql varchar(8000)
declare @lParent_id int
declare @nNextid int
if @szParent_id<>'00'
begin
   set @nNextid=1
   set @szWhere=''
end
	    
if @nSelMode = 0 
begin
      select @lParent_id = id from customCategory where class_id = @szParent_id  and deleted=0
      select *, 
         Case baseType when 0 then '商品资料'
					   when 1 then '往来单位资料'		        
                       when 2 then '分支机构资料'
                       when -1 then '全部' 
         end as baseTypename, 
         LEFT(class_id, 2) as MAINCATEGORYNO,  
         dbo.GetCateGoryStr(ID, 'MAINCATEGORY') as MAINCATEGORY, 
         class_id as SUBCATEGORYNO,
         dbo.GetCateGoryStr(ID, 'SUBCATEGORY') as SUBCATEGORY,         
         id as CG_ID        
  from customCategory 
  where parent_id = @lParent_id and
	    ((@nBaseType < 0) or (baseType in(@nBaseType)) or ((@nBaseType = 0) and (baseType = -1))) 
	    and deleted = 0 and class_id <> '00' 
	    and ((@szclass_id = '') or (class_id = @szclass_id))
  order by rowIndex	    
end
else if @nSelMode = 1 
begin
  if @nNextid=1/*-点击下一步选择子类别*/
  begin
      select @lParent_id = id from customCategory where class_id = @szParent_id and deleted=0
	  if @szWhere <> '' 
	  set @szWhere = ' and (name like ''%@szWhere%'' or  pinyin like ''%@szWhere%'') '   
		   set @Sql = 
			'select *, 
				 Case baseType when 0 then ''商品资料''
							   when 1 then ''往来单位资料''		        
							   when 2 then ''分支机构资料'' 
							   when -1 then ''全部''
				 end as baseTypename,
				 left(Class_id, 2) as MAINCATEGORYNO,
				 dbo.GetCateGoryStr(ID, ''MAINCATEGORY'') as MAINCATEGORY, 
				 class_id as SUBCATEGORYNO, 
				 dbo.GetCateGoryStr(ID, ''SUBCATEGORY'') as SUBCATEGORY,     
				 id as CG_ID
		  from customCategory 
		  where parent_id = '+cast(@lParent_id as varchar)+' and ((baseType = '+ cast(@nBaseType as varchar) +') or (('+ cast(@nBaseType as varchar) +' =0) and (basetype=-1)))  and 
		  deleted = 0   and class_id <> ''00''' 
		 /* and (( + ''' +@szclass_id +''' = '''') or (class_id ='''+ @szclass_id + ''' )) '*/
		  + @szWhere +'  order by rowIndex'  
		  print @Sql
		  exec(@Sql)
  end
  else
  begin
     if @szWhere=''/*判断报表选择自定义类型*/
     begin
         select *, 
         Case baseType when 0 then '商品资料'
					   when 1 then '往来单位资料'		        
                       when 2 then '分支机构资料' 
                       when -1 then '全部' 
         end as baseTypename,
         left(Class_id, 2) as MAINCATEGORYNO,
         dbo.GetCateGoryStr(ID, 'MAINCATEGORY') as MAINCATEGORY, 
         class_id as SUBCATEGORYNO, 
         dbo.GetCateGoryStr(ID, 'SUBCATEGORY') as SUBCATEGORY,     
         id as CG_ID
			  from customCategory 
			  where ((@nBaseType < 0) or (baseType in(@nBaseType)) or ((@nBaseType = 0) and (baseType = -1)))  
			  and parent_id=1 and  child_number <> 0 and 
			  deleted = 0 and class_id <> '00' 
			  and ((@szclass_id = '') or (class_id = @szclass_id))
			  order by rowIndex, Class_Id
     end
     else/*基本信息选择自定义类型*/
     begin
		   select *, 
				 Case baseType when 0 then '商品资料'
							   when 1 then '往来单位资料'		        
							   when 2 then '分支机构资料'
							   when -1 then '全部' 
				 end as baseTypename,
				 left(Class_id, 2) as MAINCATEGORYNO,
				 dbo.GetCateGoryStr(ID, 'MAINCATEGORY') as MAINCATEGORY, 
				 class_id as SUBCATEGORYNO, 
				 dbo.GetCateGoryStr(ID, 'SUBCATEGORY') as SUBCATEGORY,     
				 id as CG_ID
		  from customCategory 
		  where deleted = 0 and typeid =0  and class_id =@szWhere 
		     and ((@szclass_id = '') or (class_id = @szclass_id))
		   order by rowIndex
     end
 end
end

return 0
GO
