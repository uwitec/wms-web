
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-07-27*/
/* Description:	商品配送分布*/
/*
exec Ts_Y_qrCompanySenddis ;1 '2013-03-22 00:00:00','2013-05-02 23:59:59',0,2,2
总部对门店  出库 机构发货单   150    自营店发货单  152
            
            入库 机构发货退货单 151  自营店发货退货单 153


门店对门店  出库 机构发货单  150  自营店发货单 152

            入库 机构收货单 160 自营店收货单  162

门店对总部  出库 机构收货退货单  161自营店收货退货单163

            入库 机构收货单 160 自营店收货单 162
*/            
/* =============================================*/
CREATE PROCEDURE [dbo].[Ts_Y_qrCompanySenddis]
(
  @BeginDate 	datetime,
  @EndDate	 	datetime,
  @p_id int,
  @c_id int,
  @y_id int
)
AS
BEGIN 
CREATE TABLE #t1
 (	
    billtype  INT,
    by_id     INT,
	c_id      INT,
    y_id      INT,
    p_id      INT,
    quantity  NUMERIC(25,8),
    costtotal NUMERIC(25,8),
    total     NUMERIC(25,8),
    sDatetime datetime
  )
CREATE TABLE #temp
 (	
    Atype  varchar(10),
    P_ID INT,
	inqty NUMERIC(25,8),
    outqty NUMERIC(25,8),
	intotal  NUMERIC(25,8),
    outtotal NUMERIC(25,8), 
    mltotal  NUMERIC(25,8),   
    c_id   INT,
    c_name varchar(100)
  )
CREATE TABLE #tempC(C_ID INT,c_name VARCHAR(100))
/*提取数据*/
declare  @p_id1 int,@p_id2 int 
select @p_id1=@p_id,@p_id2=@p_id1
if @p_id1=0 select @p_id2=2147483647
declare @ztjg varchar(1000)
declare @cjg  varchar(1000)
if @c_id=0
  set @c_id=(select company_id from company where class_id='000001')
set @y_id=@c_id
set @ztjg=(select class_id from company where company_id=@y_id)
set @cjg =(select class_id from company where company_id=@c_id)
  /*-写临时表*/
  insert into  #t1 
  select a.billtype,a.y_id as by_id,a.c_id,b.y_id,b.p_id,b.quantity,b.costtotal,b.total,b.makedate
  from billidx a,productdetail b
  where a.billid=b.billid  and a.billtype in (150,151,152,153,160,161,162,163)
        and a.billdate>=@BeginDate and  a.billdate<=@EndDate
        and b.p_id>=@p_id1 and b.p_id<=@p_id2
  order by a.c_id,b.p_id
  if @ztjg ='000001'  /*总部账套*/
  begin
       /*1 总部对门店-- if @c_id = @y_id  --选择发货机构为'总部'*/
     insert into #temp(Atype,p_id,c_id,inqty,intotal,outqty,outtotal,mltotal)  
     select '1',p_id,c_id,
     sum(case when billtype in (150,152) then -quantity else 0 end)inqty,
     sum(case when billtype in (150,152) then -total else 0 end)intotal,
     sum(case when billtype in (151,153) then quantity else 0 end)outqty,
     sum(case when billtype in (151,153) then total else 0 end)outtotal,
     (sum(case when billtype in (150,152) then -total else 0 end) - 
        sum(case when billtype in (150,152) then -costtotal else 0 end))mltotal
     from #t1 
     where   by_id=y_id and  by_id=@c_id and billtype in (150,151,152,153) /*and c_id in (3,4)*/
     group by p_id,c_id        
  end
  if @ztjg <>'000001'   /*门店帐套*/
  begin
      /* if @c_id = @y_id  --选择发货机构为'本机构'*/
     insert into #temp(Atype,p_id,c_id,inqty,intotal,outqty,outtotal,mltotal)  
     select '1',p_id,c_id,
     sum(case when billtype in (150,152,161,163) then -quantity else 0 end)inqty,
     sum(case when billtype in (150,152,161,163) then -total else 0 end)intotal,
     sum(case when billtype in (160,162) then quantity else 0 end)outqty,
     sum(case when billtype in (160,162) then total else 0 end)outtotal,
     (sum(case when billtype in (150,152,161,163) then -total else 0 end) - 
        sum(case when billtype in (150,152,161,163) then -costtotal else 0 end))mltotal
     from #t1 
     where   by_id=y_id and by_id=@c_id and billtype in (150,152,160,162,161,163) 
     group by p_id,c_id
  end
   
  update #temp set c_name=b.class_id
  from #temp a,company b
  where a.c_id=b.company_id
  
insert into #tempC select distinct  a.c_id,b.class_id AS c_name
from #temp a,company b  where a.c_id=b.company_id
    
/*--------*/
 declare @col         varchar(8000)
 declare @SQL         varchar(8000)
 declare @iFor        int 
 declare @SQLC        varchar(8000)
 declare @SQLCc        varchar(8000)
 declare @SQLinqty    varchar(8000)
 declare @SQLintotal  varchar(8000)
 declare @SQLoutqty   varchar(8000)
 declare @SQLouttotal varchar(8000)
 declare @Sml         varchar(8000)
 declare @MSQL        varchar(8000)
 set @MSQL=''
 set @SQLC=''
 set @SQLCc=''
 set @SQLinqty=''
 declare curAlter scroll cursor for
 select c_name from #tempC
 open curAlter
 set @iFor = 0
 while @iFor < @@cursor_rows
 begin
     fetch next from curAlter into @col
     /*增加列  入库inqty*/
     set @SQL='ALTER TABLE #temp ADD '+'A'+@col+'  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
     exec(@SQL)
     /*修改数据*/
     set @SQL='update #temp set '+'A'+@col+'=b2.inqty '+' from #temp b1 ,(select distinct P_ID,c_name,inqty from #temp  '
     set @SQL=@SQL+' where c_name='+''''+@col+''''+ ') b2 ' 
     set @SQL=@SQL+' where b1.p_id=b2.p_id and b1.c_name='+''''+@col+''''      
     exec(@SQL)
     /*增加列  出库outqty*/
     set @SQL='ALTER TABLE #temp ADD '+'B'+@col+'  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
     exec(@SQL)
     /*修改数据  ,c_name +'2'*/
     set @SQL='update #temp set '+'B'+@col+'=b4.outqty '+' from #temp b3 ,(select distinct P_ID,c_name,outqty from #temp  '
     set @SQL=@SQL+' where c_name='+''''+@col+''''+ ') b4 ' 
     set @SQL=@SQL+' where b3.p_id=b4.p_id and b3.c_name='+''''+@col+''''      
     exec(@SQL)  
     /*增加列  入库金额intotal*/
     set @SQL='ALTER TABLE #temp ADD '+'C'+@col+'  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
     exec(@SQL)
     /*修改数据  */
     set @SQL='update #temp set '+'C'+@col+'=b6.intotal '+' from #temp b5 ,(select distinct P_ID,c_name,intotal from #temp  '
     set @SQL=@SQL+' where c_name='+''''+@col+''''+ ') b6 ' 
     set @SQL=@SQL+' where b5.p_id=b6.p_id and b5.c_name='+''''+@col+''''      
     exec(@SQL)
     /*增加列  出库金额outtotal*/
     set @SQL='ALTER TABLE #temp ADD '+'D'+@col+'  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
     exec(@SQL)
     /*修改数据 */
     set @SQL='update #temp set '+'D'+@col+'=b2.outtotal '+' from #temp b1 ,(select distinct P_ID,c_name,outtotal from #temp  '
     set @SQL=@SQL+' where c_name='+''''+@col+''''+ ') b2 ' 
     set @SQL=@SQL+' where b1.p_id=b2.p_id and b1.c_name='+''''+@col+''''      
     exec(@SQL)
     /*--毛利*/
     set @SQL='ALTER TABLE #temp ADD '+'E'+@col+'  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
     exec(@SQL)  
     /*修改数据  */
     set @SQL='update #temp set '+'E'+@col+'=b2.mltotal '+' from #temp b1 ,(select distinct P_ID,c_name,mltotal from #temp  '
     set @SQL=@SQL+' where c_name='+''''+@col+''''+ ') b2 ' 
     set @SQL=@SQL+' where b1.p_id=b2.p_id and b1.c_name='+''''+@col+''''      
     exec(@SQL)
     /*-生成查询字段*/
     set  @SQLC=@SQLC+','+'A'+@col+','+'B'+@col+','+'C'+@col+','+'D'+@col+','+'E'+@col
     set  @MSQL=@MSQL+','+'sum(A'+@col+'),'+'sum(B'+@col+'),'+'sum(C'+@col+'),'+'sum(D'+@col+'),'+'sum(E'+@col+')'
     /*-合计*/
     if  @iFor=0 
     begin
       set @SQLinqty    ='(A'+@col+'+'
       set @SQLintotal  ='(C'+@col+'+'
       set @SQLoutqty   ='(B'+@col+'+'
       set @SQLouttotal ='(D'+@col+'+'
       set @Sml         ='(E'+@col+'+'
     end
     else
     begin
       if @iFor=@@cursor_rows-1  
       begin
         set @SQLinqty    =@SQLinqty+'A'+@col+')'
         set @SQLintotal  =@SQLintotal+'C'+@col+')'
         set @SQLoutqty   =@SQLoutqty+'B'+@col+')'
         set @SQLouttotal =@SQLouttotal+'D'+@col+')'
         set @Sml         =@Sml+'E'+@col+')'
       end
       else
       begin
         set @SQLinqty    =@SQLinqty+'A'+@col+'+'
         set @SQLintotal  =@SQLintotal+'C'+@col+'+'
         set @SQLoutqty   =@SQLoutqty+'B'+@col+'+'
         set @SQLouttotal =@SQLouttotal+'D'+@col+'+'
         set @Sml         =@Sml+'E'+@col+'+'
       end           
     end
	set @iFor = @iFor + 1
 end 
 DEALLOCATE curAlter
 /*--*/
 
 
 
 /*--*/
 /*-加入合计字段 */
 if @iFor>1 
 begin     
   set @SQL='ALTER TABLE #temp ADD Sinqty  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
   exec(@SQL)
   set @SQL='ALTER TABLE #temp ADD Sintotal NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
   exec(@SQL)
   set @SQL='ALTER TABLE #temp ADD Soutqty  NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
   exec(@SQL)
   set @SQL='ALTER TABLE #temp ADD Souttotal NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
   exec(@SQL)
   set @SQL='ALTER TABLE #temp ADD Smltotal NUMERIC(25,8) NOT NULL DEFAULT 0 WITH VALUES  '
   exec(@SQL)
   /*set @SQLCc=@SQLC+','*/
  set @SQLC=@SQLC+',Sinqty,Sintotal,Soutqty,Souttotal,Smltotal'
  /* set @SQLC=@SQLC+@SQLoutqty+' as Soutqty'+','+@SQLouttotal+' as  Souttotal '+','+@Sml+' as  Smltotal '*/
  set @SQLCc=' update #temp set Sinqty='+@SQLinqty+',Sintotal='+@SQLintotal+',Soutqty='+@SQLoutqty
  set @SQLCc=@SQLCc+',Souttotal='+@SQLouttotal+',Smltotal='+@Sml
 /* select  @SQLCc*/
  exec(@SQLCc) 
 /* select * from #temp*/
  set @MSQL=@MSQL+',sum(Sinqty) as Sinqty,sum(Sintotal) as Sintotal,sum(Soutqty) as Soutqty,sum(Souttotal) as Souttotal,sum(Smltotal) as Smltotal'
  set @SQL=' insert into #temp(p_id'+@SQLC+')'
  set @SQL=@SQL+' select p_id'+@MSQL+' from #temp group by p_id'   
  /*+@SQLC*/
 /* select @SQL*/
  exec(@SQL)
  delete #temp where Atype='1'
 
  /*select * from #temp*/
 end   
 /*-返回数据*/
 declare @SQL1 varchar(8000) 
 if @SQLC<>''
 begin 
   /*set  @SQL='  select distinct  p_id'+@SQLC+' from #temp '*/
   /*兼容客户端基类，故重命名*/
   set @SQL='  select distinct  p_id Product_id'+@SQLC+' from #temp '
   set @SQL1=' select  a.serial_number as code,a.name,a.alias,a.standard,a.makearea,m.name as medtype,a.Custompro1,a.Custompro2,'
   set @SQL1=@SQL1+' a.Custompro3,a.Custompro4,a.Custompro5'
 /*  set @SQL1=' select  a.serial_number as 药品|编号,a.name as 药品|品名,a.standard as 药品|规格,a.makearea as 药品|产地,c.mt_name as 药品|类型 ,a.Custompro1 as 药品|Custompro1,a.Custompro2 as 药品|Custompro2,'*/
 /*  set @SQL1=@SQL1+' a.Custompro3 as 药品|Custompro3,a.Custompro4 as 药品|Custompro4,a.Custompro5 as 药品|Custompro5'*/
   set @SQL1=@SQL1+',b.*  from products a '
   /*set @SQL1=@SQL1+' inner join ( '+@SQL+' ) b'+' on a.product_id=b.P_ID '*/
   set @SQL1=@SQL1+' inner join ( '+@SQL+' ) b'+' on a.product_id=b.Product_id '
   set @SQL1=@SQL1+' left  join 
	  (
		select P_id as baseinfo_id,name from ProductCategory p  
		inner join customCategory c on p.PComent3 = c.class_id
		and c.deleted = 0 and Child_Number = 0 and Category_id = 3
	  )m on b.product_id = m.baseinfo_id   order by  a.pinyin'

    print  @SQL1
   exec(@SQL1)
 end
 else
 begin
   select  a.serial_number as code,a.name,a.alias,a.standard,a.makearea,c.mt_name as medtype,a.Custompro1,a.Custompro2,
   a.Custompro3,a.Custompro4,a.Custompro5
   from products a
   inner join #temp b    on a.product_id=b.P_ID
   left  join medtype c  on c.mt_id=a.medtype
 end 
 drop table #temp
 drop table #tempC
 drop table #t1

END
GO
