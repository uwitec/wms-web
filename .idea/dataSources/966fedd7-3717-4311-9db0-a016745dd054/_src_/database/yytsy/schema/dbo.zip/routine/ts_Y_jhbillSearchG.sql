
/******************************************
拣货单查询
作者：yanrui
创建日期 2012-12-13
********************************************/
CREATE PROCEDURE ts_Y_jhbillSearchG
(	
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间*/
	@billNO         varchar(50) = '', /*销售单编号*/
	@billtype       int = 254,        /*单据类型 254 拣货单*/
	@states         int = -1,        /*单据状态 -1全部,0完成2拣货,5复核*/
	@s_id           int = 0,         /*仓库ID*/
	@c_id           int = 0,         /*单位id*/
	@jhr_id         int = 0,         /*拣货人*/
	@fhr_id         int = 0         /*复核人*/
	
)
as
/*--初始化参数*/
/**/
/*单据状态*/
declare  @st1 int,@st2 int 
select @st1=@states,@st2=@st1
if @states=-1 select @st2=10
/*仓库ID*/
declare  @s_id1 int,@s_id2 int 
select @s_id1=@s_id,@s_id2=@s_id1
if @s_id1=0 select @s_id2=2147483647

declare @xs_no varchar(50)
set @xs_no='%'+@billNO+'%'
/*select @xs_no*/

begin
  select w.serialno,w.billnumber,w.billdate,w.c_name,w.ck_name,w.jsr,w.zdr,w.shr
  ,w.billstates,w.S_billid,w.billid,w.auditman,w.Y_ID,w.states,w.jhr,w.fhr,w.S_SN
  ,w.sendC_id,w.WholeQty,w.PartQty,w.note,w.printcount,w.locname,contact_personal,
  phone_number,address,quantity
  from 
  (
  select y.serialno,y.billnumber,isnull(CONVERT(varchar, ci.checkdate, 120), '') as billdate,y.c_name,y.ck_name,y.jsr,y.zdr,y.shr
  ,y.billstates,y.S_billid,y.billid,y.auditman
  ,y.Y_ID,y.states,isnull(e3.name,'') as jhr,isnull(e4.name,'') as fhr,isnull(e5.billnumber,'') as S_SN
  ,y.sendC_id,y.WholeQty,y.PartQty,isnull(y.note,'') as note,y.printcount,y.locname,contact_personal,phone_number,
  y.address,y.quantity
  from 
  (
  select '' as serialno,a.billnumber,a.billdate
  ,b.name as c_name,c.name as ck_name,e.name as jsr,e1.name as zdr,e2.name as shr,
  b.contact_personal,b.phone_number,b.address,
  (Case a.VIPCardID 
  when  1 then '拣货退回'
  when  2 then '拣货'
  when  3 then '拣货完成'
  when  4 then '复核退回' 
  when  5 then '复核'
  when  6 then '复核完成'
  when  0 then '完成'
  else 
    ''  
  end ) as billstates,a.order_id as S_billid,a.billid,a.auditman,a.Y_ID,a.VIPCardID as states
  ,a.integral,a.integralYE,a.sendC_id,a.WholeQty,a.PartQty,a.note,a.InvoiceNO,transcount as printcount
  ,a.B_CustomName3 as locname,a.quantity 
  from billdraftidx a,clients b,storages c,employees e,employees e1,employees e2  
  where a.billtype=@billtype and a.billdate>=@BeginDate and a.billdate<=@EndDate and a.InvoiceNO <> '' 
        and a.VIPCardID>=@st1 and a.VIPCardID<=@st2 
        and a.sout_id>=@s_id1 and a.sout_id<=@s_id2        
        and a.c_id=b.client_id 
        and a.sout_id=c.storage_id
        and a.e_id=e.emp_id
        and a.inputman=e1.emp_id
        and a.auditman=e2.emp_id
        and (a.c_id = @c_id or @c_id = 0)
        and ( integral  = @jhr_id or @jhr_id = 0) 
        and (integralYE = @fhr_id or @fhr_id = 0)
        
  ) y 
  left join  employees e3     on  y.integral    =e3.emp_id  
  left join  employees e4     on  y.integralYE  =e4.emp_id 
  inner join  
  (
    select  distinct a1.billnumber,a1.GUID
    from billidx a1,billdraftidx  a2  
    where a1.guid=a2.InvoiceNO  and  a2.billtype=254 and a2.InvoiceNO <> ''
    union 
    select  distinct b1.billnumber,b1.GUID
    from billdraftidx b1,billdraftidx  b2  
    where b1.guid=b2.InvoiceNO   and b2.billtype=254 and b2.InvoiceNO <> ''
  ) e5 
  on  e5.guid=y.InvoiceNO   
  left join (select * from checkidx where IsDraft = 1) ci on y.billid = ci.billid
  ) w
  where w.S_SN like @xs_no 
end
GO
