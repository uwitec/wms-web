CREATE FUNCTION GetPrice(@Y_ID int)
RETURNS
     @companyprice TABLE (
                            [p_id] [int] NOT NULL default(0),
							[u_id] [smallint] NOT NULL default(0),
							[retailprice] numeric(25,8) NOT NULL default(0),
							[recprice] numeric(25,8) NOT NULL default(0),
							[price1] numeric(25,8) NOT NULL default(0),
							[price2] numeric(25,8) NOT NULL default(0),
							[price3] numeric(25,8) NOT NULL default(0),
							[price4] numeric(25,8) NOT NULL default(0),
							[gpprice] numeric(25,8) NOT NULL default(0),
							[glprice] numeric(25,8) NOT NULL default(0),
							[specialprice] numeric(25,8) NOT NULL default(0),
							[unittype] [tinyint] NOT NULL default(0),
							[lowprice] numeric(25,8) NOT NULL default(0),							
							[lastprice] numeric(25,8) NOT NULL default(0)) 
AS  
begin
  
  
  declare @SWarajPrice int
  select @SWarajPrice = swarajPrice from company where company_id =@Y_ID
  
  if (@Y_ID = 2) or  (@SWarajPrice = 0)
    insert into @companyprice([p_id], [u_id],[retailprice], [recprice], [price1],
							  [price2],[price3],[price4],[gpprice],[glprice],
							  [specialprice],[unittype],[lowprice],[lastprice]) 
    select  [p_id], [u_id],[retailprice], [recprice], [price1],
			[price2],[price3],[price4],[gpprice],[glprice],
			[specialprice],[unittype],[lowprice],[lastprice]  from price
  else 
    if (@Y_ID <> 2) and  (@SWarajPrice = 1)
    begin
      insert into @companyprice([p_id], [u_id],[retailprice], [recprice], [price1],
							  [price2],[price3],[price4],[gpprice],[glprice],
							  [specialprice],[unittype],[lowprice],[lastprice]) 
      select  [p_id], [u_id],[retailprice], [recprice], [price1],
			  [price2],[price3],[price4],[gpprice],[glprice],
			 [specialprice],[unittype],[lowprice],[lastprice]  
	    from PosPrice   
	   where Y_ID =@Y_ID and ([retailprice] > 0 or [price1] > 0 or
							  [price2] > 0 or [price3] > 0 or [price4] >0 or 
							  [gpprice] > 0 or [glprice] >0 or [specialprice] > 0 
							  or [lowprice] >0)
							  
     insert into @companyprice([p_id], [u_id],[retailprice], [recprice], [price1],
							  [price2],[price3],[price4],[gpprice],[glprice],
							  [specialprice],[unittype],[lowprice],[lastprice]) 
      select  [p_id], [u_id],[retailprice], [recprice], [price1],
			  [price2],[price3],[price4],[gpprice],[glprice],
			 [specialprice],[unittype],[lowprice],[lastprice]  
	    from Price   
	   where p_id not in (select p_id from @companyprice)				        							  			 			     
    end            
  RETURN             
end
GO
