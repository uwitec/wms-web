





/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/



/*单据合并*/
CREATE proc ts_c_Meragebill
(
  @szBillid      varchar(2000),
  @szBilltype    varchar(10), /*源单据类型*/
	@nDestBilltype int,         /*目的单据类型*/
  @nE_id         int,         /*经手人*/
  @inputman      int,         /*制单人*/
  @nSFlag        int,         /*仓库合并方式     0 无条件合并 1  出货仓库相同合并 2 入货仓库相同合并 */
  @nSs_id        int,         /*无条件合并时指定的出货仓库id号    -1 转为源单据仓库 当@nSFlag=0时有效*/
  @nSd_id        int,         /*无条件合并时指定的入货仓库id号    -1 转为源单据仓库 当@nSFlag=0时有效*/
  @nCFlag        int,         /*往来单位合并方式 0 无条件合并 1 往来单位相同合并 */
  @nC_id         int,         /*为无条件合并时指定的单位id号  -2 转为源单据往来单位  当@nCFlag=0时有效*/
  @nBilldate     int,         /*日期合并方式     0 无条件合并 1 日期相同合并*/
  @szBilldate    varchar(10),  /*日期无条件合并时指定的日期*/
  @nKeepDraft    int,         /*是否保留源单据 0 否  1 是*/
  @nRet          int output   /*返回值*/
)
as
/*set nocount on*/
declare @billdate datetime ,@e_id int ,@ss_id int ,@sd_id int,@billtype int,@a_id int,@posid int,@c_id int,@Y_id int
declare @nNewBillId numeric(10,0),@szBillCode varchar(30)
declare @nCount int,@dtotalmoney NUMERIC(25,8),@dtotalqty NUMERIC(25,8),@dSsMoney NUMERIC(25,8),@SendQTY NUMERIC(25,8)
declare @dTaxRate numeric(5,2)
declare @newbillguid varchar(50)
declare @sql varchar(8000)
set @nret=-1

if OBJECT_ID('tempdb..##temptable1') is not null drop table ##temptable1
set @SendQTY=0
set @Y_id=0
select @Y_id=isnull(cast([sysvalue] as int),0) from sysconfig where upper([sysname])='Y_ID'

select @dTaxRate=0
exec ts_getsysvalue 'TaxRate',@dTaxRate out

  set @szbillcode= ''
  set @dtotalmoney=0
  set @dtotalqty=0
  set @dSsMoney=0 

/*转入到临时表*/

if @nDestBilltype not in (44,45) 
begin
  if @nDestBilltype in (10,11,12,13,16,17,110,111,112,32) 
    set @nSd_id=@nSs_id
  else
    set @nSs_id=@nSd_id
end
/*------//判断是否存在未退回的拣货单，存在则合并失败 add by luowei 2013-05-21*/
if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1')
begin
  declare @exesql varchar(8000)
  set @exesql = 'select i.*  from billdraftidx i where billid in '+ @szBillid + ' 
              and exists(select 1 from billdraftidx where order_id = i.billid and billtype = 254 and VIPCardID <> 1) '
  exec (@exesql)
  
  if @@rowcount > 0
  begin
    /*raiserror('合并单据失败，存在未退回的拣货单！',16,1)*/
    set @nRet = -199
    return -1
  end
end

/*采购类单据*/
if @szBilltype in ('20','21','24','25','120','121','122','35')
begin
  set @sql='
          select 
          b.billdate,b.c_id,b.a_id,b.Y_id,
			    s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,
                            s.validdate,s.ss_id,s.sd_id,isnull(p.unit1_id,0) unit1_id,s.taxrate,s.aoid,
                            s.instoretime,
                            MIN(s.price_id)                      as Price_id,
                            isnull(sum(b.Invoicetotal),0)        as Invoicetotal,
                            isnull(sum(b.ArAptotal),0)           as ArAptotal,
                            isnull(sum(b.jsInvoiceTotal),0)      as jsInvoiceTotal,
                            isnull(sum(b.jsye),0)                as jsye,
			    isnull(sum(s.quantity),0)		  as quantity,
			    isnull(sum(s.totalmoney),0)		as totalmoney,            --折后税前金额
			    isnull(sum(s.retailtotal),0)	as retailtotal,
			    isnull(sum(s.taxmoney),0)		  as taxmoney,
			    isnull(sum(s.taxtotal),0)		  as taxtotal,
			    isnull(sum(s.total),0)			  as total,     --折前金额
                            isnull(sum(s.SendQTY),0)              as SendQTY,
                            isnull(sum(S.SendCosttotal),0)        as SendCosttotal
			    into ##temptable1 from billdraftidx b right join buymanagebilldrf s 
			    on b.billid=s.bill_id
			    left join products p
			    on s.p_id=p.product_id
			    where b.billtype =' +@szbilltype+' and b.billid in ' + @szBillid + '
			    group by 
          b.billdate,b.c_id,b.a_id,b.Y_id,
          s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,s.validdate,s.ss_id,s.sd_id,p.unit1_id,s.taxrate,s.aoid, s.instoretime
           '
    /*print (@sql)*/
    exec (@sql)
end else
if @szBilltype in ('10','11','12','13','16','17','110','111','112','32')
begin
  set @sql='
          select 
          b.billdate,b.c_id,b.a_id,b.Y_id,
			    s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,
                            s.validdate,s.ss_id,s.sd_id,isnull(p.unit1_id,0) unit1_id,s.taxrate,s.aoid,
                            s.instoretime,
                            MIN(s.price_id)                      as Price_id,
                            isnull(sum(b.Invoicetotal),0)        as Invoicetotal,
                            isnull(sum(b.ArAptotal),0)           as ArAptotal,
                            isnull(sum(b.jsInvoiceTotal),0)      as jsInvoiceTotal,
                            isnull(sum(b.jsye),0)                as jsye,
			    isnull(sum(s.quantity),0)		  as quantity,
			    isnull(sum(s.totalmoney),0)		as totalmoney,            --折后税前金额
			    isnull(sum(s.retailtotal),0)	as retailtotal,
			    isnull(sum(s.taxmoney),0)		  as taxmoney,
			    isnull(sum(s.taxtotal),0)		  as taxtotal,
			    isnull(sum(s.total),0)		  as total,      --折前金额
                            isnull(sum(s.SendQTY),0)              as SendQTY,
                            isnull(sum(S.SendCosttotal),0)        as SendCosttotal
			    into ##temptable1 from billdraftidx b right join salemanagebilldrf s 
			    on b.billid=s.bill_id
			    left join products p
			    on s.p_id=p.product_id
			    where b.billtype =' +@szbilltype+' and b.billid in ' + @szBillid + ' 
			    group by 
          b.billdate,b.c_id,b.a_id,b.Y_id,
          s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,s.validdate,s.ss_id,s.sd_id,p.unit1_id,s.taxrate,s.aoid, s.instoretime
          '
    exec (@sql)
end else
if @szBilltype in ('30','31','33','34','40','41','42','43','44','45','46','47','48','49','51','141')
begin
  set @sql='
          select 
          b.billdate,b.c_id,b.a_id,b.Y_id,
			    s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,
                            s.validdate,s.ss_id,s.sd_id,isnull(p.unit1_id,0) unit1_id,0 as taxrate,s.aoid,
                            s.instoretime,
                            MIN(s.price_id)                      as Price_id,
                            isnull(sum(b.Invoicetotal),0)        as Invoicetotal,
                            isnull(sum(b.ArAptotal),0)           as ArAptotal,
                            isnull(sum(b.jsInvoiceTotal),0)      as jsInvoiceTotal,
                            isnull(sum(b.jsye),0)                as jsye,
			    isnull(sum(s.quantity),0)		  as quantity,
			    isnull(sum(s.totalmoney),0)		as totalmoney,            --折后税前金额
			    isnull(sum(s.retailmoney),0)	as retailtotal,
			    isnull(sum(s.totalmoney),0)	  as taxmoney,
			    isnull(sum(s.totalmoney),0)	  as taxtotal,
			    isnull(sum(s.total),0)		as total,        --折前金额
                            isnull(sum(s.SendQTY),0)              as SendQTY,
                            isnull(sum(S.SendCosttotal),0)        as SendCosttotal
			    into ##temptable1 from billdraftidx b right join storemanagebilldrf s 
			    on b.billid=s.bill_id
			    left join products p
			    on s.p_id=p.product_id
			    where b.billtype =' +@szbilltype+' and b.billid in ' + @szBillid + ' 
			    group by 
          b.billdate,b.c_id,b.a_id,b.Y_id,
          s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,s.validdate,s.ss_id,s.sd_id,p.unit1_id,s.aoid, s.instoretime
          '
    exec (@sql)
end else 
begin
  raiserror('此类单据不支持合并转换',16,1)
  return 0
end

if not exists (select * from ##temptable1) goto error1


/*转入到临时表*/

/*根据条件合并*/
begin
/*
  @nSFlag        int,         --仓库合并方式     0 无条件合并 1  出货仓库相同合并 2 入货仓库相同合并 
  @nSs_id        int,         --无条件合并时指定的出货仓库id号    -1 转为源单据仓库 当@nSFlag=0时有效
  @nSd_id        int,         --无条件合并时指定的入货仓库id号    -1 转为源单据仓库 当@nSFlag=0时有效
  @nCFlag        int,         --往来单位合并方式 0 无条件合并 1 往来单位相同合并 
  @nC_id         int,         --为无条件合并时指定的单位id号  -2 转为源单据往来单位  当@nCFlag=0时有效
  @nBilldate     int,         --日期合并方式     0 无条件合并 1 日期相同合并
  @szBilldate    varchar(10), --日期无条件合并时指定的日期
*/

  if @nDestBilltype not in (44,45)
  begin
    if @nSflag=0 
    begin  
      update ##temptable1 set ss_id=@nSs_id,sd_id=@nSs_id
    end
  end else
  begin
    if @nSflag=0 update ##temptable1 set ss_id=@nss_id,sd_id=@nsd_id
    else if @nSFlag =1 
    begin
      if @nSd_id<>-1 update ##temptable1 set sd_id=@nSd_id
    end 
    else if @nSFlag =2 
    begin
      if @nSd_id=-1 
      begin
        if @szbilltype not in ('44','45') and @nDestBilltype in (44,45)
          update ##temptable1 set sd_id=ss_id 
      end else update ##temptable1 set sd_id=@nsd_id
      if @nSs_id<>-1 update ##temptable1 set ss_id=@nSs_id
    end
  end
  if @nDestBilltype in (40,41,42,43,44,45,48,49,51) set @nc_id=0
  if @nDestBilltype in (14,22,26)
  begin
    update ##temptable1 set ss_id=0,sd_id=0
  end

  if @nCFlag=0  update ##temptable1 set c_id=@nC_id
  if @nBilldate=0  update ##temptable1 set billdate=@szBilldate


end
/*根据条件合并*/


/*生产单据*/

begin tran makenewbill

  select @nCount=1

  declare mergebill cursor for
  select distinct billdate,ss_id,sd_id,c_id,a_id
  from ##temptable1 
  order by billdate
 
  open mergebill

  fetch next from mergebill  into @billdate,@ss_id,@sd_id,@c_id,@a_id

  while @@fetch_status=0
  begin
    select 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,sd_id,unit1_id,taxrate,aoid,instoretime,
    MIN(price_id)                      as Price_id,
    isnull(sum(quantity),0)		  as quantity,
    isnull(sum(totalmoney),0)		as totalmoney,            /*折后税前金额*/
    isnull(sum(retailtotal),0)	as retailtotal,
    isnull(sum(taxmoney),0)		  as taxmoney,
    isnull(sum(taxtotal),0)		  as taxtotal,
    isnull(sum(total),0)		  as total,                  /*折前金额*/
    isnull(sum(SendQTY),0)              as SendQTY,
    isnull(sum(SendCosttotal),0)        as SendCosttotal
    into #temptable2 from ##temptable1 
    where billdate=@billdate and ss_id=@ss_id and sd_id=@sd_id and a_id=@a_id and c_id=@c_id
    group by 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,sd_id,unit1_id,taxrate,aoid,instoretime

    if not exists (select * from #temptable2) goto error

		select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
		from #temptable2
		where p_id>0/*不计算多帐户收款*/
    and aoid=0

    /*if @@rowcount=0 goto error*/
    
		select @szBillCode=dbo.Getbillnumber(@nDestBilltype)+'-'+convert(varchar(10),@billdate,21)+'-'+right(cast(10000+@nCount as varchar(5)),4)/*单据编号*/
   
    if @nDestBilltype in (44,45) select @c_id=isnull(c_id,0) from shop where s_id=@sd_id and deleted=0   

    if @nDestBilltype in (14,22,26)
    begin
  	  insert orderidx (billdate,billnumber,billtype,a_id,c_id,e_id,sin_id,sout_id,
  		auditman,inputman,ysmoney,ssmoney,quantity,taxrate,billstates,auditdate,skdate,Y_id)
  		values(@billdate,@szBillCode,@nDestBilltype,@a_id,@c_id,@nE_id,@sd_id,@ss_id,
  		0,@inputman,@dtotalmoney,0,@dtotalqty,@dTaxRate,'2',@billdate,@billdate,@Y_id )
    end else
    begin
  	  insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sin_id,sout_id,
  		auditman,inputman,ysmoney,ssmoney,quantity,taxrate,Period,billstates,auditdate,skdate,GUID,SendQTY,Y_ID,ZBAuditMan,ZBAuditDate)
  		values(@billdate,@szBillCode,@nDestBilltype,@a_id,@c_id,@nE_id,@sd_id,@ss_id,
  		0,@inputman,@dtotalmoney,0,@dtotalqty,@dTaxRate,0,'2',@billdate,@billdate,newid(),@SendQTY,@Y_id,0,'1900-01-01')
    end

    if @@rowcount=0 goto error

    set @nnewbillid=@@identity
    
    if @nDestBilltype in (20,21,24,25,120,121,122,35)
    begin
  		insert into buymanagebilldrf
  		(bill_id,p_id,batchno,quantity,costprice,buyprice,discount,discountprice,
  		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
  		 validdate,qualitystatus,ss_id,sd_id,location_id,supplier_id,commissionflag,
  		 taxrate,total,unitid,aoid,price_id,SendQTY,SendCosttotal,RowGuid,RowE_id,YGuid,Y_id,instoretime)
  		select @nnewbillid,p_id,batchno,quantity,costprice,case when aoid=0 then total/quantity else 0 end,case when (aoid=0 and total<>0) then totalmoney/total else 0 end,
      totalmoney/quantity, 
  		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
  		validdate,'合格',ss_id,0,location_id,supplier_id,commissionflag,
      taxrate,total,unit1_id,aoid,price_id,SendQTY,SendCosttotal,newid(),@nE_id,newid(),@Y_id,instoretime
  		from #temptable2 where p_id>0 
      if @@rowcount=0 goto error
    end else
    if @nDestBilltype in (10,11,12,13,16,17,110,111,112,32)
    begin
  		insert into salemanagebilldrf
  		(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
  		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
  		 validdate,qualitystatus,ss_id,sd_id,location_id,supplier_id,commissionflag,
  		 taxrate,total,unitid,aoid,price_id,SendQTY,SendCosttotal,RowGuid,RowE_id,YGuid,Y_id,instoretime)
  		select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity,case when (aoid=0 and total<>0)then totalmoney/total else 0 end,totalmoney/quantity, 
  		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
  		validdate,'合格',ss_id,0,location_id,supplier_id,commissionflag,
      taxrate,total,unit1_id,aoid,price_id,SendQTY,SendCosttotal,newid(),@nE_id,newid(),@Y_id,instoretime
  		from #temptable2 where p_id>0
      if @@rowcount=0 goto error
    end else
    if @nDestBilltype in (14,22,26)
    begin
  		insert into orderbill
  		(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
  		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
  		 validdate,qualitystatus,price_id,ss_id,sd_id,location_id,supplier_id,commissionflag,
  		 taxrate,total,unitid,Y_id, Instoretime)
  		select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity,case when (aoid=0 and total<>0) then totalmoney/total else 0 end,totalmoney/quantity, 
  		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
  		validdate,'合格',0,ss_id,0,location_id,supplier_id,commissionflag,
      taxrate,total,unit1_id,@Y_id, instoretime
  		from #temptable2 where p_id>0
      if @@rowcount=0 goto error
    end else
    if @nDestBilltype in (30,31,33,34,40,41,42,43,44,45,46,47,48,49,51,141)
    begin
  		insert into storemanagebilldrf
  		(bill_id,p_id,batchno,quantity,costprice,price,
  		 totalmoney,retailprice,retailmoney,makedate,
  		 validdate,qualitystatus,ss_id,sd_id,location_id,supplier_id,commissionflag,
  		 total,unitid,aoid,price_id,SendQTY,SendCosttotal,RowGuid,RowE_id,Y_id,instoretime)
  		select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity, 
  		totalmoney,retailtotal/quantity,retailtotal,makedate,
  		validdate,'合格',ss_id,sd_id,location_id,supplier_id,commissionflag,
      total,unit1_id,aoid,price_id,SendQTY,SendCosttotal,newid(),@nE_id,@Y_id,instoretime
  		from #temptable2 where p_id>0
      if @@rowcount=0 goto error
    end 

    drop table #temptable2
    select @nCount=@nCount+1
    fetch next from mergebill  into @billdate,@ss_id,@sd_id,@c_id,@a_id
 end

 if (@nKeepDraft =0 )        /*是否保留源单据 0 否  1 是*/
 begin
	set @sql=' delete billDraftidx where billid in ' + @szBillid 
	exec (@sql)
 end
 
 if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') /*启用拣货流程，删除退回的捡货单 add by luowei 2013-05-21*/
 begin
 
   set @sql = 'delete salemanagebilldrf where exists(select 1 from billDraftidx where billid = bill_id and billtype = 254 and order_id in '+@szBillid+')'
   exec (@sql)
   set @sql = 'delete billDraftidx where billtype = 254 and order_id in ' + @szBillid
   exec (@sql)
   
 end
 
 goto success


error1:
  set @nret=-1
  return -1

success:
  drop table ##temptable1
  close mergebill
  deallocate mergebill
  commit tran makenewbill
  set @nret=0
  return 0
error:
  close mergebill
  deallocate mergebill
  drop table ##temptable1
  rollback tran makenewbill
  set @nret=-1
	return -1
GO
