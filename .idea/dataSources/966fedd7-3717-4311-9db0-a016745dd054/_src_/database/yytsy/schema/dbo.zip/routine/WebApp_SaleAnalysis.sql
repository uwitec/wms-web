CREATE PROCEDURE WebApp_SaleAnalysis
(
 @dateMode int,--0昨天，1 近7天，2 近30天，3近90天
 @nMode INT, --0 价格带,1 供货商,2 生产厂家,3 门店,4 经手人,5 客户,6 建档日期,7 按日期,8 GSP属性,9 综合ABC,10 功能主治, 11 客户活动率
 @nY_id INT --机构ID/门店ID  (0 所有门店)
)
AS
SET NOCOUNT ON

IF @nY_id IS NULL SET @nY_id = 0

declare @BeginDate varchar(200),
        @EndDate varchar(200)


    SET @EndDate = CONVERT(VARCHAR(100), GETDATE(), 23)
	IF @dateMode = 0
	begin
		SET @BeginDate = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -1, GETDATE()) AS DATETIME), 23)
    end
	ELSE
	IF @dateMode = 1
	begin
		SET @BeginDate = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -7, GETDATE()) AS DATETIME), 23)
    end
	ELSE
	if @dateMode = 2
	begin
		SET @BeginDate = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -30, GETDATE()) AS DATETIME), 23)
    end 
	else if @dateMode = 3
	begin
	  SET @BeginDate = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -90, GETDATE()) AS DATETIME), 23)
	end
	
CREATE TABLE #SaleTmp
(
BillId INT,
BillType INT,                 /*单据类型*/
P_id INT,                     /*商品id*/
Qty  NUMERIC(25,8),           /*数量*/
Total NUMERIC(25,8),          /*金额(含税)*/
CostTotal NUMERIC(25,8),      /*成本金额(含税)*/ 
PriceBand VARCHAR(200),       /*价格带*/      
Supplier_id INT,              /*供应商id*/
Factoryc_id INT,              /*生产厂家id*/
Y_id        INT,              /*机构id*/
E_id        INT,              /*经手人id*/
C_id        INT,              /*往来单位id*/
InputDate   VARCHAR(200),     /*建档日期*/
BillDate    VARCHAR(200),     /*单据日期*/
GSPPropert  VARCHAR(200),     /*GSP属性*/
SyntheticalABC VARCHAR(200),  /*综合ABC分类(毛利)*/
FunIndication VARCHAR(200),   /*主治功能*/
--CActivityRate NUMERIC(25,2)   /*客户活动率*/
) 

CREATE TABLE #RetTable(
Total          NUMERIC(25,8), /*金额*/
CostTotal      NUMERIC(25,8), /*成本金额*/
BillSum        INT,           /*单据量*/
Ml             NUMERIC(25,8), /*毛利*/
Name           VARCHAR(200),  
TotalRate      NUMERIC(25,2), /*金额占比*/
CostTotalRate  NUMERIC(25,2), /*成本金额占比*/
MlRate         NUMERIC(25,2), /*毛利占比*/
BillRate       NUMERIC(25,2)  /*单据量占比*/
)

/*这里主要处理按门店分析可以多门店*/
CREATE TABLE #Companytable([id] INT)
IF @nY_id <> 0 
   INSERT INTO #Companytable ([id]) SELECT @nY_id
ELSE  
   INSERT INTO #Companytable ([id]) SELECT company_id FROM company where deleted = 0  

BEGIN
  IF @nMode NOT IN(0,1,2,3,4,5,6,7,8,9,10)
    Return 0

  INSERT INTO #SaleTmp(BillId,BillType,P_id,Qty,Total,CostTotal,Supplier_id,Factoryc_id,Y_id,E_id,C_id,InputDate,BillDate,GSPPropert)
  SELECT b.billid,b.billtype,s.p_id,
  CASE WHEN b.billtype IN (11,13) THEN -s.quantity ELSE s.quantity END,
  CASE WHEN b.billtype IN (11,13) THEN -s.taxtotal ELSE s.taxtotal END,
  CASE WHEN b.billtype IN (11,13) THEN -s.costtaxtotal ELSE s.costtaxtotal END,
  s.supplier_id,p.factoryc_id,b.Y_ID,s.RowE_id,b.c_id,CONVERT(VARCHAR(100), p.Inputdate, 23),CONVERT(VARCHAR(100), b.billdate, 23),p.gspPropert 
  FROM salemanagebill s 
  LEFT JOIN billidx b ON s.bill_id = b.billid
  LEFT JOIN vw_Products p ON s.p_id = p.product_id
  WHERE billtype IN (10,11,12,13) AND b.billstates = 0 AND p_id > 0
        AND b.Y_ID IN (SELECT ID FROM #Companytable) 
        AND billdate BETWEEN @BeginDate AND @EndDate 

  DECLARE @SzSql  VARCHAR(8000)
  DECLARE @INSSql VARCHAR(8000)
  DECLARE @SELSql VARCHAR(8000)
  DECLARE @GRPSql VARCHAR(8000)
  DECLARE @LETSql VARCHAR(8000)  
  
  SET @INSSql = ' INSERT INTO #RetTable(Total,CostTotal,BillSum,Ml,Name) ' 
  
  SET @SzSql = ' SELECT SUM(Total) AS Total,SUM(CostTotal) AS CostTotal,SUM(Total)-SUM(CostTotal) AS Ml,COUNT(DISTINCT BillId) AS BillSum, '

  IF @nMode = 0
    BEGIN
      UPDATE S SET S.PriceBand = ISNULL(P.PComent5,'') FROM #SaleTmp S LEFT JOIN ProductCategory P ON S.P_id = P.P_id
      SET @GRPSql = 'PriceBand '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.PriceBand FROM ('
      SET @LETSql = ''
    END 
      
  IF @nMode = 1
    BEGIN
      SET @GRPSql = 'Supplier_id '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,ISNULL(c.name,'''') AS Name FROM ('
      SET @LETSql = ' LEFT JOIN clients c ON s.Supplier_id = c.client_id'
    END 
       
  IF @nMode = 2
    BEGIN
      SET @GRPSql = 'Factoryc_id '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,ISNULL(c.AccountComment,'''') AS Name FROM ('
      SET @LETSql = ' LEFT JOIN BaseFactory c ON s.Factoryc_id = c.CommID'
    END
    
  IF @nMode = 3
    BEGIN
      SET @GRPSql = 'Y_id '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,ISNULL(c.name,'''') AS Name FROM ('
      SET @LETSql = ' LEFT JOIN company c ON s.Y_id = c.company_id'
    END 
        
  IF @nMode = 4
    BEGIN
      SET @GRPSql = 'E_id '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,ISNULL(c.name,'''') AS Name FROM ('
      SET @LETSql = ' LEFT JOIN employees c ON s.E_id = c.emp_id'     
    END   

  IF @nMode = 5
    BEGIN
        INSERT INTO #RetTable(Total,CostTotal,BillSum,Ml,Name)
        SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,ISNULL(c.name,'零售客户') AS Name FROM 
        ( 
        SELECT SUM(Total) AS Total,SUM(CostTotal) AS CostTotal,SUM(Total)-SUM(CostTotal) AS Ml,
        COUNT(DISTINCT BillId) AS BillSum, 0 as C_id FROM #SaleTmp
        WHERE BillType IN (12,13)
      UNION ALL
        SELECT SUM(Total) AS Total,SUM(CostTotal) AS CostTotal,SUM(Total)-SUM(CostTotal) AS Ml,
        COUNT(DISTINCT BillId) AS BillSum, C_id  FROM #SaleTmp
        WHERE BillType IN (10,11)
        GROUP BY C_id 
        ) S LEFT JOIN clients c ON s.C_id = c.client_id 
      GOTO SUCCEE    
    END   

  IF @nMode = 6
    BEGIN
      SET @GRPSql = 'InputDate '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.InputDate FROM ('
      SET @LETSql = ''     
    END 

  IF @nMode = 7
    BEGIN
      SET @GRPSql = 'BillDate '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.BillDate FROM ('
      SET @LETSql = ''     
    END 

  IF @nMode = 8
    BEGIN
      SET @GRPSql = 'GSPPropert '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.GSPPropert FROM ('
      SET @LETSql = ''    
    END 

  IF @nMode = 9
    BEGIN
      UPDATE S SET S.SyntheticalABC = ISNULL(P.PComent7,'') FROM #SaleTmp S LEFT JOIN ProductCategory P ON S.P_id = P.P_id
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.SyntheticalABC FROM ('
      SET @GRPSql = 'SyntheticalABC '
      SET @LETSql = ''
    END    
  
  IF @nMode = 10
    BEGIN
      DECLARE @ColName VARCHAR(200)
      DECLARE @ColSql  VARCHAR(8000)
      SELECT @ColName = ISNULL(ct.FieldName,'') FROM customCategory cc
             LEFT JOIN CategoryTemplate ct ON cc.Category_id = ct.Sx_id
             WHERE cc.class_id = '01' AND ct.BaseType = 1
      IF @ColName <> ''
      BEGIN
         SET @ColSql = ' UPDATE s SET FunIndication = ISNULL(cc.name,'''') FROM #SaleTmp s '
                     + ' LEFT JOIN products pr ON s.p_id = pr.product_id ' 
                     + ' LEFT JOIN ProductCategory pc ON pr.product_id = pc.P_id '
                     + ' LEFT JOIN customCategory cc ON cc.class_id = pc.'+@ColName
         EXEC (@ColSql)
      END 
                 
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.FunIndication FROM ('
      SET @GRPSql = 'FunIndication '
      SET @LETSql = ''
    END 
/*
  IF @nMode = 11
    BEGIN
      SET @GRPSql = 'CActivityRate '
      SET @SELSql = ' SELECT S.Total,S.CostTotal,S.BillSum,S.Ml,S.CActivityRate FROM ('
      SET @LETSql = ''      
    END 
*/
  SET @SzSql = @SzSql + @GRPSql + ' FROM #SaleTmp GROUP BY ' + @GRPSql +') S'

  SET @SzSql = @INSSql + @SELSql + @SzSql + @LETSql
             
  EXEC (@SzSql)


SUCCEE:
  DECLARE @SumTotal     NUMERIC(25,8)
  DECLARE @SumCostTotal NUMERIC(25,8)
  DECLARE @SumBill      NUMERIC(25,1)
  DECLARE @SumMl        NUMERIC(25,8)

  SELECT @SumTotal = SUM(Total),@SumCostTotal = SUM(CostTotal), @SumBill = SUM(BillSum), @SumMl = SUM(Ml) FROM #RetTable
    
  UPDATE #RetTable SET TotalRate = (Total/@SumTotal)*100, CostTotalRate = (CostTotal/@SumCostTotal)*100, MlRate = (Ml/@SumMl)*100, BillRate = (BillSum/@SumBill)*100 

  SELECT * FROM #RetTable
  
  DROP TABLE #SaleTmp
  DROP TABLE #RetTable
  
END
GO
