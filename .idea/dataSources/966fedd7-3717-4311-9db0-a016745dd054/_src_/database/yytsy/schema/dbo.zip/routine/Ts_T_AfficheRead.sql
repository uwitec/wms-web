
/******************************************
系统公告的已读操作
********************************************/
CREATE PROCEDURE [Ts_T_AfficheRead]
(    
  @AID       INT,  /*公告ID号，*/
  @EID       INT,
  @YID       INT,
  @ModifyDate DATETIME,
  @Flag      INT /*0: 置为已读；1：置为未读*/
)
AS
  SET NOCOUNT ON
  
  if @Flag = 0 
    INSERT INTO AfficheReadRec (ID, R_EID, R_YID, RDate) VALUES (@AID, @EID, @YID, @ModifyDate)
  else if @Flag = 1 
    Delete AfficheReadRec where ID = @AID and R_YID = @YID
  
  RETURN  0
GO
