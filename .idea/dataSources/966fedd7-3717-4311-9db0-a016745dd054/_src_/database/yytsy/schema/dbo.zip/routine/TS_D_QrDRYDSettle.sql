

CREATE procedure TS_D_QrDRYDSettle
@BeginDate	DATETIME,
@EndDate	DATETIME,
@DRDDNo     VARCHAR(30),   /*定点编号*/
@AKC300     VARCHAR(3),    /*人群类别 0所有 1职工 2居民 3离休*/
@y_id       INT,           /*机构id*/
@ybkind     INT,           /*医保类别 0异地 1本地*/
@AKC300Group INT           /*0不按人群类别分组 1按人群类别分组*/
AS  
  SET NOCOUNT ON 
  /*本地社保,0职工 1居民*/
  /*异地社保,1职工 2居民 3离休*/
  DECLARE @yb_y_name VARCHAR(200),@DDNo VARCHAR(20),@nPubYZYiBao INT 
  SELECT @yb_y_name='',@DDNo=''
  SELECT @nPubYZYiBao=sysvalue FROM sysconfigtmp WHERE sysname='yzshebao'

  SELECT a.Billid,a.TCAreaNo,ISNULL(c.TCAreaName,'') TCAreaName,ISNULL(b.AKC300,'-1') AKC300
         ,ISNULL(d.TCAreaName,'') yb_y_name,a.DRDDNo,a.InvoiceNo
         ,1 SettleCount,a.TCMoney,a.YBMoney,a.CashMoney 
         ,a.TCMoney+a.YBMoney+a.CashMoney SumMoney
  INTO #QrDRYDSettle
  FROM DRBillidx a LEFT JOIN DRYDEmpinfo b 
       ON a.TCAreaNo=b.YAB003 AND a.EmpNum=b.EmpNum
       LEFT JOIN billidx e
       ON a.billid=e.billid
       LEFT JOIN DRTCArea c 
       ON a.TCAreaNo=c.TCAreaNo AND c.Kind=0/*统筹区名称*/
       LEFT JOIN DRTCArea d 
       ON e.Y_ID=d.TCAreaNo AND d.Kind=1/*分支机构名称     */
  WHERE a.billdate>=@BeginDate AND a.billdate<@EndDate+1
        AND (@DRDDNo='' OR (@DRDDNo<>'' AND a.DRDDNo=@DRDDNo))
        AND (@AKC300='0' OR (@AKC300<>'0' AND b.DRbillid IS NOT NULL AND ISNUMERIC(b.AKC300)=1 
             AND (
             (@nPubYZYiBao=3 AND ((a.BATCHNO='' AND b.AKC300+1=@AKC300) OR (a.BATCHNO<>'' AND b.AKC300=@AKC300)))
             OR (@nPubYZYiBao IN (5,6) AND b.AKC300=@AKC300)             
             )))
        AND (@y_id=0 OR (@y_id<>0 AND e.Y_ID=@y_id))
        AND ((@ybkind=0 AND a.BATCHNO<>'') OR (@ybkind<>0 AND a.BATCHNO=''))
        AND a.Billstates=0 
        AND ((a.Billtype=12 AND a.SettleFlag='600') OR (a.Billtype=13 AND a.SettleFlag='601')) 
        
  /*一段时间内，同一人同一单，买药后又退货，不计算人次，这种情况共用一个billid和InvoiceNo     */
  UPDATE R SET 
  SettleCount=0
  FROM #QrDRYDSettle R INNER JOIN 
       (
         SELECT Billid
         FROM #QrDRYDSettle
         GROUP BY billid
         HAVING COUNT(1)>=2
       ) CI ON R.Billid=CI.Billid  
        
  IF @y_id>0
    SELECT TOP 1 @yb_y_name=yb_y_name,@DDNo=DRDDNo FROM #QrDRYDSettle

  IF @AKC300Group=0
  BEGIN 	 
	SELECT TCAreaNo,TCAreaName,'-1' AKC300,@yb_y_name yb_y_name,@DDNo DRDDNo  
		   ,SUM(SettleCount) InvCount
		   ,SUM(SettleCount) SettleCount
		   ,SUM(TCMoney) TCMoney
		   ,0.0 DBMoney
		   ,0.0 QtMoney
		   ,SUM(YBMoney) YBMoney
		   ,SUM(CashMoney) CashMoney 
		   ,SUM(SumMoney) SumMoney
		   ,0 InvCount_1
		   ,0.0 SettleCount_1
		   ,0.0 TCMoney_1
		   ,0.0 DBMoney_1
		   ,0.0 QtMoney_1
		   ,0.0 YBMoney_1
		   ,0.0 CashMoney_1
		   ,0.0 GWYMoney_1
		   ,0.0 SumMoney_1
		   ,SUM(SumMoney) AllMoney
	FROM #QrDRYDSettle
	GROUP BY TCAreaNo,TCAreaName
  END 
  ELSE 
  BEGIN	 
	SELECT TCAreaNo,TCAreaName,AKC300,@yb_y_name yb_y_name,@DDNo DRDDNo  
		   ,SUM(SettleCount) InvCount
		   ,SUM(SettleCount) SettleCount
		   ,SUM(TCMoney) TCMoney
		   ,0.0 DBMoney
		   ,0.0 QtMoney
		   ,SUM(YBMoney) YBMoney
		   ,SUM(CashMoney) CashMoney 
		   ,SUM(SumMoney) SumMoney
		   ,0 InvCount_1
		   ,0.0 SettleCount_1
		   ,0.0 TCMoney_1
		   ,0.0 DBMoney_1
		   ,0.0 QtMoney_1
		   ,0.0 YBMoney_1
		   ,0.0 CashMoney_1
		   ,0.0 GWYMoney_1
		   ,0.0 SumMoney_1
		   ,SUM(SumMoney) AllMoney
	FROM #QrDRYDSettle
	GROUP BY TCAreaNo,TCAreaName,AKC300
  END

  DROP TABLE #QrDRYDSettle
GO
