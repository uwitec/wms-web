/**************************************************************
app_yyt会员分析查询单击后执行的查询
**************************************************************/
create proc WebAPP_VIPSaleAnalyseDetail
(
  @Begin      DATETIME = 0,
  @End        DATETIME = 0,
  @chvparams  varchar(400) = '',
  @retmessage varchar(200) OUT
)
--$encode$--
as
BEGIN
	--DECLARE @a VARCHAR(200) EXEC WebAPP_VIPSaleAnalyseDetail;1 '2012-01-19', '2017-05-19', 'y_id=5',@a
	
	IF object_id(N'#BaseData', N'U') is not null
		Drop Table #BaseData
	
	CREATE TABLE #BaseData 
	(
		billid         INT NULL DEFAULT(0) ,
		billtype       INT NULL DEFAULT(0) ,
		y_id           INT NULL DEFAULT(0) , 
		VIPCardID      INT NULL DEFAULT(0) ,
		ysMoney        NUMERIC(18, 4) NULL DEFAULT('') ,
		VIPysMoney     NUMERIC(18, 4) NULL DEFAULT('')
	)
	
	SET @retmessage = '操作成功'

	DECLARE @YId INT --机构ID
	        
	SET @YId = dbo.webapp_get_param(@chvparams, 'y_id', default, default)
	
	INSERT INTO #BaseData(billid, billtype, y_id, VIPCardID, ysMoney, VIPysMoney)
	SELECT billid, billtype, y_id, VIPCardID, 
           CASE WHEN billtype = 12 THEN ysmoney ELSE -ysmoney END AS ysMoney,
           CASE WHEN VIPCardID > 0 THEN (CASE WHEN billtype = 12 THEN ysmoney ELSE -ysmoney END) ELSE 0 END AS VIPysMoney
		FROM billidx 
	WHERE billtype IN (12, 13) AND y_id = @YId AND billdate BETWEEN @Begin AND @End AND billstates = 0
	
	--返回的数据集	 
     
    SELECT d.ysMoney,												--销售金额
           d.VIPysMoney,											--会员销售金额
           ISNULL(f.KDRate, '0.00%') AS KDRate,						--会员客单占比
           d.JERate,												--会员金额占比
           ISNULL(f.VIPCount, 0) AS VIPCount,						--会员客单数
           ISNULL(f.VIPPrice, 0.00) AS VIPPrice,					--会员客单价
           ISNULL(g.VIPPCount, 0.00) AS VIPPCount,					--会员客品数       !
           d.VIPysMoney - ISNULL(g.VIPCostTotal, 0.00) AS VIPMl,	--会员客单毛利
           
           CASE WHEN ISNULL(g.VIPCostTotal, 0.00) = 0 THEN '0.00%' 
           ELSE 
			CAST(CAST(ROUND((d.VIPysMoney - ISNULL(g.VIPCostTotal, 0.00)) / (g.VIPCostTotal + 0.00), 2) AS NUMERIC(18, 2)) * 100 AS VARCHAR) + '%'           	
           END AS VIPMlRate,                                        --会员客单毛利率  
           ISNULL(e.CardCount, 0) AS NewCardCount                   --新增会员数
		FROM (
			SELECT y_id, 
				   SUM(ysMoney) AS ysMoney, 
				   SUM(VIPysMoney) AS VIPysMoney,
				   CASE WHEN SUM(ysMoney) = 0 THEN '0.00%' 
						ELSE CAST(CAST(ROUND(SUM(VIPysMoney) / SUM(ysMoney), 2) AS NUMERIC(18, 2)) * 100 AS VARCHAR) + '%' END AS JERate
			FROM #BaseData 
			GROUP BY y_id	
		) d 
		LEFT JOIN (
			SELECT a.y_id, COUNT(*) AS CardCount FROM (
				SELECT y_id, VIPCardID FROM #BaseData GROUP BY y_id, VIPCardID) a 
				INNER JOIN (
					SELECT v.VIPCardID FROM VIPCard v WHERE v.BulidDate BETWEEN @Begin AND @End	
				) b ON a.VIPCardID = b.VIPCardID
			GROUP BY a.y_id	
		) e ON d.y_id = e.y_id
		LEFT JOIN (
			SELECT @YId AS YId, SUM(CASE WHEN VIPCardID > 0 THEN 1 ELSE 0 END) AS VIPCount, 
			       COUNT(*) AS ALLCount,
			       CASE WHEN COUNT(*) = 0 THEN '0.00%' 
			       ELSE CAST(CAST(ROUND(SUM(CASE WHEN VIPCardID > 0 THEN 1 ELSE 0 END) / (COUNT(*) + 0.0), 2) AS NUMERIC(18, 2)) * 100 AS VARCHAR) + '%' END AS KDRate,
			       CASE WHEN SUM(CASE WHEN VIPCardID > 0 THEN 1 ELSE 0 END) = 0 THEN 0.00
			       ELSE CAST(ROUND(SUM(VIPysMoney) / (SUM(CASE WHEN VIPCardID > 0 THEN 1 ELSE 0 END) + 0.0) , 2) AS NUMERIC(18, 2)) END AS VIPPrice  
				FROM #BaseData 
		) f ON d.y_id = f.YId
		LEFT JOIN (
			SELECT @YId AS y_id, SUM(CASE WHEN a.billtype = 12 THEN s.costtaxtotal ELSE -s.costtaxtotal END) AS VIPCostTotal, COUNT(*) AS VIPPCount 
				FROM #BaseData a INNER JOIN salemanagebill s ON a.billid = s.bill_id 
			WHERE a.VIPCardID > 0 AND s.p_id > 0
		) g ON d.y_id = g.y_id
		--INNER JOIN company y ON d.y_id = y.company_id
    
	IF object_id(N'#BaseData', N'U') is not null
		Drop Table #BaseData	
		
	 
END
GO
