
/* =============================================*/
/* Author:		XXX*/
/* Create date: 2017-05-24 */
/* Description:	分配货位算法*/
/*  算法主要规则	

		如果表头没有选择仓库，则对本机构的所有仓库来自动分配，否则就按选择的仓库分配

1. 寻找相同批号的同一商品的存放位置，是否能存放，能存放优先
2. 按剂型、存放要求寻找能存放的区域，并找出历史存放过的可存放货位，可存放优先
3. 按剂型，存放要求寻找能存放的区域，找到可存放的空货位，按可剩余存放数量、可存放品规数排序，计算存放货位，自动分配多个货位
4. 当存放要求不能满足时，找到更难一级可存放的空货位，按可剩余存放数量、可存放品规数排序，计算存放货位，自动分配多个货位
5. 当存放要求不能满足时，找到更低一级可存放的空货位，按可剩余存放数量、可存放品规数排序，计算存放货位，自动分配多个货位
6. 自动计算货位时，需要注意：同一品种，不同批次不允许存放同一货位

7.冷链药品过滤冷链库     --

注意： 大前提是整货零货直接根据明细字段拆分行

传入需要分配货位的单据类型和id
*/
/* =============================================*/

CREATE PROCEDURE TS_X_AutoAssignLocation 
	@nMode int = 0,		/* 分配类型*/
	@billid int = 0,		/*单据id -- 选择的仓库id  */
	@billtype int = 0,		/* 单据类型*/
	@y_id int = 0,		/* 机构id*/
	@nRet int output		/* 返回值，成功返回0，失败返回-1，错误返回-2*/
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @nSmbId INT
	DECLARE @s_id INT /*仓库*/
	DECLARE @nNewBillID int 
	DECLARE @yGuid uniqueidentifier
	DECLARE @pid int
	DECLARE @r_id int
	DECLARE @Loc_id int
	DECLARE @Batchno varchar(100)
	DECLARE @WholeQty NUMERIC(25,8)
	DECLARE @PartQty NUMERIC(25,8)
	DECLARE @inQty NUMERIC(25,8)
	DECLARE @InceptQty NUMERIC(25,8)
	DECLARE @kQty NUMERIC(25,8)
	DECLARE @WholeRate int
	DECLARE @StoreCondition int
	DECLARE @nEid int
	DECLARE @FResultId_BillAudit INT
	DECLARE @FVchCode_BillAudit INT /*草稿自动过账使用*/
	DECLARE @nYId INT, @nTmpBillId INT
	DECLARE @detailCount INT
	DECLARE @bNestedFlag INT
	
	
	DECLARE @useRate NUMERIC(10,4)   /*用来控制货位的使用率*/
	set @useRate = 0.95   /*先默认为95%*/
	
/*	select top 1 @nYNDZ001=CAST(sysvalue as Int) from sysconfigtmp where [sysname] = 'yndz001'
	if 	@nYNDZ001 is null set @nYNDZ001 = 0		
*/
	SET @nRet = -1
	
	IF not exists(select 1 from gspbillidx where billtype = @billtype and gspbillid = @billid) 
	begin
		RAISERROR('待分配单据异常!', 16, 1)
		RETURN -1
	end 
	
	select @s_id = S_id,@nYId = isnull(Y_id,0) from gspbillidx where billtype = @billtype and gspbillid = @billid
	
	if @s_id is null set @s_id = 0  /*取表头仓库*/
	
	IF @@TRANCOUNT > 0
	BEGIN
		SET @bNestedFlag = 1
		SAVE TRAN CREATEBILL
	END
	ELSE
	BEGIN
		SET @bNestedFlag = 0
		BEGIN TRAN CREATEBILL
	END
	
	if exists (select 1 from gspbilldetail where Gspbill_id = @billid and P_id >0 )
	begin
		if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
			drop table #tmpDetail
		create table #tmpDetail
		 (
		  smbid     int,   /*对应的明细id*/
		  s_id		int,   /*仓库id*/
		  l_id      int,   /*货位id*/
		  r_id      int,   /*剂型id*/
		  qty     int,		/*-分配基本数量*/
		  fqty     int,		/*-分配数量*/
		  sflag    int		/*整，零货类型	*/
		 )

		DECLARE curArtoLoc CURSOR static 
		FOR		
		SELECT /*Gspbill_id,*/Gspsmb_id,P_id,Batchno,InceptQty,WHOLEQTY,PARTQTY,p.WholeRate,p.r_id,p.StoreCondition FROM gspbilldetail g,vw_Products p 
			where Gspbill_id = @billid and g.P_id = p.product_id  ORDER BY gspbill_id
		/*(CASE WHEN p.wholeUnit_id = p.unit2_id THEN rate2 WHEN p.wholeUnit_id = p.unit3_id THEN rate3 WHEN p.wholeUnit_id = p.unit4_id THEN rate4 ELSE 1 END) AS WholeRate*/
		
		OPEN curArtoLoc
		FETCH NEXT FROM curArtoLoc 
		INTO @nSmbId, @pid,@Batchno,@InceptQty, @WholeQty, @PartQty, @WholeRate, @r_id, @StoreCondition
		/*insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
		select top 1 GUID,@nFor,0,@nCur,GETDATE(),billnumber,billdate,'进入游标'  FROM billidx_dts   */ 	
		
		while @@fetch_status=0 
		BEGIN
		
			/*找出不能存放的货位（同品种，不同批次的货位）*/
			/*select location_id from storehouse where p_id = @pid and batchno = @Batchno   */
		
			/*临时表，存放仓库,货位可用的空间数量*/
			select a.s_id,a.loc_id,(isnull(a.Quantity,0) - isnull(y.quantity,0) - ISNULL(t.qty,0)) as kqty
			into #Ltmp from 	
				(select l.s_id,l.loc_id,m.Quantity from location l left join WMSMedtype m on l.loc_id = m.StoreQYHWID 	 
				where m.MedtypeID =@r_id and isnull(m.Flag,2) = 2 and l.deleted = 0) a	/*每一个货位总共可存放该商品剂型的数量*/
			left OUTER JOIN				
				(select s.s_id,s.location_id,SUM(quantity) as quantity				
				from storehouse s,vw_Products p 
				where s.p_id = p.product_id and s.Y_ID = @nYId and p.r_id = @r_id group by s_id,s.location_id,p.r_id ) y	/*计算当前货位状况,每一个仓库已存放该商品剂型的数量	*/
			on a.s_id = y.s_id and a.loc_id = y.location_id	
			left OUTER JOIN				
				(select gd.s_id,gd.Location_id,SUM(gd.EligibleQty) as quantity				
				from gspbillidx g,gspbilldetail gd,vw_Products p 
				where g.Gspbillid = gd.Gspbill_id and gd.P_id = p.product_id and g.BillType = 531 and g.BillStates <> 15 and g.Y_ID = @nYId and p.r_id = @r_id group by gd.S_id,gd.location_id,p.r_id ) gs	/*统计未完成的上架确认单	*/
			on a.s_id = y.s_id and a.loc_id = y.location_id	
			left OUTER JOIN 
				(select l_id,SUM(qty) as qty from #tmpDetail where r_id = @r_id
				 group by l_id	)t  /*还要减去该单已经占用的货位量*/
			on a.loc_id = t.l_id 
			where a.loc_id not in (select location_id from storehouse where p_id = @pid and batchno <> @Batchno)
				and (isnull(a.Quantity,0) - isnull(y.quantity,0)- ISNULL(t.qty,0)) > a.Quantity *@useRate	 /*这儿仓库货位使用率设置为95%， */
				
			/*select * from #Ltmp*/
		
			/*临时表，存放仓库可用的空间数量*/
			/*为了防止极端情况，一批货总量够放某个仓库，但是其中整货货位或则零货货位不够*/
			/*  1.仓库整货统计*/
			select a.s_id
			into #swtmp from 	
				(select l.s_id,sum(m.Quantity) as aQuantity from location l left join WMSMedtype m on l.loc_id = m.StoreQYHWID
						left join stockArea sa on l.sa_id = sa.sa_id
				where m.MedtypeID =@r_id and sa.SAType = 0 and l.deleted = 0  /*整货统计*/
					and isnull(m.Flag,2) = 2	
					and l.loc_id not in (select location_id from storehouse where p_id = @pid and batchno <> @Batchno) 
				group by l.s_id,m.MedtypeID) a	/*每一个仓库总共可存放该商品剂型的数量*/
			left OUTER JOIN				
				(select s.s_id,SUM(quantity) as quantity				
				from storehouse s,vw_Products p, location l, stockArea sa
				where s.p_id = p.product_id and s.Y_ID = @nYId and s.location_id = l.loc_id and l.sa_id = sa.sa_id and p.r_id = @r_id 
						and sa.SAType = 0   /*整货统计 */
						and l.loc_id not in (select location_id from storehouse where p_id = @pid and batchno <> @Batchno) 
				group by s.s_id,p.r_id ) y	/*计算当前货位状况,每一个仓库已存放该商品剂型的数量	*/
			on a.s_id = y.s_id	
			left OUTER JOIN 
				(select s_id,SUM(qty) as qty from #tmpDetail where r_id = @r_id and sflag = 0
				 group by s_id	)t  /*还要减去该单已经占用的货位量*/
			on a.s_id = t.s_id 
			where (isnull(a.aQuantity,0) - isnull(y.quantity,0) - ISNULL(t.qty,0))*@useRate > @WholeQty * @WholeRate		/*这儿仓库货位使用率设置为95% @InceptQty*/
			
			/*select * from #swtmp*/
			/*  2.仓库零货统计*/
			select a.s_id
			into #sptmp from 	
				(select l.s_id,sum(m.Quantity) as aQuantity from location l left join WMSMedtype m on l.loc_id = m.StoreQYHWID 
						left join stockArea sa on l.sa_id = sa.sa_id
				where m.MedtypeID =@r_id and sa.SAType = 1 and l.deleted = 0     /*零货统计	*/
				and isnull(m.Flag,2) = 2
					and l.loc_id not in (select location_id from storehouse where p_id = @pid and batchno <> @Batchno)
				group by l.s_id,m.MedtypeID) a	/*每一个仓库总共可存放该商品剂型的数量*/
			left OUTER JOIN				
				(select s.s_id,SUM(quantity) as quantity				
				from storehouse s,vw_Products p, location l, stockArea sa
				where s.p_id = p.product_id and s.Y_ID = @nYId and s.location_id = l.loc_id and l.sa_id = sa.sa_id and p.r_id = @r_id 
						and sa.SAType = 1   /*零货统计 */
						and l.loc_id not in (select location_id from storehouse where p_id = @pid and batchno <> @Batchno)
				group by s.s_id,p.r_id ) y	/*计算当前货位状况,每一个仓库已存放该商品剂型的数量	*/
			on a.s_id = y.s_id	
			left OUTER JOIN 
				(select s_id,SUM(qty) as qty from #tmpDetail where r_id = @r_id and sflag = 1
				 group by s_id	)t  /*还要减去该单已经占用的货位量*/
			on a.s_id = t.s_id 
			where (isnull(a.aQuantity,0) - isnull(y.quantity,0) - ISNULL(t.qty,0))*@useRate > @PartQty		/*这儿仓库货位使用率设置为95% ，@InceptQty*/
			
			/*select * from #sptmp*/
			/*
			---然后只需要取一个满足条件的仓库就行，这样就不需要循环 回滚仓库操作,
			--把对仓库的控制都放在这儿来，让代码简洁，可读性更强，更容易修改
			select top 1 @s_id = sw.s_id
			from #swtmp sw,#sptmp sp,storages s 
			where sw.s_id = sp.s_id and sw.s_id = s.storage_id 
				and (sw.s_id = @s_id or @s_id = 0)  --过滤选择的仓库
				and s.Y_ID = @nYId					--过滤机构
				and s.storeCondition = @StoreCondition  --严格控制温度条件
			*/	
			
			if @WholeQty > 0		/*先分配整货，再分配零货*/
			begin
				set @s_id = 0
				select top 1 @s_id = isnull(sw.s_id,0)
				from #swtmp sw,storages s 
				where  sw.s_id = s.storage_id 
					/*and (sw.s_id = @s_id or @s_id = 0)  --过滤选择的仓库*/
					and s.Y_ID = @nYId					/*过滤机构*/
					and s.storeCondition = @StoreCondition  /*严格控制温度条件*/
					and s.qualityFlag = 0 /*控制不合格仓库*/
					and s.WholeFlag <> 3 /*控制零售拆零仓库*/
					
				if @s_id <= 0 
				begin 
					goto ERRORA2  /*仓库没找到*/
				end
				
				/*先通过行商品找到所有满足条件的货位 */
				select 999 as level,L.loc_id,ISNULL(lt.kqty,0)* @useRate as kQty ,(l.stockpilePgNum -l.alreadyPgNum) as pgQty,l.PickEasy 
				into #Rtmp
				from location l left OUTER JOIN  WMSMedtype m on l.loc_id = m.StoreQYHWID 
					/*left join WMSRegion wr on l.Regionid = l.loc_id*/
					left join stockArea sa on l.sa_id = sa.sa_id
					left join #Ltmp lt on l.loc_id = lt.loc_id		/*取出可用的货位的可存放数量*/
					where isnull(Flag,2) = 2 and l.deleted = 0 and isnull(m.deleted,0) =0
						and isnull(m.MedtypeID,@r_id) = @r_id   /*过滤剂型*/
						/*and (l.s_id = @s_id or @s_id = 0)   --过滤仓库	*/
						and sa.SAType = 0   /*过滤整货库区*/
						and l.stockpilePgNum  > l.alreadyPgNum
						and l.s_id = @s_id
						/*and l.s_id in (select s_id from #swtmp)  --仓库可存放量需要大于本次采购数量*/
						/*and l.s_id in (select s_id from #sptmp)  --仓库可存放量需要大于本次采购数量*/
						/*and l.loc_id in (select loc_id from #Ltmp)   --取出可用的货位  */
						
				/*先找到当前存放货位是否还能够存放*/
				/*#Rtmp 表当前找到的货位都是满足条件的货位，然后开始存放，设置优先级别*/
				
				/*select * from #Rtmp*/
				
				declare @count int
				/*declare @PickEasy int */
				set @count = 0
				while @count < 5   /*难易程度的处理*/
				begin
					/*set @PickEasy = @count -1*/
					/*1.同批次的货位*/
					update #Rtmp set level = 1 + @count *100 where loc_id in (select location_id from storehouse where p_id = @pid and batchno = @Batchno and Y_ID = @nYId) and PickEasy = @count 
					/*2.同批次的历史货位*/
					update #Rtmp set level = 2 + @count *100 where loc_id in (select location_id from productdetail where p_id = @pid and batchno = @Batchno and Y_ID = @nYId) and PickEasy = @count  and level >= 100
					/*--3.其它条件
					update #Rtmp set level = 3 + @count *100 where loc_id in (select location_id from productdetail where p_id = @pid and batchno = @Batchno) and PickEasy = @count  and level >= 200
					*/	
					set @count = @count +1			
				end
				
				/*-根据设置好的优先级，在循环游标里面作综合排序*/
				DECLARE curWLoc CURSOR static 
				FOR
				select loc_id,kQty	/*,PickEasy */
				from #Rtmp order by level asc,kqty asc,pgQty asc
														
				OPEN curWLoc 
				FETCH NEXT FROM curWLoc INTO @Loc_id, @kQty		
				while @WholeQty > 0 AND @@FETCH_STATUS = 0 
				begin
					if @kQty  > @WholeQty * @WholeRate 
						set @inQty = @WholeQty    /*-分配一个货位就完成*/
					else
						set @inQty = floor(@kQty/@WholeRate)  /*往下继续分配*/
						
					insert into #tmpDetail(smbid,s_id,l_id,qty,fqty,sflag,r_id)
					select @nSmbId,@s_id,@Loc_id,@inQty *@WholeRate,@inQty ,0,@r_id	
						
					set @WholeQty = @WholeQty - @inQty
					FETCH NEXT FROM curWLoc INTO @Loc_id, @kQty	
				end
				
				CLOSE curWLoc
				DEALLOCATE curWLoc
				
			end
			
			if @WholeQty > 0 goto ERRORA1  /*整货货位不足*/
			
			if @PartQty > 0   /*分配零货									*/
			begin	
				set @s_id = 0
				select top 1 @s_id = isnull(sp.s_id,0)
				from #sptmp sp,storages s 
				where  sp.s_id = s.storage_id 
					/*and (sp.s_id = @s_id or @s_id = 0)  --过滤选择的仓库*/
					and s.Y_ID = @nYId					/*过滤机构*/
					and s.storeCondition = @StoreCondition  /*严格控制温度条件*/
					and s.qualityFlag = 0 /*控制不合格仓库*/
					and s.WholeFlag <> 3 /*控制零售拆零仓库*/
					
				if @s_id <= 0 
				begin 
					goto ERRORA2  /*仓库没找到*/
				end
			
			
				/*先通过行商品找到所有满足条件的货位 */
				select 999 as level,L.loc_id,ISNULL(lt.kqty,0)*@useRate as kQty ,(l.stockpilePgNum -l.alreadyPgNum) as pgQty,l.PickEasy 
				into #Rptmp
				from location l left OUTER JOIN  WMSMedtype m on l.loc_id = m.StoreQYHWID 
					/*left join WMSRegion wr on l.Regionid = l.loc_id*/
					left join stockArea sa on l.sa_id = sa.sa_id
					left join #Ltmp lt on l.loc_id = lt.loc_id		/*取出可用的货位的可存放数量*/
					where isnull(Flag,2) = 2 and l.deleted = 0 and isnull(m.deleted,0) =0
						and isnull(m.MedtypeID,@r_id) = @r_id   /*过滤剂型*/
						/*and (l.s_id = @s_id or @s_id = 0)   --过滤仓库	*/
						and sa.SAType = 1   /*过滤零货库区*/
						and l.stockpilePgNum  > l.alreadyPgNum
						and l.s_id = @s_id  /*仓库可存放量需要大于本次采购数量*/
						/*and l.loc_id in (select loc_id from #Ltmp)   --取出可用的货位  					*/
				/*先找到当前存放货位是否还能够存放*/
				/*#Rptmp 表当前找到的货位都是满足条件的货位，然后开始存放，设置优先级别		*/
				
				/*select * from #Rptmp		*/
				declare @PickEasy int 
				set @PickEasy = 0
				while @PickEasy < 5     /* 规则里面的嵌套循环*/
				begin
					/*1.同批次的货位*/
					update #Rptmp set level = 1 + @PickEasy *100 where loc_id in (select location_id from storehouse where p_id = @pid and batchno = @Batchno) and PickEasy = @PickEasy 
					/*2.同批次的历史货位*/
					update #Rptmp set level = 2 + @PickEasy *100 where loc_id in (select location_id from productdetail where p_id = @pid and batchno = @Batchno) and PickEasy = @PickEasy  and level >= 100
					/*--3.其它条件
					update #Rptmp set level = 3 + @@PickEasy *100 where loc_id in (select location_id from productdetail where p_id = @pid and batchno = @Batchno) and PickEasy = @PickEasy  and level >= 200
					*/
					set @PickEasy = @PickEasy +1			
				end
								
				/*-根据设置好的优先级，在循环游标里面作综合排序*/
				DECLARE curPLoc CURSOR static 
				FOR
				select loc_id,kQty	/*,PickEasy */
				from #Rptmp order by level asc,kqty asc,pgQty asc
														
				OPEN curPLoc 
				FETCH NEXT FROM curPLoc INTO @Loc_id, @kQty		
				while @PartQty > 0 AND @@FETCH_STATUS = 0 
				begin
					if @kQty > @PartQty 
						set @inQty = @PartQty    /*-分配一个货位就完成*/
					else
						set @inQty = floor(@kQty)  /*往下继续分配*/
						
					insert into #tmpDetail(smbid,s_id,l_id,qty,fqty,sflag,r_id)
					select @nSmbId,@s_id,@Loc_id,@inQty,@inQty,1,@r_id
						
					set @PartQty = @PartQty - @inQty
					FETCH NEXT FROM curPLoc INTO @Loc_id, @kQty	
				end
				
				CLOSE curPLoc
				DEALLOCATE curPLoc								
			end
			
			if @PartQty > 0 goto ERRORA1  /*零货货位不足*/
			
			if  OBJECT_ID('tempdb..#Ltmp') IS NOT NULL 
				drop table #Ltmp
	
			if  OBJECT_ID('tempdb..#swtmp') IS NOT NULL
				drop table #swtmp
			
			if  OBJECT_ID('tempdb..#sptmp') IS NOT NULL
				drop table #sptmp	
				
			if  OBJECT_ID('tempdb..#Rtmp') IS NOT NULL
				drop table #Rtmp
			
			if  OBJECT_ID('tempdb..#Rptmp') IS NOT NULL
				drop table #Rptmp		
			
			/*分配完成一行商品，循环下一行商品								    */
			FETCH NEXT FROM curArtoLoc INTO @nSmbId, @pid,@Batchno,@InceptQty, @WholeQty, @PartQty, @WholeRate, @r_id, @StoreCondition
		end
	end
	
	CLOSE curArtoLoc
	DEALLOCATE curArtoLoc
	
/*	select * from #tmpDetail*/
	/*-得到的#tmpDetail 表数据就是实际分配情况，然后生成上架确认单*/
	declare @NewbillType int 
	select @NewbillType = NextVch from VchFlow where VchType = @billtype
	if @billtype >500 and @NewbillType > 500
	begin
		DECLARE @szBillNumber varchar(200)
		DECLARE @dtBillDate datetime	/* 单据日期*/
		
		IF @NewBillType < 500
			SET @dtBillDate = CONVERT(VARCHAR(10), GETDATE(), 120)
		ELSE
			SET @dtBillDate = GETDATE()
	
		EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nYId
		INSERT INTO GSPbillidx 
					(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
					upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
					trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
					GUID,FollowNumber,TicketDate, BalanceMode,YE_ID,SendC_Id)
		SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, 
					CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 
					0, '1900-1-1', 0, '1900-1-1', 
					auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
					trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, s_id, TrafficTime, 
					NEWID(),FollowNumber,TicketDate, BalanceMode,YE_ID,SendC_Id
    	FROM      dbo.GSPbillidx
     	WHERE Gspbillid = @billid
	  
		SELECT @nNewBillID = @@IDENTITY
											
		IF @nNewBillID > 0
		BEGIN
			INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
					discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
					checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
					BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
					Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal,OldOrderQty,OldOrderUnit,
					OldOrderUnitId,OldOrderUnitRate,WholeQty,PartQty)
			SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, isnull(td.qty,0), isnull(td.qty,0), 0, isnull(td.qty,0), refuseqty, 
						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, price *isnull(td.qty,0) as total, 
						discount, DiscountPrice * isnull(td.qty,0) as discounttotal, TaxRate,price *TaxRate* isnull(td.qty,0) as taxmoney, taxprice *isnull(td.qty,0) as TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
						checkaccept, checkreport, returnreason, '', checkreason, td.s_id, td.l_id, supplier_id, instoretime, cansaleqty, 
						BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
						Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal,OldOrderQty,OldOrderUnit,
					    OldOrderUnitId,OldOrderUnitRate,
					    case td.sflag  when 0 then td.fqty else 0 end as WholeQty, case td.sflag  when 1 then td.fqty else 0 end  as PartQty
			FROM      dbo.GSPbilldetail gd
			left join #tmpDetail td on gd.Gspsmb_id = td.smbid
			WHERE Gspbill_id = @billid and td.qty > 0
			order by Gspsmb_id
			
			if @@ERROR > 0
				GOTO ERROR

			SET @nRet = @nNewBillID
			EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @billid, @billtype, 1, 0
			/*-更新表头仓库*/
			select top 1 @s_id = S_id from GSPbilldetail where Gspbill_id = @nNewBillID AND S_id > 0
			update GSPbillidx set S_id = @s_id  where Gspbillid = @nNewBillID 
			
			update GSPbillidx set detailcount = gd.dcount from (select Gspbill_id,COUNT(1) as dcount from gspbilldetail where Gspbill_id = @nNewBillID group by Gspbill_id ) gd 
						where GSPbillidx.Gspbillid = gd.Gspbill_id and GSPbillidx.Gspbillid = @nNewBillID
						
			UPDATE GSPbillidx SET PgQty = gd.PgQty from (select Gspbill_id,COUNT(1) as PgQty from 
				(select Gspbill_id,P_id as PgQty from GSPbilldetail group by Gspbill_id,P_id)t group by Gspbill_id
				) gd WHERE Gspbillid = @nNewBillID AND BillType = @NewBillType AND GSPbillidx.Gspbillid = gd.Gspbill_id 

			IF @billtype=541 AND @NewBillType=551 /*-写入检验报告*/
			begin
				exec  TS_Y_InsertCheckReport @nNewBillID
			end
			
			set @nRet = @nNewBillID

		END
		ELSE
			GOTO ERROR
	end	
	
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	
	if  OBJECT_ID('tempdb..#Ltmp') IS NOT NULL 
		drop table #Ltmp
	
	if  OBJECT_ID('tempdb..#swtmp') IS NOT NULL
		drop table #swtmp
	
	if  OBJECT_ID('tempdb..#sptmp') IS NOT NULL
		drop table #sptmp	
		
	if  OBJECT_ID('tempdb..#Rtmp') IS NOT NULL
		drop table #Rtmp
	
	if  OBJECT_ID('tempdb..#Rptmp') IS NOT NULL
		drop table #Rptmp		

	IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END
	RETURN @nRet

ERROR:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail

	RETURN -1

	
ERRORA1:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	CLOSE curArtoLoc
	DEALLOCATE curArtoLoc
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	RAISERROR('该剂型货位不足!',16,1)
	RETURN -1
	
ERRORA2:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	CLOSE curArtoLoc
	DEALLOCATE curArtoLoc
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	RAISERROR('没找到合适的仓库可存放!',16,1)
	RETURN -1
END
GO
