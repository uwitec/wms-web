CREATE proc WebApp_MessageOpreate
 (
   @intuserid  int,
   @e_id INT=0,
   @type INT=0,--0 查询单条信息标题 1 查询完整消息
   @mesid INT =0,--对应消息id
   @params VARCHAR(100), --预留接口
   @RetMessage varchar(200) out
 )
--$encode$--
as
 BEGIN
 	
 	DECLARE @id int,@lastdate DATETIME,@newdate DATETIME
 	IF @type=0 
 	BEGIN
 		SELECT @lastdate=messagedate FROM TeenySoftMaster.dbo.WebAPP_OAGetMessageVer WHERE e_id=@e_id;
 		SELECT TOP 1 @id=id,@newdate=[datetime] FROM TeenySoftMaster.dbo.WebAPP_OAMessage oa WHERE [datetime]>ISNULL(@lastdate,'1900-01-01') ORDER BY [datetime] DESC
 	    IF(@id>0)
 	    BEGIN
 	    	SELECT id,title,oa.body,oa.[datetime] AS createdate
 			FROM TeenySoftMaster.dbo.WebAPP_OAMessage oa WHERE [datetime]=@newdate
 			IF ISNULL(@lastdate,'')<>''
 				UPDATE TeenySoftMaster.dbo.WebAPP_OAGetMessageVer SET messagedate=@newdate WHERE e_id=@e_id; 
 			ELSE 
 				INSERT  TeenySoftMaster.dbo.WebAPP_OAGetMessageVer (e_id,messagedate) VALUES (@e_id,@newdate);   	
 	    END
 	    ELSE
 	    	BEGIN
 	    		SELECT -1 as id,'' AS title,'' AS body
 	    	END
 	END
 	IF @type=1
 	BEGIN
 		-- declare @MutilAudited int set @MutilAudited =-1
		 --exec ts_GetSysValue 'MutilAudited',@MutilAudited OUTPUT
		 
		 DECLARE @starttime VARCHAR(10),@endtime VARCHAR(10)
		 SET @starttime=convert(varchar(8),GETDATE(),20)+'01'
		 SET @endtime=convert(varchar(10),GETDATE(),20)
		 
		 SELECT @lastdate=messagedate FROM TeenySoftMaster.dbo.WebAPP_OAGetMessageVer WHERE e_id=@intuserid AND TYPE=1;
 		
 		CREATE TABLE #table
 		(
 			[id] [int] IDENTITY(1,1) NOT NULL,
 			[title] [varchar](60) NOT NULL,--标题
			[datetime] [datetime] NOT NULL,--时间
 		)
 		
 		INSERT INTO #table(title,[datetime]) 
		 SELECT TOP 1 a.billname AS title,a.builddate AS datetime FROM (
			select case when idx.billtype=14 then '销售订单' when idx.billtype=22 then '采购订单' else '' end as billname,
					o.billdate AS builddate
			FROM vw_c_orderidx idx
		   LEFT JOIN orderidx o ON o.billid=idx.billid
			WHERE idx.billtype IN (14,22)
			and convert(varchar(10),idx.billdate,20) between @starttime and @endtime
			--AND idx.guid IN (select billguid from vw_AuditBillDetail where e_id=0 and charindex(CAST(@intuserid AS varchar),empList)>0)
			UNION ALL
			SELECT case when idx.billtype=10 then '销售出库单' when  idx.billtype=20 then '采购入库单' when idx.billtype=21 then '采购退货单' when idx.billtype=11 then '销售退货单'else '' end as billname,
					b.billdate AS builddate
		   from VW_C_BillDraftIDX idx 
		   LEFT JOIN billdraftidx b ON b.billid=idx.billid
			 WHERE idx.billtype IN (10,20,21,11)
			 and convert(varchar(10),idx.billdate,20) between @starttime and @endtime
			--AND idx.guid IN (select billguid from vw_AuditBillDetail where e_id=0 and charindex(CAST(@intuserid AS varchar),empList)>0)
		 ) a ORDER BY a.builddate DESC
 		
 		SELECT @id=id,@newdate=[datetime] FROM #table WHERE [datetime]>ISNULL(@lastdate,'1900-01-01')
 		
 		IF(@id>0)
 	    BEGIN
 	    	SELECT [title],datetime FROM #table WHERE id=@id
 			IF ISNULL(@lastdate,'')<>''
 				UPDATE TeenySoftMaster.dbo.WebAPP_OAGetMessageVer SET messagedate=@newdate WHERE e_id=@intuserid AND TYPE=1; 
 			ELSE 
 				INSERT  TeenySoftMaster.dbo.WebAPP_OAGetMessageVer (e_id,messagedate,Type) VALUES (@intuserid,@newdate,1);   	
 	    END
 	    
 	    DROP TABLE #table
 	END
	RETURN 1;
 END
GO
