




























/*-----------------------
-取得单一或一类会计科目余额
*//*---------------------*/





CREATE	 PROCEDURE Ts_c_GetAccount
(	
	@nA_id int=0,/*帐户id*/
	@nC_id int=0,/*客户id*/
	@szPeriod  varchar(2)='',/*会计期*/
	@dTotal NUMERIC(25,8) output/*金额*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nA_id is null  SET @nA_id = 0
if @nC_id is null  SET @nC_id = 0
if @szPeriod is null  SET @szPeriod = ''
/*Params Ini end*/
set nocount on

/*------Some Account*/
	declare @Artotal_Id int,	/*9	『应收款合计』*/
		@Aptotal_Id int 	/*15	『应付帐款合计』*/
	select	@Artotal_Id=9		/*9	『应收款合计』*/
	select	@Aptotal_Id=15		/*15	『应付帐款合计』*/
/*----------------*/
	if @nA_id=@Aptotal_Id
	begin	
		if @szperiod='' /*-取当前应付余额*/
		begin
			select @dTotal=sum(aptotal) from Clients 
			where Client_id=@nC_Id and deleted=0 and child_number=0 
			if @dTotal is null select @dTotal=0
			return
		end else /*-取期初应付余额*/
		begin
			select @dTotal=sum(aptotal_ini) from Clients 
			where Client_id=@nC_Id and deleted=0 and child_number=0 
			if @dTotal is null select @dTotal=0
			return
		end
	end else if @nA_id=@ArTotal_ID
	begin	
		if @szperiod='' /*-取当前应收余额*/
		begin
			select @dTotal=sum(artotal) from Clients 
			where Client_id=@nC_Id and deleted=0 and child_number=0 
			if @dTotal is null select @dTotal=0
			return
		end else /*-取期初应收余额*/
		begin
			select @dTotal=sum(artotal_ini) from Clients 
			where Client_id=@nC_Id and deleted=0 and child_number=0 
			if @dTotal is null select @dTotal=0
			return
		end
	end else 
	begin
		if @szperiod='' /*-取当前余额*/
		begin
			select @dtotal=sum(cur_total) from account 
			where account_id=@nA_id and deleted=0 and child_number=0
			if @dtotal is null select @dtotal=0
			return
		end else /*-取期初余额*/
		begin
			select @dTotal=sum(ini_total) from account
			where account_id=@na_id and deleted=0 and child_number=0
			if @dtotal is null select @dtotal=0
			return
		end
	end
GO
