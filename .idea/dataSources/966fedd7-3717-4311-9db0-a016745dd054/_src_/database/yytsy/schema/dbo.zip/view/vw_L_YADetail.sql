

CREATE VIEW dbo.vw_L_YADetail
AS
  /*  --select * from dbo.vw_L_YADetail*/
  SELECT YA.* ,
  invoicetype=(
  case YA.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
  ISNULL(C.class_id,'')CClass_ID,ISNULL(C.[name],'')Cname,
  ISNULL(E.class_id,'')EClass_ID,ISNULL(E.[name],'')Ename,
  ISNULL(AE.class_id,'')Auditmanclass_id,ISNULL(AE.[name],'')Auditmanname,
  ISNULL(IE.class_id,'')Inputmanclass_id,ISNULL(IE.[name],'')Inputmanname,      
  ISNULL(D.[name],'')Departname,
  ISNULL(R.[name],'')Regionname,
  ISNULL(Y.class_id,'')Yclass_ID, ISNULL(Y.[name],'')Yname,
  ISNULL(a.class_id,'')AClass_id, ISNULL(A.[NAME],'')accountname

  FROM  dbo.YAccountDetail  YA
   INNER JOIN Account A	          ON A.Account_id=YA.A_ID
   LEFT OUTER JOIN  clients    c  ON YA.C_id=c.client_id
   LEFT OUTER JOIN  employees  E  ON YA.e_id=E.emp_id
   LEFT OUTER JOIN  employees  AE ON YA.auditman=AE.emp_id
   LEFT OUTER JOIN  employees  IE ON YA.inputman=IE.emp_id
   LEFT OUTER JOIN  department D  ON YA.department_id=D.departmentId
   LEFT OUTER JOIN  Region     R  ON YA.region_id=R.region_id
   LEFT OUTER JOIN  Company    Y  ON YA.Y_id=Y.company_id
GO
