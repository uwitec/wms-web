
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<收银缴款统计报表>*/
/* =============================================*/
CREATE PROCEDURE TS_Y_RepCashPaySure 
 @beginDate    varchar(30) = '',
 @endDate      varchar(30) = '',
 @SaleMan      varchar(30) = '',
 @nloginEID    int=0,
 @Y_id  varchar(30) = ''
AS
BEGIN

  DECLARE @SQLScript   VARCHAR(8000)
  DECLARE @BankClassID      VARCHAR(300)
  DECLARE @BankName         VARCHAR(300)
  DECLARE @FieldName        VARCHAR(80) 
  DECLARE @FieldNameHead    VARCHAR(30)
  DECLARE @FieldNameCounter INT
  DECLARE @SQL	     VARCHAR(8000)

  
   
 set @endDate= @endDate+' 23:59:59'
/*初始化变量*/
SELECT @SQLScript = '',@SQL = ''
/*使用银行名字作为字段名，会因为名字中存在非法字符或名字过长出错*/


SELECT @FieldNameHead = 'FIELD_NAME',@FieldNameCounter = 1
SELECT @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
/*游标取得银行帐户的动态Sql*/
DECLARE BankSubject_cursor CURSOR FOR
SELECT  name,class_id
FROM    vw_Account
WHERE 	class_id Like '000001000004%' or class_id='000002000006' or class_id='000004000003000008' or class_id='000001000012' or class_id='000001000013' and Child_number = 0
ORDER BY [Class_ID] DESC  

OPEN BankSubject_cursor

FETCH NEXT FROM BankSubject_cursor
INTO @BankName,@BankClassID

WHILE @@FETCH_STATUS = 0 
BEGIN
    SET @FieldNameCounter = @FieldNameCounter + 1
	SET @BankName = REPLACE(@BankName,' ','')/*去除名字中的空格字符*/
	SET @SQL = @SQL + 'ISNULL(SUM(CASE WHEN (rb.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
                            ') AND (rb.BILLTYPE = 12) THEN rb.JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'

	SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
	FETCH NEXT FROM BankSubject_cursor
	INTO @BankName,@BankClassID
END

CLOSE BankSubject_cursor
DEALLOCATE BankSubject_cursor 
/*游标取得银行帐户的动态Sql END*/

set @SQLScript='select c.Y_id, isnull(p.name,'''') as yname,c.StartDate,c.EndDate,c.TotalTime,c.kdsl,c.YJCash,c.SJCash,
               (c.SJCash-c.YJCash)AS CashPayOff ,isnull(m.name,'''') as auditman, '
SET @SQLScript = @SQLScript+ @SQL + 
   ' isnull(e.name,'''' ) as chamberlain , '
  +' c.saletotal as SaleMoney,c.yhtotal as DiscountMoney ,c.suretime'
  +' from ChangeDutys as c '
  +'left join company as p on c.Y_id=p.company_id '
  +'left join employees as m on m.emp_id=c.auditman '
  +'LEFT JOIN VW_EMPLOYEE as e  on e.emp_id=c.e_id '
  /*+'LEFT JOIN  dutybill as d on d.dutyid=c.id '*/
  +'  left join (select dt.dutyid,x.y_id, x.billid,i.billdate,x.ACLASS_ID,x.jdmoney,(i.ysmoney-i.ssmoney) as yhmoney,i.billtype,'
  +'i.ysmoney from dutybill as dt left join VW_X_ADetail x  on dt.bill_id=x.billid left join billidx as i on i.billid=x.billid '
  +' where x.billid in (select bill_id from dutybill ) ) as rb on rb.dutyid=c.id and rb.y_id=c.y_id '
  +' where c.startdate between '''+@beginDate +''' and '''+@endDate+''' and (('''+@SaleMan +'''=0) or(c.e_id='''+@SaleMan +'''))'+
  '  and (('''+@Y_id+'''=0)or (c.y_id='''+@Y_id+''')) group by c.y_id,'
  +'p.name,c.StartDate,c.EndDate,c.TotalTime,c.kdsl,c.YJCash,c.SJCash,m.name,e.name,c.saletotal,c.yhtotal,c.suretime order by c.startdate' 
EXEC (@SQLScript)
END
GO
