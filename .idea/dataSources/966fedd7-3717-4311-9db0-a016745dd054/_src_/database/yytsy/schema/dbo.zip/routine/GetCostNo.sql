







create FUNCTION GetCostNo(@nPId int)  
RETURNS  int
AS  
BEGIN 
	declare @nCostNo int
	select @nCostNo=costmethod from products where product_id=@nPid
	return(@nCostNo)
END
GO
