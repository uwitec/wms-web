  
CREATE PROCEDURE ts_g_Replace
(
  @TableName VARCHAR(50),
  @FieldType VARCHAR(1000),
  @OldValue VARCHAR(100),
  @NewValue	VARCHAR(100)
)
AS
BEGIN
  DECLARE @FieldName VARCHAR(50) SET @FieldName=''
  DECLARE @i INT SET @i=0 
  DECLARE @count INT SET @count = 0
  DECLARE @SQl VARCHAR (8000) SET @SQl=''
  DECLARE @OldName VARCHAR (50) SET @OldName=''
  
  DECLARE MyCur SCROLL CURSOR FOR
    select Name from dbo.syscolumns 
     where object_name(id) IN (@TableName)
       and xtype IN (@FieldType) 
    ORDER BY id
  OPEN MyCur  
  SET @count = @@CURSOR_ROWS
  if @count <> 0
    SET @SQl = @SQl + 'update ' + @TableName + ' set '
  
  WHILE @i < @count
  BEGIN
    FETCH NEXT FROM MyCur INTO @FieldName
    set @SQl = @SQl + @FieldName + '=REPLACE(REPLACE(replace(' + @FieldName + ',CHAR(9),''''),CHAR(10),''''),CHAR(13),''''),'
    set @i=@i + 1
  END
  DEALLOCATE MyCur
  
  IF @SQl <> ''
  BEGIN
    SET @SQl = SUBSTRING(@SQl,1,LEN(@SQl)-1)

	declare @sConv varchar(50)
	SET @sConv = 'RE_' + @TableName

	DECLARE @MD BIGINT
	DECLARE @MDFIELD VARCHAR(300)
	SET @MDFIELD = ''
	SELECT @MDFIELD = name FROM SYSCOLUMNS WHERE ID = OBJECT_ID(@TableName) AND xtype = 189
	IF @MDFIELD <> ''
	BEGIN
		SET @MD = 0
		SELECT @MD = CAST(Up_Value AS bigint) FROM tsUpgradeInfo WHERE UP_NAME = @sConv
		SET @SQl = @SQl + ' WHERE ' + @MDFIELD + ' > ' + CAST(@MD AS VARCHAR(50))
	END

    /*print @SQL*/
    exec(@SQL)

	IF @MDFIELD <> ''
	BEGIN
		SET @SQl = 'UPDATE tsUpgradeInfo SET Up_Value = (SELECT CAST(ISNULL(CAST(MAX(' + @MDFIELD + ') AS BIGINT), 0) AS VARCHAR(50)) FROM ' + @TableName + ') WHERE UP_NAME = ''' + @sConv + ''''
			+ ' IF @@ROWCOUNT <= 0 '
			+ ' INSERT INTO tsUpgradeInfo(UP_NAME, Up_Value)'
			+ ' SELECT ''' + @sConv + ''', CAST(ISNULL(CAST(MAX(' + @MDFIELD + ') AS BIGINT), 0) AS VARCHAR(50)) FROM ' + @TableName
		/*print @SQL*/
		EXEC(@SQL)
	END
  END	
	
	
END
GO
