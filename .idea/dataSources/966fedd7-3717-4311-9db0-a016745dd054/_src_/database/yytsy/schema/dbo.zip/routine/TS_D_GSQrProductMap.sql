
create procedure TS_D_GSQrProductMap
@ProductState   INT=0,  /*0未对照 1已对照未上传 2已对照已上传 3所有*/
@MedType VARCHAR(50)='',
@PName    VARCHAR(100)='库',
@GSDDNo VARCHAR(30)='' /*定点编号*/
as 
  SET NOCOUNT ON 
  
  SELECT a.serial_number serial_number_Y,a.name name_Y,a.alias alias_Y,a.standard standard_Y
         ,a.pinyin pinyin_Y,a.MedName MedName_Y,a.product_id p_id_Y
         ,b.GSSFLB,b.IsUp
         ,c.*
  FROM vw_Products a LEFT JOIN GSProductMap b 
       ON a.product_id=b.p_id AND b.GSDDNo=@GSDDNo AND b.IsDel=0
       LEFT JOIN GSProducts c 
       ON b.GSP_id=c.GSP_id
  WHERE a.deleted=0 AND a.child_number=0
        AND ((@ProductState=0 AND b.GSP_id IS NULL) 
              OR (@ProductState=1 AND b.GSP_id IS NOT NULL AND b.IsUp=0) 
              OR (@ProductState=2 AND b.GSP_id IS NOT NULL AND b.IsUp=1) 
              OR @ProductState=3)
        AND (@MedType='' OR a.MedName=@MedType)
        AND (@PName='' OR a.serial_number like '%'+@PName+'%' or a.name like '%'+@PName+'%' or a.pinyin like '%'+@PName+'%')
GO
