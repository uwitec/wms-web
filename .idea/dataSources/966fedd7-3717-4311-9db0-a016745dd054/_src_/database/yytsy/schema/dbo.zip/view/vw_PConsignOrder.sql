/*---委托书商品期限    ConsignType  1:客户委托书 2：采购委托书*/
CREATE VIEW vw_PConsignOrder
AS
  select a.C_ID,a.ConsignID,a.ConsignType,b.P_ID,a.BeginDate,a.EndDate 
  from  ConsignOrder a,ConsignOrderDetail b,clients c
  where a.C_ID=c.client_id and a.ConsignID=b.ConsignID
GO
