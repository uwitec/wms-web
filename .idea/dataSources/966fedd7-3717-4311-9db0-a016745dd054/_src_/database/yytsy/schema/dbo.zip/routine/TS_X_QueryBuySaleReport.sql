


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/****************************************
一个补充的存储过程，可用于查询各种单位下销售的数量
请先在SQL的查询分析品中执行一次，记得首先要选择帐套的名称
然后就可以通过SQL的查询分析器或药易通中的查询分析器执行

参数说明
@BeginDate           开始的时间 （请输入如下的格式: '2004-01-01'）
@EndDate             结束的时间 （请输入如下的格式: '2004-12-31'）
@szListFlag 	       分级显示参数（分级显示：'L'；部分显示：'P'；全部显示：'A'）
@lVchtype  		       单据类型（0：所有单据
                              10：销售单
                              11：销售退货单
                              12：零售单
                              13：零售退货单
                              53：配送出库单
                              54：配送出库退货单
                              112：委托代销结算单  ）

@szCClass_Name       单位的全名 （请输入如下的格式: '成都天力卓越软件公司'；如果不想使用这个条件，请输入''）
@szEClass_Name       职员的全名 （请输入如下的格式: '曾川'；如果不想使用这个条件，请输入''）
@szSClass_Name       仓库的全名 （请输入如下的格式: '主仓库'；如果不想使用这个条件，请输入''）
@szZdClass_Name      制单人的全名 （请输入如下的格式: '管理员'；如果不想使用这个条件，请输入''）
@szPar_Name          商品的全名（如果想查询所有的商品：请输入''；如果是希望查询某一类，请输入这一类商品父结点的全名）

****************************************/
CREATE  PROCEDURE TS_X_QueryBuySaleReport
(	@BeginDate      DATETIME,
	@EndDate		    DATETIME,
	@szListFlag 	  VARCHAR(1)='L',
	@lVchtype  		  INT=0,
	@szCClass_Name	VARCHAR(80)='',
	@szEClass_Name  VARCHAR(80)='',
	@szSClass_Name  VARCHAR(80)='',
	@szZdClass_Name VARCHAR(80)='',
	@szPar_Name		  VARCHAR(30)='000000'
)

/*with encryption*/
AS
/*Params Ini begin*/
if @szListFlag is null  SET @szListFlag = 'L'
if @lVchtype is null  SET @lVchtype = 0
if @szCClass_Name is null  SET @szCClass_Name = ''
if @szEClass_Name is null  SET @szEClass_Name = ''
if @szSClass_Name is null  SET @szSClass_Name = ''
if @szZdClass_Name is null  SET @szZdClass_Name = ''
if @szPar_Name is null  SET @szPar_Name = '000000'
/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000),	
    @szCClass_ID	VARCHAR(30), @szEClass_ID	VARCHAR(30), @szSClass_ID	VARCHAR(30), 
    @szZdClass_ID VARCHAR(30), @szVchType VARCHAR(50), @szParID VARCHAR(30)

  IF exists (SELECT * FROM dbo.sysobjects WHERE ID = object_id(N'[dbo].[##mytempdb]') 
    AND OBJECTPROPERTY(ID, N'IsUserTABLE') = 1)
  DROP TABLE [dbo].[##mytempdb]

/*生成单位条件*/
	IF @szCClass_Name	<>'' SELECT @szCClass_ID=[Class_ID] FROM Clients WHERE [name]=@szCClass_Name
  ELSE SELECT @szCClass_ID=''

/*生成职员条件*/
	IF @szEClass_Name	<>'' SELECT @szEClass_ID=[Class_ID] FROM Employees WHERE [name]=@szEClass_Name
  ELSE SELECT @szEClass_ID=''

/*生成仓库条件*/
	IF @szSClass_Name	<>'' SELECT @szSClass_ID=[Class_ID] FROM Storages WHERE [name]=@szSClass_Name
  ELSE SELECT @szSClass_ID=''

/*生成制单人条件*/
	IF @szZdClass_Name	<>'' SELECT @szZdClass_ID=[Class_ID] FROM Employees WHERE [name]=@szZdClass_Name
  ELSE SELECT @szZdClass_ID=''

/*生成商品全名*/
	IF @szPar_Name	<>'' SELECT @szParID=[Class_ID] FROM Products WHERE [name]=@szPar_Name
  ELSE SELECT @szParID='000000'

/*生成单据条件*/
  IF @lVchtype=0 SELECT @szVchType='(10,11,12,13,112,53,54)'
  ELSE SELECT @szVchType='('+CAST(@lVchtype AS VARCHAR)+')'
  
/*销售,销售退货,零售,零售退货,委托代销结算*/
 	SELECT @SQLScript='SELECT * INTO ##mytempdb FROM (SELECT dbo.products.class_id,
	  ISNULL(SUM(CASE WHEN b.billtype IN (10,12,112,53) THEN a.quantity else -a.quantity end), 0) AS quantity, 
		ISNULL(SUM(CASE WHEN b.billtype IN (10,12,112,53) THEN a.costprice*a.quantity else -(a.costprice*a.quantity) end), 0) AS costtotal,
		ISNULL(SUM(CASE WHEN b.billtype IN (10,12,112,53) THEN a.taxtotal else -a.taxtotal end), 0) AS taxtotal,
		ISNULL(SUM(CASE WHEN b.billtype IN (10,12,112,53) THEN a.retailtotal else -a.retailtotal end), 0) AS retailtotal
		FROM VW_C_SaleMb a INNER JOIN
		dbo.products ON a.p_id = dbo.products.product_id
		LEFT JOIN vw_c_billidx b on b.billid=a.bill_id
		WHERE dbo.products.deleted<>1  AND b.billdate between '
      +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' AND '
      +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+
		' AND b.billtype IN '+@szVchType+' AND b.billstates=''0'''

 	IF @szCClass_ID<>'' 	SET @SQLScript=@SQLScript+' AND  LEFT(b.cclass_ID,LEN('
    +CHAR(39)+@szCClass_id+CHAR(39)+'))='+CHAR(39)+@szCClass_id+CHAR(39)
 	IF @szEClass_ID<>'' 	SET @SQLScript=@SQLScript+' AND  LEFT(b.eclass_ID,LEN('
    +CHAR(39)+@szEClass_id+CHAR(39)+'))='+CHAR(39)+@szEClass_id+CHAR(39)
 	IF @szSClass_ID<>''	SET @SQLScript=@SQLScript+' AND  LEFT(a.ssclass_ID,LEN('
    +CHAR(39)+@szSClass_id+CHAR(39)+'))='+CHAR(39)+@szSClass_id+CHAR(39)
 	IF @szZdClass_ID<>''	SET @SQLScript=@SQLScript+' AND  LEFT(b.inputmanclass_ID,LEN('
    +CHAR(39)+@szZdClass_id+CHAR(39)+'))='+CHAR(39)+@szZdClass_id+CHAR(39)
 	SET @SQLScript=@SQLScript+' GROUP BY dbo.products.class_id) AS t' 
 	EXEC(@SQLScript)

  IF @szListFlag='L'  GOTO ListLeavel
  IF @szListFlag='A' 	GOTO ListAll
  IF @szListFlag='P' 	GOTO ListPart

ListLeavel:
	SELECT a.product_ID AS [ID], a.[Class_ID] AS [Class_ID], a.[child_number] AS [结点儿子数], 
    a.[name] AS [全名], a.[serial_number] AS [编号], a.[Alias] AS [通用名], a.[Standard] AS [规格], a.[modal] AS [型号],
    a.[makearea] AS [产地], a.[medtype] AS [剂型], 
    (SELECT [name] FROM Unit WHERE [unit_id]=a.[unit1_id]) AS [单位一],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit2_id]), '') AS [单位二],
    ISNULL(SUM(CASE [rate2] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate2] END), 0) AS [单位二数量],
    a.[rate2] AS [单位关系二], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit3_id]), '')AS [单位三],
    ISNULL(SUM(CASE [rate3] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate3] END), 0) AS [单位三数量],
    a.[rate3] AS [单位关系三], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit4_id]), '') AS [单位四],
    ISNULL(SUM(CASE [rate4] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate4] END), 0) AS [单位四数量],
    a.[rate4] AS [单位关系四], 

		ISNULL(SUM(b.costtotal),0) AS [成本金额],
		ISNULL(SUM(b.taxtotal),0) AS [含税金额],
		ISNULL(SUM(b.retailtotal),0) AS [零售金额]
		FROM Products a 
      LEFT JOIN	##mytempdb AS b
		ON LEFT(b.[class_id], LEN(a.[class_id]))=a.[class_id]
  	WHERE a.[parent_id]=@szParid AND a.[deleted]<>1 
		GROUP BY a.[product_id], a.[class_id], a.[child_number], a.[name], a.[serial_number], a.[alias], a.[standard],
      a.[modal], a.[makearea], a.[medtype], a.[unit1_id], a.[unit2_id], a.[rate2], a.[unit3_id], a.[rate3], 
      a.[unit4_id], a.[rate4]
		ORDER BY a.[product_ID]

  GOTO Succee

ListAll:
	SELECT a.product_ID AS [ID], a.[Class_ID] AS [Class_ID], a.[child_number] AS [结点儿子数], 
    a.[name] AS [全名], a.[serial_number] AS [编号], a.[Alias] AS [通用名], a.[Standard] AS [规格], a.[modal] AS [型号],
    a.[makearea] AS [产地], a.[medtype] AS [剂型], 
    (SELECT [name] FROM Unit WHERE [unit_id]=a.[unit1_id]) AS [单位一],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit2_id]), '') AS [单位二],
    ISNULL(SUM(CASE [rate2] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate2] END), 0) AS [单位二数量],
    a.[rate2] AS [单位关系二], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit3_id]), '')AS [单位三],
    ISNULL(SUM(CASE [rate3] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate3] END), 0) AS [单位三数量],
    a.[rate3] AS [单位关系三], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit4_id]), '') AS [单位四],
    ISNULL(SUM(CASE [rate4] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate4] END), 0) AS [单位四数量],
    a.[rate4] AS [单位关系四], 

		ISNULL(SUM(b.costtotal),0) AS [成本金额],
		ISNULL(SUM(b.taxtotal),0) AS [含税金额],
		ISNULL(SUM(b.retailtotal),0) AS [零售金额]
		FROM Products a 
      LEFT JOIN	##mytempdb AS b
		ON b.[class_id]=a.[class_id]
  	WHERE a.[child_number]=0 AND a.[product_id]<>0
		GROUP BY a.[product_id], a.[class_id], a.[child_number], a.[name], a.[serial_number], a.[alias], a.[standard],
      a.[modal], a.[makearea], a.[medtype], a.[unit1_id], a.[unit2_id], a.[rate2], a.[unit3_id], a.[rate3], 
      a.[unit4_id], a.[rate4]
		ORDER BY a.[product_ID]

  GOTO Succee
ListPart:
	SELECT a.product_ID AS [ID], a.[Class_ID] AS [Class_ID], a.[child_number] AS [结点儿子数], 
    a.[name] AS [全名], a.[serial_number] AS [编号], a.[Alias] AS [通用名], a.[Standard] AS [规格], a.[modal] AS [型号],
    a.[makearea] AS [产地], a.[medtype] AS [剂型], 
    (SELECT [name] FROM Unit WHERE [unit_id]=a.[unit1_id]) AS [单位一],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],
  	ISNULL(SUM(b.[quantity]),0) AS [单位一数量],

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit2_id]), '') AS [单位二],
    ISNULL(SUM(CASE [rate2] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate2] END), 0) AS [单位二数量],
    a.[rate2] AS [单位关系二], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit3_id]), '')AS [单位三],
    ISNULL(SUM(CASE [rate3] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate3] END), 0) AS [单位三数量],
    a.[rate3] AS [单位关系三], 

    ISNULL((SELECT [name] FROM Unit WHERE [unit_id]=a.[unit4_id]), '') AS [单位四],
    ISNULL(SUM(CASE [rate4] WHEN 0 THEN 0
      ELSE b.[quantity]/a.[rate4] END), 0) AS [单位四数量],
    a.[rate4] AS [单位关系四], 

		ISNULL(SUM(b.costtotal),0) AS [成本金额],
		ISNULL(SUM(b.taxtotal),0) AS [含税金额],
		ISNULL(SUM(b.retailtotal),0) AS [零售金额]
		FROM Products a 
      LEFT JOIN	##mytempdb AS b
		ON b.[class_id]=a.[class_id]
  	WHERE LEFT(a.[class_id],LEN(@szParid))=@szParid AND a.[deleted]<>1 AND a.[child_number]=0
		GROUP BY a.[product_id], a.[class_id], a.[child_number], a.[name], a.[serial_number], a.[alias], a.[standard],
      a.[modal], a.[makearea], a.[medtype], a.[unit1_id], a.[unit2_id], a.[rate2], a.[unit3_id], a.[rate3], 
      a.[unit4_id], a.[rate4]
		ORDER BY a.[product_ID]

  GOTO Succee

Succee:
	DROP TABLE ##mytempdb
  RETURN 0
GO
