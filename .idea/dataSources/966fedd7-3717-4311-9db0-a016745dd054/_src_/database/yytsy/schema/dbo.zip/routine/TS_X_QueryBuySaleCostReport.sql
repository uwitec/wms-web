

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

@lMode 0 
查询商品在一段时间内的进货、销售和
  成本、利润的报表

@lMode 1
查询商品在一段时间内，结束日期是当前的进货、销售的报表
如果还有库存余量就列出批次的明细

@lMode 2
门店请货分析，分析门店的请货数量和当前的库存数量及进销订单的分析

********************************************/
CREATE  PROCEDURE TS_X_QueryBuySaleCostReport
( @lMode        INT=0,
  @szListFlag 	VARCHAR(1)='L',
  @ParID        VARCHAR(30)='000000',
  @BeginDate    DATETIME=0,
  @EndDate		  DATETIME=0,
  @nYClassid                 varchar(100)='',
  @LoginYID                 int=0,
  @nloginEID               int=0,
  @isaddDate              int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
  @CheckFlag     int    /*是否包含待退厂库：1 表示不包含 0表示包含*/
)

/*with encryption*/
AS
/*Params Ini begin*/
if @lMode is null  SET @lMode = 0
if @szListFlag is null  SET @szListFlag = 'L'
if @ParID is null  SET @ParID = '000000'
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nYClassid is null  SET @nYClassid = ''
if @LoginYID is null  SET @LoginYID = 0
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @CheckFlag is null set @CheckFlag = 0
/*Params Ini end*/
 /* SET NOCOUNT ON*/
  DECLARE @SQLScript VARCHAR(8000)
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  Declare @Y_id int
  select @Y_id=@LoginYID

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin
     set @Storetable=1 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


  IF @lMode=0
  BEGIN
    IF @szListFlag='L' GOTO GetListCost
    IF @szListFlag='A' GOTO GetAllCost
    IF @szListFlag='P' GOTO GetPartCost
  END
  ELSE IF @lMode=1 GOTO GetBatchNO
  ELSE
  BEGIN
    IF @szListFlag='L' GOTO GetListMD
    IF @szListFlag='A' GOTO GetAllMD
    IF @szListFlag='P' GOTO GetPartMD
  END

/*---------------业务单据查询*/
GetListCost:

  SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,
        p.serial_number,
        SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)) AS [IniTotal],
        SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)+ISNULL(B.[BMSendCostTotal], 0)-ISNULL(B.[SMSendCostTotal], 0)) AS [NowTotal],
        SUM(ISNULL(B.[BMCostTotal], 0)) AS [BuyTotal],

        SUM(ISNULL(B.[BMSendQTY],0))    AS [BMSendQTY],
        SUM(ISNULL(B.[BMSendCostTotal],0)) AS [BMSendCostTotal],

        SUM(ISNULL(B.[SMCostTotal], 0)) AS [CostTotal],
        cast(SUM(ISNULL(B.[SMSaleTotal], 0)) as NUMERIC(25,8)) AS [SaleTotal],

        SUM(ISNULL(B.[SMSendQTY],0))    AS [SMSendQTY],
        SUM(ISNULL(B.[SMSendCostTotal],0)) AS [SMSendCostTotal],
        cast(SUM(ISNULL(B.[SMSendTotal],0)) as NUMERIC(25,8))  AS [SMSendTotal],
        cast(SUM(ISNULL(B.[SMSendTotal], 0)-ISNULL(B.[SMSendCostTotal], 0)) as NUMERIC(25,8)) AS [GainTotal]
  FROM
       (SELECT [Product_ID], [Class_ID], [Child_Number], [Name], [Standard], [MakeArea],
        Inputman,InputDate,Custompro1,Custompro2,Custompro3,Custompro4,Custompro5, serial_number
        FROM  Products  WHERE [Deleted]<>1 AND [Parent_ID]=@ParID and IsSplit = 0) P
      
        LEFT JOIN
       (SELECT P.*,
          ISNULL(SH.[SHCostTotal], 0) AS [SHCostTotal], ISNULL(PD.[PDCostTotal], 0) AS [PDCostTotal], 
          ISNULL(BM.[BMCostTotal], 0) AS [BMCostTotal], ISNULL(BM.[BMSendQTY],0) AS [BMSendQTY],
          ISNULL(BM.[BMSendCostTotal],0) AS [BMSendCostTotal],
          ISNULL(SM.[SMCostTotal], 0) AS [SMCostTotal], ISNULL(SM.[SMSaleTotal], 0) AS [SMSaleTotal],
          ISNULL(SM.[SMSendQTY],0) AS [SMSendQTY],      ISNULL(SM.[SMSendTotal],0) AS  [SMSendTotal],   
          ISNULL(SM.[SMSendCostTotal],0) AS [SMSendCostTotal] 
        FROM
          (SELECT [Product_ID], [Class_ID] FROM Products WHERE [Deleted]<>1 AND [Child_Number]=0 AND IsSplit = 0) P
       
          LEFT JOIN
          (SELECT s.[P_ID], SUM(s.[CostTotal]) AS [SHCostTotal]
           FROM 
                (select p_id,Costtotal,Y.class_id,s_id,s.Y_ID from FilterStorehouseini(@nloginEID) S 
                Inner join Company Y ON S.Y_id=Y.Company_id
                INNER JOIN storages t on t.storage_id = s.s_id
                where WholeFlag <> 3)s
           WHERE (@nYClassID='' or s.Class_id like @nYClassID+'%')
           AND ((@Companytable=0) or (s.Y_id in (select [id] from #Companytable)))
           AND ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 

          GROUP BY s.[P_ID])SH
          ON SH.[P_ID]=P.[Product_ID]
 
          LEFT JOIN
          (SELECT [P_ID], SUM([CostTotal]) AS [PDCostTotal]
           FROM
            (select PD.*,Y.class_id as YClass_id 
             FROM
              (select pd.billid,pd.s_id,pd.Rowe_id,pd.p_id,pd.Costtotal,b.c_id,b.Y_id from FilterProductdetail(@nloginEID) pd
                INNER JOIN (select billid,c_id,Y_id from billidx where billdate<@begindate and 
                            billtype not in (150,151,152,153,155,160,161,162,163,165) and billstates=0
                            )B ON B.billid=pd.billid  
                where aoid in (0,5) and Storetype IN (0)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=16 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where [BillDate]<@BeginDate
                            and billtype in (16,17) and [BillStates]='0'
                            )B ON b.billid=sm.bill_id
                where aoid in (0,5)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=25 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                from BuyManageBill bm
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where [BillDate]<@BeginDate
                            and billtype in (24,25) and [BillStates]='0'
                            )B ON b.billid=bm.bill_id
                where aoid in (0,5)                              
            )PD 
             INNER JOIN Company Y ON PD.Y_id=Y.company_id
           )YPPD  
           WHERE (@nYClassID='' or YPPD.YClass_id like @nYClassID+'%')
             AND ((@Companytable=0)or (YPPD.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPPD.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPPD.s_id in (select [id] from #storagestable))) 
             AND ((@employeestable=0) OR (YPPD.RowE_id in (select [id] from #employeestable)))  
           GROUP BY YPPD.[P_ID]) PD

          ON PD.[P_ID]=P.[Product_ID]

          LEFT JOIN
          (SELECT YPBM.[P_ID],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.CostTotal ELSE -(YPBM.CostTotal) END) AS [BMCostTotal],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendQTY] ELSE -YPBM.[SendQTY] END) AS [BMSendQTY],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendCostTotal] ELSE -YPBM.[SendCostTotal] END) AS [BMSendCostTotal]
           
           FROM
             (SELECT YPBM.*,isnull(Y.class_id,'') as YClass_id
              from
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 from buymanagebill BM 
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (20,21,122,24,25,222)
                              and billstates='0'
                              and billdate BETWEEN @BeginDate AND @EndDate
                              ) BI ON BI.billid=BM.bill_id
                 where aoid in(0) and p_id>0
                )YPBM
                INNER JOIN Company Y ON YPBM.Y_id=Y.company_id
              )YPBM  
	    WHERE (@nYClassid='' OR YPBM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPBM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPBM.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPBM.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPBM.RowE_id in (select [id] from #employeestable)))
            GROUP BY YPBM.[P_ID]) BM
          ON BM.[P_ID]=P.[Product_ID]
  
          LEFT JOIN
          (SELECT YPSM.[P_ID],
	    SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[Costtotal] ELSE -(YPSM.[Costtotal]) END) AS [SMCostTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[TaxTotal]-YPSM.[TaxMoney] ELSE -(YPSM.[TaxTotal]-YPSM.[TaxMoney]) END) AS [SMSaleTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendQTY] ELSE -YPSM.[SendQTY] END) AS [SMSendQTY],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] ELSE -YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] END) AS [SMSendTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendCostTotal] ELSE -YPSM.[SendCostTotal] END) AS [SMSendCostTotal]
           
           FROM
             (select YPSM.*,isnull(Y.class_id,'') as YClass_id
              FROM 
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal,taxtotal,taxmoney,totalmoney,quantity
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (10,11,12,13,112,53,54,16,17,212)
                              and billdate BETWEEN @BeginDate AND @EndDate
                              and billstates='0'
                              ) BI ON BI.billid=SM.bill_id
                 INNER JOIN storages s on sm.ss_id = s.storage_id             
                 where aoid in(0) and p_id>0 and WholeFlag <> 3
                )YPSM
   	        INNER JOIN Company Y ON YPSM.Y_id=Y.company_id
             )YPSM  
          WHERE (@nYClassid='' or YPSM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPSM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPSM.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPSM.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPSM.RowE_id in (select [id] from #employeestable)))
           GROUP BY YPSM.[P_ID]) SM
         ON SM.[P_ID]=P.[Product_ID]
  
      )B
  ON LEFT(B.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5, p.serial_number
  ORDER BY P.[Class_ID]
  
  GOTO Succee

GetAllCost:
  SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,
        p.serial_number,
         SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)) AS [IniTotal],
         SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)+ISNULL(B.[BMSendCostTotal], 0)-ISNULL(B.[SMSendCostTotal], 0)) AS [NowTotal],
         SUM(ISNULL(B.[BMCostTotal], 0)) AS [BuyTotal],

         SUM(ISNULL(B.[BMSendQTY],0))    AS [BMSendQTY],
         SUM(ISNULL(B.[BMSendCostTotal],0)) AS [BMSendCostTotal],
 
         SUM(ISNULL(B.[SMCostTotal], 0)) AS [CostTotal],
         cast(SUM(ISNULL(B.[SMSaleTotal], 0)) as NUMERIC(25,8)) AS [SaleTotal],

         SUM(ISNULL(B.[SMSendQTY],0))    AS [SMSendQTY],
         SUM(ISNULL(B.[SMSendCostTotal],0)) AS [SMSendCostTotal],
         cast(SUM(ISNULL(B.[SMSendTotal],0)) as NUMERIC(25,8))  AS [SMSendTotal],
         cast(SUM(ISNULL(B.[SMSendTotal], 0)-ISNULL(B.[SMSendCostTotal], 0))  as NUMERIC(25,8))AS [GainTotal]
  FROM
  
     (SELECT [Product_ID], [Class_ID], [Child_Number], [Name], [Standard], [MakeArea],
        Inputman,InputDate,Custompro1,Custompro2,Custompro3,Custompro4,Custompro5, serial_number
        FROM Products  WHERE [Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P
      
        LEFT JOIN
       (SELECT P.*,
          ISNULL(SH.[SHCostTotal], 0) AS [SHCostTotal], ISNULL(PD.[PDCostTotal], 0) AS [PDCostTotal], 
          ISNULL(BM.[BMCostTotal], 0) AS [BMCostTotal], ISNULL(BM.[BMSendQTY],0) AS [BMSendQTY],
          ISNULL(BM.[BMSendCostTotal],0) AS [BMSendCostTotal],
          ISNULL(SM.[SMCostTotal], 0) AS [SMCostTotal], ISNULL(SM.[SMSaleTotal], 0) AS [SMSaleTotal],
          ISNULL(SM.[SMSendQTY],0) AS [SMSendQTY],      ISNULL(SM.[SMSendTotal],0) AS  [SMSendTotal],   
          ISNULL(SM.[SMSendCostTotal],0) AS [SMSendCostTotal] 
        FROM
          (SELECT [Product_ID], [Class_ID] FROM Products WHERE [Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P
       
          LEFT JOIN
          (SELECT s.[P_ID], SUM(s.[CostTotal]) AS [SHCostTotal]
           FROM 
              (select p_id,Costtotal,Y.class_id,s_id,s.Y_ID from FilterStorehouseini(@nloginEID) S 
              Inner join Company Y ON S.Y_id=Y.Company_id
              inner join storages t on t.storage_id = s.s_id
              where WholeFlag <> 3)s
           WHERE (@nYClassID='' or s.Class_id like @nYClassID+'%')
            AND ((@Companytable=0) or (s.Y_id in (select [id] from #Companytable)))
            AND ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable)))
          GROUP BY s.[P_ID])SH
          ON SH.[P_ID]=P.[Product_ID]
 
          LEFT JOIN
          (SELECT [P_ID], SUM([CostTotal]) AS [PDCostTotal]
           FROM 
            (select PD.*,Y.class_id as YClass_id 
             FROM
              (select pd.billid,pd.s_id,pd.Rowe_id,pd.p_id,pd.Costtotal,b.c_id,b.Y_id from FilterProductdetail(@nloginEID) pd
                INNER JOIN (select billid,c_id,Y_id from billidx where billtype not in (150,151,152,153,155,160,161,162,163,165)
                             and billdate<@begindate
                             and billstates=0
                            )B ON B.billid=pd.billid  
                where aoid in (0,5) and Storetype IN (0)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=16 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where [billtype] in (16,17)
                                   AND [BillDate]<@BeginDate and [BillStates]='0'
                            )B ON b.billid=sm.bill_id
                where aoid in (0,5)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=25 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                from BuyManageBill bm
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where billtype in (24,25)
                                  AND [BillDate]<@BeginDate and [BillStates]='0'
                            )B ON b.billid=bm.bill_id
                where aoid in (0,5)
            )PD 
             INNER JOIN Company Y ON PD.Y_id=Y.company_id
           )YPPD  
           WHERE (@nYClassID='' or YPPD.YClass_id like @nYClassID+'%')
             AND ((@Companytable=0)or (YPPD.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPPD.c_id in (select [id] from #Clienttable)))  
             AND ((@Storetable=0) OR (YPPD.s_id in (select [id] from #storagestable)))
             AND ((@employeestable=0) OR (YPPD.RowE_id in (select [id] from #employeestable)))
           GROUP BY YPPD.[P_ID]) PD
          ON PD.[P_ID]=P.[Product_ID]
 
          LEFT JOIN
          (SELECT YPBM.[P_ID],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[CostTotal] ELSE -(YPBM.[CostTotal]) END) AS [BMCostTotal],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendQTY] ELSE -YPBM.[SendQTY] END) AS [BMSendQTY],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendCostTotal] ELSE -YPBM.[SendCostTotal] END) AS [BMSendCostTotal]
           
            FROM
             (SELECT YPBM.*,isnull(Y.class_id,'') as YClass_id
              from
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 from buymanagebill BM 
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (20,21,122,24,25,222)
                                    and billdate BETWEEN @BeginDate AND @EndDate and billstates='0'
                              ) BI ON BI.billid=BM.bill_id
                 where aoid in(0) and p_id>0
                )YPBM
                INNER JOIN Company Y ON YPBM.Y_id=Y.company_id
              )YPBM  
	    WHERE (@nYClassid='' OR YPBM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPBM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPBM.c_id in (select [id] from #Clienttable))) 
             AND ((@Storetable=0) OR (YPBM.s_id in (select [id] from #storagestable))) 
             and ((@employeestable=0) OR (YPBM.RowE_id in (select [id] from #employeestable)))
            GROUP BY YPBM.[P_ID]) BM
          ON BM.[P_ID]=P.[Product_ID]
  
          LEFT JOIN
          (SELECT YPSM.[P_ID],
	    SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[CostTotal] ELSE -(YPSM.[CostTotal]) END) AS [SMCostTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[TaxTotal]-YPSM.[TaxMoney] ELSE -(YPSM.[TaxTotal]-YPSM.[TaxMoney]) END) AS [SMSaleTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendQTY] ELSE -YPSM.[SendQTY] END) AS [SMSendQTY],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] ELSE -YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] END) AS [SMSendTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendCostTotal] ELSE -YPSM.[SendCostTotal] END) AS [SMSendCostTotal]
           
           FROM
             (select YPSM.*,isnull(Y.class_id,'') as YClass_id
              FROM 
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal,taxtotal,taxmoney,totalmoney,quantity
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (10,11,12,13,112,53,54,16,17,212)
                                     and billdate BETWEEN @BeginDate AND @EndDate and billstates='0'
                              ) BI ON BI.billid=SM.bill_id
                 INNER JOIN storages t on sm.ss_id = t.storage_id              
                 where aoid in(0) and p_id>0 AND WholeFlag <> 3
                )YPSM
   	        INNER JOIN Company Y ON YPSM.Y_id=Y.company_id
             )YPSM  
          WHERE (@nYClassid='' or YPSM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPSM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPSM.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPSM.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPSM.RowE_id in (select [id] from #employeestable)))
           GROUP BY YPSM.[P_ID]) SM
         ON SM.[P_ID]=P.[Product_ID]
  
      )B
  ON B.[Class_ID]=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5, p.serial_number
  ORDER BY P.[Class_ID]

  GOTO Succee

GetPartCost:
  SELECT P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,
        p.serial_number,
  SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)) AS [IniTotal],
        SUM(ISNULL(B.[SHCostTotal], 0)+ISNULL(B.[PDCostTotal], 0)+ISNULL(B.[BMSendCostTotal], 0)-ISNULL(B.[SMSendCostTotal], 0)) AS [NowTotal],
        SUM(ISNULL(B.[BMCostTotal], 0)) AS [BuyTotal],

        SUM(ISNULL(B.[BMSendQTY],0))    AS [BMSendQTY],
        SUM(ISNULL(B.[BMSendCostTotal],0)) AS [BMSendCostTotal],

        SUM(ISNULL(B.[SMCostTotal], 0)) AS [CostTotal],
        cast(SUM(ISNULL(B.[SMSaleTotal], 0)) as NUMERIC(25,8)) AS [SaleTotal],

        SUM(ISNULL(B.[SMSendQTY],0))    AS [SMSendQTY],
        SUM(ISNULL(B.[SMSendCostTotal],0)) AS [SMSendCostTotal],
        cast(SUM(ISNULL(B.[SMSendTotal],0)) as NUMERIC(25,8)) AS [SMSendTotal],
        cast(SUM(ISNULL(B.[SMSendTotal], 0)-ISNULL(B.[SMSendCostTotal], 0)) as NUMERIC(25,8)) AS [GainTotal]
  FROM
       (SELECT [Product_ID], [Class_ID], [Child_Number], [Name], [Standard], [MakeArea],
        Inputman,InputDate,Custompro1,Custompro2,Custompro3,Custompro4,Custompro5, serial_number
        FROM Products  WHERE [Deleted]<>1 AND LEFT([Class_ID], LEN(@ParID))=@ParID AND [Child_Number]=0 and IsSplit = 0) P
      
        LEFT JOIN
       (SELECT P.*,
          ISNULL(SH.[SHCostTotal], 0) AS [SHCostTotal], ISNULL(PD.[PDCostTotal], 0) AS [PDCostTotal], 
          ISNULL(BM.[BMCostTotal], 0) AS [BMCostTotal], ISNULL(BM.[BMSendQTY],0) AS [BMSendQTY],
          ISNULL(BM.[BMSendCostTotal],0) AS [BMSendCostTotal],
          ISNULL(SM.[SMCostTotal], 0) AS [SMCostTotal], ISNULL(SM.[SMSaleTotal], 0) AS [SMSaleTotal],
          ISNULL(SM.[SMSendQTY],0) AS [SMSendQTY],      ISNULL(SM.[SMSendTotal],0) AS  [SMSendTotal],   
          ISNULL(SM.[SMSendCostTotal],0) AS [SMSendCostTotal] 
        FROM
          (SELECT [Product_ID], [Class_ID] FROM Products WHERE [Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P
       
          LEFT JOIN
          (SELECT s.[P_ID], SUM(s.[CostTotal]) AS [SHCostTotal]
           FROM 
                (select p_id,Costtotal,Y.class_id,s_id,s.Y_ID from FilterStorehouseini(@nloginEID) S 
                Inner join Company Y ON S.Y_id=Y.Company_id
                Inner join storages t ON s.s_id = t.storage_id
                where WholeFlag <> 3 )s
           WHERE (@nYClassID='' or s.Class_id like @nYClassID+'%')
            AND ((@Companytable=0) or (s.Y_id in (select [id] from #Companytable)))
            AND ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable)))
          GROUP BY s.[P_ID])SH
          ON SH.[P_ID]=P.[Product_ID]
 
          LEFT JOIN
          (SELECT [P_ID], SUM([CostTotal]) AS [PDCostTotal]
           FROM
            (select PD.*,Y.class_id as YClass_id 
             FROM
              (select pd.billid,pd.s_id,pd.Rowe_id,pd.p_id,pd.Costtotal,b.c_id,b.Y_id from FilterProductdetail(@nloginEID) pd
                INNER JOIN (select billid,c_id,Y_id from billidx where billtype not in (150,151,152,153,155,160,161,162,163,165)
                                   and billdate<@begindate and billstates=0
                            )B ON B.billid=pd.billid  
                where aoid in (0,5) and Storetype IN (0)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=16 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where billtype in (16,17) AND [BillDate]<@BeginDate
                            and [BillStates]='0'
                            )B ON b.billid=sm.bill_id
                where aoid in (0,5)
              union all
                select bill_id as billid,ss_id as s_id,RowE_id,p_id,
                (case when b.billtype=25 then -(costprice*quantity) else (costprice*quantity) end)Costtotal
                ,B.c_id,B.Y_id
                from BuyManageBill bm
                INNER JOIN (select billid,billtype,c_id,Y_id from Billidx where billtype in (24,25) AND [BillDate]<@BeginDate
                            and [BillStates]='0'
                            )B ON b.billid=bm.bill_id
                where aoid in (0,5)
            )PD 
             INNER JOIN Company Y ON PD.Y_id=Y.company_id
           )YPPD  
           WHERE (@nYClassid='' or YPPD.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPPD.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPPD.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPPD.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPPD.RowE_id in (select [id] from #employeestable)))
           GROUP BY YPPD.[P_ID]) PD
          ON PD.[P_ID]=P.[Product_ID]
 
          LEFT JOIN
          (SELECT YPBM.[P_ID],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[CostTotal] ELSE -(YPBM.[CostTotal]) END) AS [BMCostTotal],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendQTY] ELSE -YPBM.[SendQTY] END) AS [BMSendQTY],
	    SUM(CASE WHEN YPBM.[BillType] IN (20,122,24,222) THEN YPBM.[SendCostTotal] ELSE -YPBM.[SendCostTotal] END) AS [BMSendCostTotal]
           
            FROM
             (SELECT YPBM.*,isnull(Y.class_id,'') as YClass_id
              from
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 from buymanagebill BM 
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (20,21,122,24,25,222) and billdate BETWEEN @BeginDate AND @EndDate and
                              billstates='0'
                              ) BI ON BI.billid=BM.bill_id
                 where aoid in(0) and p_id>0
                )YPBM
                INNER JOIN Company Y ON YPBM.Y_id=Y.company_id
              )YPBM  
	    WHERE (@nYClassid='' or YPBM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPBM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPBM.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPBM.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPBM.RowE_id in (select [id] from #employeestable)))
            GROUP BY YPBM.[P_ID]) BM
          ON BM.[P_ID]=P.[Product_ID]
  
          LEFT JOIN
          (SELECT YPSM.[P_ID],
	    SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[CostTotal] ELSE -(YPSM.[CostTotal]) END) AS [SMCostTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[TaxTotal]-YPSM.[TaxMoney] ELSE -(YPSM.[TaxTotal]-YPSM.[TaxMoney]) END) AS [SMSaleTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendQTY] ELSE -YPSM.[SendQTY] END) AS [SMSendQTY],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] ELSE -YPSM.totalmoney/YPSM.quantity*YPSM.[SendQTY] END) AS [SMSendTotal],
            SUM(CASE WHEN YPSM.[BillType] IN (10,12,112,53,16,212) THEN YPSM.[SendCostTotal] ELSE -YPSM.[SendCostTotal] END) AS [SMSendCostTotal]
           
           FROM
             (select YPSM.*,isnull(Y.class_id,'') as YClass_id
              FROM 
                (select p_id,RowE_id,ss_id as s_id,(Costprice*quantity)CostTotal,SendQTY,SendCostTotal,taxtotal,taxmoney,totalmoney,quantity
                        ,BI.c_id,BI.Y_id,BI.billtype 
                 FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                 INNER JOIN  (select billid,billtype,c_id,Y_id from BillIDX where billtype in (10,11,12,13,112,53,54,16,17,212) and billdate BETWEEN @BeginDate AND @EndDate and
                              billstates='0'
                              ) BI ON BI.billid=SM.bill_id
                 INNER JOIN storages t on sm.ss_id = t.storage_id                  
                 where aoid in(0) and p_id>0 and WholeFlag <> 3
                )YPSM
   	        INNER JOIN Company Y ON YPSM.Y_id=Y.company_id
             )YPSM  
          WHERE (@nYClassid='' or YPSM.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (YPSM.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (YPSM.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (YPSM.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (YPSM.RowE_id in (select [id] from #employeestable)))  
           GROUP BY YPSM.[P_ID]) SM
         ON SM.[P_ID]=P.[Product_ID]
  
      )B
  ON LEFT(B.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Child_Number], P.[Name], P.[Standard], P.[MakeArea],
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5, p.serial_number
  ORDER BY P.[Class_ID]

  GOTO Succee

GetBatchNO:
  
  SELECT * FROM (
  SELECT P.[Product_ID], (0) AS PNO, P.[Class_ID], P.[Code], P.[Name],P.[Standard], P.[MakeArea], P.[UnitName1],
         SUM(ISNULL(SHI.[Quantity], 0)+ISNULL(PD.[Quantity], 0)) AS [IniQuantty],
         SUM(ISNULL(SH.[Quantity], 0)) AS [NowTotal],
         SUM(ISNULL(BM.[Quantity], 0)) AS [BuyTotal],
         ISNULL(SUM(BM.[BMSendQTY]),0) AS [BMSendQTY],
         ISNULL(SUM(BM.[BMSendCostTotal]),0) AS [BMSendCostTotal],
         SUM(ISNULL(SM.[Quantity], 0)) AS [SaleTotal],
         ISNULL(SUM(SM.[SMSendQTY]),0) AS [SMSendQTY],
         ISNULL(SUM(SM.[SMSendCostTotal]),0) AS [SMSendCostTotal]
  
  FROM
     (SELECT p.[Product_ID],p.[Class_ID], p.Serial_Number as [Code], p.[Name], p.[Standard], p.[MakeArea]
           , ISNULL(U1.[Name], '') AS [UnitName1]
       FROM Products p
       LEFT JOIN Unit U1  ON p.[Unit1_ID]=U1.[Unit_ID]
       WHERE p.[Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P

      LEFT JOIN
     (SELECT s.[p_id], SUM(s.[Quantity]) AS [Quantity]
      FROM
          (select s.p_id,s.s_id,s.Y_id,isnull(Y.class_id,'') as YClass_id,quantity  from StoreHouseIni s
           INNER JOIN Company Y  ON Y.Company_id=s.Y_id
           Inner join storages t ON s.s_id = t.storage_id
           where WholeFlag <> 3 )s  
      WHERE  (@nYClassID='' OR s.YClass_id like @nYClassID+'%')
         AND ((@Companytable=0) or (s.Y_id in (select [id] from #Companytable)))
         AND ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable)))
      GROUP BY s.[p_id]) SHI
      ON SHI.[p_ID]=P.[Product_ID]

      LEFT JOIN
     (SELECT [p_ID], SUM(PD.[Quantity]) AS [Quantity]
      FROM  
       (select PD.*,isnull(Y.Class_id,'') as YClass_id
        from 
         (  SELECT pd.p_id ,pd.quantity,pd.s_id,bi.Y_id,PD.RowE_id,BI.c_id
            FROM  productdetail PD
             INNER JOIN BillIDX BI  ON bi.billid=pd.billid
            WHERE bi.billtype not in (150,151,152,153,155,160,161,162,163,165) 
                 AND Bi.[BillDate]<@BeginDate
                 and PD.p_id>0 and pd.aoid in (0,5,7) AND Bi.[BillStates]='0'
                 AND PD.Storetype IN (0)
         )PD
          INNER JOIN Company Y ON Y.Company_id=PD.Y_id
        )PD    
      WHERE (@nYClassid='' or PD.Yclass_id like @nYClassid+'%')
             AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
             AND ((@ClientTable=0) or (PD.c_id in (select [id] from #Clienttable)))
             AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable)))
             and ((@employeestable=0) OR (PD.RowE_id in (select [id] from #employeestable)))
      GROUP BY [p_ID]) PD
      ON PD.[p_ID]=P.[Product_ID]

      LEFT JOIN
    (SELECT s.[P_ID] , SUM(s.[Quantity]) AS [Quantity] 
      FROM (select s.p_id,s.s_id,s.Y_id,Y.Class_id as YClass_id,quantity from StoreHouse s  
             INNER JOIN Company Y ON Y.Company_id=s.Y_id)s 
      WHERE (@nYClassID='' or S.YClass_id like @nYClassID+'%')
        AND ((@Companytable=0) or (s.Y_id in (select [id] from #Companytable)))
        AND ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable)))
      GROUP BY s.[p_ID]) SH
      ON SH.[p_ID]=P.[Product_ID]

      LEFT JOIN
    (SELECT BM.[p_ID],
	SUM(CASE WHEN BM.[BillType] IN (20,122,24,220) THEN BM.[Quantity] ELSE -(BM.[Quantity]) END) AS [Quantity],
        ISNULL(SUM(CASE WHEN BM.[BillType] IN (20,122,24,220) THEN BM.[SendQTY] ELSE -(BM.[SendQTY]) END),0) AS [BMSendQTY],
        ISNULL(SUM(CASE WHEN BM.[BillType] IN (20,122,24,220) THEN BM.[SendCostTotal] ELSE -(BM.[SendCostTotal]) END),0) AS [BMSendCostTotal]
     FROM
      (select BM.*,isnull(Y.Class_id,'')as YClass_id
       from
        (  SELECT P_id,BM.quantity,BM.SendQTY,bm.SendCosttotal,bm.RowE_id,bm.ss_id as s_id,bi.Y_id,bi.C_id,bi.billtype  FROM buymanagebill bm
             INNER JOIN BillIDX bi ON  bi.billid=BM.bill_id
           WHERE BI.[BillType] IN (20,21,122,24,25,220,221) 
             AND BI.[Billdate] BETWEEN @BeginDate AND @EndDate
             and BI.[BillID]=BM.[Bill_ID]
             AND BI.[BillStates]='0' and bm.aoid in (0) and bm.p_id>0
         )BM
          INNER JOIN Company Y ON Y.Company_id=BM.Y_id 
      )BM 
     WHERE (@nYClassid='' or BM.Yclass_id like @nYClassid+'%')
            AND ((@Companytable=0)or (BM.Y_id in (select [id] from #Companytable)))
            AND ((@ClientTable=0) or (BM.c_id in (select [id] from #Clienttable)))
            AND ((@Storetable=0) OR (BM.s_id in (select [id] from #storagestable)))
            and ((@employeestable=0) OR (BM.RowE_id in (select [id] from #employeestable)))
     GROUP BY BM.[p_id]) BM
     ON BM.[p_ID]=P.[Product_ID]

      LEFT JOIN
    (SELECT BM.[p_ID],
	SUM(CASE WHEN BM.[BillType] IN (10,12,112,53,16,210) THEN BM.[Quantity] ELSE -(BM.[Quantity]) END) AS [Quantity],
        ISNULL(SUM(CASE WHEN BM.[BillType] IN (10,12,112,53,16,210) THEN BM.[SendQTY] ELSE -(BM.[SendQTY]) END),0) AS [SMSendQTY],
        ISNULL(SUM(CASE WHEN BM.[BillType] IN (10,12,112,53,16,210) THEN BM.[SendCostTotal] ELSE -(BM.[SendCostTotal]) END),0) AS [SMSendCostTotal]
      FROM
       (Select BM.*,isnull(Y.Class_id,'')YClass_id
        from 
         ( SELECT BM.P_id,BM.quantity,BM.SendQTY,BM.SendCosttotal,BM.RowE_id,ss_id as s_id,bi.Y_id,bi.C_id,bi.billtype  FROM salemanagebill Bm   /*FilterSalemanagebill(@nloginEID) bm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
             INNER JOIN BillIDX bi ON  bi.billid=BM.bill_id
             INNER JOIN storages s on s.storage_id = Bm.ss_id
           WHERE  BI.[BillType] IN (10,11,12,13,112,53,54,16,17,210,211) AND BI.[Billdate] BETWEEN @BeginDate AND @EndDate
             AND BI.[BillID]=BM.[Bill_ID] AND BI.[BillStates]='0' and bm.aoid in (0) and bm.p_id>0 and WholeFlag <> 3
         )BM
         INNER JOIN Company Y ON Y.Company_id=BM.Y_id
       )BM 
      WHERE (@nYClassid='' or BM.Yclass_id like @nYClassid+'%')
            AND ((@Companytable=0)or (BM.Y_id in (select [id] from #Companytable)))
            AND ((@ClientTable=0) or (BM.c_id in (select [id] from #Clienttable)))
            AND ((@Storetable=0) OR (BM.s_id in (select [id] from #storagestable)))
            and ((@employeestable=0) OR (BM.RowE_id in (select [id] from #employeestable)))                                                                                                  
      GROUP BY BM.[p_ID]) SM
      ON SM.[p_ID]=P.[Product_ID]

  GROUP BY P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Standard], P.[MakeArea], P.[UnitName1]

  UNION 
  
  SELECT P.[Product_ID], (1) AS PNO, P.[Class_ID], '库存批次' AS [Code], '进库日期' AS [Name], 
  '批号' AS [Standard], '效期' AS [MakeArea], '批次剩余量' AS [UnitName1],
  (0) AS [IniQuantity],
  (0) AS [NowTotal],
  (0) AS [BuyTotal],
  (0) AS [BMSendQTY],
  (0) AS [BMSendCostTotal],
  (0) AS [SaleTotal],
  (0) AS [SMSendQTY],
  (0) AS [SMSendCostTotal]

  FROM
  (SELECT p.[Product_ID], p.[Class_ID], p.Serial_Number as [Code], p.[Name], p.[Standard], p.[MakeArea], ISNULL(U1.[Name], '') AS [UnitName1]
  FROM  Products p LEFT JOIN Unit U1 ON [Unit1_ID]=U1.[Unit_ID]
  WHERE p.[Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P,
  (SELECT [P_ID]
   FROM (select s.p_id,s.s_id,s.Y_id,Y.class_id as YClass_id from StoreHouse S
             INNER JOIN Company Y on s.Y_id=Y.Company_id
             inner join storages t on t.storage_id = s.s_id
             where WholeFlag <> 3)S
   WHERE (@nYClassID='' or S.YClass_id like @nYClassID+'%')
    AND ((@Companytable=0)or (S.Y_id in (select [id] from #Companytable)))
    AND ((@Storetable=0) OR (S.s_id in (select [id] from #storagestable)))
  ) BNO 
  WHERE P.[Product_ID]=BNO.[P_ID]
  
  UNION all

  SELECT P.[Product_ID], (2) AS PNO, P.[Class_ID], P.[Code],
  CONVERT(VARCHAR(10), BNO.[InStoreTime], 20) AS [Name], 
  ISNULL(BNO.[Batchno], '') AS [Standard], 
  CONVERT(VARCHAR(10), BNO.[ValidDate], 20) AS [MakeArea],
  CAST(BNO.[Quantity] AS VARCHAR) AS [UnitName1], 
  (0) AS [IniQuantity],
  (0) AS [NowTotal],
  (0) AS [BuyTotal],
  (0) AS [BMSendQTY],
  (0) AS [BMSendCostTotal],
  (0) AS [SaleTotal],
  (0) AS [SMSendQTY],
  (0) AS [SMSendCostTotal]
  
  FROM
  (SELECT p.[Product_ID], p.[Class_ID], p.Serial_Number as [Code], p.[Name], p.[Standard],
          p.[MakeArea], ISNULL(U1.[Name], '') AS [UnitName1]
  FROM  Products P LEFT JOIN Unit U1 ON [Unit1_ID]=U1.[Unit_ID]
  WHERE P.[Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0) P,
  (SELECT s.[P_ID], s.[InStoreTime], s.[Batchno], s.[ValidDate], s.[Quantity]
  FROM (select s.[P_ID], s.[InStoreTime], s.[Batchno], s.[ValidDate], s.[Quantity],s.s_id,s.Y_id,Y.class_id as YClass_id
         from Storehouse  s  INNER JOIN Company Y on s.Y_id=Y.Company_id
         inner join storages t on t.storage_id = s.s_id 
         where WholeFlag <> 3)s
  WHERE (@nYClassID='' or S.YClass_id like @nYClassID+'%')
    AND ((@Companytable=0)or (S.Y_id in (select [id] from #Companytable)))
    AND ((@Storetable=0) OR (S.s_id in (select [id] from #storagestable))) 
                                                                                                 
   ) BNO
  WHERE P.[Product_ID]=BNO.[P_ID]) MainTable
  ORDER BY [Class_ID], [PNO] 
  GOTO Succee

GetListMD:
  SELECT P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard],
         P.[Makearea], P.[MedType],p.[factorycName],
         isnull(sum(B.SalesVolumes),0) AS SalesVolumes,
         isnull(sum(B.SalesAmount),0) AS SalesAmount,
         ISNULL(SUM(B.[Quantity])    ,0)  AS [Quantity],
         ISNULL(SUM(B.[CostTotal])   ,0)  AS [CostTotal],
         ISNULL(SUM(B.[BuyComeQty])  ,0)  AS [BuyComeQty],
         ISNULL(SUM(B.[SaleComeQty]) ,0)  AS [SaleComeQty],
         ISNULL(SUM(B.[TranQty])     ,0)  AS [TranQty],
         ISNULL(SUM(B.[TranComeQty]) ,0)  AS [TranComeQty],
         ISNULL(MAX(B.[CostPrice])   ,0)  AS [CostPrice],
         ISNULL(MAX(B.[ClientName])  ,'') AS [ClientName],
	 ISNULL(MAX(B.[LASTPRICE])   ,0)  AS [LASTPRICE]
  FROM

  (	SELECT p.[Product_ID], p.[Class_ID], p.serial_number as [Code], p.[Name], p.[Child_Number], p.[Standard],
         [Makearea], ISNULL(M.name,'')[MedType],ISNULL(b.AccountComment,'') as factorycName
    FROM Products P
    left   join 
	  (
      select P_id as baseinfo_id,c.name from ProductCategory pc
      left join customCategory c on PComent3 = c.class_id 
      where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
	  )m on p.product_id = m.baseinfo_id
	left join basefactory b on p.factoryc_id = b.CommID
    WHERE p.[Deleted]<>1 AND p.[Parent_ID]=@ParID and IsSplit = 0
  ) P

  LEFT JOIN 
  (	SELECT P.[Class_ID], 
         isnull(SAl.quantity,0) AS SalesVolumes,
         isnull(SAL.total,0) AS SalesAmount,
         ISNULL(SH.[Quantity]    ,0) AS [Quantity],
         ISNULL(SH.[CostTotal]   ,0) AS [CostTotal],
         ISNULL(OB.[BuyComeQty]  ,0) AS [BuyComeQty],
         ISNULL(OB.[SaleComeQty] ,0) AS [SaleComeQty],
         ISNULL(TB.[Quantity]    ,0) AS [TranQty],
         ISNULL(TB.[TranComeQty] ,0) AS [TranComeQty],
         ISNULL(BM.[CostPrice]   ,0) AS [CostPrice],
         ISNULL(BM.[ClientName]  ,'') AS [ClientName],
         ISNULL(vp.[recprice],0) AS [LASTPRICE]

    FROM
      (	SELECT [Product_ID], [Class_ID] 
		FROM Products 
        WHERE [Deleted]<>1 AND [Child_Number]=0 and IsSplit = 0
      ) P
      LEFT JOIN
      (	SELECT s.[P_ID], SUM(s.[Quantity]) AS [Quantity], SUM(s.[CostTotal]) AS [CostTotal]
        FROM  FilterStorehouse(@nloginEID) s
              left join storages ss on s.s_id = ss.storage_id
        WHERE (s.Y_id=@Y_id)   
        AND ((@Storetable=0) OR (s_id in (select [id] from #storagestable)))
        AND ((@CheckFlag = 0) or (ss.qualityFlag <> 2)) and WholeFlag <> 3
        GROUP BY [P_ID]
      ) SH
      ON P.[Product_ID]=SH.[P_ID]
      LEFT JOIN
       ( SELECT s.p_id,sum(CASE when o.billtype=12 THEN s.quantity WHEN o.billtype=13 THEN -s.quantity END) AS quantity ,
                   sum(CASE when o.billtype=12 THEN s.total WHEN o.billtype=13 THEN -s.total END) AS total
                   FROM salemanagebill AS s,billidx AS o,storages t WHERE s.bill_id=o.billid AND s.ss_id = t.storage_id AND s.Y_ID=@Y_id
                   AND  o.billdate BETWEEN @BeginDate AND @EndDate AND t.WholeFlag <> 3 AND
                   o.billtype IN(12,13) GROUP BY s.p_id
        ) SAL
       ON P.[Product_ID]=SAL.[P_ID]
      LEFT JOIN
      (  SELECT ob.[P_ID], 
           ISNULL(SUM(CASE WHEN b.[billtype]=22 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [BuyComeQty], 
           ISNULL(SUM(CASE WHEN b.[billtype]=14 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [SaleComeQty] 
           FROM OrderIDX b, OrderBill ob
           WHERE b.[BillDate] BETWEEN @BeginDate AND @EndDate AND b.[BillID]=ob.[Bill_ID] and B.Y_id=@Y_id
           AND b.[BillStates] IN ('3') 
           GROUP BY ob.[P_ID]
      ) OB
      ON P.[Product_ID]=OB.[P_ID]
      LEFT JOIN
	  (
		 SELECT tb.[P_ID], SUM(tb.[Quantity]) AS [Quantity], SUM(tb.[Quantity]-tb.[ComeQty]) AS [TranComeQty]
		 FROM  
		 (
			select b.billdate,b.billid,b.billstates,b.c_id,Y.Class_id as YClass_id 
			FROM Tranidx b
			LEFT JOIN
			Company Y on Y.company_id=b.c_id
			where Y.deleted=0 and startUse=0
		  ) b,TranBill tb
		  WHERE b.[BillDate] BETWEEN @BeginDate AND @EndDate
			    AND b.[BillID]=tb.[Bill_ID]
			    AND b.[BillStates] IN ('3','0') /*添加状态0，否则请货完成后查不出数据*/
			    AND (@nYClassID='' or B.YClass_id like @nYClassID+'%')
			    AND ((@Companytable=0)or (b.c_id in (select [id] from #Companytable)))
		  GROUP BY tb.[P_ID]
       ) TB
       ON P.[Product_ID]=TB.[P_ID]
       LEFT JOIN
	   (
	      select t.Product_ID,t.BuyPrice as costprice,c.name as 'ClientName' from 
	      (
	      select bh.p_id as 'Product_ID',bh.c_id,bh.BuyPrice from buypricehis bh,(select p_id,MAX(ModifyDate) as 'ModifyDate' from buypricehis group by p_id) mx 
           where  bh.ModifyDate = mx.ModifyDate and bh.p_id = mx.p_id AND bh.Y_ID =@Y_id
           ) t 
           left join clients c on c.client_id = t.c_id
	    ) BM 
		ON P.[Product_ID]=BM.[Product_ID]
		LEFT JOIN 
		( select p_id ,max(recprice)recprice 
		  from Price Group by p_id
		) vp on p.[product_id] = vp.[p_id] 

  ) B
  ON LEFT(B.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard], P.[Makearea], P.[MedType],p.[factorycName]
  GOTO SUCCEE


GetAllMD:

  SELECT P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard],
  P.[Makearea], P.[MedType],p.[factorycName],
  isnull(sum(SAl.quantity),0) AS SalesVolumes,
  isnull(sum(SAL.total),0) AS SalesAmount,
  ISNULL(sum(SH.[Quantity])    ,0)  AS [Quantity],
  ISNULL(sum(SH.[CostTotal])   ,0)  AS [CostTotal],
  ISNULL(SUM(OB.[BuyComeQty])  ,0)  AS [BuyComeQty],
  ISNULL(SUM(OB.[SaleComeQty]) ,0)  AS [SaleComeQty],
  ISNULL(SUM(TB.[Quantity])    ,0)  AS [TranQty],
  ISNULL(SUM(TB.[TranComeQty]) ,0)  AS [TranComeQty],
  isnull(max(BM.CostPrice),0) as [CostPrice],
  ISNULL(max(BM.ClientName),'') AS [ClientName],
  cast(ISNULL(MAX(pr.[recprice])   ,0) as numeric(10,4))  AS [LASTPRICE]
  FROM

  (SELECT p.[Product_ID], p.[Class_ID], p.serial_number as [Code], p.[Name], p.[Child_Number], p.[Standard],
         [Makearea], ISNULL(M.name,'')[MedType],ISNULL(b.AccountComment,'') as factorycName
    FROM Products P
    left   join 
	  (
		select P_id as baseinfo_id,c.name from ProductCategory pc
        left join customCategory c on PComent3 = c.class_id 
        where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
	  )m on p.product_id = m.baseinfo_id
	left join basefactory b on p.factoryc_id = b.CommID
    WHERE p.[Deleted]<>1 AND p.[Child_Number]=0 AND IsSplit = 0) P
  LEFT JOIN
	   (
	      select t.Product_ID,t.BuyPrice as costprice,c.name as 'ClientName' from 
	      (
	      select bh.p_id as 'Product_ID',bh.c_id,bh.BuyPrice from buypricehis bh,(select p_id,MAX(ModifyDate) as 'ModifyDate' from buypricehis group by p_id) mx 
           where  bh.ModifyDate = mx.ModifyDate and bh.p_id = mx.p_id AND bh.Y_ID =@Y_id
           ) t 
           left join clients c on c.client_id = t.c_id
	    ) BM 
		ON P.[Product_ID]=BM.[Product_ID]   

  LEFT JOIN
  (SELECT s.[P_ID], SUM(s.[Quantity]) AS [Quantity], SUM(s.[CostTotal]) AS [CostTotal]
   FROM  FilterStorehouse(@nloginEID) s
		left join storages ss on s.s_id = ss.storage_id
   WHERE (s.Y_id=@Y_id)
   AND ((@Storetable=0) OR (s_id in (select [id] from #storagestable)))
   AND ((@CheckFlag = 0) or (ss.qualityFlag <> 2)) AND WholeFlag <> 3
   GROUP BY s.[P_ID]) SH
  ON P.[Product_ID]=SH.[P_ID]
  LEFT JOIN
   ( SELECT s.p_id,sum(CASE when o.billtype=12 THEN s.quantity WHEN o.billtype=13 THEN -s.quantity END) AS quantity ,
                   sum(CASE when o.billtype=12 THEN s.total WHEN o.billtype=13 THEN -s.total END) AS total
                   FROM salemanagebill AS s,billidx AS o,storages t WHERE s.bill_id=o.billid AND s.ss_id = t.storage_id AND s.Y_ID=@Y_id
                   AND  o.billdate BETWEEN @BeginDate AND @EndDate AND WholeFlag <> 3 AND
                   o.billtype IN(12,13) GROUP BY s.p_id
        ) SAL
   ON P.[Product_ID]=SAL.[P_ID]
  LEFT JOIN
  (SELECT ob.[P_ID], 
   ISNULL(SUM(CASE WHEN b.[billtype]=22 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [BuyComeQty], 
   ISNULL(SUM(CASE WHEN b.[billtype]=14 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [SaleComeQty] 
   FROM OrderIDX b, OrderBill ob
   WHERE B.Y_id=@Y_id and b.[BillDate] BETWEEN @BeginDate AND @EndDate AND b.[BillID]=ob.[Bill_ID]
   AND b.[BillStates] IN ('3') 
   GROUP BY ob.[P_ID]) OB
  ON P.[Product_ID]=OB.[P_ID]


  LEFT JOIN
  (SELECT tb.[P_ID], SUM(tb.[Quantity]) AS [Quantity], SUM(tb.[Quantity]-tb.[ComeQty]) AS [TranComeQty]
   FROM  
     (select b.billdate,b.billid,b.billstates,b.C_id,Y.Class_id as YClass_id 
      FROM Tranidx b
      LEFT JOIN
      Company Y on Y.company_id=b.C_id
      where Y.deleted=0 and startUse=0
      )b, TranBill tb
   WHERE b.[BillDate] BETWEEN @BeginDate AND @EndDate
   AND b.[BillID]=tb.[Bill_ID]
   AND b.[BillStates] IN ('3','0') /*添加状态0，否则请货完成后查不出数据*/
   AND (@nYClassID='' or B.YClass_id like @nYClassID+'%')
   AND ((@Companytable=0)or (b.C_id in (select [id] from #Companytable)))
   GROUP BY tb.[P_ID]) TB
  ON P.[Product_ID]=TB.[P_ID]

  LEFT JOIN 
  
  (select p_id,max(recprice) as recprice  from Price group by p_id) pr on p.[product_id] = pr.[p_id] 
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard], P.[Makearea], P.[MedType],sh.Quantity,sh.CostTotal,
  p.[factorycName],SAl.quantity,SAL.total

  GOTO SUCCEE

GetPartMD:


  SELECT P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard],
  P.[Makearea], P.[MedType],p.[factorycName],
  isnull(sum(B.SalesVolumes),0) AS SalesVolumes,
  isnull(sum(B.SalesAmount),0) AS SalesAmount,
  ISNULL(SUM(B.[Quantity])    ,0)  AS [Quantity],
  ISNULL(SUM(B.[CostTotal])   ,0)  AS [CostTotal],
  ISNULL(SUM(B.[BuyComeQty])  ,0)  AS [BuyComeQty],
  ISNULL(SUM(B.[SaleComeQty]) ,0)  AS [SaleComeQty],
  ISNULL(SUM(B.[TranQty])     ,0)  AS [TranQty],
  ISNULL(SUM(B.[TranComeQty]) ,0)  AS [TranComeQty],
  ISNULL(MAX(B.[CostPrice])   ,0)  AS [CostPrice],
  ISNULL(MAX(B.[ClientName])  ,'') AS [ClientName],
  ISNULL(MAX(B.[LASTPRICE])   ,0)  AS [LASTPRICE]
  FROM

  (SELECT p.[Product_ID], p.[Class_ID], p.serial_number as [Code], p.[Name], p.[Child_Number], p.[Standard],
         [Makearea], ISNULL(M.name,'')[MedType],ISNULL(b.AccountComment,'') as factorycName
    FROM Products P
    left   join 
	  (
       select P_id as baseinfo_id,c.name from ProductCategory pc
       left join customCategory c on PComent3 = c.class_id 
       where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
	  )m on p.product_id = m.baseinfo_id
	left join basefactory b on p.factoryc_id = b.CommID
    WHERE P.[Deleted]<>1 AND p.[Child_Number]=0 AND LEFT(p.[Class_ID], LEN(@ParID))=@ParID AND IsSplit = 0) P

  LEFT JOIN

  (SELECT P.[Class_ID], 
  ISNULL(SAl.quantity,0) AS SalesVolumes,
  ISNULL(SAL.total,0) AS SalesAmount,
  ISNULL(SH.[Quantity]    ,0) AS [Quantity],
  ISNULL(SH.[CostTotal]   ,0) AS [CostTotal],
  ISNULL(OB.[BuyComeQty]  ,0) AS [BuyComeQty],
  ISNULL(OB.[SaleComeQty] ,0) AS [SaleComeQty],
  ISNULL(TB.[Quantity]    ,0) AS [TranQty],
  ISNULL(TB.[TranComeQty] ,0) AS [TranComeQty],
  ISNULL(BM.[CostPrice]   ,0) AS [CostPrice],
  ISNULL(BM.[ClientName]  ,'') AS [ClientName],
  ISNULL(vp.[RECPRICE]    ,0)  AS [LASTPRICE]
  FROM

  (SELECT [Product_ID], [Class_ID] FROM Products 
  WHERE [Deleted]<>1 AND [Child_Number]=0) P
  LEFT JOIN
  (SELECT s.[P_ID], SUM(s.[Quantity]) AS [Quantity], SUM(s.[CostTotal]) AS [CostTotal]
    FROM  FilterStorehouse(@nloginEID) s
		left join storages ss on s.s_id = ss.storage_id
    WHERE (s.Y_id=@Y_id)   
      AND ((@Storetable=0) OR (s_id in (select [id] from #storagestable)))
      AND ((@CheckFlag = 0) or (ss.qualityFlag <> 2)) AND WholeFlag <> 3
   GROUP BY [P_ID]) SH
  ON P.[Product_ID]=SH.[P_ID]
  

  LEFT JOIN
  (SELECT ob.[P_ID], 
   ISNULL(SUM(CASE WHEN b.[billtype]=22 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [BuyComeQty], 
   ISNULL(SUM(CASE WHEN b.[billtype]=14 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [SaleComeQty] 
   FROM OrderIDX b, OrderBill ob
   WHERE B.Y_id=@Y_id and b.[BillDate] BETWEEN @BeginDate AND @EndDate AND b.[BillID]=ob.[Bill_ID]
   AND b.[BillStates] IN ('3') 
   GROUP BY ob.[P_ID]) OB
  ON P.[Product_ID]=OB.[P_ID]
  LEFT JOIN
   ( SELECT s.p_id,sum(CASE when o.billtype=12 THEN s.quantity WHEN o.billtype=13 THEN -s.quantity END) AS quantity ,
                   sum(CASE when o.billtype=12 THEN s.total WHEN o.billtype=13 THEN -s.total END) AS total
                   FROM salemanagebill AS s,billidx AS o,storages t WHERE s.bill_id=o.billid AND s.ss_id = t.storage_id AND s.Y_ID=@Y_id
                   AND  o.billdate BETWEEN @BeginDate AND @EndDate AND WholeFlag <> 3 AND
                   o.billtype IN(12,13) GROUP BY s.p_id
        ) SAL
    ON P.[Product_ID]=SAL.[P_ID]
  LEFT JOIN
  (SELECT tb.[P_ID], SUM(tb.[Quantity]) AS [Quantity], SUM(tb.[Quantity]-tb.[ComeQty]) AS [TranComeQty]
   FROM  
     (select b.billdate,b.billid,b.billstates,b.c_id,Y.Class_id as YClass_id 
      FROM Tranidx b
      LEFT JOIN
      Company Y on Y.company_id=b.c_id
      where Y.deleted=0 and startUse=0
      )b, TranBill tb
   WHERE b.[BillDate] BETWEEN @BeginDate AND @EndDate
   AND b.[BillID]=tb.[Bill_ID]
   AND b.[BillStates] IN ('3','0') /*添加状态0，否则请货完成后查不出数据*/
   AND (@nYClassID='' or B.YClass_id like @nYClassID+'%')
   AND ((@Companytable=0)or (b.c_id in (select [id] from #Companytable)))
   GROUP BY tb.[P_ID]) TB
  ON P.[Product_ID]=TB.[P_ID]
  LEFT JOIN
	   (
	      select t.Product_ID,t.BuyPrice as costprice,c.name as 'ClientName' from 
	      (
	      select bh.p_id as 'Product_ID',bh.c_id,bh.BuyPrice from buypricehis bh,(select p_id,MAX(ModifyDate) as 'ModifyDate' from buypricehis group by p_id) mx 
           where  bh.ModifyDate = mx.ModifyDate and bh.p_id = mx.p_id AND bh.Y_ID =@Y_id
           ) t 
           left join clients c on c.client_id = t.c_id
	    ) BM 
		ON P.[Product_ID]=BM.[Product_ID]

  LEFT JOIN 
  (select p_id ,max(recprice)recprice from Price Group by p_id) vp on p.[product_id] = vp.[p_id] 
  ) B
  ON LEFT(B.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], P.[Code], P.[Name], P.[Child_Number], P.[Standard], P.[Makearea], P.[MedType],p.[factorycName]

  GOTO SUCCEE

Succee:
  RETURN 0
GO
