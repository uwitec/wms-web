

/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_ProBuyfrequency
( @Begindate   varchar(50),
  @Enddate     varchar(50),
  @szCClass_id   varchar(50)='',
  @szEClass_id   varchar(50)='',
  @szSClass_id   varchar(50)='',
  @szYClass_id   varchar(50)='',
  @nloginEID   int=0          
 )	
AS
/*Params Ini begin*/
if @szCClass_id is null  SET @szCClass_id = ''
if @szEClass_id is null  SET @szEClass_id = ''
if @szSClass_id is null  SET @szSClass_id = ''
if @szYClass_id is null  SET @szYClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
 
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

create table #ProductBuyFre
(p_id       int         null,
 Pname      varchar(50) null,
 billid     int         null,
 Alias      varchar(50) null,
 Makearea   varchar(50) null,
 Inputmanname   varchar(50) null,
 InputDate  varchar(50) null,
 Custompro1 varchar(50) null,
 Custompro2 varchar(50) null,
 Custompro3 varchar(50) null,
 Custompro4 varchar(50) null,
 Custompro5 varchar(50) null,
 billdate   varchar(50) null,
 billnumber varchar(50) null,
 billtype   int         null,
 Inputman   int         null,
 cname      varchar(50) null,
 Ename      varchar(50) null,
 Sname      varchar(50) null,
 Supname    varchar(50) null,
 quantity   NUMERIC(25,8)       null, 
 costprice  NUMERIC(25,8)       null,
 buyprice   NUMERIC(25,8)       null, 
 taxprice   NUMERIC(25,8)       null 
)

Insert #ProductBuyFre(p_id, Pname,billid,Alias,Makearea,Inputmanname,InputDate,Custompro1,Custompro2,
                Custompro3,Custompro4,Custompro5,billdate,billnumber,billtype,Inputman,cname,Ename,Sname,Supname,quantity,costprice
                ,buyprice,taxprice)
SELECT YP.p_id,YP.Pname,YP.bill_id,YP.Alias,YP.Makearea,YP.Inputmanname,convert(varchar(10),YP.InputDate,20),YP.Custompro1,YP.Custompro2,
       YP.Custompro3,YP.Custompro4,YP.Custompro5,convert(varchar(10),YP.billdate,20),YP.billnumber,YP.billtype,YP.Inputman,YP.cname,YP.REname,YP.Sname,
       YP.supname,YP.quantity,YP.Costprice,YP.buyprice,YP.taxprice 
FROM  
  (SELECT YPBM.*,P.[Name]as Pname, P.[Alias], P.[Standard], P.[Makearea],p.Inputman as Inputmanname,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5
                ,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(RE.[name],'')REname
                ,isnull(C.Class_id,'')CClass_id,isnull(C.[name],'')Cname
                ,isnull(Sup.Class_id,'')SupClass_id,isnull(Sup.[name],'')Supname
                ,isnull(Y.Class_id,'')YClass_id,isnull(S.Class_id,'')SClass_id
                ,isnull(s.[name],'')sname
      
   FROM
     (SELECT B.billdate,B.billnumber,B.billtype,B.c_id,B.Y_id,B.Inputman,
             bm.bill_id,bm.supplier_id,bm.p_id,BM.ss_id as s_id,BM.RowE_id,bm.quantity,bm.costprice,bm.buyprice,bm.taxprice
      FROM buymanagebill BM
      INNER JOIN 
        (select billdate,billid,billnumber,billtype,c_id,Y_id,Inputman
         from Billidx
         WHERE (billtype in (20,21,35,122,24,25,220,221)
               and billdate between @Begindate and @Enddate)
               and billstates=0
        )B ON B.billid=bm.bill_id
      WHERE BM.aoid in (0,5) and BM.p_id>0 and p_id in (select billid from pdidx)
      )YPBM
      LEFT JOIN products  P  ON YPBM.p_id=p.product_id
      LEFT JOIN Clients   C  ON YPBM.c_id=C.Client_id
      LEFT JOIN Employees RE ON YPBM.Rowe_id=RE.emp_id
      LEFT JOIN storages  S  ON YPBM.s_id=S.storage_id
      LEFT JOIN Company   Y  on YPBM.Y_ID=Y.Company_id
      LEFT JOIN Clients  sup on YPBM.supplier_id=sup.client_id
  )YP
  WHERE     ((@szYClass_id='') or (YP.YClass_id like @szYClass_id+'%'))
        ANd ((@szCClass_id='') OR (YP.CClass_id like @szCClass_id+'%'))
        AND ((@szSClass_id='') or (YP.SClass_id like @szSClass_id+'%'))
        AND ((@szEClass_ID='') or (YP.reclass_id like @szEClass_id+'%'))
        AND (@Companytable=0 or (YP.Y_id in (select [id] from #Companytable)))
        AND (@ClientTable=0 or (YP.c_id in (select [id] from #Clienttable)))
        AND (@Storetable=0 or (YP.s_id in (select [id] from #storagestable)))
        AND (@employeestable=0 OR (YP.RowE_id in (select [id] from #Employeestable)))

  Insert #ProductBuyFre(p_id, Pname,billid,Alias) 
  select p.p_id,'总次数',-1,count(billid)
  from 
  #ProductBuyFre P Group by p_id

select * from #ProductBuyFre order by p_id ,billid desc
GO
