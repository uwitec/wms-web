CREATE	FUNCTION GetNamePath(@nFlag char(1),@szClassid varchar(30))  
RETURNS  varchar(800) 
AS  
BEGIN 
	declare @szPath varchar(800),@i int,@k int,@szName varchar(256),@szClassIdtemp varchar(30),@nLen int
	set @szPath='\'
	set @nLen=6
	if upper(@nFlag)='C' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from clients where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='P' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from products where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='A' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from account where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='S' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from storages where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='E' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from employees where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
        if upper(@nFlag)='Y' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from Company where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='R' 
	begin
		set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*6)
			select @szName=[name] from Region where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end
	if upper(@nFlag)='T'
	begin
	    set @nLen=2
	    set @i=len(@szClassid)/@nLen
		set @k=1
		while @k<@i 
		begin
			set @szClassidtemp=left(@szClassid,@k*2)
			select @szName=[name] from customCategory where class_id=@szClassidtemp
			set @szPath=@szPath+'\'+@szName
			set @k=@k+1
		end
	end 
	
	return(@szPath)
END
GO
