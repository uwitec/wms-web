


CREATE  PROCEDURE ts_c_OfflineAuditP 
(
	@nBillId int,
	@nP_idOut int output,
	@nReturnNumber int output,
	@nMode smallint=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
/*Params Ini end*/
/*-----Costing method------------*/
	declare @AVERAGE smallint
	declare @FIFO    smallint
	declare @LIFO    smallint
	declare @HAND    smallint

	select @AVERAGE=0
	select @FIFO   =1
	select @LIFO   =2
	select @HAND   =3
/*	
	 @Give_NoCost=6,--无成本赠送
     @Give_Cost=7,   --有成本赠送
	 @Sale_NoCost=5  --零成本转销售
	 
	 if (@aoid=@Give_NoCost)or(@aoid=@Sale_NoCost)
		select @nStoreType=3	--库外库，商品成本为零
	 else				
		select @nStoreType=0	--正常库
nCommissionFlag: integer; //0: 实际库存；1：委托代销仓库 2：受托代销；3：借出 4：借进
				*/
/*-------------------*/
	declare @nP_id int,@nS_id int,@nL_id int,@dQuantity NUMERIC(25,8),@dPrice NUMERIC(25,8),@dTotal NUMERIC(25,8),@dStoretype tinyint,@szBatchno varchar(20),@nStoretype int,@tBilldate datetime,
	@nC_id int ,@nA_id int ,@nE_id int,@nCostType int,@nPriceId int,@szPeriod varchar(2),@nSupplier_id int,@nCommissionflag int,@dCostTotalOut NUMERIC(25,8),@nBillType int,@nUnitid int,@nOrderId numeric(10,0)
	declare @tMakeDate datetime,@tValidDate datetime,@tMakeDateTemp datetime,@tValidDateTemp datetime,@dQtyIn NUMERIC(25,8),@dCostTotalIn NUMERIC(25,8),@dCostPriceIn NUMERIC(25,8),
	@dTemp NUMERIC(25,8),@nCostMethod int,@dPricetemp NUMERIC(25,8)
	declare @cUseSameCostMethod char(1),@cUseSalePriceTrace char(1),@cUseBuyPriceTrace char(1),@smb_id numeric(10,0)
	declare @dYsmoney NUMERIC(25,8),@dSsMoney NUMERIC(25,8), @dTaxPrice NUMERIC(25,8), @nPriceTrace INT
	declare @vchtype int,@lastprice NUMERIC(25,8)
    	declare @tInStoreTime datetime
	declare @y_id int
  
  declare @oldcommissionflag int/*解决商品属性导致不能退货的问题 zc 2005-07*/
  declare @cRetailNoBatchno char(1)
	declare @aoid int	/*辅助业务标志*/

	set @vchtype=0
  set @cRetailNoBatchno='0'
	select @vchtype=billtype,@tBilldate=billdate from billidx where billid=@nBillid	
  /*--------得到成本核算法*/
	exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
	if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
		exec ts_getsysvalue 'CostMethod',@nCostMethod out
	/*--------是否使用销价跟踪*/
	exec ts_getsysvalue 'UseBuyTrace',@cUseBuyPriceTrace out 
	exec ts_getsysvalue 'UseSaleTrace',@cUseSalePriceTrace out 

	if (@cUseBuyPriceTrace=1) or(@cUseSalePriceTrace=1) exec ts_getsysvalue 'PriceTrace',@nPriceTrace out 
	/*--------是否使用进价跟踪*/

  /*零售不管理批次*/
	exec ts_getsysvalue 'RetailNoBatchno',@cRetailNoBatchno out 
	select @nReturnNumber=-1
			
/*select * from RetailBill		*/
	declare pdetail_cursor cursor local scroll scroll_locks  for
	select p.p_id,b.sin_id,quantity=(case when (b.billtype=12) then -p.quantity else p.quantity end),
	p.costprice,costtotal=p.costprice*(case when (b.billtype=12) then -p.quantity else p.quantity end),
	storetype=(case when p.aoid in(5,6)then 3 else 0 end),
	p.batchno,p.supplier_id,p.unitid,p.makedate,p.validdate,p.commissionflag,p.location_id,p.unitid,p.saleprice,order_id=0,p.smb_id,
	b.c_id,b.a_id,p.Rowe_id,b.billtype, p.TaxPrice,oldcommissionflag=0,p.aoid,InStoreTime,p.y_id
	from Yretailbill p,YRetailBillIdx b where b.billid=@nBillId and p.bill_id=b.billid and p.p_id>0
	order by p.smb_id
	for update
	open pdetail_cursor

	fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
	@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id
	while @@FETCH_STATUS=0
	begin
    if @nStoreType<>3
    begin
	  if @cUseSameCostMethod='0' /*系统不使用统一成本核算，得到该商品成本算法*/
		set @nCostMethod=dbo.GetcostNo(@nP_id)
	  if @nS_id=0 and @nbilltype not in (30,31,32,33,34,35)
		begin
			set @nReturnnumber=-10
			goto error
		end
      if @nBilltype=12 and @cRetailNoBatchno='1'
		begin
			set @dCosttotalIn=0
			set @nCostMethod=4
		end

			exec ts_c_ModifyP @nBillType,@nCostMethod,@nP_id,@nS_id,@nL_id output,@nStoreType,@nUnitId,@szBatchNo,'',@dQtyIn,@dCostTotalIn,
			@dCostPriceIn output,@tMakeDate output,@tValidDate output,@nSupplier_id output,@nCommissionflag output,@dCostTotalOut output,@nReturnNumber output,@nBillId,@OldCommissionflag,@tInStoreTime output,@y_id
			if @@error<>0 goto error
			if @nReturnNumber<>0 goto error
			
			fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
			@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id
 
    end else if @nStoreType=3/*零成本出入库*/
    begin
  			exec ts_y_ModifyPForNoCost @nP_id,@nS_id,@dQtyIn,@nReturnNumber output,@nBillType,@y_id
  			if @@error<>0 goto error
  			if @nReturnNumber<>0 goto error
  
			fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
			@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id
    end
	end



	Close pdetail_cursor
	deallocate pdetail_cursor
	select @nReturnNumber=0
	select @nP_idOut=0
	return 0



error:
	Close pdetail_cursor
	deallocate pdetail_cursor
	select @nP_IdOut=@nP_id
	return @nReturnNumber
GO
