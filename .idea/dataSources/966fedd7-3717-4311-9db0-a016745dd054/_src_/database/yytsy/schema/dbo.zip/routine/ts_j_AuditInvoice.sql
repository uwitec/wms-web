

CREATE	 PROCEDURE [ts_j_AuditInvoice]
	(
	 @nIVID int,
         @nOpmode int=0 /*0过账　１作废  */
        )
AS 
/*Params Ini begin*/
if @nOpmode is null  SET @nOpmode = 0
/*Params Ini end*/


if exists(select 1 from invoice where invoiceid = @nIVID) goto AuditIV
else 
  if exists (select 1 from invoiceidx where [id] = @nIVID and jsflag = 0)
  begin
    if @nOpmode = 1 
      update invoiceidx set states = 3 where [id] = @nIVID 
    else
      update invoiceidx set states = 2 where [id] = @nIVID
      
    return 0   
  end     
  

AuditIV: 
begin tran 
  declare @nBillid int, @nIVBillType int, @nSign int
  declare @invoicetotal NUMERIC(25,8)
  declare IVcur cursor for
	select distinct billid from invoice where invoiceid = @nIVID
	open IVcur
	fetch next from IVcur into @nBillid
	while @@FETCH_STATUS=0	
	begin
          select @nIVBillType = invoicebilltype from invoiceidx where [id] = @nIVID
 	  if (((@nIVBillType = 0) and (@nOpmode = 0)) or ((@nIVBillType = 1) and (@nOpmode = 1))) 
 	      and (exists(select 1 from billidx where billid = @nBillid and ysmoney > 0))
            set @nSign =1 
          else 
            set @nSign = -1
                  
      select @invoicetotal = isnull(@nSign*(select abs(sum(CurrTotal)) from vw_j_invoice where billid=@nBillid and invoiceid = @nIVID),0)
      if exists(select 1 from billidx where billid = @nBillid and ysmoney < jsinvoicetotal + @invoicetotal) /*判断是否存在开票金额大于应开票金额的单据*/
       begin
           rollback tran
           close IVcur
	       deallocate IVcur
           return -1
       end     
     
        update billidx set jsinvoicetotal = jsinvoicetotal + 
			   @nSign*(select abs(sum(CurrTotal)) from vw_j_invoice where billid=@nBillid and invoiceid = @nIVID)
           	       where billid = @nBillid          

	fetch next from IVcur into @nBillid
	end	
	close IVcur
	deallocate IVcur
  if @nOpmode = 0
    update invoiceidx set states = 2 where [id] = @nIVID  
  else if @nOpmode = 1
    update invoiceidx set states = 3 where [id] = @nIVID  
 
commit tran
return 0
GO
