
/*历史(每天的库存状况)*/

CREATE PROCEDURE TS_X_RepperdayStorehouse
(
  @Y_id	int,					/*机构id*/
  @s_id	int,					/*仓库id*/
  @szL_id Varchar(1000)='',		/*货位id串*/
  @c_id	int,					/*供应商id*/
  @fc_id Varchar(500)='',		/*生产厂家   直接传入名称*/
  @P_ID  INT,					/*商品id*/
  @pname       Varchar(50)='',	/*商品字段*/
  @HL    Varchar(500)='',		/*货龄*/
  @sxqj  Varchar(500)='',		/*失效区间*/
  @SZPtype  Varchar(1000)='',	/*商品类别字串*/
  @EndData    datetime = 0,		/*截止时间*/
  @isBatch  int = 0,			/*是否按批次，0表示否，1表示是*/
  @nloginEID int = 0			/*操作员*/
)
AS

/*Params Ini begin*/
if @Y_id is null  SET @Y_id = 0
if @s_id is null  SET @s_id = 0
if @szL_id is null  SET @szL_id = ''
if @c_id is null  SET @c_id = 0
if @fc_id is null  SET @fc_id = ''
if @pname is null  SET @pname = ''
if @HL is null  SET @HL = ''
if @sxqj is null  SET @sxqj = ''
if @SZPtype is null  SET @SZPtype = ''
if @EndData is null or @EndData = ''  SET @EndData = GETDATE()
if @isBatch is null  SET @isBatch = 0
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/

declare @pby_id int
if @y_id = 0 
	set @pby_id = 2
else
	set @pby_id = @y_id
DECLARE @SQL 	VARCHAR(8000)
DECLARE @szP_Id VARCHAR(100)
DECLARE @szS_Id VARCHAR(100)
DECLARE @szYClassID varchar(100)
Declare @Companytable INTEGER,@Storetable integer
create table #Companytable([id] int)
create table #storagestable([id] int)

  /*新自定义类别的解析，获取过滤的商品id*/
  DECLARE @cColName VARCHAR(100)
  set @cColName = ''
  CREATE TABLE #TmpP ([pid] [int] NOT NULL DEFAULT(0))
  IF @SZPtype <> '' 
  BEGIN   
    DECLARE @info_ID INT
    DECLARE @classid varchar(100)
    DECLARE @szSql varchar(2000)
    SELECT @info_ID = Category_id 
    FROM customCategory WHERE ID  in (select type  from DecodeStr(@SZPtype))
    
	SELECT @classid = dbo.GetCateClassids(@SZPtype)
    
    IF @classid IS NULL SET @classid = ''
    IF LEN(@classid) > 0
    SET @classid = LEFT(@classid,LEN(@classid)-1)
    
    set @cColName = dbo.GetColName(@info_ID,'ProductCategory')  
    set @szSql =  'INSERT INTO #TmpP(pid) ' +
		'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @cColName + 
		' in (select type  from DecodeStr(''' +@classid +'''))'  
	exec (@szSql)        
  END

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


/*货龄条件的转化*/
DECLARE @QJ1 int 
DECLARE @QJ2 int 
DECLARE @QJ3 int 
DECLARE @QJ4 int 
DECLARE @QJ5 int 
DECLARE @QJ6 int 
DECLARE @QJ7 int 

select @QJ1= CHARINDEX('一个月以内',@HL)
select @QJ2 = CHARINDEX('1-3个月',@HL) 
select @QJ3 = CHARINDEX('3-6个月',@HL) 
select @QJ4 = CHARINDEX('6-12个月',@HL)
select @QJ5 = CHARINDEX('12-24个月',@HL) 
select @QJ6 = CHARINDEX('24-36个月',@HL)    
set @QJ7 = CHARINDEX('36月以上',@HL)
 


/*失效期条件的转化*/
DECLARE @SXQJ1 int 
DECLARE @SXQJ2 int 
DECLARE @SXQJ3 int 
DECLARE @SXQJ4 int 
DECLARE @SXQJ5 int 
DECLARE @SXQJ6 int 
DECLARE @SXQJ7 int 
DECLARE @SXQJ8 int 
DECLARE @SXQJ9 int 

select @SXQJ1 = CHARINDEX('不明确失效期',@sxqj) 
select @SXQJ2 = CHARINDEX('30天内到期',@sxqj) 
select @SXQJ3 = CHARINDEX('30-60天到期',@sxqj)
select @SXQJ4 = CHARINDEX('60-90天到期',@sxqj)  
select @SXQJ5 =  CHARINDEX('90-180天到期',@sxqj)
select @SXQJ6 = CHARINDEX('180-360天到期',@sxqj)    
select @SXQJ7 = CHARINDEX('360-720天到期',@sxqj)
select @SXQJ8 = CHARINDEX('大于720天到期',@sxqj) 
select @SXQJ9 = CHARINDEX('已失效',@sxqj) 

IF exists (SELECT * FROM dbo.sysobjects WHERE ID = object_id(N'[dbo].[##temp]') AND OBJECTPROPERTY(ID, N'IsUserTABLE') = 1)
  DROP TABLE [dbo].[##temp1]

if @EndData < CONVERT(varchar(10),GETDATE(),121)   /*取历史库存*/
begin
	select [location_id],[s_id],[p_id],[supplier_id],sum(pd.[quantity]) as [quantity],[costprice],sum([costtotal]) as [costtotal],[batchno] ,[makedate] ,[instoretime],[validdate],pd.[Y_ID],[scomment],[batchprice],[costtaxprice],sum([costtaxtotal]) as [costtaxtotal],[factoryid],pd.[taxrate],@EndData as [ModifyDate] 
	into #pdetail
	from productdetail pd,billidx b
	where pd.billid=b.billid and b.billstates = 0  /*XXX这儿应该是单据状态的判断，只统计完成的单据 --xzdong-2016-10-09-TFS-ZD41512-修改库存状况查询选择总部且时间不是当天时记录为空的问题*/
	and b.billdate<=@EndData
	group by [location_id],[s_id],[p_id],[supplier_id],[costprice],[batchno] ,[makedate] ,[instoretime],[validdate],pd.[Y_ID],[scomment],[batchprice],[costtaxprice],[factoryid],pd.[taxrate]

	select [location_id],[s_id],[p_id],[supplier_id],sum(a.[quantity]) as [quantity],[costprice],sum([costtotal]) as [costtotal],[batchno] ,[makedate] ,[instoretime],[validdate],[Y_ID],[scomment],[batchprice],[costtaxprice],sum([costtaxtotal]) as [costtaxtotal],[factoryid],[taxrate],@EndData as [ModifyDate] 
	into #pdetail1     /*这儿就是历史库存*/
	from 
		(	select [location_id],[s_id],[p_id],[supplier_id],[quantity],[costprice],[costtotal],[batchno] ,[makedate] ,[instoretime],[validdate],[Y_ID],[scomment],[batchprice],[costtaxprice],[costtaxtotal],[factoryid],[taxrate] from #pdetail a 
			union all 
			select [location_id],[s_id],[p_id],[supplier_id],[quantity],[costprice],[costtotal],[batchno] ,[makedate] ,[instoretime],[validdate],[Y_ID],[scomment],[batchprice],[costtaxprice],[costtaxtotal],[factoryid],[taxrate] from storehouseini 
		) a	
	group by  [location_id],[s_id],[p_id],[supplier_id],[costprice],[batchno] ,[makedate] ,[instoretime],[validdate],[Y_ID],[scomment],[batchprice],[costtaxprice],[factoryid],[taxrate]
	having sum(a.quantity)>0

end

if @EndData >= CONVERT(varchar(10),GETDATE(),121)
begin
  if @isBatch = 0  /*不按批次（只按商品和需要显示的列作为分组条件）*/
  begin
  /*xzdong-2016-11-11-TFS42746-BB.（科开）库存状况查询（新做的报表），增加机构名称列*/
  select com.name as companyname,com.company_id as companyid, A.* into ##temp1 from 
    (SELECT sp.Y_ID, sp.p_id ,sp.batchno,sum(sp.quantity) quantity,cast (rt.name as NUMERIC(25,8)) as taxrate,isnull(sum(sp.costtaxprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.costtaxprice)) costtaxprice,sum(TaxTotla) TaxTotla,
	/*isnull(sum(sp.costprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.costprice)) costprice,sum(sp.Totla) Totla,sum(sp.Taxmoney) Taxmoney,*/
	isnull(sum(TaxTotla)/nullif(SUM(sp.quantity),0)/(1+(cast (rt.name as NUMERIC(25,8))/100)),0) costprice,
	isnull(sum(Totla), 0) Totla,
	sum(Taxmoney) Taxmoney,
	pr.code,pr.name,pr.alias,pr.comment,pr.standard,pr.Factory,pr.makearea,pr.medtype,pr.UNIT1,pr.Unit1_id,isnull(sum(sp.retailprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.retailprice)) retailprice,sum(sp.RetailTotal) RetailTotal,
	 /*s.location_id,*/sp.locname,pl.Supplier_id,sp.cname,sum(sp.RetailTotal) - sum(sp.TaxTotla) as ml, (sum(sp.RetailTotal) - sum(sp.TaxTotla)) / nullif(sum(sp.RetailTotal), 0) * 100 as mlRate,
	 sum(sp.BHGqty) BHGqty,sum(sp.DCKQTY) DCKQTY, sp.sxq ,sp.HL, sp.validdate  
	 from vw_b_Products pr left join productbalance pl on pr.p_id = pl.p_id and pl.Y_id = @pby_id
	                       left join clients cs on pl.Supplier_id = cs.client_id
	                       left join (select P_id as baseinfo_id,name from ProductCategory p  
                                      left join customCategory c on p.PComent2 = c.class_id
                                      and c.deleted = 0 and Child_Number = 0 and Category_id = 2
									  )rt on pr.p_id = rt.baseinfo_id
	 left join (
	SELECT s.Y_ID, s.p_id,s.batchno as batchno,sum(s.quantity) as quantity,s.taxrate,isnull(sum(s.costtaxtotal)/nullif(sum(s.quantity),0),max(s.costtaxprice)) costtaxprice,sum(s.costtaxtotal) as TaxTotla,
	 isnull(sum(s.costtaxtotal / (1 + s.taxrate))/nullif(sum(s.quantity),0),max(s.costprice)) costprice ,sum(s.costtaxtotal / (1 + s.taxrate)) as Totla,sum(s.costtaxtotal / (1 + s.taxrate) * s.taxrate) as Taxmoney,
	 p.code,p.name,p.alias,p.comment,p.standard,p.Factory,' ' as makearea,p.medtype,p.UNIT1,p.Unit1_id,isnull(sum(r.retailprice* s.quantity)/nullif(sum(s.quantity),0),max(r.retailprice)) retailprice,sum(r.retailprice* s.quantity) as RetailTotal,
	 /*s.location_id,*/isnull(l.loc_name,'') as locname,0 as supplier_id,c.name as cname,
	 case when st.qualityFlag = 0 then 0 when st.qualityFlag in (1,2) then sum(s.quantity) end as BHGqty,
	 sum(ISNULL(SM.dckqty,0)) AS DCKQTY ,nullif(s.validdate,0) as validdate, 
	 case when s.validdate = '' or s.validdate = 0 then '不明确失效期' 
		  when cast(s.validdate as datetime) < GETDATE() then '已失效'  when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
		  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
		  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
		  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
		  end as sxq ,s.instoretime,
	 case when cast(DATEADD(DAY,1080,s.instoretime) as datetime) < GETDATE() then '36个月以上' when cast(DATEADD(DAY,720,s.instoretime) as datetime) < GETDATE() then '24-36个月'
		  when cast(DATEADD(DAY,360,s.instoretime) as datetime) < GETDATE() then '12-24个月' when cast(DATEADD(DAY,180,s.instoretime) as datetime) < GETDATE() then '6-12个月'
	      when cast(DATEADD(DAY,90,s.instoretime) as datetime) < GETDATE() then '3-6个月' when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '1-3个月' 
		  when cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE() then '一个月以内'	    
		  end as HL       
	 FROM FilterStorehouse(@nloginEID) S 
	 left join  vw_b_Products p on s.p_id = p.p_id
					   left join price r on p.p_id = r.p_id and p.Unit1_id = r.u_id
					   left join location l on s.location_id = l.loc_id
					   left join clients c on s.supplier_id = c.client_id
					   left join storages st on s.s_id = st.storage_id
					   left join (
							select o.p_id,validdate,Instoretime,/*ss_id,costprice,batchno,makedate,supplier_id,location_id,o.Y_ID,factoryid,*/SUM(o.quantity) as dckqty 
							from OrderBill o left join orderidx dx on o.bill_id = dx.billid
							where billtype in (14,154) and billstates <> 0
							group by o.p_id,validdate,Instoretime/*, ss_id,costprice,batchno,makedate,supplier_id,location_id,o.Y_ID,factoryid*/
							) as SM 
						  on S.p_id = SM.p_id /*AND S.s_id = SM.ss_id AND S.costprice = SM.costprice AND S.batchno = SM.batchno AND S.makedate = SM.makedate */
								AND  S.validdate = SM.validdate /*AND  S.supplier_id = SM.supplier_id AND S.location_id = SM.location_id AND S.Y_ID = SM.Y_ID */
								AND  S.instoretime = SM.Instoretime /* AND  S.factoryid = SM.factoryid  --批次条件*/

		where (@Y_id = 0 or s.Y_ID = @Y_id) AND
			  (@s_id = 0 or s.s_id = @s_id) AND
			  (@c_id = 0 or s.supplier_id = @c_id) AND
			  (@fc_id = '' or p.Factory = @fc_id) AND
			  (@P_ID = 0 or s.p_id = @P_ID) AND
			  (@pname = '' or P.name + p.alias + p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND	
			  ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
			  ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  )AND 
			   			  
			  (@szL_id = '0' OR S.location_id in (select CAST(szTYPE as int) as L_id from dbo.DecodeToStr(@szL_id)))	AND
		      (@SZPtype = '' or p.p_id in (SELECT PID FROM #TmpP))
		      /*(@HL = '' or ) AND	*/
		      /*(@sxqj = '' or )*/
		group by s.p_id,p.code, p.name,p.alias,p.comment, p.standard,p.Factory,/*p.makearea,*/p.medtype,p.UNIT1,p.Unit1_id,s.y_id, s.taxrate,
				 qualityFlag,s.supplier_id, c.name,s.instoretime,s.validdate,l.loc_name,s.batchno
	) as sp on pr.p_id = sp.p_id	
	WHERE /*pr.deleted <> 1 and*/ pr.IsSplit  = 0 and pr.pclass_id <> '000000' and pr.child_number=0
	group by sp.p_id ,sp.batchno,sp.Y_ID, cast (rt.name as NUMERIC(25,8)),
	 pr.code, pr.name,pr.alias,pr.comment,pr.standard,pr.Factory,pr.makearea,pr.medtype,pr.UNIT1,pr.Unit1_id,
	 sp.locname,pl.Supplier_id,cs.name, sp.sxq ,sp.HL,sp.cname, sp.validdate ,rt.name 	 
	/*order by sp.p_id--,s.validdate,s.instoretime*/
	) as A
	/*xzdong-2016-11-11-TFS42746-BB.（科开）库存状况查询（新做的报表），增加机构名称列*/
	inner join company com on com.company_id = A.Y_ID
	
    goto Succee1	
  end
  else if @isBatch = 1
  begin	
 	SELECT com.name as companyname, com.company_id as companyid, s.p_id,s.batchno,s.quantity,s.taxrate * 100 as taxrate,s.costtaxprice,s.costtaxtotal as TaxTotla,
	/* s.costprice,s.costtotal as Totla,(s.costtaxprice*s.quantity - s.costprice* s.quantity) as Taxmoney,*/
	 s.costtaxtotal/(1+s.taxrate)/s.quantity as costprice,s.costtaxtotal/(1+s.taxrate) as Totla,
	 s.costtaxtotal/ (1 + s.taxrate) *s.taxrate as Taxmoney,
	 p.code, p.name,p.alias,p.comment,p.standard,p.Factory,p.makearea,p.medtype,p.UNIT1,p.Unit1_id,r.retailprice,r.retailprice* s.quantity as RetailTotal,
	 s.location_id,isnull(l.loc_name,'') as locname,s.supplier_id,isnull(c.name,'') as cname,
	 r.retailprice* s.quantity - s.costtaxprice*s.quantity as ml, (r.retailprice* s.quantity - s.costtaxprice*s.quantity) / nullif(r.retailprice* s.quantity, 0) * 100 as mlRate,
	 case when st.qualityFlag = 0 then 0 when st.qualityFlag in (1,2) then s.quantity end as BHGqty,
	 ISNULL(SM.dckqty,0) AS DCKQTY,nullif(s.validdate,0) as validdate, 
	 case when s.validdate = '' or s.validdate = 0 then '不明确失效期' 
		  when cast(s.validdate as datetime) < GETDATE() then '已失效'  when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
		  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
		  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
		  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
		  end as sxq ,s.instoretime,
	 case when cast(DATEADD(DAY,1080,s.instoretime) as datetime) < GETDATE() then '36个月以上' when cast(DATEADD(DAY,720,s.instoretime) as datetime) < GETDATE() then '24-36个月'
		  when cast(DATEADD(DAY,360,s.instoretime) as datetime) < GETDATE() then '12-24个月' when cast(DATEADD(DAY,180,s.instoretime) as datetime) < GETDATE() then '6-12个月'
	      when cast(DATEADD(DAY,90,s.instoretime) as datetime) < GETDATE() then '3-6个月' when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '1-3个月' 
		  when cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE() then '一个月以内'	    
		  end as HL  
	into ##temp2   
	 FROM FilterStorehouse(@nloginEID) S left join  vw_b_Products p on s.p_id = p.p_id
	                   inner join company com on com.company_id = s.Y_ID
					   left join price r on p.p_id = r.p_id and p.Unit1_id = r.u_id	
					   left join location l on s.location_id = l.loc_id
					   left join clients c on s.supplier_id = c.client_id
					   left join storages st on s.s_id = st.storage_id
					   left join (
							select o.p_id,ss_id,costprice,batchno,makedate,validdate,Instoretime,supplier_id,location_id,o.Y_ID,factoryid,SUM(o.quantity) as dckqty 
							from OrderBill o left join orderidx dx on o.bill_id = dx.billid
							where billtype in (14,154) and billstates <> 0
							group by o.p_id,ss_id,costprice,batchno,makedate,validdate,Instoretime,supplier_id,location_id,o.Y_ID,factoryid
							) as SM 
						  on S.p_id = SM.p_id AND S.s_id = SM.ss_id AND S.costprice = SM.costprice AND S.batchno = SM.batchno AND S.makedate = SM.makedate 
								AND  S.validdate = SM.validdate AND  S.supplier_id = SM.supplier_id AND S.location_id = SM.location_id AND S.Y_ID = SM.Y_ID 
								AND  S.instoretime = SM.Instoretime  AND  S.factoryid = SM.factoryid  /*批次条件*/

		where (@Y_id = 0 or s.Y_ID = @Y_id) AND
			  (@s_id = 0 or s.s_id = @s_id) AND
			  (@c_id = 0 or s.supplier_id = @c_id) AND
			  (@fc_id = '' or p.Factory = @fc_id) AND
			  (@P_ID = 0 or s.p_id = @P_ID) AND
			  (@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND
			  ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
			  ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND			  
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  )AND 			 
		    
			  (@szL_id = '0' OR S.location_id in (select CAST(szTYPE as int) as L_id from dbo.DecodeToStr(@szL_id)))	AND		
		      (@SZPtype = '' or p.p_id in (SELECT PID FROM #TmpP)) /*AND*/
		      /*(@HL = '' or ) AND	*/
		      /*(@sxqj = '' or )*/
		order by s.p_id,s.validdate,s.instoretime	
		
	goto Succee2 
  end					
end
else begin
  if @isBatch = 0  /*不按批次（只按商品和需要显示的列作为分组条件）*/
  begin
  /*xzdong-2016-11-11-TFS42746-BB.（科开）库存状况查询（新做的报表），增加机构名称列*/
  select com.name as companyname,com.company_id as companyid, A.* into ##temp3 from( 
    SELECT sp.p_id,sp.batchno,sp.Y_ID,sum(sp.quantity) quantity,cast (rt.name as NUMERIC(25,8)) as taxrate,isnull(sum(sp.costtaxprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.costtaxprice)) costtaxprice,sum(TaxTotla) TaxTotla,
	/*isnull(sum(sp.costprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.costprice)) costprice,sum(sp.Totla) Totla,sum(sp.Taxmoney) Taxmoney,*/
	isnull(sum(TaxTotla)/nullif(SUM(sp.quantity),0)/(1+(cast (rt.name as NUMERIC(25,8))/100)),0) costprice,
	isnull(sum(Totla), 0) Totla,
	sum(Taxmoney) Taxmoney,
	 pr.code, pr.name,pr.alias,pr.comment,pr.standard,pr.Factory,pr.makearea,pr.medtype,pr.UNIT1,pr.Unit1_id,isnull(sum(sp.retailprice * sp.quantity)/nullif(SUM(sp.quantity),0),max(sp.retailprice)) retailprice,sum(sp.RetailTotal) RetailTotal,
	 /*s.location_id,*/sp.locname,pl.Supplier_id,sp.cname,sum(sp.RetailTotal) - sum(sp.TaxTotla) as ml, (sum(sp.RetailTotal) - sum(sp.TaxTotla)) / nullif(sum(sp.RetailTotal), 0) * 100 as mlRate,
	 sum(sp.BHGqty) BHGqty,sum(sp.DCKQTY) DCKQTY, sp.sxq ,sp.HL, sp.validdate 
	 from vw_b_Products pr left join productbalance pl on pr.p_id = pl.p_id
	                       left join clients cs on pl.Supplier_id = cs.client_id
	                       left join (select P_id as baseinfo_id,name from ProductCategory p  
                                      left join customCategory c on p.PComent2 = c.class_id
                                      and c.deleted = 0 and Child_Number = 0 and Category_id = 2
									  )rt on pr.p_id = rt.baseinfo_id
	 left join (
	SELECT s.p_id,s.batchno as batchno,s.Y_ID,sum(s.quantity) as quantity,s.taxrate,isnull(sum(s.costtaxtotal)/nullif(sum(s.quantity),0),max(s.costtaxprice)) costtaxprice,sum(s.costtaxtotal) as TaxTotla,
	 isnull(sum(s.costtaxtotal / (1 + s.taxrate))/nullif(sum(s.quantity),0),max(s.costprice)) costprice ,sum(s.costtaxtotal / (1 + s.taxrate)) as Totla,sum(s.costtaxtotal / (1 + s.taxrate) * s.taxrate) as Taxmoney,
	 p.code, p.name,p.alias,p.comment,p.standard,p.Factory,' ' as makearea,p.medtype,p.UNIT1,p.Unit1_id,isnull(sum(r.retailprice* s.quantity)/nullif(sum(s.quantity),0),max(r.retailprice)) retailprice,sum(r.retailprice* s.quantity) as RetailTotal,
	 /*s.location_id,*/isnull(l.loc_name,'') as locname,0 as supplier_id,c.name as cname,
	 case when st.qualityFlag = 0 then 0 when st.qualityFlag in (1,2) then sum(s.quantity) end as BHGqty,
	 sum(ISNULL(SM.dckqty,0)) AS DCKQTY,nullif(s.validdate,0) as validdate, 
	 case when s.validdate = '' or s.validdate = 0 then '不明确失效期' 
		  when cast(s.validdate as datetime) < GETDATE() then '已失效'  when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
		  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
		  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
		  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
		  end as sxq ,s.instoretime,
	 case when cast(DATEADD(DAY,1080,s.instoretime) as datetime) < GETDATE() then '36个月以上' when cast(DATEADD(DAY,720,s.instoretime) as datetime) < GETDATE() then '24-36个月'
		  when cast(DATEADD(DAY,360,s.instoretime) as datetime) < GETDATE() then '12-24个月' when cast(DATEADD(DAY,180,s.instoretime) as datetime) < GETDATE() then '6-12个月'
	      when cast(DATEADD(DAY,90,s.instoretime) as datetime) < GETDATE() then '3-6个月' when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '1-3个月' 
		  when cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE() then '一个月以内'	    
		  end as HL      
	 FROM #pdetail1 S left join  vw_b_Products p on s.p_id = p.p_id
					   left join price r on p.p_id = r.p_id and p.Unit1_id = r.u_id
					   left join location l on s.location_id = l.loc_id
					   left join clients c on s.supplier_id = c.client_id
					   left join storages st on s.s_id = st.storage_id
					   left join (
							select o.p_id,validdate,Instoretime,/*ss_id,costprice,batchno,makedate,supplier_id,location_id,o.Y_ID,factoryid,*/SUM(o.quantity) as dckqty 
							from OrderBill o left join orderidx dx on o.bill_id = dx.billid
							where billtype in (14,154) and billstates <> 0
							group by o.p_id,validdate,Instoretime/*, ss_id,costprice,batchno,makedate,supplier_id,location_id,o.Y_ID,factoryid*/
							) as SM 
						  on S.p_id = SM.p_id /*AND S.s_id = SM.ss_id AND S.costprice = SM.costprice AND S.batchno = SM.batchno AND S.makedate = SM.makedate */
								AND  S.validdate = SM.validdate /*AND  S.supplier_id = SM.supplier_id AND S.location_id = SM.location_id AND S.Y_ID = SM.Y_ID */
								AND  S.instoretime = SM.Instoretime /* AND  S.factoryid = SM.factoryid  --批次条件*/
		where (s.ModifyDate = @EndData) AND
			  (@Y_id = 0 or s.Y_ID = @Y_id) AND
			  (@s_id = 0 or s.s_id = @s_id) AND
			  (@c_id = 0 or s.supplier_id = @c_id) AND
			  (@fc_id = '' or p.Factory = @fc_id) AND
			  (@P_ID = 0 or s.p_id = @P_ID) AND
			  (@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND
			  ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
			  ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND			  
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  )AND 			  
				  
			  (@szL_id = '0' OR S.location_id in (select CAST(szTYPE as int) as L_id from dbo.DecodeToStr(@szL_id)))	AND		
		      (@SZPtype = '' or p.p_id in (SELECT PID FROM #TmpP)) /*AND*/
		      /*(@HL = '' or ) AND	*/
		      /*(@sxqj = '' or )*/
		group by s.p_id,p.code, p.name,p.alias,p.comment,p.standard,p.Factory,/*p.makearea,*/p.medtype,p.UNIT1,p.Unit1_id,s.Y_ID,s.taxrate, 				 
		qualityFlag,s.supplier_id, c.name,s.validdate,s.instoretime,l.loc_name,s.batchno
	) as sp on pr.p_id = sp.p_id
	WHERE /*pr.deleted <> 1 and*/ pr.IsSplit  = 0 and pr.pclass_id <> '000000' and pr.child_number=0
	group by sp.p_id ,sp.batchno,sp.y_id,cast (rt.name as NUMERIC(25,8)),
	 pr.code, pr.name,pr.alias,pr.comment,pr.standard,pr.Factory,pr.makearea,pr.medtype,pr.UNIT1,pr.Unit1_id,
	 sp.locname,pl.Supplier_id,cs.name, sp.sxq ,sp.HL,sp.cname,sp.validdate ,rt.name		 
	/*order by sp.p_id--,s.validdate,s.instoretime*/
	) as A
	/*xzdong-2016-11-11-TFS42746-BB.（科开）库存状况查询（新做的报表），增加机构名称列*/
	inner join company com on com.company_id = A.Y_ID
 
  goto Succee3	
  end
  else if @isBatch = 1
  begin
	SELECT com.name as companyname, com.company_id as companyid, s.p_id,s.batchno,s.quantity,s.taxrate * 100 as taxrate,s.costtaxprice,s.costtaxprice*s.quantity as TaxTotla,
	/* s.costprice,s.costtotal as Totla,(s.costtaxprice*s.quantity - s.costprice* s.quantity) as Taxmoney,*/
	 s.costtaxtotal/(1+s.taxrate)/s.quantity as costprice,s.costtaxtotal/(1+s.taxrate) as Totla,
	 s.costtaxtotal/ (1 + s.taxrate) *s.taxrate as Taxmoney,
	 p.code, p.name,p.alias,p.comment,p.standard,p.Factory,p.makearea,p.medtype,p.UNIT1,p.Unit1_id,r.retailprice,r.retailprice* s.quantity as RetailTotal,
	 s.location_id,isnull(l.loc_name,'') as locname,s.supplier_id,isnull(c.name,'') as cname,
	 r.retailprice* s.quantity - s.costtaxprice*s.quantity as ml, (r.retailprice* s.quantity - s.costtaxprice*s.quantity) / nullif(r.retailprice* s.quantity, 0) * 100 as mlRate,
	 case when st.qualityFlag = 0 then 0 when st.qualityFlag in (1,2) then s.quantity end as BHGqty,
	 ISNULL(SM.dckqty,0) AS DCKQTY,nullif(s.validdate,0) as validdate, 
	 case when s.validdate = '' or s.validdate = 0 then '不明确失效期' 
		  when cast(s.validdate as datetime) < GETDATE() then '已失效' 	when cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() then '30天内到期'
		  when cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() then '30-60天内到期' when cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() then '60-90天内到期'
		  when cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() then '90-180天内到期'  when cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() then '180-360天内到期'
		  when cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() then '360-720天内到期' when cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() then '大于720天到期' 
		  end as sxq ,s.instoretime,
	 case when cast(DATEADD(DAY,1080,s.instoretime) as datetime) < GETDATE() then '36个月以上' when cast(DATEADD(DAY,720,s.instoretime) as datetime) < GETDATE() then '24-36个月'
		  when cast(DATEADD(DAY,360,s.instoretime) as datetime) < GETDATE() then '12-24个月' when cast(DATEADD(DAY,180,s.instoretime) as datetime) < GETDATE() then '6-12个月'
	      when cast(DATEADD(DAY,90,s.instoretime) as datetime) < GETDATE() then '3-6个月' when cast(DATEADD(DAY,30,s.instoretime) as datetime) < GETDATE() then '1-3个月' 
		  when cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE() then '一个月以内'	    
		  end as HL 
	into ##temp4   
	 FROM #pdetail1 S left join  vw_b_Products p on s.p_id = p.p_id
	                   inner join company com on com.company_id = s.Y_ID
					   left join price r on p.p_id = r.p_id and p.Unit1_id = r.u_id	
					   left join location l on s.location_id = l.loc_id
					   left join clients c on s.supplier_id = c.client_id
					   left join storages st on s.s_id = st.storage_id
					   left join (
							select o.p_id,ss_id,costprice,batchno,makedate,validdate,Instoretime,supplier_id,location_id,o.Y_ID,factoryid,SUM(o.quantity) as dckqty 
							from OrderBill o left join orderidx dx on o.bill_id = dx.billid
							where billtype in (14,154) and billstates <> 0
							group by o.p_id,ss_id,costprice,batchno,makedate,validdate,Instoretime,supplier_id,location_id,o.Y_ID,factoryid
							) as SM 
						  on S.p_id = SM.p_id AND S.s_id = SM.ss_id AND S.costprice = SM.costprice AND S.batchno = SM.batchno AND S.makedate = SM.makedate 
								AND  S.validdate = SM.validdate AND  S.supplier_id = SM.supplier_id AND S.location_id = SM.location_id AND S.Y_ID = SM.Y_ID 
								AND  S.instoretime = SM.Instoretime  AND  S.factoryid = SM.factoryid  /*批次条件*/
		where (s.ModifyDate = @EndData) AND
			  (@Y_id = 0 or s.Y_ID = @Y_id) AND
			  (@s_id = 0 or s.s_id = @s_id) AND
			  (@c_id = 0 or s.supplier_id = @c_id) AND
			  (@fc_id = '' or p.Factory = @fc_id) AND
			  (@P_ID = 0 or s.p_id = @P_ID) AND
			  (@pname = '' or P.name + p.alias+ p.standard + p.pinyin LIKE '%' +@pname +'%' ) AND	
			  ((@Storetable=0) or (s.s_id in (select [id] from #storagestable))) AND
			  ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable))) AND			  
			 ( (@HL = '') or    /*货龄*/
			 (@QJ1 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ2 > 0 and cast(DATEADD(DAY,30,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,90,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ3 > 0 and cast(DATEADD(DAY,90,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,180,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ4 > 0 and cast(DATEADD(DAY,180,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,360,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ5 > 0 and cast(DATEADD(DAY,360,s.instoretime) as datetime) <= GETDATE() and  cast(DATEADD(DAY,720,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ6 > 0 and cast(DATEADD(DAY,720,s.instoretime) as datetime) <= GETDATE() and cast(DATEADD(DAY,1080,s.instoretime) as datetime) > GETDATE()) or
			 (@QJ7 > 0 and cast(DATEADD(DAY,1080,s.instoretime) as datetime) <= GETDATE() )) AND
			 ( (@sxqj = '') or   /*失效区间*/
			   (@SXQJ1 > 0 and s.validdate = 0) or 
			   (@SXQJ2 > 0 and cast(DATEDIFF(DAY,30,s.validdate) as datetime) < GETDATE() and cast(s.validdate as datetime) > GETDATE()) or 
			   (@SXQJ3 > 0 and cast(DATEDIFF(DAY,60,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,30,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ4 > 0 and cast(DATEDIFF(DAY,90,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,60,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ5 > 0 and cast(DATEDIFF(DAY,180,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,90,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ6 > 0 and cast(DATEDIFF(DAY,360,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,180,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ7 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) < GETDATE() and cast(DATEDIFF(DAY,360,s.validdate) as datetime) > GETDATE()) or 
			   (@SXQJ8 > 0 and cast(DATEDIFF(DAY,720,s.validdate) as datetime) > GETDATE() ) or 
			   (@SXQJ9 > 0 and s.validdate > 0 and cast(s.validdate as datetime) < GETDATE())  )AND 
			   			  
	 		  (@szL_id = '0' OR S.location_id in (select CAST(szTYPE as int) as L_id from dbo.DecodeToStr(@szL_id)))	AND	
		      (@SZPtype = '' or p.p_id in (SELECT PID FROM #TmpP)) /*AND*/
		      /*(@HL = '' or ) AND	*/
		      /*(@sxqj = '' or )*/
		order by s.p_id,s.validdate,s.instoretime
		
	goto Succee4	  
  end
end

Succee1:
    if (@Y_id = 0) and (@s_id	= 0) and (@szL_id ='0') and (@c_id = 0) and (@fc_id ='') and (@P_ID = 0) and (@pname ='') and (@HL ='') and (@sxqj ='') and (@SZPtype ='')
      select * from ##temp1
    else
      select * from ##temp1 where quantity > 0 
	DROP TABLE ##temp1
	  RETURN 0
Succee2:
    if (@Y_id = 0) and (@s_id	= 0) and (@szL_id ='0') and (@c_id = 0) and (@fc_id ='') and (@P_ID = 0) and (@pname ='') and (@HL ='') and (@sxqj ='') and (@SZPtype ='')
      select * from ##temp2
    else
    select * from ##temp2 where quantity > 0 
	DROP TABLE ##temp2
	  RETURN 0
Succee3:
    if (@Y_id = 0) and (@s_id	= 0) and (@szL_id ='0') and (@c_id = 0) and (@fc_id ='') and (@P_ID = 0) and (@pname ='') and (@HL ='') and (@sxqj ='') and (@SZPtype ='')
      select * from ##temp3
    else
    select * from ##temp3 where quantity > 0 
	DROP TABLE ##temp3
	DROP TABLE #pdetail
	DROP TABLE #pdetail1
	  RETURN 0
Succee4:
    if (@Y_id = 0) and (@s_id	= 0) and (@szL_id ='0') and (@c_id = 0) and (@fc_id ='') and (@P_ID = 0) and (@pname ='') and (@HL ='') and (@sxqj ='') and (@SZPtype ='')
      select * from ##temp4
    else
    select * from ##temp4 where quantity > 0  
	DROP TABLE ##temp4
	DROP TABLE #pdetail
	DROP TABLE #pdetail1   	
	  RETURN 0
GO
