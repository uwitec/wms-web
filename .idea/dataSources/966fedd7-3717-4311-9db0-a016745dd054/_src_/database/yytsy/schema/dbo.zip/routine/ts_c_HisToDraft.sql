


/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/


/*复制草稿*/

create     procedure ts_c_HisToDraft
(
	@nBillId numeric(10,0),
	@nReturnNumber numeric(10,0) output
)
/*with encryption*/
as
set nocount on 

/*变量定义*/
declare @nBillType smallint,@nNewBillId int,@cBillStates char(1)
declare @cUseSameCostMethod char(1)
declare @nCostMethod int
select @nBilltype=billtype,@cBillstates=billstates from billidx where billid=@nBillId
if @cBillStates='1' or  @cBillStates='4'
begin
	set @nReturnNumber=0
	return 0
end
/*变量定义end*/

/*--------得到成本核算法*/

exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  exec ts_getsysvalue 'CostMethod',@nCostMethod out


/*销售类单据*/
if @nBilltype in (10,11,12,13,16,17,110,111,112,32,210,212,211,150,151,152) 
/*销售出库单,销售出库退货单,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,销售单,销售退货单,发货单,,机构发货单,机构发货退货单*/
begin
	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,guid,invoicetotal,invoiceNo,businesstype,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,beginDate,EndDate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate)
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, /*auditman*/0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, 0, department_id, 
      	posid, region_id, auditdate, skdate, ysmoney-ssmoney, '0', note, summary, invoice,0,0,newid(),invoicetotal,invoiceNo,businesstype,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,beginDate,EndDate,
	        B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
	FROM billidx  where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,invoice,invoiceno,orgbillid,jsprice,aoid,YCostPrice,
                        SendQTY,SendCostTotal,PriceType,RowGuid,RowE_id,YGUID,Y_ID,InStoreTime,cxtype, comment2,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
        totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
        qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
        comment,unitid,taxrate,0,total,iotag,InvoiceTotal,quantity,taxprice,invoice,invoiceno,0,jsprice,aoid,YCostPrice,
         SendQTY,SendCostTotal,PriceType,newid(),RowE_id,NEWID(),Y_ID,InStoreTime,cxtype,comment2,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM dbo.salemanagebill
 	where bill_id=@nBillid	
	order by smb_id
	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update salemanagebilldrf set costprice=0 where bill_id=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from salemanagebilldrf a,products p
    where a.p_id=p.product_id and a.bill_id=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update salemanagebilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0
end
/*销售类单据*/

/*采购类单据*/
if @nBilltype in (20,21,24,25,120,121,122,35,220,222,221,160,161) 
/*采购入库单,采购入库退货单,受托代销收货,受托代销退货,受托代销结算,采购单,采购退货单,收货单,机构收货单,机构收货退货单*/
begin
	insert into billdraftidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate)
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, 0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, 0, department_id, 
      	posid, region_id, auditdate, skdate, ysmoney-ssmoney, '0', note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,newid(),
        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	    B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
	FROM billidx where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,jsprice,aoid,invoice,invoiceno,YCostPrice,
                      PriceType,SendQTY,SendCostTotal,RowGuid,RowE_id,YGUID,Y_ID,InStoreTime, comment2,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
      	totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      	qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      	comment,unitid,taxrate,0,total,iotag,InvoiceTotal,quantity,taxprice,0,jsprice,aoid,invoice,invoiceno,YCostPrice,
        PriceType,SendQTY,SendCostTotal,newid(),RowE_id,NEWID(),Y_ID,InStoreTime, comment2,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM dbo.buymanagebill where bill_id=@nBillid	
	order by smb_id
	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update buymanagebilldrf set costprice=0 where bill_id=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from buymanagebilldrf a,products p
    where a.p_id=p.product_id and a.bill_id=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update buymanagebilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0
end
/*采购类单据*/

/*库存类单据*/
if @nBilltype in (30,31,33,34,40,41,42,43,44,45,46,47,48,49,51,141)
/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
begin
	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate) 
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, 0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, 0, department_id, 
      	posid, region_id, auditdate, skdate, ysmoney-ssmoney, '0', note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,newid(),
        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	    B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
	FROM billidx 
	where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into storemanagebilldrf(bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
		     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,thqty,newprice,orgbillid,aoid,
                     SendQTY,SendCostTotal,RowGuid,RowE_id,Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId, p_id, batchno, quantity, price, totalmoney,costprice, costtotal,retailprice, retailmoney,  
      	makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, 
      	supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,quantity,price,0,aoid,
        SendQTY,SendCostTotal,newid(),RowE_id,Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM storemanagebill
	where bill_id=@nBillid	
	order by smb_id
	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update storemanagebilldrf set costprice=0 where bill_id=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from storemanagebilldrf a,products p
    where a.p_id=p.product_id and a.bill_id=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update storemanagebilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0
end
/*库存类单据*/

/*库存盘点单*/
if @nBilltype=50
begin
	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate) 
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, 0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, order_id, department_id, 
      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,newid(),
        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
	FROM billidx where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into GoodsCheckbilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,aoid,RowGuid,Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      comment,unitid,taxrate,order_id,total,aoid,newid(),Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM GoodsCheckbill where bill_id=@nBillid	
	order by smb_id
	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update GoodsCheckbilldrf set costprice=0 where bill_id=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from GoodsCheckbilldrf a,products p
    where a.p_id=p.product_id and a.bill_id=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update GoodsCheckbilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0
end
/*库存盘点单*/


/*钱流单据*/
if @nBilltype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,87,88,148,155,165,170,171,172,173,174,147,146)
/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买，储值单*/
begin
	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,ZBAuditMan,ZBAuditDate) 
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, 0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, order_id, department_id, 
      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,newid(),
        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,ZBAuditMan,ZBAuditDate
	FROM billidx where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into financebilldrf(bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal,RowGuid,Y_ID,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal,RowGuid,Y_ID,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM financebill
	where bill_id=@nBillid	
	order by smb_id
	if @@rowcount=0 goto error
	return	0
end
/*钱流单据*/

/*配送*/
if @nBilltype in (53,54,55,56) 
/*配送*/
begin
	insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,businesstype,guid,
                        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate)
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, /*auditman*/0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, 0, department_id, 
      	posid, region_id, auditdate, skdate, ysmoney-ssmoney, '0', note, summary, 0,0,0,businesstype,newid(),
        SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
	FROM billidx  where billid=@nBillId

	select @nNewBillId=@@identity
	
	insert into tranmanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,thqty,newprice,orgbillid,aoid,invoice,invoiceno,
                        PriceType,SendQTY,SendCostTotal,RowGuid,RowE_id,Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate)
	SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
        totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
        qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
        comment,unitid,taxrate,0,total,iotag,quantity,taxprice,0,aoid,invoice,invoiceno,
        PriceType,SendQTY,SendCostTotal,newid(),RowE_id,Y_ID,InStoreTime,batchbarcode,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM dbo.tranmanagebill
 	where bill_id=@nBillid	
	order by smb_id

	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update tranmanagebilldrf set costprice=0 where bill_id=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from tranmanagebilldrf a,products p
    where a.p_id=p.product_id and a.bill_id=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update tranmanagebilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0

end
/*配送*/

/*积分兑换单*/
if @nBilltype in (149)
begin
        insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,businesstype,guid,
                        InvoiceTotal,InvoiceNO,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
			B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,ZBAuditMan,ZBAuditDate)
	SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, /*auditman*/0, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, 2, 0, department_id, 
      	posid, region_id, auditdate, skdate, ysmoney-ssmoney, '0', note, summary, 0,0,0,businesstype,newid(),
        InvoiceTotal,InvoiceNO,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,begindate,Enddate,
	B_CustomName1,B_CustomName2,B_CustomName3,sendC_ID,ZBAuditMan,ZBAuditDate
	FROM billidx  where billid=@nBillId

	select @nNewBillId=@@identity

        insert into ExIntegRalManagebilldrf(billid,p_id,u_id,s_id,ColorID,SizeID,quantity,costprice,costTotal,price,
                    Totalmoney,IntegralMoney,IntegRalTotal,status,comment,RowTag,Aoid,batchno,makedate,validdate,location_id,
                    supplier_id,commissionflag,SendQTY,SendCostTotal,rowguid,Y_ID,InStoreTime,factoryid,costtaxprice,costtaxtotal,costtaxrate)

	SELECT @nNewBillId,p_id,u_id,s_id,ColorID,SizeID,quantity,costprice,costTotal,price,
        Totalmoney,IntegralMoney,IntegRalTotal,status,comment,RowTag,Aoid,batchno,makedate,validdate,location_id,
        supplier_id,commissionflag,SendQTY,SendCostTotal,newid(),Y_ID,InStoreTime,factoryid,costtaxprice,costtaxtotal,costtaxrate
	FROM ExIntegRalManagebill
 	where billid=@nBillid	
	order by smb_id

	if @@rowcount=0 goto error

  if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
  begin
    if @ncostmethod<>3
      update ExIntegRalManagebilldrf set costprice=0 where billid=@nNewBillId
  end else
  begin
    declare clearcostprice cursor scroll for
    select p.costmethod
    from ExIntegRalManagebilldrf a,products p
    where a.p_id=p.product_id and a.billid=@nNewBillid
    for update
  
    open clearcostprice
  
    fetch next from clearcostprice into @ncostmethod
    while @@fetch_status=0
    begin
      if @ncostmethod<>3
        update ExIntegRalManagebilldrf set costprice=0 where current of clearcostprice
      fetch next from clearcostprice into @ncostmethod
    end

    close clearcostprice
    deallocate clearcostprice
  end

	return	0
end 

/*返利单*/
IF @nBilltype IN (185)
BEGIN
    INSERT INTO billdraftidx
      (
        billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, araptotal,
        quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag,
        note, summary, invoice, transcount, lasttranstime, invoicetotal, invoiceNo, businesstype, guid, SendQTY,
        GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, begindate, Enddate, B_CustomName1, B_CustomName2, B_CustomName3, 
        RetailDate, sendC_ID, WholeQty, PartQty,ZBAuditMan,ZBAuditDate
      )
    SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, 0, inputman, ysmoney, ssmoney, araptotal,
           quantity, taxrate, period, 2, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag,
           note, summary, invoice, 0, 0, invoicetotal, invoiceNo, businesstype, NEWID(), SendQTY, GatheringMan, VIPCardID,
           jsInvoiceTotal, Y_ID, begindate, Enddate, B_CustomName1, B_CustomName2, B_CustomName3,
           RetailDate, sendC_ID, WholeQty, PartQty,ZBAuditMan,ZBAuditDate
    FROM   billidx
    WHERE  billid = @nBillId
    
    SELECT @nNewBillId = @@identity
    
    INSERT INTO ReturnBilldrf
      (
        bill_id, ret_id, SaleQty, SaleTotal,
        RetTotal, p_id, Total, comment
      )
    SELECT @nNewBillId, ret_id, 0, 0,
           RetTotal, p_id, Total, comment
    FROM   ReturnBill
    WHERE  bill_id = @nBillid
    ORDER BY
           smb_id
    
    IF @@rowcount = 0
        GOTO ERROR
    
    RETURN 0
END
/*返利单*/

error:
	set @nReturnNumber=-200
	return -1
GO
