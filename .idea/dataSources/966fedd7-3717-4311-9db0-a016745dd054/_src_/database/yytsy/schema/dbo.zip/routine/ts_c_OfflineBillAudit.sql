
/*nReturnNumber
－100：单据日期小于本期开始日期
 -101: 本张单据里包含结算金额大于结算余额的业务单据,可能的原因是业务单据已被其他人结算
	-1: 负库存
	-2:
	-3: 数量为零
	-4: 期初不能修改
	-5: 无成本价
  -6: 异常错误
  -7: 已经开帐，数据不能修改
	-8: 会计凭证不平
	-9：商品已删除
	-10：仓库已删除
	-11：职员已删除
	-12：往来单位已删除
	-13: 会计科目已删除
	-14: 货位已删除
	-15：商品单位已删除

	-21:退货数量大于原单数量
	-22:未指定当前机构
*/
CREATE  procedure ts_c_OfflineBillAudit
(
	@nBillId int,
	@nP_id int output,
	@nReturnNumber int output,
	@nVchtype int
)
/*with encryption*/
/*离线版本门店零售单过账:*/
as
set nocount on

declare @nTempPid int,@szBillNumber varchar(20),@szProductName varchar(60)/*,@nNewBillId int*/
declare @nC_id int,@nE_id int,@tBillDate datetime,@tBeginDate datetime,@tAuditDate datetime
declare @nDep_id int,@nRegion_id int,@nPeriod int,@cBillState char(1),@nBilltype int,@cJsFlag char(1)
declare @totalmoney NUMERIC(25,8),@billguid varchar(50)
declare @Y_id int,@billdateAudit int



select @nC_id=c_id,@nE_id=e_id,@tBillDate=billdate,@cBillState=billstates,@nBilltype=billtype,@szBillNumber=billnumber,@cJsFlag=jsflag,@Y_id=Y_id,@billguid=guid  from Yretailbillidx where billid=@nBillid

select @tBeginDate=begindate from MonthSettleInfo where monthname='本期' and Y_id=@Y_id
if exists(select 1 from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id)
  select @nPeriod=cast(sysvalue as int) from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id
else set @nPeriod = 1

if @tBillDate<@tBeginDate 
begin 
	select @nReturnNumber=-100
	return 0
end

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 

begin tran Audit_Offline

	select @nRegion_id=region_id from clients where client_id=@nC_id
	select @nDep_id=dep_id from employees where emp_id=@nE_id
	if @nRegion_id is null select @nRegion_id=0
	if @nDep_id is null select @nDep_id=0


	/*exec @nReturnNumber=ts_c_RetailToOfflineHis @nBillId,@nNewBillId output--从草稿库拷贝到历史单据库*/
	/*if @nReturnNumber<>0 goto error*/


        /*update retailmerge set draft=0 where newbillguid=@billguid and draft=1*/
declare @nIntergalYE NUMERIC(25,8)/*单据积分余额*/
declare @intergal int, /*积分*/
	@vipCardID int
declare @dicount NUMERIC(25,8), @isBank int/*会员卡所有商品折扣*/
declare @ArApTotal NUMERIC(25,8)  /*标识是否已计算过积分*/

set @billguid=''
set @totalmoney= 0 
select @ArApTotal=ArApTotal,@billguid=guid,@intergal = order_id,@vipCardID =vipcardid,@totalmoney =ssmoney ,@nIntergalYE =invoicetotal from Yretailbillidx where billid=@nBillId
select @dicount=ct.Discount, @isBank = ct.isBank from VIPCardType ct,Vipcard V where V.ct_id=ct.ct_id and v.VIPCardID= @vipcardid

	if @nbilltype in (12,13)
	begin
		/*update retailmerge set draft=0 where newbillguid=@billguid and draft=1*/
		if @nBilltype in(12,13) and  @vipCardID <> 0 and @ArApTotal=0
		begin
		  if exists(select top 1 * from YRetailBill s, CTIntegralOther ct, VIPCard V,Yretailbillidx b where b.billid=s.bill_id and s.p_id=ct.p_id and v.ct_id=ct.ct_id and b.VIPCardID=v.vipcardid and billid=@nBillId)
          begin        
		    execute ts_c_YVipIntergral @nBillId,@nBilltype
		    if @@error<>0 goto error	
          end else
          begin
            exec  ts_c_YTheAllVipIntergral  @nBillId,@nBilltype
            if @@error<>0 goto error	
          end
          
		  update Yretailbillidx set ArApTotal=1 where billid=@nBillId
		         
		end
	end
       
	exec ts_getsystmpvalue 'billdateAudidate',2,@billdateAudit out
    
    Select @tAuditDate=getdate()
	
	IF ISNULL(@billdateAudit,0)=0
	  update Yretailbillidx set billstates='0',period=@nPeriod,AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	  where BillId=@nBillId
	ELSE
      update Yretailbillidx set billstates='0',period=@nPeriod,billdate=left(@tAuditDate,10),AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	  where BillId=@nBillId

	if @@error<>0 goto error

	/*产生库存*/
	exec ts_c_OfflineAuditP @nBillId,@nP_Id out,@nReturnNumber out
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error


	exec @nReturnNumber=ts_c_Offlinevalidcheck @nBillId,@nbilltype
	if @@error<>0 goto error
	if @nReturnNumber<>0 
	begin
		rollback tran Audit_Offline
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return -1
	end


	if @np_id=0 set @nP_id=@nBillId
	
	commit tran Audit_Offline
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	
	return 0


error:
	rollback tran Audit_Offline
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	return -0
GO
