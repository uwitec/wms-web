

/*
   '000001000001'; 『库存商品总值合计』
   '000001000005';『应收款合计』
   '000002000001';『应付帐款合计』
   '000001000003';现 金
   'CASHBANK'; 
   '000001000004';银行
   '000004000002000001'; //商品报损
   '000003000002000001'; //商品报溢收入
  '000003000002000005'; //变价调拨差价
   '000003000002000003'; //成本调价收入
   '000003000002000006'; //商品拆装差价

   '000004000001'; //『销售成本』
  '000003000001'; //『销售收入』
   '000003000002000004'; //进货退货差价
  '000004000003000002'; //固定资产折旧
   '000001000007'; //待摊费用
   '000003'; //【收入类】
  '000003000003'; //其他收入
  '000004'; //【支出类】
  '000004000003'; // 其他费用
  '000001'; //【资产合计】
  '000002'; //【负债合计】
   '000002000004000002'; //应交增值税销项税金
  '000002000004000001'; //应交增值税进项税金
   '000005'; //【所有者权益】
  '000003000003000001'; //调帐收入
   '000004000003000001'; //调帐亏损
   '000001000002'; //固定资产合计

  '000005000006'; //【利润】
*/

CREATE      PROCEDURE ts_L_MultiAccount
( 
 @Parent_id varchar(36),
 @szWhere varchar(500),
 @E_id  int =0,
 @C_id int =0,
 @Y_id int =0
) /*在商品中作仓库用，*/
 AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @C_id is null  SET @C_id = 0
if @Y_id is null  SET @Y_id = 0
/*Params Ini end*/

set nocount on

 DECLARE @ArTotal NUMERIC(25,8)
 SELECT @ArTotal = 0

 if @szWhere ='CASHBANK'
 begin
  if not exists(select * from userauthorize u where u.e_id=@e_id and u.Type='A')
  select * 
    from vw_AccountBalance 
    where (sysFlag=1 or left(parent_id,12) ='000001000004') and Child_number=0
	   and Class_ID not in ('000001000004009999','000001009999') 
	   and Y_id = @Y_id
    order by class_id 
  else
  select * 
    from vw_AccountBalance a Inner join
    userauthorize u ON LEFT(a.class_id, LEN(u.psc_id))=u.psc_id
    where (a.sysFlag=1 or left(a.parent_id,12) ='000001000004') and a.Child_number=0 and
          (u.type = 'A') AND (u.e_id = @e_id) 
	  and Class_ID not in ('000001000004009999','000001009999') 
	  and Y_id = @Y_id
    order by a.class_id
 end
 else 
 if @szWhere = 'CASHBANKPR' /*现金银行、预收*/
 begin
   if  not exists(select * from userauthorize u where u.e_id=@e_id and u.Type='A')
   BEGIN
     SELECT @ArTotal = Pre_artotal FROM Clients WHERE Client_ID = @C_ID
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE WHEN Class_ID = '000002000005' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
     FROM vw_AccountBalance
     WHERE (sysFlag=1 or left(parent_id,12) ='000001000004')  and Child_number=0
            and Class_ID not in ('000001000009','000001000004009999','000001009999')
	    and Y_id = @Y_id
   END
   ELSE BEGIN    
     SELECT @ArTotal = Pre_artotal FROM Clients WHERE Client_ID = @C_ID
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE WHEN Class_ID = '000002000005' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
     FROM vw_AccountBalance a Inner join
          userauthorize u ON LEFT(a.class_id, LEN(u.psc_id))=u.psc_id
     where (a.sysFlag=1 or left(a.parent_id,12) ='000001000004') and a.Child_number=0 and
          (u.type = 'A') AND (u.e_id = @e_id) and (child_number=0)     
	  and Class_ID not in ('000001000004009999','000001009999')
          and Y_id = @Y_id
     union 
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE WHEN Class_ID = '000002000005' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
     FROM vw_AccountBalance WHERE Class_ID = '000002000005' and Y_id = @Y_id
 		
/*     WHERE (sysFlag=1 or left(parent_id,12) ='000001000004' or Class_ID = '000002000005') and Child_number=0*/
   end     
 end else
 if @szWhere = 'CASHBANKPP' /*现金银行、预付*/
 begin
   if not exists(select * from userauthorize u where u.e_id=@e_id and u.Type='A') 
   begin
     SELECT @ArTotal = Pre_aptotal FROM Clients WHERE Client_ID = @C_ID
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE  WHEN Class_ID = '000001000009' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
      FROM vw_AccountBalance
      WHERE (sysFlag=1 or left(parent_id,12) ='000001000004')  and Child_number=0  
             and Class_ID not in( '000002000005','000001000004009999','000001009999')
	     and Y_id = @Y_id
   end
   else begin     
     SELECT @ArTotal = Pre_aptotal FROM Clients WHERE Client_ID = @C_ID
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE  WHEN Class_ID = '000001000009' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
      FROM vw_AccountBalance a Inner join
           userauthorize u ON LEFT(a.class_id, LEN(u.psc_id))=u.psc_id
      where (a.sysFlag=1 or left(a.parent_id,12) ='000001000004') and a.Child_number=0 and
           (u.type = 'A') AND (u.e_id = @e_id) and (child_number=0)
	   and a.Class_ID not in('000001000004009999','000001009999')
	   and Y_id = @Y_id
      union 
     SELECT ACCOUNT_ID,    CLASS_ID,    PARENT_ID,    CHILD_NUMBER,     CHILD_COUNT,      [NAME],   ALIAS,
            SERIAL_NUMBER, COMMENT,     
            [CUR_TOTAL]  = (CASE WHEN Class_ID = '000002000005' AND @C_ID>0 THEN @ArTotal ELSE CUR_TOTAL END),    
            INI_TOTAL,        SYSFLAG,          SYSROW,   DELETED,
            PINYIN,        TOTAL_01,    TOTAL_02,     TOTAL_03,         TOTAL_04,         TOTAL_05, TOTAL_06,
            TOTAL_07,      TOTAL_08,    TOTAL_09,     TOTAL_10,         TOTAL_11,         TOTAL_12, BQTOTAL,
            SUMTOTAL,      CASHAUDIT,   DIRECTION 
     FROM vw_AccountBalance WHERE Class_ID = '000001000009'  and Y_id = @Y_id   
 
/*     WHERE (sysFlag=1 or left(parent_id,12) ='000001000004' or Class_ID = '000001000009') and Child_number=0    */
   end
 end  
 /*if @szWhere<>''
  select * 
  from vw_ACCOUNT
  where Parent_id=@parent_id and left(class_id,len(@szWhere))=@szWhere 
 else
  select * 
  from vw_ACCOUNT
  where Parent_id=@parent_id */
GO
