/************************************************************

--功能：查询最近几次价格跟踪   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_RepPriceHis]
	(
	 @nC_ID int =0,
         @nP_ID int = 0,
 	 @nbilltype int=0,
 	 @nUnit_id int = 0
        )
AS 
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = 0
if @nP_ID is null  SET @nP_ID = 0
if @nbilltype is null  SET @nbilltype = 0
if @nUnit_id is null  SET @nUnit_id = 0
/*Params Ini end*/


if @nBilltype in (10, 210, 231, 232, 11, 211, 212, 12, 13, 14, 15, 16, 17)
  goto RepSale  

if @nBilltype in (20, 220, 241, 242, 21, 221, 222, 22, 23, 24, 25, 26)
  goto RepBuy  
else 
  Return -1

RepSale:

if object_id('tempdb..#billsalemx') is not null
  drop table #billsalemx

select bill_id, p_id, taxprice as price into #billsalemx from salemanagebill where p_id = @nP_ID and unitid =  @nUnit_id  

if object_Id('tempdb..#RepSaleC') is not null
  drop table #RepSaleC

   select top 30 IDENTITY(int, 1,1) AS mxid, mx.p_id, convert(varchar(10), b.billdate, 20) as ChisDate, mx.price as CHisPrice into #RepSaleC  
     from #billsalemx mx, billidx b 
     where mx.bill_id = b.billid and 
           b.billtype in (10,12,53,112,122,210) and 
           b.c_id = @nC_ID 
     order by b.billdate desc
   
if object_Id('tempdb..#RepSale') is not null
  drop table #RepSale

   select top 30 IDENTITY(int, 1,1) AS mxid, mx.p_id, convert(varchar(10), b.billdate, 20) as hisDate,
    mx.price as HisPrice ,c.serial_number,c.name as clientname into #RepSale   
     from #billsalemx mx, billidx b 
     left join clients c on c.client_id=b.c_id
     where mx.bill_id = b.billid and 
           b.billtype in (10,12,53,112,122,210) 
     order by b.billdate desc

select isnull(ChisDate, ' ') as ChisDate, isnull(cast(CHisPrice as NUMERIC(25,8)), 0.0) as ChisPrice,
 isnull(b.HisDate, ' ') as hisDate, isnull(cast(b.HisPrice as NUMERIC(25,8)), 0.0) as HisPrice,
 ISNULL(b.serial_number,'') as serial_number,ISNULL(b.clientname,'') as clientname,
 (SELECT MIN(CHisPrice)FROM #RepSaleC) AS MINCHisPrice,(SELECT MIN(HisPrice)FROM #RepSale) AS MINHisPrice
   from #RepSaleC a  right join #RepSale b on a.mxid = b.mxid

Return 0


RepBuy:

if object_id('tempdb..#billmx') is not null
  drop table #billmx

  select bill_id, p_id, taxprice as price into #billmx from buymanagebill where p_id = @nP_ID and unitid =  @nUnit_id  


if object_Id('tempdb..#RepBuyC') is not null
  drop table #RepBuyC

   select top 30 IDENTITY(int, 1,1) AS mxid, mx.p_id, convert(varchar(10), b.billdate, 20) as ChisDate, mx.price as CHisPrice into #RepBuyC  
     from #billmx mx inner join billidx b on mx.bill_id = b.billid
     where  
           b.billtype in (20,122,220) and 
           b.c_id = @nC_ID 
     order by b.billdate desc


if object_Id('tempdb..#RepBuy') is not null
  drop table #RepBuy

   select top 30 IDENTITY(int,1,1) AS mxid, mx.p_id, convert(varchar(10), b.billdate, 20) as hisDate, mx.price as HisPrice
   ,c.serial_number,c.name as clientname into #RepBuy   
     from #billmx mx inner join billidx b on mx.bill_id = b.billid
     left join  clients c on c.client_id=b.c_id
     where 
           b.billtype in (20,122,220)
     order by b.billdate desc

select isnull(ChisDate, ' ') as ChisDate, isnull(cast(CHisPrice as NUMERIC(25,8)), 0.0) as ChisPrice, 
   isnull(b.HisDate, ' ') as hisDate, isnull(cast(b.HisPrice as NUMERIC(25,8)), 0.0) as HisPrice ,
   isnull(b.serial_number,'') as serial_number,isnull(b.clientname,'') as clientname,
   (SELECT MIN(CHisPrice)FROM #RepBuyC) AS MINCHisPrice,(SELECT MIN(HisPrice)FROM #RepBuy) AS MINHisPrice
   from #RepBuyC a right join  #RepBuy b on a.mxid = b.mxid

Return 0
GO
