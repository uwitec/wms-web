
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-24*/
/* Description:	拆分批次条码*/
/* =============================================*/
CREATE FUNCTION FN_SplitBatchCode 
(
	@szBatchCode varchar(20)
)
RETURNS 
@SplitBatchCode TABLE 
(
	p_id int, 
	BatchNo varchar(10),
	ValidDate datetime
)
AS
BEGIN
	DECLARE @szP char(4)
	DECLARE @szB varchar(50)
	DECLARE @szV char(3)
	DECLARE @iP int
	DECLARE @sB varchar(50)
	DECLARE @dtV datetime

	IF SUBSTRING(@szBatchCode, 1, 1) = '^'
	BEGIN
		SET @szP = SUBSTRING(@szBatchCode, 2, 4)
		SET @iP = DBO.FN_DecodeIntStr(@szP)
		SET @szB = SUBSTRING(@szBatchCode, 6, 12)
		SET @szB = CAST(DBO.FN_DecodeIntStr(@szB) AS VARCHAR(50))
		SET @sB = ''
		IF LEN(@szB) % 2 = 1
			SET @szB = '0' + @sB
		WHILE LEN(@szB) > 0
		BEGIN
			SET @sB = @sB + CHAR(CAST(SUBSTRING(@szB, 1, 2) AS int))
			SET @szB = SUBSTRING(@szB, 3, 50)
		END
		SET @szV = SUBSTRING(@szBatchCode, 18, 3)
		SET @dtV = DATEADD(DD, dbo.FN_DecodeIntStr(@szV), '2000-1-1')
		IF @dtV = '2000-1-1'
			SET @dtV = '1900-1-1'
		INSERT INTO @SplitBatchCode(p_id, BatchNo, ValidDate) VALUES(@iP, @sB, @dtV)
	END
	ELSE
	BEGIN
		INSERT INTO @SplitBatchCode(p_id, BatchNo, ValidDate) SELECT TOP 0 0, '', '1900-1-1'
	END
	
	RETURN 
END
GO
