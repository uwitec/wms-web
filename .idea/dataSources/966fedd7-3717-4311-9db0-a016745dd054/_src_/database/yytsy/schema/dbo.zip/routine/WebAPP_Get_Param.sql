/**************************************************************
返回指定名称的参数值
调用示例:
dbo.WebAPP_Get_Param('a=123;b=456;', 'a', default, default)
将返回123
**************************************************************/
CREATE function WebAPP_Get_Param
(
  @str varchar(8000),   --要分割的字符串
  @name varchar(50),    --取元素名称
  @sp1 varchar(10)=';', --分隔符号
  @sp2 varchar(10)='='  --分隔符号
)
returns varchar(1024)
as
begin
  DECLARE @retval    VARCHAR(1024)
	DECLARE @location  INT
	DECLARE @vallen    INT
	SET @retval = ''
	SET @str = LTRIM(RTRIM(@str)) + @sp1
	SET @location = CHARINDEX(@name + @sp2, @str)
	IF (@location > 0)
	BEGIN
	    SET @location = @location + LEN(@name + @sp2)
	    SET @vallen = CHARINDEX(@sp1, SUBSTRING(@str, @location, LEN(@str)))
	    IF (@vallen > 0)
	    BEGIN
	        SET @vallen = @vallen -LEN(@sp1)
	        IF (@location > 0 AND @vallen > 0)
	            SET @retval = SUBSTRING(@str, @location, @vallen)
	    END
	END
	
	RETURN REPLACE(@retval, '''', '')
end
GO
