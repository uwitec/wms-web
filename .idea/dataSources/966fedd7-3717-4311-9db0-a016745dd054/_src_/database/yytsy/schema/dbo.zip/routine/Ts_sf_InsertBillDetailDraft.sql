
CREATE proc Ts_sf_InsertBillDetailDraft
(
@nRET	INT OUTPUT,
@nTableTAG INT,
@nID  INT,
@bill_id  INT,
@a_id  INT,
@p_id  INT,
@batchno  VARCHAR(20),
@quantity  NUMERIC(25,8),
@costprice  NUMERIC(25,8),
@price	NUMERIC(25,8),
@total	NUMERIC(25,8),
@discount  NUMERIC(25,8),
@discountprice	NUMERIC(25,8),
@totalmoney  NUMERIC(25,8),
@taxprice  NUMERIC(25,8),
@taxtotal  NUMERIC(25,8),
@taxmoney  NUMERIC(25,8),
@retailprice  NUMERIC(25,8),
@retailtotal  NUMERIC(25,8),
@makedate  DATETIME,
@validdate  DATETIME,
@qualitystatus	VARCHAR(20),
@price_id  INT,
@ss_id	INT,
@sd_id	INT,
@order_id INT,
@location_id  INT,
@b_id  INT,
@commissionflag  TINYINT,
@comment  VARCHAR(255),
@unitid  INT,
@taxrate  NUMERIC(25,8),
@location_id2 INT,
@iotag INT,
@invoiceTotal NUMERIC(25,8),
@OrgBillID INT,
@jsPrice NUMERIC(25,8),
@nCheckQty int=1,
@AOID INT=0,
@SendQTY NUMERIC(25,8)=0,
@SendCostTotal NUMERIC(25,8)=0,
@PriceType INT=0,
@RowE_ID int = 0,
@YGUID   uniqueidentifier=null,
@YCostPrice varchar(50)='0',
@INVOICENO varchar(50)='',/*该字段标识:机构单据是手工录入的还是其他机构传输的*/
@Y_ID INT = 0,
@InStoreTime DateTime =0,
@CXTYPE int = 0,
@comment2 varchar(200)='', /*备注二*/
@scomment varchar(80) = '',		/* 批次备注*/
@batchprice NUMERIC(25,8) = 0,			/* 批次限价*/
@batchbarcode varchar(80) = '',	/* 批次条码*/
@cxGuid uniqueidentifier = 0x0,
@Conclusion VARCHAR(200) = '', /*质量结论*/
@FactoryId int =0,    /*生产厂家id*/
@costtaxrate NUMERIC(25,8) = 0 ,   /*成本税率*/
@costtaxprice NUMERIC(25,8) = 0,  /*成本单价*/
@costtaxtotal NUMERIC(25,8) = 0   /*成本金额*/
)

/*with encryption*/
AS
/*Params Ini begin*/
if @nCheckQty is null  SET @nCheckQty = 1
if @AOID is null  SET @AOID = 0
if @SendQTY is null  SET @SendQTY = 0
if @SendCostTotal is null  SET @SendCostTotal = 0
if @PriceType is null  SET @PriceType = 0
if @RowE_ID is null  SET @RowE_ID = 0
if @YGUID is null  SET @YGUID = null
if @YCostPrice is null  SET @YCostPrice = '0'
if @INVOICENO is null  SET @INVOICENO = ''
if @Y_ID is null  SET @Y_ID = 0
if @InStoreTime is null  SET @InStoreTime = 0
if @CXTYPE is null  SET @CXTYPE = 0
if @comment2 is null  SET @comment2 = ''
if @scomment is null  SET @scomment = ''
if @batchprice is null  SET @batchprice = 0
if @batchbarcode is null  SET @batchbarcode = ''
if @cxGuid is null  SET @cxGuid = 0x0
IF @Conclusion IS NULL SET @Conclusion = ''
if @FactoryId is null  SET @FactoryId = 0
if @costtaxrate is null  SET @costtaxrate = 0
if @costtaxprice is null  SET @costtaxprice = 0
if @costtaxtotal is null  SET @costtaxtotal = 0
/*Params Ini end*/
SET NOCOUNT ON

if @makedate<10 set @makedate=0
if @validdate<10 set @validdate=0

SET @nRET = -1
/*批次:入库时间只精确到天*/
set @InStoreTime = (DATENAME(Year, @InStoreTime) + '-' + DATENAME(Month, @InStoreTime) + '-' + DATENAME(Day, @InStoreTime))
/*mixb修改*/
declare @billtype int, @nE_ID int, @nSin_id int, @c_id int
declare @RowGUID uniqueidentifier, @szError varchar(200), @szErrQty varchar(100)/*处理出错提示*/
DECLARE @dtBillDate datetime
set @nE_ID=0
set @billtype = 0

/*mxb:如果单据是销售定单,采购计划,采购定单,则明细单据经手人不能从billdraftidx取.*/
   
IF @nTableTAG IN (5, 25, 40)
  select @dtBillDate = billdate, @c_id = c_id, @billtype=isnull(billType,0), @nE_ID = isnull(E_ID, 0), 
         @nSin_id = sin_id from sf_retailbillidx where billid=@bill_id
    
if @RowE_ID = 0 set @RowE_ID = @nE_ID  /*默认为表关经手人*/

declare @nLocalYid int
select @nLocalYid = sysvalue from sysconfig where sysname = 'y_id'

declare @DBqty NUMERIC(25,8)    /*调拨入库数量，用于启用仓库管理控制时回写调拨入库数量，增加可开数量 add by luowei 2012-12-12 */
set @DBqty = 0

/* 启用标准GSP流程*/
DECLARE @nStandardGSP VARCHAR(2), @nGspOrderProcess int
SELECT @nStandardGSP = sysvalue FROM sysconfigtmp WHERE sysname = 'GspStandardProcess'
SELECT top 1 @nGspOrderProcess = cast(sysvalue as int) FROM sysconfigtmp WHERE sysname = 'GspOrderProcess'
if @nGspOrderProcess is null set @nGspOrderProcess = 0

IF @nStandardGSP = '1'
BEGIN
  IF @billtype IN(161, 163) and @nLocalYid <> 2
  BEGIN
	set @order_id = (SELECT orgbillid FROM buymanagebill WHERE smb_id = @OrgBillID)
	set @OrgBillID = 0
  END
END
ELSE
BEGIN
  if @billtype = 163 and @nLocalYid <> 2	/* 自营店收货退货单门店不保存原单信息，否则不能过账*/
  begin
    set @order_id = 0
	set @OrgBillID = 0
  end
END

IF @billtype IN (10,12,14)  /*特殊商品每单限量(add by luowei 2013-08-12 增加往来单位类型判断,有单位类型的商品优先于没有单位的商品)*/
BEGIN
    declare @ctype_id int
    select @ctype_id = isnull(clienttype_id,0) from clients where client_id = @c_id
	DECLARE @QtyLimit NUMERIC(25,8)
	DECLARE @nMonthCount int
	DECLARE @nMonthQty NUMERIC(25,8)
	DECLARE @nMonthCountHis int
	DECLARE @nMonthQtyHis NUMERIC(25,8)
    SELECT TOP 1 @QtyLimit = ISNULL(b.Qty, 9999999), @nMonthCount = ISNULL(b.MonthCount, 0), @nMonthQty = ISNULL(b.MonthQty, 0)
	FROM BillProductLimit b, products p  
	WHERE b.PId = p.product_id AND p.cldw <> @unitid AND b.PId = @p_id AND b.[Deleted] = 0 AND b.BillType = @billtype AND 
		  b.YId = @Y_ID AND b.BeginTime <= GETDATE() AND b.EndTime >= GETDATE() AND 
		  (b.ctype_id = @ctype_id or b.ctype_id = 0) order by b.ctype_id desc	

	IF @quantity > @QtyLimit 
	BEGIN
		SET @nRet = - @p_id
		DECLARE @ZK_PName VARCHAR(100)
		SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
		SET @szError = '商品【' + @ZK_PName + '】的开票数量大于特殊商品每单限量 '+ CAST(@QtyLimit AS VARCHAR(24))+'(基本数量)。' 
		RAISERROR(@szError, 16, 1) 
		RETURN -100	
	END
	ELSE
	/* 每月限量*/
	BEGIN
		DECLARE @dtBegin datetime
		DECLARE @dtEnd datetime
		SET @dtBegin = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-01' AS datetime)
		SET @dtEnd = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-' + CAST(DBO.DaysThisMonth(@dtBillDate) AS VARCHAR(2)) AS datetime)
		SELECT @nMonthCountHis = COUNT(1) FROM billidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND billtype = @billtype
				AND billid IN (SELECT s.bill_id FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id) AND c_id = @c_id
		SELECT @nMonthQtyHis = ISNULL(SUM(s.quantity), 0) FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id AND s.bill_id IN
				(SELECT BILLID FROM billidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND billtype = @billtype AND c_id = @c_id)
		IF @nMonthCountHis >= @nMonthCount AND @nMonthCount > 0
		BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			SET @szError = '商品【' + @ZK_PName + '】的开票次数大于特殊商品每月限次 '+ CAST(@nMonthCount AS VARCHAR(24))+'。' 
			SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthCountHis AS VARCHAR(24)) + ' 次'
			RAISERROR(@szError, 16, 1) 
			RETURN -100	
		END
		ELSE
		IF @nMonthQtyHis + @quantity > @nMonthQty AND @nMonthQty > 0
		BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			SET @szError = '商品【' + @ZK_PName + '】的开票数量大于特殊商品每月限量 '+ CAST(@nMonthQty AS VARCHAR(24))+'。'
			SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthQtyHis AS VARCHAR(24))
			RAISERROR(@szError, 16, 1) 
			RETURN -100	
		END
	END
END                    

/*特殊商品零售限量控制  (按限量规则)        */
IF (@BillType IN (12)) 
BEGIN
  DECLARE @nBillQtyLimit NUMERIC(25,8) ,@nBillCountLimit int,@nQtyLimit NUMERIC(25,8) /*总数量上限，品规数上限,单个商品数量上限*/
  DECLARE @nBillQty NUMERIC(25,8),@nBillCount INT,@nQty NUMERIC(25,8) /*总数量，品规数,单个商品数量*/
  DECLARE @newY_ID INT
  DECLARE @RuleID int 
  SELECT @newY_ID=CASE WHEN ISNULL(YType,0) IN (0,1,3) THEN 2 ELSE @Y_ID end FROM company where company_id=@Y_ID
  
  /*检测当前商品是否是拆零的*/
  DECLARE @sfcl INT,@cldw int,@hsbl numeric(25,8) 
  SELECT @sfcl=ISNULL(IsSplit,0),@cldw=ISNULL(cldw,0),@hsbl=ISNULL(hsbl,0) FROM products WHERE product_id=@P_ID  
  
  /*如果换算系数等于0，那么强制为1，防止被0除的错误*/
  IF @hsbl=0 SET @hsbl=1    
  
  /*每个机构只能有一个规则,取最近被修改的规则*/
  SELECT TOP 1 @RuleID = a.idxID 
  FROM BillProductLimit_Idx a LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID 
  WHERE a.YID=@NewY_ID AND (b.idxID IS NOT NULL) AND States=0 AND begintime<=GETDATE() AND Endtime>=GETDATE()
  ORDER BY a.ModifyDate DESC	  

  SELECT
  @nBillCountLimit=PCount,@nBillQtyLimit=PQty,@nQtyLimit=b.Qty
  FROM BillProductLimit_Idx a
  LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID
  LEFT JOIN company com ON a.YID=com.Company_ID
  LEFT JOIN employees emp ON a.Eid=emp.emp_id
  LEFT JOIN vw_c_products pdt ON b.pid=pdt.product_id	  		
  WHERE a.idxID=@RuleID
  AND b.idxID IS NOT NULL
  AND b.PID=@P_ID
  ORDER BY b.DetailID
  	  	 	 	  
  IF @@rowCount>0 
  BEGIN
	  /*单个商品限量*/
	  SELECT @nQty = SUM(
		  CASE WHEN r.unitid=@cldw THEN (ISNULL(r.quantity,0) / @hsbl)  /*把拆零单位的数量折算成基本单位的数量*/
	           ELSE ISNULL(r.quantity,0) END )	  
	  FROM RetailBill r WHERE r.bill_id = @bill_id AND r.p_id = @p_id				
	  SET @nQty = ISNULL(@nQty,0) + @quantity
	  
	  IF @nQty > @nQtyLimit
	  BEGIN
		SET @nRet = - @p_id
		SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id			
		SET @szError = '商品【' + @ZK_PName + '】的开票数量大于零售单限量 '+ CAST(@nQtyLimit AS VARCHAR(24))+'(基本数量)。'						
		RAISERROR(@szError, 16, 1) 
		RETURN -100	
	  END	  
	  
	  /*每单品规数(满足限量规则的商品)*/
	  IF @nBillCountLimit > 0 
	  BEGIN
	      SELECT @nBillCount=COUNT(*) from
		  (SELECT DISTINCT b.PID
		  FROM BillProductLimit_Idx a
		  LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID
		  LEFT JOIN company com ON a.YID=com.Company_ID
		  LEFT JOIN employees emp ON a.Eid=emp.emp_id
		  LEFT JOIN vw_c_products pdt ON b.pid=pdt.product_id	  		
		  WHERE a.idxID=@RuleID AND b.idxID IS NOT NULL) a 
		  LEFT JOIN (SELECT DISTINCT P_id FROM RetailBill WHERE bill_id=@bill_id UNION SELECT @p_id) b ON a.pid=b.p_id
		  WHERE b.p_id IS NOT null		  
		  
		  IF @nBillCount > @nBillCountLimit
		  BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			SET @szError = '当前品规数大于每单品规数上限 '+ CAST(@nBillCountLimit AS VARCHAR(24))+'。'
			RAISERROR(@szError, 16, 1) 
			RETURN -100		  
		  end		  
	  end		
	  
	  /*每单总数量(满足限量规则的商品)*/
	  IF @nBillQtyLimit>0 
	  BEGIN
		  SELECT @nBillQty=SUM(
		  CASE WHEN r.unitid=@cldw THEN (ISNULL(r.quantity,0) / @hsbl)  /*把拆零单位的数量折算成基本单位的数量*/
	           ELSE ISNULL(r.quantity,0) END 		  
		  ) FROM RetailBill r 
		  WHERE r.bill_id=@bill_id AND r.p_id IN (
		  SELECT b.p_id from
		  (SELECT DISTINCT b.PID
		  FROM BillProductLimit_Idx a
		  LEFT JOIN BillProductLimit_Detail b ON a.idxID=b.idxID
		  LEFT JOIN company com ON a.YID=com.Company_ID
		  LEFT JOIN employees emp ON a.Eid=emp.emp_id
		  LEFT JOIN vw_c_products pdt ON b.pid=pdt.product_id	  		
		  WHERE a.idxID=@RuleID AND b.idxID IS NOT NULL) a 
		  LEFT JOIN (SELECT DISTINCT P_id FROM RetailBill WHERE bill_id=@bill_id UNION ALL SELECT @p_id) b ON a.pid=b.p_id
		  WHERE b.p_id IS NOT null
		  )
		  	  
		  SET @nBillQty = @nBillQty + @quantity
		    		 
		  IF @nBillQty > @nBillQtyLimit
		  BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			SET @szError = '零售单商品总数量大于每单总数量上限 '+ CAST(@nBillQtyLimit AS VARCHAR(24))+'。'
			RAISERROR(@szError, 16, 1) 
			RETURN -100
		  end	    	  
	  end
  END  
END

set @RowGUID=NEWID()
   
/*近效期商品禁止销售*/
/*-----------取零售单,合同的单据类型*/
if @nTableTag in(5,25,40) select @billtype=isnull(billType,0)from sf_retailbillidx where billid=@bill_id

declare @P1 int, @PName varchar(100)
set @P1=0 set @PName=''
exec ts_M_qrStopSaleDay;1 @P1 output,@BillType,@validdate 
if (@P1=-1) 
begin
    set @nRet=-@p_id
    select @PName=[name] from products where product_id=@p_id
	set @szError = '商品【'+@PName+'】，近效期禁止商品' 
	raiserror(@szError,16,1) 
	return -100
end 

set @SendQty=@quantity 
set @SendCostTotal=@costprice*@quantity

declare @nSaleQuantity NUMERIC(18,8),@szPname varchar(255)
declare @cUseSameCostMethod char(1),@nCostMethod char(1),@CheckSaleQty char(1), @GspStandardProcess char(1)
declare @isPAllQty int  /*是否根据批次计算可开数量，0按批次计算可开数量，　1按全部商品合计计算可开数量　zjl140105*/

set @CheckSaleQty='0'
exec ts_getsysvalue 'CheckSaleQty',@CheckSaleQty out/*存草稿是否检测可开数量*/
		
exec ts_GetSystmpValue 'GspStandardProcess',0,@GspStandardProcess out, 0 
           
if (@CheckSaleQty<>'0') and (@AOID not in (5,6))
begin
	/* 启用标准流程后销售出库单、自营店发货单、机构发货单、采购入库退货单不检测可开数量*/
	IF NOT ((@nStandardGSP = '1') AND @billtype IN(10, 150, 152, 21))
	BEGIN
		exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
		if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
			exec ts_getsysvalue 'CostMethod',@nCostMethod out
		else select @nCostMethod=isnull(costmethod,'0') from products where product_id=@p_id
   
		if @nCostMethod in ('1','2','3') and @nCheckQty=1
		begin
			if @nTableTag in (0,1,35,2,8,4)
			begin
				select @szPname=[name] from products where product_id=@p_id
		
				set @nSaleQuantity=0

				if @costprice > 0
				begin
					if @billtype in (10,14,21,30,34,41,43,44,45,46,49,51,53,56,150,152,161,163,210,212, 154) and @iotag = 0
					begin
						select @nSaleQuantity = isnull(quantity, 0) from dbo.FN_GetAvlqty(@p_id, @ss_id, '', 0) where p_id = @p_id and s_id = @ss_id
							and costprice = @costprice and batchno = @batchno and makedate = @makedate and validdate = @validdate
							and instoretime = @InStoreTime and commissionflag = @commissionflag and Y_ID = @Y_ID and supplier_id = @b_id
							and location_id = @location_id
					end
					else
						set @nSaleQuantity = @quantity
					set @DBqty = 0
					if (exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue  ='1')) and (@billtype in (10, 14))/*销售出库单草稿启用仓库管理流程时检测调拨单草稿中的可开数量 add by luowei 2012-12-14*/
					begin   
					  select @DBqty = TJDB.qty from
					  (
						  select p_id,sd_id,batchno,supplier_id,location_id2,validdate,commissionflag,costprice,instoretime,sum(quantity) as qty
						  from storemanagebilldrf mx where exists(select 1 from billdraftidx idx where idx.billid = mx.bill_id and billtype = 44)
						  and aoid in (0,7)
						  group by p_id,sd_id,batchno,supplier_id,location_id2,validdate,commissionflag,costprice,instoretime
					  ) TJDB 
					  where TJDB.p_id =@p_id  AND TJDB.sd_id = @ss_id AND TJDB.batchno = @batchno AND TJDB.supplier_id = @b_id
					AND TJDB.location_id2 = @location_id
					AND TJDB.validdate = @validdate
							  AND TJDB.commissionflag = @commissionflag AND TJDB.costprice = @costprice AND TJDB.instoretime = @InStoreTime
					end
					set @nSaleQuantity=@nSaleQuantity+@DBqty
					if @nSaleQuantity<@quantity
					begin
						set @nRet=-@p_id
						set @szError = '第【'+cast(@nID as varchar)+'】行,商品【'+@szPname+'】的开票数量大于可开数量'+cast(@nSaleQuantity as varchar(24))+'(基本数量)，可能出现负库存。' 
						raiserror(@szError,16,1) 
						return -100
					end 
				end
			end
		end
	END
end

IF @order_id IS NULL
	SET @order_id = 0

INSERT INTO sf_RetailBill
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,
 retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,
 taxrate, qualitystatus, total, OrgBillID,aoid,PriceType, RowE_id, RowGUID, Y_ID, InStoreTime, cxType, scomment, batchprice, BatchBarCode, CxGuid,
 FactoryId, costtaxrate, costtaxprice, costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,
 @retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,
 @taxrate, @qualitystatus, @total, @OrgBillID,@AOID,@PriceType, @RowE_id ,@RowGUID, @Y_ID, @InStoreTime, @CXTYPE, @scomment, @batchprice, @batchbarcode, @cxGuid,
 @FactoryId, @costtaxrate, @costtaxprice, @costtaxtotal
)
      
SET @nRET = @@ROWCOUNT

/*----------启用仓库管理流程时处理正常明细，防止回滚单据   add by luowei 2012-12-18*/
if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and
      exists(select 1 from billdraftidx where billtype = 10 and billid = @bill_id) and (@order_id <> 1)
  set @nRET = 1  
  
RETURN 0
GO
