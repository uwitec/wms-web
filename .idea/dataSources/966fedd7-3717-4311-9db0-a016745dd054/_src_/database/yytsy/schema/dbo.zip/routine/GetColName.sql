
CREATE  FUNCTION [GetColName](
	@colid int,
	@TableName varchar(100)
	)  
RETURNS 
  varchar(200)
AS
BEGIN
	declare @Result nvarchar(2000)
	set @Result = ''
	if @TableName = 'ProductCategory'   /*商品自定义属性表*/
		set @Result = '[PComent' + CAST(@colid  as varchar) + ']' 
	else if @TableName = 'ClientCategory'   /*往来单位自定义属性表*/
		set @Result = '[CComent' + CAST(@colid  as varchar) + ']'
	else if @TableName = 'CompanyCategory'   /*机构自定义属性表*/
		set @Result = '[YComent' + CAST(@colid  as varchar) + ']'	
  RETURN @Result
END
GO
