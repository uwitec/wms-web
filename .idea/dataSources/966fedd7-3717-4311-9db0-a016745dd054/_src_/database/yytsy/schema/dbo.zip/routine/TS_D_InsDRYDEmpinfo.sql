

CREATE procedure TS_D_InsDRYDEmpinfo
@EmpNum	varchar(20),/*个人编码*/
@AAC003	varchar(20),/*姓名*/
@AKC020	varchar(20),/*医保卡号*/
@YAB003	varchar(10),/*参保地统筹区编码*/
@AKC300 varchar(3)/*人群类别*/
AS

  IF NOT EXISTS(SELECT 1 FROM DRYDEmpinfo WHERE EmpNum=@EmpNum AND YAB003=@YAB003)
  BEGIN
	INSERT INTO DRYDEmpinfo
	 (EmpNum,AAC003,AKC020,YAB003,billdate,AKC300)
	SELECT @EmpNum,@AAC003,@AKC020,@YAB003,GETDATE(),@AKC300
  END
  ELSE 
  BEGIN
    UPDATE DRYDEmpinfo SET 
    AAC003=@AAC003
    ,AKC020=@AKC020
    ,AKC300=@AKC300 
    WHERE EmpNum=@EmpNum AND YAB003=@YAB003
  END
GO
