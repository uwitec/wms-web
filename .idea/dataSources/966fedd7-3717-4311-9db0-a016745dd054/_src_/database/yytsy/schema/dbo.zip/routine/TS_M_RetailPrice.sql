
/*@StoreType 1 :本期库存 2 上期库存*/
CREATE PROCEDURE [TS_M_RetailPrice]
(
  @szSClassID   	VARCHAR(30)='000000',
  @szPClassID	 	VARCHAR(36)='',
  @nUnitType    	int =1 ,
  @StoreType		int =1 				
)

AS 
/*Params Ini begin*/
if @szSClassID is null  SET @szSClassID = '000000'
if @szPClassID is null  SET @szPClassID = ''
if @nUnitType is null  SET @nUnitType = 1 
if @StoreType is null  SET @StoreType = 1
/*Params Ini end*/

DECLARE @SQLScript  varchar (8000)

IF @StoreType= 1 
BEGIN
	SET @SQLScript='
	SELECT ISNULL(SUM( ISNULL(pri.[RetailPrice],0) * (ISNULL(SH.[Quantity],0)/(dbo.GetRetailRate(P.Product_id,'+cast(@nUnitType as varchar(30))+') )) ) ,0)  AS [RetailTotal]   	
	FROM StoreHouse 	SH  
	LEFT JOIN 	Storages   S 	ON SH.[S_ID]=S.[Storage_ID]
	LEFT JOIN 	Products   P	ON SH.[P_ID]=P.[Product_ID]
	LEFT JOIN 	Price	   pri  ON P.product_id=pri.p_id
        WHERE P.[Deleted]<>1    
            AND LEFT(P.[Class_ID], LEN('+char(39)+@szPClassID+char(39)+')) LIKE '+char(39)+@szPClassID+char(39)
	+'  AND pri.unittype='+cast(@nUnitType as varchar(10))
END 
IF @StoreType= 2 
BEGIN
	SET @SQLScript='
	SELECT ISNULL(SUM( ISNULL(pri.[RetailPrice],0) * (ISNULL(SH.[Quantity],0)/(dbo.GetRetailRate(P.Product_id,'+cast(@nUnitType as varchar(30))+') )) ) ,0)  AS [RetailTotal]   	
	FROM StoreHouseIni   SH  
	LEFT JOIN 	Storages   S 	ON SH.[S_ID]=S.[Storage_ID]
	LEFT JOIN 	Products   P	ON SH.[P_ID]=P.[Product_ID]
	LEFT JOIN 	Price	   pri  ON P.product_id=pri.p_id
        WHERE P.[Deleted]<>1    
            AND LEFT(P.[Class_ID], LEN('+char(39)+@szPClassID+char(39)+')) LIKE '+char(39)+@szPClassID+char(39)
	+'  AND pri.unittype='+cast(@nUnitType as varchar(10))
END 

IF not @szSClassID in ('', '000000')
  SET @SQLScript= @SQLScript+ ' AND LEFT(S.[Class_ID], LEN('+char(39)+@szSClassID+char(39)+')) LIKE '+char(39)+@szSClassID+char(39)

/*print @SQLScript*/
exec(@SQLScript)
GO
