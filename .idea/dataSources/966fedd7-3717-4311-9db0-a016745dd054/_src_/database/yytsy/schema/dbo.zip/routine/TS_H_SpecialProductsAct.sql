
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_SpecialProductsAct]
	@Act			int,				/*操作 0 添加 1 编辑 2 删除*/
	@Type			int = 0,			/*类型 0 商品 1 分类*/
	@Class_ID		varchar(30),
	@Parent_ID		varchar(30) = '',
	@Name			varchar(80) = '',
	@Serial_number	varchar(26) = '',
	@Alias			varchar(30) = '',
	@RetailPrice	NUMERIC(25,8) = 0,
	@Pinyin			varchar(80) = '',
	@EngName		varchar(50) = '',
	@Comment		varchar(250) = '',
	@deleted		int = 0,
	@RowIndex		int = 0,
	@AccountID		int = 0,
	@Emp_ID			int = 0,
	@Unit_ID		int = 0
AS
BEGIN
/*Params Ini begin*/
if @Type is null  SET @Type = 0
if @Parent_ID is null  SET @Parent_ID = ''
if @Name is null  SET @Name = ''
if @Serial_number is null  SET @Serial_number = ''
if @Alias is null  SET @Alias = ''
if @RetailPrice is null  SET @RetailPrice = 0
if @Pinyin is null  SET @Pinyin = ''
if @EngName is null  SET @EngName = ''
if @Comment is null  SET @Comment = ''
if @deleted is null  SET @deleted = 0
if @RowIndex is null  SET @RowIndex = 0
if @AccountID is null  SET @AccountID = 0
if @Emp_ID is null  SET @Emp_ID = 0
if @Unit_ID is null  SET @Unit_ID = 0
/*Params Ini end*/
	SET NOCOUNT ON;

	if @Act = 0		/*添加*/
	begin
		if @Parent_id = ''
			set @Parent_id = '000000'
		
		if exists(select * from specialproducts where name = @name)
		begin
			raiserror('名称不能重复！', 16, 1)
			return 0
		end
		
		declare @SubIdStr varchar(30)
		declare @SubId int
		declare @SubNumber int
		
		begin tran
		select @SubID = child_count from specialproducts where class_id = @Parent_id
		if @SubId is null
		begin
			if @Parent_ID = '000000'
			begin
				set @SubIdStr = '000001'
				insert into specialproducts(
					class_id,
					parent_id,
					name,
					child_number,
					child_count
				) values(
					@Parent_ID,
					'',
					'诊治费用',
					1,
					1
				)
			end
			else
			begin
				raiserror('数据结构错误！', 16, 1)
				return 0
			end
		end
		else
		begin
			if @Parent_ID = '000000'
				set @SubIdStr = dbo.padleft(cast((@SubId + 1) as varchar(6)), 6, '0')
			else
				set @SubIdStr = @Parent_Id + dbo.padleft(cast((@SubId + 1) as varchar(6)), 6, '0')
			update specialproducts set
			child_number = child_number + 1,
			child_count = child_count + 1
			where class_id = @Parent_id
		end
		insert into specialproducts(
			class_id,
			parent_id,
			serial_number,
			name,
			alias,
			RetailPrice,
			comment,
			deleted,
			pinyin,
			Engname,
			RowIndex,
			AccountID,
			Emp_ID,
			unit_id
		) values (
			@SubIdStr,
			@Parent_id,
			@Serial_number,
			@name,
			@alias,
			@RetailPrice,
			@comment,
			@deleted,
			@pinyin,
			@Engname,
			@RowIndex,
			@AccountID,
			@Emp_ID,
			@unit_id
		)
		if @@error <> 0
		begin
			rollback tran
			raiserror('添加商品信息失败！', 16, 1)
			return 0
		end
		else
		begin
			commit tran
			return @@identity
		end
	end
	else
	if @Act = 1		/*编辑*/
	begin
		update specialProducts set
			[name] =  @name,
			[serial_number] = @Serial_number,
			[alias] = @alias,
			[RetailPrice] = @RetailPrice,
			[comment] = @comment,
			[pinyin] = @pinyin,
			[Engname] = @Engname,
			[AccountID] = @AccountID,
			[Emp_ID] = @Emp_ID,
			[unit_id] = @unit_id
		where [class_id] = @Class_id
		declare @ret int
		select @ret = product_id from specialProducts where class_id = @Class_id
		return @ret
	end
	else
	if @Act = 2		/*删除*/
	begin
		return 0
	end
END
GO
