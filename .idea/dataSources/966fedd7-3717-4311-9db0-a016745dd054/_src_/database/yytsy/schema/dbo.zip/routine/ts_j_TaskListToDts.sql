/************************************************************

--功能: 
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_TaskListToDts]

AS 
  truncate table TaskListDts
  
  	if exists(select billid from tasklist where tranflag <> 3 and billtype in (180,181,182,183) and billstates = 5 and tranType = 0)/*停用促销*/
	begin
	  insert into tasklistDts(tsid, billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates)
		select tsid, billid, billtype, taskdate, lasttrandate, trancount, tranflag, posid, Y_ID, DY_ID, billguid, tranType, billstates 
		  from  tasklist
		  where tranflag <> 3 and billtype in (180,181,182,183) and billstates = 5 and tranType = 0
	  update tasklist set lasttrandate=getdate(),trancount=trancount+1,tranflag=2 where tranflag=1 and billtype in (180, 181, 182, 183) and billstates = 5 and tranType = 0    
	end 	

  if @@Error <> 0 Return -1
GO
