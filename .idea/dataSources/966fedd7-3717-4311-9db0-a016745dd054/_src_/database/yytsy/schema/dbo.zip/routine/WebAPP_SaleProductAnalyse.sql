/**************************************************************
app_yyt滞销商品查询
**************************************************************/
create proc WebAPP_SaleProductAnalyse
(
  @chvparams  varchar(400) = '',
  @retmessage varchar(200) OUT
)
--$encode$--
as
BEGIN
	--DECLARE @a VARCHAR(200)
    --EXEC WebAPP_SaleProductAnalyse;1 'y_id=2;mode=0',@a
	
	IF object_id(N'#FinalData', N'U') is not null
		Drop Table #FinalData
	
	CREATE TABLE #FinalData 
	(
		p_id     INT NULL DEFAULT(0) , 
		RecCount INT NULL DEFAULT(0) ,
		quantity NUMERIC(18,4) NULL DEFAULT(0) , 
		taxtotal NUMERIC(18,4) NULL DEFAULT(0)
	)
	
	SET @retmessage = '操作成功'

	DECLARE @YId      INT,              --机构ID
	        @Mode     INT,              --0 30天；1 90天；2 180天
			@Begin    VARCHAR(100),
			@End      VARCHAR(100),
			@AllTotal NUMERIC(18, 4)

	SET @YId = dbo.webapp_get_param(@chvparams, 'y_id', default, default)
	SET @Mode = dbo.webapp_get_param(@chvparams, 'mode', default, default)
	
	IF @Mode = 0
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -30, GETDATE()) AS DATETIME), 23)
	ELSE
	IF @Mode = 1
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -90, GETDATE()) AS DATETIME), 23)
	ELSE
		SET @Begin = CONVERT(VARCHAR(100), CAST(DATEADD(DAY, -180, GETDATE()) AS DATETIME), 23)
	SET @End = CONVERT(VARCHAR(100), GETDATE(), 23)
	
	INSERT INTO #FinalData(p_id, RecCount, quantity, taxtotal)
	SELECT b.p_id, b.RecCount, b.quantity, b.taxtotal
	  FROM (
		SELECT a.p_id, COUNT(*) AS RecCount, SUM(a.quantity) AS quantity, SUM(a.taxtotal) AS taxtotal 
		FROM (
			SELECT s.bill_id, s.p_id, 
				   SUM(CASE WHEN b.billtype IN (10, 12, 150, 152) THEN s.quantity ELSE -s.quantity END) AS quantity, 
				   SUM(CASE WHEN b.billtype IN (10, 12, 150, 152) THEN s.taxtotal ELSE -s.taxtotal END) AS taxtotal
				FROM billidx b, salemanagebill s    
			WHERE b.[BillID]=s.[Bill_ID] AND b.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND b.[BillDate] BETWEEN @Begin AND @End AND 
				  b.[BillStates]='0' AND (@YId = 0 OR b.Y_id = @YId) AND s.p_id > 0 AND s.aoid IN (0, 5) GROUP BY s.bill_id, s.p_id	
		) a GROUP BY a.p_id 	
	) b  
	
	SELECT @AllTotal = SUM(taxtotal) FROM #FinalData 
	
	IF @AllTotal = 0
		SET @AllTotal = 1
	IF @AllTotal IS NULL
		SET @AllTotal = 1
	
	--返回的数据集
	SELECT TOP 30 p.serial_number,  --编码
				  p.name,           --商品名
				  p.alias,          --通用名
				  p.[standard],     --规格 
				  p.permitcode,		--批准文号
				  p.makearea,       --产地
				  p.Factory,        --生产厂家 
				  b.quantity,       --数量 
				  b.taxtotal,       --金额
				  b.RecCount        --频次
		FROM (
			SELECT a.p_id, a.RecCount, a.quantity, a.taxtotal
				FROM #FinalData a
			WHERE (a.taxtotal / @AllTotal) < 0.2 			
		) b, products p WHERE b.p_id = p.product_id  ORDER BY b.taxtotal
	
	
	IF object_id(N'#FinalData', N'U') is not null
		Drop Table #FinalData	
END
GO
