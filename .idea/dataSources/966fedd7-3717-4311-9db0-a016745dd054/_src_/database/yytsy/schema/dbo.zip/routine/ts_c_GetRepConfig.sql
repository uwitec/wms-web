



CREATE  PROCEDURE ts_c_GetRepConfig
(
	@nE_id int,
	@szRepName varchar(300)
)
/*with encryption*/
 AS
set nocount on
select * from reportcfg where e_id=@nE_id and repname=@szRepName
GO
