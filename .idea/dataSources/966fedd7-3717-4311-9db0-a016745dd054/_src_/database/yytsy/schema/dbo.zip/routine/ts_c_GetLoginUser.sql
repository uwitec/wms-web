



create  PROCEDURE ts_c_GetLoginUser
(
	@nY_ID INT = 0,
	@nE_ID INT = 0
) 
AS
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
if @nE_ID is null  SET @nE_ID = 0
/*Params Ini end*/
set nocount on

declare @nCount int

set @nCount=0
select @nCount=count(*) from employees

if @ncount=0 
insert into employees(class_id,parent_id,[name],[alias],child_number,child_count) values('000000','root','管理员','管理员',0,0)


set @nCount=0
select @nCount=count(*) from limgroup

if @ncount=0 
begin
	truncate table limgroup
	insert into limgroup([name],comment,ProductInfor,ClientInfor,PriceInfor) 
	values('管理员组','系统管理员',
	'商品全名,通用名,拼音码,英文名,化学名,拉丁名,商品编码,规格,批准文号,产地,药品种类,有效期(月),打印类别,剂型,有效期(天),装箱规格,储藏条件,GSP属性,非处方药,提成比例,养护,养护天数,门店养护天数,注册商标,注册证号,默认货位,生产许可证号,生产厂家,商品税率,单位,主供货商,主采购员,备注,GMP达标,首营药品,处方药,生成自动编码,价格修改,价格查看,提成方式,自定义属性,基本药物,价格保护,销售加价率1,销售加价率2,销售加价率3,温度条件,检验报告,特管药品控制,贵细药品,中药,采购基数,请货基数,包装,辅助税率,税务分类编号',
	'名称,简名,拼音码,编号,首营企业,片区,类型,业务员,联系电话,仓库地址,联系人,邮编,税号,开户行及帐号,价格方式,收付款期限(天),应收合计,应付合计,预收合计,预付合计,期初应收,期初应付,期初预收,期初预付,信用额度,认证类型,GSP证书号,GMP证书号,企业许可证,销售加价率,创建日期,自定义属性,备注,经营范围,所属信息,证照期限,自定义证照,在途周期,注册地址,结算方式,结算周期',
	'1111111111'
	)
end

exec ts_j_CreateLimEx 0

SELECT  employees.[Name] as 'empname', employees.serial_number as 'serial_number', cast([users].loginpass as varchar(60)) as 'password', 
 users.[e_id],employees.lim as permission, users.USERPIN as USERPIN,users.[isBinding] as isBinding,users.[serialNumber]
 ,employees.class_ID,employees.Y_ID,isnull(ex.ProductInfor, '') ProductInfor,
  isnull(ex.ClientInfor, '') ClientInfor, isnull(ex.priceInfor, '') priceInfor,
  YName=isnull(Company.[Name],''),YClass_id=isnull(Company.Class_id,''),
 posdatamode = ISNULL(company.posdatamode, 1),superior_id = ISNULL(company.superior_id, 0)
 ,employees.limPlugin as permPlugin /*added by ZhanXinYun@2010-10-22*/
 ,isnull(company.Ytype, 0 ) as YType,users.user_id as user_id,users.bindmac as bindmac,isnull(users.maccode,'') as maccode,
 users.loginCount as loginCount,employees.pinyin
FROM employees inner join
      users ON employees.emp_id = users.e_id
left join EmplimitEx ex on employees.emp_id = ex.e_id       
left join Company on Company.Company_id = employees.Y_ID
where employees.deleted=0  
      and CAST(Y_ID as varchar(50)) like (case when (@nY_ID=0) then '%%' else  CAST(@nY_ID as varchar(50)) end)
      and ex.orderIndex =0
      AND (@nE_ID = 0 OR employees.emp_id = @nE_ID)
ORDER BY users.[user_id]
GO
