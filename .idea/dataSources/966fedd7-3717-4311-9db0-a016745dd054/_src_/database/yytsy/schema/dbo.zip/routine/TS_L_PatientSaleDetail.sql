/*******病人消费明细查询**********/
/*******add by luowei **********/
/*******2012-09-14*************/

create procedure TS_L_PatientSaleDetail  
(  
  @szbegindate datetime,  /*开始日期 */
  @szEnddate datetime,    /*结束日期 */
  @Patient_id int=0,      /*病人id */
  @y_id int=0,            /*消费机构  */
  @p_id int=0,            /*商品id  */
  @e_id int=0     
)  
 
as  
begin  
      
    if @Patient_id is null set @Patient_id = 0  
    if @y_id is null set @y_id = 0  
    if @p_id is null set @p_id = 0  
    if @e_id is null set @e_id = 0  
    
  /*set  @szEnddate=dateadd(day,1, @szEnddate)  */
      
 select p_id,billid,billtype,billdate,billnumber,e_id,ename,Name,sex,NL,Tel,serial_number,pname,standard,isnull(mt_name,'') as mt_name,uname,quantity,total,Y_ID,yname   
 from   
 (  
  select i.p_id,ridx.billid,ridx.billtype,ridx.billdate,ridx.billnumber,ridx.e_id,ridx.Y_ID,e.name as ename,ps.PatientID,ps.Name,ps.sex,dbo.GetAge(ps.Birthday,GETDATE()) as NL,  
  ps.Tel,p.serial_number,p.name as pname,u.name as uname,p.standard,m.name as mt_name,rb.quantity,rb.total,y.name as yname   
  from   
  (  
    select * from salemanagebill where  AOID = 0 
    and exists(  
                select 1 from billidx rx where rx.billid = salemanagebill.bill_id   
                       and billstates = 0 and (e_id = @e_id or @e_id = 0)  
                       and billdate between @szbegindate and @szEnddate  
               )  
  ) rb   
  left join salemanagebill i on rb.orgbillid = i.smb_id  and i.p_id=rb.p_id /*增加and i.p_id=rb.p_id */
  left join billidx idx on idx.billid = i.bill_id  
  left join billidx ridx on ridx.billid = rb.bill_id  
  left join products p on p.product_id = rb.p_id  
  left join unit u on u.unit_id = p.unit1_id  
  left   join   
     (          
     select P_id as baseinfo_id,c.name from ProductCategory pc
     left join customCategory c on PComent3 = c.class_id 
     where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
   )m on p.product_id = m.baseinfo_id  
  inner join Patients ps on ps.billid = rb.bill_id 
  left join employees e on e.emp_id = ridx.e_id  
  left join company y on y.company_id = ridx.Y_ID  
  where (@p_id = 0 or rb.p_id = @p_id) and (@y_id = 0 or rb.Y_ID = @y_id) 
  union all  
  select i.p_id,ridx.billid,ridx.billtype,ridx.billdate,ridx.billnumber,ridx.e_id,ridx.Y_ID,e.name as ename,ps.PatientID,ps.Name,ps.sex,dbo.GetAge(ps.Birthday,GETDATE()) as NL,  
  ps.Tel,p.serial_number,p.name as pname,'' as uname,'' as standard,'' as mt_name,rb.quantity,rb.total,y.name as yname   
  from   
  (  
    select * from salemanagebill where  AOID = 8
    and exists(  
                select 1 from billidx rx where rx.billid = bill_id   
                       and billstates = 0 and (e_id =@e_id or @e_id = 0)  
                       and billdate  between @szbegindate and @szEnddate   
               )  
  ) rb   
  left join salemanagebill i on rb.orgbillid = i.smb_id  and i.p_id=rb.p_id /*增加and i.p_id=rb.p_id*/
  left join billidx idx on idx.billid = i.bill_id  
  left join billidx ridx on ridx.billid = rb.bill_id  
  left join SpecialProducts p on p.product_id = rb.p_id  
  inner join Patients ps on ps.billid = rb.bill_id 
  left join employees e on e.emp_id = ridx.e_id  
  left join company y on y.company_id = ridx.Y_ID  
  where (@p_id = 0 or rb.p_id = @p_id) and (@y_id = 0 or rb.Y_ID = @y_id) 
       
 ) t where (PatientID = @Patient_id or @Patient_id = 0) and quantity<>0 order by t.billid  
  

end
GO
