











CREATE	PROCEDURE [ts_L_Insmembercard]
	(@cardID	[numeric](9),
	 @CardNo	[varchar](50),
	 @Name	[varchar](20),
	 @Tel	[varchar](20),
	 @Address	[varchar](60),
	 @Comment	[varchar](60),
	 @CardType	[int],
	 @Discount	[numeric](10,4),
	 @BulidDate	[datetime],
	 @ValidityDate	[datetime],
	 @Lose	[bit],
	 @StopUse	[bit],
	 @BuyTotal	[numeric](10,4),
	 @BuyTotalPerDay	[numeric](10,4),
	 @AutoDiscount	[char](1),
	 @IDCard	[varchar](20),
	 @Integral	[int],
	 @Brithday	[datetime],
	 @DiscountType	[int],
	 @sex	 	[varchar](10),
	 @intergralTotal	[numeric](10,4))

AS 
if @cardid=0 
begin
	if Exists(select cardNo from membercard where Cardno=@cardNo)
	begin
		RAISERROR('卡号重复！不能添加！！',16,1)
		return -1
	end

	INSERT INTO [membercard] 
		 ( [CardNo],
		 [Name],
		 [Tel],
		 [Address],
		 [Comment],
		 [CardType],
		 [Discount],
		 [BulidDate],
		 [ValidityDate],
		 [Lose],
		 [StopUse],
		 [BuyTotal],
		 [BuyTotalPerDay],
		 [AutoDiscount],
		 [IDCard],
		 [Integral],
		 [Brithday],
		 [DiscountType],
		 [sex],
		 [intergralTotal]) 
	 
	VALUES 
		( @CardNo,
		 @Name,
		 @Tel,
		 @Address,
		 @Comment,
		 @CardType,
		 @Discount,
		 @BulidDate,
		 @ValidityDate,
		 @Lose,
		 @StopUse,
		 @BuyTotal,
		 @BuyTotalPerDay,
		 @AutoDiscount,
		 @IDCard,
		 @Integral,
		 @Brithday,
		 @DiscountType,
		 @sex,
		 @intergralTotal)
	return 0

end else
begin	
/*  zhh添加重复提示 -------------------------------------------------------------------------------*/
  if exists(select cardNo from membercard where Cardno=@CardNo and [CardID]<> @cardid)
  begin
   RAISERROR('编号重复！允许修改！！',16,1)
   return -1
  end
/*-----------------------------------------------------------------------------------------------*/

	UPDATE [membercard] 
	
	SET  [CardNo]	 = @CardNo,
		 [Name]  = @Name,
		 [Tel]	 = @Tel,
		 [Address]	 = @Address,
		 [Comment]	 = @Comment,
		 [CardType]	 = @CardType,
		 [Discount]	 = @Discount,
		 [BulidDate]	 = @BulidDate,
		 [ValidityDate]  = @ValidityDate,
		 [Lose]  = @Lose,
		 [StopUse]	 = @StopUse,
		 /*[BuyTotal]	 = @BuyTotal,*/
		 /*[BuyTotalPerDay]	 = @BuyTotalPerDay,*/
		 [AutoDiscount]  = @AutoDiscount,
		 [IDCard]	 = @IDCard,
		 [Integral]	 = @Integral,
		 [Brithday]	 = @Brithday,
		 [DiscountType]  = @DiscountType, 
		 [sex]  = @sex,
		 [intergralTotal]	= @intergralTotal
	WHERE 
		( [CardID]	 = @CardID)
	return 0
end
GO
