


/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/
create  procedure ts_c_YDraftToHis
(
	@nbillid numeric(10,0),
	@nnewbillid numeric(10,0) output
)
/*with encryption*/
as
set nocount on

declare @bUserElabel char(1)
set @bUserElabel='0'
exec ts_getsysvalue 'ELabel',@bUserElabel out


/*变量定义*/
declare @nbilltype smallint /*单据类型*/
select @nbilltype=billtype from Ybilldraftidx where billid=@nbillid

/*定义单据明细*/
declare 
       @p_id             int, 
       @batchno          varchar(20), 
       @quantity         NUMERIC(25,8), 
       @costprice        NUMERIC(25,8), 
       @saleprice        NUMERIC(25,8), 
       @discount         NUMERIC(25,8), 
       @discountprice    NUMERIC(25,8), 
       @totalmoney       NUMERIC(25,8), 
       @taxprice         NUMERIC(25,8), 
       @taxtotal         NUMERIC(25,8), 
       @taxmoney         NUMERIC(25,8), 
       @retailprice      NUMERIC(25,8), 
       @retailtotal      NUMERIC(25,8), 
       @makedate         datetime, 
       @validdate        datetime, 
       @qualitystatus    varchar(20), 
       @price_id         int, 
       @ss_id            int, 
       @sd_id            int, 
       @location_id      int, 
       @supplier_id      int, 
       @commissionflag   tinyint, 
       @comment          varchar(255),
       @unitid           int,
       @taxrate          NUMERIC(25,8),
       @order_id         int,
       @total            NUMERIC(25,8),
       @iotag            smallint,
       @invoicetotal     NUMERIC(25,8),
       @thqty            NUMERIC(25,8),
       @newprice         NUMERIC(25,8),
       @orgbillid        int,
       @sizeid           int,
       @colorid          int,
       @status           int,
       @invoice          int,
       @invoiceno        varchar(50),
       @jsprice          NUMERIC(25,8),
       @groupid          int,
       @draftrowid       int,
       @aoid             int,
       @businesstype     int,
       @rowtag           tinyint,
 	@sm_id           int,
 	@err_count       int,
	@SendQTY	 NUMERIC(25,8),/*已发货数量 */
 	@SendCostTotal	 int,/*已发货成本金额*/
 	@PriceType	 int,/*价格类型*/
	@RowGuid	 uniqueidentifier, /*行GUID*/
 	@RowE_id	 int , /*明细行经手人*/
	@YCostPrice 	 varchar(50), /*机构收发货成本单价*/
        @YGUID           uniqueidentifier,
        @Y_ID    	 int ,
	@InStoreTime    datetime,
	@CxType			int,
	@scomment  varchar(80),
    @batchbarcode varchar(80),
    @batchprice NUMERIC(25,8),
	@cxGuid uniqueidentifier,
	@cxSale NUMERIC(25,8)

	
/*变量定义end*/
select @err_count = 0
/*销售类单据*/
if @nbilltype in (12,13) 
begin
/*插入表头*/
/*------------------------zhh添加，如果发货单存在未分配的行，返回-999999999*/
	/*if exists(select costprice from salemanagebilldrf where bill_id=@nbillid and costprice=999999999)  */
	/*	return -999999999*/
/*----------------------------------------------------------------------*/

	insert into billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID ,B_CustomName1,B_CustomName2,B_CustomName3,RetailDate,integral,integralYE,ZBAuditMan,ZBAuditDate)
	select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
		SendQTY,GatheringMan,VipCardID, Y_ID ,B_CustomName1,B_CustomName2,B_CustomName3,RetailDate,integral,integralYE,0,'1900-01-01'
	from Ybilldraftidx where billid=@nbillid
	

 select @nnewbillid=@@identity
 declare salebillcurr cursor for
	 select p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID,INVOICENO,Y_ID, InStoreTime, cxtype,
	       batchbarcode,scomment,batchprice, cxGuid
	 from dbo.Ysalemanagebilldrf
	 where bill_id=@nbillid 
         order by smb_id
 open salebillcurr
 fetch next FROM  salebillcurr
 into  @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
       @newprice         , @orgbillid 	     , @jsprice          , @aoid             ,  @SendQTY	  , @SendCostTotal    ,         
       @PriceType	 , @RowGuid	     , @RowE_id		 , @YCostPrice       ,  @YGUID            , @INVOICENO        ,
       @Y_ID		 , @InStoreTime  , @CxType,
       @batchbarcode,@scomment,@batchprice, @cxGuid
while(@@fetch_status = 0)
begin
	 insert into salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID,INVOICENO, Y_ID, InStoreTime, cxType,batchbarcode,scomment,batchprice, cxGuid)
	select @nnewbillid,
               @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid             ,  @SendQTY	  , @SendQTY*@costprice,
 	       @PriceType	 , @RowGuid	     , @RowE_id  	 , @YCostPrice       ,  @YGUID		  ,@INVOICENO         ,
           @Y_ID		 , @InStoreTime  , @CxType,@batchbarcode,@scomment,@batchprice, @cxGuid
        select @sm_id =@@identity
        select @err_count = @err_count + @@error

	 insert into salemanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType,
	       batchbarcode,scomment,batchprice, cxGuid)
	select @nnewbillid,
               @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid 	     ,  @sm_id            ,
               @SendQTY	         , @SendQTY*@costprice, @PriceType	 , @RowGuid	     ,  @RowE_id          , @YCostPrice       ,
               @YGUID	         , @Y_ID    	      , @InStoreTime , @CxType,
               @batchbarcode,@scomment,@batchprice, @cxGuid

 	if @cxGuid <> 0x0
	begin
		/*select @cxTodaySale = SUM(b.quantity) from salemanagebill b inner join billidx i on b.bill_id = i.billid where CxGuid = @cxGuid */
		/*	and i.billdate = CONVERT(varchar(10), Getdate(), 120) and i.billstates = 0 and i.billtype in (10, 210, 12)*/
		if not exists(select 0 from CxBillNew b inner join CxBillIdx i on b.billid = i.billid where b.guid = @cxGuid 
			and (b.billlimit >= @quantity or b.billlimit = 0) and i.billstate = 3)
		begin
			set @err_count = @err_count + 1
			break
		end

		select @cxSale = SUM(b.quantity) from salemanagebill b inner join billidx i on b.bill_id = i.billid where b.CxGuid = @cxGuid 
		and i.billstates = 0 and i.billtype in (10, 210, 12) and b.Y_ID = @Y_ID

		if not exists(select 0 from CxBillNew b inner join CxBillIdx i on b.billid = i.billid where b.guid = @cxGuid 
			and (b.totallimit >= @quantity + @cxSale or b.totallimit = 0) and i.billstate = 3)
			set @err_count = @err_count + 1
		else
			update CxBillNew set sale = sale + @quantity where guid = @cxGuid
	end

       select @err_count = @err_count + @@error
        if @err_count <> 0 break

		if @bUserElabel='1' and @nbilltype=10 exec ts_c_AddElalbeTask @nnewbillid,@nbilltype,@sm_id,@location_id,@batchno,@quantity

        fetch next FROM  salebillcurr
	 into  @p_id             , @batchno          , @quantity         , @costprice        ,  @saleprice        , @discount         ,
	       @discountprice    , @totalmoney       , @taxprice         , @taxtotal         ,  @taxmoney         , @retailprice      ,
	       @retailtotal      , @makedate         , @validdate        , @qualitystatus    ,  @price_id         , @ss_id            ,
	       @sd_id            , @location_id      , @supplier_id      , @commissionflag   ,  @comment          , @unitid           ,
	       @taxrate          , @order_id         , @total            , @iotag            ,  @invoicetotal     , @thqty            ,
	       @newprice         , @orgbillid        , @jsprice          , @aoid             ,  @SendQTY	  , @SendCostTotal    ,
  	       @PriceType	 , @RowGuid	     , @RowE_id          , @YCostPrice       ,  @YGUID		  , @INVOICENO        ,
               @Y_ID		 , @InStoreTime, @Cxtype,@batchbarcode,@scomment,@batchprice, @cxGuid
end
 close salebillcurr
 deallocate salebillcurr
 if @err_count = 0
   return 0
 else
   return -1

end
/*销售类单据*/
GO
