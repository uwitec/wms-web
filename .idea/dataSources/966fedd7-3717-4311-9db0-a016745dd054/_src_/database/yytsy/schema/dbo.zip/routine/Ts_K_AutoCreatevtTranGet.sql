
CREATE	       PROCEDURE Ts_K_AutoCreatevtTranGet
(
	@BillSN VARCHAR(30)
)
/*with encryption*/
AS
BEGIN
	DECLARE @YId INT
	SELECT @YId = s.[sysvalue] FROM sysconfig s WHERE s.[sysname] = 'Y_ID'
	IF @YId > 0 
	BEGIN
		DECLARE @Temp TABLE (PId [INT], Quantity [NUMERIC] (18, 4))
		INSERT INTO @Temp
		SELECT a.P_id, (a.LowLimit - ISNULL(b.Quantity, 0)) AS Quantity
		FROM   (
		           SELECT P_id, SUM(LowLimit) AS LowLimit
		           FROM   StoreLimit
		           WHERE  LowLimit > 0 AND S_id IN (SELECT storage_id FROM   storages WHERE  Y_ID = @YId)
		           GROUP BY P_id
		       ) a
		       LEFT JOIN (
		                SELECT s.p_id, SUM(s.quantity) AS Quantity
		                FROM   storehouse s WHERE  s.Y_ID = @YId
		                GROUP BY s.p_id
		            ) b
		            ON  a.P_id = b.p_id
		WHERE  a.LowLimit > ISNULL(b.Quantity, 0)
		
		IF EXISTS(SELECT 1 FROM @Temp) 
		BEGIN
			BEGIN TRAN K_AutoCreatevtTranGet
            
            DECLARE @Quantity NUMERIC(25,8)
			SELECT @Quantity = ISNULL(SUM(Quantity), 0) FROM @Temp
			
			INSERT INTO TranIdx
			(
				billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity,
				taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note,
				summary, invoice, transcount, lasttranstime, InvoiceTotal, InvoiceNO, BusinessType, [GUID], ArAptotal, SendQTY, GatheringMan, Y_ID
			)
			VALUES
			(   
				CONVERT(VARCHAR(100), GETDATE(), 23), @BillSN, 52, 0, @YId, 1, 0, 0, 1, 1, 0.00, 0.00, @Quantity, 
				0.00, 0, 3, 0, 0, @YId, 0, CONVERT(VARCHAR(100), GETDATE(), 23), '1900-01-01', 0, 0, '由库存下限自动生成', 
				0, 0, 0, '1900-01-01', 0.00, 0, 0, NEWID(), 0, 0.00, 0, @YId
			) 
			IF @@ROWCOUNT = 0
			BEGIN 
				ROLLBACK TRAN K_AutoCreatevtTranGet
				RETURN -1
			END
			DECLARE @BillId INT
			SET @BillId = @@IDENTITY  
			INSERT INTO TranBill(bill_id, p_id, quantity, retailprice, retailmoney, ComeQty, ComeDate, comment, unitid, RowGuid, Y_ID, Conclusion)
			SELECT @BillId, a.PId, a.Quantity, 0.00, 0.00, 0.00, '1900-01-01', CAST(a.Quantity AS VARCHAR(100)) + '(' + p.uname + ')', p.unit1_id, NEWID(), @YId, ''
			FROM   @Temp a
			       INNER JOIN (
			                SELECT p.product_id, p.unit1_id, u.name AS uname 
			                FROM   products p 
								LEFT JOIN unit u ON p.unit1_id = u.unit_id 
			                WHERE p.child_number = 0 AND p.[deleted] = 0
			            ) p
			            ON  a.PId = p.product_id 
			IF @@ROWCOUNT = 0
			BEGIN
			    ROLLBACK TRAN K_AutoCreatevtTranGet
			    RETURN -1
			END
			ELSE
			BEGIN
			    COMMIT TRAN K_AutoCreatevtTranGet
			    RETURN 1
			END
		END
	END
END
GO
