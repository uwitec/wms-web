
CREATE VIEW dbo.vw_L_sysconfig
AS

SELECT sys_id, sysvalue, comment, sysflag,

 [sysname]=case [sysname] when 'Customname1' then '自定义属性1'   
                           when 'Customname2' then '自定义属性2'
                           when 'Customname3' then '自定义属性3'
                           when 'Customname4' then '自定义属性4'
                           when 'Customname5' then '自定义属性5'
			  when 'C_Customname1' then '往来自定义属性1'   
                           when 'C_Customname2' then '往来自定义属性2'
                           when 'C_Customname3' then '往来自定义属性3'
                           when 'C_Customname4' then '往来自定义属性4'
                           when 'C_Customname5' then '往来自定义属性5'
                           when 'Cer_CustomNo1' then '自定义证照号1'
                           when 'Cer_CustomNo2' then '自定义证照号2'
                           when 'Cer_CustomNo3' then '自定义证照号3'
                           when 'Cer_CustomNo4' then '自定义证照号4'
                           when 'Cer_CustomNo5' then '自定义证照号5'
                           when 'Cer_CustomNo6' then '自定义证照号6'
                           when 'Cer_CustomNo7' then '自定义证照号7'
                           when 'Cer_CustomNo8' then '自定义证照号8'
                           when 'Cer_CustomNo9' then '自定义证照号9'
                           when 'Cer_CustomNo10' then '自定义证照号10'
end
FROM dbo.sysconfig
GO
