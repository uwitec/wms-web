
create procedure TS_D_GSQrUpData
@GSDDNo VARCHAR(30)='' /*定点编号*/
as 
  SET NOCOUNT ON 
  
  DECLARE @TGSP_id INT,@DateStr VARCHAR(20) 
  SELECT @TGSP_id=TGSP_id FROM GSTransNum WHERE GSDDNo=@GSDDNo 
  
  SET @DateStr=CONVERT(VARCHAR(30),GETDATE(),121)
  SET @DateStr=LEFT(REPLACE(REPLACE(REPLACE(@DateStr,'-',''),' ',''),':',''),14)  
  
  SELECT p_id,billid   
  INTO #ProductMap 
  FROM GSProductMap
  WHERE GSDDNo=@GSDDNo AND GSP_id>0 AND GSP_id<=@TGSP_id AND IsUp=0
  
  /*将同一商品多个未上传的直接删除,只保留一个*/
  UPDATE R SET  
  IsDel=4
  FROM GSProductMap R INNER JOIN #ProductMap CI 
       ON R.billid=CI.billid
       LEFT JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap GROUP BY p_id
       ) M ON CI.billid=M.billid
  WHERE M.billid IS NULL 
  
  UPDATE R SET  
  IsDel=5
  FROM GSProductMap R
       INNER JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap GROUP BY p_id
       ) CI ON R.billid=CI.billid
 
  SELECT '1' SFXMLB,c.serial_number,dbo.FN_GSReplace(d.serial_number) serial_number_Y,dbo.FN_GSReplace(d.name) name_Y
         ,dbo.FN_GSReplace(c.MedType) MedType,dbo.FN_GSReplace(c.UnitName) UnitName,dbo.FN_GSReplace(c.standard) standard
         ,c.price,dbo.FN_GSReplace(d.makearea) makearea_Y
         ,@DateStr DateStr,c.BeginDate,c.EndDate
         ,'' YPJJ,'' BLFY,'' ZYSX   
  FROM GSProductMap a
       INNER JOIN 
       (
         SELECT MAX(billid) billid FROM #ProductMap GROUP BY p_id
       ) b ON a.billid=b.billid
       INNER JOIN GSProducts c
       ON a.GSP_id=c.GSP_id
       INNER JOIN products d 
       ON a.p_id=d.product_id
GO
