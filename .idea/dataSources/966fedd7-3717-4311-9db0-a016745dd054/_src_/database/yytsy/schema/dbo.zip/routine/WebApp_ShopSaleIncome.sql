CREATE PROC WebApp_ShopSaleIncome
( 
	@Begindate datetime = 0,
    @Enddate   datetime = 0,
    @nPosId	INT = 0,
    @nStorageId	INT = 0,
    @chvparams  varchar(400)=''
)
AS
BEGIN
	--参考916脚本Ts_T_QueryRetailGeneralReport.sql
	IF object_id(N'#BaseGroup1', N'U') is not null
		Drop Table #BaseGroup1 
	IF object_id(N'#FinalData', N'U') is not null
		Drop Table #FinalData
	
	DECLARE @YClass_id VARCHAR(60), @YID INT
	SELECT @YID = dbo.WebAPP_Get_Param(@chvparams, 'y_id', DEFAULT, DEFAULT)
	SELECT @YClass_id = class_id FROM company WHERE company_id = @nPosId AND company_id > 1
	IF @YClass_id IS NULL
		SET @YClass_id = '' 
	
	--查询结果集临表
	Create Table #FinalData 
	(
		--RecNum INT IDENTITY(1,1) NOT NULL,  --自增列
		Y_ID INT NULL DEFAULT(0), --零售单所属机构
		YClass_id VARCHAR(100) NULL DEFAULT(''), --机构Class_id
		SaleQuantity numeric(25,8) NULL DEFAULT(0),    --销售数量
		SaleBackQuantity numeric(25,8) NULL DEFAULT(0),--销售退货数量
		SumRetailtotal numeric(25,8) NULL DEFAULT(0),  --零售金额
		SaleBackTotal numeric(25,8) NULL DEFAULT(0),  --销售退货金额
		SumTaxTotal numeric(25,8) NULL DEFAULT(0),  --实收金额
		SumML numeric(25,8) NULL DEFAULT(0),  --毛利
		MLRATE numeric(25,8) NULL DEFAULT(0),  --毛利率
		--以下2个字段根据实际需要在获取数据集后重新计算  
		SumBillNumber numeric(25,8) NULL DEFAULT(0), --客流量
		PricePerBill numeric(25,8) NULL DEFAULT(0), --客单价
	)
	
	DECLARE @TMPSQL VARCHAR(6000)  --临时使用
    DECLARE @INSSQL VARCHAR(6000) --组合语句的INSERT部分
    DECLARE @SELSQL VARCHAR(6000) --组合语句的SELECT部分
    DECLARE @GRPSQL VARCHAR(6000) --组合语句的GROUP部分
    DECLARE @EXESQL VARCHAR(6000) --组合后需执行SQL语句，由前三部分组装而成
     
    SET @TMPSQL = ''
    SET @INSSQL = ''
    SET @SELSQL = ''
    SET @GRPSQL = ''
    SET @EXESQL = ''
    
	SELECT identity(int, 1, 1) as RecNo, 
         idx.Y_ID,c.class_id as YClass_id,
         idx.billid, sm.smb_id, sm.p_id,sm.AOID, 
         (case idx.billtype when 12 then sm.quantity else (-1) * sm.quantity end) as quantity, 
         (case idx.billtype when 12 then 0 else sm.quantity end) as SaleBackQuantity, 
         (case idx.billtype when 12 then sm.retailtotal else -sm.retailtotal end) as retailtotal,
         (case idx.billtype when 12 then 0 else sm.retailtotal end) as SaleBackTotal,
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.taxtotal end) else -(case AOID when 7 then 0 else sm.taxtotal end) end) as taxtotal,
         (case idx.billtype when 12 then sm.taxtotal - sm.costtaxtotal else -(sm.taxtotal - sm.costtaxtotal) end) as MLMoney 
    INTO #BaseGroup1
    FROM billidx idx inner join salemanagebill sm on idx.billid = sm.bill_id AND IsNull(sm.p_id, 0) >= 0
         INNER join company c on c.company_id = idx.Y_ID                                                                  
    WHERE 1=1  
      AND (idx.billtype = 12 or idx.billtype = 13)
      AND idx.billstates = 0 
      AND idx.billdate >= @BeginDate AND idx.billdate < @EndDate  	
		
	SET @TMPSQL = 'Y_ID,YClass_id'
    SET @INSSQL = @INSSQL + 'Y_ID,YClass_id, '
    SET @SELSQL = @SELSQL + @TMPSQL + ', '
    SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    SET @INSSQL = ' INSERT INTO #FinalData (' + @INSSQL  
    SET @SELSQL = ' SELECT ' + @SELSQL
    SET @GRPSQL = ' GROUP BY ' + @GRPSQL
    SET @INSSQL = @INSSQL 
                + 'SaleQuantity, SaleBackQuantity, SumRetailtotal, SaleBackTotal, SumTaxTotal, '
                + 'SumML, MLRATE, SumBillNumber, PricePerBill) '    
    SET @SELSQL = @SELSQL 
                + 'SUM(quantity) SaleQuantity, SUM(SaleBackQuantity) SaleBackQuantity, SUM(RetailTotal) SumRetailtotal, SUM(SaleBackTotal) SaleBackTotal, ' 
                + 'SUM(TaxTotal) SumTaxTotal, '
                + 'SUM(MLMoney) SumML, '
                + '(CASE SUM(taxtotal) WHEN 0 THEN 100 ELSE SUM(MLMoney)*100/SUM(taxtotal) END) AS MLRATE, COUNT(DISTINCT billid) SumBillNumber, '                
                + '(CASE COUNT(DISTINCT billid) WHEN 0 THEN SUM(TaxTotal) ELSE SUM(TaxTotal)/COUNT(DISTINCT billid) END) PricePerBill '                      
    
    SET @SELSQL = @SELSQL + 'FROM #BaseGroup1 '
	
	IF @GRPSQL <> ''
	BEGIN
		IF RIGHT(RTRIM(@GRPSQL), 1) = ','
			SET @GRPSQL = LEFT(RTRIM(@GRPSQL), LEN(RTRIM(@GRPSQL))-1)          
	END
	
	--执行SQL，获取数据集
    SET @EXESQL = @INSSQL + @SELSQL + @GRPSQL
  
    IF @EXESQL <> ''
		EXEC(@EXESQL) 
    PRINT @EXESQL  
      
	--空值处理
	DELETE #FinalData WHERE ISNULL(SumRetailtotal, 0) = 0 AND ISNULL(SumTaxTotal, 0) = 0
                      
	--返回数据集    
	SELECT  cmy.name as PosName, tmp.SaleQuantity, tmp.SumRetailtotal AS SaleTotal, tmp.SaleBackQuantity, tmp.SaleBackTotal, tmp.SumTaxTotal AS BQSkdje, 
	        tmp.SumBillNumber, tmp.PricePerBill,
	        tmp.SumML, CAST(CAST(ROUND(tmp.MLRATE, 2) AS NUMERIC(10, 2)) AS VARCHAR(10)) + '%' AS MlRate
	    FROM #FinalData tmp INNER JOIN company cmy on tmp.Y_ID = cmy.company_id
						
	WHERE (@YClass_id = '' OR tmp.YClass_id = @YClass_id)
	ORDER By cmy.Name
	
	IF object_id(N'#BaseGroup1', N'U') is not null
		Drop Table #BaseGroup1
	IF object_id(N'#FinalData', N'U') is not null
		Drop Table #FinalData	
		
END
GO
