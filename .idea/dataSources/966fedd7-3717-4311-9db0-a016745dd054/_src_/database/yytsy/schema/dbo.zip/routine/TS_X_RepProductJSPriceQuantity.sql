




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

查询内部结算商品的数量
@lMode 0 外调销售表，统计本单位对应仓库被其它单位销售
       1 内调销售表，统计本单位销售其它单位的对应仓库
       2 自调销售表，统计与外调销售表相同，选择本部门对应的经手人，就是自调表 
       3 外调销售汇总表
       4 内调销售汇总表

********************************************/
CREATE PROCEDURE [TS_X_RepProductJSPriceQuantity]
( @lMode        INT=0,
  @lClientID    INT=0,
  @lEmployeeID  INT=0,
  @BeginDate    VARCHAR(10)='',
  @EndDate      VARCHAR(10)=''
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @lMode is null  SET @lMode = 0
if @lClientID is null  SET @lClientID = 0
if @lEmployeeID is null  SET @lEmployeeID = 0
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
/*Params Ini end*/
  
	SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000)
  DECLARE @szEID     VARCHAR(10)

  IF @lEmployeeID=0 SELECT @szEID='%%'
  ELSE 
  BEGIN
    SELECT @szEID=[Class_ID] FROM Employees WHERE [Emp_ID]=@lEmployeeID
    SET @szEID=@szEID+'%'
  END

  IF @lMode=0 GOTO QuerySaleOutQuantity
  IF @lMode=1 GOTO QuerySaleInQuantity
  IF @lMode=2 GOTO QuerySaleOutQuantity
  IF @lMode=3 GOTO QuerySaleOutSumQuantity
  IF @lMode=4 GOTO QuerySaleInSumQuantity
  ELSE GOTO SUCCEE

/**************************************************************
外调销售表
**************************************************************/
QuerySaleOutQuantity:

  SELECT 
  P.[Product_ID], P.[Class_ID], 
  P.[Code],       P.[Name], 
  P.[Alias],      P.[Standard], 
  P.[PermitCode], P.[Makearea], 
  P.[Medtype],    P.[Unitname1], 
  ISNULL(PD.[Department_ID] ,0)        AS [Department_ID],
  ISNULL(PD.[S_ID]          ,0)        AS [S_ID],
  ISNULL(PD.[JsPrice]       ,0)        AS [JSPrice],
  ISNULL(PD.[BillDate]      ,'')       AS [BillDate],
  ISNULL(PD.[BillNumber]    ,'')       AS [BillNumber],
  ISNULL(PD.[E_ID]          ,0)        AS [E_ID],
  ISNULL(PD.[Inputman]      ,'')       AS [Inputman],
  ISNULL(PD.[DepartmentName],'')       AS [DepartmentName],
  ISNULL(PD.[SName]         ,'')       AS [SName],
  ISNULL(PD.[Quantity]      ,0)        AS [Quantity],
  CAST(ISNULL(PD.[CostTotal],0) AS NUMERIC(25,8)) AS [CostTotal],
  CAST(ISNULL(PD.[TaxPrice] ,0) AS NUMERIC(25,8)) AS [SalePrice],  
  CAST(ISNULL(PD.[JSTotal]  ,0) AS NUMERIC(25,8)) AS [JSTotal],
  CAST(ISNULL(PD.[Total]    ,0) AS NUMERIC(25,8)) AS [Total],
  CAST(ISNULL(PD.[SendQTY]  ,0) AS NUMERIC(25,8)) AS [SendQTY],
  CAST(ISNULL(PD.[SendCostTotal] ,0) AS NUMERIC(25,8)) AS [SendCostTotal],
  CAST(ISNULL(PD.[SendTotal]    ,0) AS NUMERIC(25,8)) AS [SendTotal]
  FROM VW_C_Products P, 
  (SELECT PD.[P_ID], BI.[Department_ID], BI.[DepartmentName], BI.[BillDate], 
  BI.[Billnumber], BI.[Inputman], BI.[E_ID], PD.[JSPrice],
  PD.[S_ID], PD.[Sname], PD.[Taxprice],
  -(PD.[Quantity])              AS [Quantity],
  -(PD.[CostTotal])             AS [CostTotal],
  -(PD.[JSPrice]*PD.[Quantity]) AS [JSTotal],
  -(PD.[Totalmoney])            AS [Total],
  -(PD.[SendQTY])               AS [SendQTY],
  -(PD.[SendCostTotal])         AS [SendCostTotal],
  -(PD.Totalmoney/PD.quantity*PD.SendQTY) AS [Sendtotal]
  FROM VW_C_BillIDX BI, VW_L_pDetailBySMBM PD
  WHERE BI.[BillID]=PD.[BillID] AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate 
  AND BI.[Department_ID]<>@lClientID
  AND BI.[BillStates] IN (0) AND [BillType] IN (10,11,12,13,32,112,210,211)
  AND BI.[EClass_ID] LIKE @szEID 
  AND PD.[S_ID] IN (SELECT [S_ID] FROM VW_X_UnionClient WHERE [C_ID]=@lClientID)) PD
  WHERE P.[Deleted]<>1 AND P.[Product_ID]=PD.[P_ID]
  ORDER BY PD.[Department_ID], P.[Product_ID]

  GOTO SUCCEE


/**************************************************************
内调销售表
**************************************************************/
QuerySaleInQuantity:

  SELECT 
  P.[Product_ID], P.[Class_ID], 
  P.[Code],       P.[Name], 
  P.[Alias],      P.[Standard], 
  P.[PermitCode], P.[Makearea], 
  P.[Medtype],    P.[Unitname1], 
  ISNULL(PD.[Department_ID] ,0)        AS [Department_ID],
  ISNULL(PD.[S_ID]          ,0)        AS [S_ID],
  ISNULL(PD.[JsPrice]       ,0)        AS [JSPrice],
  ISNULL(PD.[BillDate]      ,'')       AS [BillDate],
  ISNULL(PD.[BillNumber]    ,'')       AS [BillNumber],
  ISNULL(PD.[E_ID]          ,0)        AS [E_ID],
  ISNULL(PD.[Inputman]      ,'')       AS [Inputman],
  ISNULL(PD.[DepartmentName],'')       AS [DepartmentName],
  ISNULL(PD.[SName]         ,'')       AS [SName],
  ISNULL(PD.[Quantity]      ,0)        AS [Quantity],
  CAST(ISNULL(PD.[CostTotal],0) AS NUMERIC(25,8)) AS [CostTotal],
  CAST(ISNULL(PD.[TaxPrice] ,0) AS NUMERIC(25,8)) AS [SalePrice],  
  CAST(ISNULL(PD.[JSTotal]  ,0) AS NUMERIC(25,8)) AS [JSTotal],
  CAST(ISNULL(PD.[Total]    ,0) AS NUMERIC(25,8)) AS [Total]

  FROM VW_C_Products P, 
  (SELECT PD.[P_ID], BI.[Department_ID], BI.[DepartmentName], BI.[BillDate],
  BI.[Billnumber], BI.[Inputman], BI.[E_ID], PD.[JSPrice],
  PD.[S_ID], PD.[Sname], PD.[Taxprice],
  -(PD.[Quantity])              AS [Quantity],
  -(PD.[CostTotal])             AS [CostTotal],
  -(PD.[JSPrice]*PD.[Quantity]) AS [JSTotal],
  -(PD.[Totalmoney])            AS [Total]
  FROM VW_C_BillIDX BI, VW_L_pDetailBySMBM PD
  WHERE BI.[BillID]=PD.[BillID] AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate 
  AND BI.[Department_ID]=@lClientID
  AND BI.[BillStates] IN (0) AND [BillType] IN (10,11,12,13,32,112,210,211)
  AND BI.[EClass_ID] LIKE @szEID ) PD
  WHERE P.[Deleted]<>1 AND P.[Product_ID]=PD.[P_ID]
  ORDER BY PD.[S_ID], P.[Product_ID]

  GOTO SUCCEE

/**************************************************************
外调销售汇总表
**************************************************************/
QuerySaleOutSumQuantity:

  SELECT BI.[Department_ID], BI.[DepartmentName], PD.[S_ID], PD.[Sname], 
  SUM(-(PD.[Quantity]))              AS [Quantity],
  CAST(SUM(-(PD.[CostTotal])) AS numeric(25,8)) AS [CostTotal],
  SUM(-(PD.[Totalmoney]))                 AS [Total],
  SUM(-(PD.[JSPrice]*PD.[Quantity])) AS [JSTotal]
  FROM VW_C_BillIDX BI, VW_L_pDetailBySMBM PD
  WHERE BI.[BillID]=PD.[BillID] AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate 
  AND BI.[Department_ID]<>@lClientID
  AND BI.[BillStates] IN (0) AND [BillType] IN (10,11,12,13,32,112,210,211)
  AND BI.[EClass_ID] LIKE @szEID 
  AND PD.[S_ID] IN (SELECT [S_ID] FROM VW_X_UnionClient WHERE [C_ID]=@lClientID)
  GROUP BY BI.[Department_ID], BI.[DepartmentName], PD.[S_ID], PD.[Sname]
  ORDER BY BI.[Department_ID]

  GOTO SUCCEE


/**************************************************************
内调销售汇总表
**************************************************************/
QuerySaleInSumQuantity:

  SELECT BI.[Department_ID], BI.[DepartmentName], PD.[S_ID], PD.[Sname], 
  SUM(-(PD.[Quantity]))              AS [Quantity],
  Cast(SUM(-(PD.[CostTotal]))as NUMERIC(25,8))  AS [CostTotal],
  SUM(-(PD.[Totalmoney]))                 AS [Total],
  SUM(-(PD.[JSPrice]*PD.[Quantity])) AS [JSTotal]
  FROM VW_C_BillIDX BI, VW_L_pDetailBySMBM PD
  WHERE BI.[BillID]=PD.[BillID] AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate 
  AND BI.[Department_ID]=@lClientID
  AND BI.[BillStates] IN (0) AND [BillType] IN (10,11,12,13,32,112,210,211)
  AND BI.[EClass_ID] LIKE @szEID 
  GROUP BY BI.[Department_ID], BI.[DepartmentName], PD.[S_ID], PD.[Sname]
  ORDER BY BI.[Department_ID]

  GOTO SUCCEE


SUCCEE:
  RETURN  0
GO
