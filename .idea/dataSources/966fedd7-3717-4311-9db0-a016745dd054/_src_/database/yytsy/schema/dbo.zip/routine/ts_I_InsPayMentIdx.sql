CREATE	 PROCEDURE ts_I_InsPayMentIdx
@nRET int,
@billdate datetime,
@billnuber varchar(50),
@invoiceNumber varchar(50),
@c_id int = 0,
@e_id int = 0,
@paymoney NUMERIC(25,8),
@comment varchar(800),
@Y_id int =0
as
begin 
  insert into PayMentIdx(
  BillDate,BillNumber,InvoiceNumber,CreateDate,BillStates,C_Id,E_Id,PayMoney,Comment,Y_id,billtype
  ) values
  (
  @billdate,@billnuber,@invoiceNumber,GETDATE(),0,@c_id,@e_id,@paymoney,@comment,@Y_id,202
  )
  if @@rowCount=0 
  begin
	 return -1
  end else
     exec ts_b_GetBillSN 0,'',202,1,@e_id 
     set @nRET = @@IDENTITY 
	 return @nRET
end
GO
