








CREATE VIEW dbo.vw_L_StockLimit
AS
SELECT isnull(s.class_id,'') AS sClass_id, isnull(s.name,'') AS SName, 
      sl.SLID,sl.P_id,sl.S_id,sl.UpperLimit,sl.LowLimit,sl.AdjQty,
      sl.Y_ID,sl.ByWayDay,sl.PlanDay,sl.sa_id,p.Unit1Name AS Unit1Name,   
      p.MedName AS MedName, p.class_id AS PClass_id, p.name AS PName,   
      p.alias AS Alias, p.standard AS Standard, p.modal AS Modal,   
      p.permitcode AS permitcode, p.trademark AS trademark,   
      p.makearea AS makearea  
FROM dbo.StoreLimit sl LEFT OUTER JOIN  
      dbo.vw_Products p ON sl.P_id = p.product_id LEFT OUTER JOIN  
      dbo.storages s ON sl.S_ID = s.storage_id
GO
