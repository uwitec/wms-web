
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-23*/
/* Description:	转换批次条码*/
/* =============================================*/
CREATE FUNCTION FN_MakeBatchCode 
(
	@nPid int,					/* 商品ID*/
	@szBatchNo varchar(30),		/* 批号*/
	@dtValidDate datetime		/* 效期*/
)
RETURNS varchar(20)
AS
BEGIN
	DECLARE @Result varchar(20)
	DECLARE @sDeal varchar(9)
	DECLARE @iLen int
	DECLARE @iSource int
	DECLARE @sAsc varchar(80)
	DECLARE @iBatch bigint
	/* 商品*/
	SELECT @Result = '^' + dbo.FN_EncodeIntStr(@nPid, 4)

	/* 批号*/
	DECLARE @iDays int
	SET @sAsc = ''

	SET @sDeal = RIGHT(RTRIM(UPPER(@szBatchNo)), 9)
	SET @iLen= LEN(@sDeal)
	while @iLen > 0
	begin
		SET @iSource = ASCII(SUBSTRING(@sDeal, @iLen, 1))
		if @iSource < 128
			SET @sAsc = dbo.PadLeft(CAST(@iSource % 120 AS VARCHAR(2)), 2, '0') + @sAsc
		else
			SET @sAsc = '00' + @sAsc
		SET @iLen = @iLen - 1
	end
	IF @sAsc = '' SET @sAsc = '0'
	SET @iBatch = CAST(@sAsc AS bigint)
	SET @Result = @Result + dbo.FN_EncodeIntStr(@iBatch, 12)
	/*效期*/
	SET @iDays = DATEDIFF(dd, '2000-1-1', @dtValidDate)
	IF @dtValidDate < '2000-1-1' SET @iDays = 0
	SET @Result = @Result + dbo.FN_EncodeIntStr(@iDays, 3)

	RETURN @Result
END
GO
