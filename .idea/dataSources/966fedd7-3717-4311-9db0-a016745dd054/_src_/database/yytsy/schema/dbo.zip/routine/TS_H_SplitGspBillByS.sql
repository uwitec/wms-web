/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-15*/
/* Description:	按仓库拆分GSP单据*/
/* =============================================*/
CREATE PROCEDURE TS_H_SplitGspBillByS 
	@nBillID int = 0
AS
BEGIN
	SET NOCOUNT ON;

	if @nBillId is null set @nBillId = 0
	
	if @nBillId <= 0
		RETURN -1

	DECLARE @nNewBillId int
	DECLARE @nSid int, @nSA_ID int
	DECLARE @nBillCount int
	DECLARE @nStorageCount int
	DECLARE @uBillGuid uniqueidentifier
	DECLARE @nRemainSid int
	DECLARE @szBillNumber varchar(80)
	DECLARE @nEid int
	DECLARE @nBillType int
	DECLARE @nYBillType int
	DECLARE @nYBillId int
	DECLARE @nYid int

	SET @nBillCount = 0
	
	if exists (select 1 from sysconfigtmp where sysvalue = '1' and [sysname] = 'yndz001')	
	begin
	 	 
     
 		  select @nStorageCount = count(1) from 
		  (SELECT DISTINCT mx.s_id, ISNULL(l.sa_Id, 0) as pickSaid FROM GSPbilldetail mx 
		      left join location l on mx.Location_id = l.loc_id  WHERE Gspbill_id = @nBillID) t
		      		      		  		
		IF @nStorageCount <= 1
			RETURN 0


		DECLARE curSplit CURSOR FOR
		SELECT DISTINCT mx.s_id, isnull(l.sa_id, 0) as sa_id FROM GSPbilldetail mx
		        left join location l on mx.Location_id = l.loc_id    
		 WHERE Gspbill_id = @nBillId
		OPEN curSplit
		FETCH NEXT FROM curSplit INTO @nSid, @nSa_id
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nBillCount = @nBillCount + 1
			SET @uBillGuid = NEWID()

			SELECT @nEid = inputman, @nBillType = billtype, @nYid = Y_id, @nYBillId = Ybillid, @nYBillType = 154 from GSPbillidx where Gspbillid = @nBillID

			EXEC TS_H_CreateBillSN @nBillType, 1, null, @nEid, @nEid, @szBillNumber output, @nYid

			INSERT INTO GSPbillidx(BillType, BillNumber, Y_id, C_id, S_id, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, 
					UpauditMan1, UpauditMan2, TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, 
					SendTime, TrafficCompany, TempControlMode, WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					GUID, BillStates, B_CustomName1, B_CustomName2, B_CustomName3, B_CustomName4, B_CustomName5, 
					Note,YE_Id)
			SELECT BillType, @szBillNumber, Y_id, C_id, 0, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, 
					UpauditMan1, UpauditMan2, TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, 
					SendTime, TrafficCompany, TempControlMode, 0, 0, 0, 0, Ybillid, Ybilltype, Yguid, 
					Yguid, BillStates, B_CustomName1, B_CustomName2, B_CustomName3, B_CustomName4, B_CustomName5, 
					Note,@nEid
			FROM GSPbillidx WHERE Gspbillid = @nBillId

			SET @nNewBillId = @@IDENTITY

			INSERT INTO GSPbilldetail(Gspbill_id, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, 
					RefuseQty, PickQty, CheckQty, SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, 
					Pricediscrepancy, Total, Discount, DiscountTotal, TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, 
					RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept, CheckReport, ReturnReason, CheckState, 
					CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode, Batchcomment, BatchPrice, 
					Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2, 
					Comment3,factoryid,costtaxprice,costtaxrate,costtaxtotal)
			SELECT @nNewBillId, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, 
					RefuseQty, PickQty, CheckQty, SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, 
					Pricediscrepancy, Total, Discount, DiscountTotal, TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, 
					RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept, CheckReport, ReturnReason, CheckState, 
					CheckReason, mx.S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode, Batchcomment, BatchPrice, 
					Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, NEWID(), Comment, Comment2, 
					Comment3,factoryid,costtaxprice,costtaxrate,costtaxtotal
			FROM GSPbilldetail mx
			     left join location l on mx.Location_id = l.loc_id	
			WHERE Gspbill_id = @nBillId AND mx.S_id = @nSid and			      
				  (@nSA_ID = 0 and (l.sa_id = 0 or l.sa_id is null)) or (@nSA_ID  <> 0 and l.sa_id = @nSA_ID)
			
			IF @@ROWCOUNT > 0
			BEGIN
				UPDATE GSPbillidx SET TaxTotal = X.TaxTOTAL, DiscountTotal = X.DiscountTOTAL, S_id = x.s_id
				FROM(SELECT SUM(taxtotal) AS TaxTOTAL, SUM(DiscountTOTAL) AS DiscountTOTAL, MIN(s_id) AS s_id FROM GSPbilldetail WHERE Gspbill_id = @nNewBillId) X
				WHERE GSPbillidx.Gspbillid = @nNewBillId
				EXEC TS_H_BillTraceAct 0, @nNewBillId, 541, @nYBillId, @nYBillType
			END
			ELSE
				DELETE FROM GSPbillidx WHERE GSPbillid = @nNewBillId

			FETCH NEXT FROM curSplit INTO @nSid
		END
		CLOSE curSplit
		deallocate curSplit

		DELETE FROM GSPbilldetail WHERE Gspbill_id = @nBillID
		DELETE FROM GSPbillidx WHERE Gspbillid = @nBillID
		
	end
	else begin /*按仓库生成*/

		SELECT @nStorageCount = COUNT(DISTINCT(s_id)) FROM GSPbilldetail WHERE Gspbill_id = @nBillID
		IF @nStorageCount <= 1
			RETURN 0

		SELECT @nRemainSid = MIN(S_ID) FROM GSPbilldetail WHERE Gspbill_id = @nBillID

		DECLARE curSplit CURSOR FOR
		SELECT DISTINCT s_id FROM GSPbilldetail WHERE Gspbill_id = @nBillId AND S_id <> @nRemainSid
		OPEN curSplit
		FETCH NEXT FROM curSplit INTO @nSid
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nBillCount = @nBillCount + 1
			SET @uBillGuid = NEWID()

			SELECT @nEid = inputman, @nBillType = billtype, @nYid = Y_id, @nYBillId = Ybillid, @nYBillType = 154 from GSPbillidx where Gspbillid = @nBillID

			EXEC TS_H_CreateBillSN @nBillType, 1, null, @nEid, @nEid, @szBillNumber output, @nYid

			INSERT INTO GSPbillidx(BillType, BillNumber, Y_id, C_id, S_id, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, 
					UpauditMan1, UpauditMan2, TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, 
					SendTime, TrafficCompany, TempControlMode, WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					GUID, BillStates, B_CustomName1, B_CustomName2, B_CustomName3, B_CustomName4, B_CustomName5, 
					Note,YE_Id)
			SELECT BillType, @szBillNumber, Y_id, C_id, 0, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, 
					UpauditMan1, UpauditMan2, TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, 
					SendTime, TrafficCompany, TempControlMode, 0, 0, 0, 0, Ybillid, Ybilltype, Yguid, 
					Yguid, BillStates, B_CustomName1, B_CustomName2, B_CustomName3, B_CustomName4, B_CustomName5, 
					Note,@nEid
			FROM GSPbillidx WHERE Gspbillid = @nBillId

			SET @nNewBillId = @@IDENTITY

			INSERT INTO GSPbilldetail(Gspbill_id, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, 
					RefuseQty, PickQty, CheckQty, SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, 
					Pricediscrepancy, Total, Discount, DiscountTotal, TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, 
					RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept, CheckReport, ReturnReason, CheckState, 
					CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode, Batchcomment, BatchPrice, 
					Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2, 
					Comment3,factoryid,costtaxprice,costtaxrate,costtaxtotal)
			SELECT @nNewBillId, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, 
					RefuseQty, PickQty, CheckQty, SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, 
					Pricediscrepancy, Total, Discount, DiscountTotal, TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, 
					RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept, CheckReport, ReturnReason, CheckState, 
					CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode, Batchcomment, BatchPrice, 
					Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, NEWID(), Comment, Comment2, 
					Comment3,factoryid,costtaxprice,costtaxrate,costtaxtotal
			FROM GSPbilldetail WHERE Gspbill_id = @nBillId AND S_id = @nSid

			IF @@ROWCOUNT > 0
			BEGIN
				UPDATE GSPbillidx SET TaxTotal = X.TaxTOTAL, DiscountTotal = X.DiscountTOTAL, S_id = x.s_id
				FROM(SELECT SUM(taxtotal) AS TaxTOTAL, SUM(DiscountTOTAL) AS DiscountTOTAL, MIN(s_id) AS s_id FROM GSPbilldetail WHERE Gspbill_id = @nNewBillId) X
				WHERE GSPbillidx.Gspbillid = @nNewBillId
				EXEC TS_H_BillTraceAct 0, @nNewBillId, 541, @nYBillId, @nYBillType
			END
			ELSE
				DELETE FROM GSPbillidx WHERE GSPbillid = @nNewBillId

			FETCH NEXT FROM curSplit INTO @nSid
		END
		CLOSE curSplit
		deallocate curSplit

		DELETE FROM GSPbilldetail WHERE Gspbill_id = @nBillID AND S_id <> @nRemainSid

		UPDATE GSPbillidx SET TaxTotal = X.TaxTOTAL, DiscountTotal = X.DiscountTOTAL, S_id = x.s_id
		FROM(SELECT SUM(taxtotal) AS TaxTOTAL, SUM(DiscountTOTAL) AS DiscountTOTAL, MIN(s_id) AS s_id FROM GSPbilldetail WHERE Gspbill_id = @nBillID) X
		WHERE GSPbillidx.Gspbillid = @nBillID
	
	end /*按仓库生成*/
	
END
GO
