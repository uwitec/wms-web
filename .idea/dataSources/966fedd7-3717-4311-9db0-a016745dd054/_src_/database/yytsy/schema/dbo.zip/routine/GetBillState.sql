
CREATE FUNCTION GetBillState
(
	@billid             INT
)
RETURNS VARCHAR(800)
AS
BEGIN
	DECLARE @sResult VARCHAR(800)
	DECLARE @Result VARCHAR(800)
	DECLARE @billtype int
    select @billtype=max(billtype) from  gspbillidx  where yguid in (select Guid from orderidx where billid=@billid and billtype=14) and billtype in (541,551)
	if 	@billtype=551 
	begin
		    select @Result= Case BILLSTATES when 10 then '复核中' else '' end  from  gspbillidx  where yguid in
	          (select Guid from orderidx where billid=@billid and billtype=14) and  billtype=551
		  if @Result=''
		  begin
			   select @Result=(Case when a.Sendid = 0 then '待配送' when ISNULL(b.Transportation_States,0) = 2 then '配送完成' else '配送中' end )
			          from gspbillidx a left join Sendmangebill b on a.Gspbillid=b.billid
			          where gspbillid in (
										     select gspbillid from  gspbillidx  where yguid in
										     (select Guid from orderidx where billid=@billid and billtype=14) and  billtype=551
			                              ) and billtype=551
		  end
	end		
	if 	@billtype=541 
	begin		
	      select @Result= Case BillStates when 10 then '待拣货' when 14 then '拣货中' end  from  gspbillidx  where yguid in
	          (select Guid from orderidx where billid=@billid and billtype=14) and  billtype=541
	end	
	set @sResult=@Result 
	RETURN @sResult	
END
GO
