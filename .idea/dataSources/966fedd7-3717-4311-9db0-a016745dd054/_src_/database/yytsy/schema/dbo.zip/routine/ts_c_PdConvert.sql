
/*从盘点单转换到报损报溢单*/
create proc ts_c_PdConvert
(
	@billid int
)
/*with encryption*/
as
set nocount on 

declare @nNewBillid int,@dTotalMoney numeric(20,4),@dQuantity numeric(20,4)
declare @billnumber varchar(30),@note varchar(300),@oldbillnumber varchar(100),@oldnote varchar(256)
declare @Y_ID		int


 declare @bWmsPD int 
  select @bWmsPD = isnull(CAST(sysvalue as int), 0) from sysconfigtmp where [sysname]= 'jointechwmspd'
  if @bWmsPD is null set @bWmsPD = 0
  if @bWmsPD = 1  /*启用盘点接口程序时，不再生成报损报溢单*/
    Return 0
  

select @Y_ID=Y_id,@oldbillnumber=billnumber,@oldnote=note from billdraftidx where billid=@billid
set @note=''
begin tran pdConvert
/*生成报损单*/
	/*1、生成临时表*/
	/*2、生成表头        */
		if exists(select 1 from goodscheckbilldrf where bill_id=@billid and totalmoney<0)
		begin
			insert billdraftidx 
			(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
			select billdate,'',41,a_id,c_id,e_id,sout_id,sin_id,'',inputman,ysmoney,ssmoney,quantity,taxrate,period,'2',order_id,department_id,posid,region_id,@Y_ID, summary,0,'1900-01-01'
			from billdraftidx 
			where billid=@billid 
			if @@error<>0 goto error
			select @nNewBillId=@@identity
		/*3、生成表体*/
		    
		
		
			insert storemanagebilldrf
			(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
			 supplier_id,commissionflag,unitid,total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
			select @nNewBillId,p_id,batchno,abs(totalmoney),costprice,abs(totalmoney*costprice),costprice,abs(totalmoney*costprice),retailprice,abs(retailtotal),makedate,validdate,price_id,ss_id,sd_id,location_id,
			       supplier_id,commissionflag,unitid,abs(totalmoney*costprice),aoid, instoretime, Y_ID, costtaxprice, costtaxrate, abs(totalmoney*costtaxprice), factoryid
			from goodscheckbilldrf
			where bill_id=@billid and totalmoney<0
			if @@error<>0 goto error
	
			set @billnumber='BS'+right(cast(100000000+@nNewBillId as varchar),8)
		  set @oldnote=@oldnote+'  已生成报损单：【'+@billnumber+'】'
			set @note='从盘点单:【'+@oldbillnumber+'】生成的报损单'
			select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
			update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
			if @@error<>0 goto error
		end
		set @nNewBillId=0

/*生产报溢单*/
	/*1、生成临时表*/

		if exists(select * from goodscheckbilldrf where bill_id=@billid and totalmoney>0)
		begin
			insert billdraftidx 
			(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
			select billdate,'',42,a_id,c_id,e_id,sout_id,sin_id,'',inputman,ysmoney,ssmoney,quantity,taxrate,period,'2',order_id,department_id,posid,region_id,@Y_ID, summary,0,'1900-01-01'
			from billdraftidx 
			where billid=@billid 
			if @@error<>0 goto error
			select @nNewBillId=@@identity
		/*3、生成表体*/
			insert storemanagebilldrf
			(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
			 supplier_id,commissionflag,unitid,total,aoid, instoretime,Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
			select @nNewBillId,p_id,batchno,abs(totalmoney),costprice,abs(totalmoney*costprice),costprice,abs(totalmoney*costprice),retailprice,retailtotal,makedate,validdate,price_id,ss_id,sd_id,location_id,
			        supplier_id,commissionflag,unitid,abs(totalmoney*costprice),aoid,instoretime,Y_ID, costtaxprice, costtaxrate, abs(totalmoney*costtaxprice), factoryid
			from goodscheckbilldrf
			where bill_id=@billid and totalmoney>0
			if @@error<>0 goto error
	
			set @billnumber='BY'+right(cast(100000000+@nNewBillId as varchar),8)
		  set @oldnote=@oldnote+',报溢单【'+@billnumber+'】'
			select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
			set @note='从盘点单:【'+@oldbillnumber+'】生成的报溢单'
			update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
			update billdraftidx set note=@oldnote where billid=@BillId
	
			if @@error<>0 goto error
		end	
commit tran pdConvert
return 0

error:
rollback tran pdConvert
return -1
GO
