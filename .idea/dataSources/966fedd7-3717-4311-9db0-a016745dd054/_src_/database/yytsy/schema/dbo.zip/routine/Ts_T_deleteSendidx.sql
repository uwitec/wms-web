/************************************************************
--过程名称：Ts_T_SendSaleDetail
--功能：删除物流单草稿并把单据状态改为未配送
--创建人：LUO XIAOTIAN 
--创建时间：2011-03-12  
--最后修改:


参数说明：
		   

备注：
**************************************************************/
create proc [dbo].[Ts_T_deleteSendidx]
(@billid int
)
as
  if exists(select 1 from  Sendidx where Send_id=@billid and billstates=1)
  begin
     update billidx set Sendid=0 where billid in (select billid from Sendmangebill where sendid=@billid)
     delete from  Sendmangebill where Sendid=@billid
     delete Sendidx where Send_id=@billid and billstates=1
     DELETE FROM GspTable WHERE BillId = @billid AND BillType = 186
  end
GO
