
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-10*/
/* Description:	查询职员授权商品提成明细*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepEmpDeductDetail] 
	@BeginDate		datetime,
	@EndDate		datetime,
	@E_ID			int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT     p_id, standard, makearea, medtype, unit, name, cast(quantity as money) as quantity, cast(CostTotal as money) as CostTotal, cast(SaleTotal as money) as SaleTotal, cast(TaxTotal as money) as TaxTotal, deduct * 100 AS deduct, cast(SaleTotal - CostTotal as money) AS ml, 
						  (SaleTotal - CostTotal) / SaleTotal AS mll, SaleTotal * deduct AS deductTotal
	FROM         (SELECT     t.p_id, t.standard, t.makearea, t.medtype, t.unit, t.name, SUM(b.quantity * t.direction) AS quantity, SUM(b.SendCostTotal * t.direction) 
												  AS CostTotal, SUM(b.totalmoney * t.direction) AS SaleTotal, SUM(b.taxtotal * t.direction) AS TaxTotal, e.deduct
						   FROM          (SELECT     d.emp_id, d.p_id, d.bill_id, p.standard, p.makearea, m.name AS medtype, u.name AS unit, p.name, 
																		  d.price * 2 - 1 AS direction
												   FROM          dbo.EmpDeduct AS d INNER JOIN
																		  dbo.products AS p ON d.p_id = p.product_id INNER JOIN
																		  dbo.unit AS u ON p.unit1_id = u.unit_id INNER JOIN
																		  (
																			select P_id as baseinfo_id,name from ProductCategory p  
																			inner join customCategory c on p.PComent3 = c.class_id
																			and c.deleted = 0 and Child_Number = 0 and Category_id = 3
																		  )m on p.product_id = m.baseinfo_id
												   GROUP BY d.emp_id, d.bill_id, p.standard, p.makearea, u.name, p.name, d.price * 2 - 1, d.p_id, m.name) AS t INNER JOIN
												  dbo.salemanagebill AS b ON t.p_id = b.p_id AND t.bill_id = b.bill_id INNER JOIN
												  dbo.billidx AS i ON t.bill_id = i.billid INNER JOIN
												  dbo.employees AS e ON t.emp_id = e.emp_id
						   WHERE      (i.billdate BETWEEN @BeginDate AND @EndDate) AND (e.emp_id = @E_ID) AND (i.billstates NOT IN(1, 4))
						   GROUP BY t.p_id, t.standard, t.makearea, t.medtype, t.unit, t.name, e.deduct) AS x
				WHERE x.quantity > 0
END
GO
