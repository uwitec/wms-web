











CREATE       PROCEDURE [Ts_L_InsEmp]
 (@parent_id [varchar](30),
  @name [varchar](80),
  @alias  [varchar](30),
  @serial_number  [varchar](26),
  @dep_id [int],
  @phone  [varchar](60),
  @address [varchar](66),
  @comment [varchar](256),
  @aplimit NUMERIC(25,8),
  @arlimit NUMERIC(25,8),
  @discountlimit  [numeric](3,2),
  @pinyin [varchar](80),
  @LowPrice [numeric](5,4),
  @HighPrice [numeric](5,4),
  @Duty  varchar(20),
  @Study varchar(20),
  @GraduateDate Datetime,
  @Teach Varchar(20),
  @szWork varchar(20),
  @inDate Datetime,
  @Tp_ID int,
  @CertNo varchar(50),
  @IdCard varchar(20),
  @RowIndex int,    /*Wsk ADD*/
  @Deduct        numeric(8,4),
  @Y_id   int,
  @GradeId	int
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/
/*if exists(select * from products where )*/
if exists(select 1 from employees where serial_number=@serial_number and deleted=0)
begin
 RAISERROR('编号重复！不能添加！！',16,1)
 return -2
end

if exists(select 1 from employees where name=@name and deleted=0)
begin
 RAISERROR('名称重复！不能添加！！',16,1)
 return -2
end

/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Employees')
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*BEGIN TRAN insertBaseEmp*/

INSERT INTO [employees] 
  ( [class_id],
  [parent_id],
  [name],
  [alias],
  [serial_number],
  [dep_id],
  [phone],
  [address],
  [comment],
  [aplimit],
  [arlimit],
  [discountlimit],
  [pinyin],
  [LowPrice],
  [highPrice],
  [Duty],
  [Study],
  [GraduateDate],
  [Teach],
  [szWork],
  [inDate],
  [Tp_ID],
  [CertNo],
  [IdCard],
  [RowIndex],  /*Wsk ADD*/
  [Deduct],
  [Y_id],
  [GradeID]
  )
 
VALUES 
 (  @Tempid,
  @parent_id,
  @name,
  @alias,
  @serial_number,
  @dep_id,
  @phone,
  @address,
  @comment,
  @aplimit,
  @arlimit,
  @discountlimit,
  @pinyin,
  @LowPrice,
  @highPrice,
  @Duty,
  @Study,
  @GraduateDate,
  @Teach,
  @szWork,
  @inDate,
  0,/*@Tp_ID, 提成方案设置转移到单独模块*/
  @CertNo,
  @IDCard,
  @RowIndex,   /*Wsk ADD*/
  @Deduct,
  @Y_id,
  @GradeId
  )
if @@rowCount=0 
begin
/* rollback tran insertBaseEmp*/
 return -1
end else
begin
 update Employees set child_number=@child_number,child_count=@child_count,Y_ID=@Y_ID
 where class_id =@Parent_id
 return @@identity
end
/* commit tran insertBaseEmp*/
GO
