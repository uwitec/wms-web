
CREATE VIEW dbo.vw_Region
AS
SELECT rowindex ,region_id  ,name ,comment ,parent_id,child_count,child_number,serial_number,class_id,pinyin  
FROM dbo.region  R
WHERE (deleted = 0)
GO
