

/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/


/*查询往业单位预收、预付余额 上期余额,本期，期末，当前
 2007-12-05
*/
CREATE PROCEDURE TS_S_QrClientPreArAp
(@BeginDate Datetime = 0,
 @EndDate   Datetime = 0,
 @szCClass_ID VARCHAR(30) = '',
 @ListMode varchar(10) = 'L',             /*列表方式*/
 @szCurrentParentId Varchar(36) = '000000',
 @OperatorID INT = 0,
 @YClass_id  varchar(60)=''
)
AS
BEGIN
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szCClass_ID is null  SET @szCClass_ID = ''
if @ListMode is null  SET @ListMode = 'L'
if @szCurrentParentId is null  SET @szCurrentParentId = '000000'
if @OperatorID is null  SET @OperatorID = 0
if @YClass_id is null  SET @YClass_id = ''
/*Params Ini end*/
/*--------------分支机构*/
   DECLARE @Companytable int,@ClientTable INT
   DECLARE @SQLYClassId varchar(200)
   if @YClass_id='' select @YClass_id='%%' else select @YClass_id=@YClass_id+'%'
   
  Declare @YId int 
  set @YId=0
  SELECT @YId =company_id from company where Class_id=@YClass_id
/*------------------------------授权  */
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

  SELECT YAD.*
  INTO #YAccountDetail
  FROM
    (select YAD.*,ISNULL(C.[Class_ID] ,'') AS [CClass_ID], 
          ISNULL(A.[Class_ID] ,'') AS [AClass_ID], ISNULL(A.[Name]     ,'') AS [AccountName], 
          ISNULL(C.[Name]     ,'') AS [ClientName]
     from 
       (select ad.a_id,b.c_id,b.Y_id,jdmoney,billtype ,billdate,Y.class_id as Yclass_id,
        Y.superior_id,Y.Ytype
        from AccountDetail ad
        LEFT JOIN billidx B ON B.billid=ad.billid
        LEFT JOIN company Y ON ad.Y_id =Y.company_id
        where billtype not in (150,151,155,160,161,165) and billdate <= @EndDate
         /*and Y.class_id like @YClass_id  */
         and (@YID=0 or (Y.Company_ID=@YID or (Y.superior_id=@YID and Y.yType=1)) )
         and billstates=0
       )YAD
       LEFT JOIN Account A ON A.[Account_ID]=YAD.[A_ID] 
       LEFT JOIN Clients C ON C.[Client_ID]=YAD.[C_ID]
    )YAD
  WHERE ((@Companytable=0)or (YAD.Y_id in (select [id] from #Companytable)))
     /*AND YAD.YClass_ID like @YClass_id*/
     and (@YID=0 or (YAD.Y_ID=@YID or (YAD.superior_id=@YID and YAD.yType=1)) )
/*----------*/
   DECLARE @ArID varchar(30),
           @ApID varchar(30),
           @OldClass_ID varchar(30)
   SET @OldClass_ID = @szCClass_ID

   SELECT @ArID = '000002000005',@ApID = '000001000009'

   IF @szCClass_ID NOT IN('','%%','000000') AND @szCurrentParentId IN ('','%%','000000')
   SELECT @szCurrentParentId=LEFT(@szCClass_ID,LEN(@szCClass_ID) -6)

   IF @szCurrentParentId in ('', '%%') SELECT @szCurrentParentId='000000'
   IF @szCClass_ID IN ('','%%','000000') SELECT @szCClass_ID='%%' ELSE SELECT @szCClass_ID = @szCClass_ID + '%'

/* 期初  */
    select Class_ID,
           [S_Pre_ArTotal] = ISNULL(S.[S_Pre_ArTotal],0) + C.[pre_artotal_ini],
           [S_Pre_ApTotal] = ISNULL(S.[S_Pre_ApTotal],0) + C.[pre_aptotal_ini],
           [B_Pre_ArTotal] = ISNULL(B.[B_Pre_ArTotal],0),
           [B_Pre_ApTotal] = ISNULL(B.[B_Pre_ApTotal],0),
           [M_Pre_ArTotal] = ISNULL(M.[M_Pre_ArTotal],0) + C.[pre_artotal_ini],
           [M_Pre_ApTotal] = ISNULL(M.[M_Pre_ApTotal],0) + C.[pre_aptotal_ini],
           CB.[pre_artotal],
           CB.[pre_aptotal]   INTO #tmpTb
    from (select c.class_id,c.Child_Number,c.deleted,cb.* from ClientsBalance cb 
          inner join clients c on  c.client_id=cb.c_id
	  inner join company Y on cb.Y_id=Y.company_id 
          /*where  Y.class_id like @YClass_id*/
          where (@YID=0 or (Y.Company_ID=@YID or (Y.superior_id=@YID and Y.yType=1)) )
          
          )  C 
    left join
 /*上期末  */
   (select CClass_ID,Y_ID,
           S_Pre_ArTotal = SUM(Case AClass_ID when @ArID then jdMoney else 0 end),
           S_Pre_ApTotal = SUM(Case AClass_ID when @ApID then jdMoney else 0 end)
      from #YAccountDetail
      where Billdate <@BeginDate 
       and (AClass_ID like @ArID or AClass_ID like @ApID)
     group by CClass_ID,Y_ID) S on C.Class_ID = S.CClass_ID and s.Y_ID = c.Y_id
/*本期*/
    left join
    (select CClass_ID,Y_ID,
           B_Pre_ArTotal = SUM(Case AClass_ID when @ArID then jdMoney else 0 end),
           B_Pre_ApTotal = SUM(Case AClass_ID when @ApID then jdMoney else 0 end)
      from #YAccountDetail
     where  Billdate Between @BeginDate and @EndDate AND 
        (AClass_ID like @ArID or AClass_ID like @ApID)
     group by CClass_ID,Y_ID) B ON C.[Class_ID] = B.[CClass_ID] and c.Y_id = b.Y_ID
/*期末*/
    left join
   (select CClass_ID,Y_ID,
           M_Pre_ArTotal = SUM(Case AClass_ID when @ArID then jdMoney else 0 end),
           M_Pre_ApTotal = SUM(Case AClass_ID when @ApID then jdMoney else 0 end)
      from #YAccountDetail
     where Billdate <=@EndDate AND 
         (AClass_ID like @ArID or AClass_ID like @ApID)
     group by CClass_ID,Y_ID) M on C.[Class_ID] = M.[CClass_ID] and c.Y_id = m.Y_ID 
/*当前*/
     left join 
     (select CB.c_id,Y_ID,
	     Pre_ArTotal = SUM(CB.Pre_ArTotal), 
             Pre_ApTotal = SUM(CB.Pre_ApTotal) 
      from ClientsBalance CB 
      left join Company Y on Y.[company_id]=cb.[Y_ID]
	/*where Y.Class_ID like @YClass_id*/
	where (@YID=0 or (Y.Company_ID=@YID or (Y.superior_id=@YID and Y.yType=1)) )
	and (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and Y.class_id like u.psc_id+'%'))))
	group by c_id,Y_ID
	) CB on C.c_id = CB.C_ID and cb.Y_id = c.Y_id
 
    where C.[Class_ID] <> '000000' AND deleted in (0) AND Child_Number = 0
	
  if @ListMode = 'L' goto ListLeavel
  if @ListMode = 'P' goto ListPart
  if @ListMode = 'A' goto ListAll

ListLeavel:
     declare @nLen int, @szParentID varchar(30)
     select @szParentID = ''
     if (len(@szCurrentParentId) = 6 and @szCurrentParentId = '000000') or @szCurrentParentId in ('','%%')
       select @nLen = 6 ,@szParentID = '%'
     else
       select @nLen = len(@szCurrentParentId) + 6,@szParentID = @szCurrentParentId

     select  C.Client_ID,
            C.Serial_Number,C.[Name],C.Child_Number,c.child_number as Child_Count,C.Class_ID,C.Parent_ID,
            isnull(R.name,'') RegionName,C.csflag,
            S_Pre_ArTotal = ISNULL(S_Pre_ArTotal,0),
            S_Pre_ApTotal = ISNULL(S_Pre_ApTotal,0),
			B_Pre_ArTotal = ISNULL(B_Pre_ArTotal,0),
			B_Pre_ApTotal = ISNULL(B_Pre_ApTotal,0),
			M_Pre_ArTotal = ISNULL(M_Pre_ArTotal,0),
			M_Pre_ApTotal = ISNULL(M_Pre_ApTotal,0),
			Pre_ArTotal = ISNULL(T.Pre_ArTotal,0),
            Pre_ApTotal = ISNULL(T.Pre_ApTotal,0)
       from Clients C
       left join Region R on C.region_id=R.region_id
       left join
          (select left(Class_ID,@nLen) AS Class_ID,
                  SUM(S_Pre_ArTotal) as S_Pre_ArTotal ,
                  SUM(S_Pre_ApTotal) as S_Pre_ApTotal,
                  SUM(B_Pre_ArTotal) as B_Pre_ArTotal,
                  SUM(B_Pre_ApTotal) as B_Pre_ApTotal,
                  SUM(M_Pre_ArTotal) as M_Pre_ArTotal,
                  SUM(M_Pre_ApTotal) as M_Pre_ApTotal,
                  SUM(Pre_ArTotal) as Pre_ArTotal,
                  SUM(Pre_ApTotal) as Pre_ApTotal
            from #tmpTb where Class_ID like @szParentID + '%'
           Group by left (Class_ID,@nLen)) T
         on C.[Class_ID] = T.[Class_ID]
      where  C.Parent_ID like @szCurrentParentId
         and C.[Class_ID] like @szCClass_ID
         and C.[deleted] = 0
         AND ((@ClientTable=0) or (c.client_id in (select [id] from #Clienttable)))
        order by C.RowIndex
   goto  SUCCEE
ListPart:
IF @OldClass_ID <> left(@szCurrentParentID,Len(@OldClass_ID))
BEGIN
 select  C.Client_ID,
            C.Serial_Number,C.[Name],C.Child_Number,c.child_number as Child_Count,C.Class_ID,C.Parent_ID,
            isnull(R.name,'') RegionName,C.csflag,
            S_Pre_ArTotal = ISNULL(t.S_Pre_ArTotal,0),
            S_Pre_ApTotal = ISNULL(t.S_Pre_ApTotal,0),
			B_Pre_ArTotal = ISNULL(t.B_Pre_ArTotal,0),
			B_Pre_ApTotal = ISNULL(t.B_Pre_ApTotal,0),
			M_Pre_ArTotal = ISNULL(t.M_Pre_ArTotal,0),
			M_Pre_ApTotal = ISNULL(t.M_Pre_ApTotal,0),
			Pre_ArTotal = ISNULL(T.Pre_ArTotal,0),
            Pre_ApTotal = ISNULL(T.Pre_ApTotal,0)
       from Clients C
       left join Region R on C.region_id=R.region_id
       left join
          (select Class_ID,
                  SUM(S_Pre_ArTotal) as S_Pre_ArTotal ,
                  SUM(S_Pre_ApTotal) as S_Pre_ApTotal,
                  SUM(B_Pre_ArTotal) as B_Pre_ArTotal,
                  SUM(B_Pre_ApTotal) as B_Pre_ApTotal,
                  SUM(M_Pre_ArTotal) as M_Pre_ArTotal,
                  SUM(M_Pre_ApTotal) as M_Pre_ApTotal,
                  SUM(Pre_ArTotal) as Pre_ArTotal,
                  SUM(Pre_ApTotal) as Pre_ApTotal
            from #tmpTb 
           Group by class_id) T
          on C.[Class_ID] = T.[Class_ID]								
      where    C.[Class_ID] like @OldClass_ID +'%'
               AND C.[Child_Number] = 0
               AND C.[deleted]  = 0
               AND ((@ClientTable=0) or (c.client_id in (select [id] from #Clienttable)))
            order by  C.[Parent_ID],c.class_id,c.RowIndex
            GOTO SUCCEE
END ELSE
BEGIN
 select  C.Client_ID,
            C.Serial_Number,C.[Name],C.Child_Number,c.child_number as Child_Count,C.Class_ID,C.Parent_ID,
            isnull(R.name,'') RegionName,C.csflag,
            S_Pre_ArTotal = ISNULL(t.S_Pre_ArTotal,0),
            S_Pre_ApTotal = ISNULL(t.S_Pre_ApTotal,0),
			B_Pre_ArTotal = ISNULL(t.B_Pre_ArTotal,0),
			B_Pre_ApTotal = ISNULL(t.B_Pre_ApTotal,0),
			M_Pre_ArTotal = ISNULL(t.M_Pre_ArTotal,0),
			M_Pre_ApTotal = ISNULL(t.M_Pre_ApTotal,0),
			Pre_ArTotal = ISNULL(T.Pre_ArTotal,0),
            Pre_ApTotal = ISNULL(T.Pre_ApTotal,0)
       from Clients C
       left join Region R on C.region_id=R.region_id
       left join
          (select Class_ID,
                  SUM(S_Pre_ArTotal) as S_Pre_ArTotal ,
                  SUM(S_Pre_ApTotal) as S_Pre_ApTotal,
                  SUM(B_Pre_ArTotal) as B_Pre_ArTotal,
                  SUM(B_Pre_ApTotal) as B_Pre_ApTotal,
                  SUM(M_Pre_ArTotal) as M_Pre_ArTotal,
                  SUM(M_Pre_ApTotal) as M_Pre_ApTotal,
                  SUM(Pre_ArTotal) as Pre_ArTotal,
                  SUM(Pre_ApTotal) as Pre_ApTotal
            from #tmpTb 
           Group by Class_ID) T
          on C.[Class_ID] = T.[Class_ID]             
       where   C.[Parent_id] like @szCurrentParentId +'%'
                AND C.[Child_Number] = 0
                and C.[deleted] = 0
	        AND ((@ClientTable=0) or (c.client_id in (select [id] from #Clienttable)))
             order by  C.[Parent_ID],c.class_id,C.RowIndex
       GOTO SUCCEE
    END
ListAll:


    select  C.Client_ID,
            C.Serial_Number,C.[Name],C.Child_Number,c.child_number as Child_Count,C.Class_ID,C.Parent_ID,
            isnull(R.name,'') RegionName,C.csflag,
            S_Pre_ArTotal = ISNULL(T.S_Pre_ArTotal,0),
            S_Pre_ApTotal = ISNULL(T.S_Pre_ApTotal,0),
			B_Pre_ArTotal = ISNULL(T.B_Pre_ArTotal,0),
			B_Pre_ApTotal = ISNULL(T.B_Pre_ApTotal,0),
			M_Pre_ArTotal = ISNULL(T.M_Pre_ArTotal,0),
			M_Pre_ApTotal = ISNULL(T.M_Pre_ApTotal,0),
			Pre_ArTotal = ISNULL(T.Pre_ArTotal,0),
            Pre_ApTotal = ISNULL(T.Pre_ApTotal,0)
       from Clients C
       left join Region R on C.region_id=R.region_id
       left join
          (select Class_ID,
                  SUM(S_Pre_ArTotal) as S_Pre_ArTotal ,
                  SUM(S_Pre_ApTotal) as S_Pre_ApTotal,
                  SUM(B_Pre_ArTotal) as B_Pre_ArTotal,
                  SUM(B_Pre_ApTotal) as B_Pre_ApTotal,
                  SUM(M_Pre_ArTotal) as M_Pre_ArTotal,
                  SUM(M_Pre_ApTotal) as M_Pre_ApTotal,
                  SUM(Pre_ArTotal) as Pre_ArTotal,
                  SUM(Pre_ApTotal) as Pre_ApTotal
            from #tmpTb
           Group by class_id) T
      on C.Class_ID = T.[Class_ID]
             /*增加排续 */
      where C.Child_Number = 0 and C.[deleted] = 0 
             and  c.class_id like @szCClass_ID 
             AND ((@ClientTable=0) or (c.client_id in (select [id] from #Clienttable)))
          order by  C.[Parent_ID],c.[Class_ID],C.RowIndex
  
          
   GOTO SUCCEE

 SUCCEE:
   DROP TABLE #tmpTb
   DROP TABLE #YAccountDetail
   RETURN 0

END
GO
