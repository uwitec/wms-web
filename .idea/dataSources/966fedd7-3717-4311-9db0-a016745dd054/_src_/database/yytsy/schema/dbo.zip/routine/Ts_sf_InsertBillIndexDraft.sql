
CREATE proc Ts_sf_InsertBillIndexDraft
(
@nRET	int output,
@nVchCode int,
@nTableTag int,
@billid  int,
@billdate  datetime,
@billnumber  varchar(30),
@billtype  smallint,
@a_id  int,
@c_id  int,
@e_id  int,
@sout_id  int,
@sin_id  int,
@auditman  int,
@inputman  int,
@ysmoney  NUMERIC(25,8),
@ssmoney  NUMERIC(25,8),
@quantity  NUMERIC(25,8),
@taxrate  NUMERIC(25,8),
@period  smallint,
@billstates  char(1),
@order_id  int,
@department_id	int,
@Y_ID	int,     /*表头机构 editcompany 对应ID*/
@region_id  int,
@auditdate  datetime,
@skdate  datetime,
@jsye  NUMERIC(25,8),
@jsflag  char(1),
@note  varchar(256),
@summary  varchar(256),
@invoice int,
@invoiceNO varchar(50),
@invoiceTotal NUMERIC(25,8),
@businesstype int,
@araptotal NUMERIC(25,8),
@GatheringMan int,
@SendQTY NUMERIC(25,8),
@VIPCardID int =0,
@begindate datetime=0,
@enddate   datetime=0,
@begintime datetime=0,
@endtime   datetime=0,
@xq	       varchar(7)='1111111',
@CURY_ID   int=0,             /*当前录单机构ID*/
@B_CustomName1 varchar(100)='',
@B_CustomName2 varchar(100)='',
@B_CustomName3 varchar(100)='',
@sendC_Id   int=0,
@WHOLEQTY   int=0,
@PARTQTY    int=0,
@DPdate  datetime='1900-01-01',
@WT_ID      int=0,
@CYDW varchar(80) ='',
@CYFS varchar(60) ='',
@QYTime datetime = '1900-01-01',
@OrderValidDate datetime = '1900-01-01',
@QualityAudit  int = 0,
@QualityAuditDate  Datetime = '1900-01-01',
@financeAudit  int = 0,
@financeAuditDate  Datetime = '1900-01-01',
/*@YGuid uniqueidentifier = '00000000-0000-0000-0000-000000000000',*/
@FollowNumber varchar(80) ='',
@TicketDate	varchar(80) ='1900-01-01',
@BalanceMode INT = -1,
@PRIORITY  int =0,
@ZBAuditMan  INT =0,
@ZBAuditDate Datetime = '1900-01-01' 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @VIPCardID is null  SET @VIPCardID = 0
if @begindate is null  SET @begindate = 0
if @enddate is null  SET @enddate = 0
if @begintime is null  SET @begintime = 0
if @endtime is null  SET @endtime = 0
if @xq is null  SET @xq = '1111111'
if @CURY_ID is null  SET @CURY_ID = 0
if @B_CustomName1 is null  SET @B_CustomName1 = ''
if @B_CustomName2 is null  SET @B_CustomName2 = ''
if @B_CustomName3 is null  SET @B_CustomName3 = ''
if @sendC_Id is null  SET @sendC_Id = 0
if @WHOLEQTY is null  SET @WHOLEQTY = 0
if @PARTQTY is null  SET @PARTQTY = 0
if @WT_ID is null   set @WT_ID = 0
if @CYDW is null set @CYDW = ''
if @CYFS is null set @CYFS = ''
if @QYTime is null set @QYTime = '1900-01-01' 
if @OrderValidDate is null set @OrderValidDate = '1900-01-01' 
if @QualityAudit is null set @QualityAudit = 0
if @QualityAuditDate is null set   @QualityAuditDate= '1900-01-01'
if (@QualityAudit > 0) and (@QualityAuditDate < 100) 
   set @QualityAuditDate = GETDATE()
   
if @financeAudit is null set @financeAudit = 0
if @financeAuditDate is null set   @financeAuditDate= '1900-01-01'
if (@financeAudit > 0) and (@financeAuditDate < 100) 
   set @financeAuditDate = GETDATE()
/*if @YGuid is null or @YGuid = 0x0 set @YGuid = '00000000-0000-0000-0000-000000000000'*/
if (@DPdate is null) or (@DPdate < '1900-01-01')   set @DPdate='1900-01-01'   
if @FollowNumber is null set @FollowNumber=''
if @TicketDate	is null set @TicketDate ='1900-01-01'
if @PRIORITY  is null set @PRIORITY=0
/*Params Ini end*/

/*SET NOCOUNT ON*/
SET @nRET = -1

declare @nCurY_ID int
set @nCurY_ID =@CurY_ID

if @auditdate  <10 set @auditdate=0
if @skdate  <10 set @skdate=0

IF @nVchCode =0  /*new*/
BEGIN

  INSERT INTO sf_retailbillidx
  (
    billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman, 
    ysmoney,ssmoney,araptotal,quantity,taxrate,period,billstates,order_id,
    department_id,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,jsye,
    invoice, InvoiceNO,vipCardID,invoicetotal, Y_ID
   )
  VALUES
  (
    @billdate,@billnumber,@billtype,@a_id,@c_id,@e_id,@sout_id,@sin_id,@auditman,@inputman,
    @ysmoney,@ssmoney,@araptotal,@quantity,@taxrate,@period,@billstates,@order_id,
    @department_id,@region_id ,@auditdate ,@skdate  ,@JSFlag,@note  ,@summary ,@jsye,
    0, @invoiceNO, @vipCardID,@invoicetotal, @CURY_ID
   )

  IF @@ROWCOUNT=1
  begin
    SET @nRET = @@IDENTITY
    delete sf_RetailBill where bill_id = @nRET      
  end
END
ELSE  /*Edit*/
BEGIN	  
  DELETE FROM sf_RetailBill  WHERE BILL_ID = @nVchCode
    
  UPDATE sf_retailbillidx SET
    billdate =         @billdate,
    billnumber =         @billnumber,
    billtype =         @billtype,
    a_id =         @a_id,
    c_id =         @c_id,
    e_id =         @e_id,
    sout_id =         @sout_id,
    sin_id =         @sin_id,
    auditman =         @auditman,
    inputman =         @inputman,
    ysmoney =         @ysmoney,
    ssmoney =         @ssmoney,
    araptotal=        @araptotal,
    quantity =         @quantity,
    taxrate =         @taxrate,
    period =         @period,
    billstates =         @billstates,
    order_id =         @order_id,
    department_id =         @department_id,
    region_id =         @region_id,
    auditdate =         @auditdate,
    skdate =         @skdate,
    jsflag =         @JSFlag,
    note =         @note,
    summary =         @summary,
    jsye =         @jsye,
    invoice =         @invoice,
    invoiceNO =         @invoiceNO,
    invoiceTotal =         @invoiceTotal,
    businesstype =         @businesstype,
    VIPCardID    = @VIPCardID,
    Y_ID =         @CURY_ID,
    guid = newid()
  WHERE billid = @nVchCode

  IF @@ERROR=0
  SET @nRET = @nVchCode

END
GO
