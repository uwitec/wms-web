

CREATE procedure TS_D_InsDRBillidx
@Billid INT,/*单据id*/
@YBMoney numeric(18,4),/*医保账户*/
@TCMoney numeric(18,4),/*统筹*/
@CashMoney numeric(18,4),/*现金*/
@YBType int,/*11普通门诊 13门诊慢性病*/
@Billtype int,/*单据类型*/
@Billstates int,/*单据状态*/
@BillTotal numeric(18,4),/*单据金额*/
@SettleFlag varchar(10),/*结算状态  */
@billnumber varchar(30),/*单据编号*/
@e_name varchar(30),/*经手人*/
@EmpNum varchar(20),/*个人编号*/
@DR01Num varchar(100),/*登记流水号*/
@DR06Num varchar(100),/*处方流水号*/
@DR10Num varchar(100),/*结算流水号*/
@InvoiceNo VARCHAR(50),/*发票号*/
@OperatorNo INT,/*操作员编码=employees.emp_id*/
@BATCHNO VARCHAR(30),/*业务周期号(异地社保才用)*/
@TCAreaNo VARCHAR(10),/*统筹区编码*/
@CurYBMoney NUMERIC(18,4),/*刷卡前余额*/
@DRDDNo VARCHAR(30),/*定点编号*/
@Mode int       
AS

  IF @Billid IS NULL SET @Billid=0
  IF @YBMoney IS NULL SET @YBMoney=0
  IF @TCMoney IS NULL SET @TCMoney=0
  IF @CashMoney IS NULL SET @CashMoney=0
  IF @YBType IS NULL SET @YBType=11
  IF @Billtype IS NULL SET @Billtype=12
  IF @Billstates IS NULL SET @Billstates=3
  IF @BillTotal IS NULL SET @BillTotal=0
  IF @SettleFlag IS NULL SET @SettleFlag=11
  IF @billnumber IS NULL SET @billnumber=''
  IF @e_name IS NULL SET @e_name=''
  IF @EmpNum IS NULL SET @EmpNum=''
  IF @DR01Num IS NULL SET @DR01Num=''
  IF @DR06Num IS NULL SET @DR06Num=''
  IF @DR10Num IS NULL SET @DR10Num=''
  IF @InvoiceNo IS NULL SET @InvoiceNo=''
  IF @OperatorNo IS NULL SET @OperatorNo=0
  IF @BATCHNO IS NULL SET @BATCHNO=''
  IF @CurYBMoney IS NULL SET @CurYBMoney=0
  /*同一零售单及对应零售退货,共用一个billid,DR01Num*/
  IF @Mode = 0
  BEGIN
	IF NOT EXISTS(SELECT 1 FROM DRBillidx WHERE DR01Num=@DR01Num AND Billtype=@Billtype AND OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO)
	BEGIN
	  INSERT INTO DRBillidx
	   (Billid,YBMoney,TCMoney,CashMoney,YBType,Billtype,Billstates,
		BillTotal,SettleFlag,billnumber,e_name,EmpNum,
		DR01Num,DR06Num,DR10Num,InvoiceNo,OperatorNo,BATCHNO,TCAreaNo,
		CurYBMoney,DRDDNo)
	  SELECT @Billid,@YBMoney,@TCMoney,@CashMoney,@YBType,@Billtype,@Billstates,
		   @BillTotal,@SettleFlag,@billnumber,@e_name,@EmpNum,
		   @DR01Num,@DR06Num,@DR10Num,@InvoiceNo,@OperatorNo,@BATCHNO,@TCAreaNo,
		   @CurYBMoney,@DRDDNo
	END  
  END
  IF @Mode = 1
  BEGIN  
    UPDATE DRBillidx SET 
    SettleFlag=@SettleFlag
    ,Billstates=0
    ,InvoiceNo=CASE WHEN @SettleFlag=600 AND @InvoiceNo<>'' THEN @InvoiceNo ELSE InvoiceNo END
    ,DR10Num=CASE WHEN @SettleFlag=600 AND @DR10Num<>'' THEN @DR10Num ELSE DR10Num END
    ,Billid=CASE WHEN @SettleFlag=600 AND @Billid>0 THEN @Billid ELSE Billid END 
    ,CurYBMoney=CASE WHEN @SettleFlag=600 AND @CurYBMoney>0 THEN @CurYBMoney ELSE CurYBMoney END 
    ,billdate=GETDATE() 
    WHERE DR01Num=@DR01Num AND Billtype=@Billtype AND OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO
  END 
  IF @Mode = 2 /*药易通过账后,社保结算前,请更新零售单id到表做记录,防止社保结算失败,失去关联*/
  BEGIN  
    UPDATE DRBillidx SET 
    Billid=@Billid  
    WHERE DR01Num=@DR01Num AND Billtype=@Billtype AND OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO AND @Billid>0
  END
GO
