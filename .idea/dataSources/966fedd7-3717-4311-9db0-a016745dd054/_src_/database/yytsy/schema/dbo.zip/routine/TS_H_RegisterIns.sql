
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-14*/
/* Description:	写入挂号信息*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RegisterIns]
	/* Add the parameters for the stored procedure here*/
	@BillID int,
	@RegDate datetime,
	@Dept int,
	@Doctor int,
	@WorkDay datetime,
	@WorkPart int,
	@Patient int,
	@Actor int,
	@Comment varchar(200) = ''
AS
BEGIN
/*Params Ini begin*/
if @Comment is null  SET @Comment = ''
/*Params Ini end*/
	SET NOCOUNT ON;
	
	declare @dt datetime
	declare @szDate varchar(10)
	declare @szTime varchar(8)
	
	set @szDate = convert(varchar, @WorkDay, 120)
	select @szTime = convert(varchar, EndTime, 108) from workpart
	where part_id = @WorkPart
	set @dt = convert(datetime, @szDate + ' ' + @szTime, 120)
	if @dt <= getdate()
	begin
		raiserror('不能挂已过期的号！', 16, 1)
		return 0
	end
	
	declare @CardNo varchar(60)
	declare @Plan_ID int
	declare @Max int
	declare @Cur int

	select @Cur = count(0) from registered r
	inner join WorkPlan w
	on r.RegWorkPlan = w.Plan_ID
	where w.WorkDay = @WorkDay
	and w.doctor_id = @Doctor
	and w.workPart_ID = @WorkPart
	
	select @Max = maxReg, @Plan_ID = Plan_ID from workplan
	where workday = @workDay
	and WorkPart_ID = @workPart
	and onDuty = 1
	and Doctor_ID = @Doctor
	
	if @@rowcount <= 0
	begin
		raiserror('医生未当班！', 16 ,1)
		return 0
	end
	else
	begin
		if @Cur >= @Max
		begin
			raiserror('挂号人数已满！', 16, 1)
			return 0
		end
		else
		begin
			insert into registered(
				[Patient_id],
				[Doctor_id],
				[RegWorkPlan],
				[RegDate],
				[bill_id],
				[Emp_ID],
				[comment]
			) values(
				@Patient,
				@Doctor,
				@Plan_ID,
				@RegDate,
				@BillID,
				@Actor,
				@Comment
			)
			return @@identity
		end
	end
END
GO
