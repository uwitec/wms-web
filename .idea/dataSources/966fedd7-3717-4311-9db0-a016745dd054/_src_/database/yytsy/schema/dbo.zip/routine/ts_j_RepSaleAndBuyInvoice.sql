
/*************************************************************************************
往来结算查询
@StoredProcMode:=0 收款结算查询
@StoredProcMode:=1 付款结算查询
@StoredProcMode:=2 全部
@nJsFlag=0 1 2 3   全部、按单结算、按行结算、未结算
@nShowFlag 0 1 2 3 4 全部、所有完成、已完成、已强制完成、未完成 
*************************************************************************************/
CREATE	 PROCEDURE [ts_j_RepSaleAndBuyInvoice]
	(
	@szCClass_ID 	   VARCHAR(30)='',
	@szEClass_ID 	   VARCHAR(30)='',
	@szIClass_ID 	   VARCHAR(30)='',
 	@nD_ID        	   INT=0,
 	@szBillNum         VARCHAR(255)='',
	@szComment         VARCHAR(255)='',
	@nJsFlag	   INT=0,
 	@nShowFlag         INT=0, 
  	@BeginDate 	   DATETIME=0,
 	@EndDate	   DATETIME=0,
 	@szBillType        VARCHAR(200)='0',
 	@szOrderInvoice    varchar(60) = '2,3', /*原始单据上选择的可开发票状态*/
 	@OperatorID        INT=1,
    @szYClass_id       varchar(50)='000000',
    @KP_E_id   int = 0,   /*开票人id*/
    @store_id  int = 0,   /*仓库id*/
    @p_id      int = 0,   /*商品id*/
    @batchno varchar(50) =''  /*商品批次    */
        )
AS 
/*Params Ini begin*/
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szIClass_ID is null  SET @szIClass_ID = ''
if @nD_ID is null  SET @nD_ID = 0
if @szBillNum is null  SET @szBillNum = ''
if @szComment is null  SET @szComment = ''
if @nJsFlag is null  SET @nJsFlag = 0
if @nShowFlag is null  SET @nShowFlag = 0
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szBillType is null  SET @szBillType = '0'
if @szOrderInvoice is null  SET @szOrderInvoice = '2,3'
if @OperatorID is null  SET @OperatorID = 1
if @szYClass_id is null  SET @szYClass_id = '000000'
if @KP_E_id is null set @KP_E_id = 0
if @store_id is null set @store_id = 0
if @p_id is null set @p_id = 0
if @batchno is null set @batchno = ''
/*Params Ini end*/


if @szCClass_ID = '' set @szCClass_ID='000000'  if @szCClass_ID <> '000000' set @szCClass_ID= @szCClass_ID + '%'
if @szEClass_ID = '' set @szEClass_ID='000000'  if @szEClass_ID <> '000000' set @szEClass_ID= @szEClass_ID + '%'
if @szIClass_ID = '' set @szIClass_ID='000000'  if @szIClass_ID <> '000000' set @szIClass_ID= @szIClass_ID + '%'
if @szBillNum <> '' set @szBillNum = '%'+@szBillNum+'%'
if @szComment <> '' set @szComment = '%'+@szComment+'%'
if @szOrderInvoice = '' set @szOrderInvoice='2,3'

declare @ClientTable int ,@Companytable int ,@employeestable int ,@Storetable int
create table #Clienttable([id] int) 
create table #Companytable([id] int)
create table #employeestable([id] int)
create table #storagestable([id] int)


/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/
/*---仓库授权*/
   create table #storageslimt(id int)
   if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='S' and C.class_id like u.psc_id+'%')
   
     insert into #storageslimt
      select a.billid from  billidx a
           left join salemanagebill   b on a.billid=b.bill_id 
           where a.billtype in (10,11,12,13,16,17,18,32,112)  and a.billdate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and b.p_id>0 and a.billstates=0
      union all
      select a.billid from  billidx a 
           left join buymanagebill   b on a.billid=b.bill_id where a.billtype in (20,21,24,25,28,35,122)  and a.billdate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and b.p_id>0 and a.billstates=0
   end
/*---仓库授权*/

/*销售类　10,11,12,13,16,17,18,32,112*/
/*采购类　20,21,24,25,28,35,122*/
/*11, 13 , 21, 24,　25 需要反号*/


select * from (

select DISTINCT alltable.*, (case isnull(s.name,'') when '' then otherstoragename.name else isnull(s.name,'') end) as StorageName,
      (case ISNULL(alltable.storageid,0) when 0 then otherstoragename.storageid else ISNULL(alltable.storageid,0)end) as NowS_id 
from (
  select 
        /*0 as [SerialNo],*/ 	BI.[BillID],        BI.[Billtype],  		 BI.BillStates,        	 
	CONVERT(VARCHAR(10), BI.[Billdate], 20) AS [BillDate],			 case  BI.BillStates when 1 then '红冲' when 0 then '过账' else ' ' end StatesName, 	 
        BI.[AuditDate],		BI.[Billnumber],    isnull(C.[Name],'')[Clientname],  isnull(E.[name],'')[EmployeeName],
        BI.[InputMan],		ISNULL(IE.[NAME],'')[InputmanName],  isnull(AE.[name],'')[AuditmanName], isnull(D.[name],'')[DepartmentName],  
        BI.[Note],	        billname=CASE bi.billtype 
				WHEN 10 THEN '销售出库单'
				WHEN 11 THEN '销售出库退货单'
				WHEN 16 THEN '销售结算调价'
				WHEN 17 THEN '销售退货结算调价'
				WHEN 53 THEN '配送出库单'
				WHEN 54 THEN '配送出库退货单'
				WHEN 12 THEN '零售单'
				WHEN 13 THEN '零售退货单'
				WHEN 20 THEN '采购入库单'
				WHEN 21 THEN '采购入库退货单'
				WHEN 24 THEN '采购结算调价'
				WHEN 25 THEN '采购退货结算调价'
				WHEN 112 THEN '委托代销结算单'
				WHEN 122 THEN '受托代销结算单'
				WHEN 210 THEN '销售单'
				WHEN 211 THEN '销售退货单'     
				WHEN 220 THEN '采购单'
				WHEN 221 THEN '采购退货单'
				END,
        CASE WHEN Bi.[BILLType] in (11,13,21,24,25,211,221) THEN -BI.[Ysmoney] ELSE BI.[Ysmoney] END AS [YsMoney], 
        isnull(CASE WHEN (OV.TYPE IS NOT NULL) AND BI.[BILLTYPE] IN (11,13,21,24,25,211,221) THEN -BI.[YSMONEY]
 	     WHEN (OV.TYPE IS NOT NULL) AND (NOT BI.[BILLTYPE] IN (11,13,21,24,25,211,221)) THEN BI.[YSMONEY]
 	END ,0) as NeedTotal,
/* 	isnull(CASE WHEN Bi.[BILLType] in (11,13,21,24,25,211,221) THEN -BI.jsinvoiceTotal else bi.jsInvoiceTotal end ,0) as OverTotal,*/
 	isnull(iv.Total, 0) as OverTotal,
/* 	isnull(CASE WHEN (OV.TYPE IS NOT NULL) AND BI.[BILLTYPE] IN (11,13,21,24,25,211,221) THEN -BI.[YSMONEY] -(- BI.jsinvoiceTotal)*/
 /*	     WHEN (OV.TYPE IS NOT NULL) AND (NOT BI.[BILLTYPE] IN (11,13,21,24,25,211,221)) THEN BI.[YSMONEY] - BI.jsinvoiceTotal */
	/*end,0) as NoOverTotal, */
	 case when BI.[BILLTYPE] IN (11,13,21,24,25,211,221) THEN -BI.[YSMONEY] else bi.ysmoney end - isnull(iv.total, 0) as NoOverTotal,
        case iv.jsflag when 1 then '按单开票'  when 2 then '按行开票' else '未开票' end  as JsType,
	case when abs(jsinvoiceTotal) - abs(ysmoney) >= 0 then '已完成' else '未完成' end  as OverState,
	isnull(CONVERT(VARCHAR(10), f.invoiceDate, 120), ' ') as invoiceDate,
	ISNULL(f.invoice_E_id,0) as invoice_E_id,  /*增加开票人id 用于过滤 add by luowei 2013-04-28*/
	ISNULL(f.invoiceMan, ' ') as invoiceMan,
	ISNULL(f.invoiceno, ' ') as invoiceno,
	ISNULL(f.billnumber, ' ') as InvoiceBillNumber,
	ISNULL(f.fptotal,0) as fptotal,
	Invoicetype,
	ISNULL(sbc.costtotal, 0) as costtotal,
	c.phone_number, c.[address], c.contact_personal,bi.order_id, /*添加order_id字段 luowei 2013-04-26*/
	(case when bi.billtype in(10,11,12,13,16,17,18,32,112) then ISNULL(bi.sout_id,0) else ISNULL(bi.sin_id,0) end) as storageid /*添加仓库ID字段 luowei 2013-04-26*/
  from billidx bi
  left join Clients   C  ON C.Client_id=bi.c_id
  left join employees E  ON E.emp_id=bi.e_id
  Left join employees IE ON IE.emp_id=bi.inputman
  Left JOIN employees AE ON AE.emp_id=bi.Auditman
  left join department D ON D.departmentId=bi.department_id
  left join (select type from dbo.DecodeStr(@szOrderInvoice)) OV on bi.invoice=ov.type
  left join (select sum(Case when 0 = inv.invoicebilltype then CurrTotal else -CurrTotal end) as Total, billid,max(inv.jsFlag) as jsflag from invoice i LEFT JOIN invoiceidx inv ON inv.[id]=i.invoiceid where inv.states = 2 group by billid) iv on bi.billid= iv.billid
  left join Company  Y ON Y.Company_id=bi.Y_id
  left join (SELECT     MAX(i.invoicedate) AS invoicedate, c.billid,i.inputman as invoice_E_id, e.name AS invoiceMan, i.invoiceno,invoiceid,billnumber,max(i.invoicetotal) as fptotal,
                       (case max(i.invoice) when 0 then '无' when '1' then '收据' when 2 then '普票' when 3 then '增值税票' when 4 then '其他' end) as Invoicetype
FROM         dbo.invoice AS c INNER JOIN
                      dbo.invoiceidx AS i ON c.invoiceid = i.id INNER JOIN
                      dbo.employees AS e ON i.inputman = e.emp_id
WHERE     (i.states = 2)
GROUP BY c.billid,i.inputman,e.name, i.invoiceno,invoiceid,billnumber) f on bi.billid = f.billid
left join
(SELECT     CAST(SUM(s.costprice * s.quantity) AS NUMERIC(25,8)) AS costtotal, s.bill_id
FROM         dbo.salemanagebill AS s INNER JOIN
                      dbo.billidx AS i ON s.bill_id = i.billid
WHERE     (i.billstates = '0') AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND (s.p_id > 0)
GROUP BY s.bill_id) sbc on bi.billid = sbc.bill_id
/*  left join billtypename bname on bi.billtype = bname.billtype*/
  where bi.billdate between @BeginDate and @EndDate and
	bi.c_id in (select Client_ID from authorizeClients(@OperatorID)) and
        bi.billtype in (select type from dbo.decodestr(@szBillType)) and
        (C.Class_ID like @szCClass_ID or @szCClass_ID= '000000') and
        (E.Class_ID like @szEClass_ID or @szEClass_ID= '000000') and
	(IE.Class_ID like @szIClass_ID or @szIClass_ID= '000000') and
        (Y.Class_id like @szYClass_id+'%' or @szYClass_id='000000')and
        (bi.Department_id = @nD_ID or @nD_ID = 0 ) and
 	(bi.billnumber like @szBillNum or @szBillNum ='') and
	(bi.note like @szComment or @szComment = '') and
	((iv.jsflag = @nJsFlag or @nJsFlag=0) or (@nJsFlag=3 and iv.jsFlag is null)) and
	(@nShowFlag = 0 or (@nShowFlag = 1 and (abs(bi.jsinvoicetotal) -  abs(bi.ysmoney)) >= -0.001) or (@nShowFlag = 2 and (abs(bi.jsinvoicetotal) - abs(bi.ysmoney)) < -0.001)) and
        bi.BillStates in (0,1)
        AND ((@employeestable=0) OR (bi.E_id in (select [id] from #employeestable))) 
        AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
        AND ((@Companytable=0)or (bi.Y_id in (select [id] from #Companytable)))
       /* AND ((@Storetable=0)or (bi.sin_id in (select [id] from #storagestable)))*/
        and bi.billid not in (select id from #storageslimt)     
        AND (@p_id = 0 or EXISTS(SELECT 1 FROM buymanagebill pd where pd.bill_id = bi.billid and pd.p_id = @p_id))  /*add by luowei 增加商品过滤 2013-04-27 */
        AND (@batchno = '' or EXISTS(SELECT 1 FROM buymanagebill pd where pd.bill_id = bi.billid and pd.batchno = @batchno))  /* add by luowei 增加商品批次过滤  */
 ) alltable left join storages s on alltable.storageid=s.storage_id  /*add by luowei 开票查询增加仓库列显示  2013-04-26*/
 left join  (  /*关联没有原单没有仓库的单据（例如结算类单据） add by luowei 开票查询增加仓库列显示  2012-03-21*/
                select a.billid,s.name,a.storageid  from (
				  select billid,(case when billtype in (10,11,12,13,16,17,18,32,112) then idx.sout_id else sin_id end) as storageid 
				  from billidx idx
				  where exists(select billid from (select order_id from billidx where billtype in (16,17,24,25) and billstates = 0) a where a.order_id=idx.billid) 
				) a left join storages s on s.storage_id = a.storageid 
			) otherstoragename 	on otherstoragename.billid= alltable.order_id
where (@KP_E_id = 0 or alltable.invoice_E_id = @KP_E_id) /* add by luowei 添加开票人过滤 2013-04-27	*/
) maintable where (maintable.NowS_id = @store_id or @store_id = 0) /*add by luowei 添加仓库过滤 2013-04-27*/
		
 order by maintable.billdate, maintable.billid
 drop table #storageslimt
GO
