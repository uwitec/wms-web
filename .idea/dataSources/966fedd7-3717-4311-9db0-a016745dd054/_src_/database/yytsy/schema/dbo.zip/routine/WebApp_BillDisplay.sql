CREATE proc WebApp_BillDisplay
 (
   @intuserid  int,
   @billid INT=0,
   @e_id INT=0,
   @y_id INT=0,
   @billtype int = 0, --单据ID
   @billnumber VARCHAR(100),
   @startdate VARCHAR(10),
   @enddate VARCHAR(10),
   @type INT,
   @params VARCHAR(100), --预留接口
   @RetMessage varchar(200) out
 )
--$encode$--
as
BEGIN
	IF @type=0 
	BEGIN
		declare @tempe_id int 
		select @tempe_id=ISNULL(e_id,0) from users where user_id = @e_id
		IF ISNULL(@startdate,'')=''
		SET @startdate=Convert(VARCHAR(10),DATEADD(month,-1,GETDATE()),120)
		IF ISNULL(@enddate,'')=''
		SET @enddate=Convert(VARCHAR(10),GETDATE(),120)
		IF @billtype IN (22,14,162)--订单
		BEGIN
			SELECT 
			wab.billid AS billid,
			wab.billnumber AS billnumber,
			CONVERT(varchar(10),wab.billdate,120) AS billdate,
			wab.c_id AS c_id,
			c.name AS c_name,
			wab.e_id AS e_id,
			e.name AS e_name,
			wab.quantity AS quantity,
			wab.ysmoney AS total,
			CASE WHEN ISNULL(o.billstates,0)=0  OR ISNULL(o.billstates,0)=5 THEN 2 --已经处理完成
				 WHEN ISNULL(o.billstates,0)=3 THEN 1 --审核中
				 WHEN ISNULL(o.billstates,0)=2 THEN 0 --草稿可以进行删除
			END AS billflag
			FROM WebApp_Billidx wab 
			LEFT JOIN Orderidx o ON o.billid=wab.drfbillid
			LEFT JOIN clients c ON c.client_id=wab.c_id
			LEFT JOIN employees e ON e.emp_id=wab.e_id
			WHERE (ISNULL(@y_id,0)=0 OR wab.y_id=@y_id) AND wab.inputman=@tempe_id AND wab.billtype=@billtype
			AND (
			(ISNULL(@billnumber,'')<>'' AND wab.billnumber=@billnumber) OR 
			(ISNULL(@billnumber,'')='' and Convert(VARCHAR(10),wab.billdate,120)>=@startdate--当前时间
			AND Convert(VARCHAR(10),wab.billdate,120)<=@enddate) 
			) ORDER BY wab.billid DESC --上个月今天 
		END
		ELSE
		BEGIN
			SELECT 
			wab.billid AS billid,
			wab.billnumber AS billnumber,
			CONVERT(varchar(10),wab.billdate,120) AS billdate,
			wab.c_id AS c_id,
			c.name AS c_name,
			wab.e_id AS e_id,
			e.name AS e_name,
			wab.quantity AS quantity,
			wab.ysmoney AS total,
			CASE WHEN ISNULL(o.billstates,0)=0  OR ISNULL(o.billstates,0)=5 THEN 2 --已经处理完成
				 WHEN ISNULL(o.billstates,0)=3 THEN 1 --审核中
				 WHEN ISNULL(o.billstates,0)=2 THEN 0 --草稿可以进行删除
			END AS billflag
			FROM WebApp_Billidx wab 
			LEFT JOIN billdraftidx o ON o.billid=wab.drfbillid
			LEFT JOIN clients c ON c.client_id=wab.c_id
			LEFT JOIN employees e ON e.emp_id=wab.e_id
			WHERE (ISNULL(@y_id,0)=0 OR wab.y_id=@y_id) AND wab.inputman=@tempe_id AND wab.billtype=@billtype
			AND (
			(ISNULL(@billnumber,'')<>'' AND wab.billnumber=@billnumber) OR 
			(ISNULL(@billnumber,'')='' and Convert(VARCHAR(10),wab.billdate,120)>=@startdate--当前时间
			AND Convert(VARCHAR(10),wab.billdate,120)<=@enddate)) ORDER BY wab.billid DESC--上个月今天 
		END                                          --
	END
	ELSE IF @type=1
	BEGIN
		declare @CostMethod int,@UseSameCostMethod int,@AverBatchNoAndlocation int
    	select @CostMethod=s.sysvalue from sysconfig s where s.sysname='CostMethod'
    	select @UseSameCostMethod=s.sysvalue from sysconfig s where s.sysname='UseSameCostMethod'
    	select @AverBatchNoAndlocation=s.sysvalue from sysconfig s where s.sysname='AverBatchNoAndlocation'
		--订单 
		IF @billtype IN (22,14,162)
		BEGIN
			IF not EXISTS(SELECT 1 FROM WebApp_Billidx wab LEFT JOIN Orderidx o ON o.billid=wab.drfbillid WHERE o.billstates=2 AND wab.BillID=@billid)
			BEGIN
				SET @RetMessage='单据状态已经改变或草稿单据已经不存在'
				RETURN -1
			END
			ELSE
			BEGIN
			SELECT  wab.BillID,CONVERT(varchar(10),wab.billdate,120) AS billdate,wab.billnumber,wab.billtype,
		
				ISNULL(wab.a_id,'0') AS a_id,
				ISNULL(wab.multia_id,'0') AS multia_id,
				ISNULL(wab.multia_name,'') AS multia_name,
				ISNULL(wab.multia_total,'0') AS multia_total,
				
				wab.c_id  as c_id,c.name AS c_name,wab.e_id as e_id,
				e.name AS e_name,wab.sout_id as sout_id,s.name AS sin_name,
				wab.sin_id as sin_id,s.name AS sout_name,
				wab.auditman,wab.inputman,wab.ysmoney as ysmoney,
				wab.ssmoney,wab.quantity as quantity,wab.taxrate as taxrate,wab.period,--期间
				wab.billstates,wab.order_id,d.departmentId as dep_id,d.name AS dep_name,
				wab.posid,wab.jsye,wab.jsflag,wab.note,wab.price,wab.pricename,wab.summary,
				wab.y_id as y_id,c2.name as y_name,wab.flag,wab.address,wab.vIPCardID,wab.field1,
				wab.field2,wab.field3, wab.field4,wab.field5,wab.startbilldate, wab.endbilldate,ISNULL(wab.disprice,0) AS disprice
		  FROM WebApp_Billidx wab
		LEFT JOIN clients c ON c.client_id=wab.c_id
		LEFT JOIN employees e ON e.emp_id=wab.e_id
		LEFT JOIN department d ON d.departmentId=wab.dep_id
		LEFT JOIN storages s ON s.storage_id=wab.sout_id
		LEFT JOIN company c2 ON c2.company_id=wab.y_id
		inner JOIN orderidx o ON o.billid=wab.drfbillid
		 WHERE wab.billid=@billid and o.billstates=2
    		
		SELECT wabd.BillID,BillGuid,RowGuid,BillNO,BarCode,wabd.P_ID,P_Code,P_Name,UnitID,UnitName,BatchNo,CASE WHEN wabd.Price=0 THEN wabd.remenberprice ELSE wabd.Price END AS Price
		,wabd.Quantity/rate AS Quantity,Quantity2,Quantity3,Total,ColorID,ColorCode,ColorName,SizeID,SizeCode,SizeName,wabd.Field1,
		wabd.Field2,wabd.Field3,wabd.Field4,wabd.Field5,wabd.Field6,wabd.Field7,wabd.Field8,wabd.Field9,wabd.Field10,supplier_id,wabd.costprice,costtotal
		,wabd.s_id,validate,makedate,location_id,commissionflag,costmethod,defaultprice,retailprice,recprice
		,vipprice,specialprice,lowprice,retaillowprice,price1,price2,price3,price4,price5,price6,rate,pricetype,TYPE,comment,aoid,
			case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
			when @CostMethod=3 and @UseSameCostMethod=1 then 1 
			else 0 end as showCostmethod,
				ISNULL(st.storage,0) AS storage,ISNULL(wabd.discount,1) AS discount,CASE WHEN wabd.discountprice=0 THEN ISNULL(wabd.discount,1)*wabd.remenberprice ELSE  ISNULL(wabd.discountprice,0) END AS discountprice
		  FROM WebAPP_BillDrf wabd
		  inner join WebApp_Billidx wab on wabd.BillID=wab.billid
		  inner JOIN orderidx o ON o.billid=wab.drfbillid
		  LEFT JOIN (select s.s_id,s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice
		               FROM Storehouse s GROUP BY s.s_id,s.p_id) 
		  st ON st.p_id=wabd.p_id AND wab.sin_id=st.s_id 
		 WHERE wabd.BillID=@billid and o.billstates=2
			END
		END
		ELSE
		BEGIN
			IF not EXISTS(SELECT 1 FROM WebApp_Billidx wab LEFT JOIN billdraftidx o ON o.billid=wab.drfbillid WHERE o.billstates=2 AND wab.BillID=@billid)
			BEGIN
				SET @RetMessage='单据状态已经改变或草稿单据已经不存在'
				RETURN -1
			END
			ELSE
			BEGIN
			SELECT  wab.BillID,CONVERT(varchar(10),wab.billdate,120) AS billdate,wab.billnumber,wab.billtype,
		
				ISNULL(wab.a_id,'0') AS a_id,
				ISNULL(wab.multia_id,'0') AS multia_id,
				ISNULL(wab.multia_name,'') AS multia_name,
				ISNULL(wab.multia_total,'0') AS multia_total,
				
				wab.c_id  as c_id,c.name AS c_name,wab.e_id as e_id,
				e.name AS e_name,wab.sout_id as sout_id,s.name AS sin_name,
				wab.sin_id as sin_id,s.name AS sout_name,
				wab.auditman,wab.inputman,wab.ysmoney as ysmoney,
				wab.ssmoney,wab.quantity as quantity,wab.taxrate as taxrate,wab.period,--期间
				wab.billstates,wab.order_id,d.departmentId as dep_id,d.name AS dep_name,
				wab.posid,wab.jsye,wab.jsflag,wab.note,wab.price,wab.pricename,wab.summary,
				wab.y_id as y_id,c2.name as y_name,wab.flag,wab.address,wab.vIPCardID,wab.field1,
				wab.field2,wab.field3, wab.field4,wab.field5,wab.startbilldate, wab.endbilldate,ISNULL(wab.disprice,0) AS disprice
		  FROM WebApp_Billidx wab
		LEFT JOIN clients c ON c.client_id=wab.c_id
		LEFT JOIN employees e ON e.emp_id=wab.e_id
		LEFT JOIN department d ON d.departmentId=wab.dep_id
		LEFT JOIN storages s ON s.storage_id=wab.sout_id
		LEFT JOIN company c2 ON c2.company_id=wab.y_id
		inner JOIN billdraftidx o ON o.billid=wab.drfbillid
		 WHERE wab.billid=@billid and o.billstates=2
		 		
		SELECT wabd.BillID,BillGuid,RowGuid,BillNO,BarCode,wabd.P_ID,P_Code,P_Name,UnitID,UnitName,BatchNo,CASE WHEN wabd.Price=0 THEN wabd.remenberprice ELSE wabd.Price END AS Price
		,wabd.Quantity/rate AS Quantity,Quantity2,Quantity3,Total,ColorID,ColorCode,ColorName,SizeID,SizeCode,SizeName,wabd.Field1,
		wabd.Field2,wabd.Field3,wabd.Field4,wabd.Field5,wabd.Field6,wabd.Field7,wabd.Field8,wabd.Field9,wabd.Field10,supplier_id,wabd.costprice,costtotal
		,wabd.s_id,validate,makedate,location_id,commissionflag,costmethod,defaultprice,retailprice,recprice
		,vipprice,specialprice,lowprice,retaillowprice,price1,price2,price3,price4,price5,price6,rate,pricetype,TYPE,comment,aoid,
			case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
			when @CostMethod=3 and @UseSameCostMethod=1 then 1 
			else 0 end as showCostmethod,
				ISNULL(st.storage,0) AS storage,ISNULL(wabd.discount,1) AS discount,CASE WHEN wabd.discountprice=0 THEN ISNULL(wabd.discount,1)*wabd.remenberprice ELSE  ISNULL(wabd.discountprice,0) END AS discountprice
		  FROM WebAPP_BillDrf wabd
		  inner join WebApp_Billidx wab on wabd.BillID=wab.billid
		  inner JOIN billdraftidx o ON o.billid=wab.drfbillid
		  LEFT JOIN (select s.s_id,s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice
		               FROM Storehouse s GROUP BY s.s_id,s.p_id) 
		  st ON st.p_id=wabd.p_id AND wab.sin_id=st.s_id
		 WHERE wabd.BillID=@billid and o.billstates=2
			END
		END
		
	END
end
GO
