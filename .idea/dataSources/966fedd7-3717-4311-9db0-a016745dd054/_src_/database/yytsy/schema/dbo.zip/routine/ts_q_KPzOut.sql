
create  proc ts_q_KPzOut
(
	@nBillid int
)
/*with encryption*/
as
set nocount on

	declare @szAClass_id varchar(30),@szCClass_id varchar(30),@szUfoAccount_id varchar(30),@szUfoClient_id varchar(30)
	declare @nA_id int,@nC_id int,@tBilldate datetime,@szBillCode varchar(30),@sznote varchar(256)
	declare @dJfmoney NUMERIC(25,8),@dDfmoney NUMERIC(25,8),@szPzlb varchar(30),@dTotal NUMERIC(25,8)
	declare @FPreparerID int,@FCashierID int,@FCashierName varchar(80)
	declare @FItem varchar(20),@e_serialnumber varchar(50),@dep_id int,@d_serialnumber varchar(50),@d_name varchar(50)
	declare @c_name varchar(80),@i int,@alias varchar(30),@csname varchar(10),@billtype smallint
	declare @szFPreparerID varchar(80)
	
                                  /*单据编号做摘要*/
	select @tBilldate=billdate,@szBillCode=billnumber,@sznote=note,@FPreparerID=inputman,@FCashierID=e_id,@billtype=billtype from billidx where billid=@nBillid
	if @billtype in(10,11,12,13,14,15,16,17,102,110,111,112,113) select @csname='客户'
	if @billtype in(20,21,22,23,24,25,26,120,121,122,123) select @csname='供应商'
	if @csname is null select @csname=''
	select @i=0
	
	if exists(select 1 from pzOutBill where billid = @nBillid)
	begin
	  update pzOutBill set OutDate = GETDATE(), OutCount = OutCount + 1, OutStates = 1 where billid = @nBillid
	end 
	else begin
	  insert into pzOutBill(BillID, OutCount, OutDate, mergeFlag, OutGUID, BillType, OutStates)
	       values (@nBillid, 1, GETDATE(), 0, NEWID(), @billtype, 1) 
	end
	
	select @szFPreparerID = sysvalue from sysconfigtmp where [sysname] = 'cqkoutEmp'
	
	
	declare pzinfo cursor for
	
	select a_id,c_id,aclass_id,cclass_id,jdmoney from vw_c_adetail 
	where billid=@nBillId	
		 
	open pzinfo
	fetch next from pzinfo into @nA_id,@nC_id,@szAClass_id,@szCClass_id,@dTotal
	while @@fetch_status=0
	begin
	
		set @dJfmoney=0
		set @dDfmoney=0
		select @szUfoAccount_id=serialnumber,@FItem=FItem from kmdz where a_id=@nA_id and type='K'
                      
		if @szUfoAccount_id is null select @szUfoAccount_id=''
		
		select @FCashierName=isnull(e.name,''),@e_serialnumber=isnull(d.serialnumber,''),@dep_id=dep_id from empdz d,employees e where d.e_id=@FCashierID and d.type='K' and e.emp_id=d.e_id
		if @e_serialnumber is null select @FCashierName='',@e_serialnumber=''
		select @d_serialnumber=isnull(dz.serialnumber,''),@d_name=isnull(dm.name,'') from departmentdz dz,department dm where dz.d_id=@dep_id and dz.d_id=dm.departmentId  and dz.type='K'
		if @d_serialnumber is null select @d_serialnumber='',@d_name=''
                if @nC_id<>0 
               		select @szUfoClient_id=isnull(serialnumber,''),@c_name=c.name from dwdz dz,clients c where c_id=@nC_id and type='K' and dz.c_id=c.client_id
		else
			select @szUfoClient_id='',@c_name=''
		if @szUfoClient_id is null select @szUfoClient_id='',@c_name=''

		if left(@szAClass_Id,6)='000001' or left(@szAClass_id,6)='000004'
		begin
			if @dTotal>=0 set @dJfmoney=@dTotal else set @dDfmoney=-@dTotal
		end else if left(@szAClass_id,6)='000002' or left(@szAClass_id,6)='000003'
		begin
			if @dTotal>=0 set @dDfmoney=@dTotal else set @dJfmoney=-@dTotal
		end
		
		insert into Kpzout (FDate,FYear,FPeriod,FGroupID,
                       FNumber,FAccountNum,FAccountName,FCurrencyNum,FCurrencyName,
                       FAmountFor,FDebit,FCredit,
                       FPreparerID,FCheckerID,FApproveID,FCashierID,FHandler,
                       FSettleTypeID,FSettleNo,FExplanation,FQuantity,FMeasureUnitID,FUnitPrice,
			FReference,FTransDate,FTransNo,FAttachments,FSerialNum,FObjectName,
			FParameter,FExchangeRate,FEntryID,
			FItem,FPosted,FInternalInd,FCashFlow)
		values(@tBillDate,convert(varchar(20),DATEPART(yy,@tBillDate)),convert(varchar(20),DATEPART(mm,@tBillDate)),'记',
                       @nBillId,@szUfoAccount_id,' ','RMB',' ',
                       case @dJfmoney when 0 then @dDfmoney else @dJfmoney end,@dJfmoney,@dDfmoney,
                       @szFPreparerID, ' ',' ',@FCashierName,' ',' ',' ',case @szBillCode when '' then '药易通凭证' else @szBillCode end,0,' ',0,
			@sznote,@tBillDate,' ',0,@nBillId,' ',' ',0,@i,/*FEntryID为@izh,zh100906*/
			case convert(int,@FItem)
			when 0 then ' ' when 1 then '职员---'+@e_serialnumber+'---'+@FCashierName+''
			when 10 then '部门---'+@d_serialnumber+'---'+@d_name+''
			when 11 then '部门---'+@d_serialnumber+'---'+@d_name+',职员---'+@e_serialnumber+'---'+@FCashierName+'' 
			when 100 then @csname+'---'+@szUfoClient_id+'---'+@c_name+''
			when 101 then @csname+'---'+@szUfoClient_id+'---'+@c_name+',职员---'+@e_serialnumber+'---'+@FCashierName+''
			when 110 then @csname+'---'+@szUfoClient_id+'---'+@c_name+',部门---'+@d_serialnumber+'---'+@d_name+''
			when 111 then @csname+'---'+@szUfoClient_id+'---'+@c_name+',职员---'+@e_serialnumber+'---'+@FCashierName+',部门---'+@d_serialnumber+'---'+@d_name+''
			else ' '
			end,0,' ',' ')
			
		select @i=@i+1
		if @@rowcount=0 return -1
		fetch next from pzinfo into @nA_id,@nC_id,@szAClass_id,@szCClass_id,@dTotal
	end
	close pzinfo
	deallocate pzinfo
	
return 0
GO
