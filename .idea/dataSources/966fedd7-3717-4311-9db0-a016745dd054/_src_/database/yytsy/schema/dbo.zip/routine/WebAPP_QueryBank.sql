CREATE      PROCEDURE WebAPP_QueryBank
 AS

set nocount on

--select * from account order by class_id

select Serial_number, [Name], Ini_Total, Cur_Total 
from Account
where class_id like '000001000004%'
and child_number=0
GO
