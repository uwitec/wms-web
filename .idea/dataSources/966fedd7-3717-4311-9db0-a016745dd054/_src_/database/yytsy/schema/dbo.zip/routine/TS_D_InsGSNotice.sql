
create procedure TS_D_InsGSNotice
@billnumber	varchar(16),
@Title	varchar(100),
@Memo	varchar(1000),
@BeginDate	datetime,
@EndDate	datetime,
@BillDate	datetime
AS 
  SET NOCOUNT ON
  
  IF EXISTS(SELECT 1 FROM GSNotice WHERE billnumber=@billnumber)
  BEGIN
    UPDATE GSNotice SET  
    Title=@Title,
	Memo=@Memo,
	BeginDate=@BeginDate,
	EndDate=@EndDate,
	BillDate=@BillDate
    WHERE billnumber=@billnumber
  END 
  ELSE 
  BEGIN
    INSERT INTO GSNotice
      (billnumber,Title,Memo,BeginDate,EndDate,BillDate)
    SELECT @billnumber,@Title,@Memo,@BeginDate,@EndDate,@BillDate
  END
GO
