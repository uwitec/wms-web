

create view dbo.vw_M_YRetailBillIdx
as
select B.*,
      invoicetype=(
      case B.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
      isnull(clients.[name], '') as cname,
      isnull(clients.address,'') as cAddress,
      isnull(clients.contact_personal, '') as cContact_personal,
      isnull(clients.phone_Number, '') as cPhone_Number,
      isnull(clients.class_id, '')cclass_id,
      isnull(clients.serial_number, '')Cnumber, 
      isnull(dbo.account.name, '') as aname, isnull(dbo.employees.name, '') as ename,isnull(employees.serial_number, '')enumber,
      isnull(employees.dep_id,0)dep_id, isnull(dbo.account.class_id,'') as aclass_id,
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      isnull(ss.[name],'') as ssname, 
      isnull(sd.[name],'') as sdname,
      0 as GatheringMan,
      /*isnull(empg.[Name],'') as GatheringManName,*/
      ' ' as GatheringManName,
      /*isnull(empg.[class_id],'') as GatheringManclass_id,*/
      ' ' as GatheringManclass_id,
      isnull(Y.Class_ID,'') as YClass_ID,
      isnull(Y.[name],'') as Yname,
      isnull((case when b.billtype in (150,151,155,160,161,165) then CY.Class_ID else '' end),'') as CYClass_ID,
      BillName=(case when billtype=12 then '零售单' when billtype=13 then '零售退货单' end)
      
from  YRetailBillIdx b left outer join
      dbo.account on B.a_id = dbo.account.account_id left outer join
      dbo.clients on B.c_id = dbo.clients.client_id left outer join
      dbo.employees on B.e_id = dbo.employees.emp_id
      left outer join employees emp on B.inputman=emp.emp_id
      left outer join employees empa on B.auditman=empa.emp_id
      /*left outer join employees empg on B.gatheringman=empg.emp_id*/
      left outer join department dep on B.department_id=dep.departmentid
      left outer join region reg on B.region_id=reg.region_id
      left outer join storages ss on B.sout_id=ss.storage_id
      left outer join storages sd on B.sin_id=sd.storage_id
      left outer join Company  Y  on B.Y_id=Y.Company_id
      left Outer join Company  CY  on B.C_id=CY.company_id
GO
