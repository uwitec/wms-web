
/*create by  zjilin 2014-04-29*/
/*说明： 和vw_Products区别,不关联价格表，需要关联价格表的地方在存储过程中关联,例：ts_l_qrbaseinfo*/

CREATE VIEW vw_Products2
AS
SELECT TOP 100 PERCENT ISNULL(u1.name, '') AS Unit1Name,ISNULL(WholeU.name, '') AS WholeUnitName, ISNULL(m.medtype, '') 
      AS MedName, '' AS MedCode,ISNULL(pc.pc_name, '') 
      AS PcName, ISNULL(pc.pc_code, '') AS PcCode,
			p.AuditStates,p.BulidNo,p.ChemName,p.ControlYard,p.Custompro1,p.Custompro2,p.Custompro3,
			p.Custompro4,p.Custompro5,p.EngName,p.Factory,p.GMP,p.GMPNo,p.GMPvaliddate,
			p.Gross,p.IfZYCheck,p.Incrate,p.Inputdate,p.Inputman,p.Integral,p.IsClientDiscount,
			p.IsSplit,p.IsValuedProduct,p.LTTime,p.LastUpDate,p.LastUpdateman,p.LatinName,
	        p.MaintainDay,p.MaintainType,p.ModifyDate,p.NoneQuantity,
			p.OTCType,p.PackStd,p.PerCodevalid,p.PosYhDay,p.PrintClass,p.ProREP_Data,
			p.ProREP_No,p.Profit,p.RegisterNo,p.Registervalid,p.RowIndex,p.SR2_id,p.SR_id,
			p.StorageCon,p.StoreCondition,p.TC1,p.TC2,isnull(tx.TaxRate,0) as TaxRate,p.TcCost,p.TransTimes,p.TransToYJ,
			p.WholeUnit_id,p.alert,p.alias,p.auditComment,p.auditMan,p.basicMedication,
			p.buycount,p.child_count,p.child_number,p.class_id,p.cldw,p.cljg,p.comment,p.costmethod,
			p.deduct,p.deleted,p.factoryc_id,p.firstcheck,p.gspflag,p.hsbl,p.ifIntegral,p.ifdiscount,
			p.incRate2,p.incRate3,p.isCheckReport,p.makearea,isnull(m.id,0) as medtype,p.modal,p.name,p.otcflag,
			p.pack,p.parent_id,p.permitcode,p.pinyin,p.protectprice,isnull(r.id,0) as r_id,p.rate2,p.rate3,
			p.rate4,p.serial_number,p.sfcl,p.standard,p.tcmoney,p.trademark,p.unit1_id,p.unit2_id,p.StandardCode,p.CloudCode,
			p.unit3_id,p.unit4_id,p.validcheck,p.validday,p.validmonth,p.product_id,isnull(tx.id,0) as taxrateid
      , ISNULL(u3.name, '') 
      AS Unit4Name, ISNULL(u0.name, '') AS Unit2Name, ISNULL(u2.name, '') 
      AS Unit3Name, p.serial_number AS code,
      otcbz=case p.otcflag
      when 0 then '否'  when 1 then '是'
      end  ,
      StatusName=case p.deleted
      when 0 then '正常'  when 1 then '删除'  when 2 then '停购'  when 3 then '停售'  when 4 then '停用'
      end  ,
      isnull(r.RangeName,'')rName,isnull(g.gspPropert,'')gspPropert
      ,(case p.OTCType when 0 then '甲类'when 1 then '乙类'when 2 then '[无]' else '' end)OTCName
      ,(case p.MaintainType when 0 then '一般养护'when 1 then'重点养护' when 2 then '不养护' end) Maintain
      ,(case p.firstCheck when 0 then '否'  when 1 then '是'end)szFirst
      ,(case p.gmp when 0 then '否'  when 1 then '是'end)szGmp
      ,ISNULL(p.NoneQuantity,'') as NoneQname
      ,ISNULL(SR.[name],'') as SRname,
      ifalert= case p.alert when 0 then '是' when 1 then '否'end,
      (case when p.wholeUnit_id = p.unit2_id then rate2
				 when p.wholeUnit_id = p.unit3_id then rate3
				 when p.wholeUnit_id = p.unit4_id then rate4
				 else 1 end)  as WholeRate,			 
	 (Case isnull(p.AuditStates,0) when 1 then '已审核' else '未审核' end) as AuditStatesStr,
	 CASE p.StoreCondition WHEN 2 THEN 1 ELSE 0 END AS Iscold,
	 ISNULL(g.doubleCheck, 0) AS Isspec,
	 ISNULL(u5.name, '') AS UnitNameCL,
	 isnull(PE.lcsl,0) as lcsl,
	 isnull(PE.syts,0) as syts
FROM dbo.unit u0 RIGHT OUTER JOIN
      dbo.products p LEFT OUTER JOIN
      dbo.Unit WholeU on p.WholeUnit_id=WholeU.Unit_id left outer join
      dbo.unit u3 ON p.unit4_id = u3.unit_id LEFT OUTER JOIN
      dbo.unit u5 ON p.cldw = u5.unit_id LEFT OUTER JOIN
      dbo.unit u2 ON p.unit3_id = u2.unit_id ON u0.unit_id = p.unit2_id left   join 
      VW_MedType m on p.product_id = m.product_id left join 
      dbo.PrintClass pc ON p.PrintClass = pc.pc_id LEFT OUTER JOIN
      dbo.unit u1 ON p.unit1_id = u1.unit_id       left   join 
      VW_Range r on p.product_id = r.product_id
      left   join VW_TaxRate tx on p.product_id = tx.product_id
      left join gspPropert g on g.gspid=p.gspFlag
      left join saleRange SR  on SR.[ID]=p.SR_ID
      LEFT JOIN productsExtend PE ON P.product_id = PE.p_id
WHERE (p.deleted <> 1) and p.IsSplit = 0
ORDER BY p.class_id
GO
