
CREATE  PROCEDURE [dbo].[TS_DtsToTable] 
  @DtsTable varchar(100),
  @Table varchar(100),
  @TableKey varchar(100),
  @FieldList varchar(2000)
AS
begin
  /*特殊处理的表需要判断*/
/*
  if @Table = '?'
  begin
    --insert
    return
  end;
*/

  declare 
     @begin varchar(100),
     @end varchar(100),
     @Del varchar(500),
     @Insert varchar(5000),
     @DelDts VARCHAR(500),
     @Sql varchar(8000)

  set @Begin=''
  set @End=''    
  if columnproperty(object_id(@Table),@TableKey,'IsIdentity')=1
  begin
    set @Begin = ' SET IDENTITY_INSERT ' + @Table + ' ON ' 
    set @End   = ' SET IDENTITY_INSERT ' + @Table + ' OFF '
  end  
  set @Del = ' delete from '+ @Table + ' where ' + @TableKey + ' in (select ' + @TableKey + ' from ' + @DtsTable + ') ' 
  set @Insert = ' insert into ' + @Table + '(' + @FieldList + ')' + ' select ' + @FieldList + ' from ' + @DtsTable
  SET @DelDts = ''  /*' delete from ' + @DtsTable */
  set @Sql = @Del + @begin + @Insert + @DelDts + @End 
  print @Sql
  print len(@Sql)
  Exec(@Sql)
end
GO
