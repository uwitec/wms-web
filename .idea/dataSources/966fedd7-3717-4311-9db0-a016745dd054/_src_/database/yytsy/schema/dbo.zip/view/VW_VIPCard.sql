

CREATE	   VIEW dbo.VW_VIPCard
AS



  SELECT card.*,      
         IsNull(ct.name,'') as ctName,
         IsNull(emp.name,'') AS e_name,
         IsNull(s.PosName,'') as PosName,
         ct.ct_Type,
         ct.isBank,
         ct.isIntegral
         
        
    FROM VIPCard card left join VIPCardType ct on card.ct_id=ct.ct_id
                      LEFT JOIN employees emp ON card.E_id = emp.emp_id
                      left join shop s on card.pos_id=s.PosID
GO
