
CREATE VIEW dbo.vw_Location
AS
SELECT l.*,
      LocTypeName= case l.loctype
      when 0 then '存货货位'
      when 1 then '发货货位'
      end,
      ISNULL(s.name, '') AS sName, 
      ISNULL(s.WholeFlag, 0) AS sWholeFlag, 
      ISNULL(SF.Slf_name, '') AS Slfname,
      s.Y_ID, ISNULL(sa.name, '') as saName, 
      ISNULL(sa.serial_number, '') as saCode,
      s.storeCondition, ISNULL(wmsr.Name,'') as qyName
FROM dbo.location l LEFT OUTER JOIN
      (select * from dbo.Shelf where deleted=0) SF ON l.Shelfid = SF.Slf_id LEFT OUTER JOIN
      dbo.storages s ON l.s_id = s.storage_id
      left join stockArea sa on l.sa_id = sa.sa_id
      Left join WMSLocation wmsl on l.loc_id=wmsl.Loc_Id  /*zhangw tfs51035 WMS区域*/
      LEFT join WMSRegion wmsr on wmsl.regionid=wmsr.ID
WHERE (l.deleted = 0)
GO
