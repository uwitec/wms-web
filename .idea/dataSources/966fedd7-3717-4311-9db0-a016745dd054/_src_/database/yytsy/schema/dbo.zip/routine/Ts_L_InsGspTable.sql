





CREATE	PROCEDURE [Ts_L_InsGspTable]
	(@GspID 	[numeric],
	 @GspType	[smallint],
	 @BillCode	[varchar](60),
	 @BillE 	[varchar](20),
	 @BillDate	[datetime],
	 @GspText	[Text],
	 @comment	[varchar](600),
	 @Sign		[TinyInt],
	 @Y_ID      [int],
	 @GspVer	[tinyInt]=1,
	 @BillId    [int] = 0,
	 @BillType  [int] = 0
)

AS
/*Params Ini begin*/
if @GspVer is null  SET @GspVer = 1
/*Params Ini end*/

/* 2009-08-06 不处理GSP报表相关查询，一个账套，一套GSP报表，先写入Y_ID，避免以后(各机构独立GSP时)不能升级数据*/
 
if exists(select GSPID from GSPTable where GSPID=@Gspid)
begin
	UPDATE [GspTable] 
	
	SET  [GspType]		= @GspType,
		 [BillCode]	 = @BillCode,
		 [BillE]		= @BillE,
		 [BillDate]	 = @BillDate,
		 [GspText]	 = @GspText,
		 [comment]	 = @comment,
		 [Sign] 	 = @Sign,
		 [GspVer]	 = @GspVer,
		 [Y_ID]      = CASE WHEN @GspType IN (2299) THEN Y_ID ELSE @Y_ID END/*bug48911/48923*/
		 		
	WHERE 
		( [GspID]	 = @GspID)
return @Gspid
end else
BEGIN
	/*药品停售通知单生成药品质量复检通知单时不删除之前的关联GSP记录*/
	IF ((@BillType > 0) AND (@BillId > 0)) AND ((@BillType <> 2277) AND (@GspType <> 2278)) AND (@GspType <> 2258) AND (@BillType <> 186)
		DELETE FROM GspTable WHERE BillId = @BillId AND GspType = @GspType AND BillType = @BillType
	
	INSERT INTO [GspTable] 
		 ( [GspType],
		 [BillCode],
		 [BillE],
		 [BillDate],
		 [GspText],
		 [comment],
		 [Sign],
		 [GspVer],
		 [Y_ID],
		 [BillId],
		 [BillType]) 
	 
	VALUES 
		( @GspType,
		 @BillCode,
		 @BillE,
		 @BillDate,
		 @GspText,
		 @comment,
		 @Sign,
		 @GspVer,
		 @Y_ID,
		 @BillId,
		 @BillType)

return @@IDENTITY

end
GO
