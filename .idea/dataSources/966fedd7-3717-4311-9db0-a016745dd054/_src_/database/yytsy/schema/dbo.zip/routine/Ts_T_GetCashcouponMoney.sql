
CREATE PROCEDURE [dbo].[Ts_T_GetCashcouponMoney] 
    @szCTID varchar(3000), 	/*代金券ID串*/
	@szPid varchar(3000), /*商品id串*/
	@szbillTotal varchar(3000),  /*单据金额串	*/
	@Model int /*类别：0--获取代金券和零售单金额的小值；1--检查代金券和商品是否匹配; */
AS   
 	DECLARE @CashType Integer, @CalTotal NUMERIC(25,8), @ccTotal NUMERIC(25,8), @cnt integer
 		
	if OBJECT_ID('tempdb..#CheckP') is not null
		  drop table #CheckP  
	
	select  top 0 IDENTITY(Int, 1,1 ) as smb_Id,  0  as p_id,  CAST (0  as NUMERIC(25,8))  as total into #checkp
						 
	if @szPid <> ''
	begin		
	  if OBJECT_ID('tempdb..#billtotal') is not null
	    drop table #billtotal                               
		  
	  insert into #checkp(p_id, total) select cast(szTYPE as int) as p_id,  CAST (0  as NUMERIC(25,8))  as total from dbo.DecodeToStr(@szPid)
	  select IDENTITY(Int, 1,1 ) as smb_Id,  cast(szTYPE as NUMERIC(25,8)) as total into #billtotal from dbo.DecodeToStr(@szbillTotal)
	  update #checkp set total = t.total from #checkp c, #billtotal t where c.smb_Id = t.smb_Id					
    end
    
    /*获取代金券绑定类型：4--自定义类别；5--商品 */
    select top 1 @CashType = c.Limitflag from Cashcoupon a inner join dbo.DecodeToStr(@szCTID) b on a.ccid = b.szTYPE    
                                                           left join cashcoupontype c on a.typeid = c.typeid
    /*获取代金券和零售单金额的小值                                           */
    if @Model = 0
    begin                                                           
      /*无绑定 */
      if @CashType = 0 
      begin
        select @CalTotal = SUM(total) from #checkp
      end                                                             
      /*商品*/
      else if @CashType = 1 
      begin
        select @CalTotal = SUM(total) from #checkp where p_id in 
        ( 
        select distinct cm.BaseID from Cashcoupon cc inner join dbo.DecodeToStr(@szCTID) cs on cc.ccid = cs.szTYPE 
                                                     inner join CashcouponMapping cm on cc.typeid = cm.typeid                                                          
        )      
      end
      /*自定义类别*/
      else if @CashType = 2
      begin      
        select @CalTotal = SUM(total) from #checkp where p_id in 
        ( 
		select distinct ccm.baseinfo_id from Cashcoupon cc 
											inner join dbo.DecodeToStr(@szCTID) cs on cc.ccid = cs.szTYPE 
											inner join CashcouponMapping cm on cc.typeid = cm.typeid 
											inner join customCategory ccg on cm.BaseID = ccg.id
											left join 
											(select P_id as baseinfo_id,class_id from (
											select P_id,PComent1 as class_id from ProductCategory
											union all
											select P_id,PComent2 as class_id from ProductCategory
											union all
											select P_id,PComent3 as class_id from ProductCategory
											) a
											)
											ccm on ccm.class_id = ccg.id   
        )                                         
      end
    
      /*再获取代金券列表金额累计    */
      select @ccTotal = SUM(ct.total) from Cashcoupon cc inner join dbo.DecodeToStr(@szCTID) cs on cc.ccid = cs.szTYPE 
                                                         inner join cashcoupontype ct on cc.typeid = ct.typeid
    
      /*再把零售单上获取到的总金额和代金券列表总金额取小*/
      set @CalTotal = ISNULL(@CalTotal, 0)
      set @ccTotal = ISNULL(@ccTotal, 0)
      select ISNULL((Case when (@CalTotal < @ccTotal) then @CalTotal else @ccTotal end), 0)
    end
    /*检查代金券和商品是否匹配*/
    else if @Model = 1 
    begin
      /*无绑定 */
      if @CashType = 0 
      begin
        select @cnt = COUNT(distinct p_id) from #checkp
      end   
      /*商品*/
      else if @CashType = 1 
      begin
        select @cnt = COUNT(distinct p_id) from #checkp where p_id in 
        ( 
        select distinct cm.BaseID from Cashcoupon cc inner join dbo.DecodeToStr(@szCTID) cs on cc.ccid = cs.szTYPE 
                                                     inner join CashcouponMapping cm on cc.typeid = cm.typeid                                                          
        )      
      end
      /*自定义类别*/
      else if @CashType = 2
      begin      
        select @cnt = COUNT(distinct p_id) from #checkp where p_id in 
        ( 
		select distinct ccm.baseinfo_id from Cashcoupon cc 
											inner join dbo.DecodeToStr(@szCTID) cs on cc.ccid = cs.szTYPE 
											inner join CashcouponMapping cm on cc.typeid = cm.typeid 
											inner join customCategory ccg on cm.BaseID = ccg.id
											left join 
											(select P_id as baseinfo_id,class_id from (
											select P_id,PComent1 as class_id from ProductCategory
											union all
											select P_id,PComent2 as class_id from ProductCategory
											union all
											select P_id,PComent3 as class_id from ProductCategory
											) a
											)
											ccm on ccm.class_id = ccg.id  
        )                                         
      end       

      select ISNULL(@cnt, 0)  
    end
GO
