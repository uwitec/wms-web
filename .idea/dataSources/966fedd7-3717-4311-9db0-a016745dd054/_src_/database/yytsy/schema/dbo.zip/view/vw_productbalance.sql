
create view vw_productbalance as


SELECT pb.*, isnull(L1.loc_name, '') as Locname, ISNULL(WL.loc_name, '') as WLocname,
       ISNULL(Sl.loc_name, '')  as SLocname,  ISNULL(c.name, '') as C_Name,
       ISNULL(e.name, '') as e_name, ISNULL(e.pinyin, '') as e_pinyin
  from productbalance pb
  left join location L1 on pb.locationid= L1.loc_id
  left join location WL on pb.WholeLoc = WL.loc_id
  left join location Sl on pb.SingleLoc = Sl.loc_id
  left join clients c on pb.Supplier_id = c.client_id
  left join employees e on pb.Emp_id = e.emp_id
GO
