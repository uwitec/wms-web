
CREATE       PROCEDURE [Ts_L_InsEmpSet]
 (  @mode int = 0,					/*0表示添加1表示修改*/
	@E_id [int] ,				/* 职员id*/
	@p_id [int] ,				/* 商品id   为0的时候表示总额度，其它就是对应商品的额度*/
	@OneYear [varchar] (30) ,			/* 年度*/
	/*[zq_no] [varchar] (30) DEFAULT (''),		-- 周期编号*/
	/*直接设置12个月，每月为一个周期*/
	@OneM NUMERIC(25,8) ,		/*1月份  （金额）*/
	@twoM NUMERIC(25,8) ,
	@threeM NUMERIC(25,8) ,
	@fourM NUMERIC(25,8) ,
	@fiveM NUMERIC(25,8) ,
	@sixM NUMERIC(25,8) ,
	@sevenM NUMERIC(25,8) ,
	@eightM NUMERIC(25,8) ,
	@nineM NUMERIC(25,8) ,
	@tenM NUMERIC(25,8) ,
	@elenM NUMERIC(25,8) ,
	@twentyM NUMERIC(25,8) ,		/*12月份	*/

	@OneT NUMERIC(25,8) ,		/*1月份  （数量）*/
	@twoT NUMERIC(25,8) ,
	@threeT NUMERIC(25,8) ,
	@fourT NUMERIC(25,8) ,
	@fiveT NUMERIC(25,8) ,
	@sixT NUMERIC(25,8) ,
	@sevenT NUMERIC(25,8) ,
	@eightT NUMERIC(25,8) ,
	@nineT NUMERIC(25,8) ,
	@tenT NUMERIC(25,8) ,
	@elenT NUMERIC(25,8) ,
	@twentyT NUMERIC(25,8) 		/*12月份*/
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/

if @mode = null set @mode = 0
if @E_id = null set @E_id = 0
if @p_id = null set @p_id = 0

if @mode = 0 /*添加*/
begin
if @E_id > 0 and @p_id > 0
begin
	if exists(select 1 from employeesSeting where E_id=@E_id and p_id=@p_id and OneYear = @OneYear)
	begin
	 /*RAISERROR('该职员该商品本年度的销售额度已经存在！不能添加！！',16,1)*/
	 return -2
	end
	
  INSERT INTO [employeesSeting] 
	  (
	[E_id] ,				/* 职员id*/
	[p_id] ,				/* 商品id   为0的时候表示总额度，其它就是对应商品的额度*/
	[OneYear],			/* 年度*/
	/*[zq_no] [varchar] (30) DEFAULT (''),		-- 周期编号*/
	/*直接设置12个月，每月为一个周期*/
	[OneM] ,		/*1月份  （金额）*/
	[twoM] ,
	[threeM] ,
	[fourM] ,
	[fiveM] ,
	[sixM],
	[sevenM] ,
	[eightM] ,
	[nineM],
	[tenM],
	[elenM] ,
	[twentyM] ,		/*12月份	*/

	[OneT],		/*1月份  （数量）*/
	[twoT] ,
	[threeT] ,
	[fourT] ,
	[fiveT] ,
	[sixT] ,
	[sevenT] ,
	[eightT] ,
	[nineT] ,
	[tenT],
	[elenT],
	[twentyT] 		/*12月份*/
	  )
	 
  VALUES 
	 (
	@E_id ,				/* 职员id*/
	@p_id ,				/* 商品id   为0的时候表示总额度，其它就是对应商品的额度*/
	@OneYear,			/* 年度*/
	/*[zq_no] [varchar] (30) DEFAULT (''),		-- 周期编号*/
	/*直接设置12个月，每月为一个周期*/
	@OneM ,		/*1月份  （金额）*/
	@twoM ,
	@threeM ,
	@fourM ,
	@fiveM ,
	@sixM,
	@sevenM ,
	@eightM ,
	@nineM,
	@tenM,
	@elenM ,
	@twentyM ,		/*12月份	*/

	@OneT,		/*1月份  （数量）*/
	@twoT ,
	@threeT ,
	@fourT ,
	@fiveT ,
	@sixT ,
	@sevenT ,
	@eightT ,
	@nineT ,
	@tenT,
	@elenT,
	@twentyT 		/*12月份*/
	  )
	/*if @@rowCount=0 */
  return @@identity	
end
end
else if @mode = 1
begin
  update employeesSeting set 
  	OneM=@OneM ,		/*1月份  （金额）*/
	twoM=@twoM ,
	threeM=@threeM ,
	fourM=@fourM ,
	fiveM=@fiveM ,
	sixM=@sixM,
	sevenM=@sevenM ,
	eightM=@eightM ,
	nineM=@nineM,
	tenM=@tenM,
	elenM=@elenM,
	twentyM =@twentyM,		/*12月份	*/

	OneT=@OneT,		/*1月份  （数量）*/
	twoT =@twoT,
	threeT =@threeT,
	fourT =@fourT,
	fiveT =@fiveT,
	sixT =@sixT,
	sevenT =@sevenT,
	eightT =@eightT,
	nineT =@nineT,
	tenT=@tenT,
	elenT=@elenT,
	twentyT =@twentyT		/*12月份*/
  where E_id=@E_id and p_id=@p_id and OneYear = @OneYear 
  
  return @@ROWCOUNT
end
GO
