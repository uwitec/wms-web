
create   PROCEDURE ts_c_UpdatePermission
(
	@nE_id 		int,
	@nPermission	image,
	@nPermPlugin	binary(800),/*added by ZhanXinYun@2010-10-22*/
	@szPass		varchar(20),
	@nMode   	int,
	@szComment	varchar(60)=''
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szComment is null  SET @szComment = ''
/*Params Ini end*/
set nocount on
if @nMode=0
	update employees set lim=@nPermission,limPlugin=@nPermPlugin where emp_id=@nE_id
else 
if @nMode=1
	update users set loginpass=cast(@szPass as varbinary(20)) where e_id=@nE_id
else
if @nMode=2
begin
	if exists(select e_id from users where e_id=@nE_id) return -1
	else
	begin
		insert users(e_id,loginpass)
		values(@nE_id,cast('' as varbinary(20)))
		if @@rowcount=0 return -2
                if exists(select e_id from limgroupuser where e_id=@nE_id)
                update users set ProductInfor=l.ProductInfor,ClientInfor=l.ClientInfor
                from users U, (select ProductInfor,ClientInfor,ls.e_id from limgroup L,limgroupuser ls where ls.lgid=l.gid and ls.e_id=@nE_id)l 
                where u.e_id=l.E_id
	end
end else
if @nMode=3
begin
	if not exists(select e_id from users where e_id=@nE_id) return -3
	else
	begin
		delete from  users where e_id=@nE_id
		if @@rowcount=0 return -2
	end
end else
if @nMode=10 /*以下为权限组*/
begin
	update limgroup set permission=@nPermission,limPlugin=@nPermPlugin where gid=@nE_id
end else
if @nMode=11
begin
	if exists(select [name] from limgroup where [name]=@szPass) return -1
	else
	begin
		insert limgroup([name],comment)
		values(@szPass,@szComment)
		if @@rowcount=0 return -2
	end
end else
if @nMode=12
begin
	if not exists(select gid from limgroup where gid=@nE_id) return -3
	else
	begin
		delete from  limgroup where gid=@nE_id
		if @@rowcount=0 return -2
		delete from  limgroupuser where lgid=@nE_id
	end
end
GO
