
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-7-11*/
/* Description: 下传单据DTS表处理*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_DtsDownBillDeal]
AS
BEGIN
    /*RETURN*/
	SET NOCOUNT ON;
 
	DECLARE @nFor int
	DECLARE @nNewBillId int    /*生成的billid*/
	DECLARE @nTmpBillId int 
	DECLARE @nPid int     /*商品id*/
	DECLARE @nRetNum int    /*返回值*/

	DECLARE @nBillId int    /*游标中使用的单据id*/
	DECLARE @nBillType int    /*-单据类型*/
	DECLARE @nNewBillType int    /*-下一步单据类型*/
	DECLARE @cBillStates char(1)  /*单据状态*/
	DECLARE @uGuid uniqueidentifier  /*单据GUID*/
	DECLARE @YGuid uniqueidentifier  /*原单GUID                                 --*/
	DECLARE @nCid int     /*往来单位id /机构类单据为门店ID*/
	DECLARE @sBillNum varchar(100)  /*单据编号*/
	DECLARE @nSaleQty numeric(18, 4) /*暂未使用*/
	DECLARE @nAdjustQty numeric(18, 4) /*暂未使用*/
 
	DECLARE @nYid int     /*-当前帐套机构ID*/
	DECLARE @nInput int     /*-机构发货类单据默认制单人*/
	DECLARE @nEid int     /*-机构发货类单据默经手人*/
	DECLARE @nAuditman int    /*机构发货类单据默审核人*/
	DECLARE @nSid int     /*机构发货退货单默认入库仓库*/
	DECLARE @nCur int
	DECLARE @szNote varchar(256)  /* 单据备注*/
	DECLARE @nZBAuditman int, @Zbaudittime datetime, @mdbillid int    /*机构申请单总部审核人*/
	DECLARE @QualityAudit    INT
 
	SET @nYid = 0
	SET @nInput = 0
	SET @nEid = 0
	SET @nAuditman = 0
	SET @nPid = 0
 
	/* 取默认值*/
	SELECT @nYid = sysvalue FROM sysconfig WHERE sysname = 'y_id'
	SELECT @nInput = sysvalue FROM sysconfig WHERE sysname = 'localinputman' AND Y_ID = @nYid
	SELECT @nEid = sysvalue FROM sysconfig WHERE sysname = 'localeid' AND Y_ID = @nYid
	SELECT @nSid = sysvalue FROM sysconfig WHERE sysname = 'CenterSID' AND Y_ID = @nYid
	SELECT @nAuditman = sysvalue FROM sysconfig WHERE sysname = 'localauditman' AND Y_ID = @nYid

    /*如果日志清除了，可以找回已经过账成功的日志信息*/
	INSERT INTO BillLog(BillGuid, y_id, Status, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate)
	SELECT guid, Y_ID, 0, 0, billid, billtype, 1, GETDATE(), billnumber, billdate FROM BillIdx_dts 
	WHERE GUID NOT IN (SELECT billguid FROM BillLog)    
		AND GUID IN (SELECT GUID FROM billidx)
	INSERT INTO BillLog
	  (BillGuid, y_id, STATUS, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate)
	SELECT guid, Y_ID, 0, 0, gspbillid, billtype, 1, GETDATE(), billnumber, billdate
	FROM   GspBillIdx_dts
	WHERE  GUID NOT IN (SELECT billguid FROM BillLog)
		   AND GUID IN (SELECT GUID FROM Gspbillidx)
	/*修改日志的传输标记，不管日志是否已经已传输*/
	UPDATE BillLog SET TransFlag = 0 WHERE BillGuid IN (SELECT Guid FROM BillIdx_Dts)
	UPDATE BillLog SET TransFlag = 0 WHERE BillGuid IN (SELECT Guid FROM GSPbillidx_dts)
 
	/* 删除本地已存在单据*/
	DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM billdraftidx) AND billstates NOT IN (1,4)
	DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM billidx WHERE billstates = '0') AND billstates = '0'
	DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM gspbillidx) AND billstates = '0'
	DELETE FROM GSPbillidx_dts WHERE GUID IN (SELECT GUID FROM GSPbillidx) and Billtype <> 563
	DELETE FROM GSPbillidx_dts WHERE GUID IN (SELECT GUID FROM GSPbillidx where Billtype = 563 and AuditMan2 <>0 and BillStates = '13')
 
	/*已红冲的单据不再处理*/
	DELETE FROM billidx_dts WHERE billstates IN (1,4) AND GUID IN (SELECT GUID FROM billidx WHERE billstates IN (1,4))

	/* 错误次数+1*/
	/*UPDATE BillLog SET ErrCount = ErrCount + 1 WHERE BillGuid IN(SELECT guid FROM BillIdx_Dts)*/
	INSERT INTO BillLog(BillGuid, y_id, Status, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate)
	SELECT guid, Y_ID, 1, 0, billid, billtype, 1, GETDATE(), billnumber, billdate FROM BillIdx_Dts WHERE GUID NOT IN
		(SELECT billguid FROM BillLog)

	/*小于本期开账日期的单据不过账 日志显示为正常 */
	IF EXISTS(SELECT BeginDate FROM MonthSettleInfo WHERE Y_ID NOT IN (0,2) AND MonthName = '本期') 
	BEGIN
		DECLARE @OpenAccountDate DATETIME
		SELECT TOP 1 @OpenAccountDate = BeginDate FROM MonthSettleInfo WHERE Y_ID NOT IN (0,2) AND MonthName = '本期'
		DELETE FROM billidx_dts WHERE billdate < @OpenAccountDate
		UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE billdate < @OpenAccountDate 
	END
		

	DECLARE curBill SCROLL CURSOR FOR
	SELECT  billid, billtype, billstates, guid, c_id, YGuid FROM billidx_dts ORDER BY billid
	SET @nFor = 0
	OPEN curBill
	SET @nCur = @@CURSOR_ROWS
	WHILE @nFor < @nCur
	BEGIN
		FETCH next FROM curBill INTO @nBillId, @nBillType, @cBillStates, @uGuid, @nCid, @YGuid
  
		/* 机构/自营店发货/机构发货退货单，生成机构/自营店收货/机构收货退货单  分公司用默认接收仓库*/
		IF @nBillType IN (150, 152, 151) AND (@nCid = @nYid OR @nYid = 2)
		BEGIN   
			IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND [sysvalue] = '1')
			BEGIN
				/*生成GSP收货单*/
				IF @nBillType IN (150, 152)
				BEGIN
					UPDATE billidx_dts SET inputman = @nInput, e_id = @nEid WHERE billid = @nBillId
					DECLARE @nGspId INT
					EXEC TS_H_CreateNewGspBill;1 @nBillId, @nBillType, 516, @nGspId output
					IF @nGspId > 0 
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
				END
			END
			ELSE
			BEGIN
				/*SET @nBillType = @nBillType + 10*/
				SET @nBillType = CASE @nBillType WHEN 150 THEN 160 WHEN 151 THEN 161 WHEN 152 THEN 162 END
				IF @cBillStates = '0'
				BEGIN
					BEGIN
						EXEC TS_H_CreateBillSN @nBillType, 1, null, @nInput, @nInput, @sBillNum output
						INSERT INTO billdraftidx
							(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
							order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
							InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
							B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, ZBAuditMan, ZBAuditDate)
						SELECT     billdate, @sBillNum, @nBillType, a_id, Y_ID, @nEid, sin_id, sin_id, 0, @nInput, ysmoney, ssmoney, quantity, taxrate, period, '2', 
							order_id, 0, 0, 0, '1900-1-1', '1900-1-1', jsye, jsflag, '原单据号【' + billnumber + '】' + note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
							InvoiceNO, BusinessType, ArAptotal, SendQTY, 0, VIPCardID, jsInvoiceTotal, @nYid, 0, begindate, Enddate, integral, integralYE,
							B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, ZBAuditMan, ZBAuditDate
						FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
						SET @nNewBillId = @@IDENTITY
     
						/* 机构收货退货单按本地单据编号重新生成备注，仓库*/
						IF @nBillType = 161
						BEGIN
							SELECT top 1 @szNote = '原单据号：' + billnumber FROM billidx WHERE billid IN(SELECT bill_id FROM buymanagebill WHERE YGuid IN(SELECT YGuid FROM SaleManageBill_Dts WHERE bill_id = @nBillId))
							UPDATE billdraftidx SET note = @szNote, sin_id = @nSid, sout_id = @nSid WHERE billid = @nNewBillId
						END
     
						INSERT INTO buymanagebilldrf
							(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
							makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, 
							InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 
							Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice,factoryid,costtaxrate,costtaxprice,costtaxtotal)
						SELECT     @nNewBillId, p_id, batchno, quantity, saleprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
							makedate, validdate, qualitystatus, price_id, CASE @nBillType WHEN 160 THEN @nSid ELSE sd_id END, sd_id, location_id2, supplier_id, commissionflag, comment, unitid, taxrate, location_id2, total, iotag,
							InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, costprice, YGuid, 
							@nYid, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice,factoryid,costtaxrate,costtaxprice,quantity*costtaxprice
						FROM         dbo.SaleManageBill_Dts
						WHERE bill_id = @nBillId
						ORDER BY smb_id
     
						/*处理自营店收货单电子监管码*/
						IF @nBillType IN (162)
						BEGIN
							INSERT INTO RetailBillidx_Sfda(bill_id, Product_Id, sfda_code, BillType, IsDraft, BatchNo, ValidDate, MakeDate)
							SELECT @nNewBillID AS BillId, a.p_id, s.sfda_code, @nBillType AS BillType, 1 AS IsDraft, 
								'' AS BatchNo, '1900-01-01' AS ValidDate, '1900-01-01' AS MakeDate 
							FROM Sfda_Detail s INNER JOIN 
								(SELECT GUID AS GUID, MAX(s.p_id) AS p_id FROM salemanagebill_dts s INNER JOIN billidx_dts b ON s.bill_id = b.billid
							WHERE s.bill_id = @nBillId GROUP BY b.GUID) a ON s.guid = a.GUID
							DELETE FROM Sfda_Detail WHERE guid IN (SELECT GUID FROM billidx_dts WHERE billid = @nBillId)      
						END
      
						/* 机构收货退货单按本地单据重新生成明细的仓库、货位*/
						IF @nBillType = 161
						BEGIN
							UPDATE buymanagebilldrf SET ss_id = x.ss_id, sd_id = x.sd_id, location_id = x.location_id, orgbillid = x.smb_id
							FROM (SELECT smb_id, ss_id, YGuid, sd_id, location_id FROM buymanagebill WHERE YGuid IN(SELECT YGuid FROM SaleManageBill_Dts WHERE bill_id = @nBillId))	x 
							WHERE buymanagebilldrf.YGuid = x.YGuid
						END
     
						/*检测是否自动过账 add BY luowei 2012-11-01*/
						IF exists(SELECT 1 FROM sysconfigtmp WHERE sysname = 'AutoCompanyBillAudit' AND sysvalue = '1')
						BEGIN
							EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
							IF @nRetNum <> 0
							BEGIN
								UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
								EXEC Ts_b_DeleteBillDraft @nRetNum output, 0, @nNewBillId
							END
							ELSE
							BEGIN
								UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
							END
						END
						ELSE
						BEGIN
							UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
						END
					END
				END
				ELSE
				IF @cBillStates = '1'
				BEGIN
					SET @nNewBillId = 0
					SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
					IF @nNewBillId > 0
					BEGIN
						EXEC ts_c_redword @nBillId, @nRetNum output
						IF @nRetNum <> 0
						BEGIN
							UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
						END
						ELSE
						BEGIN
							UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
						END
					END
					ELSE
					BEGIN
						SELECT @nNewBillId = ISNULL(billid, 0) FROM billdraftidx WHERE billtype = @nBillType AND GUID = @uGuid
						IF @nNewBillId > 0
						BEGIN 
							/*EXEC Ts_b_DeleteBillDraft @nRetNum output, 0, @nNewBillId*/
							UPDATE billdraftidx SET note = '总部已红冲本张单据' WHERE billid = @nNewBillId
							UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
						END  
					END
				END
			END
		END
  
		/* 销售类单据*/
		ELSE
		IF @nBillType IN (10, 11, 16, 17, 110, 111, 112, 113, 210, 211, 212)
		BEGIN
			/* 过账*/
			IF @cBillStates = '0'
			BEGIN
				BEGIN
					INSERT INTO billdraftidx
						(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
						order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate)
					SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', 
						0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate
					FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
					SET @nNewBillId = @@IDENTITY
     
					INSERT INTO salemanagebilldrf
						(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, 
						InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 
						Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, 0, total, iotag, 
						InvoiceTotal, thqty, newprice, 0, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 
						Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion,factoryid,costtaxprice,costtaxrate,quantity*costtaxprice
					FROM         dbo.SaleManageBill_Dts
					WHERE bill_id = @nBillId
					ORDER BY smb_id
     
					EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
						EXEC Ts_b_DeleteBillDraft @nRetNum output, 1, @nNewBillId
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
			ELSE
			/* 红冲*/
			IF @cBillStates = '1'
			BEGIN
				SET @nNewBillId = 0
				SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
				IF @nNewBillId > 0
				BEGIN
					EXEC ts_c_redword @nNewBillId, @nRetNum output
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
		END
  
		/* 采购类单据*/
		ELSE
		IF @nBillType IN (20, 21, 24, 25, 120, 121, 122, 123, 220, 221, 222)
		BEGIN
			/* 过账*/
			IF @cBillStates = '0'
			BEGIN
				BEGIN
					INSERT INTO billdraftidx
						(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
						order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate)
					SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', 
						0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate
					FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
					SET @nNewBillId = @@IDENTITY
     
					INSERT INTO buymanagebilldrf
						(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, 
						InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 
						Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, 0, total, iotag, 
						InvoiceTotal, thqty, newprice, 0, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 
						Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,quantity*costtaxprice
					FROM         dbo.buymanagebill_Dts
					WHERE bill_id = @nBillId
					ORDER BY smb_id
     
					EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
						EXEC Ts_b_DeleteBillDraft @nRetNum output, 0, @nNewBillId
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
			ELSE
			/* 红冲*/
			IF @cBillStates = '1'
			BEGIN
				SET @nNewBillId = 0
				SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
				IF @nNewBillId > 0
				BEGIN
					EXEC ts_c_redword @nNewBillId, @nRetNum output
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
		END
		/* 库存类单据*/
		ELSE
		IF @nBillType IN (30, 31, 33, 34, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 100, 101, 141)
		BEGIN
			/* 过账*/
			IF @cBillStates = '0'
			BEGIN
				BEGIN
					INSERT INTO billdraftidx
						(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
						order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate)
					SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', 
						0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate
					FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
					SET @nNewBillId = @@IDENTITY
     
					INSERT INTO storemanagebilldrf
						(bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, 
						ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, 
						SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillId, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, 
						ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, 0, AOID, 
						SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,quantity*costtaxprice
					FROM         dbo.storemanagebill_Dts
					WHERE bill_id = @nBillId
					ORDER BY smb_id, iotag
     
					EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
						EXEC Ts_b_DeleteBillDraft @nRetNum output, 2, @nNewBillId
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
			ELSE
			/* 红冲*/
			IF @cBillStates = '1'
			BEGIN
				SET @nNewBillId = 0
				SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
				IF @nNewBillId > 0
				BEGIN
					EXEC ts_c_redword @nNewBillId, @nRetNum output
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
		END
		/* 财务类单据*/
		ELSE
		IF @nBillType IN (15, 23, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 80, 81, 82, 83, 84, 87, 88, 90, 115, 146, 147, 148, 155, 165, 170, 171, 172, 173, 174)
		BEGIN
			/* 过账*/
			/* 储值单只执行红冲*/
			IF (@cBillStates = '0') AND (@nBillType <> 148)
			BEGIN
				BEGIN
					INSERT INTO billdraftidx
						(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
						order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate)
					SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', 
						0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate
					FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
					SET @nNewBillId = @@IDENTITY
     
					INSERT INTO financebilldrf
						(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillId, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id,factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM         dbo.financebill_Dts
					WHERE bill_id = @nBillId
					ORDER BY smb_id
     
					EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
						EXEC Ts_b_DeleteBillDraft @nRetNum output, 3, @nNewBillId
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
			ELSE
			/* 红冲*/
			IF @cBillStates = '1'
			BEGIN
				SET @nNewBillId = 0
				SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
				IF @nNewBillId > 0
				BEGIN
					EXEC ts_c_redword @nNewBillId, @nRetNum output
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
		END
		/* 库存盘点单*/
		ELSE
		IF @nBillType IN (50)
		BEGIN
			/* 过账*/
			IF @cBillStates = '0'
			BEGIN
				BEGIN
					INSERT INTO billdraftidx
						(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, 
						order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate)
					SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', 
						0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
						InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, 
						B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan, ZBAuditDate
					FROM         dbo.BillIdx_Dts WHERE billid = @nBillId
     
					SET @nNewBillId = @@IDENTITY
     
					INSERT INTO GoodsCheckBillDrf
						(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, AOID, 
						RowGuid, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
						makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, AOID, 
						RowGuid, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,quantity*costtaxprice
					FROM         dbo.GoodsCheckbill_Dts
					WHERE bill_id = @nBillId
					ORDER BY smb_id
     
					EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
						EXEC Ts_b_DeleteBillDraft @nRetNum output, 6, @nNewBillId
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
			ELSE
			/* 红冲*/
			IF @cBillStates = '1'
			BEGIN
				SET @nNewBillId = 0
				SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid
				IF @nNewBillId > 0
				BEGIN
					EXEC ts_c_redword @nNewBillId, @nRetNum output
					IF @nRetNum <> 0
					BEGIN
						UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid
					END
					ELSE
					BEGIN
						UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
					END
				END
			END
		END
  /* 库存批次调整单*/
  /*ELSE*/
  /*IF @nBillType IN (51)*/
  /*BEGIN*/
  /* IF @cBillStates = '0'*/
  /* BEGIN*/
  /*  -- 检测现有库存是否足够*/
  /*  IF NOT exists(*/
  /*  SELECT     0*/
  /*  FROM         dbo.storemanagebill_Dts AS b LEFT OUTER JOIN*/
  /*         dbo.storehouse AS s ON b.instoretime = s.instoretime AND b.batchno = s.batchno AND b.commissionflag = s.commissionflag AND */
  /*         b.supplier_id = s.supplier_id AND b.location_id = s.location_id AND b.ss_id = s.s_id AND b.validdate = s.validdate AND b.makedate = s.makedate AND */
  /*         b.costprice = s.costprice AND b.p_id = s.p_id*/
  /*  WHERE     (b.bill_id = @nBillId) AND (b.iotag = 0) AND (b.quantity > s.quantity)*/
  /*  )*/
  /*  -- 库存足够直接过账*/
  /*  BEGIN*/
  /*   BEGIN*/
  /*    INSERT INTO billdraftidx*/
  /*    (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, */
  /*      order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, */
  /*      InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, */
  /*      B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty)*/
  /*    SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', */
  /*      0, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, */
  /*      InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, */
  /*      B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty*/
  /*    FROM         dbo.BillIdx_Dts WHERE billid = @nBillId*/
      
  /*    SET @nNewBillId = @@IDENTITY*/
      
  /*    INSERT INTO financebilldrf*/
  /*    (bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id)*/
  /*    SELECT @nNewBillId, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id*/
  /*    FROM         dbo.financebill_Dts*/
  /*    WHERE bill_id = @nBillId*/
      
  /*    EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType*/
  /*    IF @nRetNum <> 0*/
  /*    BEGIN*/
  /*     UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid*/
  /*     EXEC Ts_b_DeleteBillDraft @nRetNum output, 5, @nNewBillId*/
  /*    END*/
  /*    ELSE*/
  /*    BEGIN*/
  /*     UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid*/
  /*    END*/
  /*   END*/
  /*  END*/
  /*  -- 库存不足，需要调整已过账单据*/
  /*  ELSE*/
  /*  BEGIN*/
  /*   SELECT     @nSaleQty = ISNULL(sum(s.quantity), 0)*/
  /*   FROM         dbo.storemanagebill_Dts AS b LEFT OUTER JOIN*/
  /*          (SELECT * FROM dbo.salemanagebill WHERE bill_id IN(SELECT billid FROM billidx WHERE transflag IN(0, -1))) AS s ON b.instoretime = s.instoretime AND b.batchno = s.batchno AND b.commissionflag = s.commissionflag AND */
  /*          b.supplier_id = s.supplier_id AND b.location_id = s.location_id AND b.ss_id = s.ss_id AND b.validdate = s.validdate AND b.makedate = s.makedate AND */
  /*          b.costprice = s.costprice AND b.p_id = s.p_id*/
  /*   WHERE     (b.bill_id = @nBillId) AND (b.iotag = 0)*/
  /*   GROUP BY b.p_id, b.batchno, b.costprice, b.makedate, b.validdate, b.ss_id, b.location_id, b.supplier_id, b.commissionflag, b.instoretime*/
     
  /*   UPDATE salemanagebill SET */
  /*  END*/
  /* END*/
  /* ELSE*/
  /* -- 红冲*/
  /* IF @cBillStates = '1'*/
  /* BEGIN*/
  /*  SET @nNewBillId = 0*/
  /*  SELECT @nNewBillId = ISNULL(billid, 0) FROM billidx WHERE billtype = @nBillType AND GUID = @uGuid*/
  /*  IF @nNewBillId > 0*/
  /*  BEGIN*/
  /*   EXEC ts_c_redword @nNewBillId, @nRetNum output*/
  /*   IF @nRetNum <> 0*/
  /*   BEGIN*/
  /*    UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1 WHERE BillGuid = @uGuid*/
  /*   END*/
  /*   ELSE*/
  /*   BEGIN*/
  /*    UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid*/
  /*   END*/
  /*  END*/
  /* END*/
  /*END*/

		SET @nFor = @nFor + 1
	/*  PRINT @nFor*/
	END
	DEALLOCATE curBill
 
	/*处理下传的GSP单据*/
	DECLARE curGspBill   SCROLL CURSOR  
	FOR
	SELECT gspbillid, billtype, billstates, guid, c_id, YGuid 
	FROM gspbillidx_dts 
	ORDER BY gspbillid

	SET @nFor = 0
	OPEN curGspBill
	SET @nCur = @@CURSOR_ROWS
	WHILE @nFor < @nCur
	BEGIN
		FETCH NEXT FROM curGspBill INTO @nBillId, @nBillType, @cBillStates, @uGuid, @nCid, @YGuid
		/*处理机构退回通知单564*/
		IF (@nBillType = 564) AND (@nCid = @nYid OR @nCid = 0)
		BEGIN
			EXEC TS_H_CreateBillSN @nBillType, 1, null, @nInput, @nInput, @sBillNum OUTPUT
			INSERT INTO GSPbillidx
				(BillType, BillNumber, Y_id, C_id, S_id, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, UpauditMan1, UpauditMan2,
				TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, SendTime, TrafficCompany, TempControlMode,
				WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, GUID, BillStates, Note, B_CustomName1, B_CustomName2,
				B_CustomName3, B_CustomName4, B_CustomName5, financeAudit, financeAuditDate, FollowNumber, TicketDate, transflag, Sendid, BalanceMode)
			SELECT BillType, @sBillNum, @nYid, Y_id, S_id, GETDATE(), @nInput, @nAuditman, GETDATE(), AuditMan2, AuditTime2, UpauditMan1, UpauditMan2,
				TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, SendTime, TrafficCompany, TempControlMode,
				WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, GUID, 13, Note, B_CustomName1, B_CustomName2,
				B_CustomName3, B_CustomName4, B_CustomName5, financeAudit, financeAuditDate, FollowNumber, TicketDate, transflag, Sendid, BalanceMode 
			FROM GSPbillidx_dts
			WHERE Gspbillid = @nBillId
			
			SET @nTmpBillId = @@IDENTITY
		    
			INSERT INTO GSPbilldetail
				(Gspbill_id, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, RefuseQty, PickQty, CheckQty,
				SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, Pricediscrepancy, Total, Discount, DiscountTotal,
				TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept,
				CheckReport, ReturnReason, CheckState, CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode,
				Batchcomment, BatchPrice, Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2,
				Comment3, factoryid, costtaxprice, costtaxrate, costtaxtotal)
			SELECT @nTmpBillId, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, RefuseQty, PickQty, CheckQty,
				SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, Pricediscrepancy, Total, Discount, DiscountTotal,
				TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept,
				CheckReport, ReturnReason, CheckState, CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode,
				Batchcomment, BatchPrice, Iscold, Isspec, @nYid, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2,
				Comment3, factoryid, costtaxprice, costtaxrate, costtaxtotal
			FROM GSPbilldetail_dts
			WHERE Gspbill_id = @nBillId
			
			SELECT @nNewBillType = CASE WHEN sendBillType = 1 THEN 161 ELSE 163 END FROM company WHERE company_id = @nYid
			
			EXEC TS_H_CreateBillSN @nNewBillType, 1, null, @nInput, @nInput, @sBillNum OUTPUT				
			INSERT INTO billdraftidx
				(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate,
				period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount,
				lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID,
				transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty,
				PartQty, DPdate, financeAudit, financeAuditDate, FollowNumber, QualityAudit, QualityAuditDate, TicketDate, YGuid, BalanceMode,ZBAuditMan, ZBAuditDate)
			SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @sBillNum, @nNewBillType, 0, y_id, InputMan, S_id, 0, 0, InputMan, 0, 0, 0, 0,
				1, 2, 0, 0, 0, 0, '1900-01-01', '1900-01-01', 0, 0, '原单编号【' + billnumber + '】', '', 0, 0, 
				'1900-01-01', NEWID(), 0, '', 0, 0, 0, 0, 0, 0, @nYid, 
				0, '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 0, 0,
				0, '1900-01-01', 0, '1900-01-01', '', 0, '1900-01-01', '1900-01-01', GUID, -1,0,'1900-01-01'
			FROM GSPbillidx_dts 
			WHERE Gspbillid = @nBillId
			
			SELECT @nNewBillID = @@IDENTITY
			
			INSERT INTO buymanagebilldrf
				(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney,
				retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag,
				comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno,
				PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode,
				scomment, batchprice, Conclusion, costtaxprice, costtaxrate, costtaxtotal, factoryid)
			SELECT @nNewBillID, a.P_id, a.Batchno, a.ApplicantQty, 0, 0, 1, 0, 0, 0, 0, 0,
				0, 0, a.MakeDate, a.Validdate, '合格', 0, a.S_id, 0, 0, 0, 0,
				'', a.Unit_id, 0, 0, 0, 0, 0, a.ApplicantQty, 0, 0, 0, 0, 0, '',
				-1, a.ApplicantQty, 0, NEWID(), b.InputMan, 0, b.Yguid, @nYid, 0, '1900-01-01', '', '',
				'', 0, '', 0, 0, 0, 0  
			FROM GSPbilldetail_dts a, GSPbillidx_dts b
			WHERE a.Gspbill_id = b.Gspbillid AND Gspbill_id = @nBillId
			
			EXEC TS_H_BillTraceAct 0, @nNewBillID, @nNewBillType, @nTmpBillId, @nBillType, 1, 0
		END
		
		if @nBillType = 563
		begin		   
		   select @nZBAuditman = AuditMan2, @Zbaudittime = AuditTime2 from gspbillidx_dts where gspbillid = @nBillId 
		   select @mdbillid	= gspbillid from gspbillidx where [GUID] = @uGuid
		   if @mdbillid is null set @mdbillid = 0
		   if @mdbillid > 0
		   begin		 
		     update gspbilldetail set CheckQty = t.checkqty,UneligibleTranSactor=t.UneligibleTranSactor  
		       from gspbilldetail_dts t, gspbilldetail mx 
		      where t.YrowGuid = mx.YrowGuid and t.Gspbill_id = @nBillId and mx.Gspbill_id = @mdbillid
		     update gspbillidx set BillStates = '13', AuditMan2 = @nZBAuditman, AuditTime2 = @Zbaudittime where gspbillid  =@mdbillid   		   
		   end   		
		end
			
		SET @nFor = @nFor + 1
	END
	DEALLOCATE curGspBill 
/*------------------------草稿单据------------------------- */
    /*写入日志*/
	DELETE FROM billdraftidx_dts WHERE GUID IN (SELECT GUID FROM billidx) AND billstates = '0'
	DELETE FROM billdraftidx_dts WHERE GUID IN (SELECT YGuid FROM billidx WHERE billtype = 163)
	DELETE FROM billdraftidx_dts WHERE GUID IN (SELECT GUID FROM billdraftidx) AND billstates IN (2,3)
    
	INSERT INTO BillLog(BillGuid, y_id, Status, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate)
	SELECT guid, Y_ID, 2, 0, billid, billtype, 1, GETDATE(), billnumber, billdate FROM BillDraftIdx_Dts WHERE GUID NOT IN
	(SELECT billguid FROM BillLog)

	/*处理草稿单据*/
	DECLARE CurDraft SCROLL CURSOR FOR
	SELECT billid, billtype, billstates, guid, y_id, YGuid,QualityAudit FROM billdraftidx_dts ORDER BY billid
	SET @nFor = 0
	OPEN CurDraft
	SET @nCur = @@CURSOR_ROWS
	WHILE @nFor < @nCur
	BEGIN
		FETCH next FROM CurDraft INTO @nBillId, @nBillType, @cBillStates, @uGuid, @nYid, @YGuid,@QualityAudit
		/*下传的已审核的调拨单*/
		
		IF @nBillType IN (157) /*AND @cBillStates IN (3)  xxx。2017-08-31 ，在现有模式下，这儿直接移到xml文件过滤中去处理*/
		BEGIN
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid, ZBAuditMan, ZBAuditDate)
			SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid, ZBAuditMan, ZBAuditDate FROM billdraftidx_dts
			WHERE billid = @nBillId

			SET @nNewBillId = @@IDENTITY
   
			INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
				ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, 
				InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, 
				RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, 
				scomment, batchprice, CxGuid, Conclusion, OOSid, costtaxprice, factoryid, costtaxrate, costtaxtotal)
			SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
				ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, 
				InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, 
				RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, 
				scomment, batchprice, CxGuid, Conclusion, OOSid, costtaxprice, factoryid, costtaxrate, costtaxtotal
			FROM salemanagebilldrf_dts
			WHERE bill_id = @nBillId
       
			UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
			
			EXEC TS_H_BillTraceAct 0, @nNewBillId, @nBillType, 0, @nBillType, 1, 1   
		END
		
  /*XXX.2017-05-15 只处理下传到收货门店的店间调拨单，简化流程*/
	/*	--下传的已同意的调拨单生成自营店收货退货单
		IF @nBillType IN (157) AND @cBillStates IN (0)
		BEGIN
			DECLARE @BillSN VARCHAR(200) SET @BillSN = ''
			EXEC TS_H_CreateBillSN 163,1,NULL,0,0,@BillSN OUTPUT,0 
			--PRINT @BillSN
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates,
				order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
				InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid)
			SELECT CONVERT(VARCHAR(10),convert(datetime,GETDATE(),10)),
				@BillSN,163,0,2,e_id, sout_id, 0, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period,3,
				0,0,0,0,0,0,ysmoney,0,'由店间调拨单生成,原单编号:' + billnumber,'',0,0,0,NewID(),0,
				'',0,0,quantity,0,0,0, Y_ID, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, Guid
           
			FROM billdraftidx_dts
			WHERE billid= @nBillId
   
			SET @nNewBillId = @@IDENTITY
   
			INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
				price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
				iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
				SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, 
				scomment, batchprice, Conclusion, costtaxprice, factoryid, costtaxrate, costtaxtotal)
			SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
				price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
				iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
				SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, 
				scomment, batchprice, Conclusion, costtaxprice, factoryid, costtaxrate, costtaxtotal
			FROM salemanagebilldrf_dts
			WHERE bill_id = @nBillId    

			--自动过账
			EXEC ts_c_BillAudit @nNewBillId, @nPid output, @nRetNum output, @nBillType
			IF @nRetNum <> 0
			BEGIN
				UPDATE BillLog SET ErrFlag = @nRetNum, ErrCount = ErrCount + 1, p_id = @nPid WHERE BillGuid = @uGuid
				DELETE FROM billdraftidx WHERE billid = @nNewBillId
			END
			ELSE
			BEGIN
				DECLARE @nNBILLID INT, @nYBILLID INT
			    SELECT @nYBILLID = billid FROM billdraftidx WHERE GUID  = @uGuid AND billtype = @nBillType
			    SELECT @nNBILLID = billid FROM billidx      WHERE YGuid = @uGuid AND billtype = 163
			    EXEC TS_H_BillTraceAct 0, @nNBILLID, 163, @nYBILLID, @nBillType, 0, 1 --店间调拨单单据跟踪
			    
				UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
				UPDATE billdraftidx SET billstates = 0, transflag = 3 WHERE GUID = @uGuid
			END     
		END 
  
		--下传的已拒绝的调拨单
		IF @nBillType IN (157) AND @cBillStates IN (1)
		BEGIN 
			UPDATE billdraftidx SET billstates = 1, transflag = 3 WHERE GUID = @uGuid
		END 
		IF @nBillType IN (157) AND @cBillStates IN (0)
		BEGIN 
			UPDATE billdraftidx SET QualityAudit=@QualityAudit WHERE GUID = @uGuid
		END 
  */
		/*下传的机构费用单*/
		IF @nBillType IN (166) AND @cBillStates IN (3)
		BEGIN
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid, ZBAuditMan, ZBAuditDate)
			SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid, ZBAuditMan, ZBAuditDate
			FROM billdraftidx_dts
			WHERE billid = @nBillId
    
			SET @nNewBillId = @@IDENTITY
   
			INSERT INTO financebilldrf(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id, Conclusion)
			SELECT @nNewBillId, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id, Conclusion
			FROM financebilldrf_dts 
			WHERE bill_id = @nBillId
    
			UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
		END   

		SET @nFor = @nFor + 1
		/*  PRINT @nFor  */
	END  
    
	DEALLOCATE CurDraft 
	
	
	/*XXX.对下传单据做一次检测*/
	IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND [sysvalue] = '1')
	begin
		insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown)
		select GUID,YGuid,billtype,Y_ID,0 from billidx_dts where billtype in (152,150) and GUID not in (select GUID from gspbillidx where billtype = 516)
	 
		delete from DownBillLog where BillGuid  in (select GUID from gspbillidx where billtype = 516)
	end
	else begin
		insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown)
		select GUID,YGuid,billtype,Y_ID,0 from billidx_dts where billtype in (152,150) and GUID not in 
		(select GUID from billidx where billtype in (160,162)
		union all
		select GUID from billdraftidx where billtype in (160,162)	
		)
	 
		delete from DownBillLog where BillGuid  in 		
		(select GUID from billidx where billtype in (160,162)
		union all
		select GUID from billdraftidx where billtype in (160,162)	
		)	
	end
	/*XXX.2017-04-24 对店间调拨单也做未传输成功，自动更新传输标记的处理*/
		insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown)
		select GUID,YGuid,billtype,Y_ID,0 from
		(
		/*下传到收货方*/
		select GUID,YGuid,billtype,c_id as Y_ID from billdraftidx_dts where billtype in (157) and c_id = @nYid and
			GUID not in (select GUID from billdraftidx where billtype in (157) and c_id = @nYid )
		union all
		/*下传回发货方*/
		select GUID,YGuid,billtype,Y_ID from billdraftidx_dts where billtype in (157) and Y_ID = @nYid and
			GUID not in (select GUID from billdraftidx where billtype in (157) and Y_ID = @nYid and billstates = 0 and transflag = 3)
		) t
	/*XXX.删除掉已经传输成功了的	*/
		delete from DownBillLog where BillGuid  in 
		(
			select GUID from billdraftidx where billtype in (157) and c_id = @nYid
			union all
			select GUID from billdraftidx where billtype in (157) and Y_ID = @nYid and billstates = 0 and transflag = 3
		)	
	
    /*删除业务表 */
	TRUNCATE TABLE GSPbillidx_dts
	TRUNCATE TABLE GSPbilldetail_dts
	TRUNCATE TABLE billidx_dts
	TRUNCATE TABLE salemanagebill_dts
	TRUNCATE TABLE buymanagebill_Dts
	TRUNCATE TABLE financebill_Dts 
	TRUNCATE TABLE storemanagebill_Dts
	TRUNCATE TABLE goodscheckbill_Dts
	TRUNCATE TABLE tranmanagebill_Dts

	TRUNCATE TABLE billdraftidx_dts 
	TRUNCATE TABLE salemanagebilldrf_dts
	TRUNCATE TABLE financebilldrf_dts
END
GO
