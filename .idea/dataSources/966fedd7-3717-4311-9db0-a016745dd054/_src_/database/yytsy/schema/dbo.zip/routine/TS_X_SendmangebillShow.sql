
/******************************************
复核单查询（物流配送）
作者：XXX
创建日期 2015-04-11
********************************************/
CREATE PROCEDURE TS_X_SendmangebillShow
(	
	@BillList VARCHAR(300)= '',			/*单据id字符串  --这儿修改为按物流单查复核明细*/
	@C_id int,                          /*往来单位*/
	@nSendC_id int                      /*收货方*/
)
as
BEGIN
	if @BillList is null set @BillList = 0

	SELECT   g.Gspbillid AS billId, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
					g.AUDITER1 AS auditmanN1name, 
					/*g.AuditTime1, */
					(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
					g.AuditMan2, g.AUDITER2 AS auditmanN2name, 
					/*g.AuditTime2, */
					(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
					 g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
					 g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
					g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
					g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
					g.YBILLNUMBER, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,g.TicketDate,isnull(o.TrafficType,'') as TrafficType,isnull(o.TrafficCompany,'') as TrafficCompany,
					isnull((o.ysmoney -gd.TaxTotal),0) as SYMoney,e.name as ename,case when SM.Transportation_States = 2 then 1 else 0 end as Transportation_States,
					Case when g.Sendid > 0 then '已配送' else '未配送' end as PSState,sm.sm_id,g.SendCName
	FROM      dbo.VW_GSPBILLIDX AS g
				LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
				LEFT JOIN orderidx O ON g.Yguid = o.Guid
				LEFT JOIN employees E ON E.emp_id = O.e_id
				LEFT JOIN (select Gspbill_id,case when gb.BillStates = 15 then SUM(CheckQty * TaxPrice) else 0 end as TaxTotal  from GSPbilldetail gt left join GSPbillidx gb on gt.Gspbill_id = gb.Gspbillid group by Gspbill_id,BillStates ) 
							gd on gd.Gspbill_id = g.Gspbillid
				LEFT JOIN Sendmangebill sm ON sm.billid = g.Gspbillid
	WHERE   (g.BillType = 551) AND (g.Sendid in (select CAST(szTYPE as int) as Gspbillid from dbo.DecodeToStr(@BillList)))
	         and (@C_id = 0 or g.C_id = @C_id)
	         and (@nSendC_id = 0 or g.SendC_id = @nSendC_id)
	        /*AND SM.Transportation_States <> 2      --这儿查询未抵达的*/
	order by g.C_id
end
GO
