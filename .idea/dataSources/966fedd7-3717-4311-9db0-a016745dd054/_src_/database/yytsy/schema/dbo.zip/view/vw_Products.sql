

/*修改deleted列的类型*/
/*修改deleted的检索条件为 deleted<>1*/
/*增加deleted的转译列 StatusName*/
CREATE VIEW [dbo].[vw_Products]
AS
SELECT ISNULL(u1.name, '') AS Unit1Name, ISNULL(WholeU.name, '') AS WholeUnitName, ISNULL(m.medtype, '') AS MedName, '' AS MedCode, ISNULL(pc.pc_name, '') AS PcName, 
          ISNULL(pc.pc_code, '') AS PcCode, p.AuditStates, p.BulidNo, p.ChemName, p.ControlYard, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, p.Custompro5, p.EngName,isnull(f.AccountComment,'') AS Factory, p.GMP, 
          p.GMPNo, p.GMPvaliddate, p.Gross, p.IfZYCheck, p.Incrate, p.Inputdate, p.Inputman, p.Integral, p.IsClientDiscount, p.IsSplit, p.IsValuedProduct, p.LTTime, p.LastUpDate, p.LastUpdateman, p.LatinName, 
          p.MaintainDay, p.MaintainType, p.ModifyDate, p.NoneQuantity, p.OTCType, p.PackStd, p.PerCodevalid, p.PosYhDay, p.PrintClass, p.ProREP_Data, p.ProREP_No, p.Profit, p.RegisterNo, p.Registervalid, 
          p.RowIndex, p.SR2_id, p.SR_id, p.StorageCon, p.StoreCondition, p.TC1, p.TC2, CAST(ISNULL(tx.TaxRate, 0) AS numeric(25,8)) AS TaxRate, p.TcCost, p.TransTimes, p.TransToYJ, p.WholeUnit_id, p.alert, p.alias, 
          p.auditComment, p.auditMan, p.basicMedication, p.buycount, p.child_count, p.child_number, p.class_id, p.cldw, p.cljg, p.comment, p.costmethod, p.deduct, p.deleted, p.factoryc_id, p.firstcheck, p.gspflag, 
          p.hsbl, p.ifIntegral, p.ifdiscount, p.incRate2, p.incRate3, p.isCheckReport, p.makearea, ISNULL(m.id, 0) AS medtype, p.modal, p.name, p.otcflag, p.pack, p.parent_id, p.permitcode, p.pinyin, p.protectprice, 
          ISNULL(r.id, 0) AS r_id, p.rate2, p.rate3, p.rate4, p.serial_number, p.sfcl, p.standard, p.tcmoney, p.trademark, p.unit1_id, p.unit2_id, p.unit3_id, p.unit4_id, p.validcheck, p.validday, p.validmonth, p.product_id, 
          ISNULL(tx.id, 0) AS taxrateid, ISNULL(u3.name, '') AS Unit4Name, ISNULL(u0.name, '') AS Unit2Name, ISNULL(u2.name, '') AS Unit3Name, p.serial_number AS code, ISNULL(pr.retailprice, 0) AS retailprice, 
          CAST(ISNULL(pr.recprice, 0) AS numeric(18, 4)) AS recprice, ISNULL(pr.price1, 0) AS price1, ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, ISNULL(pr.glprice, 0) 
          AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice, CASE p.otcflag WHEN 0 THEN '否' WHEN 1 THEN '是' END AS otcbz, 
          CASE p.deleted WHEN 0 THEN '正常' WHEN 1 THEN '删除' WHEN 2 THEN '停购' WHEN 3 THEN '停售' WHEN 4 THEN '停用' END AS StatusName, ISNULL(r.RangeName, '') AS rName, ISNULL(g.GSPPropert, '') 
          AS gspPropert, (CASE p.OTCType WHEN 0 THEN '甲类' WHEN 1 THEN '乙类' WHEN 2 THEN '[无]' ELSE '' END) AS OTCName, 
          (CASE p.MaintainType WHEN 0 THEN '一般养护' WHEN 1 THEN '重点养护' WHEN 2 THEN '不养护' END) AS Maintain, (CASE p.firstCheck WHEN 0 THEN '否' WHEN 1 THEN '是' END) AS szFirst, 
          (CASE p.gmp WHEN 0 THEN '否' WHEN 1 THEN '是' END) AS szGmp, ISNULL(p.NoneQuantity, '') AS NoneQname, ISNULL(SR.name, '') AS SRname, 
          CASE p.alert WHEN 0 THEN '是' WHEN 1 THEN '否' END AS ifalert, 
          (CASE WHEN p.wholeUnit_id = p.unit2_id THEN rate2 WHEN p.wholeUnit_id = p.unit3_id THEN rate3 WHEN p.wholeUnit_id = p.unit4_id THEN rate4 ELSE 1 END) AS WholeRate, (CASE isnull(p.AuditStates, 0) 
          WHEN 1 THEN '已审核' ELSE '未审核' END) AS AuditStatesStr, CASE p.StoreCondition WHEN 2 THEN 1 ELSE 0 END AS Iscold, ISNULL(g.doubleCheck, 0) AS Isspec,
          p.StandardCode, p.CloudCode 
FROM   dbo.unit AS u0 RIGHT OUTER JOIN
          dbo.products AS p LEFT OUTER JOIN
          basefactory f on p.factoryc_id=f.CommID   LEFT OUTER JOIN
          dbo.unit AS WholeU ON p.WholeUnit_id = WholeU.unit_id LEFT OUTER JOIN
          dbo.unit AS u3 ON p.unit4_id = u3.unit_id LEFT OUTER JOIN
          dbo.unit AS u2 ON p.unit3_id = u2.unit_id ON u0.unit_id = p.unit2_id LEFT OUTER JOIN
          VW_MedType AS m ON p.product_id = m.product_id LEFT OUTER JOIN
          dbo.PrintClass AS pc ON p.PrintClass = pc.pc_id LEFT OUTER JOIN
          dbo.unit AS u1 ON p.unit1_id = u1.unit_id LEFT OUTER JOIN
              (SELECT p_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, lowprice
             FROM   dbo.price
             WHERE (unittype = 1)) AS pr ON pr.p_id = p.product_id 
             LEFT OUTER JOIN VW_Range AS r ON p.product_id = r.product_id 
             LEFT OUTER JOIN VW_TaxRate AS tx ON p.product_id = tx.product_id
             LEFT OUTER JOIN dbo.GSPPropert AS g ON g.GSPID = p.gspflag 
             LEFT OUTER JOIN dbo.SaleRange AS SR ON SR.id = p.SR_id
WHERE (p.deleted <> 1) AND (p.IsSplit = 0)
GO
