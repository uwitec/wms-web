


CREATE VIEW DBO.[VW_X_BillIDX]
AS
SELECT  BI.*, 
  ISNULL(C.[Name]  ,'') AS [CName],          ISNULL(C.[Class_ID]  ,'') AS [CClass_ID], 
  ISNULL(A.[Name]  ,'') AS [AName],          ISNULL(A.[Class_ID]  ,'') AS [AClass_ID], 
  ISNULL(E1.[Name] ,'') AS [EName],          ISNULL(E1.[Class_ID] ,'') AS [EClass_ID], 
  ISNULL(E2.[Name] ,'') AS [InputManName],   ISNULL(E2.[Class_ID] ,'') AS [InputManClass_ID], 
  ISNULL(E3.[Name] ,'') AS [AuditManName],   ISNULL(E3.[Class_ID] ,'') AS [AuditManClass_ID], 
  ISNULL(D.[Name]  ,'') AS [DepartmentName], ISNULL(R.[Name]      ,'') AS [RegionName], 
  ISNULL(SS.[Name] ,'') AS [SSName],         ISNULL(SS.[Class_ID] ,'') AS [SSClass_ID],
  ISNULL(SD.[Name] ,'') AS [SDName],         ISNULL(SD.[Class_ID] ,'') AS [SDClass_ID],
  ISNULL(SP.[PosName],'') AS [PosName],      ISNULL(Y.Class_ID,'') as [YClass_ID],
  ISNULL(Y.[Name],'')   AS [Yname] 
FROM BillIDX BI
  LEFT JOIN Account A    ON BI.[A_ID]=A.[Account_ID] 
  LEFT JOIN ClientS C    ON BI.[C_ID]=C.[Client_ID] 
  LEFT JOIN Employees E1 ON BI.[E_ID]=E1.[EMP_ID] 
  LEFT JOIN Employees E2 ON BI.[InputMan]=E2.[EMP_ID] 
  LEFT JOIN Employees E3 ON BI.[AuditMan]=E3.[EMP_ID] 
  LEFT JOIN Department D ON BI.[Department_ID]=D.[DepartmentID] 
  LEFT JOIN Region R     ON BI.[Region_ID]=R.[Region_ID] 
  LEFT JOIN Storages SS  ON BI.[SOUT_ID]=SS.[Storage_ID] 
  LEFT JOIN Storages SD  ON BI.[SIN_ID]=SD.[Storage_ID]
  LEFT JOIN Shop     SP  ON BI.[posid]=SP.[PosID]
  LEFT JOIN Company  Y   ON Y.[Company_id]=BI.Y_id
GO
