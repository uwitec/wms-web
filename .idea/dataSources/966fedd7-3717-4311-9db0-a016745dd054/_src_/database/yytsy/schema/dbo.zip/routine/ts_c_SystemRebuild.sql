
create  procedure ts_c_SystemRebuild
(
	@bIni			bit,/*是否清除期初*/
 	@bDraft 	bit	/*是否清除草稿*/
)

/*with eccrypt*/
as
/*系统重建*/
declare @nY_ID int, @nRet int

begin tran 
	if @bDraft=1
	begin
		truncate table billdraftidx
		truncate table buymanagebilldrf
		truncate table salemanagebilldrf
		truncate table storemanagebilldrf
		truncate table financebilldrf
		truncate table tranmanagebilldrf
		truncate table jspdetail
		truncate table jsbdetail
		truncate table GoodsCheckBilldrf
		truncate table retailmerge
		truncate table ReturnBilldrf
	end
	TRUNCATE TABLE GSPbillidx
	TRUNCATE TABLE GSPbilldetail
	truncate table billidx
	truncate table buymanagebill
	truncate table salemanagebill
	truncate table storemanagebill
	truncate table buymanagebilltmp
	truncate table salemanagebilltmp
	truncate table storemanagebilltmp
	truncate table tranmanagebilltmp
	truncate table tranmanagebill
	truncate table financebill
	truncate table productdetail
	truncate table accountdetail
 	truncate table retailbillidx
 	truncate table retailbill
	truncate table orderbill
	truncate table orderidx
	truncate table storehouse
    truncate table storezero
	truncate table GoodsCheckBill
	truncate table storedx
	truncate table storebrrow
	truncate table jspdetail
	truncate table jsbdetail
	truncate table jbdetail
	truncate table jkdetail
	truncate table tranidx
	truncate table tranbill
	truncate table tasklist
    truncate table tasklistup
	truncate table AutoGoodsCheck
  truncate table pdplanidx
  truncate table pdplan
  truncate table checkidx
  truncate table redhistory
  truncate table otherstorehouse
  truncate table GspTable
  truncate table PrintDetail
  delete from goodscheckbilldrf where bill_id in (select billid from billdraftidx where billtype=58)
  delete from billdraftidx where billtype=58 
  truncate table invoiceidx
  truncate table invoice 
  truncate table VIPLog
  truncate table ExIntegRalManagebill
  truncate table ExIntegRalManagebilldrf
  truncate table accountbalanceDts
  truncate table YAccountDetail  
  truncate table YProductdetail
  truncate table ClientsbalanceDts
  truncate table CompanybalanceDts
  truncate table accountbalanceDts
  truncate table PRICEINQUIREIDX  
  truncate table PriceInquireBill
  truncate table ReturnBill
  truncate table yretailbillidx
  truncate table yretailbill
  truncate table ybilldraftidx
  truncate table ysalemanagebilldrf
  truncate table dayaccount
  truncate table dayaccountdetail
  truncate table UpBillList
  truncate table sendidx
  truncate table sendmangebill
  truncate table msgcenter
  truncate table productdetailtmp
  truncate table accountdetailtmp
  truncate table Sfda_Detail
  truncate table RetailBillidx_Sfda
  truncate table Sfda_List
  truncate table GspMaintainPlan
  truncate table billtrace
  truncate table zerostockidx
  truncate table cxXML
  truncate table cxDetail
  truncate table billlog/*yypeng-2016-12-23 13:58:49--系统重建清除传输日志表*/
  truncate table PerDayData
  truncate table PaymentBill
  truncate table PaymentIdx
  truncate table OOSCatalog  
  truncate table VipDetail
  truncate table systemlog
  truncate table MsgHistory
  truncate table Integralidx
  truncate table Integraldetail  
  			
/*	删除业务表 */
	TRUNCATE TABLE billidx_dts
	TRUNCATE TABLE salemanagebill_dts
	TRUNCATE TABLE buymanagebill_Dts
	TRUNCATE TABLE financebill_Dts 
	TRUNCATE TABLE storemanagebill_Dts
	TRUNCATE TABLE goodscheckbill_Dts
	TRUNCATE TABLE tranmanagebill_Dts 
	truncate table productdetail_dts
	truncate table accountdetail_dts
	truncate table retailbillidx_dts
	truncate table retailbill_dts	
	truncate table ExIntegRalManagebill_dts
	/*删除草稿中间表*/
	TRUNCATE TABLE billDraftidx_dts
	TRUNCATE TABLE salemanagebilldrf_dts
	TRUNCATE TABLE financebilldrf_dts
	TRUNCATE TABLE GSPCompy_dts	
	/*删除会员积分表*/
	TRUNCATE TABLE Integralidx_dts
	TRUNCATE TABLE Integraldetail_dts
	
	IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
		truncate table billhistory

	if @bIni =1 
	begin
		truncate table storehouseini
    truncate table storezeroini
		truncate table storedxini
		truncate table storebrrowini
    truncate table otherstorehouse
    truncate table otherstorehouseini
		update account set ini_total=0
		update accountbalance set ini_total=0
		update clients set artotal_ini=0,aptotal_ini=0,pre_artotal_ini=0,pre_aptotal_ini=0
		update Clientsbalance set artotal_ini=0,aptotal_ini=0,pre_artotal_ini=0,pre_aptotal_ini=0
		update Companybalance set artotal_ini=0,aptotal_ini=0,pre_artotal_ini=0,pre_aptotal_ini=0,OpenAccount=0
		update employees set artotal=0,aptotal=0
	end

	update account set cur_total=0,total_01=0,total_02=0,total_03=0,total_04=0,total_05=0,total_06=0,total_07=0,total_08=0,total_09=0,total_10=0,total_11=0,total_12=0
	update accountbalance set cur_total=0,total_01=0,total_02=0,total_03=0,total_04=0,total_05=0,total_06=0,total_07=0,total_08=0,total_09=0,total_10=0,total_11=0,total_12=0
	update clients set artotal=0,aptotal=0
	update Clientsbalance set artotal=0,aptotal=0, pre_artotal=0,pre_aptotal=0
    update Companybalance set artotal=0,aptotal=0, pre_artotal=0,pre_aptotal=0
  	update employees set artotal=0,aptotal=0
	delete from monthsettleinfo where monthname<>'本期'
	update monthsettleinfo set begindate=convert(varchar(10),getdate(),20),
		period=1 where monthname='本期'
	update sysconfig set sysvalue='1' where [sysname]='AccountPeriod' 
	update sysconfig set sysvalue='0' where [sysname]='OpenAccount' 
        update sysconfig set sysvalue='0' where [sysname]='isupdatefiliale'

 	delete from users 			where e_id in (select emp_id from employees where deleted=1 and child_number=0)
 	delete from account  		where deleted=1
 	delete from products    where deleted=1
 	delete from clients    	where deleted=1
 	delete from employees 	where deleted=1
 	delete from storages    where deleted=1
	delete from department  where deleted=1
	delete from region	where deleted=1
	/*delete from medtype	where deleted=1*/
	delete from unit	where deleted=1

	update billsnstyle set sncount=0
	update sysconfig set sysvalue=0 where [sysname]='billsncount'
	update gspsnstyle set sncount=0
	update sysconfig set sysvalue=0 where [sysname]='gspsncount'
    update Companybalance set OpenAccount = 0 where c_id = 0
     
       /*计算 accountbalance */
    declare UpdateUseFlag cursor for
	  select posid from  ReplicationAuthorize
	  open UpdateUseFlag
	  fetch next from UpdateUseFlag into @nY_ID
	  while @@FETCH_STATUS=0	
	  begin 
	    exec @nRet = ts_j_GetUseTag @nY_Id
	    update ReplicationAuthorize set UseTag = @nRet
	    fetch next from UpdateUseFlag into @nY_ID
	  end	
	  close UpdateUseFlag
   deallocate UpdateUseFlag
     
commit tran 

return 0
GO
