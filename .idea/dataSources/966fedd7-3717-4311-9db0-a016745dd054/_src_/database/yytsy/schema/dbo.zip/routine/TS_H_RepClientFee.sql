
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-12-17*/
/* Description:	客户费用核算报表，统计一般费用单*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepClientFee]
	@BeginDate		datetime,
	@EndDate		datetime,
	@Type			int		/*0：往来单位。1：职员。2：部门*/
AS
BEGIN
	SET NOCOUNT ON;

	delete from reportcfg where repname like 'fmRepClientFee%'
	
	create table #tmp(class_id varchar(30), name varchar(80), aname varchar(80), fee NUMERIC(25,8))
	declare @sql varchar(8000)
	if @Type = 0
	begin
		insert into #tmp
		SELECT     c.class_id, c.name, a.name AS aname, SUM(b.jftotal) AS fee
		FROM         dbo.billidx AS i INNER JOIN
							  dbo.financebill AS b ON i.billid = b.bill_id INNER JOIN
							  dbo.clients AS c ON b.c_id = c.client_id INNER JOIN
							  dbo.account AS a ON b.a_id = a.account_id
		WHERE     (i.billtype = 61) and (i.billdate between @BeginDate and @EndDate)
					and  (NOT (i.billstates IN (1, 4)))
		GROUP BY c.name, a.name, c.class_id
		set @sql = 'select class_id, name as [往来单位]'
	end
	else
	if @Type = 1
	begin
		insert into #tmp
		SELECT     e.class_id, e.name, a.name AS aname, SUM(b.jftotal) AS fee
		FROM         dbo.billidx AS i INNER JOIN
							  dbo.financebill AS b ON i.billid = b.bill_id INNER JOIN
							  dbo.account AS a ON b.a_id = a.account_id INNER JOIN
							  dbo.employees AS e ON i.e_id = e.emp_id
		WHERE     (i.billtype = 61) and (i.billdate between @BeginDate and @EndDate)
					and  (NOT (i.billstates IN (1, 4)))
		GROUP BY a.name, e.class_id, e.name
		set @sql = 'select class_id, name as [职员名称]'
	end
	
	select @sql = @sql + ' , max(case aname when ''' + aname + ''' then fee else 0 end) [' + aname + ']'
	from (select distinct aname from #tmp) as a
	set @sql = @sql + ', sum(fee) as [费用合计] from #tmp group by name, class_id'
	exec(@sql)
	
	drop table #tmp
END
GO
