CREATE proc WebApp_BillDisPatch
 (
   @intuserid  int,
   @billid INT=0,--单据id
   @c_id INT=0,--往来单位
   @e_id INT=0,--经手人
   @y_id INT=0,--所属公司
   @billtype int = 0, --单据类型
   @billnumber VARCHAR(100),--单据编号
   @startdate VARCHAR(10),--开始时间
   @enddate VARCHAR(10),--结束时间
   @billstates int=0,--单据状态 0 过账  2草稿   3审核
   @type INT,--0单据索引过滤  1单据明细
   @params VARCHAR(100), --预留接口
   @RetMessage varchar(200) out
 )
--$encode$--
as
BEGIN
	IF @type=0 
	BEGIN
	
		--IF ISNULL(@startdate,'')=''
		--SET @startdate=Convert(VARCHAR(10),DATEADD(month,-1,GETDATE()),120)
		--IF ISNULL(@enddate,'')=''
		--SET @enddate=Convert(VARCHAR(10),GETDATE(),120)
		IF @billtype IN (22,14,162)--订单
		BEGIN
			SELECT 
			wab.billid AS billid,
			wab.billnumber AS billnumber,
			CONVERT(varchar(10),wab.billdate,120) AS billdate,
			wab.c_id AS c_id,
			c.name AS c_name,
			wab.e_id AS e_id,
			e.name AS e_name,
			wab.quantity AS quantity,
			wab.ysmoney AS total,
			@billstates AS billflag
			FROM vw_c_orderidx wab 
			LEFT JOIN clients c ON c.client_id=wab.c_id
			LEFT JOIN employees e ON e.emp_id=wab.e_id
			WHERE --(ISNULL(@y_id,0)=0 OR wab.y_id=@y_id) AND
                        (ISNULL(@e_id,0)=0 or wab.inputman=@e_id) 
			AND (ISNULL(@c_id,0)=0 or wab.c_id=@c_id) 
			and ((@billstates not in (3) and wab.billstates=@billstates) or wab.billstates in (3))
			AND wab.billtype=@billtype
			AND (ISNULL(@billnumber,'')='' or wab.billnumber=@billnumber) 
			and	(ISNULL(@startdate,'')='' or Convert(VARCHAR(10),wab.billdate,120)>=@startdate)--当前时间
			AND (ISNULL(@enddate,'')='' or Convert(VARCHAR(10),wab.billdate,120)<=@enddate)
				order by wab.billid desc
			--上个月今天 
		END
		ELSE
		BEGIN
			if @billstates in (0,5)  --过账
				SELECT 
				wab.billid AS billid,
				wab.billnumber AS billnumber,
				CONVERT(varchar(10),wab.billdate,120) AS billdate,
				wab.c_id AS c_id,
				c.name AS c_name,
				wab.e_id AS e_id,
				e.name AS e_name,
				wab.quantity AS quantity,
				wab.ysmoney AS total,
				@billstates AS billflag
				FROM vw_x_billidx wab 
				LEFT JOIN clients c ON c.client_id=wab.c_id
				LEFT JOIN employees e ON e.emp_id=wab.e_id
				WHERE --(ISNULL(@y_id,0)=0 OR wab.y_id=@y_id) 
				--AND 
                                (ISNULL(@e_id,0)=0 or wab.e_id=@e_id) 
				AND (ISNULL(@c_id,0)=0 or wab.c_id=@c_id) 
				--and wab.billstates=@billstates
				and wab.billstates in (0,5)
				AND wab.billtype=@billtype
				AND (ISNULL(@billnumber,'')='' or wab.billnumber=@billnumber) 
				and	(ISNULL(@startdate,'')='' or Convert(VARCHAR(10),wab.billdate,120)>=@startdate)--当前时间
				AND (ISNULL(@enddate,'')='' or Convert(VARCHAR(10),wab.billdate,120)<=@enddate)
				order by wab.billid desc
			else  --草稿及审核
				SELECT 
				wab.billid AS billid,
				wab.billnumber AS billnumber,
				CONVERT(varchar(10),wab.billdate,120) AS billdate,
				wab.c_id AS c_id,
				c.name AS c_name,
				wab.e_id AS e_id,
				e.name AS e_name,
				wab.quantity AS quantity,
				wab.ysmoney AS total,
				@billstates AS billflag
				FROM VW_C_BillDraftIDX wab 
				LEFT JOIN clients c ON c.client_id=wab.c_id
				LEFT JOIN employees e ON e.emp_id=wab.e_id
				WHERE --(ISNULL(@y_id,0)=0 OR wab.y_id=@y_id) 
				--AND
                                (ISNULL(@e_id,0)=0 or wab.inputman=@e_id) 
				AND (ISNULL(@c_id,0)=0 or wab.c_id=@c_id) 
				and wab.billstates=@billstates
				AND wab.billtype=@billtype
				AND (ISNULL(@billnumber,'')<>'' or wab.billnumber=@billnumber) 
				and	(ISNULL(@startdate,'')='' or Convert(VARCHAR(10),wab.billdate,120)>=@startdate)--当前时间
				AND (ISNULL(@enddate,'')='' or Convert(VARCHAR(10),wab.billdate,120)<=@enddate)
				order by wab.billid desc
		END                                          --
	END
	ELSE IF @type=1
	BEGIN	   

		DECLARE @s_id INT
		declare @CostMethod int,@UseSameCostMethod int,@AverBatchNoAndlocation int
    	select @CostMethod=s.sysvalue from sysconfig s where s.sysname='CostMethod'
    	select @UseSameCostMethod=s.sysvalue from sysconfig s where s.sysname='UseSameCostMethod'
    	select @AverBatchNoAndlocation=s.sysvalue from sysconfig s where s.sysname='AverBatchNoAndlocation'
		IF @billtype IN (22,14,162)--订单
		BEGIN
			SELECT @s_id= CASE WHEN ISNULL(sout_id,0)=0 THEN sin_id ELSE sout_id end FROM Orderidx WHERE billid=@billid
			SELECT 
			'' as billName,
			0 as BillID,
			'' as billdate,
			'' as billnumber,
			case when @billtype=14 then 10 when @billtype=22 then 20 when @billtype=10 then 11 when @billtype=20 then 21 end as billtype,
			0 as a_id,
			'0' as multia_id,
			'' as multia_name,
			'0' as multia_total,
			wab.c_id  as c_id,
			c.name AS c_name,
			wab.e_id as e_id,
			e.name AS e_name,
			wab.sout_id as sout_id,
			s2.name AS sin_name,
			wab.sin_id as sin_id,
			s.name AS sout_name,
			0 as auditman,
			0 as inputman,
			wab.ysmoney as ysmoney,
			0 as ssmoney,
			wab.quantity as quantity,
			wab.taxrate as taxrate,
			0 as period,--期间
			0 as billstates,
			0 as order_id,
			wab.department_id as dep_id,
			d.name AS dep_name,
			0 as posid,
			0 as jsye,
			'' as jsflag,
			'' as note,
			ISNULL(app.price,'') as price,
			isnull(app.pricename,'') as  pricename,
			'' summary,
			0 as y_id,
			c2.name as y_name,
			0 as flag,
			'' address,
			0 as vIPCardID,
			'' field1,
			'' field2,
			'' field3,
			'' field4,
			'' field5,
			'1900-01-01' startbilldate,
			'1900-01-01' endbilldate,
			'' params,0 AS disprice
			  FROM Orderidx wab
			    left join WebApp_Billidx app on wab.billid = app.drfbillid
				LEFT JOIN clients c ON c.client_id=wab.c_id
				LEFT JOIN employees e ON e.emp_id=wab.e_id
				LEFT JOIN department d ON d.departmentId=wab.department_id
				LEFT JOIN storages s ON s.storage_id=wab.sout_id
				LEFT JOIN storages s2 ON s2.storage_id=wab.sin_id
				LEFT JOIN company c2 ON c2.company_id=0--wab.y_id
			 WHERE wab.billid=@billid

			
			 SELECT	b.bill_id as BillID,'' BillGuid,
					'' RowGuid,'' BillNO,'' BarCode,
					b.p_id as P_ID ,p.serial_number as P_Code,p.name as P_Name,
					b.unitid as UnitID,u.name as UnitName,b.batchno as BatchNo,
				 	b.saleprice as Price
					,b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) AS Quantity,0 as Quantity2,0 as Quantity3,
					b.total as Total,
					0 as ColorID,'' as ColorCode, '' as ColorName,
					0 as SizeID,'' as SizeCode,'' as SizeName,
					'' as Field1,'' as Field2,'' as Field3,'' as Field4,'' as Field5,'' as Field6,
					'' as Field7,'' as Field8,'' as Field9,'' as Field10,
					b.supplier_id,b.costprice,b.costprice*b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) as costtotal
					,b.ss_id as s_id,b.validdate as validate,b.makedate,
					b.location_id,b.commissionflag,p.costmethod as costmethod,
					b.saleprice as defaultprice,b.retailprice,pri.recprice
					,pri.price4 as vipprice,specialprice,lowprice,0 as retaillowprice,
					pri.price1,pri.price2,pri.price3,0 as price4,
					0 as price6,
					case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then p.rate2 
						when b.unitid=p.unit3_id then p.rate3 
						when b.unitid=p.unit4_id then p.rate4 end  as rate,
					'' pricetype,'' as TYPE,'' as comment,b.AOID,p.costmethod,
					isnull(st.storage,0) AS storage,  --库存
			case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
			else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
					@billid AS oldbillid,b.discount,b.discountprice
			  FROM OrderBill b
			  left join unit u on u.unit_id=b.unitid
			  left join products p on p.product_id=b.p_id
			  --left join color c on c.ID=b.colorid
			  --left join size s on s.id=b.sizeid
			  LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) st ON st.p_id=p.product_id
    			left join price pri on pri.price_id=b.price_id and pri.u_id=b.unitid
			 WHERE b.bill_id=@billid and b.p_id>0
		end
		else
		begin
			if @billstates=0  --过账
			BEGIN
			SELECT @s_id=CASE WHEN ISNULL(sout_id,0)=0 THEN sin_id ELSE sout_id end FROM Billidx WHERE billid=@billid
				SELECT'' as billName,
					0 as BillID,
					'' as billdate,
					'' as billnumber,
					case when @billtype=14 then 10 when @billtype=22 then 20 when @billtype=10 then 11 when @billtype=20 then 21 end as billtype,
					0 as a_id,
					'0' as multia_id,
					'' as multia_name,
					'0' as multia_total,
					wab.c_id  as c_id,
					c.name AS c_name,
					wab.e_id as e_id,
					e.name AS e_name,
					wab.sout_id as sout_id,
					s2.name AS sin_name,
					wab.sin_id as sin_id,
					s.name AS sout_name,
					0 as auditman,
					0 as inputman,
					wab.ysmoney as ysmoney,
					0 as ssmoney,
					wab.quantity as quantity,
					wab.taxrate as taxrate,
					0 as period,--期间
					0 as billstates,
					0 as order_id,
					wab.department_id as dep_id,
					d.name AS dep_name,
					0 as posid,
					0 as jsye,
					'' as jsflag,
					'' as note,
					'' price,
					'' pricename,
					'' summary,
					0 as y_id,
					c2.name as y_name,
					0 as flag,
					'' address,
					0 as vIPCardID,
					'' field1,
					'' field2,
					'' field3,
					'' field4,
					'' field5,
					'1900-01-01' startbilldate,
					'1900-01-01' endbilldate,
					'' params,0 AS disprice
					from Billidx wab
					LEFT JOIN clients c ON c.client_id=wab.c_id
					LEFT JOIN employees e ON e.emp_id=wab.e_id
					LEFT JOIN department d ON d.departmentId=wab.department_id
					LEFT JOIN storages s ON s.storage_id=wab.sout_id
				LEFT JOIN storages s2 ON s2.storage_id=wab.sin_id
					LEFT JOIN company c2 ON c2.company_id=0--wab.y_id
				 WHERE wab.billid=@billid
				 if @billtype IN (10,11)--销售类
					 SELECT	
						 b.bill_id as BillID,'' BillGuid,
						'' RowGuid,'' BillNO,'' BarCode,
						b.p_id as P_ID ,p.serial_number as P_Code,p.name as P_Name,
						b.unitid as UnitID,u.name as UnitName,b.batchno as BatchNo,
				 		b.saleprice as Price
						,b.quantity/
						(case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
						when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
						when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
						END) AS Quantity,0 as Quantity2,0 as Quantity3,
						b.total as Total,
						0 as ColorID,'' as ColorCode, '' as ColorName,
						0 as SizeID,'' as SizeCode,'' as SizeName,
						'' as Field1,'' as Field2,'' as Field3,'' as Field4,'' as Field5,'' as Field6,
						'' as Field7,'' as Field8,'' as Field9,'' as Field10,
						b.supplier_id,b.costprice,b.costprice*b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) as costtotal
						,b.ss_id as s_id,b.validdate as validate,b.makedate,
						b.location_id,b.commissionflag,p.costmethod as costmethod,
						b.saleprice as defaultprice,b.retailprice,pri.recprice
						,pri.price4 as vipprice,specialprice,lowprice,0 as retaillowprice,
						pri.price1,pri.price2,pri.price3,0 as price4,
						0 as price6,
						case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then p.rate2 
						when b.unitid=p.unit3_id then p.rate3 
						when b.unitid=p.unit4_id then p.rate4 end  as rate,
						'' pricetype,'' as TYPE,'' as comment,b.AOID,p.costmethod,
					isnull(st.storage,0) AS storage,  --库存
						case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
						else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
					@billid AS oldbillid,b.discount,b.discountprice
					  FROM SalemanageBill b
					  left join unit u on u.unit_id=b.unitid
					  left join products p on p.product_id=b.p_id
					  --left join color c on c.ID=b.colorid
					  --left join size s on s.id=b.sizeid
					 LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) st ON st.p_id=p.product_id
    				 left join price pri on pri.price_id=b.price_id and pri.u_id=b.unitid
					 WHERE b.bill_id=@billid and b.p_id>0
				else
					SELECT	b.bill_id as BillID,'' BillGuid,
						'' RowGuid,'' BillNO,'' BarCode,
						b.p_id as P_ID ,p.serial_number as P_Code,p.name as P_Name,
						b.unitid as UnitID,u.name as UnitName,b.batchno as BatchNo,
				 		b.buyprice as Price
						,b.quantity/
						(case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
						when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
						when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
						END) AS Quantity,0 as Quantity2,0 as Quantity3,
						b.total as Total,
						0 as ColorID,'' as ColorCode, '' as ColorName,
						0 as SizeID,'' as SizeCode,'' as SizeName,
						'' as Field1,'' as Field2,'' as Field3,'' as Field4,'' as Field5,'' as Field6,
						'' as Field7,'' as Field8,'' as Field9,'' as Field10,
						b.supplier_id,b.costprice,b.costprice*b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) as costtotal
						,b.ss_id as s_id,b.validdate as validate,b.makedate,
						b.location_id,b.commissionflag,p.costmethod as costmethod,
						b.buyprice as defaultprice,b.retailprice,pri.recprice
						,pri.price4 as vipprice,specialprice,lowprice,0 retaillowprice,
						pri.price1,pri.price2,pri.price3,0 as price4,
						0 as price6,
						case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then p.rate2 
						when b.unitid=p.unit3_id then p.rate3 
						when b.unitid=p.unit4_id then p.rate4 end  as rate,
						'' pricetype,'' as TYPE,'' as comment,b.AOID,p.costmethod,
					isnull(st.storage,0) AS storage,  --库存
						case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
						else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
					@billid AS oldbillid,b.discount,b.discountprice
					  FROM BuymanageBill  b
					  left join unit u on u.unit_id=b.unitid
					  left join products p on p.product_id=b.p_id
					  --left join color c on c.ID=b.colorid
					  --left join size s on s.id=b.sizeid
					 LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) st ON st.p_id=p.product_id
    				 left join price pri on pri.price_id=b.price_id and pri.u_id=b.unitid
					 WHERE b.bill_id=@billid and b.p_id>0
			end
			else
			BEGIN
				
				SELECT @s_id= CASE WHEN ISNULL(sout_id,0)=0 THEN sin_id ELSE sout_id end FROM billdraftidx WHERE billid=@billid
				SELECT'' as billName,
					0 as BillID,
					'' as billdate,
					'' as billnumber,
					case when @billtype=14 then 10 when @billtype=22 then 20 when @billtype=10 then 11 when @billtype=20 then 21 end as billtype,
					0 as a_id,
					'0' as multia_id,
					'' as multia_name,
					'0' as multia_total,
					wab.c_id  as c_id,
					c.name AS c_name,
					wab.e_id as e_id,
					e.name AS e_name,
					wab.sout_id as sout_id,
					s2.name AS sin_name,
					wab.sin_id as sin_id,
					s.name AS sout_name,
					0 as auditman,
					0 as inputman,
					wab.ysmoney as ysmoney,
					0 as ssmoney,
					wab.quantity as quantity,
					wab.taxrate as taxrate,
					0 as period,--期间
					0 as billstates,
					0 as order_id,
					wab.department_id as dep_id,
					d.name AS dep_name,
					0 as posid,
					0 as jsye,
					'' as jsflag,
					'' as note,
					'' price,
					'' pricename,
					'' summary,
					0 as y_id,
					c2.name as y_name,
					0 as flag,
					'' address,
					0 as vIPCardID,
					'' field1,
					'' field2,
					'' field3,
					'' field4,
					'' field5,
					'1900-01-01' startbilldate,
					'1900-01-01' endbilldate,
					'' params,0 AS disprice
					FROM billdraftidx wab
					LEFT JOIN clients c ON c.client_id=wab.c_id
					LEFT JOIN employees e ON e.emp_id=wab.e_id
					LEFT JOIN department d ON d.departmentId=wab.department_id
					LEFT JOIN storages s ON s.storage_id=wab.sout_id
				LEFT JOIN storages s2 ON s2.storage_id=wab.sin_id
					LEFT JOIN company c2 ON c2.company_id= 0 --wab.y_id
				 WHERE wab.billid=@billid
				 if @billtype IN (10,11)--销售类
					 SELECT	
						 b.bill_id as BillID,'' BillGuid,
						'' RowGuid,'' BillNO,'' BarCode,
						b.p_id as P_ID ,p.serial_number as P_Code,p.name as P_Name,
						b.unitid as UnitID,u.name as UnitName,b.batchno as BatchNo,
				 		b.saleprice as Price
						,b.quantity/
						(case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
						when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
						when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
						END) AS Quantity,0 as Quantity2,0 as Quantity3,
						b.total as Total,
						0 as ColorID,'' as ColorCode, '' as ColorName,
						0 as SizeID,'' as SizeCode,'' as SizeName,
						'' as Field1,'' as Field2,'' as Field3,'' as Field4,'' as Field5,'' as Field6,
						'' as Field7,'' as Field8,'' as Field9,'' as Field10,
						b.supplier_id,b.costprice,b.costprice*b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) as costtotal
						,b.ss_id as s_id,b.validdate as validate,b.makedate,
						b.location_id,b.commissionflag,p.costmethod as costmethod,
						b.saleprice as defaultprice,b.retailprice,pri.recprice
						,pri.price4 as vipprice,specialprice,lowprice,0 as retaillowprice,
						pri.price1,pri.price2,pri.price3,0 as price4,
						0 as price6,
						case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then p.rate2 
						when b.unitid=p.unit3_id then p.rate3 
						when b.unitid=p.unit4_id then p.rate4 end  as rate,
						'' pricetype,'' as TYPE,'' as comment,b.AOID,p.costmethod,
					isnull(st.storage,0) AS storage,  --库存
						case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
						else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
					@billid AS oldbillid,b.discount,b.discountprice
					  FROM SalemanageBilldrf b
					  left join unit u on u.unit_id=b.unitid
					  left join products p on p.product_id=b.p_id
					  --left join color c on c.ID=b.colorid
					  --left join size s on s.id=b.sizeid
					 LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) st ON st.p_id=p.product_id
    				 left join price pri on pri.price_id=b.price_id and pri.u_id=b.unitid
					 WHERE b.bill_id=@billid and b.p_id>0
				else
					SELECT	b.bill_id as BillID,'' BillGuid,
						'' RowGuid,'' BillNO,'' BarCode,
						b.p_id as P_ID ,p.serial_number as P_Code,p.name as P_Name,
						b.unitid as UnitID,u.name as UnitName,b.batchno as BatchNo,
				 		b.buyprice as Price
						,b.quantity/
						(case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
						when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
						when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
						END) AS Quantity,0 as Quantity2,0 as Quantity3,
						b.total as Total,
						0 as ColorID,'' as ColorCode, '' as ColorName,
						0 as SizeID,'' as SizeCode,'' as SizeName,
						'' as Field1,'' as Field2,'' as Field3,'' as Field4,'' as Field5,'' as Field6,
						'' as Field7,'' as Field8,'' as Field9,'' as Field10,
						b.supplier_id,b.costprice,b.costprice*b.quantity/
					(case when b.unitid=p.unit1_id then 1 
					when b.unitid=p.unit2_id then CASE WHEN ISNULL(p.rate2,0)=0 THEN 1 ELSE p.rate2 end
					when b.unitid=p.unit3_id then CASE WHEN ISNULL(p.rate3,0)=0 THEN 1 ELSE p.rate3 end 
					when b.unitid=p.unit4_id then CASE WHEN ISNULL(p.rate4,0)=0 THEN 1 ELSE p.rate4 end 
					END) as costtotal
						,b.ss_id as s_id,b.validdate as validate,b.makedate,
						b.location_id,b.commissionflag,p.costmethod as costmethod,
						b.buyprice as defaultprice,b.retailprice,pri.recprice
						,pri.price4 as vipprice,specialprice,lowprice,0 as retaillowprice,
						pri.price1,pri.price2,pri.price3,0 as price4,
						0 as price6,
						case when b.unitid=p.unit1_id then 1 
						when b.unitid=p.unit2_id then p.rate2 
						when b.unitid=p.unit3_id then p.rate3 
						when b.unitid=p.unit4_id then p.rate4 end  as rate,
						'' pricetype,'' as TYPE,'' as comment,b.AOID,p.costmethod,
						isnull(st.storage,0) AS storage,  --库存
						case when @CostMethod=0 and @UseSameCostMethod=1 and @AverBatchNoAndlocation=1 then 1 
						else CASE when @CostMethod=3 and @UseSameCostMethod=1 then 1 ELSE 0 end  end as showCostmethod,
					@billid AS oldbillid,b.discount,b.discountprice
					  FROM BuymanageBilldrf  b
					  left join unit u on u.unit_id=b.unitid
					  left join products p on p.product_id=b.p_id
					  --left join color c on c.ID=b.colorid
					  --left join size s on s.id=b.sizeid
					  LEFT JOIN (select s.p_id,SUM(s.quantity) AS storage,SUM(s.costprice*s.quantity)/case when SUM(s.quantity)=0 THEN 1 ELSE SUM(s.quantity) end AS costprice FROM Storehouse s WHERE s.s_id=@s_id GROUP BY s.p_id) st ON st.p_id=p.product_id
    					left join price pri on pri.price_id=b.price_id and pri.u_id=b.unitid
					 WHERE b.bill_id=@billid and b.p_id>0
			end
			
		end
		
	END
end
GO
