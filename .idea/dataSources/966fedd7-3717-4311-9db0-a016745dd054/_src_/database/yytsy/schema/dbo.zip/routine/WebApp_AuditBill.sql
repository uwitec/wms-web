/*审核单据*/
CREATE proc WebApp_AuditBill
(
 @billid int = 0,    --单据ID
 @billtype int = 0,  --单据类型
 @auditdate datetime = 0,  --审核时间
 @e_id int =0,       --审核人
 @billstates int = 2 --审核状态 2：取消审核，3：审核
)
as
begin
  if  @billstates = 2 --取消审核
  begin
    select @auditdate = 0,@e_id=0
  end
  if @billtype in (14,22) --销售订单,采购订单
  begin
    update orderidx  set auditman   = @e_id,
                         auditdate  = @auditdate,
                         billstates = @billstates
     where billid = @billid

     if @@error<>0 return -1 else return 0
  end else 
  if @billtype in (10,11,20,21) --销售出库，销售退货，采购入库，采购退货
  begin
    update billdraftidx set auditman   = @e_id,
                            auditdate  = @auditdate,
                            billstates = @billstates
    where billid = @billid
    if @@error<>0 return -1 else return 0  
  end  
end
GO
