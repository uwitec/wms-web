








CREATE PROCEDURE  [Ts_L_InsertUnitTB]
(	@szName varchar(30))
AS
if exists(select * from unit where [Name]=@szName)
begin
	RAISERROR('该商品名已经存在，请重新输入其它名称！',16,1) 
	return 0 
end
Insert Into 
	unit ([Name])
Values
	(@szName)
if @@rowcount=0 
begin
	RAISERROR('数据库写入数据失败!',16,1) 
	return 0 
end else
return @@identity
GO
