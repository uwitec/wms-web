
/*代金券管理  zjl 2013-05-27*/
create   PROCEDURE TS_j_SelCashCoupon
(	
  @szCashNO varchar(30), /*编号*/
  @nVipCardID integer, /*绑定会员*/
  @nTypeID integer,    /*类型ID*/
  @cg_id integer,      /*绑定类别*/
  @begindate datetime,  /*启用日期 */
  @ValidDate datetime,  /*有效期*/
  @CreateDate datetime, /*发行日期*/
  @nFlag integer,       /*状态*/
  @nMode integer,		/*查询模式 0 sel 1 Qr*/
  @nCurMinID    int , 
  @nCurMaxID    int ,
  @nDirection   int ,  /*方向 1 next, -1 up*/
  @nPageSize    int output, /*用于控制序号*/
  @npagecount   int output,
  @nMinID	    int output, 
  @nMaxID       int output
)
AS

declare @SQL varchar(6000)

set @npagecount = 0
set @nMinID = 0
set @nMaxID = 0
set @npagesize = 10000

if @nMode = 0
begin   
   if @szCashNO = '' and @nVipCardID =0 and @cg_id=0
   begin
	  select @nMinID = MIN(VIPCardID),  @nMaxid = max(vipcardid), @npagecount = count(1) 
	    from cashcoupon  where (@nTypeID = 0 or typeid = @nTypeID) and (@nFlag = -1 or flag = @nFlag)
               	    	    	    
	  if  @npagecount % @npagesize > 0
		set @npagecount =  cast(@npagecount/@npagesize as int) + 1
	  else  
		set @npagecount =  cast(@npagecount/@npagesize as int) 
		
	  if @nDirection = -1
	  begin
		if OBJECT_ID('tempdb..#CashcoupoTmp') is not null
		  drop table #CashcoupoTmp
		  	  
		select top 10000 ccid into #CashcoupoTmp
		  from cashcoupon
		  where  ccid < @nCurMinID	 
		  order by ccid desc 
		select @nCurMaxID = MIN(ccid) -1 from #CashcoupoTmp  
          end

          if @nMinID is null set @nMinID = 0
          if @nMaxID is null set @nMaxID = 0
		
       set @SQL = 'select  top '+CAST(@npagesize as varchar)+' cc.*, ct.*, isnull(ie.name, '''')  as inputmanName, isnull(y.name , '''')  as companyname,
		   isnull(v.CardNo, '''') as cardno, isnull(v.Name, '''') as vipname, ISNULL(v.Tel, '''') as vipTel,
		   Case cc.flag when 0 then ''启用'' when 1 then ''删除'' when 2 then ''停用'' 
					    when 4 then ''作废'' when 5 then ''已用'' else '' '' end  as flagName,
		   Case ct.Limitflag when 0 then ''整单限额'' when 1 then ''商品限额'' 
					         when 2 then ''类别限额'' else '' '' end  as LimitflagName,
		   Case ct.multiflag when 0 then ''否'' when 1 then ''是'' end as multiflagName	 		         						    					    
    from Cashcoupon cc
         inner join CashcouponType ct on cc.typeid =ct.typeid         
         left join employees ie on cc.inputMan = ie.emp_id
         left join company y on cc.UseCompany = y.company_id
         left join VIPCard v on cc.vipcardid = v.VIPCardID         
    where ( '+ cast(@nTypeID as varchar) +' = 0 or cc.typeid = '+cast(@nTypeID as varchar)+') and
          ( '+ cast(cast(@begindate as NUMERIC(25,8)) as varchar)  +' < 10 or ct.begindate>= '+ cast(cast(@begindate as NUMERIC(25,8)) as varchar) +') and
          ( ' + cast(cast(@ValidDate as NUMERIC(25,8)) as varchar) + ' < 10 or ct.validDate <= ' + cast(cast(@ValidDate as NUMERIC(25,8)) as varchar) +') and
          ( ' + cast(cast(@CreateDate as NUMERIC(25,8))  as varchar)+ ' < 10 or cc.Createdate >=' + cast(cast(@CreateDate as NUMERIC(25,8)) as varchar)+') and
          ( '+ cast(@nFlag as varchar) + ' = -1 or cc.flag = '+ cast(@nFlag as varchar) +' ) and cc.flag <> 1  and ccid >'+ cast(@nCurMaxID as varchar)
          + '  order by ccid'
	  /*print (@sql)	*/
     EXEC (@SQL)
     		 			
  end 
  else begin
     if @szCashNO <> ''
     set @szCashNO = '%'+@szCashNO+'%'    
       select      cc.*, ct.*, isnull(ie.name, '')  as inputmanName, isnull(y.name , '')  as companyname,
		   isnull(v.CardNo, '') as cardno, isnull(v.Name, '') as vipname, ISNULL(v.Tel, '') as vipTel,
		   Case cc.flag when 0 then '启用' when 1 then '删除' when 2 then '停用' 
					    when 4 then '作废' when 5 then '已用' else ' ' end  as flagName,
		   Case ct.Limitflag when 0 then '整单限额' when 1 then '商品限额' 
					         when 2 then '类别限额' else ' ' end  as LimitflagName,
		   Case ct.multiflag when 0 then '否' when 1 then '是' end as multiflagName	 		         						    					    
    from Cashcoupon cc
         inner join CashcouponType ct on cc.typeid =ct.typeid         
         left join employees ie on cc.inputMan = ie.emp_id
         left join company y on cc.UseCompany = y.company_id
         left join VIPCard v on cc.vipcardid = v.VIPCardID         
    where (@nTypeID = 0 or cc.typeid = @nTypeID) and
          (@szCashNO ='' or  cc.CashNO like @szCashNO) and
          (@begindate < 10 or ct.begindate>= @begindate) and
          (@ValidDate < 10 or ct.validDate <= @ValidDate) and
          (@CreateDate < 10 or cc.Createdate >= @CreateDate) and
          (@nFlag = -1 or cc.flag = @nFlag) and          
          cc.flag <> 1
           
  end
                                         
end else if @nMode = 1
begin
  select cc.*,ct.*, isnull(ie.name, '')  as inputmanName, isnull(y.name , '')  as companyname,
		   isnull(v.CardNo, '') as cardno, isnull(v.Name, '') as vipname,ISNULL(v.Tel, '') as vipTel,
		   Case cc.flag when 0 then '启用' when 1 then '删除' when 2 then '停用' 
					    when 3 then '作废' else  ' ' end as flagName,
		   Case ct.Limitflag when 0 then '整单限额' when 1 then '商品限额' 
					         when 2 then '类别限额' else ' ' end  as LimitflagName,
		   Case ct.multiflag when 0 then '否' when 1 then '是' end as multiflagName			         			    
    from Cashcoupon cc 
         inner join CashcouponType ct on cc.typeid = ct.typeid         
         left join employees ie on cc.inputMan = ie.emp_id
         left join company y on cc.UseCompany = y.company_id
         left join VIPCard v on cc.vipcardid = v.VIPCardID         
    where (cc.CashNO = @szCashNO) and
           flag = 0 and ct.validDate >= floor(CAST(GETDATE() as NUMERIC(25,8)))         
end                                                                                                         
return 0
GO
