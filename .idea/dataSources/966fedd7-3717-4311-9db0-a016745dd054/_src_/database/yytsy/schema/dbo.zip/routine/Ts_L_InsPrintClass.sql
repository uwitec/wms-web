









CREATE	PROCEDURE [Ts_L_InsPrintClass]
	(@pc_code	[varchar](3),
	 @pc_name	[varchar](12))

AS

IF exists (select * from PrintClass where pc_name =@pc_name)
begin
     RAISERROR('该打印类型已经存在，请重新输入其它名称！',16,1) 
     return 0 
end 
INSERT INTO [PrintClass] 
	 ( [pc_code],
	 [pc_name]) 
 
VALUES 
	( @pc_code,
	 @pc_name)
if @@rowcount<>0 
	return @@IDENTITY
else
	return 0
GO
