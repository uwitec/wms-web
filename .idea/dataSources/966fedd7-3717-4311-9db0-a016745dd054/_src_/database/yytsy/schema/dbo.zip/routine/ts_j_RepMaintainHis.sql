
/************************************************************
--功能：商品养护类型修改记录查询  
--创建人：Zhou JiLin 
--创建时间：2010-12-02  
--最后修改:
参数说明：
**************************************************************/
CREATE  PROCEDURE [dbo].[ts_j_RepMaintainHis]
(@begindate datetime,
 @enddate datetime,
 @nP_ID int = 0
)
AS 
if @nP_ID > 0
begin
  set @begindate = 0 
  set @enddate =0
end
   select *, OldMaintainname = Case when pm.OldMaintainType = 0 then '一般养护' else '重点养护' end,
          newMaintainname = Case when pm.newMaintainType = 0 then '一般养护' else '重点养护' end   
     from ProductMaintainHis pm
     inner join vw_Products p on pm.P_ID = p.product_id 
     where (pm.modifydate >= @begindate) and 
           (@enddate < 10  or pm.modifydate  <= @enddate) and 
           (@nP_ID = 0 or pm.P_ID = @nP_ID) and p.deleted = 0 and p.child_number =0
     order by pm.modifydate, pm.PM_ID
GO
