CREATE proc WebApp_InsClients
(
  @name varchar(150)='',              --单位名称
  @contact_personal [varchar](255)='',--联系人
  @phone_number varchar(255)='',    --电话 
  @address varchar(255)='',         --联系地址
  @RecGoodsPerson varchar(50)='',   --收货人
  @RecGoodsTel varchar(50)='',      --收货电话
  @RecGoodsAddress varchar(255)='', --收货地址
  @csflag int = 0,
  @comment varchar(255)='',          --备注
  @RetMessage varchar(200) out
)
as 
begin
  set nocount on
  declare @pyin varchar(100),@bma varchar(50),@maxbma varchar(50)
  select @pyin = dbo.FGetPY(@name),@bma=''
  SET @RetMessage='添加完成'
  
  declare @rowindex int,@OldLen int,@NewLen int
  select @maxbma = isnull(max(serial_number),''),@rowindex=isnull(max(rowindex),0) from clients where parent_id='000000' and deleted<>1 and isnumeric(serial_number)<>0
  select @OldLen = Len(@maxbma)
  select @bma = @maxbma+1 
  select @NewLen= Len(@bma)
  

  exec Ts_L_InsClients @parent_id='000000',
                       @serial_number=@bma,
                       @name= @name,
                       @alias='',
                       @region_id=0,
                       @address=@address,
                       @zipcode='',
                       @contact_personal=@contact_personal,
                       @phone_number=@phone_number,
                       @tax_number='',
                       @acount_number='',
                       @credit_total=0,
                       @pinyin=@pyin,
                       @pricemode=0,
                       @sklimit=0,
		       @artotal=0,                       
		       @artotal_ini=0,
                       @aptotal=0,                       
                       @aptotal_ini=0,
                       @csflag=@csflag,
                       @comment=@comment,
                       @sktype=0,
                       @incRate=0, 
                       @RecGoodsPerson = @RecGoodsPerson,
                       @RecGoodsTel=@RecGoodsTel,
                       @RecGoodsAddress=@RecGoodsAddress,
                       @DsRate=0,
                       @DsPrice=0
   if @@error<>0 
   BEGIN
   	SET @RetMessage='添加失败'
	return -1 
   	end
   else 
   begin
     update clients set rowindex = @rowindex+1 where client_id=@@identity
     return 0
   end
   set nocount off                       
end
GO
