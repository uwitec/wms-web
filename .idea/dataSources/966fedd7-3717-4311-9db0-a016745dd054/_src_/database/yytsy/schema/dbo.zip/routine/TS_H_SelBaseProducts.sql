
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-9-11*/
/* Description:	获取指定的基本资料*/
/* =============================================*/
CREATE PROCEDURE [TS_H_SelBaseProducts] 
	@Yid int = 0, 
	@Mod bigint = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT MAX(product_id), '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0 FROM products
	UNION ALL
	SELECT p.product_id, p.name, p.alias, p.serial_number, p.pinyin, p.[standard], isnull(p.makearea,''), p.Factory, p.PermitCode, p.LatinName,  
	       p.ChemName, ISNULL(dbo.MergeBarcode(p.product_id), '') AS barcode, ISNULL(o.name, '') AS ename, ISNULL(o.pinyin, '') AS epinyin, 
	       IsNull(o2.name, '') as cname, IsNull(o2.pinyin, '') as cpinyin, 0 AS unitid, IsNull(p.protectprice, 0) as protectprice, 
	       ISNULL(p.isCheckReport, 0) as isCheckReport, ISNULL(g.doubleCheck, 0) AS Isspec, ISNULL(p.LTTime, 0) isCheckLT, 
	       CAST(p.basicMedication AS int) AS elecCode, p.deleted, CAST(p.ModifyDate AS bigint) AS ModifyDate  /*, p.permitcode,  	      */
	FROM         dbo.products AS p LEFT OUTER JOIN
							  (SELECT     c.p_id, e.name, e.pinyin
								FROM          dbo.productbalance AS c INNER JOIN
													   dbo.employees AS e ON c.Emp_id = e.emp_id
								WHERE      (c.Y_id = @Yid)) AS o ON p.product_id = o.p_id
								LEFT JOIN gspPropert g on g.gspid = p.gspFlag
								 LEFT OUTER JOIN
								 (SELECT     c.p_id, e.name, e.pinyin
								FROM          dbo.productbalance AS c INNER JOIN
													   dbo.clients AS e ON c.Supplier_id = e.client_id
								WHERE      (c.Y_id = @Yid)) AS o2 ON p.product_id = o2.p_id
	WHERE     (p.child_number = 0) AND (p.ModifyDate > @Mod)
END
GO
