


/*-------拆零处理  return -1 表示商品不可拆零*/
CREATE procedure TS_L_ProductSplit
(
  @p_id int,
  @batchno varchar(100),
  @costprice  NUMERIC(25,8),
  @RetailPrice NUMERIC(25,8),
  @RetailTotal NUMERIC(25,8),
  @supplier_id INT,
  @location_id  INT,
  @commissionflag  TINYINT,
  @InStoreTime datetime,
  @makedate  datetime,
  @validdate  datetime,
  @Unit_id int,
  @e_id int,
  @s_id int,
  @y_id int
)
as
begin
/*---------处理有效期*/
	declare @Outvaliddate varchar(20)
    set @Outvaliddate = substring(convert(varchar, @validdate,121),1,10);

  /*-----判断商品是否可以拆零*/
  if not exists(select 1 from products,productsExtend where products.deleted = 0 and product_id = @p_id and p_id = product_id and productsExtend.sfcl = 1)
  begin
    RAISERROR('所选商品不可拆零！', 16, 1)
    return -1
  end
  /*-----原商品库存不足无法拆零*/
  if not exists(select 1 from storehouse where p_id = @p_id and batchno = @batchno and costprice = @costprice
                and supplier_id = @supplier_id and location_id = @location_id and commissionflag = @commissionflag
                and instoretime = @InStoreTime and makedate = @makedate and substring(convert(varchar, validdate,121),1,10) = @Outvaliddate and s_id = @s_id 
                and Y_ID = @y_id and quantity > 0) 
  begin
    RAISERROR('原商品库存不足无法拆零！', 16, 1)              
    return -2
  end               
           
  /*-----------判断商品拆零后的商品是否有库存                 */
  declare @SplitP_id int /*-零货商品id*/
  declare @Splitrate NUMERIC(25,8) /*拆零换算比率*/
  declare @SplitPrice NUMERIC(25,8) /*拆零价格*/
  declare @SplitUnit int   /*拆零单位*/
  declare @SplitCostPrice NUMERIC(25,8) /*-拆零成本价*/
  declare @SplitTotal NUMERIC(25,8)  /*拆零金额合计*/
  
  select @SplitP_id = product_id from products where Custompro1 in (select class_id from products where product_id = @p_id) and IsSplit = 1
  select @Splitrate = pe.hsbl,@SplitPrice = cljg,@SplitUnit = cldw from productsExtend pe where p_id = @p_id
  select @SplitCostPrice = @Costprice/@Splitrate
  select @SplitTotal = @SplitPrice*@Splitrate
  
  /*if not exists(select 1 from storehouse where p_id = @SplitP_id) ---不存在库存则使用组装单进行拆零操作*/
  begin
	DECLARE @Ret int					/* 返回值*/
	DECLARE @VchCode int				/* 单据 ID*/
	DECLARE @Today varchar(10)			/* 当前日期*/
	/*DECLARE @RetailPrice NUMERIC(25,8) --零售价 */
	/*DECLARE @RetailTotal NUMERIC(25,8) --零售金额*/
	DECLARE @SendBillSN varchar(100)
	DECLARE @GUDI VARCHAR(100)
	  
	/*select @VchCode = MAX(billid)+1 from billdraftidx*/
	set @VchCode = 0
	select @Today = left(CONVERT(varchar,GETDATE(),121),10)
	select @GUDI = NEWID()
	exec TS_H_CreateBillSN 40, 1, null, @e_id, @e_id, @SendBillSN output
	/*-------------------生成草稿主表*/
	
	
	exec ts_b_insertbillindexdraft @VchCode output, @VchCode, 2, 0, @Today, @SendBillSN, 40, 0, 0,
			@e_id, @s_id, @s_id, @e_id, @e_id, @costprice, 0, @Splitrate, 0, 0, '3', 0, 0, @y_id, 0, 0, 0, 0, ' ',
			'【由零售单拆零生成】', '', 0, '', 0, 0, 0, 0, 0, 0, default, default, default, default,
			default, @y_id			
	
	/*-------------------生成草稿明细*/
	
	/*---------处理有效期*/
	declare @MXvaliddate datetime
	if @validdate <> '1900-01-01 00:00:00.000'
	begin
	  if exists(select * from products where validmonth <> 0) 
	    set @MXvaliddate = dateADD(SECOND,1,@validdate)
	  else
	    set @MXvaliddate = @validdate  
	end  
	else  
	  set @MXvaliddate = @validdate
	  
	/*----出库商品*/
	exec Ts_b_InsertBillDetailDraft;1 @Ret output,2,1,@VchCode,0,@p_id,@batchno,1,@costprice,@costprice,1,0,0,@costprice,0,0,0,@RetailPrice,@RetailTotal,
	@makedate,@MXvaliddate,'合格',0,@s_id,0,0,@location_id,@supplier_id,@commissionflag,'',@Unit_id,0,0,0,0,0,0,default,0,1,@costprice,0,@e_id,@GUDI,
	'0','0',@y_id,@InStoreTime,0,'','',0,'','00000000-0000-0000-0000-000000000000',''		
	/*----入库商品*/
	exec Ts_b_InsertBillDetailDraft;1 @Ret output,2,1,@VchCode,0,@SplitP_id,@batchno,@Splitrate,@SplitCostPrice,@SplitCostPrice,@costprice,0,0,@costprice,0,0,0,@SplitPrice,@SplitTotal,
	@makedate,@MXvaliddate,'合格',0,0,@s_id,0,@location_id,@supplier_id,@commissionflag,'',@SplitUnit,0,0,1,0,0,0,default,0,1,@costprice,0,@e_id,@GUDI,
	'0','0',@y_id,@InStoreTime,0,'','',0,'','00000000-0000-0000-0000-000000000000',''
	
	/*----过账草稿单据*/
	declare @nPid int
	declare @nRetNum int
	set @nRetNum = 0
    exec ts_c_BillAudit @VchCode, @nPid output, @nRetNum output, 40
	if @nRetNum <> 0
	begin
	 RAISERROR('拆零组装单过账失败！', 16, 1)
	 /*----过账失败删除草稿*/
	 delete billdraftidx where billid = @VchCode
	 delete storemanagebilldrf where bill_id = @VchCode 
	  return -6
	end    
  end
  return @SplitP_id       
    
end
GO
