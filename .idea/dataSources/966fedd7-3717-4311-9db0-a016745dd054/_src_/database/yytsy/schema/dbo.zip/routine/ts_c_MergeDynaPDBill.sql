

create proc ts_c_MergeDynaPDBill
(
	@nInputMan 	int,
	@nPdPlanIdx int,
	@nDelDraft	int=1
)
/*with encryption*/
as
/*Params Ini begin*/
if @nDelDraft is null  SET @nDelDraft = 1
/*Params Ini end*/
set nocount on 
declare @nNewBillId int,@szMergeMan varchar(20),@szSName varchar(20),@tBilldate varchar(10),@szNote varchar(300)
declare @dYkTotal numeric(25,8)
declare @cUseSameCostMethod char(1),@nCostMethod char(1),@pdconvert int
declare @nS_id 		int
declare @Y_ID		int
declare @nNoBatch	int
declare @planGuid varchar(50)

/**/
	declare @dDoubleZero numeric(25,8)
	set @dDoubleZero=0.001
/*2005-06-28 zc modify 解决小数位数带来的误差。*/
  declare @bWmsPD int 
  select @bWmsPD = isnull(CAST(sysvalue as int), 0) from sysconfigtmp where [sysname]= 'jointechwmspd'
  if @bWmsPD is null set @bWmsPD = 0



select @Y_ID=Y_ID from billdraftidx where billtype=58 and order_id=@npdplanidx

select @szMergeMan=name from employees where emp_id=@nInputMan
select @ns_id=k_id, @nNoBatch = nobatch, @planGuid = CAST(Guid as varchar(50)) from pdplanidx where pdidx=@nPdPlanIdx
select @szSName=[name] from storages where storage_id=@nS_id
select @tBillDate=convert(varchar(10),GetDate(),20)

if @bWmsPD = 1 
  select @szNote='【WMS导入盘点单】  '+'日期： '+@tBillDate+'   合并人：'+@szMergeMan
else
  select @szNote='【合并盘点单】  '+'日期： '+@tBillDate+'   合并人：'+@szMergeMan

if @bWmsPD = 0
begin
	if not exists (select * from billdraftidx where billtype=58 and order_id=@npdplanidx)
	begin
	  raiserror('该盘点计划还没有录入动态盘点单！',16,1)
	  return 0
	end
	if exists (select * from billdraftidx where billtype=58 and order_id=@npdplanidx and billstates='2')
	begin
	  raiserror('该盘点计划存在没有审核的动态盘点单，请进入盘点查看进行审核！',16,1)
	  return 0
	end

	set @pdconvert=-1


		exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
		if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
			exec ts_getsysvalue 'CostMethod',@nCostMethod out


		if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[goodtemp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
		drop table [dbo].[goodtemp]

	begin tran mergepdbill

	/*合并选中的盘点单草稿*/

		if @cUseSameCostMethod='1' 
		begin
			if @nCostMethod in ('0','1','2') 
			begin
				select p_id,ss_id,aoid,max(batchno) as batchno,costprice=case sum(quantity) when 0 then 0 else sum(total)/sum(quantity) end ,max(location_id) as location_id,max(supplier_id) as supplier_id,
				max(commissionflag) as commissionflag,max(discountprice) discountprice,max(discount) as discount,max(taxprice) as taxprice,
				max(makedate) as makedate,max(validdate) as validdate,max(instoretime) as instoretime, max(sd_id) as sd_id,MAX(unitid) as unitid,buyprice=case sum(quantity) when 0 then 0 else sum(total)/sum(quantity) end,max(retailprice) as retailprice,
				0 as taxrate,0 as order_id,0 as totalmoney,sum(quantity) as quantity,sum(total) as total,y_id, bybatch
				into goodtemp
				from goodscheckbilldrf where bill_id in (select b.billid from billdraftidx b where  b.order_id=@nPdplanIdx and b.billstates='3' and b.billtype=58) 
				group by p_id,ss_id,aoid,y_ID, bybatch
				if @@error<>0 goto error
			end else 
		if @nCostMethod in ('3','4')
			begin
				select p_id,ss_id,aoid,batchno,costprice,location_id,supplier_id,commissionflag,max(discountprice) discountprice,max(discount) as discount,max(taxprice) as taxprice,
				makedate as makedate,validdate as validdate,instoretime,max(sd_id) as sd_id,MAX(unitid) as unitid,max(buyprice) as buyprice,max(retailprice) as retailprice,
				0 as taxrate,0 as order_id,0 as totalmoney,sum(quantity) as quantity,sum(total) as total,y_id, bybatch,costtaxprice, costtaxrate, sum(costtaxtotal) as costtaxtotal, factoryid
				into goodtemp
				from goodscheckbilldrf where bill_id in (select b.billid from billdraftidx b where  b.order_id=@nPdplanIdx and b.billstates='3' and b.billtype=58) 
				group by p_id,ss_id,aoid,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,instoretime,y_id, bybatch,costtaxprice, costtaxrate,  factoryid
				if @@error<>0 goto error
			end
		end else
		begin
			select * into goodtemp 
			from (
				select g.p_id,g.ss_id,g.aoid,g.batchno,g.costprice,g.location_id,g.supplier_id,g.commissionflag,max(g.discountprice) discountprice,max(g.discount) as discount,max(g.taxprice) as taxprice,
				g.makedate as makedate,g.validdate as validdate,g.instoretime as instoretime, max(g.sd_id) as sd_id,MAX(unitid) as unitid,max(g.buyprice) as buyprice,max(g.retailprice) as retailprice,
				0 as taxrate,0 as order_id,0 as totalmoney,sum(g.quantity) as quantity,sum(g.total) as total,g.y_id, g.bybatch,costtaxprice, costtaxrate, sum(costtaxtotal) as costtaxtotal, factoryid
				from goodscheckbilldrf g,products p where g.bill_id in (select b.billid from billdraftidx b where  b.order_id=@nPdplanIdx and b.billstates='3' and b.billtype=58) 
				and g.p_id=p.product_id and p.costmethod in ('3','4') and p.deleted<>1
				group by g.p_id,g.ss_id,g.aoid,g.batchno,g.costprice,g.location_id,g.supplier_id,g.commissionflag,g.makedate,g.validdate,g.instoretime,g.Y_ID, g.bybatch,costtaxprice, costtaxrate,  factoryid
				union 
				select g.p_id,g.ss_id,g.aoid,max(g.batchno) batchno,max(g.costprice) costprice,max(g.location_id) location_id,
				max(g.supplier_id) supplier_id,max(g.commissionflag) commissionflag,max(g.discountprice) discountprice,
				max(g.discount) as discount,max(g.taxprice) as taxprice,
				max(g.makedate) as makedate,max(g.validdate) as validdate, max(g.instoretime) as  instoretime, max(g.sd_id) as sd_id,MAX(unitid) as unitid,max(g.buyprice) as buyprice,max(g.retailprice) as retailprice,
				0 as taxrate,0 as order_id,0 as totalmoney,sum(g.quantity) as quantity,sum(g.total) as total,g.Y_ID, g.bybatch,costtaxprice, costtaxrate, sum(costtaxtotal) as costtaxtotal, factoryid
				from goodscheckbilldrf g,products p where g.bill_id in (select b.billid from billdraftidx b where  b.order_id=@nPdplanIdx and b.billstates='3' and b.billtype=58) 
				and g.p_id=p.product_id and p.costmethod in ('0','1','2') and p.deleted<>1
				group by g.p_id,g.ss_id,g.aoid,g.Y_ID, g.bybatch,costtaxprice, costtaxrate,  factoryid
				 ) b

			if @@error<>0 goto error
		end

	/*生成表头文件*/

		insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,order_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
		values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'3',@npdplanidx,@Y_ID, @planGuid,0,'1900-01-01')
		if @@error<>0 goto error

		select @nNewBillId=@@identity
		
		insert goodscheckbilldrf (bill_id,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
		discount,taxprice,makedate,validdate,instoretime,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,aoid,y_id, 
		bybatch,costtaxprice, costtaxrate, costtaxtotal, factoryid)
		select @nNewBillId,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
		discount,taxprice,makedate,validdate,instoretime,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,aoid,y_id, 
		bybatch,costtaxprice, costtaxrate, costtaxtotal, factoryid
		from goodtemp
		if @@error<>0 goto error

	  /*调整大单位报溢的成本价格*/
	  update goodscheckbilldrf set costprice=cast(total/quantity as numeric(25,8)) where taxprice=0 and quantity>0 and bill_id=@nNewBillId

	  /*调整计量单位为基本单位*/
		update goodscheckbilldrf set unitid=b.u_id,buyprice=total/quantity,retailprice=b.retailprice from goodscheckbilldrf gc,price b
		where gc.p_id=b.p_id and b.unittype=1 and gc.bill_id=@nNewBillId and gc.quantity<>0 
		if @@error<>0 goto error
		
		update goodscheckbilldrf set totalmoney=quantity-taxprice,taxtotal=(quantity-taxprice)*costprice,taxmoney=quantity-taxprice,
		total=quantity*costprice,retailtotal=retailprice*(quantity-taxprice)
		where bill_id=@nNewBillId
		if @@error<>0 goto error
		
		set @dYkTotal=0
		select @dYkTotal=isnull(abs(sum(taxtotal)),0) from goodscheckbilldrf	
		where bill_id=@nNewBillId and taxtotal>0
		
		update billdraftidx set ysmoney=@dYkTotal,ssmoney=@dYkTotal,billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
		where billid=@nNewBillId 
		if @@error<>0 goto error

		update billdraftidx set note='已经合并到盘点单  '+'【PD'+right(cast(100000000+@nNewBillId as varchar),8)+'】  ' 
	  where billid in (select b.billid from billdraftidx b where  b.order_id=@nPdplanIdx and b.billstates='3' and b.billtype=58)
		if @@error<>0 goto error
	  
	  set @pdconvert=@nNewBillId



	/*生成未盘点商品表*/

		select @szNote='【未盘点商品】  '+'日期： '+@tBillDate+'   合并人：'+@szMergeMan

	/*	select * into #storehouse from storehouse where s_id=@ns_id*/
	  select * into #storehouse from pdplan where pdidx=@npdplanidx
	/*删除已经盘点商品*/
		if @cUseSameCostMethod='1' 
		begin
			if @nCostMethod in ('0','1','2') or @nNoBatch = 1
			begin
				delete from #storehouse from #storehouse s,goodtemp g 
				where s.p_id=g.p_id and g.aoid in (0,7)
			end else
			begin
				delete from #storehouse from #storehouse s,goodtemp g 
				where s.p_id=g.p_id and abs(s.costprice-g.costprice)<=@dDoubleZero and s.batchno=g.batchno and s.location_id=g.location_id and s.supplier_id=g.supplier_id and s.makedate=g.makedate and s.validdate=g.validdate and
					  g.aoid in (0,7) and s.instoretime = g.instoretime
			end
		end else
		begin
			delete from #storehouse from #storehouse s,goodtemp g ,products p
			where s.p_id=g.p_id and s.p_id=p.product_id and (s.costprice-g.costprice)<=@dDoubleZero and s.batchno=g.batchno and s.location_id=g.location_id and s.supplier_id=g.supplier_id and s.makedate=g.makedate and 
				  s.validdate=g.validdate and s.instoretime = g.instoretime
			and p.costmethod in ('3','4') and g.aoid in (0,7)

			delete from #storehouse from #storehouse s,goodtemp g ,products p
			where s.p_id=g.p_id and s.p_id=p.product_id and (p.costmethod in ('0','1','2') or g.bybatch = 0) and g.aoid in (0,7)
		end


		if exists(select * from #storehouse)
		begin
			select 0 as smb_id,0 as bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.costprice as price,0 as discount,b.quantity as discountprice,0 as totalmoney, b.costtotal as total,
			  b.quantity as taxprice,0 as taxtotal,0 as taxmoney,0 as retailprice,0 as retailtotal,b.makedate,b.validdate,b.instoretime,' ' as qualitystatus, b.pdplan_id as order_id,
			  0 as price_id, b.s_id, b.s_id as s_id2, b.location_id as l_id , b.supplier_id as b_id, b.commissionflag, ' ' as comment, 0 as unitid,0 as taxrate,b.location_id as l_id2, 0 as iotag,
			  p.code,p.name,p.standard,p.modal,p.makearea, p.permitcode, p.trademark,p.medtype,
			  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validday, p.costmethod,
			  p.unit1_id, p.unit2_id, p.unit3_id, p.unit4_id, p.otcflag,p.alias,
			  0 as invoicetotal,
			  0 as comedate,
			  0 as comeqty,
			  ' ' as sn,
			  ' ' as vendor,
			  b.costtaxprice, b.costtaxrate, b.costtaxtotal, b.factoryid
			into #storehoustemp from #storehouse b,vw_b_products p ,vw_b_storage  s 
			where b.stopsaleflag = 0 and b.p_id=p.p_id and b.s_id=s.s_id 
			
			
		/*生成表头文件*/
		
			insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,Y_ID, summary,ZBAuditMan,ZBAuditDate)
			values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'2',0, @planGuid,0,'1900-01-01')
			if @@error<>0 goto error
		
			select @nNewBillId=@@identity
			
			insert goodscheckbilldrf (bill_id,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,
			discount,taxprice,makedate,validdate,instoretime,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,buyprice,retailprice,total,
			aoid,costtaxprice, costtaxrate, costtaxtotal, factoryid)
			select @nNewBillId,p_id,batchno,costprice,l_id,b_id,commissionflag,discountprice,
			discount,taxprice,makedate,validdate,instoretime,s_id,s_id2,unitid,taxrate,order_id,totalmoney,quantity,price,retailprice,total,0,
			costtaxprice, costtaxrate, costtaxtotal, factoryid
			from #storehoustemp
			if @@rowcount=0 goto error
		/*	
			update goodscheckbilldrf set totalmoney=quantity-taxprice,taxtotal=(quantity-taxprice)*costprice,taxmoney=quantity-taxprice,
			total=quantity*costprice,retailtotal=retailprice*(quantity-taxprice)
			where bill_id=@nNewBillId
			if @@error<>0 goto error
			
			set @dYkTotal=0
			select @dYkTotal=isnull(abs(sum(taxtotal)),0) from goodscheckbilldrf	
			where bill_id=@nNewBillId and taxtotal<0
		*/	
			update billdraftidx set billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
			where billid=@nNewBillId 
			if @@error<>0 goto error
		
			update goodscheckbilldrf set unitid=b.u_id,buyprice=gc.total/gc.quantity from goodscheckbilldrf gc,price b
			where gc.p_id=b.p_id and b.unittype=1 and gc.bill_id=@nNewBillId and gc.quantity<>0
			if @@error<>0 goto error
		end


		if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[goodtemp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
		drop table [dbo].[goodtemp]
	  
	  update pdplanidx set billstates='0' where pdidx=@npdplanidx
	commit tran mergepdbill
	
	return @pdconvert

end  else

/*根据WMS接口返回的数据生成盘点单*/
begin
 
  /*计算pdplan表*/
   /*exec ts_wms_UpdatePdPlan @nPdPlanIdx*/
    
  /*生成盘点单*/
   begin tran mergepdbill
     insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,order_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
		values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'3',@npdplanidx,@Y_ID, @planGuid,0,'1900-01-01')
		if @@error<>0 goto error
		select @nNewBillId=@@identity
   /*写入明细*/
     insert goodscheckbilldrf (bill_id,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,buyprice,
		discount,taxprice,makedate,validdate,instoretime,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,retailprice,total,aoid,y_id, bybatch)
		select @nNewBillId,pd.p_id,pd.batchno,pd.costprice,pd.location_id,pd.supplier_id,pd.commissionflag,pd.spQuantity,pd.costprice,
		0,pd.spQuantity,pd.makedate,pd.validdate,pd.instoretime,pd.s_id,pd.s_id, p.unit1_id,0,0,pd.quantity - pd.spQuantity, pd.quantity, 0, pd.costtotal,0,pd.Y_ID, 0
		from PdPlan pd
		inner join products p on pd.p_id = p.product_id 
		where pdidx = @nPdPlanIdx and PDFlag = 1
		if @@rowcount=0 goto error
		
		update billdraftidx set billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
			where billid=@nNewBillId 
			if @@error<>0 goto error
   
   /*默认未被盘点的商品将被盘为0*/
   /*生成未盘点商品表，需要重点确认的品种*/
        set @nNewBillId = 0 
        if exists(select 1 from pdplan where PDFlag = 0 and pdidx = @nPdPlanIdx)
        begin
		    select @szNote='【WMS未盘点商品】  '+'需要重点确认是否漏盘 '+'日期： '+@tBillDate
		    insert billdraftidx (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,note,billstates,order_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
				values(@tBillDate,'',50,0,0,@nInputMan,@nS_id,@nS_id,@nInputMan,@nInputMan,@szNote,'2',@npdplanidx,@Y_ID, @planGuid,0,'1900-01-01')
				if @@error<>0 goto error
				select @nNewBillId=@@identity
		   /*写入明细*/
			 insert goodscheckbilldrf (bill_id,p_id,batchno,costprice,location_id,supplier_id,commissionflag,discountprice,buyprice,
				discount,taxprice,makedate,validdate,instoretime,ss_id,sd_id,unitid,taxrate,order_id,totalmoney,quantity,retailprice,total,aoid,y_id, bybatch)
				select @nNewBillId,pd.p_id,pd.batchno,pd.costprice,pd.location_id,pd.supplier_id,pd.commissionflag,pd.spQuantity,pd.costprice,
				0,pd.spQuantity,pd.makedate,pd.validdate,pd.instoretime,pd.s_id,pd.s_id, p.unit1_id,0,0,pd.quantity - pd.spQuantity, pd.quantity, 0, pd.costtotal,0,pd.Y_ID, 0
				from PdPlan pd
				inner join products p on pd.p_id = p.product_id 
				where pdidx = @nPdPlanIdx and PDFlag = 1
				if @@rowcount=0 goto error
				
				update billdraftidx set billnumber='PD'+right(cast(100000000+@nNewBillId as varchar),8)
					where billid=@nNewBillId 
					if @@error<>0 goto error
        
        end                                  
   commit tran mergepdbill
   return @pdconvert
end

	error:
	rollback tran mergepdbill
	return -1
GO
