
-- exec TS_D_pdaComm 50
CREATE PROCEDURE TS_D_pdaComm
(
  @Data_Type INT --1商品资料 2职员 3仓库 4库区 5区域 6库位 7往来单位 8货位跟踪
                 --31收货 33上架 35复核 40物流配送 45动态初单 46动态复盘  50调拨单 55盘点单 
)
AS 
  SET NOCOUNT ON 
  DECLARE @Maxbillid INT,@billid INT
  SET @Maxbillid=0
  INSERT INTO pda_timestamp
	(Kind,billid)
  SELECT a.TYPE,0 
  FROM dbo.DecodeStr('1,2,3,4,5,6,7,8,31,33,35,40,45,46,50,55') a LEFT JOIN pda_timestamp b 
	 ON a.type=b.Kind 
  WHERE b.Kind IS NULL  
  SELECT @Maxbillid=ISNULL(billid,0) FROM pda_timestamp WHERE Kind=@Data_Type
     
  CREATE TABLE #pdacomm(billid INT)
  INSERT INTO #pdacomm
  SELECT a.billid
  FROM orderidx a LEFT JOIN pda_RecBill b 
       ON a.billid=b.billid
  WHERE @Data_Type=31 AND a.billid>@Maxbillid AND a.billtype=22 
        AND a.billstates=3 AND b.billid IS NULL
  UNION ALL 
  SELECT a.Gspbillid
  FROM GSPbillidx a LEFT JOIN pda_PutOnBill b 
       ON a.Gspbillid=b.billid
  WHERE @Data_Type=33 AND a.Gspbillid>@Maxbillid AND a.billtype=531 AND a.Ybilltype=22
        AND a.billstates=10 AND b.billid IS NULL
  UNION ALL 
  SELECT a.Gspbillid
  FROM GSPbillidx a LEFT JOIN pda_CheckBill b 
       ON a.Gspbillid=b.billid
  WHERE @Data_Type=35 AND a.Gspbillid>@Maxbillid AND a.billtype=551 
        AND a.billstates=10 AND b.billid IS NULL
  UNION ALL 
  SELECT a.pdidx
  FROM pdplanidx a LEFT JOIN pda_pdBill b 
       ON a.pdidx=b.billid
  WHERE @Data_Type=45 AND a.pdidx>@Maxbillid AND a.UsePDA=1 
        AND EXISTS(SELECT 1 FROM PdPlan WHERE PdPlan_id=a.pdidx AND pdastates=0)
        AND a.billstates=3 AND b.billid IS NULL
  UNION ALL 
  SELECT a.pdidx
  FROM pdplanidx a LEFT JOIN pda_pdBill b 
       ON a.pdidx=b.billid
  WHERE @Data_Type=46 AND a.pdidx>@Maxbillid AND a.UsePDA=1 
        AND EXISTS(SELECT 1 FROM PdPlan WHERE PdPlan_id=a.pdidx AND pdastates=2)
        AND a.billstates=3 AND b.billid IS NULL
  UNION ALL 
  SELECT a.billid
  FROM billdraftidx a LEFT JOIN pda_TranBill b 
       ON a.billid=b.billid
  WHERE @Data_Type=50 AND a.billid>@Maxbillid AND a.billtype=44 
        AND a.billstates=2 AND b.billid IS NULL
          
  DECLARE Cur_ReadData CURSOR FOR 
  SELECT billid FROM #pdacomm 
  OPEN Cur_ReadData  
  FETCH NEXT FROM Cur_ReadData INTO @billid 
  WHILE @@FETCH_STATUS=0 
	BEGIN
      EXEC TS_D_pdaData @Data_Type,0,@billid
	  FETCH NEXT FROM Cur_ReadData INTO @billid 
	END
  CLOSE Cur_ReadData
  DEALLOCATE Cur_ReadData 
  
  SELECT @Maxbillid=MAX(billid) FROM #pdacomm
  
  UPDATE pda_timestamp SET billid=@Maxbillid WHERE Kind=@Data_Type AND @Maxbillid>0

GO
