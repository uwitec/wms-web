/************************************************************

--功能：委托书查询   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_RepWtorder
	(
      @C_ID int = 0,
      @P_id int = 0,
      @E_id int = 0,
      @begindate datetime =0,
      @endDate datetime =0,
      @type int = 0,  /*-委托书类型 0 为供货商法人委托书,1 为购货单位采购委托书*/
      @EName varchar(30), /*按业务代表姓名进行查找　zjl140107  */
      @FilterStop int = 0 /*默认为不过滤掉停用的供货商*/
     )
AS 
/*Params Ini begin*/
declare @zsql varchar(2000) 
if @C_ID is null  SET @C_ID = 0
if @P_id is null  SET @P_id = 0
if @E_id is null  SET @E_id = 0
if @begindate is null  SET @begindate = 0
if @endDate is null  SET @endDate = 0
if @EName is null  set @EName = ''
  if @EName =  '' 
    set @EName = '%%' 
  else set @EName = '%'+@EName+'%'
  
/*Params Ini end*/

  if @type = 1 
  begin
    set @zsql ='
	  select c.*, w.saleename as wtename, 
	    CASE w.StopUse
        WHEN 0 THEN '+''''+'正常'+'''' 
        +' WHEN 1 THEN '+''''+'停用'+''''
        +' ELSE '+''''+''''
        +' END AS UseState, 
	    W.*
		from wtorder w
		inner join Clients c on w.c_id = c.client_id
		where (' + cast(@C_ID as varchar)+' = 0 or W.c_id = '+cast(@C_ID as varchar)+') and
			  ('+cast(@P_id as varchar)+' = 0 or w.WT_ID in (select wt_id from wtdetail where p_id = '+cast(@P_id as varchar) +') or w.p_id = -1) and
			  [type] = 1 and
			   w.validdate between '+''''+convert(varchar(10),@begindate,20)+''''+' and '+''''+convert(varchar(10),@endDate,20)+''''+' and
			   w.saleEName like '+''''+@EName+'''' 
	  if @FilterStop = 1  /*过滤停用的*/
	    set @zsql = @zsql + ' and stopuse = 0'  
	  exec(@zsql)
	  /*print(@zsql)*/
			  			   
  end
  else
  begin
      set @zsql = 
      'select c.*, w.saleename as wtename, 
	    CASE w.StopUse'
        +' WHEN 0 THEN '+''''+'正常'+'''' 
        +' WHEN 1 THEN '+''''+'停用'+''''
        +' ELSE '+''''+''''
        +' END AS UseState, 
        W.*
		from wtorder w
		inner join Clients c on w.c_id = c.client_id
		where (' + cast(@C_ID as varchar)+' = 0 or W.c_id = '+cast(@C_ID as varchar)+') and
			  ('+cast(@P_id as varchar)+' = 0 or w.WT_ID in (select wt_id from wtdetail where p_id = '+cast(@P_id as varchar) +') or w.p_id = -1) and
			  [type] = 0 and
			   w.validdate between '+''''+convert(varchar(10),@begindate,20)+''''+' and '+''''+convert(varchar(10),@endDate,20)+''''+' and 
			   W.saleEName like '+''''+@EName+''''  
	  if @FilterStop = 1  /*过滤停用的*/
	    set @zsql = @zsql + ' and stopuse = 0'  
	  exec(@zsql)
	   /*print(@zsql)*/
  end
GO
