CREATE VIEW vw_T_GLProducts
AS
SELECT      Gp.*,otcbz=case Gp.otcflag
	        when 0 then '否'  when 1 then '是' end ,isnull(r.RangeName,'')rName,isnull(g.gspPropert,'')gspPropert
	        ,(case Gp.OTCType when 0 then '甲类'when 1 then '乙类'when 2 then '[无]' else '' end)OTCName
	        ,(case Gp.firstCheck when 0 then '否'  when 1 then '是'end)szFirst
	        ,(case Gp.gmp when 0 then '否'  when 1 then '是'end)szGmp ,       
            Gp.glp_id as product_id,isnull(Gp.attendeffect,'') as Comment,isnull(u.name,'') as Unit1Name,isnull(m.medtype,'')MedName
FROM GLProducts Gp
left join Unit u on Gp.unitid=u.unit_id
left   join VW_MedType m on gp.glp_id = m.product_id
left   join VW_Range r on gp.glp_id = r.product_id
left join gspPropert g on Gp.gspflag=g.GSPID  
where Gp.deleted=0
GO
