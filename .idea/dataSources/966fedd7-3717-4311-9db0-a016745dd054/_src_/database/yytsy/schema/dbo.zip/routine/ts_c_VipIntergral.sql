
CREATE  procedure ts_c_VipIntergral
(
	@nBillId int,
	@nbilltype int,
	@nCalcFlag int = 0,  /*1 通过服务器计算积分，不再写入日志*/
	@nUpFlag int = 0 /*--是否是上传单据，避免计算积分时重复扣减储值金额  1 :是, 0 : 不是	 */
)
/*with encryption*/
as
/*Params Ini begin*/
if @nCalcFlag is null  SET @nCalcFlag = 0
/*Params Ini end*/
set nocount on

/*declare @nbillID numeric(10,0)*/

declare @isbank int,@isIntergral int,@Vipcardid int,@iscxIntegral int
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
declare @saleIntegralYE NUMERIC(25,8)
declare @money NUMERIC(25,8)
declare @ctid int
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8)
declare @saleIntegral NUMERIC(25,8),@salemoney NUMERIC(25,8)
declare @RemainderMoney NUMERIC(25,8)
declare @INTEGRALMONEY NUMERIC(25,8)
declare @Intergral NUMERIC(25,8)
declare @isSpecialPriceIntegral int,@isPromotionIntegral int,@isYeIntegral int, @PriceType int,@Cxtype int
declare @StoreMoney_ID int
declare @nY_id int, @isZBZT int, @billguid varchar(50) 
declare @Canintegral int /*判断是否计算积分*/
select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/

/*初始化,避免出现null*/
set @nowIntergral=0
set @modIntergral=0 
set @nowmoney=0 
set @modmoney=0 
set @comment=''
set @IntegralYE = 0 
set @OrverIntegral =0 
set @OrverYE = 0 
set @saleIntegralYE =0 
set @money =0
set @Canintegral = 0

      /*如果不是总部账套不实时处理余额积分，门店的余额在总部上传数据时统一处理       */
      if exists(select 1 from sysconfig  where [sysname] = 'YClassid' and [sysvalue] = '000001' and Y_ID = 0)
        set @isZBZT = 1
      else 
        set @isZBZT = 0     

if @nbilltype in (10,11,12,13,210,211,243)
begin
      select @ctid=v.ct_id,@money=v.RemainderMoney,@salemoney=b.ssmoney,@Vipcardid=v.Vipcardid,@isbank=v.isbank,
             @isSpecialPriceIntegral=isSpecialPriceIntegral,@isPromotionIntegral=isPromotionIntegral,@isYeIntegral=ISYEINTEGRAL,
             /*特殊商品参与积分                              特殊商品累计未兑换积分金额                积分余额累计*/
             @iscxIntegral=V.IsCxIntegral,@IntegralYE=v.IntergralYE ,@Canintegral = auditman,  /*-零售类单据使用auditman存储是否计算积分的字段*/
             @order=b.billnumber,@isIntergral=V.isIntegral,@Intergral=v.Integral,@nY_id=b.Y_id,
             @billguid = [GUID], @IntegralYE= v.IntergralYE
             from billidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid
       
       if @nbilltype not in (12,13)  /*--只有零售类单据才判断*/
       set @Canintegral = 0      
       select @INTEGRALMONEY=dbo.GetIntegralMoney(@ctid, GETDATE())                

      select @RemainderMoney=abs(isnull(sum(total),0)) from salemanageBill where bill_id=@nBillId and p_id=-@StoreMoney_ID 

      if @isIntergral=1 and @Vipcardid>0
      begin 
        select   @saleIntegral=0 ,   @saleIntegralYE=0

        declare saleIntegral cursor 
        for select vs.PClass_ID,sum(vs.taxtotal)totalmoney,vs.PriceType,vs.cxtype 
        from vw_c_salemb vs,products b 
        where vs.p_id=b.product_id and  vs.bill_id=@nBillId and vs.p_id>0  and b.ifIntegral=1
        Group by vs.Pclass_id,vs.PriceType,vs.cxtype
        
        open saleIntegral
        fetch next from saleIntegral into @Pclassid,@totalmoney,@PriceType,@cxtype
        while @@fetch_status=0
        begin
           if (@PriceType=7 and  @isSpecialPriceIntegral=0)
           begin
              SELECT  @SALEINTEGRAL=ISNULL(@SALEINTEGRAL,0)+0 
              SELECT  @SALEINTEGRALYE=ISNULL(@SALEINTEGRALYE,0)+0
           end           
           else
           if (@Cxtype<>0 and @iscxIntegral=0)
           begin
              SELECT  @SALEINTEGRAL=ISNULL(@SALEINTEGRAL,0)+0 
              SELECT  @SALEINTEGRALYE=ISNULL(@SALEINTEGRALYE,0)+0           
           end
           else
           begin
               exec TS_L_CTIntegralANDDiscountOther @ctid,0,@Pclassid,@CTIntegral out
           
               if @CTintegral<=0
               begin
				 select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@INTEGRALMONEY) as int) 
				 select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@INTEGRALMONEY as int)*@INTEGRALMONEY)
               end
               else
               begin	
				 select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@CTintegral) as int) 
	          
                 if @isPromotionIntegral=1
                    select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@CTintegral as int)*@CTintegral)
                 else
                    select  @saleIntegralYE=isnull(@saleIntegralYE,0)+0
               end
           end
           fetch next from saleIntegral into @Pclassid,@totalmoney,@PriceType,@cxtype
        end
        close saleIntegral
        DEALLOCATE  saleIntegral
        
        if @isYeIntegral=1 
        begin
          select @saleIntegral=@saleIntegral+cast((@saleIntegralYE/@INTEGRALMONEY) as int)
          select @saleIntegralYE=@saleIntegralYE-cast((@saleIntegralYE/@INTEGRALMONEY) as int)*@INTEGRALMONEY
        end else
        begin
          select @saleIntegralYE=0
        end 
     end
end



if @nbilltype in (10,12,210,243) and @Vipcardid>0
begin
    if @isIntergral=1 and (@Canintegral = 0)
    begin
      
        if @isZBZT=1
        begin
          select @IntegralYE=@IntegralYE+@saleIntegralYE
          select @modIntergral=@saleIntegral+cast((@IntegralYE/@INTEGRALMONEY) as int)
          select @IntegralYE=@IntegralYE-cast((@IntegralYE/@INTEGRALMONEY) as int)*@INTEGRALMONEY
          select @nowIntergral=@Intergral+@modIntergral
          update Vipcard set Integral=Integral+@modIntergral,IntergralYE=@IntegralYE where VipCardid=@Vipcardid
        end
        else
        begin
          select @modIntergral=@saleIntegral 
          select @nowIntergral=@Intergral+@saleIntegral
          update Vipcard set Integral=Integral+@saleIntegral,IntergralYE=IntergralYE+@saleIntegralYE where VipCardid=@Vipcardid
        end
       
         update billidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where billid = @nBillId 
         if @nbilltype in (12, 13)
         begin
           update retailbillidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
           update billdraftidx set integral=@saleIntegral,integralYE=@saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
         end
    end
    else
    begin  
      select @nowIntergral=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modIntergral=0
    end

    if (@isbank=1) 
    begin
      if @nUpFlag = 0 /*上传单据不扣减储值金额 add by luowei 2012-10-25*/
      begin
        update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid
        select @nowmoney=@money-@RemainderMoney,@modmoney=-@RemainderMoney
      end
      else
      begin
        select  @nowmoney = @money,@modmoney = -@RemainderMoney
      end  
    end
    else
    begin
      select @nowmoney=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modmoney=0
    end  

    if (@isbank=1) or (@isIntergral=1)
      update Vipcard set TotalBuyMoney=isnull(TotalBuyMoney,0)+@salemoney,BuyCount=isnull(BuyCount,0)+1 where Vipcardid=@Vipcardid  
    select @ntag=15
    select @comment='零售单：【'+@order+'】'

    exec ts_SetSysValue 'VIPIntegral',@modIntergral,@nY_id/*在sys中记录本次消费积分，在打印小票的时候取出。*/
end

if @nbilltype in (11,13,211) and @Vipcardid>0
begin
	if (@isIntergral=1) and (@Canintegral = 0)
	begin
	  /*if @isYeIntegral=0 or @isZBZT =0
	  begin
	    update  Vipcard set Integral=Integral-@saleIntegral where VipCardid=@Vipcardid
	    if @isYeIntegral=1
	    begin
	      update billidx set integral = -@saleIntegral, integralYE = -@saleIntegralYE where billid = @nBillId
	      if @nbilltype in (12, 13)
            update retailbillidx set integral = -@saleIntegral, integralYE = -@saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid  
	   end 
	   else begin
	      update billidx set integral = -@saleIntegral where billid = @nBillId 
	      if @nbilltype in (12, 13)
            update retailbillidx set integral = -@saleIntegral where VIPCardID = @Vipcardid and [GUID] = @billguid  
	   end   
	  end      
      else      
          update  Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
        
          select @nowIntergral=@Intergral-@saleIntegral,@modIntergral=@saleIntegral

          select @IntegralYE=IntergralYE from Vipcard where Vipcardid=@Vipcardid       

          if @IntegralYE<0
          begin
            select @OrverYE=@IntegralYE

            while @IntegralYE<0 
            begin
              select @IntegralYE=@IntegralYE+@INTEGRALMONEY
              select @OrverIntegral=isnull(@OrverIntegral,0)+1
            end

            update Vipcard set Integral=Integral-@OrverIntegral,IntergralYE=@OrverYE+@INTEGRALMONEY*@OrverIntegral where Vipcardid=@Vipcardid
            select @nowIntergral=@nowIntergral-@OrverIntegral,@modIntergral=@modIntergral+@OrverIntegral
          end
          select @modIntergral=-@modIntergral
          if @isZBZT = 1
          begin
            update billidx set Integral = -@modIntergral where billid =@nBillId
            if @nbilltype in (12, 13)
              update retailbillidx set integral = -@modIntergral where VIPCardID = @Vipcardid and [GUID] = @billguid  
         end*/ 
      select @modIntergral=-@saleIntegral 
      select @nowIntergral=@Intergral-@saleIntegral
      update Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
                    
      update billidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where billid = @nBillId
      if @nbilltype in (12, 13)
      begin
        update retailbillidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where VIPCardID = @Vipcardid and [GUID] = @billguid  
        update billdraftidx set integral=-@saleIntegral,integralYE=-@saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
       end 
    end
	else 
	begin
	  select @nowIntergral=0/* from Vipcard where Vipcardid=@Vipcardid*/
	  select @modIntergral=0
	end
	
	if (@isbank=1)   
	begin
	  if @nUpFlag = 0 /*零售退货上传单据不增加储值金额 add by luowei 2012-10-25*/
	  begin
	    update Vipcard set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid
	    select @nowmoney=@money+@RemainderMoney,@modmoney=@RemainderMoney
	  end
	  else
	  begin
	    select @nowmoney=@money,@modmoney = @RemainderMoney
	  end
	end
	else
	begin
	  select @nowmoney=0 /*from vipcard where vipcardid=@Vipcardid*/
	  select @modmoney=0
	end
	
	if (@isbank=1) or (@isIntergral=1) 
	  update Vipcard set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1  where Vipcardid=@Vipcardid
	
        select @ntag=16 
	select @comment='零售退货单：【'+@order+'】'

end

if  @Vipcardid>0 and @nCalcFlag = 0
  exec TS_L_InsVIPCardLog @ntag,'','',@Vipcardid,@nowIntergral,@modIntergral,@nowmoney,@modmoney,0,@comment 



SET QUOTED_IDENTIFIER ON
GO
