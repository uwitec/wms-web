

CREATE procedure TS_D_InsDRBillidxTemp
@OperatorNo	INT,
@BATCHNO	varchar(30),
@SendSerialNo	varchar(50),
@DR10Num	varchar(100),
@EmpNum	varchar(20),
@DRRecZYNo	varchar(50),
@InvoiceNo	varchar(50),
@Billtype	INT,
@SettleFlag	varchar(10),
@TCAreaNo	varchar(10),
@BillTotal	NUMERIC(18,4),
@CashMoney	numeric(18,4),
@YBMoney	numeric(18,4),
@TCMoney	numeric(18,4),
@DRZYNo	VARCHAR(50)
AS

  IF NOT EXISTS(SELECT 1 FROM DRBillidxtemp WHERE OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO AND SendSerialNo=@SendSerialNo AND DR10Num=@DR10Num)
  BEGIN
	INSERT INTO DRBillidxtemp
	 (OperatorNo,BATCHNO,SendSerialNo,DR10Num,EmpNum,DRRecZYNo,
	 InvoiceNo,Billtype,SettleFlag,TCAreaNo,BillTotal,CashMoney,
	 YBMoney,TCMoney,DRZYNo,billdate)
	SELECT @OperatorNo,@BATCHNO,@SendSerialNo,@DR10Num,@EmpNum,@DRRecZYNo,
		   @InvoiceNo,@Billtype,@SettleFlag,@TCAreaNo,@BillTotal,@CashMoney,
		   @YBMoney,@TCMoney,@DRZYNo,GETDATE()
  END
GO
