/*---拣货单发货货位 查询 出仓库ID*/
CREATE VIEW vw_locfindsid
AS
  select distinct b.s_id from billidx a,location b 
  where a.billtype=10 and  a.VIPCardID=b.loc_id
GO
