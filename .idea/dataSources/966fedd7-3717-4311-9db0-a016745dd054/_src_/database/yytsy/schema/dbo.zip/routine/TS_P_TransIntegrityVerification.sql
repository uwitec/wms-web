
/* =============================================*/
/* Author:		Yypeng*/
/* Create date: 2017-08-14*/
/* Description:	传输完整性验证，保证门店传上来的数据一定与总部一致*/
/* Note:暂时先做 零售、零售退货，自营店入库单，积分兑换单；其他单据类型，尤其是会生成下一步GSP的单据类型暂时不做检查*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_P_TransIntegrityVerification]
(@BillYID int)
AS
BEGIN

    /*------------------------------------------------------完整性验证开始-----------------------------------------------------------------*/
/*本期日期，调整不能影响到本期之前的账务*/
declare @perioddate datetime
select @perioddate =  MAX(BeginDate) from MonthSettleinfo where MonthName = '本期' and Y_ID = 2
    
/*当前日期与前7天的完整性验证*/
DECLARE @begindate DATETIME,@enddate DATETIME
SET @enddate = GETDATE()    
SET @begindate = GETDATE() - 7
if  @begindate < @perioddate
set @begindate = @perioddate
    
    
    
   
     create table #noSaledetail(billid int,Billguid uniqueidentifier,Yguid uniqueidentifier,billtype int) 
     create table #noBuydetail (billid int,Billguid uniqueidentifier,Yguid uniqueidentifier,billtype int) 
     create table #noStoredetail (billid int,Billguid uniqueidentifier,Yguid uniqueidentifier,billtype int) 
     create table #noOtherdetail (billid int,Billguid uniqueidentifier,Yguid uniqueidentifier,billtype int) 
     
     
    
     
   
    insert into #noSaledetail
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join productdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype  in (12,13)
    and isnull(t2.billid,0) = 0  /*没有库存明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join salemanagebill t2 on t1.billid = t2.bill_id where t1.y_id = @BillYID and billtype in (12,13)
    and isnull(t2.bill_id,0) = 0 /*没有销售明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join accountdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype  in (12,13)
    and isnull(t2.billid,0) = 0  /*没有科目明细的ID集合*/
    and t1.billdate between @begindate and @enddate
  
    if exists(select 1 from #noSaledetail) 
    begin
		delete from billidx where billid in (select billid  from #noSaledetail)
		delete from productdetail  where billid in (select billid  from #noSaledetail)
		delete from salemanagebill  where bill_id in (select billid  from #noSaledetail)
		delete from accountdetail  where billid in (select billid  from #noSaledetail)
		/*delete t1 from BillLog t1 inner join #noSaledetail t2 on t1.Bill_ID = t2.billid and t1.BillType = t2.billtype and t1.BillGuid = t2.Billguid where y_id = @BillYID    */
    end


    /*------------------------------------------------先检查店间调拨单--------------------------------------------------------------------	*/
	/*Wusj.2017-08-25-通过店间调拨单匹配是否生成自营店发货单*/
	/*先删除上次同步异常数据*/
	delete from DownBillLog where billtype in (157,163) and y_id = @BillYID and UpOrDown = 1
	
	insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown) 
	select i.GUID,i.YGuid,i.billtype,@BillYID,1
	from billdraftidx i left join billidx b on i.GUID = b.YGuid  and b.billtype = 152 
	where i.billtype = 157  and i.Y_ID = @BillYID and i.billdate between @begindate and @enddate 
	and isnull(b.billid,0) = 0
	
	insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown) 
	select b.GUID,b.YGuid,b.billtype,@BillYID,1 from billidx b inner join DownBillLog d on b.YGuid = d.BillGuid and d.BillType = 157
	and b.billtype = 163 and b.Y_ID = @BillYID   
		
    if exists(select 1 from DownBillLog where billtype = 157 and y_id = @BillYID)/*如果存在*/
	begin
	/*删除与店间调拨单相关的流程单据，包括157，153，163，517，524，531   */
	select t2.traceGuid into #traceguid from DownBillLog t1 inner join billTrace t2 on t1.BillGuid = t2.billGuid and t1.BillType = t2.billType and t1.y_id = @BillYID 
	where t1.BillType = 157
		
	select t1.billId  into #billdrfid from billTrace t1 inner join #traceguid t2 on t1.traceGuid = t2.traceGuid where t1.billType =157	
	select t1.billId  into #billid from billTrace t1 inner join #traceguid t2 on t1.traceGuid = t2.traceGuid where t1.billType in (153,163)
	select t1.billid into #gspbillid from billTrace t1 inner join #traceguid t2 on t1.traceGuid = t2.traceGuid where t1.billType in (517,524,531)
		
		delete from billidx where billid in (select billid  from #billid)
		delete from productdetail  where billid in (select billid  from #billid)
		delete from Buymanagebill  where bill_id in (select billid  from #billid)
		delete from accountdetail  where billid in (select billid  from #billid)
		
		delete from billdraftidx  where billid in (select billid  from #billdrfid)	
		delete from gspbillidx where gspbillid in (select billid  from #gspbillid)
		delete from billTrace where traceGuid in (select traceGuid  from #traceguid)
	end	
       
   
    insert into #noBuydetail
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join productdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype  in (162,163)
    and isnull(t2.billid,0) = 0  /*没有库存明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join buymanagebill  t2 on t1.billid = t2.bill_id where t1.y_id = @BillYID and billtype  in (162,163)
    and isnull(t2.bill_id,0) = 0 /*没有采购明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join accountdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype  in (162,163)
    and isnull(t2.billid,0) = 0  /*没有科目明细的ID集合*/
    and t1.billdate between @begindate and @enddate
  
    if exists(select 1 from #noBuydetail) 
    begin
         /*删除163生成的GSP流程单据517*/
        delete from GSPbillidx where Ybillid in (select billid from #noBuydetail where billtype = 163) and billtype = 517    
		delete from billidx where billid in (select billid  from #noBuydetail)
		delete from productdetail  where billid in (select billid  from #noBuydetail)
		delete from Buymanagebill  where bill_id in (select billid  from #noBuydetail)
		delete from accountdetail  where billid in (select billid  from #noBuydetail)
		/*delete t1 from BillLog t1 inner join #noBuydetail t2 on t1.Bill_ID = t2.billid and t1.BillType = t2.billtype and t1.BillGuid = t2.Billguid where y_id = @BillYID    */
    end		
    
    
    insert into #noStoredetail
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join productdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype  in (39)
    and isnull(t2.billid,0) = 0  /*没有库存明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join Storemanagebill  t2 on t1.billid = t2.bill_id where t1.y_id = @BillYID and billtype in (39)
    and isnull(t2.bill_id,0) = 0 /*没有仓库明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    /*union all */
    /*select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join accountdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype in  (39)*/
    /*and isnull(t2.billid,0) = 0  --没有科目明细的ID集合*/
    /*and t1.billdate between @begindate and @enddate*/
  
    if exists(select 1 from #noStoredetail) 
    begin
		delete from billidx where billid in (select billid  from #noStoredetail)
		delete from productdetail  where billid in (select billid  from #noStoredetail)
		delete from Storemanagebill  where bill_id in (select billid  from #noStoredetail)
		/*delete from accountdetail  where billid in (select billid  from #noStoredetail)*/
		/*delete t1 from BillLog t1 inner join #noStoredetail t2 on t1.Bill_ID = t2.billid and t1.BillType = t2.billtype and t1.BillGuid = t2.Billguid where y_id = @BillYID    */
    end	
    
    
    
    insert into #noOtherdetail
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join productdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype = 149
    and isnull(t2.billid,0) = 0  /*没有库存明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join ExIntegRalManagebill t2 on t1.billid = t2.billid where t1.y_id = @BillYID and billtype = 149
    and isnull(t2.billid,0) = 0 /*没有积分明细的ID集合*/
    and t1.billdate between @begindate and @enddate
    union all 
    select t1.billid,t1.GUID,t1.YGuid,t1.billtype from billidx  t1 left join accountdetail  t2 on t1.billid = t2.billid where t1.y_id  = @BillYID and billtype = 149
    and isnull(t2.billid,0) = 0  /*没有科目明细的ID集合*/
    and t1.billdate between @begindate and @enddate
  
    if exists(select 1 from #noOtherdetail) 
    begin
		delete from billidx where billid in (select billid  from #noOtherdetail)
		delete from productdetail  where billid in (select billid  from #noOtherdetail)
		delete from ExIntegRalManagebill  where billid in (select billid  from #noOtherdetail)
		delete from accountdetail  where billid in (select billid  from #noOtherdetail)
		/*delete t1 from BillLog t1 inner join #noOtherdetail t2 on t1.Bill_ID = t2.billid and t1.BillType = t2.billtype and t1.BillGuid = t2.Billguid where y_id = @BillYID    */
    end
    
    
    
    /*把异常单据传回到门店，重写传输标志*/
    insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown)
    
    select a.BillGuid,a.Yguid,a.billtype,@BillYID,1 from
    (
	select BillGuid,YGuid,BillType from #noSaledetail 
	union all
	select BillGuid,YGuid,BillType from #noBuydetail
	union all
	select BillGuid,YGuid,BillType from #noStoredetail
	union all
	select BillGuid,YGuid,BillType from #noOtherdetail
	)a left join DownBillLog b on a.Billguid = b.BillGuid and a.billtype = b.BillType and a.Yguid = b.YGuid 
	where isnull(b.BillType,0) = 0 

	
	delete t1 from DownBillLog t1 inner join billidx t2 on t1.BillGuid = t2.GUID and t1.billtype = t2.billtype and t1.y_id = t2.Y_ID and t1.y_id = @BillYID and t2.billdate between @begindate and @enddate
	
	
	
		
				
    /*------------------------------------------------------完整性验证结束-----------------------------------------------------------------*/

	
END
GO
