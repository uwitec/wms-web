
CREATE	    VIEW dbo.VW_Range
AS
	SELECT   p.product_id, c.name AS RangeName,c.id
	FROM      dbo.products AS p INNER JOIN
					dbo.ProductCategory AS cm ON p.product_id = cm.P_id INNER JOIN
					dbo.customCategory  AS c ON cm.PComent1 = c.class_id
	WHERE  (c.deleted = 0)
		AND c.Child_Number = 0 and  baseType=-1 and Category_id=1
GO
