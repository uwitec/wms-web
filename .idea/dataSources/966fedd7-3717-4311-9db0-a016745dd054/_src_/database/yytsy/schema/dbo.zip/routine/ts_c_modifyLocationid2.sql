




/*-----------------------
-门店收货修改货位
-----------------------*/

CREATE    procedure ts_c_modifyLocationid2
(
	@nBillId numeric(10,0),
	@np_id   int,
	@ns_id   int,
	@nloc_id int,
	@nsmb_id int,
	@ncommissionflag int,
	@dcostprice NUMERIC(25,8),
	@ny_id int,
	@nNewLoc_id int,
	@szbatchno varchar(100),
	@makedate  varchar(100),
	@validdate varchar(100)
)

as

set nocount on
declare @tmakedate datetime,@tvaliddate datetime,@nbilltype int,@nReturnNumber int,@tTrace datetime,@npubyid int
if @makedate='' set @tmakedate=0 else set @tmakedate=@makedate
if @validdate='' set @tvaliddate=0 else set @tvaliddate=@validdate
set @tTrace=GETDATE()

select @nbilltype=billtype from billidx where billid=@nBillId

begin tran modifyloc
/*修改单据loc*/
  update salemanagebill set location_id2=@nNewLoc_id where bill_id=@nBillId and smb_id=@nsmb_id
  if @@ROWCOUNT=0 goto error  
/*修改明细loc*/
  update productdetail set location_id=@nNewLoc_id where billid=@nBillId and smb_id=-@nsmb_id and Y_ID=@ny_id
  if @@ROWCOUNT=0 goto error  
/*修改storehouse*/
  update storehouse set location_id=@nNewLoc_id 
  where p_id=@np_id and s_id=@ns_id and commissionflag=@ncommissionflag and batchno=@szbatchno
  and location_id=@nloc_id and (makedate=@tmakedate or makedate<10) and (validdate=@tvaliddate or validdate<10)  and costprice=@dcostprice
  and Y_ID=@ny_id

  if @@ROWCOUNT=0 goto error  
  
  exec @nReturnNumber=ts_c_LocationTrace  @nP_id ,@nS_id ,@nNewLoc_id ,@tTrace, @nbilltype, @nY_ID 
 
commit tran modifyloc
return 0

error:

rollback tran modifyloc
return -1
GO
