/************************************************************

--功能：计算会员卡积分  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [TS_j_CalcIntergral]
	(
	  @VipCardID int
     )
AS 


declare @nNewBillId int, @nBilltype int, @nIntergalYE NUMERIC(25,8), @nOpType int/*单据积分余额*/
declare @intergal int /*积分        */
declare @dicount NUMERIC(25,8), @totalmoney NUMERIC(25,8)/*会员卡所有商品折扣*/
declare @ArApTotal NUMERIC(25,8)  /*标识是否已计算过积分*/
declare @billguid varchar(50), @nRet int


begin tran calc

declare CalcIntergral cursor for
	  select billid, billtype, Optype  from billunitetmp where vipcardid = @VipCardID and vipflag = 1
	  open CalcIntergral
	  fetch next from CalcIntergral into @nNewBillId, @nBilltype, @nOpType
	  while @@FETCH_STATUS=0	
	  begin 
	    select @ArApTotal=ArApTotal,@billguid=guid,@intergal = order_id,@vipCardID =vipcardid,@totalmoney =ssmoney ,@nIntergalYE =invoicetotal from billidx where billid=@nNewBillId
        select @dicount=ct.Discount from VIPCardType ct,Vipcard V where V.ct_id=ct.ct_id and v.VIPCardID= @vipcardid
		if @nBilltype in(12,13) and  @vipCardID <> 0 
		begin
		  if exists(select top 1 * from salemanagebill s, CTIntegralOther ct, VIPCard V,billidx b where b.billid=s.bill_id and s.p_id=ct.p_id and v.ct_id=ct.ct_id and b.VIPCardID=v.vipcardid and billid=@nNewBillId)
		  begin
		   if @nOpType <> 0
		     execute ts_c_Redword @nNewBillId, @nRet, 1
		   else        
			 execute ts_c_VipIntergral @nNewBillId,@nBilltype, 1
			
		   if @@error<>0 goto error	
		  end else
		  begin
		    if @nOpType <> 0
		      execute ts_c_Redword @nNewBillId, @nRet, 1
		    else   
			  exec  ts_c_TheAllVipIntergral  @nNewBillId, @nBilltype, 1
			if @@error<>0 goto error	
		  end
          
		  /*update billidx set ArApTotal=2 where billid=@nNewBillId*/
    
		 update billunitetmp set vipflag = 2 where billid = @nNewBillId and vipcardid = @VipCardID and vipflag = 1 /* and OpType = 0*/
			 
 		  if @@error<>0 goto error	  
		end
	    fetch next from CalcIntergral into @nNewBillId, @nBilltype, @nOpType
	  end	
	  close CalcIntergral
   deallocate CalcIntergral

commit tran calc

return 0

Error:
  rollback tran calc
  return 0
GO
