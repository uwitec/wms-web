
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-6*/
/* Description:	写入商品授权信息*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_PRightIns]
	@Act		int,	/*操作：0 写入职员授权；1 删除职员授权；2 写入区域客户授权；3 删除区域客户授权*/
	@CLASS_ID	varchar(30),
	@EID		int,	/*职员ID/客户ID*/
	@RID		int		/*区域ID*/
AS
BEGIN
	SET NOCOUNT ON;

	if @Act = 0
	begin
		update productempright set emp_id = @eid where p_id in (select product_id from products where class_id like @CLASS_ID + '%') and R_ID = @RID
		insert into productempright 
		select product_id as p_id, @EID as Emp_id, @RID as R_ID from products where class_id like @CLASS_ID + '%' and product_id not in(select p_id from productempright where R_ID = @RID)
	end
	else
	if @Act = 1
	begin
		delete from productempright where p_id in(select product_id from products where class_id like @CLASS_ID + '%') and R_ID = @RID
	end
	else
	if @Act = 2
	begin
		update ProductCustomRight set c_id = @EID
		WHERE     (p_id IN
								  (SELECT     product_id
									FROM          dbo.products
									WHERE      (class_id LIKE @CLASS_ID + '%'))) AND (c_id IN
								  (SELECT     client_id
									FROM          dbo.clients
									WHERE      (region_id =
															   (SELECT     region_id
																 FROM          dbo.clients AS clients_1
																 WHERE      (client_id = @EID)))))
		insert into ProductCustomRight
		select product_id as p_id, @EID as c_id from products where class_id like @CLASS_ID + '%' and product_id not in
		(SELECT     p_id
		FROM         dbo.ProductCustomRight
		WHERE     (p_id IN
								  (SELECT     product_id
									FROM          dbo.products
									WHERE      (class_id LIKE @CLASS_ID + '%'))) AND (c_id IN
								  (SELECT     client_id
									FROM          dbo.clients
									WHERE      (region_id =
															   (SELECT     region_id
																 FROM          dbo.clients AS clients_1
																 WHERE      (client_id = @EID))))))
	end
	else
	if @Act = 3
	begin
		delete from ProductCustomRight
		WHERE     (p_id IN
								  (SELECT     product_id
									FROM          dbo.products
									WHERE      (class_id LIKE @CLASS_ID + '%'))) AND (c_id IN
								  (SELECT     client_id
									FROM          dbo.clients
									WHERE      (region_id = @RID)))
	end
END
GO
