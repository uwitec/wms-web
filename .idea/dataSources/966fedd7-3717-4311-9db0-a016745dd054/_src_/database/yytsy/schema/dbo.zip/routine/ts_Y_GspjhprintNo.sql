
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2014-02-27*/
/* Description:	GSP复核生成装箱单打印开始页      */
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_Y_GspjhprintNo]
(
  @zguid varchar(50)
)
AS
BEGIN
CREATE TABLE #t1
 (	
    Atype  varchar(10),
	totalQty     INT,
    WholeQty     INT,
    PartQty      INT,
    billid       INT,
    bguid        uniqueidentifier,
    startNum     int,
    xh           Int IDENTITY(1,1) NOT NULL
  )
  declare  @vguid uniqueidentifier
  set @vguid=cast(@zguid as uniqueidentifier)
  
  /*-删除以前生成过的数据*/
  delete GspJhInfo where BillGuid=@vguid
  /*-插入数据*/
  insert into  GspJhInfo(jhBillId,BillGuid,totalQty,wholeQty,partQty)
  select Gspbillid,GUID,WholeQty+PartQty,WholeQty,PartQty from  GSPbillidx 
  where billtype=551 and GUID=@vguid
  /*-提取数据*/
  insert into #t1(Atype,totalQty,WholeQty,PartQty,billid,bguid,startNum)
  select distinct 'A',WholeQty+PartQty,WholeQty,PartQty,jhBillId,@vguid,0 
  from GspJhInfo  where BillGuid=@vguid
  order by jhBillId 
  /*修改总计*/
  update #t1 set totalQty=d.totalQty
  from #t1 c,(select bguid,sum(totalQty) as totalQty from #t1 group by bguid) d
  where c.bguid=d.bguid /*and c.billid=d.billid  */
  /*-修改每张拣货单打印开始页数    */
  declare @iFor  int 
  declare @col   int
  declare curAlter scroll cursor for
  select xh from #t1
  open curAlter
  set @iFor = 0
  while @iFor < @@cursor_rows
  begin
    fetch next from curAlter into @col
    if  @iFor=0   
    begin
      /*第一行*/
      update #t1 set startNum=1 where xh=@col
    end
    else
    begin
     update #t1 set startNum=(b.WholeQty+b.PartQty+1) 
     from #t1 a,(select WholeQty,PartQty,xh from #t1 where xh=(@col-1)) b
     where a.xh=(b.xh+1)     
    end
    set @iFor = @iFor + 1 
  end
  DEALLOCATE curAlter

  /*-修改数据  */
  update GspJhInfo set totalqty=b.totalQty,startNum=b.startNum,endNum=(b.startNum+b.WholeQty+b.PartQty-1)
  from GspJhInfo a,#t1 b
  where a.jhBillId=b.billid   

  drop table  #t1
END
GO
