
create procedure TS_D_InsGSProductMap
@p_id INT,
@GSP_id INT,
@GSDDNo VARCHAR(30),
@GSSFLB VARCHAR(3)
AS 
  SET NOCOUNT ON
  
  IF @GSP_id IS NULL SET @GSP_id=0 
  IF @GSSFLB IS NULL SET @GSSFLB=''
  
  IF @GSSFLB<>''
  BEGIN
    DELETE FROM GSProductMap WHERE GSDDNo=@GSDDNo AND p_id=@p_id AND IsUp=0 AND IsDel=0
	INSERT INTO GSProductMap
	  (p_id,GSP_id,GSDDNo,GSSFLB,IsUp,IsDel,serial_number,serial_number_y,name_Y,UnitName,standard)
	SELECT @p_id,0,@GSDDNo,@GSSFLB,0,0,'','','','',''
  END 
  ELSE 
  BEGIN   
	IF EXISTS(SELECT 1 FROM GSProductMap WHERE GSDDNo=@GSDDNo AND p_id=@p_id AND IsUp=0)
	BEGIN
	  UPDATE R SET  
	  GSP_id=CI.GSP_id,
	  GSDDNo=@GSDDNo,
	  GSSFLB=@GSSFLB,
	  serial_number=CI.serial_number,
	  serial_number_y=dbo.FN_GSReplace(M.serial_number),
	  name_Y=dbo.FN_GSReplace(M.name),
	  UnitName=dbo.FN_GSReplace(CI.UnitName),
	  standard=dbo.FN_GSReplace(CI.standard)
	  FROM GSProductMap R INNER JOIN GSProducts CI 
		   ON CI.GSP_id=@GSP_id
		   INNER JOIN products M 
		   ON M.product_id=@p_id
	  WHERE R.GSDDNo=@GSDDNo AND R.p_id=@p_id AND R.IsUp=0 AND R.IsDel=0
	END 
	ELSE 
	BEGIN
	  INSERT INTO GSProductMap
		(p_id,GSP_id,GSDDNo,GSSFLB,IsUp,IsDel,serial_number,serial_number_y,name_Y,UnitName,standard)
	  SELECT @p_id,CI.GSP_id,@GSDDNo,@GSSFLB,0,0,CI.serial_number,dbo.FN_GSReplace(M.serial_number)
			 ,dbo.FN_GSReplace(M.name),dbo.FN_GSReplace(CI.UnitName),dbo.FN_GSReplace(CI.standard)
	  FROM GSProducts CI INNER JOIN products M 
		   ON M.product_id=@p_id
	  WHERE CI.GSP_id=@GSP_id
	END 
  END
GO
