/************************************************************

--功能：离线版本接收门店数据   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:2011-10-18 黄耀 // 增加缺货单

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_ZBReceivePosData
( 
  @nY_ID int
)
	
AS 

declare @nBillid int, @nBillType int, @nNewBillId int, @minBillDate datetime, @maxbillDate datetime
declare @bSkipRetail bit

set @bSkipRetail = 0

select @minBillDate = min(billdate) from Yretailbillidxdts 
select @maxBillDate = max(billdate) from Yretailbillidxdts 
if @minBillDate is null set @bSkipRetail = 1
if @minBillDate < 10 set @bSkipRetail = 1

if @bSkipRetail <> 1
begin
	set @minBillDate = convert(varchar(10),@minBillDate,20)
	set @maxBillDate = convert(varchar(10),@maxBillDate,20)

	/*总部红冲了，门店就不允许再传了*/
	/*2010.10.11 修改为 总部红冲后门店可以继续上传*/
	select a.* into #guidtemp
	  from (select guid from billidx where billdate between @minBillDate and @maxBillDate and billtype in (12,13) and billstates = '0'  
			 union select guid from Ybilldraftidx )a

	delete YRetailBilldts from Yretailbillidxdts b , YRetailBilldts s 
		where b.billid=s.bill_id  and b.guid in (select guid from #guidtemp)
	delete Yretailbillidxdts where guid in (select guid from #guidtemp)

	 delete Yretailbillidxdts where billid not in (select distinct bill_id from YRetailBilldts)
	 delete Yretailbillidxdts where billid not in (select distinct bill_id from YRetailBilldts where p_id < 0) 
	 delete YRetailBilldts where bill_id not in (select billid from Yretailbillidxdts)
 
	if object_id('tempdb..#vipTmp') is not null
		  drop table #vipTmp
	   select top 0 vipcardid, TotalBuyMoney, BuyCount, Integral, IntergralYE, CAST(0 as int) as billtype, 0 as integralmoney, 0 as ct_id, cast(0 as int) as gflag into #viptmp from VIPCard
end

delete from ZeroStockIDXdts where [guid] in (select [guid] from ZeroStockIDX)
delete from ZeroStockbilldts where bill_id not in (select billid from ZeroStockIDXdts)

begin tran importPosData
	if @bSkipRetail <> 1
	begin
	 /*批量处理会员卡积分begin*/
	  truncate table #viptmp
	  
	  insert into #viptmp(vipcardid, totalbuymoney, buycount, integral, intergralYe, billtype, integralmoney, ct_id, gflag)
		select  vipcardid, ysmoney, 1, integral, integralYe, billtype, 0, 0, 0 from Yretailbillidxdts where VIPCardid <>0    
	  update #viptmp set totalbuymoney = -ABS(totalbuymoney), buycount = -1 where billtype =13  
	  
	  insert into #viptmp(vipcardid, totalbuymoney, buycount, integral, intergralYe, billtype, integralmoney, ct_id, gflag)
		select vipcardid, SUM(totalbuymoney), SUM(buycount), SUM(integral), SUM(intergralYE),0, 0, 0, 1 
		  from #viptmp where Gflag  = 0
		  group by vipcardid
	      
	  delete #viptmp where gflag = 0   
	  
	  /*得到积分余额        */
	  update #viptmp set intergralYe = t.intergralYe + v.IntergralYE , ct_id = v.CT_ID from #viptmp t, VIPCard v where t.VIPCardID = v.VIPCardID
	  /*更新vipcard的积分设置（多少钱积多少分）      */
	  update #viptmp set integralmoney = CT.integralmoney from #viptmp t, vipcardtype ct where t.ct_id = ct.ct_id and ct.isYeIntegral = 1
	  /*计算积分 积分=本单积分+余额积分      */
	  update #viptmp set integral = integral + cast((intergralye/integralmoney) as int), 
						 intergralYE = cast(((intergralye/integralmoney) -  cast((intergralye/integralmoney) as int)) * integralmoney as NUMERIC(25,8))
					 where integralmoney <> 0                          
	                                                              
	  update vipcard set Integral = v.Integral+t.integral, IntergralYE = t.IntergralYE, TotalBuyMoney = v.TotalBuyMoney + t.totalbuymoney,  BuyCount = v.BuyCount + t.buycount 
		from VIPCard v, #viptmp t where v.VIPCardID = t.vipcardid                
	  /*批量处理会员卡积分end*/

  		declare ybillcur cursor for
		  select billid,billtype from Yretailbillidxdts where y_id = @nY_ID
		  open ybillcur
		  	
		  fetch next from ybillcur into @nBillid,@nBillType
		  while @@FETCH_STATUS=0	
		  begin


			insert into Ybilldraftidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
						ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
      					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,guid,SendQty,VIPCardID,invoiceTotal,Y_ID, retaildate, integral, integralye)
			  SELECT convert(varchar(10),billdate,20), billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					 ysmoney, ssmoney,araptotal, quantity, taxrate, period, 3, order_id, department_id, 
      				 posid, region_id, isnull(auditdate, 0), skdate, jsye, jsflag, note, summary,guid,quantity,VIPCardID,invoiceTotal,Y_ID, billdate,integral, integralye
				FROM Yretailbillidxdts where billid=@nBillId

			select @nNewBillId=@@identity
				if @nNewBillid is null goto Error
			if @nNewBillid < 1 goto Error

			insert into Ysalemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
						totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
						qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
						comment,unitid,taxrate,order_id,total,aoid,thqty,SendQty,SendCostTotal,PriceType,RowE_ID,
						YGUID,Y_ID,InStoreTime,cxType, RowGuid,BatchBarCode, scomment, batchprice, cxGuid)
			 SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,0,total,aoid, quantity, 
					quantity ,(quantity*costprice)
					,priceType,RowE_ID,NEWID(),Y_ID,InStoreTime,cxType, RowGuid,BatchBarCode, scomment, batchprice, CxGuid
			  from Yretailbilldts
			  where bill_id=@nbillid and Y_ID = @nY_ID
			  order by smb_id	  
		  
			  fetch next from ybillcur into @nBillid,@nBillType
		  end	
		  close ybillcur
		  deallocate ybillcur
		  
		  delete Ybilldraftidx where billid not in (select distinct bill_id from Ysalemanagebilldrf)
		  delete Ybilldraftidx where billid not in (select distinct bill_id from Ysalemanagebilldrf where p_id < 0) 
		  delete Ysalemanagebilldrf where bill_id not in (select billid from Ybilldraftidx)
	end
	
  	declare zsIdxcur cursor for
  	select billid from ZeroStockIDXdts
  	open zsIdxcur
	fetch next from zsIdxcur into @nBillid
	while @@FETCH_STATUS = 0
	begin
		INSERT INTO dbo.ZeroStockIDX(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, 
							  region_id, auditdate, jsflag, note, summary, Y_ID, [guid])
		SELECT     billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, 
							  region_id, auditdate, jsflag, note, summary, Y_ID, [guid]
		FROM         dbo.ZeroStockIDXdts where billid = @nBillid
		
	    select @nNewBillId = @@identity
            if @nNewBillid is null goto Error
	    if @nNewBillid < 1 goto Error
	
		INSERT INTO dbo.ZeroStockBill(bill_id, p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, 
						  comment2, aoid, Y_ID)
		SELECT     @nNewBillid, p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, 
						  comment2, aoid, Y_ID
		FROM         dbo.ZeroStockBilldts where bill_id = @nBillid
		fetch next from zsIdxcur into @nBillid
	end	
	close zsIdxcur
	deallocate zsIdxcur

commit tran importPosData

if OBJECT_ID('tempdb..#guidtemp') is not null
  drop table #guidtemp
truncate table yretailbillidxdts
truncate table yretailbilldts
truncate table ZeroStockIDXdts
truncate table ZeroStockbilldts

return 0



Error:
  if OBJECT_ID('tempdb..#guidtemp') is not null
    drop table #guidtemp
 truncate table yretailbillidxdts
 truncate table yretailbilldts
 truncate table ZeroStockIDXdts
 truncate table ZeroStockbilldts

 rollback tran importPosData
 return -1
GO
