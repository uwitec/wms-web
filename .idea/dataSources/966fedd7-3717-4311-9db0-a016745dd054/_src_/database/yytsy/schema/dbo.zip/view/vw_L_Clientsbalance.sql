
CREATE VIEW dbo.vw_L_Clientsbalance
AS

  SELECT CB.* ,ISNULL(C.class_id,'')CClass_ID,ISNULL(C.[name],'')Cname,
  ISNULL(E.class_id,'')EClass_ID,ISNULL(E.[name],'')Ename,
  ISNULL(Y.class_id,'')Yclass_ID, ISNULL(Y.[name],'')Yname

  FROM  Clientsbalance CB
  
   LEFT OUTER JOIN  clients    c  ON CB.C_id=c.client_id
   LEFT OUTER JOIN  employees  E  ON CB.e_id=E.emp_id
   LEFT OUTER JOIN  Company    Y  ON CB.Y_id=Y.company_id
where cb.c_id  in (select client_id from clients where deleted=0)
GO
