create  PROCEDURE  [dbo].[Ts_M_XMLOutput] 
 @tag  int=0 ,
 @beginDate varchar(100),
 @endDate    varchar(100)
AS
/*Params Ini begin*/
if @tag is null  SET @tag = 0 
/*Params Ini end*/
declare @sql varchar(5000)
if @tag=0 
begin
      set @sql='select p.PermitCode as pass_num,sm.Pname as goods_name,P.Alias as drug_name,
          p.Factory as goods_manu, (select a.engname from products a where a.product_id=p.product_id ) drug_ename,
          p.standard as standard,p.medType as form,
          sm.Batchno as lot_num,sm.unitName as uom,sm.quantity as trans_amount
   ,0 as prices,0 as trans_num
   ,sm.validdate as validate_date
          ,bi.cname as s_ent_name
          ,bi.billdate as trans_date 
          ,c.address as s_ent_address 
          ,c.serial_number as  CUSTOM_CODE
          ,c.Licence_no  as  s_licence_no 
          ,c.Ent_type    as  s_ent_type
          ,c.City_id     as  s_city_id     
          ,c.City_name   as  s_city_name
         ,c.boro_id     as  s_boro_id
         ,c.boro_name   as  s_boro_name
          ,bi.ename as report_user
          ,e.Phone as user_link 
          ,Bi.BillID 
            from vw_c_Buymb sm left join VW_C_Products p on p.product_id=sm.p_id 
                             left join vw_c_billIdx bi on sm.bill_id=bi.billid 
                             left join clients c on c.CLient_id=bi.c_id 
                             left join employees e on bi.e_id= e.emp_id  
            where bi.billStates=0 and sm.P_id>0 and bi.billtype<>21 and bi.auditDate between '
         set @sql=@sql+''''+@beginDate+' 00:00:00''  and '''+@endDate+' 23:59:59''  order by bi.billID  '
         /*print(@sql)*/
         exec(@sql)
end
if @tag=1
begin
     set @sql='select p.PermitCode as pass_num,sm.Pname as goods_name,P.Alias  as drug_name,
          p.Factory as goods_manu, (select a.engname from products a where a.product_id=p.product_id ) drug_ename,
          p.standard as standard,p.medType as form,
          sm.Batchno as lot_num,sm.unitName as uom,sm.quantity as trans_amount
          ,0 as prices,0 as trans_num
          ,sm.validdate as validate_date
          ,bi.cname as b_ent_name 
          ,bi.billdate as trans_date
          ,c.address as b_ent_address
          ,c.serial_number  as  CUSTOM_CODE
          ,c.Licence_no     as  b_licence_no
          ,c.Ent_type       as  b_ent_type
          ,c.City_id        as  b_city_id
          ,c.City_name      as  b_city_name
          ,c.boro_id        as  b_boro_id
         ,c.boro_name      as  b_boro_name
         ,bi.ename as report_user
         ,e.Phone as user_link 
         ,Bi.BillID 
           from vw_c_salemb sm left join VW_C_Products p on p.product_id=sm.p_id 
                             left join vw_c_billIdx bi on sm.bill_id=bi.billid 
                             left join employees e on bi.e_id= e.emp_id  
                             left join clients c on c.CLient_id=bi.c_id 
           where bi.billStates=0 and sm.P_id>0 and bi.billtype<>11 and bi.auditDate between '
 set @sql=@sql+''''+@beginDate+' 00:00:00''  and '''+@endDate+' 23:59:59''  order by bi.billID  '
        exec(@sql)
        /*print @sql*/
end
if @tag=2 
begin
      set @sql='select s.PermitCode as pass_num,s.Pname as goods_name,p.alias as drug_name,p.Factory as goods_manu, p.engname as drug_ename,
           s.standard as standard,s.medName as form,s.Batchno as lot_num,s.name1 as uom,s.validDate as validate_date ,s.quantity as trans_amount
            from VW_C_Storehouse s left join clients c on s.supplier_id=c.client_id 
                                left join products p on p.product_id=s.p_id'
 exec(@sql)
end
/********************add by luowei 增加采购退货与销售退货 begin***********************/
if @tag=3     /*采购退货*/
begin
      set @sql='select p.PermitCode as pass_num,sm.Pname as goods_name,P.Alias as drug_name,
          p.Factory as goods_manu, (select a.engname from products a where a.product_id=p.product_id ) drug_ename,
          p.standard as standard,p.medType as form,
          sm.Batchno as lot_num,sm.unitName as uom,sm.quantity as trans_amount
   ,0 as prices,0 as trans_num
   ,sm.validdate as validate_date
          ,bi.cname as s_ent_name
          ,bi.billdate as trans_date 
          ,c.address as s_ent_address 
          ,c.serial_number as  CUSTOM_CODE
          ,c.Licence_no  as  s_licence_no 
          ,c.Ent_type    as  s_ent_type
          ,c.City_id     as  s_city_id     
          ,c.City_name   as  s_city_name
         ,c.boro_id     as  s_boro_id
         ,c.boro_name   as  s_boro_name
          ,bi.ename as report_user
          ,e.Phone as user_link 
          ,Bi.BillID 
            from vw_c_Buymb sm left join VW_C_Products p on p.product_id=sm.p_id 
                             left join vw_c_billIdx bi on sm.bill_id=bi.billid 
                             left join clients c on c.CLient_id=bi.c_id 
                             left join employees e on bi.e_id= e.emp_id  
            where bi.billStates=0 and sm.P_id>0 and bi.billtype=21 and bi.auditDate between '
         set @sql=@sql+''''+@beginDate+' 00:00:00''  and '''+@endDate+' 23:59:59''  order by bi.billID  '
         /*print(@sql)*/
         exec(@sql)
end
if @tag=4  /*销售退货*/
begin
     set @sql='select p.PermitCode as pass_num,sm.Pname as goods_name,P.Alias  as drug_name,
          p.Factory as goods_manu, (select a.engname from products a where a.product_id=p.product_id ) drug_ename,
          p.standard as standard,p.medType as form,
          sm.Batchno as lot_num,sm.unitName as uom,sm.quantity as trans_amount
          ,0 as prices,0 as trans_num
          ,sm.validdate as validate_date
          ,bi.cname as b_ent_name 
          ,bi.billdate as trans_date
          ,c.address as b_ent_address
          ,c.serial_number  as  CUSTOM_CODE
          ,c.Licence_no     as  b_licence_no
          ,c.Ent_type       as  b_ent_type
          ,c.City_id        as  b_city_id
          ,c.City_name      as  b_city_name
          ,c.boro_id        as  b_boro_id
         ,c.boro_name      as  b_boro_name
         ,bi.ename as report_user
         ,e.Phone as user_link 
         ,Bi.BillID 
           from vw_c_salemb sm left join VW_C_Products p on p.product_id=sm.p_id 
                             left join vw_c_billIdx bi on sm.bill_id=bi.billid 
                             left join employees e on bi.e_id= e.emp_id  
                             left join clients c on c.CLient_id=bi.c_id 
           where bi.billStates=0 and sm.P_id>0 and bi.billtype=11 and bi.auditDate between '
 set @sql=@sql+''''+@beginDate+' 00:00:00''  and '''+@endDate+' 23:59:59''  order by bi.billID  '
        exec(@sql)
        /*print @sql*/
end
/**************************end*************************/



/*------------------*/
GO
