
/* =============================================*/
/* Author:		XXX*/
/* Create date: 2017-05-24 */
/* Description:	分配货位算法*/
/*在药易通程序 非wms 版本使用，返回空*/
/* =============================================*/

CREATE PROCEDURE TS_X_WmsAutoAssignLocation 
	@nMode int = 0,		/* 分配类型*/
	@billid int = 0,		/*单据id -- 选择的仓库id  */
	@billtype int = 0,		/* 单据类型*/
	@y_id int = 0,		/* 机构id*/
	@nRet int output		/* 返回值，成功返回0，失败返回-1，错误返回-2*/
AS
BEGIN
	SET NOCOUNT ON;
	RAISERROR('在升级wms版本后才能使用自动分配货位流程',16,1)
	RETURN -1
END
GO
