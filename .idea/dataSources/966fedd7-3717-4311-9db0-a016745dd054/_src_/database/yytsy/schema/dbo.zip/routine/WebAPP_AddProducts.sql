create proc WebAPP_AddProducts(
	@server_number varchar(150)='',--编码
	@name varchar(150)='', --名称
	@alias varchar(150) = '',--简明
	@standard varchar(150)='',--规格
	@model varchar(150)='',--型号
	@makearea varchar(150)='',--产地
	@Unit1_id int =0,--基本单位ID 如果为0并且Unit1_Name不为空表示用户手动输入的基本单位，脚本中还需对基本单位进行保存。
	@Unit1_Name varchar(150)='',--单位名称
	@trademark varchar(150)='',--条形码
	@costmethod int=0,-- 成本和算法（T9FZ和T6FZ传入其他产品线不管）
	@SizeGroupID int=0,--尺码组ID
	@ColorGroupID int=0,--颜色组ID
	@comment varchar(200)='',--备注
	@isUseBatch int=0,--管理批次(T6FZ传入其他产品线不管)
	@property int=0,--无形资产(T6FZ传入其他产品线不管)
	@materialld int=0,--物料属性(JC传入其他产品线不管)
	@snflag int=0,--管理批号(JC传入其他产品线不管)
	@Unit4_Stid int=0,--JC副单位ID()如果为0并且Unit4_Name不为空表示用户手动输入的基本单位，脚本中还需对单位进行保存。
	@Unit4_Name varchar(200)='',--JC副单位名称@PurUnit
	@PP_id int=0,--JC核算类别其他产品线不管
	@Params varchar(200),--扩展参数 
	@pinyin varchar(150)='',--拼音码
	@RetMessage varchar(200) OUT 
)
as
begin

	 SET @RetMessage='添加成功'
	 declare @resulttype INT,@product_id int
	 SET @resulttype=0
	 if(@Unit1_id=0)
	 begin
		if(@Unit1_Name<>'')
		begin
		if not exists(select * from unit where name = @Unit1_Name)
		begin
		insert into unit(name,deleted) values(@Unit1_Name,0)
		SELECT @Unit1_id=@@IDENTITY
		end
		else
		begin
		select @Unit1_id=unit_id from unit where name=@Unit1_Name
		end
		end
	 end

	exec @resulttype=Ts_L_insBaseProducts @class_id='000000',@serial_number=@server_number,@name=@name,@alias=@alias,@standard=@standard,@modal=@model,
	@permitcode='',@trademark=@trademark,@makearea=@makearea,@unit1_id=@Unit1_id,@unit2_id=0,@unit3_id=0,@unit4_id=0,@rate2=0,@rate3=0,@rate4=0,
	@validmonth='', @validday='',@comment=@comment,@pinyin=@pinyin,@firstcheck='',@otcflag=0,@medtype=0,@costmethod=1,@Parent_id='000000',@GspFlag=0,
	@engName='',@chemName='',@latinName='',@deduct=0,@OTCType=0, @GMP=0,@Gross=0,@MaintainType=0,@MaintainDay =0,@taxRate=0, @packStd='', @storageCon='', 
	@Range = 0, @supplier_id = 0, @emp_id = 0, @posYhDay = 0, @ifIntegral = 0, @Integral = 0, @Factory = '', @RowIndex = 1, @tc1 = 0, @tc2 = 0, @tcmoney = 0,
	@TcCost = 0, @BulidNo = '', @RegisterNo = '', @WholeUnit_id = 0, @PrintClass = 0, @deleted = 0, @Inputdate = '1900-01-01', @Inputman = '', @Custompro1 = '',
	@Custompro2 = '', @Custompro3 = '', @Custompro4 = '', @Custompro5 = '', @Locid = 0, @NoneQuantity = 0, @FactoryC_ID = 0, @SR_ID = 0, @nY_id = 2, @Drate = 0,
	@basicMedication = 0, @SR2_id = 0, @Wholeloc = 0, @SingleLoc = 0, @protectprice = 0, @RegistervalidDate = '1900-01-01', @PerCodevalidDate = '1900-01-01',
	@TransToYJ = 0, @ControlYard = 0, @ifdiscount = 0, @pack = '', @isCheckReport = 0, @GMPNo = '', @GMPValiddate = '1900-01-01', @Kcl = 0, @Kcldw = 0, @Khsbl = 0,
	@Kcljg = 0, @incRate2 = 0, @incRate3 = 0, @isCheckLT = 0, @StoreCondition = 0, @IsValidP = 0, @IfZYCheck = 0, @IsClientDiscount = 0, @FCategoryStr = '',
	@commodityCode = '', @fztaxrate = 0, @taxrateflcode = '', @Z_ZNumber = '', @Z_ZBillDate = '1900-01-01', @auditManID = 0, @auditMan = '', @auditComment = ''
	if(@resulttype>0)
	begin
	set @product_id=@resulttype
	exec Ts_L_InsPrice @Price_id=0,@p_id=@product_id,@u_id=@Unit1_id,@retailprice=0.0, @price1=0.0, @price2=0.0,@price3=0.0, @price4=0.0, @gpprice=0.0,@glprice=0.0,
	@specialprice=0.0,@recPrice=0.0,@unitType=1,@LowPrice=0.0,@DbName='PRICE',@POSID=0
	
	end
	if(@resulttype=-1)
	begin
	set @RetMessage='ID号生成错误，可能是这类目录的记录数已经超出限制'
	return -1
	end

	if @@error<>0 
    BEGIN
   	SET @RetMessage='添加失败'
	return -1 
   	end


end
GO
