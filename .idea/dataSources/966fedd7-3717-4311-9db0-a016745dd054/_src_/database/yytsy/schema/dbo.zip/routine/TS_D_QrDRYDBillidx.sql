

CREATE procedure TS_D_QrDRYDBillidx
@BeginDate	DATETIME,
@EndDate	DATETIME,
@Sign       INT,   /*0按日期查 1只查未签退的*/
@nloginEID  INT    /*当前用户*/
AS
  
  SET NOCOUNT ON 

  SELECT a.OperatorNo,a.BATCHNO,a.SignStatus,a.SignInDate,a.SignOutDate,a.SignInNo,a.SignOutNo
         ,CASE WHEN a.SignStatus=0 THEN '已签到' ELSE '已签退' END SignStatusStr 
         ,b.name OperatorName
  FROM DRYDBillidx a LEFT JOIN employees b 
       ON a.OperatorNo=b.emp_id
  WHERE (@nloginEID=1 OR a.OperatorNo=@nloginEID) 
        AND ((@Sign=1 AND SignStatus=0) OR (@Sign=0 AND SignInDate>=@BeginDate AND SignInDate<@EndDate+1))
  ORDER BY a.SignInDate
GO
