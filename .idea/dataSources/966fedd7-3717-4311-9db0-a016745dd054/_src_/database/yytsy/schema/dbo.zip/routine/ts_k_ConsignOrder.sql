

CREATE PROCEDURE ts_k_ConsignOrder(
    @nType           INT = 1,/*1 查询；2 新增、修改委托书主表；3 删除委托书；4 新增、修改委托书明细表*/
    @ConsignID       INT = 0,
    @ConsignType     INT = 0,
    @ConsignCode     VARCHAR(30) = '',
    @OperationCode   VARCHAR(30) = '',
    @Name            VARCHAR(30) = '',
    @Job             VARCHAR(30) = '',
    @Sex             INT = 0,
    @PersonNO        VARCHAR(30) = '',
    @C_ID            INT = 0,
    @BeginDate       DATETIME,
    @EndDate         DATETIME,
    @AccreditOrg     VARCHAR(100) = '',
    @Corporation     VARCHAR(30) = '',
    @AccreditDate    DATETIME,
    @ConsignComment  VARCHAR(200) = '',
    @Y_ID            INT = 2,
    @nLoginUserID    INT = 1,
    @P_ID            INT = 0,
    @Comment         VARCHAR(200) = '',
    @PDPic			 VARCHAR(1000) = '',
    @nRet            INT = 0 OUTPUT 
)
AS
	IF @nType = 1
	BEGIN
	   if @OperationCode is null
	     set @OperationCode = ''
	   if @OperationCode = '' 
	     set @OperationCode= '%%'   
	   else
	     set @OperationCode = '%'+@OperationCode+'%'  
	
	    SELECT a.ConsignID, a.ConsignType, a.ConsignCode, a.OperationCode, a.Name, a.[Job],
	           a.Sex, CASE a.Sex WHEN 0 THEN '男' ELSE '女' END AS SexName,	a.PersonNO,
	           a.C_ID, b.Name AS CName, a.BeginDate, a.EndDate, a.AccreditOrg, a.Corporation,
	           a.AccreditDate, a.ConsignComment, a.Y_ID, a.ModifyDateTime, a.ModifyEID, c.name AS EName,
	           a.PDPic
	    FROM   ConsignOrder a
	           INNER JOIN clients b
	                ON  a.C_ID = b.client_id
	           INNER JOIN employees c
	                ON  a.ModifyEID = c.emp_id
	    WHERE  a.Y_ID = @Y_ID
	           AND a.ConsignType = @ConsignType
	           AND (@C_ID = 0 OR a.C_ID = @C_ID)
	           AND (@OperationCode = '' OR (a.OperationCode LIKE @OperationCode or a.Name like @OperationCode))
	           AND (@ConsignCode = '' OR a.ConsignCode LIKE @ConsignCode + '%')	          
	    SET @nRet = 0 
	END
	ELSE
	IF @nType = 3
	BEGIN
	   DELETE FROM ConsignOrderDetail WHERE ConsignID = @ConsignID
	   DELETE FROM ConsignOrder WHERE ConsignID = @ConsignID
	   IF @@ERROR = 0
	   BEGIN
	       SET @nRet = 0
	   END
	   ELSE
	   BEGIN
	       SET @nRet = -1
	   END
	END
	ELSE 
	IF @nType = 2
	BEGIN
	    IF EXISTS(
	           SELECT 1
	           FROM   ConsignOrder
	           WHERE  ConsignID = @ConsignID
	       )
	    BEGIN
	    	UPDATE ConsignOrder
	    	SET
	    		ConsignType = @ConsignType,
	    		ConsignCode = @ConsignCode,
	    		OperationCode = @OperationCode,
	    		Name = @Name,
	    		[Job] = @Job,
	    		Sex = @Sex,
	    		PersonNO = @PersonNO,
	    		C_ID = @C_ID,
	    		BeginDate = @BeginDate,
	    		EndDate = @EndDate,
	    		AccreditOrg = @AccreditOrg,
	    		Corporation = @Corporation,
	    		AccreditDate = @AccreditDate,
	    		ConsignComment = @ConsignComment,
	    		Y_ID = @Y_ID,
	    		ModifyDateTime = GETDATE(),
	    		ModifyEID = @nLoginUserID,
	    		PDPic = @PDPic
	    	WHERE ConsignID = @ConsignID
	    	
	    	IF @@ERROR = 0
	        BEGIN
	            DELETE FROM ConsignOrderDetail WHERE ConsignID = @ConsignID
	            SET @nRet = @ConsignID
	        END
	        ELSE
	        BEGIN
	            SET @nRet = -1	
	        END
	    END
	    ELSE
	    BEGIN
	    	INSERT INTO ConsignOrder
	    	(
	    		ConsignType,
	    		ConsignCode,
	    		OperationCode,
	    		Name,
	    		[Job],
	    		Sex,
	    		PersonNO,
	    		C_ID,
	    		BeginDate,
	    		EndDate,
	    		AccreditOrg,
	    		Corporation,
	    		AccreditDate,
	    		ConsignComment,
	    		Y_ID,
	    		ModifyDateTime,
	    		ModifyEID,
	    		PDPic
	    	)
	    	VALUES
	    	(
	    		@ConsignType,
	    		@ConsignCode,
	    		@OperationCode,
	    		@Name,
	    		@Job,
	    		@Sex,
	    		@PersonNO,
	    		@C_ID,
	    		@BeginDate,
	    		@EndDate,
	    		@AccreditOrg,
	    		@Corporation,
	    		@AccreditDate,
	    		@ConsignComment,
	    		@Y_ID,
	    		GETDATE(),
	    		@nLoginUserID,
	    		@PDPic
	    	)
	    	
	    	IF @@ERROR = 0
	        BEGIN
	            SET @nRet = @@IDENTITY 
	        END
	        ELSE
	        BEGIN
	            SET @nRet = -1	
	        END
	    END
	END
	ELSE
	IF @nType = 4 
	BEGIN
		INSERT INTO ConsignOrderDetail
		(
			ConsignID,
			P_ID,
			Comment
		)
		VALUES
		(
			@ConsignID,
			@P_ID,
			@Comment
		)
		IF @@ERROR = 0
		BEGIN
		    SET @nRet = @@IDENTITY
		END
		ELSE
		BEGIN
		    SET @nRet = -1
		END
	END
GO
