
create proc ts_c_modifycostprice
(
	@nbilltype int,
	@smb_id numeric(10,0),
	@dcostprice NUMERIC(25,8)
)
/*with encryption*/
as
set nocount on

/*销售单,发货单,销售退货单,采购单,收货单,采购退货单*/
if @nBilltype in (210,212,211,220,222,221,104,105,106,107)/*,160,161,162,163)  */
begin
  return 0
end

/*销售类单据*/
if @nBilltype in (10,11,12,13,110,111,112,32,150,151,152,153) 
/*销售出库单,销售出库退货单,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,机构发货单,机构发货退货单*/
begin
	update salemanagebill set costprice=@dcostprice, costtaxprice = @dcostprice * (1 + costtaxrate), 
		costtaxtotal = @dcostprice * (1 + costtaxrate) * quantity where smb_id=@smb_id 
	if @@rowcount=0 goto error
        /*处理在统设置里面设置"零售不管批次"，使用最近进价为成本价"，单据没有写sendcosttotal(发货金额)*/
 	if @nBilltype in (11,12,13) 
	begin
                /*取开关*/
		declare @cRetailNoBatchno char(1)  /*零售不管批次*/
		declare @cRecpriceAsCost  char(1)  /*是否使用最近进价作为成本价*/
		set @cRetailNoBatchno='0' set @cRecpriceAsCost='0'
		exec ts_getsysvalue 'RetailNoBatchno',@cRetailNoBatchno out 
		exec ts_GetSysValue 'RecpriceAsCost', @cRecpriceAsCost output
		if (@cRetailNoBatchno='1') and (@nBilltype in (12,13) )
			update salemanagebill set SendCostTotal=(quantity*costprice) where smb_id=@smb_id 
		if (@cRecpriceAsCost='1') and @nBilltype in (11)  
			update salemanagebill set SendCostTotal=(quantity*costprice) where smb_id=@smb_id 
	end  
	return	0
end
/*销售类单据*/

/*采购类单据*/
if @nBilltype in (20,21,120,121,122,35,160,161,162,163) 
/*采购入库单,采购入库退货单,受托代销收货,受托代销退货,受托代销结算,机构收货单,机构收货退货单*/
begin
   /*zjx-tfs41395-2016-09-28-入库这里不应该反算costtaxprice，costtaxtotal*/
	update buymanagebill set costprice=@dcostprice/*, costtaxprice = @dcostprice * (1 + costtaxrate), */
		/*costtaxtotal = @dcostprice * (1 + costtaxrate) * quantity */
		where smb_id=@smb_id
	if @@rowcount=0 goto error
	return	0
end
/*采购类单据*/

/*库存类单据*/
if @nBilltype in (30,31,33,34,38,39,40,41,42,43,44,45,46,47,48,49,51)
/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
begin
	update storemanagebill set costprice=@dcostprice,costtotal=quantity*@dcostprice, costtaxprice = @dcostprice * (1 + costtaxrate), 
		costtaxtotal = @dcostprice * (1 + costtaxrate) * quantity where smb_id=@smb_id
	if @@rowcount=0 goto error
	if @nbilltype in (30,34,38,41,44,49)
	begin
		update storemanagebill set /*price=@dcostprice,*/totalmoney=quantity*@dcostprice,total=quantity*@dcostprice where smb_id=@smb_id
		if @@rowcount=0 goto error
	end
	return	0
end
/*库存类单据*/

if @nBilltype in (53,54,55,56)
/*配送单*/
begin
	update tranmanagebill set costprice=@dcostprice, costtaxprice = @dcostprice * (1 + costtaxrate), 
		costtaxtotal = @dcostprice * (1 + costtaxrate) * quantity where smb_id=@smb_id
	if @@rowcount=0 goto error
	return	0
end
/*配送单*/


/*库存盘点单*/
if @nBilltype=50
begin
	update GoodsCheckbill set costprice=@dcostprice, costtaxprice = @dcostprice * (1 + costtaxrate) where smb_id=@smb_id
	if @@rowcount=0 goto error
	return	0
end
/*库存盘点单*/

/*积分兑换单*/
if @nBilltype=149
begin
	update ExIntegRalManagebill set costprice=@dcostprice, costtaxprice = @dcostprice * (1 + costtaxrate) where smb_id=@smb_id
	if @@rowcount=0 goto error
	return	0
end
/*积分兑换单*/



error:
	return -6
GO
