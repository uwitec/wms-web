
/******************************************
GSP订单数据查询
作者：yanrui
创建日期 2014-01-27
********************************************/
CREATE PROCEDURE ts_Y_GSPSelectReport
(	
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间	*/
	@billnumber     varchar(30) ='',  /*单据编号*/
	@szguid         varchar(30) ='',  /* GUID*/
	@billtype       int=0,      /*单据类型*/
	@billid         int=0,      /*单据ID*/
	@c_id           int=0       /* 往来单位/往来机构 */
)
as
/*----------------初始化参数*/
/* 往来单位/往来机构 */
declare  @c_id1 int,@c_id2 int 
select @c_id1=@c_id,@c_id2=@c_id1
if @c_id1=0 select @c_id2=2147483647
/*单据类型*/
declare  @btp1 int,@btp2 int 
select @btp1=@billtype,@btp2=@btp1
if @btp1=0 select @btp2=10000
/*单据ID*/
declare  @b_id1 int,@b_id2 int 
select @b_id1=@billid,@b_id2=@b_id1
if @b_id1=0 select @b_id2=2147483647
/*-单据编号*/
declare @xs_no varchar(50)
set @xs_no='%'+@billnumber+'%'
/*--GUID*/
declare @vguid varchar(50)
set @vguid='%'+@szguid+'%'

DECLARE @uGuid uniqueidentifier /* guid*/

IF @billtype IN (14, 22)
BEGIN
	SELECT @uGuid = Guid FROM orderidx WHERE billid = @billid

	select  a.Gspbillid as billid, ISNULL(v.comment, '') as billtype,a.billnumber,a.Y_id,a.c_id,a.billdate,isnull(e1.name,'') as  inputmanname,a.auditman1,
	isnull(e2.name,'') as auditmann1Name,a.audittime1,a.auditman2,isnull(e3.name,'') as auditmann2Name,a.audittime2, 
	isnull(a.traffictype,'') as traffictype,ISNULL(a.traffictools,'') as traffictools,a.traffictime,
	isnull(a.tempcontrol,'') as tempcontrol,ISNULL(a.spectrafficprove,'') as spectrafficprove,ISNULL(a.sendaddress,'') as sendaddress,
	a.sendtime,isnull(a.trafficCompany,'') as trafficCompany,ISNULL(a.tempcontrolmode,'') as tempcontrolmode,
	a.WholeQty,a.PartQty,a.discountTotal,a.TaxTotal,a.billstates,isnull(a.b_CustomName1,'') as b_CustomName1,isnull(a.b_CustomName2,'') as b_CustomName2,
	isnull(a.b_CustomName3,'') as b_CustomName3,isnull(a.b_CustomName4,'') as b_CustomName4,isnull(a.b_CustomName5,'') as b_CustomName5,Note,
	a.Ybillid,a.BillType as Ybilltype,a.s_id,a.inputman,
	/*---此处先定义拣货的状态 */
	(case 
		when a.billtype =541 and a.billstates=10 then '待拣货' 
		when a.billtype =541 and a.billstates=13 then '拣货审核' 
		when a.billtype =541 and a.billstates=14 then '拣货中' 
		when a.billtype =541 and a.billstates=15 then '拣货完成'
		when a.billtype =551 and a.billstates=10 then '复核中' 
		when a.billtype =551 and a.billstates=12 then '复核1完成'
		when a.billtype =551 and a.billstates=13 then '复核 完成'
		when a.billtype =551 and a.billstates=15 then '订单复核完成'
		when a.billtype =531 and a.billstates=10 then '未处理' 
		when a.billtype =531 and a.billstates=13 then '审核完成'     
		when a.billtype  not in(541,551,531) and a.billstates=10 then '开始'
		when a.billtype  not in(541,551,531) and a.billstates=11 then '删除'
		when a.billtype  not in(541,551,531) and a.billstates=12 then '审核1完成'
		when a.billtype  not in(541,551,531) and a.billstates=13 then '审核 完成'
		when a.billtype  not in(541,551,531) and a.billstates=15 then '审核 完成'
		else ''
		end
	)as billstatesN 
	from GSPbillidx a
	left join  company b on  a.Y_id=b.company_id
	left join  clients c on  a.c_id=c.client_id
	left join  storages d on  a.s_id=d.storage_id
	left join  employees e1 on  a.inputman=e1.emp_id
	left join  employees e2 on  a.auditman1=e2.emp_id
	left join  employees e3 on  a.auditman2=e3.emp_id
	left join VchType v on a.BillType = v.Vch_ID
	where  A.Yguid = @uGuid
END
ELSE
begin
 select  a.Gspbillid as billid,a.billtype,a.billnumber,a.Y_id,a.c_id,a.billdate,isnull(e1.name,'') as  inputmanname,a.auditman1,
 isnull(e2.name,'') as auditmann1Name,a.audittime1,a.auditman2,isnull(e3.name,'') as auditmann2Name,a.audittime2, 
 isnull(a.traffictype,'') as traffictype,ISNULL(a.traffictools,'') as traffictools,a.traffictime,
 isnull(a.tempcontrol,'') as tempcontrol,ISNULL(a.spectrafficprove,'') as spectrafficprove,ISNULL(a.sendaddress,'') as sendaddress,
 a.sendtime,isnull(a.trafficCompany,'') as trafficCompany,ISNULL(a.tempcontrolmode,'') as tempcontrolmode,
 a.WholeQty,a.PartQty,a.discountTotal,a.TaxTotal,a.billstates,isnull(a.b_CustomName1,'') as b_CustomName1,isnull(a.b_CustomName2,'') as b_CustomName2,
 isnull(a.b_CustomName3,'') as b_CustomName3,isnull(a.b_CustomName4,'') as b_CustomName4,isnull(a.b_CustomName5,'') as b_CustomName5,Note,
 a.Ybillid,a.Ybilltype,a.s_id,a.inputman,
 /*---此处先定义拣货的状态 */
  (case 
     when a.billtype =541 and a.billstates=10 then '待拣货' 
	 when a.billtype =541 and a.billstates=13 then '拣货审核' 
     when a.billtype =541 and a.billstates=14 then '拣货中' 
     when a.billtype =541 and a.billstates=15 then '拣货完成'
     when a.billtype =551 and a.billstates=10 then '复核中' 
     when a.billtype =551 and a.billstates=12 then '复核1完成'
     when a.billtype =551 and a.billstates=13 then '复核 完成'
     when a.billtype =551 and a.billstates=15 then '订单复核完成'
     when a.billtype =531 and a.billstates=10 then '未处理' 
     when a.billtype =531 and a.billstates=13 then '审核完成'     
     when a.billtype  not in(541,551,531) and a.billstates=10 then '开始'
     when a.billtype  not in(541,551,531) and a.billstates=11 then '删除'
     when a.billtype  not in(541,551,531) and a.billstates=12 then '审核1完成'
     when a.billtype  not in(541,551,531) and a.billstates=13 then '审核 完成'
     when a.billtype  not in(541,551,531) and a.billstates=15 then '审核 完成'
     else ''
     end
  )as billstatesN,billtype 
 from GSPbillidx a
 left join  company b on  a.Y_id=b.company_id
 left join  clients c on  a.c_id=c.client_id
 left join  storages d on  a.s_id=d.storage_id
 left join  employees e1 on  a.inputman=e1.emp_id
 left join  employees e2 on  a.auditman1=e2.emp_id
 left join  employees e3 on  a.auditman2=e3.emp_id
 where  a.billdate>=@BeginDate and a.billdate<=@EndDate 
 and a.Gspbillid>=@b_id1  and a.Gspbillid<=@b_id2
 and a.billtype>=@btp1 and a.billtype<=@btp2
 and a.c_id>=@c_id1 and a.c_id<=@c_id2
 and a.billnumber like @xs_no
 and a.Yguid like @vguid
 
 
end
GO
