








CREATE	PROCEDURE [Ts_L_InsGspFlowControl]
	(@SourceGspType 	[int],
	 @DestGspType	[int],
	 @Comment	[varchar](50),
	 @SysFlag	[tinyint],
	 @gspPropert	[binary](50),
	 @Y_id        int,
	 @nMode		  int
	 )

AS 

/*gsp to gsp*/
if @nMode = 0
begin
	if  not exists(Select * from GspFlowControl where DestGspType=@destGsptype and SourceGsptype=@SourceGsptype and y_ID=@Y_id)
	begin
		INSERT INTO [GspFlowControl] 
			 ( [SourceGspType],
			 [DestGspType],
			 [Comment],
			 [SysFlag],
			 [GspPropert],
			 [Y_id]) 
		 
		VALUES 
			( @SourceGspType,
			 @DestGspType,
			 @Comment,
			 @SysFlag,
			 @GspPropert,
			 @Y_id
			 )
	end else
	begin
		UPDATE [GspFlowControl] 
		
		SET	 [SourceGspType]	 = @SourceGspType,
			 [DestGspType]	 = @DestGspType,
			 [Comment]	 = @Comment,
			 [SysFlag]	 = @SysFlag ,
			 [GspPropert]	 = @gspPropert	
		
		WHERE 
			( SourceGsptype=@sourceGsptype and destGsptype=@destGsptype)
	end
end

/* bill to gsp*/
if @nMode = 1
begin
	if  not exists(Select * from BillToGsp where GspType=@destGsptype and billtype=@SourceGsptype)
	begin
		INSERT INTO [BillToGsp]  
			 ( [billType],
			 [GspType],			 
			 [SysFlag],
			 [GspPropert])			 
		 
		VALUES 
			( @SourceGspType,
			 @DestGspType,			 
			 @SysFlag,
			 @GspPropert			 
			 )
	end else
	begin
		UPDATE [BillToGsp] 
		
		SET	 [BillType] 	 = @SourceGspType,
			 [GspType]	 = @DestGspType,			 
			 [SysFlag]	 = @SysFlag ,
			 [GspPropert]	 = @gspPropert	
		
		WHERE 
			( billtype =@sourceGsptype and Gsptype=@destGsptype)
	end
end
GO
