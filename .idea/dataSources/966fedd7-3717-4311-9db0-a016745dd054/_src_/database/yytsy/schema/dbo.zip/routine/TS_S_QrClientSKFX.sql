

CREATE PROC TS_S_QrClientSKFX
( @Begindate      datetime = 0,
  @Enddate        datetime = 0,
  @szCClass_ID    varchar(30)='',
  @szBillType     varchar(255)='0',
  @OperatorID     INT = 1,
  @QrType         INT = 0, /* 0 销售类收款 1 采购类付款*/
  @nloginEID      int=0,
  @szYclass_id    varchar(50)=''/*分支机构Class_id*/
)
AS
BEGIN
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = 0
if @Enddate is null  SET @Enddate = 0
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szBillType is null  SET @szBillType = '0'
if @OperatorID is null  SET @OperatorID = 1
if @QrType is null  SET @QrType = 0
if @nloginEID is null  SET @nloginEID = 0
if @szYclass_id is null  SET @szYclass_id = ''
/*Params Ini end*/
SET NOCOUNT ON 
declare  @BANK_ID    	varchar(100),
         @CASH_ID    	varchar(100),       
         @SQLScript  	varchar(8000),
         @szName     	varchar(100),
         @szID       	varchar(100),
         @nAID       	INT,
         @ArOrApID   	varchar(30),
         @ArID       	varchar(30),
         @ApID       	varchar(30),
         @ClientTable    int,
	 @Companytable   int
 select @ArID = '000002000005',@ApID = '000001000009'  
 if @QrType = 0  select @nAID = 15,@ArOrApID = @ArID  else if @QrType = 1 select @nAID = 23 ,@ArOrApID = @ApID
  create table #SKtmp(c_id int,skje NUMERIC(25,8),flag varchar(50))

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  /*create table #employeestable([id] int)*/
  /*create table #storagestable([id] int)*/
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权 */


if @szYclass_id='' select @szYclass_id='%%' else select @szYclass_id=@szYclass_id+'%'        
select @BANK_ID='000001000004%' ,@CASH_ID ='000001000003%'
    if @szCClass_ID = '' select  @szCClass_ID = '%%' else select  @szCClass_ID = @szCClass_ID +'%'
/*前期业务收款、付款合计  */

    SELECT  b.c_ID,Sum(jstotal) as skje,'QSKsum' as flag INTO #tmpSK 
      FROM
          (select b.c_id,pd.jstotal
             from 
            (
				 select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jsbdetail  where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid,c_id
				 UNION ALL 
				 select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jspdetail   where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid,c_id 
             ) pd
             inner join vw_x_billidx b  on pd.skd_bid = b.billid and pd.c_id=b.c_id                  
             inner join vw_x_billidx bi on pd.xsd_bid = bi.billid and pd.c_id=bi.c_id
             where bi.billdate<b.billdate and b.billdate between @Begindate and @Enddate
                   and bi.billdate <@Begindate
                   and b.[CClass_ID]  like @szCClass_ID
                   and bi.[CClass_ID] like @szCClass_ID
                   and b.[Yclass_id]  like @szYclass_id
                   and bi.[Yclass_id]  like @szYclass_id
                   and b.billstates = 0 
                   and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
                   and b.billtype in (@nAID)    
          )b
  GROUP BY b.c_ID 


/*前期业务欠款余额*/
     insert into #tmpSK(C_ID,skje,flag)
     select c_id,sum(case when billtype in (11,13,21,24,25,54,211,221) then -jsye else jsye end) as skje ,'QQkSum' 
     from (select c_id,billtype,jsye,Y_id from billidx
            where billstates=0 and billdate<@BeginDate and billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
             )a
       left join Clients C ON a.C_id=c.client_id
       left join Company Y ON a.Y_id=Y.Company_id 
     where C.[Class_ID]  like @szCClass_ID
     and Y.[class_id]  like @szYclass_id
     group by c_id

/* 本期多账户  */
     SELECT AD.[c_ID],AD.[a_ID],A.Class_ID as AClass_id,A.[Name],
            SUM(case when @nAID in (23) or (@nAID in (15) and A.[Class_ID]=@ArID) then -AD.jdmoney  else AD.jdmoney end) AS skje,
            'B' as flag INTO #QD 
     FROM (select B.c_id,AD.a_id,B.billtype,AD.jdmoney,b.Y_id 
             from accountDetail AD
             left join billidx B ON AD.billid=b.billid
            where B.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
          )AD
     LEFT JOIN account a on a.account_id=AD.a_id
     LEFT JOIN Clients C on c.Client_id=AD.c_id
     LEFT JOIN Company Y ON Y.company_id=AD.Y_id  
     WHERE (a.class_ID like @CASH_ID  or  a.class_ID like @BANK_ID Or a.class_ID like @ArOrApID or a.class_id = '000001000012' or a.class_id = '000001000013')  
       and C.[Class_ID]  like @szCClass_ID
       and Y.[class_id]  like @szYclass_id
     group by AD.[c_ID],A.Class_ID,A.[Name],AD.[a_ID]
     order by AD.A_ID
 
  
/*本期收款、付款单*/
     insert into #tmpSK(C_ID,skje,flag)          
     select A.c_ID,(A.skje) as skje,'BQskd' as flag 
     from (select pd.c_ID,sum(case  when pd.billtype = 15 and A.Class_ID <> @ArID  then pd.jdMoney 
                             when pd.billtype = 23 or (pd.billtype = 15 and A.Class_ID = @ArID) then -pd.jdMoney end) as skje  
           from (select b.c_id,ad.a_id,b.billtype,ad.jdmoney,b.Y_id 
                   from  accountDetail ad
                   left join billidx b on ad.billid=b.billid
                  where  b.billdate  between @Begindate and @Enddate
                    and b.billstates = 0
                    and b.billtype in (@nAID)
                 )pd
            left join account a on pd.a_id=a.account_id
            left join clients c on pd.c_id=c.client_id
            left join company Y on Y.company_id=pd.Y_id
           where (A.Class_ID like @BANK_ID or A.Class_ID like @CASH_ID or A.Class_ID like @ArOrApID or a.class_id = '000001000012' or a.class_id = '000001000013')          
             and c.[Class_ID] like @szCClass_ID
	     and Y.[class_id]  like @szYclass_id                         
           group by pd.c_ID
           ) A
     left join #tmpSK sk on A.c_id = sk.c_ID  and  sk.flag = 'QSKsum'
             
        /*  GROUP BY A.C_ID*/

/*本期收款(付款)单上业务结算金额 */
   insert into #tmpSK(C_id,skje,flag)  
   select C_ID,sum(jsTotal) as skje,'BQJS' as flag
     from
       (select b.c_id,pd.jstotal
          from   
         (select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jsbdetail Group by skd_bid,xsd_bid,c_id 
          union ALL 
          select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jspdetail Group by skd_bid,xsd_bid,c_id
          ) pd
          inner join
          (select * from  vw_x_billidx  b
          where b.billdate  between @Begindate and @Enddate
          and b.billtype in (@nAID)
          and b.CClass_ID    like @szCClass_ID                         
          and b.[Yclass_id]  like @szYclass_id
          and b.billstates = 0 
          ) b  on pd.skd_bid = b.billid and pd.c_id=b.c_id
          inner join
          (select * from  vw_x_billidx bi 
          where bi.billdate between @Begindate and @Enddate
          and bi.billstates = 0
          and bi.CClass_ID like @szCClass_ID                         
          and bi.[Yclass_id]  like @szYclass_id
          and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
          )bi on pd.xsd_bid = bi.billid and pd.c_id=b.c_id 
          
       )bi
    group by bi.C_ID

/*本期收款(付款)单折让*/
     insert into #tmpSK (C_ID,skje,flag)
     select B.[c_ID],SUM(case @nAID when 23 then -AD.jdmoney else AD.jdmoney end) AS skje,'SKzr' as flag 
     FROM  (select * from vw_x_Adetail where aclass_ID= '000004000003000004')AD
     inner JOIN  ( select distinct b.billid,b.c_ID from 
                         (select skd_bid,xsd_bid from jsbdetail 
                          union 
                          select skd_bid,xsd_bid from jspdetail) pd
                          inner join vw_x_billidx b  on pd.skd_bid = b.billid
                          inner join vw_x_billidx bi on pd.xsd_bid = bi.billid 
                          where    b.billtype in (@nAID)
                          and  bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
                          and  b.billdate  between @Begindate and @Enddate
                          /*and bi.billdate between @Begindate and @Enddate*/
                          and b.[CClass_ID] like @szCClass_ID                         
                          and bi.[CClass_ID] like @szCClass_ID
                          and b.[Yclass_id]  like @szYclass_id
                          and bi.[Yclass_id]  like @szYclass_id 
                          and b.billstates = 0 and bi.billstates = 0        
                 ) B ON AD.billid = B.Billid
     group by B.[c_ID]              

/*本期业务收款合计  : 本期收款 - 前期收款 + 多账户    */
    INSERT INTO #tmpSK (C_ID,skje,flag)
    select E.Client_ID as C_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) + ISNULL(C.skje,0),'BSKsum' as flag
    from Clients E
    left join (select C_id,sum(skje) as skje from #tmpSK where flag = 'BQskd' group by c_ID) A  on E.Client_ID = A.C_ID
    left join (select C_id,sum(skje) as skje from #tmpSK where flag = 'QSKsum' group by c_ID)  B on E.Client_ID = B.C_ID
    left join (select C_id,sum(skje) as skje from #QD    where flag = 'B' group by c_ID)    C   on E.Client_ID = C.C_ID        
    where E.child_Number = 0 and E.deleted = 0
    and E.Client_ID in (select C_ID from #tmpSK where flag = 'BQskd' 
                        union
                        select C_ID from #QD    where flag = 'B')

/*本期销售(采购)金额合计  */
    select c_ID, BQxshj = ISNULL(SUM(CASE WHEN billtype in (11,13,21,24,25,54,211,221) then -ysmoney else ysmoney end),0) into #tmpBQXShj
    FROM (select c_id,ysmoney,billtype,Y_id  from billidx 
           where [billtype] in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))                           
             and billdate between @Begindate and @EndDate
             and billstates = 0
         )a
       left join Clients C ON C.Client_id=a.C_id
       left join Company Y ON Y.Company_id=a.Y_id
       where C.[Class_ID] like @szCClass_ID
       and Y.[class_id]  like @szYclass_id
    
    GROUP BY c_ID

/*本期业务|欠款金额 */
    insert into #tmpSK(C_id,skje,flag)
    select E.Client_ID as C_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) - ISNULL(C.skje,0),'BQQK' as flag
    from Clients E
    left join (select C_ID,SUM(BQxshj) as skje from #tmpBQXShj  group by C_ID) A on E.Client_ID = A.C_ID
    left join (select C_id,SUM(skje) as skje from #tmpSK where flag = 'BQJS' group by C_ID) B on E.Client_ID = B.C_ID
    left join (select C_id,SUM(skje) as skje from #QD    where flag = 'B' group by C_ID)    C on E.Client_ID = C.C_ID        
    where E.child_Number = 0 and E.deleted = 0
    and E.Client_ID in (select C_ID from #tmpSK where flag = 'BQskd' 
                        union
                        select C_id from #tmpBQXShj
                        union
                        select C_ID from #QD    where flag = 'B')    
                            

/* 各项现金银行科目合计 :  属于结算的收款(付款)单 + 本期多帐户 */
            
    SELECT [c_ID],[a_ID],AClass_ID,SUM(skje) as skje INTO #CaseBankSum   
    FROM (select ad.C_ID,ad.a_id,A.Class_ID as AClass_ID,
         /* update  yanrui 2012-09-28*/
         /* SUM(case when ad.billtype in (23,15) and A.Class_ID = @ArID then -ad.jdMoney */
         /*     else ad.jdMoney end) as skje */
          SUM(case when ad.billtype in (23)  then -ad.jdMoney  else ad.jdMoney end) as skje 
         /* yanrui end               */
          from (select b.billtype,ad.jdmoney,b.c_id,ad.a_id,b.Y_id 
                  from accountDetail ad inner join billidx b  ON ad.billid = b.billid
                  where b.billdate between  @BeginDate and @EndDate
                    and b.billstates = 0 and b.billtype in (@nAID)
               )ad 
          left join Clients C on ad.c_id=c.client_id
          left join company Y on ad.Y_id=Y.company_id
          left join account a on ad.a_id=a.account_id
          where (a.Class_ID like @BANK_ID or  a.Class_ID like @CASH_ID or a.Class_ID like @ArOrApID or a.class_id = '000001000012' or a.class_id = '000001000013')
            and c.[Class_ID] like @szCClass_ID
            and y.[class_id]  like @szYclass_id  
          group by ad.C_ID ,A.Class_ID,ad.a_id  
           UNION ALL              
           select [c_ID],[a_ID],AClass_ID,skje from #QD where flag = 'B'
         )A   /*多账户*/
    GROUP BY [c_ID],[a_ID],AClass_ID


/*合计收款*/

    insert into #tmpSK(C_ID,skje,flag)
    select c_ID,SUM(skje) as skje ,'SKsum' as flag from #tmpSK where flag = 'QSKsum' or  flag = 'BSKsum' GROUP BY C_ID



/*时间段内收款单折让合计 :属于结算的收款单*/

    insert into #tmpSK (C_id,skje,flag)
    select b.c_id,SUM(Case b.billtype when 23 then -AD.[jdmoney] else AD.[jdmoney] end) as skje,'SKzrH' as flag 
    from (select * from vw_x_Adetail where aclass_Id = '000004000003000004') ad 
    inner join vw_x_billidx b  on ad.billid = b.billid
    and b.billdate between @Begindate and @Enddate
    and b.[CClass_ID] like @szCClass_ID
    and b.[Yclass_id]  like @szYclass_id                           
    and b.billstates = 0 
    and b.billtype in (@nAID)
    inner join (select distinct a.skd_bid from
                    (select skd_bid,xsd_bid from jsbdetail union  select skd_bid,xsd_bid from jspdetail) a
                     inner join vw_x_billidx bi on a.xsd_bid = bi.billid
                     where bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
                     and bi.billstates = 0
                     and bi.billdate <= @Enddate
                     and bi.[CClass_ID] like @szCClass_ID
                     and bi.[Yclass_id]  like @szYclass_id  
               ) c  on b.billid = c.skd_bid          
    group by B.[c_ID]       

  
    set  @SQLScript = 'Create table ##ClientAccount
               (C_ID    INT,
                QQSKSum NUMERIC(25,8) default(0),
                QQkSum  NUMERIC(25,8) default(0),
                BQSKSum NUMERIC(25,8) default(0),
                BQSKdje NUMERIC(25,8) default(0),
                BQxshj  NUMERIC(25,8) default(0),
                BQJS    NUMERIC(25,8) default(0),
                BQQK    NUMERIC(25,8) default(0),   
                SKSum   NUMERIC(25,8) default(0),
                BQSKzr  NUMERIC(25,8) default(0),
                SKzrSUM NUMERIC(25,8) default(0),
                ssSUM   NUMERIC(25,8) default(0),
                QKSum   NUMERIC(25,8) default(0),'         
        
declare getClientA Cursor 
for
     SELECT CAST(account_ID AS VARCHAR) AS szField 
     FROM account WHERE child_number = 0 AND deleted = 0 
          AND (class_id LIKE @BANK_ID OR class_id LIKE @CASH_ID Or Class_ID like @ArOrApID or class_id = '000001000012' or class_id = '000001000013') ORDER BY Class_ID          
 
OPEN getClientA
 
FETCH NEXT FROM getClientA
INTO @szName 
       
WHILE @@FETCH_STATUS = 0
BEGIN
     SELECT @SQLScript = @SQLScript /*+'fa'+@szName+ ' NUMERIC(25,8)(8) default 0 ,'*/
                                      +'fb'+@szName+ ' NUMERIC(25,8) default 0 ,'
                                    /*+'fc'+@szName+ ' NUMERIC(25,8)(8) default 0 ,'        --                              */
                                      +'fh'+@szName+ ' NUMERIC(25,8) default 0 ,'                                         
FETCH NEXT FROM getClientA
INTO @szName/*,@szID*/
END 
 close getClientA 
 select  @SQLScript = left(@SQLScript,len(@SQLScript)-1)+')'
 exec (@SQLScript)
 
 insert into ##ClientAccount(C_ID)
 select A.[C_ID] FROM 
         (SELECT C_ID from #tmpBQXShj
                 UNION
                 SELECT C_ID FROM #tmpSK   
                 UNION 
                 SELECT C_ID FROM #CaseBankSum               
                  ) A       

 OPEN getClientA

         
 FETCH NEXT FROM getClientA
 INTO @szName/*,@szID*/
 
 WHILE @@FETCH_STATUS = 0
 BEGIN 
   set @SQLScript = 'update A set fb'+@szName+' = pd.skje from  ##ClientAccount A join #QD pd on A.[c_ID] = pd.[c_ID] and PD.[flag] = ''B'' and pd.[a_ID] = '+@szName
   Exec(@SQLScript) 

   set @SQLScript = 'update A set fh'+@szName+' = pd.skje from  ##ClientAccount A join (select c_ID,sum(skje) as skje ,a_id from #CaseBankSum group by c_ID,a_ID) pd on A.[c_ID] = pd.[c_ID] and pd.[a_ID] = '+@szName
        
   Exec(@SQLScript)

   FETCH NEXT FROM getClientA
   INTO @szName/*,@szID*/
 END
 
 CLOSE getClientA 
 DEALLOCATE getClientA

         update A  set QQSKSum = B.skje from ##ClientAccount A join  #tmpSK   B ON A.c_ID = B.c_ID where B.flag = 'QSKsum'
         update A  set QQkSum  = B.skje from ##ClientAccount A join  #tmpSK   B ON A.c_ID = B.c_ID where B.flag = 'QQkSum'

         update A  set BQSKSum = B.skje from ##ClientAccount A join  #tmpSK   B ON A.c_ID = B.c_ID where B.flag = 'BSKsum'
         update A  set BQSKdje = B.skje from ##ClientAccount A  
                                       join #tmpSK  B ON A.c_ID = B.c_ID and B.flag = 'BQskd'
         /* left join #tmpSK  C ON A.c_ID = C.c_ID and C.flag = 'SKzr'*/

	 update A  set BQxshj  = B.BQxshj  from ##ClientAccount A join  #tmpBQXShj B ON A.c_ID = B.c_ID
	 update A  set BQQK    = B.skje    from ##ClientAccount A join  #tmpSK     B ON A.c_ID = B.c_ID where B.flag = 'BQQK'
	 update A  set SKSum   = B.skje    from ##ClientAccount A join  #tmpSK     B ON A.c_ID = B.c_ID where B.flag = 'SKsum'
	 update A  set BQSKzr  = B.skje    from ##ClientAccount A join  #tmpSK     B ON A.c_ID = B.c_ID where B.flag = 'SKzr'
	 update A  set SKzrSUM = B.skje    from ##ClientAccount A join  #tmpSK   B ON A.c_ID = B.c_ID where B.flag = 'SKzrH'      
	 update A  set BQJS = B.skje       from ##ClientAccount A join  #tmpSK   B ON A.c_ID = B.c_ID where B.flag = 'BQJS'      



        /*欠款合计 = 前期欠合计+本期欠款合计*/
         update A set  QKSum = ISNULL(QQkSum,0) + ISNULL(BQQK,0) FROM ##ClientAccount A     

         SELECT 0 as Serialno, E.[Client_ID],E.[Serial_Number],[Name],E.[RegionName],PD.* 
         FROM VW_CLIENTS E           
         JOIN ##ClientAccount PD ON E.Client_ID = PD.c_ID
         WHERE (E.[Child_Number] = 0) 
           AND E.[Class_ID] LIKE @szCClass_ID
           AND E.[Class_ID] IN (SELECT Class_ID FROM dbo.AuthorizeClients(@OperatorID))
           AND (@ClientTable=0 OR ((E.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and E.class_id like u.psc_id+'%'))))

        SET NOCOUNT OFF
        GOTO SUCC

    
END

SUCC: drop table #QD 
        drop table #tmpSK
        drop table #tmpBQXShj
        drop table #CaseBankSum
        drop table #SKtmp
 drop table ##ClientAccount
        RETURN 0
GO
