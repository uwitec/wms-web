
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-12-20*/
/* Description:	拣货单生成打印开始页 同时写入发货货位        */
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_Y_jhwriteprintNo]
(
  @billid int,
  @locID  int
)
AS
BEGIN
CREATE TABLE #t1
 (	
    Atype  varchar(10),
    order_id     INT,
	sendC_id      INT,
    WholeQty     INT,
    PartQty      INT,
    billid       INT,
    xh           Int IDENTITY(1,1) NOT NULL
  )
  insert into #t1(Atype,order_id,sendC_id,WholeQty,PartQty,billid)
  select distinct 'A',order_id,sendC_id,WholeQty,PartQty,billid
  from billdraftidx  where billtype=254 and order_id=@billid
  order by billid 
  /*修改总计*/
  update #t1 set sendC_id=d.sendC_id
  from #t1 c,(select order_id,sum(WholeQty) as sendC_id from #t1 group by order_id ) d
  where c.order_id=d.order_id
  /*-修改每张拣货单打印开始页数    */
  declare @iFor  int 
  declare @col   int
  declare curAlter scroll cursor for
  select xh from #t1
  open curAlter
  set @iFor = 0
  while @iFor < @@cursor_rows
  begin
    fetch next from curAlter into @col
    if  @iFor=0   
    begin
      /*第一行*/
      update #t1 set PartQty=1 where xh=@col
    end
    else
    begin
     update #t1 set PartQty=(b.WholeQty+b.PartQty) 
     from #t1 a,(select WholeQty,PartQty,xh from #t1 where xh=(@col-1)) b
     where a.xh=(b.xh+1)     
    end
    set @iFor = @iFor + 1 
  end
  DEALLOCATE curAlter
  /*-修改数据*/
  update billdraftidx set sendC_id=b.sendC_id,PartQty=b.PartQty
  from billdraftidx a,#t1 b
  where a.billid=b.billid
  /*-------------------------写入发货货位ID*/
  update billidx set VIPCardID=y.locid
  from billidx x,(select @locID as locid,InvoiceNO from billdraftidx where 
  billtype=254 and order_id=@billid) y
  where x.GUID=y.InvoiceNO
  /*----拣货单 备注3 写入 发货区域货位 便于装箱单打印*/
  update billdraftidx set B_CustomName3=(select loc_name from location where loc_id=@locID)
  where billtype=254 and order_id=@billid
  
  
  
  
  drop table  #t1
END
GO
