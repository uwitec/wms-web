/************************************************************
--过程名称：Ts_Y_InYbJs
--功能    ：结算数据写入本地库
--创建人  ：YANRUI 
--创建时间：2013-12-26
------上传成功后需要回写的项目
交易流水号|统筹支付|帐户支付|公务员补助|现金支付|大额理赔金额|历史起付线公务员返还|
帐户余额|单病种定点医疗机构垫支|民政救助金额|民政救助门诊余额|耐多药项目支付金额|
一般诊疗支付数|神华救助基金支付数|本年统筹支付累计|本年大额支付累计|特病起付线支付累计|
耐多药项目累计|本年民政救助住院支付累计|中心结算时间|
支付扩展预留1|支付扩展预留2|累计扩展预留1|累计扩展预留2
  a10---a33 
**************************************************************/
CREATE	  PROCEDURE [dbo].[Ts_Y_InYbJs]
(
 @A0  varchar(18),
 @A1  varchar(3),
 @A2  varchar(10),
 @A3  varchar(20),
 @A4  varchar(3),
 @A5  varchar(30),
 @A6  varchar(20),
 @A7  varchar(10),
 @A8  varchar(3),
 @A9  varchar(10),
 @A10 varchar(20),
 @A11 varchar(10),
 @A12 varchar(10),
 @A13 varchar(10),
 @A14 varchar(10),
 @A15 varchar(10),
 @A16 varchar(10),
 @A17 varchar(10),
 @A18 varchar(10),
 @A19 varchar(10),
 @A20 varchar(10),
 @A21 varchar(10),
 @A22 varchar(10),
 @A23 varchar(10),
 @A24 varchar(10),
 @A25 varchar(10),
 @A26 varchar(10),
 @A27 varchar(10),
 @A28 varchar(10),
 @A29 varchar(30),
 @A30 varchar(10),
 @A31 varchar(10),
 @A32 varchar(10),
 @A33 varchar(10),
 @Aguid varchar(50),
 @Y_ID  int
)
as
 declare @cts int
 declare @bGuid varchar(50)
 set @bGuid=
 (
  select  CAST(a.GUID AS varchar(50)) 
  from retailbillidx a, RetailBill b
  where a.billid=b.bill_id and b.RowGuid=CAST(@Aguid AS uniqueidentifier) 
  )
 set @cts=(select count(1) from YbJSinfo where A0=@A0 and Y_ID=@Y_ID )	
 if  @cts<=0  
 begin
    insert into YbJSinfo
    (A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A20,A21,A22,A23,A24,A25,A26,
     A27,A28,A29,A30,A31,A32,A33,Aguid,Y_ID)
	 VALUES
    (@A0,@A1,@A2,@A3,@A4,@A5,@A6,@A7,@A8,@A9,@A10,@A11,@A12,@A13,@A14,@A15,@A16,@A17,@A18,@A19,@A20,
    @A21,@A22,@A23,@A24,@A25,@A26,@A27,@A28,@A29,@A30,@A31,@A32,@A33,@bGuid,@Y_ID)  
 end
  else
 begin
  update YbJSinfo
    set   
    A10=@A10,A11=@A11,A12=@A12,A13=@A13,A14=@A14,A15=@A15,A16=@A16,
    A17=@A17,A18=@A18,A19=@A19,A20=@A20,A21=@A22,
    A23=@A23,A24=@A24,A25=@A25,A26=@A26,A27=@A27,A28=@A28,A29=@A29,
    A30=@A30,A31=@A31,A32=@A32,A33=@A33
   where A0=@A0 and Y_ID=@Y_ID
   
 end	            
 /**/
GO
