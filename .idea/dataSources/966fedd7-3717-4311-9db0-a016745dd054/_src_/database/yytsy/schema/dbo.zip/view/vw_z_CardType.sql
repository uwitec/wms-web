
create view vw_z_CardType as

SELECT ct_id, Code, Name, case ct_Type when 0 then '会员卡' when 1 then '打折卡' when 2 then '积分卡' when 3 then '储值卡' end as ct_Type, 
      case isBank when 0 then'' when 1 then '√' end as isBank,case isIntegral when 0 then '' when 1 then '√' end as isIntegral, 
      PriceMode, cast(Discount as numeric(25,8))Discount, cast(IntegralMoney as numeric(25,8))IntegralMoney, isYeIntegral, isSpecialPriceIntegral, 
      isPromotionIntegral, isMoneyUp, cast(UpMoney as numeric(25,8))UpMoney, MoneyUpCT_id, isIntegralUp, cast(UpIntegral as numeric(25,8))UpIntegral, 
      IntegeralUpCT_id, cast(UpDecIntegral as numeric(25,8))UpDecIntegral, Comment, 
      (case when ValidDate='' then '' else CONVERT(varchar(100), ValidDate, 23) end) ValidDate,
      case isDiscount when 0 then '' when 1 then '√' end AS isDiscount,
      case IsCompanyCheck when 0 then '' when 1 then '√' end AS ControlCompay      /*暂时返回一个值,还需要等表结构设计*/
FROM dbo.VipCardType
where deleted=0
GO
