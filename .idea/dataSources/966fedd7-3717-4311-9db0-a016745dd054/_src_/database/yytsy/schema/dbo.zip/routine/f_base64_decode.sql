
CREATE FUNCTION [dbo].[f_base64_decode]
(  @input varchar(8000) )
RETURNS varbinary(8000) 
AS 
BEGIN  
	DECLARE  @base64 char(64),  
	@pos int,  
	@len int,  
	@output varbinary(8000);   
	SELECT  @base64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',  
	@pos = 1,  
	@len = LEN(@input),  
	@output = 0x;    
	IF @input = ''  
	RETURN 0x;    
	IF @len % 4 > 0 OR @len IS NULL  
	RETURN NULL;   
	WHILE @pos < @len  
	BEGIN  
		SELECT  @output = @output  + CONVERT(binary(1), ((v1 & 63) * 4 ) | ((v2 & 48) / 16))  + CONVERT(binary(1), ((v2 & 15) * 16) | ((v3 & 60) / 4 ))  + CONVERT(binary(1), ((v3 & 3 ) * 64) | ((v4 & 63) / 1 )),  @pos = @pos + 4  
		FROM(  SELECT  v1 = CHARINDEX(SUBSTRING(@input, @pos + 0, 1) COLLATE Chinese_PRC_BIN, @base64) - 1,  v2 = CHARINDEX(SUBSTRING(@input, @pos + 1, 1) COLLATE Chinese_PRC_BIN, @base64) - 1,  v3 = CHARINDEX(SUBSTRING(@input, @pos + 2, 1) COLLATE Chinese_PRC_BIN, @base64) - 1,  v4 = CHARINDEX(SUBSTRING(@input, @pos + 3, 1) COLLATE Chinese_PRC_BIN, @base64) - 1   )A;  
	END;   
	RETURN(SUBSTRING(@output, 1, @len / 4 * 3 - 3 + CHARINDEX('=', RIGHT(@input, 2) + '='))); 
END
GO
