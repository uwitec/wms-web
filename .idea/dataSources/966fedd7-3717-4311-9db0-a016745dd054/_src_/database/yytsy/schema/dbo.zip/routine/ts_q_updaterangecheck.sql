
Create procedure [dbo].[ts_q_updaterangecheck]
(@flag int=0)
as
/*flag:1 次数，2 月份，3 全部*/
set nocount on

declare @rowcounts int,@currentrow int,@c_id int,@r_id int,@cdt_time int,@cdt_type int,@cdt_date datetime,@enddate datetime
declare @nowdatetime datetime
select @nowdatetime=getdate()
/*---------------次数控制*/
if @flag=1 or @flag=3
begin 
  select identity(int,1,1) xh,r_id,c_id,cdt_time into #temp_time from rangeconditionbm where cdt_type=1
  if exists(select xh from #temp_time)
  begin
    select @rowcounts=count(xh) from #temp_time
    select @currentrow=1
    while @currentrow <= @rowcounts
    begin
      select @c_id=c_id,@r_id=r_id,@cdt_time=cdt_time from #temp_time where xh=@currentrow
      if @cdt_time=0
         delete customCategoryMapping where baseinfo_id=@c_id and category_id=@r_id
      if @cdt_time>0
         exec dbo.Ts_L_RangeCheck @c_id,@r_id,0
      select @currentrow=@currentrow+1
    end
  end
end
/*-----------------月份、季节控制*/
if @flag=2 or @flag=3
begin
  select identity(int,1,1) xh,r_id,c_id,cdt_date,cdt_type into #temp_date from rangeconditionbm where cdt_type in(2,3)
  if exists(select xh from #temp_date)
  begin
    select @rowcounts=count(xh) from #temp_date
    select @currentrow=1
    while @currentrow <= @rowcounts
    begin
      select @c_id=c_id,@r_id=r_id,@cdt_type=cdt_type,@cdt_date=cdt_date from #temp_date where xh=@currentrow
      if @cdt_type=2 and datediff(m,@cdt_date,@nowdatetime)=0 and @nowdatetime>=@cdt_date
        exec dbo.Ts_L_RangeCheck @c_id,@r_id,0
      if @cdt_type=2 and (datediff(m,@cdt_date,@nowdatetime)<>0 or @nowdatetime<@cdt_date)
        delete rangecheck where c_id=@c_id and r_id=@r_id and CType = 0
      if @cdt_type=3 and datediff(q,@cdt_date,@nowdatetime)=0 and @nowdatetime>=@cdt_date
        exec dbo.Ts_L_RangeCheck @c_id,@r_id,0
      if @cdt_type=3 and (datediff(q,@cdt_date,@nowdatetime)<>0 or @nowdatetime<@cdt_date)
        delete rangecheck where c_id=@c_id and r_id=@r_id and CType = 0
      select @currentrow=@currentrow+1
    end
  if exists(select sysvalue from sysconfig where sysname='RangeUpdateTime')
    update sysconfig set sysvalue=convert(varchar(50),@nowdatetime,112) where sysname='RangeUpdateTime'
  else
    insert into sysconfig (sysname,sysvalue,comment,sysflag)
    values ('RangeUpdateTime',convert(varchar(50),@nowdatetime,112),'记录rangecheck表更新时间',0)
  end
end
GO
