
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-12-15*/
/* Description:	发货量、复核量统计*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepSendAndCheck]
	@BeginDate		datetime,
	@EndDate		datetime
AS
BEGIN
	SET NOCOUNT ON;

SELECT     emp_id, name, position, send, review, comment
FROM         (SELECT     e.emp_id, e.name, '发货员' AS position, COUNT(b.p_id) AS send, 0 AS review, e.comment
                       FROM          dbo.billidx AS i INNER JOIN
                                              dbo.salemanagebill AS b ON i.billid = b.bill_id INNER JOIN
                                              dbo.employees AS e ON i.e_id = e.emp_id
                       WHERE      (b.p_id > 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND (i.billtype IN (10, 212))
                       GROUP BY e.emp_id, e.name, e.comment) AS s
union all
SELECT     emp_id, name, position, send, review, comment
FROM         (SELECT     e.emp_id, e.name, '复核员' AS position, 0 AS send, COUNT(b.p_id) AS review, e.comment
FROM         dbo.checkidx AS c INNER JOIN
                      dbo.employees AS e ON c.checkman = e.emp_id INNER JOIN
                      dbo.salemanagebill AS b ON c.billid = b.bill_id INNER JOIN
                      dbo.billidx AS i ON c.billid = i.billid
WHERE     (b.p_id > 0) AND (i.billtype IN (10, 212)) AND (c.checkdate BETWEEN @BeginDate AND @EndDate)
GROUP BY e.emp_id, e.name, e.comment) AS r
END
GO
