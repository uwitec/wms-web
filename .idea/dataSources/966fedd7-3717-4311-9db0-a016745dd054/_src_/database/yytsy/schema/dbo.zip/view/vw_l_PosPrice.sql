
CREATE VIEW dbo.vw_l_PosPrice
AS
SELECT ISNULL(dbo.unit.name, '') AS UnitName, dbo.PosPrice.*,
       ISNULL(Y.Class_id,'') as YClass_ID,
       Isnull(Y.[name],'') as Yname
FROM dbo.PosPrice LEFT OUTER JOIN
      dbo.unit ON dbo.PosPrice.u_id = dbo.unit.unit_id
     lEFT OUTER JOIN 
      Company Y ON Y.Company_id=PosPrice.Y_id
GO
