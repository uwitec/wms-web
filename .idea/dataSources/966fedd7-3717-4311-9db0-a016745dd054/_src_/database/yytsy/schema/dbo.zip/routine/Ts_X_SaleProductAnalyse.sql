



/******************************************
滞销商品和畅销商品分析

算法：先算出以各种不同算法为基数的统计的临时表中，其中包括了时间之前，之中和之后的数量，
[BQuantity] 统计之前的数量
[Quantity]  统计之间的数量
[EQuantity] 统计之后的数量
再从临时表来统计数据

@StoredProcMode       方式
  ‘S’=0 滞销商品分析
  ‘U’=1 畅销商品分析
统计畅销时，销售数量为0的不进行统计
统计滞销时，销售基数为0的不进行统计

@lStorageID    仓库ID号
@lLocationID   货位ID号

@BeginDate  开始时间
@EndDate     结束时间

最后的修改日期 2003-11-10

********************************************/

CREATE PROCEDURE [Ts_X_SaleProductAnalyse]
( @InStoreDate DateTime=0,
  @nP_ID       INT=0,
  @nS_ID       INT=0,
  @BeginDate   DateTime=0,
  @EndDate     DateTime=0,
  @nYClassID   varchar(50)='',
  @nloginEID   int=0,
  @isaddDate   int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
/*with encryption*/

AS 
/*Params Ini begin*/
if @InStoreDate is null  SET @InStoreDate = 0
if @nP_ID is null  SET @nP_ID = 0
if @nS_ID is null  SET @nS_ID = 0
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/

 /*SET NOCOUNT ON*/

  DECLARE @SQLScript VARCHAR(8000), @SQLScript2 VARCHAR(8000),@szsql varchar(1000)
  DECLARE @szProduct VARCHAR(500)
  DECLARE @szStorage VARCHAR(500)
  DECLARE @szValidDay VARCHAR(500)
  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),
  @nYid int

  Declare @FilteCompany varchar(8000)
                                                                        
  select  @FilteCompany=''

 exec Ts_L_SearchUserauthorize @nLoginEid,0,@ClientTable out,1,@Companytable out,0,@employeestable out,0,@storetable out /*调用后，要在最后释放临时表*/

 IF ISNULL(@Companytable,'')<>''    set @FilteCompany=' and ((PD.YClass_ID='''') or (exists(select YCID from '+@Companytable+' where PD.YClass_ID like YCID+''%''))) '/*只用于查询YProductDetail*/
 If @nYClassID='' Set @nYid = 2 else select @nYid=company_id  from  company where class_id = @nYClassID 
 
  SELECT @szProduct = ''
  SELECT @szStorage = ''
  SELECT @szValidDay = ''

  IF @nP_ID<>0 SELECT @szProduct=' AND P.[Product_ID]=' + CAST(@nP_ID AS VARCHAR)
  IF @nS_ID<>0 SELECT @szStorage=' AND [S_ID]='         + CAST(@nS_ID AS VARCHAR)
  SELECT @szValidDay = ' AND [InStoretime]<'+CHAR(39)+CONVERT(VARCHAR(10), @InStoreDate, 20)+CHAR(39)
  /*zjx--tfs46798--20170330--因为现在不存在yproductdetail表，所当门店版查询@isaddDate=1 的时候，修改成0，*/
  /*跟选择总部机构查询进入同一段*/
  if  @isaddDate=1  set @isaddDate=0
IF @isaddDate=1 
BEGIN
  SELECT @SQLScript='
   SELECT P.[Product_ID], MAX(P.[Code]) AS [Code], MAX(P.[Name]) AS [Name], '
     +' MAX(P.[Alias]) AS [Alias], MAX(P.[Standard]) AS [Standard], '
     +' MAX(P.[Modal]) AS [Modal],MAX(P.[Makearea]) AS [Makearea],ISNULL(MAX(VP.e_name),'''') as e_name,ISNULL(MAX(VP.C_Name),'''') as C_Name, '
     +' MAX(P.[PermitCode]) AS [PermitCode],MAX(P.[Trademark]) AS [Trademark],'
     +' MAX(P.[Medtype]) AS [Medtype], p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,'
     +' p.Custompro3,p.Custompro4,p.Custompro5,'

     +' SUM(ISNULL(SHI.[Quantity]    ,0.0))  AS [IniQuantity],'
     +' SUM(ISNULL(SHI.[CostTotal]   ,0.0))  AS [IniCostTotal],'

     +' SUM(ISNULL(SH.[Quantity]     ,0.0))  AS [CurQuantity],'
     +' SUM(ISNULL(SH.[CostTotal]    ,0.0))  AS [CurCostTotal],'

     +' SUM(ISNULL(SB.[BBQuantity]   ,0.0))  AS [BBQuantity],'
     +' SUM(ISNULL(SB.[BBCostTotal]  ,0.0))  AS [BBCostTotal],'
     +' SUM(ISNULL(SB.[SBQuantity]   ,0.0))  AS [SBQuantity],'
     +' SUM(ISNULL(SB.[SBCostTotal]  ,0.0))  AS [SBCostTotal],'
     +' SUM(ISNULL(SB.[BBSendQTY]    ,0.0))  AS [BBSendQTY],'
     +' SUM(ISNULL(SB.[SBSendQTY]    ,0.0))  AS [SBSendQTY],'

     +' SUM(ISNULL(OB.[OBQuantity]   ,0.0))  AS [OBQuantity],'
     +' SUM(ISNULL(OB.[OBCostTotal]  ,0.0))  AS [OBCostTotal],'

     +' SUM(ISNULL(SB.[BNQuantity]   ,0.0))  AS [BNQuantity],'
     +' SUM(ISNULL(SB.[BNCostTotal]  ,0.0))  AS [BNCostTotal],'
     +' SUM(ISNULL(SB.[SNQuantity]   ,0.0))  AS [SNQuantity],'
     +' SUM(ISNULL(SB.[SNCostTotal]  ,0.0))  AS [SNCostTotal],'
     +' SUM(ISNULL(SB.[BNSendQTY]    ,0.0))  AS [BNSendQTY],'
     +' SUM(ISNULL(SB.[SNSendQTY]    ,0.0))  AS [SNSendQTY],'

     +' SUM(ISNULL(OB.[ONQuantity]   ,0.0))  AS [ONQuantity],'
     +' SUM(ISNULL(OB.[ONCostTotal]  ,0.0))  AS [ONCostTotal],'

     +' SUM(ISNULL(SB.[BEQuantity]   ,0.0))  AS [BEQuantity],'
     +' SUM(ISNULL(SB.[BECostTotal]  ,0.0))  AS [BECostTotal],'
     +' SUM(ISNULL(SB.[SEQuantity]   ,0.0))  AS [SEQuantity],'
     +' SUM(ISNULL(SB.[SECostTotal]  ,0.0))  AS [SECostTotal],'
     +' SUM(ISNULL(SB.[BESendQTY]    ,0.0))  AS [BESendQTY],'
     +' SUM(ISNULL(SB.[SESendQTY]    ,0.0))  AS [SESendQTY],'

     +' SUM(ISNULL(OB.[OEQuantity]   ,0.0))  AS [OEQuantity],'
     +' SUM(ISNULL(OB.[OECostTotal]  ,0.0))  AS [OECostTotal]'
     +' FROM VW_X_Products P'

     +' LEFT JOIN '
     +'  (SELECT [P_ID], SUM([Quantity]) AS [Quantity], SUM([CostTotal]) AS [CostTotal] ' 
     +'   FROM VW_X_StorehouseIni '
     +'   WHERE [P_ID] >0 '+ @szStorage +''
     +'   GROUP BY [P_ID] ) SHI'
     +' ON P.[Product_ID]=SHI.[P_ID]'

     +' LEFT JOIN '
     +'  (SELECT [P_ID], SUM([Quantity]) AS [Quantity], SUM([CostTotal]) AS [CostTotal] ' 
     +'   FROM VW_X_Storehouse '
     +'   WHERE [P_ID]>0 '+ @szStorage + @szValidDay + ''
     +'  GROUP BY [P_ID ]) SH '
     +' ON P.[Product_ID]=SH.[P_ID]'
set  @SQLScript2=
      ' LEFT JOIN '
     +'  (SELECT  SQ.[BBQuantity],SQ.[SBQuantity],SQ.[BNQuantity],SQ.[SNQuantity],SQ.[BEQuantity],SQ.[SEQuantity],SE.* FROM '
     +'      (SELECT PD.[P_ID], '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,220,221) and  PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+' THEN PD.[Quantity] WHEN PD.[BillType] IN (122) and  PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN -PD.[Quantity] ELSE 0 END) AS [BBQuantity], '
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,210,211) and  PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN -PD.[Quantity]  ELSE 0 END) AS [SBQuantity], '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,220,221) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[Quantity]  WHEN PD.[BillType] IN (122) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN -PD.[Quantity]   ELSE 0 END) AS [BNQuantity], '
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,210,211) and  PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'  THEN -PD.[Quantity]  ELSE 0 END) AS [SNQuantity],  '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,220,221) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39) +' THEN PD.[Quantity] WHEN PD.[BillType] IN (122) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39) +' THEN -PD.[Quantity]  ELSE 0 END) AS [BEQuantity], '
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,210,211) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+ ' THEN -PD.[Quantity]  ELSE 0 END) AS [SEQuantity] '
     +'       FROM  vw_L_YProductdetail PD'
     +'       WHERE PD.aoid in (0,5)  AND PD.[BillStates]=''0'' AND ('''+@nYClassID+'''='''' or PD.YClass_id like '''+@nYClassID+'%'')'+@FilteCompany
     +'       and PD.billtype in (10,11,12,13,32,112, 20,21,35,122,53,54,212,222)  GROUP BY PD.[P_ID]) SQ,'

     +'      (SELECT PD.[P_ID],'
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'         THEN PD.[SendQTY]       WHEN PD.[BillType] IN (122) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN -PD.[SendQTY]   ELSE 0 END) AS [BBSendQTY], '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'         THEN PD.[SendCostTotal] WHEN PD.[BillType] IN (122) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN -PD.[SendCostTotal]  ELSE 0 END) AS [BBCostTotal],'
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) and  PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+' THEN -PD.[SendQTY]  ELSE 0 END) AS [SBSendQTY],'
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) and  PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+' THEN -PD.[SendCostTotal] ELSE 0 END) AS [SBCostTotal],'
  
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[SendQTY] WHEN PD.[BillType] IN (122) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN -PD.[SendQTY]   ELSE 0 END) AS [BNSendQTY], '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[SendCostTotal] WHEN PD.[BillType] IN (122) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN -PD.[SendCostTotal] ELSE 0 END) AS [BNCostTotal],'
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'     THEN -PD.[SendQTY]  ELSE 0 END) AS [SNSendQTY], ' 
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'     THEN -PD.[SendCostTotal] ELSE 0 END) AS [SNCostTotal],'

     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'                 THEN PD.[SendQTY]       WHEN PD.[BillType] IN (122) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'               THEN -PD.[SendQTY]   ELSE 0 END) AS [BESendQTY], '
     +'          SUM(CASE WHEN PD.[BillType] IN (20,21,35,222) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'                 THEN PD.[SendCostTotal] WHEN PD.[BillType] IN (122) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'  THEN -PD.[SendCostTotal] ELSE 0 END) AS [BECostTotal],'
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'        THEN -PD.[SendQTY]  ELSE 0 END) AS [SESendQTY], '
     +'          SUM(CASE WHEN PD.[BillType] IN (10,11,12,13,32,112,53,54,212) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'        THEN -PD.[SendCostTotal] ELSE 0 END) AS [SECostTotal]'

     +'        FROM vw_L_YProductdetail PD'
     +'        WHERE PD.aoid in (0,5) AND PD.[BillStates]=''0''' + @szStorage+' AND ('''+@nYClassID+'''='''' or PD.YCLass_id like '''+@nYclassID+'%'')'+@FilteCompany
     +'        and PD.billtype in (10,11,12,13,32,112, 20,21,35,122,53,54,212,222)  GROUP BY PD.[P_ID])SE'
     +'        WHERE SQ.[P_ID]=SE.[P_ID])SB '   
     +' ON P.[Product_ID]=SB.[P_ID]'

    
     + ' LEFT JOIN '
     +'  (SELECT PD.[P_ID], '

     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN PD.[Quantity]   ELSE 0 END) AS [OBQuantity],'
     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and PD.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN PD.[CostTotal]  ELSE 0 END) AS [OBCostTotal],'

     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[Quantity]   ELSE 0 END) AS [ONQuantity],'
     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and PD.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[CostTotal]  ELSE 0 END) AS [ONCostTotal],'

     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+' THEN PD.[Quantity]   ELSE 0 END) AS [OEQuantity],'
     +'      SUM(CASE WHEN PD.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) AND PD.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+' THEN PD.[CostTotal]  ELSE 0 END) AS [OECostTotal]'

     +'    FROM vw_L_YProductdetail PD'
     +'    WHERE PD.[BillStates]=''0'' and PD.storetype=0 '+ @szStorage
     +'    and PD.billtype  not in (150,151,155,160,161,165)  GROUP BY PD.[P_ID])OB'
     +' ON OB.[P_ID]=P.[Product_ID]'
     +' LEFT JOIN vw_productbalance VP ON P.[Product_ID]=VP.[p_id]'
   +' WHERE P.[Child_Number]=0 AND P.[Deleted]<>1 and VP.Y_id = '+convert(varchar(10),@nYid) +' '+ @szProduct
   +' GROUP BY P.[Product_ID],p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5 ORDER BY P.[Product_ID] '
  
END
ELSE
BEGIN
  SELECT @SQLScript='
   SELECT P.[Product_ID], MAX(P.[Code]) AS [Code], MAX(P.[Name]) AS [Name], '
     +' MAX(P.[Alias]) AS [Alias], MAX(P.[Standard]) AS [Standard], '
     +' MAX(P.[Modal]) AS [Modal],MAX(P.[Makearea]) AS [Makearea],ISNULL(MAX(VP.e_name),'''') as  e_name,ISNULL(MAX(VP.C_Name),'''') as C_Name, '
     +' MAX(P.[PermitCode]) AS [PermitCode],MAX(P.[Trademark]) AS [Trademark],'
     +' MAX(P.[Medtype]) AS [Medtype], p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,'
     +' p.Custompro3,p.Custompro4,p.Custompro5,'

     +' SUM(ISNULL(SHI.[Quantity]    ,0.0))  AS [IniQuantity],'
     +' SUM(ISNULL(SHI.[CostTotal]   ,0.0))  AS [IniCostTotal],'

     +' SUM(ISNULL(SH.[Quantity]     ,0.0))  AS [CurQuantity],'
     +' SUM(ISNULL(SH.[CostTotal]    ,0.0))  AS [CurCostTotal],'
     +' SUM(ISNULL(SH.[CostTaxTotal] ,0.0))  AS [CurCostTaxTotal],'
     
     +' SUM(ISNULL(SB.[BBQuantity]   ,0.0))  AS [BBQuantity],'
     +' SUM(ISNULL(SB.[BBCostTotal]  ,0.0))  AS [BBCostTotal],'
     +' SUM(ISNULL(SB.[SBQuantity]   ,0.0))  AS [SBQuantity],'
     +' SUM(ISNULL(SB.[SBCostTotal]  ,0.0))  AS [SBCostTotal],'
     +' SUM(ISNULL(SB.[BBSendQTY]    ,0.0))  AS [BBSendQTY],'
     +' SUM(ISNULL(SB.[SBSendQTY]    ,0.0))  AS [SBSendQTY],'

     +' SUM(ISNULL(OB.[OBQuantity]   ,0.0))  AS [OBQuantity],'
     +' SUM(ISNULL(OB.[OBCostTotal]  ,0.0))  AS [OBCostTotal],'

     +' SUM(ISNULL(SB.[BNQuantity]   ,0.0))  AS [BNQuantity],'
     +' SUM(ISNULL(SB.[BNCostTotal]  ,0.0))  AS [BNCostTotal],'
     +' SUM(ISNULL(SB.[SNQuantity]   ,0.0))  AS [SNQuantity],'
     +' SUM(ISNULL(SB.[SNCostTotal]  ,0.0))  AS [SNCostTotal],'
     +' SUM(ISNULL(SB.[BNSendQTY]    ,0.0))  AS [BNSendQTY],'
     +' SUM(ISNULL(SB.[SNSendQTY]    ,0.0))  AS [SNSendQTY],'

     +' SUM(ISNULL(OB.[ONQuantity]   ,0.0))  AS [ONQuantity],'
     +' SUM(ISNULL(OB.[ONCostTotal]  ,0.0))  AS [ONCostTotal],'

     +' SUM(ISNULL(SB.[BEQuantity]   ,0.0))  AS [BEQuantity],'
     +' SUM(ISNULL(SB.[BECostTotal]  ,0.0))  AS [BECostTotal],'
     +' SUM(ISNULL(SB.[SEQuantity]   ,0.0))  AS [SEQuantity],'
     +' SUM(ISNULL(SB.[SECostTotal]  ,0.0))  AS [SECostTotal],'
     +' SUM(ISNULL(SB.[BESendQTY]    ,0.0))  AS [BESendQTY],'
     +' SUM(ISNULL(SB.[SESendQTY]    ,0.0))  AS [SESendQTY],'

     +' SUM(ISNULL(OB.[OEQuantity]   ,0.0))  AS [OEQuantity],'
     +' SUM(ISNULL(OB.[OECostTotal]  ,0.0))  AS [OECostTotal]'
     +' FROM VW_X_Products P'

     +' LEFT JOIN '
     +'  (SELECT [P_ID], SUM([Quantity]) AS [Quantity], SUM([CostTotal]) AS [CostTotal] ' 
     +'   FROM VW_X_StorehouseIni '
     +'   WHERE [P_ID] > 0'+ @szStorage +' AND ('+convert(varchar(10),@nYid)+' = 0 OR Y_ID = '+convert(varchar(10),@nYid)
     +')   GROUP BY [P_ID] ) SHI'
     +' ON P.[Product_ID]=SHI.[P_ID]'

     +' LEFT JOIN '
     +'  (SELECT [P_ID], SUM([Quantity]) AS [Quantity], SUM([CostTotal]) AS [CostTotal],SUM([CostTaxTotal]) as CostTaxTotal  ' 
     +'   FROM VW_X_Storehouse '
     +'   WHERE [P_ID]>0'+ @szStorage + @szValidDay + ' AND ('+convert(varchar(10),@nYid)+' = 0 OR Y_ID = '+convert(varchar(10),@nYid)
     +')  GROUP BY [P_ID ]) SH '
     +' ON P.[Product_ID]=SH.[P_ID] '

     +' LEFT JOIN '
     +'  (SELECT  SQ.[BBQuantity],SQ.[SBQuantity],SQ.[BNQuantity],SQ.[SNQuantity],SQ.[BEQuantity],SQ.[SEQuantity],SE.* FROM '
     +'      (SELECT PD.[P_ID], '
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,220,221) and  BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'   THEN PD.[Quantity]   ELSE 0 END) AS [BBQuantity], '
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,210,211) and  BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN -PD.[Quantity]  ELSE 0 END) AS [SBQuantity], '
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,220,221) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[Quantity]   ELSE 0 END) AS [BNQuantity], '
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,210,211) and  BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'  THEN -PD.[Quantity]  ELSE 0 END) AS [SNQuantity],  '
     +'         SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,220,221) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39) +' THEN PD.[Quantity]   ELSE 0 END) AS [BEQuantity], '
     +'         SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,210,211) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+ ' THEN -PD.[Quantity]  ELSE 0 END) AS [SEQuantity] '
     +'       FROM VW_X_BillIDX BI,VW_L_pDetailBySMBM PD'
     +'       WHERE PD.aoid in (0,5) and BI.[BillID]=PD.[BillID] AND BI.[BillStates]=''0'' and BI.billtype in (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and  BI.Y_id = '+convert(varchar(10),@nYid) +' '
     +'       GROUP BY PD.[P_ID]) SQ,'

 set  @SQLScript2=
      '       (SELECT PD.[P_ID],'
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) and BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'         THEN PD.[SendQTY]   ELSE 0 END) AS [BBSendQTY], '
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) and BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'         THEN PD.[SendCostTotal]  ELSE 0 END) AS [BBCostTotal],'
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) and  BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+' THEN -PD.[SendQTY]  ELSE 0 END) AS [SBSendQTY],'
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) and  BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+' THEN -PD.[SendCostTotal] ELSE 0 END) AS [SBCostTotal],'
  
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[SendQTY]   ELSE 0 END) AS [BNSendQTY], '
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[SendCostTotal]  ELSE 0 END) AS [BNCostTotal],'
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'     THEN -PD.[SendQTY]  ELSE 0 END) AS [SNSendQTY], ' 
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+'     THEN -PD.[SendCostTotal] ELSE 0 END) AS [SNCostTotal],'

     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'                 THEN PD.[SendQTY]   ELSE 0 END) AS [BESendQTY], '
     +'          SUM(CASE WHEN BI.[BillType] IN (20,21,35,122,222) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'                 THEN PD.[SendCostTotal]  ELSE 0 END) AS [BECostTotal],'
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'        THEN -PD.[SendQTY]  ELSE 0 END) AS [SESendQTY], '
     +'          SUM(CASE WHEN BI.[BillType] IN (10,11,12,13,32,112,53,54,212) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+'        THEN -PD.[SendCostTotal] ELSE 0 END) AS [SECostTotal]'

     +'        FROM VW_X_BillIDX BI,VW_L_pDetailBySMBM PD'
     +'        WHERE PD.aoid in (0,5) and BI.[BillID]=PD.[BillID] AND BI.[BillStates]=''0''' + @szStorage
     +'        and BI.billtype in (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and  BI.Y_id = '+convert(varchar(10),@nYid) +'   GROUP BY PD.[P_ID]   )SE'
     +'        WHERE SQ.[P_ID]=SE.[P_ID])SB '   
     +' ON P.[Product_ID]=SB.[P_ID]'

     +' LEFT JOIN '
     +'  (SELECT PD.[P_ID], '

     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN PD.[Quantity]   ELSE 0 END) AS [OBQuantity],'
     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and BI.[BillDate]<'+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39)+'  THEN PD.[CostTotal]  ELSE 0 END) AS [OBCostTotal],'

     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[Quantity]   ELSE 0 END) AS [ONQuantity],'
     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) and BI.[BillDate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 20)+CHAR(39)+' THEN PD.[CostTotal]  ELSE 0 END) AS [ONCostTotal],'

     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+' THEN PD.[Quantity]   ELSE 0 END) AS [OEQuantity],'
     +'      SUM(CASE WHEN BI.[BillType] NOT IN (10,11,12,13,32,112, 20,21,35,122,53,54,212,222) AND BI.[BillDate]>' + CHAR(39) + CONVERT(VARCHAR(10), @EndDate, 20) + CHAR(39)+' THEN PD.[CostTotal]  ELSE 0 END) AS [OECostTotal]'

     +'    FROM VW_X_BillIDX BI,VW_X_PDetail PD'
     +'    WHERE BI.[BillID]=PD.[BillID] AND BI.[BillStates]=''0'' and PD.storetype=0'+ @szStorage
     +'    and BI.billtype not in (150,151,155,160,161,165) and  BI.Y_id = '+convert(varchar(10),@nYid) +'    GROUP BY PD.[P_ID])OB'
     +' ON OB.[P_ID]=P.[Product_ID]'
     +' LEFT JOIN (select * from vw_productbalance where Y_id = '+convert(varchar(10),@nYid) +') VP ON P.[Product_ID]=VP.[p_id]'
   +' WHERE P.[Child_Number]=0 AND P.[Deleted]<>1  ' + @szProduct
   +' GROUP BY P.[Product_ID],p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5 ORDER BY P.[Product_ID] '
END

   /*PRINT (@SQLScript)*/
   /*PRINT(@SQLScript2)*/
  EXEC(@SQLScript+@SQLScript2)
  GOTO SUCCEE

Succee:

 IF @Companytable<>'' 
 begin
   set @szsql='drop table '+@Companytable
   exec(@szsql)
 end  
  RETURN  0
GO
