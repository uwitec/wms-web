

/*********将金税开票版开票数据导入到发票**********/
/******add by jfy 2016-07-19***/
/* exec TS_D_ImportInvoice 2*/
create procedure TS_D_ImportInvoice
@inputman int
as 
  set nocount on  
  
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
begin tran ImportInvoice  
  
  declare @invoiceid int,@CurCount int  

  select smb_id,billid,detail_id,invoiceDate,eName,taxrate,invoice,InvoiceNO,InvoiceTotal
         ,case when InvoiceTotal<0 then 1 else 0 end InvoiceBillType
  into #Tax_salebill
  from Tax_salebill 
  where InStatus=0
  /*同一发票号同一单据id未找到已开票时,按开票处理*/
  UPDATE R SET  
  InvoiceBillType=0
  FROM #Tax_salebill R LEFT JOIN invoice CI 
       ON R.billid=CI.billid
       LEFT JOIN invoiceidx M 
       ON CI.invoiceid=M.id AND R.InvoiceNO=M.invoiceno AND M.InvoiceBillType=0
  WHERE R.InvoiceBillType=1 AND M.id IS NULL   
  
  select a.billid,a.detail_id,a.InvoiceNO,isnull(d.inputman,@inputman) eName
         ,case when a.invoice=0 then 2 else 3 end invoice,b.c_id,a.InvoiceBillType
         ,b.Y_ID,b.GUID,c.p_id,c.quantity,c.taxtotal,b.billtype
         ,a.InvoiceTotal,a.invoiceDate
  into #Tax_salebill_D
  from #Tax_salebill a inner join billidx b
       on a.billid=b.billid
       inner join salemanagebill c 
       on b.billid=c.bill_id and a.detail_id=c.smb_id
       left join 
       (
		  select t1.eName,MAX(t2.emp_id) inputman
		  from #Tax_salebill t1 inner join employees t2 
			   on t1.eName=t2.name
		  group by t1.eName
       ) d on a.eName=d.eName 
       
  set @CurCount=@@ROWCOUNT
  
  select @invoiceid=ISNULL(MAX(id),0) from invoiceidx
  
  insert into invoiceidx
    (invoicedate,invoiceno,invoicetotal,invoice,inputman,auditman,states,comment
     ,invoicetype,c_id,departmentid,Jsflag,InvoiceBillType,ReAuditFlag,ReAuditMan
     ,OrderID,invoiceGuid,Summary,Y_ID)
  select convert(char(10),MAX(invoiceDate),121),a.InvoiceNO,SUM(InvoiceTotal)
         ,a.invoice,a.eName,@inputman,1,'金税导入',0,a.c_id,0,2,a.InvoiceBillType
         ,0,'',0,NEWID(),'',a.Y_ID
  from #Tax_salebill_D a
  group by a.InvoiceNO,a.eName,a.invoice,a.c_id,a.InvoiceBillType,a.Y_ID
  
  if @@ERROR<>0
     goto error 
     
  /*同一发票号只能有一个开票人与发票类型*/
  insert into invoice
    (invoiceid,billid,smb_id,BILLGUID,RowGuid,p_id,quantity,TOTAL,YKQuantity
     ,YKTOTAL,CurrQuantity,CurrTotal,Y_Id)
  select b.id,a.billid,a.detail_id,a.GUID,'00000000-0000-0000-0000-000000000000'
         ,a.p_id,CASE WHEN a.InvoiceTotal<0 THEN -1 ELSE 1 END*ABS(a.quantity)
         ,CASE WHEN a.InvoiceTotal<0 THEN -1 ELSE 1 END*ABS(a.taxtotal),0,0
         ,case when a.taxtotal=0 then 0 else a.InvoiceTotal*a.quantity/a.taxtotal end 
         ,a.InvoiceTotal,0
  from #Tax_salebill_D a inner join invoiceidx b 
       on a.InvoiceNO=b.InvoiceNO and a.c_id=b.c_id 
          and a.InvoiceBillType=b.InvoiceBillType and a.Y_ID=b.Y_ID
  where b.id>@invoiceid and b.comment='金税导入'
  
  if @@ERROR<>0 or @@ROWCOUNT<>@CurCount
     goto error 
     
  update r set 
  InStatus=1
  from Tax_salebill r inner join #Tax_salebill ci 
       on r.smb_id=ci.smb_id 
  
  commit tran ImportInvoice
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
     
  /*更新单据结算余额等信息*/
  DECLARE @tempinvoiceid INT
  DECLARE Cur_ImportInvoice CURSOR FOR 
  SELECT id FROM invoiceidx WHERE id>@invoiceid AND comment='金税导入' AND states=1
  OPEN Cur_ImportInvoice  
  FETCH NEXT FROM Cur_ImportInvoice INTO @tempinvoiceid
  WHILE @@FETCH_STATUS=0 
	BEGIN
	  EXEC dbo.ts_j_AuditInvoice @tempinvoiceid,0
	  FETCH NEXT FROM Cur_ImportInvoice INTO @tempinvoiceid 
	END
  CLOSE Cur_ImportInvoice
  DEALLOCATE Cur_ImportInvoice 
     
  select COUNT(1) TotalCount,@CurCount CurCount 
  from #Tax_salebill
  
  drop table #Tax_salebill
  drop table #Tax_salebill_D 
  return 0

error:

  select COUNT(1) TotalCount,0 CurCount 
  from #Tax_salebill
  
  drop table #Tax_salebill
  drop table #Tax_salebill_D 

  rollback tran ImportInvoice
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED  
  return 0
GO
