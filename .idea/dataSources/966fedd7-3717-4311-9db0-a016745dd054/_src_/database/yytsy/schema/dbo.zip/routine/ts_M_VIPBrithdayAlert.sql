








CREATE	PROCEDURE [ts_M_VIPBrithdayAlert] 
( 
 @nDay 	int=0
)
AS
/*Params Ini begin*/
if @nDay is null  SET @nDay = 0
/*Params Ini end*/
  select * from vw_M_VipCard 
  where Lose <> 1 and StopUse <> 1
     and (
           (cast(year(GetDate()) as varchar)+'-'+cast(substring(convert(varchar(10), birthday, 20), 6, 5) as varchar) 
            between convert(varchar(10), GetDate(), 20) and convert(varchar(10), GetDate()+@nDay, 20)
            )
            or 
            /*处理报警器跨年度的问题*/
            (cast(year(GetDate() + 365) as varchar)+'-'+cast(substring(convert(varchar(10), birthday, 20), 6, 5) as varchar) 
            between convert(varchar(10), GetDate(), 20) and convert(varchar(10), GetDate()+@nDay, 20)
            )
          )
GO
