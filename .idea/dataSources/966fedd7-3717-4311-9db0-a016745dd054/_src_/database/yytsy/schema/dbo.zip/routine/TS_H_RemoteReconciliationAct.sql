
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-1-14*/
/* Description:	远程零售对账计划操作*/
/* =============================================*/
CREATE PROCEDURE [TS_H_RemoteReconciliationAct] 
	@Act int,			/* 0: 插入 1: 列表 2: 对账结果 3: 对账明细 4: 重新对账*/
	@PlanId int,
	@BeginDate datetime = 0,
	@EndDate datetime = 0,
	@Eid int = 0,
	@TansFlag int = 0,
	@Yid varchar(1000) = '',
	@Note varchar(200) = ''
AS
BEGIN
	SET NOCOUNT ON;

	if @BeginDate is null set @BeginDate = 0
	if @EndDate is null set @EndDate = 0
	if @Eid is null set @Eid = 0
	if @TansFlag is null set @TansFlag = 0
	if @Yid is null set @Yid = ''
	if @Note is null set @Note = ''
	
	declare @nPlanId int

	if @Act = 0
	begin
		insert into reconciliationPlan(begindate, enddate, e_id, plandate, note, TransFlag)
		values(@BeginDate, @EndDate, @Eid, GETDATE(), @Note, 0)
		set @nPlanId = @@IDENTITY
		
		insert into reconciliationResult(plan_id, y_id, isRemote, TransFlag)
		select @nPlanId, type, 0, 0 from dbo.DecodeStr(@Yid)
		
		exec TS_L_CompareOfCompanySale 2, @nPlanId
	end
	else
	if @Act = 1
	begin
		select p.plan_id, p.e_id, e.name as empname, p.begindate, p.enddate, p.plandate, p.note,
		dbo.MergeReconCompany(p.plan_id) as yname, CASE WHEN p.TransFlag IN (1, 2) THEN '已完成' ELSE '正在查询' END as [status]
		from reconciliationPlan p inner join employees e
		on p.e_id = e.emp_id 
		where p.plandate between @BeginDate and DATEADD(d, 1, @EndDate)
	end
	else
	if @Act = 2
	begin
		/*if not EXISTS(select 0 from reconciliationResult where plan_id = @PlanId and isRemote = 1)*/
		/*begin*/
			SELECT     y.name, x1.retailQty, x1.retailTotal, x1.retailBackQty, x1.retailBackTotal, x1.cash, x1.nonCash, ISNULL(x2.retailQty, 0) AS retailQtyY, 
								  ISNULL(x2.retailTotal, 0) AS retailTotalY, ISNULL(x2.retailBackQty, 0) AS retailBackQtyY, ISNULL(x2.retailBackTotal, 0) AS retailBackTotalY, 
								  ISNULL(x2.cash, 0) AS cashY, ISNULL(x2.nonCash, 0) AS nonCashY, ISNULL(x2.payIn, 0) AS payIn, CASE WHEN TransFlag IN (1 ,2) THEN '对账完成' ELSE '正在传输' END as TransFlag, x1.y_id
			FROM         (SELECT     retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, y_id, TransFlag
								   FROM          dbo.reconciliationResult
								   WHERE      (isRemote = 0) AND (plan_id = @PlanId)) AS x1 INNER JOIN
								  dbo.company AS y ON x1.y_id = y.company_id LEFT OUTER JOIN
									  (SELECT     retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, payIn, y_id
										FROM          dbo.reconciliationResult AS reconciliationResult_1
										WHERE      (isRemote = 1) AND (plan_id = @PlanId)) AS x2 ON x1.y_id = x2.y_id
		/*end*/
		/*else*/
		/*begin*/
		/*	SELECT     y.name, ISNULL(x1.retailQty, 0) AS retailQty, ISNULL(x1.retailTotal, 0) AS retailTotal, ISNULL(x1.retailBackQty, 0) AS retailBackQty, ISNULL(x1.retailBackTotal, 0) AS retailBackTotal, ISNULL(x1.cash, 0) AS cash, ISNULL(x1.nonCash, 0) AS nonCash, ISNULL(x2.retailQty, 0) AS retailQtyY, */
		/*						  ISNULL(x2.retailTotal, 0) AS retailTotalY, ISNULL(x2.retailBackQty, 0) AS retailBackQtyY, ISNULL(x2.retailBackTotal, 0) AS retailBackTotalY, */
		/*						  ISNULL(x2.cash, 0) AS cashY, ISNULL(x2.nonCash, 0) AS nonCashY, ISNULL(x2.payIn, 0) AS payIn, CASE TransFlag WHEN 1 THEN '对账完成' ELSE '正在传输' END AS TransFlag, x2.y_id*/
		/*	FROM         dbo.company AS y INNER JOIN*/
		/*							  (SELECT     retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, payIn, y_id, TransFlag*/
		/*								FROM          dbo.reconciliationResult AS reconciliationResult_1*/
		/*								WHERE      (isRemote = 1) AND (plan_id = @PlanId)) AS x2 ON y.company_id = x2.y_id LEFT OUTER JOIN*/
		/*							  (SELECT     retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, y_id*/
		/*								FROM          dbo.reconciliationResult*/
		/*								WHERE      (isRemote = 0) AND (plan_id = @PlanId)) AS x1 ON x2.y_id = x1.y_id*/
		/*end*/
	end
	else
	if @Act = 3
	begin
		if not exists(select 0 from reconciliationDetail where plan_id = @PlanId and isRemote = 1)
		begin
			SELECT     d1.billDate, d1.retailQty, d1.retailTotal, d1.retailBackQty, d1.retailBackTotal, d1.cash, d1.nonCash, ISNULL(d2.retailQty, 0) AS retailQtyY, 
								  ISNULL(d2.retailTotal, 0) AS retailTotalY, ISNULL(d2.retailBackQty, 0) AS retailBackQtyY, ISNULL(d2.retailBackTotal, 0) AS retailBackTotalY, 
								  ISNULL(d2.cash, 0) AS cashY, ISNULL(d2.nonCash, 0) AS nonCashY, CASE WHEN ISNULL(d2.TransFlag, 0) IN(1, 2) THEN '对账完成' ELSE '正在传输' END AS TransFlag
			FROM         dbo.reconciliationDetail AS d1 LEFT OUTER JOIN
									  (SELECT     plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag
										FROM          dbo.reconciliationDetail
										WHERE      (plan_id = @PlanId) AND (y_id = CAST(@Yid as int)) AND (isRemote = 1)) AS d2 ON d1.billDate = d1.billDate
			WHERE     (d1.plan_id = @PlanId) AND (d1.isRemote = 0) AND (d1.y_id = CAST(@Yid as int)) AND (d1.cash > 0 OR d1.retailQty > 0 OR d1.retailBackQty > 0 OR d1.nonCash > 0)
			ORDER By d1.billDate
		end
		else
		begin
			SELECT     d1.billDate, d1.retailQty, d1.retailTotal, d1.retailBackQty, d1.retailBackTotal, d1.cash, d1.nonCash, ISNULL(d2.retailQty, 0) AS retailQtyY, 
								  ISNULL(d2.retailTotal, 0) AS retailTotalY, ISNULL(d2.retailBackQty, 0) AS retailBackQtyY, ISNULL(d2.retailBackTotal, 0) AS retailBackTotalY, 
								  ISNULL(d2.cash, 0) AS cashY, ISNULL(d2.nonCash, 0) AS nonCashY, CASE WHEN ISNULL(d2.TransFlag, 0) IN (1, 2) THEN '对账完成' ELSE '正在传输' END AS TransFlag
			FROM         (SELECT     plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag
								   FROM          dbo.reconciliationDetail
								   WHERE      (plan_id = @PlanId) AND (isRemote = 0) AND (y_id = CAST(@Yid as int))) AS d1 RIGHT OUTER JOIN
									  (SELECT     plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag
										FROM          dbo.reconciliationDetail AS reconciliationDetail_1
										WHERE      (plan_id = @PlanId) AND (y_id = CAST(@Yid as int)) AND (isRemote = 1) AND (cash > 0 OR nonCash > 0 OR retailQty > 0 OR retailBackQty > 0)) AS d2 ON d1.billDate = d2.billDate
			ORDER BY d2.billDate
		end
	end
	else
	if @Act = 4
	begin
		delete from reconciliationDetail where plan_id = @PlanId
		update reconciliationPlan set TransFlag = 0 where plan_id = @PlanId
		update reconciliationResult set TransFlag = 0, retailQty = 0, retailBackQty = 0, 
			retailTotal = 0, retailBackTotal = 0, cash = 0, nonCash = 0, payIn = 0
		where plan_id = @PlanId
		delete from reconciliationResult where plan_id = @PlanId and isRemote = 1

		exec TS_L_CompareOfCompanySale 2, @PlanId
	end
END
GO
