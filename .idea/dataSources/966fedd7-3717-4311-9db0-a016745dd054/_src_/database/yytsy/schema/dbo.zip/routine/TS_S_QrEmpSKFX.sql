
CREATE PROC TS_S_QrEmpSKFX
( @Begindate       datetime = 0,
  @Enddate         datetime = 0,
  @szEClass_ID     varchar(30)='',
  @szBillType      varchar(255)='0',/*                                          */
  @InputOrEmp      INT =0,             /*0 经手人  1 制单人*/
  @QrType          INT =0, /* 0 销售类收款 1 采购类付款 */
  @nloginEID       int=0,
  @szYclass_id     varchar(30)='' /*分支机构*/
)
AS
BEGIN
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = 0
if @Enddate is null  SET @Enddate = 0
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szBillType is null  SET @szBillType = '0'
if @InputOrEmp is null  SET @InputOrEmp = 0
if @QrType is null  SET @QrType = 0
if @nloginEID is null  SET @nloginEID = 0
if @szYclass_id is null  SET @szYclass_id = ''
/*Params Ini end*/
 /* SET NOCOUNT ON */
 declare @BANK_ID varchar(50),
         @CASH_ID varchar(50),
         @SQLScript varchar(8000),
         @szName varchar(100),
         @szID   varchar(30),   
         @nAID   INT,
         @ArID   varchar(30),
         @ApID   varchar(30),
         @ArOrApID varchar(30)
 Declare @employeestable int,
	 @Companytable   int
  
        select @ArID = '000002000005',@ApID = '000001000009'
        IF @QrType = 0 SELECT @nAID = 15,@ArOrApID = @ArID ELSE IF @QrType = 1 SELECT @nAID = 23,@ArOrApID = @ApID

 select @BANK_ID='000001000004%' ,@CASH_ID ='000001000003%'
        if @szEClass_ID = '' select  @szEClass_ID = '%%' else select  @szEClass_ID = @szEClass_ID +'%'
        if @szYclass_id= '' select @szYclass_id='%%' else select @szYclass_id=@szYclass_id+'%'
 /*select  @Begindate = '2007-05-27',@Enddate = '2007-05-30'*/


  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


if @InputOrEmp = 0  /*按经手人*/
begin
      /*前期业务收款合计           */
select  b.E_ID,Sum(jstotal) as skje ,'QSKsum' as flag INTO #tmpSK from 
      (select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jsbdetail where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid ,c_id      
       union 
       select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal  from jspdetail  where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid,c_id) pd
       inner join vw_x_billidx b  on pd.skd_bid = b.billid and pd.c_id=b.c_id
       and b.billdate between @Begindate and @Enddate
       and b.EClass_ID like @szEClass_ID
       and b.billstates = 0
       and b.billtype in (@nAID)
       and b.Yclass_id like @szYclass_id 
       inner join vw_x_billidx bi on pd.xsd_bid = bi.billid and pd.c_id=bi.c_id
       and bi.billdate <@Begindate
       and bi.billstates = 0
       and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
       and bi.Yclass_id like @szYclass_id 
       where bi.billdate<b.billdate                                      
       group by b.E_ID

        /*前期业务欠款余额*/
       insert into #tmpSK (E_ID,skje,flag)       
       select E_ID,sum(case when billtype in (11,13,21,24,25,54,211,221) then -jsye else jsye end) as skje ,'QQkSum'  from vw_x_billidx 
       where billstates = '0' 
       and billdate < @BeginDate
       and EClass_ID like @szEClass_ID
       and billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
       and Yclass_id like @szYclass_id 
       group by E_ID
          

        /* 本期多账户*/
 SELECT B.[e_id],AD.[a_ID],AD.AClass_ID,AD.AccountName,
        SUM(case when @nAID in (23) or (@nAID in (15) AND AD.[AClass_ID] = @ArID) 
            then -AD.jdmoney else AD.jdmoney end) AS skje ,'B' as flag 
 INTO #QD FROM 
        (select a.*,isnull(Y.class_id,'') as Yclass_id  from vw_x_Adetail a
         left join company Y on a.Y_id=Y.company_id
         where  Y.class_id like @szYclass_id  and (aclass_ID like @CASH_ID or  aclass_ID like @BANK_ID or aclass_ID like @ArOrApID or AClass_ID = '000001000012' or AClass_ID = '000001000013')) AD 
         inner JOIN vw_x_billidx B ON AD.billID = B.billid 
         WHERE B.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
         and B.billdate between @Begindate and @EndDate
         and B.[EClass_ID] like @szEClass_ID
         and B.billstates = '0'
         and B.Yclass_id like @szYclass_id 
         group by B.[e_id],AD.AClass_ID,AD.AccountName,AD.[a_ID]
 /*order by AD.AClass_ID */

         /*本期收款(付款)单折让*/
         insert into #tmpSK(e_id,skje,flag)
         select B.[e_id],SUM(case when @nAID in (23) or (@nAID in (15) and AD.[AClass_ID] = @ArID) then -AD.jdmoney else AD.jdmoney end) AS skje,
         'SKZR' as flag
         FROM  (select * from vw_x_Adetail where aclass_ID ='000004000003000004') AD
         inner JOIN  (select distinct b.billid,b.e_ID from 
                     (select skd_bid,xsd_bid from jsbdetail where billtype not in (150,151,155,160,161,165)
                      union 
                      select skd_bid,xsd_bid from jspdetail where billtype not in (150,151,155,160,161,165)) pd
                      inner join vw_x_billidx b  on pd.skd_bid = b.billid
                      and b.billdate between @Begindate and @Enddate
                      and b.EClass_ID like @szEClass_ID                         
                      and b.billstates = 0
                      and b.billtype in (@nAID)
 		      and b.Yclass_id like @szYclass_id
                      inner join vw_x_billidx bi on pd.xsd_bid = bi.billid                         
                      and bi.billdate between @Begindate and @Enddate
                      and bi.billstates = 0
                      and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
 		      and bi.Yclass_id like @szYclass_id 
                 ) B ON AD.billid = B.Billid
          group by B.[e_id]

       /*本期收款、付款单     */
         insert into #tmpSK(E_id,skje,flag)          
         select A.E_ID,SUM(A.skje) as skje,'BQskd' as flag 
         from (select b.E_ID,sum(case  when b.billtype in (23) or pd.[AClass_ID] = @ArID  then -pd.jdMoney
               else pd.jdMoney end) as skje
               from (select *  from vw_x_adetail 
                     where AClass_ID like @BANK_ID or AClass_ID like @CASH_ID or AClass_ID like @ArOrApID or AClass_ID = '000001000012' or AClass_ID = '000001000013') pd
                     inner join vw_x_billidx b 
                     on pd.billid = b.billid 
                     and b.billdate  between @Begindate and @Enddate
                     and b.[EClass_ID] like  @szEClass_ID                         
                     and b.billstates = '0'
                     and b.billtype in (@nAID)
		     and b.Yclass_id like @szYclass_id
               group by b.E_ID ) A
           GROUP BY A.E_ID

        /*本期收款(付款)单上业务结算金额*/
          insert into #tmpSK(E_id,skje,flag)  
          select bi.E_ID,sum(jsTotal) as skje,'BQJS' as flag  from
           (select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jsbdetail where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid,c_id
            union 
            select skd_bid,xsd_bid,c_id,sum(jstotal)jstotal from jspdetail  where billtype not in (150,151,155,160,161,165) Group by skd_bid,xsd_bid,c_id) pd
            inner join vw_x_billidx b  on pd.skd_bid = b.billid and pd.c_id=b.c_id
            and b.billdate  between @Begindate and @Enddate
            and b.billtype in (@nAID)
            /*and b.EClass_ID like @szEClass_ID                         */
            and b.billstates = 0
            and b.Yclass_id like @szYclass_id
            inner join vw_x_billidx bi on pd.xsd_bid = bi.billid and pd.c_id=bi.c_id
            and bi.billdate between @Begindate and @Enddate
            and bi.billstates = 0
            and bi.EClass_ID like @szEClass_ID                         
            and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
            and bi.Yclass_id like @szYclass_id          
           group by bi.E_ID


  /*本期业务收款、付款合计  = 本期收款金额 - 前期 +多帐户   */
        insert into #tmpSK(E_id,skje,flag)         
          select E.emp_ID as e_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) + ISNULL(C.skje,0),'BSKsum' as flag
          from Employees E
          left join (select e_id,SUM(skje) as skje from #tmpSK where flag = 'BQskd' group by e_ID) A on E.emp_ID = A.e_ID
          left join (select e_id,SUM(skje) as skje from #tmpSK where flag = 'QSKsum' group by e_ID) B on E.emp_ID = B.e_ID
          left join (select e_id,SUM(skje) as skje from #QD    where flag = 'B' group by e_ID)    C on E.emp_ID = C.e_ID        
          where (E.child_Number = 0 or Emp_ID = 1) and E.deleted = 0
          and E.emp_ID in (select e_id from #tmpSK where flag = 'BQskd' 
                           union
                           select e_id from #QD    where flag = 'B')


  /*本期销售(采购)金额合计 */
      select e_id, BQxshj = ISNULL(SUM(CASE WHEN billtype in (13,11,21,24,25,54,211,221) then -ysmoney else ysmoney end),0) into #tmpBQXShj
      FROM vw_x_billidx where [EClass_ID] like @szEClass_ID
      and [billtype] in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
      and [billstates] = 0                           
      and [billdate] between @Begindate and @EndDate
      and [Yclass_id] like @szYclass_id  GROUP BY E_iD
  /*本期业务|欠款金额 */
     insert into #tmpSK(E_id,skje,flag)
     select E.emp_ID as e_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) - ISNULL(C.skje,0),'BQQK' as flag
     from Employees E
     left join (select e_id,SUM(BQxshj) as skje from #tmpBQXShj  group by e_ID) A on E.emp_ID = A.e_ID
     left join (select e_id,SUM(skje) as skje from #tmpSK where flag = 'BQJS' group by e_ID) B on E.emp_ID = B.e_ID
     left join (select e_id,SUM(skje) as skje from #QD    where flag = 'B' group by e_ID)    C on E.emp_ID = C.e_ID        
     where (E.child_Number = 0 or Emp_ID = 1) and E.deleted = 0
     and E.emp_ID in (select e_id from #tmpSK where flag = 'BQskd' 
                      union
                      select e_id from #tmpBQXShj
                      union
                      select e_id from #QD    where flag = 'B')
             

   /* 各项现金银行科目合计 :属于结算的收款(付款)单 + 本期多帐户 */

  
    SELECT A.E_ID,A.AClass_ID,A.a_id,sum(skje) as skje INTO #CaseBankSum 
    FROM (select b.E_ID,ad.AClass_ID,ad.a_id,
          SUM(case  when b.billtype in (23) or (b.billtype in (15) and ad.[AClass_ID] = @ArID) 
              then -ad.jdMoney else ad.jdMoney end) as skje  
          from vw_x_adetail ad 
          inner join vw_x_billidx b  ON ad.billid = b.billid 
          and b.billdate between @BeginDate and @EndDate
          and b.billstates = '0'
          and b.[EClass_ID] like @szEClass_ID
          and b.billtype in (@nAID)
          and b.Yclass_id like @szYclass_id
              /*join (select distinct a.skd_bid 
                      from (select skd_bid,xsd_bid from jsbdetail 
                            union 
                            select skd_bid,xsd_bid from jspdetail) a
                      join vw_x_billidx bi on a.xsd_bid = bi.billid
                     where bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
                       and bi.billstates = 0
                       and bi.billdate <= @Enddate) c
               on b.billid = c.skd_bid */
          where b.Yclass_id like @szYclass_id and (ad.AClass_ID like @BANK_ID or  ad.AClass_ID like @CASH_ID  or ad.AClass_ID like @ArOrApID or ad.AClass_ID = '000001000012' or ad.AClass_ID = '000001000013')                    
          group by b.E_ID ,ad.AClass_ID,ad.a_id
          UNION ALL /*多账户*/
          select E_ID,AClass_ID,a_id,skje from #QD where flag = 'B')A  GROUP BY  A.E_ID,A.AClass_ID,A.a_id


  /*合计收款*/
     insert into #tmpSK (e_id,skje,flag)
     select e_ID,SUM(skje) as skje,'SKsum' as flag 
     from #tmpSK      
     where flag = 'QSKsum' or flag = 'BSKsum' GROUP BY E_ID

 
  /*时间段内收款(付款)单折让合计 :属于结算的收款(付款)单*/
     insert into #tmpSK(e_id,skje,flag)
     select b.E_id,SUM(Case when b.billtype in (23) or (b.billtype in (15) and ad.[AClass_ID] = @ArID)  
                       then -AD.[jdmoney] else AD.[jdmoney] end) as skje,'skzrH' as flag /*INTO #SKzrSUM */
     from (select * from vw_x_Adetail where aclass_Id = '000004000003000004') ad 
     inner join vw_x_billidx b  on ad.billid = b.billid
     and b.billdate between @Begindate and @Enddate
     and b.[EClass_ID] like @szEClass_ID                         
     and b.billstates = 0 
     and b.billtype in (@nAID)
     and b.Yclass_id like @szYclass_id
     inner join (select distinct a.skd_bid from
                 (select skd_bid,xsd_bid from jsbdetail union select skd_bid,xsd_bid from jspdetail) a
                  inner join vw_x_billidx bi on a.xsd_bid = bi.billid
                  where bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
                  and bi.billstates = 0
                  and bi.billdate <= @Enddate
		  and bi.Yclass_id like @szYclass_id
                 ) c  on b.billid = c.skd_bid
     group by B.[E_ID]
          

    set  @SQLScript = 'Create table ##EmpAccount
        (e_ID INT,
         QQSKSum NUMERIC(25,8) default(0),
         QQkSum  NUMERIC(25,8) default(0),
         BQSKSum NUMERIC(25,8) default(0),
         BQxshj  NUMERIC(25,8) default(0),
         BQQK    NUMERIC(25,8) default(0),   
         SKSum   NUMERIC(25,8) default(0),
         BQSKzr  NUMERIC(25,8) default(0), 
         BQSKdje NUMERIC(25,8) default(0),
         SKzrSUM NUMERIC(25,8) default(0),
         ssSUM   NUMERIC(25,8) default(0),
         BQskdJS NUMERIC(25,8) default(0),
         QKSum   NUMERIC(25,8) default(0),'
  
 declare getEmpA Cursor 
 for
     SELECT CAST(account_ID AS VARCHAR) AS szfield,Class_id AS AClass_ID  
     FROM account WHERE child_number = 0 AND deleted = 0 
     AND (class_id LIKE @BANK_ID OR class_id LIKE @CASH_ID or Class_ID like @ArOrApID or class_id = '000001000012' or class_id = '000001000013')
     ORDER BY Class_ID
 
 OPEN getEmpA
 
 FETCH NEXT FROM getEmpA
 INTO @szName,@szID 
 WHILE @@FETCH_STATUS = 0
 BEGIN
     SELECT @SQLScript = @SQLScript  +'fb'+@szName+ ' NUMERIC(25,8) default 0 ,'                                        
                                          +'fh'+@szName+ ' NUMERIC(25,8) default 0 ,'                                         
     FETCH NEXT FROM getEmpA
     INTO @szName,@szID
 END 
 close getEmpA 
 select  @SQLScript = left(@SQLScript,len(@SQLScript)-1)+')'
 exec (@SQLScript)
 /*print  @SQL*/
 
 insert into ##EmpAccount(e_id)
 select A.[e_id] FROM 
         (select e_id from #tmpBQXShj
                 union
          select e_ID from #tmpSK
                 union
                 select e_id from #CaseBankSum
                 ) A

 OPEN getEmpA
 
 FETCH NEXT FROM getEmpA
 INTO @szName,@szID
 
 WHILE @@FETCH_STATUS = 0
 BEGIN 
   set @SQLScript = 'update A set fb'+@szName+' = pd.skje from  ##EmpAccount A join #QD pd on A.[e_ID] = pd.[e_id] and PD.[flag] = ''B'' and pd.[a_ID] = '+@szName
   Exec(@SQLScript)

   set @SQLScript = 'update A set fh'+@szName+' = pd.skje from  ##EmpAccount A join (select e_id,sum(skje) as skje ,a_id from #CaseBankSum group by e_ID,a_ID) pd on A.[e_ID] = pd.[e_id] and pd.[a_ID] = '+@szName
  /*print @SQLScript*/
   Exec(@SQLScript)

   FETCH NEXT FROM getEmpA
   INTO @szName,@szID
 END
 
 CLOSE getEmpA
 DEALLOCATE getEmpA
        
        
        update A  set QQSKSum = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'QSKsum'
        update A  set QQkSum  = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'QQkSum'

        update A  set BQSKSum = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'BSKsum'
        update A  set BQxshj  = B.BQxshj from ##EmpAccount A join  #tmpBQXShj B ON A.e_id = B.e_id
        update A  set BQQK    = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'BQQK' 
        update A  set SKSum   = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'SKsum' 
        update A  set BQSKzr  = B.skje   from ##EmpAccount A join  #tmpSK  B ON A.e_id = B.e_id and B.flag = 'skzr'  
        update A  set BQSKdje = B.skje   from ##EmpAccount A join #tmpSK  B ON A.e_id = B.e_id and B.flag = 'BQskd'
        update A  set SKzrSUM = B.skje   from ##EmpAccount A join  #tmpSK   B ON A.e_id = B.e_id and B.flag = 'skzrH'

        update A  set BQskdJS = B.skje   from ##EmpAccount A join  #tmpSK   B ON A.e_id = B.e_id and B.flag = 'BQJS'
        /*欠款合计*/
        update A set  QKSum = ISNULL(QQkSum,0) + ISNULL(BQQK,0) FROM ##EmpAccount A   

        SELECT 0 as Serialno, E.[EMP_id],E.[Serial_Number],[Name],E.[DepName],E.[deduct],PD.* FROM VW_EMPLOYEE E
               JOIN ##EmpAccount PD ON E.emp_ID = PD.e_ID
               WHERE (E.[Child_Number] = 0 or E.[emp_ID] = 1) and E.[Class_ID] like @szEClass_ID
        AND (@employeestable=0 OR ((E.class_id='') or (exists (select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and E.class_id like u.psc_id+'%'))))


        SET NOCOUNT OFF
        GOTO SUCCE
 end else
 if @InputOrEmp = 1 
 begin
   select  b.InputMan as E_ID,Sum(jstotal) as skje ,'QSKsum' as flag INTO #tmpSKI from 
           (select skd_bid,xsd_bid,Sum(jstotal)Jstotal from jsbdetail Group by skd_bid,xsd_bid       
            union 
            select skd_bid,xsd_bid,sum(jstotal)jstotal from jspdetail Group by skd_bid,xsd_bid) pd
            inner join vw_x_billidx b  on pd.skd_bid = b.billid                  
            and b.billdate between @Begindate and @Enddate
            and b.[inputManClass_ID] like @szEClass_ID
            and b.billstates = 0
            and b.billtype in (@nAID)
            and b.Yclass_id like @szYclass_id
            inner join vw_x_billidx bi on pd.xsd_bid = bi.billid 
            and bi.billdate <@Begindate
            and bi.billstates = 0
            and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
            and bi.Yclass_id like @szYclass_id
            where bi.billdate<b.billdate                                      
   group by b.InputMan 


        /*前期业务欠款余额*/
   insert into #tmpSKI (E_ID,skje,flag)       
   select InputMan as E_ID,sum(case when billtype in (11,13,21,24,25,54,211,221) then -jsye else jsye end) as skje ,'QQkSum' 
   from vw_x_billidx 
   where billstates = '0' 
   and billdate < @BeginDate
   and inputManClass_ID like @szEClass_ID
   and billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
   and Yclass_id like @szYclass_id
   group by InputMan      
         

        /* 本期多账户*/
   SELECT B.[InputMan] as [e_id]  ,AD.[a_ID],AD.AClass_ID,AD.AccountName,
          SUM(case when @nAID in (23) or (@nAID in (15) and AD.[AClass_ID] = @ArID) 
              then -AD.jdmoney else AD.jdmoney end) AS skje ,'B' as flag INTO #QDI 
   FROM (select *  from vw_x_Adetail  
         where aclass_ID like @CASH_ID or  aclass_ID like @BANK_ID or aClass_ID like @ArOrApID or AClass_ID = '000001000012' or AClass_ID = '000001000013') AD 
   inner JOIN vw_x_billidx B on AD.billID = B.billid 
   where B.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
   and B.billdate between @Begindate and @EndDate
   and B.[inputManClass_ID] like @szEClass_ID
   and B.billstates = 0
   and B.Yclass_id like @szYclass_id
   group by B.[InputMan],AD.AClass_ID,AD.AccountName,AD.[a_ID]
   order by AD.AClass_ID
  
  
         /*本期收款、付款单*/

    insert into #tmpSKI(E_id,skje,flag)          
    select A.E_ID,SUM(A.skje) as skje,'BQskd' as flag 
    from (select b.[InputMan] as E_ID,
                 sum(case when b.billtype in (23) or (b.billtype in (15) and pd.[AClass_ID] = @ArID) 
                     then -pd.jdMoney  else pd.jdMoney end) as skje  
          from (select * from vw_x_adetail 
                where AClass_ID like @BANK_ID or AClass_ID like @CASH_ID or AClass_ID like @ArOrApID or AClass_ID = '000001000012' or AClass_ID = '000001000013') pd
          inner join vw_x_billidx b  on pd.billid = b.billid 
          and b.billdate  between @Begindate and @Enddate
          and b.[inputManClass_ID] like @szEClass_ID                         
          and b.billstates = 0
          and b.billtype  in (@nAID)
          and Yclass_id like @szYclass_id
          group by b.[InputMan]
         ) A
     left join #tmpSKI sk on A.E_id = sk.E_ID and sk.flag = 'QSKsum'              
     GROUP BY A.E_ID

         /*本期收款(付款)单折让*/
     insert into #tmpSKI(e_id,skje,flag)
     select  B.[e_id],SUM(case @nAID when 23 then -AD.jdmoney else AD.jdmoney end) AS skje,'skzr' as flag /*INTO  #BQskzr*/
     FROM  (select * from vw_x_Adetail where aclass_ID ='000004000003000004') AD
     inner JOIN   ( select distinct b.billid,b.inputMan as [e_id] from 
                    (select skd_bid,xsd_bid from jsbdetail 
                     union 
                     select skd_bid,xsd_bid from jspdetail) pd
                     inner join vw_x_billidx b  on pd.skd_bid = b.billid
                     and b.billdate between @Begindate and @Enddate
                     and b.[inputManClass_ID] like @szEClass_ID     
                     and b.billstates = 0
                     and b.billtype in (@nAID)
                     and B.Yclass_id like @szYclass_id
                     inner join vw_x_billidx bi on pd.xsd_bid = bi.billid                         
                     /*and bi.billdate between @Begindate and @Enddate*/
                     and bi.billstates = 0
                     and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))
                     and bi.Yclass_id like @szYclass_id
                  ) B ON AD.billid = B.Billid
     group by B.[e_id]


        /*本期收款单上对业务结算*/
      insert into #tmpSKI (E_id,skje,flag)  
      select b.inputman as [E_ID],sum(jsTotal) as skje,'BQJS' as flag  from  /*INTO #BQSK*/
      (select skd_bid,xsd_bid,sum(jstotal)jstotal from jsbdetail Group by skd_bid,xsd_bid 
       union 
       select skd_bid,xsd_bid,sum(jstotal)jstotal from jspdetail Group by skd_bid,xsd_bid) pd
       inner join vw_x_billidx b  on pd.skd_bid = b.billid
       and b.billdate between @Begindate and @Enddate
       and b.billtype in (@nAID)
       and b.billstates = 0
       and B.Yclass_id like @szYclass_id
       inner join vw_x_billidx bi on pd.xsd_bid = bi.billid  
       and bi.billdate between @Begindate and @Enddate
       and bi.billstates = 0
       and bi.[inputManClass_ID] like @szEClass_ID                         
       and bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType))          
       and bi.Yclass_id like @szYclass_id
       group by b.inputman


  /*本期业务收款合计*/
       insert into #tmpSKI (e_id,skje,flag)
       select E.emp_ID as e_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) + ISNULL(C.skje,0),'BSKsum' as flag
       from Employees E
       left join (select e_id,sum(skje) as skje from #tmpSKI where flag = 'BQskd' group by e_ID) A on E.emp_ID = A.e_ID
       left join (select e_id,sum(skje) as skje from #tmpSKI where flag = 'QSKsum' group by e_ID) B on E.emp_ID = B.e_ID
       left join (select e_id,sum(skje) as skje from #QDI    where flag = 'B' group by e_ID)    C on E.emp_ID = C.e_ID        
       where (E.child_Number = 0 or Emp_ID = 1) and E.deleted = 0
       and E.emp_ID in (select e_id from #tmpSKI where flag = 'BQskd' 
                        union
                        select e_id from #QDI    where flag = 'B')


  /*本期销售金额合计  */
      select inputMan as [e_id], BQxshj = ISNULL(SUM(CASE WHEN billtype in (13,11,21,24,25,54,221,211) then -ysmoney else ysmoney end),0) into #tmpBQXShjI
      FROM vw_x_billidx where [inputManClass_ID] like @szEClass_ID
       and [billtype] in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
       and [billstates] = 0                           
       and [billdate] between @Begindate and @EndDate 
       and [Yclass_id] like @szYclass_id  GROUP BY inputMan
  /*本期业务|欠款金额 */

   insert into #tmpSKI(E_id,skje,flag)
   select E.emp_ID as e_ID, skje = ISNULL(A.skje,0) - ISNULL(B.skje,0) - ISNULL(C.skje,0),'BQQK' as flag
   from Employees E
   left join (select e_id,SUM(BQxshj) as skje from #tmpBQXShjI  group by e_ID) A on E.emp_ID = A.e_ID
   left join (select e_id,SUM(skje) as skje from #tmpSKI where flag = 'BQJS' group by e_ID) B on E.emp_ID = B.e_ID
   left join (select e_id,SUM(skje) as skje from #QDI    where flag = 'B' group by e_ID)    C on E.emp_ID = C.e_ID        
   where (E.child_Number = 0 or Emp_ID = 1) and E.deleted = 0
   and E.emp_ID in (select e_id from #tmpSKI where flag = 'BQskd' 
                    union 
                    select e_id from #tmpBQXShjI 
                    union
                    select e_id from #QDI    where flag = 'B')

/*     select A.e_ID, [skje] = ISNULL(A.[BQxshj],0) - ISNULL(B.[skje],0) - ISNULL(C.[skje],0),'BQQK' as flag   */
/*                               from #tmpBQXShjI A left join #tmpSKI B ON A.e_ID = B.e_ID and B.flag ='BQJS'  */
/*                                                  left join #QDI    C on A.e_ID = C.e_ID and C.flag ='B'*/
 
 

   /* 各项现金银行科目合计 :属于结算的收款单*/
   select A.E_ID,A.AClass_ID,A.a_id,SUM(skje) as skje INTO #CaseBankSumI 
   from (select b.[inputMan] as [E_ID],ad.AClass_ID,ad.a_id,
         SUM(case when b.billtype in (23) or (b.billtype in (15) and ad.[AClass_ID] = @ArID) then -ad.jdMoney else ad.jdMoney end) as skje  
         from vw_x_adetail ad 
         inner join vw_x_billidx b  ON ad.billid = b.billid 
         and b.billdate between @BeginDate and @EndDate
         and b.billstates = 0
         and b.[inputManClass_ID] like @szEClass_ID
         and b.billtype in (@nAID)
         and B.Yclass_id like @szYclass_id
                                  
            /* join (select distinct a.skd_bid 
                     from (select skd_bid,xsd_bid  from jsbdetail 
                            union 
                           select skd_bid,xsd_bid from jspdetail) a
                             join vw_x_billidx bi on a.xsd_bid = bi.billid
                            where bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
                              and bi.billstates = 0
                              and bi.billdate <= @Enddate ) c 
               on b.billid = c.skd_bid */
         where ad.AClass_ID like @BANK_ID or  ad.AClass_ID like @CASH_ID  or ad.AClass_ID like @ArOrApID or ad.AClass_ID = '000001000012' or ad.AClass_ID = '000001000013'                   
         group by b.inputMan ,ad.AClass_ID,ad.a_id
         UNION ALL
         select E_ID,AClass_ID,a_id,skje from #QDI where flag = 'B') A
   GROUP BY A.E_ID,A.AClass_ID,A.a_id
  


  /*合计收款*/

    insert into #tmpSKI (e_id,skje,flag)
    select e_ID,SUM(skje) as skje,'SKsum' as flag 
    from #tmpSKI where flag = 'QSKsum' or flag = 'BSKsum' GROUP BY E_ID

  /*时间段内收款单折让合计 :属于结算的收款单*/
    insert into #tmpSKI(e_id,skje,flag)
    select b.inputMan as [E_id],
           SUM(Case  when b.billtype in (23) Or (b.billtype in (15) and ad.[AClass_ID] = @ArID) then -AD.[jdmoney] else AD.[jdmoney] end) as skje,'skzrH' as flag /*INTO #SKzrSUM */
    from (select * from vw_x_Adetail where aclass_Id = '000004000003000004') ad 
    inner join vw_x_billidx b  on ad.billid = b.billid
    and b.billdate between @Begindate and @Enddate
    and b.[inputManClass_ID] like @szEClass_ID                         
    and b.billstates = 0 
    and b.billtype in (@nAID)
    and B.Yclass_id like @szYclass_id   
    inner join (select distinct a.skd_bid 
                from (select skd_bid,xsd_bid from jsbdetail 
                      union 
                      select skd_bid,xsd_bid from jspdetail) a
                inner join vw_x_billidx bi on a.xsd_bid = bi.billid
                where bi.billtype in (SELECT TYPE FROM dbo.DecodeStr(@szBillType)) 
                and bi.billstates = 0
                and bi.billdate <= @Enddate
                and Bi.Yclass_id like @szYclass_id) c  
     on b.billid = c.skd_bid           
     group by B.[inputMan]
          

 set  @SQLScript = 'Create table ##EmpAccountI
        (e_ID INT,
                QQSKSum NUMERIC(25,8) default(0),
                QQkSum  NUMERIC(25,8) default(0),
                BQSKSum NUMERIC(25,8) default(0),
                BQxshj  NUMERIC(25,8) default(0),
                BQQK    NUMERIC(25,8) default(0),   
                SKSum   NUMERIC(25,8) default(0),
                BQSKzr  NUMERIC(25,8) default(0), 
                BQSKdje NUMERIC(25,8) default(0),
                SKzrSUM NUMERIC(25,8) default(0),
                ssSUM   NUMERIC(25,8) default(0),
                BQskdJS NUMERIC(25,8) default(0),
                QKSum   NUMERIC(25,8) default(0),'
 
 declare getEmpA Cursor 
 for
     SELECT CAST(account_ID AS VARCHAR) AS szfield,Class_id AS AClass_ID  
     FROM account WHERE child_number = 0 AND deleted = 0 
     AND (class_id LIKE @BANK_ID OR class_id LIKE @CASH_ID OR Class_ID like @ArOrApID or class_id = '000001000012' or class_id = '000001000013') 
     ORDER BY Class_ID
 
 OPEN getEmpA
 
 FETCH NEXT FROM getEmpA
 INTO @szName,@szID 
 WHILE @@FETCH_STATUS = 0
 BEGIN
   SELECT @SQLScript = @SQLScript  +'fb'+@szName+ ' NUMERIC(25,8) default 0 ,'                                        
                                   +'fh'+@szName+ ' NUMERIC(25,8) default 0 ,'                                         
   FETCH NEXT FROM getEmpA
   INTO @szName,@szID
 END 
 close getEmpA 
 select  @SQLScript = left(@SQLScript,len(@SQLScript)-1)+')'
 exec (@SQLScript)
 /*print  @SQL*/
 
 insert into ##EmpAccountI(e_id)
 select A.[e_id] FROM 
         (select e_id from #tmpBQXShjI
                 union
          select e_ID from #tmpSKI
                 union
                 select e_id from #CaseBankSumI
                 ) A

 OPEN getEmpA
 
 FETCH NEXT FROM getEmpA
 INTO @szName,@szID
 
 WHILE @@FETCH_STATUS = 0
 BEGIN 
   set @SQLScript = 'update A set fb'+@szName+' = pd.skje from  ##EmpAccountI A join #QDI pd on A.[e_ID] = pd.[e_id] and PD.[flag] = ''B'' and pd.[a_ID] = '+@szName
   Exec(@SQLScript)

   set @SQLScript = 'update A set fh'+@szName+' = pd.skje from  ##EmpAccountI A join (select e_id,sum(skje) as skje ,a_id from #CaseBankSumI group by e_ID,a_ID) pd on A.[e_ID] = pd.[e_id] and pd.[a_ID] = '+@szName
 /*  print @SQLScript*/
   Exec(@SQLScript)

   FETCH NEXT FROM getEmpA
   INTO @szName,@szID
 END
 
 CLOSE getEmpA
 DEALLOCATE getEmpA
        
        
        update A  set QQSKSum = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'QSKsum'
        update A  set QQkSum  = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'QQkSum'


        update A  set BQSKSum = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'BSKsum'
        update A  set BQxshj  = B.BQxshj from ##EmpAccountI A join  #tmpBQXShjI B ON A.e_id = B.e_id
        update A  set BQQK    = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'BQQK' 
        update A  set SKSum   = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'SKsum' 
        update A  set BQSKzr  = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'skzr'  
        update A  set BQSKdje = B.skje   from ##EmpAccountI A join  #tmpSKI  B ON A.e_id = B.e_id and B.flag = 'BQskd'
        update A  set SKzrSUM = B.skje   from ##EmpAccountI A join  #tmpSKI   B ON A.e_id = B.e_id and B.flag = 'skzrH'
        update A  set BQskdJS = B.skje   from ##EmpAccountI A join  #tmpSKI   B ON A.e_id = B.e_id and B.flag = 'BQJS'
 /*欠款合计*/
        update A set  QKSum = ISNULL(QQkSum,0) + ISNULL(BQQK,0) FROM ##EmpAccountI A           

        SELECT 0 as Serialno, E.[EMP_id],E.[Serial_Number],[Name],E.[DepName],E.[deduct],PD.* FROM VW_EMPLOYEE E
               JOIN ##EmpAccountI PD ON E.emp_ID = PD.e_ID
               WHERE (E.[Child_Number] = 0 or E.[emp_ID] = 1) and E.[Class_ID] like @szEClass_ID
        AND (@employeestable=0 OR ((E.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and E.class_id like u.psc_id+'%'))))

        SET NOCOUNT OFF
        GOTO SUCCI
 end
    
END

SUCCE: drop table #QD
        drop table #tmpSK
        drop table #tmpBQXShj
 drop table ##EmpAccount
        RETURN 0     
SUCCI: drop table #QDI
        drop table #tmpSKI
        drop table #tmpBQXShjI
 drop table ##EmpAccountI
        RETURN 0
GO
