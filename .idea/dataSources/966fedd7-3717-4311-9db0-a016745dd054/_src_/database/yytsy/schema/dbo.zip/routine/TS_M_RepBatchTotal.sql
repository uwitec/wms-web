


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/



/*销售品种报表*/

CREATE PROCEDURE TS_M_RepBatchTotal
(
  @szBeginDate	varchar(10),
  @szEndDate	varchar(10),
  @nS_Id	int,
  @nP_Id	int,
  @nYClassID       Varchar(50)='',
  @nloginEID    int=0,
  @isaddDate    int=0
)
AS
/*exec TS_M_RepBatchTotal;1 '2015-02-01','2015-02-06',0,0,'',2,1*/
/*Params Ini begin*/
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
/*
DECLARE  @szBeginDate	varchar(10)
DECLARE  @szEndDate	varchar(10)
DECLARE @nP_Id	int
DECLARE @nS_Id	int
set @szBeginDate='2008-08-01' set @szEndDate='2008-09-02'
set @nP_Id=10 set @nS_Id=2
*/
DECLARE @SQL 	VARCHAR(8000)
DECLARE @szP_Id VARCHAR(100)
DECLARE @szS_Id VARCHAR(100)
DECLARE @szYClassID varchar(100)
Declare @Companytable INTEGER,@Storetable integer
create table #Companytable([id] int)
create table #storagestable([id] int)

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


   SELECT 
	A.SQQuantity,A.InQuantity,A.OutQuantity,A.BQQuantity,
	A.location_id,A.supplier_id,A.costprice,A.s_id,A.batchno,A.makedate,A.validdate,A.Product_id,'' as scomment,
    a.factory,P.Code,P.Name,P.Alias,P.Pinyin,P.Standard,P.PermitCode,P.MakeArea,P.UnitName1,P.MedType,
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    S.Name as SName,L.Loc_Name as LName,C.Name as CName
    FROM 
    (
	SELECT  
	/*上期存=(库存-查询开始日期到现在的库存)*/
	(isnull(SH.Quantity,0) - sum(case when (PD.BILLDATE>=@szBeginDate) then isnull(PD.quantity,0) else 0 end)) as SQQuantity,
	/*本期入库数量*/
	sum(case when ( (PD.quantity>0) and (PD.BILLDATE BETWEEN  @szBeginDate AND @szEndDate) ) then  isnull(PD.quantity,0) else 0 end) as InQuantity,
	/*本期出库数量*/
	sum(case when ( (PD.quantity<0) and (PD.BILLDATE BETWEEN  @szBeginDate AND @szEndDate) ) then  -isnull(PD.quantity,0) else 0 end) as OutQuantity,
	/*本期存=(库存-查询结束日期到现在的库存)*/
	(isnull(SH.Quantity,0) - sum(case when (PD.BILLDATE>@szEndDate) then isnull(PD.quantity,0) else 0 end)) as BQQuantity,	
	PD.location_id,PD.supplier_id,PD.costprice,PD.s_id,PD.batchno,PD.makedate,PD.validdate,PD.p_id as Product_id,sh.Factory
	FROM dbo.vw_L_YProductdetail	PD 

	INNER JOIN    /*XXX.2017-02-22  这儿需要按批次合并汇总*/
        (select SUM(quantity) as Quantity,location_id,supplier_id,costprice, s_id, batchno, makedate, validdate, p_id,factory,Y_ID,instoretime from VW_C_Storehouse where (''='' or YClass_ID like ''+'%')
		     and ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
		     and ((@Storetable=0) OR (s_id in (select [id] from #storagestable)))
		     group by location_id,supplier_id,costprice, s_id, batchno, makedate, validdate, p_id,factory,Y_ID,instoretime
        )SH		 
		ON SH.location_id=PD.location_id and SH.supplier_id=PD.supplier_id 
	        and SH.costprice=PD.costprice and SH.s_id=PD.s_id and SH.batchno=PD.batchno and SH.makedate=PD.makedate 
	        and SH.validdate=PD.validdate and SH.p_id=PD.p_id
	        and SH.Y_ID=PD.Y_ID and SH.instoretime=PD.instoretime 
	WHERE PD.BILLSTATES='0' AND   PD.storetype=0
          AND PD.BILLDATE>=@szBeginDate 	 
	  AND (@nP_id=0 or PD.P_id=@nP_id)
          AND (@NS_Id=0 OR PD.S_id=@nS_id)

	  GROUP BY PD.location_id,PD.supplier_id,PD.costprice,PD.s_id,PD.batchno,PD.makedate,PD.validdate,PD.p_id,SH.Quantity,sh.Factory
    )A
    LEFT JOIN vw_c_products 	P	ON P.Product_id=A.Product_id
    LEFT JOIN Storages		S	ON S.Storage_id=A.S_ID
    LEFT JOIN Location		L	ON A.location_id=L.loc_id
    LEFT JOIN Clients		C	ON C.Client_id=A.supplier_id

UNION ALL/*----------------------*/

    SELECT 
	A.SQQuantity,A.InQuantity,A.OutQuantity,A.BQQuantity,
	A.location_id,A.supplier_id,A.costprice,A.s_id,A.batchno,A.makedate,A.validdate,A.Product_id,A.scomment,
    a.factory,P.Code,P.Name,P.Alias,P.Pinyin,P.Standard,P.PermitCode,P.MakeArea,P.UnitName1,P.MedType,
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
    S.Name as SName,L.Loc_Name as LName,C.Name as CName
    FROM 
    (
	SELECT  
	/*上期存=(库存-查询开始日期到现在的库存)*/
	(isnull(SH.Quantity,0) - sum(case when (B.BILLDATE>=@szBeginDate) then isnull(PD.quantity,0) else 0 end)) as SQQuantity,
	/*本期入库数量*/
	sum(case when ( (PD.quantity>0) and (B.BILLDATE BETWEEN  @szBeginDate AND @szEndDate) ) then  isnull(PD.quantity,0) else 0 end) as InQuantity,
	/*本期出库数量*/
	sum(case when ( (PD.quantity<0) and (B.BILLDATE BETWEEN  @szBeginDate AND @szEndDate) ) then  -isnull(PD.quantity,0) else 0 end) as OutQuantity,
	/*本期存=(库存-查询结束日期到现在的库存)*/
	(isnull(SH.Quantity,0) - sum(case when (B.BILLDATE>@szEndDate) then isnull(PD.quantity,0) else 0 end)) as BQQuantity,	
	PD.location_id,PD.supplier_id,PD.costprice,PD.s_id,PD.batchno,PD.makedate,PD.validdate,PD.p_id as Product_id,PD.scomment,
	sh.Factory
	FROM productDetail 	PD 
	LEFT JOIN BILLIDX  	B	ON B.BILLID=PD.BILLID
	LEFT JOIN   /*XXX.2017-02-22  这儿需要按批次合并汇总*/
        (select SUM(quantity) as Quantity,location_id,supplier_id,costprice, s_id, batchno, makedate, validdate, p_id,factory,Y_ID,instoretime from VW_C_Storehouse where (''='' or YClass_ID like ''+'%')
		     and ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
		     and ((@Storetable=0) OR (s_id in (select [id] from #storagestable)))
		     group by location_id,supplier_id,costprice, s_id, batchno, makedate, validdate, p_id,factory,Y_ID,instoretime
        )SH	 
		ON SH.location_id=PD.location_id and SH.supplier_id=PD.supplier_id 
	        and SH.costprice=PD.costprice and SH.s_id=PD.s_id and SH.batchno=PD.batchno and SH.makedate=PD.makedate 
	        and SH.validdate=PD.validdate and SH.p_id=PD.p_id 
	        and SH.Y_ID=PD.Y_ID and SH.instoretime=PD.instoretime 
	WHERE B.BILLSTATES='0' AND   PD.storetype=0
          AND B.BILLDATE>=@szBeginDate	 
          AND (@nP_id=0 or PD.P_id=@nP_id)
          AND (@NS_Id=0 OR PD.S_id=@nS_id)
	  GROUP BY PD.location_id,PD.supplier_id,PD.costprice,PD.s_id,PD.batchno,PD.makedate,PD.validdate,PD.p_id,SH.Quantity,PD.scomment,sh.Factory 
    )A
    LEFT JOIN vw_c_products 	P	ON P.Product_id=A.Product_id
    LEFT JOIN Storages		S	ON S.Storage_id=A.S_ID
    LEFT JOIN Location		L	ON A.location_id=L.loc_id
    LEFT JOIN Clients		C	ON C.Client_id=A.supplier_id
GO
