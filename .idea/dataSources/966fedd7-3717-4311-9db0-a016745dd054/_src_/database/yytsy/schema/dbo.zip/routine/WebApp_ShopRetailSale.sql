CREATE PROC WebApp_ShopRetailSale
( 
	@Begindate datetime = 0,
    @Enddate   datetime = 0,
	@nPosId	INT = 0,
    @nStorageId	INT = 0
)
AS
BEGIN
	--参考916脚本TS_H_EHandInRetailTotal.sql
	DECLARE @SaleMan VARCHAR(60)
	SET @SaleMan = '' --调试用正式发须删除
	IF (@SaleMan = '') OR (@SaleMan = '000000') 
		SET @SaleMan = '%%' 
	ELSE 
		SET @SaleMan = @SaleMan + '%'
	
	--SET @nPosId = 0  --调试用正式发须删除
	
	DECLARE @SQLScript   VARCHAR(8000)
	DECLARE @SQLScript1  VARCHAR(8000)
	DECLARE @SQLScript2  VARCHAR(8000)

	DECLARE @BankClassID      VARCHAR(300)
	DECLARE @BankName         VARCHAR(300)
	DECLARE @FieldName        VARCHAR(80) 
	DECLARE @FieldNameHead    VARCHAR(30)
	DECLARE @FieldNameCounter INT

	DECLARE @SQL1	     VARCHAR(8000)
	DECLARE @SQL2	     VARCHAR(8000)
	DECLARE @SQL3	     VARCHAR(8000)
	DECLARE @SQL4	     VARCHAR(8000)

	--初始化变量
	SELECT @SQLScript = '', @SQLScript1 = '', @SQLScript2 = '', @BankClassID = '', @BankName = '', @FieldName = '', @FieldNameHead = '', @SQL1 = '', @SQL2 = '', @SQL3 = '', @SQL4 = ''

	
	DECLARE @SQLElse VARCHAR(8000)  --按时间段汇总的汇总动态列
	SET @SQLElse = ''

	SELECT @FieldNameHead = 'FIELD_NAME', @FieldNameCounter = 1
	SELECT @FieldName = @FieldNameHead + CAST(@FieldNameCounter AS VARCHAR)
	
	--游标取得银行帐户的动态Sql
	DECLARE BankSubject_cursor CURSOR FOR
		SELECT  name,class_id
			FROM    vw_Account
		WHERE 	class_id Like '000001000004%' and Child_number = 0 or class_id='000002000006' or class_id='000004000003000008' or class_id='000004000003000009' 
				or class_id='000001000012' or class_id='000001000013'
		ORDER BY [Class_ID] DESC  

	OPEN BankSubject_cursor

	FETCH NEXT FROM BankSubject_cursor INTO @BankName,@BankClassID
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		SET @BankName = REPLACE(@BankName,' ','')--去除名字中的空格字符
		SET @SQL1 = @SQL1 + ' ISNULL(SUM(ABS(RB.['+@FieldName+'])),0) AS ['+@FieldName+'],'
		SET @SQL2 = @SQL2 + 'AD.['+       @FieldName+'] AS ['+       @FieldName+'],'
		SET @SQL3 = @SQL3 + 'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
								') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
	                            
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'
		
		SET @FieldNameCounter = @FieldNameCounter + 1
		SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter AS VARCHAR)
		/*
		SET @SQL1 = @SQL1 + ' ISNULL(SUM(abs(RB.['+@FieldName+'])),0) AS ['+@FieldName+'],'
		SET @SQL2 = @SQL2 + 'AD.['+@FieldName+'] AS ['+@FieldName+'],'
		SET @SQL3 = @SQL3 + 'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
								') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
	                            
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'
		
	    -- 现金、银行合计
		SET @FieldNameCounter = @FieldNameCounter + 1
		SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter AS VARCHAR)

	
		IF @bankclassid='000002000006'
			SET @SQL1 = @SQL1 + ' ISNULL(SUM(-RB.['+@FieldName+']),0) AS ['+@FieldName+'],'
		ELSE
		    SET @SQL1 = @SQL1 + ' ISNULL(SUM(RB.['+@FieldName+']),0) AS ['+@FieldName+'],' 

		SET @SQL2 = @SQL2 + ' AD.['+@FieldName+'] AS ['+@FieldName+'],'
		SET @SQL3 = @SQL3 + ' ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
								') THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
	                            
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'                     
	    --现金、银行合计

		SET @FieldNameCounter = @FieldNameCounter + 1
		SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter AS VARCHAR)
		*/	 
		--PRINT @SQLElse
		FETCH NEXT FROM BankSubject_cursor
		INTO @BankName,@BankClassID
	END

	CLOSE BankSubject_cursor
	DEALLOCATE BankSubject_cursor 
	--游标取得银行帐户的动态Sql END

	SET @SQLScript = '
	SELECT  0   AS  SerialNo,
	 E.NAME   AS  EName,
	 ISNULL(SUM(RB.YsMoney),0)  		AS YsMoney,  
	 ISNULL(SUM(RB.YfMoney),0)  		AS YfMoney,  
	 ISNULL(SUM(RB.Quantity),0)  		AS Quantity,
	 ISNULL(SUM(RB.SaleMoney),0)  		AS SaleMoney,
	 ISNULL(SUM(RB.TotalMoney),0)  		AS TotalMoney,
	 ISNULL(SUM(RB.BackQuantity),0)  	AS BackQuantity,
	 ISNULL(SUM(RB.BackTotalMoney),0) 	AS BackTotalMoney,
	 ISNULL(SUM(RB.TaxTotal),0)             AS TaxTotal,
	 ISNULL(SUM(RB.BackTaxTotal),0)         AS BackTaxTotal,
	 ISNULL(SUM(RB.BillDiscount),0)         AS BillDiscount,
	 ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,
	 ISNULL(SUM(RB.CashMoney),0)  		AS CashMoney,
	 -ISNULL(SUM(RB.BackCashMoney),0) 	AS BackCashMoney,'
	SET @SQLScript = @SQLScript+ @SQL1 + '
	 ISNULL(SUM(RB.DiscountMoney),0)  	AS DiscountMoney,
	 ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY),0)     	AS  skTotalMoney,
	 -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY),0)    AS  fkTotalMoney,
	 ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)            AS  ssTaxTotal,                            
	 ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0)    AS  ssBillDisCount,                        
	 ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)               AS  ssYsMoney,                             
	 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0)     	AS  ssCashTotalMoney,
	 ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0)     	AS  ssBankTotalMoney,
	 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY),0) AS  ssTotalMoney
	 INTO #mydata FROM (SELECT * from  vw_L_Company VC 
		  WHERE (vc.Child_number = 0) and vc.Deleted = 0
		  AND ('+char(39)+cast(@nPosId as varchar(10))+char(39)+'=0 or company_id='+char(39)+cast(@nPosId as varchar(10))+char(39)+')) E 
	LEFT JOIN( 
	 SELECT
			ri.Y_ID,
			RI.BillID        AS BillID,
			CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,
			CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney, 
			RB.quantity           AS Quantity,
			RB.SaleMoney          AS SaleMoney,
			RB.TotalMoney         AS TotalMoney,
			RB.Backquantity       AS BackQuantity,
			RB.BackTotalMoney     AS BackTotalMoney,
			RB.TaxTotal           AS TaxTotal,
			RB.BackTaxTotal       AS BackTaxTotal, 
			AD.BillDiscount       AS BillDiscount,
			AD.BackBillDiscount   AS BackBillDiscount,
			AD.CashMoney          AS CashMoney,
			AD.BackCashMoney      AS BackCashMoney,
			AD.BankMoney          AS BankMoney,
			AD.BackBankMoney      AS BackBankMoney,
			AD.CZZKMONEY          AS CZZKMONEY,
			AD.BackCZZKMONEY      AS BackCZZKMONEY,
			AD.DJQMONEY          AS DJQMONEY,
			AD.BackDJQMONEY      AS BackDJQMONEY,
			AD.JFDXMONEY          AS JFDXMONEY,
			AD.BackJFDXMONEY      AS BackJFDXMONEY,'
	SET @SQLScript1 = ' 
			CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney
	 FROM (SELECT * FROM VW_X_BILLIDX 
		   WHERE EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)+' 
		   AND [BillStates] IN (0) AND ('+char(39)+cast(@nPosId as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nPosId as varchar(10))+char(39)+')

		   AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR(10))+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR(10))+CHAR(39)+'
		  ) RI 
	 LEFT JOIN (SELECT BI.BILLId,
					   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)                  as Quantity,
					   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0)  as saleMoney,
					   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0)                as TotalMoney,
					   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0)                  as TaxTotal,
					   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)                  as BackQuantity,
					   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0)                  as BackTaxTotal,
					   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0)                as BackTotalMoney
			   FROM billidx BI 
			   LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id 
			   WHERE BI.BILLTYPE in(12,13) AND ('+char(39)+cast(@nPosId as varchar(10))+char(39)+'=0 or bi.Y_id='+char(39)+cast(@nPosId as varchar(10))+char(39)+')     
			   GROUP BY BI.BILLID
	 
			   ) RB ON RI.BillID = RB.BillID
	 
	 LEFT JOIN (SELECT  BI.BILLId,
	       
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 13) THEN JDMONEY ELSE 0 END),0) AS BackBILLDISCOUNT,'

	SET @SQLScript2 = 
	  'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,

	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,
	 
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,
	 
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,
	   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY
	 
	   FROM BILLIDX BI 
	   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID 
	   WHERE BI.BILLTYPE in(12,13) and ('+char(39)+cast(@nPosId as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nPosId as varchar(10))+char(39)+')
	   GROUP BY BI.BILLID   
	 ) AD ON RI.BillID = AD.BillID
	 WHERE RI.BillType in(12,13)
	) RB ON E.company_id = RB.y_id
	GROUP BY E.NAME
	ORDER BY E.name ' 
	SET @SQLScript2 = @SQLScript2+
	'SELECT ename AS PosName,SUM(Quantity) AS SaleQuantity,SUM(SaleMoney) AS SaleTotal,SUM(BackQuantity) as SaleBackQuantity, SUM(BackTotalMoney) AS SaleBackTotal,
	(SUM(SaleMoney) - SUM(BackTotalMoney)) AS BQSKDje,
	
	
	SUM(ssCashTotalMoney) AS Cash,
	(SUM(SaleMoney) - SUM(BackTotalMoney)) - SUM(ssCashTotalMoney) AS fh6
	 FROM #mydata GROUP BY ename ORDER BY ename'

	EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2) 
	--print (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2) 
END
GO
