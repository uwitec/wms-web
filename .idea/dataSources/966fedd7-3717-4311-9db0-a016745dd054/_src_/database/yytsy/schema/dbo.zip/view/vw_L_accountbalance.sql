
CREATE VIEW dbo.vw_L_accountbalance
AS

  SELECT AB.* ,ISNULL(A.class_id,'')AClass_ID,ISNULL(A.[name],'')Aname,
  ISNULL(Y.class_id,'')Yclass_ID, ISNULL(Y.[name],'')Yname

  FROM  accountbalance AB
  
   LEFT OUTER JOIN  account    A  ON AB.a_id=a.account_id
   LEFT OUTER JOIN  Company    Y  ON AB.Y_id=Y.company_id
where AB.a_id in (select account_id from account where [deleted]=0)
GO
