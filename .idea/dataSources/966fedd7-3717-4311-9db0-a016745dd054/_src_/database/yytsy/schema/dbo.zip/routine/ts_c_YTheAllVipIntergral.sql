

create proc ts_c_YTheAllVipIntergral
(
	@nbillid int,
	@nbilltype int,
	@nCalcFlag int = 0
)
/*with encryption*/
as
/*Params Ini begin*/
if @nCalcFlag is null  SET @nCalcFlag = 0
/*Params Ini end*/
/*set nocount on*/

        /*储值       积分              会员卡ID     */
declare @isbank int,@isIntergral int,@Vipcardid int,@iscxIntegral int
        /*积分余额            */
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
        /*消费积分余额*/
declare @saleIntegralYE NUMERIC(25,8)
        /*记录储值金额变化结果*/
declare @money NUMERIC(25,8)
        /*卡类ID*/
declare @ctid int
       /*当前积分            修改积分             */
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8)
        /*消费积分*/
declare @saleIntegral NUMERIC(25,8),@salemoney NUMERIC(25,8)
        /*储值金额*/
declare @RemainderMoney NUMERIC(25,8)
declare @isSpecialPriceIntegral int
declare @INTEGRALMONEY NUMERIC(25,8)
        /*积分*/
declare @Intergral NUMERIC(25,8)

        /*是否统计积分余额  */
declare @isYeIntegral int, @PriceType int

declare @StoreMoney_ID int, @isZBZT int
select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/
declare @billguid varchar(50), @y_id int
select @billguid = guid, @Y_id = Y_ID from billidx where billid = @nBillId 

if exists(select * from sysconfig  where [sysname] = 'YClassid' and [sysvalue] = '000001' and Y_ID = 0)
  set @isZBZT = 1
else 
  set @isZBZT = 0        

/*if @nbilltype in (12,13,10,11,210,211)*/
if @nbilltype in (12,13)
begin
          select @ctid=v.ct_id,@money=v.RemainderMoney,@salemoney=b.ssmoney,@Vipcardid=b.Vipcardid,@isbank=v.isbank,
             @isYeIntegral=isYeIntegral, /*是否统计积分余额, 门店不处理余额积分*/
             @isSpecialPriceIntegral=V.isSpecialPriceIntegral,  @iscxIntegral=IsCxIntegral,  
             @order=b.billnumber,@isIntergral=V.isIntegral,@INTEGRALMONEY=v.INTEGRALMONEY,@Intergral=v.Integral
             from Yretailbillidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid

      /*储值金额消费总额*/
      select @RemainderMoney=abs(isnull(sum(total),0)) from YRetailBill where bill_id=@nBillId and p_id=-@StoreMoney_ID 
      /*整单金额*/
      
      
      select @totalmoney=isnull(sum(taxtotal),0) from YRetailBill where bill_id=@nBillid
      and (@isSpecialPriceIntegral=1 or (@isSpecialPriceIntegral=0 and PriceType<>7))
      and (@iscxIntegral=1 or (@iscxIntegral=0 and cxType=0))
      and p_id>0
      select  @totalmoney= @totalmoney -isnull(sum(total),0)
        from YRetailBill sm ,account a 
       where bill_id=@nBillid
           and abs(sm.p_id) = a.account_id
           and a.class_id = '000004000003000004'
           
      if @INTEGRALMONEY<>0 
      begin
        /*换算积分*/
        select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@INTEGRALMONEY) as int) 
        /*积分余额*/
        if @isYeIntegral=1 
          select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@INTEGRALMONEY as int)*@INTEGRALMONEY)
        else
          select  @saleIntegralYE=0
      end
end

/*if @nbilltype in (10,12,210) and @Vipcardid>0*/
if @nbilltype in (12) and @Vipcardid>0
begin
    if @isIntergral=1
    begin
        if @isZBZT=1
        begin
          select @IntegralYE=@IntegralYE+@saleIntegralYE
          select @modIntergral=@saleIntegral+cast((@IntegralYE/@INTEGRALMONEY) as int)
          select @IntegralYE=@IntegralYE-cast((@IntegralYE/@INTEGRALMONEY) as int)*@INTEGRALMONEY
          select @nowIntergral=@Intergral+@modIntergral
          update Vipcard set Integral=Integral+@modIntergral,IntergralYE=@IntegralYE where VipCardid=@Vipcardid
        end
        else
        begin
          select @modIntergral=@saleIntegral 
          select @nowIntergral=@Intergral+@saleIntegral
          update Vipcard set Integral=Integral+@saleIntegral,IntergralYE=IntergralYE+@saleIntegralYE where VipCardid=@Vipcardid
        end
       
         update Yretailbillidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where billid = @nBillId 
         /*if @nbilltype in (12, 13)*/
         /*  update Yretailbillidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid*/
    end
    else
    begin  
      select @nowIntergral=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modIntergral=0
    end

    if (@isbank=1) 
    begin
      update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid        

      select @nowmoney=@money-@RemainderMoney,@modmoney=-@RemainderMoney
    end
    else
    begin
      select @nowmoney=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modmoney=0
    end  

    if (@isbank=1) or (@isIntergral=1)
    begin
      update Vipcard set TotalBuyMoney=isnull(TotalBuyMoney,0)+@salemoney,BuyCount=isnull(BuyCount,0)+1 where Vipcardid=@Vipcardid  
  
    end
    select @ntag=15
    select @comment='零售单：【'+@order+'】'

    exec ts_SetSysValue 'VIPIntegral',@modIntergral,@Y_id/*在sys中记录本次消费积分，在打印小票的时候取出。*/
end


/*if @nbilltype in (11,13,211) and @Vipcardid>0*/
if @nbilltype in (13) and @Vipcardid>0
begin
	if @isIntergral=1
	begin
      select @modIntergral=-@saleIntegral 
      select @nowIntergral=@Intergral-@saleIntegral
      update Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
                    
      update Yretailbillidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where billid = @nBillId
      /*if @nbilltype in (12, 13)*/
      /*  update Yretailbillidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where VIPCardID = @Vipcardid and [GUID] = @billguid  */
 	end
	else 
	begin
	  select @nowIntergral=0/* from Vipcard where Vipcardid=@Vipcardid*/
	  select @modIntergral=0
	end
	
	if (@isbank=1)   
	begin
	  update Vipcard set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid
          
	  select @nowmoney=@money+@RemainderMoney,@modmoney=@RemainderMoney
	end
	else
	begin
	  select @nowmoney=0 /*from vipcard where vipcardid=@Vipcardid*/
	  select @modmoney=0
	end
	
	if (@isbank=1) or (@isIntergral=1)         
	  update Vipcard set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1  where Vipcardid=@Vipcardid

	  
    select @ntag=16 
	select @comment='零售退货单：【'+@order+'】'

end

if  @Vipcardid>0 and @nCalcFlag = 0
  exec TS_L_InsVIPCardLog @ntag,'','',@Vipcardid,@nowIntergral,@modIntergral,@nowmoney,@modmoney,0,@comment
GO
