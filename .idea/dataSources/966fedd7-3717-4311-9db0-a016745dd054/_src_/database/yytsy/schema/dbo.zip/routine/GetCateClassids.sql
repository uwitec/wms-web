/************************************************************

XXX.2017-04-26  
--功能：根据id返回对应的自定义类别的classid 串

**************************************************************/

/*select * from CategoryGroups*/

CREATE function [GetCateClassids]
  ( @Ids VARCHAR(2000)
  )
  returns nvarchar(2000)
AS 

  begin
	declare @returnStr nvarchar(2000)
	declare @classid varchar(50)

	/*
	insert @t select substring(@str, number, charindex(',', @str + ',', number) - number) from 
	master..spt_values where type='p' and substring(',' + @str, number,1) = ',' 
	*/

	set @returnStr = ''
	declare @curCate cursor
	set @curCate = cursor for
	select class_id from customCategory where id in (select type from dbo.DecodeStr(@Ids))

   open @curCate
	FETCH next from @curCate into @classid  
	  while @@FETCH_STATUS = 0
	  begin	    

		    set @returnStr = @returnStr  + @classid  +','
		fetch next from @curCate into @classid    
	  end 
  close @curCate
  deallocate @curCate
  
  return @returnStr
 end
GO
