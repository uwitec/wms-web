-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[WebAPP_Qry_BasicDetail] 
	-- Add the parameters for the stored procedure here
	@chvparams  varchar(400)='',
	@retmessage varchar(200) out
AS
	select @retmessage = '操作成功'
	--解析扩展参数
	declare @datatype varchar(60),
	        @serial_number varchar(30),
            @classid varchar(60),
            @basicname varchar(60),
            @empid int,
            @clientid INT,
	        @YId      INT
	SET @YId = 2 --YYT机构ID需要APP传入参数
	select @datatype = upper(dbo.webapp_get_param(@chvparams, 'datatype', default, default))
	select @serial_number  = dbo.webapp_get_param(@chvparams, 'basiccode', default, default)
	select @empid=dbo.webapp_get_param(@chvparams, 'empid', default, default)
	select @clientid=dbo.webapp_get_param(@chvparams, 'clientid', default, default)
	/*select @classid  = dbo.webapp_get_param(@chvparams, 'classid', default, default)
	select @basicname  = dbo.webapp_get_param(@chvparams, 'basicname', default, default)*/
BEGIN
	if (@datatype=upper('clients')) --往来单位详细信息查询
	begin
		 select c.client_id,c.class_id,c.parent_id,CAST(c.serial_number as nvarchar) serial_number,CAST(c.name as nvarchar) name,CAST(c.alias as nvarchar) alias,
		 c.region_id,cast(c.phone_number as nvarchar) phone_number,CAST(c.[address] as nvarchar) [address],c.zipcode,
		 CAST(c.contact_personal as nvarchar) contact_personal,c.tax_number,c.acount_number,
         ISNULL(d.credit_total,0) credit_total,c.pinyin,c.pricemode,ISNULL(d.sklimit, 0) sklimit,ISNULL(d.artotal,0) artotal,ISNULL(d.aptotal,0) aptotal,
         ISNULL(d.aptotal_ini,0) aptotal_ini,ISNULL(d.artotal_ini,0) artotal_ini,ISNULL(d.pre_aptotal,0) pre_aptotal,ISNULL(d.pre_aptotal_ini,0) pre_aptotal_ini,
         ISNULL(d.pre_artotal,0) pre_artotal,ISNULL(d.pre_artotal_ini,0) pre_artotal_ini,
         CAST(c.comment as nvarchar) comment,
         csflag,GMPNo,GSPNo,'' as QQ 
	     from clients c LEFT JOIN (select * from Clientsbalance cb WHERE cb.Y_id = @YId) d ON c.client_id = d.C_ID   
	     where deleted=0 and child_count=0 and client_id=@clientid 
  end
  else if (@datatype=upper('OnLineEmployee')) --职员详细信息查询
  begin
         select emp_id as _id, serial_number as _code, [name] as _name, depname as d_name, phone,indate,'' as img
         from vw_employee 
         where deleted=0 and child_number=0 and emp_id=@empid 
end
END

----------------------------------------
----------------------------------------
GO
