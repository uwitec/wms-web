







CREATE	PROCEDURE [Ts_L_InsDep]
	(@TableName	[varchar](20)='DEPARTMENT',
	 @serial_number	[varchar](10),
	 @name	[varchar](50),
	 @comment	[varchar](50),
	 @Type_ID int = 0
	)
AS
/*Params Ini begin*/
if @TableName is null  SET @TableName = 'DEPARTMENT'
if @Type_ID is null  SET @Type_ID = 0
/*Params Ini end*/
declare  @tempId  varchar(30),
         @child_number  [int],
         @child_count [int],
         @Numbertmp int           
 
if upper(@TableName)='DEPARTMENT'
BEGIN
   if exists(select * from department where ([name]=@name or serial_number=@serial_number))
   begin
   	RAISERROR('部门名称或部门编号重复，请检查',16,1) 
	return 0
   end 
	INSERT INTO [department] 
		 ( [serial_number],
		 [name],
		 [comment],
		 [Type_id]
		 )	 
	VALUES 
		(@serial_number,
		 @name,
		 @comment,
		 @Type_ID
		 )
	if @@rowcount <>0 
		return @@IDENTITY
	else return 0

END
if upper(@TableName)='REGION'
begin
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid('000000','Region')

	  INSERT INTO [Region] 
          ([class_id],
           [parent_id],
           [serial_number],
           [name],
           [Comment],
           [Rowindex],
           [Deleted]
          ) 
          VALUES 
 	 (@tempid,
  	  '000000',
  	  @serial_number, 
  	  @name,
  	  @comment,
  	  0,
          0
         )
	if @@rowcount <>0
        Begin 
              select @NumberTmp = @@IDENTITY
              update [Region] set child_number=@child_number,child_count=@child_count where class_id = '000000'
              update [Region] set [serial_number]=@NumberTmp where class_id =@tempid
              return  @@IDENTITY
        End 
	else return 0
end

if upper(@TableName)='clienttype'
begin
	INSERT INTO [clienttype] 
		 ([name]
		 ) 
 
	VALUES 
		(
		 @name
		)
	if @@rowcount <>0 
		return @@IDENTITY
	else return 0
end
GO
