

create proc ts_c_TheAllVipIntergral
(
	@nbillid int,
	@nbilltype int,
	@nCalcFlag int = 0,
	@nUpFlag int = 0 /*--是否是上传单据，避免计算积分时重复扣减储值金额  1 :是, 0 : 不是*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @nCalcFlag is null  SET @nCalcFlag = 0
/*Params Ini end*/
/*set nocount on*/

        /*储值       积分              会员卡ID     */
declare @isbank int,@isIntergral int,@Vipcardid int,@iscxIntegral int
declare @CanIntegral int /*-是否计算积分*/
        /*积分余额            */
declare @IntegralYE NUMERIC(25,8),@OrverIntegral NUMERIC(25,8),@OrverYE NUMERIC(25,8)
        /*消费积分余额*/
declare @saleIntegralYE NUMERIC(25,8)
        /*记录储值金额变化结果*/
declare @money NUMERIC(25,8)
        /*卡类ID*/
declare @ctid int
       /*当前积分            修改积分             */
declare @nowIntergral NUMERIC(25,8),@modIntergral NUMERIC(25,8),@nowmoney NUMERIC(25,8),@modmoney NUMERIC(25,8),@ntag int,@order varchar(50),@comment varchar(50)
declare @Pclassid varchar(50),@totalmoney NUMERIC(25,8),@CTIntegral NUMERIC(25,8)
        /*消费积分*/
declare @saleIntegral NUMERIC(25,8),@salemoney NUMERIC(25,8)
        /*储值金额*/
declare @RemainderMoney NUMERIC(25,8)
declare @isSpecialPriceIntegral int
declare @INTEGRALMONEY NUMERIC(25,8)
        /*积分*/
declare @Intergral NUMERIC(25,8)

        /*是否统计积分余额  */
declare @isYeIntegral int, @PriceType int

/*初始化,避免出现null*/
set @nowIntergral=0
set @modIntergral=0 
set @nowmoney=0 
set @modmoney=0 
set @comment=''
set @IntegralYE = 0 
set @OrverIntegral =0 
set @OrverYE = 0 
set @saleIntegralYE =0 
set @money =0
set @CanIntegral = 0

declare @StoreMoney_ID int, @isZBZT int
select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/
declare @billguid varchar(50), @y_id int
select @billguid = guid, @Y_id = Y_ID from billidx where billid = @nBillId 

if exists(select * from sysconfig  where [sysname] = 'YClassid' and [sysvalue] = '000001' and Y_ID = 0)
  set @isZBZT = 1
else 
  set @isZBZT = 0        

if @nbilltype in (12,13,10,11,210,211,243)
begin
          select @ctid=v.ct_id,@money=v.RemainderMoney,@salemoney=b.ssmoney,@Vipcardid=b.Vipcardid,@isbank=v.isbank,
             @isYeIntegral=isYeIntegral, /*是否统计积分余额, 门店不处理余额积分*/
             @isSpecialPriceIntegral=V.isSpecialPriceIntegral,  @iscxIntegral=IsCxIntegral,@CanIntegral = auditman, /*零售单重auditman 表示是否计算积分  */
             @order=b.billnumber,@isIntergral=V.isIntegral,@Intergral=v.Integral, @IntegralYE=v.IntergralYE
             from billidx b,vw_M_VipCard v where b.billid=@nBillId and
             v.vipcardid=b.vipcardid
         if @nbilltype  not in (12,13) /*-只有零售类单据才进行判断*/
           set @CanIntegral = 0
         select @INTEGRALMONEY=dbo.GetIntegralMoney(@ctid, GETDATE())                  

      /*储值金额消费总额*/
      select @RemainderMoney=abs(isnull(sum(total),0)) from salemanageBill where bill_id=@nBillId and p_id=-@StoreMoney_ID 
      /*整单金额*/
      
      /*有积分的消费金额*/
      select @totalmoney=isnull(sum(s.taxtotal),0) 
      from salemanageBill s,products p
      where bill_id=@nBillid and s.p_id=p.product_id and p.ifIntegral=1
      and (@isSpecialPriceIntegral=1 or (@isSpecialPriceIntegral=0 and PriceType<>7))
      and (@iscxIntegral=1 or (@iscxIntegral=0 and cxType=0))
      and p_id>0 and AOID in (0,5)
      
      /*计算折让金额，折让金额不积分*/
      select  @totalmoney= @totalmoney -isnull(sum(total),0)
        from salemanageBill sm ,account a 
       where bill_id=@nBillid
           and abs(sm.p_id) = a.account_id and sm.p_id<0
           and a.class_id = '000004000003000004'
           
      if @INTEGRALMONEY<>0 
      begin
        /*换算积分*/
        select  @saleIntegral=isnull(@saleIntegral,0)+cast((@totalmoney/@INTEGRALMONEY) as int) 
        /*积分余额*/
        if @isYeIntegral=1 
          select  @saleIntegralYE=isnull(@saleIntegralYE,0)+(@totalmoney-cast(@totalmoney/@INTEGRALMONEY as int)*@INTEGRALMONEY)
        else
          select  @saleIntegralYE=0
      end
end

if @nbilltype in (10,12,210,243) and @Vipcardid>0
begin
    if (@isIntergral=1) and (@CanIntegral = 0)
    begin
        if @isZBZT=1
        begin
          select @IntegralYE=@IntegralYE+@saleIntegralYE
          select @modIntergral=@saleIntegral+cast((@IntegralYE/@INTEGRALMONEY) as int)
          select @IntegralYE=@IntegralYE-cast((@IntegralYE/@INTEGRALMONEY) as int)*@INTEGRALMONEY
          select @nowIntergral=@Intergral+@modIntergral
          update Vipcard set Integral=Integral+@modIntergral,IntergralYE=@IntegralYE where VipCardid=@Vipcardid
        end
        else
        begin
          select @modIntergral=@saleIntegral 
          select @nowIntergral=@Intergral+@saleIntegral
          update Vipcard set Integral=Integral+@saleIntegral,IntergralYE=IntergralYE+@saleIntegralYE where VipCardid=@Vipcardid
        end
         update billidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where billid = @nBillId 
         if @nbilltype in (12, 13)
         begin
		   update retailbillidx set integral = @saleIntegral, IntegralYE = @saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
		   update billdraftidx set integral=@saleIntegral,integralYE=@saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
         end
         declare @autoUpgrade bit
         declare @isMoneyUp int
         declare @isIntegralUp int
         declare @UpMoney NUMERIC(25,8)
         declare @UpIntegral int
         declare @CardMoney NUMERIC(25,8)
         declare @CardIntegral int
         declare @nRet int
         declare @UpDecIntegral int
         declare @CurInteger int
         declare @UpDecIntegral2 int
         
        select @autoUpgrade = t.isAutoUpgrade, @isMoneyUp = t.isMoneyUp, @isIntegralUp = t.isIntegralUp,
			@UpMoney = t.UpMoney, @UpIntegral = t.UpIntegral, @CardMoney = v.TotalBuyMoney, @CardIntegral = v.Integral,
			@UpDecIntegral = t.UpDecIntegral
		from VIPCardType t inner join VIPCard v on t.ct_id = v.CT_ID where v.VIPCardID = @Vipcardid
		if @autoUpgrade = 1
		begin
			set @CurInteger = @CardIntegral - @UpDecIntegral
			set @UpDecIntegral2 = -@UpDecIntegral
			set @nRet = -1
			if (@isMoneyUp = 1) and (@CardMoney >= @UpMoney)
			begin
				exec @nRet = TS_L_VIPCardLevelUp 1, @VipCardId
				if @nRet >= 0
					exec TS_L_InsVIPCardLog 13, 0, '服务器', @Vipcardid, @CurInteger, @UpDecIntegral2, 0, 0, @vipcardid, '系统自动升级'
			end
			if (@nRet < 0) AND (@isIntegralUp = 1) and (@CardIntegral >= @UpIntegral)
			begin
				exec @nRet = TS_L_VIPCardLevelUp 2, @VipCardId
				if @nRet >= 0
					exec TS_L_InsVIPCardLog 14, 0, '服务器', @Vipcardid, @CurInteger, @UpDecIntegral2, 0, 0, @vipcardid, '系统自动升级'
			end
		end
    end
    else
    begin  
      select @nowIntergral=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modIntergral=0
    end

    if (@isbank=1)  
    begin
      if @nUpFlag = 0 /*上传单据不扣减储值金额 add by luowei 2012-10-25*/
      begin
		  update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid        

		  select @nowmoney=@money-@RemainderMoney,@modmoney=-@RemainderMoney
      end
      else
      begin
          select  @nowmoney = @money,@modmoney = -@RemainderMoney 
      end
    end
    else
    begin
      select @nowmoney=0 /*from vipcard where Vipcardid=@Vipcardid*/
      select @modmoney=0
    end  

    if (@isbank=1) or (@isIntergral=1)
    begin
      update Vipcard set TotalBuyMoney=isnull(TotalBuyMoney,0)+@salemoney,BuyCount=isnull(BuyCount,0)+1 where Vipcardid=@Vipcardid  
  
    end
    select @ntag=15
    select @comment='零售单：【'+@order+'】'

    exec ts_SetSysValue 'VIPIntegral',@modIntergral,@Y_id/*在sys中记录本次消费积分，在打印小票的时候取出。*/
end


if @nbilltype in (11,13,211) and @Vipcardid>0
begin
	if (@isIntergral=1) and (@CanIntegral = 0) 
	begin
	   select @modIntergral=-@saleIntegral 
	   select @nowIntergral=@Intergral-@saleIntegral
	   update Vipcard set Integral=Integral-@saleIntegral,IntergralYE=IntergralYE-@saleIntegralYE where VipCardid=@Vipcardid
                
	   update billidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where billid = @nBillId
	   if @nbilltype in (12, 13)
		 begin
		   update retailbillidx set integral = -@saleIntegral, integralYE =(-@saleIntegralYE) where VIPCardID = @Vipcardid and [GUID] = @billguid  
		   update billdraftidx set integral=-@saleIntegral,integralYE=-@saleIntegralYE where VIPCardID = @Vipcardid and [GUID] = @billguid
		 end  
 	end
	else 
	begin
	  select @nowIntergral=0/* from Vipcard where Vipcardid=@Vipcardid*/
	  select @modIntergral=0
	end
	
	if (@isbank=1)   
	begin
	  if @nUpFlag = 0 /*零售退货上传单据不增加储值金额 add by luowei 2012-10-25*/
	  begin 
		update Vipcard set RemainderMoney=RemainderMoney+@RemainderMoney where VipCardid=@Vipcardid
	          
		select @nowmoney=@money+@RemainderMoney,@modmoney=@RemainderMoney
	  end
	  else
	  begin
	    select @nowmoney=@money,@modmoney=@RemainderMoney
	  end
	end
	else
	begin
	  select @nowmoney=0 /*from vipcard where vipcardid=@Vipcardid*/
	  select @modmoney=0
	end
	
	if (@isbank=1) or (@isIntergral=1)         
	  update Vipcard set TotalBuyMoney=TotalBuyMoney-@salemoney,BuyCount=BuyCount-1  where Vipcardid=@Vipcardid

	  
    select @ntag=16 
	select @comment='零售退货单：【'+@order+'】'

end

if  @Vipcardid>0 and @nCalcFlag = 0
  exec TS_L_InsVIPCardLog @ntag,'','',@Vipcardid,@nowIntergral,@modIntergral,@nowmoney,@modmoney,0,@comment
GO
