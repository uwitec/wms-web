
/* exec TS_D_GSTransNum '1234567890123457'*/
CREATE PROCEDURE TS_D_GSTransNum
@GSDDNo VARCHAR(30)
AS
  DECLARE @ReturnStr VARCHAR(50),@TransNum INT 
  SET @ReturnStr=CONVERT(VARCHAR(30),GETDATE(),121)
  SET @ReturnStr=LEFT(REPLACE(REPLACE(REPLACE(@ReturnStr,'-',''),' ',''),':',''),14)
  IF NOT EXISTS(SELECT 1 FROM GSTransNum WHERE GSDDNo=@GSDDNo)
  BEGIN
    INSERT INTO GSTransNum
      (GSDDNo,TransNum)
    SELECT @GSDDNo,0
  END    
  SELECT @TransNum=TransNum FROM GSTransNum WHERE GSDDNo=@GSDDNo
  IF @TransNum>=9999
  BEGIN
    UPDATE GSTransNum SET TransNum=0 WHERE GSDDNo=@GSDDNo
    SET @TransNum=0
  END  
  SET @TransNum=@TransNum+1
  SET @ReturnStr=@ReturnStr+'-'+RIGHT(@GSDDNo,8)+'-'+RIGHT('0000'+CAST(@TransNum AS VARCHAR),4)
  UPDATE GSTransNum SET TransNum=@TransNum WHERE GSDDNo=@GSDDNo
   
  SELECT @ReturnStr
GO
