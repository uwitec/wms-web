
create procedure TS_D_GSQrUpDataE
as 
  SET NOCOUNT ON 
  
  INSERT INTO GSEmployeesMap 
    (emp_id,name,IdCard,DeptName,OTC,XZZW,XSZW,Phone,ZYLB,ZYNo,ZYDate,LCZY,Memo,YSJB,IsUp)
  SELECT a.emp_id,a.name,a.IdCard,'','','','','','','','','','','',0
  FROM employees a LEFT JOIN GSEmployeesMap b 
       ON a.emp_id=b.emp_id 
  WHERE a.child_number=0 AND a.deleted=0 AND b.emp_id IS NULL 
 
  SELECT *
  FROM GSEmployeesMap
  WHERE IsUp=0
GO
