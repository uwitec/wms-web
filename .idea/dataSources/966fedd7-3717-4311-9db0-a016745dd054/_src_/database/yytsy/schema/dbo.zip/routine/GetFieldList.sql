

CREATE  FUNCTION GetFieldList(@TableName varchar(100))  
RETURNS  varchar(2000)
AS  
BEGIN 
  declare 
    @s varchar(2000)
  set @s=''
  SELECT @s=@s+[name]+',' FROM syscolumns where id = object_ID(@TableName) and xtype not in (189)
  set @s=left(@s,len(@s)-1)
  RETURN(@s)
END
GO
