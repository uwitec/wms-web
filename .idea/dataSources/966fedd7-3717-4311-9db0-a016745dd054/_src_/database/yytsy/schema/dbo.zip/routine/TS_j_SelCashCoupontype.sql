
/*代金券类型查询  zjl 2013-06-05*/
create   PROCEDURE TS_j_SelCashCoupontype
(	
  @szTypeName varchar(60), /*名称*/
  @begindate datetime,  /*启用日期 */
  @ValidDate datetime,  /*有效期   */
  @CashC_id  int = 0,   /*代金券id    */
  @nMode integer		/*查询模式 0 sel 1 Qr*/
)
AS

if @CashC_id is null set @CashC_id = 0

if @szTypeName <> ''
    set @szTypeName = '%'+@szTypeName+'%'

if @nMode = 0
begin 

    update cashcoupontype set UseQuantity = t.UseQty
      from cashcoupontype c,  (select typeid, COUNT(1) as UseQty from cashcoupon where flag = 5 group by typeid) t 
      where c.typeid = t.typeid
        
    select ct.*, 		   		  		
		   Case ct.Limitflag when 0 then '整单限额' when 1 then '商品限额' 
					         when 2 then '类别限额' else ' ' end  as LimitflagName,
		   Case ct.multiflag when 0 then '否' when 1 then '是' end as multiflagName	 		         						    					    
    from Cashcoupontype ct                            
    where 
		  (@CashC_id = 0 or ct.typeid = @CashC_id) and
          (@szTypeName ='' or  ct.TypeName like @szTypeName) and
          (@begindate < 10 or ct.begindate>= @begindate) and
          (@ValidDate < 10 or ct.validDate <= @ValidDate)          
end else if @nMode = 1
begin
    
    select ct.*, 		   		  		
		   Case ct.Limitflag when 0 then '整单限额' when 1 then '商品限额' 
					         when 2 then '类别限额' else ' ' end  as LimitflagName,
		   Case ct.multiflag when 0 then '否' when 1 then '是' end as multiflagName	 		         						    					    
    from Cashcoupontype ct                            
    where 
		  (@CashC_id = 0 or ct.typeid = @CashC_id) and
          (@szTypeName ='' or  ct.TypeName like @szTypeName) and          
          ct.validDate >= floor(CAST(GETDATE() as NUMERIC(25,8)))
          
end                                                                                                         
return 0
GO
