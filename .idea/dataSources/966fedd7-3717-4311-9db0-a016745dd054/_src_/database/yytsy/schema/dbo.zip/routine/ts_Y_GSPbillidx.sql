
/******************************************
GSP订单数据查询
作者：yanrui
创建日期 2014-01-06
********************************************/
CREATE PROCEDURE ts_Y_GSPbillidx
(	
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间*/
	@e_id			int,
	@billtype       int=0,            /*GSP单据类型*/
	@billnumber     varchar(30) ='',  /*单据编号*/
	@Y_id           int=0,  /*业务机构*/
	@c_id           int=0,  /* 往来单位  */
	@cp_id          int=0,  /* 往来机构  */
	@s_id           int=0,   /*仓库ID*/
	@billstates     int=0,   /*单据状态*/
	@p_id           int=0,     /*商品ID*/
	@yw_type        int=0,  /*--ywtype 业务类型*/
	@orderbill      varchar(30) = '', /*订单编号*/
	@wt_ID          int=0,  /*供货商代表*/
	@SendC_id       int=0   /*收货方*/
)
as
BEGIN
	if @billtype is null set @billtype = 0
	if @billnumber is null set @billnumber = ''
	if @Y_id is null set @Y_id = 0
	if @billtype = 563 set @Y_id = 0    /*门店退货申请单需要查询所有门店的数据*/
	if @c_id is null set @c_id = 0
	if @cp_id is null set @cp_id = 0
	if @s_id is null set @s_id = 0
	if @billstates is null set @billstates = 0
	if @p_id is null set @p_id = 0
	if @yw_type is null set @yw_type = 0
	if @orderbill is null set @orderbill = ''
	if @orderbill = '' 
	  set @orderbill = '%%'
	else 
	  set @orderbill = '%' + @orderbill + '%'
	SET @billnumber = '%' + @billnumber + '%'
	if @wt_ID is null set @wt_ID = 0
    if @SendC_id is null set @SendC_id = 0
	SELECT   g.Gspbillid AS billId, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
					g.AUDITER1 AS auditmanN1name, 
					/*g.AuditTime1, */
					(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
					g.AuditMan2, g.AUDITER2 AS auditmanN2name, 
					/*g.AuditTime2, */
					(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
					g.TrafficType, g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
					g.TrafficCompany, g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
					g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
					g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
					g.YBILLNUMBER, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,  
					CASE WHEN (g.TicketDate = '1900-01-01' OR g.TicketDate = '00:00:00') THEN '' ELSE CONVERT(VARCHAR(100), g.TicketDate, 23) END AS TicketDate,inbags,
					g.sendcname as SendCName,g.yxj,d.detailcount,
					CAST(datediff(N,g.BillDate,GETDATE())/60 AS VARCHAR) + 'h' + CAST(datediff(N,g.BillDate,GETDATE())%60 AS VARCHAR) + 'm' as  WaitTime
	FROM      dbo.VW_GSPBILLIDX AS g
	            left join 
	            (
	             select COUNT(P_id) as detailcount,Gspbill_id  from gspbillidx a left join gspbilldetail b on a.Gspbillid=b.Gspbill_id
	                   where a.BillType=541
	             group by Gspbill_id
	            ) d on g.Gspbillid=d.Gspbill_id
				LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
	WHERE   (BillType = @billtype) AND (BillDate BETWEEN @BeginDate AND @EndDate) AND (@Y_id = 0 OR g.Y_id = @Y_id)
		AND (@c_id = 0 OR IsCompany = 0 AND C_id = @c_id) AND (@cp_id = 0 OR IsCompany = 1 AND C_id = @cp_id)
		AND (@s_id = 0 OR g.S_id = @s_id) AND (@billstates = 0 OR BillStates = @billstates) AND (@p_id = 0 OR Gspbillid IN (SELECT Gspbill_id FROM GSPbilldetail WHERE P_id = @p_id))
		AND (@yw_type = 0 OR Ybilltype = @yw_type) AND (YBILLNUMBER LIKE @orderbill) AND (BillNumber LIKE @billnumber)
		AND (G.S_id = 0 OR G.S_id IN (select storage_id from AuthorizeStorage(@e_id))) AND (G.Y_id IN (SELECT company_ID FROM AuthorizeCompany(@e_id)))
		AND (@wt_ID = 0 or g.BillType <> 561 or (@wt_ID > 0 and g.BillType = 561 and g.B_CustomName1 = @wt_ID))
		AND (@SendC_id=0 or (g.sendc_id>0 and g.BillType in (541,551,562,512,522,531,514,516,523) and g.sendc_id=@SendC_id)) 
end
GO
