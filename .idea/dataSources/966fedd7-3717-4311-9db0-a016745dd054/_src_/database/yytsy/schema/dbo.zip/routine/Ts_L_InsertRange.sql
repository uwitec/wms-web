

CREATE PROCEDURE  [Ts_L_InsertRange]
(	@szName varchar(30))
AS
if exists(select * from customCategory where name=@szName)
begin
	RAISERROR('已经存在，请重新输入其它名称！',16,1) 
	return 0 
end
Insert Into 
	customCategory (name)
Values
	(@szName)
if @@rowcount=0 
begin
	RAISERROR('数据库写入数据失败!',16,1) 
	return 0 
end else
return @@identity
GO
