
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-18*/
/* Description:	以生日生成年龄*/
/* =============================================*/
CREATE FUNCTION GetAge 
(
	@Birthday		datetime,	/*生日*/
	@EndDate		datetime	/*计算日期*/
)
RETURNS int
AS
BEGIN
	declare @Result int
	set @Result = ceiling(datediff(dd, @Birthday, @EndDate) / 365.25)
	RETURN @Result
END
GO
