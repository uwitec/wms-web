create procedure [dbo].[ts_e_StoreWMSRoleInsBaseInfo]
 @E_id  integer=0,/*职员ID*/
 @WorkNo varchar(100)='',/*工号*/
 @PickType integer=0,/*拣货类型*/
 @WorkFirst   integer=0,/*作业优先*/
 @PickOrder   integer=0,/*拣货顺序*/
 @Coment    varchar(100)='',/*备注*/
 @Roletype  integer=0,/*角色类型1代表收货员，2代表验收员，3代表拣货员，4复核员，5代表库管员*/
 @RoleId    integer=0,/*用于修改记录ID*/
 @InsOrUpdate varchar(100)='',/*是新增或者修改或者查询*/
 @OldE_id    integer=0,/*旧职员ID*/
 @nRet  int OUTPUT/*新增成功后返回自增列ID*/
as
declare @LimGid integer
begin
 if @InsOrUpdate='Ins'
 begin
   insert into  WMSEmpRole(Roleid,EmpId,WorkNo, PickType,WorkFirst,PickOrder,Coment)
                   values(@Roletype,@E_id,@WorkNo,@PickType,@WorkFirst,@PickOrder,@Coment)
   IF @@ERROR = 0 
   begin
       if @Roletype=1 
       begin
        select @LimGid=gid from limgroup where name ='收货员'
        if @LimGid>0 
        begin
           insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
        end
       end
       if @Roletype=2 
       begin
        select @LimGid=gid from limgroup where name ='验收员'
        if @LimGid>0 
        begin
           insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
        end
       end
       if @Roletype=3
       begin
        select @LimGid=gid from limgroup where name ='拣货员'
        if @LimGid>0 
        begin
           insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
        end
       end
       if @Roletype=4
       begin
        select @LimGid=gid from limgroup where name ='复核员'
        if @LimGid>0 
        begin
           insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
        end
       end
       if @Roletype=5
       begin
        select @LimGid=gid from limgroup where name ='库管员'
        if @LimGid>0 
        begin
           insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
        end
       end
       set  @nRet= @@IDENTITY
   end
 end
 if @InsOrUpdate='Update'
 begin
   update WMSEmpRole  set Empid=@E_id,WorkNo=@WorkNo,PickType=@PickType,WorkFirst=@WorkFirst,
   PickOrder=@PickOrder,Coment=@Coment WHERE id=@RoleId
   IF @@ERROR = 0 
   BEGIN
     if @Roletype=1 
     begin
       if @E_id<>@OldE_id
       begin
          select @LimGid=gid from limgroup where name ='收货员'
          delete from limgroupuser where e_id=@OldE_id and  lgid=@LimGid
          insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
       end
     end
     if @Roletype=2
     begin
       if @E_id<>@OldE_id
       begin
          select @LimGid=gid from limgroup where name ='验收员'
          delete from limgroupuser where e_id=@OldE_id and  lgid=@LimGid
          insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
       end
     end
     if @Roletype=3
     begin
       if @E_id<>@OldE_id
       begin
          select @LimGid=gid from limgroup where name ='拣货员'
          delete from limgroupuser where e_id=@OldE_id and  lgid=@LimGid
          insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
       end
     end
     if @Roletype=4
     begin
       if @E_id<>@OldE_id
       begin
          select @LimGid=gid from limgroup where name ='复核员'
          delete from limgroupuser where e_id=@OldE_id and  lgid=@LimGid
          insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
       end
     end
     if @Roletype=4
     begin
       if @E_id<>@OldE_id
       begin
          select @LimGid=gid from limgroup where name ='库管员'
          delete from limgroupuser where e_id=@OldE_id and  lgid=@LimGid
          insert limgroupuser(lgid,e_id) values(@LimGid,@E_id)
       end
     end
       set @nRet=1
   END
 end
 if  @InsOrUpdate='Select'
 begin
   select  a.id as id,c.name as rolename,isnull(b.serial_number,'') as ecode,isnull(b.name,'') as ename,
           case Roleid when  3  then  (Case a.picktype when 0 then '全部' when 1 then  '零货' else  '整货' end)  else '' end as picktype,
           case Roleid when  3  then  (Case a.workfirst when 0 then '补货优先' else '拣货优先' end) else '' end  as workfirst,
           case Roleid when  3  then  a.pickorder else '' end as pickorder,
           isnull(a.coment,'') as coment ,isnull(workno,'') as WorkNo,
           a.Empid as e_id 
           from WMSEmpRole a left join employees b on a.empid=b.emp_id
                                           left join WMSRole   c on a.Roleid=c.id
    where  (empid=@E_id or @E_id=0) and (RoleId=@Roletype or @Roletype=0)  and a.deleted=0
 end
 if @InsOrUpdate = 'Read'
 begin
    select  a.id as id,c.name as rolename,isnull(b.serial_number,'') as ecode,isnull(b.name,'') as ename,
           a.picktype as picktype,
           a.workfirst as workfirst,
           a.pickorder as pickorder,
           isnull(a.coment,'') as coment ,isnull(workno,'') as WorkNo,a.Empid as eid 
           from WMSEmpRole a left join employees b on a.empid=b.emp_id
                                           left join WMSRole   c on a.Roleid=c.id
    where  a.Id=@RoleId  and a.deleted=0
 end 
end
GO
