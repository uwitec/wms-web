

CREATE	PROCEDURE [Ts_L_insStoreLimit]
	(@P_id	[int],
	 @S_id	[int],
	 @UpperLimit	[numeric](19,4),
	 @LowLimit	[numeric](19,4),
	 @adjQty	[numeric](19,4),
     @Y_id          int,
     @ByWayDay      int,
     @PlanDay		int,
     @nsa_id        int
     )


AS 
if @p_id not in (select product_id from products where deleted=0) return -1/*zh100910,被停用的商品不能做上下限处理*/
if Exists(select slid from storeLimit where P_id=@p_id and s_id=@s_id and Y_id=@Y_id)
begin
delete from storelimit where p_id =@p_id and s_id=@s_id and Y_id=@Y_id and sa_id =@nsa_id
/*	UPDATE [StoreLimit] 
	
	SET  [P_id]	 = @P_id,
		 [S_id]  = @S_id,
		 [UpperLimit]	 = @UpperLimit,
		 [LowLimit]	 = @LowLimit ,
		 [AdjQty]	 = @AdjQty
	WHERE 
		( [P_id] = @P_id  and S_id=@s_id )*/
end /*else*/
/*begin*/
	INSERT INTO [StoreLimit] 
		 ( [P_id],
		 [S_id],
		 [UpperLimit],
		 [LowLimit],
		 [AdjQty],
         Y_id, 
         ByWayDay,
         PlanDay,
         sa_id
         ) 
	VALUES 
		( @P_id,
		 @S_id,
		 @UpperLimit,
		 @LowLimit,
		 @AdjQty,
         @Y_id,
         @ByWayDay,
         @PlanDay,
         @nsa_id
         )
/*end*/
GO
