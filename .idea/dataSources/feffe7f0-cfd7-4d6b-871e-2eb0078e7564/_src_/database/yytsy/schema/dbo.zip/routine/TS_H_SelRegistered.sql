
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-9-15*/
/* Description:	读取已挂号病人资料*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_SelRegistered] 
	@DoctorID	int,				/*医生编号*/
	@Name		varchar(60) = '',	/*姓名*/
	@IDCard		varchar(50) = '',	/*身份证号*/
	@Tel		varchar(30) = '',	/*电话号码*/
	@LastExam	int = 0				/*最后诊断时间*/
AS
BEGIN
/*Params Ini begin*/
if @Name is null  SET @Name = ''
if @IDCard is null  SET @IDCard = ''
if @Tel is null  SET @Tel = ''
if @LastExam is null  SET @LastExam = 0
/*Params Ini end*/
	SET NOCOUNT ON;
	
	declare @varCount int
	declare @SQL varchar(8000)
	
	set @varCount = 1
	set @SQL = 'select * from vw_h_registered where Doctor_ID = ' + cast(@DoctorID as varchar(12))

	if @Name <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '[name] like ''%' + @name + '%'''
		set @varCount = @varcount + 1
	end
	if @IDCard <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '[IDCard] like ''%' + @IDCard + '%'''
		set @varCount = @varcount + 1
	end
	if @Tel <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '[Tel] like ''%' + @Tel + '%'''
		set @varCount = @varcount + 1
	end
	if @LastExam > 0
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + 'datediff(dd, [regdate], getdate()) <= ' + cast(@LastExam as varchar(20))
	end
	print @SQL
	exec(@SQL)
END
GO
