
/*销售结算统计表*/
CREATE PROCEDURE ts_L_qrSalejsPdetail 
(@ntype               int=0,/*查询内容  0：业务人员销售；1：往来单位销售；2：药品种类销售；3：药品种类采购结算统计；4：往来单位采购结算统计*/
 @BeginDate 	      varchar(50),/*开始时间*/
 @EndDate	      varchar(50),/*结束时间*/
 @departid            int=0,     /*部门ID*/
 @sclassid            varchar(50)='000000',/*仓库ID*/
 @szEClassID          varchar(50)='000000',/*经手人*/
 @szCClassID          varchar(50)='000000'/*往来单位*/
)
AS
/*Params Ini begin*/
if @ntype is null  SET @ntype = 0
if @departid is null  SET @departid = 0
if @sclassid is null  SET @sclassid = '000000'
if @szEClassID is null  SET @szEClassID = '000000'
if @szCClassID is null  SET @szCClassID = '000000'
/*Params Ini end*/

IF @ntype=0
BEGIN
   SELECT B.enumber,B.ename,' ' as Cnumber,' ' as Cname,' ' as Ptype ,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSQTY else -SM.JSQTY end),0)JSQTY,   
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JStotalmoney else -SM.JStotalmoney end),0)JStotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSCostTotal else -SM.JSCostTotal end),0)JSCostTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.mlTotal else -SM.mlTotal end),0)mlTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.Freetaxtotalmoney else -SM.Freetaxtotalmoney end),0)Freetaxtotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.FreetaxJSCostTotal else -SM.FreetaxJSCostTotal end),0)FreetaxJSCostTotal

   FROM 
     (SELECT billid,billtype,e_id,enumber,ename FROM vw_c_billidx where  jsflag='P' and  
               (eclass_id=@szEClassID or @szEClassID='000000') and (dep_id=@departid or @departid=0) and 
               billtype in (10,11,12,13,32,112,53,54,16,17,210,211) and billstates='0' )B
      INNER JOIN
      (SELECT distinct xsd_bid  FROM jspdetail where skd_bid in (select billid from vw_c_billidx 
        where Billdate between @BeginDate and @EndDate and billstates='0') and  billtype in (10,11,12,13,32,112,53,54,16,17,210,211))JS
       ON js.xsd_bid=B.billid 

      INNER JOIN
     (SELECT SB.bill_id,SB.p_id,isnull(sum(JS.JSQTY),0)JSQTY,
             ISNULL(SUM(SB.costprice*JS.JSQTY),0) as JSCostTotal,
             ISNULL(SUM(JS.JSQTY*SB.saleprice),0) as JStotalmoney,
             ISNULL(SUM(JS.JSQTY*SB.saleprice-SB.costprice*JS.JSQTY),0) as mlTotal,
             ISNULL(SUM( (JS.JSQTY*SB.saleprice)/(1+p.taxrate/100) ),0) as Freetaxtotalmoney,
             ISNULL(SUM( (SB.costprice*JS.JSQTY)/(1+p.taxrate/100) ),0) as FreetaxJSCostTotal            

      FROM (select bill_id,smb_id,P_id,(totalmoney/quantity)saleprice,costprice from VW_z_SaleTranMB 
            where  (ssclass_id=@sclassid or @sclassid='000000') and p_id>0) SB
       
            INNER JOIN products P ON sb.P_id=p.product_id 
      
            INNER JOIN (select detail_id,sum(quantity)JSQTY from jspdetail where billtype 
                        in (10,11,12,13,32,112,53,54,16,17,210,211) Group by detail_id)js
            ON  js.detail_id=SB.smb_id 
       

      Group by bill_id,SB.p_id

      )SM ON B.billid=SM.bill_id
  
  Group by B.enumber,B.ename
END

ELSE IF @ntype=1
BEGIN
   SELECT ' ' as enumber,' ' as ename,B.Cnumber as Cnumber,B.Cname as Cname,' ' as Ptype ,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSQTY else -SM.JSQTY end),0)JSQTY,   
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JStotalmoney else -SM.JStotalmoney end),0)JStotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSCostTotal else -SM.JSCostTotal end),0)JSCostTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.mlTotal else -SM.mlTotal end),0)mlTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.Freetaxtotalmoney else -SM.Freetaxtotalmoney end),0)Freetaxtotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.FreetaxJSCostTotal else -SM.FreetaxJSCostTotal end),0)FreetaxJSCostTotal

   FROM 
     (SELECT billid,billtype,e_id,Cnumber,Cname FROM vw_c_billidx where  jsflag='P' and  
               (cclass_id=@szCClassID or @szCClassID='000000') and (dep_id=@departid or @departid=0) and 
               billtype in (10,11,12,13,32,112,53,54,16,17,210,211) and billstates='0' )B
      INNER JOIN
      (SELECT distinct xsd_bid  FROM jspdetail where skd_bid in (select billid from vw_c_billidx 
        where Billdate between @BeginDate and @EndDate and billstates='0') and  billtype in (10,11,12,13,32,112,53,54,16,17,210,211))JS
       ON js.xsd_bid=B.billid 

      INNER JOIN
     (SELECT SB.bill_id,SB.p_id,isnull(sum(JS.JSQTY),0)JSQTY,
             ISNULL(SUM(SB.costprice*JS.JSQTY),0) as JSCostTotal,
             ISNULL(SUM(JS.JSQTY*SB.saleprice),0) as JStotalmoney,
             ISNULL(SUM(JS.JSQTY*SB.saleprice-SB.costprice*JS.JSQTY),0) as mlTotal,
             ISNULL(SUM( (JS.JSQTY*SB.saleprice)/(1+p.taxrate/100) ),0) as Freetaxtotalmoney,
             ISNULL(SUM( (SB.costprice*JS.JSQTY)/(1+p.taxrate/100) ),0) as FreetaxJSCostTotal            

      FROM (select bill_id,smb_id,P_id,(totalmoney/quantity)saleprice,costprice from VW_z_SaleTranMB 
            where  (ssclass_id=@sclassid or @sclassid='000000') and p_id>0) SB
       
            INNER JOIN products P ON sb.P_id=p.product_id 
      
            INNER JOIN (select detail_id,sum(quantity)JSQTY from jspdetail where billtype 
                        in (10,11,12,13,32,112,53,54,16,17,210,211) Group by detail_id)js
            ON  js.detail_id=SB.smb_id 
       

      Group by bill_id,SB.p_id

      )SM ON B.billid=SM.bill_id
  
  Group by B.Cnumber,B.Cname
END

ELSE IF @ntype=2
BEGIN
   SELECT ' 'as Cnumber,' ' as Cname,' ' as Enumber,' ' as Ename,SM.rname as Ptype ,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSQTY else -SM.JSQTY end),0)JSQTY,   
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JStotalmoney else -SM.JStotalmoney end),0)JStotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.JSCostTotal else -SM.JSCostTotal end),0)JSCostTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.mlTotal else -SM.mlTotal end),0)mlTotal,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.Freetaxtotalmoney else -SM.Freetaxtotalmoney end),0)Freetaxtotalmoney,
    ISNULL(SUM(case when B.billtype in (10,12,32,112,53,16,210) then SM.FreetaxJSCostTotal else -SM.FreetaxJSCostTotal end),0)FreetaxJSCostTotal

   FROM 
     (SELECT billid,billtype,e_id,Cnumber,Cname FROM vw_c_billidx where  jsflag='P' and  
               (dep_id=@departid or @departid=0) and 
               billtype in (10,11,12,13,32,112,53,54,16,17,210,211) and billstates='0' )B
      INNER JOIN
      (SELECT distinct xsd_bid  FROM jspdetail where skd_bid in (select billid from vw_c_billidx 
        where Billdate between @BeginDate and @EndDate and billstates='0') and  billtype in (10,11,12,13,32,112,53,54,16,17,210,211))JS
       ON js.xsd_bid=B.billid 
     
      INNER JOIN
     (SELECT SB.bill_id,SB.p_id,p.rname,isnull(sum(JS.JSQTY),0)JSQTY,
             ISNULL(SUM(SB.costprice*JS.JSQTY),0) as JSCostTotal,
             ISNULL(SUM(JS.JSQTY*SB.saleprice),0) as JStotalmoney,
             ISNULL(SUM(JS.JSQTY*SB.saleprice-SB.costprice*JS.JSQTY),0) as mlTotal,
             ISNULL(SUM( (JS.JSQTY*SB.saleprice)/(1+p.taxrate/100) ),0) as Freetaxtotalmoney,
             ISNULL(SUM( (SB.costprice*JS.JSQTY)/(1+p.taxrate/100) ),0) as FreetaxJSCostTotal            

      FROM (select bill_id,smb_id,P_id,ssclass_id,(totalmoney/quantity)saleprice,costprice from VW_z_SaleTranMB 
            where  (ssclass_id=@sclassid or @sclassid='000000') and p_id>0) SB
       
            INNER JOIN VW_C_Products P ON sb.P_id=p.product_id 
      
            INNER JOIN (select detail_id,sum(quantity)JSQTY from jspdetail where billtype 
                        in (10,11,12,13,32,112,53,54,16,17,210,211) Group by detail_id)js
            ON  js.detail_id=SB.smb_id 
      
        where  p.rname<>''
      Group by bill_id,SB.p_id,p.rname

      )SM ON B.billid=SM.bill_id
  Group by SM.rname
END
ELSE IF @ntype=3
BEGIN
   SELECT ' 'as Cnumber,' ' as Cname,' ' as Enumber,' ' as Ename,SM.rname as Ptype ,
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.JSQTY else -SM.JSQTY end),0)JSQTY,   
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.JStotalmoney else -SM.JStotalmoney end),0)JStotalmoney,
    cast(0 as numeric(18,6)) AS JSCostTotal,
    cast(0 as numeric(18,6)) as mlTotal,
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.Freetaxtotalmoney else -SM.Freetaxtotalmoney end),0)Freetaxtotalmoney,
    cast(0 as NUMERIC(25,8)) AS FreetaxJSCostTotal

   FROM 
     (SELECT billid,billtype,e_id,Cnumber,Cname FROM vw_c_billidx where  jsflag='P' and  
               (dep_id=@departid or @departid=0) and 
               billtype in (20,21,35,122,24,25,220) and billstates='0' )B
      INNER JOIN
      (SELECT distinct xsd_bid  FROM jspdetail where skd_bid in (select billid from vw_c_billidx 
        where Billdate between @BeginDate and @EndDate and billstates='0') and  billtype in (20,21,35,122,24,25,220))JS
       ON js.xsd_bid=B.billid 
     
      INNER JOIN
     (SELECT SB.bill_id,SB.p_id,p.rname,isnull(sum(JS.JSQTY),0)JSQTY,

             ISNULL(SUM(JS.JSQTY*SB.saleprice),0) as JStotalmoney,

             ISNULL(SUM( (JS.JSQTY*SB.saleprice)/(1+p.taxrate/100) ),0) as Freetaxtotalmoney
       FROM (select bill_id,smb_id,P_id,ssclass_id,(totalmoney/quantity)saleprice,costprice from vw_c_buymb 
            where  (ssclass_id=@sclassid or @sclassid='000000') and p_id>0) SB
       
            INNER JOIN VW_C_Products P ON sb.P_id=p.product_id 
      
            INNER JOIN (select detail_id,sum(quantity)JSQTY from jspdetail where billtype 
                        in (20,21,35,122,24,25,220) Group by detail_id)js
            ON  js.detail_id=SB.smb_id 
      
        where  p.rname<>''
      Group by bill_id,SB.p_id,p.rname

      )SM ON B.billid=SM.bill_id
  Group by SM.rname
END
ELSE IF @ntype=4
BEGIN
   SELECT ' ' as enumber,' ' as ename,B.Cnumber as Cnumber,B.Cname as Cname,' ' as Ptype ,
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.JSQTY else -SM.JSQTY end),0)JSQTY,   
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.JStotalmoney else -SM.JStotalmoney end),0)JStotalmoney,
    cast(0 as numeric(18,6)) AS JSCostTotal,
    cast(0 as numeric(18,6))AS mlTotal,
    ISNULL(SUM(case when B.billtype in (20,35,122,24) then SM.Freetaxtotalmoney else -SM.Freetaxtotalmoney end),0)Freetaxtotalmoney,
    cast(0 as NUMERIC(25,8)) AS FreetaxJSCostTotal

   FROM 
     (SELECT billid,billtype,e_id,Cnumber,Cname FROM vw_c_billidx where  jsflag='P' and  
               (cclass_id=@szCClassID or @szCClassID='000000') and (dep_id=@departid or @departid=0) and 
               billtype in (20,21,35,122,24,25,220) and billstates='0' )B
      INNER JOIN
      (SELECT distinct xsd_bid  FROM jspdetail where skd_bid in (select billid from vw_c_billidx 
        where Billdate between @BeginDate and @EndDate and billstates='0') and  billtype in (20,21,35,122,24,25,220))JS
       ON js.xsd_bid=B.billid 

      INNER JOIN
     (SELECT SB.bill_id,SB.p_id,isnull(sum(JS.JSQTY),0)JSQTY,

             ISNULL(SUM(JS.JSQTY*SB.saleprice),0) as JStotalmoney,

             ISNULL(SUM( (JS.JSQTY*SB.saleprice)/(1+p.taxrate/100) ),0) as Freetaxtotalmoney            

      FROM (select bill_id,smb_id,P_id,(totalmoney/quantity)saleprice,costprice from vw_c_buymb 
            where  (ssclass_id=@sclassid or @sclassid='000000') and p_id>0) SB
       
            INNER JOIN products P ON sb.P_id=p.product_id 
      
            INNER JOIN (select detail_id,sum(quantity)JSQTY from jspdetail where billtype 
                        in (20,21,35,122,24,25,220) Group by detail_id)js
            ON  js.detail_id=SB.smb_id 
       

      Group by bill_id,SB.p_id

      )SM ON B.billid=SM.bill_id
  
  Group by B.Cnumber,B.Cname
END
GO
