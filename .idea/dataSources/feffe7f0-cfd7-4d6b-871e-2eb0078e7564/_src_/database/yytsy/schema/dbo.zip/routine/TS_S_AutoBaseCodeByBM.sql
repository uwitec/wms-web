

CREATE PROCEDURE TS_S_AutoBaseCodeByBM
( @TbName varchar(200),
  @FirstSn varchar(10),
  @_Class_ID varchar(120),
  @_Flag int = 0)
  
AS 

if @FirstSn is null set @FirstSn=''

SET NOCOUNT ON 
   DECLARE @Comment varchar(8000),
           @flag varchar(10),
           @nLen int,
           @nStr int,
           @StrComment varchar(8000),
	       @nMaxLen int,
           @nSN varchar(120),
           @n  int   ,
           @mlen int,
           @mStr int,
           @parent_id varchar(120),
           @szsql varchar(8000),
           @szsql1 varchar(8000),
           @plen int,
           
           @baseStr  varchar(10),
           @nMaxKeyid int,
           @sLen varchar(10),
           @sKeyID varchar(8000),
           @X  varchar(8)
           
           
   if exists (select * from tempdb..sysobjects where name = '##TmpAutoRule')
		drop table ##TmpAutoRule
   if exists (select * from tempdb..sysobjects where name = '##TmpTable')
		drop table ##TmpTable        
           
           
           
BEGIN TRAN T1

    CREATE TABLE ##TmpAutoRule    
    (nLevel  int,
     nLen int,
     nStr int
     )  
     
    CREATE TABLE ##TmpTable    
    (KeyID int  IDENTITY (1, 1) NOT NULL,
     p_id int
     )         

  set  @n = 1 
  set  @flag=''
  set @szsql=''
  
  IF Upper(@TbName) = 'PRODUCTS'   
  begin
     SET @flag = 'P'  
     set @sKeyID = 'product_id'
  end
  
  ELSE IF Upper(@TbName) = 'CLIENTS' 
  begin  
	 SET @flag = 'C' 
	 set @sKeyID = 'Client_id'  
  end
  
  ELSE IF Upper(@TbName) = 'EMPLOYEES'  
  begin
	 SET @flag = 'E' 
	 set @sKeyID = 'Emp_id'   
  end
  
  ELSE IF Upper(@TbName) = 'STORAGES'  
  begin
	 SET @flag = 'S' 
	 set @sKeyID = 'storage_id'   
  end
  
  ELSE IF Upper(@TbName) = 'DEPARTMENT'  
  begin
	 SET @flag = 'D' 
	 set @sKeyID = 'departmentId'   
  end
  
 
  
  ELSE IF Upper(@TbName) = 'CW_PROJECT'  
  begin
	 SET @flag = 'M' 
	 set @sKeyID = 'Project_ID'   
  end  
  
  

  IF @flag<> ''
  BEGIN
    SELECT @Comment     = comment FROM sysconfig WHERE [sysName] = 'Zdbm'+@TbName+'2'
    SELECT @StrComment  = comment FROM sysconfig WHERE [sysName] = 'Zdbm'+@TbName+'3'
    SET @Comment	= REPLACE(@Comment,CHAR(13),',')     
    SET @StrComment = REPLACE(@StrComment,CHAR(13),',') 
        
    WHILE @n<=5
    BEGIN
         set @nLen	 = Left(@Comment,patindex('%,%',@Comment)-1) 
         set @nStr   = Left(@StrComment,patindex('%,%',@StrComment)-1) 
         insert into ##TmpAutoRule(nLevel,nLen,nStr) values(@n,@nLen,@nStr)
         set @Comment = substring(@Comment,patindex('%,%',@Comment)+2,len(@Comment)) 
         set @StrComment = substring(@StrComment,patindex('%,%',@StrComment)+2,len(@StrComment))        
         SET @n = @n +1
    END
  END ELSE
    GOTO LabExit
    
    
    if exists(select 1 from ##TmpAutoRule having sum(nLen) > 26)
    GOTO error1 
    
    
    
if @FirstSn = '0'
select @baseStr = '00000000'/*定义最大长度*/
else if @FirstSn = '1'
select @baseStr = '10000000'/*定义最大长度*/
set @X = 'XXXXXXXX'

select @nMaxLen=max(nLen) from ##TmpAutoRule
if @nMaxLen>0
begin
	set @n=1
        set @nSN='0'
	while @n<@nMaxLen
	begin
          set @nSN=@nSN+'0'
 	  set @n=@n+1
	end
end else 
  goto LabExit
    if @_Flag = 0 
    begin 
          if @TbName='products'/*取出所有Parent_ID并按长度排序确定父类*/
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM products WHERE Class_ID<>'000000' and deleted <> 1 and IsSplit = 0) A order by Len(A.Parent_ID),Parent_ID
	  end
          if @TbName='clients'
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM clients WHERE Class_ID<>'000000' and deleted <> 1) A order by Len(A.Parent_ID),Parent_ID
	  end
          if @TbName='employees'
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM employees WHERE Class_ID<>'000000' and deleted <> 1) A order by Len(A.Parent_ID),Parent_ID
	  end
	  
	      if @TbName='STORAGES'
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM STORAGES WHERE Class_ID<>'000000' and deleted <> 1) A order by Len(A.Parent_ID),Parent_ID
	  end
	  
	    /*  if @TbName='DEPARTMENT'
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM DEPARTMENT WHERE Class_ID<>'000000' and deleted <> 1) A order by Len(A.Parent_ID),Parent_ID
	  end */
	     
	      if @TbName='CW_Project'
          begin
	  DECLARE GetParentID CURSOR FOR
          SELECT   A.Parent_ID FROM
                            (SELECT DISTINCT parent_ID FROM CW_Project WHERE Class_ID<>'000000' and deleted <> 1) A order by Len(A.Parent_ID),Parent_ID
	  end
	 
      end else 
        DECLARE GetParentID CURSOR FOR
	     select  @_Class_ID   
	  OPEN GetParentID
	
	
	  FETCH NEXT FROM GetParentID INTO @Parent_ID
	  WHILE @@FETCH_STATUS = 0
	  BEGIN  
		if @parent_id='000000'  set @plen=1 else set @plen=len(@parent_id)/6+1
                    
               select @mlen=nlen,@mStr = nStr from ##TmpAutoRule where nlevel=@plen  
               

		if @mlen>0
		begin
		/*先把该父类下的所有商品插入到临时表  and Class_ID = '+@_Class_ID+'*/
		select @szsql = 'insert into ##TmpTable (p_id) select '+@sKeyID+' from '+@TbName+' where parent_id = '''+@parent_id+''' and deleted <> 1  '
		     /*  print @szsql*/
		if @TbName = 'products' 
			      set @szsql = @szsql + ' and IsSplit = 0 '   
	    set @szsql = @szsql +  'order by RowIndex'  	   
	    exec (@szsql)
	    select @nMaxKeyid = len(MAX(keyid)) from ##TmpTable
	    
	    
	    
		   if @plen= 1 /*第一级*/
		   begin
			   /*第一步先更新父类编码 */
			   /*找出父类   */
			   /*如果超过长度，不符合规则不予编码   		  */
			   if @mlen < @nMaxKeyid and @FirstSn = 0 and @mStr = 0/*截取操作不用提示长度不够，如有截取后重复经讨论不予解决*/
			   begin
			     select @sLen = @plen
			     GOTO error
			   end
			   
			   		  
			   if @mlen < @nMaxKeyid + 1 and @FirstSn = '1' and @mStr = 0/*截取操作不用提示长度不够，如有截取后重复经讨论不予解决*/
			   begin
			     select @sLen = @plen
			     GOTO error
			   end
			    /*修改父类	*/
			    
			   if @mStr = 1/*保留字符，进行截取重算，不足以字母“X”替代，单纯截取字符操作*/
			   
			    select @szsql = 'update '+@TbName+' set serial_number = 
			    
			    case when LEN(serial_number) >= '+CAST(@mlen as VARCHAR(8000)) +' then LEFT(serial_number,'+CAST(@mlen as VARCHAR(8000)) +') else LEFT(serial_number,'+CAST(@mlen as VARCHAR(8000)) +') + LEFT('''+@X+''','+CAST(@mlen as VARCHAR(8000)) +'-len(serial_number)) end from '+@TbName+' p,##TmpTable temp where p.'+@sKeyID+' = temp.p_id' 
			      
			   /*set @S = case when LEN(@s) >= 3 then LEFT(@S,3) else LEFT(@S,3) + LEFT(@x,3-len(@s)) end*/
			   
			    
			   else/*按原来的方式进行数字重算 	   */
			   select @szsql = 'update '+@TbName+' set serial_number = left('''+@baseStr+''','+CAST(@mlen as VARCHAR(8000)) +' - LEN(temp.keyid)) + cast(temp.keyid as varchar(8000)) from '+@TbName+' p,##TmpTable temp where p.'+@sKeyID+' = temp.p_id'
		       
		         
		       print @szsql	   
			   exec (@szsql)			   			 			 
		      truncate table ##TmpTable/*清空临时表*/
	       end	
	       
	   
	       else /*第一级之外的其他级次*/
	       begin
	           /*如果超过长度，不符合规则不予编码 */
			   if @mlen < @nMaxKeyid and @mStr = 0/*截取操作不用提示长度不够，如有截取后重复经讨论不予解决*/
			   begin
			     select @sLen = @plen
			     GOTO error
			   end    
	         	           	           
	           select @szsql = 'declare @ParentNo varchar(8000)
	           select @ParentNo = serial_number from '+@TbName+' where class_id = '''+@Parent_ID+''' and deleted <> 1'
	           
	           if @mStr = 1/*保留字符，进行截取重算，其他级次取的时候，这里注意：*/
	           /*1、以父类的长度为基础进行左截取当前级次位数*/
	           /*2、不足以字母“X”替代   */
	           select @szsql = @szsql + ' update '+@TbName+' set serial_number = 			    
			    case when LEN(serial_number) - LEN(@ParentNo) > 0 then @ParentNo + SUBSTRING(serial_number,LEN(@ParentNo) + 1,'+CAST(@mlen as VARCHAR(8000)) +')+ LEFT('''+@X+''',case when '+CAST(@mlen as VARCHAR(8000)) +' - (LEN(serial_number) - LEN(@ParentNo)) > 0 then '+CAST(@mlen as VARCHAR(8000)) +' - (LEN(serial_number) - LEN(@ParentNo)) else 0 end)  			    			  	        	  	    
			     else @ParentNo + LEFT('''+@X+''','+CAST(@mlen as VARCHAR(8000)) +') end from '+@TbName+' p,##TmpTable temp where p.'+@sKeyID+' = temp.p_id'			    
			   	    
	           
		       else
		       select @szsql = @szsql + ' update '+@TbName+' set serial_number =  @ParentNo + left('''+@baseStr+''','+CAST(@mlen as VARCHAR(8000)) +' - LEN(temp.keyid)) + cast(temp.keyid as varchar(8000)) from '+@TbName+' p,##TmpTable temp where p.'+@sKeyID+' = temp.p_id' 		  		  
			   
			   exec (@szsql)	
	           truncate table ##TmpTable/*清空临时表   */
	       end
        end       

		FETCH NEXT FROM GetParentID INTO @Parent_ID                         
      END
          close GetParentID
	  DEALLOCATE GetParentID     
	   COMMIT TRAN T1
	   RETURN 0
LabExit:   
   ROLLBACK TRAN T1  
   RETURN -1
error:  
      close GetParentID
	  DEALLOCATE GetParentID     
   ROLLBACK TRAN T1  
   RAISERROR('第【%s】级商品的数量超出了编码规则设置的第【%s】级长度，不能重新生成编码！',16,1,@sLen,@sLen) 
   RETURN -2
  
error1:
ROLLBACK TRAN T1  
RAISERROR('所有级次长度之和不能超过最大26位！',16,1) 
   RETURN -3

SET NOCOUNT OFF
GO
