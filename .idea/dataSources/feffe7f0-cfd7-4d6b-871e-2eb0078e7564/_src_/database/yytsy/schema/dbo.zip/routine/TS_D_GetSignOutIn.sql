

CREATE procedure TS_D_GetSignOutIn
@OperatorNo INT,
@BATCHNO VARCHAR(30)  
AS

  SELECT SUM(CASE WHEN Billtype=12 THEN 1 ELSE 0 END) POSNUM
         ,SUM(CASE WHEN Billtype=13 THEN 1 ELSE 0 END) NEGNUM
         ,SUM(CASE WHEN Billtype=12 THEN BillTotal ELSE 0 END) AKC264
         ,SUM(CASE WHEN Billtype=12 THEN CashMoney ELSE 0 END) AKC261
         ,SUM(CASE WHEN Billtype=12 THEN YBMoney ELSE 0 END) AKC255
         ,SUM(CASE WHEN Billtype=12 THEN TCMoney ELSE 0 END) AKC260
  FROM DRBillidx
  WHERE OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO	 
        AND ((Billtype=12 AND SettleFlag=600) OR (Billtype=13 AND SettleFlag=601))
GO
