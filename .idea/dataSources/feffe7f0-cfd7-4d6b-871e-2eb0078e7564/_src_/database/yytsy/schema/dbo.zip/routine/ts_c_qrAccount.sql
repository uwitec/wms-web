




































CREATE	proc ts_c_qrAccount

(	
	@szParid		varchar(20),
	@cFlag		char(2),
	@szPeriod	char(2),
        @szLoginID      int
)
as
set nocount on

declare @YID INT

select @YID=@szLoginID 

	/*exec ts_L_TempBillToYPDetail*/
	
	select a.account_id,a.[name],a.parent_id,a.child_number,a.class_id,a.serial_number,
		(select isnull( sum(case @szPeriod 
			when '' 	then b.cur_total
			when '01' then b.total_01
			when '02' then b.total_02
			when '03' then b.total_03
			when '04' then b.total_04
			when '05' then b.total_05
			when '06' then b.total_06
			when '07' then b.total_07
			when '08' then b.total_08
			when '09' then b.total_09
			when '10' then b.total_10
			when '11' then b.total_11
			when '12' then b.total_12
			else b.ini_total end)
									,0)  
		       from 
			(select a.class_id,a.deleted,cast(ab.total_01 as NUMERIC(25,8)) as total_01,total_02=cast(ab.total_02 as NUMERIC(25,8)) ,
			total_03=cast(ab.total_03 as NUMERIC(25,8)) , total_04=cast(ab.total_04 as NUMERIC(25,8)),
	                total_05=cast(ab.total_05 as NUMERIC(25,8)) , total_06=cast(ab.total_06 as NUMERIC(25,8)),
			total_07=cast(ab.total_07 as NUMERIC(25,8)) , total_08=cast(ab.total_08 as NUMERIC(25,8)),
			total_09=cast(ab.total_09 as NUMERIC(25,8)) , total_10=cast(ab.total_10 as NUMERIC(25,8)),
			total_11=cast(ab.total_11 as NUMERIC(25,8)) , total_12=cast(ab.total_12 as NUMERIC(25,8)),
			cur_total= cast(ab.cur_total as NUMERIC(25,8)),ini_total=cast(ab.ini_total as NUMERIC(25,8)) 
			from accountBalance ab ,account a 
			where a.account_id=ab.a_id and ab.Y_id=@YID) b
		where left(b.class_id,len(a.class_id))=a.class_id and b.deleted=0) as 'total' 
	from account a 
	where a.parent_id=@szParid and sysflag=@cFlag and a.deleted=0
GO
