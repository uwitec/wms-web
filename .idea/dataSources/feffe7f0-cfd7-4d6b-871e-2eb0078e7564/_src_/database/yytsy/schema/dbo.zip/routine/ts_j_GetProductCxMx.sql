/************************************************************

--功能：获取商品促销明细   
--创建人：Zhou JiLin 
--创建时间：2009-08-08  
--最后修改:

参数说明：
@nMode
'1', '2', '3', '4'  --同时存在的促销方案只存在4种
'价格促销、折扣促销', '赠品促销', '超量促销', '整单折扣、整单折让'

**************************************************************/

CREATE	 PROCEDURE ts_j_GetProductCxMx
	( 
	 @nMode int, 
	 @nC_ID int,
	 @nVipType int,
	 @nCxType int,  /*1, 零售 2, 批发*/
	 @nY_ID int,
	 @nP_ID int,
	 @dBillJE NUMERIC(25,8)  /*整单时，传入单据金额*/
     )
AS
declare @nRet int	
declare @dtToday datetime, @nWeek int, @billid int, @d1 NUMERIC(25,8) 
set @dtToday = cast(CAST(GETDATE() as varchar(10)) as datetime)
SET DATEFIRST 1
set @nWeek = DATEPART(dw, @dtToday)
set @d1 = cast(GETDATE() as NUMERIC(25,8)) - cast(cast(GETDATE() as NUMERIC(25,8)) as int)

declare @retailprice NUMERIC(25,8),@GPprice NUMERIC(25,8),@GLprice NUMERIC(25,8)
declare @PosPrice int
exec ts_GetSysValue 'PosPrice',@PosPrice out,2

if @PosPrice=0 
  select @retailprice=isnull(retailprice,0),@GPprice=ISNULL(gpprice,0),@Glprice=ISNULL(glprice,0)
    from price pc,products p where p_id=@nP_ID and pc.p_id=p.product_id and pc.u_id=p.unit1_id
else
  select @retailprice=isnull(retailprice,0),@GPprice=ISNULL(gpprice,0),@Glprice=ISNULL(glprice,0)
    from PosPrice pc,products p where p_id=@nP_ID and pc.Y_id=@nY_ID and pc.p_id=p.product_id and pc.u_id=p.unit1_id

set @nRet = -1

if OBJECT_ID('tempdb..#cxIdxTmp') is not null
  drop table #cxIdxTmp
select top 0  (billid+0) as billid, priceorder, spnointeger,cxtype, ArAptotal into #cxIdxTmp from cxIdx 

/* 180 cxPrice*/
/* 181 cxZP*/
/* 182 CxOver*/
/* 183 vtCxBill*/

if @nMode = 1 goto cxPrice
else if  @nMode = 2 goto cxZP
else if  @nMode = 3 goto CxOver
else if  @nMode = 4 goto vtCxBill
else goto Pend

cxPrice:
  insert into #cxIdxTmp(billid, priceorder, spnointeger, ArAptotal, cxtype)
  select billid, priceorder, spnointeger, ArAptotal, 0
  from cxIdx 
  where billtype = 180 and c_id in (@nC_ID,0) and  cardtype in (@nVipType, 0) and billstates = 3 and posid in (@nY_ID, 0) and
		cxtype in (0, @nCxType) and @dtToday >= begindate and @dtToday <= enddate and SUBSTRING(xq, @nWeek, 1)='1' and
		@d1 >= (cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8))  as int)) and @D1 <= (cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8))  - CAST(cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8))  as int))
		        
  select top 1 mx.P_ID, (case when mx.CxPrice<>0 then
                            (mx.CxPrice/(case when mx.UnitID=p.unit1_id then 1  
                                              when mx.UnitID=p.unit2_id then p.rate2 
 					  when mx.UnitID=p.unit3_id then p.rate3 
					  when mx.UnitID=p.unit4_id then p.rate4 else 1 end)) else @retailprice end)Cxprice,
   mx.discount, mx.LowQty, mx.HighQty, mx.IfIntegral, mx.Integral, idx.priceorder, idx.spnointeger
   ,@retailprice as retailprice, @GPprice as Gpprice, @Glprice as Glprice
    from CxBill mx
    inner join #cxIdxTmp idx on mx.Bill_ID = idx.billid
    left join products p   on mx.p_id=p.product_id
    where mx.P_ID = @nP_ID
    order by mx.smb_ID desc 
 set @nRet = @@rowcount
 
 goto PEnd
 
cxZP:
  insert into #cxIdxTmp(billid, priceorder, spnointeger, araptotal, cxtype)
  select top 1 billid, priceorder, spnointeger, ArAptotal, 0
  from cxIdx
  where billtype = 181 and c_id in (@nC_ID, 0) and  cardtype in (@nVipType,0) and billstates = 3 and region_id = @nP_ID and posid in (@nY_ID, 0) and
		cxtype in (0, @nCxType) and @dtToday >= begindate and @dtToday <= enddate and SUBSTRING(xq, @nWeek, 1)='1'  and
		@d1 >= (cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) as int)) and @D1 <= (cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) as int))
  order by billid desc		
  
  if exists(select * from #cxIdxTmp)
  begin
    select mx.P_ID, mx.HighQty, mx.AOID, idx.araptotal,mx.CxPrice,
           p.*, s.*, (CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE ' ' END) FBTag,ISNULL(FB.fbType ,-1)fbType,
           s.quantity+ISNULL(o.quantity,0) as salequantity, s.storehouse_id AS batchid,
    ISNULL(c.[name],'''') as suppliername,ISNULL(l.loc_name,'''') as locname,
    st.Name as sName
    from (select * from CxBill where Bill_ID in (select billid from #cxIdxTmp)) mx
    inner join #cxIdxTmp idx on mx.Bill_ID = idx.billid
    left join vw_Products p on mx.P_ID = p.product_id
    inner join (select * from storehouse where Y_ID = @nY_ID) s on mx.P_ID = s.p_id
    LEFT JOIN ForbiddenBatch FB ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
    left join dbo.OutBatchNotS() o
	ON o.p_id=s.p_id
	LEFT JOIN clients c ON s.supplier_id=c.client_id 
	LEFT JOIN locatiON l ON s.location_id=l.loc_id 
	LEFT JOIN Storages st ON s.s_id=st.storage_id
    
    set  @nRet = @@ROWCOUNT  
  end
  else set @nRet = 0    
  goto Pend

CxOver:
  insert into #cxIdxTmp(billid, priceorder, spnointeger, araptotal, cxType)
  select billid, priceorder, spnointeger, ArAptotal, 0
  from cxIdx 
  where billtype = 182 and c_id in (@nC_ID, 0) and cardtype in (@nVipType, 0) and billstates = 3 and @dBillJE >= ArAptotal and posid in (@nY_ID, 0) and
		cxtype in (0, @nCxType) and @dtToday >= begindate and @dtToday <= enddate and SUBSTRING(xq, @nWeek, 1)='1' and
		@d1 >= (cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) as int)) and @D1 <= (cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) as int))
  if exists(select * from #cxIdxTmp)
  begin   
    select mx.P_ID,  mx.cxprice, mx.HighQty, idx.araptotal, 0 as aoid, p.*, s.*, (CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE ' ' END) FBTag,ISNULL(FB.fbType ,-1)fbType,
    s.quantity+ISNULL(o.quantity,0) as salequantity, s.storehouse_id AS batchid,
    ISNULL(c.[name],'''') as suppliername,ISNULL(l.loc_name,'''') as locname,
    st.Name as sName
    from (select * from CxBill where Bill_ID in (select billid from #cxIdxTmp)) mx
    inner join #cxIdxTmp idx on mx.Bill_ID = idx.billid
    left join vw_Products p on mx.P_ID = p.product_id
    inner join (select * from storehouse where Y_ID = @nY_ID) s on mx.P_ID = s.p_id
    LEFT JOIN ForbiddenBatch FB ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
    left join dbo.OutBatchNotS() o
	ON o.p_id=s.p_id
	LEFT JOIN clients c ON s.supplier_id=c.client_id 
	LEFT JOIN locatiON l ON s.location_id=l.loc_id 
	LEFT JOIN Storages st ON s.s_id=st.storage_id
    set  @nRet = @@ROWCOUNT  
  end
  else set @nRet = 0    
  goto Pend
			 
vtCxBill:
  select top 1 @billid = isnull(billid, 0)
  from cxIdx 
  where billtype = 183 and c_id in (@nC_ID, 0) and cardtype in (@nVipType, 0) and billstates = 3 and posid in (@nY_ID, 0) and
		cxtype in (0, @nCxType) and @dtToday >= begindate and @dtToday <= enddate and SUBSTRING(xq, @nWeek, 1)='1' and
		@d1 >= (cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), begintime, 114) as datetime) as NUMERIC(25,8)) as int)) and @D1 <= (cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) - CAST(cast(cast(convert(varchar(20), endtime, 114) as datetime) as NUMERIC(25,8)) as int))
  order by billid desc	
  if @billid > 0
  begin
    select lowQty, Discount,HighQty 
      from cxbill 
      where bill_id = @billid
      order by highQty desc  
    set @nRet = @@rowcount
  end else
  set @nRet = 0
  goto Pend  		
		
Pend:
  if OBJECT_ID('tempdb..#cxIdxTmp') is not null
    drop table #cxIdxTmp
  Return @nRet
GO
