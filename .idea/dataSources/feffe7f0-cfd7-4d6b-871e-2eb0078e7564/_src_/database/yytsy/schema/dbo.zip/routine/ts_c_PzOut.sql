



CREATE  proc ts_c_PzOut
(
	@nBillid int
)
/*with encryption*/
as
set nocount on

	declare @szAClass_id varchar(30),@szCClass_id varchar(30),@szUfoAccount_id varchar(30),@szUfoClient_id varchar(30)
	declare @nA_id int,@nC_id int,@tBilldate datetime,@szBillCode varchar(30),@sznote varchar(256)
	declare @dJfmoney NUMERIC(25,8),@dDfmoney NUMERIC(25,8),@szPzlb varchar(30),@dTotal NUMERIC(25,8)

	select @tBilldate=billdate,@szBillCode=billnumber,@sznote=note from billidx where billid=@nBillid

	declare pzinfo cursor for
	select a_id,c_id,aclass_id,cclass_id,jdmoney from vw_c_adetail 
	where billid=@nBillId
	 
	open pzinfo
	fetch next from pzinfo into @nA_id,@nC_id,@szAClass_id,@szCClass_id,@dTotal
	while @@fetch_status=0
	begin
		set @dJfmoney=0
		set @dDfmoney=0
		set @szPzlb='转'
		if exists(select * from  vw_c_adetail where billid=@nBillId and aclass_id='000001000003') 
			select @szPzlb='现'
		if exists(select * from  vw_c_adetail where billid=@nBillId and left(aclass_id,12)='000001000004') 
			select @szPzlb='银'

		select @szUfoAccount_id=serialnumber from kmdz where a_id=@nA_id and type='U'

		if @szUfoAccount_id='' or @szUfoAccount_id is null  return -1

		select @szUfoClient_id=''
                if @nC_id<>0 
               		select @szUfoClient_id=isnull(serialnumber,'') from dwdz where c_id=@nC_id and type='U'

		if left(@szAClass_Id,6)='000001' or left(@szAClass_id,6)='000004'
		begin
			if @dTotal>=0 set @dJfmoney=@dTotal else set @dDfmoney=-@dTotal
		end else if left(@szAClass_id,6)='000002' or left(@szAClass_id,6)='000003'
		begin
			if @dTotal>=0 set @dDfmoney=@dTotal else set @dJfmoney=-@dTotal
		end

		insert pzout(billdate,pzlb,pznumber,pzfj,pzcomment,kmcode,jfmoney,dfmoney,gysnumber,ccode) 
		values(@tBillDate,@szPzlb,@szBillCode,0,@sznote,@szUfoAccount_id,@dJfmoney,@dDfmoney,'',@szUfoClient_id)
		if @@rowcount=0 return -1
		fetch next from pzinfo into @nA_id,@nC_id,@szAClass_id,@szCClass_id,@dTotal
	end
	close pzinfo
	deallocate pzinfo
return 0
GO
