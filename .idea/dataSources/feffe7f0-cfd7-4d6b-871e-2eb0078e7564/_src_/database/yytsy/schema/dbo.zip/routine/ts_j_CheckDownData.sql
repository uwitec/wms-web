/************************************************************

--功能：   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_CheckDownData]
	
AS
 
 declare @nRet int
 set @nRet = -1
  if exists(select * from sysconfig where upper([sysname]) = 'REMOTEGUID' and len(sysvalue) = 36)
    if exists(select * from sysconfig where upper([sysname]) = 'YClassID' and sysvalue <> '' and sysvalue <> '000001')
      set @nRet = 0
 if @nRet = -1
 begin
   raiserror('未下载基本资料，不能继续升级！',16,1)
   Return @nRet
 end
 Return @nRet
GO
