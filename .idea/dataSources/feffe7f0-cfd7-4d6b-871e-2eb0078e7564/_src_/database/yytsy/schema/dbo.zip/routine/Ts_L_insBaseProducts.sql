

CREATE      PROCEDURE Ts_L_insBaseProducts
 (@class_id [varchar](30),
  @serial_number  [varchar](26),
  @name [varchar](80),
  @alias  [varchar](80),
  @standard [varchar](100),
  @modal  [varchar](20),
  @permitcode [varchar](50),
  @trademark [varchar](50),
  @makearea [varchar](60),
  @unit1_id [int],
  @unit2_id [int],
  @unit3_id [int],
  @unit4_id [int],
  @rate2  NUMERIC(25,8),
  @rate3  NUMERIC(25,8),
  @rate4  NUMERIC(25,8),
  @validmonth [smallint],
  @validday [smallint],
  @comment [varchar](250),
  @pinyin [varchar](80),
  @firstcheck [bit],
  @otcflag [char](1),
  @medtype int,
  @costmethod [char](1),
  @Parent_id [varchar](30),
  @GspFlag [char](2),
  @engName [varchar](50),
  @chemName [varChar](50),
  @latinName [varChar](50),
  @deduct NUMERIC(25,8),
  @OTCType [Tinyint],
  @GMP  [bit],
  @Gross  NUMERIC(25,8),
  @MaintainType  [Tinyint],
  @MaintainDay [Int],
  @Range  [int],
  @packStd [varchar](30),
  @storageCon [varchar](30),
  @TaxRate NUMERIC(25,8),
  @supplier_id [int],
  @emp_id [int],
  @posYhDay [int],
  @ifIntegral bit,
  @Integral int,
  @Factory varchar(80),
  @RowIndex int,   /* wsk add*/
  @tc1 NUMERIC(25,8),
  @tc2 NUMERIC(25,8),
  @tcmoney NUMERIC(25,8),
  @TcCost NUMERIC(25,8),
  @BulidNo	[varchar](500),
  @RegisterNo	[varchar](500),
  @WholeUnit_id int,
  @PrintClass int,
  @deleted  int,
  @Inputdate varchar(50),
  @Inputman  varchar(50),
  @Custompro1 varchar(100),
  @Custompro2 varchar(100),
  @Custompro3 varchar(100),
  @Custompro4 varchar(100),
  @Custompro5 varchar(100),
  @Locid int,
  @NoneQuantity NUMERIC(25,8),/*断货数量参数*/
  @FactoryC_ID int,
  @SR_ID  int,   /*商品销售区域控制*/
  @nY_id  int,    /*当前机构ID*/
  @Drate  NUMERIC(25,8),   /*-商品加价率*/
  @basicMedication NUMERIC(25,8),  /*-基本药物*/
  @SR2_id int, /*商品类别2*/
  @Wholeloc int,/*整货货位*/
  @SingleLoc int, /*零货货位*/
  @protectprice int,  /*价格保护 add by luowei 2013-01-31*/
  @RegistervalidDate datetime,  /*--注册证号有效期 add by luowei 2013-03-26*/
  @PerCodevalidDate datetime, /*--批准文号有效期 add by luowei 2013-03-26*/
  @TransToYJ    [bit],
  @ControlYard  [bit],
  @ifdiscount [bit],
  @pack varchar(100),
  @isCheckReport bit,
  @GMPNo varchar(120),
  @GMPValiddate  datetime,
  @Kcl INT,
  @Kcldw INT,
  @Khsbl NUMERIC(25,8),
  @Kcljg NUMERIC(25,8),
  @incRate2 NUMERIC(25,8),
  @incRate3 NUMERIC(25,8),
  @isCheckLT BIT,
  @StoreCondition INT,
  @IsValidP int, /*zfl贵细药品*/
  @IfZYCheck int,/*中药*/
  @IsClientDiscount int, /*是否打折，和往来单位折扣有关*/
  @FCategoryStr  varchar(100),/*自定义类别字符串*/
  @commodityCode varchar(100),
  @fztaxrate     NUMERIC(25,8),/*辅助税率*/
  @taxrateflcode varchar(100), /*税务类型编号*/
  @Z_ZNumber     varchar(100), /*证照编号*/
  @Z_ZBillDate   datetime,/*证照期限*/
  @auditManID  Int, /*审核人ID*/
  @auditMan  varchar(50), /*审核人*/
  @auditComment varchar(50), /*审核意见*/
  @AloneLocation INT,
  @LocationRequirement INT,
  @DefaultBuyUnit INT,
  @DefaultSaleUnit INT,
  @SaleUnitMultiple INT,
  @StandardCode  VARCHAR(60),
  @CloudCode  VARCHAR(60),
  @isonline INT  /*网上商品*/
)

AS 
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int],
  @newP_id  int,
  @AuditStates int
   
  if @auditManID > 0
    set @AuditStates = 1
  else 
    set @AuditStates = 0
/*合法性检查*/
/*if exists(select * from products where )*/

/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Products')
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*检查黑名单*/
if exists(select 1 from ProductBlacklist where name=@name)
begin
  RAISERROR('该药品名称在药品黑名单中，不能使用该名称',16,1)
  return-1
end

if exists(select 1 from ProductBlacklist where permitcode =@permitcode)
begin
  RAISERROR('该批准文号的药品已列入黑名单，不能添加',16,1)
  return-1
end
if exists(select 1 from products where serial_number=@serial_number and deleted=0)
begin
  RAISERROR('商品编号重复，不能添加',16,1)
  return-1
end

/*BEGIN TRAN insertBaseInfo  */

INSERT INTO [products] 
  ( [class_id],
  [serial_number],
  [name],
  [alias],
  [standard],
  [modal],
  [permitcode],
  [trademark],
  [makearea],
  [unit1_id],
  [unit2_id],
  [unit3_id],
  [unit4_id],
  [rate2],
  [rate3],
  [rate4],
  [validmonth],
  [validday],
  [comment],
  [deleted],
  [pinyin],
  [firstcheck],
  [otcflag],
  [medtype],
  [costmethod],
  [Parent_id],
  [GspFlag],
  [EngName],
  [ChemName],
  [LatinName],
  [Deduct],
  [OTCType],
  [GMP],
  [gross],
  [MaintainType],
  [MaintainDay],
  [r_id],
  [packStd],
  [storageCon],
 	[Taxrate],
 	[PosYhDay],
  ifIntegral,
  Integral,
  factory,
  RowIndex,    /*wsk add*/
	tc1,
  tc2,
  tcmoney,
  TcCost,
  BulidNo,
  RegisterNo,
  printClass,
  WholeUnit_id,
  Inputdate,
  Inputman,
  Custompro1,
  Custompro2,
  Custompro3,
  Custompro4,
  Custompro5,
  NoneQuantity, /*断货数量*/
  FactoryC_ID,
  SR_ID,
  Incrate,
  basicMedication,
  SR2_id,
  protectprice,
  Registervalid,
  PerCodevalid,
  TransToYJ ,
  ControlYard,
  ifdiscount,
  pack ,
  isCheckReport,
  GMPNo,
  GMPvaliddate,
  sfcl,
  cldw,
  hsbl,
  cljg,
  incRate2,
  incRate3,
  LTTime,
  StoreCondition,
  IsValuedProduct,
  IfZYCheck,
  IsClientDiscount,
  commodityCode,
  fztaxrate,
  taxrateflcode,
  Z_ZNumber,
  Z_ZBillDate,
  auditMan,
  auditComment,
  AuditStates,
  AloneLocation,
  LocationRequirement,
  DefaultBuyUnit,
  DefaultSaleUnit,
  SaleUnitMultiplex,
  StandardCode,
  CloudCode,
  isonline 
) 
VALUES 
 ( @Tempid,
  @serial_number,
  @name,
  @alias,
  @standard,
  @modal,
  @permitcode,
  @trademark,
  @makearea,
  @unit1_id,
  @unit2_id,
  @unit3_id,
  @unit4_id,
  @rate2,
  @rate3,
  @rate4,
  @validmonth,
  @validday,
  @comment,
  @deleted,
  @pinyin,
  @firstcheck,
  @otcflag,
  @medtype,
  @costmethod,
  @Parent_ID,
  @GSPFlag,
  @engName,
  @chemName,
  @latinName,
  @Deduct,
  @OTCType,
  @GMP,
  @gross,
  @MaintainType,
  @MaintainDay,
  @range,
  @packStd ,
  @storageCon,
 	@taxrate,
 	@posYhDay,
  @ifIntegral,
  @Integral,
  @Factory,
	@RowIndex, /*wsk add*/
  @tc1,
  @tc2,
  @tcmoney,
  @TcCost,
  @BulidNo,
  @RegisterNo,
  @PrintClass,
  @WholeUnit_id,
  @Inputdate,
  @Inputman,
  @Custompro1,
  @Custompro2,
  @Custompro3,
  @Custompro4,
  @Custompro5,
  @NoneQuantity,  /*--断货数量参数*/
  @FactoryC_ID,
  @SR_ID,
  @Drate,
  @basicMedication,
  @SR2_id,
  @protectprice,   /*-价格保护*/
  @RegistervalidDate,
  @PerCodevalidDate,
  @TransToYJ,
  @ControlYard,
  @ifdiscount,
  @pack ,
  @isCheckReport,
  @GMPNo,
  @GMPvaliddate,
  @Kcl,
  @Kcldw,
  @Khsbl,
  @Kcljg,
  @incRate2,
  @incRate3,
  @isCheckLT,
  @StoreCondition,
  @IsValidP,
  @IfZYCheck,
  @IsClientDiscount,
  @commodityCode,
  @fztaxrate,
  @taxrateflcode,
  @Z_ZNumber,
  @Z_ZBillDate,
  @auditMan,
  @auditComment,
  @AuditStates,
  @AloneLocation,
  @LocationRequirement,
  @DefaultBuyUnit,
  @DefaultSaleUnit,
  @SaleUnitMultiple,
  @StandardCode,
  @CloudCode,
  @isonline  
)

if @@rowCount=0 
begin
 return -1
end 
else 
begin
   select @newP_id= @@IDENTITY
   /*---增加商品税率
     --数据中0,13,17三种税率是定死了的，所以新建时候直接默认为0,所以传过来id为0的时候取0税率id
   if @TaxRate = 0 
   begin
     select top 1 @TaxRate = id from customCategory where Typeid = 3 and name = '0'  
   end
   insert into customCategoryMapping (category_id,baseinfo_id,deleted,BaseTypeid)
   values(@TaxRate,@newP_id,0,0)
   ---增加商品剂型
   if @medtype<>0
   begin
     insert into customCategoryMapping (category_id,baseinfo_id,deleted,BaseTypeid)
     values(@medtype,@newP_id,0,0)
   end
   ---增加商品经营范围
   insert into customCategoryMapping (category_id,baseinfo_id,deleted,BaseTypeid)
   values(@Range,@newP_id,0,0)
   update products set child_number=@child_number,child_count=@child_count
   where class_id =@Parent_id
   ---处理自定义类别
   delete  from  customCategoryMapping  where category_id=0 
   update customCategoryMapping set baseinfo_id=@newP_id where baseinfo_id=0 and BaseTypeid=0 
   and id in (select  szTYPE from  DecodeToStr(@FCategoryStr)) and deleted=0
   */
   update products set child_number=@child_number,child_count=@child_count
   where class_id =@Parent_id
    if exists(select 1 from Productbalance where Y_id=@nY_id and P_id=@newP_id)
    begin
	UPDATE Productbalance 
	
	SET	 [Locationid] 	        = @Locid,
		 [Supplier_id]          = @supplier_id,
		 [Emp_id]               = @emp_id,
		 [WholeLoc]             = @Wholeloc,
		 [SingleLoc]            = @SingleLoc
	WHERE 
		( [P_id]		= @newP_id  AND
	          Y_id      = @nY_id)  
    end
    else
    begin
	
	INSERT Productbalance(Y_id,P_ID,Locationid,Wholeloc,Singleloc,Supplier_id,Emp_id)
	VALUES(@nY_id,@newP_id,@Locid,@Wholeloc,@SingleLoc,@supplier_id,@emp_id)
    end
    
    if @auditManID > 0
    begin
       INSERT sysTnotes (magbillid, billtype,updateman,updatedate,notes)
       VALUES(@newP_id,0,@auditManID,GETDATE(),'【审核】')
    end
 return @newP_id
end
GO
