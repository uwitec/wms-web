
/* =============================================*/
/* Author:		zjiin*/
/* Create date: 2013-5-10*/
/* Description:	读取主类别及子类别相关信息*/
/* =============================================*/
CREATE FUNCTION GetCateGoryStr 
(
	@CG_ID int,
	@SelStr varchar(50)
	
)
RETURNS varchar(200)
AS
BEGIN
	declare @Result Varchar(200), @szClass_id varchar(10), @szMainClass_ID varchar(4)
	declare @szParent_ID varchar (10), @szParentName varchar (10), @szName varchar(100)
	
	select @szClass_id = class_id, @szName = name from customCategory where id = @CG_ID	
    		
	if UPPER(@SelStr) = 'MAINCATEGORY'
	begin
      set @szMainClass_ID = LEFT(@szClass_id, 2)
      select @Result = name from customCategory where class_id =  @szMainClass_ID   		      	
	end  
			
	if UPPER(@SelStr) = 'SUBCATEGORY'
	begin
	  declare @i int
	  set @i = len(@szClass_id)
	  if @i < 5 
	    set @Result = @szName
	  else begin
	    set @szParent_ID = LEFT(@szClass_id, 4) 
	    select @szParentName = name from customCategory where class_id = @szParent_ID
	    if @i>7 begin 
	      set @szParent_ID = LEFT(@szClass_id, 6)
	      select @szParentName = @szParentName+'-'+name from customCategory where class_id = @szParent_ID 
	    end  
	    set @Result = @szParentName + '-' +@szName
	  end	    	  		
	end 
	RETURN @Result
END
GO
