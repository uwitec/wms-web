





CREATE	 PROCEDURE ts_L_LimitBulidBill 
(
	@Billtype   int,
	@s_id	    int,	
	@Bille	    int,
    @nPriceMode int=0,
    @nMergeMode int=0,
    @nY_id      int=0,
    @billSN     varchar(60)= '',
    @nsa_id     int,  /*入库库区*/
    @sout_id    int,  /*出库仓库*/
    @saOut_id   int  /*出库库区*/
)
AS
SET NOCOUNT ON;
/*Params Ini begin*/
if @nPriceMode is null  SET @nPriceMode = 0
if @nMergeMode is null  SET @nMergeMode = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/
/* 1.采购入库单
   2.采购合同
   3.同价配送
   4.变价配送*/ 
DECLARE @nRet INT  
DECLARE @bNestedFlag INT   
   
IF @@TRANCOUNT > 0
BEGIN
	SET @bNestedFlag = 1
	SAVE TRAN CREATEBILL
END
ELSE
BEGIN
	SET @bNestedFlag = 0
	BEGIN TRAN CREATEBILL
END
   
DECLARE @IsUseWms INT  
  SET @IsUseWms = 0
IF exists(SELECT * FROM sysconfigtmp where [sysname] = 'StoreWMS' and [sysvalue] = '1') 
  SET @IsUseWms = 1 
if @Billtype in (44) AND @IsUseWms = 1 and @nsa_id > 0  /*启用WMS后需要自动分配货位,当前只处理库存下限生成的同价调拨单@nsa_id > 0,如果以后加上限,需加参数控制*/
begin
	DECLARE @useRate NUMERIC(10,4)   /*用来控制货位的使用率*/
	set @useRate = 0.95   /*先默认为95%*/
	
	SET @nRet = -1
	
	IF OBJECT_ID('tempdb..#OutStoreTmp') IS NOT NULL
	   DROP TABLE #OutStoreTmp
	   
	CREATE TABLE #OutStoreTmp
	(
	 Storehouse_id INT,
	 s_id   INT, /*仓库*/
	 sa_id  INT, /*库区*/
	 p_id   INT, /*商品*/
	 Batchno VARCHAR(200),/*批次 */
	 loc_id INT, /*货位*/
	 qty    NUMERIC(18,4), /*数量*/
	)
    
    INSERT INTO #OutStoreTmp 
    SELECT a.storehouse_id,a.s_id,b.sa_id,a.p_id,a.batchno,a.location_id,a.quantity FROM Storehouse a 
    INNER JOIN StoreLimit b on a.p_id = b.P_id AND a.Y_ID = b.Y_ID
    LEFT  JOIN location c on a.location_id = c.loc_id and b.sa_id = b.sa_id
    where b.AdjQty <> 0 AND a.S_id = @sout_id AND c.sa_id = @saOut_id
    and a.Y_ID = @nY_id AND b.P_id in (select billtype from billtype)
    
    IF NOT EXISTS (SELECT TOP 1 * FROM #OutStoreTmp)
    BEGIN
      RAISERROR('该库区不存在可以配送的商品!', 16, 1)
      GOTO ERROR
    END
    
	IF OBJECT_ID('tempdb..#DetailTmp') IS NOT NULL
	   DROP TABLE #DetailTmp    
	CREATE TABLE #DetailTmp 
	(
	 Storehouse_id INT,
	 s_id int,
	 Loc_id int,
	 p_id   int,
	 quantity NUMERIC(18,4),
	 Batchno VARCHAR(200) 	 
	)   
       
    DECLARE @inss_id INT          /*入库仓库*/
    DECLARE @P_ID     INT         /*商品*/
    DECLARE @FPQTY NUMERIC(18,4)  /*可配送数量*/
    DECLARE @AdjQty NUMERIC(18,4) /*调整数量*/
	DECLARE @r_id int
	
    DECLARE curArtoLoc CURSOR STATIC FOR
    		
        SELECT P_id,AdjQty,r_id FROM StoreLimit s left join vw_Products p on s.P_id = p.product_id
        where Y_ID = @nY_id and S_id = @s_id and sa_id = @nsa_id AND AdjQty <> 0
        
	OPEN curArtoLoc
	FETCH NEXT FROM curArtoLoc INTO @P_ID, @AdjQty, @r_id
	while @@fetch_status=0 
	BEGIN
	   DECLARE @bS_id   INT            /*仓库ID*/
	   DECLARE @bLoc_id INT            /*货位ID*/ 
	   DECLARE @bP_id INT              /*本次P_ID*/
	   DECLARE @bQYT  Numeric(18,4)    /*本次数量*/
	   DECLARE @bBatchno VARCHAR(200) /*批次*/
	   DECLARE @YFPQTY NUMERIC(18,4)   
	   DECLARE @Storehouse_id INT
	   DECLARE @Falg  INT 
	   SET @YFPQTY = 0.00
	   SET @Falg = 0
	   DECLARE curFpQty CURSOR STATIC FOR
	     SELECT Storehouse_id FROM #OutStoreTmp WHERE p_id = @P_ID ORDER BY Storehouse_id
	   OPEN curFpQty
	   FETCH NEXT FROM curFpQty INTO @Storehouse_id
	   WHILE @Falg < 1
	   BEGIN 
	      SELECT @bS_id = s_id,@bLoc_id = location_id,@bP_id = p_id,@bQYT = quantity,@bBatchno = batchno FROM storehouse WHERE storehouse_id = @Storehouse_id
	      BEGIN
	        SELECT @YFPQTY = ISNULL(SUM(quantity),0.00) FROM #DetailTmp WHERE p_id = @P_ID
	        IF @YFPQTY + @bQYT <= @AdjQty
	        BEGIN
	          INSERT INTO #DetailTmp (Storehouse_id,s_id,Loc_id,p_id,quantity,Batchno)  /*如果已分配数量+本次分配数量 <= 调整数量*/
	          SELECT @Storehouse_id,@bS_id,@bLoc_id,@bP_id,@bQYT,@bBatchno
	          SET @Falg = 0
	        END
	        ELSE
	        BEGIN
	          INSERT INTO #DetailTmp (Storehouse_id,s_id,Loc_id,p_id,quantity,Batchno)  /*否则取剩余的调整数量*/
	          SELECT @Storehouse_id,@bS_id,@bLoc_id,@bP_id,@AdjQty - @YFPQTY,@bBatchno 
	          SET @Falg = 1
	        END
	      END  
	      FETCH NEXT FROM curFpQty INTO @Storehouse_id   
	   END
	   CLOSE curFpQty
	   DEALLOCATE curFpQty	   
	FETCH NEXT FROM curArtoLoc INTO @P_ID, @AdjQty, @r_id	   
    END
	CLOSE curArtoLoc
	DEALLOCATE curArtoLoc
	
	
 	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		DROP TABLE #tmpDetail
	CREATE TABLE #tmpDetail
	(
	  Storehouse_id INT,
	  p_id      INT,   /*商品*/
	  s_id		INT,   /*仓库id*/
	  l_id      INT,   /*货位id*/
	  r_id      INT,   /*剂型id*/
	  qty       NUMERIC(18,4),   /*-分配基本数量*/
	  fqty      NUMERIC(18,4),   /*-分配数量*/
	  sflag     INT	   /*整，零货类型	*/
	)   
	
	/*开始货位分配*/
	DECLARE @nStorehouse_id INT
	DECLARE @fp_id INT
	DECLARE @fqty NUMERIC(18,4) 
	DECLARE @fBatchno VARCHAR(200)
	DECLARE @fr_id INT
    DECLARE curFpLoc CURSOR STATIC FOR	
      SELECT a.Storehouse_id,a.p_id,a.quantity,a.Batchno,b.r_id FROM #DetailTmp a LEFT JOIN vw_Products b on a.p_id = b.product_id ORDER BY p_id,quantity      
	OPEN curFpLoc
	FETCH NEXT FROM curFpLoc INTO @nStorehouse_id,@fp_id, @fqty, @fBatchno, @fr_id
	while @@fetch_status=0 
	BEGIN
			/*查找可分配的货位*/
			select a.s_id,a.loc_id,(isnull(a.Quantity,0) - isnull(y.quantity,0) - ISNULL(t.qty,0)) as kqty
			into #Ltmp from 	
				(select l.s_id,l.loc_id,m.Quantity,l.sa_id from location l left join WMSMedtype m on l.loc_id = m.StoreQYHWID 	 
				where m.MedtypeID = @fr_id and isnull(m.Flag,2) = 2 and l.deleted = 0 and l.sa_id = @nsa_id ) a	/*每一个货位总共可存放该商品剂型的数量*/
			left OUTER JOIN				
				(select s.s_id,s.location_id,sa_id,SUM(quantity) as quantity				
				from storehouse s,vw_Products p, location c 
				where s.p_id = p.product_id and s.Y_ID = @nY_id and p.r_id = @fr_id 
				and c.s_id = s.s_id and c.sa_id = @nsa_id group by s.s_id,s.location_id,p.r_id,sa_id ) y	/*计算当前货位状况,每一个仓库已存放该商品剂型的数量	*/
			on a.s_id = y.s_id and a.loc_id = y.location_id	and a.sa_id = y.sa_id
			left OUTER JOIN 
				(select l_id,SUM(qty) as qty from #tmpDetail where r_id = @fr_id  /*减去该单已经占用的货位量*/
				 group by l_id	)t                                                
			on a.loc_id = t.l_id 
			where (isnull(a.Quantity,0) - isnull(y.quantity,0)- ISNULL(t.qty,0)) >= a.Quantity
	        
			select 999 as level,L.loc_id,ISNULL(lt.kqty,0) as kQty ,(l.stockpilePgNum -l.alreadyPgNum) as pgQty,l.PickEasy 
			into #Rtmp
			from location l left OUTER JOIN  WMSMedtype m on l.loc_id = m.StoreQYHWID 
				 left join stockArea sa on l.sa_id = sa.sa_id
				 left join #Ltmp lt on l.loc_id = lt.loc_id		/*取出可用的货位的可存放数量*/
				 where isnull(Flag,2) = 2 and l.deleted = 0 and isnull(m.deleted,0) =0
					   and isnull(m.MedtypeID,@fr_id) = @fr_id   /*过滤剂型*/
					   and sa.SAType = 0   /*过滤整货库区*/
					   and l.stockpilePgNum  > l.alreadyPgNum
					   and l.sa_id = @nsa_id

			
			declare @count int
			set @count = 0
			while @count < 5
			begin
				/*1.同批次的货位*/
				update #Rtmp set level = 1 + @count *100 where loc_id in (select location_id from storehouse where p_id = @fp_id and batchno = @fBatchno and Y_ID = @nY_id) and PickEasy = @count 
				/*2.同批次的历史货位*/
				update #Rtmp set level = 2 + @count *100 where loc_id in (select location_id from productdetail where p_id = @fp_id and batchno = @fBatchno and Y_ID = @nY_id) and PickEasy = @count  and level >= 100
				/*--3.其它条件
				update #Rtmp set level = 3 + @count *100 where loc_id in (select location_id from productdetail where p_id = @pid and batchno = @Batchno) and PickEasy = @count  and level >= 200
				*/	
				set @count = @count +1			
			end
				
			/*-根据设置好的优先级，在循环游标里面作综合排序*/
			DECLARE @kLoc_id INT
			DECLARE @kQty    NUMERIC(18,4)
			DECLARE @inQty NUMERIC(18,4)
			DECLARE curWLoc CURSOR STATIC FOR
			   select loc_id,kQty from #Rtmp order by level asc,kqty asc,pgQty asc									
			OPEN curWLoc 
			FETCH NEXT FROM curWLoc INTO @kLoc_id, @kQty		
			while @fqty > 0 AND @@FETCH_STATUS = 0 
			BEGIN
					if @kQty  > @fqty 
						set @inQty = @fqty    /*-分配一个货位就完成*/
					else
						set @inQty = floor(@kQty/@fqty)  /*往下继续分配*/
						
					insert into #tmpDetail(Storehouse_id,p_id,s_id,l_id,r_id,qty,fqty,sflag)
					select @nStorehouse_id,@fp_id,@s_id,@kLoc_id,@fr_id,@inQty,@inQty,0	

					set @fqty = @fqty - @inQty
					FETCH NEXT FROM curWLoc INTO @kLoc_id, @kQty	
			END	
			CLOSE curWLoc
			DEALLOCATE curWLoc

 	  IF  OBJECT_ID('tempdb..#Rtmp') IS NOT NULL
		  DROP TABLE #Rtmp	
		
 	  IF  OBJECT_ID('tempdb..#Ltmp') IS NOT NULL
		  DROP TABLE #Ltmp	
					        
	  FETCH NEXT FROM curFpLoc INTO @nStorehouse_id,@fp_id, @fqty, @fBatchno, @fr_id
	END	
	CLOSE curFpLoc
	DEALLOCATE curFpLoc

    DECLARE @billdate varchar(12)
    DECLARE @nPeriod varchar(30)
    DECLARE @NewBillid INT 
    
    set @billdate=convert(varchar(10),GetDate(),20)
    exec ts_GetSysValue 'AccountPeriod',@nPeriod output
    INSERT INTO BillDraftidx
      (
      billdate ,billnumber,billtype,c_id,e_id,sout_id,sin_id,auditman,inputman,
      period  ,billstates,GUID, taxrate,
      auditdate ,note  ,summary ,begindate,enddate,Y_id,
      B_CustomName1,B_CustomName2,B_CustomName3,sendC_Id, 
      financeAudit,financeAuditDate, BalanceMode,ZBAuditMan,ZBAuditDate      
      )
      VALUES
      (
      @billdate,@billSN,@billtype,0,@Bille,@sout_id,@s_id,0,@Bille,
      CAST(@nPeriod AS INT) ,'2' ,NEWID(), 0.00,
      '' ,'【由库存预警生成】','' ,'1900-01-01 00:00:00.000','1900-01-01 00:00:00.000',@nY_id,
      '','','','', 0,'1900-01-01 00:00:00.000', 0,0,'1900-01-01')
 
    SET @NewBillid = @@IDENTITY
    
    INSERT INTO storemanageBilldrf
    (
    bill_id, p_id, batchno, quantity, costprice, price, totalmoney, retailprice,
    retailmoney, makedate, validdate, price_id, ss_id, sd_id, location_id, supplier_id,
    commissionflag, comment, unitid, location_id2, qualitystatus, iotag, total, invoiceTotal , 
    OrgBillID,Aoid,SendQTY,SendCostTotal,RowE_id,RowGUID, Y_ID, InStoreTime, scomment, batchprice, 
    BatchBarCode,factoryid,costtaxprice,costtaxrate,costtaxtotal
    )
    SELECT 
    @NewBillid, t.p_id, s.batchno, t.fqty, s.costprice, s.costprice, isnull(t.fqty,0) * s.costprice, p.retailprice,
    isnull(t.fqty,0) * p.retailprice, s.makedate, s.validdate, 0, t.s_id, @sout_id, s.location_id, s.supplier_id,
    s.commissionflag, '', p.unit1_id ,t.l_id, '合格',0, isnull(t.fqty,0) * s.costprice, 0.00 ,
    0,0,t.fqty,isnull(t.fqty,0) * s.costprice,@Bille,NEWID(), @nY_id, @billdate, '', 0.00, 
    s.BatchBarCode,s.factoryid,s.costtaxprice,s.taxrate,isnull(t.fqty,0) * s.costtaxprice
    FROM  #tmpDetail t
    LEFT JOIN storehouse s on s.Storehouse_id = t.Storehouse_id
    LEFT JOIN vw_Products p on t.p_id = p.product_id
    where t.fqty > 0

    if @@ROWCOUNT = 0
	   GOTO ERROR   
	ELSE 
	   SET @nRet = @NewBillid 
	
	update billdraftidx set ysmoney=O.tax ,quantity=O.Qty
	from (select sum(o.totalmoney) as tax ,SUM(O.quantity) as Qty from storemanagebilldrf O where O.bill_id=@nRet)O 
	where billdraftidx.billid=@nRet	

	GOTO SUCCEE  
	  
end
else
begin
	declare @szPeriod varchar(30),@lPeriod int,@lBillRet int,@toDay varchar(12)
	declare @lP_id int,@ls_id int,@dAdjNum NUMERIC(25,8),@lTmp int,@nTableTag int,@B_id int
	declare @price NUMERIC(25,8),@Total NUMERIC(25,8),@Unitid int,@retailPrice NUMERIC(25,8),@retailTotal numeric(25,8)
	declare @TaxRate numeric(3, 2), @sysTaxRate numeric(3,2), @TaxPrice NUMERIC(25,8), @TaxTotal NUMERIC(25,8), @Taxmoney NUMERIC(25,8)
	declare @nreturn int
	declare @GUID uniqueidentifier
	declare @currY_ID INT
	declare @nGuid varchar(200)
	declare @FactoryId int

	declare @c_id int
	set @GUID=newid()

	/*删除billtype里面 停用的商品*/

	if @Billtype in (52)
	  delete from billtype where billtype in (select product_id from products where deleted=4)
	  


	/**/
	if not exists(select p_id from StoreLimit where s_id=@S_id and AdjQty<>0) 
	GOTO ERROR 
	exec ts_GetSysValue 'AccountPeriod',@szPeriod output

	/*------------------------添加到缺货清单中 add by luowei 2012-08-20  */
	IF @Billtype = 187 
	BEGIN
	  exec ts_getsysvalue 'Y_ID',@currY_ID out
	  if (@currY_ID = 2) and (@nY_id = 2)
	  begin 
		  insert into OOSCatalog(ProductId,CompanyId,ClientId,EId,OOSQty,PlanQty,Deleted,InputManId)
				  select  s.P_id,s.Y_ID,0,0,s.AdjQty,0,0,@Bille 
				  from StoreLimit s
				  where Y_id=@nY_id and AdjQty<>0 and s.p_id in (select distinct billtype from billtype)
		  SET @nRet = 1
		  GOTO SUCCEE
	  end		  
	END 

	set @sysTaxRate = -1
	if exists(select 1 from sysconfig where [sysname] = 'UseSameTaxRate' and [sysvalue] = '1') 
	  select @sysTaxRate = CAST(cast(sysvalue as NUMERIC(25,8))/100  as numeric(3, 2)) from sysconfig where [sysname] = 'TaxRate' and [Y_ID] = 0

	set @lperiod=Cast(@szPeriod as int)
	/*   采购入库单*/
	if @billtype =20  set @nTableTag=0 
	/*   采购合同*/
	if @billtype =22 or  @Billtype=26 set @nTableTag=4 
	/*   同价调拨 变价调拨*/
	if @billtype in (44,45) set @nTableTag=2 
	if @billtype in (52) set @ntableTag=7
	set @toDay=convert(varchar(10),GetDate(),20)


	if @nPriceMode=0
	  select distinct a.p_id,min(c.buyprice) as taxprice ,max(a.supplier_id) as supplier_id
	  into #lowprice
	  from buymanagebill a,billidx b,
	  (
		select b.p_id,min(b.buyprice) as buyprice
		from billidx a,buymanagebill b 
		where a.Y_id=@nY_id and a.billid=b.bill_id and a.billstates='0' and a.billtype=20 and b.aoid=0
		group by b.p_id
	  ) c
	  where b.billid=a.bill_id and a.aoid=0 and b.billstates='0' and a.p_id=c.p_id and a.buyprice=c.buyprice
	  group by a.p_id



	if @nPriceMode=1
	  select distinct vb.p_id ,max(supplier_id) as supplier_id,c.buyprice as taxprice
	  into #recprice

	  from  
	  (select a.p_id ,min(buyprice) buyprice,max(b.billdate) as billdate from buymanagebill a,billidx b
	  where b.Y_id=@nY_id and a.bill_id=b.billid and b.billtype=20 and b.billstates='0' and a.aoid=0 group by a.p_id ) as c

	  left join buymanagebill vb
	  on vb.p_id=c.p_id and vb.buyprice=c.buyprice
	  left join (select * from billidx where billstates = 0 and billtype = 20) bi
	  on bi.billid=vb.bill_id and bi.billdate=c.billdate
	  where vb.aoid=0 
	  group by vb.p_id,c.buyprice
	  order by vb.p_id

	/*生成表头*/
	if @billtype in (52)
	begin
	 select @c_id=@nY_id
	 set @nGuid = NEWID()
	end 
	else
	begin
	 select @c_id=0
	 set @nGuid = ''
	end 


	/* 生成billdraftidx */
	exec Ts_b_InsertBillIndexDraft @nret output,0,@ntableTag,0,@today,@billSN,
			@Billtype,0,@c_id,@Bille,0,0,0,@Bille,0,0,0,0,@lperiod,'2',0,0,0,0,0,0,0,
			'0','【由库存报警生成】','',0,'',0,0,0,0,0,0,0,0,0,0,'1111111',@nY_id,'','',@nGuid
	if @nret<>0 
	begin    
		if @Billtype= 52
		   update tranidx set billnumber =  @billSN where billid = @nret
	    
		if @Billtype in (22,26)
		begin
		if @nPriceMode=0
  			declare Limit_cur cursor for 
  				select s.p_id,s.s_id,s.adjQty,isnull(c.Supplier_id,0)  supplier_id,isnull(c.taxprice,0) taxprice,
  					p.unit1_id,p.retailPrice, cast(p.taxrate/100 as numeric(3, 2)) as taxrate,factoryc_id
  				from StoreLimit s
  				left join #lowprice c On c.P_id=s.p_id ,
  					  vw_products p
  				where Y_id=@nY_id and s_id=@S_id and AdjQty<>0 and s.p_id=p.product_id and s.p_id in (select distinct billtype from billtype)
	  
		else if @nPriceMode=1
  			declare Limit_cur cursor for 
  				select s.p_id,s.s_id,s.adjQty,isnull(c.Supplier_id,0)  supplier_id,isnull(c.taxprice,0) taxprice,
  					p.unit1_id,p.retailPrice, cast(p.taxrate/100 as numeric(3, 2)) as taxrate,factoryc_id
  				from StoreLimit s
  				left join #recprice c On c.P_id=s.p_id ,
  						 vw_products p
  				where Y_id=@nY_id and s_id=@S_id and AdjQty<>0 and s.p_id=p.product_id and s.p_id in (select distinct billtype from billtype)
	  		
  		open Limit_cur
  		fetch next from Limit_cur into @lp_id,@lS_id,@dAdjNum,@B_id,@price,@unitid,@retailPrice, @taxrate,@FactoryId
	  		
  		while @@fetch_status=0
  		begin
  			set @total=@DAdjNum*@price
  			if @sysTaxRate > -1 set @TaxRate = @sysTaxRate  /*取系统设置税率 */
  			set @TaxPrice = cast(@price*(1+@Taxrate) as NUMERIC(25,8))
  			set @TaxTotal = cast(@dAdjNum*@TaxPrice as NUMERIC(25,8))
  			set @Taxmoney = @TaxTotal-@Total
  			set @retailTotal = cast(@dAdjNum*@retailprice as numeric(25,8))  		
	  		
  			exec Ts_b_InsertBillDetailDraft @lBillret output,
  								@nTableTag,
  								0,
  								@nret,
  								0,
  								@lp_id,
  								'',
  								@DAdjNum,
  								@price,@price,@total,1,@price,
  								@total,@taxprice,@taxtotal,@Taxmoney,@retailprice,
  								@retailTotal,0,0,
  								'合格',
  								0,0,0,0,0,
  								@b_id,0,'',@unitid,@TaxRate,0,0,0,0,0,0,
  								0,0,0,0,@Bille,@GUID,'0','',@nY_id,0,
  								0,'','',0,'',0x0,'','',@FactoryId
	  							
  			SET @nRet = @lBillret
  			if @lBillret=-1 
  			begin
  				/*exec Ts_b_DeleteBillDraft @ltmp output,@nTableTag,@nret*/
  			   GOTO	ERROR  
  			end
  			fetch next from Limit_cur into @lp_id,@lS_id,@dAdjNum,@B_id,@price,@unitid,@retailPrice, @taxrate,@FactoryId
  		end
	  		
  		close Limit_cur
  		deallocate Limit_cur

		if @nMergeMode=1 
		begin
		  exec ts_c_SplitBill @Billtype,@nret,@nMergeMode,@nreturn output
		  if @nreturn=0
 				  exec Ts_b_DeleteBillDraft @ltmp output,@nTableTag,@nret
		end
	   /*zh 10.08.13,@nret+1(采购合同生成单据号为单号) */
	   update orderidx set ysmoney=O.tax ,quantity=O.Qty
	   from (select sum(o.taxtotal)tax ,SUM(O.quantity)Qty from OrderBill O where O.bill_id=(@nret+1))O 
	   where orderidx.billid=(@nret+1)
	   
		end 
		else
		begin
			declare Limit_cur cursor for 
				select s.p_id,s.s_id,s.adjQty,isnull(c.recprice,0)as recprice ,
					p.unit1_id,p.retailPrice, cast(p.taxrate/100 as numeric(3, 2)) as taxrate,factoryc_id
				from StoreLimit s
				left join (select recPrice,p_id 
  					   from price 
						   Where Unittype=1
						   group by p_id,recprice ) as c On c.P_id=s.p_id ,
					vw_products p
				where Y_id=@nY_id and s.s_id=@S_id and s.AdjQty<>0 and s.p_id=p.product_id and s.p_id in (select distinct billtype from billtype)
			
			open Limit_cur
			fetch next from Limit_cur into @lp_id,@lS_id,@dAdjNum,@price,@unitid,@retailPrice, @taxrate,@FactoryId
			
			while @@fetch_status=0
			begin
				set @total=@DAdjNum*@price
				if @sysTaxRate > -1 set @TaxRate = @sysTaxRate  /*取系统设置税率 */
				set @TaxPrice = cast(@price*(1+@TaxRate) as NUMERIC(25,8))
  				set @TaxTotal = cast(@dAdjNum*@TaxPrice as NUMERIC(25,8)) 
  				set @Taxmoney = @TaxTotal-@Total
  				set @retailTotal = cast(@dAdjNum*@retailprice as numeric(25,8))
				
				exec Ts_b_InsertBillDetailDraft @lBillret output,
								@nTableTag,
								0,
								@nret,
								0,
								@lp_id,
								'',
								@DAdjNum,
								@price,@price,@total,1,@price,
								@total,@taxprice,@taxtotal,@Taxmoney,@retailprice,
								@retailTotal,0,0,
								'合格',
								0,0,0,0,0,
								0,0,'',@unitid,@TaxRate,0,0,0,0,0,0,
								0,0,0,0,@Bille,@GUID,'0','',@nY_id,0,
								0,'','',0,'',0x0,'','',@FactoryId
				SET @nRet = @lBillret
				if @lBillret=-1 
				begin
					/*exec Ts_b_DeleteBillDraft @ltmp output,@nTableTag,@nret*/
					GOTO ERROR 
				end
				fetch next from Limit_cur into @lp_id,@lS_id,@dAdjNum,@price,@unitid,@retailPrice, @taxrate,@FactoryId
			end
			
			close Limit_cur
			deallocate Limit_cur
		  if @Billtype in (44,45)
			update billdraftidx set ysmoney=O.tax ,quantity=O.Qty
			from (select sum(o.totalmoney)tax ,SUM(O.quantity)Qty from storemanagebilldrf O where O.bill_id=@nret)O 
			where billdraftidx.billid=@nret
		  else
			update billdraftidx set ysmoney=O.tax ,quantity=O.Qty
			from (select sum(o.taxtotal)tax ,SUM(O.quantity)Qty from buymanagebilldrf O where O.bill_id=@nret)O 
			where billdraftidx.billid=@nret
		END
	end
end

IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END
    RETURN @nRet
    
SUCCEE:   
IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END
    RETURN @nRet

ERROR:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	if  OBJECT_ID('tempdb..#tmpDetail') IS NOT NULL
		drop table #tmpDetail
	RETURN -1
GO
