create proc ts_c_CreateVipDetail
(
  @nbillid int
)

as
set nocount on 

declare @nNewBillid int

set @nNewBillid=-1

INSERT INTO vipidx
           (
            billid,
			billdate
           ,billnumber
           ,billtype
           ,yname
           ,y_id
           ,vipcardid
           ,vipcardno
           ,skname
           ,ywname
           ,qty
           ,total
           ,distotal
           ,integral)
 select a.billid,a.billdate,a.billnumber,a.billtype,b.name,b.company_id,a.VIPCardID,c.CardNo,inputman,ename,a.integral,
 qty= case a.billtype when 12 then  sum(s.quantity) else -sum(s.quantity) end,
 total=case a.billtype when 12 then  sum(s.taxtotal) else -sum(s.taxtotal) end,
 distotal=case a.billtype when 12 then  sum(s.totalmoney) else -sum(s.totalmoney) end
 
 from vw_c_billidx a,company b,VIPCard c,salemanagebill s
 where a.Y_ID=b.company_id and a.VIPCardID=c.VIPCardID and a.billid=s.bill_id and s.p_id>0 
 and a.billid=@nbillid
 group by 
	   a.billid,a.billdate,a.billnumber,a.billtype,b.name,b.company_id,a.VIPCardID,c.CardNo,inputman,ename,a.integral
 if @@ROWCOUNT>0 set @nNewBillid=@@IDENTITY else goto error1
 
 
 
 /* 插入收款明细*/
 INSERT INTO vipAdetail
           (
           vipidx_id
           ,accountname
           ,total
           ) 
 select @nNewBillid,accountname,jdmoney
 from vw_c_ADetail a                     /*现金                             银行                           储值                                折让*/
 where billid=@nbillid and (a.aclass_id='000001000003' or a.aclass_id like '000001000004%' or a.aclass_id='000002000006' or a.aclass_id='000004000003000004')
        
 if @@ROWCOUNT=0 goto error1
           
           
           
/* 插入商品明细           */
INSERT INTO vippdetail
           (
           vipidx_id,
           pname,
           pstandard,
           makearea,
           qty,
           price,
           total,
           costprice)
select @nNewBillid,p.name,p.standard,p.makearea,
qty=case a.billtype when 12 then s.quantity else -s.quantity end,s.taxprice,
total=case a.billtype when 12 then s.taxtotal else -s.taxtotal end,s.costprice
from billidx a,salemanagebill s,products p
where a.billid=s.bill_id and  a.billid=@nbillid and s.p_id>0 and s.p_id=p.product_id
if @@ROWCOUNT=0 goto error1


return @nNewBillid 

error1:

   return -100001
GO
