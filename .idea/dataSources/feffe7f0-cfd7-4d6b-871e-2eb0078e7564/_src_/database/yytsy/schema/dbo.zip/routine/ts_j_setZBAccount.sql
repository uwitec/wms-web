/************************************************************

说明：
ts_j_setUsefiliale 使用了该过程，修改时注意


**************************************************************/

CREATE	 PROCEDURE [ts_j_setZBAccount]  
	
AS 

declare @Y_ID int, @szYClass_id varchar(30)
select @Y_ID = company_id, @szYClass_id = class_id  from company where class_id = '000001'
if @szYClass_id <> '000001'
begin
  Raiserror('数据升级错误，请手动升级数据库！', 16 ,1)
  Return -1
end

   update sysconfig set sysvalue = cast(@Y_ID as varchar(10)) where upper([sysname]) = 'Y_ID'
   update sysconfig set sysvalue = @szYClass_id where upper([sysname]) = 'YCLASSID'
   update sysconfig set sysvalue = '总公司' where upper([sysname]) = 'YNAME'

if @@Error <> 0 Return -1

if exists (select * from sysconfig where upper([sysname]) = 'ISUSEFILIALE' and sysvalue = '0')
begin
  update storages set y_id = @Y_ID
  update employees set y_id = @Y_ID
end

if @@Error <> 0 Return -1

Return 0
GO
