
CREATE	       PROCEDURE Ts_K_AddSpecialProducts
(
	@TpId  INT,  
	@PId   INT,
	@FId   INT	
)
/*with encryption*/
AS
BEGIN
	IF EXISTS(SELECT 1 FROM products p WHERE p.product_id = @PId AND p.child_number = 0)
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM TcProjectOther t WHERE t.Tp_id = @TpId AND t.p_id = @PId)
		BEGIN
			INSERT INTO TcProjectOther
			(
				Tp_id,
				p_id,
				F_id
			)
			VALUES
			(
				@TpId,
				@PId,
				@FId
			)
		END
	END
	ELSE
	BEGIN
		DECLARE @szClassId VARCHAR(30)
		SELECT @szClassId = p.class_id FROM products p WHERE p.product_id = @PId
		
		INSERT INTO TcProjectOther
		SELECT @TpId,
		       a.product_id,
		       @FId
		FROM   (
		           SELECT p.product_id
		           FROM   products p
		           WHERE  p.parent_id LIKE @szClassId + '%'
		                  AND p.[deleted] = 0
		       ) a
		       LEFT JOIN (
		                SELECT DISTINCT t.p_id
		                FROM   TcProjectOther t
		                WHERE  t.Tp_id = @TpId
		            ) b
		            ON  a.product_id = b.p_id
		            AND b.p_id IS NULL 
	END	
END
GO
