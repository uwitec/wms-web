
CREATE PROCEDURE [dbo].[Ts_K_AfterBillAudit]
(
    @BillType   INT,
    @BillId     INT,
    @NewBillId  INT)
AS
BEGIN
	DECLARE @SfdaCode VARCHAR(20), @BatchNo VARCHAR(20)
	DECLARE @PId INT, @SId INT, @YId INT
	DECLARE @ValidDate DATETIME, @MakeDate DATETIME		
	IF @Billtype IN (10, 11)
 	BEGIN
 		INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
 		SELECT b.billid, a.Sfda_Code, CASE WHEN @BillType = 11 THEN 1 ELSE 2 END, b.GUID
 		FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 		           FROM   RetailBillidx_Sfda
 		           WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		       ) a
 		       INNER JOIN (
 		                SELECT b.billid, b.GUID, bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                FROM   billidx b
 		                       INNER JOIN salemanagebill bb ON b.billid = bb.bill_id WHERE b.billid = @NewBillId
 		            ) b
 		            ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate 
 		
 		DECLARE WriteSfdaList CURSOR  
	    FOR
			SELECT a.Sfda_Code, b.p_id, b.batchno, b.validdate, b.makedate, b.ss_id, b.Y_ID
 			FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 					   FROM   RetailBillidx_Sfda
 		               WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		           ) a
 		           INNER JOIN (
 		                    SELECT bb.Y_ID, bb.bill_id,  bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                    FROM   salemanagebill bb WHERE bb.bill_id = @NewBillId
 		                ) b
 		                ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate	
	    OPEN WriteSfdaList
	    FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId                                                                                                     
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        IF NOT EXISTS(SELECT 1 FROM Sfda_List WHERE Sfda_Code = @SfdaCode)
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId, CASE WHEN @BillType = 11 THEN 0 ELSE 1 END)
			ELSE
				UPDATE Sfda_List 
					SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, 
					    S_Id = @SId, Y_Id = @YId, [Deleted] = CASE WHEN @BillType = 11 THEN 0 ELSE 1 END
				WHERE Sfda_Code = @SfdaCode	        
	        FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId
	    END
	    CLOSE WriteSfdaList
	    DEALLOCATE WriteSfdaList
 	END
 	IF @Billtype IN (12, 13)
 	BEGIN
		INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
 		SELECT b.billid, a.Sfda_Code, CASE WHEN @BillType = 13 THEN 1 ELSE 2 END, b.GUID
 		FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 		           FROM   RetailBillidx_Sfda
 		           WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		       ) a
 		       INNER JOIN (
 		                SELECT b.billid, b.GUID, bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                FROM   billidx b
 		                       INNER JOIN salemanagebill bb ON b.billid = bb.bill_id WHERE b.billid = @NewBillId
 		            ) b
 		            ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate 
 		
 		DECLARE WriteSfdaList CURSOR  
	    FOR
			SELECT a.Sfda_Code, b.p_id, b.batchno, b.validdate, b.makedate, b.ss_id, b.Y_ID
 			FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 					   FROM   RetailBillidx_Sfda
 		               WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		           ) a
 		           INNER JOIN (
 		                    SELECT bb.Y_ID, bb.bill_id,  bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                    FROM   salemanagebill bb WHERE bb.bill_id = @NewBillId
 		                ) b
 		                ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate	
	    OPEN WriteSfdaList
	    FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId                                                                                                     
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        IF NOT EXISTS(SELECT 1 FROM Sfda_List WHERE Sfda_Code = @SfdaCode)
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId, CASE WHEN @BillType = 13 THEN 0 ELSE 1 END)
			ELSE
				UPDATE Sfda_List 
					SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, 
					    S_Id = @SId, Y_Id = @YId, [Deleted] = CASE WHEN @BillType = 13 THEN 0 ELSE 1 END
				WHERE Sfda_Code = @SfdaCode	        
	        FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId
	    END
	    CLOSE WriteSfdaList
	    DEALLOCATE WriteSfdaList
	    /*Wusj.2017-07-14.上传不需要过账不再需要此处	    */
	    /*处理门店上传总部后的顾客资料关联字段值*/
	    /*UPDATE a SET a.Gspbill_id = b.billid FROM GSPCompy a, billidx b */
	    /*WHERE a.[GUID] = b.[GUID] AND b.billid = @NewBillId*/
	END
 	IF @Billtype IN (150, 152)
 	BEGIN
 		INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
 		SELECT b.billid, a.Sfda_Code, 2, b.GUID
 		FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 		           FROM   RetailBillidx_Sfda
 		           WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		       ) a
 		       INNER JOIN (
 		                SELECT b.billid, b.GUID, bb.p_id, bb.batchno, bb.validdate, bb.makedate, b.sin_id
 		                FROM   billidx b
 		                       INNER JOIN salemanagebill bb ON b.billid = bb.bill_id WHERE b.billid = @NewBillId
 		            ) b
 		            ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate
 		
 		DECLARE WriteSfdaList CURSOR  
	    FOR
			SELECT a.Sfda_Code, b.p_id, b.batchno, b.validdate, b.makedate, 
			       CASE WHEN @BillType = 150 THEN b.sin_id ELSE b.sd_id END, b.c_id
 			FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 					   FROM   RetailBillidx_Sfda
 		               WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		           ) a
 		           INNER JOIN (
 		                    SELECT b.c_id, bb.bill_id,  bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.sd_id, b.sin_id
 		                    FROM billidx b INNER JOIN salemanagebill bb ON b.billid = bb.bill_id WHERE bb.bill_id = @NewBillId
 		                ) b
 		                ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate	
	    OPEN WriteSfdaList
	    FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId                                                                                                     
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        IF EXISTS(SELECT 1 FROM Sfda_List WHERE Sfda_Code = @SfdaCode)
				UPDATE Sfda_List 
					SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, 
					    S_Id = @SId, Y_Id = @YId, [Deleted] = 0
				WHERE Sfda_Code = @SfdaCode
			ELSE
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId, 0)	        
	        FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId
	    END
	    CLOSE WriteSfdaList
	    DEALLOCATE WriteSfdaList	
 	END
	IF @BillType IN (20, 21)
 	BEGIN
 		INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
 		SELECT b.billid, a.Sfda_Code, CASE WHEN @BillType = 20 THEN 1 ELSE 2 END, b.GUID
 		FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 		           FROM   RetailBillidx_Sfda
 		           WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		       ) a
 		       INNER JOIN (
 		                SELECT b.billid, b.GUID, bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                FROM   billidx b
 		                       INNER JOIN buymanagebill bb ON b.billid = bb.bill_id WHERE b.billid = @NewBillId
 		            ) b
 		            ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate 
 		
 		DECLARE WriteSfdaList CURSOR  
	    FOR
			SELECT a.Sfda_Code, b.p_id, b.batchno, b.validdate, b.makedate, b.ss_id, b.Y_ID
 			FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 					   FROM   RetailBillidx_Sfda
 		               WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		           ) a
 		           INNER JOIN (
 		                    SELECT bb.Y_ID, bb.bill_id,  bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                    FROM   buymanagebill bb WHERE bb.bill_id = @NewBillId
 		                ) b
 		                ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate	
	    OPEN WriteSfdaList
	    FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId                                                                                                     
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        IF NOT EXISTS(SELECT 1 FROM Sfda_List WHERE Sfda_Code = @SfdaCode)
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId, CASE WHEN @BillType = 20 THEN 0 ELSE 1 END)
			ELSE
				UPDATE Sfda_List 
					SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, 
					    S_Id = @SId, Y_Id = @YId, [Deleted] = CASE WHEN @BillType = 20 THEN 0 ELSE 1 END
				WHERE Sfda_Code = @SfdaCode	        
	        FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId
	    END
	    CLOSE WriteSfdaList
	    DEALLOCATE WriteSfdaList
 	END
 	IF @BillType IN (160, 162)
	BEGIN
		/*处理总部下传的电子监管码*/
		UPDATE a
		SET    a.billid = b.billid, a.flag = 1
		FROM   Sfda_Detail a,
		       (SELECT b.billid, b.GUID FROM billidx b WHERE  b.billid = @NewBillId) b
		WHERE  a.guid = b.GUID
		/*处理门店录入的电子监管码*/
		INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
 		SELECT b.billid, a.Sfda_Code, 1, b.GUID
 		FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 		           FROM   RetailBillidx_Sfda
 		           WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		       ) a
 		       INNER JOIN (
 		                SELECT b.billid, b.GUID, bb.p_id, bb.batchno, bb.validdate, bb.makedate, b.sin_id
 		                FROM   billidx b
 		                       INNER JOIN buymanagebill bb ON b.billid = bb.bill_id WHERE b.billid = @NewBillId
 		            ) b
 		            ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate
		
		DECLARE WriteSfdaList CURSOR  
	    FOR
			SELECT a.Sfda_Code, b.p_id, b.batchno, b.validdate, b.makedate, b.ss_id, b.y_id
 			FROM   (   SELECT Product_Id, BatchNo, ValidDate, MakeDate, Sfda_Code
 					   FROM   RetailBillidx_Sfda
 		               WHERE  Bill_Id = @BillId AND BillType = @BillType AND IsDraft = 1
 		           ) a
 		           INNER JOIN (
 		                    SELECT b.y_id, bb.bill_id, bb.p_id, bb.batchno, bb.validdate, bb.makedate, bb.ss_id
 		                    FROM billidx b INNER JOIN buymanagebill bb ON b.billid = bb.bill_id WHERE bb.bill_id = @NewBillId
 		                ) b
 		                ON  a.Product_Id = b.p_id AND a.BatchNo = b.batchno AND a.ValidDate = b.validdate AND a.MakeDate = b.makedate	
	    OPEN WriteSfdaList
	    FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId                                                                                                     
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        IF EXISTS(SELECT 1 FROM Sfda_List WHERE Sfda_Code = @SfdaCode)
				UPDATE Sfda_List 
					SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, 
					    S_Id = @SId, Y_Id = @YId, [Deleted] = 0
				WHERE Sfda_Code = @SfdaCode
			ELSE
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId, 0)	        
	        FETCH NEXT FROM WriteSfdaList INTO @SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, @YId
	    END
	    CLOSE WriteSfdaList
	    DEALLOCATE WriteSfdaList
	END
	UPDATE RetailBillidx_Sfda SET Bill_Id = @NewBillId, IsDraft = 0 
	WHERE Bill_Id = @BillId AND BillType = @Billtype AND IsDraft = 1
END
GO
