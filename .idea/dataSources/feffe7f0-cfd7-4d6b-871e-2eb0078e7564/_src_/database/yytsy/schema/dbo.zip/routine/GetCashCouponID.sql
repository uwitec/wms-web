
/*返回CashCoupon新的typeID*/
CREATE	FUNCTION [GetCashCouponID](@Typeid INT)
RETURNS int 	 
BEGIN 
	declare @nRet int
	if (@Typeid > 0) and  (exists(select 1 from Cashcoupon where TYPEid= @Typeid))
	  set @nRet = @Typeid 
    else 
      select @nRet = MAX(typeid)+1 from Cashcoupon
    if  @nRet is null
      set @nRet =1             	  					    	     	
	return @nRet
END
GO
