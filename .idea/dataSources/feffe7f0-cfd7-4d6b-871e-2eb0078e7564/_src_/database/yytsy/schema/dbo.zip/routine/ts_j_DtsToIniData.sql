
/*接收总部的期初数据， 与 ts_j_currtoIniData对应*/
create proc ts_j_DtsToIniData
/*with encryption*/
as
set nocount on

declare @Y_ID int, @nRet int
  exec ts_getsysvalue 'Y_ID', @Y_ID out
  if @Y_ID = 0 or @Y_ID is null
  begin
    set @nRet = -91      /*未设置分支机构*/
    goto PEnd
  end   
    
   delete accountbalanceDtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete ClientsbalanceDtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete CompanybalanceDtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete OtherStorehouseinidtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete storebrrowinidtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete storedxinidtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   delete storehouseinidtsIN where y_id not in (select company_id from company where superior_id = @Y_ID or company_id = @Y_ID)
   
begin tran ImportIniData
  truncate table accountbalance
  insert into accountbalance(y_id, a_id, ini_total) select y_id, a_id, ini_total from accountbalancedtsIN
  if @@ERROR<>0  goto Error
  
  truncate table clientsbalance
  insert into Clientsbalance(Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id) 
    select Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id from ClientsbalancedtsIN
  if @@ERROR<>0  goto Error
  
  truncate table companybalance
  insert into Companybalance(y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini)
    select y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini from CompanybalanceDtsIN    
  if @@ERROR<>0  goto Error 
  
  truncate table OtherStorehouseini
  insert into OtherStorehouseini(location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid)
    select location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid from OtherStorehouseinidtsIN
  if @@ERROR<>0  goto Error
  
  truncate table storebrrowini
  insert into storebrrowini(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storebrrowinidtsIN
  if @@ERROR<>0  goto Error
  
  truncate table storedxini
  insert into storedxini(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storedxinidtsIN
  if @@ERROR<>0  goto Error
  
  truncate table storehouseini
  insert into storehouseini(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID)
    select location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID from storehouseinidtsIN
  if @@ERROR<>0  goto Error

commit tran ImportIniData

set @nRet = 0
goto PEnd

Error:
    ROLLBACK TRANSACTION ImportIniData
	set @nRet = -1
	goto PEnd

PEnd:
  truncate table accountbalanceDtsIN
  truncate table ClientsbalanceDtsIN
  truncate table CompanybalanceDtsIN
  truncate table OtherStorehouseinidtsIN
  truncate table storebrrowinidtsIN
  truncate table storedxinidtsIN
  truncate table storehouseinidtsIN
  Return @nRet
GO
