
CREATE VIEW dbo.VW_H_LoadSP
AS
SELECT     p.product_id AS p_id, p.class_id AS pclass_id, p.name, '' AS standard, p.modal, '' AS makearea, '' AS Factory, '' AS BulidNo, '' AS RegisterNo, 
                      p.comment, '' AS permitcode, '' AS trademark, '' AS costmethod, 0 AS UNITRATE2, 0 AS UNITRATE3, 0 AS UNITRATE4, 0 AS validmonth, 0 AS validday, 
                      p.child_number, '' AS otcflag, p.alias, '' AS gspflag, '' AS PackStd, '' AS StorageCon, 0 AS OTCType, 0 AS r_id, ISNULL(pc.pc_name, '') AS PcName, 
                      ISNULL(pc.pc_code, '') AS pcCode, ISNULL(m.mt_name, '') AS medtype, ISNULL(m.mt_id, 0) AS medtype_id, ISNULL(u1.u_name, '') AS unit1, ISNULL(u2.u_name, '') AS unit2, 
                      ISNULL(u3.u_name, '') AS unit3, ISNULL(u4.u_name, '') AS unit4, p.unit_id AS unit1_id, 0 AS unit2_id, 0 AS unit3_id, 0 AS unit4_id, 
                      p.serial_number AS Code, '' AS Custompro1, '' AS Custompro2, '' AS Custompro3, '' AS Custompro4, '' AS Custompro5, p.InputDate, 
                      e.name AS Inputman, 0 AS Wholerate
FROM         dbo.SpecialProducts AS p INNER JOIN
                      dbo.employees AS e ON p.Emp_ID = e.emp_id LEFT OUTER JOIN
                      dbo.vw_b_medtype AS m ON 0 = m.mt_id LEFT OUTER JOIN
                      dbo.vw_b_unit AS u1 ON p.unit_id = u1.u_id LEFT OUTER JOIN
                      dbo.vw_b_unit AS u2 ON 0 = u2.u_id LEFT OUTER JOIN
                      dbo.vw_b_unit AS u3 ON 0 = u3.u_id LEFT OUTER JOIN
                      dbo.vw_b_unit AS u4 ON 0 = u4.u_id LEFT OUTER JOIN
                      dbo.PrintClass AS pc ON 0 = pc.pc_id
WHERE     (p.deleted <> 1)
GO
