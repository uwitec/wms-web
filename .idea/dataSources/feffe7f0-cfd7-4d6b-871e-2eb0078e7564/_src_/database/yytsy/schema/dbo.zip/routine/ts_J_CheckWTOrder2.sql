
CREATE	PROCEDURE [ts_J_CheckWTOrder2]
	(@WT_ID 	[int],
	 @P_ID	[int],
	 @billtype [int])

AS
  /*委托书过期后不能对选择的业务代表开订单 */
    declare @nType int, @wtNo varchar(100), @dtToday datetime  
      set @dtToday =CAST( cast(GETDATE() as varchar(10)) as datetime)
  
  if exists(select 1 from wtorder where WT_ID =  @wt_id and validDate < @dtToday)
  begin    
    return -11   
  end
      
  if @billtype = 22
    set @nType = 0
  else 
    set @nType = 1
 
  if exists(select 1 from wtorder where wt_id = @WT_ID and p_id =-1)   
  begin
    return 0     
  end
        
  if not exists(select 1 from wtdetail where wt_id = @WT_ID and p_id =@P_id)
  begin
    return -12
  end 
   
 return 0
GO
