CREATE PROCEDURE TS_ZH_LZstock
 @begindate datetime=0,
 @enddate datetime=0
AS
BEGIN
/*Params Ini begin*/
if @begindate is null  SET @begindate = 0
if @enddate is null  SET @enddate = 0
/*Params Ini end*/
/*
 当 SET NOCOUNT 为 ON 时，不返回计数。当 SET NOCOUNT 为 OFF 时，返回计数。
 即使当 SET NOCOUNT 为 ON 时，也更新 @@ROWCOUNT 函数。
 当 SET NOCOUNT 为 ON 时，将不向客户端发送存储过程中每个语句的 DONE_IN_PROC 消息。如果存储过程中包含一些并不返回许多实际数据的语句，网络通信流量便会大量减少，因此，将 SET NOCOUNT 设置为 ON 可显著提高性能
*/
SET NOCOUNT ON;
/*
select SaleRange2.name as sort,storages.name as storage,
case inorder when 1 then isnull(SUM(costtotal),0) when 2 then isnull(-SUM(costtotal),0) end as total
from products inner join SaleRange2 on SR2_id=id
inner join storehouse on product_id=p_id 
inner join storages on s_id=storage_id
where storehouse.instoretime between '2010-10-23' and '2010-10-23'
group by SaleRange2.name,storages.name,storehouse.inorder */
if object_id('tempdb..#tmp') is not null
 drop table #tmp
if object_id('tempdb..#all') is not null 
 drop table #all
/*--------------------------*/
select s.name as [仓库], sr.name as [类别], 
case when billtype in (20,222) then sum(sh.taxtotal)  when billtype in(21) then -sum(sh.taxtotal) end as [合计]
into #tmp
from billidx inner join  buymanagebill sh on billid=bill_id 
inner join products p on sh.p_id = p.product_id
inner join SaleRange2 sr on p.SR2_id = sr.id
inner join storages s on s.storage_id = sh.ss_id
where sh.instoretime between @begindate and @enddate
group by billtype, sr.name, s.name
order by s.name

create table #All ([仓库] varchar(200))
declare @totalSQL varchar(8000)
declare @store varchar(200)
declare @iFor int
declare @sql varchar(8000)
declare @talsql varchar(8000)
set @totalSQL = 'update #all set  '

if exists( select 1 from #tmp)
begin

declare curLst scroll cursor for
select distinct([类别]) from #tmp
open curLst
set @iFor = 0
fetch next from curLst into @store
while @iFor < @@CURSOR_ROWS
begin
	set @sql = 'alter table #all add [' + @store + '|采购入库金额] money default 0, [' 
		+ @store + '|采购退货金额] money default 0, ['
		+ @store + '|采购合计] money default 0'
		/*print @sql*/
	set @totalSQL = @totalSQL + '[' + @store + '|采购合计] = [' + @store + '|采购入库金额] + [' + @store + '|采购退货金额], '
	/*print (@totalSQL)*/
	exec(@sql)
	set @iFor = @iFor + 1
 fetch next from curLst into @store
end
close curlst
deallocate curLst
set @totalSQL = LEFT(@totalSQL, Len(@totalSQL) - 1)
/*print @totalSQL*/
declare curLst scroll cursor for
select * from #tmp
open curLst

declare @sort varchar(200)
declare @total money
declare @col varchar(200)

set @iFor = 0

while @iFor < @@CURSOR_ROWS
begin
	fetch next from curLst into @store, @sort, @total
	if @total < 0
		set @col = '[' + @sort + '|采购退货金额]'
	else
		set @col = '[' + @sort + '|采购入库金额]'
	set @sql = 'update #all set ' + @col + ' = ' + cast(@total as varchar(200)) + ' where [仓库] = ''' + @store + ''''
	/*print(@sql)*/
	exec(@sql)
	if @@ROWCOUNT <= 0
	begin
		set @sql = 'insert into #All([仓库], ' + @col + ') values(''' 
			+ @store + ''', ' + cast(@total as varchar(200)) + ')'
		/*print(@sql)*/
		exec(@sql)
	end
	
	set @iFor = @iFor + 1
end
close curlst
deallocate curLst

/*print @totalsql*/
exec(@totalSQL)
select * from #All

end
else
 select * from #tmp


if object_id('tempdb..#tmp') is not null
 drop table #tmp
if object_id('tempdb..#all') is not null 
 drop table #all

END
GO
