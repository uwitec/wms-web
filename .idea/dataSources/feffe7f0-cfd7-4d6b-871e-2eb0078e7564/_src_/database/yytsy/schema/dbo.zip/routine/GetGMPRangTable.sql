CREATE FUNCTION GetGMPRangTable()
RETURNS
     @GmpRange TABLE (
                            [R_id] int NOT NULL default(0),							
							[ranges] varchar(2000) NOT NULL default('')) 
AS  
begin
  
	declare @gid int
	declare @curGMPRang cursor
	set @curGMPRang = cursor for
		SELECT   g_id
		FROM   	GMPIndex 
  open @curGMPRang
	FETCH next from @curGMPRang into @gid  
	  while @@FETCH_STATUS = 0
	  begin
	    if @gid > 0
	    begin
			insert into @GmpRange([R_id],[ranges])
			values(@gid,dbo.GetGMPMedString(@gid))
		end
		fetch next from @curGMPRang into @gid    
	  end 
  close @curGMPRang
  deallocate @curGMPRang           
  RETURN             
end
GO
