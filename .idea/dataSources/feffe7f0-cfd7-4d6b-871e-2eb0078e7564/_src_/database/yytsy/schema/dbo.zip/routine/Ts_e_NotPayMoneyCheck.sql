create procedure Ts_e_NotPayMoneyCheck
   @BeginDate   varchar(100) ,   /*开始日期*/
   @EndDate     varchar(100),    /*结束日期*/
   @C_id        int             /*单位ID */
as
begin
   SELECT * FROM (
	SELECT mx.smb_id AS SMB_ID, vw.billid as bill_id,p.product_id as p_id,vw.billtype,Mx.factoryid,
	       vw.billdate,
	       isnull(p.Custompro1,'') as Custompro1,
	       isnull(p.Custompro2,'') as Custompro2,
	       isnull(p.Custompro3,'') as Custompro3,
	       isnull(p.Custompro4,'') as Custompro4,
	       isnull(p.Custompro5,'') as Custompro5,
	       isnull(k.name,'') as s_name,
	       mx.ss_id AS s_id,
	       y.name as yname,isnull(vw.billnumber,'') as billnumber,
	       isnull(p.alias,'') as alias, isnull(p.standard,'') as standard,mx.comment,
	       isnull(p.makearea,'') as P_MAKEAREA,
	       p.permitcode as P_PERMITCODE,
	       case when vw.billtype = 21 then -mx.quantity else mx.quantity end as quantity, mx.taxprice,
	       case when vw.billtype = 21 then -mx.taxtotal else mx.taxtotal end as taxtotal,
	       isnull(mx.batchno,'') as P_BATCHNO,mx.makedate,mx.validdate,isnull(f.AccountComment,'') as Factory
	FROM vw_c_billidx as vw 
	 left join buymanagebill Mx on vw.billid=mx.bill_id
	 left join products      P  on mx.p_id=p.product_id
	 left join storages      k  on mx.ss_id=k.storage_id
	 left join company       Y  on vw.Y_ID=y.company_id
	 left join basefactory   F  on mx.factoryid=f.CommID
	 WHERE  vw.billstates= 0 and vw.billtype in (20,21) and  
		  (vw.billdate>= @BeginDate) and (vw.billdate<=@EndDate) 
		  and vw.c_id = @C_id and (vw.jsflag='0' OR vw.jsflag= 'P') and vw.jsye<>0 
	      and vw.Y_id=2 and mx.smb_id not in (select BuyDetai_Id from PaymentBill )
	UNION ALL 
	SELECT mx.smb_id AS SMB_ID, vw.billid as bill_id,p.product_id as p_id,vw.billtype,Mx.factoryid,
	       vw.billdate,
	       isnull(p.Custompro1,'') as Custompro1,
	       isnull(p.Custompro2,'') as Custompro2,
	       isnull(p.Custompro3,'') as Custompro3,
	       isnull(p.Custompro4,'') as Custompro4,
	       isnull(p.Custompro5,'') as Custompro5,
           isnull(s.name,'') as s_name,
           Mx.ss_id as s_id,y.name as yname,isnull(vw.billnumber,'') as billnumber,
	       isnull(p.alias,'') as alias, isnull(p.standard,'') as standard,mx.comment,
	       isnull(p.makearea,'') as P_MAKEAREA,
	       p.permitcode as P_PERMITCODE,Mx.quantity,
	       cast(a.taxprice as NUMERIC(25,8)) as taxprice,
	       cast(a.taxtotal as NUMERIC(25,8)) as taxtotal,
	       isnull(mx.batchno,'') as P_BATCHNO,mx.makedate,mx.validdate,isnull(f.AccountComment,'') AS Factory
   FROM (
        SELECT distinct a.smb_id,isnull(a.taxprice-b.taxprice,0) AS taxprice,isnull(a.taxtotal+b.taxtotal,0) AS taxtotal FROM
          (SELECT smb_id,orgbillid,taxprice,taxtotal FROM buymanagebill a 
           LEFT JOIN billidx b ON a.bill_id = b.billid 
           WHERE b.billtype IN (24,25) AND a.iotag = 0 and b.billstates = 0) a
        LEFT JOIN 
          (SELECT smb_id,orgbillid,taxprice,taxtotal FROM buymanagebill a 
           LEFT JOIN billidx b ON a.bill_id = b.billid 
           WHERE b.billtype IN (24,25) AND a.iotag = 1 and b.billstates = 0) b
           ON a.orgbillid = b.orgbillid
        ) a
        LEFT JOIN buymanagebill Mx ON mx.smb_id = a.smb_id
        LEFT JOIN vw_c_billidx vw ON Mx.bill_id = vw.billid 
        LEFT JOIN products p ON Mx.p_id = p.product_id
        LEFT JOIN storages s ON Mx.ss_id = s.storage_id
        LEFT JOIN company  y  ON vw.Y_ID=y.company_id
        LEFT JOIN basefactory f ON mx.factoryid=f.CommID
        WHERE  vw.billstates= 0 and 
		(vw.billdate>= @BeginDate) and (vw.billdate<=@EndDate) 
		and vw.c_id = @C_id and (vw.jsflag='0' OR vw.jsflag= 'P') and vw.jsye<>0 
	    and vw.Y_id = 2 and mx.smb_id not in (select BuyDetai_Id from PaymentBill ) 
	    ) PayBill order by billdate	    
end
GO
