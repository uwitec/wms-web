
/* 功能：采购决策查询 商品级
  
*/

CREATE PROCEDURE TS_J_RepBuy03
( 
	@szbegindate varchar(12),   /*开始时间*/
	@szenddate   varchar(12),   /*结束时间*/
	@dateMode  int,		   /*1 月 2 季度 3 年*/
	@cg_id     int = 0,        /*选择类别组*/
	@szID      varchar(3000),  /*类别id*/
	@p_id      int = 0,			/*商品名称*/
	@s_id	   int = 0,			/*仓库*/
	@loc_id	   int = 0,			/*货位*/
	@e_id      int = 0,			/*经手人*/
	@c_id	   int = 0          /*往来单位(供应商)	*/
)

AS

/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @opendate  datetime    /*开账时间*/
   declare @cgClassid varchar(12)  /*类别组classid*/
   if @szID<>'' 
   begin 
       /*zjx.通过选择自定义类别id的字符串获取class_ID*/
	   select   class_id into #Categoryclassid from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
   end     
   if @szbegindate <> ''
     set @begindate = CAST((@szbegindate+ '-01') as datetime)
     
   if @szenddate <> ''
     set @enddate = CAST((@szenddate+ '-01') as datetime)      
   set @enddate = dateadd(mm,1,@enddate) 
   set @enddate = @enddate -1 
   
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @begindate
   if @begindate <  @OpenDate
     set @begindate = cast((cast(datepart(yyyy, @OpenDate) as varchar(4)) + '-' + cast(datepart(MM, @OpenDate) as varchar(2)) + '-' + '01') as datetime)

/*创建日期分段表，标识，时间跨度*/
/*创建需要查询的商品表，关联了类别组的商品*/
/*创建新品表*/
/*创建返回信息表*/
/*创建表根据类别组取的各级类别名*/
/*计算返回值*/



if OBJECT_ID('tempdb..#SplitDate' ) is not null 
  drop table #SplitDate
create table #splitDate
			 ( dateid int IDENTITY,   /*分隔日期后标识*/
			   FlagName varchar(50),  /*分隔后标识名称，例按年 2013 按月201306 按季度2013二季度*/
			   yyyy     varchar(10),  /*所属于年 */
			   qqq		varchar(10),  /*所属季度			   */
			   mm		varchar(10),  /*所属月			   			   	     */
			   begindate datetime,    /*本段分隔的开始时间*/
			   enddate   datetime,    /*本段分隔的结束时间*/
			   daycount  int		  /*本段分隔的天数统计	  */
			  )  
			  
if OBJECT_ID('tempdb..#QrProducts' ) is not null 
  drop table #QrProducts
create table #QrProducts
 			( p_id int, 			  
 			  billid int,
 			  billtype int,
 			  billdate datetime,
 			  quantity NUMERIC(25,8),
 			  taxprice NUMERIC(25,8),
 			  total    NUMERIC(25,8),
 			  retailTotal NUMERIC(25,8) 			   			   			   			 
 			 )  
			  			  
			  
if OBJECT_ID('tempdb..#NewProducts' ) is not null 
  drop table #NewProducts
create table #NewProducts
			 ( dateid int,
			   p_id int,
			   cg_id int,			   
			   BuyDate datetime, 
			   preDate datetime,
			   DayCount int			   			  			   		  
			  )  			  
    
if OBJECT_ID('tempdb..#qrbuy01' ) is not null 
  drop table #qrbuy01
create table #qrbuy01
             ( dateid int,
               p_id  int,            /*商品id                                          */
               buyQty NUMERIC(25,8),		 /*采购数量*/
               buyPrice NUMERIC(25,8),       /*采购均价*/
               buytotal NUMERIC(25,8),		 /*采购金额	*/
               BackQty NUMERIC(25,8),        /*退货数量 not show*/
               BackTotal NUMERIC(25,8),      /*退货金额 not show */
               RetailTotal NUMERIC(25,8),    /*预估零售金额*/
               PlanRate NUMERIC(25,8),		 /*计划完成率*/
               orderRate NUMERIC(25,8),		 /*采购合同履约率*/
               backRate NUMERIC(25,8),		 /*退货发生率*/
               buyUpRate NUMERIC(25,8),		 /*采购增长率	*/
               profferRate NUMERIC(25,8),    /*预估贡献率 */
               plancomeQty NUMERIC(25,8),    /*计划完成数量   */
               planQty     NUMERIC(25,8),    /*计划数量*/
               orderComeQty NUMERIC(25,8),   /*合同完成数量*/
               orderQty     NUMERIC(25,8),    /*合同数量*/
               beginQty     NUMERIC(25,8),    /*期初余量*/
               OverQty      NUMERIC(25,8)     /*期未余量                                                                                                   */
              )
               
if OBJECT_ID('tempdb..#qrcustomGory' ) is not null 
  drop table #qrcustomGory
create table #qrcustomGory
		   ( cg_id int,
			 p_id int,
		     c1name varchar(80),
		     c2name varchar(80),
		     c3name varchar(80),
		     c1class_id varchar(12),
		     c2class_id varchar(12),
		     c3class_id varchar(12),
		     c1id int,
		     c2id int,
		     c3id int		     		    		     		   
		   )	               

declare @nMinDateid int, @nMaxDateid int, @splitBegindate datetime,  @splitEnddate datetime, @nDateid int
declare @const_newDay int /*新品计算时间，定义为100天*/
set @const_newDay = 100

/*初始化#QrProducts*/
insert into #QrProducts(p_id, billid, billtype, billdate, quantity, taxprice, total, retailTotal) 	 
   select mx.p_id, mx.bill_id, bi.billtype, bi.billdate, mx.quantity, mx.taxprice, mx.taxtotal, mx.retailtotal
     from billidx  bi
     inner join buymanagebill mx on bi.billid = mx.bill_id
     where  (@p_id = 0 or mx.p_id = @p_id) and
	        (@s_id = 0 or mx.ss_id = @s_id) and
	        (@loc_id = 0 or mx.location_id = @loc_id) and
	        (@e_id = 0 or bi.e_id = @e_id) and
	        (@c_id = 0 or bi.c_id = @c_id) and
	        bi.billtype in (20, 21) and
	        bi.billstates = 0 and mx.AOID = 0 and
	        mx.p_id > 0
                    
if @dateMode = 1 goto repMonth    /*按月查询*/
if @dateMode = 2 goto repquarter  /*按季度查询*/
if @dateMode = 3 goto repYear     /*按年查询*/

repMonth:
/*取月begindate*/

set @begindate = DATEADD(MM, -1, @begindate)

insert into #SplitDate(begindate)
   select    
     dateadd(mm,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(mm,number,@begindate)<=@enddate
/*计算其他时间列     */
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+cast(DATEPART(MM, begindate) as varchar(2))+'月',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = DATEPART(MM, begindate)
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1
                        								                    
  goto  rep


repquarter:
/*取季度begindate*/
set @begindate = DATEADD(QQ, -1, @begindate) /*需要计算到选择时间段的上一期*/

insert into #SplitDate(begindate)
   select    
     dateadd(QQ,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(QQ,number,@begindate)<=@enddate
/*计算其他时间列*/
	update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+ cast(DATEPART(QQ, begindate) as varchar(2))+'季度',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = 0	
	update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
	select @nMaxDateid = MAX(dateid) from #splitDate
    update #splitDate set enddate = @enddate where dateid = @nMaxDateid
    update #splitDate set daycount = cast((enddate - begindate) as Int)+1 	
            							
    goto rep

repYear:
  /*取年begindate*/

set @begindate = DATEADD(YYYY, -1, @begindate) /*需要计算到选择时间段的上一期*/
  
insert into #SplitDate(begindate)
   select    
     dateadd(YYYY,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(YYYY,number,@begindate)<=@enddate
/*计算其他时间列*/
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年',
						yyyy = DATEPART(YYYY, begindate), qqq = 0, mm=0	
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1										
  
  goto Rep
  
  
rep:
    /*初始化#qrbuy01表*/
  insert into #qrbuy01(dateid, p_id)
     select sp.dateid, mx.p_Id  
      from #splitDate sp
      cross join (select distinct p_id as p_Id from #QrProducts) mx
      order by sp.dateid, mx.p_Id
                 
  /*采购数量	采购数量   --采购金额	采购金额   --退货总数量  --退货金额*/
          
  update b01 set b01.buyQty = t1.buyQty, b01.buytotal = t1.buytotal, 
				 b01.BackQty = t1.backQty, b01.BackTotal = t1.backTotal      
    from  #qrbuy01 b01,  
         (		           
		    select sp.dateid, p.p_id,  
							 sum(case p.billtype when 20 then p.quantity else 0 end) as buyQty, 
							 sum(case p.billtype when 20 then p.total else 0  end) as buytotal,
							 sum(case p.billtype when 21 then p.quantity else 0 end) as backQty, 
							 sum(case p.billtype when 21 then p.total else 0  end) as backTotal,
							 sum(case p.billtype when 20 then p.retailTotal else -p.retailTotal  end) as retailtotal							 							                         
			   from #QrProducts  p 
			   left join #splitDate  sp on p.billdate between sp.begindate and sp.enddate			    					
			   group by sp.dateid, p.p_id
			   			                   
         ) t1
    where b01.dateid = t1.dateid and b01.p_id = t1.p_id  
    
       			 
/*采购计划完成率	采购合同数量/采购总数量  --采购合同履约率  	采购总数量/采购合同总数量*/
  update b01 set b01.plancomeQty = t1.plancomeqty, b01.planQty = t1.planQty, 
				 b01.orderComeQty = t1.orderComeQty, b01.orderQty = t1.orderQty      
    from  #qrbuy01 b01,  
         (
          select sp.dateid, p.p_id,
				     sum(case bi.billtype when 26 then mx.ComeQty else 0 end) as plancomeqty, 
					 sum(case bi.billtype when 26 then mx.quantity else 0 end) as planQty,
					 sum(case bi.billtype when 22 then mx.ComeQty else 0 end) as orderComeQty, 
					 sum(case bi.billtype when 26 then mx.quantity else 0 end) as orderQty					                                                               
		   from #splitDate sp            
		   left join  Orderidx bi on bi.billdate between sp.begindate and sp.enddate
		   inner join orderbill mx  on mx.bill_id= bi.billid
		   inner join (select distinct p_id from #qrproducts) p on mx.p_id = p.p_id
		   where bi.billtype in (22, 26) and bi.billstates = 3 and bi.billdate between @begindate and @enddate 
		   group by sp.dateid, p.p_id      
         ) t1
    where b01.dateid = t1.dateid and b01.p_id = t1.p_id 
   
   /*清除null 避免计算出错*/
   update #qrbuy01 set planQty = 0			where planQty is null
   update #qrbuy01 set plancomeQty =  0		where plancomeQty is null
   update #qrbuy01 set orderComeQty = 0		where orderComeQty is null	
   update #qrbuy01 set orderQty =0			where orderQty is null
   update #qrbuy01 set buyQty = 0			where buyQty is null
   update #qrbuy01 set buytotal = 0			where buytotal is null
   update #qrbuy01 set BackQty = 0			where BackQty is null
   update #qrbuy01 set BackTotal = 0		where BackTotal is null
					   					          
   update #qrbuy01 set PlanRate = plancomeQty/planQty*100 where planQty <> 0
   update #qrbuy01 set orderRate = orderComeQty/orderQty*100 where orderQty <> 0
   
/*采购均价*/
   update #qrbuy01 set buyPrice = buytotal/buyQty where buyQty <> 0         
     
/*采购退货发生率	退货总数量/采购总数量 分母为0返回空     */
   update #qrbuy01 set backRate = BackQty/buyQty*100 where buyQty <> 0     
/*采购增长率	(本期采购额-上期采购额)/上期采购额*/
   update q1 set buyUpRate = (q1.buytotal-q2.buytotal)/q2.buytotal*100  
     from #qrbuy01 q1, #qrbuy01 q2   
     where q1.dateid = q2.dateid + 1 and q2.buytotal <> 0 
     
 /*预估贡献率    */
   update #qrbuy01 set profferRate = RetailTotal/(buytotal- BackTotal)*100  where (buytotal- BackTotal) <> 0
   
   goto repend  
  
  
repend:
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int      
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'       
   
   select @cgClassid = class_id from customCategory where  id = @cg_id

    DECLARE @PColName VARCHAR(100)
    SET @PColName = ''
    CREATE TABLE #TmpP (
    [class_id] [varchar](100) NOT NULL DEFAULT(''),    
    [baseinfo_id] [int] NOT NULL DEFAULT(0),
    [id] [int]  NOT NULL DEFAULT(0),
    [name] [varchar](200) NOT NULL DEFAULT('')
    )
    IF @cg_id = 0
    begin
      INSERT INTO #TmpP(class_id,baseinfo_id,id,name) 
      SELECT '',product_id,0,'' FROM products WHERE deleted = 0 AND class_id <> '000000' 
    end
    ELSE
    BEGIN   
      DECLARE @Pinfo_ID INT
      DECLARE @PszSql varchar(2000)
      SELECT @Pinfo_ID = Category_id FROM customCategory WHERE class_id  = @cgClassid    
      SET @PColName = dbo.GetColName(@Pinfo_ID,'ProductCategory')
      SET @PszSql = ' INSERT INTO #TmpP(class_id,baseinfo_id,id,name) '
                + ' select isnull(cc.class_id,''''),p.product_id as baseinfo_id,isnull(cc.id,0),isnull(cc.name,'''') from products p ' 
                + ' left join ProductCategory pc on p.product_id = pc.P_id '
                + ' left join customCategory cc on pc.' + @PColName + ' = cc.class_id where ' + @PColName + ' in (select class_id from #Categoryclassid)'
	  EXEC (@PszSql)      
    END
   
   insert into #qrcustomGory(cg_id, p_id, c1name, c2name, c3name, c1id, c2id, c3id, c1class_id, c2class_id, c3class_id)   
   select cg.id, cm.baseinfo_id, isnull(c1.name, ''), isnull(c2.name, ''), isnull(c3.name, ''),
          isnull(c1.id, 0), isnull(c2.id, 0), isnull(c3.id, 0),
          isnull(c1.class_id, ''), isnull(c2.class_id, ''), isnull(c3.class_id, '')             
     from #TmpP cm
     inner join customCategory cg on cm.class_id = cg.class_id
     left join  customCategory c1 on LEFT(cg.class_id, 4) = c1.class_id and LEN(c1.class_id) =4
     left join  customCategory c2 on LEFT(cg.class_id, 6) = c2.class_id and LEN(c2.class_id) =6
     left join  customCategory c3 on LEFT(cg.class_id, 8) = c3.class_id and LEN(c3.class_id) =8 
     where cg.baseType =0 and left(cg.class_id, 2) = @cgClassid and 
		   cg.id in (select CAST(szTYPE as Int) from dbo.DecodeToStr(@szID))
      

   select @nMinDateid = MIN(dateid)  from #SplitDate
   select 
		  /*b.dateid,*/
		  b.p_id,  
		  dbo.DecimalQrValue(@nSL,b.buyQty) buyQty,
		  dbo.DecimalQrValue(@nDJ,b.buyPrice) buyPrice, 
		  dbo.DecimalQrValue(@nTotal,b.buytotal) buytotal,
		  /*dbo.DecimalQrValue(@nSL,b.BackQty) BackQty,*/
		  /*dbo.DecimalQrValue(@nTotal,b.BackTotal) BackTotal,*/
		  /*dbo.DecimalQrValue(@nTotal,b.RetailTotal) RetailTotal, */
		  dbo.DecimalQrValue(@nOther,b.PlanRate) PlanRate,
		  dbo.DecimalQrValue(@nOther,b.orderRate) orderRate,
		  dbo.DecimalQrValue(@nOther,b.backRate) backRate,
		  dbo.DecimalQrValue(@nOther,b.buyUpRate) buyUpRate,
		  dbo.DecimalQrValue(@nOther,b.profferRate) profferRate, 
		  /*dbo.DecimalQrValue(@nSL,b.plancomeQty) plancomeQty, */
		  /*dbo.DecimalQrValue(@nSL,b.planQty) planQty,     */
		  /*dbo.DecimalQrValue(@nSL,b.orderComeQty) orderComeQty,*/
		  /*dbo.DecimalQrValue(@nSL,b.orderQty) orderQty,    */
		  /*dbo.DecimalQrValue(@nSL,b.beginQty) beginQty,    */
		  dbo.DecimalQrValue(@nSL,b.OverQty) OverQty,     			                                                                       
		  sd.FlagName, cg.c1name, cg.c2name, cg.c3name
		   /*sd.yyyy, sd.qqq, sd.mm, sd.begindate, sd.enddate, sd.daycount,*/
          /*p.Code, p.Name, p.Standard, p.MakeArea, p.Factory, p.MedType, p.medname, p.Unit1Name, p.Inputdate,*/
          /*p.StorageCon, p.C_Name, p.E_Name, p.packstd,cg.cg_id, */
          
         /* cg.c1id, cg.c2id, cg.c3id, cg.c1class_id, cg.c2class_id, cg.c3class_id*/
     from  #qrbuy01 b 
     inner join  #qrcustomGory cg on b.p_id = cg.p_id                
     left join #SplitDate sd on b.dateid = sd.dateid  
     left join  FilterProduct(2) p on b.p_id = p.Product_ID   
     where sd.dateid >  @nMinDateid            
     
   return 0
GO
