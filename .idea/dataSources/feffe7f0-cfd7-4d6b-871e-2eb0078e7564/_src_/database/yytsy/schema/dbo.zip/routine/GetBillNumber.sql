


create  FUNCTION GetBillNumber(@billtype int)  
RETURNS  varchar(800) 
AS  
BEGIN 
 declare @szbillnumber varchar(800)
  select @szbillnumber=
  case @billtype
  when 10 then 'XS'  /*销售单*/
  when 11 then 'XT'  /*销售退货单*/
  when 12 then 'LS'  /*零售单*/
  when 13 then 'LT'  /*零售退货单*/
  when 14 then 'XO'  /*销售定单*/
  when 15 then 'SK'  /*收款单*/
  when 16 then 'XJ'  /*销售结算调价*/
  when 17 then 'XJ'  /*销售退货结算调价*/
  when 20 then 'CG'  /*采购单*/
  when 21 then 'CT'  /*采购退货单*/
  when 22 then 'CO'  /*采购定单*/
  when 23 then 'FK'  /*付款单*/
  when 24 then 'CJ'  /*采购结算调价*/
  when 25 then 'CJ'  /*采购退货结算调价*/
  when 26 then 'CP'  /*采购计划*/
  when 30 then 'BO'  /*借出单*/
  when 31 then 'BT'  /*借出还回单*/
  when 32 then 'BS'  /*借出转销售单*/
  when 33 then 'LI'  /*借进单*/
  when 34 then 'LT'  /*借进还出单*/
  when 35 then 'LC'  /*借进转采购单*/
  when 40 then 'PA'   /*组装单*/
  when 41 then 'BL'   /*报损单*/
  when 42 then 'BG'   /*报溢单*/
  when 43 then 'TJ'   /*成本调价单*/
  when 44 then 'TB'   /*调拨单*/
  when 45 then 'BB'   /*变价调拨单*/
  when 46 then 'ZS'   /*赠送单*/
  when 47 then 'HZ'   /*获赠单*/
  when 48 then 'RK'   /*入库单*/
  when 49 then 'CK'   /*出库单*/
  when 50 then 'PD'   /*库存盘点单*/
  when 51 then 'BA'   /*库存批次调整单*/
  when 52 then 'MQ'   /*门店请货单*/
  when 53 then 'TO'   /*配送出库单*/
  when 54 then 'TT'   /*配送出库退货单*/
  when 55 then 'PR'   /*配送入库单*/
  when 56 then 'PT'   /*配送入库退货单*/
  when 57 then 'XS'   /*门店请货缺货单O*/
  when 58 then 'DP'   /*动态盘点单*/
  when 60 then 'XJ'   /*现金费用单*/
  when 61 then 'FY'   /*费用单*/
  when 62 then 'QR'   /*其它收入单*/
  when 63 then 'XZ'   /*现金转帐单*/
  when 64 then 'SZ'   /*应收增加*/
  when 65 then 'SJ'   /*应收减少*/
  when 66 then 'FZ'   /*应付增加*/
  when 67 then 'FJ'   /*应付减少*/
  when 68 then 'ZZ'   /*资金增加*/
  when 69 then 'ZJ'   /*资金减少*/
  when 80 then 'GG'   /*固定资产购置*/
  when 81 then 'GS'   /*固定资产变卖*/
  when 82 then 'GZ'   /*固定资产折旧*/
  when 83 then 'DF'   /*待摊费用发生*/
  when 84 then 'DT'   /*待摊费用摊销*/
  when 87 then 'PFK'   /*配送付款单*/
  when 88 then 'PSK'   /*配送收款单*/
  when 90 then  'PZ'   /*会计凭证*/
  when 100 then 'FH'  /*发货单*/
  when 101 then 'FT'  /*发货退货单*/
  when 102 then 'FJ'  /*发货结算单*/
  when 103 then 'FA'  /*发货调价单*/
  when 110 then 'WO'  /*委托代销单*/
  when 111 then 'WT'  /*委托代销退货单*/
  when 112 then 'WJ'  /*委托代销结算单*/
  when 113 then 'WA'  /*委托代销调价*/
  when 120 then 'SO'  /*受托代销单*/
  when 121 then 'ST'  /*受托代销退货单*/
  when 122 then 'SJ'  /*受托代销结算单*/
  when 123 then 'SA'  /*受托代销调价*/
  when 130 then 'SI'  /*库外入库单*/
  when 131 then 'SO'  /*库外出库单*/
  when 140 then 'AP'  /*价格调整单*/
  when 141 then 'IP'  /*期初库存录入单*/
  end 
 return(@szbillnumber)
END
GO
