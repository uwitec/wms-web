


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
批次选择--整零库

********************************************/
CREATE  PROCEDURE  TS_Z_QrWholeBatch
( @nP_id      	int,
  @nWholeFlag   int,
  @nY_ID		int,
  @nloginEID    int=0,
  @nS_ID        int=0
)   
/*with encryptiON      */
AS
/*Params Ini begin*/
if @nloginEID is null  SET @nloginEID = 0
if @nS_ID is null  SET @nS_ID = 0
/*Params Ini end*/
SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000)
  declare @SQLOrder varchar(1000)
  declare @SQLWholeFlag varchar(500)
  declare @filtstr varchar(500)
  declare @filtSID varchar(100)
  Declare @Companytable INTEGER,@Storetable integer

  declare @BatchOrder char(1)
	set @BatchOrder='0'
	select @BatchOrder=sysvalue from sysconfig where upper([sysname])='BATCHORDER'/*批次排序方式*/
	
/*本机构ID*/
  
  if @BatchOrder='0' 
    select @SqlOrder = ' order by s.validdate, s.makedate'
  else if @BatchOrder='1'
    select @SqlOrder = ' order by s.InstoreTime,s.inorder, s.makedate'
  else if @BatchOrder='2'
    select @SqlOrder = ' order by s.validdate,s.InstoreTime,s.inorder, s.makedate'
  else if @BatchOrder='3'
    select @SqlOrder = ' order by s.InstoreTime,s.inorder,s.validdate, s.makedate'      
    
  set @filtSID = ' '
  if @nWholeFlag<>0 select @SqlWholeFlag = ' and st.WholeFlag='+cast(@nWholeFlag as Varchar(10))
  else begin    
    select @SqlWholeFlag=' '
    if @nS_ID <> 0 set @filtSID = ' and s.s_id ='+cast(@nS_ID as Varchar(10))
    else set @filtSID = ' '
  end
  
  select @filtstr=''
  create table #Companytable([id] int)
  create table #storagestable([id] int)
  
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      select @filtstr=@filtstr+' AND (s.Y_id in (select [id] from #Companytable))'
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      select @filtstr=@filtstr+' AND (s.s_id in (select [id] from #storagestable))'
   end
/*---仓库授权*/

/*--启用仓库管理流程后将生成的同价调拨草稿计入可开数量中 add by luowei 2012-12-12*/
/*---使用同价调拨单虚拟出一个批次*/
if not exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = 1)
begin
  select @SqlScript='
  	SELECT s.storehouse_id AS batchid,s.quantity,ISNULL(o.quantity,0) as salequantity,s.costtotal,
        s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,s.stopsaleflag,s.supplier_id,s.location_id,s.y_id,
        ISNULL(c.[name],'''') as suppliername,ISNULL(l.loc_name,'''') as locname,s.instoretime,s.s_id as s_id,
        isnull(f.AccountComment,'''') as  Factory,p.comment,s.factoryid as factoryid,
        s.s_id,st.Name as sName
	,(CASE WHEN  not (FB.BatchNo is null) THEN ''禁销'' ELSE '''' END) FBTag,ISNULL(FB.fbType ,-1)fbType,
	o.batchbarcode,o.scomment,o.batchprice,0 as billid, s.costtaxprice, s.costtaxtotal, s.taxrate * 100 AS taxrate
			 FROM Storehouse s 
				LEFT JOIN 
				clients c ON s.supplier_id=c.client_id 
				LEFT JOIN locatiON l ON s.location_id=l.loc_id 
				LEFT JOIN Storages st ON s.s_id=st.storage_id	
				LEFT JOIN basefactory f on s.factoryid=f.CommID			
				LEFT JOIN dbo.FN_GetAvlqty('+cast(@nP_id as varchar(10))+',0,'''',0) o
				ON o.p_id=s.p_id and o.s_id=s.s_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate 
        AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime = s.instoretime and o.makedate=s.makedate and o.costtaxprice=s.costtaxprice
        and o.factoryid=s.factoryid and o.costtaxrate=s.taxrate
        LEFT JOIN 
        products p ON s.P_ID=p.product_ID
	LEFT JOIN ForbiddenBatch FB 
		ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				WHERE s.stopsaleflag=0 and s.p_id='+cast(@nP_id as varchar(10))
                                  + '  and s.Y_ID=' + cast(@nY_ID as varchar(50))
                                  +@filtstr+ @SqlWholeFlag + @filtSID + @SqlOrder 
end                                  
else
begin
declare @where varchar(1000)
declare @nflag int
if @nWholeFlag = 1
begin
  set @where = ''
  set @nflag = 0 
end
if @nWholeFlag = 2  /*零货库时有库存的商品显示合并后的商品批次,没有库存的商品批次显示根据同价调拨单虚拟出的批次*/
begin
set @where = ' and ((s.saleqty <> 0 and nowqty = 0) or (s.quantity <> 0 and s.saleqty <> 0)or (s.quantity <> 0 and s.saleqty = 0 and s.nowqty = 0 ) or (s.quantity = 0 and s.costtotal = 0))  '
set @nflag = 1
end
select @SqlScript='
  	SELECT s.storehouse_id AS batchid,s.quantity,(s.quantity+ISNULL(o.quantity,0)+isnull(saleqty,0)) as salequantity,s.costtotal,
        s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,s.stopsaleflag,s.supplier_id,s.location_id,s.y_id,
        ISNULL(c.[name],'''') as suppliername,ISNULL(l.loc_name,'''') as locname,s.instoretime,s.s_id as s_id,p.Factory,p.comment,
        s.s_id,st.Name as sName
	,(CASE WHEN  not (FB.BatchNo is null) THEN ''禁销'' ELSE '''' END) FBTag,ISNULL(FB.fbType ,-1)fbType,
	batchbarcode,scomment,batchprice,billid, s.costtaxprice, s.costtaxtotal, s.taxrate * 100 AS taxrate 
			 FROM 
			 (
			   select storehouse_id,S.location_id,S.s_id,S.p_id,S.supplier_id,S.quantity,isnull(MX.quantity,0) as saleqty,0 as nowqty,S.costprice,costtotal,S.batchno,S.makedate,S.instoretime,
			   S.validdate,S.commissionflag,stopsaleflag,S.Y_ID,BatchBarCode,scomment,batchprice,inorder,0 as billid from storehouse s
	            left join 
	            (
	              select p_id,location_id2 as location_id,sd_id as s_id,supplier_id,costprice,batchno,makedate,instoretime,validdate,commissionflag,Y_ID
	              ,SUM(quantity) as quantity from storemanagebilldrf where exists(select 1 from billdraftidx idx where idx.billid = bill_id and billtype = 44)
	              and ( '+CAST(@nWholeFlag  as varchar)+' = 1 or comment <> ''自动拆零'')
	              group by p_id,location_id2,sd_id,supplier_id,costprice,batchno,makedate,
	              instoretime,validdate,commissionflag,Y_ID
	            ) MX  on mx.p_id = s.p_id and mx.location_id = s.location_id and mx.s_id = s.s_id and mx.supplier_id = s.supplier_id
	      	    and mx.costprice = s.costprice and mx.batchno = s.batchno and mx.makedate = s.makedate and mx.instoretime = s.instoretime and mx.validdate = s.validdate and
	      	    mx.commissionflag = s.commissionflag and mx.Y_ID = s.Y_ID
	            union all
	            select  -99 as storehouse_id,location_id2 as location_id,sd_id as s_id,mx.p_id,mx.supplier_id,0 as quantity,sum(mx.quantity) as saleqty,sum(isnull(s.quantity,0)) as nowqty,mx.costprice,
	      	    0 as costtotal,mx.batchno,mx.makedate,mx.instoretime,mx.validdate,mx.commissionflag,0 as stopsaleflag,mx.y_id,
	      	    '''' as batchbarcode,''由同价调拨草稿生成'' as scomment,0 as batchprice,99999999 as inorder,0 as billid
	      	    from storemanagebilldrf mx 
	      	    left join storehouse s on mx.p_id = s.p_id and mx.location_id2 = s.location_id and mx.sd_id = s.s_id and mx.supplier_id = s.supplier_id
	      	    and mx.costprice = s.costprice and mx.batchno = s.batchno and mx.makedate = s.makedate and mx.instoretime = s.instoretime and mx.validdate = s.validdate and
	      	    mx.commissionflag = s.commissionflag and mx.Y_ID = s.Y_ID 
	      	    where exists(select 1 from billdraftidx idx where idx.billid = mx.bill_id and billtype = 44)
	      	    group by location_id2,sd_id,mx.p_id,mx.supplier_id,mx.costprice,mx.batchno,mx.makedate,mx.instoretime,mx.validdate,mx.commissionflag,mx.y_id 
			 ) s 
				LEFT JOIN 
				clients c ON s.supplier_id=c.client_id 
				LEFT JOIN locatiON l ON s.location_id=l.loc_id 
				LEFT JOIN Storages st ON s.s_id=st.storage_id				
				LEFT JOIN OutBatchByP_Fliter('+cast(@nP_id as varchar(10))+','+CAST(@nflag  as varchar)+') o
				ON o.p_id=s.p_id and o.s_id=s.s_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate 
        AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime = s.instoretime 
        LEFT JOIN 
        products p ON s.P_ID=p.product_ID
	LEFT JOIN ForbiddenBatch FB 
		ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
		WHERE 
		s.stopsaleflag=0 and s.p_id='+cast(@nP_id as varchar(10))
                                  + '  and s.Y_ID=' + cast(@nY_ID as varchar(50))
                                  +@filtstr+ @SqlWholeFlag + @filtSID + @where + @SqlOrder                            
end


  PRINT @SQLScript
  EXEC(@SQLScript)
  
  drop table #Companytable
  drop table #storagestable
	RETURN 0
GO
