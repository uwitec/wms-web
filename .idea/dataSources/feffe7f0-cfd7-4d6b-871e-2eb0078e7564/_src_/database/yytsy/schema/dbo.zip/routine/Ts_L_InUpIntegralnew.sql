Create  procedure Ts_L_InUpIntegralnew
( 
  @I_id         [int],
  @IntegralMoney  [numeric](18, 2), 
  @Integralmode   [int],
  @memberbl       [numeric](18, 2),
  @birthdaybl     [numeric](18, 2),
  @Specialbl      [numeric](18, 2),
  @discountbl     [numeric](18, 2),
  @daymode        [int],
  @dmstr          [varchar](200), 
  @cidstr         [varchar](1000) ,
  @cnamestr       [varchar](5000) ,
  @cardidstr      [varchar](1000) ,
  @cardnamestr    [varchar](1000),
  @validmonth     [int] ,
  @casevalid      [int],
  @ismoneyup      [int],
  @moneyup        [numeric](18, 2),
  @moneyupC_id    [int],
  @moneyupC_name  [varchar](100),  
  @isIntegralup   [int],
  @Integralup     [int],
  @IntegralupC_id [int],
  @IntegralupC_name [varchar](100), 
  @Integralupkc   [int],  
  @isautoup       [varchar](100), 
  @remake         [varchar](200),
  @BackIntNeedMoney [numeric](18, 2)
 )  
AS
declare    @newP_id  int
/*取得ID号*/
if @I_id=0
begin     
   insert into VipCardTypeExtend
	( 
	[IntegralMoney],
	[Integralmode],
	[memberbl],
	[birthdaybl],
	[Specialbl],	
	[discountbl],
	[daymode],
	[dmstr],
	[cidstr],
	[cnamestr],
	[cardidstr],
	[cardnamestr],
	[validmonth],
	[casevalid],  
	[ismoneyup], 
	[moneyup],   
	[moneyupC_id],   
	[moneyupC_name],   
	[isIntegralup], 
	[Integralup],   
	[IntegralupC_id],   
	[IntegralupC_name], 
	[Integralupkc], 
	[isautoup],    
	[remake],
	[BackIntNeedMoney]
	)						
	Values(	
     @IntegralMoney, 
     @Integralmode,
     @memberbl,
     @birthdaybl,
     @Specialbl,
     @discountbl,
     @daymode,
     @dmstr, 
     @cidstr,
     @cnamestr,
     @cardidstr,
     @cardnamestr,
     @validmonth,	
     @casevalid,      
     @ismoneyup,
     @moneyup,
     @moneyupC_id,
     @moneyupC_name,  
     @isIntegralup,
     @Integralup,
     @IntegralupC_id,
     @IntegralupC_name,
     @Integralupkc, 
     @isautoup,
     @remake,
     @BackIntNeedMoney			    	    
		   )									

	if @@rowCount=0 
	begin
	 return -1
	end else 
	begin
	 select @newP_id= @@IDENTITY
	 return @newP_id 
    end
end 
else
begin
   UPDATE VipCardTypeExtend
	SET  		
	[IntegralMoney]=@IntegralMoney,
	[Integralmode]=@Integralmode,
	[memberbl]=@memberbl,
	[birthdaybl]=@birthdaybl,
	[Specialbl]=@Specialbl,	
	[discountbl]=@discountbl,
	[daymode]=@daymode,
	[dmstr]=@dmstr,
	[cidstr]=@cidstr,
	[cnamestr]=@cnamestr,
	[cardidstr]=@cardidstr,
	[cardnamestr]=@cardnamestr,
	[validmonth]=@validmonth,
    [casevalid]=@casevalid,  
    [ismoneyup] =@ismoneyup,    
    [moneyup]=@moneyup,       
    [moneyupC_id]=@moneyupC_id,   
    [moneyupC_name]=@moneyupC_name,  
    [isIntegralup]=@isIntegralup,  
    [Integralup]=@Integralup,  
    [IntegralupC_id]=@IntegralupC_id,
    [IntegralupC_name]=@IntegralupC_name,
    [Integralupkc]=@Integralupkc,  
    [isautoup]=@isautoup,   
    [remake]=@remake,
    [BackIntNeedMoney]=@BackIntNeedMoney
  WHERE I_id =@I_id
	
  /*return @CG_id*/
  
end
GO
