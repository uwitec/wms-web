/************************************************************
--过程名称：ts_T_InsorupdateSendIDX
--功能：添加和修改物流配送单的主表
--创建人：LUO XIAOTIAN 
--创建时间：2010-12-09  
--最后修改:


参数说明：
		   

备注：@nMode 1:为添加 2:为修改
**************************************************************/
Create procedure [dbo].[ts_T_InsorupdateSendIDX]
( @Send_id  int=0,
  @serial_number  varchar(30),/*编号*/
  @billDate       datetime,   /*单据日期*/
  @billstates     char(1),    /*单据状态 */
  @consign_dep    Varchar(30), /*托运部名称*/
  @wholeNumber    int,        /*整货数*/
  @remnantNumber  int,        /*零货数*/
  @trafficMode    varchar(30),  /*运输方式*/
  @Driver         VARCHAR(30),   /*驾驶员*/
  @stevedore      int,         /*装卸工*/
  /*@consignee      varchar(60),--收货人    */
  /*@relationPhone  varchar(60),  --收货人联系电话  */
  /*@paymentMode    varchar(20),  --付款方式  */
  @consigner      int,          /*发货人*/
  @checkman       int,          /*复核人*/
  @inputman       int,          /*制单人*/
  @remark         varchar(200),  /*备注 */
  @auditDate      datetime,  /*审核日期 */
  @c_id           int,      /*配货客户 */
  @roadid         int,      /*线路号*/
  @nRet           int output  ,
  @lhQty		  int=0,
  @CamionCode     VARCHAR(30),/*运输车辆（车牌号）*/
  @SendTime       DATETIME,   /*启运时间*/
  @Porthole       VARCHAR(200), /*装货地点22*/
  @Conveyancer    INT,         /*运输员*/
  @consign_depID  INT, /*托运部id           */
  @SendCustomerID int,		   /*收货方*/
  @DeviceID int,  /*运输设备*/
  
  /*@ArriveStation  DATETIME,   --运达目的站时间*/
  /*@ArriveCustomer DATETIME,   --运达客户地时间*/
  /*@Signfor        VARCHAR(30),--签收人*/
  /*@TransportationHour NUMERIC(25,8) = 0, --运输时间（小时）*/
  @TransportationType CHAR(1) = '0',/*类型（常温、冷藏） 0 无 1 2~8度*/
  @DeviceTemperature_Begin NUMERIC(25,8) = 0, /*发运时设备温度*/
  @ConditionTemperature_Begin NUMERIC(25,8) = 0, /*发运时环境温度*/
  /*@DeviceTemperature_End NUMERIC(25,8) = 0, --到达时设备温度*/
 /* @ConditionTemperature_End NUMERIC(25,8) = 0, --到达时环境温度 */
  @DetectTemperature VARCHAR(50) = '', /*温度检测装置*/
  /*@AffirmTemperature NUMERIC(25,8) = 0, --收货确认温度*/
  /*@ProcessTemperature NUMERIC(25,8) = 0,*/
  /*@SignforNote    varchar(100) ='',  --签收情况*/
  @TransportEquipment  varchar(200) = '',  /*运输设备*/
  @TemperatureNumber   varchar(200) = '',  /*设备编号	*/
  @TransportationLimit    NUMERIC(25,8) = 0,  /*运输时限（小时） */
  @TrafficType  varchar(100) = '',					/*承运方式     */
  @wtorder  varchar(100) = '' ,            /*自提的提货人   */
  @PersonNO varchar(200) = '' ,		/*自提的提货人的身份证 */
  @szserial_code  varchar(200) = '',    /*货运单号*/
  @yslc varchar(100) = '' ,   /*运输里程   */
  @XhAddress  varchar(500) = ''    /*卸货地点   */
)
AS

declare @DriverID int
/*Params Ini begin*/

if @Send_id is null  SET @Send_id = 0

if @serial_number is null set @serial_number= ''
if @billDate is null set @billDate= convert(varchar(60),GETDATE(),21)
if @billstates is null set @billstates= '0'
if @consign_dep is null set @consign_dep= ''
if @wholeNumber is null set @wholeNumber=0
if @remnantNumber is null  SET @remnantNumber = 0
if @trafficMode is null set @trafficMode = ''
if @CamionCode is null  SET @CamionCode = ''
if @SendTime is null set @SendTime= convert(varchar(60),GETDATE(),21)

if @Porthole is null set @Porthole= ''
if @Conveyancer is null set @Conveyancer=0
if @SendCustomerID is null set @SendCustomerID=0
if @consign_depID is null set @consign_depID=0
if @DeviceID is null set @DeviceID=0
if @DeviceTemperature_Begin is null  SET @DeviceTemperature_Begin = 0
if @ConditionTemperature_Begin is null set @ConditionTemperature_Begin =0

if @TransportationType is null  SET @TransportationType = '0'
if @DetectTemperature is null set @DetectTemperature= ''
if @TransportEquipment is null set @TransportEquipment= ''
if @TemperatureNumber is null set @TemperatureNumber= ''
if @TransportationLimit is null  SET @TransportationLimit = 9999
if @TrafficType is null set @TrafficType= ''

if @wtorder is null  SET @wtorder = ''
if @PersonNO is null set @PersonNO= ''
if @szserial_code is null set @szserial_code= ''
if @yslc is null set @yslc= ''
if @XhAddress is null set @XhAddress= ''

/*Params Ini end*/
if @Driver is null  SET @Driver = ''
select @DriverID = ISNULL(id,0) from logisticsInfo where ClassFlag = 'D' and Driver = @Driver
if @DriverID is null set @DriverID=0



if @Send_id=0
begin
  insert into Sendidx
  ( [serial_number],
    [billDate],     
	[billstates],   
	[consign_dep],  
    [wholeNumber],  
    [remnantNumber],
    [trafficMode],  
    [Driver],       
    [stevedore],    
    [consigner],    
    [checkman],
    [inputman],     
    [remark],
    [auditDate],
    [C_id],
    [roadid],
    lhqty,
    CamionCode,
    SendTime,
    Porthole,
    Conveyancer,
    consign_depID,
    SendCustomerID,
    DeviceID,
    DeviceTemperature_Begin,
    ConditionTemperature_Begin,
    TransportationType,
    TransportationLimit,
    DetectTemperature,
    TrafficType,
    wtorder,
    PersonNO,
    TransportEquipment,
    TemperatureNumber,
    [szserial_code],
    [yslc],
    [XhAddress]
  ) 
 Values(
	@serial_number, 
	@billDate,      
	@billstates,    
	@consign_dep,   
	@wholeNumber,   
	@remnantNumber, 
	@trafficMode,   
	@DriverID,        
	@stevedore,     
	@consigner,     
	@checkman, 
	@inputman,     
	@remark,
	@auditDate,
	@c_id ,
	@roadid              ,
	@lhQty,
	@CamionCode,
    @SendTime,
    @Porthole,
    @Conveyancer,
    isnull(@consign_depID,0),
    isnull(@SendCustomerID,0),
    @DeviceID,
    @DeviceTemperature_Begin,
    @ConditionTemperature_Begin,
    @TransportationType,
    @TransportationLimit,
    @DetectTemperature,
    @TrafficType,
    @wtorder,
    @PersonNO,
    @TransportEquipment,
    @TemperatureNumber,
    @szserial_code,
    @yslc,
    @XhAddress 
       )
    set @nRet = @@IDENTITY
/*  set select @nRet=Max(Send_id) from Sendidx */
end       
else
begin
  update Sendidx Set
		 [serial_number] = @serial_number,
		 [billDate]      = @billDate,     
		 [billstates]    = @billstates, 
		 [auditDate]     = @auditDate,  
		 [consign_dep]   = @consign_dep,  
		 [wholeNumber]   = @wholeNumber,  
		 [remnantNumber] = @remnantNumber,
		 [trafficMode]   = @trafficMode,  
		 [Driver]    = @Driver,       
		 [stevedore]     = @stevedore,    
		 [consigner]     = @consigner,    
		 [checkman]      = @checkman,     
		 [remark]        = @remark , 
		 [C_id]          = @c_id,
		 roadid          = @roadid,    
		 lhqty			 = @lhQty,
		 CamionCode      = @CamionCode,
         SendTime        = @SendTime,
		 Porthole        = @Porthole,
         Conveyancer     = @Conveyancer,
         consign_depID   = isnull(@consign_depID,0),
         SendCustomerID  = isnull(@SendCustomerID,0),
         DeviceID=@DeviceID,
         DeviceTemperature_Begin= @DeviceTemperature_Begin,
		 ConditionTemperature_Begin= @ConditionTemperature_Begin,
		 TransportationType= @TransportationType,
		 TransportationLimit= @TransportationLimit,
		 DetectTemperature	= @DetectTemperature,
		 TrafficType      = @TrafficType,
		 wtorder		  =	@wtorder,
         PersonNO			=@PersonNO,
		 TransportEquipment = @TransportEquipment,
		 TemperatureNumber  = @TemperatureNumber,
		 szserial_code   = @szserial_code,
		 yslc  =  @yslc,
		 XhAddress = @XhAddress
  where Send_id = @Send_id 
  set @nRet= @Send_id    
end
GO
