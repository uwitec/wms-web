
CREATE FUNCTION GetOOSCatalogStorehouse
(
	@PId       INT = 0	
)
RETURNS numeric(25,8)
AS
BEGIN
    DECLARE @Re numeric(25,8)
    SET @Re = 0
	IF @PId > 0 
	BEGIN
	    DECLARE @CheckSaleQty CHAR(1)
		SET @CheckSaleQty='0'
		SELECT @CheckSaleQty = sysvalue FROM sysconfig WHERE [sysname] = 'CheckSaleQty' /*存草稿是是否检测可开数量*/
	    
	    SELECT @Re = ISNULL(SUM(k.Quantity), 0) FROM (
			SELECT a.p_id, SUM(a.quantity) AS Quantity FROM (
				SELECT b.p_id, SUM(b.quantity) AS Quantity FROM billdraftidx a INNER JOIN salemanagebilldrf b ON a.billid = b.bill_id 
				WHERE b.Y_id = 2 AND b.p_id = @PId AND a.billtype IN (10, 110, 212, 150, 152) AND 
					(@CheckSaleQty = '1' OR ( @CheckSaleQty = '2' and a.billstates = 3)) AND b.aoid IN (0, 7) 
				GROUP BY b.p_id       
				UNION ALL
				SELECT b.p_id, SUM(b.quantity) AS Quantity FROM billdraftidx a INNER JOIN buymanagebilldrf b ON a.billid = b.bill_id 
				WHERE b.Y_id = 2 AND b.p_id = @PId AND a.billtype IN (21, 121) AND 
					(@CheckSaleQty = '1' OR ( @CheckSaleQty = '2' and a.billstates = 3)) AND b.aoid IN (0, 7) 
				GROUP BY b.p_id
				UNION ALL
				SELECT b.p_id, SUM(b.quantity) AS Quantity FROM billdraftidx a INNER JOIN storemanagebilldrf b ON a.billid = b.bill_id 
				WHERE b.Y_id = 2 AND b.p_id = @PId AND a.billtype IN (40, 41, 44, 45, 47, 49) AND 
					(@CheckSaleQty = '1' OR ( @CheckSaleQty = '2' and a.billstates = 3)) AND b.aoid IN (0, 7) 
				GROUP BY b.p_id 
				UNION ALL     
				SELECT b.p_id, SUM(b.quantity) AS Quantity FROM billdraftidx a INNER JOIN tranmanagebilldrf b ON a.billid = b.bill_id 
				WHERE b.Y_id = 2 AND b.p_id = @PId AND a.billtype IN (53, 56) AND 
					(@CheckSaleQty = '1' OR ( @CheckSaleQty = '2' and a.billstates = 3)) AND b.aoid IN (0, 7)       
				GROUP BY b.p_id
				) a GROUP BY a.p_id
			UNION ALL
			SELECT s.p_id, SUM(s.quantity) AS Quantity FROM storehouse s 
			WHERE s.p_id = @PId AND s.s_id IN (SELECT s.storage_id FROM storages s 
												WHERE s.Y_ID = 2 AND s.[deleted] = 0 AND s.child_number = 0 and s.WholeFlag<>3)/*zjx--tfs45072--2017-01-18--商品缺货分析库存量剔除拆零商品*/
			GROUP BY s.p_id
			) k GROUP BY k.p_id 									      
	END
	
	RETURN @Re
END
GO
