

/* =============================================*/
/* Author:		zjilin	*/
/* Create date: 2013-05-21*/
/* Description:	返回基本资料相关的关键指标*/
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_j_LoadBaseKpi] 
	@BaseName	varchar(60),		/*基本资料类型 */
	@BaseID     int,				/*基本资料ID*/
	@KpiName    varchar(100) = ''   /*指标名称，为空时返回该类基本资料的所有KPI	  */
AS
BEGIN       
  if upper(@BaseName) = 'VIPCARD' 
  begin
    if OBJECT_ID('tempdb..#BaseKpi') is not null
      drop table #BaseKpi
    
    create table #BaseKpi
    (		
		[kpiname] [varchar] (100) ,
		[kpivalue] [varchar] (100)
	)
	 
    if (@KpiName ='') or (upper(@KpiName) ='LASTSALEDATE') 
    begin
      declare @lastSaleDate datetime, @szLastSaleDate varchar(30) 
      select @lastSaleDate = MAX(billdate) from billidx where VIPCardID = @BaseID and billtype in (10, 12) and billstates = 0      
      if @lastSaleDate is null
        set @szLastSaleDate = '无购买记录'
      else
        set @szLastSaleDate = cast(DATEPART(yyyy, @LastSaleDate) as varchar(4)) + '-' +cast(DATEPART(mm, @LastSaleDate) as varchar(2))+'-' +cast(DATEPART(DD, @LastSaleDate) as varchar(2))
      insert into #BaseKpi(kpiname, kpivalue) values ('LASTSALEDATE',  @szLastSaleDate)
    end
    
    if (@KpiName ='') or (upper(@KpiName) ='PROFIT') 
    begin
      declare @Profit NUMERIC(25,8)
      select @Profit = isnull(-sum(total - costtotal), 0) 
        from productdetail pd
        inner join billidx bi on pd.billid = bi.billid
         where bi.VIPCardID = @BaseID and billtype in (10, 11, 12, 13) and bi.billstates = 0
      insert into #BaseKpi(kpiname, kpivalue) values ('PROFIT',  CAST(@Profit as varchar(20)))            
    end
    select * from #BaseKpi                    
  end  
  else if upper(@BaseName) = 'CUSTOMCATEGORY' 
  begin
    if OBJECT_ID('tempdb..#vipCustomtmp') is not null
      drop table #vipCustomtmp
      
    select 
         cg.id as CG_ID, sum(-pd.quantity) as quantity
         into #vipCustomtmp                       
       from productdetail pd
       inner join billidx bi on pd.billid = bi.billid         
       inner join (select p_id as baseinfo_id,class_id from (
                   select p_id,PComent1 as class_id from ProductCategory
                   union all 
                   select p_id,PComent2 as class_id from ProductCategory
                   union all
                   select p_id,PComent3 as class_id from ProductCategory
                   ) a 
            ) c on pd.P_ID = c.baseinfo_id
       inner join customCategory cg on c.class_id = cg.class_id
       where cg.baseType in( -1, 0) and
             bi.VIPCardID = @BaseID and billtype in (10, 11, 12, 13) and bi.billstates = 0
       Group by cg.id  
       
       
       select 
         v.CG_ID , cg.*, 
         LEFT(cg.class_id, 2) as MAINCATEGORYNO,  
         dbo.GetCateGoryStr(cg.ID, 'MAINCATEGORY') as MAINCATEGORY, 
         cg.class_id as SUBCATEGORYNO,
         dbo.GetCateGoryStr(cg.ID, 'SUBCATEGORY') as SUBCATEGORY,          
         v.quantity
       from  #vipCustomtmp v 
       left join customCategory cg on v.CG_ID = cg.id
       order by v.quantity desc        
  end       
END
GO
