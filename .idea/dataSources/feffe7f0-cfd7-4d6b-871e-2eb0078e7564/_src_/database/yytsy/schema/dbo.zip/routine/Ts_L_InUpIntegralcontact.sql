Create  procedure Ts_L_InUpIntegralcontact
( 
  @I_id   [int],
  @c_id   [int],  
  @ctype  [int]  
 )  
AS
   /*---修改先删除
   if @I_id=2  
   begin
     delete Integralcontact where I_id=@I_id
   end
   */
   /*-写入数据   */
   insert into Integralcontact
	( 
    [I_id],
    [c_id],  
    [ctype]
	)						
	Values
	(	
       @I_id,
       @c_id,  
       @ctype		    	    
    )
GO
