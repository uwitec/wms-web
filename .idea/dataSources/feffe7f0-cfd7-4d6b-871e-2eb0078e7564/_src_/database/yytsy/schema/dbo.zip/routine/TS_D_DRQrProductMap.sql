

/*********jfyan-tfs任务46678-2017-03-24 17:31-增加东软医保接品对照表**********/
create procedure TS_D_DRQrProductMap
@ProductState   INT=0,  /*0未对照 1已对照 2所有*/
@MedType VARCHAR(50)='',
@PName    VARCHAR(100)='库'
as 
  set nocount on 
  IF @ProductState IS NULL SET @ProductState=0  
  IF @MedType IS NULL SET @MedType=''
  if @PName IS NULL SET @PName=''
  
  SELECT a.serial_number,a.name,a.alias,a.standard,a.pinyin,a.MedName,a.product_id,b.*
  FROM vw_Products a LEFT JOIN DRProductMap b 
       ON a.product_id=b.p_id
  WHERE a.deleted=0 AND a.child_number=0
        AND ((@ProductState=0 AND b.DRid IS NULL) OR (@ProductState=1 AND b.DRid IS NOT NULL) OR @ProductState=2)
        AND (@MedType='' OR a.MedName=@MedType)
        AND (@PName='' OR a.serial_number like '%'+@PName+'%' or a.name like '%'+@PName+'%' or a.pinyin like '%'+@PName+'%')
GO
