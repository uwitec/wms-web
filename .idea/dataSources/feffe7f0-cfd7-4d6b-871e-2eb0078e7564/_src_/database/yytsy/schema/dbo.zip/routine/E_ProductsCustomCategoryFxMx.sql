create procedure E_ProductsCustomCategoryFxMx
  @y_id integer=0,/*机构*/
  @stopcheckd integer=0,/*是否停用 */
  @RowClassId varchar(100),/*行类别Classid*/
  @ColClassId Varchar(100)/*列类别名称*/
as
  declare @ColId int
  declare @CategoryClassid varchar(100)
  declare @code int
  declare @swarajprice int /*独立物价*/
  declare @info_id  int
  declare @ColName VARCHAR(100)
  declare @info_idOne  int
  declare @ColNameOne VARCHAR(100)
  declare @sqlstr  VARCHAR(2000)
  declare @sqlstrOne  VARCHAR(2000)
  declare @sqlstrThree  VARCHAR(2000)
  set @swarajprice = 0
  set @ColName=''
begin
    if @RowClassId<>''
    begin
      SELECT distinct @info_id = Category_id FROM customCategory WHERE class_id=@RowClassId
      set @ColName = dbo.GetColName(@info_id,'ProductCategory')  
    end
    set @sqlstr= '
                  select  distinct b.p_id as baseinfo_id into ##tempOne from 
						 (
						   select class_id from customCategory where deleted=0 
						 ) a 
						  left join  ProductCategory  b on a.class_id=b.'+@ColName+''
    exec (@sqlstr)  
    set @sqlstrOne  ='
                 select distinct b.p_id as baseinfo_id  into ##tempTwo from 
					(
						select class_id from customCategory   where class_id like '''+@RowClassId+'''+''%'' and deleted=0 
					) a
					inner join ProductCategory b on a.class_id=b.'+@ColName+''
	exec (@sqlstrOne)   
					 
    /*-通过所选择机构查询是否启用独立物价*/
    select @swarajprice=swarajPrice from company  where company_id=@y_id
    /*查找毛利区间表中的预估毛利区间取值 例如：1 ：零售价，2：预设售价1,3：预设售价2 .....*/
	select @code=code from 
    (
	  select distinct code from mlRataRoom
    ) a
    /*-毛利区间高中低取值*/
    select  baseinfo_id,mlqj 
    into #MLQJ 
    from 
    (
        select  a.baseinfo_id as baseinfo_id,
			case  when @code=1 then  (isnull(retailprice,0)-isnull(i.taxprice,0))/nullif(retailprice,0)
	              when @code=2 then  (isnull(price1,0)-isnull(taxprice,0))/nullif(price1,0)
	              when @code=3 then  (isnull(price2,0)-isnull(taxprice,0))/nullif(price2,0)
	              when @code=4 then  (isnull(price3,0)-isnull(taxprice,0))/nullif(price3,0)
	              when @code=5 then  (isnull(price4,0)-isnull(taxprice,0))/nullif(price4,0)
	              when @code=6 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              when @code=7 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              end as mlqj   
	        from  ##tempOne a 
	        left join 
			(
			  select c.smb_id,c.p_id,b.taxprice from
				(
				select MAX(smb_id) smb_id,p_id from 
				buymanagebill where p_id>0 group by p_id 
				)c
				left join buymanagebill b on c.smb_id= b.smb_id
				left join billidx bx on b.bill_id= bx.billid and bx.billtype=20								
			 )i on a.baseinfo_id=i.p_id
			 left join 
			 (
				select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from price where unittype=1 and @swarajprice=0
	            union all
	            select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id		
			 ) j on a.baseinfo_id=j.p_id     
			  
	) d inner join 
	(
		select product_id,deleted  from products  where IsSplit=0 and deleted<>1
	) z on d.baseinfo_id=z.product_id
				  where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)/*是否停用*/
				   
  if @ColClassId='GML'
  begin
       select distinct x.baseinfo_id as p_id 
       into #ProceductidGML 
       from ##tempTwo  x 
       inner join 
	    (
			   select count(distinct(baseinfo_id)) as gml,baseinfo_id
		       from #MLQJ
	            where  isnull(mlqj,0)>=(select minValue/100 from mlRataRoom where name='高')
		         group by  baseinfo_id
		 ) y on x.baseinfo_id=y.baseinfo_id
		 inner join 
		 (
		   select product_id,deleted  from products 
		 ) z on x.baseinfo_id=z.product_id
		 where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)	
		 
	   select distinct b.serial_number,b.alias as PName,standard,c.name as DWNmae,makearea,isnull(d.AccountComment,'') as FactoryName,
	       permitcode,e.retailprice,e.price1,e.price2,e.price3,e.gpprice,e.glprice,e.specialprice,e.price4 as vipprice,
	       recprice as lastPrice,e.lowprice,isnull(h.name,'') as Empname, isnull(g.name,'') as suppliername,Custompro1,Custompro2,Custompro3,Custompro4,
	       Custompro5,isnull(k.zbuytotal/((j.costtaxtotalini+j.costtaxtotal)/2),0)*100 as zzlv,i.quantity,i.taxprice,i.costtaxtotal as costtaxtotal,
	       ISNULL(e.retailprice,0)*ISNULL(i.quantity,0) as retailtotal,
	       case   when  @code=1 then  (isnull(e.retailprice,0)-isnull(i.taxprice,0))/nullif(e.retailprice,0)*100
	              when @code=2 then  (isnull(e.price1,0)-isnull(i.taxprice,0))/nullif(e.price1,0) *100
	              when @code=3 then  (isnull(e.price2,0)-isnull(i.taxprice,0))/nullif(e.price2,0)*100
	              when @code=4 then  (isnull(e.price3,0)-isnull(i.taxprice,0))/nullif(e.price3,0)*100
	              when @code=5 then  (isnull(e.price4,0)-isnull(i.taxprice,0))/nullif(e.price4,0)*100
	              when @code=6 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              when @code=7 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              end as  Mlv
	   from #ProceductidGML a left join products b on a.p_id=b.product_id
	                       left join unit c on b.unit1_id=c.unit_id
	                       left join basefactory d on b.factoryc_id=d.CommID
	                       left join 
	                       (
	                        select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from price where unittype=1/* and @swarajprice=0*/
	                        union all
	                        select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
	                       ) e on b.product_id=e.p_id
	                       left join (select  * from  productbalance where Y_id=@y_id) f on b.product_id=f.p_id
	                       left join clients g on f.Supplier_id=g.client_id
	                       left join employees h on f.Emp_id=h.emp_id
	                       left join (
										select y.p_id, quantity,isnull(x.taxprice,0)*quantity as costtaxtotal,isnull(x.taxprice,0) as taxprice from 
											(
												select a.p_id, sum(quantity) as quantity 
												       from storehouse a
													   group by a.p_id
											 ) y 											 
												 left join 
												 (  												 
												 select c.smb_id,c.p_id,b.taxprice from
												   (
													select MAX(smb_id) smb_id,p_id from 
													buymanagebill where p_id>0 group by p_id 
													)c
													left join buymanagebill b on c.smb_id= b.smb_id
													left join billidx bx on b.bill_id= bx.billid and bx.billtype=20
													
												 ) x on y.p_id=x.p_id 
									 )i on a.p_id=i.p_id
							left join 
							        (
							         select  a.costtaxtotal as costtaxtotalini,b.costtaxtotal as costtaxtotal,a.p_id from 
										(
										select sum(costtaxtotal) as  costtaxtotal,p_id from storehouseini group by p_id
										) a inner join 
										(
											select sum(costtaxtotal) as  costtaxtotal,p_id from storehouse  group by p_id
										) b on a.p_id=b.p_id
							        ) j on a.p_id=j.p_id	
							 left join 
							        (
							           select sum(costtaxtotal) as zbuytotal,b.p_id from billidx a 
							                  inner join buymanagebill b on a.billid=b.bill_id
							                  where billtype=20  and billstates=0 and b.p_id>0
							                  group by b.p_id           
							        ) k	  on a.p_id=k.p_id
  end
  else if @ColClassId='ZML'
  begin
       select  distinct  x.baseinfo_id as p_id into #ProceductidZML from 
	     ##tempTwo x inner join 
	    (
			   select count(distinct(baseinfo_id)) as gml,baseinfo_id
		       from #MLQJ
	            where  (select minValue/100 from mlRataRoom where name='中') <= mlqj 
	                and isnull(mlqj,0)< (select maxValue/100 from mlRataRoom where name='中')
		         group by baseinfo_id
		 ) y on x.baseinfo_id=y.baseinfo_id
		 inner join 
		 (
		   select product_id,deleted  from products
		 ) z on x.baseinfo_id=z.product_id
			 where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)	
	   select distinct b.serial_number,b.alias as PName,standard,c.name as DWNmae,makearea,isnull(d.AccountComment,'') as FactoryName,
	       permitcode,e.retailprice,e.price1,e.price2,e.price3,e.gpprice,e.glprice,e.specialprice,e.price4 as vipprice,
	       recprice as lastPrice,e.lowprice,isnull(h.name,'') as Empname, isnull(g.name,'') as suppliername,Custompro1,Custompro2,Custompro3,Custompro4,
	       Custompro5,isnull(k.zbuytotal/((j.costtaxtotalini+j.costtaxtotal)/2),0)*100 as zzlv,i.quantity,i.taxprice,i.costtaxtotal as costtaxtotal,
	       ISNULL(e.retailprice,0)*ISNULL(i.quantity,0) as retailtotal,
	       case  when @code=1 then  (isnull(e.retailprice,0)-isnull(i.taxprice,0))/nullif(e.retailprice,0)*100
	              when @code=2 then  (isnull(e.price1,0)-isnull(i.taxprice,0))/nullif(e.price1,0)*100
	              when @code=3 then  (isnull(e.price2,0)-isnull(i.taxprice,0))/nullif(e.price2,0)*100
	              when @code=4 then  (isnull(e.price3,0)-isnull(i.taxprice,0))/nullif(e.price3,0)*100
	              when @code=5 then  (isnull(e.price4,0)-isnull(i.taxprice,0))/nullif(e.price4,0)*100
	              when @code=6 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              when @code=7 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              end as  Mlv
	   from #ProceductidZML a left join products b on a.p_id=b.product_id
	                       left join unit c on b.unit1_id=c.unit_id
	                       left join basefactory d on b.factoryc_id=d.CommID
	                       left join 
	                       (
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
	                       ) e on b.product_id=e.p_id
	                       left join (select  * from  productbalance where Y_id=@y_id) f on b.product_id=f.p_id
	                       left join clients g on f.Supplier_id=g.client_id
	                       left join employees h on f.Emp_id=h.emp_id
	                       left join (
										select y.p_id, quantity,isnull(x.taxprice,0)*quantity as costtaxtotal,isnull(x.taxprice,0) as taxprice from 
											(
												select a.p_id, sum(quantity) as quantity 
												       from storehouse a 
													   group by a.p_id
											 ) y 
												 left join 
												 (
													select c.smb_id,c.p_id,b.taxprice from
												   (
													select MAX(smb_id) smb_id,p_id from 
													buymanagebill where p_id>0 group by p_id 
													)c
													left join buymanagebill b on c.smb_id= b.smb_id
													left join billidx bx on b.bill_id= bx.billid and bx.billtype=20
													
												 ) x on y.p_id=x.p_id
									 )i on a.p_id=i.p_id
							left join 
							        (
							         select  a.costtaxtotal as costtaxtotalini,b.costtaxtotal as costtaxtotal,a.p_id from 
										(
										select sum(costtaxtotal) as  costtaxtotal,p_id from storehouseini group by p_id
										) a inner join 
										(
											select sum(costtaxtotal) as  costtaxtotal,p_id from storehouse  group by p_id
										) b on a.p_id=b.p_id
							        ) j on a.p_id=j.p_id	
							 left join 
							        (
							           select sum(costtaxtotal) as zbuytotal,b.p_id from billidx a 
							                  inner join buymanagebill b on a.billid=b.bill_id
							                  where billtype=20  and billstates=0 and b.p_id>0
							                  group by b.p_id           
							        ) k	  on a.p_id=k.p_id
  end
  else if @ColClassId='DML'
  begin
       select distinct x.baseinfo_id as p_id into #ProceductidDML from 
	     ##tempTwo x inner join 
	    (
			    select count(distinct(baseinfo_id)) as gml,baseinfo_id
		       from #MLQJ
	            where  (select minValue/100 from mlRataRoom where name='低')<=mlqj
	                   and  isnull(mlqj,0)<(select maxValue/100 from mlRataRoom where name='低')
		          group by baseinfo_id
		 ) y on x.baseinfo_id=y.baseinfo_id
		 inner join 
		 (
		   select product_id,deleted  from products
		 ) z on x.baseinfo_id=z.product_id
			 where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)	
	   select distinct b.serial_number,b.alias as PName,standard,c.name as DWNmae,makearea,isnull(d.AccountComment,'') as FactoryName,
	       permitcode,e.retailprice,e.price1,e.price2,e.price3,e.gpprice,e.glprice,e.specialprice,e.price4 as vipprice,
	       recprice as lastPrice,e.lowprice,isnull(h.name,'') as Empname, isnull(g.name,'') as suppliername,Custompro1,Custompro2,Custompro3,Custompro4,
	       Custompro5,isnull(k.zbuytotal/((j.costtaxtotalini+j.costtaxtotal)/2),0)*100 as zzlv,i.quantity,i.taxprice,i.costtaxtotal as costtaxtotal,
	       ISNULL(e.retailprice,0)*ISNULL(i.quantity,0) as retailtotal,
	       case  when @code=1 then  (isnull(e.retailprice,0)-isnull(i.taxprice,0))/nullif(e.retailprice,0)*100
	              when @code=2 then  (isnull(e.price1,0)-isnull(i.taxprice,0))/nullif(e.price1,0)*100
	              when @code=3 then  (isnull(e.price2,0)-isnull(i.taxprice,0))/nullif(e.price2,0)*100
	              when @code=4 then  (isnull(e.price3,0)-isnull(i.taxprice,0))/nullif(e.price3,0)*100
	              when @code=5 then  (isnull(e.price4,0)-isnull(i.taxprice,0))/nullif(e.price4,0)*100
	              when @code=6 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              when @code=7 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              end as  Mlv
	   from #ProceductidDML a left join products b on a.p_id=b.product_id
	                       left join unit c on b.unit1_id=c.unit_id
	                       left join basefactory d on b.factoryc_id=d.CommID
	                       left join 
	                       (
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
	                       ) e on b.product_id=e.p_id
	                       left join (select  * from  productbalance where Y_id=@y_id) f on b.product_id=f.p_id
	                       left join clients g on f.Supplier_id=g.client_id
	                       left join employees h on f.Emp_id=h.emp_id
	                       left join (
										select y.p_id, quantity,isnull(x.taxprice,0)*quantity as costtaxtotal,isnull(x.taxprice,0) as taxprice from 
											(
												select a.p_id, sum(quantity) as quantity 
												       from storehouse a 
													   group by a.p_id
											 ) y 
												 left join 
												 (
													select c.smb_id,c.p_id,b.taxprice from
												   (
													select MAX(smb_id) smb_id,p_id from 
													buymanagebill where p_id>0 group by p_id 
													)c
													left join buymanagebill b on c.smb_id= b.smb_id
													left join billidx bx on b.bill_id= bx.billid and bx.billtype=20
													
												 ) x on y.p_id=x.p_id
									 )i on a.p_id=i.p_id
							left join 
							        (
							         select  a.costtaxtotal as costtaxtotalini,b.costtaxtotal as costtaxtotal,a.p_id from 
										(
										select sum(costtaxtotal) as  costtaxtotal,p_id from storehouseini group by p_id
										) a inner join 
										(
											select sum(costtaxtotal) as  costtaxtotal,p_id from storehouse  group by p_id
										) b on a.p_id=b.p_id
							        ) j on a.p_id=j.p_id	
							 left join 
							        (
							           select sum(costtaxtotal) as zbuytotal,b.p_id from billidx a 
							                  inner join buymanagebill b on a.billid=b.bill_id
							                  where billtype=20  and billstates=0 and b.p_id>0
							                  group by b.p_id           
							        ) k	  on a.p_id=k.p_id
  end
  else if @ColClassId='FML'
  begin
        select distinct  x.baseinfo_id as p_id into #ProceductidFML from 
	     ##tempTwo x inner join 
	    (
			    select count(distinct(baseinfo_id)) as gml,baseinfo_id
		       from #MLQJ
	           where  mlqj<0
		       group by baseinfo_id
		 ) y on x.baseinfo_id=y.baseinfo_id
		 inner join 
		 (
		   select product_id,deleted  from products
		 ) z on x.baseinfo_id=z.product_id
			 where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)	
	   select  distinct b.serial_number,b.alias as PName,standard,c.name as DWNmae,makearea,isnull(d.AccountComment,'') as FactoryName,
	       permitcode,e.retailprice,e.price1,e.price2,e.price3,e.gpprice,e.glprice,e.specialprice,e.price4 as vipprice,
	       recprice as lastPrice,e.lowprice,isnull(h.name,'') as Empname, isnull(g.name,'') as suppliername,Custompro1,Custompro2,Custompro3,Custompro4,
	       Custompro5,isnull(k.zbuytotal/((j.costtaxtotalini+j.costtaxtotal)/2),0)*100 as zzlv,i.quantity,i.taxprice,i.costtaxtotal as costtaxtotal,
	       ISNULL(e.retailprice,0)*ISNULL(i.quantity,0) as retailtotal,
	       case  when @code=1 then  (isnull(e.retailprice,0)-isnull(i.taxprice,0))/nullif(e.retailprice,0)*100
	              when @code=2 then  (isnull(e.price1,0)-isnull(i.taxprice,0))/nullif(e.price1,0)*100
	              when @code=3 then  (isnull(e.price2,0)-isnull(i.taxprice,0))/nullif(e.price2,0)*100
	              when @code=4 then  (isnull(e.price3,0)-isnull(i.taxprice,0))/nullif(e.price3,0)*100
	              when @code=5 then  (isnull(e.price4,0)-isnull(i.taxprice,0))/nullif(e.price4,0)*100
	              when @code=6 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              when @code=7 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              end as  Mlv
	   from #ProceductidFML a left join products b on a.p_id=b.product_id
	                       left join unit c on b.unit1_id=c.unit_id
	                       left join basefactory d on b.factoryc_id=d.CommID
	                       left join 
	                       (
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
	                       ) e on b.product_id=e.p_id
	                       left join (select  * from  productbalance where Y_id=@y_id) f on b.product_id=f.p_id
	                       left join clients g on f.Supplier_id=g.client_id
	                       left join employees h on f.Emp_id=h.emp_id
	                       left join (
										select y.p_id, quantity,isnull(x.taxprice,0)*quantity as costtaxtotal,isnull(x.taxprice,0) as taxprice from 
											(
												select a.p_id, sum(quantity) as quantity 
												       from storehouse a
													   group by a.p_id 
											 ) y 
												 left join 
												 (
												 select c.smb_id,c.p_id,b.taxprice from
												   (
													select MAX(smb_id) smb_id,p_id from 
													buymanagebill where p_id>0 group by p_id 
													)c
													left join buymanagebill b on c.smb_id= b.smb_id
													left join billidx bx on b.bill_id= bx.billid and bx.billtype=20
												 ) x on y.p_id=x.p_id
									 )i on a.p_id=i.p_id
							left join 
							        (
							         select  a.costtaxtotal as costtaxtotalini,b.costtaxtotal as costtaxtotal,a.p_id from 
										(
										select sum(costtaxtotal) as  costtaxtotal,p_id from storehouseini group by p_id
										) a inner join 
										(
											select sum(costtaxtotal) as  costtaxtotal,p_id from storehouse  group by p_id
										) b on a.p_id=b.p_id
							        ) j on a.p_id=j.p_id	
							 left join 
							        (
							           select sum(costtaxtotal) as zbuytotal,b.p_id from billidx a 
							                  inner join buymanagebill b on a.billid=b.bill_id
							                  where billtype=20  and billstates=0 and b.p_id>0
							                  group by b.p_id           
							        ) k	  on a.p_id=k.p_id
  end
  else 
  begin 
  /*-拆分出列类别名称中的类别ID 列如：n2_124 ； 124:为类别名称的ID号*/
  select @ColId=substring(@ColClassId,charindex('_',@ColClassId)+1,10)
  /*通过拆分出列类别名称中的类别id查询出类别Classid*/
  select @CategoryClassid=class_id from customCategory where id=@ColId
 
  if @CategoryClassid<>''
  begin
      SELECT distinct @info_idOne = Category_id FROM customCategory WHERE id=@ColId
      set @ColNameOne = dbo.GetColName(@info_idOne,'ProductCategory')  
  end
  set @sqlstrThree=' select distinct b.p_id as baseinfo_id into ##tempthree from 
			 (
				select class_id from customCategory   where class_id like '''+@CategoryClassid+'''+''%'' and  deleted=0 
		     ) a
			 inner join ProductCategory b on a.Class_id=b.'+@ColNameOne+''
  exec (@sqlstrThree)
  
  /*查询取出既满足类别组二，又满足类别组三的商品ID号*/
  select  distinct x.baseinfo_id as p_id into #Proceductid from 
	     ##tempTwo x inner join 
	     ##tempthree y on x.baseinfo_id=y.baseinfo_id
		 inner join 
		 (
		   select product_id,deleted  from products where IsSplit=0 and deleted<>1
		 ) z on x.baseinfo_id=z.product_id  where   (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)
			 		 
   					 
	   select  distinct b.serial_number,b.alias as PName,standard,c.name as DWNmae,makearea,isnull(d.AccountComment,'') as FactoryName,
	       permitcode,e.retailprice,e.price1,e.price2,e.price3,e.gpprice,e.glprice,e.specialprice,e.price4 as vipprice,
	       recprice as lastPrice,e.lowprice,isnull(h.name,'') as Empname, isnull(g.name,'') as suppliername,Custompro1,Custompro2,Custompro3,Custompro4,
	       Custompro5,isnull(k.zbuytotal/((j.costtaxtotalini+j.costtaxtotal)/2),0)*100 as zzlv,i.quantity,i.taxprice,i.costtaxtotal as costtaxtotal,
	       ISNULL(e.retailprice,0)*ISNULL(i.quantity,0) as retailtotal,
	       case  when @code=1 then  (isnull(e.retailprice,0)-isnull(i.taxprice,0))/nullif(e.retailprice,0)*100
	              when @code=2 then  (isnull(e.price1,0)-isnull(i.taxprice,0))/nullif(e.price1,0)*100
	              when @code=3 then  (isnull(e.price2,0)-isnull(i.taxprice,0))/nullif(e.price2,0)*100
	              when @code=4 then  (isnull(e.price3,0)-isnull(i.taxprice,0))/nullif(e.price3,0)*100
	              when @code=5 then  (isnull(e.price4,0)-isnull(i.taxprice,0))/nullif(e.price4,0)*100
	              when @code=6 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              when @code=7 then  (isnull(e.gpprice,0)-isnull(i.taxprice,0))/nullif(e.gpprice,0)*100
	              end as  Mlv
	   from #Proceductid a inner join  products b on a.p_id=b.product_id
	                       left join unit c on b.unit1_id=c.unit_id
	                       left join basefactory d on b.factoryc_id=d.CommID
	                       left join 
	                       (
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,specialprice,recprice,lowprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
	                       ) e on b.product_id=e.p_id
	                       left join (select  * from  productbalance where Y_id=@y_id) f on b.product_id=f.p_id
	                       left join clients g on f.Supplier_id=g.client_id
	                       left join employees h on f.Emp_id=h.emp_id
	                       left join (
										select y.p_id, quantity,isnull(x.taxprice,0)*quantity as costtaxtotal,isnull(x.taxprice,0) as taxprice from 
											(
												select a.p_id, sum(quantity) as quantity 
												       from storehouse a 
													   group by a.p_id
											 ) y 
												 left join 
												 (
												 select c.smb_id,c.p_id,b.taxprice from
												   (
													select MAX(smb_id) smb_id,p_id from 
													buymanagebill where p_id>0 group by p_id 
													)c
													left join buymanagebill b on c.smb_id= b.smb_id
													left join billidx bx on b.bill_id= bx.billid and bx.billtype=20
												 ) x on y.p_id=x.p_id
									 )i on a.p_id=i.p_id
							left join 
							        (
							         select  a.costtaxtotal as costtaxtotalini,b.costtaxtotal as costtaxtotal,a.p_id from 
										(
										select sum(costtaxtotal) as  costtaxtotal,p_id from storehouseini group by p_id
										) a inner join 
										(
											select sum(costtaxtotal) as  costtaxtotal,p_id from storehouse  group by p_id
										) b on a.p_id=b.p_id
							        ) j on a.p_id=j.p_id	
							 left join 
							        (
							           select sum(costtaxtotal) as zbuytotal,b.p_id from billidx a 
							                  inner join buymanagebill b on a.billid=b.bill_id
							                  where billtype=20  and billstates=0 and b.p_id>0
							                  group by b.p_id           
							        ) k	  on a.p_id=k.p_id
  end
end
 if OBJECT_ID('tempdb..#MLQJ') is not null
      drop table #MLQJ
 if OBJECT_ID('tempdb..#Proceductid') is not null
      drop table #Proceductid
 if OBJECT_ID('tempdb..#ProceductidGML') is not null
      drop table #ProceductidGML
 if OBJECT_ID('tempdb..#ProceductidZML') is not null
      drop table #ProceductidZML
 if OBJECT_ID('tempdb..#ProceductidDML') is not null
      drop table #ProceductidDML
 if OBJECT_ID('tempdb..#ProceductidFML') is not null
      drop table #ProceductidFML
 if OBJECT_ID('tempdb..##tempOne') is not null
     drop table ##tempOne
 if OBJECT_ID('tempdb..##tempTwo') is not null
      drop table ##tempTwo
 if OBJECT_ID('tempdb..##tempthree') is not null
      drop table ##tempthree
/*exec E_ProductsCustomCategoryFxMx 0,0,'0403','Gml'*/
GO
