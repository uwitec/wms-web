


/*

用于查询库存商品的批次明细和代销，委销的批次明细
@cCommionFalg  库存标记
@szSClass_id   仓库ID号
@szCClass_id   单位ID号
@szPClass_id   商品ID号
****************************************/
CREATE PROCEDURE TS_C_QrStoreMx
( @cCommionFalg  INT,
  @szSClass_id   VARCHAR(30),
	@szCClass_id   VARCHAR(30),
	@szPClass_id   VARCHAR(30),
        @nYClassid     varchar(50)='',
        @nloginEID     int=0,        
        @loc_id        int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
declare  @l_id int,@l_id1 int,@l_id2 int 
set   @l_id =@loc_id
select @l_id1=@l_id,@l_id2=@l_id1
if @l_id1=0 select @l_id2=2147483647

if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000)
  Declare @ClientTable varchar(100),@Companytable varchar(100),@Storetable varchar(100),@employeestable varchar(100)
  Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@FilteStore   varchar(8000)

  Declare @szsql2  varchar(100)

  select  @FilteClient='',@FilteCompany='',@FilteStore =''

  exec Ts_L_SearchUserauthorize @nLoginEid,1,@ClientTable out,1,@Companytable out,0,@employeestable,1,@Storetable out/*调用后，要在最后释放临时表*/
   
 IF ISNULL(@ClientTable,'') <>' '     set @FilteClient=' and ((vs.cclassid='''') or (exists(select CCID FROM '+@ClientTable+' where vs.cclassid like CCID+''%'' ))) '
 IF ISNULL(@Companytable,'')<>' '     set @FilteCompany=' and ((vs.YClass_ID='''') or (exists(select YCID from '+@Companytable+' where vs.YClass_ID like YCID+''%'' ))) '/*只用于查询YProductDetail*/
 IF ISNULL(@storetable,'')  <>' '     set @FilteStore=' and ((vs.sclassid='''')  or (exists(select SCID from '+@storetable+' where vs.sclassid like SCID+''%'' ))) '

/*库存商品查询*/
  IF @cCommionFalg IN (0)
  BEGIN
    SET @SQLScript=	' SELECT Vs.storehouse_id, VS.location_id, VS.s_id, VS.p_id, VS.supplier_id, VS.quantity,VS.price1, VS.price2, VS.price3, VS.lowprice, VS.costprice, 
		                     VS.costtotal,  VS.makedate, VS.instoretime, VS.validdate, VS.commissionflag, VS.stopsaleflag, VS.inorder, VS.yhdate, VS.ModifyDate, VS.BatchBarCode, VS.Y_ID, VS.SendFlag, VS.scomment, 
							 VS.batchprice,VS.SClassID,VS.YClass_id,PClassID,Pname,VS.Alias,VS.Standard,VS.Makearea,VS.comment,VS.Taxrate,Cname,VS.CclassID,VS.MedName,VS.Medtype,VS.Locname,
							 VS.C_Name,VS.Code,VS.Factory,VS.Name1,VS.Name2,VS.Name3,VS.Name4,VS.Otcflag,VS.Permitcode,VS.Rate2,VS.Rate3,VS.Rate4,VS.RetailTotal,VS.SR2_id,
							 VS.Sname,VS.Validmonth,VS.Yname,VS.batchno,VS.e_name,VS.retailprice,VS.scode,VS.costtaxprice AS taxprice, VS.costtaxtotal AS taxtotal, ISNULL(pri.retailprice,0) AS retailprice,
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.Factory
    FROM FilterVW_C_Storehouse('+CHAR(39)+CAST(@nloginEID as varchar)+CHAR(39)+') vs LEFT JOIN price pri ON vs.p_id=pri.p_id AND pri.unittype=1
                            LEFT JOIN products p on p.product_id=vs.p_id ' 

    IF @szSClass_id='000000'
  	  SET @SQLScript=	@SQLScript+ ' WHERE vs.sclassid LIKE ''%%'' '
    ELSE
  	  SET @SQLScript=	@SQLScript+ ' WHERE LEFT(vs.sclassid,LEN('+CHAR(39)+@szSClass_id+CHAR(39)+'))='
        +CHAR(39)+@szSClass_id+CHAR(39)
  
    IF @szCClass_id<>'' 
  	  SET @SQLScript=	@SQLScript+ ' AND LEFT(vs.cclassid,LEN('+CHAR(39)+@szCClass_id+CHAR(39)+'))='
        +CHAR(39)+@szCClass_id+CHAR(39)
  
    IF @szPClass_id<>''
  	  SET @SQLScript=	@SQLScript+ ' AND LEFT(vs.pclassid,LEN('+CHAR(39)+@szPClass_id+CHAR(39)+'))='
        +CHAR(39)+@szPClass_id+CHAR(39)
    
    IF @nYClassID<>''
  	  SET @SQLScript=	@SQLScript+ ' AND vs.YClass_id like '''+@nYClassID+'%'''
  	
  	/*--加入货位条件  */
    SET @SQLScript=	@SQLScript+ '  and ( vs.location_id>='+CAST(@l_id1 as varchar)+' and vs.location_id<='+CAST(@l_id2 as varchar)+' )' 	  
     
    SET @SQLScript=	@SQLScript+ @FilteClient+ @FilteCompany+ @FilteStore+'  ORDER BY vs.p_id, vs.batchno'
  
    PRINT @SQLScript
    EXEC(@SQLScript)
    GOTO Succee
  END

/*代销、委托库存商品查询*/
  ELSE IF @cCommionFalg IN (1, 2)
  BEGIN
    SET @SQLScript='SELECT VS.*, ISNULL(pri.retailprice,0) AS retailprice,
        p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5 
      FROM VW_C_StoreDX vs LEFT JOIN price pri ON vs.p_id=pri.p_id AND pri.unittype=1
                           LEFT JOIN products p on p.product_id=vs.p_id 
      WHERE  [commissionflag] IN ('+CAST(@cCommionFalg AS VARCHAR)+')'

     IF @szCClass_id<>'' 
   	  SET @SQLScript=	@SQLScript+ ' AND LEFT(vs.cclassid,LEN('+CHAR(39)+@szCClass_id+CHAR(39)+'))='
         +CHAR(39)+@szCClass_id+CHAR(39)
  
    IF @szPClass_id<>''
  	  SET @SQLScript=	@SQLScript+ ' AND LEFT(vs.pclassid,LEN('+CHAR(39)+@szPClass_id+CHAR(39)+'))='
        +CHAR(39)+@szPClass_id+CHAR(39)
  
    IF @nYClassID<>''
  	  SET @SQLScript=	@SQLScript+ ' AND vs.YClass_id like '''+@nYClassID+'%'''

    SET @SQLScript=	@SQLScript+ @FilteCompany+@FilteClient+' ORDER BY vs.p_id, vs.batchno'

    PRINT @SQLScript
    EXEC(@SQLScript)
    GOTO Succee
  END

Succee:
  if isnull(@ClientTable,'')<>''
  begin
    set @szsql2='drop table '+@ClientTable
    exec (@szsql2) 
  end

  if isnull(@companytable,'')<>''
  begin
    set @szsql2='drop table '+@Companytable
    exec (@szsql2) 
  end

  if isnull(@Storetable,'')<>''
  begin
    set @szsql2='drop table '+@Storetable
    exec (@szsql2)
  end
  RETURN 0
GO
