

/******************************************************/
/*功能：用于离线模式，生成门店数据到dts表*/
/*参数说明:*/
/*创建人：周继林*/
/*创建时间：2011-02-23*/
/*最后修改人：黄耀*/
/*最后修改时间:2011-10-18*/
/*最后修改修改说明：增加商品缺货单上传*/
/******************************************************/
/*复制到DTS库*/
create  procedure ts_c_YHisToDts

/*with encryption*/
as
set nocount on
declare @nPosid int,@nret int,@posguid varchar(50), @nYtype int
declare @dtLastDCDate datetime

exec ts_getsysvalue 'Y_ID',@nPosid out
if @nPosid is null set @nPosid=0

exec ts_getsysvalue 'GUID',@Posguid out


if @Posguid='' or @Posguid is null 
begin
	return -100
end
	truncate table yretailbilldts
	truncate table yRetailbillidxDts
	truncate table ZeroStockIDXdts
	truncate table ZeroStockbilldts
	

begin tran createbill

	insert into Yretailbillidxdts (billid, billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	    ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,[guid],VIPCardID,invoiceTotal,Y_ID,integral,integralYE)
	SELECT bi.billid, retaildate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
	       ysmoney, ssmoney,araptotal, quantity, taxrate, period, '0', order_id, department_id, 
      	   posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,bi.[guid],VIPCardID,invoiceTotal,bi.Y_ID,integral,integralYE
	FROM billidx bi
	inner join upbilllist up on bi.billid = up.mdbillid
	where bi.billtype in (12, 13) and up.dcflag = 0 and bi.billstates = 0
	
    if @@ERROR <> 0 goto error
    		
	insert into Yretailbilldts(smb_id, bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      comment,unitid,taxrate,total,aoid,thqty,PriceType,RowE_ID,Y_ID,InStoreTime,cxType,rowguid,billguid,BatchBarCode, scomment, batchprice, cxGuid)

	SELECT smb_id, bill_id, p_id, batchno, mx.quantity, costprice, saleprice, discount, discountprice, 
      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
      comment,unitid,mx.taxrate,total,aoid,mx.quantity,priceType,RowE_ID,mx.Y_ID,InStoreTime,
	  cxType,rowguid,rbi.[guid],BatchBarCode, scomment, batchprice, cxGuid
	FROM salemanagebill mx 
	inner join Yretailbillidxdts rbi on mx.bill_id =rbi.billid
	
    if @@ERROR <> 0 goto error 	  
    
	SELECT     TOP 1 @dtLastDCDate = i.billdate
	FROM         dbo.UpBillList AS u INNER JOIN
						  dbo.billidx AS i ON u.mdbillid = i.billid
	WHERE     (u.DCflag = 1)
	ORDER BY i.billdate DESC

	INSERT INTO dbo.ZeroStockIDXdts(billid, billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, 
						  region_id, auditdate, jsflag, note, summary, Y_ID, [guid])
	SELECT     billid, billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, 
						  region_id, auditdate, jsflag, note, summary, Y_ID, [guid]
	FROM         dbo.ZeroStockIDX WHERE billstates = '3' and billdate >= @dtLastDCDate

    if @@ERROR <> 0 goto error 	 
     
	INSERT INTO dbo.ZeroStockBilldts(smb_id, bill_id, p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, 
                      comment2, aoid, Y_ID)
	SELECT     smb_id, bill_id, p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, 
                      comment2, aoid, Y_ID
	FROM         dbo.ZeroStockBill where bill_id in (select billid from ZeroStockIDXdts WHERE billstates = '3' and billdate >= @dtLastDCDate)

    if @@ERROR <> 0 goto error 	  
    
commit tran createbill

return 0

error:
	rollback tran createbill
	return -1
GO
