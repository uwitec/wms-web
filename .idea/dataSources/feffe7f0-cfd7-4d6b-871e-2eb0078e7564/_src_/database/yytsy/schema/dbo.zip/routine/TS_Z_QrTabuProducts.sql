
/*Tabu商品*/
create   PROCEDURE TS_Z_QrTabuProducts
(	
    @nTabuID	int
)
AS

set nocount on


	SELECT   p.serial_number, p.name, p.standard, p.makearea, p.permitcode, p.medtype, p.alias, p.Factory, p.comment, 
					p.product_id
	FROM      dbo.TabuMx AS tm INNER JOIN
					dbo.TabuIndex AS ti ON ti.Tabu_ID = tm.Tabu_ID LEFT OUTER JOIN
					dbo.products AS p ON tm.p_id = p.product_id
    where tm.Tabu_ID = @nTabuID
      
return 0
GO
