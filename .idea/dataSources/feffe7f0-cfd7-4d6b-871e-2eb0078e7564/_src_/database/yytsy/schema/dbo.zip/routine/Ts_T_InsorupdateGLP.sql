Create  procedure Ts_T_InsorupdateGLP
( @GLp_id         [int],
  @Parent_id      [varchar](30),
  @serial_number  [varchar](26),
  @name           [varchar](80),
  @alias          [varchar](30),
  @engName        [varchar](50),
  @chemName       [varChar](50),
  @latinName      [varChar](50),
  @pinyin         [varchar](80),
  @standard       [varchar](20), 
  @makearea       [varchar](60),
  @Range          [int],
  @validmonth     [smallint],
  @validday       [smallint],
  @GspFlag        [char](2),
  @GMP            [bit], 
  @firstcheck     [bit],
  @medtype        int,
  @basicMedication NUMERIC(25,8), 
  @OTCType         [Tinyint],
  @unitid          [int],
  @Inputdate       varchar(50),
  @Inputman        varchar(50),
  @Custompro1      varchar(100),
  @Custompro2 	    varchar(100),
  @Custompro3 		varchar(100), 
  @Custompro4 		varchar(100),
  @Custompro5 	    varchar(100),
  @tcmoney          NUMERIC(25,8),
  @tc1             NUMERIC(25,8),
  @tc2             NUMERIC(25,8),
  @rowindex        int,
  @packStd         [varchar](30),
  @storageCon      [varchar](30),
  @attendeffect    Text,
  @otcflag       varchar(1)
)
AS
declare  @tempId  varchar(30),
         @child_number  [int],
         @child_count [int],
         @newP_id  int
/*合法性检查*/

/*取得ID号*/
if @GLp_id=0
begin
	select @tempid=classid,@child_number=childnumber,@child_count=childCount 
	from Getid(@Parent_id,'GLProducts')
	if @@rowcount=0
	begin
	 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
	 return-1
	end

	 insert into GLProducts( 
				[class_id],                     
				[parent_id],									          
				[serial_number],				
				[name]  ,						
				[alias] ,						
				[EngName] ,						
				[ChemName] ,					
				[LatinName],					
				[pinyin] ,						
				[standard] ,					
				[makearea],						
				[r_id] ,						
				[validmonth],					
				[validday],						
				[gspflag],						
				[GMP],							
				[firstcheck],					
				[medtype] ,						
				[basicMedication],				
				[OTCType],						
				[unitid],						
				[Inputdate] ,					
				[Inputman] ,									                	
				[Custompro1] ,					
				[Custompro2],					
				[Custompro3],					
				[Custompro4],					
				[Custompro5] ,					
				[tcmoney],						
				[TC1] ,							
				[TC2] ,
				[rowindex],							
				[PackStd],						
				[StorageCon],					
				[attendeffect],
				[otcflag] 
			 )						
	Values(	@tempId,
	        @Parent_id ,     
			@serial_number, 
			@name,           
			@alias,          
			@engName,        
			@chemName,       
			@latinName,      
			@pinyin,         
			@standard,       
			@makearea,       
			@Range,          
			@validmonth,     
			@validday,       
			@GspFlag,        
			@GMP,            
			@firstcheck,     
			@medtype,        
			@basicMedication,
			@OTCType,        
			@unitid,         
			@Inputdate,      
			@Inputman,       
			@Custompro1,     
			@Custompro2, 	  
			@Custompro3, 		
			@Custompro4, 		
			@Custompro5, 	  
			@tcmoney,        
			@tc1,            
			@tc2,  
			@rowindex,          
			@packStd,        
			@storageCon,     
			@attendeffect,
			@otcflag      						    	    
		   )									

	if @@rowCount=0 
	begin
	 return -1
	end else 
	begin
	 update GLproducts set child_number=@child_number,child_count=@child_count
	 where class_id =@Parent_id
	 select @newP_id= @@IDENTITY
	 return @newP_id 
    end
end else
begin
   UPDATE [GLProducts]  
		SET  
		[serial_number]	 = @serial_number,
		[name]           = @name,
		[alias]	         = @alias,
		[standard]	     = @standard,
		[makearea]	     = @makearea,
		[validmonth]	 = @validmonth,
		[validday]	     = @validday,
		[pinyin]	     = @pinyin,
		[firstcheck]	 = @firstcheck,
		[gspflag]		 = @gspflag,
		[medtype]		 = @medtype,
		[engName]		 =@engName,
		[chemName]		 =@chemName,
		[LatinName]		 =@latinName,
		[otcType]		 =@otcType,
		[Gmp]			 =@gmp,
		[r_id]			 = @range,
		[otcflag]        = @otcflag,
		packStd	    	 =@packStd,
		storagecon		 =@storageCon,	
		tc1		    	 = @tc1,
		tc2         	 = @tc2,
		tcmoney     	 =@tcmoney,
	    unitid           =@unitid,   
		LastUpDate  	 =@Inputdate,
		LastUpdateman    =@Inputman,
		Custompro1       =@Custompro1, 
		Custompro2       =@Custompro2,
		Custompro3       =@Custompro3, 
		Custompro4       =@Custompro4, 
		Custompro5       =@Custompro5,
		basicMedication  =@basicMedication,
	    attendeffect     = @attendeffect
  WHERE 
	( [glp_id] = @GLp_id)
  return @GLp_id
end
GO
