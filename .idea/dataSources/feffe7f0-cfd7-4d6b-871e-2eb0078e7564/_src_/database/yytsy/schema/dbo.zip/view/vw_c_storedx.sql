


CREATE VIEW dbo.vw_c_storedx
AS
SELECT 
      
      P.class_id AS pclassid, C.class_id AS cclassid, 
      P.name, P.alias, P.standard, P.otcflag,
      P.serial_number as code,
      P.permitcode, P.makearea, P.rate2, 
      P.rate3, P.rate4, P.validmonth, 
      P.medtype, C.name AS cname, ISNULL(U1.name, '') 
      AS Name1, ISNULL(U2.name, '') AS Name2, ISNULL(U3.name, '') AS Name3, 
      ISNULL(U4.name, '') AS Name4, ISNULL(L.loc_name, '') AS loc_name, 
      ISNULL(M.medtype, '') AS medname,
      SH.*,
      ISNULL(Y.class_id,'')as YClass_ID,ISNULL(Y.[name],'')Yname,
      ISNULL(f.AccountComment,'') as factory
FROM  dbo.storedx SH LEFT OUTER JOIN
      dbo.clients C ON SH.c_id = C.client_id LEFT OUTER JOIN
      dbo.location L ON SH.location_id = L.loc_id LEFT OUTER JOIN
      dbo.clients S ON SH.supplier_id = S.client_id LEFT OUTER JOIN
      dbo.products P ON SH.p_id = P.product_id LEFT OUTER JOIN
      dbo.unit U1 ON U1.unit_id = P.unit1_id LEFT OUTER JOIN
      dbo.unit U2 ON U2.unit_id = P.unit2_id LEFT OUTER JOIN
      dbo.unit U3 ON U3.unit_id = P.unit3_id LEFT OUTER JOIN
      dbo.unit U4 ON U4.unit_id = P.unit4_id LEFT OUTER JOIN
	  VW_MedType m on p.product_id = m.product_id
	  left join 
      dbo.company  Y  ON Y.Company_id=sh.Y_id left outer join
      basefactory f on sh.factoryid=f.CommID
GO
