
/* =============================================*/
/* Author:		ZK*/
/* Create date: 2014-05-22*/
/* Description:	根据单据状态和单据类型返回审核人*/
/* =============================================*/
CREATE FUNCTION FN_GetVchAuditMan 
(
	@BillId   INT,
	@BillType INT,
	@IsDraft  INT
)
RETURNS varchar(50)
AS
BEGIN
	DECLARE @Result VARCHAR(50)
	SET @Result = ''
	
	IF @BillType >= 501 AND @BillType <= 599
	BEGIN
		SELECT @Result = CASE WHEN a.AuditMan2 = '' THEN a.AuditMan1 ELSE a.AuditMan1 + '+' + a.AuditMan2 END 
		  FROM ( 
			SELECT ISNULL(e.name, '') AS AuditMan1, ISNULL(e1.name, '') AS AuditMan2 
				FROM GSPbillidx g LEFT JOIN employees e ON g.AuditMan1 = e.emp_id
								  LEFT JOIN employees e1 ON g.AuditMan2 = e1.emp_id
			WHERE g.Gspbillid = @BillId AND g.BillType = @BillType) a
	END
	ELSE
	IF @BillType IN (14, 22, 26)
	BEGIN
		SELECT @Result = ISNULL(e.name, '')
			FROM orderidx g LEFT JOIN employees e ON g.auditman = e.emp_id
		WHERE g.billid = @BillId AND g.BillType = @BillType
	END
	ELSE
	BEGIN
		IF @IsDraft = 1
		BEGIN
			SELECT @Result = ISNULL(e.name, '')
				FROM billdraftidx g LEFT JOIN employees e ON g.auditman = e.emp_id
			WHERE g.billid = @BillId AND g.BillType = @BillType		
		END
		ELSE
		BEGIN
			SELECT @Result = ISNULL(e.name, '')
				FROM billidx g LEFT JOIN employees e ON g.auditman = e.emp_id
			WHERE g.billid = @BillId AND g.BillType = @BillType
		END	
	END	
	RETURN @Result	
END
GO
