/*基本信息的Class_id自动生成的函数。*/
/*@parid父ID*/
/*@dbName 基本信息的表名*/
CREATE	  FUNCTION [GetID] (@ParID varchar(36),@DBName Varchar(20))  
RETURNS @Getid table 
	(ClassID varchar(36),
	 ChildNumber int,
	 ChildCount int)  AS  
BEGIN 

	declare @szClassId varchar(36),@Childnum int,@Childcount int,@count int
	declare @tempId varchar(100)

	if upper(@DBName)='PRODUCTS'
		select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from products 
		where Class_id= @parid
	if upper(@dbName)='ACCOUNT'
		select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from account 
		where Class_id= @parid
	if upper(@dbName)='STORAGES'
		select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from storages 
		where Class_id= @parid
	if upper(@dbName)='EMPLOYEES'
		select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from employees 
		where Class_id= @parid
	if upper(@dbName)='CLIENTS'
		select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from clients 
		where Class_id= @parid
    if upper(@dbname)='COMPANY'
        select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from company 
		where Class_id= @parid 
    if upper(@dbname)='REGION'
        select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
		from region 
		where Class_id= @parid
	if upper(@dbname)='CUSTOMREP'
	    select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
	    from CustomReport 
	    where Class_id=@parid
	if upper(@dbname)='GLPRODUCTS'
	    select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
	    from GLProducts 
	    where Class_id=@parid
	    
	if upper(@dbname)='CLINICRANGE'
	    select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count 
	    from clinicRange 
	    where Class_id=@parid 	    
	    
    if upper(@dbname)='CUSTOMCATEGORY'  /*需要单独处理*/
    begin
	    select @szClassid=Class_id,@childnum=child_number,@childcount=Child_count
	    from customCategory 
	    where Class_id=@parid    
	    if @Parid='00' 
	    begin
			set @Childcount=@Childcount+1
			set @tempId=right(@childcount+100,2) 
			set @szClassid=@tempId
			set @childNum=@childNum+1
			Insert into @GetID(classid,ChildNumber,ChildCount)  
			values(@szClassid,@childNum,@ChildCount)
	    end 
	    else 
	    Begin		 
	      if not exists (select top 1 right(class_id,2) from customCategory 
		                     where  parent_id in (select id from customCategory where class_id=@parid)
		                           and deleted=0 order by id desc)
	      begin  
	        set @szClassid=@parid+'01'   
	      end
	      else
	      begin  
            select top 1 @tempId=right(class_id,2) from customCategory 
		                     where  parent_id in(select id from customCategory where class_id=@parid)
		                           and deleted=0 order by id desc  
		    select @count=cast(convert(binary(1), @tempId, 2) as int)+1/*16进制转换成10进制*/
	        set @tempId=convert(varchar, cast(@count as binary(1)), 2)/*10进制转换成16进制*/
	        set @szClassid=rtrim(@szClassid)+@tempId
		  end  
		    set @childNum=@childNum+1
		    Insert into @GetID(classid,ChildNumber,ChildCount)
	   	    values(@szClassid,@childNum,@ChildCount)    
	   end
	   	return
	end    	    	           	       
	if @ChildNum<999999
	begin
		if @Parid='000000' 
		begin
			set @Childcount=@Childcount+1
			set @tempId=right(@childcount+1000000,6) 
			set @szClassid=@tempId
			set @childNum=@childNum+1
			Insert into @GetID(classid,ChildNumber,ChildCount)  
			values(@szClassid,@childNum,@ChildCount)
		end else 
		Begin
			set @Childcount=@Childcount+1
			set @tempId=right(@childcount+1000000,6) 
			set @szClassid=rtrim(@szClassid)+@tempId
			set @childNum=@childNum+1
			Insert into @GetID(classid,ChildNumber,ChildCount)
			values(@szClassid,@childNum,@ChildCount)
		end
	end
		return
END
GO
