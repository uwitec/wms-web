
CREATE PROCEDURE ts_L_qrPriceChange 
(
@EndDate       varchar(50),/*查询时间*/
@SearchNo      int,
@SearchType    int,
@nYClassid     varchar(100)='',
@nloginEID     int=0,
@isaddDate     int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
@clientid      VARCHAR(10)='0'
)
AS
/*Params Ini begin*/
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0

/*Params Ini end*/

Declare @szsql varchar(8000)

  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),
          @szsql2  varchar(800)
  Declare @FilteCompany varchar(8000)                                                                        
 
  select  @FilteCompany=''


 create table #Companytable([id] int)
/*---分支机构授权*/

      set @Companytable=0

/*---分支机构授权*/

   
IF ISNULL(@Companytable,'')<>''    set @FilteCompany=' and ((BI.YClass_ID='''') or (exists(select YCID from '+@Companytable+' where BI.YClass_ID like YCID+''%''))) '/*只用于查询YProductDetail*/


IF @Searchtype=0 
begin
SET @szsql=
    'SELECT YPBM.*,isnull(P.[name],'''')Pname, ISNULL(U.[NAME],'''')unitname,isnull(c.[name],'''')cname,
            isnull(S.[name],'''')SSname,isnull(RE.[name],'''')ename
            ,isnull(P.standard,'''')standard,isnull(P.makearea,'''')makearea,isnull(P.Factory,'''')Factory,
            isnull(P.Custompro1,'''')Custompro1,isnull(P.Custompro2,'''')Custompro2,isnull(P.Custompro3,'''')Custompro3,
            isnull(P.Custompro4,'''')Custompro4,isnull(P.Custompro5,'''')Custompro5,isnull(P.pinyin,'''')pinyin 
     into #PriceChange FROM 
        (select bm.smb_id, bm.p_id,bm.unitid,bm.quantity,(bm.buyprice)price ,bi.billDate,bi.BillID,bi.billtype,
                bi.c_id,bm.RowE_id,BM.ss_id,bi.billnumber,bi.Inputman,bi.Y_id 
         from buymanagebill bm
         Inner join
         (select billDate,BillID,billtype,c_id,billnumber,Inputman,Y_id  
          from billidx where billDate<='''+@EndDate+''' and billtype in (20,122,220) and (c_id='''+@clientid+''' or 0='''+@clientid+''')
         )bi on bm.Bill_id=bi.billid
         where
         smb_id in (select top '+cast(@SearchNo as varchar(50))+' smb_id from buymanagebill bm1,billidx B where b.billid=bm1.bill_id and bm1.p_id=bm.p_id and bm1.AOID=0 and b.billtype in (20,122,220) order by smb_id desc)--zh100909  
        )YPBM
        LEFT JOIN Products  p  on p.product_id=YPBM.p_id
        LEFT JOIN employees RE on re.emp_id=YPBM.RowE_id
        LEFT JOIN storages  S  on S.storage_id=YPBM.ss_id
        LEFT JOIN Clients   C  on YPBM.c_id=c.client_id
        LEFT JOIN employees E  on YPBM.inputman=E.emp_id 
        LEFT JOIN Company   Y  on Y.Company_id=YPBM.y_id
        LEFT JOIN unit      U  on YPBM.unitid=U.unit_id
     WHERE
            ('''+@nYClassid+'''='''' or (YPBM.Y_id in (select company_id from Company where Class_id like '''+@nYClassid+'%''))) 
        and (('+@Companytable+'=0)or (YPBM.Y_id in (select [id] from #Companytable)))   
     order by YPBM.billDate Desc'



end
else
begin

SET @szsql=
    'SELECT YPBM.*,isnull(P.[name],'''')Pname, ISNULL(U.[NAME],'''')unitname,isnull(c.[name],'''')cname,
            isnull(S.[name],'''')SSname,isnull(RE.[name],'''')ename 
            ,isnull(P.standard,'''')standard,isnull(P.makearea,'''')makearea,isnull(P.Factory,'''')Factory,
            isnull(P.Custompro1,'''')Custompro1,isnull(P.Custompro2,'''')Custompro2,isnull(P.Custompro3,'''')Custompro3,
            isnull(P.Custompro4,'''')Custompro4,isnull(P.Custompro5,'''')Custompro5,isnull(P.pinyin,'''')pinyin  
     into #PriceChange FROM 
        (select bm.smb_id, bm.p_id,bm.unitid,bm.quantity,(bm.saleprice)price ,bi.billDate,bi.BillID,bi.billtype,
                bi.c_id,bm.RowE_id,BM.ss_id,bi.billnumber,bi.Inputman,bi.Y_id 
         from salemanagebill bm
         Inner join
         (select billDate,BillID,billtype,c_id,billnumber,Inputman,Y_id  
          from billidx where billDate<='''+@EndDate+''' and billtype in (10,12,112,210) and (c_id='''+@clientid+''' or 0='''+@clientid+''')
         )bi on bm.Bill_id=bi.billid
         where
         smb_id in (select top '+cast(@SearchNo as varchar(50))+' smb_id from salemanagebill bm1,billidx B where b.billid=bm1.bill_id and bm1.p_id=bm.p_id and bm1.AOID=0  and b.billtype in (10,12,112,210) order by smb_id desc)--zh100909 
        )YPBM
        LEFT JOIN Products  p  on p.product_id=YPBM.p_id
        LEFT JOIN employees RE on re.emp_id=YPBM.RowE_id
        LEFT JOIN storages  S  on S.storage_id=YPBM.ss_id
        LEFT JOIN Clients   C  on YPBM.c_id=c.client_id
        LEFT JOIN employees E  on YPBM.inputman=E.emp_id 
        LEFT JOIN Company   Y  on Y.Company_id=YPBM.y_id
        LEFT JOIN unit      U  on YPBM.unitid=U.unit_id
     WHERE
            ('''+@nYClassid+'''='''' or (YPBM.Y_id in (select company_id from Company where Class_id like '''+@nYClassid+'%''))) 
        and (('+@Companytable+'=0)or (YPBM.Y_id in (select [id] from #Companytable)))   
     order by YPBM.billDate Desc'
end

  SET @szsql= @szsql+'  
   select * from #PriceChange  where p_id in
        	(select p_id from 
	        	(select p_id,count(aa.ShowCount)as PriceCount
		         from 
			(select p_id,price,count(smb_id)as ShowCount from  #PriceChange group by p_id,price 
			)aa
	group by p_id 
	having count(aa.ShowCount)>1) bb) 
  order by p_id,billDate'
  print (@szsql)
  EXEC (@SZSQL)
GO
