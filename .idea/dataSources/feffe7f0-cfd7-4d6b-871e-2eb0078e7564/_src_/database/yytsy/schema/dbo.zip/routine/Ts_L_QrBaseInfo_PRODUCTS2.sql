
create PROCEDURE Ts_L_QrBaseInfo_PRODUCTS2
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,			/*这儿是仓库的id，但还有其它的用法*/
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找 6:在零成本库存余量显示总部库存余量*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0,
 @s_id int= 0       /*仓库的id*/
 )       
 AS

declare @sql varchar(8000), @szPname varchar(8000)
declare @sql2 varchar(8000),@sqlCheckSaleQty varchar(8000),@SaleQtyCol varchar(50)
DECLARE @PRICE VARCHAR(5000)

DECLARE @nCalcMode int
SELECT @nCalcMode = sysvalue FROM sysconfig WHERE sysname = 'CheckSaleQty'
select @sqlCheckSaleQty = ''
if @nCalcMode <> 0/*检测科开数量*/
begin
set @sqlCheckSaleQty = 'left join (select p_id,SUM(quantity) as saleqty from dbo.fn_getavlqty(0, '+ cast(@s_id as varchar)+', '''',3) group by p_id) sq on p.product_id = sq.p_id'
set @SaleQtyCol =',isnull(sq.saleqty,0) as saleqty'
end
else/*不检测时不调用这个函数，加快开单速度*/
begin
set @sqlCheckSaleQty = ''
set @SaleQtyCol =',ISNULL(sh.qty, 0)  as saleqty'
end



IF EXISTS(SELECT * FROM company WHERE swarajPrice = 1 and company_id=@nY_ID) AND @nY_ID > 2
	SET @PRICE = '(SELECT * FROM POSPRICE WHERE Y_ID = ' + CAST(@nY_ID AS VARCHAR(10)) + ' AND UNITTYPE = 1)'
ELSE
	SET @PRICE = '(select * from price a,#t WHERE a.p_id = #t.id and a.unittype = 1)'

set @szPname = @szName

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

	declare @sOQtySql varchar(8000)
	/* 零成本库存余量字段显示总部库存*/
	if @nFilterY = 6
		set @sOQtySql = 'SELECT     p_id, SUM(quantity) AS qty
									FROM          dbo.Storehouse
									WHERE      (y_id = 2)
									GROUP BY p_id'
	else
		set @sOQtySql = 'SELECT     p_id, SUM(quantity) AS qty
									FROM          dbo.OtherStorehouse
									WHERE      (y_id = '+ cast(@nY_id as varchar)+') AND (AOID = 5)
									GROUP BY p_id'

	if @E_id = 0
	begin
	 if @nFilterY=999 
	 begin
	        set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4) ' BUG33708、33709*/
			set @sql = @sql + '   SELECT  min(validdate) validdate ,p_id into #tt FROM dbo.storehouse  GROUP BY p_id    '
			set @sql2 = 
			'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
								  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
								  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
								  isnull(os.qty, 0) AS otherqty,isnull(#tt.validdate,0) as validdate '+@SaleQtyCol+'
			FROM         (select p1.*,  ISNULL(pr.retailprice, 0) AS retailprice, 
								 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
								 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
								 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
								 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 
							 from dbo.vw_Productscl p1
							 left join ' + @PRICE + ' pr On p1.product_id = pr.p_id		                         				                 
									  where p1.product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
									  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
									  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
										FROM          dbo.vw_productbalance
										WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
									  (SELECT     s.p_id, SUM(s.quantity) AS qty
										FROM          (SELECT     p_id, quantity, s_id
																FROM          dbo.storehouse where p_id in (select id from #t)) AS s INNER JOIN
															   dbo.AuthorizeStorage('+cast(@nLoginid as varchar)+') AS a ON s.s_id = a.Storage_ID
										GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
					  		LEFT JOIN #tt  ON p.product_id = #tt.P_ID 
					  		'+ @sqlCheckSaleQty +'	
							ORDER BY #tt.validdate,product_id
										
			drop table #t      
			drop table #tt'
			
	/*		print @sql + @sql2*/
			exec(@sql + @sql2)
	 end
	 else
	 begin
			set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4) ' BUG33708、33709*/
			set @sql = @sql + '   SELECT  min(validdate) validdate ,p_id into #tt FROM dbo.storehouse  GROUP BY p_id    '
			set @sql2 = 
			'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
								  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
								  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
								  isnull(os.qty, 0) AS otherqty,isnull(#tt.validdate,0) as validdate'+@SaleQtyCol+'
			FROM         (select p1.*,  ISNULL(pr.retailprice, 0) AS retailprice, 
								 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
								 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
								 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
								 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 
							 from dbo.vw_Products2 p1
							 left join ' + @PRICE + ' pr On p1.product_id = pr.p_id		                         				                 
									  where p1.product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
									  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
									  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
										FROM          dbo.vw_productbalance
										WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
									  (SELECT     s.p_id, SUM(s.quantity) AS qty
										FROM          (SELECT     p_id, quantity, s_id
																FROM          dbo.storehouse where p_id in (select id from #t)) AS s INNER JOIN
															   dbo.AuthorizeStorage('+cast(@nLoginid as varchar)+') AS a ON s.s_id = a.Storage_ID
										GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
					  		LEFT JOIN #tt  ON p.product_id = #tt.P_ID 
					  		'+ @sqlCheckSaleQty +'		 		
							ORDER BY #tt.validdate,product_id
										
			drop table #t      
			drop table #tt'
			
	/*		print @sql + @sql2*/
			exec(@sql + @sql2)
      end
	end
	else
	if @E_id = -100
	begin
	 if @nFilterY=999 
	 begin
		set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4)' BUG33708、33709*/
		set @sql = @sql + '   SELECT  min(validdate) validdate ,p_id into #tt FROM dbo.storehouse  GROUP BY p_id    '		
		set @sql2 = 
		'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
							  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
							  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
							  isnull(os.qty, 0) AS otherqty, isnull(#tt.validdate,0) as validdate '+@SaleQtyCol+'  
		FROM         (select p1.*,ISNULL(pr.retailprice, 0) AS retailprice, 
							 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
							 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
							 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
							 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 		
					  from dbo.vw_Productscl p1
		              left join ' + @PRICE + ' pr  on p1.product_id = pr.p_id		
		              where product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
								  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
								  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
									FROM          dbo.vw_productbalance
									WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
								  (SELECT     s.p_id, SUM(s.quantity) AS qty
									FROM          (SELECT     p_id, quantity, s_id
															FROM          dbo.storehouse '
		if @nY_ID = 2
			set @sql2 = @sql2 + ' inner join storages on storehouse.s_id = storages.storage_id where storages.flag = 0 '
		else
			set @sql2 = @sql2 + ' where y_id = '+ cast(@nY_id as varchar)
		set @sql2 = @sql2 +						' and p_id in (select id from #t)) AS s INNER JOIN
														   dbo.AuthorizeStorage('+cast(@nLoginid as varchar)+') AS a ON s.s_id = a.Storage_ID
									GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
					  	LEFT JOIN #tt  ON p.product_id = #tt.P_ID 
					  	'+ @sqlCheckSaleQty +'		 		
						ORDER BY #tt.validdate,product_id
									
		drop table #t      
		drop table #tt'
		
		/*print @sql + @sql2*/
		exec(@sql + @sql2)
	  end
	  else
	  begin
	     	set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4)' BUG33708、33709*/
		set @sql = @sql + '   SELECT  min(validdate) validdate ,p_id into #tt FROM dbo.storehouse  GROUP BY p_id    '		
		set @sql2 = 
		'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
							  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
							  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
							  isnull(os.qty, 0) AS otherqty, isnull(#tt.validdate,0) as validdate '+@SaleQtyCol+' 
		FROM         (select p1.*,ISNULL(pr.retailprice, 0) AS retailprice, 
							 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
							 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
							 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
							 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 		
					  from dbo.vw_Products2 p1
		              left join ' + @PRICE + ' pr  on p1.product_id = pr.p_id		
		              where product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
								  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
								  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
									FROM          dbo.vw_productbalance
									WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
								  (SELECT     s.p_id, SUM(s.quantity) AS qty
									FROM          (SELECT     p_id, quantity, s_id
															FROM          dbo.storehouse '
		if @nY_ID = 2
			set @sql2 = @sql2 + ' inner join storages on storehouse.s_id = storages.storage_id where storages.flag = 0 '
		else
			set @sql2 = @sql2 + ' where y_id = '+ cast(@nY_id as varchar)
		set @sql2 = @sql2 +						' and p_id in (select id from #t)) AS s INNER JOIN
														   dbo.AuthorizeStorage('+cast(@nLoginid as varchar)+') AS a ON s.s_id = a.Storage_ID
									GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
					  	LEFT JOIN #tt  ON p.product_id = #tt.P_ID 
					  	'+ @sqlCheckSaleQty +'		 		
						ORDER BY #tt.validdate,product_id
									
		drop table #t      
		drop table #tt'
		
		/*print @sql + @sql2*/
		exec(@sql + @sql2)
	  end
	end
	else
	begin
	 if @nFilterY=999 
	 begin
		set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4)' BUG33708、33709*/
		set @sql2 = 
		'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
							  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
							  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
							  isnull(os.qty, 0) AS otherqty, 0 as validdate '+@SaleQtyCol+' 
		FROM         (select p1.*, ISNULL(pr.retailprice, 0) AS retailprice, 
							 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
							 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
							 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
							 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice  
						from dbo.vw_Productscl p1
						left join ' + @PRICE + ' pr	 on p1.product_id = pr.p_id	
					   where product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
								  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
								  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
									FROM          dbo.vw_productbalance
									WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
								  (SELECT     s.p_id, SUM(s.quantity) AS qty
									FROM          (SELECT     p_id, quantity, s_id
															FROM          dbo.storehouse where s_id = ' + cast(@E_id as varchar) + '
															 and p_id in (select id from #t)) AS s
									GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
								left join (select p_id,SUM(quantity) as saleqty from dbo.fn_getavlqty(0, '+ cast(@E_id as varchar)+', '''',3) group by p_id) sq on p.product_id = sq.p_id
		drop table #t'
		/*print @sql + @sql2*/
		exec(@sql + @sql2)
	 end
	 else
	 begin
	   	set @sql = 'select product_id as id into #t from products where product_id in(' + @szPname + ') ' /*and deleted not in (3,4)' BUG33708、33709*/
		set @sql2 = 
		'SELECT     p.*, ISNULL(pb.locationid, 0) AS locationid, ISNULL(pb.WholeLoc, 0) AS wholeloc, ISNULL(pb.SingleLoc, 0) AS singleloc, ISNULL(pb.Supplier_id, 0) 
							  AS supplier_id, ISNULL(pb.Emp_id, 0) AS emp_id, ISNULL(pb.Locname, '''') AS locname, ISNULL(pb.WLocname, '''') AS Wlocname, 
							  ISNULL(pb.SLocname, '''') AS Slocname, ISNULL(pb.C_Name, '''') AS c_name, ISNULL(pb.e_name, '''') AS E_name, ISNULL(sh.qty, 0) AS qty, 
							  isnull(os.qty, 0) AS otherqty, 0 as validdate '+@SaleQtyCol+' 
		FROM         (select p1.*, ISNULL(pr.retailprice, 0) AS retailprice, 
							 cast(ISNULL(pr.recprice, 0)as numeric(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
							 ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
							 ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
							 ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice  
						from dbo.vw_Products2 p1
						left join ' + @PRICE + ' pr	 on p1.product_id = pr.p_id	
					   where product_id in (select id from #t)' + @szWhere + ') AS p LEFT OUTER JOIN
								  (' + @sOQtySql +') AS os ON p.product_id = os.p_id LEFT OUTER JOIN
								  (SELECT     p_id, locationid, WholeLoc, SingleLoc, Supplier_id, Emp_id, Y_id, Locname, WLocname, SLocname, C_Name, e_name, e_pinyin
									FROM          dbo.vw_productbalance
									WHERE      (Y_id = '+ cast(@nY_id as varchar)+') and p_id in (select id from #t)) AS pb ON p.product_id = pb.p_id LEFT OUTER JOIN
								  (SELECT     s.p_id, SUM(s.quantity) AS qty
									FROM          (SELECT     p_id, quantity, s_id
															FROM          dbo.storehouse where s_id = ' + cast(@E_id as varchar) + '
															 and p_id in (select id from #t)) AS s
									GROUP BY s.p_id) AS sh ON p.product_id = sh.p_id
								left join (select p_id,SUM(quantity) as saleqty from dbo.fn_getavlqty(0, '+ cast(@E_id as varchar)+', '''',3) group by p_id) sq on p.product_id = sq.p_id
		drop table #t'
		/*print @sql + @sql2*/
		exec(@sql + @sql2)
	 end
	end
GO
