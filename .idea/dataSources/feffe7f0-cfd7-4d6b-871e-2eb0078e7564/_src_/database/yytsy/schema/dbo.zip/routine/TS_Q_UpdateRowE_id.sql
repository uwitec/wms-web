
CREATE PROCEDURE TS_Q_UpdateRowE_id
(  
  @billid   int,
  @eid    int
)
AS
  SET NOCOUNT ON

BEGIN TRAN UpDateRowE_id

  update BillIdx set e_id=@eid where billid=@billid
if @@rowcount<=0
  goto Failure

  update productdetail set RowE_id =@eid  where billid = @billid and p_id > 0

  update salemanagebill set RowE_id =@eid  where bill_id = @billid and p_id > 0

  update buymanagebill  set RowE_id =@eid  where bill_id = @billid  and p_id > 0

  update storemanagebill  set RowE_id =@eid  where bill_id = @billid and p_id > 0

  GOTO SUCCEE

SUCCEE:
  COMMIT TRAN UpDateRowE_id
  RETURN 0 
Failure:
  ROLLBACK TRAN UpDateRowE_id
  RAISERROR('修改经手人失败！',16,1)
  RETURN -1
GO
