



CREATE PROCEDURE [dbo].[TS_H_WorkPlanIns] 
	@Act int,
	@ID int,
	@Dept int = 0,
	@Emp int = 0,
	@WorkDay datetime = '',
	@WorkPart int = 0,
	@OnDuty bit = 0,
	@MaxExam int = 0
AS
BEGIN
/*Params Ini begin*/
if @Dept is null  SET @Dept = 0
if @Emp is null  SET @Emp = 0
if @WorkDay is null  SET @WorkDay = ''
if @WorkPart is null  SET @WorkPart = 0
if @OnDuty is null  SET @OnDuty = 0
if @MaxExam is null  SET @MaxExam = 0
/*Params Ini end*/
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;

    /* Insert statements for procedure here*/
	if @Act = 0
	begin
		if exists(select * from employees where emp_id = @Emp and dep_id = @dept)
		begin
			if Exists(select * from WorkPlan where workday = @WorkDay
				and doctor_id = @emp and WorkPart_id = @WorkPart)
			begin
				raiserror('已安排此时间段！', 16, 1)
				return 0
			end
			else
			begin
				insert into workplan(
					[workDay],
					[doctor_id],
					[WorkPart_id],
					[onduty],
					[maxReg]
				) values(
					@WorkDay,
					@Emp,
					@WorkPart,
					@OnDuty,
					@MaxExam
				)
				if @@RowCount > 0
					Return @@Identity
				else
					Return 0
			end
		end
		else
		begin
			raiserror('职员不存在！', 16, 1)
			return 0
		end
	end
	else
	if @Act = 1
	begin
		if @workday < getdate()
		begin
			raiserror('不能安排以往的工作！', 16, 1)
			return 0
		end
		if Exists(select * from WorkPlan where workday = @WorkDay
			and doctor_id = @emp and WorkPart_id = @WorkPart and plan_id <> @ID)
		begin
			raiserror('已安排此时间段！', 16, 1)
			return 0
		end
		update workplan set
			[workDay] = @WorkDay,
			[doctor_id] = @Emp,
			[WorkPart_id] = @WorkPart,
			[onduty] = @OnDuty,
			[maxReg] = @MaxExam
		where plan_id = @ID
		return @ID
	end
	else
	if @Act = 2
	begin
		if @workday < getdate()
		begin
			raiserror('不能删除以往的工作！', 16, 1)
			return 0
		end
		if exists(select * from registered where regworkplan = @ID)
		begin
			raiserror('不能删除已挂号的工作计划！', 16, 1)
			return 0
		end
		delete from workplan where plan_id = @ID
		return @ID
	end
END
GO
