








CREATE	PROCEDURE [Ts_L_insShop]
	(@PosID 	[smallint],
	 @PosCode	[varchar](20),
	 @PosName	[varchar](50),
	 @S_ID	[int],
	 @C_ID	[int],
	 @RemotePath	[varchar](50),
	 @Comment	[varchar](50),
	 @ShopType	[tinyint])

AS 
if not exists(select * from shop where Posid=@posid) 
begin
	INSERT INTO [Shop] 
		 ( [PosCode],
		 [PosName],
		 [S_ID],
		 [C_ID],
		 [RemotePath],
		 [Comment],
		 [PosType]) 
	 
	VALUES 
		( @PosCode,
		 @PosName,
		 @S_ID,
		 @C_ID,
		 @RemotePath,
		 @Comment,
		 @shoptype)
 
	return @@IDENTITY
end else
begin
	if exists(select posid from billidx where posid=@posid) 
	begin
		Raiserror('已经有该门店的单据，不能修改!',16,1)
		return -1
	end

	if exists(select posid from TranIdx where posid=@posid)
	begin
		Raiserror('已经有该门店的单据，不能修改！',16,1)
		return -1
	end

	 UPDATE [Shop] 
	
	SET  [PosCode]	 = @PosCode,
		 [PosName]	 = @PosName,
		 [S_ID]  = @S_ID,
		 [C_ID]  = @C_ID,
		 [RemotePath]	 = @RemotePath,
		 [Comment]	 = @Comment ,
		 [PosType]	 = @ShopType
	
	WHERE 
		( [PosID]	 = @PosID)
	return 0
end
GO
