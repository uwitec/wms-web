
CREATE VIEW dbo.vw_h_department
AS
SELECT     departmentId, serial_number, name, comment, deleted, ModifyDate, pinyin, Type_ID, CAST(Type_ID AS bit) AS IsExam
FROM         dbo.department
GO
