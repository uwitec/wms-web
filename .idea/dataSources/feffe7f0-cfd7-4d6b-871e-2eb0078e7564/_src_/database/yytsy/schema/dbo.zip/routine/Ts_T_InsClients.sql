 Create procedure [dbo].[Ts_T_InsClients]
 (                      
   @c_id int,
   @nid int,
   @nRpid int /*协议id*/
 ) 
AS
if @nid=0
begin
	insert  flprovider([RP_id],[C_id])		       
	values( @nRpid,
			@c_id		 
		  )  
end else
begin
declare @cid int
  select @cid=C_id from flprovider where id=@nid
  if @cid<>@c_id 
  begin
    delete flprovider where id=@nid 
    insert  flprovider([RP_id],[C_id])		       
	values( @nRpid,
			@c_id		 
		  )  
  end
end
return 0
 GO
