create procedure [dbo].[ts_e_StoreWMSCheckInsBaseInfo]
 @S_id  integer=0,/*仓库ID*/
 @Code varchar(100)='',/*复核台编号*/
 @Name varchar(100)='',/*复核台名称*/
 @PinYin     varchar(100)='',/*拼音码*/
 @Deleted   integer=0,/*停用状态*/
 @BillNum   [numeric](25,8),/*活动单据数*/
 @GroupNum  varchar(100)='',/*复核台分组编号*/
 @WorkNum   [numeric](25,8)=0,/*工作量*/
 @IfHold    integer=0 ,/*允许虚拟暂存区--修改为是否是双人审核的值*/
 @InsOrUpdate   varchar(50) ,/*判断是新增还是修改*/
 @id    integer=0,/*复核台ID（用于修改）*/
 @nRet  int OUTPUT,/*新增成功后返回自增列ID*/
 @NewCode     varchar(2000) OUTPUT/*返回新的复核台编号（连续添加生成新的编号）*/
as
declare @Newcodestr varchar(2000)
declare @i  integer
if @Deleted=1 set @Deleted=2
begin
 if @InsOrUpdate='Ins'
 begin
   insert into  WMSCheckBaseInfo(s_id,code,name,pinyin, GroupCode,deleted,WorkNum,IfHold,DoubleCheck)
   values(@s_id,@Code,@Name,@PinYin,@GroupNum,@Deleted,@WorkNum,0,@IfHold)
   set  @nRet= @@IDENTITY
   select @Newcodestr=dbo.GetWMSHWCode(1,@Code) 
   set @i=0
   while @i=0 
   begin
      if exists (select 1 from WMSHold  where code =@Newcodestr and deleted=0)
      begin
        select @Newcodestr=dbo.GetWMSHWCode(1,@Newcodestr)  
      end
      else
      begin
        set @i=1
      end
   end
   set @NewCode=@Newcodestr
 end
 else
 begin
   update WMSCheckBaseInfo  set s_id=@s_id,Code=@Code,name=@Name,pinyin=@PinYin,
   deleted=@Deleted, GroupCode=@GroupNum,WorkNum=@WorkNum,DoubleCheck=@IfHold WHERE id=@id
   IF @@ERROR = 0 
   BEGIN
       set @nRet=1
   END
 end
end
GO
