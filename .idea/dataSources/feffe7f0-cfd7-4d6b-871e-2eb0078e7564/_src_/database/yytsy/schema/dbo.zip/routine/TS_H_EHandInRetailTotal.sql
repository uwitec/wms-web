
CREATE PROCEDURE TS_H_EHandInRetailTotal
(
 @beginDate    datetime = 0,
 @endDate      datetime = 0,
 @SaleMan      varchar(30) = '',
 @gatheringMan varchar(30) = '',
 @GroupMode    int = 0, /*汇总方式 0 按收银员 1 销售员 2 机构 3零售单号 4 按时间段汇总*/
 @nloginEID    int=0,
 @szYclass_id  varchar(30) = '',
 @nPubOffline  int = 0
 )
AS
/*Params Ini begin*/
if @beginDate is null  SET @beginDate = 0
if @endDate is null  SET @endDate = 0
if @SaleMan is null  SET @SaleMan = ''
if @gatheringMan is null  SET @gatheringMan = ''
if @GroupMode is null  SET @GroupMode = 0
if @nloginEID is null  SET @nloginEID = 0
if @szYclass_id is null  SET @szYclass_id = ''
if @nPubOffline is null  SET @nPubOffline = 0
/*Params Ini end*/
/*初始化条件*/

IF @GroupMode = 0 /*收银员 --即制单员*/
BEGIN  
  SELECT @gatheringMan = @SaleMan
  IF (@gatheringMan = '') or (@gatheringMan = '000000') SELECT @gatheringMan = '%%' ELSE SELECT @gatheringMan = @gatheringMan + '%'  
  SET @SaleMan = '%%'      
END ELSE
IF @GroupMode = 1 /*销售员 --即经手人*/
BEGIN
  IF (@SaleMan = '') or (@SaleMan = '000000') SELECT @SaleMan = '%%' ELSE SELECT @SaleMan = @SaleMan + '%'
  SELECT @gatheringMan = '%%'    
END ELSE
IF @GroupMode = 2 /* 机构*/
BEGIN
/*@SaleMan 传入的表示选择的职员*/
  IF (@SaleMan = '') or (@SaleMan = '000000') SELECT @SaleMan = '%%' ELSE SELECT @SaleMan = @SaleMan + '%'
  /*SELECT @gatheringMan = '%%'    */
END
IF @GroupMode = 3 /* 零售单号*/
BEGIN
/*@SaleMan 传入的表示选择的职员*/
  IF (@SaleMan = '') or (@SaleMan = '000000') SELECT @SaleMan = '%%' ELSE SELECT @SaleMan = @SaleMan + '%'
  /*SELECT @gatheringMan = '%%'    */
END
IF @GroupMode = 4 /* 按时间段汇总*/
BEGIN
/*@SaleMan 传入的表示选择的职员*/
  IF (@SaleMan = '') or (@SaleMan = '000000') SELECT @SaleMan = '%%' ELSE SELECT @SaleMan = @SaleMan + '%'
  /*SELECT @gatheringMan = '%%'    */
END



DECLARE @nY_id int
IF @szYclass_id<>''  select @nY_id=(select company_id from company where class_id=@szYclass_id)
ELSE select @nY_id = 0

/*IF (@SaleMan = '') or (@SaleMan = '000000') SELECT @SaleMan = '%%' ELSE SELECT @SaleMan = @SaleMan + '%'*/
/*IF (@gatheringMan = '') or (@gatheringMan = '000000') SELECT @gatheringMan = '%%' ELSE SELECT @gatheringMan = @gatheringMan + '%'*/

DECLARE @SQLScript   VARCHAR(8000)
DECLARE @SQLScript1  VARCHAR(8000)
DECLARE @SQLScript2  VARCHAR(8000)

DECLARE @BankClassID      VARCHAR(300)
DECLARE @BankName         VARCHAR(300)
DECLARE @FieldName        VARCHAR(80) 
DECLARE @FieldNameHead    VARCHAR(30)
DECLARE @FieldNameCounter INT

DECLARE @SQL1	     VARCHAR(8000)
DECLARE @SQL2	     VARCHAR(8000)
DECLARE @SQL3	     VARCHAR(8000)
DECLARE @SQL4	     VARCHAR(8000)

  Declare @employeestable integer
  create table #employeestable([id] int)
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


  Declare @Companytable INTEGER
  create table #Companytable([id] int)

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*初始化变量*/
SELECT @SQLScript = '',@SQL1 = '',@SQL2 = '',@SQL3 = '',@SQL4 = ''
/*使用银行名字作为字段名，会因为名字中存在非法字符或名字过长出错*/

DECLARE @SQLElse	     VARCHAR(8000)  /*按时间段汇总的汇总动态列*/
set @SQLElse = ''

SELECT @FieldNameHead = 'FIELD_NAME',@FieldNameCounter = 1
SELECT @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
/*游标取得银行帐户的动态Sql*/
DECLARE BankSubject_cursor CURSOR FOR
SELECT  name,class_id
FROM    vw_Account
WHERE 	class_id Like '000001000004%' and Child_number = 0 or class_id='000002000006' or class_id='000004000003000008' or class_id='000004000003000009' 
        or class_id='000001000012' or class_id='000001000013' or class_id='000001000014'
ORDER BY [Class_ID] DESC  

OPEN BankSubject_cursor

FETCH NEXT FROM BankSubject_cursor
INTO @BankName,@BankClassID


WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @BankName = REPLACE(@BankName,' ','')/*去除名字中的空格字符*/
	SET @SQL1 = @SQL1 + ' ISNULL(SUM(ABS(RB.['+@FieldName+'])),0) AS ['+@FieldName+'],'
	SET @SQL2 = @SQL2 + 'AD.['+       @FieldName+'] AS ['+       @FieldName+'],'
	SET @SQL3 = @SQL3 + 'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
                            ') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
                            
    IF @GroupMode = 4
    begin
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'
    end
	SET @FieldNameCounter = @FieldNameCounter + 1
	SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)

	SET @SQL1 = @SQL1 + ' ISNULL(SUM(abs(RB.['+@FieldName+'])),0) AS ['+@FieldName+'],'
	SET @SQL2 = @SQL2 + 'AD.['+@FieldName+'] AS ['+@FieldName+'],'
	SET @SQL3 = @SQL3 + 'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
                            ') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
                            
    IF @GroupMode = 4
    begin
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'
    end

/* 现金、银行合计*/
	SET @FieldNameCounter = @FieldNameCounter + 1
	SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)

/*	SET @SQL1 = @SQL1 + ' -ISNULL(SUM(RB.['+@FieldName+']),0) AS ['+@FieldName+'],'*/
        if @bankclassid='000002000006'
          SET @SQL1 = @SQL1 + ' ISNULL(SUM(-RB.['+@FieldName+']),0) AS ['+@FieldName+'],'
        else
          SET @SQL1 = @SQL1 + ' ISNULL(SUM(RB.['+@FieldName+']),0) AS ['+@FieldName+'],' 

	SET @SQL2 = @SQL2 + ' AD.['+@FieldName+'] AS ['+@FieldName+'],'
	SET @SQL3 = @SQL3 + ' ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+ @BankClassID +CHAR(39) + 
                            ') THEN JDMONEY ELSE 0 END),0) AS ['+@FieldName+ '],'
                            
    IF @GroupMode = 4
    begin
		SET @SQLElse = @SQLElse + ' ISNULL(SUM('+@FieldName+'),0) AS ['+@FieldName+'],'
    end                            
/*现金、银行合计*/

	SET @FieldNameCounter = @FieldNameCounter + 1
	SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
 
  /* ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '000001000004%') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,*/
	FETCH NEXT FROM BankSubject_cursor
	INTO @BankName,@BankClassID
END

CLOSE BankSubject_cursor
DEALLOCATE BankSubject_cursor 
/*游标取得银行帐户的动态Sql END*/


IF @GroupMode = 0 /*按收银员汇总*/
BEGIN
SET @SQLScript = 
'SELECT  0  AS  SerialNo, rb.billdate,'
+'E.EMP_ID  AS   EMP_ID,'
+' E.NAME   AS  EName,'
+' E.Serial_number  AS  ESerial_Number,'
+' E.Class_id  AS  EClass_id,'
+' E.DepName  AS  DepName,'
+' E.deduct   AS  deduct,'
+' ISNULL(SUM(RB.YsMoney),0)  	AS YsMoney,'  
+' ISNULL(SUM(RB.YfMoney),0)  	AS YfMoney,'  
+' ISNULL(SUM(RB.Quantity),0)  	AS Quantity,'
+' ISNULL(SUM(RB.SaleMoney),0)  AS SaleMoney,'
+' ISNULL(SUM(RB.TotalMoney),0)  AS TotalMoney,'
+' ISNULL(SUM(RB.BackQuantity),0)  AS BackQuantity,'
+' ISNULL(SUM(RB.BackTotalMoney),0) AS BackTotalMoney,'
+' ISNULL(SUM(RB.TaxTotal),0) AS TaxTotal,'
+' ISNULL(SUM(RB.BackTaxTotal),0) AS BackTaxTotal,'
+' ISNULL(SUM(RB.BillDiscount),0)  AS BillDiscount,'
+' ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,'
+' ISNULL(SUM(RB.CashMoney),0)  AS CashMoney,'
+' -ISNULL(SUM(RB.BackCashMoney),0) AS BackCashMoney,'
SET @SQLScript = @SQLScript + @SQL1
+' ISNULL(SUM(RB.DiscountMoney),0)  AS DiscountMoney,'
+' ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY+RB.WXMONEY+RB.ZFBMONEY+RB.YBTCMONEY),0) AS  skTotalMoney,'
+' -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY+RB.BackWXMONEY+RB.BackZFBMONEY+RB.BackYBTCMONEY),0) AS  fkTotalMoney,'
+' ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)         AS ssTaxTotal,'                                   /*含税合计*/
+' ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0) AS ssBillDisCount,'                               /*折让合计*/
+' ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)            AS ssYsMoney,'                                       /*应收合计*/
+' ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0) AS  ssCashTotalMoney,'                                 /*现金收款合计*/
+' ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0) AS  ssBankTotalMoney,'                                 /*银行收款合计*/
+' ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY+RB.WXMONEY-RB.BackWXMONEY+RB.ZFBMONEY-BackZFBMONEY+RB.YBTCMONEY-BackYBTCMONEY),0) AS  ssTotalMoney'     /*合计收款*/
+' FROM (SELECT * FROM VW_EMPLOYEE WHERE (Child_number = 0) ' 
+' and ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0  or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'
+' and ('+cast(@Companytable as varchar(10))+'=0 or Y_id in (select [id] from #Companytable))'
+' and ('+cast(@employeestable as varchar(10))+'=0 or emp_id in (select [id] from #employeestable))) E'
+' LEFT JOIN( '
+' SELECT'
+' RI.BillID AS BillID, ri.billdate as billdate,'
+' RI.E_ID AS E_ID,'
+' RI.EClass_Id AS EClass_ID,' 
+' RI.InputMan  AS InputMan,'
+' RI.InputManClass_Id  AS InputManClass_Id,'
+' CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,' 
+' CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney,' 
+' RB.quantity      AS Quantity,'
+' RB.SaleMoney     AS SaleMoney,'
+' RB.TotalMoney    AS TotalMoney,'
+' RB.Backquantity  AS BackQuantity,'
+' RB.BackTotalMoney AS BackTotalMoney,' 
+' RB.TaxTotal AS TaxTotal,' 
+' RB.BackTaxTotal AS BackTaxTotal,' 
+' AD.BillDiscount  AS BillDiscount,'
+' AD.BackBillDiscount  AS BackBillDiscount,'
+' AD.CashMoney     AS CashMoney,'
+' AD.BackCashMoney AS BackCashMoney,'
+' AD.BankMoney     AS BankMoney,'
+' AD.BackBankMoney AS BackBankMoney,'
+' AD.CZZKMONEY     AS CZZKMONEY,'
+' AD.BACKCZZKMONEY AS BACKCZZKMONEY,'
+' AD.DJQMONEY     AS DJQMONEY,'
+' AD.BACKDJQMONEY AS BACKDJQMONEY,'
+' AD.JFDXMONEY     AS JFDXMONEY,'
+' AD.BACKJFDXMONEY AS BACKJFDXMONEY,'
+' AD.WXMONEY AS WXMONEY,'
+' AD.BackWXMONEY AS BackWXMONEY,'
+' AD.ZFBMONEY AS ZFBMONEY,'
+' AD.BackZFBMONEY AS BackZFBMONEY,'
+' AD.YBTCMONEY AS YBTCMONEY,'
+' AD.BackYBTCMONEY AS BackYBTCMONEY,'
SET @SQLScript1 =
'        CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney'
+' FROM (SELECT * FROM VW_X_BILLIDX WHERE' 
+' EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)
+' AND [BillStates] IN (0) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'
+' AND InputManClass_Id LIKE '+CHAR(39)+@gatheringMan + CHAR(39)
+' AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR)+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR)+CHAR(39)
+'  ) RI' 
+' LEFT JOIN (SELECT BI.BILLId,' 
+' ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)   as Quantity,'
+' ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0) as saleMoney,'
+' ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0) as TotalMoney,'
+' ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0) as TaxTotal,'
+' ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0) as BackTaxTotal,'
+' ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)   as BackQuantity,'
+' ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0) as BackTotalMoney'
+' FROM billidx BI' 
+' LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id' 
+' WHERE BI.BILLTYPE in(12,13) AND AOID IN (0,5) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'      
+' GROUP BY BI.BILLID'
 
+' ) RB ON RI.BillID = RB.BillID'
 
+' LEFT JOIN (SELECT  BI.BILLId,'
       
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype =12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype =13)THEN  JDMONEY ELSE 0 END),0)  AS BackBILLDISCOUNT,'
SET @SQLScript2 = 
' ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,' 

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,'

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,'

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY,'

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS WXMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackWXMONEY,'

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS ZFBMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackZFBMONEY,'

+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS YBTCMONEY,'
+'   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackYBTCMONEY'

+'   FROM BILLIDX BI' 
+'   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID' 
+'              WHERE BI.BILLTYPE in(12,13) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')' 
+'        GROUP BY BI.BILLID'   
+' ) AD ON RI.BillID = AD.BillID'
+' WHERE RI.BillType in(12,13)'
+' ) RB ON E.EMP_ID = RB.InputMan'
+' WHERE E.Class_id LIKE '+CHAR(39)+@gatheringMan +CHAR(39)+
' GROUP BY E.EMP_ID,rb.billdate,E.NAME,E.Serial_number,E.Class_id,E.DepName,E.deduct'
/*PRINT @SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2*/
/*pRINT lEN(@SQLScript)*/
/*pRINT lEN(@SQLScript1)*/
/*pRINT lEN(@SQLScript2)*/
/*print (@SQLScript+ @SQL2)*/
/*print(@SQLScript1+ @SQL3)*/
/*print (@SQLScript2)*/
EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2)
END
ELSE IF @GroupMode = 1 /*按销售员汇总*/
BEGIN
SET @SQLScript = '
SELECT  0   AS  SerialNo,
  rb.billdate,
 E.EMP_ID  AS   EMP_ID,
 E.NAME   AS  EName,
 E.Serial_number  AS  ESerial_Number,
 E.Class_id  AS  EClass_id,
 E.DepName  AS  DepName,
 E.deduct   AS  deduct,
 ISNULL(SUM(RB.YsMoney),0)  		AS YsMoney,  
 ISNULL(SUM(RB.YfMoney),0)  		AS YfMoney,  
 ISNULL(SUM(RB.Quantity),0)  		AS Quantity,
 ISNULL(SUM(RB.SaleMoney),0)  		AS SaleMoney,
 ISNULL(SUM(RB.TotalMoney),0)  		AS TotalMoney,
 ISNULL(SUM(RB.BackQuantity),0)  	AS BackQuantity,
 ISNULL(SUM(RB.BackTotalMoney),0) 	AS BackTotalMoney,
 ISNULL(SUM(RB.TaxTotal),0)             AS TaxTotal,
 ISNULL(SUM(RB.BackTaxTotal),0)         AS BackTaxTotal,
 ISNULL(SUM(RB.BillDiscount),0)         AS BillDiscount,
 ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,
 ISNULL(SUM(RB.CashMoney),0)  		AS CashMoney,
 -ISNULL(SUM(RB.BackCashMoney),0) 	AS BackCashMoney,'
SET @SQLScript = @SQLScript+ @SQL1 + '
 ISNULL(SUM(RB.DiscountMoney),0)  	AS DiscountMoney,
 ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY+RB.WXMONEY+RB.ZFBMONEY+RB.YBTCMONEY),0)     	AS  skTotalMoney,
 -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY+RB.BackWXMONEY+BackZFBMONEY+BackYBTCMONEY),0)    AS  fkTotalMoney,
 ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)            AS  ssTaxTotal,                            
 ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0)    AS  ssBillDisCount,                        
 ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)               AS  ssYsMoney,                             
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0)     	AS  ssCashTotalMoney,
 ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0)     	AS  ssBankTotalMoney,
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY+RB.WXMONEY-RB.BackWXMONEY+RB.ZFBMONEY-BackZFBMONEY+RB.YBTCMONEY-BackYBTCMONEY),0) AS  ssTotalMoney
FROM (SELECT * FROM VW_EMPLOYEE 
      WHERE (Child_number = 0) 
      AND ('+cast(@Companytable as varchar(10))+'=0 or Y_id in (select [id] from #Companytable))'
+' and ('+cast(@employeestable as varchar(10))+'=0 or emp_id in (select [id] from #employeestable))) E 
LEFT JOIN( 
 SELECT
        RI.BillID        AS BillID,
        ri.billdate,
        RI.E_ID        	 AS E_ID,
        RI.EClass_Id     AS EClass_ID, 
        RI.InputMan      AS InputMan,
        RI.InputManClass_Id     AS InputManClass_Id, 
        CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,
        CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney, 
        RB.quantity           AS Quantity,
        RB.SaleMoney          AS SaleMoney,
        RB.TotalMoney         AS TotalMoney,
        RB.Backquantity       AS BackQuantity,
        RB.BackTotalMoney     AS BackTotalMoney,
        RB.TaxTotal           AS TaxTotal,
        RB.BackTaxTotal       AS BackTaxTotal, 
        AD.BillDiscount       AS BillDiscount,
        AD.BackBillDiscount   AS BackBillDiscount,
        AD.CashMoney          AS CashMoney,
        AD.BackCashMoney      AS BackCashMoney,
        AD.BankMoney          AS BankMoney,
        AD.BackBankMoney      AS BackBankMoney,
        AD.CZZKMONEY          AS CZZKMONEY,
        AD.BackCZZKMONEY      AS BackCZZKMONEY,
        AD.DJQMONEY          AS DJQMONEY,
        AD.BackDJQMONEY      AS BackDJQMONEY,
        AD.JFDXMONEY          AS JFDXMONEY,
        AD.BackJFDXMONEY      AS BackJFDXMONEY,
        AD.WXMONEY            AS WXMONEY,
        AD.BackWXMONEY        AS BackWXMONEY,
        AD.ZFBMONEY           AS ZFBMONEY,
        AD.BackZFBMONEY       AS BackZFBMONEY,  
        AD.YBTCMONEY           AS YBTCMONEY,
        AD.BackYBTCMONEY       AS BackYBTCMONEY,'        
SET @SQLScript1 = ' 
        CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney
 FROM (SELECT * FROM VW_X_BILLIDX 
       WHERE EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)+' 
       AND [BillStates] IN (0) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')
       AND InputManClass_Id LIKE '+CHAR(39)+@gatheringMan + CHAR(39)+'
       AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR)+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR)+CHAR(39)+'
      ) RI 
 LEFT JOIN (SELECT BI.BILLId,bi.billdate, 
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)                  as Quantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0)  as saleMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0)                as TotalMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0)                  as TaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)                  as BackQuantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0)                  as BackTaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0)                as BackTotalMoney
           FROM billidx BI 
           LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id 
           WHERE BI.BILLTYPE in(12,13) AND AOID IN (0,5) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or bi.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')     
           GROUP BY BI.BILLID,bi.billdate
 
           ) RB ON RI.BillID = RB.BillID
 
 LEFT JOIN (SELECT  BI.BILLId,
       
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 13) THEN JDMONEY ELSE 0 END),0) AS BackBILLDISCOUNT,'

SET @SQLScript2 = 
  'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY,
   
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS WXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackWXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS ZFBMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackZFBMONEY,   
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS YBTCMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackYBTCMONEY   
 
   FROM BILLIDX BI 
   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID 
   WHERE BI.BILLTYPE in(12,13) and ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')
   GROUP BY BI.BILLID   
 ) AD ON RI.BillID = AD.BillID
 WHERE RI.BillType in(12,13)
) RB ON E.EMP_ID = RB.E_ID
WHERE E.Class_id LIKE '+CHAR(39)+@SaleMan +CHAR(39)+
' GROUP BY E.EMP_ID,E.NAME,E.Serial_number,E.Class_id,E.DepName,E.deduct,rb.billdate ' 
/*PRINT @SQLScript*/
/*pRINT lEN(@SQLScript)*/
/*print(@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2)*/
EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2)
END
ELSE IF @GroupMode = 2
begin
SET @SQLScript = '
SELECT  0   AS  SerialNo,
  rb.billdate,
 E.company_id  AS   EMP_ID,
 E.NAME   AS  EName,
 E.Serial_number  AS  ESerial_Number,
 E.Class_id  AS  EClass_id,
 E.opaddress  AS  DepName,
 0   AS  deduct,
 ISNULL(SUM(RB.YsMoney),0)  		AS YsMoney,  
 ISNULL(SUM(RB.YfMoney),0)  		AS YfMoney,  
 ISNULL(SUM(RB.Quantity),0)  		AS Quantity,
 ISNULL(SUM(RB.SaleMoney),0)  		AS SaleMoney,
 ISNULL(SUM(RB.TotalMoney),0)  		AS TotalMoney,
 ISNULL(SUM(RB.BackQuantity),0)  	AS BackQuantity,
 ISNULL(SUM(RB.BackTotalMoney),0) 	AS BackTotalMoney,
 ISNULL(SUM(RB.TaxTotal),0)             AS TaxTotal,
 ISNULL(SUM(RB.BackTaxTotal),0)         AS BackTaxTotal,
 ISNULL(SUM(RB.BillDiscount),0)         AS BillDiscount,
 ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,
 ISNULL(SUM(RB.CashMoney),0)  		AS CashMoney,
 -ISNULL(SUM(RB.BackCashMoney),0) 	AS BackCashMoney,'
SET @SQLScript = @SQLScript+ @SQL1 + '
 ISNULL(SUM(RB.DiscountMoney),0)  	AS DiscountMoney,
 ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY+RB.WXMONEY+RB.ZFBMONEY+RB.YBTCMONEY),0)     	AS  skTotalMoney,
 -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY+RB.BackWXMONEY+BackZFBMONEY+BackYBTCMONEY),0)    AS  fkTotalMoney,
 ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)            AS  ssTaxTotal,                            
 ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0)    AS  ssBillDisCount,                        
 ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)               AS  ssYsMoney,                             
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0)     	AS  ssCashTotalMoney,
 ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0)     	AS  ssBankTotalMoney,
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY+RB.WXMONEY-RB.BackWXMONEY+RB.ZFBMONEY-BackZFBMONEY+RB.YBTCMONEY-BackYBTCMONEY),0) AS  ssTotalMoney
FROM (SELECT * from  vw_L_Company VC 
      WHERE (vc.Child_number = 0) and vc.Deleted = 0
      AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or company_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'
+' and ('+cast(@Companytable as varchar(10))+'=0 or company_id in (select [id] from #Companytable))) E 
LEFT JOIN( 
 SELECT
        ri.Y_ID,
        RI.BillID        AS BillID,
        ri.billdate,
        CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,
        CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney, 
        RB.quantity           AS Quantity,
        RB.SaleMoney          AS SaleMoney,
        RB.TotalMoney         AS TotalMoney,
        RB.Backquantity       AS BackQuantity,
        RB.BackTotalMoney     AS BackTotalMoney,
        RB.TaxTotal           AS TaxTotal,
        RB.BackTaxTotal       AS BackTaxTotal, 
        AD.BillDiscount       AS BillDiscount,
        AD.BackBillDiscount   AS BackBillDiscount,
        AD.CashMoney          AS CashMoney,
        AD.BackCashMoney      AS BackCashMoney,
        AD.BankMoney          AS BankMoney,
        AD.BackBankMoney      AS BackBankMoney,
        AD.CZZKMONEY          AS CZZKMONEY,
        AD.BackCZZKMONEY      AS BackCZZKMONEY,
        AD.DJQMONEY          AS DJQMONEY,
        AD.BackDJQMONEY      AS BackDJQMONEY,
        AD.JFDXMONEY          AS JFDXMONEY,
        AD.BackJFDXMONEY      AS BackJFDXMONEY,
        AD.WXMONEY            AS WXMONEY,
        AD.BackWXMONEY        AS BackWXMONEY,
        AD.ZFBMONEY           AS ZFBMONEY,
        AD.BackZFBMONEY       AS BackZFBMONEY,  
        AD.YBTCMONEY          AS YBTCMONEY,
        AD.BackYBTCMONEY      AS BackYBTCMONEY,'    
SET @SQLScript1 = ' 
        CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney
 FROM (SELECT * FROM VW_X_BILLIDX 
       WHERE EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)+' 
       AND [BillStates] IN (0) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')

       AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR(10))+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR(10))+CHAR(39)+'
      ) RI 
 LEFT JOIN (SELECT BI.BILLId,bi.billdate, 
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)                  as Quantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0)  as saleMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0)                as TotalMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0)                  as TaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)                  as BackQuantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0)                  as BackTaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0)                as BackTotalMoney
           FROM billidx BI 
           LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id 
           WHERE BI.BILLTYPE in(12,13) AND AOID IN (0,5) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or bi.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')     
           GROUP BY BI.BILLID,bi.billdate
 
           ) RB ON RI.BillID = RB.BillID
 
 LEFT JOIN (SELECT  BI.BILLId,
       
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 13) THEN JDMONEY ELSE 0 END),0) AS BackBILLDISCOUNT,'

SET @SQLScript2 = 
  'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS WXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackWXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS ZFBMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackZFBMONEY,  
   
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS YBTCMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackYBTCMONEY  
 
   FROM BILLIDX BI 
   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID 
   WHERE BI.BILLTYPE in(12,13) and ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')
   GROUP BY BI.BILLID   
 ) AD ON RI.BillID = AD.BillID
 WHERE RI.BillType in(12,13)
) RB ON E.company_id = RB.y_id
  and rb.billdate > 0 and rb.billdate > 0  
GROUP BY E.company_id,E.NAME,E.Serial_number,E.Class_id,E.opaddress,rb.billdate 
ORDER BY E.company_id,billdate ' 

EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2) 
end
ELSE IF @GroupMode = 3  /*零售单号*/
BEGIN
SET @SQLScript = '
SELECT  0   AS  SerialNo,
  rb.billdate,
 E.company_id  AS   EMP_ID,
 rb.billnumber   AS  EName,
 rb.BillID  AS  ESerial_Number,'+CHAR(39)+CHAR(39)+
 ' AS  EClass_id,
 E.opaddress  AS  DepName,
 0   AS  deduct,
 ISNULL(SUM(RB.YsMoney),0)  		AS YsMoney,  
 ISNULL(SUM(RB.YfMoney),0)  		AS YfMoney,  
 ISNULL(SUM(RB.Quantity),0)  		AS Quantity,
 ISNULL(SUM(RB.SaleMoney),0)  		AS SaleMoney,
 ISNULL(SUM(RB.TotalMoney),0)  		AS TotalMoney,
 ISNULL(SUM(RB.BackQuantity),0)  	AS BackQuantity,
 ISNULL(SUM(RB.BackTotalMoney),0) 	AS BackTotalMoney,
 ISNULL(SUM(RB.TaxTotal),0)             AS TaxTotal,
 ISNULL(SUM(RB.BackTaxTotal),0)         AS BackTaxTotal,
 ISNULL(SUM(RB.BillDiscount),0)         AS BillDiscount,
 ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,
 ISNULL(SUM(RB.CashMoney),0)  		AS CashMoney,
 -ISNULL(SUM(RB.BackCashMoney),0) 	AS BackCashMoney,'
SET @SQLScript = @SQLScript+ @SQL1 + '
 ISNULL(SUM(RB.DiscountMoney),0)  	AS DiscountMoney,
 ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY+RB.WXMONEY+RB.ZFBMONEY+RB.YBTCMONEY),0)     	AS  skTotalMoney,
 -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY+RB.BackWXMONEY+BackZFBMONEY+BackYBTCMONEY),0)    AS  fkTotalMoney,
 ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)            AS  ssTaxTotal,                            
 ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0)    AS  ssBillDisCount,                        
 ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)               AS  ssYsMoney,                             
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0)     	AS  ssCashTotalMoney,
 ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0)     	AS  ssBankTotalMoney,
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY+RB.WXMONEY-RB.BackWXMONEY+RB.ZFBMONEY-BackZFBMONEY+RB.YBTCMONEY-BackYBTCMONEY),0) AS  ssTotalMoney
FROM (SELECT * from  vw_L_Company VC 
      WHERE (vc.Child_number = 0) and vc.Deleted = 0
      AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or company_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'
+' and ('+cast(@Companytable as varchar(10))+'=0 or company_id in (select [id] from #Companytable))) E 
LEFT JOIN( 
 SELECT
        ri.Y_ID,
        RI.BillID        AS BillID,
        rb.billnumber,
        ri.billdate,
        CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,
        CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney, 
        RB.quantity           AS Quantity,
        RB.SaleMoney          AS SaleMoney,
        RB.TotalMoney         AS TotalMoney,
        RB.Backquantity       AS BackQuantity,
        RB.BackTotalMoney     AS BackTotalMoney,
        RB.TaxTotal           AS TaxTotal,
        RB.BackTaxTotal       AS BackTaxTotal, 
        AD.BillDiscount       AS BillDiscount,
        AD.BackBillDiscount   AS BackBillDiscount,
        AD.CashMoney          AS CashMoney,
        AD.BackCashMoney      AS BackCashMoney,
        AD.BankMoney          AS BankMoney,
        AD.BackBankMoney      AS BackBankMoney,
        AD.CZZKMONEY          AS CZZKMONEY,
        AD.BackCZZKMONEY      AS BackCZZKMONEY,
        AD.DJQMONEY          AS DJQMONEY,
        AD.BackDJQMONEY      AS BackDJQMONEY,
        AD.JFDXMONEY          AS JFDXMONEY,
        AD.BackJFDXMONEY      AS BackJFDXMONEY,
        AD.WXMONEY            AS WXMONEY,
        AD.BackWXMONEY        AS BackWXMONEY,
        AD.ZFBMONEY           AS ZFBMONEY,
        AD.BackZFBMONEY       AS BackZFBMONEY,   
        AD.YBTCMONEY          AS YBTCMONEY,
        AD.BackYBTCMONEY      AS BackYBTCMONEY,'      
SET @SQLScript1 = ' 
        CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney
 FROM (SELECT * FROM VW_X_BILLIDX 
       WHERE EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)+' 
       AND [BillStates] IN (0) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')

       AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR(10))+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR(10))+CHAR(39)+'
      ) RI 
 LEFT JOIN (SELECT BI.BILLId,bi.billdate,bi.billnumber, 
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)                  as Quantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0)  as saleMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0)                as TotalMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0)                  as TaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)                  as BackQuantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0)                  as BackTaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0)                as BackTotalMoney
           FROM billidx BI 
           LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id 
           WHERE BI.BILLTYPE in(12,13) AND AOID IN (0,5) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or bi.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')     
           GROUP BY BI.BILLID,bi.billdate,bi.billnumber
 
           ) RB ON RI.BillID = RB.BillID
 
 LEFT JOIN (SELECT  BI.BILLId,
       
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 13) THEN JDMONEY ELSE 0 END),0) AS BackBILLDISCOUNT,'

SET @SQLScript2 = 
  'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS WXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackWXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS ZFBMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackZFBMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS YBTCMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackYBTCMONEY 
 
   FROM BILLIDX BI 
   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID 
   WHERE BI.BILLTYPE in(12,13) and ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')
   GROUP BY BI.BILLID   
 ) AD ON RI.BillID = AD.BillID
 WHERE RI.BillType in(12,13)
) RB ON E.company_id = RB.y_id
  and rb.billdate > 0 and rb.billdate > 0  
GROUP BY E.company_id,E.NAME,E.Serial_number,E.Class_id,E.opaddress,rb.billdate,rb.billnumber,rb.BillID 
ORDER BY E.company_id,billdate ' 

EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2) 
END
ELSE IF @GroupMode = 4  /*按照时间段汇总*/
begin
SET @SQLScript = '
SELECT  0   AS  SerialNo,
  rb.billdate,
 E.company_id  AS   EMP_ID,
 E.NAME   AS  EName,
 E.Serial_number  AS  ESerial_Number,
 E.Class_id  AS  EClass_id,
 E.opaddress  AS  DepName,
 0   AS  deduct,
 ISNULL(SUM(RB.YsMoney),0)  		AS YsMoney,  
 ISNULL(SUM(RB.YfMoney),0)  		AS YfMoney,  
 ISNULL(SUM(RB.Quantity),0)  		AS Quantity,
 ISNULL(SUM(RB.SaleMoney),0)  		AS SaleMoney,
 ISNULL(SUM(RB.TotalMoney),0)  		AS TotalMoney,
 ISNULL(SUM(RB.BackQuantity),0)  	AS BackQuantity,
 ISNULL(SUM(RB.BackTotalMoney),0) 	AS BackTotalMoney,
 ISNULL(SUM(RB.TaxTotal),0)             AS TaxTotal,
 ISNULL(SUM(RB.BackTaxTotal),0)         AS BackTaxTotal,
 ISNULL(SUM(RB.BillDiscount),0)         AS BillDiscount,
 ISNULL(SUM(ABS(RB.BackBillDiscount)),0)  AS BackBillDiscount,
 ISNULL(SUM(RB.CashMoney),0)  		AS CashMoney,
 -ISNULL(SUM(RB.BackCashMoney),0) 	AS BackCashMoney,'
SET @SQLScript = @SQLScript+ @SQL1 + '
 ISNULL(SUM(RB.DiscountMoney),0)  	AS DiscountMoney,
 ISNULL(SUM(RB.CashMoney + RB.BankMoney+RB.CZZKMONEY+RB.DJQMONEY+RB.JFDXMONEY+RB.WXMONEY+RB.ZFBMONEY+RB.YBTCMONEY),0)     	AS  skTotalMoney,
 -ISNULL(SUM(RB.BackCashMoney + RB.BackBankMoney-RB.backCZZKMONEY+RB.backDJQMONEY+RB.backJFDXMONEY+RB.BackWXMONEY+BackZFBMONEY+BackYBTCMONEY),0)    AS  fkTotalMoney,
 ISNULL(SUM(RB.TaxTotal- RB.BackTaxTotal),0)            AS  ssTaxTotal,                            
 ISNULL(SUM(RB.BillDiscount+ RB.BackBillDiscount),0)    AS  ssBillDisCount,                        
 ISNULL(SUM(RB.YsMoney- RB.YfMoney),0)               AS  ssYsMoney,                             
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney),0)     	AS  ssCashTotalMoney,
 ISNULL(SUM(RB.BankMoney + RB.BackBankMoney),0)     	AS  ssBankTotalMoney,
 ISNULL(SUM(RB.CashMoney + RB.BackCashMoney +RB.BankMoney + RB.BackBankMoney+RB.CZZKMONEY-RB.backCZZKMONEY+RB.DJQMONEY-RB.backDJQMONEY+RB.JFDXMONEY-RB.backJFDXMONEY+RB.WXMONEY-RB.BackWXMONEY+RB.ZFBMONEY-BackZFBMONEY+RB.YBTCMONEY-BackYBTCMONEY),0) AS  ssTotalMoney
 INTO #mydata FROM (SELECT * from  vw_L_Company VC 
      WHERE (vc.Child_number = 0) and vc.Deleted = 0
      AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or company_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')'
+' and ('+cast(@Companytable as varchar(10))+'=0 or company_id in (select [id] from #Companytable))) E 
LEFT JOIN( 
 SELECT
        ri.Y_ID,
        RI.BillID        AS BillID,
        ri.billdate,
        CASE RI.BillType WHEN 12 THEN RI.YsMoney ELSE 0 END  AS YsMoney,
        CASE RI.BillType WHEN 13 THEN RI.YsMoney ELSE 0 END  AS YfMoney, 
        RB.quantity           AS Quantity,
        RB.SaleMoney          AS SaleMoney,
        RB.TotalMoney         AS TotalMoney,
        RB.Backquantity       AS BackQuantity,
        RB.BackTotalMoney     AS BackTotalMoney,
        RB.TaxTotal           AS TaxTotal,
        RB.BackTaxTotal       AS BackTaxTotal, 
        AD.BillDiscount       AS BillDiscount,
        AD.BackBillDiscount   AS BackBillDiscount,
        AD.CashMoney          AS CashMoney,
        AD.BackCashMoney      AS BackCashMoney,
        AD.BankMoney          AS BankMoney,
        AD.BackBankMoney      AS BackBankMoney,
        AD.CZZKMONEY          AS CZZKMONEY,
        AD.BackCZZKMONEY      AS BackCZZKMONEY,
        AD.DJQMONEY          AS DJQMONEY,
        AD.BackDJQMONEY      AS BackDJQMONEY,
        AD.JFDXMONEY          AS JFDXMONEY,
        AD.BackJFDXMONEY      AS BackJFDXMONEY,
        AD.WXMONEY            AS WXMONEY,
        AD.BackWXMONEY        AS BackWXMONEY,
        AD.ZFBMONEY           AS ZFBMONEY,
        AD.BackZFBMONEY       AS BackZFBMONEY,  
        AD.YBTCMONEY          AS YBTCMONEY,
        AD.BackYBTCMONEY      AS BackYBTCMONEY,'      
SET @SQLScript1 = ' 
        CASE RI.BillType WHEN 12 THEN RB.SaleMoney - RB.TotalMoney ELSE 0 END AS DiscountMoney
 FROM (SELECT * FROM VW_X_BILLIDX 
       WHERE EClass_Id LIKE '+CHAR(39)+@SaleMan+CHAR(39)+' 
       AND [BillStates] IN (0) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')

       AND BillDate Between '+CHAR(39)+CAST(@beginDate AS VARCHAR(10))+CHAR(39)+' and '+CHAR(39)+CAST(@endDate AS VARCHAR(10))+CHAR(39)+'
      ) RI 
 LEFT JOIN (SELECT BI.BILLId,bi.billdate, 
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.quantity ELSE 0 END),0)                  as Quantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN(MB.SalePrice * MB.quantity) ELSE 0 END),0)  as saleMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TotalMoney ELSE 0 END),0)                as TotalMoney,
                   ISNULL(SUM(CASE BI.BillType WHEN 12 THEN MB.TaxTotal ELSE 0 END),0)                  as TaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.quantity ELSE 0 END),0)                  as BackQuantity,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TaxTotal ELSE 0 END),0)                  as BackTaxTotal,
                   ISNULL(SUM(CASE BI.BillType WHEN 13 THEN MB.TotalMoney ELSE 0 END),0)                as BackTotalMoney
           FROM billidx BI 
           LEFT JOIN VW_X_SaleMB  MB on BI.billid = MB.bill_id 
           WHERE BI.BILLTYPE in(12,13) AND AOID IN (0,5) AND ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or bi.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')     
           GROUP BY BI.BILLID,bi.billdate
 
           ) RB ON RI.BillID = RB.BillID
 
 LEFT JOIN (SELECT  BI.BILLId,
       
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 12) THEN JDMONEY ELSE 0 END),0) AS BILLDISCOUNT,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000004000003000004%'+CHAR(39)+') AND (BI.Billtype = 13) THEN JDMONEY ELSE 0 END),0) AS BackBILLDISCOUNT,'

SET @SQLScript2 = 
  'ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS CASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000003%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKCASHMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN JDMONEY ELSE 0 END),0) AS BANKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID LIKE '+CHAR(39)+'000001000004%'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN JDMONEY ELSE 0 END),0) AS BACKBANKMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS CZZKMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000002000006'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackCZZKMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS DJQMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000008'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackDJQMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS JFDXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000004000003000009'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackJFDXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS WXMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000012'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackWXMONEY,

   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS ZFBMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000013'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackZFBMONEY,
 
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 12) THEN ABS(JDMONEY) ELSE 0 END),0) AS YBTCMONEY,
   ISNULL(SUM(CASE WHEN (AD.ACLASS_ID = '+CHAR(39)+'000001000014'+CHAR(39)+') AND (BI.BILLTYPE = 13) THEN ABS(JDMONEY) ELSE 0 END),0) AS BackYBTCMONEY
 
   FROM BILLIDX BI 
   LEFT JOIN VW_X_ADETAIL  AD ON BI.BILLID = AD.BILLID 
   WHERE BI.BILLTYPE in(12,13) and ('+char(39)+cast(@nY_id as varchar(10))+char(39)+'=0 or BI.Y_id='+char(39)+cast(@nY_id as varchar(10))+char(39)+')
   GROUP BY BI.BILLID   
 ) AD ON RI.BillID = AD.BillID
 WHERE RI.BillType in(12,13)
) RB ON E.company_id = RB.y_id
  and rb.billdate > 0 and rb.billdate > 0  
GROUP BY E.company_id,E.NAME,E.Serial_number,E.Class_id,E.opaddress,rb.billdate 
ORDER BY E.company_id,billdate ' 
SET @SQLScript2 = @SQLScript2+
'SELECT ESerial_Number,ename,DepName,SUM(ysmoney) AS ysmoney,SUM(YfMoney) AS YfMoney,SUM(Quantity) AS Quantity, 
SUM(SaleMoney) AS SaleMoney, sum(TotalMoney) as TotalMoney,SUM(BackQuantity) as BackQuantity,
SUM(BackTotalMoney) AS BackTotalMoney,SUM(TaxTotal)AS TaxTotal,SUM(BackTaxTotal) AS BackTaxTotal,
SUM(BillDiscount) AS BillDiscount,SUM(BackBillDiscount) AS BackBillDiscount,SUM(CashMoney) AS CashMoney,
SUM(BackCashMoney) AS BackCashMoney,'
+ @SQLElse +
'SUM(DiscountMoney) AS DiscountMoney,SUM(skTotalMoney) AS skTotalMoney,SUM(fkTotalMoney) as fkTotalMoney,SUM(ssTaxTotal) AS ssTaxTotal,
SUM(ssBillDisCount) AS ssBillDisCount,SUM(ssYsMoney) AS ssYsMoney,SUM(ssCashTotalMoney) AS ssCashTotalMoney,
SUM(ssBankTotalMoney) AS ssBankTotalMoney,SUM(ssTotalMoney) AS ssTotalMoney
 FROM #mydata GROUP BY ESerial_Number,ename,DepName ORDER BY ESerial_Number'

EXEC (@SQLScript+ @SQL2 +@SQLScript1+ @SQL3 + @SQLScript2) 
end
GO
