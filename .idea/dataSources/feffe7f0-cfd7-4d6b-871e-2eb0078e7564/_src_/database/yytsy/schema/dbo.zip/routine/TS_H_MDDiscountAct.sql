
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-4-20*/
/* Description:	店长打折控制*/
/* =============================================*/
CREATE PROCEDURE TS_H_MDDiscountAct 
	@Act		int,		/*操作：0 查询 1 添加/编辑 2 删除*/
	@RD_ID		int = 0,	/*记录ID*/
	@Y_ID		int = 0,	/*机构*/
	@E_ID		int = 0,	/*职员*/
	@TotalMoney	NUMERIC(25,8) = 0,	/*金额*/
	@Discount	NUMERIC(25,8) = 0	/*折扣*/
AS
BEGIN
/*Params Ini begin*/
if @RD_ID is null  SET @RD_ID = 0
if @Y_ID is null  SET @Y_ID = 0
if @E_ID is null  SET @E_ID = 0
if @TotalMoney is null  SET @TotalMoney = 0
if @Discount is null  SET @Discount = 0
/*Params Ini end*/

	IF @Act = 0
	begin
		SELECT     y.name AS YName, e.name AS EName, d.totalmoney, d.discount, d.e_id, d.y_id, d.rd_id
			FROM         dbo.company AS y INNER JOIN
								  dbo.RetailDiscount AS d ON y.company_id = d.y_id INNER JOIN
								  dbo.employees AS e ON d.e_id = e.emp_id
			WHERE     (d.y_id = @Y_ID or @Y_ID = 0)
	end
	else
	if @Act = 1
	begin
		if @RD_ID > 0
			update RetailDiscount set
				totalmoney = @totalmoney,
				discount = @discount,
				y_id = @y_id,
				e_id = @e_id
			where rd_id = @rd_id
		else
			insert into RetailDiscount(
				y_id,
				e_id,
				totalmoney,
				discount
				) values (
				@y_id,
				@e_id,
				@totalmoney,
				@discount
				)
	end
	else
	if @Act = 2
	begin
		delete from retaildiscount where rd_id = @rd_id
	end
END
GO
