
CREATE PROCEDURE [dbo].[ts_j_StartSFDA]
AS
BEGIN
  /*启用多网融合，注意，当启用多网融合时，需要将 ScanSFDACode =1*/
	IF NOT EXISTS (SELECT * FROM [sysconfigtmp] WHERE SYSNAME = 'LINKSFDANET')
	BEGIN
		INSERT INTO [sysconfigtmp]([sysname], [sysvalue], [comment], tagno, sysflag, y_id)
		VALUES('LINKSFDANET', 1, '启用多网融合，要求必须能连外网', 0, 0, 0)
	END
	else
	  update  sysconfigtmp set  sysvalue   = '1' where sysname = 'LINKSFDANET' AND sysvalue <> '1'

	/*单据上扫描监管码,可以单独启用,不需要和LINKSFDANET同时启用*/
	IF NOT EXISTS (SELECT * FROM [sysconfigtmp] WHERE SYSNAME = 'ScanSFDACode')
	BEGIN
		INSERT INTO [sysconfigtmp]([sysname], [sysvalue], [comment], tagno, sysflag, y_id)
		VALUES('ScanSFDACode', 1, '单据中扫描监管码', 0, 0, 0)
	END
	else
	  update  sysconfigtmp set  sysvalue   = '1' where sysname = 'ScanSFDACode' AND  sysvalue <> '1'
	
	IF NOT EXISTS (SELECT * FROM [sysconfig] WHERE SYSNAME = 'ElectricCode')
		INSERT INTO [sysconfig]([sysname], [sysvalue], [comment],sysflag, y_id)
		VALUES('ElectricCode', 1, '启用监管码', 0, 0)
	else 
		update sysconfig set sysvalue = 1 where [sysname] =  'ElectricCode' AND sysvalue <> '1'

	/*开启电子监管多网融合，要求客户端电脑必须能上外网，否则将不能正确解析监管码			*/
END
GO
