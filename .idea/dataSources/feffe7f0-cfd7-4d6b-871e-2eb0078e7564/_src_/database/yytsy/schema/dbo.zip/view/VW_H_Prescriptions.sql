
CREATE VIEW dbo.VW_H_Prescriptions
AS
SELECT     p.PatientID, p.Name, p.sex, p.Tel, p.Birthday, p.Job, p.Address, p.Comment, p.IDCard, p.BulidDate, p.Pos_Id, p.Deleted, p.PinYin, b.GUID, p.ModifyDate, p.isVIP, 
                      p.VIP_ID, ISNULL(r.regDate, '1900-1-1') AS regDate, ISNULL(r.count, 0) AS Count, e.name AS PosName, b.billid AS Pres_ID, b.billnumber AS BillNo, ISNULL(d.name, '') 
                      AS DeptName, b.e_id AS Doctor_ID, e2.name AS Doctor, b.order_id AS Reg_id, b.billdate, b.summary AS Diagnose, b.InvoiceNO AS BedNo, b.c_id AS Patient_ID, 
                      b.note AS Symptom, dbo.GetAge(p.Birthday, GETDATE()) AS Age, ISNULL(v.CardNo, ' ') AS CardNo
FROM         dbo.Patients AS p INNER JOIN
                      dbo.employees AS e ON p.Pos_Id = e.emp_id INNER JOIN
                      dbo.retailbillidx AS b ON p.PatientID = b.region_id INNER JOIN
                      dbo.employees AS e2 ON b.e_id = e2.emp_id LEFT OUTER JOIN
                      dbo.VIPCard AS v ON p.VIP_ID = v.VIPCardID LEFT OUTER JOIN
                      dbo.department AS d ON e.dep_id = d.departmentId LEFT OUTER JOIN
                          (SELECT     Patient_ID, MAX(RegDate) AS regDate, COUNT(*) AS count
                            FROM          dbo.Registered AS Registered_1
                            GROUP BY Patient_ID) AS r ON p.PatientID = r.Patient_ID
WHERE     (p.Deleted = 0) AND (b.billtype = 244)
GO
