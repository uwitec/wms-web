
/******************************************
拣货单查询
作者：yanrui
创建日期 2012-12-13
********************************************/
CREATE PROCEDURE ts_Y_jhbillSearch
(	
    @BeginDate 	    DATETIME,    /*开始时间*/
	@EndDate	 	DATETIME,    /*结束时间*/
	@billNO         varchar(50), /*销售单编号*/
	@billtype       int,        /*单据类型 254 拣货单*/
	@states         int,        /*单据状态 -1全部,0完成2拣货,5复核*/
	@s_id           int,         /*仓库ID*/
    @pcount         int,         /*拣货单打印状态 0:未打印 1:已打印 2:全部*/
    @e_id           int=0,      /*经手人*/
	@nloginEID		int			/* 当前登录职员*/
)
as
/*--初始化参数*/
/**/
/*单据状态*/
declare  @st1 int,@st2 int 
select @st1=@states,@st2=@st1
if @states=-1 select @st2=10

  Declare @Storetable integer
  create table #storagestable([id] int)
/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      Insert #storagestable ([id]) select 0
   end
/*---仓库授权*/

/*仓库ID*/
declare  @s_id1 int,@s_id2 int 
select @s_id1=@s_id,@s_id2=@s_id1
if @s_id1=0 select @s_id2=2147483647

/*拣货单打印状态*/
declare  @pt1 int,@pt2 int 
/*select @st1=@pcount   --,@pt2=@pt1*/
if @pcount=0 select @pt1=0,@pt2=0
if @pcount=1 select @pt1=1,@pt2=255
if @pcount=2 select @pt1=0,@pt2=255

declare @xs_no varchar(50)
set @xs_no='%'+@billNO+'%'
/*select @xs_no*/

create table #t1
(
 billnumber  varchar(50),
 GUID  uniqueidentifier
)
insert into #t1
 select * from (
    select  distinct a1.billnumber,/*CAST(a1.guid AS VARCHAR(50)) as GUID*/
    a1.GUID
    from billidx a1,billdraftidx  a2  
    where a2.InvoiceNO<>'' and  len(a2.InvoiceNO)=36 and  a2.billtype=254 
    and cast(a2.InvoiceNO as uniqueidentifier) = a1.GUID        
    union 
    select  distinct b1.billnumber,/*CAST(b1.guid AS VARCHAR(50)) as GUID*/
    b1.GUID
    from billdraftidx b1,billdraftidx  b2  
   /* where CAST(b1.guid AS VARCHAR(40))=b2.InvoiceNO  and  b2.billtype=254 and b2.InvoiceNO<>''*/
    where b2.InvoiceNO<>'' and len(b2.InvoiceNO)=36 and  b2.billtype=254 
    and cast(b2.InvoiceNO as uniqueidentifier) = b1.GUID     
  ) e5   
/* top 2000*/
begin
  select top 5000 w.serialno,w.billnumber,w.billdate,w.c_name,w.ck_name,w.jsr,w.zdr,w.shr
  ,w.billstates,w.S_billid,w.billid,w.auditman,w.Y_ID,w.states,w.jhr,w.fhr,w.S_SN
  ,w.sendC_id,w.WholeQty,w.PartQty,w.note,w.printcount,w.jhprintcount,w.locname,contact_personal,
  phone_number,address,cast(w.InvoiceTotal as int) invoicetotal,w.lhqty,w.jhrid,w.fhrid, w.RoadName
  from 
  (
  select y.serialno,y.billnumber,y.billdate,y.c_name,y.ck_name,y.jsr,y.zdr,y.shr
  ,y.billstates,isnull(y.S_billid,0) as S_billid,y.billid,y.auditman
  ,y.Y_ID,y.states,isnull(e3.name,'') as jhr,isnull(e4.name,'') as fhr,
  isnull(#t1.billnumber,'') as S_SN
  /*isnull(e5.billnumber,'') as S_SN*/
  ,ISNULL(e3.emp_id,0) jhrid,ISNULL(e4.emp_id,0) fhrid
  ,y.sendC_id,y.WholeQty,y.PartQty,isnull(y.note,'') as note,y.printcount,y.jhprintcount,y.locname,contact_personal,phone_number,
  y.address,y.InvoiceTotal,y.lhqty, ISNULL(r.RoadName, '') AS RoadName
  from 
  (
  select '' as serialno,a.billnumber,a.billdate
  ,b.name as c_name,c.name as ck_name,e.name as jsr,e1.name as zdr,e2.name as shr,
  b.contact_personal,b.phone_number,b.address,
  (Case a.VIPCardID 
  when  1 then '拣货退回'
  when  2 then '拣货'
  when  3 then '拣货完成'
  when  4 then '复核退回' 
  when  5 then '待复核'
  when  6 then '复核完成'
  when  0 then '完成'
  else 
    ''  
  end ) as billstates,a.order_id as S_billid,a.billid,a.auditman,a.Y_ID,a.VIPCardID as states
  ,a.integral,a.integralYE,a.sendC_id,a.WholeQty,a.PartQty,a.note,a.InvoiceNO,transcount as printcount,BusinessType as jhprintcount
  ,a.B_CustomName3 as locname,a.InvoiceTotal,cast(a.summary as int) as lhqty, b.RoadID
  from billdraftidx a,clients b,storages c,employees e,employees e1,employees e2  
  where a.billtype=@billtype and a.billdate>=@BeginDate and a.billdate<=@EndDate  and a.invoiceNO<>'' and (@e_id=0 or a.e_id=@e_id)
        and a.VIPCardID>=@st1 and a.VIPCardID<=@st2 
        and (@Storetable = 0 OR a.sout_id in (select id from #storagestable))
        and a.BusinessType>=@pt1  and a.BusinessType<=@pt2
        and a.c_id=b.client_id 
        and a.sout_id=c.storage_id
        and a.e_id=e.emp_id
        and a.inputman=e1.emp_id
        and a.auditman=e2.emp_id
        and (@s_id = 0 or a.sout_id = @s_id)
  ) y  
  left join  employees e3     on  y.integral    =e3.emp_id  
  left join  employees e4     on  y.integralYE  =e4.emp_id 
  left join SendRoad r on y.RoadID = r.RoadID  
  left join #t1  on  cast(y.InvoiceNO as uniqueidentifier)= #t1.GUID /*on y.InvoiceNO = #t1.GUID    */
   ) w
  
  where w.S_billid <> 0 and  w.S_SN like @xs_no 
  
 drop table #t1  
end
GO
