
CREATE PROCEDURE Ts_K_GSPUnqualifiedOK
(
	@StorehouseId  INT = 0,           /*存放2277选批次后的初始storehouseid*/
	@StorehouseId2 INT = 0,           /*存放2277调整停售货位后的storehouseid*/
	@Quantity      NUMERIC(25,8) = 0,/*需要解除停售的数量*/
    @EId           INT = 2,
    @GSPNo         VARCHAR(60)        /*不合格药品确认单编号*/
)
/*with encryption*/
AS
BEGIN
	DECLARE @ResultFlag INT
	SET @ResultFlag = -99
	
	IF @StorehouseId = 0 OR @StorehouseId2 = 0
		RETURN -51
	IF @Quantity <= 0
	    RETURN -52
	if not exists(select 1 from storehouse where storehouse_id=@StorehouseId2)
        RETURN -51
    if not exists(select 1 from storehouse where storehouse_id=@StorehouseId)
        RETURN -51
    
	DECLARE @SId INT, @UnqualifiedSId INT, @YId INT
	DECLARE @CostPrice NUMERIC(25,8)
	SET @SId = 0
	SET @UnqualifiedSId = 0
	SET @YId = 0
	SET @CostPrice = 0
	SELECT @YId = ISNULL(y_id, 0), @SId = ISNULL(s_id, 0), @CostPrice = ISNULL(costprice, 0) FROM storehouse WHERE storehouse_id = @StorehouseId2
	
	IF EXISTS(SELECT 1 FROM storages WHERE storage_id = @SId AND qualityFlag =1)
	BEGIN
		/*仓库本来就是不合格库类型则返回*/
		RETURN 1
	END
	
	IF EXISTS(SELECT 1 FROM storages WHERE [deleted] = 0 AND Y_ID = @YId AND qualityFlag = 1)
	BEGIN
		SELECT TOP 1 @UnqualifiedSId = ISNULL(storage_id, 0) FROM storages WHERE [deleted] = 0 AND Y_ID = @YId AND qualityFlag = 1
	END
	ELSE
	BEGIN
		/*如不存在不合格品库则新建一个不合格品库*/
		DECLARE @TempId VARCHAR(30)
		DECLARE @Child_Number INT, @Child_Count INT
		/*SELECT @TempId = classid FROM Getid('000000', 'Storages')*/
		/*zjx--2016-12-30---tfs44514--处理生成不合格仓库后，在新建仓库Class_ID会重复*/
		select @tempid=classid,@child_number=childnumber,@child_count=childCount 
        from Getid('000000','Storages')
		IF @@ROWCOUNT = 0
			RETURN -53
		 
		INSERT INTO storages
		(class_id, parent_id, child_number, child_count, name, alias, serial_number, Comment, flag, 
		 PinYin, [deleted], RowIndex, WholeFlag, Y_ID, Fzr_id, Bgy_id, storeCondition, qualityFlag)
		VALUES
		(@TempId, '000000', 0, 0, '不合格品库', '不合格品库', '0', '不合格药品确认单自动创建', 0,  
		 'BHGPK', 0, 1, 0, @YId, 0, 0, 1, 1)
		IF @@ROWCOUNT > 0
		begin
		    /*zjx--2016-12-30---tfs44514--处理生成不合格仓库后，在新建仓库Class_ID会重复*/
		    update Storages set child_number=@child_number,child_count=@child_count
            where class_id ='000000'
			SET @UnqualifiedSId = @@identity
	    end
		ELSE
			RETURN -53
	END 
	
	BEGIN TRAN CreatevtTransfer
		DECLARE @szBillNumber VARCHAR(200)
		DECLARE @BillId INT 
		EXEC TS_H_CreateBillSN 44, 1, NULL, 0, 0, @szBillNumber OUTPUT, @YId
		
		INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
								 ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
								 auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
								 InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
								 begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, 
								 PartQty, YGuid,ZBAuditMan,ZBAuditDate)
		VALUES(CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, 44, 0, 0, @EId, @SId, @UnqualifiedSId, @EId, @EId,
			   @CostPrice * @Quantity, @CostPrice * @Quantity, @Quantity, 0, 0, 3, 0, 0, 0, 0,
			   '1900-01-01', '1900-01-01', 0, 0, '不合格药品确认单' + @GSPNo, '', 0, 0, '1900-01-01', NEWID(),
			   0, '', 0, 0, @Quantity, 0, 0, 0, @YId, 0,
			   '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 0, 0, 
			   0, 0x0,0,'1900-01-01') 
		IF @@ERROR <> 0
		BEGIN
			SET @ResultFlag = -54
			GOTO ERROR	
		END
		ELSE
			SET @BillId = @@identity	
		
		INSERT INTO storemanagebilldrf
			  (bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney,
			   makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment,
			   unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, SendQTY,
			   SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxrate,costtaxprice,costtaxtotal)
		SELECT @BillId, s.p_id, s.batchno, @Quantity, s.costprice, s.costprice * @Quantity, s.costprice, s.costprice * @Quantity, 0, 0,
		       s.makedate, s.validdate, '不合格', 0, @SId, @UnqualifiedSId, s.location_id, s.supplier_id, s.commissionflag, '',
		       p.unit1_id, 0, 0, s.costprice * @Quantity, 0, @Quantity, s.costprice, 0, 0, @Quantity,
		       s.costprice * @Quantity, NEWID(), @EId, @YId, S.instoretime, S.BatchBarCode, S.scomment, S.batchprice, '',s.factoryid,s.taxrate,s.costtaxprice, @Quantity*s.costtaxprice
			FROM storehouse s INNER JOIN products p ON s.p_id = p.product_id 
		WHERE s.storehouse_id = @StorehouseId2
		IF @@ERROR <> 0
		BEGIN
			SET @ResultFlag = -54
			GOTO ERROR	
		END
		
		DECLARE @FResultId_BillAudit INT, @FVchCode_BillAudit INT
		SET @FResultId_BillAudit = -1
		SET @FVchCode_BillAudit = -1
		EXEC ts_c_BillAudit @BillId, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 44
		IF @FVchCode_BillAudit < 0
		BEGIN
			SET @ResultFlag = @FVchCode_BillAudit
			GOTO ERROR	
		END
	COMMIT TRAN CreatevtTransfer
	
	RETURN 1
	
	ERROR:
		ROLLBACK TRAN CreatevtTransfer
		RETURN @ResultFlag
END
GO
