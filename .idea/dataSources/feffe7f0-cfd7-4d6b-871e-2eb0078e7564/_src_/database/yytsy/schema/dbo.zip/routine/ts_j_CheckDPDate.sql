/************************************************************

--功能：检查是否存在未到发票的单据
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_CheckDPDate]
( 
  @nC_ID int = 0
)
AS 
/*Params Ini begin*/
if @nC_ID is null  SET @nC_ID = 0

declare @nRet int
set @nRet = 0
if exists(
	select 1 from (
			select xsd_bid,SUM(isnull(remaintotal,0))-SUM(isnull(jstotal,0)) as jsye 
			from jsbdetail 
			 left join billidx on jsbdetail.xsd_bid=billidx.billid
			 where billidx.billstates = '0' and billidx.c_id = 182 and billidx.billtype = 20 and DPdate > 10 and jsye >0
			 group by xsd_bid) as tb
		 )
  set @nRet = -1

Return @nRet
GO
