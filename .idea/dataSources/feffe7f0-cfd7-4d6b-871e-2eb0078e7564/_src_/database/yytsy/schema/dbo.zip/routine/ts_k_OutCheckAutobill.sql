

CREATE PROCEDURE ts_k_OutCheckAutobill(
    @nType        INT,	/*1 只执行复核；2 执行复核并生成销售出库退货单 */
    @CheckIdxRec  VARCHAR(8000),
    @TempRec      VARCHAR(8000),
    @nE_id        INT,
    @nBillid      INT,
    @BillNumber   VARCHAR(20)
)
AS
	IF @nType = 1
	BEGIN
	    BEGIN TRAN k_OutCheckAutobill
	    EXECUTE(@CheckIdxRec)
	    IF @@ERROR <> 0
	    BEGIN
	        ROLLBACK TRAN k_OutCheckAutobill
	        RETURN -1
	    END
	    ELSE
	    BEGIN
	        COMMIT TRAN k_OutCheckAutobill
	        RETURN 0
	    END
	END
	ELSE 
	IF @nType = 2
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   tempdb.dbo.SYSOBJECTS
	           WHERE  id = OBJECT_ID(N'tempdb..#tmpk_OutCheckAutobill')
	                  AND TYPE = 'U'
	       )
	        DROP TABLE #tmpk_OutCheckAutobill
	    
	    CREATE TABLE #tmpk_OutCheckAutobill
	    (
	    	[id]      [int] IDENTITY(1, 1) NOT NULL,
	    	[e_id]    [int] NOT NULL,
	    	[billid]  [int] NOT NULL,
	    	[smbid]   [int] NOT NULL,
	    	[qty]     NUMERIC(25,8)NOT NULL
	    )
	    
	    EXECUTE (@TempRec)
	    IF @@ERROR <> 0
	    BEGIN
	        RETURN -1
	    END
	    
	    BEGIN TRAN k_OutCheckAutobill  
	    DECLARE @newbillid INT
	    INSERT INTO billdraftidx
	      (
	        billdate,
	        billnumber,
	        billtype,
	        a_id,
	        c_id,
	        e_id,
	        sout_id,
	        sin_id,
	        auditman,
	        inputman,
	        ysmoney,
	        ssmoney,
	        quantity,
	        taxrate,
	        period,
	        billstates,
	        order_id,
	        department_id,
	        posid,
	        region_id,
	        auditdate,
	        skdate,
	        jsye,
	        jsflag,
	        note,
	        summary,
	        invoice,
	        transcount,
	        lasttranstime,
	        GUID,
	        invoiceTotal,
	        invoiceNO,
	        businesstype,
	        araptotal,
	        sendqty,
	        gatheringman,
	        vipcardid,
	        jsinvoicetotal,
	        Y_ID,
	        transflag,
	        begindate,
	        Enddate,
	        integral,
	        integralYE,
	        B_CustomName1,
	        B_CustomName2,
	        b_CustomName3,
	        RetailDate,
	        sendC_id,
	        WholeQty,
	        PartQty
	        ,ZBAuditMan,ZBAuditDate
	      )
	    SELECT CONVERT(VARCHAR(100), GETDATE(), 23) AS billdate,
	           @BillNumber,
	           11,
	           b.a_id,
	           b.c_id,
	           b.e_id,
	           b.sout_id,
	           b.sin_id,
	           0,
	           @nE_id,
	           (
	               SELECT SUM(b.taxprice * a.qty)
	               FROM   #tmpk_OutCheckAutobill a
	                      INNER JOIN salemanagebill b
	                           ON  a.smbid = b.smb_id
	               WHERE  a.e_id = @nE_id
	                      AND billid = @nBillid
	               GROUP BY
	                      BILLID
	           ) AS ysmoney,
	           0 AS ssmoney,
	           (
	               SELECT SUM(a.qty)
	               FROM   #tmpk_OutCheckAutobill a
	                      INNER JOIN salemanagebill b
	                           ON  a.smbid = b.smb_id
	               WHERE  a.e_id = @nE_id
	                      AND billid = @nBillid
	               GROUP BY
	                      BILLID
	           ) AS quantity,
	           b.taxrate,
	           b.period,
	           2 AS billstates,
	           0,
	           b.department_id,
	           b.posid,
	           b.region_id,
	           '1900-1-1' AS auditdate,
	           '1900-1-1' AS skdate,
	           (
	               SELECT SUM(b.taxprice * a.qty)
	               FROM   #tmpk_OutCheckAutobill a
	                      INNER JOIN salemanagebill b
	                           ON  a.smbid = b.smb_id
	               WHERE  a.e_id = @nE_id
	                      AND billid = @nBillid
	               GROUP BY
	                      BILLID
	           ) AS jsye,
	           0,
	           '发货复核生成单据，原单号：' + CASE 
	                                               WHEN (RTRIM(LTRIM(b.billnumber)) = '') THEN 
	                                                    CAST(b.billid AS VARCHAR(50))
	                                               ELSE b.billnumber
	                                          END,
	           '',
	           0,
	           0,
	           '1900-1-1' AS lasttranstime,
	           NEWID(),
	           0,
	           '',
	           0,
	           b.araptotal,
	           (
	               SELECT SUM(a.qty)
	               FROM   #tmpk_OutCheckAutobill a
	                      INNER JOIN salemanagebill b
	                           ON  a.smbid = b.smb_id
	               WHERE  a.e_id = @nE_id
	                      AND billid = @nBillid
	               GROUP BY
	                      BILLID
	           ) AS sendqty,
	           0 AS gatheringman,
	           b.vipcardid,
	           0 AS jsinvoicetotal,
	           b.Y_ID,
	           b.transflag,
	           b.begindate,
	           b.Enddate,
	           b.integral,
	           b.integralYE,
	           b.B_CustomName1,
	           b.b_CustomName2,
	           b.B_CustomName3,
	           b.RetailDate,
	           b.sendC_id,
	           b.WholeQty,
	           b.PartQty
	           ,0,'1900-01-01'
	    FROM   (
	               SELECT TOP 1 billid
	               FROM   #tmpk_OutCheckAutobill
	               WHERE  e_id = @nE_id
	                      AND billid = @nBillid
	           ) a
	           INNER JOIN BillIdx b
	                ON  a.billid = b.billid
	    WHERE  b.billtype = 10 
	    
	    IF @@ROWCOUNT = 0
	    BEGIN
	        ROLLBACK TRAN k_OutCheckAutobill
	        RETURN -1
	    END
	    
	    SET @newbillid = @@IDENTITY 
	    INSERT INTO salemanagebilldrf
	      (
	        bill_id,
	        p_id,
	        batchno,
	        quantity,
	        costprice,
	        saleprice,
	        discount,
	        discountprice,
	        totalmoney,
	        taxprice,
	        taxtotal,
	        taxmoney,
	        retailprice,
	        retailtotal,
	        makedate,
	        validdate,
	        qualitystatus,
	        price_id,
	        ss_id,
	        sd_id,
	        location_id,
	        supplier_id,
	        commissionflag,
	        comment,
	        unitid,
	        taxrate,
	        order_id,
	        total,
	        iotag,
	        invoicetotal,
	        thqty,
	        newprice,
	        orgbillid,
	        aoid,
	        jsprice,
	        invoice,
	        invoiceno,
	        pricetype,
	        sendqty,
	        sendcosttotal,
	        RowGuid,
	        RowE_id,
	        YCostPrice,
	        YGuid,
	        Y_ID,
	        transflag,
	        instoretime,
	        cxType,
	        location_id2,
	        comment2,
	        BatchBarCode,
	        scomment,
	        batchprice
	      )
	    SELECT @newbillid,
	           b.p_id,
	           b.batchno,
	           a.qty,
	           b.costprice,
	           b.saleprice,
	           b.discount,
	           b.discountprice,
	           a.qty * b.discountprice AS totalmoney,
	           b.taxprice,
	           a.qty * b.taxprice AS taxtotal,
	           a.qty * b.discountprice * b.taxrate AS taxmoney,
	           b.retailprice,
	           a.qty * b.retailprice AS retailtotal,
	           b.makedate,
	           b.validdate,
	           b.qualitystatus,
	           b.price_id,
	           b.ss_id,
	           b.sd_id,
	           b.location_id,
	           b.supplier_id,
	           b.commissionflag,
	           b.comment,
	           b.unitid,
	           b.taxrate,
	           0,
	           a.qty * b.saleprice AS total,
	           b.iotag,
	           0 AS invoicetotal,
	           a.qty AS thqty,
	           b.newprice,
	           b.orgbillid,
	           b.AOID,
	           b.jsprice,
	           b.invoice,
	           b.invoiceno,
	           b.pricetype,
	           a.qty AS sendqty,
	           0 AS sendcosttotal,
	           b.RowGuid,
	           b.RowE_id,
	           b.YCostPrice,
	           b.YGuid,
	           b.Y_ID,
	           b.transflag,
	           b.instoretime,
	           b.cxType,
	           b.location_id2,
	           b.comment2,
	           b.BatchBarCode,
	           b.scomment,
	           b.batchprice
	    FROM   (
	               SELECT *
	               FROM   #tmpk_OutCheckAutobill
	               WHERE  e_id = @nE_id
	                      AND billid = @nBillid
	           ) a
	           INNER JOIN salemanagebill b
	                ON  a.smbid = b.smb_id 
	    
	    IF @@ROWCOUNT = 0
	    BEGIN
	        ROLLBACK TRAN k_OutCheckAutobill
	        RETURN -1
	    END
	    
	    EXECUTE (@CheckIdxRec)
	    IF @@ERROR <> 0
	    BEGIN
	        ROLLBACK TRAN k_OutCheckAutobill
	        RETURN -1
	    END
	    ELSE
	    BEGIN
	    	DROP TABLE #tmpk_OutCheckAutobill
	        COMMIT TRAN k_OutCheckAutobill
	        RETURN 0
	    END
	END
	ELSE
	BEGIN
	    RETURN -1
	END
GO
