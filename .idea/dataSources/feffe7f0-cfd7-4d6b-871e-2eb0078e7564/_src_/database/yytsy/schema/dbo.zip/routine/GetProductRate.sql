

CREATE FUNCTION GetProductRate(@nProduct_id int,@nUnit_id int)
RETURNS numeric(25,8) 
AS

BEGIN 

declare @Rate numeric(25,8)

set @Rate=1

if exists(select isnull(Rate2,0) from products p where p.Product_id=@nProduct_id and unit2_id=@nUnit_id)
begin
  select @Rate=isnull(Rate2,0) from products p where p.Product_id=@nProduct_id and unit2_id=@nUnit_id
  return(@Rate)
end
else 
if exists(select isnull(Rate3,0) from products p where p.Product_id=@nProduct_id and unit3_id=@nUnit_id)
begin
  select @Rate=isnull(Rate3,0) from products p where p.Product_id=@nProduct_id and unit3_id=@nUnit_id
  return(@Rate)
end
else
if exists(select isnull(Rate4,0) from products p where p.Product_id=@nProduct_id and unit4_id=@nUnit_id)
begin
  select @Rate=isnull(Rate4,0) from products p where p.Product_id=@nProduct_id and unit4_id=@nUnit_id
  return(@Rate)
end

RETURN(@Rate)



	
END
GO
