



CREATE PROCEDURE [dbo].[Ts_L_QrReturnStd] 
    @beginDate   datetime='',
    @endDate     datetime='',
    @C_id        int=0,
    @p_id        int=0,
    @y_id        int=0,
    @nrettag    int=0
AS
/*Params Ini begin*/
if @beginDate is null  SET @beginDate = ''
if @endDate is null  SET @endDate = ''
if @C_id is null  SET @C_id = 0
if @p_id is null  SET @p_id = 0
if @y_id is null  SET @y_id = 0
if @nrettag is null  SET @nrettag = 0
/*Params Ini end*/
	/*已返金额*/
        select rb.SaleQty,rb.SaleTotal,rb.p_id,b.billtype,b.billdate,b.c_id,b.Y_id
	into #returnBill
	from returnBill rb 
        inner join Billidx b on  rb.bill_id=b.billid
	where (b.billdate between @beginDate and @endDate) and b.billtype in (184,185)
	   
	/*返利数量=现在单据数量 - 已返数量*/
	select r.*,tagName= case r.tag when 0 then '返利' else '获利' end,
           ModeName= case r.ReturnMode when 0 then '按数量' else '按金额' end,
           p.name as P_name,c.name as c_name,
           qty=(isnull((select abs(sum(pb.quantity)) qty
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (10,11)
                          and b.c_id=r.c_id 
                          and pb.p_id=r.p_id
                          and b.Y_id=@Y_id),0) 
	      		- isnull((select abs(sum(b.SaleQty)) qty
                        from  #returnBill b 
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (184)
                          and b.c_id=r.c_id
			  and b.p_id=r.p_id
			  and b.Y_id=@Y_id),0) ),
           saletotal=(isnull((select abs(sum(total)) qty
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (10,11)
                          and b.c_id=r.c_id 
                          and pb.p_id=r.p_id
                          and b.Y_id=@Y_id),0) 
	      		- isnull((select abs(sum(b.SaleTotal)) qty
                        from  #returnBill b 
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (184)
                          and b.c_id=r.c_id 
			  and b.p_id=r.p_id
                          and b.Y_id=@Y_id),0) ) ,
	   buyqty=(isnull((select abs(sum(pb.quantity)) qty
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (20,21)
                          and b.c_id=r.c_id 
                          and pb.p_id=r.p_id
                          and b.Y_id=@Y_id),0)
	      		- isnull((select abs(sum(b.SaleQty)) qty
                        from  #returnBill b 
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (185)
                          and b.c_id=r.c_id 
			  and b.p_id=r.p_id
                          and b.Y_id=@Y_id),0) ) ,
           buytotal=(isnull((select abs(sum(total)) qty
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (20,21)
                          and b.c_id=r.c_id 
                          and pb.p_id=r.p_id
                          and b.Y_id=@Y_id),0) 
     		        -  isnull((select abs(sum(b.SaleTotal)) qty
                        from  #returnBill b  
                        where (b.billdate between r.begindate and r.endDate) and b.billtype in (185)
                          and b.c_id=r.c_id 
			  and b.p_id=r.p_id
                          and b.Y_id=@Y_id),0)) 
	from returnstd r 
	     INNER JOIN products p on r.p_id =p.product_id 
	     INNER JOIN clients c on c.client_id=r.C_id
	where (@c_id=0 or r.c_id=@c_id) and (@p_id=0 or r.P_id=@p_id) and y_id=@y_id and r.tag=@nrettag
          and r.begindate>=cast(@begindate as datetime) and r.enddate<=cast(@enddate as datetime)
GO
