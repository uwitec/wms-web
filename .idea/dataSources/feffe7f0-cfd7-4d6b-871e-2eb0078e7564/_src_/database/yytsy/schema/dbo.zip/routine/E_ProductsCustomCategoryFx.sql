create procedure E_ProductsCustomCategoryFx
  @y_id integer=0,     /*机构*/
  @stopcheckd integer=0,/*是否停用*/
  @CategoryGroupClassidOne    varchar(1000),/*选中类别组一 class_id*/
  @CategoryCheckOne           integer=0,/*选中大 1，中 2，小 3*/
  @CategoryOne_id             varchar(1000),/*选中的类别组ID号*/
  
  @CategoryGroupClassidTwo    varchar(1000),/*选中类别组二 class_id*/
  @CategoryCheckTwo           integer=0,/*选中大 1，中 2，小 3*/
  @CategoryTwo_id             varchar(1000),/*选中的类别组ID号*/
  
  @CategoryGroupClassidThree    varchar(1000),/*选中类别组三 class_id*/
  @CategoryCheckThree          integer=0,/*选中大 1，中 2，小 3*/
  @CategoryThree_id             varchar(1000)/*选中的类别组ID号*/
  
as 
Create Table #CategoryALL
  (
    RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
    CategoryId            INT     NULL DEFAULT(0), /*类ID*/
    CategoryClassId       varchar (100)    NULL DEFAULT(''),/*-类别ClassId*/
    CategoryName          varchar (100)    NULL DEFAULT(''),/*-类别名称*/
    ZPgNum                INT   NULL DEFAULT(0), /*总品规数*/
    GMl                   INT   NULL DEFAULT(0), /*配送单(制单人)*/
    ZML                   INT   NULL DEFAULT(0), /*-商品类别组名称*/
    DML                   INT   NULL DEFAULT(0), /*-机构类别名称*/
    FML                   INT   NULL DEFAULT(0), /*配送单目标机构         */
  )
create table #CategoryThree_id
(
  RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
  class_id              varchar (100)    NULL DEFAULT(''),
  id                    INT   NULL DEFAULT(0)
)
create table #CategoryTwo_id
(
  RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
  class_id              varchar (100)    NULL DEFAULT(''),
  id                    INT   NULL DEFAULT(0)
)
create table #tempThree
(
  RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
  baseinfo_id           INT   NULL DEFAULT(0),
  class_id              varchar (100)    NULL DEFAULT('')
)
begin
  declare @LENone   int
  declare @LENTwo    int
  declare @LENThree    int
  declare @code int
  declare @swarajprice int /*独立物价*/
  declare @gid int
  declare @zid int
  declare @did int
  declare @fid int
  declare @info_idOne int
  declare @PColNameOne VARCHAR(100)
  declare @info_idTwo int
  declare @PColNametwo VARCHAR(100)
  declare @info_idThree int
  declare @PColNameThree VARCHAR(100)
  declare @sqlstrOne varchar(2000)
  declare @sqlstrTwo varchar(2000)
  declare @sqlstrThree varchar(2000)
    set @PColNameOne = ''
    set @PColNametwo = ''
    set @PColNameThree = ''
  set @LENone = 0
  set @LENTwo = 0
  set @LENThree = 0
  set @code = 1
  set @swarajprice = 0 
  
    if @CategoryOne_id<>''
    begin
      SELECT distinct @info_idOne = Category_id FROM customCategory WHERE ID in (select  szTYPE from  DecodeToStr(@CategoryOne_id))
      set @PColNameOne = dbo.GetColName(@info_idOne,'ProductCategory')  
    end
    if @CategoryTwo_id<>''
    begin
      SELECT distinct @info_idTwo = Category_id FROM customCategory WHERE ID in (select  szTYPE from  DecodeToStr(@CategoryTwo_id)) 
      set @PColNametwo = dbo.GetColName(@info_idTwo,'ProductCategory') 
    end
    if @CategoryThree_id<>''
    begin
      SELECT distinct @info_idThree = Category_id FROM customCategory WHERE ID in (select  szTYPE from  DecodeToStr(@CategoryThree_id))  
      set @PColNameThree = dbo.GetColName(@info_idThree,'ProductCategory') 
    end
    
  /*查找毛利区间表中的预估毛利区间取值 例如：1 ：零售价，2：预设售价1,3：预设售价2 .....*/
  select @code=code from 
  (
   select distinct code from mlRataRoom
  ) a
   /*通过所选择机构查询是否启用独立物价*/
  select @swarajprice=swarajPrice from company  where company_id=@y_id
  /*-处理类别组一*/
  if @CategoryCheckOne=3 
  begin
    if exists(select 1 from customCategory where class_id like @CategoryGroupClassidOne + '%' and LEN(class_id) = 8)
		SET @LENone=8
  end
  
  if  (@CategoryCheckOne=2) or (@LENone<>8)
  begin
       if exists(select 1 from customCategory where class_id like  @CategoryGroupClassidOne + '%' and LEN(class_id) = 6)
		SET @LENone=6
  end

  if  (@CategoryCheckOne=1) or (@LENone<>6 and @LENone<>8 )  
  begin
       if exists(select 1 from customCategory where class_id like  @CategoryGroupClassidOne  + '%' and LEN(class_id) = 4)
		SET @LENone=4
  end
  set @sqlstrOne =' select  a.id as cuid,a.name as cuname,class_id,parent_id,rowIndex,
                            a.modifyDate,deleted,pinyin,Child_Number,Child_Count,Typeid,Category_id,b.p_id
                           into ##PtempOne from customCategory a 
                            left join  ProductCategory b on a.class_id=b.'+@PColNameOne+'
                            where deleted=0'
  exec(@sqlstrOne) 
  if @CategoryTwo_id<>''
  begin
	  set @sqlstrTwo =' select  a.id as cuid,a.name as cuname,class_id,parent_id,rowIndex,
								a.modifyDate,deleted,pinyin,Child_Number,Child_Count,Typeid,Category_id,b.p_id
								into ##PtempTwo from customCategory a 
								inner join  ProductCategory b on a.class_id=b.'+@PColNametwo+'
								where deleted=0'
	  exec(@sqlstrTwo) 
  end
  if @CategoryThree_id<>''
  begin
	  set @sqlstrThree =' select  a.id as cuid,a.name as cuname,class_id,parent_id,rowIndex,
								a.modifyDate,deleted,pinyin,Child_Number,Child_Count,Typeid,Category_id,b.p_id
								into ##PtempThree from customCategory a 
								inner join  ProductCategory b on a.class_id=b.'+@PColNameThree+'
								where deleted=0'
	  exec(@sqlstrThree) 
  end
  

 /*处理类别组一*/
   insert into #CategoryALL(CategoryId,CategoryName,CategoryClassId)
   select distinct a.id,a.name as name,a.class_id from customCategory a inner join
	  (
	     select a.class_id from ##PtempOne a 
	                      where a.deleted=0  and 
	                            a.cuid in (select szTYPE from  dbo.DecodeToStr(@CategoryOne_id))
      )b  on  a.class_id LIKE b.class_id + '%' and len(a.class_id)=@LENone
  /*处理类别组一*/
   SELECT id  
   into #CategoryOne_id
    FROM customCategory x INNER JOIN 
       (    
          SELECT class_id 
            FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryOne_id))
       ) b  ON x.class_id LIKE b.class_id + '%' where x.Child_Number = 0 and x.deleted=0
   /*处理类别组二*/
   insert into  #CategoryTwo_id  
   SELECT class_id,id FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryTwo_id))
   /*处理类别组三*/
   insert into #CategoryThree_id(class_id,id)
   SELECT class_id,id   FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryThree_id))
    /*-毛利区间高中低取值*/
    select  name,id, baseinfo_id,class_id,mlqj into #MLQJ  from 
    (
    select a.name,a.id, a.baseinfo_id as baseinfo_id,a.class_id,
			case  when @code=1 then  (isnull(retailprice,0)-isnull(i.taxprice,0))/nullif(retailprice,0)
	              when @code=2 then  (isnull(price1,0)-isnull(taxprice,0))/nullif(price1,0)
	              when @code=3 then  (isnull(price2,0)-isnull(taxprice,0))/nullif(price2,0)
	              when @code=4 then  (isnull(price3,0)-isnull(taxprice,0))/nullif(price3,0)
	              when @code=5 then  (isnull(price4,0)-isnull(taxprice,0))/nullif(price4,0)
	              when @code=6 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              when @code=7 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              end as  mlqj   from 
			(
			  select a.cuname as name,a.cuid as id, a.P_id as baseinfo_id,retailprice,price1,price2,
			         price3,price4,gpprice ,glprice, a.class_id from 
						 ##PtempOne a
						 left join 
						 (
						     select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
						 ) d on a.p_id=d.p_id       
					   where a.deleted=0  and a.cuid in (select id from #CategoryOne_id)
			           
			)a left join 
			(
				select c.smb_id,c.p_id,b.taxprice from
				(
				select MAX(smb_id) smb_id,p_id from 
				buymanagebill where p_id>0 group by p_id 
				)c
				left join buymanagebill b on c.smb_id= b.smb_id
				left join billidx bx on b.bill_id= bx.billid and bx.billtype=20							
			 )i on a.baseinfo_id=i.p_id
	) d inner join (
						 select product_id,deleted  from products  where IsSplit=0 and deleted<>1
				   ) z on d.baseinfo_id=z.product_id
				   where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)/*是否停用		   */
						 
    select * into #CategoryFind from #CategoryALL
    truncate table #CategoryALL
    insert into #CategoryALL(CategoryId,CategoryName,CategoryClassId,ZPgNum,GMl,ZML,DML,FML) 
    select CategoryId,CategoryName,CategoryClassId,isnull(y.zpgnum,0) as zpgnum
    ,isnull(e.gml,0) as gml,isnull(f.zml,0) as zml,isnull(h.dml,0) as dml,isnull(i.fml,0) as fml
    from 
	  (
	   select * from  #CategoryFind
      )x 
      left join
      (
        select SUM(zpgnum) as  zpgnum,left(class_id,@LENone) as class_id  from 
         (
		  select id,class_id,count(distinct(a.baseinfo_id)) as zpgnum from 
		  (
		   select id,class_id,baseinfo_id from 
		   (
		     select a.cuid as id,isnull(a.p_id,'') as baseinfo_id,a.cuname as name,class_id from 
					 ##PtempOne a                 
				   where a.deleted=0   and a.cuid in (select id from  #CategoryOne_id) and a.p_id<>0
		   ) m 
		   inner join 
		   (
		     select product_id,deleted  from products
		   ) l  on m.baseinfo_id=l.product_id  where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)/*是否停用*/
		  )a  group by id,class_id
		 ) r group by left(class_id,@LENone)
      )y on  x.CategoryClassId=class_id
      left join 
      (
       select SUM(gml) as gml,left(class_id,@LENone) as class_id from 
       (
        select count(distinct(baseinfo_id)) as gml,class_id,id  
		from #MLQJ
	    where  isnull(mlqj,0)>=(select minValue/100 from mlRataRoom where name='高')
		group by class_id,id 
	   ) r group by  left(class_id,@LENone)
      ) e on  x.CategoryClassId=e.class_id
      left join 
      (
         select SUM(zml) as zml,left(class_id,@LENone) as class_id from 
         (
			select count(distinct(baseinfo_id)) as zml,class_id,id  
			from  #MLQJ
			where  (select minValue/100 from mlRataRoom where name='中') <= mlqj 
						and isnull(mlqj,0)< (select maxValue/100 from mlRataRoom where name='中')
			group by class_id,id 
		 ) r group by  left(class_id,@LENone)
      ) f on  x.CategoryClassId=f.class_id
      left join 
      (
         select SUM(dml) as dml,left(class_id,@LENone) as class_id from 
         (
				select count(distinct(baseinfo_id)) as dml,class_id,id  
				from  #MLQJ 
				where (select minValue/100 from mlRataRoom where name='低')<=mlqj
					  and  isnull(mlqj,0)<(select maxValue/100 from mlRataRoom where name='低')
				group by class_id,id 
		 ) r group by  left(class_id,@LENone)
      ) h on  x.CategoryClassId=h.class_id
      left join 
      (
        select SUM(fml) as fml,left(class_id,@LENone) as class_id from 
        (
			select count(distinct(baseinfo_id)) as fml,class_id,id  
			from  #MLQJ
			where  mlqj<0/*负毛利*/
			group by class_id,id 
		) r group by  left(class_id,@LENone)
      ) i on  x.CategoryClassId=i.class_id
    if @CategoryOne_id<>''
    begin 
	   insert into #tempThree(baseinfo_id,class_id)							 
       select distinct b.p_id as baseinfo_id ,class_id from 
							   ##PtempOne b
							   inner join 
							   (
									select product_id,deleted  from products  where IsSplit=0 and deleted<>1
							   ) z on b.p_id=z.product_id
									 where (@stopcheckd=0 ) or (@stopcheckd=1 and z.deleted<>4)
	end
    if @CategoryTwo_id<>''
    begin 
	   insert into #tempThree(baseinfo_id,class_id)							 
       select distinct b.p_id as baseinfo_id ,class_id from 
							   ##PtempTwo b
							   inner join 
							   (
									select product_id,deleted  from products  where IsSplit=0 and deleted<>1
							   ) z on b.p_id=z.product_id
									 where (@stopcheckd=0 ) or (@stopcheckd=1 and z.deleted<>4)
	end
    if @CategoryThree_id<>''
    begin	
      insert into #tempThree(baseinfo_id,class_id)							 
      select distinct b.p_id as baseinfo_id ,class_id from 
							   ##PtempThree b
							   inner join 
							   (
									select product_id,deleted  from products  where IsSplit=0 and deleted<>1
							   ) z on b.p_id=z.product_id
									 where (@stopcheckd=0 ) or (@stopcheckd=1 and z.deleted<>4)
	end
	/*exec E_ProductsCustomCategoryFx 2,0,'02',1,'471,472,473,474,475,487','03',1,'476,477,478,479,480','',0,''*/
   /*处理类别组二*/
   /*动态添加零时表中的列根据选择的类别组*/
   if @CategoryTwo_id<>''
   begin
    declare @IdOne int
    declare @CategoryClassId varchar(1000)
    declare @sql  varchar(1000)
    declare @colnameOne varchar(1000)
    declare @rowssumFour int
    declare @currentidxFour  int
    select  @currentidxFour=1
    select @rowssumFour=count(*) from #CategoryTwo_id
	 while @currentidxFour<=@rowssumFour
	 begin
	    select @IdOne=id,@CategoryClassId=class_id from #CategoryTwo_id where  RecId=@currentidxFour
	    if @IdOne <> 0
	    begin
	        set @colnameOne ='n2_'+cast(@IdOne as varchar)
		    set @sql =' ALTER TABLE #CategoryALL Add ['+@colnameOne+'] int not NULL default(0) '  
		    exec (@sql)
		    /*-添加一列之后循环零时表中的行，循环修改零时表当前列的每一行品规数的值*/
				declare @nameT varchar(1000)
				declare @RecIdTwo varchar(100)
				declare @CategoryClassIdT varchar(1000)
				declare @str   varchar(8000)
				declare @rwosum int
				declare @currentidx int
			    set @currentidx=1
			    select @rwosum =COUNT(*)  from #CategoryALL
			    while @currentidx<=@rwosum
			    begin
			       select @CategoryClassIdT = CategoryClassId,@RecIdTwo=RecId from #CategoryALL where RecId=@currentidx
			       set @str='
			      update #CategoryALL set '+@colnameOne+'=
			      (
			        select COUNT(distinct a.baseinfo_id) as pgqty from 
			        (
			          select  distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassId+'''+''%'' 
			        ) a inner join 
			        (
			           select distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdT+'''+''%'' 
			        ) b on a.baseinfo_id=b.baseinfo_id
			       ) where RecId='''+@RecIdTwo+''' '
					exec (@str)
					set @currentidx=@currentidx+1
		     end     
		 end	
		set @currentidxFour=@currentidxFour+1	    
      end 
   end
    /*-处理类别组三  */
    /*动态添加零时表中的列根据选择的类别组*/
    if @CategoryThree_id<>''
    begin
		declare @IdThree int
		declare @CategoryClassIdThree varchar(1000)
		declare @sqlThree  varchar(1000)
		declare @colnameThree varchar(1000)
		declare @rowssumThree int
		declare @currentidxthree int			  
       select @currentidxthree=1
       select @rowssumThree=COUNT(*) from #CategoryThree_id  
       while @currentidxthree<=@rowssumThree
	   begin
	     select @IdThree=id,@CategoryClassIdThree=class_id from #CategoryThree_id where  RecId=@currentidxthree
	     if @IdThree <>0
	     begin
	        set @colnameThree ='n3_'+cast(@IdThree as varchar)
		    set @sqlThree =' ALTER TABLE #CategoryALL Add ['+@colnameThree+'] int not NULL default(0) '  
		    exec (@sqlThree)
		    declare @nameThreeT varchar(1000)
			declare @CategoryClassIdThreeT varchar(1000)
			declare @strThree   varchar(8000)
			declare @CurcustormThreeT cursor
			declare @RecIdThree      varchar(100)
			declare @rwosumtwo int
			declare @currentidxtwo int
		    set @currentidxtwo=1
		    select @rwosumtwo =COUNT(*)  from #CategoryALL
			while @currentidxtwo<=@rwosumtwo
		    begin
			      select @CategoryClassIdThreeT = CategoryClassId,@RecIdThree=RecId from #CategoryALL where RecId=@currentidxtwo
			      set @strThree='
			      update #CategoryALL set '+@colnameThree+'=
			      (
			        select COUNT(distinct a.baseinfo_id) as pgqty from 
			        (
			          select   distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdThree+'''+''%'' 
			        ) a inner join 
			        (
			           select  distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdThreeT+'''+''%'' 
			        ) b on a.baseinfo_id=b.baseinfo_id
			       )  where RecId='''+@RecIdThree+''' '
					exec (@strThree)
					set @currentidxtwo=@currentidxtwo+1
		     end    
	     end	
        set @currentidxthree=@currentidxthree+1     
      end  
    end
   select * from #CategoryALL 
   if @CategoryThree_id<>''
   begin
     drop table  #tempThree
   end
   drop table  #CategoryALL
   drop table  #CategoryOne_id
   drop table  #CategoryTwo_id
   drop table  #CategoryThree_id
   drop table  #CategoryFind
   drop table  #MLQJ
   drop table  ##PtempOne
   if @CategoryTwo_id<>''
   begin
     drop table  ##PtempTwo
   end
   if @CategoryThree_id<>''
   begin
     drop table  ##PtempThree
   end
end
GO
