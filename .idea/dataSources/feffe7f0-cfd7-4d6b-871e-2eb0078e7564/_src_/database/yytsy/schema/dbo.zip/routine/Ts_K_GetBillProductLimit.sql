

CREATE PROCEDURE Ts_K_GetBillProductLimit(@PClassId VARCHAR(30), @BillType INT, @YId INT,@Ctype_ID INT = 0)
AS
BEGIN
	SELECT a.KeyID, a.BillType, a.YId, a.PId, a.Qty, a.BeginTime, a.EndTime, a.[Deleted], a.EId, a.ModifyDate, a.CreateDate,
	       e.name AS EName, y.name AS YName, isnull(c.name,'') as ctypename,p.Unit1Name, p.name, p.alias, p.serial_number, p.MedName, p.[standard], p.permitcode,
	       p.makearea, p.Factory
	FROM   (
	           SELECT a.* 
	           FROM   BillProductLimit a
	                  INNER JOIN products p
	                       ON  a.PId = p.product_id
	                       AND a.Deleted = 0
	                       AND a.YId = @YId
	                       AND (a.ctype_id = @Ctype_ID or @Ctype_ID = 0)
	                       AND (@BillType = 0 OR a.BillType = @BillType)
	                       AND p.class_id LIKE @PClassId + '%'
	       ) a
	       left JOIN vw_Products p
	            ON  a.PId = p.product_id
	       left JOIN employees e
	            ON  a.EId = e.emp_id
	       left JOIN company y
	            ON  a.YId = y.company_id
	       left join Clienttype c
	            on  a.ctype_id = c.Clienttype_id     
END
GO
