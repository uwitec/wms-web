
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-7-9*/
/* Description:	上传单据DTS表处理*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_DtsUpBillDeal]
AS
BEGIN
	/*RETURN*/
	SET NOCOUNT ON;
	
	DECLARE @nFor        INT
	DECLARE @nForsj        INT
	DECLARE @nNewBillId  INT
	DECLARE @nPid        INT 
	SET @nPid = 0
	DECLARE @nRetNum         INT
	DECLARE @nCur            INT
	DECLARE @nCursj            INT
	DECLARE @sBillNum        VARCHAR(100)
	
	DECLARE @nBillId         INT
	DECLARE @nBillType       INT
	DECLARE @cBillStates     CHAR(1)
	DECLARE @uGuid           UNIQUEIDENTIFIER
	DECLARE @YGuid           UNIQUEIDENTIFIER
	DECLARE @nYid            INT
	
	DECLARE @nBillEid        INT
	DECLARE @nBillInput      INT
	DECLARE @nBillAudit      INT
	
	DECLARE @nDefaultYid     INT
	DECLARE @nDefaultSid     INT
	DECLARE @nDefaultEid     INT
	DECLARE @nDefaultInput   INT
	DECLARE @nDefaultAudit   INT
	DECLARE @nDefaultAudit2  INT 
	DECLARE @PosType         INT
	DECLARE @nGspId          INT	
	DECLARE @QualityAudit    INT
	DECLARE @VipCardID		 INT
	DECLARE @BillYID		 INT /*业务单据对应的y_id	*/
	DECLARE @billDCount int, @RetailDCount int, @SmbDcount int, @PDCount int 
	DECLARE @YsendHeadquartersAuditor INT
	DECLARE @ZBAuditor       INT
			
	
	/*如果日志清除了，根据传输的单据找回已经过账成功的日志信息*/
	INSERT INTO BillLog
	  (
	    BillGuid, y_id, STATUS, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate
	  )
	SELECT guid, Y_ID, 0, 0, billid, billtype, 0, GETDATE(), billnumber, billdate
	FROM   BillIdx_Dts
	WHERE  GUID NOT IN (SELECT billguid FROM BillLog bl
	                           INNER JOIN billidx_dts d ON  bl.BillGuid = d.GUID AND bl.BillType = d.billtype)
	       AND GUID IN (SELECT GUID FROM billidx WHERE transflag <> 0)
	
	/*修改日志的传输标记，不管日志是否已经已传输*/
	UPDATE BillLog SET TransFlag = 0 WHERE  BillGuid IN (SELECT Guid FROM BillIdx_Dts)
	
	SELECT @nDefaultYid = ISNULL(sysvalue, 2) FROM sysconfig WHERE SYSNAME = 'y_id' AND Y_ID = 0
	
	SELECT @nDefaultSid = ISNULL(sysvalue, 0) FROM sysconfig WHERE SYSNAME = 'CenterSID' AND Y_ID = @nDefaultYid
	
	SELECT @nDefaultEid = ISNULL(sysvalue, 0) FROM sysconfig WHERE SYSNAME = 'Centereid' AND Y_ID = @nDefaultYid
	
	SELECT @nDefaultInput = ISNULL(sysvalue, 0) FROM sysconfig WHERE SYSNAME = 'CenterInputman' AND Y_ID = @nDefaultYid
	
	SELECT @nDefaultAudit = ISNULL(sysvalue, 0) FROM sysconfig WHERE SYSNAME = 'Centerauditman' AND Y_ID = @nDefaultYid
	
	SELECT @nDefaultAudit2 = ISNULL(sysvalue, 0) FROM sysconfig WHERE SYSNAME = 'Centerauditman2' AND Y_ID = @nDefaultYid
	
	SELECT @YsendHeadquartersAuditor = ISNULL(CAST(sysvalue AS INT),0) FROM sysconfigtmp WHERE SYSNAME = 'YsendHeadquartersAuditor'
	
	SELECT @ZBAuditor = ISNULL(tagNO,0) FROM sysconfigtmp WHERE SYSNAME = 'YsendHeadquartersAuditor'	
	
	/*DELETE FROM retailbillidx WHERE Y_ID <> @nDefaultYid AND billstates = '3'*/
	
	/*DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM billdraftidx) AND billstates = '0'*/
	
	/*DELETE FROM billidx_dts*/
	/*WHERE GUID IN (SELECT d.GUID FROM billidx i INNER JOIN BillIdx_Dts d ON i.GUID = d.GUID AND i.billtype = d.billtype) AND billstates = '0'*/
	
	/*DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM retailbillidx) AND billstates = '0'*/
	
	/*DELETE FROM billidx_dts WHERE GUID IN (SELECT GUID FROM gspbillidx) AND billstates = '0'*/
	/*--已红冲的单据不再处理*/
	/*DELETE FROM billidx_dts WHERE billstates IN (1, 4) AND GUID IN (SELECT GUID FROM billidx WHERE billstates IN (1, 4))*/
	
	/*所有退货调原单billid不对,遗留的报可退数量问题*/
	UPDATE salemanagebill_dts SET orgbillid = 0 /*WHERE bill_id IN (SELECT billid FROM billidx_dts WHERE billtype = 13)*/
	UPDATE buymanagebill_dts SET orgbillid = 0 
	
	/*UPDATE BillLog SET ErrCount = ErrCount + 1 WHERE BillGuid in(SELECT guid FROM BillIdx_Dts)*/
	INSERT INTO BillLog
	  (
	    BillGuid, y_id, STATUS, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate
	  )
	SELECT guid, Y_ID, 2, 0, billid, billtype, 0, GETDATE(), billnumber, billdate
		FROM BillIdx_Dts
	WHERE  GUID NOT IN (SELECT billguid FROM BillLog)
	
	/*小于本期开账日期的单据不过账 日志显示为正常 */
	/*IF EXISTS(SELECT BeginDate FROM MonthSettleInfo WHERE Y_ID = 2 AND MonthName = '本期')*/
	/*BEGIN*/
	/*    DECLARE @OpenAccountDate DATETIME*/
	/*    SELECT TOP 1 @OpenAccountDate = BeginDate FROM MonthSettleInfo WHERE Y_ID = 2 AND MonthName = '本期'*/
	    
	/*    DELETE FROM billidx_dts WHERE billdate < @OpenAccountDate*/
	    
	/*    UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE  billdate < @OpenAccountDate*/
	/*END*/
	
	TRUNCATE TABLE UPaccountdetailtmp    /*XXX.2016-12-15上传清空会计凭证临时表*/
	
	IF EXISTS(SELECT * FROM billidx_dts)
	BEGIN
	    DECLARE @nInsertNewBILLID INT
	    set @nInsertNewBILLID = 0
	    DECLARE @nNewRBillid INT
	    set @nNewRBillid = 0	    
	/*	DECLARE @MAXBILLID INT
		SET @MAXBILLID = 0
		DECLARE @MINBILLID INT
		SET @MINBILLID = 0
		DECLARE @BILLIDDIFF INT
		SET @BILLIDDIFF = 0
		DECLARE @RETAILBILLIDDIFF INT
		SET @RETAILBILLIDDIFF = 0
		DECLARE @SMBIDDIFF INT
		SET @SMBIDDIFF = 0  */
		
	END

	/*每次只导入一个门店的数据，避免出错*/
		
	select top 1 @BillYID = y_id from billidx_dts
	
	DECLARE @trantErrcount int set @trantErrcount = 0   /*XXX.统计一个事务中的错误	*/
	
	
	DECLARE curBill_up   SCROLL CURSOR  
	FOR
	    SELECT billid, billtype, billstates, guid, y_id, YGuid, vipcardid, detailcount FROM billidx_dts where Y_ID = @BillYID ORDER BY billid
	
	SET @nFor = 0
	OPEN curBill_up
	SET @nCur = @@CURSOR_ROWS

	/*insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
	select top 1 GUID,@nFor,0,@nCur,GETDATE(),billnumber,billdate,'进入游标'  FROM billidx_dts   */ 	
	
	WHILE @nFor < @nCur 
	BEGIN	  
	  /*begin tran upAllbill  --XXX.2016-12-20  在处理每张单据上传的时候加上事务，不然会出现在上传单据的时候做单，单据明细会增加  	  */
	    /*open curBill_up*/
	    
	    FETCH NEXT FROM curBill_up INTO @nBillId, @nBillType, @cBillStates, @uGuid, @nYid, @YGuid, @vipcardid, @billDCount	 

	    /*insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)*/
	    /*select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'游标遍历过的表值'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID	    */
	       
    	IF exists(select 1 from billidx where GUID  = @uGuid and billtype = @nBillType)
    	BEGIN
    	    PRINT ''  
    	   /* SET @nCur = @@CURSOR_ROWS*/
    	    insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
    	    select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'总部表已经存在'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
    	    SET @nFor = @nFor + 1
    	    /*commit tran upAllbill--yypeng-2016-12-28 13:43:59--跳出循环之前提交，不然事务没有结束会无限制锁表*/
    	    CONTINUE
    	END 	 	
    	    
		/*SET Transaction Isolation Level SERIALIZABLE    */
	    /* 零售单、零售退货单*/
	    IF @nBillType IN (12, 13)
	    BEGIN
	        /*处理门店上传总部后的顾客资料*/
  			INSERT INTO GSPCompy(Gspbill_Type, Gspbill_id, conName, CallNumber, IDNumber, [GUID])
  			SELECT a.Gspbill_Type, a.Gspbill_id, a.conName, a.CallNumber, a.IDNumber, a.[GUID] 
  				FROM GSPCompy_dts a INNER JOIN BillIdx_Dts b ON a.[GUID] = b.[GUID] 
  									LEFT JOIN GSPCompy g ON a.[GUID] = g.[GUID]
  			WHERE b.billid = @nBillId AND g.[GUID] IS NULL and b.Y_ID = @BillYID
  			  			
  			/*select @RetailDCount = COUNT(1)from retailbill_dts where bill_id IN (SELECT billid FROM RetailBillIdx_dts WHERE GUID IN(SELECT GUID FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID)) and p_id >0  			*/
  			select @SmbDcount = COUNT(1) from salemanagebill_dts where bill_id = @nBillId and Y_ID  = @BillYID and p_id > 0
  			select @PDCount = COUNT(1) from productdetail_dts where billid = @nBillId and Y_ID  = @BillYID 
  			
  			if not ((@billDCount = @SmbDcount) and (@billDCount = @PDCount))
  			begin
  			   PRINT ''  
    			insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
    			select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'明细不匹配'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID  			   
    	       SET @nFor = @nFor + 1
    	       /*commit tran upAllbill--yypeng-2016-12-28 13:43:59--跳出循环之前提交，不然事务没有结束会无限制锁表*/
    	       CONTINUE  			
  			end  			  			  			

			/*
			XXX.2016-12-27 
			设计思路：1.采用不打开自增列标识的方式，游标循环主表数据（在游标内加入事务），每插入一条主表，
					  用自增列作为新插入的主表的id 去关联对应的明细表，
					  2.明细表增加一列记录原来的对照关系的id，用来最后更新新的对照关系
			*/
			/*SET IDENTITY_INSERT billidx ON  								*/
	
			INSERT INTO billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
                      auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
                      transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
                      QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
            SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
                      auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
                      transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
                      QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
			FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
			
			select @nInsertNewBILLID=@@identity				
			 if @@ERROR <> 0
			 begin
				set @trantErrcount = @trantErrcount +1	
				insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
				select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'上传主表出现异常'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
			 end			
			/*SET IDENTITY_INSERT billidx OFF*/
			/*
			SELECT @MAXBILLID = MAX(smb_id) FROM salemanagebill
			if @MAXBILLID is null set @MAXBILLID = 0--yypeng-如果总部开始就是空账套，salemanagebill是没有值的，取出来就是NULL
			SELECT @MINBILLID = MIN(smb_id) FROM salemanagebill_dts WHERE bill_id = @nBillId and Y_ID = @BillYID
			if @MINBILLID is null set @MINBILLID = 0--yypeng-如果DTS表是空的，取出来就是NULL，上面只判断了BILLIDX_DTS表是否有东西
			SET @SMBIDDIFF = @MAXBILLID - @MINBILLID + 1*/
			INSERT INTO salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
                      SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
                      costtaxrate, costtaxprice, costtaxtotal,sm_SMID)
			SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
                      SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
                      costtaxrate, costtaxprice, costtaxtotal,smb_id
			FROM salemanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
			
			 if @@ERROR <> 0
			 begin
				set @trantErrcount = @trantErrcount +1
				insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
				select GUID,billtype,0,s.Y_ID,GETDATE(),billnumber,billdate,'上传salemanagebill表出现异常'  FROM salemanagebill_dts s,billidx_dts b WHERE s.bill_id = b.billid and s.bill_id = @nBillId and s.Y_ID  = @BillYID
			 end
			/*--XXX.2016-12-22 处理代金券上传*/
		 	if @nBilltype = 12   /*上传代金券使用状态，零售退货不处理代金券*/
			begin	 
			  declare @nUseYid int, @szUseMan varchar(100)
				select @nUseYid = y_id from billidx_dts where billid = @nBillId
			  if @vipCardID > 0 
				select @szUseMan = '卡号：'+cardno from VIPCard where VIPCardID = @vipCardID
			  else 
				select @szUseMan = '单位：' +c.name from clients c  inner join billidx_dts bi
				 on bi.c_id = c.client_id where bi.billid = @nBillId 
			  if @szUseMan is null set @szUseMan = ''
			   		 
			  update Cashcoupon set flag = 5, UseDate = GETDATE(), UseCompany = @nUseYid, UseMan  = @szUseMan 
			   where ccid in (select price_id 
							   from salemanagebill_dts 
							   where bill_id = @nBillId and p_id = -9999)
			end
			
			INSERT INTO RetailBillIDX( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
                      auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, VIPCardID, Y_ID, integral, integralYE)
			SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
                      auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, VIPCardID, Y_ID, integral, integralYE
			FROM retailbillidx_Dts WHERE GUID IN (SELECT GUID FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID)
			
			select @nNewRBillid = @@IDENTITY
			 if @@ERROR <> 0
			 begin
				set @trantErrcount = @trantErrcount +1
				insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
				select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'上传表RetailBillIDX出现异常'  FROM retailbillidx_Dts WHERE GUID IN (SELECT GUID FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID)
			 end

			INSERT INTO RetailBill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, PriceType, RowGuid, RowE_id, Y_ID, instoretime, cxType, 
                      BatchBarCode, scomment, batchprice, CxGuid, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal)
			SELECT @nNewRBillid, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, PriceType, RowGuid, RowE_id, Y_ID, instoretime, cxType, 
                      BatchBarCode, scomment, batchprice, CxGuid, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal
			FROM RetailBill_DTS WHERE bill_id IN (SELECT billid FROM RetailBillIdx_dts WHERE GUID IN(SELECT GUID FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID))

			 if @@ERROR <> 0
			 begin
				set @trantErrcount = @trantErrcount +1
				insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
				select GUID,billtype,0,s.Y_ID,GETDATE(),billnumber,billdate,'上传RetailBill表出现异常'  FROM RetailBill_DTS s,RetailBillIdx_dts b  WHERE s.bill_id = b.billid and bill_id IN (SELECT billid FROM RetailBillIdx_dts WHERE GUID IN(SELECT GUID FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID))
			 end
			
			INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
                      smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
                      scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
			SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
                      smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
                      scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
			FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID

			if @@ERROR <> 0
				set @trantErrcount = @trantErrcount +1		
				
			update productdetail set smb_id = s.smb_id from salemanagebill s 
			where productdetail.billid = s.bill_id and productdetail.md_SMID = S.sm_SMID AND productdetail.billid = @nInsertNewBILLID  
			
			/*DELETE FROM accountdetailtmp  */
			/*
			XXX.这儿把上传科目的明细只写到临时表，然后在最后对所有的临时表数据汇总，再去更新对应的应收应付科目总计
			下面其它的单据类型也一样的处理方式
			*/
			INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
			SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
			FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID			
			/*  
			SET @nBillId = @nBillId + @BILLIDDIFF
			EXEC ts_c_AuditA @nBillId, 0, 0  
			*/
			if @@ERROR <> 0
				set @trantErrcount = @trantErrcount +1			
			if @vipcardid = 0		    			
    	      UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
	    END/* 销售类单据*/
	    ELSE
	    IF @nBillType IN (10, 11, 16, 17, 110, 111, 112, 113, 210, 211, 212, 150, 151, 152, 153)
	    BEGIN
	        /*同济定制生成到草稿单据中*/
	        IF @nBillType IN (152) AND @YsendHeadquartersAuditor = 1
	        BEGIN
                INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,ZBAuditMan,ZBAuditDate)
				SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, '3', order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,ZBAuditMan,ZBAuditDate
				FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
	            
	            SET @nInsertNewBILLID=@@identity
	            
	            if @@ERROR <> 0
				 begin
					insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
					select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'上传主表出现异常'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
				 end
				 
				INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
						  costtaxrate, costtaxprice, costtaxtotal)
				SELECT    @nInsertNewBILLID, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
						  costtaxrate, costtaxprice, costtaxtotal
				FROM salemanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID

				if @@ERROR <> 0
				begin
					insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
					select GUID,billtype,0,s.Y_ID,GETDATE(),billnumber,billdate,'上传salemanagebilldrf表出现异常'  FROM salemanagebill_dts s,billidx_dts b WHERE s.bill_id = b.billid and s.bill_id = @nBillId and s.Y_ID  = @BillYID
				end
				
				UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid	 	
	        END
	        ELSE
	        BEGIN  
				INSERT INTO billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
				SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,@ZBAuditor,GETDATE()
				FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID

				select @nInsertNewBILLID=@@identity	
				 if @@ERROR <> 0
				 begin
					insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
					select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'上传主表出现异常'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
				 end
		
				INSERT INTO salemanagebill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
						  costtaxrate, costtaxprice, costtaxtotal,sm_SMID)
				SELECT    @nInsertNewBILLID, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, factoryid, 
						  costtaxrate, costtaxprice, costtaxtotal,smb_id
				FROM salemanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID

				 if @@ERROR <> 0
				 begin
					insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
					select GUID,billtype,0,s.Y_ID,GETDATE(),billnumber,billdate,'上传salemanagebill表出现异常'  FROM salemanagebill_dts s,billidx_dts b WHERE s.bill_id = b.billid and s.bill_id = @nBillId and s.Y_ID  = @BillYID
				 end
				
				INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
						  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
						  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
				SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
						  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
						  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
				FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID			
				
				update productdetail set smb_id = s.smb_id from salemanagebill s 
				where productdetail.billid = s.bill_id and productdetail.md_SMID = S.sm_SMID AND productdetail.billid = @nInsertNewBILLID  
				
				/*DELETE FROM accountdetailtmp  */
				INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
				SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
				FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
				
				/*SET @nBillId = @nBillId + @BILLIDDIFF*/
				/*EXEC ts_c_AuditA @nBillId, 0, 0*/
    			UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
    	    END
	    END/* 采购类单据*/
	    ELSE
	    IF @nBillType IN (20, 21, 24, 25, 120, 121, 122, 123, 160, 161, 162, 163, 220, 221, 222)
	    BEGIN
			/*分公司和加盟店不处理机构收获单*/
        	SELECT @PosType = ytype FROM company WHERE company_id = @nYid
        	
        	IF @nBillType = 160 AND @PosType IN (0, 2)
        	BEGIN
        	    PRINT ''  
        	    SET @nFor = @nFor + 1
        	    /*commit tran upAllbill--yypeng-2016-12-28 13:43:59--跳出循环之前提交，不然事务没有结束会无限制锁表*/
        	    CONTINUE
        	END 
        	/* 过账*/
        	IF @cBillStates = '0'
        	BEGIN
        	    IF @nBillType = 162
        	    BEGIN
			
					INSERT INTO billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
							  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
							  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
							  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
					SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
							  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
							  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
							  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
					FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
					
					select @nInsertNewBILLID=@@identity	
			
					INSERT INTO buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
							  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
							  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
							  costtaxtotal,bm_SMID)
					SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
							  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
							  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
							  costtaxtotal,smb_id
					FROM buymanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
					
					INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
							  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
							  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
					SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
							  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
							  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
					FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
				
					update productdetail set smb_id = s.smb_id from buymanagebill s 
					where productdetail.billid = s.bill_id and productdetail.md_SMID = S.bm_SMID AND productdetail.billid = @nInsertNewBILLID  
										
					/*DELETE FROM accountdetailtmp*/
					INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
					SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
					FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
					
					/*
					SET @nBillId = @nBillId + @BILLIDDIFF
					EXEC ts_c_AuditA @nBillId, 0, 0
					*/
    				UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
        	    END
        	    ELSE
        	    /* 机构收货退货单生成机构发货退货单草稿，同时也需要将收货退货单过帐*/
        	    IF @nBillType = 161
        	    BEGIN
        	        /*门店和内部机构需要过账原收货退货单*/
        	        SELECT @PosType = ytype FROM company WHERE company_id = @nYid
        	        
        	        IF @PosType IN (1, 3)
        	        BEGIN
				
						INSERT INTO billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
								  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
								  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
								  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
						SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
								  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
								  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
								  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
						FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
						
						select @nInsertNewBILLID=@@identity
				
						INSERT INTO buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
								  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
								  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
								  costtaxtotal,bm_SMID)
						SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
								  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
								  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
								  costtaxtotal,smb_id
						FROM buymanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
						
						INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
								  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
								  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
						SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
								  smb_id , comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
								  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
						FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID

						update productdetail set smb_id = s.smb_id from buymanagebill s 
						where productdetail.billid = s.bill_id and productdetail.md_SMID = S.bm_SMID AND productdetail.billid = @nInsertNewBILLID  
												
						/*DELETE FROM accountdetailtmp*/
						INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
						SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
						FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
						SET @nPid = @nInsertNewBILLID
						/*
						EXEC ts_c_AuditA @nPid, 0, 0
						*/
    					UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid

    	                IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND [sysvalue] = '1')
    	                BEGIN
    	                    /*生成GSP机构收货单*/
    	                    IF @nBillType IN (161)
    	                    BEGIN
    	                        EXEC TS_H_CreateNewGspBill;1 @nPid, @nBillType, 517, @nGspId 
    	                    END
    	                END
        	        END
        	        ELSE
        	           /* SET @nRetNum = 0  这儿ELSE 应该走下面的一段才符合逻辑    */
        	        BEGIN
        	            IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND [sysvalue] = '1')
        	            BEGIN
        	                /*生成GSP机构收货单*/
        	                IF @nBillType IN (161)
        	                BEGIN
        	                    EXEC TS_H_CreateNewGspBill;1 @nBillId, @nBillType, 517, @nGspId 
        	                    IF @nGspId > 0
        	                        UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
        	                END
        	            END
        	            ELSE
        	            BEGIN
        	                /* 过账成功后生成发货退货单草稿*/
        	                EXEC TS_H_CreateBillSN 151, 1, NULL, @nDefaultEid, @nDefaultInput, @sBillNum OUTPUT
        	                
        	                INSERT INTO billdraftidx
        	                  (
        	                    billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney,
        	                    quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate,
        	                    jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType,
        	                    ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate,
        	                    integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,ZBAuditMan,ZBAuditDate
        	                  )
        	                SELECT billdate, @sBillNum, 151, a_id, Y_ID, @nDefaultEid, @nDefaultSid, @nDefaultSid, @nDefaultAudit, @nDefaultInput, ysmoney, ssmoney,
        	                       quantity, taxrate, period, '3', 0, department_id, posid, region_id, auditdate, skdate,
        	                       jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType,
        	                       ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, @nDefaultYid, 2, begindate, Enddate,
        	                       integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, @YGuid,ZBAuditMan,ZBAuditDate
        	                FROM   dbo.BillIdx_Dts
        	                WHERE  billid = @nBillId and Y_ID  = @BillYID
        	                
        	                SET @nNewBillId = @@IDENTITY
        	                
        	                UPDATE buymanagebill_Dts 
        						SET ss_id = @nDefaultSid, sd_id = @nDefaultSid, location_id = 0, Y_ID = @nDefaultYid, RowE_id = @nDefaultEid
        	                WHERE  bill_id = @nBillId and Y_ID  = @BillYID
        	                
        	                /* 从原发货单获取价格及批次信息，并根据退货数量重算金额*/
        	                UPDATE buymanagebill_Dts
        						SET p_id = x.p_id, batchno = x.batchno, costprice = x.costprice, buyprice = x.saleprice,
        	                        discount = x.discount, discountprice = x.discountprice, totalmoney = x.saleprice * 
        	                        buymanagebill_Dts.quantity, taxprice = x.taxprice, taxtotal = x.taxprice * buymanagebill_Dts.quantity,
        	                        taxmoney = x.taxprice * buymanagebill_Dts.quantity - x.saleprice * buymanagebill_Dts.quantity,
        	                        retailprice = x.retailprice, retailtotal = x.retailprice * buymanagebill_Dts.quantity,
        	                        makedate = x.makedate, validdate = x.validdate, price_id = x.price_id, ss_id = x.ss_id, sd_id = x.sd_id,
        	                        location_id = x.location_id, supplier_id = x.supplier_id, commissionflag = x.commissionflag, unitid = x.unitid,
        	                        taxrate = x.taxrate, total = x.saleprice * buymanagebill_Dts.quantity, Y_ID = x.Y_ID,
        	                        instoretime = x.instoretime, batchprice = x.batchprice, BatchBarCode = x.BatchBarCode, scomment = x.scomment,
        	                        PriceType = x.PriceType, SendCostTotal = x.costprice * buymanagebill_Dts.quantity, RowE_id = x.RowE_id,
        	                        YCostPrice = x.YCostPrice, factoryid = x.factoryid, costtaxprice = x.costtaxprice,
        	                        costtaxrate = x.costtaxrate, costtaxtotal = x.costtaxprice * buymanagebill_Dts.quantity
        	                FROM   (
        	                           SELECT * FROM salemanagebill WHERE YGuid IN (SELECT YGuid FROM buymanagebill_Dts)
        	                       ) x
        	                WHERE  buymanagebill_Dts.YGuid = X.YGuid AND buymanagebill_Dts.bill_id = @nBillId
        	                
        	                INSERT INTO salemanagebilldrf
        	                  (
        	                    bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney,
        	                    taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus,
        	                    price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate,
        	                    order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice,
        	                    invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID,
        	                    transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid,
        	                    costtaxprice, costtaxrate, costtaxtotal
        	                  )
        	                SELECT @nNewBillId, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney,
        	                       taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
        	                       price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate,
        	                       0, total, iotag, InvoiceTotal, thqty, newprice, 0, AOID, jsprice, invoice,
        	                       invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID,
        	                       transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid,
        	                       costtaxprice, costtaxrate, quantity * costtaxprice
        	                FROM   dbo.buymanagebill_Dts
        	                WHERE  bill_id = @nBillId and Y_ID  = @nDefaultYid  /*XXX这个时候的y_id 已经被更新为总部的y_id了*/
        	                
        	                UPDATE BillLog
        	                SET    STATUS = 0,
        	                       InDateTime = GETDATE(),
        	                       ErrFlag = 0
        	                WHERE  BillGuid = @uGuid
        	            END
        	        END
        	    END
        	    ELSE
        	    BEGIN
			
					INSERT INTO billidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
							  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
							  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
							  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
					SELECT   billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
							  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
							  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
							  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
					FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
					
					select @nInsertNewBILLID=@@identity
			
					INSERT INTO buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
							  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
							  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
							  costtaxtotal,bm_SMID)
					SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
							  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
							  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
							  costtaxtotal,smb_id
					FROM buymanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
					
					INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
							  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
							  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
					SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
							  smb_id , comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
							  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
					FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
					
					update productdetail set smb_id = s.smb_id from buymanagebill s 
					where productdetail.billid = s.bill_id and productdetail.md_SMID = S.bm_SMID AND productdetail.billid = @nInsertNewBILLID  
					
					/*XXX.2017-01-05 更新门店做的采购的最近进价跟踪*/
					if @nBillType in (20)
					begin
						declare @BuyPriceTrace char(1)   /*进价跟踪*/
						declare @nPriceTrace INT         /*价格跟踪*/
						declare @nsmbid INT
						declare @nP_Id INT
						declare @nunitid INT
						
						declare @lastprice numeric(18,4)
						declare @dPrice numeric(18,4)
						declare @dTaxPrice numeric(18,4)
						declare @date datetime
						
						set @BuyPriceTrace = 0
						set @nPriceTrace = 0
						exec ts_getsysvalue 'UseBuyTrace',@BuyPriceTrace out  
						if (@BuyPriceTrace=1)  exec ts_getsysvalue 'PriceTrace',@nPriceTrace out 
						
						if @BuyPriceTrace=1
						begin						
							DECLARE curbuymanagebill   SCROLL CURSOR  
							FOR
							SELECT p.smb_id, p.p_id,p.unitid, i.billdate,p.costprice,p.taxprice 
							FROM buymanagebill p,billidx i 
							where  i.billid =@nInsertNewBILLID and p.bill_id = i.billid  and p.AOID =0 and p.p_id >0
							ORDER BY p.smb_id
							
							open curbuymanagebill							
							fetch next from curbuymanagebill into @nsmbid,@nP_Id,@nunitid,@date,@dPrice,@dTaxPrice
							while @@FETCH_STATUS=0
							begin
						   
								select @lastprice=0  
								select @lastprice=recprice from price 
								where p_id=@nP_Id and u_id=@nunitid and @date >= lasttime 
								/*XXX.这儿不需要单独处理独立物价，如果有独立物价，有price表的触发器*/
								if @nPriceTrace =0 and @lastprice<>@dPrice /*如果进价不发生变化则不更新进价*/
								begin  /*单价*/
    									update price set recprice=@dPrice,lastprice=@lastprice,lasttime=convert(varchar(10),@date,21),billid=@nInsertNewBILLID
  	  									where p_id=@nP_Id and u_id=@nunitid
								end else
								if @nPriceTrace =1 and @lastprice<>@dPrice 
								begin  /*单价*/
    									update price set recprice=@dPrice,lastprice=@lastprice,lasttime=convert(varchar(10),@date,21),billid=@nInsertNewBILLID
  	  									where p_id=@nP_Id and u_id=@nunitid            
								end else
								if @nPriceTrace =2 and @lastprice<>@dTaxPrice 
								begin  /*税率、税后单价*/
    									update price set recprice=@dTaxPrice,lastprice=@lastprice,lasttime=convert(varchar(10),@date,21),billid=@nInsertNewBILLID
  	  									where p_id=@nP_Id and u_id=@nunitid            
								end else
								begin
								  update price set lasttime=convert(varchar(10),@date,21),billid=@nInsertNewBILLID
  	  									where p_id=@nP_Id and u_id=@nunitid
								end
  								/*-更新价格跟踪表*/
  								exec ts_c_SaleBuyPriceTrace 'B',@nsmbid  			
								fetch next from curbuymanagebill into @nsmbid,@nP_Id,@nunitid,@date,@dPrice,@dTaxPrice
  	  						end
  	  						
  	  						close curbuymanagebill
							deallocate curbuymanagebill	  									
  	  					end
					end
					/*DELETE FROM accountdetailtmp*/
					INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
					SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
					FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
					SET @nPid = @nInsertNewBILLID
					/*
					EXEC ts_c_AuditA @nPid, 0, 0*/
					UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid

        	        BEGIN
        	            IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND [sysvalue] = '1')
        	            BEGIN
        	                /*生成GSP验收单*/
        	                IF @nBillType IN (163)
        	                BEGIN
        	                    /*由调拨单生成的收货退货单*/
        	                    /*IF EXISTS(SELECT 1 FROM billdraftidx WHERE billtype = 157 AND GUID = @YGuid) */
        	                    IF EXISTS(SELECT 1 FROM billdraftidx_dts WHERE billtype = 157 AND GUID = @YGuid) 
        	                    BEGIN
									/*生成收货单*/
									DECLARE @sh_id INT SET @sh_id = 0
				           
									EXEC TS_H_CreateNewGspBill;1 @nPid, @nBillType, 517, @sh_id OUTPUT
									IF @sh_id > 0
									BEGIN 
										UPDATE gspbillidx SET s_id = @nDefaultSid, BillStates = 13, auditman1 = @nDefaultAudit, auditTime1 = GETDATE()
										WHERE gspbillid = @sh_id  
										/* */
										UPDATE GSPbilldetail SET S_id = @nDefaultSid WHERE Gspbill_id = @sh_id  
									END 
				           
        											/*生成验收单*/
									EXEC TS_H_CreateNewGspBill;1 @sh_id, 517, 524, @nGspId output
        	                        IF @nGspId > 0
        	                        BEGIN
        	                            /*有特殊药品双人审核*/
        	                            IF EXISTS(SELECT 1 FROM GSPbilldetail WHERE Gspbill_id = @nGspId AND Isspec = 1)
        	                            BEGIN
        	                                UPDATE gspbillidx
        										SET s_id = @nDefaultSid, BillStates = 13, auditman1 = @nDefaultAudit, auditTime1 = GETDATE(),
        	                                        AuditMan2 = @nDefaultAudit2, AuditTime2 = GETDATE(),
        	                                        Note = (SELECT TOP 1 '原收货退货单编号:' + billnumber FROM billidx_dts WHERE billid = @nBillId)
        	                                WHERE  gspbillid = @nGspId
        	                            END
        	                            ELSE
        	                            BEGIN
        	                                UPDATE gspbillidx
        										SET s_id = @nDefaultSid, BillStates = 13, auditman1 = @nDefaultAudit, auditTime1 = GETDATE(),
        	                                       Note = (SELECT TOP 1 '原收货退货单编号:'+ billnumber FROM billidx_dts WHERE billid = @nBillId)
        	                                WHERE  gspbillid = @nGspId
        	                            END  
        	                            UPDATE GSPbilldetail SET S_id = @nDefaultSid WHERE Gspbill_id = @nGspId
        	                            
        	                            DECLARE @billsn VARCHAR(200) 
        	                            SET @billsn = ''
        	                            SELECT @billsn = billnumber FROM GSPbillidx WHERE gspbillid = @nGspId
        	                            
        	                            DECLARE @nGspId2 INT 
        	                            SET @nGspId2 = 0
        	                            /*生成上架单*/
        	                            EXEC TS_H_CreateNewGspBill @nGspId, 517, 531, @nGspId2 OUTPUT
        	                            
        	                            IF @nGspId2 > 0
        	                            BEGIN
        	                                UPDATE gspbillidx
        										SET BillStates = 13, auditman1 = @nDefaultAudit, auditTime1 = GETDATE(), Note = '原验收单编号:' + @billsn
        	                                WHERE gspbillid = @nGspId2
        	                                
        	                                SELECT @billsn = billnumber FROM GSPbillidx WHERE gspbillid = @nGspId2
        	                                
        	                                DECLARE @nGspId3 INT 
        	                                SET @nGspId3 = 0 
        	                                /*生成发货退货单草稿            */
        	                                EXEC TS_H_CreateNewGspBill;1 @nGspId2, 531, 153, @nGspId3 OUTPUT
        	                                IF @nGspId3 > 0
        	                                BEGIN
        	                                    UPDATE billdraftidx
        											SET billstates = 3, auditman = @nDefaultAudit, auditdate = GETDATE(), note = '原上架单编号:' + @billsn
        	                                    WHERE billid = @nGspId3
        	                                    
        	                                    UPDATE salemanagebilldrf SET orgbillid = 0 WHERE bill_id = @nGspId3
        	                                    
        	                                    SELECT @billsn = billnumber FROM billdraftidx WHERE billid = @nGspId3
        	                                    
        	                                    EXEC ts_c_BillAudit @nGspId3, @nPid OUTPUT, @nRetNum OUTPUT, 153
        	                                    
        	                                    IF @nPid > 0
        	                                    BEGIN
        	                                        /*生成自营店发货单 SELECT transflag,* FROM billdraftidx*/
        	                                        EXEC TS_H_CreateBillSN  152, 1, NULL, 0, 0, @BillSN OUTPUT, 0
        	                                        
        	                                        INSERT INTO billdraftidx
        	                                          (
        	                                            billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id,
        	                                            auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period,
        	                                            billstates, order_id, department_id, posid, region_id, auditdate,
        	                                            skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime,
        	                                            GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan,
        	                                            VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, 
        	                                            integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate,
        	                                            sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid,ZBAuditMan,ZBAuditDate
        	                                          )
        	                                        SELECT billdate, @BillSN, 152, a_id, c_id, @nDefaultEid, @nDefaultSid, sin_id,
        	                                               @nDefaultAudit, @nDefaultInput, ysmoney, ssmoney, quantity, taxrate, period,
        	                                               3, -1, department_id, posid, region_id, GETDATE(), 
        	                                               skdate, jsye, jsflag, '原调拨单编号:' + billnumber, summary, invoice, transcount, lasttranstime,
        	                                               NEWID(), InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan,
        	                                               VIPCardID, jsInvoiceTotal, 2, 0, begindate, Enddate, integral,
        	                                               integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate,
        	                                               sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, GUID,ZBAuditMan,ZBAuditDate
        	                                        FROM   billdraftidx_dts
        	                                        WHERE  billid = (SELECT billid FROM billdraftidx_dts WHERE billtype = 157 AND GUID = @YGuid)
        	                                        
        	                                        SET @nNewBillId = @@IDENTITY
        	                                        
        	                                        INSERT INTO salemanagebilldrf
        	                                          (
        	                                            bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice,
        	                                            totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate,
        	                                            validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id,
        	                                            commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal,
        	                                            thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY,
        	                                            SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime,
        	                                            cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid,
        	                                            Conclusion, OOSid, factoryid, costtaxprice, costtaxrate, costtaxtotal
        	                                          )
        	                                        SELECT @nNewBillId,
        	                                               p_id, batchno, quantity,  costprice, saleprice, discount, discountprice, 
        	                                               totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate,
        	                                               validdate, qualitystatus, price_id, @nDefaultSid, sd_id, 0, supplier_id,
        	                                               commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal,
        	                                               thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY,
        	                                               SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, 2, transflag, instoretime,
        	                                               cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid,
        	                                               Conclusion, OOSid, factoryid, costtaxprice, costtaxrate, quantity * costtaxprice
        	                                        FROM   salemanagebilldrf_dts
        	                                        WHERE  bill_id = (SELECT billid FROM billdraftidx_dts WHERE billtype = 157 AND GUID = @YGuid)   
        	                                        
        	                                        EXEC ts_c_BillAudit @nNewBillId, @nPid OUTPUT, @nRetNum OUTPUT, 152
        	                                        
        	                                        /*更新调拨单传输状态*/
        	                                        UPDATE billdraftidx_dts SET transflag = 0 WHERE  billtype = 157 AND GUID = @YGuid
        	                                    END
        	                                END
        	                            END/*exec TS_H_GspBillAct 3,@nGspId,524,@nDefaultEid,NULL*/
        	                        END
        	                    END
        	                    ELSE
        	                    BEGIN
        	                        EXEC TS_H_CreateNewGspBill;1 @nPid, @nBillType, 517, @nGspId 
        	                        IF @nGspId > 0
        	                            UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
        	                    END
        	                END
        	            END
        	        END
        	    END
        	END
        	ELSE
        	/* 其他*/
        	BEGIN
		
				INSERT INTO billidx( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
				SELECT   billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
						  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
						  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
						  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
				FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
				
				select @nInsertNewBILLID=@@identity
		
				INSERT INTO buymanagebill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
						  costtaxtotal,bm_SMID)
				SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
						  ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, invoice, invoiceno, AOID, jsprice, PriceType, SendQTY, 
						  SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, 
						  costtaxtotal,smb_id
				FROM buymanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
				
				INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
						  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
						  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
				SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
						  smb_id , comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
						  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
				FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
				
				update productdetail set smb_id = s.smb_id from buymanagebill s 
				where productdetail.billid = s.bill_id and productdetail.md_SMID = S.bm_SMID AND productdetail.billid = @nInsertNewBILLID  				
				
				/*DELETE FROM accountdetailtmp*/
				INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
				SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
				FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
				
				/*SET @nBillId = @nBillId + @BILLIDDIFF
				EXEC ts_c_AuditA @nBillId, 0, 0
				*/
				UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
        	END
	    END/* 库存类单据*/
	    ELSE
	    IF @nBillType IN (30, 31, 33, 34, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 100, 101, 141)
	    BEGIN
	
			INSERT INTO billidx( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
			SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
			FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
			
			select @nInsertNewBILLID = @@IDENTITY
	
			INSERT INTO storemanagebill(bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                      commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, 
                      batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal,sm_SMID)
			SELECT @nInsertNewBILLID, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                      commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, 
                      batchprice, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal,smb_id
			FROM storemanagebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
			
			INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
			SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
			FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			update productdetail set smb_id = s.smb_id from storemanagebill s 
			where productdetail.billid = s.bill_id and productdetail.md_SMID = S.sm_SMID AND productdetail.billid = @nInsertNewBILLID  
						
			/*DELETE FROM accountdetailtmp*/
			INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
			SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
			FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			/*SET @nBillId = @nBillId + @BILLIDDIFF
			EXEC ts_c_AuditA @nBillId, 0, 0*/
			UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
	    END/* 财务类单据*/
	    ELSE
	    IF @nBillType IN (15, 23, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 80, 81, 82, 83, 84, 87, 88, 90, 115, 146, 147, 155, 165, 170, 171, 172, 173, 174)
	    BEGIN
	
			INSERT INTO billidx( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
			SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
			FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
			
			select @nInsertNewBILLID = @@IDENTITY
	
			INSERT INTO financebill(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_ID, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal)
			SELECT @nInsertNewBILLID, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_ID, Conclusion, factoryid, costtaxrate, costtaxprice, costtaxtotal
			FROM financebill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
			
			/*DELETE FROM accountdetailtmp*/
			INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
			SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
			FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			/*SET @nBillId = @nBillId + @BILLIDDIFF
			EXEC ts_c_AuditA @nBillId, 0, 0*/
			UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
	    END/* 库存盘点单*/
	    ELSE
	    IF @nBillType IN (50)
	    BEGIN
	
			INSERT INTO billidx( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
			SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
			FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
			
			select @nInsertNewBILLID = @@IDENTITY
	
			INSERT INTO GoodsCheckBill(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, AOID, RowGuid, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion, factoryid, 
                      costtaxrate, costtaxprice, costtaxtotal,gm_SMID)
			SELECT @nInsertNewBILLID, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, 
                      ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, AOID, RowGuid, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion, factoryid, 
                      costtaxrate, costtaxprice, costtaxtotal,smb_id
			FROM GoodsCheckBill_dts WHERE bill_id = @nBillId and Y_ID  = @BillYID
			
			INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
			SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id , comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
			FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			update productdetail set smb_id = s.smb_id from GoodsCheckBill s 
			where productdetail.billid = s.bill_id and productdetail.md_SMID = S.gm_SMID AND productdetail.billid = @nInsertNewBILLID  
						
			/*DELETE FROM accountdetailtmp*/
			INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
			SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
			FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			/*SET @nBillId = @nBillId + @BILLIDDIFF
			EXEC ts_c_AuditA @nBillId, 0, 0*/
			UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
	    END/* 积分兑换单*/
	    ELSE
	    IF @nBillType IN (149)
	    BEGIN
	
			INSERT INTO billidx( billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate)
			SELECT  billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, 
					  transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, ImportJscw, JscwGuid, RetailDate, sendC_id, Sendid, WholeQty, PartQty, DPdate, 
					  QualityAudit, QualityAuditDate, YGuid, FollowNumber, TicketDate, BalanceMode, financeAudit, financeAuditDate,detailcount,ZBAuditMan,ZBAuditDate
			FROM billidx_dts WHERE billid = @nBillId and Y_ID  = @BillYID
			
			select @nInsertNewBILLID = @@IDENTITY
	
			INSERT INTO ExIntegRalManagebill(billid, p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid, batchno, makedate, validdate, 
                      location_id, supplier_id, commissionflag, SendQTY, SendCostTotal, rowguid, Y_Id, instoretime, factoryid, costtaxrate, costtaxprice, costtaxtotal,em_SMID)
			SELECT @nInsertNewBILLID, p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid, batchno, makedate, validdate, 
                      location_id, supplier_id, commissionflag, SendQTY, SendCostTotal, rowguid, Y_Id, instoretime, factoryid, costtaxrate, costtaxprice, costtaxtotal,smb_id
			FROM ExIntegRalManagebill_dts WHERE billid = @nBillId and Y_ID  = @BillYID
			
			INSERT INTO productdetail(billid, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,md_SMID)
			SELECT @nInsertNewBILLID, p_id, s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal, batchno, makedate, validdate, commissionflag, supplier_id, location_id, storetype, price_id, order_id, unitid, 
					  smb_id, comment, oldcommissionflag, AOID, jsprice, rowguid, ROWE_id, SendQTY, SendCostTotal, retailtotal, Y_ID, transflag, instoretime, cxType, retailprice, thqty, FlowFlag, BatchBarCode, 
					  scomment, batchprice, factoryid, costtaxtotal, costtaxrate, costtaxprice, taxrate,smb_id
			FROM productdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			update productdetail set smb_id = s.smb_id from ExIntegRalManagebill s 
			where productdetail.billid = s.billid and productdetail.md_SMID = S.em_SMID AND productdetail.billid = @nInsertNewBILLID  
						
			/*DELETE FROM accountdetailtmp*/
			INSERT INTO UPaccountdetailtmp(billid, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag)
			SELECT @nInsertNewBILLID, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, transflag
			FROM accountdetail_DTS WHERE billid = @nBillId and Y_ID  = @BillYID
			
			/*SET @nBillId = @nBillId + @BILLIDDIFF
			EXEC ts_c_AuditA @nBillId, 0, 0
			*/
			UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @uGuid
	    END
	    
	    SET @nFor = @nFor + 1
	        /*  PRINT @nFor*/
	 /*   if @trantErrcount = 0    --XXX.主要检测零售单上传过程中是否发生错误，如果出现错误，回滚当前操作*/
		/*	commit tran upAllbill*/
		/*else if @@TRANCOUNT > 0*/
		/*	rollback tran upAllbill	 */
/*		SET Transaction Isolation Level Read UNCOMMITTED       */
	END
	DEALLOCATE curBill_up
	
	
	/*XXX.2016-12-15 在单据传输完成后，一次性处理科目会计凭证的明细表	*/
	TRUNCATE TABLE accountdetailUPtmp
	IF EXISTS (SELECT TOP 1 * FROM UPaccountdetailtmp)
	BEGIN
		INSERT INTO accountdetailUPtmp(billtype, a_id, c_id, jdmoney, jdflag, rowguid, Y_ID, E_ID, transflag)
		select b.billtype,p.a_id,p.c_id,sum(p.jdmoney) as jdmoney,p.jdflag,NEWID(),p.Y_ID,b.e_id,0
		from UPaccountdetailtmp p,billidx b where  p.billid=b.billid
		GROUP BY  b.billtype,p.a_id,p.c_id,p.jdflag,p.Y_ID,b.e_id
		
		declare @nReturnNumber int
		declare @nA_id int,@nC_id int,@nE_id int,@dTotal numeric(18,4)
		declare @szPeriod varchar(2)
		declare 
		@ArTotal_Id 		int,				/*9	『应收款合计』*/
		@ApTotal_Id 		int					/*15	『应付帐款合计』*/
		select	@ArTotal_Id		=9			/*9	『应收款合计』*/
		select	@ApTotal_Id		=15			/*15	『应付帐款合计』	*/
		set @nReturnNumber = 0
		
		declare @nTmpBillId int
		declare adetailUPtmp_cursor cursor scroll for
		select Y_ID,billtype, a_id, c_id, jdmoney, E_ID  from accountdetailUPtmp
		open adetailUPtmp_cursor
		fetch next from adetailUPtmp_cursor into @nYid,@nBillType,@nA_id,@nC_id,@dTotal,@nE_id
		while @@FETCH_STATUS=0	
		begin
			
			/*EXEC ts_c_UPBillAuditA @nTmpBillId, 0   */
			/*对汇总后的科目汇总去做对应的应收应付科目汇总*/
			exec ts_c_ModifyA @nBillType,@nA_id,@nC_id,@nE_id,'',@dTotal,@nReturnNumber output,@nYid
			
			fetch next from adetailUPtmp_cursor into @nYid,@nBillType,@nA_id,@nC_id,@dTotal,@nE_id
		end
		Close adetailUPtmp_cursor
		deallocate adetailUPtmp_cursor
				
		/*处理完会计科目的明细和汇总后，最后才讲明细表 搬移财务明细帐	*/
	    insert into accountdetail ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID],rowguid,transflag)
	    select [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID],rowguid,transflag
	    from UPaccountdetailtmp
	END
	TRUNCATE TABLE accountdetailUPtmp
	truncate table UPaccountdetailtmp
	
	/*------------------------草稿单据-------------------------*/
	/*写入日志*/
	DELETE FROM billdraftidx_dts WHERE GUID IN (SELECT GUID FROM billidx) AND billstates = '0'
	DELETE FROM billdraftidx_dts WHERE GUID IN (SELECT GUID FROM billdraftidx) AND billstates IN (3)
	
	INSERT INTO BillLog(BillGuid, y_id, Status, ErrCount, Bill_id, BillType, UpOrDown, InDateTime, billnumber, billdate)
	SELECT guid, Y_ID, 2, 0, billid, billtype, 0, GETDATE(), billnumber, billdate 
	FROM BillDraftIdx_Dts 
	WHERE GUID not in (SELECT billguid FROM BillLog)
	
	/*处理草稿单据*/
	DECLARE CurDraft SCROLL CURSOR FOR
	SELECT billid, billtype, billstates, guid, y_id, YGuid,QualityAudit FROM billdraftidx_dts ORDER BY billid
	SET @nFor = 0
	OPEN CurDraft
	SET @nCur = @@CURSOR_ROWS
	WHILE @nFor < @nCur
	BEGIN
		FETCH NEXT FROM CurDraft INTO @nBillId, @nBillType, @cBillStates, @uGuid, @nYid, @YGuid,@QualityAudit
		/*上传的已审核的调拨单*/
		/*xxx.2017-05-16  这儿处理上传发货单位审核完成的店间调拨单*/
		IF @nBillType IN (157) AND @cBillStates IN (0)
		BEGIN  
		    /*Wusj.2017-05-16.Tfs48219 这儿检查billdraftidx 不能使用CONTINUE*/
			IF exists(select 1 from billdraftidx where GUID  = @uGuid and billtype = @nBillType)
			BEGIN
				insert into UpDownBillLog( BillGuid, BillType, UpOrDown, y_id, InDateTime, BillNumber, BillDate, ErrMsg)
				select GUID,billtype,0,Y_ID,GETDATE(),billnumber,billdate,'总部表已经存在'  FROM billidx_dts WHERE billid = @nBillId and Y_ID = @BillYID
			END 
    	    ELSE 
    	    BEGIN
		  		INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid,ZBAuditMan,ZBAuditDate)
				SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid,ZBAuditMan,ZBAuditDate FROM billdraftidx_dts
				WHERE billid = @nBillId
		
				SET @nNewBillId = @@IDENTITY
		
				INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
					price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
					iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
					SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, 
					comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, costtaxprice, factoryid, costtaxrate,
					costtaxtotal)
				SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
					price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
					iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
					SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, 
					comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid, costtaxprice, factoryid, costtaxrate,
					costtaxtotal
				FROM salemanagebilldrf_dts
				WHERE bill_id = @nBillId
		
				UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @uGuid
				
				EXEC TS_H_BillTraceAct 0, @nNewBillId, @nBillType, 0, @nBillType, 1, 1      
		    END
		END
	
		/*上传的已同意或已拒绝的调拨单*/
		IF @nBillType IN (157) AND @cBillStates IN (0,1)
		BEGIN
			UPDATE billdraftidx SET billstates = @cBillStates,QualityAudit=@QualityAudit WHERE GUID = @uGuid
		END
	
		/*上传的自营店付款单*/
		IF @nBillType IN (159) AND @cBillStates IN (3)
		BEGIN 
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid,ZBAuditMan,ZBAuditDate)
			SELECT billdate, billnumber, 158, a_id, y_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, C_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid,ZBAuditMan,ZBAuditDate
			FROM billdraftidx_dts
			WHERE billid = @nBillId
	
			SET @nNewBillId = @@IDENTITY
	
			INSERT INTO financebilldrf(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id, Conclusion)
			SELECT @nNewBillId, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, InvoiceTotal, RowGuid, Y_Id, Conclusion
			FROM financebilldrf_dts 
			WHERE bill_id = @nBillId

			UPDATE BillLog
			SET    STATUS = 0,
				   InDateTime = GETDATE(),
				   ErrFlag = 0
			WHERE  BillGuid = @uGuid
		END  

		SET @nFor = @nFor + 1
		/*  PRINT @nFor  */
    END
	DEALLOCATE CurDraft
	
	/*处理会员积分*/
		
	declare @billguid varchar(60),  @totalltg numeric(18, 4), @ljtotalye numeric(18, 4)
	declare @vipbillid int, @newbillid int, @newvipbillid int
	declare @BuyMoney numeric(18, 4)   /*消费金额*/
	declare @BuyCount int     /*消费次数*/
	declare @IsBank int   /*判断是否是储值卡，1表示是储值卡*/
	declare @nCashIntegral int   /*积分抵现*/
	
	DECLARE curvip   SCROLL CURSOR  
	FOR
	    SELECT billguid, billid, vipcardid, totalItg, ljtotalye, y_id FROM Integralidx_dts where bill_id in (select billid from billidx_dts where billstates = 0) ORDER BY billid	    	/*xxx暂时红冲了的单据不需要传积分明细，下周讨论把红冲单据上传    		    	    */
	SET @nFor = 0
	OPEN curvip
	SET @nCur = @@CURSOR_ROWS
	WHILE @nFor < @nCur
	BEGIN
	    FETCH NEXT FROM curvip INTO @billguid, @vipbillid, @vipcardid, @totalltg, @ljtotalye, @nyid
	    if (not exists(select 1 from Integralidx where billguid = @billguid)) and (exists (select 1 from billidx where [GUID] = @billguid and billtype in (12, 13)))	     
	    begin
	      select @newbillid =  billid from billidx where [guid] = @billguid and billtype  in (12, 13) 
	      insert into Integralidx(bill_id, VIPCardID, I_id, Itgmode, totalItg, totalye, ljtotalye, billdate, remake, PtotalItg, Y_ID, billguid, transflag)
	      select @newbillid, VIPCardID, I_id, Itgmode, totalItg, totalye, ljtotalye, billdate, remake, PtotalItg, Y_ID, billguid, transflag from Integralidx_dts
	      where billguid = @billguid	      
		  set @newvipbillid =@@IDENTITY		  
		  insert into Integraldetail(billid, smb_id, totalmoney, baseItg, Itgrate, totalItg, remake, Y_ID, rowguid)
		  select @newvipbillid, mx.smb_id, vip.totalmoney, baseItg, Itgrate, totalItg, remake, vip.Y_ID, vip.rowguid
		    from Integraldetail_dts vip inner join salemanagebill mx on vip.rowguid = mx.RowGuid
		    where vip.billid = @vipbillid
		  select @BuyMoney =SUM(taxtotal) from salemanagebill where bill_id = @newbillid
		  
		  /*XXX.2017-02-07 因为积分抵现，实时处理的总部，这儿不能再减一次  ,*/
		  /*XXX.2017-04-05 零售退货的时候不需要直接连接总部，所以这儿需要上传*/
		  if  (exists (select 1 from billidx where [GUID] = @billguid and billtype = 12)) 
		  BEGIN
			select @nCashIntegral = floor(isnull(SUM(totalItg),0)) from Integraldetail where rowguid in (select rowguid from salemanagebill where bill_id = @newbillid 
																						and p_id = -(select account_id from account where class_id = '000004000003000009'))
																						and (remake <> '扣除抵现金额的积分')    /*xxx.2017-02-20  这个需要上传*/
		  END
		  ELSE
			set @nCashIntegral = 0
			
		  if @nCashIntegral is null set @nCashIntegral = 0
		  
		  select @IsBank = VT.isBank from VIPCard V,VIPCardType VT where V.CT_ID = VT.ct_id AND V.VIPCardID = @vipcardid   
		  IF @IsBank IS NULL SET @IsBank = 0
		  if @IsBank = 0 
			update VIPCard set Integral = Integral+@totalltg-@nCashIntegral,TotalBuyMoney = TotalBuyMoney + @BuyMoney,BuyCount = BuyCount +1, IntergralYE = @ljtotalye where VIPCardID = @vipcardid
		 /*XXX.2016-11-18 储值卡都直接在客户端更新了总部*/
		 /* -else		--储值卡直接更新了总部的消费金额和消费次数 */
		--	update VIPCard set Integral = Integral+@totalltg/*,TotalBuyMoney = TotalBuyMoney + @BuyMoney,BuyCount = BuyCount +1*/, IntergralYE = @ljtotalye where VIPCardID = @vipcardid	

		  UPDATE BillLog SET STATUS = 0, InDateTime = GETDATE(), ErrFlag = 0 WHERE BillGuid = @billguid		  	  	     	      	    
	    end	      	   
	   SET @nFor = @nFor + 1 
	end 
	DEALLOCATE curvip  	
	
	/* 增加会员卡自动升级功能----zjx--2016-12-22--tfs44243---处理自动升级会员卡*/
	DECLARE @CARDTYPE INT	/*卡类型*/
	DECLARE @MONEYLIMIT NUMERIC(18, 4)
	DECLARE @ITGLIMIT NUMERIC(18, 4)
	DECLARE @Integralupkc NUMERIC(18, 4)
	DECLARE @NEWCARDMONEY INT
	DECLARE @NEWCARDITG INT
	DECLARE @CURMONEY NUMERIC(18, 4)
	DECLARE @CURITG NUMERIC(18, 4)
	DECLARE @UPGRADED BIT
	DECLARE @CardName varchar(100)
	DECLARE @moneyUPCName varchar(100)
	DECLARE @integraUPCName varchar(100)
	
	declare @CZMoney   NUMERIC(18, 4)
	declare @NEWCZMONEY  INT
	DECLARE @CZGLIMIT NUMERIC(18, 4)
	DECLARE @CZUPCName varchar(100)

	SET @UPGRADED = 0
    
    DECLARE curvipsj   SCROLL CURSOR  
	FOR
	    SELECT distinct vipcardid FROM billidx_dts where billtype=12 ORDER BY vipcardid	    	    		    	    
	SET @nForsj = 0
	OPEN curvipsj
	SET @nCursj = @@CURSOR_ROWS
	WHILE @nForsj < @nCursj
	BEGIN
                FETCH NEXT FROM curvipsj INTO  @vipcardid
				SELECT @CARDTYPE = CT_ID, @CURMONEY = TotalBuyMoney,@CZMoney=SaveMoney,  @CURITG = Integral FROM VIPCard WHERE VIPCardID = @vipcardid
				IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
									AND ismoneyup = 1 and isMoneyAutoup = 1)  /*先判断消费金额升级*/
				BEGIN
					SELECT TOP 1 @MONEYLIMIT = moneyup,  @NEWCARDMONEY = moneyupC_id,
						@CardName = ISNULL(cardnamestr,''),@moneyUPCName = ISNULL(moneyupC_name,'')
					FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 AND ismoneyup = 1 and isMoneyAutoup = 1			

					IF @CURMONEY >= @MONEYLIMIT AND @NEWCARDMONEY <> @CARDTYPE
					BEGIN
						UPDATE VIPCard SET CT_ID = @NEWCARDMONEY WHERE VIPCardID = @vipcardid
						/*写入日志*/
						insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
						select 1,'system','自动升级',GETDATE(),VIPCardID,0,isnull(Integral,0.0),isnull(TotalBuyMoney,0.0),0,0.00,@CardName + '→' +@moneyUPCName
							FROM VIPCard WHERE VIPCardID = @vipcardid
						SET @UPGRADED = 1
							
					END
				END
				IF @UPGRADED = 0
				BEGIN
					IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
										AND isIntegralup = 1 and isautoup = 1)  /*如果为执行消费金额升级，再判断积分升级*/
					BEGIN
						SELECT TOP 1 @ITGLIMIT = Integralup,@Integralupkc = Integralupkc,  @NEWCARDITG = IntegralupC_id,
							@CardName = ISNULL(cardnamestr,''),@integraUPCName =ISNULL(IntegralupC_name,'')
						FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 AND isIntegralup = 1 and isautoup = 1

						IF @CURITG >= @ITGLIMIT AND @NEWCARDITG <> @CARDTYPE
						BEGIN
							UPDATE VIPCard SET CT_ID = @NEWCARDITG,Integral = Integral-isnull(@Integralupkc,0)  WHERE VIPCardID = @vipcardid
							/*写入日志*/
							insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
							select 1,'system','自动升级',GETDATE(),VIPCardID,0,isnull(Integral,0.0),isnull(TotalBuyMoney,0.0),0,0.00,@CardName + '→' +@integraUPCName
							FROM VIPCard WHERE VIPCardID = @vipcardid
							/*SET @UPGRADED = 1*/
						END
					END
				END
				/*IF @UPGRADED = 0
				BEGIN
					IF EXISTS(SELECT 1 FROM VipCardTypeExtend WHERE bill_id = @CARDTYPE and Deleted = 0 
										AND isStoragUp = 1 and isStoragAutoup = 1)  --如果为执行积分升级，再判断储值升级
					BEGIN
						SELECT TOP 1 @CZGLIMIT=a.UpStorag,  @NEWCZMONEY = a.lStoragUpCT_id,
							@CardName = ISNULL(a.cardnamestr,''),@CZUPCName =ISNULL(b.Name,'')
						FROM VipCardTypeExtend a left join VIPCardType b on a.lStoragUpCT_id=b.ct_id WHERE bill_id = @CARDTYPE 
						and a.Deleted = 0 AND a.isStoragUp = 1 and a.isStoragAutoup = 1

						IF @CZMoney >= @CZGLIMIT AND @NEWCZMONEY <> @CARDTYPE
						BEGIN
							UPDATE VIPCard SET CT_ID = @NEWCZMONEY  WHERE VIPCardID = @vipcardid
							--写入日志
							insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
							select 1,'system','自动升级',GETDATE(),VIPCardID,0,isnull(Integral,0.0),isnull(TotalBuyMoney,0.0),0,0.00,@CardName + '→' +@CZUPCName
							FROM VIPCard WHERE VIPCardID = @vipcardid
						END
					END
				END*/
	     SET @nForsj = @nForsj + 1 
	 end	      	   
	 DEALLOCATE curvipsj  	  
	
	/*Wusj.2017-06-30 对店间调拨单未能上传成功单据重置传输标记*/
	insert into DownBillLog(BillGuid,YGuid,BillType,y_id,UpOrDown)
	select GUID,YGuid,billtype,Y_ID,1 from billdraftidx_dts where billtype in (157) and Y_ID = @BillYID
	and GUID not in (select GUID from billdraftidx where billtype in (157) AND Y_ID = @BillYID)
	
	DELETE FROM DownBillLog WHERE BillGuid IN (SELECT GUID FROM billdraftidx WHERE billtype in (157) and Y_ID = @BillYID)
    			
/*	删除业务表 */
	TRUNCATE TABLE billidx_dts
	TRUNCATE TABLE salemanagebill_dts
	TRUNCATE TABLE buymanagebill_Dts
	TRUNCATE TABLE financebill_Dts 
	TRUNCATE TABLE storemanagebill_Dts
	TRUNCATE TABLE goodscheckbill_Dts
	TRUNCATE TABLE tranmanagebill_Dts 
	truncate table productdetail_dts
	truncate table accountdetail_dts
	truncate table retailbillidx_dts
	truncate table retailbill_dts	
	truncate table ExIntegRalManagebill_dts
	/*删除未处理的单据日志*/
	DELETE 
	FROM   BillLog
	WHERE  STATUS = 2
	/*删除草稿中间表*/
	TRUNCATE TABLE billDraftidx_dts
	TRUNCATE TABLE salemanagebilldrf_dts
	TRUNCATE TABLE financebilldrf_dts
	TRUNCATE TABLE GSPCompy_dts	
	/*删除会员积分表*/
	TRUNCATE TABLE Integralidx_dts
	TRUNCATE TABLE Integraldetail_dts
	
	
END
GO
