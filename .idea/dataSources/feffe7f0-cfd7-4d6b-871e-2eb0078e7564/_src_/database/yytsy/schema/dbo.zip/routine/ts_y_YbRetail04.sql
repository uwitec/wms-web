
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2013-12-09*/
/* Description:	根据草稿billid 获取上传处方信息 */
/*添加处方明细（交易类别代码:04）  */
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_y_YbRetail04]
(
  @billid int
)
AS
BEGIN
select a.ssmoney as A2,a.billnumber as A3,a.billnumber as A4,a.billdate as A5,'A6' as  A6,'A7' AS A7,
'A8' AS A8,b.retailprice as A9,b.quantity as A10,'' AS A11,'A12' AS A12,c.name as A13,
e.Unit1Name as a14,e.standard as a15,e.MedName as a16,'A17' AS A17,b.total as a18,
'A19' as A19,'A20' as A20,'A21' as A21,'A22' as A22,'A23' as A23,'A24' as A24,'1' AS A25
/*,'A26' AS A26,'A27' AS A27,'A28' AS A28,'A29' AS A29,'A30' AS A30,'A31' AS A31,'A32' AS A32,*/
/*'A33' AS A33,'A34' AS A34,'A35' AS A35,'A36' AS A36*/
from  retailbillidx a
inner join  RetailBill b on a.billid=b.bill_id
left  join  employees c  on a.e_id=c.emp_id
/*left  join  employees d  on a.inputman=d.emp_id*/
inner join  vw_Products   e  on b.p_id  =e.product_id
where    a.billid=@billid  and b.p_id>0 
      
 
END
GO
