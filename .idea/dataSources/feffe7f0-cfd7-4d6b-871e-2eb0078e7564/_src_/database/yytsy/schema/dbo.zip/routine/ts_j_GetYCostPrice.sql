/************************************************************

--功能：取回发货时的成本价  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：
 @nRet 返回值说明　
	0:执行成功
       -1:执行失败，发生异常
**************************************************************/

CREATE	 PROCEDURE [ts_j_GetYCostPrice]
	(
	  @nP_ID int,
          @nY_ID int,
          @supplier_id [int], 
          @batchno [varchar] (20),
          @makedate [datetime]=0,
          @instoretime [datetime]=0, 
          @validdate [datetime]=0, 
          @commissionflag [tinyint], 
          @costprice NUMERIC(25,8)output, 
          @nRet int output
        )
AS 
/*Params Ini begin*/
if @makedate is null  SET @makedate = 0
if @instoretime is null  SET @instoretime = 0
if @validdate is null  SET @validdate = 0
/*Params Ini end*/

  set @nRet =-1

  select top 1 @costprice = costprice from ysendcostpricehis where P_id=@np_id and supplier_id = @supplier_id and
               batchno = @batchno and makedate= @makedate and instoretime = @instoretime and validdate =@validdate and 
               commissionflag =@commissionflag 
   order by modifydate desc

 if @costprice is null or @costprice = 0
 
  select top 1 @costprice = costprice from storehouse where P_id=@np_id and supplier_id = @supplier_id and
               batchno = @batchno and makedate= @makedate and instoretime = @instoretime and validdate =@validdate and 
               commissionflag =@commissionflag and y_id = @nP_ID
if @costprice is null or @costprice = 0
  select top 1 @costprice = recprice from price where P_id=@np_id and unittype =1  

 if @costprice  is not null
  if @costprice > 0 
    set @nRet = 0 
   

  return 0
GO
