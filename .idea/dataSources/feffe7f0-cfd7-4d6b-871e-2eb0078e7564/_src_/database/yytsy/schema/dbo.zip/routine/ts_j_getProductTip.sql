
CREATE      proc ts_j_getProductTip
(
@P_ID int
)
/*with encryption*/
AS
SET NOCOUNT ON
declare @szTip varchar(1000)
select @szTip = '功能主治:' +  gnzz + CHAR(13)+CHAR(10)+'用法用量:' +  yfyl from productsExtend where p_id  = @P_ID
if @szTip is null set @szTip = ' '
select @szTip  as PTip
GO
