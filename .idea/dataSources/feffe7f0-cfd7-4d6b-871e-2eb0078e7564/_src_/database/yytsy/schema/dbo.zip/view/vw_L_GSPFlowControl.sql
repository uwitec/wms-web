

CREATE VIEW dbo.vw_L_GSPFlowControl
AS
SELECT a.FlowID, a.SourceGSPType, a.destGsptype, a.Comment, a.sysFlag, v.FormStyle, 
      a.gsppropert, a.y_ID,
      v.Name as DestName
FROM dbo.GspFlowControl a INNER JOIN
      GspVchType v ON a.destGsptype = v.GspType
GO
