
/******************************************
多选择仓库控制仓库授权
作者：yanrui
创建日期 2014-03-06
********************************************/
CREATE PROCEDURE ts_Y_selectstorages
(	
 @nloginEID int /*-职员ID	*/
)
as
begin
 declare  @Storetable int 
  create table #storagestable([id] int)
  /*---职员仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      Insert #storagestable ([id]) select 0
   end
  /*---仓库授权  */
  if @Storetable=0
  begin
    select serial_number as code,name,storage_id as id from storages 
    where deleted=0 and child_number=0 
  end
  else
  begin
    select serial_number as code,name,storage_id as id from storages 
    where deleted=0 and child_number=0 and (storage_id in (select [id] from #storagestable))
  end  
  drop table #storagestable
end
GO
