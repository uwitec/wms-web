
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_S_SpecialProductReport]
                 @BeginDate  datetime,   /* 开始日期*/
                 @EndDate    datetime,     /* 结束日期*/
                 @ReportType int       
                 /*报表类型  1代表特殊药品销售报表 2代表处方药销售查询 3代表电子监管码药品库存 4代表零售单电子监管码查询*/
AS
BEGIN
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;

    /* Insert statements for procedure here*/
    /*特殊药销售*/
	if @ReportType=1
	begin
	   select 0 as serialno, p.serial_number as serial_number,p.alias as productname,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name as uname,
       sum(case when b.billtype in (10,12,210) then s.SendQTY else -s.SendQTY end)  as qty,
       s.saleprice, sum(case when b.billtype in (10,12,210) then s.total else -s.total end) as total,
       isnull(gc.conName,'') as pname,isnull(gc.CallNumber,'') as tel,'' Address,isnull(gc.IDNumber,'') as IDCard  from billidx as b 
       inner join salemanagebill as s on s.bill_id=b.billid
       left  join products as p on p.product_id=s.p_id
       left  join GSPCompy as gc on gc.Gspbill_id=b.billid
       left  join unit as u on u.unit_id=s.unitid
       left  join GspPropert as g on g.GSPID=p.gspflag
       where b.billtype in (10,12,210,211,11,13)  and 
             (g.GSPPropert like '%特殊%' or g.doublecheck=1) and product_id>0 
             AND b.billdate BETWEEN @BeginDate and @EndDate
             and ISNULL(gc.flag,0)=0 AND b.billstates = 0
       group by p.serial_number ,p.alias ,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name ,
       s.saleprice, gc.conName, gc.CallNumber,gc.IDNumber
	end;
	
	/*处方药销售*/
	if @ReportType=2
	begin
	   select p.serial_number as serial_number,p.alias as productname,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name as uname,
       sum(case when b.billtype in (10,210) then s.SendQTY else -s.SendQTY end)  as qty,
       s.saleprice, sum(case when b.billtype in (10,210) then s.total else -s.total end) as total,
       isnull(y.Name,'') as pname,isnull(y.Tel,'') as tel,isnull(y.Address,'') as Address,isnull(y.IDCard,'') as IDCard ,'' as comment, isnull(c.Diagnose,'') as Diagnose from billidx as b 
       inner join salemanagebill as s on s.bill_id=b.billid
       left  join products as p on p.product_id=s.p_id
       left  join unit as u on u.unit_id=s.unitid
       left  join CaseHistory as c on c.Case_ID=b.posid
       left  join Patients y ON c.Patient_ID = y.PatientID 
       where b.billtype in (10,210,211,11) and  p.otcflag=1 and product_id>0 
             AND b.billdate BETWEEN @BeginDate AND @EndDate
       group by p.serial_number ,p.alias ,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name ,
       s.saleprice, y.Name, y.Tel,y.Address,y.IDCard,c.Diagnose        
       union all 
       select p.serial_number as serial_number,p.alias as productname,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name as uname,
       sum(case when b.billtype in (12) then s.quantity else -s.quantity end)  as qty,
       s.saleprice, sum(case when b.billtype in (10,12,210) then s.total else -s.total end) as total,
       isnull(y.Name,'') as pname,isnull(y.Tel,'') as tel,isnull(y.Address,'') as Address,isnull(y.IDCard,'') as IDCard ,s.comment , isnull(c.Diagnose,'') as Diagnose
       from retailbillidx as b 
       inner join retailbill as s on s.bill_id=b.billid
       left  join products as p on p.product_id=s.p_id
       left  join unit as u on u.unit_id=s.unitid
       left  join CaseHistory as c on c.Case_ID=b.posid
       left  join Patients y ON c.Patient_ID = y.PatientID 
       where b.billstates=0 and  p.otcflag=1 and s.p_id>0
       and b.billdate>=@BeginDate AND b.billdate<@EndDate+1
       group by p.serial_number ,p.alias ,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,u.name ,
       s.saleprice, y.Name, y.Tel,y.Address,y.IDCard,s.comment , c.Diagnose  
	end;
   /*电子监管码药品库存查询*/
   if @ReportType=3 
   begin
       select p.serial_number,p.alias,p.name, p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,
       ISNULL(u.name,'') as uname, sum(s.Costprice) as Costprice,sum(s.costtotal) as costtotal,
       isnull(l.Sfda_Code,'') as Sfda_Code, sum(s.quantity) as quantity
       from storehouse as s 
       left join products as p on p.product_id=s.p_id
       left join unit as u on u.unit_id=p.unit1_id
       left join Sfda_List as l on l.P_Id=s.p_id and l.BatchNo=s.batchno
       where  p.basicMedication=1 
       group by p.serial_number,p.alias, p.name,p.standard,p.factory,p.makearea,s.batchno,s.validdate,p.permitcode,
       u.name, l.Sfda_Code 
   end;
  
   /*零售单电子监管码查询*/
   if @ReportType=4
   begin
     select p.serial_number as serial_number,p.alias,p.name,p.standard,p.factory,p.makearea,b.batchno,b.validdate,p.permitcode,
     u.name as uname,sum(Case when  r.billtype=12 then b.quantity else -b.quantity end) as quantity,
     sum(Case when  r.billtype=12 then b.total else -b.total end ) as total,b.saleprice, sf.sfda_code 
     from billidx  as r 
     inner join salemanagebill  as b on b.bill_id=r.billid
     left  join products as p on p.product_id=b.p_id
     left  join unit as u on u.unit_id=b.unitid
     left  join Sfda_Detail as sf on sf.billid=b.bill_id
     where r.billtype in (12,13) and  p.basicMedication=1 and (LEFT(CONVERT(varchar,r.billdate,21),10)>=@BeginDate or @BeginDate=0)
       and (LEFT(CONVERT(varchar,r.billdate,21),10)<=@EndDate or @EndDate=0)
     group by p.serial_number ,p.alias,p.name,p.standard,p.factory,p.makearea,b.batchno,b.validdate,p.permitcode,
     u.name ,b.quantity,b.saleprice,b.total,sf.sfda_code,b.scomment 
   end;


END
GO
