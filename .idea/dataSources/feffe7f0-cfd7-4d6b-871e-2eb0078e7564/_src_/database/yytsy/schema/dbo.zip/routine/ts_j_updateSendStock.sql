
/*
  @updateflag  1 增加， -1 减少
*/
CREATE	 PROCEDURE ts_j_updateSendStock
	(
	  @nbillid int,
	  @nbilltype int,
	  @Updateflag int = 0
    )
AS 
/*Params Ini begin*/
if @Updateflag is null  SET @Updateflag = 0
/*Params Ini end*/

if @nbilltype <> 150  return 0 
if @Updateflag not in (1, -1) return 0  
declare @nflag int, @nY_ID int, @S_ID int
select @nflag = integral, @nY_ID = c_id, @S_ID = sin_id from billidx where billid = @nbillid
if @Updateflag = 1 and @nflag <> 0 return 0
if @Updateflag = -1 and @nflag <> 1 return 0
if OBJECT_ID('tempdb..#stocktmp') is not null
  drop table #stocktmp
  
select top 0 s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, validdate, instoretime, commissionflag, y_id into #stocktmp from storehouse

insert into #stocktmp(s_id, p_id, supplier_id, quantity, costprice, costtotal, 
                      batchno, makedate, validdate, instoretime, commissionflag, y_id)
                      
   select @S_ID, p_id, supplier_id, sum(quantity)*@Updateflag, costprice, sum(quantity)* costprice*@Updateflag,
          batchno, makedate, validdate, instoretime, commissionflag, @nY_ID
     from salemanagebill 
     where bill_id = @nbillid and AOID in (0, 7)
     group by p_id, supplier_id, costprice, batchno, makedate, validdate, instoretime, commissionflag
     
  insert into #stocktmp(s_id, p_id, supplier_id, quantity, costprice, costtotal, 
                      batchno, makedate, validdate, instoretime, commissionflag, y_id)
     select s_id, p_id, supplier_id, quantity, costprice, costtotal, 
                      batchno, makedate, validdate, instoretime, commissionflag, y_id
       from storehouse where s_id = @S_ID and Y_ID = @nY_ID and sendflag = 1 and p_id in (select distinct p_id from #stocktmp)
       
    delete storehouse where SendFlag = 1 and s_id = @S_ID and Y_ID  = @nY_ID and p_id in (select distinct p_id from #stocktmp)
    
  insert into storehouse(s_id, p_id, supplier_id, quantity, costprice, costtotal, 
                      batchno, makedate, validdate, instoretime, commissionflag, y_id, SendFlag)
     select s_id, p_id, supplier_id, sum(quantity), costprice, sum(costtotal), 
                      batchno, makedate, validdate, instoretime, commissionflag, y_id, 1
       from #stocktmp
       group by s_id, p_id, supplier_id,  costprice,
                      batchno, makedate, validdate, instoretime, commissionflag, y_id
                      
   delete storehouse where quantity <= 0 and SendFlag =1 and s_id = @S_ID and Y_ID  =@nY_ID
   update billidx set integral = @Updateflag where billid = @nbillid
GO
