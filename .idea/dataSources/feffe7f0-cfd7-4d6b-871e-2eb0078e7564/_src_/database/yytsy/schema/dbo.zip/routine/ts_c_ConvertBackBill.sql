
/*门店退货单*/
create proc ts_c_ConvertBackBill
/*with encryption*/
as
set nocount on
declare @billid int, @Newbillid int, @posguid varchar(50),@LocalPosguid varchar(50), @posid int,@localinputman int,@localauditman int,@localeid int
declare @postype int,@CenterSid int, @CenterInputman int, @CenterAuditman int, @CenterEid int, @locationid int ,@smbid int,@pid int, @Y_ID int
declare @billtype int, @Newbilltype int

exec ts_getsysvalue 'Y_ID',@Y_ID out

exec ts_getsysvalue 'LocalInputman',@localinputman out, @Y_ID
exec ts_getsysvalue 'LocalAuditman',@localauditman out, @Y_ID
exec ts_getsysvalue 'LocalEid',@localeid out, @Y_ID
exec ts_getsysvalue 'CenterSid',@CenterSid out, @Y_ID
exec ts_getsysvalue 'CenterInputman',@CenterInputman out, @Y_ID
exec ts_getsysvalue 'CenterAuditman',@CenterAuditman out,@Y_ID
exec ts_getsysvalue 'CenterEid',@CenterEid out, @Y_ID

    delete salemanagebilldtsIN where bill_id in (select billid from billdtsidxIN where billtype in (151, 153)) 

	declare ConvertCur cursor for
	select billid,posguid, billtype
	from billdtsidxIN
	where billtype in (161, 163)
	
	open convertcur
	
	fetch next from convertcur into @billid,@posguid, @billtype
	
	while @@fetch_status=0
	begin
		select @posid=posid from ReplicationAuthorize where guid=@posguid
		if @billtype = 161 
		  set @Newbilltype = 151
		else
		  set @Newbilltype = 153
		/*select @PosC_id=c_id,@posS_id=S_id,@postype=postype from shop where posid=@posid*/



		
      		/*机构收货退货单转机构发货退货单*/
		/*机构收付款财务单据不  */

               	/*update billdtsidxIN set billtype=@Newbilltype, c_id=y_id,sout_id = @CenterSid,sin_id = @CenterSid,ssmoney=0,jsye=ysmoney, jsflag = '0', billstates='3', y_id =@Y_ID,*/
			/*	      a_id = 0, e_id= @CenterEid, auditman = @CenterAuditman,inputman= @CenterInputman,period = 0 	 */
		      /* where billid=@billid*/

		
		select @NewBillid = max(billid)+1 from billdtsidxin

                insert into billdtsidxIN(billid, billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman,
                            ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
                            auditdate, skdate, jsye, jsflag, note, summary, invoice,  invoicetotal, invoiceNo, businesstype, 
                            guid, posguid, araptotal, sendqty, gatheringMan, vipcardid, jsInvoiceTotal, y_id, b_customname1, 
                            b_customName2, B_CustomName3,SendC_id ,WholeQty,PartQty)
                select      @NewBillid, billdate, billnumber, @Newbilltype, 0, y_id, @CenterEid, @CenterSid, @CenterSid, @CenterAuditman, @CenterInputman,
                            ysmoney, 0, quantity, taxrate, period, '3', order_id, department_id, posid, region_id, 
                            auditdate, skdate, ysmoney, '0', 0, summary, invoice,  invoicetotal, invoiceNo, businesstype, 
                            guid, posguid, araptotal, sendqty, gatheringMan, vipcardid, jsInvoiceTotal, @Y_ID, b_customname1, 
                            b_customName2, B_CustomName3,SendC_id,WholeQty,PartQty
                from billdtsidxIn where billid=@billid 
             

		insert into salemanagebilldtsIN(smb_id,bill_id, p_id, batchno,quantity, costprice,saleprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
			     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,taxrate,order_id, total, iotag,
			     InvoiceTotal,thqty,newprice,orgbillid,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,sendcosttotal,Rowguid,RowE_id, YcostPrice,YGUID, Y_ID, instoretime,comment2
			     ,batchbarcode,scomment,batchprice)
		select smb_id,@Newbillid, p_id, batchno,quantity, YCostprice,buyprice,discount,discountprice, totalmoney, taxprice,taxtotal, taxmoney, retailprice,retailtotal,
			     makedate, validdate, qualitystatus, price_id, @CenterSid, 0, 0, supplier_id, commissionflag, comment,unitid,taxrate,0, total, iotag,
			     InvoiceTotal,0,newprice,0,aoid,jsprice,invoice, invoiceno, pricetype,sendqty,SendQty*Ycostprice,newid(),@CenterEid, YcostPrice,YGUID,@Y_ID, instoretime,comment2
			     ,batchbarcode,scomment,batchprice
		from buymanagebilldtsIN where bill_id=@billid and p_id > 0
		order by smb_id

	        update billdtsidxIn set billstates = '3' where billid=@billid 
		
		/*暂不处理货位跟踪，可能会出错，需要处理整零库、默认货位等*/
		/*declare LocCur cursor for*/
		/*select smb_id,p_id*/
		/*from salemanagebilldtsIN*/
		/*where bill_id=@billid*/
		
		/*open LocCur*/
			
		/*fetch next from LocCur into @smbid,@pid*/
			
		/*while @@fetch_status=0*/
		/*begin*/
		/*	select @locationid=0*/
		/*	select @locationid=l_id from locationtrace where p_id=@pid and s_id=@CenterSid and Y_ID = @Y_ID*/
			
		/*	update salemanagebilldtsIN set location_id=@locationid where smb_id=@smbid and Y_ID = @Y_ID*/
		
		/*	fetch next from LocCur into @smbid,@pid*/
		/*end*/
		/*close LocCur*/
		/*deallocate LocCur*/
			
		/*exec ts_c_updatecostprice @billid,'stodts'*/
		/*分支机构手工录入退货单时,入库成本价库库退货价*/
                  update salemanagebilldtsIN set costprice = discountprice, sendCosttotal= sendQty*discountprice
	                 where bill_id = @Newbillid and costprice = 0       
 
		fetch next from convertcur into @billid,@posguid,@billtype
	end
	close convertcur
	deallocate convertcur
GO
