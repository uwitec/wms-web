
/*@nOperateMode = 0 选择*/
/*@nOperateMode = 1 插入*/
/*@nOperateMode = 2 删除*/
/*@nflag	=0	往来单位授权*/
/*@nflag	=1	仓库授权*/
/*@nflag	=5	分支机构授权*/
/*@nflag	=6	部门授权*/
/*@nflag	=7	分区授权*/

CREATE procedure ts_c_authorize
(
	@nOperateMode int,
	@nflag				int,
 	@ne_id 				int,
	@type 				char(1),
	@psc_id 			varchar(30),
	@parentflag 	bit
)
/*with encryption*/
as 
set nocount on
if @nOperateMode=0
begin
	if @nFlag=0
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else c.[name] end,
		c.serial_number,dbo.GetNamePath('c',c.class_id) as path,
		ut.LocationID
		from userauthorize ut,clients c 
		where ut.psc_id=c.class_id and ut.type='C'  and ut.e_id=@nE_id
	if @nFlag=1
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else s.[name] end,
		s.serial_number,dbo.GetNamePath('s',s.class_id) as path		,
		ut.LocationID
		from userauthorize ut,storages s 
		where ut.psc_id=s.class_id and ut.type='S' and ut.e_id=@nE_id
	if @nFlag=2  	/*商品授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else p.[name] end,
		p.serial_number,dbo.GetNamePath('P',p.class_id) as path		,
		ut.LocationID
		from userauthorize ut,products p 
		where ut.psc_id = p.class_id and ut.type='P'and ut.e_id=@nE_id
	if @nFlag=3  	/*职员授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else E.[name] end,
		E.serial_number,dbo.GetNamePath('E',E.class_id) as path		,
		ut.LocationID
		from userauthorize ut,Employees E 
		where ut.psc_id = E.class_id and ut.type='E'and ut.e_id=@nE_id
	if @nFlag=4  	/*科目授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else a.[name] end,
		a.serial_number,dbo.GetNamePath('A',a.class_id) as path		,
		ut.LocationID
		from userauthorize ut,account a 
		where ut.psc_id = a.class_id and ut.type='A'and ut.e_id=@nE_id
	if @nFlag=5  	/*分支机构授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else Y.[name] end,
		Y.serial_number,dbo.GetNamePath('Y',Y.class_id) as path		,
		ut.LocationID
		from userauthorize ut,company Y 
		where ut.psc_id = Y.class_id and ut.type='Y'and ut.e_id=@nE_id
	if @nFlag=6  	/*部门授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else D.[name] end,
		ISNULL(D.serial_number,'') as serial_number,'\' as path		,
		ut.LocationID
		from userauthorize ut LEFT JOIN department D ON ut.psc_id = D.departmentid
		where ut.type='D'and ut.e_id=@nE_id
	if @nFlag=7  	/*片区授权*/
		select ut.ut_id,ut.e_id,ut.type,ut.psc_id,ut.parentflag,
		[name]=case ut.psc_id 
		when '000000' then '全部权限' else R.[name] end,
		ISNULL(R.serial_number,'') as serial_number,'\' as path		,
		ut.LocationID
		from userauthorize ut 
		LEFT JOIN Region R ON ut.psc_id = R.Region_id
		where  ut.type='R'and ut.e_id=@nE_id
	return 0
end

if @nOperateMode=1
begin
	if not exists(select * from userauthorize where e_id=@ne_id and type=@type and psc_id=@psc_id) 
	begin
		if @psc_id='000000' delete from userauthorize where e_id=@ne_id and type=@type
		/*删除下级授权节点*/
	  if @parentflag=1 delete from userauthorize where e_id=@ne_id and type=@type and left(psc_id,len(@psc_id))=@psc_id
      
      declare @nid int
      set @nid=0
      if @type ='C' 	  
        select @nid=client_id from clients where class_id=@psc_id
      else if @type ='S' 	  
        select @nid=storage_id from storages where class_id=@psc_id
      else if @type ='Y' 	  
        select @nid=company_id from company where class_id=@psc_id
      else if @type ='E' 	  
        select @nid=emp_id from employees where class_id=@psc_id
      else if @type ='A' 	  
        select @nid=account_id from account where class_id=@psc_id
      else if @type ='P' 	  
        select @nid=product_id from products where class_id=@psc_id

		insert into userauthorize(e_id,type,psc_id,parentflag,[id]) 
		values 
			(@ne_id,@type,@psc_id,@parentflag,@nid)
	end
	return 0
end

if @nOperateMode=2
begin
	delete from userauthorize where e_id=@ne_id and type=@type and psc_id=@psc_id
	return 0
end
GO
