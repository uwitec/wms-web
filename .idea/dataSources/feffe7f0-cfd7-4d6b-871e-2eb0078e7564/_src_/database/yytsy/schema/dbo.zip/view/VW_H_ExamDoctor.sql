
CREATE VIEW dbo.VW_H_ExamDoctor
AS
SELECT     TOP 100 PERCENT dbo.employees.emp_id, dbo.employees.name, dbo.WorkPlan.WorkDay, dbo.WorkPlan.WorkPart_ID, dbo.WorkPlan.MaxReg, 
                      dbo.employees.dep_id, dbo.DoctorGrade.SPID
FROM         dbo.employees INNER JOIN
                      dbo.WorkPlan ON dbo.employees.emp_id = dbo.WorkPlan.Doctor_ID INNER JOIN
                      dbo.DoctorGrade ON dbo.employees.GradeId = dbo.DoctorGrade.GradeID INNER JOIN
                      dbo.department ON dbo.employees.dep_id = dbo.department.departmentId LEFT OUTER JOIN
                          (SELECT     RegWorkPlan, COUNT(RegWorkPlan) AS Expr1
                            FROM          dbo.Registered
                            GROUP BY RegWorkPlan) AS derivedtbl_1 ON dbo.WorkPlan.Plan_ID = derivedtbl_1.RegWorkPlan
WHERE     (dbo.WorkPlan.onDuty = 1) AND (dbo.DoctorGrade.isReg = 1) AND (ISNULL(derivedtbl_1.Expr1, 0) < dbo.WorkPlan.MaxReg) AND 
                      (dbo.department.Type_ID = 1)
ORDER BY dbo.WorkPlan.WorkDay DESC
GO
