








CREATE	procedure ts_SetSysValue
(
	@szSysName varchar(60),
	@szSysValue varchar(80),
	@nY_ID int = 0
)  
/*with encryption*/
AS  
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
SET NOCOUNT ON
IF EXISTS (SELECT sysvalue FROM sysconfig WHERE [sysname]=@szSysName and y_id = @nY_ID)
UPDATE sysconfig SET [sysvalue]=@szSysValue WHERE [sysname]=@szSysName and y_id = @nY_ID
ELSE
INSERT INTO sysconfig (sysvalue, sysname, y_id, sysflag)VALUES(@szSysValue,@szSysName, @nY_ID, 0)  /*这儿先改为0默认不传输*/
IF @@ROWCOUNT>0 RETURN 0
ELSE RETURN -1
GO
