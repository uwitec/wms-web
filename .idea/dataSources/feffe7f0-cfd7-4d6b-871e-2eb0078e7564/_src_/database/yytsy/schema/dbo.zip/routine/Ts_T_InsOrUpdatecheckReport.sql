/************************************************************
--过程名称：检验报告添加修改
--创建人：LUO XIAOTIAN 
--创建时间：2011-7-18  
--最后修改:


参数说明：
		  @Mrid  --0为添加，不为0是修改

备注：
**************************************************************/
CREATE PROC [dbo].[Ts_T_InsOrUpdatecheckReport]
    (
      @Mrid INT ,
      @p_id INT ,
      @batchno VARCHAR(20) ,
      @repNo VARCHAR(100) ,
      @c_id INT ,
      @inputTime VARCHAR(20) ,
      @path VARCHAR(120)
    )
AS
    IF @Mrid = 0
        BEGIN	
            IF EXISTS ( SELECT  1
                        FROM    medReport
                        WHERE   p_id = @p_id
                                AND batchno = @batchno
                                AND repNo = @repNo )
                BEGIN
                    RAISERROR('检验报告编号,有重复！',16,1)
                    RETURN-1
                END
            INSERT  INTO [dbo].[medReport]
                    ( [p_id] ,
                      [batchno] ,
                      [repNo] ,
                      [c_id] ,
                      [inputTime] ,
                      [pathName]
	                )
            VALUES  ( @p_id ,
                      @batchno ,
                      @repNo ,
                      @c_id ,
                      @inputTime ,
                      @path 
	                )
        END
    ELSE
        BEGIN
            UPDATE  medReport
            SET     [p_id] = @p_id ,
                    [batchno] = @batchno ,
                    [repNo] = @repNo ,
                    [c_id] = @c_id ,
                    [pathname] = @path
            WHERE   mr_id = @Mrid 
        END
GO
