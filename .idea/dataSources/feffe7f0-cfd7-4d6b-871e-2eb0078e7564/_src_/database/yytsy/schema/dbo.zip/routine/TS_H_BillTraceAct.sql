
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-03-30*/
/* Description:	单据追踪相关操作*/
/* =============================================*/
CREATE PROCEDURE TS_H_BillTraceAct 
	@Act int = 0,			/* 0：写入跟踪记录；1：查询跟踪；2：查询申请修改记录；3：查询变动记录*/
	@BillId int = 0,
	@BillType int = 0,
	@YBillId int = 0,
	@YBillType int = 0,
	@IsDraft int = 1,
	@IsNew int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @uBillGuid uniqueidentifier
	DECLARE @uTraceGuid uniqueidentifier
	DECLARE @nLastId int
	
	IF @Act = 0
	BEGIN
		/* 销售订单*/
		IF @BillType IN(14, 154)
		BEGIN
			SELECT @uBillGuid = GUID FROM orderidx WHERE billid = @BillId
			INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
			VALUES(@BillId, @BillType, NEWID(), 0, @uBillGuid, 1)
		END
		ELSE
		/*店间调拨单*/
		IF @BillType = 157
		BEGIN
			SELECT @uBillGuid = GUID FROM billdraftidx WHERE billid = @BillId AND billtype = @BillType
			INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
			VALUES(@BillId, @BillType, NEWID(), 0, @uBillGuid, @IsDraft)
		END
		ELSE
		/* GSP 单据*/
		IF @BillType BETWEEN 501 AND 599
		BEGIN
			/* 调单生成的单据*/
			IF @IsNew = 1
			BEGIN
				/* 收货单调订单*/
				IF @YBillType IN(22, 108)
				BEGIN
					SELECT @uBillGuid = GUID FROM orderidx WHERE billid = @YBillId
					SET @uTraceGuid = NEWID()
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 1)
					SET @nLastId = @@IDENTITY
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
				ELSE
				/* 退货申请单调原单*/
				IF @YBillType IN(10, 20)
				BEGIN
					IF (@YBillId > 0) AND EXISTS(SELECT * FROM billidx WHERE billid = @YBillId AND billtype = @YBillType)
					BEGIN
						SELECT @uBillGuid = GUID FROM billidx WHERE billid = @YBillId
						SET @uTraceGuid = NEWID()
						INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 0)
						SET @nLastId = @@IDENTITY
					END
					ELSE
					BEGIN
						SET @nLastId = 0
						SET @uTraceGuid = NEWID()
					END
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
				ELSE
				IF @YBillType BETWEEN 501 AND 599
				BEGIN
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @YBillId
					SELECT @nLastId = id, @uTraceGuid = traceGuid FROM billTrace 
						WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
				ELSE
				IF @YBillType IN(150, 152, 151, 153, 160, 161, 162, 163)
				BEGIN
					IF @YBillId > 0 
					BEGIN
					  DECLARE @YBillGuid uniqueidentifier
					      IF @YBillType IN (163) AND @BillType IN (517)
					        SELECT @YBillGuid = YGuid FROM billidx WHERE billid = @YBillId
					      ELSE IF @YBillType IN (152) AND @BillType IN (516)
					        SELECT @YBillGuid = YGuid FROM GSPbillidx WHERE Gspbillid = @BillId  
					        
						  SELECT @uBillGuid = GUID FROM billidx WHERE billid = @YBillId
						  IF (@uBillGuid IS NULL) AND (@YBillType NOT IN(152) AND @BillType NOT IN (516))
							  RETURN 0
						  IF (@YBillType IN (152,163)) AND (EXISTS (SELECT 1 FROM billdraftidx WHERE billtype = 157 AND GUID = @YBillGuid))
					         SELECT @uTraceGuid = traceGuid FROM billTrace WHERE billType = 157 AND billGuid = @YBillGuid
					      ELSE	  
						     SET @uTraceGuid = NEWID()
						  INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						  VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 0)
						  SET @nLastId = @@IDENTITY
						  SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
						  INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						  VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
					END
					ELSE
					BEGIN
						SET @uTraceGuid = NEWID()
						SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
						INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						VALUES(@BillId, @BillType, @uTraceGuid, 0, @uBillGuid, 1)
					END
				END
			END
			ELSE
			/* 自动生成的单据*/
			IF @IsNew = 0
			BEGIN
				IF @YBillType IN(14, 154)
				BEGIN
					SELECT @uBillGuid = GUID FROM orderidx WHERE billid = @YBillId
					IF EXISTS(SELECT * FROM billTrace WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid)
						SELECT @nLastId = id, @uTraceGuid = traceGuid FROM billTrace 
							WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid
					ELSE
					BEGIN
						SET @uTraceGuid = NEWID()
						INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 1)
						SET @nLastId = @@IDENTITY
					END
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
				ELSE
				IF @YBillType BETWEEN 501 AND 599
				BEGIN
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @YBillId
					IF EXISTS(SELECT * FROM billTrace WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid)
						SELECT @nLastId = id, @uTraceGuid = traceGuid FROM billTrace 
							WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid
					ELSE
					BEGIN
						SET @uTraceGuid = NEWID()
						INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 1)
						SET @nLastId = @@IDENTITY
					END
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
				ELSE
				/* 历史单据*/
				BEGIN
					SELECT @uBillGuid = GUID FROM billidx WHERE billid = @YBillId
					
					IF EXISTS(SELECT * FROM billTrace WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid)
						SELECT @nLastId = id, @uTraceGuid = traceGuid FROM billTrace 
							WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid
					ELSE
					BEGIN
						SET @uTraceGuid = NEWID()
						INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
						VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 1)
						SET @nLastId = @@IDENTITY
					END
					SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @BillId
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, 1)
				END
			END
		END
		ELSE
		IF @BillType < 255
		BEGIN
			IF @YBillType BETWEEN 501 AND 599
			BEGIN
				SELECT @uBillGuid = GUID FROM GSPbillidx WHERE GSPbillid = @YBillId
				IF EXISTS(SELECT * FROM billTrace WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid)
					SELECT @nLastId = id, @uTraceGuid = traceGuid FROM billTrace 
						WHERE billId = @YBillId AND billType = @YBillType AND billGuid = @uBillGuid
				ELSE
				BEGIN
					SET @uTraceGuid = NEWID()
					INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
					VALUES(@YBillId, @YBillType, @uTraceGuid, 0, @uBillGuid, 1)
					SET @nLastId = @@IDENTITY
				END
				IF @IsDraft = 1
					SELECT @uBillGuid = GUID FROM billdraftidx WHERE billid = @BillId
				ELSE
					SELECT @uBillGuid = GUID FROM billidx WHERE billid = @BillId				
				INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
				VALUES(@BillId, @BillType, @uTraceGuid, @nLastId, @uBillGuid, @IsDraft)
			END
			ELSE
			/*店间调拨单生成自营店收货退货单*/
			IF @YBillType IN (157) AND @BillType IN (163)
			BEGIN
			  SELECT @uBillGuid = GUID FROM billidx WHERE billid = @BillId AND billtype = @BillType
			  IF EXISTS(SELECT * FROM billTrace WHERE billId = @YBillId AND billType = @YBillType)
			   SELECT @uTraceGuid = traceGuid FROM billTrace WHERE billId = @YBillId AND billType = @YBillType
			  INSERT INTO billTrace(billId, billType, traceGuid, lastId, billGuid, isDraft)
			  VALUES(@BillId, @BillType, @uTraceGuid, 0, @uBillGuid, @IsDraft)	   
			END
		END
	END
	ELSE
	IF @Act = 1
	BEGIN
		SELECT * FROM VW_BILLTRACE WHERE ID IN(
				SELECT MAX(ID) FROM VW_BILLTRACE WHERE traceGuid IN(SELECT  traceGuid FROM dbo.billTrace WHERE billId = @BillId AND billType = @BillType AND isDraft = @IsDraft)
				GROUP BY billId,billType) ORDER BY ID
	END
	ELSE
	IF @Act = 2
	BEGIN
		SELECT     B.id, A.name AS aname, B.requestDate AS adate, ISNULL(R.name, '') AS rname, B.replyDate AS rdate, B.modifyReason AS areason, CASE B.status WHEN 2 THEN '待审核' when 3 then '审核通过' when 1 then '拒绝修改' end as [status]
		FROM         dbo.billChangelog AS B INNER JOIN
							  dbo.employees AS A ON B.requestMan = A.emp_id LEFT OUTER JOIN
							  dbo.employees AS R ON B.replyMan = R.emp_id
		WHERE (B.billId = @BillId and @IsDraft = 1 or B.billId = -@BillId and @IsDraft = 0) AND B.billType = @BillType
		ORDER BY requestDate DESC
	END
	ELSE
	IF @Act = 3
	BEGIN
		IF @IsDraft = 1
		begin
			SELECT id, modifyDate, Guid FROM BillHistory 
			WHERE billId = @BillId AND billType = @BillType AND Type = 0
			ORDER BY modifyDate DESC
		end
		ELSE
		IF @IsDraft = 0
		BEGIN
			SELECT id, modifyDate, Guid FROM BillHistory 
			WHERE Guid IN(SELECT Guid FROM billidx WHERE billId = @BillId AND billtype = @BillType) AND Type = 0 AND Billtype = @BillType
			ORDER BY modifyDate DESC
		END
	END
END
GO
