
CREATE PROCEDURE Ts_k_InsertGSPbillidx(
    @nRET              INT OUTPUT,			/*返回Gspbillid，错误返回-1*/
    @nVchCode          INT,                 /*GspBillid*/
    @Gspbillid         INT,                 /*GspBillid*/
    @billtype          INT,                 /*单据类型*/
    @billnumber        VARCHAR(30),			/*单据编号*/
    @Y_id              INT = 0,				/*业务机构*/
    @c_id              INT = 0,				/*往来单位/往来机构*/
    @billdate          DATETIME,			/*日期时间*/
    @inputman          INT = 0,				/*制单人*/
    @auditman1         INT = 0,				/*审核人1*/
    @audittime1        DATETIME,			/*审核人1审核时间*/
    @auditman2         INT = 0,				/*审核人2*/
    @audittime2        DATETIME,			/*审核人2审核时间*/
    @upauditman1       INT = 0,				/*单据上一个审核人1*/
    @upauditman2       INT = 0,				/*单据上一个审核人2*/
    @traffictype       VARCHAR(50) = '',	/*运输方式*/
    @traffictools      VARCHAR(100) = '',	/*运输工具*/
    @trafficTime       NUMERIC(8, 1) = 0,   /*运输时间*/
    @tempcontrol       VARCHAR(50) = '',	/*温度控制状况*/
    @spectrafficprove  VARCHAR(100) = '',	/*特殊药品运输证*/
    @sendaddress       VARCHAR(100) = '',	/*发运地点*/
    @sendtime          DATETIME = 0,		/*启运时间*/
    @trafficCompany    VARCHAR(100) = '',	/*运输单位*/
    @tempcontrolmode   VARCHAR(50) = '',	/*温控方式*/
    @WholeQty          INT = 0,				/*整货件数*/
    @PartQty           INT = 0,				/*拼箱件数*/
    @discountTotal     NUMERIC(25,8) = 0,	/*折后金额*/
    @TaxTotal          NUMERIC(25,8) = 0,	/*税后金额*/
    @Ybillid           INT = 0,				/*原单billid*/
    @YbillType         INT = 0,				/*原单单据类型*/
    @Yguid             UNIQUEIDENTIFIER = 0x0,/*原单guid*/
    @billstates        INT = 0,             /*单据状态*/
    @s_id              INT = 0,				/*仓库ID*/
    @Note              VARCHAR(256) = '',   /*备注*/
    @b_CustomName1     VARCHAR(100) = '',   /*备注1*/
    @b_CustomName2     VARCHAR(100) = '',	/*备注2*/
    @b_CustomName3     VARCHAR(100) = '',	/*备注3*/
    @b_CustomName4     VARCHAR(100) = '',	/*备注4*/
    @b_CustomName5     VARCHAR(100) = '',	/*备注5*/
    @financeAudit  int = 0,                 /*财务部审核人id*/
    @financeAuditDate  Datetime = '1900-01-01', /*-财务部审核时间   */
    @FollowNumber     VARCHAR(100) = '',	/*随货同行单号*/
    @TicketDate       VARCHAR(100) = '',    /*票据单号 */
    @BalanceMode       INT = -1 ,              /*结算方式*/
    @InBags           VARCHAR(100) = '',    /*袋装件数*/
    @YE_id            int = 0,              /*原单经手人*/
    @SendC_Id         int = 0               /*收货方*/
)
AS
BEGIN
	DECLARE @SQL VARCHAR(8000)
	
	SET @nRET = -1
	IF @nVchCode > 0 /*大于零为修改，反之为新增*/
	BEGIN
		IF EXISTS(SELECT * FROM GSPbillidx WHERE Gspbillid = @nVchCode AND BillStates IN (13, 15))
		BEGIN
			SET @nRET = -10
			RETURN @nRET
		END
		IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
		BEGIN
			SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nVchCode AS VARCHAR(50)) + ', ' + CAST(@billtype AS VARCHAR(10)) + ', 0'
			EXEC(@SQL)
		END
	
		DELETE FROM GSPbilldetail WHERE Gspbill_id = @nVchCode
		
		/*XXX.2017-06-22 处理冷链收货的特殊字段往后续单据带*/
		/*运输方式，运输工具，运输时间，温控状况，特殊药品运输证，发运地点，运输单位，温控方式*/
		IF @billtype IN (521,522,523,524)
		BEGIN
			SELECT 
			@traffictype = ISNULL(gi.TrafficType,''),@traffictools = ISNULL(gi.traffictools,''),
			@trafficTime = ISNULL(gi.trafficTime,0),@tempcontrol = ISNULL(gi.tempcontrol,''),
			@spectrafficprove = ISNULL(gi.spectrafficprove,''),@sendaddress = ISNULL(gi.sendaddress,''),
			@sendtime = ISNULL(gi.sendtime,GETDATE()),@trafficCompany = ISNULL(gi.trafficCompany,''),@tempcontrolmode = ISNULL(gi.tempcontrolmode,'')
			FROM GSPbillidx G
			LEFT JOIN DBO.billTrace T ON G.Gspbillid = T.billId AND G.GUID = T.billGuid
			LEFT JOIN DBO.billTrace T2 ON T.lastId  = T2.id
			LEFT JOIN GSPbillidx gi on gi.Gspbillid = t2.billId 
			WHERE G.Gspbillid = @nVchCode
		END	
		
		UPDATE GSPbillidx
		SET billtype = @billtype,
			billnumber = @billnumber,
			Y_id = @Y_id,
			c_id = @c_id,
			billdate = @billdate,
			inputman = @inputman,
			auditman1 = @auditman1,
			audittime1 = @audittime1,
			auditman2 = @auditman2,
			audittime2 = @audittime2,
			upauditman1 = @upauditman1,
			upauditman2 = @upauditman2,
			traffictype = @traffictype,
			traffictools = @traffictools,
			TrafficTime = @trafficTime,
			tempcontrol = @tempcontrol,
			spectrafficprove = @spectrafficprove,
			sendaddress = @sendaddress,
			sendtime = @sendtime,
			trafficCompany = @trafficCompany,
			tempcontrolmode = @tempcontrolmode,
			WholeQty = @WholeQty,
			PartQty = @PartQty,
			discountTotal = @discountTotal,
			TaxTotal = @TaxTotal,
			Ybillid = @Ybillid,
			Ybilltype = @YbillType,
			Yguid = @Yguid,
			S_id = @s_id,
			billstates = @billstates,
            Note = @Note,
			b_CustomName1 = @b_CustomName1,
			b_CustomName2 = @b_CustomName2,
			b_CustomName3 = @b_CustomName3,
			b_CustomName4 = @b_CustomName4,
			b_CustomName5 = @b_CustomName5,
			financeAudit  = @financeAudit,
			financeAuditDate= @financeAuditDate,
			FollowNumber=@FollowNumber,
			TicketDate=@TicketDate,
			BalanceMode = @BalanceMode,
			InBags=@InBags,
			YE_id=@YE_id,
			SendC_Id=@SendC_Id
		WHERE Gspbillid = @nVchCode
		
		IF @@ERROR = 0
		    SET @nRET = @nVchCode
    END
	ELSE if @nVchCode < 0
	BEGIN 
	
		INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
					upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
					trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
					GUID,FollowNumber,TicketDate, BalanceMode,YE_ID,SendC_Id)
		SELECT   @billtype, @billnumber, Y_id, c_id, GETDATE(), @inputman, @auditman1, @audittime1, @auditman2, @audittime2, 
					auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
					trafficCompany, tempcontrolmode, @WholeQty, @PartQty, discountTotal, @TaxTotal, Ybillid, Ybilltype, Yguid, 
					b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, @Note,@billstates, s_id, TrafficTime, 
					NEWID(),@FollowNumber,@TicketDate, BalanceMode,YE_ID,SendC_Id
		FROM      dbo.GSPbillidx
 		WHERE Gspbillid = -@nVchCode	
	
		IF @@ROWCOUNT = 1
		    SET @nRET = @@IDENTITY	
		EXEC TS_H_BillTraceAct 0, @nRet, @billType, @YBillId, @YBillType, 1, 1
	END
	else
	BEGIN 
		INSERT INTO GSPbillidx
		(   billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, 
			audittime1, auditman2, audittime2, upauditman1, upauditman2, traffictype, traffictools, 
			traffictime, tempcontrol, spectrafficprove, sendaddress, sendtime, trafficCompany, tempcontrolmode,
			WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, S_id, note,billstates,
			b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,FollowNumber,TicketDate,
			financeAudit,financeAuditDate, BalanceMode,InBags,YE_id,SendC_Id
		)
		VALUES
		(   @billtype, @billnumber, @Y_id, @c_id, @billdate, @inputman, @auditman1,
			@audittime1, @auditman2, @audittime2, @upauditman1, @upauditman2, @traffictype, @traffictools,
			@traffictime, @tempcontrol, @spectrafficprove, @sendaddress, @sendtime, @trafficCompany, @tempcontrolmode,
			@WholeQty, @PartQty, @discountTotal, @TaxTotal, @Ybillid, @Ybilltype, @Yguid, @s_id,@Note,
			@billstates, @b_CustomName1, @b_CustomName2, @b_CustomName3, @b_CustomName4, @b_CustomName5,@FollowNumber,@TicketDate,
			@financeAudit,@financeAuditDate, @BalanceMode,@InBags,@YE_id,@SendC_Id
		)
		IF @@ROWCOUNT = 1
		    SET @nRET = @@IDENTITY	
		EXEC TS_H_BillTraceAct 0, @nRet, @billType, @YBillId, @YBillType, 1, 1
	END
END
GO
