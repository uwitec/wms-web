
CREATE PROCEDURE [dbo].[TS_Z_LicenseList]
	@Act int,
    @cl_id int,
	@repname varchar(120),
	@ISExpriedTips int,
	@ISProhibitBill int
AS
BEGIN
	SET NOCOUNT ON;

	if @Act = 0  /*添加*/
	begin
		if Exists(select 1 from ClientLicense where [repname] = @repname)
		begin
			Raiserror('证照名称不能重复！', 16, 1)
			return 0
		end
		insert into ClientLicense(
			[repname],
			[ISExpriedTips],
			[ISProhibitBill],
			[sysdelete]
		) values(
			@repname,
			@ISExpriedTips,
			@ISProhibitBill,
			0
		)
		if @@rowcount > 0
			return @@identity
	end
	else
	if @Act = 1 /*修改*/
	begin
	  /*  if Exists(select 1 from ClientLicense where cl_id=@cl_id and sysdelete = 1)--系统默认的不允许修改
	    begin
			Raiserror('系统证照不允许修改！', 16, 1)
			return 0	       
	    end */
		if Exists(select 1 from ClientLicense where [repname] = @repname and cl_id <> @cl_id)
		begin
			Raiserror('证照名称不能重复！', 16, 1)
			return 0
		end
		update ClientLicense set
			[repname] = @repname,
			[ISExpriedTips] = @ISExpriedTips,
			[ISProhibitBill] = @ISProhibitBill
		where cl_id = @cl_id
		return @cl_id  
	end
	if @Act = 2 /*删除*/
	begin
		delete from ClientLicense where cl_id = @cl_id
		return 1
	end
END
GO
