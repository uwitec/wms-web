
CREATE FUNCTION GetDeductTemplateCgName
(
	@Type           INT,              /*提成方案类型*/
	@CategoryId     INT               /*Deduct_FormulaDetail.CategoryId*/
)
RETURNS VARCHAR(800)
AS
BEGIN
	DECLARE @Result VARCHAR(800)
	SET @Result = ''
	
	IF @Type IN (1, 2, 3, 4)
	BEGIN
		/*选择自定义类别的提成方案类型*/
		SELECT @Result = name FROM customCategory WHERE id = @CategoryId
	END
	ELSE
	IF @Type IN (0, 6, 7, 8)
	BEGIN
		/*选择商品的提成方案类型*/
		SET @Result = ''
		SELECT @Result = '【' + p.name + '】' + '【' + p.[standard] + '】' + '【' + u.name + '】' + '【' + p.makearea + '】' 
			FROM products p INNER JOIN unit u ON p.unit1_id = u.unit_id 
		WHERE p.product_id = @CategoryId
	END
	ELSE
	IF @Type IN (5)
	BEGIN
		/*单据量提成类型*/
		DECLARE @VchName VARCHAR(800)
		SET @VchName = ''
		
		DECLARE WriteSummary CURSOR  
		FOR
			SELECT v.Comment
			FROM   (
			           SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @Type
			       ) a
			       INNER JOIN VchType v ON  a.VchType = v.Vch_ID		
		OPEN WriteSummary
		FETCH NEXT FROM WriteSummary INTO @VchName                                                                                                     
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @Result = ''
			    SET @Result = @VchName
			ELSE
				SET @Result = @Result + ', ' + @VchName 
			FETCH NEXT FROM WriteSummary INTO @VchName
		END
		CLOSE WriteSummary
		DEALLOCATE WriteSummary
	END
	ELSE
		SET @Result = 'Error Type'
	
	RETURN @Result	
END
GO
