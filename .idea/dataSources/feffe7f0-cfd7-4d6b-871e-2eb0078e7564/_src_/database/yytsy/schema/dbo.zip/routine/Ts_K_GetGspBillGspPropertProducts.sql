CREATE PROCEDURE Ts_K_GetGspBillGspPropertProducts(@BillId INT)
AS
BEGIN
	SELECT d.p_id, ltrim(rtrim(c.gspflag)) AS GspId, c.GSPPropert, c.otcflag, c.OTCType
	FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
		    FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
			) c
			INNER JOIN (
					SELECT DISTINCT p_id
					FROM   (   SELECT p_id FROM GspBillDetail
							   WHERE  Gspbill_id = @BillId
							) e
	        ) d
	        ON  c.product_id = d.p_id
END
GO
