

/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-8-27*/
/* Description:	读取病人资料*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_SelPatient] 
	@Type		int = 0,			/*类型 0：基本资料 1：处方列表 2：病历列表 3：挂号列表 4: 工作计划  5：查询基本资料*/
	@Name		varchar(60) = '',	/*姓名 */
	@IDCard		varchar(50) = '',	/*身份证号*/
	@Tel		varchar(30) = '',	/*电话号码*/
	@FirstExam	varchar(20) = '',	/*诊断时间开始*/
	@LastExam	varchar(20) = '',	/*诊断时间结束*/
	@Where		varchar(8000) = '',	/*条件*/
	@cardno     varchar(50) = '',    /*卡号*/
	@st         int =0,              /*0：表示所有病人 1：已挂过号的病人*/
	@szcondition varchar(100) = ''   /*查询条件 add by luowei 2012-09-17*/
AS
BEGIN
/*Params Ini begin*/
if @Type is null  SET @Type = 0
if @Name is null  SET @Name = ''
if @IDCard is null  SET @IDCard = ''
if @Tel is null  SET @Tel = ''
if @FirstExam is null  SET @FirstExam = ''
if @LastExam is null  SET @LastExam = ''
if @Where is null  SET @Where = ''
if @cardno is null SET @cardno =''
if @szcondition is null set @szcondition = ''
/*Params Ini end*/
	SET NOCOUNT ON;
	
	declare @varCount int
	declare @SQL varchar(8000)
	
	set @varCount = 0
	if @Type = 0
		set @SQL = 'select * from vw_h_exampatients'
	else
	if @Type = 5
	    set @SQL = 'select * from VW_H_ExamGhPatients'
	else 
	if @Type = 1
		set @SQL = 'select * from vw_h_Prescriptions'
	else
	if @Type = 2
		set @SQL = 'select * from vw_h_casehistory'
	else
	if @Type = 3
	begin
		set @SQL = 'select * from vw_h_Registered'
		if @Where <> ''
		begin
			declare @eid int
			set @eid = cast(@where as int)
			if @eid > 0
				set @Where = '  departmentid = (select dep_id from employees where emp_id = ' + @Where + ')'
			else
			begin
				set @SQL = 'select vp.*, emp.*, CAST(ISNULL(pt.PresState, 0) AS BIT) as PresState, ISNULL(pt.ExamDate, ''1900-1-1'') as ExamDate, cast(ISNULL(pc.caseState, 0) as bit) as CaseState
					,0 as Reg_ID from vw_h_exampatients vp left join
					(select 1 as PresState, max(BillDate) as ExamDate, Patient_ID from VW_H_Prescriptions group by Patient_ID) pt
					on vp.PatientID = pt.Patient_ID LEFT JOIN
					(select 1 as caseState, Patientid from VW_H_CaseHistory group by Patientid) as pc
					on vp.PatientID = pc.PatientID cross join (
					select DepName as DeptName, name as DoctorName, dep_id as DepartmentID
					, emp_id as Doctor_ID from vw_employee where emp_id = ' + cast(abs(@eid) as varchar) +') emp'
				set @Where = ''
			end
		end
	end
	else
	if @Type = 4
	begin
		set @SQL = 'select * from vw_h_workplan'
	end
	
	if @Name <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where   '
		set @SQL = @SQL + '('
		if @Type = 4
			set @sql = @sql + '  [EmpName] like ''%' + @name + '%'''
		else
			set @sql = @sql + ' [name] like ''%' + @name + '%'''
		set @SQL = @SQL + ' OR [Pinyin] like ''%' + @Name + '%'') '
		set @varCount = @varcount + 1
	end
	if @cardno <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + 'CardNo like ''%' + @cardno + '%'''
		set @varCount = @varcount + 1
	end
	if @IDCard <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '[IDCard] like ''%' + @IDCard + '%'''
		set @varCount = @varcount + 1
	end
	if @Tel <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where  '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '[Tel] like ''%' + @Tel + '%'''
		set @varCount = @varcount + 1
	end
	
	/*查询时间段*/
	if @FirstExam <> '' and @LastExam <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where  '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		if @Type = 4
			set @sql = @sql + '([workday] >= ''' + @FirstExam + ''' and [workday] <= ''' + @LastExam + ''')'
		if @Type = 1
			set @sql = @sql + '([billdate] >= ''' + @FirstExam + ''' and [billdate] <= ''' + @LastExam + ''')'
		if (@Type = 0) OR (@Type = 3) or (@Type = 2) or (@Type = 5)
		begin
		    if @st =1 
			  set @sql = @sql + '([regdate] >= ''' + @FirstExam + ''' and [regdate] <= ''' + @LastExam + ''')'	
			else
			  set @sql = @sql + ' regdate >='''+'1900-01-01'+''''	   	
		end					
		set @varCount = @varcount + 1
	end
		
	if @Where <> ''
	begin
		if @varcount = 0
			set @sql = @sql + ' where '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + @Where
		set @varCount = @varcount + 1
	end
	if @szcondition <> ''
	begin
	    if @varcount = 0
			set @sql = @sql + ' where 1=1 '
		else
		if @varcount > 0
			set @sql = @sql + ' and '
		set @sql = @sql + '(name like ''%'+@szcondition+'%'' or Pinyin like ''%'+@szcondition+'%'' 
		                   or cardNo like ''%'+@szcondition+'%'' or tel like ''%'+@szcondition+'%''
		                   or idcard like ''%'+@szcondition+'%'')'	
	end
	/*print @sql*/
	exec(@SQL)
END
GO
