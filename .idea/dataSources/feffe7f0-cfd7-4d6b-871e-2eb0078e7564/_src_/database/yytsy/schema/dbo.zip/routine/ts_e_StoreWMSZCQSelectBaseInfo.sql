create procedure ts_e_StoreWMSZCQSelectBaseInfo
 @ID       int=0,  /*暂存区id */
 @S_id integer=0,/*仓库ID*/
 @ZCQname varchar(100)='',/*暂存区名称*/
 @PSRoad  int=0,/*配送线路*/
 @Billtype int=0,/*业务类型*/
 @StopStatus int=0/*停用状态*/
as
begin
  if @ID<>0
  begin
    	select a.Code as zcqcode,a.name as zcqname,a.PinYin as zcqpy ,isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
			case billtype when 0 then '全部' when 1 then   '销售出库' when 2 then '门店配送' when 3 then '采购退货' when 4 then '其它出库' end as billtype,
			case CyFs when 0 then '全部' when 1 then '自提' when 2 then '企业配送' when 3 then '委托运输' end as cyfstype, 
			case priority when 0 then '一般' when 1 then '补货' when 2 then '优先' when 3 then '急救' end as yxjtype,
			case LockStatus when 0 then '否' when 1 then '是' end as lockstatus,
			case isnull(c.RoadName,'') when '' then '全部' else isnull(c.RoadName,'') end  as PSRoad,
			a.ID as Store_ZCQ_ID,S_id as Store_id,isnull(d.name,'') as yname,
			Case a.deleted when 0 then '启用' when 2 then '停用' end as StopStatus,
			a.PinYin as pym,a.CyFs,a.billtype as btyid,a.priority,a.LockStatus as lockid,
			case a.Deleted when 0 then 0 when 2 then 1 end as deleted ,
			a.ifHold,Case a.ifhold when 0 then '否' else '是' end as ifexithold,
			isnull(MaxBillNum,0) as MaxBillNum
			 from WMSHold a 
				  left join storages b on a.S_id=b.storage_id
				  left join sendRoad c on a.roadid=c.roadid
				  left join company  d on b.Y_ID=d.company_id
			   where a.ID=@ID and a.deleted in (0,2)
  end
  else
  begin
		 if @StopStatus=1 
		 begin
			select a.Code as zcqcode,a.name as zcqname,a.PinYin as zcqpy ,isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
			case billtype when 0 then '全部' when 1 then   '销售出库' when 2 then '门店配送' when 3 then '采购退货' when 4 then '其它出库' end as billtype,
			case CyFs when 0 then '全部' when 1 then '自提' when 2 then '企业配送' when 3 then '委托运输' end as cyfstype, 
			case priority when 0 then '一般' when 1 then '补货' when 2 then '优先' when 3 then '急救' end as yxjtype,
			case LockStatus when 0 then '否' when 1 then '是' end as lockstatus,
			case isnull(c.RoadName,'') when '' then '全部' else isnull(c.RoadName,'') end  as PSRoad,
			a.ID as Store_ZCQ_ID,S_id as Store_id,isnull(d.name,'') as yname,
			Case a.deleted when 0 then '启用' when 2 then '停用' end as StopStatus,
			a.PinYin as pym,a.CyFs,a.billtype as btyid,a.priority,a.LockStatus as lockid,
			case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
			a.ifHold,Case a.ifhold when 0 then '否' else '是' end as ifexithold,
			isnull(MaxBillNum,0) as MaxBillNum 
			 from WMSHold a 
				  left join storages b on a.S_id=b.storage_id
				  left join sendRoad c on a.roadid=c.roadid
				  left join company  d on b.Y_ID=d.company_id
			   where 
										(a.S_id=@S_id or @S_id=0) and 
										(a.name like '%'+@ZCQname+'%') and 
										(a.RoadID=@PSRoad or @PSRoad=0) and 
										(a.billtype=@Billtype or @Billtype=0) and 
										a.deleted in (0,2)
		end
		else
		begin
			select a.Code as zcqcode,a.name as zcqname,a.PinYin as zcqpy ,isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode,
			case billtype when 0 then '全部' when 1 then   '销售出库' when 2 then '门店配送' when 3 then '采购退货' when 4 then '其它出库' end as billtype,
			case CyFs when 0 then '全部' when 1 then '自提' when 2 then '企业配送' when 3 then '委托运输' end as cyfstype, 
			case priority when 0 then '一般' when 1 then '补货' when 2 then '优先' when 3 then '急救' end as yxjtype,
			case LockStatus when 0 then '否' when 1 then '是' end as lockstatus,
			case isnull(c.RoadName,'') when '' then '全部' else isnull(c.RoadName,'') end  as PSRoad,
			a.ID as Store_ZCQ_ID,S_id as Store_id,isnull(d.name,'') as yname,
			Case a.deleted when 0 then '启用' when 2 then '停用' end as StopStatus,
			a.PinYin as pym,a.CyFs,a.billtype as btyid,a.priority,a.LockStatus as lockid,
			case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
			a.ifHold,Case a.ifhold when 0 then '否' else '是' end as ifexithold,
			isnull(MaxBillNum,0) as MaxBillNum 
			 from WMSHold a 
				  left join storages b on a.S_id=b.storage_id
				  left join sendRoad c on a.roadid=c.roadid
				  left join company  d on b.Y_ID=d.company_id
			   where 
										(a.S_id=@S_id or @S_id=0) and 
										(a.name like '%'+@ZCQname+'%') and 
										(a.RoadID=@PSRoad or @PSRoad=0) and 
										(a.billtype=@Billtype or @Billtype=0) and 
										 a.deleted in (0)
		end    
	end                            
end
GO
