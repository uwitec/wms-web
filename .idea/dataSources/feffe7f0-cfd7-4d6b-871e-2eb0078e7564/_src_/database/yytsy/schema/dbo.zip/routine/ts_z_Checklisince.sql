
CREATE	 PROCEDURE ts_z_Checklisince
	(
      @C_ID int = 0,
      @ctype int = 0,
      @entType int
     )
AS 
   if @entType = -1 
   begin
     select @entType = ent_type from clients where client_id=@C_ID
   end
   
  /* 今天不算过期*/
   if not exists(select 1 from ClientReport2 r left join ClientLicense l on r.rpn_id = l.cl_id 
       left join BindLicense bl on l.cl_id=bl.cl_id  
       where bl.ent_type=@entType and c_id = @C_ID and CType = @ctype and validTime >'1900-01-01' and validtime < convert(varchar(10), GETDATE(), 20) ) /*如果不存在过期的证照*/
   begin
       select 1
       return 0 /*不存在过期的*/
   end
   if exists(select 1 from ClientReport2 r left join ClientLicense l on r.rpn_id = l.cl_id 
            left join BindLicense bl on l.cl_id=bl.cl_id  
            where bl.ent_type=@entType and c_id = @C_ID and CType = @ctype and validTime >'1900-01-01' and validtime < convert(varchar(10), GETDATE(), 20) 
            and isexpriedtips =1)   /*过期要提示*/
    begin
		 select repname from ClientReport2 r left join ClientLicense l on r.rpn_id = l.cl_id 
		 left join BindLicense bl on l.cl_id=bl.cl_id 
		 where bl.ent_type=@entType and c_id = @C_ID and CType = @ctype and validTime >'1900-01-01' and validtime < convert(varchar(10), GETDATE(), 20) 
		 and isexpriedtips =1  
		 
	   if exists(select 1 from ClientReport2 r left join ClientLicense l on r.rpn_id = l.cl_id 
	            left join BindLicense bl on l.cl_id=bl.cl_id 
				where bl.ent_type=@entType and c_id = @C_ID and CType = @ctype and validTime >'1900-01-01' and validtime < convert(varchar(10), GETDATE(), 20) 
				and ISProhibitBill =1)  /*禁止开单*/
	   begin
			return -1 /*要提示 禁止开单*/
	   end
	   else
	   begin
	        return -2 /*要提示  不禁止开单*/
	   end      
    end
    else  /*过期不提示*/
    begin
	   if exists(select 1 from ClientReport2 r left join ClientLicense l on r.rpn_id = l.cl_id 
	            left join BindLicense bl on l.cl_id=bl.cl_id 
				where bl.ent_type=@entType and c_id = @C_ID and CType = @ctype and validTime >'1900-01-01' and validtime < convert(varchar(10), GETDATE(), 20) 
				and ISProhibitBill =1)  /*禁止开单*/
	   begin
	        select 1 
			return -3 /*不提示 禁止开单*/
	   end
	   else
	   begin
	        select 1 
	        return -4 /*不提示  不禁止开单*/
	   end   
    end
GO
