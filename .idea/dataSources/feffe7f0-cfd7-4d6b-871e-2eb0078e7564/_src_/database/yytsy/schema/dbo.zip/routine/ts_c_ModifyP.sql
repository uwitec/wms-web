/*
--------Return values--------
	 0: 成功
	-1: 负库存
	-2:
	-3: 数量为零
	-4: 期初不能修改
	-5: 无成本价
  -6: 异常错误
  -7: 已经开帐，数据不能修改
  -22: 未设置当前机构，不允许单据过账
-----------------------------
*/

CREATE  PROCEDURE [dbo].[ts_c_ModifyP]
(
	@nBillType 	numeric(4, 0),	  /*单据类型号*/
	@nCostType	int,  					  /*成本核算法*/
	@nP_id  		int,  					  /*商品id*/
	@nS_id  		int,  					  /*仓库id*/
	@nL_id			int output,  					  /*货位id*/
	@nStoreType	int,  					  /*库存余量库类型 0:Normal 1:dx 2:Br*/
	@nPriceId 	int,  					  /*Price库Id*/
	@szBatchNo 	varchar(20) output,  	  /*批号*/
	@szPeriod  	varchar(2),   	  /*会计期号*/
	@dQtyIn   		NUMERIC(25,8),	/*数量*/
	@dCostTotalIn NUMERIC(25,8),	/*总金额*/
	@dCostPriceIn	NUMERIC(25,8) output,	/*传入成本单价*/
	@MakeDate		  datetime=null output,  /*生产日期*/
	@ValidDate	  datetime=null   output,  /*效期*/
 	@nSupplier_idIn     int           output,/*供应商id*/
 	@nCommissionflagIn  int	          output,/*代销商品标记*/
	@dCostTotalOut      NUMERIC(25,8)	output,/*返回成本金额*/
	@ReturnNumber       int           output, /*返回代码*/
	@nBillid	          numeric(10,0),
  	@OldCommissionflag  int=0,
	@tInstoretime     datetime=null output,  /*入库时间*/
	@nY_ID		 int,
	@batchbarcode varchar(80)='',
	@scomment varchar(80)='',
	@batchprice NUMERIC(25,8)=0,
	@factoryid int=0, /*生成厂家*/
	@taxprice NUMERIC(25,8),/*含税单价*/
	@taxtotal NUMERIC(25,8),/*含税金额*/
	@taxrate  NUMERIC(25,8),/*税率*/
	@dTaxTotalOut  NUMERIC(25,8) output /*返回含税金额*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @MakeDate is null  SET @MakeDate = null 
if @ValidDate is null  SET @ValidDate = null   
if @OldCommissionflag is null  SET @OldCommissionflag = 0
if @tInstoretime is null  SET @tInstoretime = null 
if @batchbarcode is null  SET @batchbarcode = ''
if @scomment is null  SET @scomment = ''
if @batchprice is null  SET @batchprice = 0
/*Params Ini end*/
	set nocount on

	if @makedate<10 set @makedate=0
	if @validdate<10 set @validdate=0

/*------Some account id*/
	declare
		@Asset_Id 			int, 				/*2	【资产合计】*/
		@Products_Id 		int,				/*3	『库存商品总值合计』*/
		@FixedAsset_id 	int,				/*4	『固定资产合计』*/
		@FixedAsset1_id int,				/*5	 固定资产__甲*/
		@Cash_id 				int,				/*6	 现    金*/
																/*7	『全部银行存款合计』*/
																/*8	银行户头_1*/
		@ArTotal_Id 		int,				/*9	『应收款合计』*/
		@Lendout_Id 		int ,				/*10	『借出商品』*/
		@Dt_Expens_Id 	int,				/* 11	待摊费用*/
		@Wt_Comm_Id 		int,				/*12	委托代销商品*/
		@St_Comm_Id 		int,				/*13	受托代销商品*/
																/*14	【负债合计】*/
		@ApTotal_Id 		int,				/*15	『应付帐款合计』*/
		@Brrowin_Id 		int,				/*16	『借入商品』*/
		@DxTotal_Id 		int,				/*17	代销商品款*/
																/*18	应交税金*/
																/*19	【收入类】*/
		@SaleIncome_Id 	int					/*20	『销售收入』*/
																/*21	『商品类收入』*/
		/*Product_22	商品报溢收入

		23	商品获赠收入
		24	成本调价收入
		25	进货退货差价
		26	变价调拨差价
		27	商品拆装差价
		28	借转进货结算与成本差
		29	受托代销结算差价
		30	『其它收入』
		31	调帐收入
		32	利息收入
		33	其它....
		34	【支出类】
		35	『销售成本』
		36	『商品类支出』
		37	商品报损
		38	商品赠出
		39	『费用合计』
		40	调帐亏损
		41	固定资产折旧
		42	其它....
		43	【所有者权益】
		44	实收资本
		45	资本公积
		46	盈余公积
		47	本年利润
		48	利润分配
		49	【利润】
		54	进项税
		55	销项税
		*/

	select	@Asset_Id			=2				/*	【资产合计】*/
	select	@Products_Id	=3				/*	『库存商品总值合计』*/
	select	@FixedAsset_id=4  			/*	『固定资产合计』*/
	select	@Cash_id=6				  		/*	 现    金*/
															  	/*7	『全部银行存款合计』*/
																  /*8	银行户头_1*/
	select	@ArTotal_Id		=9				/*9	『应收款合计』*/
	select	@Lendout_Id		=10				/*10	『借出商品』*/
	select	@Dt_Expens_Id	=11			  /*11	待摊费用*/
	select	@Wt_Comm_Id		=12				/*12	委托代销商品*/
	select	@St_Comm_Id		=13				/*13	受托代销商品*/
																  /*14	【负债合计】*/
	select	@ApTotal_Id		=15				/*15	『应付帐款合计』*/
	select	@Brrowin_Id		=16				/*16	『借入商品』*/
	select	@DxTotal_Id		=17				/*17	代销商品款*/
																  /*18	应交税金*/
																  /*19	【收入类】*/
	select	@SaleIncome_Id=20			  /*20	『销售收入』*/

/*-----成本核算------------*/
	declare @MOVEAVERAGE	char(1)   /*移动加权平均*/
	declare @FIFO		char(1)   /*先进先出*/
	declare @LIFO    	char(1)   /*后进先出*/
	declare @SINGLE    	char(1)   /*个别记价*/
	declare @VALID_DATE	char(1)	  /*近效期先出*/
/*	declare @AVERAGE	char(1)	  --加权平均*/

	select @MOVEAVERAGE		='0'
	select @FIFO       		='1'
	select @LIFO       		='2'
	select @SINGLE     		='3'
	select @VALID_DATE    ='4'
/*	select @AVERAGE	      ='5'*/
/*-------------------*/
  declare @nSupplier_id     int/*供应商id*/
  declare @nFactoryid       int/*生产厂家ID*/
  declare @nCommissionflag  int/*代销商品标记*/
  declare @ntaxrate         NUMERIC(25,8) /*税率*/
  declare @nLocation_id int
  declare @dQuantity NUMERIC(25,8),@dCosttotal NUMERIC(25,8),@dCostPrice NUMERIC(25,8),@dtaxprice  NUMERIC(25,8),@dtaxtotal NUMERIC(25,8)
  declare @tMakedate datetime,@tValiddate datetime,@szBatchNoTemp varchar(30)
  declare @dCostPricetemp   NUMERIC(25,8),@dCosttotalTemp NUMERIC(25,8),@dQtyTemp NUMERIC(25,8),@dPricetemp NUMERIC(25,8),@dtPricetemp NUMERIC(25,8)
  declare @dtaxpricetemp    NUMERIC(25,8),@dtaxtotaltemp  NUMERIC(25,8)
  declare @szY_ID varchar(10)    /*当前机构*/
  declare @cNegativeStock   char(1)/*是否允许负库存*/
  declare @cRecpriceAsCost  char(1)/*是否使用最近进价作为成本价*/
  declare @nStopsaleflag		bit		 /*停售标志*/
  declare @nInorder					int		 /*入库顺序号*/
  /*declare @tInstoretime     datetime--入库时间*/
  declare @tmpInstoretime     datetime/*入库时间*/
  declare @tYhDate          datetime/*上次养护时间 zhh添加*/
  declare @PosLoc						char(1)/*是否管理门店仓库货位*/
  declare @StorageType			int/*门店仓库类型*/
  /*if @nbillid<>0 select  @tInstoretime=billdate from billidx where billid=@nbillid*/
  /*else select  @tInstoretime=convert(varchar(10),getdate(),20)*/
  
  declare @cUseSameCostMethod varchar(2),@nCostMethod varchar(2)
  declare @nQtyNagtive NUMERIC(25,8) /*处理个别计价负库存出库*/
  
  set @szY_ID = '2'
  select @szY_ID = sysvalue from sysconfig where sysname = 'Y_ID'   /*取当前机构id */
  
  

  
  /*--------得到成本核算法*/
 /* if @bKeepCostMethod <> 1*/
 /* begin*/
	/*exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out --是否使用同一成本核算法*/
	/*if @cUseSameCostMethod='1' --系统使用统一成本核算*/
	/*begin*/
	/*	exec ts_getsysvalue 'CostMethod',@nCostMethod out*/
	/*	set @nCostType=cast(@nCostMethod as int)*/
 /*   end else if @cUseSameCostMethod='0' --系统不使用统一成本核算，得到该商品成本算法*/
 /*   begin*/
	/*	set @nCostType=dbo.GetcostNo(@nP_id)*/
 /*   end*/
 /* end*/
    
  /*当入库时间不做为批次条件时且为入库时处理*/
  if (@nCostType <> 0) and (@dQtyIn > 0)
  begin  
	if exists(select 1 from sysconfigtmp where [sysname] = 'InstoretimeBatch' and sysvalue = '0')
	begin
	   select @tmpInstoretime = MAX(instoretime) from storehouse where p_id = @nP_id and s_id = @nS_id and location_id = @nL_id and
			   batchno = @szBatchNo and makedate = 	@MakeDate and validdate =  @ValidDate and supplier_id = @nSupplier_idIn and
 			   commissionflag =  @nCommissionflagIn and y_id = @nY_ID	and Factoryid=@factoryid
	   if  @tmpInstoretime is not null
		 set @tInstoretime = @tmpInstoretime
       set @tmpInstoretime = 0
    end    
  end
    
  select @tYhDate = @tInstoreTime /*zhh 添加*/

  select @dCostPricetemp=0,@dCosttotaltemp=0,@dQtyTemp=0,@dPricetemp=0,@szBatchNoTemp='',@nStopsaleflag=0,@dtaxpricetemp=0,@dtaxtotaltemp=0,@dtPricetemp=0
  select @tValidDate=0,@tMakeDate=0,@tmpInstoretime=0    
/*-----取开关--------*/
  exec ts_GetSysValue 'NegativeStock',  @cNegativeStock output
  exec ts_GetSysValue 'RecpriceAsCost', @cRecpriceAsCost output
  exec ts_GetSysValue 'PosLoc', @PosLoc output
  
  set @storagetype=0
  select @storagetype=flag from storages where storage_id=@nS_id
  
/*2004-06-27 zc modify*/
  if @PosLoc='1'
	begin
		set @storagetype=0
		select @storagetype=flag from storages where storage_id=@nS_id
		if @storagetype<>0 set @nL_id=0
	end
/**/

/**/
	declare @dDoubleZero NUMERIC(25,8)
	set @dDoubleZero=0.001
/*2005-06-28 zc modify 解决小数位数带来的误差。*/
/**/

/*-------------------*/
  if @dQtyIn=0/*数量为零返回*/
  begin
    select @ReturnNumber=-3
    return -3
  end

  if @szPeriod=''/*修改当前*/
  begin
    if @nCostType=@MOVEAVERAGE/*移动加权平均法*/
    begin
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal from storehouse
        where p_id=@nP_Id and s_id=@nS_id and Y_ID = @nY_ID
        for update
      end
      if @nStoreType=1
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
        where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
        for update
      end
      if @nStoreType=2
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
        where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
        for update
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      if @@fetch_status=0/*有库存*/
      begin

         if @dQtyin<0
         begin
              /*取成本价*/
              if @dCostTotalIn=0 
    	      begin
                if @dCostPrice=0
                begin
                  if @cRecpriceAsCost='1' and @dCostPricein=0 /*使用最近进价作为成本价*/
                  begin
                     select @dCostprice=dbo.GetRecprice(@nP_id,@nPriceid)
                     if @dCostprice=0 
    	             begin
    		            select @dCostprice=@dCostpriceIn
    		            if @dCostprice=0 goto InputCostPriceerror
                  	    select @dCostTotalIn=@dCostPrice*@dQtyIn
    	             end 
    	             else
                   	select @dCostTotalIn=@dCostPrice*@dQtyIn
                 end 
                 else 
    	         begin
    		       select @dCostprice=@dCostpriceIn
                   if @dCostprice=0 goto InputCostPriceerror
                   select @dCostTotalIn=@dCostPrice*@dQtyIn
    	         end
               end 
               else
               begin
                 select @dCostTotalIn=@dCostPrice*@dQtyIn
                 select @dCostPriceIn=@dCostPrice
               end
    	      end 
    	      else
    	         select @dCostPrice=@dCostTotalIn/@dQtyIn
         end 
         else
         begin
	          if @dCostTotalIn=0 
		      begin
				  if @dCostPriceIn<=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dCostpriceIn=0 goto InputCostPriceerror
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
					end else goto InputCostPriceerror
				  end 
				  else
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		      end 
		      else
		        select @dCostPriceIn=@dCostTotalIn/@dQtyIn
         end

        if @dQtyIn<0 /*有库存出库--*/
        begin
          if @dQuantity<abs(@dQtyIn)
          begin
            if @cNegativeStock='0' or (@nBilltype in (31,32,34,35,43,111,112,121,122) and @nstoretype<>0) goto Error/*系统不允许负库存*/
            else
            begin/*负库存出库*/
              select @dQuantity=@dQuantity+@dQtyIn
              select @dCosttotal=@dCosttotal+@dCosttotalIn
              select @dtaxtotal =@dtaxtotal +@taxtotal
              if @nStoreType=0
              begin
                update storehouse set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                      costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedx set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                      costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrow set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                      costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
/*              select @dCostTotalOut=abs(@dCosttotalIn)--返回成本总金额   2004-07-19 曾川改 解决负库存问题*/
              select @dCostTotalOut=@dCosttotalIn/*返回成本总金额   2004-07-19 曾川改 解决负库存问题*/
              select @dTaxTotalOut=@dtaxtotal
              goto Success
            end
          end
          if @dQuantity=abs(@dQtyIn)
          begin
/*	          select @dCosttotalIn=@dCosttotal
            select @dCosttotal=0
            select @dQuantity=@dQuantity+@dQtyIn
--              select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19 曾川改 解决负库存问题
              select @dCostTotalOut=(@dQtyin/abs(@dQtyin))*@dCosttotalIn-- 2004-07-19 曾川改 解决负库存问题
*/	      		     
             select @dCosttotal=@dCosttotal+@dCostTotalIn
             select @dQuantity=@dQuantity+@dQtyIn
/*             select @dCostTotalOut=abs(@dCostTotalIn)*/
             select @dCostTotalOut=@dCosttotalIn/* 2004-07-19 曾川改 解决负库存问题*/
             select @dTaxTotalOut=@taxtotal

            if @dCostTotal=0
            begin
              if @nStoreType=0
              begin
                delete from storehouse where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                delete from storedx where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                delete from storebrrow where current of curP
                if @@rowcount=0 Goto syserror
              end
            end else
	          begin
              if @nStoreType=0
              begin
                update storehouse set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
              if @nStoreType=1
              begin
                update storedx set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
              if @nStoreType=2
              begin
                update storebrrow set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
	      end
            goto Success
          end
          else
          begin
            select @dCosttotal=@dCosttotal+@dCosttotalIn
            select @dtaxtotal =@dtaxtotal+@taxtotal
            select @dQuantity=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouse set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                    costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedx set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                 costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrow set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                    costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
/*            select @dCostTotalOut=abs(@dQtyIn*@dCostprice) -- 2004-07-19 曾川改 解决负库存问题*/
            select @dCostTotalOut=@dQtyIn*@dCostprice /* 2004-07-19 曾川改 解决负库存问题*/
            select @dTaxTotalOut=@dQtyIn*@dtaxprice
            goto Success
          end
        end 
        else/*有库存入库--*/
        begin
          select @dCosttotal=@dCosttotal+@dCostTotalIn
          select @dtaxtotal =@dtaxtotal +@taxtotal
          select @dQuantity=@dQuantity+@dQtyIn
          if @dQuantity<>0
          begin
            select @dCostprice=@dCosttotal/@dQuantity
            select @dtaxprice =@dtaxtotal /@dQuantity
          end
          else
          begin
            select @dCostprice=0
            select @dtaxprice=0
          end
          if @nStoreType=0
          begin
            update storehouse set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                                  costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            update storedx set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                               costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            update storebrrow set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                                  costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn
          select @dTaxTotalOut=@taxtotal
          goto Success
        end
      end else
      begin
        if @dQtyIn<0 /*无库存出库*/
        begin
            if @cNegativeStock='0' or (@nBilltype in (31,32,34,35,43,111,112,121,122) and @nstoretype<>0) goto Error/*系统不允许负库存*/
/*          if @cNegativeStock=0 goto Error*/
            else
            begin
          /*取成本价*/
	          if @dCostTotalIn=0 
		      begin
				   if @dCostPriceIn<=0
				   begin
					 if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					 begin
					   select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
					   if @dCostpriceIn=0 goto InputCostPriceerror
						select @dCostTotalIn=@dCostPriceIn*@dQtyIn
					 end 
					 else 
					 goto InputCostPriceerror
				   end 
				   else
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		      end 
		      else
		      select @dCostPriceIn=@dCostTotalIn/@dQtyIn
            /*处理含税单价和含税金额*/
              /*if @taxtotal=0 
		      begin
				   if @taxprice<=0
				   begin
					 if @cRecpriceAsCost='1' --使用最近进价作为成本价
					 begin
					   select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
					   if @taxprice=0 goto InputCostPriceerror
						select @taxtotal=@taxprice*@dQtyIn
					 end 
					 else 
					 goto InputCostPriceerror
				   end 
				   else
					  select @taxtotal=@taxprice*@dQtyIn
		      end 
		      else
		      select @taxprice=@taxtotal/@dQtyIn */
            if @nStoreType=0
            begin
              INSERT INTO storehouse
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
              costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,
              @taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedx
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrow
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
/*            select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19曾川改负库存问题*/
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
        
          /*取成本价*/
	    if @dCostTotalIn=0 
		begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerror
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerror
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		end 
		else
		  select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		/*-----取含税单价和含税金额*/
		/*if @taxtotal=0 
		begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerror
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerror
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		end 
		else
		  select @taxprice=@taxtotal/@dQtyIn*/
        if @nStoreType=0
        begin
          INSERT INTO storehouse
          (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
          costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,
          @taxprice,@taxtotal,@taxrate)
          if @@rowcount=0 Goto syserror
        end
        if @nStoreType=1
        begin
          INSERT INTO storedx
          (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
          if @@rowcount=0 Goto syserror
        end
        if @nStoreType=2
        begin
          INSERT INTO storebrrow
          (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
          if @@rowcount=0 Goto syserror
        end
/*            select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19曾川改负库存问题*/
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut=@taxtotal
        goto Success
      end
    end
    NegRetailOut:
    if @nCostType in (@FIFO,@VALID_DATE)/*先进先出法,近效期先出*/
    begin
      if exists(select * from master.dbo.syscursors where cursor_name = 'curP')
	  begin
		deallocate curP
	  end
      if @nStoreType=0
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storehouse where p_id=@nP_id and s_id=@nS_id and Y_ID =@nY_ID
      end
      if @nStoreType=1
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storedx where p_id=@nP_id and c_id=@nS_id and Y_ID =@nY_ID
      end
      if @nStoreType=2
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storebrrow where p_id=@nP_id and c_id=@nS_id and Y_ID =@nY_ID
      end
      if (@dQtytemp+@dQtyIn)<0 /*出现负库存*/
      begin
        select @ReturnNumber=-1
        return -1
      end
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
	          select @dPricetemp=abs(@dCostTotalIn/@dQtyIn)
	          if @taxtotal<>0
	          begin
	              select @dtPricetemp=abs(@taxtotal/@dQtyIn)
	          end
      	    if @nCostType = @FIFO
      	    begin
      		    declare curP cursor scroll for 
      	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
      	            where p_id=@nP_Id and s_id=@nS_id and costprice=@dPricetemp and Y_ID =@nY_ID 
      	            order by inorder asc
      	            for update
      	    end 
      	    else
      	    if @nCostType = @VALID_DATE
      	    begin
      		    declare curP cursor scroll for 
      	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
      	            where p_id=@nP_Id and s_id=@nS_id and costprice=@dPricetemp and Y_ID =@nY_ID 
      	            order by validdate asc
      	            for update
      	    end
          end 
          else
          begin
      	    if @nCostType = @FIFO
      	    begin
      	            declare curP cursor scroll for 
      	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
      	            where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
      	            order by inorder asc
      	            for update
      	    end else
      	    if @nCostType = @VALID_DATE
      	    begin
      	            declare curP cursor scroll for 
      	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
      	            where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID

      	            order by validdate asc
      	            for update
      	    end
          end
        end 
        else    /*入库*/
        begin
      	  if @nCostType = @FIFO
  	      begin
  	          declare curP cursor scroll for 
  	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
  	          where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
  	          order by inorder desc
  	          for update
      	  end else
  	      if @nCostType = @VALID_DATE
  	      begin
  	          declare curP cursor scroll for 
  	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
  	          where p_id=@nP_Id and s_id=@nS_id and batchno=@szBatchno and validdate=@validdate and Y_ID =@nY_ID
  /*	          order by inorder desc 2004-08-06 freebird修改*/
  	          for update
  	      end
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
      	    select @dPricetemp=@dCostTotalIn/@dQtyIn
      	    if @taxtotal<>0
      	    begin
      	     select @dtPricetemp=@taxtotal/@dQtyIn
      	    end
      	    if @nCostType = @FIFO
      	    begin
      	            declare curP cursor scroll for 
      	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
      	            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and instoretime = @tinstoretime  and Y_ID =@nY_ID  
      	            order by inorder asc
      	            for update
         	    end else
        	    if @nCostType = @VALID_DATE
        	    begin
        		        select @dPricetemp=@dCostTotalIn/@dQtyIn
        		        select @dtPricetemp=@taxtotal/@dQtyIn
        	            declare curP cursor scroll for 
        	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
        	            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and instoretime = @tinstoretime and Y_ID =@nY_ID 
        	            order by validdate asc
        	            for update
        	    end
          end else
          begin
  	        if @nCostType = @FIFO
  	        begin
  	            declare curP cursor scroll for 
  	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
  	            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
  	            order by inorder asc
  	            for update
     	      end else
        	  if @nCostType = @VALID_DATE
        	  begin
        	    declare curP cursor scroll for 
        	    select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
        	    where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
        	    order by validdate asc
        	    for update
            end
         end
        end else    /*入库*/
        begin
    	    if @nCostType = @FIFO
	        begin
	          declare curP cursor scroll for 
	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
	          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
	          order by inorder desc
	          for update
 	        end else
	        if @nCostType = @VALID_DATE
	        begin
	          declare curP cursor scroll for 
	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
	          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and batchno=@szBatchno and validdate=@validdate and Y_ID =@nY_ID 
/*	          order by inorder desc  2004-08-06 freebird修改*/
	          for update
	        end
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
				select @dPricetemp=@dCostTotalIn/@dQtyIn
				if @taxtotal<>0 
				begin
				  select @dtPricetemp=@taxtotal/@dQtyIn
				end
	    if @nCostType = @FIFO
	    begin
	            declare curP cursor scroll for 
	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and instoretime = @tinstoretime and Y_ID =@nY_ID 
	            order by inorder asc
	            for update
   	    end else
	    if @nCostType = @VALID_DATE
	    begin
	            declare curP cursor scroll for 
	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID 
	            order by validdate asc
	            for update
	    end	
          end else
          begin
	    if @nCostType = @FIFO
	    begin
	            declare curP cursor scroll for 
	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
	            order by inorder asc
	            for update
   	    end else
	    if @nCostType = @VALID_DATE
	    begin
	            declare curP cursor scroll for 
	            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
	            order by validdate asc
	            for update
	    end
          end
        end else    /*入库*/
        begin
          if @nCostType = @FIFO
	  begin
	          declare curP cursor scroll for 
	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
	          order by inorder desc 
	          for update
  	  end else
	  if @nCostType = @VALID_DATE
	  begin
	          declare curP cursor scroll for 
	          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
	          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and batchno=@szBatchno and validdate=@validdate and Y_ID = @nY_ID 
/*	          order by inorder desc 2004-08-06 freebird修改*/
	          for update
	  end
        end
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      while @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          select @dQtyIn=@dQuantity+@dQtyIn
          if @dQtyIn<=0/*本批次全部出库*/
          begin
            select @dCostTotaltemp=@dCostTotaltemp+@dCostTotal
            select @dtaxtotaltemp=@dtaxtotaltemp+@dtaxtotal
            if @nStoreType=0
            begin
              delete from storehouse where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedx where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrow where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @dQtyIn<>0 /*本批次数量不够，循环用下一批次出库*/
            begin
              fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
              continue
            end else if @dQtyIn=0/*出库完毕，返回成本金额*/
            begin
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,
              @nSupplier_idIn=@nSupplier_id ,@tInstoretime=@tmpInstoretime,@nL_id=@nLocation_id,@szBatchNo=@szBatchNoTemp,
              @factoryid=@nFactoryid,@taxrate=@ntaxrate,
              @dTaxTotalOut=@dtaxtotaltemp/* 2006-05-31 zc modify 解决零售不管批次时没有把supplier_id 返回*/
	            goto Success
            end
          end 
          else
          begin
                select @dCostTotaltemp=@dCostTotaltemp+(@dQuantity-@dQtyIn)*@dCostprice
                select @dtaxtotaltemp=@dtaxtotaltemp+(@dQuantity-@dQtyIn)*@dtaxprice
	            select @dCostTotalout=@dCostTotaltemp
	            select @dTaxTotalOut=@dtaxtotaltemp
              if @nStoreType=0
              begin
                update storehouse set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedx set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrow set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@nSupplier_idIn=@nSupplier_id,@tInstoretime=@tmpInstoretime,@nL_id=@nLocation_id,@szBatchNo=@szBatchNoTemp,@factoryid=@nFactoryid,@taxrate=@ntaxrate,
                     @dtaxtotaltemp=@dtaxtotaltemp
				      goto Success
          end
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	       if @dCostTotalIn=0 
		   begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		  end
		  else
		     select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		 /*-取含税单价和含税金额*/
		  /* if @taxtotal=0 
		   begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		  end
		  else
		     select @taxprice=@taxtotal/@dQtyIn*/
/*
          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nBillType=43 and 	@nCostType = @FIFO/*调价单要比较最先入库的单价和批号是否和调价入库的批号和成本价*/
          begin
            fetch last from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchnoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
            if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn/*如果批号和成本价相同则合并*/
            begin
              select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
              select @dtaxtotaltemp=@dtaxtotal+@taxtotal
              select @dQtytemp=@dQuantity+@dQtyIn
              if @nStoreType=0
              begin
                update storehouse set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedx set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrow set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@taxtotal
              goto Success
            end 
            else                                                  /*如果批号和成本价不相同则不合并*/
            begin
              select @dCostTotalOut=@dCostTotalIn
              select @dTaxTotalOut=@taxtotal
              if @nStoreType=0
              begin
                INSERT INTO storehouse
                (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder, Y_ID,Factoryid,
                costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1, @nY_ID,@factoryid,
                @taxprice,@taxtotal,@taxrate)
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                INSERT INTO storedx
                (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                INSERT INTO storebrrow
                (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@taxtotal
              goto Success
            end
          end

          if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn and @tValidDate=@validdate and @tInstoretime=@tmpInstoretime/*如果批号、效期和成本价相同则合并*/
          begin
            select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
            select @dtaxtotaltemp =@dtaxtotal+@taxtotal
            select @dQtytemp=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouse set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedx set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrow set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
          else                                                  /*如果批号、效期和成本价不相同则不合并*/
          begin
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut=@taxtotal
            if @nStoreType=0
            begin
              INSERT INTO storehouse
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
              costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,
              @taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedx
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrow
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
      end
      if @@fetch_status<>0/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          goto error/*先进先出法不允许负库存*/
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
	    	begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		  end 
		  else
		    select @dCostPriceIn=@dCostTotalIn/@dQtyIn
        /*----取含税单价和含税金额*/
           /*取成本价*/
	       /* if @taxtotal=0 
	    	begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		  end 
		  else
		    select @taxprice=@taxtotal/@dQtyIn*/
         
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nStoreType=0
          begin
            INSERT INTO storehouse
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
            costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,0, @nY_ID,@factoryid,
            @taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            INSERT INTO storedx
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder, Y_ID,factoryid, costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0, @nY_ID,@factoryid, @taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            INSERT INTO storebrrow
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder, Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid, @taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@makedate,@validdate=@validdate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut=@taxtotal
          goto Success
        end
      end
    end
    if @nCostType=@LIFO/*后进先出法*/
    begin
      if @nStoreType=0
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storehouse where p_id=@nP_id and s_id=@nS_id
      end
      if @nStoreType=1
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storedx where p_id=@nP_id and c_id=@nS_id
      end
      if @nStoreType=2
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storebrrow where p_id=@nP_id and c_id=@nS_id
      end
      if (@dQtytemp+@dQtyIn)<0 /*出现负库存*/
      begin
        select @ReturnNumber=-1
        return -1
      end
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			select @dPricetemp=@dCostTotalIn/@dQtyIn
			if @taxtotal<>0
			begin
			  select @dtPricetemp=@taxtotal/@dQtyIn
			end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
            where p_id=@nP_Id and s_id=@nS_id and costprice=@dPricetemp and Y_ID = @nY_ID
            order by inorder desc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
            where p_id=@nP_Id and s_id=@nS_id and Y_ID = @nY_ID 
            order by inorder desc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
          where p_id=@nP_Id and s_id=@nS_id and Y_ID = @nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			select @dPricetemp=@dCostTotalIn/@dQtyIn
			if @taxtotal<> 0
			begin
			  select @dtPricetemp=@taxtotal/@dQtyIn	
			end		
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID 
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID 
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			select @dPricetemp=@dCostTotalIn/@dQtyIn
			if @taxtotal<>0 
			begin
		      select @dtPricetemp=@taxtotal/@dQtyIn	
		    end		
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID 
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
          order by inorder desc
          for update
        end
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      while @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          select @dQtyIn=@dQuantity+@dQtyIn
          if @dQtyIn<=0/*本批次全部出库*/
          begin
            select @dCostTotaltemp=@dCostTotaltemp+@dCostTotal
            select @dtaxtotaltemp=@dtaxtotaltemp+@dtaxtotal
            if @nStoreType=0
            begin
              delete from storehouse where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedx where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrow where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @dQtyIn<>0 /*本批次数量不够，循环用下一批次出库*/
            begin
              fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate
              continue
            end else if @dQtyIn=0/*出库完毕，返回成本金额*/
            begin
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@dtaxtotaltemp
              goto Success
            end
          end else
          begin
            select @dCostTotaltemp=@dCostTotaltemp+(@dQuantity-@dQtyIn)*@dCostprice
            select @dCostTotalout=@dCostTotaltemp
            select @dtaxtotaltemp=@dtaxtotaltemp+(@dQuantity-@dQtyIn)*@dtaxprice
            select @dTaxTotalOut=@dtaxtotaltemp
            if @nStoreType=0
            begin
              update storehouse set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedx set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrow set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@dtaxtotaltemp
            goto Success
          end
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	       if @dCostTotalIn=0 
		   begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end 
	            else goto InputCostPriceError
	          end 
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		   end 
		   else
		     select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		 /*----取含税单价和含税金额*/
		 /*取成本价*/
	    /*   if @taxtotal=0 
		   begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end 
	            else goto InputCostPriceError
	          end 
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		   end 
		   else
		     select @taxprice=@taxtotal/@dQtyIn*/
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0

          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn/*如果批号和成本价相同则合并*/
          begin
            select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
            select @dtaxtotaltemp =@dtaxtotal +@taxtotal
            select @dQtytemp=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouse set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedx set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrow set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
          else                                                  /*如果批号和成本价不相同则不合并*/
          begin
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut=@taxtotal
            if @nStoreType=0
            begin
              INSERT INTO storehouse
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
              costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,
              @taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedx
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrow
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
      end 
			if @@fetch_status<>0/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          goto error/*后进先出法不允许负库存*/
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceError
	          end 
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		  end 
		  else
		     select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		  /*---取含税单价和含税金额*/
		   /*--取成本价
	        if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceError
	          end 
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		  end 
		  else
		     select @taxprice=@taxtotal/@dQtyIn*/
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nStoreType=0
          begin
            INSERT INTO storehouse
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,Factoryid,
            costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,
            @taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            INSERT INTO storedx
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            INSERT INTO storebrrow
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@makedate,@validdate=@validdate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut=@taxtotal
          goto Success
        end
      end
    end
    if @nCostType=@SINGLE/*个别记价法*/
    begin
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
			declare curP cursor scroll for 
			select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
			where p_id=@nP_Id and s_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id 
			and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn 
			and validdate=@validdate and makedate=@makedate and Y_ID = @nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid   and taxrate=@taxrate and abs(costtaxprice-@taxprice)<=@dDoubleZero
			order by inorder desc
			for update
        end 
        else    /*入库*/
        begin
          /*取成本价*/
	          if @dCostTotalIn=0 
		      begin
				  if @dCostPriceIn=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dCostpriceIn=0 goto InputCostPriceerrorSingle
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
					end else goto InputCostPriceerrorSingle
				  end 
				  else
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
			  end 
		      else
		        select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		    /*-取含税单价和含税金额*/
              if @taxtotal=0 
		      begin
				  if @taxprice=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @taxprice=0 goto InputCostPriceerrorSingle
					  select @taxtotal=@taxprice*@dQtyIn
					end else goto InputCostPriceerrorSingle
				  end 
				  else
					  select @taxtotal=@taxprice*@dQtyIn
			  end 
		      else
		      begin
		        if @nBillType=50
		        begin
		          select @taxprice=@taxprice
		        end
		        else
		        begin
		          select @taxprice=@taxtotal/@dQtyIn
		        end
		      end
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouse
          where p_id=@nP_Id and s_id=@nS_id and  abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and  supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn
          and validdate=@validdate and makedate=@makedate and Y_ID = @nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid and taxrate=@taxrate and  abs(costtaxprice-@taxprice)<=@dDoubleZero    and (quantity>0 or  @nBillType in (50,41,42)) /*盘点单可以把负库存盘溢为0*/
          order by inorder desc
          for update
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal   from storedx
          where p_id=@nP_Id and c_id=@nS_id and  abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and			  supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn
          and validdate=@validdate and makedate=@makedate and oldcommissionflag=@oldcommissionflag and Y_ID = @nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid and taxrate=@taxrate and  abs(costtaxprice-@taxprice)<=@dDoubleZero/*2005-07-16 zc修改*/
          order by inorder desc
          for update
        end 
        else    /*入库*/
        begin
          /*取成本价*/
	          if @dCostTotalIn=0 
		      begin
				  if @dCostPriceIn=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dCostpriceIn=0 goto InputCostPriceerrorSingle
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
					end else goto InputCostPriceerrorSingle
				  end 
				  else
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		      end 
		      else
			      select @dCostPriceIn=@dCostTotalIn/@dQtyIn
			/*取含税单价和含税金额*/
			 if @taxtotal=0 
		      begin
				  if @taxprice=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @taxprice=0 goto InputCostPriceerrorSingle
					  select @taxtotal=@taxprice*@dQtyIn
					end else goto InputCostPriceerrorSingle
				  end 
				  else
					  select @taxtotal=@taxprice*@dQtyIn
		      end 
		      else
			      select @taxprice=@taxtotal/@dQtyIn

          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedx
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn
          and validdate=@validdate and makedate=@makedate and oldcommissionflag=@oldcommissionflag and Y_ID = @nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid and taxrate=@taxrate and  abs(costtaxprice-@taxprice)<=@dDoubleZero /*2005-07-16 zc修改*/
          order by inorder desc
          for update
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn
          and validdate=@validdate and makedate=@makedate and oldcommissionflag=@oldcommissionflag and Y_ID =@nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid  and taxrate=@taxrate and  abs(costtaxprice-@taxprice)<=@dDoubleZero /*2005-07-16 zc修改*/
          order by inorder desc
          for update
        end else    /*入库*/
        begin
          /*取成本价*/
	       if @dCostTotalIn=0 
		   begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerrorSingle
	                select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceerrorSingle
	          end
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		    end 
		    else
				  select @dCostPriceIn=@dCostTotalIn/@dQtyIn
	    /*--取含税单价和含税金额*/
	    /*取成本价*/
	       if @taxtotal=0 
		   begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerrorSingle
	                select @taxtotal=@taxprice*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceerrorSingle
	          end
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		    end 
		    else
				  select @taxprice=@taxtotal/@dQtyIn

          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrow
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn
          and validdate=@validdate and makedate=@makedate and oldcommissionflag=@oldcommissionflag and Y_ID = @nY_ID and Instoretime=@tInstoretime and factoryid=@factoryid  and taxrate=@taxrate and  abs(costtaxprice-@taxprice)<=@dDoubleZero
          order by inorder desc
          for update
        end
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      if @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
   /*       if @dQuantity < abs(@dQtyIn) and @nY_ID <> '2' and @szY_ID = '2'  --在总部上传的单据在同批次库存不足的情况可以按先进先出的过账*/
  	/*	  begin*/
		 /*   set @nCostType = '4'*/
			/*goto NegRetailOut*/
		 /* end*/
		  if @dQuantity < abs(@dQtyIn) /*and (@nY_ID = '2' or @szY_ID <> '2')*/ goto error

          if @dQuantity=abs(@dQtyIn)/*本批次全部出库*/
          begin
            if @nStoreType=0
            begin
              delete from storehouse where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedx where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrow where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotal,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@dtaxtotal
            goto Success
          end 
          else
          begin
            select @dCostTotal=@dCostTotal+@dQtyIn*@dCostprice
            select @dtaxtotal =@dtaxtotal+@dQtyIn*@dtaxprice
            select @dQuantity=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouse set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedx set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrow set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=abs(@dCostPrice*@dQtyIn),@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag ,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=ABS(@dtaxprice*@dQtyIn)
/*            select @dCostTotalOut=@dCostPrice*@dQtyIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag 2004-07-19曾川改负库存问题*/
            goto Success
          end
        end else     /*入库*/
        begin
          /*取成本价*/
/*          if @dCostTotalIn<>0 
						select @dCostPriceIn=@dCostTotalIn/@dQtyIn
					else 
						select @dCostTotalIn=@dCostPriceIn*@dQtyIn
*/
          select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
          select @dtaxtotaltemp =@dtaxtotal +@taxtotal
          select @dQtytemp=@dQuantity+@dQtyIn
          if @nStoreType=0
          begin
            update storehouse set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            update storedx set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            update storebrrow set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut=@taxtotal
          goto Success
        end
      end else/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
	      if @nY_ID <> '2' and @nBillType in (12,161,163,50) and @szY_ID = '2'  /*在总部上传的单据在同批次库存不足的情况可以按先进先出的过账*/
	      begin
		    set @nCostType = '4'
			goto NegRetailOut
		  end else
		   goto error /*个别计价法不允许负库存*/
        end else     /*入库*/
        begin
          if @nStoreType=0
          begin
            select @nInorder=isnull(max(inorder),0) from storehouse where p_id=@nP_id and s_id=@nS_Id and Y_ID = @nY_ID
            INSERT INTO storehouse
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,YhDate ,validdate,commissionflag,stopsaleflag,inorder,Y_ID,batchbarcode,scomment ,batchprice ,Factoryid,
            costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@tYhDate ,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@batchbarcode ,@scomment,@batchprice,@factoryid,
            @taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            select @nInorder=isnull(max(inorder),0) from storedx where p_id=@nP_id and c_id=@nS_Id and Y_ID = @nY_ID
            INSERT INTO storedx
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,oldcommissionflag,Y_ID,batchbarcode ,scomment,batchprice,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@OldCommissionflag,@nY_ID,@batchbarcode ,@scomment,@batchprice,@factoryid,@taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            select @nInorder=isnull(max(inorder),0) from storebrrow where p_id=@nP_id and c_id=@nS_Id and Y_ID= @nY_ID
            INSERT INTO storebrrow
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal,@taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn/*,@makedate=@tmakedate,@validdate=@tvaliddate*/
          select @dTaxTotalOut=@taxtotal
          goto Success
        end
      end
    end
  end
  else/*修改期初*/
  begin
    if	@nBillType<>141 
    begin
	    /*判断是否开帐*/
	    declare @cOpenAccount int
            select @cOpenAccount=openaccount from Companybalance where Y_id=@nY_id and c_id=0
			if @cOpenAccount='1' goto ErrorAccountOpen
    end
    if @nCostType=@MOVEAVERAGE/*移动加权平均法*/
    begin
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid ,taxrate,costtaxprice,costtaxtotal from storehouseini
        where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
        for update
      end
      if @nStoreType=1
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid ,taxrate,costtaxprice,costtaxtotal from storedxini
        where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
        for update
      end
      if @nStoreType=2
      begin
        declare curP cursor scroll for 
        select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
        where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID
        for update
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      if @@fetch_status=0/*有库存*/
      begin

         if @dQtyin<0
         begin
              /*取成本价*/
            if @dCostTotalIn=0 
    	    begin
				  if @dCostPrice=0
				  begin
					if @cRecpriceAsCost='1' and @dCostPricein=0 /*使用最近进价作为成本价*/
					begin
					  select @dCostprice=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dCostprice=0 
    					begin
    						select @dCostprice=@dCostpriceIn
    						if @dCostprice=0 goto InputCostPriceerror
                  		select @dCostTotalIn=@dCostPrice*@dQtyIn
    					end else
                  		select @dCostTotalIn=@dCostPrice*@dQtyIn
					end else 
    				  begin
    					  select @dCostprice=@dCostpriceIn
					  if @dCostprice=0 goto InputCostPriceerror
					  select @dCostTotalIn=@dCostPrice*@dQtyIn
    				  end
				  end 
				  else
				  begin
				   select @dCostTotalIn=@dCostPrice*@dQtyIn
				   select @dCostPriceIn=@dCostPrice
				  end
    	     end 
    	      else
    	        select @dCostPrice=@dCostTotalIn/@dQtyIn
    	    /*-含税单价和含税金额*/
    	     /*取成本价*/
            if @taxtotal=0 
    	    begin
				  if @dtaxprice=0
				  begin
					if @cRecpriceAsCost='1' and @taxprice=0 /*使用最近进价作为成本价*/
					begin
					  select @dtaxprice=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dtaxprice=0 
    					begin
    						select @dtaxprice=@taxprice
    						if @dtaxprice=0 goto InputCostPriceerror
                  		select @taxtotal=@dtaxprice*@dQtyIn
    					end else
                  		select @taxtotal=@dtaxprice*@dQtyIn
					end else 
    				  begin
    					  select @dtaxprice=@taxprice
					  if @dtaxprice=0 goto InputCostPriceerror
					  select @taxtotal=@dtaxprice*@dQtyIn
    				  end
				  end 
				  else
				  begin
				   select @taxtotal=@dtaxprice*@dQtyIn
				   select @taxprice=@dtaxprice
				  end
    	     end 
    	      else
    	        select @dtaxprice=@taxtotal/@dQtyIn
         end 
         else
         begin
	          if @dCostTotalIn=0 
		      begin
				  if @dCostPriceIn<=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @dCostpriceIn=0 goto InputCostPriceerror
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
					end else goto InputCostPriceerror
				  end 
				  else
					  select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		      end 
		      else
		        select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		      /*-含税单价和含税金额*/
		      if @taxtotal=0 
		      begin
				  if @taxprice<=0
				  begin
					if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
					begin
					  select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
					  if @taxprice=0 goto InputCostPriceerror
					  select @taxtotal=@taxprice*@dQtyIn
					end else goto InputCostPriceerror
				  end 
				  else
					  select @taxtotal=@taxprice*@dQtyIn
		      end 
		      else
		        select @taxprice=@taxtotal/@dQtyIn
         end
        if @dQtyIn<0 /*有库存出库--*/
        begin
          if @dQuantity<abs(@dQtyIn)
          begin
            if @cNegativeStock='0' goto Error/*系统不允许负库存*/
            else
            begin/*负库存出库*/
              select @dQuantity=@dQuantity+@dQtyIn
              select @dCosttotal=@dCosttotal+@dCosttotalIn
              select @dtaxtotal =@dtaxtotal+@taxtotal
              if @nStoreType=0
              begin
                update storehouseini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                         costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedxini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                      costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrowini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                         costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
                where current of curP
                if @@rowcount=0 Goto syserror
              end
/*              select @dCostTotalOut=abs(@dCosttotalIn)--返回成本总金额 2004-07-19曾川改负库存问题*/
              select @dCostTotalOut=@dCosttotalIn/*返回成本总金额*/
              select @dTaxTotalOut=@taxtotal
              goto Success
            end
          end
          if @dQuantity=abs(@dQtyIn)
          begin
              select @dCosttotal=@dCosttotal+@dCostTotalIn
              select @dtaxtotal =@dtaxtotal +@taxtotal
              select @dQuantity=@dQuantity+@dQtyIn
/*              select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19曾川改负库存问题*/
              select @dCostTotalOut=@dCostTotalIn/* 2004-07-19曾川改负库存问题*/
              select @dTaxTotalOut=@taxtotal
	      		     
            if @dCostTotal=0
            begin
              if @nStoreType=0
              begin
                delete from storehouseini where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                delete from storedxini where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                delete from storebrrowini where current of curP
                if @@rowcount=0 Goto syserror
              end
/*              select @dCostTotalOut=@dCosttotal*/
            end else
	    begin
              if @nStoreType=0
              begin
                update storehouseini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
              if @nStoreType=1
              begin
                update storedxini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
              if @nStoreType=2
              begin
                update storebrrowini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=0,costtaxtotal=@dtaxtotal,costtaxprice=0
                where current of curP
                if @@rowcount=0 Goto SysError
              end
	    end
            goto Success
          end
          else
          begin
            select @dCosttotal=@dCosttotal+@dCosttotalIn
            select @dtaxtotal =@dtaxtotal +@taxtotal
            select @dQuantity=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouseini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                       costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedxini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                       costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrowini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCosttotal/@dQuantity,
                                       costtaxtotal=@dtaxtotal,costtaxprice=@dtaxtotal/@dQuantity
              where current of curP
              if @@rowcount=0 Goto syserror
            end
/*            select @dCostTotalOut=abs(@dQtyIn*@dCostprice)  2004-07-19曾川改负库存问题*/
            select @dCostTotalOut=@dQtyIn*@dCostprice 
            select @dTaxTotalOut=@dQtyIn*@dtaxprice
            goto Success
          end
        end 
        else/*有库存入库--*/
        begin
          select @dCosttotal=@dCosttotal+@dCostTotalIn
          select @dtaxtotal=@dtaxtotal+@taxtotal
          select @dQuantity=@dQuantity+@dQtyIn
          if @dQuantity<>0
          begin
            select @dCostprice=@dCosttotal/@dQuantity
            select @dtaxprice=@dtaxtotal/@dQuantity
          end
          else
          begin
            select @dCostprice=0
            select @dtaxprice=0
          end
          if @nStoreType=0
          begin
            update storehouseini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                                     costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            update storedxini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                                  costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            update storebrrowini set costtotal=@dCosttotal,quantity=@dQuantity,costprice=@dCostprice,
                                     costtaxtotal=@dtaxtotal,costtaxprice=@dtaxprice
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn
          select @dTaxTotalOut=@taxtotal
          goto Success
        end
      end else
      begin
        if @dQtyIn<0 /*无库存出库*/
        begin
          if @cNegativeStock=0 goto Error
          else
          begin

          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerror
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerror
	          end 
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		     end 
		     else
		        select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		    /*---取含税单价和含税金额*/
		    if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerror
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerror
	          end 
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		     end 
		     else
		        select @taxprice=@taxtotal/@dQtyIn
            if @nStoreType=0
            begin
              INSERT INTO storehouseini
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedxini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrowini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
/*            select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19曾川改负库存问题*/
            select @dCostTotalOut=@dCostTotalIn 
            select @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
        
          /*取成本价*/
	    if @dCostTotalIn=0 
		begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerror
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerror
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		end 
		else
		  select @dCostPriceIn=@dCostTotalIn/@dQtyIn
        /*取含税单价和含税金额*/
        /*取成本价*/
	    if @taxtotal=0 
		begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerror
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerror
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		end 
		else
		  select @taxprice=@taxtotal/@dQtyIn
        if @nStoreType=0
        begin
          INSERT INTO storehouseini
          (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid, costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
          if @@rowcount=0 Goto syserror
        end
        if @nStoreType=1
        begin
          INSERT INTO storedxini
          (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
          if @@rowcount=0 Goto syserror
        end
        if @nStoreType=2
        begin
          INSERT INTO storebrrowini
          (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
          makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
          VALUES
          (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
          @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
          if @@rowcount=0 Goto syserror
        end
/*        select @dCostTotalOut=abs(@dCostTotalIn) 2004-07-19曾川改负库存问题*/
        select @dCostTotalOut=@dCostTotalIn
        select @dTaxTotalOut=@taxtotal
        goto Success
      end
    end
/*    if @nCostType=@FIFO--先进先出法*/
    if @nCostType in (@FIFO,@VALID_DATE)
    begin
      if @nStoreType=0
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storehouseini where p_id=@nP_id and s_id=@nS_id and Y_ID = @nY_ID
      end
      if @nStoreType=1
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storedxini where p_id=@nP_id and c_id=@nS_id and Y_ID = @nY_ID
      end
      if @nStoreType=2
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storebrrowini where p_id=@nP_id and c_id=@nS_id and Y_ID =@nY_ID 
      end
      if (@dQtytemp+@dQtyIn)<0 /*出现负库存*/
      begin
        select @ReturnNumber=-1
        return -1
      end
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
	          select @dPricetemp=abs(@dCostTotalIn/@dQtyIn)
	         if @taxtotal<>0 
	         begin
	          select @dtPricetemp=abs(@taxtotal/@dQtyIn)
	         end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
            where p_id=@nP_Id and s_id=@nS_id and costprice=@dPricetemp and Y_ID =@nY_ID and costtaxprice=@dtpricetemp
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
            where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
          where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
	        select @dPricetemp=abs(@dCostTotalIn/@dQtyIn)
	        if @taxtotal<>0 
	        begin
	          select @dtPricetemp=abs(@taxtotal/@dQtyIn)
	        end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID and costtaxprice=@dtpricetemp
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
	        select @dPricetemp=abs(@dCostTotalIn/@dQtyIn)
	        if @taxtotal<>0 
	        begin
	          select @dtPricetemp=abs(@taxtotal/@dQtyIn)
	        end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID = @nY_ID and costtaxprice=@dtpricetemp
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
          order by inorder desc 
          for update
        end
      end

      open curP

      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      while @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          select @dQtyIn=@dQuantity+@dQtyIn
          if @dQtyIn<=0/*本批次全部出库*/
          begin
            select @dCostTotaltemp=@dCostTotaltemp+@dCostTotal
            select @dtaxtotaltemp= @dtaxtotaltemp+@dtaxtotal
            if @nStoreType=0
            begin
              delete from storehouseini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedxini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrowini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @dQtyIn<>0 /*本批次数量不够，循环用下一批次出库*/
            begin
              fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
              continue
            end else if @dQtyIn=0/*出库完毕，返回成本金额*/
            begin
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,@nL_id=@nLocation_id,
                     @dTaxTotalOut=@dtaxtotaltemp
					    goto Success
            end
          end else
          begin
              select @dCostTotaltemp=@dCostTotaltemp+(@dQuantity-@dQtyIn)*@dCostprice
			  select @dCostTotalout=@dCostTotaltemp
			  
			  select @dtaxtotaltemp=@dtaxtotaltemp+(@dQuantity-@dQtyIn)*@dtaxprice
			  select @dTaxTotalOut=@dtaxtotaltemp
              if @nStoreType=0
              begin
                update storehouseini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedxini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrowini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
                where current of curp
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@dtaxtotaltemp
				      goto Success
          end
        end else     /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceError
	          end 
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		   end 
		   else
		    select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		   /*--取含税单价和含税金额*/
		   /*	if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end 
	            else 
	              goto InputCostPriceError
	          end 
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		   end 
		   else
		    select @taxprice=@taxtotal/@dQtyIn*/
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror

              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nBillType=43 	/*调价单要比较最先入库的单价和批号是否和调价入库的批号和成本价*/
          begin
            fetch last from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchnoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
            if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn/*如果批号和成本价相同则合并*/
            begin
              select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
              select @dtaxtotaltemp =@dtaxtotal+@taxtotal
              select @dQtytemp=@dQuantity+@dQtyIn
              if @nStoreType=0
              begin
                update storehouseini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                update storedxini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                update storebrrowini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
                where current of curP
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@taxtotal
              goto Success
            end else                                                  /*如果批号和成本价不相同则不合并*/
            begin
              select @dCostTotalOut=@dCostTotalIn
              select @dTaxTotalOut =@taxtotal
              if @nStoreType=0
              begin
                INSERT INTO storehouseini
                (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=1
              begin
                INSERT INTO storedxini
                (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
                if @@rowcount=0 Goto syserror
              end
              if @nStoreType=2
              begin
                INSERT INTO storebrrowini
                (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
                makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
                VALUES
                (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
                @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder-1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
                if @@rowcount=0 Goto syserror
              end
              select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@taxtotal
              goto Success
            end
          end

          if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn/*如果批号和成本价相同则合并*/
          begin
            select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
            select @dtaxtotaltemp =@dtaxtotal +@taxtotal
            select @dQtytemp=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouseini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedxini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrowini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end else                                                  /*如果批号和成本价不相同则不合并*/
          begin
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut =@taxtotal
            if @nStoreType=0
            begin
              INSERT INTO storehouseini
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@tValiddate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedxini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrowini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
      end
      if @@fetch_status<>0/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          goto error/*先进先出法不允许负库存*/
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		   end 
		   else
		     select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		  /*------取含税单价和含税金额*/
		     /*取成本价*/
	       /* if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		   end 
		   else
		     select @taxprice=@taxtotal/@dQtyIn*/
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nStoreType=0
          begin
            INSERT INTO storehouseini
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            INSERT INTO storedxini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            INSERT INTO storebrrowini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal,taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut=@taxtotal
          goto Success
        end
      end
    end
    if @nCostType=@LIFO/*后进先出法*/
    begin
      if @nStoreType=0
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storehouseini where p_id=@nP_id and s_id=@nS_id and Y_ID =@nY_ID
      end
      if @nStoreType=1
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storedxini where p_id=@nP_id and c_id=@nS_id  and Y_ID =@nY_ID
      end
      if @nStoreType=2
      begin
  			select @dQtytemp=isnull(sum(quantity),0) from storebrrowini where p_id=@nP_id and c_id=@nS_id and Y_ID =@nY_ID
      end
      if (@dQtytemp+@dQtyIn)<0 /*出现负库存*/
      begin
        select @ReturnNumber=-1
        return -1
      end
      /*根据不同的入出库类型定义游标*/
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			 select @dPricetemp=@dCostTotalIn/@dQtyIn
			 if @taxtotal<>0
			 begin			
			    select @dtPricetemp=@taxtotal/@dQtyIn
			 end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
            where p_id=@nP_Id and s_id=@nS_id and costprice=@dPricetemp and Y_ID =@nY_ID  and costtaxprice=@dtpricetemp
            order by inorder desc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
            where p_id=@nP_Id and s_id=@nS_id and Y_ID =@nY_ID
            order by inorder desc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal from storehouseini
          where p_id=@nP_Id and s_id=@nS_id  and Y_ID =@nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			   select @dPricetemp=@dCostTotalIn/@dQtyIn
			 if @taxtotal<>0
			 begin	
			   select @dtPricetemp=@taxtotal/@dQtyIn
			 end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn  and Y_ID =@nY_ID and costtaxprice=@dtpricetemp
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
          order by inorder desc
          for update
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          if @dCostTotalIn<>0
          begin
			  select @dPricetemp=@dCostTotalIn/@dQtyIn
			  if @taxtotal<>0
			  begin	
			    select @dtPricetemp=@taxtotal/@dQtyIn
			  end
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
            where p_id=@nP_Id and c_id=@nS_id and costprice=@dPricetemp and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID and costtaxprice=@dtpricetemp
            order by inorder asc
            for update
          end else
          begin
            declare curP cursor scroll for 
            select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
            where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
            order by inorder asc
            for update
          end
        end else    /*入库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
          where p_id=@nP_Id and c_id=@nS_id and commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID
          order by inorder desc
          for update
        end
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      while @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          select @dQtyIn=@dQuantity+@dQtyIn
          if @dQtyIn<=0/*本批次全部出库*/
          begin
            select @dCostTotaltemp=@dCostTotaltemp+@dCostTotal
            select @dtaxtotaltemp= @dtaxtotaltemp+@dtaxtotal
            if @nStoreType=0
            begin
              delete from storehouseini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedxini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrowini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @dQtyIn<>0 /*本批次数量不够，循环用下一批次出库*/
            begin
              fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
              continue
            end else if @dQtyIn=0/*出库完毕，返回成本金额*/
            begin
              select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                     @dTaxTotalOut=@dtaxtotaltemp
              goto Success
            end
          end else
          begin
            select @dCostTotaltemp=@dCostTotaltemp+(@dQuantity-@dQtyIn)*@dCostprice
            select @dCostTotalout=@dCostTotaltemp
            
            select @dtaxtotaltemp=@dtaxtotaltemp+(@dQuantity-@dQtyIn)*@dtaxprice
            select @dTaxTotalOut=@dtaxtotaltemp
            if @nStoreType=0
            begin
              update storehouseini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedxini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrowini set quantity=@dQtyIn,costtotal=@dQtyIn*@dCostPrice,costtaxtotal=@dQtyIn*@dtaxprice
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotaltemp,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@dtaxtotaltemp
            goto Success
          end
        end 
        else     /*入库*/
        begin
          /*取成本价*/
	    if @dCostTotalIn=0 
		begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		end else
		  select @dCostPriceIn=@dCostTotalIn/@dQtyIn
        /*取含税单价和含税金额*/
        /*if @taxtotal=0 
		begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceError
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		end 
		else
		  select @taxprice=@taxtotal/@dQtyIn*/
          /*取成本价*/
/*
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @szBatchnoTemp=@szBatchNo and @dCostprice=@dCostPriceIn/*如果批号和成本价相同则合并*/
          begin
            select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
            select @dtaxtotaltemp =@dtaxtotal+@taxtotal
            select @dQtytemp=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouseini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedxini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrowini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
              where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end else                                                  /*如果批号和成本价不相同则不合并*/
          begin
            select @dCostTotalOut=@dCostTotalIn
            select @dTaxTotalOut =@taxtotal
            if @nStoreType=0
            begin
              INSERT INTO storehouseini
              (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              INSERT INTO storedxini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              INSERT INTO storebrrowini
              (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
              makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
              VALUES
              (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
              @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@taxtotal
            goto Success
          end
        end
      end 
			if @@fetch_status<>0/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          goto error/*后进先出法不允许负库存*/
        end
        else     /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceError
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end
	             else goto InputCostPriceError
	          end
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		    end 
		    else
		     select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		   /*-取含税单价和含税金额*/
		  /* if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' --使用最近进价作为成本价
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceError
	              select @taxtotal=@taxprice*@dQtyIn
	            end
	             else goto InputCostPriceError
	          end
	          else
	              select @taxtotal=@taxprice*@dQtyIn
		    end 
		    else
		     select @taxprice=@taxtotal/@dQtyIn*/
/*          --取成本价
          if @dCostTotalIn<>0 select @dCostPriceIn=@dCostTotalIn/@dQtyIn
          if @dCostPriceIn=0
          begin
            if @cRecpriceAsCost='1' --使用最近进价作为成本价
            begin
              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
              if @dCostpriceIn=0 goto InputCostPriceerror
              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
            end else goto InputCostPriceerror
          end
*/
          if @nStoreType=0
          begin
            INSERT INTO storehouseini
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            INSERT INTO storedxini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            INSERT INTO storebrrowini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,0,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflagin,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut =@taxtotal
          goto Success
        end
      end
    end
    if @nCostType=@SINGLE/*个别记价法*/
    begin
      if @nStoreType=0
      begin
        if @dQtyIn<0/*出库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder, instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
          where p_id=@nP_Id and s_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn and instoretime =@tinstoretime and Y_ID =@nY_ID and factoryid=@factoryid
          order by inorder desc
          for update
        end 
        else    /*入库*/
        begin
          /*取成本价*/
	         if @dCostTotalIn=0 
		      begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerrorSingle
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
		      end else
		        select @dCostPriceIn=@dCostTotalIn/@dQtyIn
		    /*取含税单价和含税金额*/
		     if @taxtotal=0 
		      begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerrorSingle
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end else
	              select @taxtotal=@taxprice*@dQtyIn
		      end else
		        select @taxprice=@taxtotal/@dQtyIn
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storehouseini
          where p_id=@nP_Id and s_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn and 
                instoretime = @tinstoretime and Y_ID =@nY_ID and factoryid=@factoryid 
          order by inorder desc
          for update
        end
      end
      if @nStoreType=1
      begin
        if @dQtyIn<0/*出库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and 
                commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID and factoryid=@factoryid 
          order by inorder desc
          for update
        end else    /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
		    begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerrorSingle
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end 
	          else
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
			 end 
			 else
				  select @dCostPriceIn=@dCostTotalIn/@dQtyIn
			/*-取含税单价和含税金额*/
			if @taxtotal=0 
		    begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerrorSingle
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end 
	          else
	              select @taxtotal=@taxprice*@dQtyIn
			 end 
			 else
				  select @taxprice=@taxtotal/@dQtyIn			

          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storedxini
          where p_id=@nP_Id and c_id=@nS_id and costprice=@dCostPriceIn and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and
                commissionflag=@nCommissionFlagIn and Y_ID =@nY_ID and factoryid=@factoryid 
          order by inorder desc
          for update
        end
      end
      if @nStoreType=2
      begin
        if @dQtyIn<0/*出库*/
        begin
          declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn 
               and Y_ID =@nY_ID and factoryid=@factoryid 
          order by inorder desc
          for update
        end 
        else    /*入库*/
        begin
          /*取成本价*/
	        if @dCostTotalIn=0 
			begin
	          if @dCostPriceIn=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @dCostpriceIn=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @dCostpriceIn=0 goto InputCostPriceerrorSingle
	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end else

	              select @dCostTotalIn=@dCostPriceIn*@dQtyIn
			end 
			else
				select @dCostPriceIn=@dCostTotalIn/@dQtyIn
           /*取含税单价和含税金额*/
            if @taxtotal=0 
			begin
	          if @taxprice=0
	          begin
	            if @cRecpriceAsCost='1' /*使用最近进价作为成本价*/
	            begin
	              select @taxprice=dbo.GetRecprice(@nP_id,@nPriceid)
	              if @taxprice=0 goto InputCostPriceerrorSingle
	              select @taxtotal=@taxprice*@dQtyIn
	            end else goto InputCostPriceerrorSingle
	          end else

	              select @taxtotal=@taxprice*@dQtyIn
			end 
			else
				select @taxprice=@taxtotal/@dQtyIn
        declare curP cursor scroll for 
          select location_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,commissionflag,inorder,Instoretime,factoryid,taxrate,costtaxprice,costtaxtotal  from storebrrowini
          where p_id=@nP_Id and c_id=@nS_id and abs(costprice-@dCostPriceIn)<=@dDoubleZero and batchno=@szBatchNo and Location_id=@nL_id and supplier_id=@nSupplier_idIn and commissionflag=@nCommissionFlagIn and
                Y_ID =@nY_ID and factoryid=@factoryid 
          order by inorder desc
          for update
        end
      end

      open curP
      fetch next from curP into @nLocation_id,@nSupplier_id,@dQuantity,@dCostprice,@dCosttotal,@szBatchNoTemp,@tMakedate,@tValiddate,@nCommissionflag,@nInorder,@tmpInstoretime,@nfactoryid,@ntaxrate,@dtaxprice,@dtaxtotal
      if @@fetch_status=0/*有库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          if @dQuantity<abs(@dQtyIn) goto error
          if @dQuantity=abs(@dQtyIn)/*本批次全部出库*/
          begin
            if @nStoreType=0
            begin
              delete from storehouseini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              delete from storedxini where current of curP
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              delete from storebrrowini where current of curP
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=@dCostTotal,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut=@dtaxtotal
            goto Success
          end else
          begin
            select @dCostTotal=@dCostTotal+@dQtyIn*@dCostprice
            select @dtaxtotal =@dtaxtotal+@dQtyIn*@dtaxprice
            select @dQuantity=@dQuantity+@dQtyIn
            if @nStoreType=0
            begin
              update storehouseini set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=1
            begin
              update storedxini set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            if @nStoreType=2
            begin
              update storebrrowini set quantity=@dQuantity,costtotal=@dCostTotal,costtaxtotal=@dtaxtotal
              where current of curp
              if @@rowcount=0 Goto syserror
            end
            select @dCostTotalOut=abs(@dCostPrice*@dQtyIn),@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                   @dTaxTotalOut =ABS(@dtaxprice*@dQtyIn) 
/*            select @dCostTotalOut=@dCostPrice*@dQtyIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag 2004-07-19 曾川改负库存问题*/
            goto Success
          end
        end else     /*入库*/
        begin
          /*取成本价*/
/*          if @dCostTotalIn<>0 
						select @dCostPriceIn=@dCostTotalIn/@dQtyIn
					else 
						select @dCostTotalIn=@dCostPriceIn*@dQtyIn
*/
          select @dCostTotaltemp=@dCostTotal+@dCostTotalIn
          select @dtaxtotaltemp=@dtaxtotal+@taxtotal
          select @dQtytemp=@dQuantity+@dQtyIn
          if @nStoreType=0
          begin
            update storehouseini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            update storedxini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            update storebrrowini set quantity=@dQtytemp,costtotal=@dCostTotaltemp,costtaxtotal=@dtaxtotaltemp
            where current of curP
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn,@makedate=@tmakedate,@validdate=@tvaliddate,@nCommissionflagin=@nCommissionflag,@tInstoretime=@tmpInstoretime,
                 @dTaxTotalOut=@taxtotal
          goto Success
        end
      end else/*无库存*/
      begin
        if @dQtyIn<0 /*出库*/
        begin
          goto error/*后进先出法不允许负库存*/
        end else     /*入库*/
        begin
          if @nStoreType=0
          begin
            select @nInorder=isnull(max(inorder),0) from storehouseini where p_id=@nP_id and s_id=@nS_Id
            INSERT INTO storehouseini
            (location_id,s_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID, scomment, batchprice, BatchBarCode,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID, @scomment, @batchprice, @batchbarcode,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=1
          begin
            select @nInorder=isnull(max(inorder),0) from storedxini where p_id=@nP_id and c_id=@nS_Id and Y_ID =@nY_ID
            INSERT INTO storedxini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          if @nStoreType=2
          begin
            select @nInorder=isnull(max(inorder),0) from storebrrowini where p_id=@nP_id and c_id=@nS_Id and Y_ID=@nY_ID
            INSERT INTO storebrrowini
            (location_id,c_id,p_id,supplier_id,quantity,costprice,costtotal,batchno,
            makedate,instoretime,validdate,commissionflag,stopsaleflag,inorder,Y_ID,factoryid,costtaxprice,costtaxtotal, taxrate)
            VALUES
            (@nL_id,@nS_id,@nP_id,@nSupplier_idIn,@dQtyIn,@dCostPricein,@dCosttotalIn,@szBatchno,
            @MakeDate,@tInstoretime,@Validdate,@nCommissionflagIn,@nStopsaleflag,@nInorder+1,@nY_ID,@factoryid,@taxprice,@taxtotal, @taxrate)
            if @@rowcount=0 Goto syserror
          end
          select @dCostTotalOut=@dCostTotalIn/*,@makedate=@tmakedate,@validdate=@tvaliddate*/
          select @dTaxTotalOut=@taxtotal
          goto Success
        end
      end
    end

  end

Success:
  close curp
  deallocate curP
  set @ReturnNumber=0
	return 0

Error:
  close curp
	deallocate curP
  set @ReturnNumber=-1
	return -1

InputCostPriceError:
  close curp
	deallocate curP
  set @ReturnNumber=-5
	return -5

InputCostPriceerrorSingle:
  set @ReturnNumber=-5
	return -5

SysError:
  close curp
	deallocate curP
  set @ReturnNumber=-6
	return -6

ErrorAccountOpen:
  set @ReturnNumber=-7
	return -7
GO
