
CREATE PROCEDURE Ts_T_InsFLcondition(
    @Cid         INT,
    @Pid         INT,
    @quantity    INT,
    @price       NUMERIC(25,8),
    @BuyTotal    NUMERIC(25,8),
    @BackTotal   NUMERIC(25,8),
    @Month       VARCHAR(20),
    @BeginTime   DATETIME,
    @EndTime     DATETIME,
    @FLModulus   NUMERIC(25,8),
    @FLrelation  VARCHAR(6),
    @Formula     VARCHAR(80),
    @Fljsmode    SMALLINT,
    @intendTime  DATETIME,
    @alarmTime   INT,
    @nid         INT,
    @nRR_id      INT, /*协议id*/
    @SaleQty     INT
)
AS
	DECLARE @Fcid         INT,
	        @flmoney      NUMERIC(25,8),
	        @condition    VARCHAR(500),
	        @nPid         INT,
	        @TQalarmTime  DATETIME,
	        @classid      VARCHAR(30),
	        @GuessTotal   NUMERIC(25,8)
	
	SET @GuessTotal = 0.00
	SET @TQalarmTime = DATEADD(DAY, -@alarmTime, @EndTime)
	SET @Fcid = 0 
	SET @flmoney = 0.00 
	SET @condition = ''
	SET @classid = '' 
	IF @Fljsmode = 4
	BEGIN
	    SET @flmoney = @BuyTotal * @FLModulus
	    SET @GuessTotal = @BuyTotal * @FLModulus
	END
	ELSE 
	IF @Fljsmode = 3
	BEGIN
	    SET @flmoney = @BackTotal * @FLModulus
	    SET @GuessTotal = @BackTotal * @FLModulus
	END
	ELSE
	BEGIN
	    SET @flmoney = 0.00
	    SET @GuessTotal = 0.00
	    IF @Fljsmode = 2
	        SET @GuessTotal = @BuyTotal * @FLModulus
	    ELSE
	    IF @Fljsmode = 6
			SET @GuessTotal = @quantity * @FLModulus
		ELSE
		IF @Fljsmode = 5
			SET @GuessTotal = @BackTotal * @FLModulus
	END 
	
	IF SUBSTRING(@FLrelation, 1, 1) = '1'
	    SET @condition = @condition + ' 采购数量≥' + CAST(@quantity AS VARCHAR(10))
	
	IF SUBSTRING(@FLrelation, 2, 1) = '1'
	    SET @condition = @condition + ' 采购价≥' + CAST(@price AS VARCHAR(10))
	
	IF SUBSTRING(@FLrelation, 3, 1) = '1'
	    SET @condition = @condition + ' 采购金额≥' + CAST(@BuyTotal AS VARCHAR(10))
	
	IF SUBSTRING(@FLrelation, 4, 1) = '1'
	    SET @condition = @condition + ' 回款金额≥' + CAST(@BackTotal AS VARCHAR(10))
	
	IF SUBSTRING(@FLrelation, 5, 1) = '1'
	    SET @condition = @condition + ' 采购月份在' + @month
	
	IF @FLrelation = '00000'
	    SET @condition = @condition + ' 协议期间内，有采购即返利' 
	    
	IF SUBSTRING(@FLrelation, 6, 1) = '1'
	    SET @condition = @condition + ' 销售数量≥' + CAST(@SaleQty AS VARCHAR(10))    
	
	IF @nid = 0
	BEGIN
	    INSERT INTO FLCondition
	      (
	        [RP_id],
	        [c_id],
	        [P_id],
	        [quantity],
	        [price],
	        [BuyTotal],
	        [BackTotal],
	        [Month],
	        [BeginTime],
	        [EndTime],
	        [intendTime],
	        [alarmTime],
	        [FLModulus],
	        [FLStates],
	        [Flrelation],
	        [Formula],
	        [Flmoney],
	        [fljsmode],
	        [FlSjQty],
	        [FlSJBuyTotal],
	        [FlSJBackTotal],
	        [flCondition],
	        [GuessTotal],
	        [SaleQty]
	      )
	    VALUES
	      (
	        @nRR_id,
	        @Cid,
	        @Pid,
	        @quantity,
	        @price,
	        @BuyTotal,
	        @BackTotal,
	        @Month,
	        @BeginTime,
	        @EndTime,
	        @intendTime,
	        @TQalarmTime,
	        @FLModulus,
	        0,
	        @FLrelation,
	        @Formula,
	        @Flmoney,
	        @Fljsmode,
	        0,
	        0.00,
	        0.00,
	        @condition,
	        @GuessTotal,
	        @SaleQty
	      ) 
	    
	    SELECT @Fcid = @@IDENTITY 
	    SELECT @classid = class_id
	    FROM   products
	    WHERE  product_id = @Pid
	    
	    INSERT INTO flCdetail
	      (
	        Fc_id,
	        P_id
	      )
	    SELECT @Fcid,
	           p.product_id
	    FROM   products p
	    WHERE  p.class_id LIKE @classid + '%'
	           AND p.child_number = 0
	           AND p.deleted = 0
	END
	ELSE
	BEGIN
	    SELECT @nPid = P_id
	    FROM   FLCondition
	    WHERE  id = @nid 
	    
	    UPDATE FLCondition
	    SET    [RP_id] = @nRR_id,
	           [c_id] = @Cid,
	           [P_id] = @Pid,
	           [quantity] = @quantity,
	           [price] = @price,
	           [BuyTotal] = @BuyTotal,
	           [BackTotal] = @BackTotal,
	           [Month] = @Month,
	           [BeginTime] = @BeginTime,
	           [EndTime] = @EndTime,
	           [intendTime] = @intendTime,
	           [alarmTime] = @TQalarmTime,
	           [FLModulus] = @FLModulus,
	           [FLStates] = 0,
	           [Flrelation] = @FLrelation,
	           [Formula] = @Formula,
	           [Flmoney] = @Flmoney,
	           [fljsmode] = @Fljsmode,
	           [FlSjQty] = 0,
	           [FlSJBuyTotal] = 0.00,
	           [FlSJBackTotal] = 0.00,
	           [flCondition] = @condition,
	           [GuessTotal] = @GuessTotal,
	           [SaleQty] = @SaleQty
	    WHERE  id = @nid 
	    
	    IF @nPid <> @Pid
	    BEGIN
	        DELETE flCdetail
	        WHERE  FC_id = @nid
	        
	        SELECT @classid = class_id
	        FROM   products
	        WHERE  product_id = @Pid
	        
	        INSERT INTO flCdetail
	          (
	            Fc_id,
	            P_id
	          )
	        SELECT @nid,
	               p.product_id
	        FROM   products p
	        WHERE  p.class_id LIKE @classid + '%'
	               AND p.child_number = 0
	               AND p.deleted = 0
	    END
	END
GO
