/************************************************************
--过程名称：Ts_T_InSendBillByClient
--功能：添加修改物流配送单中间过程的派送单
--创建人：xxx
--创建时间：2015-04-15 
备注：
**************************************************************/
create proc [dbo].[Ts_T_InSendBillByClient]
( 
	@sendID [int] = 0,		/*物流单号*/
	@CName varchar(200) = '',		/*往来单位	*/
	@Iscompany [int] = 0,	/*1机构,0为往来单位*/
	@Qty [Int] = 0,   /*总件量*/
	@WholeQty [Int] = 0, /*  整货数量 */
	@PartQty [Int] = 0,				/*  拼箱数量*/
	@ScatQty [Int] = 0,		/*  零货数量*/
	@Total numeric(18,2) = 0,			/*  总金额*/
	@nmode int = 0,				/*为0表示录入，1表示更新*/
	@nRet           int output  
)
as
/*Params Ini begin*/
if @nmode is null  SET @nmode = 0

/*Params Ini end*/

if @nmode=0
begin
    INSERT INTO SendBillByClient
	(sendID, CName, Iscompany, 
	 Qty,
	 WholeQty, PartQty, 
	 ScatQty, Total)
	VALUES
	(@sendID, @CName, @Iscompany, 
	 @Qty,
	 @WholeQty, @PartQty, 
	 @ScatQty, @Total)
	  
	set @nRet = @@IDENTITY
end
else
begin
    UPDATE SendBillByClient
	SET sendID  =@sendID, CName = @CName, Iscompany = @Iscompany, 
	 Qty = @Qty,
	 WholeQty= @WholeQty, PartQty = @PartQty, 
	 ScatQty = @ScatQty, Total = @Total
    WHERE sendID = @sendID
	/*set @nRet = @sm_id	    */
end
GO
