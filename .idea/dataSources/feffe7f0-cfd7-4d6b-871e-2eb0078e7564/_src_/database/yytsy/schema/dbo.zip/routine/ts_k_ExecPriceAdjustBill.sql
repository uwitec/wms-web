

CREATE PROCEDURE ts_k_ExecPriceAdjustBill 
/*with encryption*/
AS
	DECLARE @SrvDate DATETIME
	DECLARE @BillID  INT
	DECLARE @YID     INT
	
	SELECT @SrvDate = CONVERT(DATETIME, CONVERT(VARCHAR(100), GETDATE(), 23))
	SET @BillID = 0
	SET @YID = 0
	
	IF EXISTS(
	       SELECT 1
	       FROM   PriceIdx A,
	              PriceAdjustJob B
	       WHERE  A.billid = B.BillID
	              AND B.IsRun = 0
	              AND B.AuditerID > 0
	              AND B.RunDate <= @SrvDate
	   )
	BEGIN
	    DECLARE ExecPriceAdjust  CURSOR  
	    FOR
			SELECT B.BillID, B.y_id
	        FROM   PriceIdx A,
	               PriceAdjustJob B
	        WHERE  A.billid = B.BillID
	               AND B.IsRun = 0
	               AND B.AuditerID > 0
	               AND B.RunDate <= @SrvDate
	    OPEN ExecPriceAdjust
	    FETCH NEXT FROM ExecPriceAdjust INTO @BillID, @YID                                                                                                    
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        Exec ts_b_ApplyPriceAdjust @BillID, @YID	        
	        FETCH NEXT FROM ExecPriceAdjust INTO @BillID, @YID
	    END
	    CLOSE ExecPriceAdjust
	    DEALLOCATE ExecPriceAdjust
	END
GO
