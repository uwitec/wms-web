
/*@nRet=0, 生成成功, -1 无数据返回*/

CREATE proc ts_j_CreateNearValid
(
	@nRet	int output
)

as
	set nocount on
	declare @curdate datetime, @newDate datetime, @b bit, @Y_ID int, @nNearValidDay int	
	set @CurDate = FLOOR(cast(GETDATE() as NUMERIC(25,8)))		
	set @newdate =dateadd(dd, 1,@curdate)
	if DATEPART(MM, @newdate) <> DATEPART(MM, @curdate)
	  set @b = 1
	else 
	  set @b = 0  

	if @b <> 1  /*不是月末返回*/
	begin
	  set @nRet = -1
	  return 0
	end 
	
	if @nRet = 1 
	begin
	  update NearValidProducts set overflag = 1 where overflag = 0 and CreateDate  = @curdate
	  set @nRet = 1
	  return 0	  
	end  
	   		  
	set @nRet = -1 	  
    select  @Y_ID = CAST(sysvalue  as int) from sysconfig where sysname = 'Y_ID'	and Y_ID  = 0    
    select @nNearValidDay = CAST(sysvalue  as int) from sysconfig where sysname = 'NearValidDay' and Y_ID  = 0
    if @nNearValidDay is null  set @nNearValidDay = 0
    if @nNearValidDay <=0 
      return 0
      
    if exists(select 1 from NearValidProducts where CreateDate = @curdate and overflag = 1)
      return 0     
  
    delete NearValidProducts where CreateDate = @curdate and overflag = 0
/*写入数据*/
    insert into NearValidProducts(	[CreateDate],
									[location_id],
									[s_id],
									[p_id],
									[supplier_id],
									[quantity],
									[costprice],
									[costtotal],
									[batchno],
									[makedate],
									[instoretime],
									[validdate],
									[commissionflag],
									[Y_ID],
									[BatchBarCode],
									[OverFlag])  
									            
       select						@curdate,
									[location_id],
									[s_id],
									[p_id],
									[supplier_id],
									[quantity],
									[costprice],
									[costtotal],
									[batchno],
									[makedate],
									[instoretime],
									[validdate],
									[commissionflag],
									[Y_ID],
									[BatchBarCode],
									0 
         from storehouse        
        where FLOOR(cast(validdate as NUMERIC(25,8))) >=  cast(@curdate as NUMERIC(25,8)) and			
              (FLOOR(cast(validdate as NUMERIC(25,8))) - cast(@curdate as NUMERIC(25,8))) <= @nNearValidDay and
              stopsaleflag = 0 and
              ((@Y_ID = 2 and Y_ID =2) or (@Y_ID <> 2 and Y_ID <> 2))              
       if @@ROWCOUNT  >0 set @nRet = 0
       return 0
GO
