
/*获取积分金额函数。*/
/*@ctid 卡类型ID*/
CREATE	  FUNCTION [GetIntegralMoney] (@CTID int,
		@dtToday datetime	
        )  
RETURNS numeric(25,8) 
 
AS  
BEGIN     
    
	declare @dIntegralMoney numeric(25,8) , @nWeek int
	declare @dIntegralMoneyDay numeric(25,8) 
	set @dIntegralMoneyDay = 0
	set @dtToday = cast(CAST(@dtToday as varchar(10)) as datetime) 
	set @nWeek = DATEPART(dw, @dtToday)
	if @nWeek = 1
	  select @dIntegralMoney = integralmoney0 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 2
	  select @dIntegralMoney = integralmoney1 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 3
	  select @dIntegralMoney = integralmoney2 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 4
	  select @dIntegralMoney = integralmoney3 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 5
	  select @dIntegralMoney = integralmoney4 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 6
	  select @dIntegralMoney = integralmoney5 from ctintegralMx where ct_id = @CTID
	else if @nWeek = 7
	  select @dIntegralMoney = integralmoney6 from ctintegralMx where ct_id = @CTID
	  
	select @dIntegralMoneyDay = isnull(Integral, 0) from DayIntegral where ct_id = @CTID and [DAY] = DATEPART(dd, @dtToday)
	
	if @dIntegralMoney is null set @dIntegralMoney = 0
	
	if @dIntegralMoneyDay < @dIntegralMoney and @dIntegralMoneyDay <> 0 or @dIntegralMoney = 0
		set @dIntegralMoney = @dIntegralMoneyDay
	
	if @dIntegralMoney =0
	  select @dIntegralMoney = integralmoney from vipcardtype where ct_id = @CTID        

    RETURN(@dIntegralMoney)	
END
GO
