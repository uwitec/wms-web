
CREATE PROCEDURE TS_T_LicensePrint
(
  @C_ID int = 0,
  @EntType int = 0,
  @begindate datetime =0,
  @endDate datetime =0
)
AS 

if @C_ID is null  SET @C_ID = 0
if @EntType is null  SET @EntType = 0
if @begindate is null  SET @begindate = 0
if @endDate is null  SET @endDate = 0

SELECT cl.repname, cr.repNo, cr.validTime, c.Class_ID, c.parent_id, c.Client_ID, c.Child_number, c.Serial_number, 
       c.Name, c.Alias, c.ZipCode, c.[address], 
       c.contact_personal, c.phone_number, c.Acount_Number, c.Tax_Number, c.Credit_Total, c.Comment
FROM dbo.clients AS c left JOIN BindLicense bl on c.ent_type = bl.ent_type and (@C_ID =0 or c.client_id = @C_ID)
                           inner join ClientLicense cl on bl.cl_id = cl.cl_id
                           left join ClientReport2 cr on cl.cl_id = cr.rpn_id and c.client_id = cr.c_id and (@C_ID =0 or cr.c_id = @C_ID)              
WHERE c.deleted <> 1 and c.child_number = 0 and (@EntType = 0 or c.ent_type = @EntType) 
  and cr.validTime >= @begindate and cr.validTime <= @endDate
Order by c.serial_number asc, cl.cl_id asc, cr.validTime asc
GO
