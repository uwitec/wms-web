
CREATE procedure ts_q_selbillcode   
(@begindate datetime,  
 @enddate datetime  
)  
as 

/*修改为支持启用GSP标准流程使用*/
delete billcode where billcode in ('jiangm', '流通监管码')
 
select identity(int,1,1) xh,billcode,billid,billtype,e_id,inputdate,flag  
     into #temp from billcode  
 where inputdate between @begindate and @enddate order by id  

select a.xh,billcode,billnumber billid,name e_id,a.inputdate,  
 case flag when 0 then '未使用' when 1 then '使用'  when -1 then '锁定' end flag  
    from #temp a left join employees e on a.e_id=e.emp_id
		left join orderidx b on a.billid=b.billid
GO
