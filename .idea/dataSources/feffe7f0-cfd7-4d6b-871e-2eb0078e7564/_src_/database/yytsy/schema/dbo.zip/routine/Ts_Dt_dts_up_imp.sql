/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-05-16*/
/* Description:	门店导入-总部接收退货单据写草稿箱*/
/* =============================================*/
CREATE PROCEDURE [dbo].[Ts_Dt_dts_up_imp]
  @c_id int
AS
BEGIN
 set nocount on
 begin tran
  /*declare   @begindate varchar(20)    --开始时间*/
  /*declare   @enddate   varchar(20)    --结束数据*/
/*主表*/
  /*set @begindate =(select min(billdate) from  billdtsidxIN )*/
  /*set @enddate   =(select max(billdate) from  billdtsidxIN ) */
  /*--删除过账表和草稿表单据*/
  delete billdtsidxIN  where billid in (select b.billid from billidx a,billdtsidxIN b       where a.GUID=b.GUID)
  delete billdtsidxIN  where billid in (select b.billid from billdraftidx a,billdtsidxIN b  where a.GUID=b.GUID)
  delete buymanagebilldtsIN where bill_id  not in (select billid from billdtsidxIN )
  /*---------------------修改数据*/
 update buymanagebilldtsIN set p_id=b.p_id,ss_id=b.ss_id,sd_id=b.sd_id,location_id=b.location_id
 from buymanagebilldtsIN a,salemanagebill b
 where a.orgbillid=b.smb_id
 /*-修改往来单位 出库仓库信息*/
 update billdtsidxIN set  c_id=v.c_id,e_id=v.e_id,sout_id=v.sout_id,sin_id=v.sin_id,billtype=11,
          auditman=v.auditman,inputman=v.inputman,GatheringMan=v.GatheringMan,billstates=3
 from   billdtsidxIN x,      
 (select distinct  a.bill_id,c.c_id,c.e_id,c.sout_id,c.sin_id,c.auditman,c.inputman,c.GatheringMan
 from  buymanagebilldtsIN a,salemanagebill b,billidx c
 where a.orgbillid=b.smb_id and b.bill_id=c.billid )v
 where x.billid=v.bill_id
 /*主表*/
 insert into billdraftidx
  (
  billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty  
  )
  select billdate,billnumber,11 as billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty
  from billdtsidxIN                  
  /*明细*/
  insert into salemanagebilldrf 
  (
   bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,totalmoney,
   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,price_id,
   ss_id,sd_id,location_id,supplier_id,commissionflag,comment,unitid,taxrate,order_id,total,iotag,
   InvoiceTotal,thqty,newprice,orgbillid,AOID,jsprice,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
   RowGuid,RowE_id,YCostPrice,YGuid,Y_ID,instoretime,comment2,BatchBarCode,
   scomment,batchprice
  )
  select    
  a.bill_id,a.p_id,a.batchno,a.quantity,a.costprice,a.taxprice as saleprice,a.discount,a.discountprice,a.totalmoney,
   a.taxprice,a.taxtotal,a.taxmoney,a.retailprice,a.retailtotal,a.makedate,a.validdate,a.qualitystatus,a.price_id,
   a.ss_id,a.sd_id,a.location_id,a.supplier_id,a.commissionflag,a.comment,a.unitid,a.taxrate,a.order_id,a.total,a.iotag,
   a.InvoiceTotal,a.thqty,a.newprice,a.orgbillid,a.AOID,a.jsprice,a.invoice,a.invoiceno,a.PriceType,a.SendQTY,a.SendCostTotal,
   a.RowGuid,a.RowE_id,a.YCostPrice,a.YGuid,a.Y_ID,a.instoretime,a.comment2,a.BatchBarCode,
   a.scomment,a.batchprice
  from buymanagebilldtsIN a 
  /*-根据GUID 修改 明细 bill_id*/
  update salemanagebilldrf set bill_id=e.newbid
  from salemanagebilldrf f, 
  (
  select c.billid as newbid,d.smb_id
  from billdraftidx c,(
  select a.GUID ,a.billid,b.smb_id
  from billdtsidxIN a,salemanagebilldrf b
  where a.billid=b.bill_id) d
  where c.GUID=d.GUID
  ) e
  where f.smb_id=e.smb_id 
 commit Tran   
END
GO
