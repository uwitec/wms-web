
CREATE PROCEDURE Ts_K_GetPaymentBillList(
	@Beg		   DATETIME, 
	@End		   DATETIME, 
	@ClientId      INT,           /*往来单位ID  */
	@EMan	       INT,           /*经手人ID*/
	@BillStates    INT,           /*单据状态*/
	@YId           INT = 2,
	@BillId        INT = 0
)
AS
BEGIN
	IF @BillId > 0
	BEGIN
		SELECT DISTINCT a.BillId, a.BillDate, a.BillNumber, a.BillType, a.BillStates, a.C_Id, a.E_Id, a.B_Id, a.Z_Id,
			   a.A_Id, a.BCount, a.PCount, a.Total, a.Comment, a.YId, t.Comment AS BillTypeName,
			   CASE a.BillStates WHEN 0 THEN '未审核' WHEN 1 THEN '审核中' WHEN 2 THEN '已审核' WHEN 3 THEN '未通过' ELSE 'Error BillStates' END AS szBillStates,
			   c.name AS CName, y.name AS YName, e.name AS EMan, ISNULL(e1.name, '') AS BMan, ISNULL(e2.name, '') AS ZMan,
			   a.CreateDate,
			   CASE WHEN a.B_AuditDate > 10 THEN CONVERT(VARCHAR(100), a.B_AuditDate, 120) ELSE '' END AS B_AuditDate,
			   CASE WHEN a.Z_AuditDate > 10 THEN CONVERT(VARCHAR(100), a.Z_AuditDate, 120) ELSE '' END AS Z_AuditDate,
			   b.Bill_Id AS Bill_BillId, d.billdate AS Bill_BillDate, d.billnumber AS Bill_BillNumber, d.billtype AS Bill_BillType,
			   d.c_id AS Bill_CId, d.e_id AS Bill_EId, d.ysmoney AS Bill_YSMONEY, d.quantity AS Bill_Quantity, d.note AS Bill_Note,
			   d.auditdate AS Bill_AuditDate, d.BalanceMode AS Bill_BalanceMode, vt.Comment AS Bill_BillTypeName, h.name AS Bill_CName, e3.name AS Bill_EName,
			   e4.name AS Bill_AuditName, e5.name AS Bill_InputName,
			   CASE d.BalanceMode WHEN 0 THEN '现结' WHEN 1 THEN '挂帐' WHEN 2 THEN '月结' WHEN 3 THEN '滚结' WHEN 4 THEN '货到付款' 
	       	                      WHEN 5 THEN '预收' WHEN 6 THEN '预付' WHEN 7 THEN '实销实结' ELSE 'Error BalanceMode' END AS Bill_BalanceModeName,
	       	   '有' + CAST(a.BCount AS VARCHAR) + '张单据，总金额为' + CAST(a.Total AS VARCHAR) + '元的商品需要付款。' AS Info 
		FROM   PaymentRequestIdx a
			   INNER JOIN PaymentRequestBill b ON  a.BillId = b.PaymentRequestId 
			   INNER JOIN billidx d ON b.Bill_Id = d.billid
			   INNER JOIN clients c ON a.C_Id = c.client_id
			   INNER JOIN company y ON a.YId = y.company_id
			   INNER JOIN VchType t ON a.BillType = t.Vch_ID
			   INNER JOIN employees e ON a.E_Id = e.emp_id
			   LEFT JOIN employees e1 ON a.B_Id = e1.emp_id
			   LEFT JOIN employees e2 ON a.Z_Id = e2.emp_id
			   INNER JOIN VchType vt ON d.billtype = vt.Vch_ID
			   INNER JOIN clients h ON d.c_id = h.client_id
			   INNER JOIN employees e3 ON d.e_id = e3.emp_id
			   INNER JOIN employees e4 ON d.auditman = e4.emp_id
			   INNER JOIN employees e5 ON d.inputman = e5.emp_id
		WHERE  a.BillId = @BillId
	END
	ELSE
	BEGIN	
		SELECT a.BillId, a.BillDate, a.BillNumber, a.BillType, a.BillStates, a.C_Id, a.E_Id AS InputMan, a.B_Id, a.Z_Id,
			   a.A_Id, a.BCount, a.PCount, a.Total, a.Comment, a.YId, t.Comment AS BillTypeName,
			   CASE a.BillStates WHEN 0 THEN '未审核' WHEN 1 THEN '审核中' WHEN 2 THEN '已审核' WHEN 3 THEN '未通过' ELSE 'Error BillStates' END AS szBillStates,
			   c.name AS CName, y.name AS YName, e.name AS EMan, ISNULL(e1.name, '') AS BMan, ISNULL(e2.name, '') AS ZMan,
			   CONVERT(VARCHAR(100), a.CreateDate, 120) AS CreateDate,
			   CASE WHEN a.B_AuditDate > 10 THEN CONVERT(VARCHAR(100), a.B_AuditDate, 120) ELSE '' END AS B_AuditDate,
			   CASE WHEN a.Z_AuditDate > 10 THEN CONVERT(VARCHAR(100), a.Z_AuditDate, 120) ELSE '' END AS Z_AuditDate
		FROM   PaymentRequestIdx a
			   INNER JOIN clients c ON  a.C_Id = c.client_id
			   INNER JOIN company y ON  a.YId = y.company_id
			   INNER JOIN VchType t ON a.BillType = t.Vch_ID
			   INNER JOIN employees e ON  a.E_Id = e.emp_id
			   LEFT JOIN employees e1 ON  a.B_Id = e1.emp_id
			   LEFT JOIN employees e2 ON  a.Z_Id = e2.emp_id
		WHERE  a.BillDate BETWEEN @Beg AND @End AND a.BillStates = @BillStates AND a.YId = @YId
			   AND (a.E_Id = @EMan OR @EMan = 0)
			   AND (a.C_Id = @ClientId OR @ClientId = 0) 

	END	           
END
GO
