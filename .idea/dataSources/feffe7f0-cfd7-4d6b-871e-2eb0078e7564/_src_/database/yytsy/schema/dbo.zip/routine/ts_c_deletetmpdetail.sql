
CREATE proc [dbo].[ts_c_deletetmpdetail]
( 
  @nBillid int
)


as


set nocount on 

	delete from productdetailtmp where billid=@nBillId
	delete from accountdetailtmp where billid=@nBillId
	
	
return 0
GO
