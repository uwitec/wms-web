
/* 功能：销售决策查询 按类别汇总
  
*/

CREATE PROCEDURE TS_J_RepSale02
( 
	@szbegindate varchar(12),   /*开始时间*/
	@szenddate   varchar(12),   /*结束时间*/
	@dateMode  int,		   /*1 月 2 季度 3 年		*/
	@CG_ID     int,         /*类别组id，必选项*/
	@szID      varchar(3000)= '',  /*选择的类别id*/
	@y_id      int = 0			 /*分支机构	*/
)

AS

/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @Opendate   datetime   /*开账时间*/
             
   if @szbegindate <> ''
     set @begindate = CAST((@szbegindate+ '-01') as datetime)
     
   if @szenddate <> ''
     set @enddate = CAST((@szenddate+ '-01') as datetime)      
   set @enddate = dateadd(mm,1,@enddate) 
   set @enddate = @enddate -1 
   
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @begindate
   if @begindate <  @OpenDate
     set @begindate = cast((cast(datepart(yyyy, @OpenDate) as varchar(4)) + '-' + cast(datepart(MM, @OpenDate) as varchar(2)) + '-' + '01') as datetime)

/*创建日期分段表，标识，时间跨度*/
/*创建需要查询的商品表，关联了类别组的商品*/
/*创建新品表*/
/*创建返回信息表*/
/*计算返回值*/


if OBJECT_ID('tempdb..#SplitDate' ) is not null 
  drop table #SplitDate
create table #splitDate
			 ( dateid int IDENTITY,   /*分隔日期后标识*/
			   FlagName varchar(50),  /*分隔后标识名称，例按年 2013 按月201306 按季度2013二季度*/
			   yyyy     varchar(10),  /*所属于年 */
			   qqq		varchar(10),  /*所属季度			   */
			   mm		varchar(10),  /*所属月			   			   	     */
			   begindate datetime,    /*本段分隔的开始时间*/
			   enddate   datetime,    /*本段分隔的结束时间*/
			   daycount  int		  /*本段分隔的天数统计	  */
			  )  
			  
if OBJECT_ID('tempdb..#QrProducts' ) is not null 
  drop table #QrProducts
create table #QrProducts
 			( p_id int,
 			  CG_id int
 			 )  
			  			  
			  
if OBJECT_ID('tempdb..#NewProducts' ) is not null 
  drop table #NewProducts
create table #NewProducts
			 ( dateid int,
			   p_id int,
			   cg_id int,			   
			   BuyDate datetime, 
			   preDate datetime,
			   DayCount int			   			  			   		  
			  )  			  
        
               
        
        
if OBJECT_ID('tempdb..#qrSale02' ) is not null 
  drop table #qrSale02
create table #qrSale02
             ( dateid int,
               cg_id  int,           /*类别id									*/
			   y_id   int,			 /*分支机构																                                                  */
               SaleQty NUMERIC(25,8),		 /*数量*/
               Saletotal NUMERIC(25,8),		 /*含税金额	*/
               BackQty NUMERIC(25,8),        /*退货数量 not show*/
               BackTotal NUMERIC(25,8),      /*退货金额 not show 										*/
               costtotal NUMERIC(25,8),      /*成本金额*/
			   profit 	 NUMERIC(25,8),		 /*毛利*/
			   geustCount  int,		 /*来客数*/
			   gesutPrice  NUMERIC(25,8),	 /*客单价*/
			   gesutpQty   int,		 /*品种数*/
			   profitRate  NUMERIC(25,8), 	 /*毛利率                              */
               backRate NUMERIC(25,8),		 /*退货率*/
               saleUpRate NUMERIC(25,8),     /*增长率	*/
			   GrowthRate NUMERIC(25,8),  	 /*成长率*/
			   CrossRate  NUMERIC(25,8),	 /*交叉比*/
			   PClassRate NUMERIC(25,8),	 /*商品品类构成比																						*/
			   saleGrowthRate NUMERIC(25,8),  /*销售营业成长率*/
			   profitGrowthRate NUMERIC(25,8), /*销售毛利成长率*/
			   iniQty  NUMERIC(25,8),          /*历史期初*/
			   beginQty  NUMERIC(25,8),        /*本期期初*/
			   OverQty   NUMERIC(25,8),         /*本期期末 */
			   sumtotal  NUMERIC(25,8),          /*所有品类的销售合计*/
			   total     NUMERIC(25,8),    /*不含税金额*/
			   costtaxtotal NUMERIC(25,8)  /*含税成本金额			                	              */
              )  


declare @nMinDateid int, @nMaxDateid int, @splitBegindate datetime,  @splitEnddate datetime, @nDateid int


/*初始化#QrProducts*/
 DECLARE @info_ID INT 
 DECLARE @ColName VARCHAR(100)
 declare @PszSql varchar(8000)
 if @szID<>'' 
 begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
            /*zjx.通过选择自定义类别id的字符串获取class_ID*/
			select   class_id into #Categoryclassid from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
 end
 if @CG_ID = 0 goto repend
 SET @PszSql = ' INSERT INTO #QrProducts(CG_id, p_id) '
                + ' select cc.id,p_id from products p ' 
                + ' left join ProductCategory pc on p.product_id = pc.P_id '
                + ' left join customCategory cc on pc.' + @ColName + ' = cc.class_id where ' + @ColName + ' in (select class_id from #Categoryclassid)'
 EXEC (@PszSql)    
		   		             
if @dateMode = 1 goto repMonth    /*按月查询*/
if @dateMode = 2 goto repquarter  /*按季度查询*/
if @dateMode = 3 goto repYear     /*按年查询*/

repMonth:
/*取月begindate*/

set @begindate = DATEADD(MM, -1, @begindate)

insert into #SplitDate(begindate)
   select    
     dateadd(mm,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(mm,number,@begindate)<=@enddate
/*计算其他时间列     */
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+cast(DATEPART(MM, begindate) as varchar(2))+'月',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = DATEPART(MM, begindate)
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1
                                                         								                     
  goto  rep


repquarter:
/*取季度begindate*/
set @begindate = DATEADD(QQ, -1, @begindate) /*需要计算到选择时间段的上一期*/

insert into #SplitDate(begindate)
   select    
     dateadd(QQ,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(QQ,number,@begindate)<=@enddate
/*计算其他时间列*/
	update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+ cast(DATEPART(QQ, begindate) as varchar(2))+'季度',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = 0	
	update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
	select @nMaxDateid = MAX(dateid) from #splitDate
    update #splitDate set enddate = @enddate where dateid = @nMaxDateid
    update #splitDate set daycount = cast((enddate - begindate) as Int)+1 	                                                								                  
  
  goto rep

repYear:
  /*取年begindate*/

set @begindate = DATEADD(YYYY, -1, @begindate) /*需要计算到选择时间段的上一期*/
  
insert into #SplitDate(begindate)
   select    
     dateadd(YYYY,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(YYYY,number,@begindate)<=@enddate
/*计算其他时间列*/
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年',
						yyyy = DATEPART(YYYY, begindate), qqq = 0, mm=0	
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1										
 
  goto rep
  
rep:
     /*初始化#qrSale02表*/
  insert into #qrSale02(dateid, y_id, cg_id)
     select sp.dateid, y.company_id, cg.cg_Id from #splitDate sp
     cross join company y 
     cross join (select distinct cg_id as cg_Id from #QrProducts) cg
     where y.child_number = 0 and y.company_id > 1 and y.deleted = 0
     order by sp.dateid, y.company_id, cg.cg_Id                           
 
  /*销售数量   --销售金额  --退货数量  --退货金额  --销售成本金额*/
          
  update s1 set s1.SaleQty = t1.SaleQty, s1.Saletotal = t1.Saletotal, 
				 s1.BackQty = t1.backQty, s1.BackTotal = t1.backTotal,
				 s1.total=t1.total,s1.costtaxtotal=t1.costtaxtotal         
    from  #qrSale02 s1,  
         (select sp.dateid, bi.Y_ID, p.CG_id,
					 sum(case  when bi.billtype in(10, 12) then mx.quantity else 0 end) as SaleQty, 
                     sum(case  when bi.billtype in(10, 12) then mx.taxtotal else 0  end) as Saletotal,
                     sum(case  when bi.billtype in(10, 12) then mx.total else 0  end) as total,
                     sum(case  when bi.billtype in(10, 12) then mx.costtaxtotal else 0  end) as costtaxtotal,
                     sum(case  when bi.billtype in(10, 12) then mx.costprice*mx.quantity else 0  end) as costtotal,
                     sum(case  when bi.billtype in(11, 13) then mx.quantity else 0 end) as backQty, 
                     sum(case  when bi.billtype in(11, 13) then mx.taxtotal else 0  end) as backTotal                        
       from billidx bi
       inner join salemanagebill mx on bi.billid = mx.bill_id 
       inner join #QrProducts  p  on mx.p_id = p.p_id
       left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate
       where bi.billtype in (10,11,12,13) and bi.billstates = 0 and bi.billdate between @begindate and @enddate 
             and mx.AOID = 0 and mx.p_id > 0 and (@y_id = 0 or mx.Y_ID = @y_id)             
       group by sp.dateid, bi.Y_ID, p.cg_id) t1
    where s1.dateid = t1.dateid and s1.y_id = t1.Y_ID and s1.cg_id = t1.CG_id                  
    
   /*来客数 品种数 */
   update s1 set gesutpQty = t1.pqty, geustCount = geustCount
     from  #qrSale02 s1,  
         (select sp.dateid, bi.Y_ID, p.CG_id,
					 COUNT(mx.p_id) as pqty, COUNT(bill_id) as guestCount
       from billidx bi
       inner join salemanagebill mx on bi.billid = mx.bill_id 
       inner join #QrProducts p on mx.p_id = p.p_id
       left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate       
       where bi.billtype in (10,11,12,13) and bi.billstates = 0 and bi.billdate between @begindate and @enddate 
             and mx.AOID = 0 and mx.p_id > 0 and (@y_id = 0 or mx.Y_ID = @y_id)
       group by sp.dateid, bi.Y_ID, p.CG_id) t1
    where s1.dateid = t1.dateid and s1.y_id = t1.Y_ID     
   
   /*清除null 避免计算出错   */
   update #qrSale02 set SaleQty = 0			where SaleQty is null
   update #qrSale02 set Saletotal = 0		where Saletotal is null
   update #qrSale02 set BackQty = 0			where BackQty is null
   update #qrSale02 set BackTotal = 0		where BackTotal is null					   					          
   update #qrSale02 set costtotal = 0		where costtotal is null
   update #qrSale02 set gesutpQty = 0		where gesutpQty is null
   update #qrSale02 set geustCount = 0		where geustCount is null         					   					          					   					             
    /*客单价 */
   update #qrSale02 set gesutPrice = Saletotal/geustCount where  geustCount <> 0   
   
   /*毛利 毛利率*/
   update #qrSale02 set profit = Saletotal - costtaxtotal
   update #qrSale02 set profitRate = profit/Saletotal*100 where Saletotal <> 0            
     
/*销售退货率	退货总数量/采购总数量 分母为0返回空     */
   update #qrSale02 set backRate = BackQty/SaleQty*100 where SaleQty <> 0
   
/*销售增长率	本期销售额/上期销售额*/
    update q1 set saleUpRate = q1.Saletotal/q2.Saletotal*100 
       from #qrSale02 q1, #qrSale02 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.y_id = q2.y_id and q1.cg_id = q2.cg_id 


  /*成长率*/
     update q1 set GrowthRate = (q1.Saletotal-q2.Saletotal)/q2.Saletotal*100 
       from #qrSale02 q1, #qrSale02 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.y_id = q2.y_id and q1.cg_id = q2.cg_id
      
  /*计算所有期初， 本期期初库存、本期期末库存*/
    update s1 set iniQty = t1.quantity
        from #qrSale02 s1,             
			  (select st.Y_ID, p.CG_id, sum(quantity) quantity
				  from 
				  storehouseini st
				  inner join #QrProducts p on st.p_id = p.p_id
				  group by st.Y_ID, p.CG_id
			   ) t1
	    where s1.y_id = t1.Y_ID and s1.cg_id = t1.CG_id
    
  
    update s1 set beginQty = t1.beginQty
        from #qrSale02 s1,             
			  (select sp.dateid, pd.Y_ID, p.CG_id, sum(pd.quantity) as beginQty
				  from 
				  billidx bi
				  inner join productdetail pd on bi.billid = pd.billid
				  inner join #QrProducts   p on pd.p_id = p.p_id
				  left join  #splitDate sp on bi.billdate < sp.begindate      
				  group by sp.dateid, pd.Y_ID, p.CG_id
			   ) t1
	    where s1.dateid =t1.dateid and s1.y_id = t1.Y_ID and s1.cg_id = t1.cg_Id
	   
	 update s1 set OverQty = t1.OverQty
        from #qrSale02 s1,             
			  (select sp.dateid, pd.Y_ID, p.cg_id,sum(pd.quantity) as OverQty
				  from 
				  billidx bi
				  inner join productdetail pd on bi.billid = pd.billid
				  inner join #QrProducts p on pd.p_id = p.p_id
				  left join  #splitDate sp on bi.billdate < (sp.enddate + 1)      
				  group by sp.dateid, pd.Y_ID, p.CG_id
			   ) t1
	    where s1.dateid =t1.dateid and s1.y_id = t1.Y_ID and s1.cg_id = t1.CG_id		   			   	  		                       		   			   	  		                        
  /*交叉比*/
      update #qrSale02 set iniQty = 0 where iniQty is null
      update #qrSale02 set beginQty = 0 where beginQty is null
      update #qrSale02 set OverQty = 0 where OverQty is null
      update #qrSale02 set profitRate = 0 where profitRate is null
            
      update #qrSale02 set beginQty = iniQty +beginQty, OverQty = iniQty + OverQty
      update #qrSale02 set CrossRate = profitRate*(SaleQty/(beginQty+OverQty)/2) where beginQty+OverQty <> 0                 	  	
  
  /*商品品类构成比*/
    update q1 set q1.sumtotal = q2.sumtotal 
      from #qrSale02 q1,
            (select dateid, y_id, SUM(Saletotal) sumtotal
              from #qrSale02
              group by dateid, y_id) q2 
       where q1.dateid = q2.dateid and q1.y_id = q2.y_id    
    update #qrSale02 set sumtotal = 0 where SumTotal is null    
    update #qrSale02 set pclassrate=Saletotal/SumTotal*100 where SumTotal <> 0    
                    
  /*销售营业成长率*/
     update q1 set saleGrowthRate = q1.Saletotal/q2.Saletotal*100 
       from #qrSale02 q1, #qrSale02 q2   
     where q1.dateid = q2.dateid + 1 and q2.Saletotal <> 0 and q1.y_id = q2.y_id and q1.cg_id = q2.cg_id            
  /*销售毛利成长率*/
     update q1 set profitGrowthRate = q1.profit/q2.profit*100 
       from #qrSale02 q1, #qrSale02 q2   
     where q1.dateid = q2.dateid + 1 and q2.profit <> 0 and q1.y_id = q2.y_id and q1.cg_id = q2.cg_id    
     goto repend
    
      
repend:
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int     
   
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT'


   select @nMinDateid = MIN(dateid)  from #SplitDate
   select 
           /*b.dateid,  b.y_id, */
           dbo.DecimalQrValue(@nSL, b.SaleQty) SaleQty,  dbo.DecimalQrValue(@ntotal,b.Saletotal) Saletotal,  
           dbo.DecimalQrValue(@ntotal,b.total) total,
           dbo.DecimalQrValue(@ntotal,b.costtaxtotal) CostTaxTotal,
           /*dbo.DecimalQrValue(@nSL,b.BackQty) BackQty,  */
		   /*dbo.DecimalQrValue(@ntotal,b.BackTotal) BackTotal,  dbo.DecimalQrValue(@ntotal,b.costtotal) costtotal,  */
		   dbo.DecimalQrValue(@ntotal,b.profit) profit,  b.geustCount,  
		   dbo.DecimalQrValue(@nDJ,b.gesutPrice) gesutPrice, b.gesutpQty,  dbo.DecimalQrValue(@nOther,b.profitRate) profitRate,  dbo.DecimalQrValue(@nOther,b.backRate) backRate,	
		   dbo.DecimalQrValue(@nOther,b.SaleUpRate) SaleUpRate,   dbo.DecimalQrValue(@nOther,b.GrowthRate) GrowthRate,  
		   /*dbo.DecimalQrValue(@nSL,b.iniQty) iniQty, dbo.DecimalQrValue(@nSL,b.beginQty) beginQty, dbo.DecimalQrValue(@nSL,b.OverQty) OverQty, */
		   dbo.DecimalQrValue(@nOther,b.CrossRate) CrossRate,  dbo.DecimalQrValue(@nOther,b.PClassRate) PClassRate,  
		   dbo.DecimalQrValue(@nOther,b.saleGrowthRate) saleGrowthRate, /*dbo.DecimalQrValue(@nOther,b.profitGrowthRate) profitGrowthRate, dbo.DecimalQrValue(@nTotal,b.SumTotal) SumTotal,               */
		  sd.FlagName, /*sd.yyyy, sd.qqq, sd.mm, sd.begindate, sd.enddate, sd.daycount,*/
          isnull(c1.name, '') as c1name, isnull(c2.name, '') as c2name, isnull(c3.name, '') as c3name,
          /*isnull(c1.id, 0) as c1id, isnull(c2.id, 0) as c2id, isnull(c3.id, 0) as c3id,*/
          /*isnull(c1.class_id, '') as c1class_Id, isnull(c2.class_id, '') as c2class_id, isnull(c3.class_id, '') as c3class_id,*/
          y.name as yname, r.name  as rname                                   
     from  #qrSale02 b 
     left join #SplitDate sd on b.dateid = sd.dateid  
     left join customCategory cg on b.cg_id = cg.id
     left join customCategory c1 on LEFT(cg.class_id, 4) = c1.class_id and LEN(c1.class_id) =4
     left join customCategory c2 on LEFT(cg.class_id, 6) = c2.class_id and LEN(c2.class_id) =6 
     left join customCategory c3 on LEFT(cg.class_id, 8) = c3.class_id and LEN(c3.class_id) =8                     
     left join Company    y on b.y_id = y.company_id
     left join region     r on y.region_id = r.region_id               
     where sd.dateid >  @nMinDateid  and (@y_id = 0 or y.company_id = @y_id)     
                
   return 0
GO
