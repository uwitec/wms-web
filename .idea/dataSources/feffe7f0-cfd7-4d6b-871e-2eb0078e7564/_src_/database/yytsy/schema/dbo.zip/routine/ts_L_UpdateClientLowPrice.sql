

/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_UpdateClientLowPrice
( @Pid         int,
  @Cid         varchar(100),
  @Yid         int,
  @Lowprice    NUMERIC(25,8),
  @istype      int        
 )	
AS
  declare @szsql varchar(1000)
  if @istype=0 
  begin
    delete from ClientLowPrice  where c_id in (select c.client_id from clients c where c.class_id like @Cid+'%') and p_id=@pid
    
    insert ClientLowPrice(p_id,c_id,Lowprice,Y_id)
    select @Pid,C.client_id,@Lowprice,@Yid from clients c where c.class_id like @cid+'%' and child_number=0
    
  end else

  if @istype=1
  begin
    update ClientLowPrice set Lowprice=@Lowprice  where p_id=@Pid and c_id =@cid and Y_id=@Yid
   

  end else

  if @istype=2
  begin  
   delete from ClientLowPrice where p_id=@pid and c_id =@cid and Y_id =@Yid
   
  end
GO
