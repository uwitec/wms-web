


CREATE  procedure ts_c_RetailToHis
(
	@nBillId numeric(10,0),
	@nNewBillId numeric(10,0) output,
	@nBillType smallint = 0 /*单据类型*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @nBillType is null  SET @nBillType = 0
/*Params Ini end*/
set nocount on

/*变量定义*/

if @nBillType not in(240, 243)
	select @nBilltype=billtype from retailbillidx where billid=@nBillId
/*变量定义end*/

/*销售类单据*/
if @nBilltype in (12,13,240,243) 
/*销售,销售退货,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,诊治费用*/
begin
    /*if @nBilltype in(12, 13)*/
    /*    update retailbillidx set guid = newid() where billid=@nBillId*/
    /*else*/
    if @nbillType in (240,243)
        set @nNewBillId = @nBillId
        
    if @nBilltype in(12, 13)
	begin	    
		if not exists(select * from retailbill where bill_id = @nBillId and p_id > 0)
			return -6

		insert into billdraftidx (billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
      		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,guid,SendQty,VIPCardID,invoiceTotal,Y_ID, RetailDate)
		SELECT convert(varchar(10),billdate,20), billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
		ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
      		posid, region_id, auditdate, skdate, jsye, jsflag, note, summary,guid,quantity,VIPCardID,invoiceTotal,Y_ID,billdate
		FROM retailbillidx where billid=@nBillId
		if @@rowcount=0 return -1
		select @nNewBillId=@@identity
	
		insert into salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,order_id,total,aoid,thqty,SendQty,SendCostTotal,PriceType,RowE_ID,YGUID,Y_ID,
		  InStoreTime,cxType,rowguid,batchbarcode,scomment,batchprice, CxGuid, orgbillid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
		SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,0,total,aoid, quantity, 
		  quantity ,(quantity*costprice)
		   ,priceType,RowE_ID,NEWID(),Y_ID,InStoreTime,cxType,rowguid,batchbarcode,scomment,batchprice, CxGuid, orgbillid,factoryid,
		   costtaxprice,costtaxrate,quantity*costtaxprice
		FROM retailbill
 		where bill_id=@nBillid	
		if @@rowcount=0 return -1
	end
	else
	if @nbillType in (240)	/*挂号单*/
	begin
		insert into salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,order_id,total,aoid,thqty,SendQty,SendCostTotal,PriceType,RowE_ID,YGUID,Y_ID,InStoreTime,cxType,rowguid)
		SELECT bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,0,total,aoid, quantity, 
		  quantity ,(quantity*costprice)
		   ,priceType,RowE_ID,NEWID(),Y_ID,InStoreTime,cxType,rowguid
		FROM Registerbilldrf
 		where bill_id=@nBillid	
		if @@rowcount=0 return -1
	end
	else
	if @nbillType in (243)	/*诊治费用单*/
	begin
		insert into salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,order_id,total,aoid,thqty,SendQty,SendCostTotal,PriceType,RowE_ID,YGUID,Y_ID,InStoreTime,cxType,rowguid)
		SELECT bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
		  totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		  qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		  comment,unitid,taxrate,0,total,aoid, quantity, 
		  quantity ,(quantity*costprice)
		   ,priceType,RowE_ID,NEWID(),Y_ID,InStoreTime,cxType,rowguid
		FROM retailClinicbilldrf
 		where bill_id=@nBillid	
		if @@rowcount=0 return -1
	end
	
	return	0
end
/*销售类单据*/
GO
