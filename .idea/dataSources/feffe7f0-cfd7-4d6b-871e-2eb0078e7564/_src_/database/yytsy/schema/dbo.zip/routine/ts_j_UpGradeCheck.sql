/************************************************************

--功能：pos前台数据合并为后台零售单   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_UpGradeCheck]
	(
	 @nUse integer
        )
AS 


declare @Y_ID int, @szYClassID varchar(30)
if @nUse = 1
begin
  select @Y_ID = cast(sysvalue as int) from sysconfig where upper([sysname]) = 'Y_ID'
  select @szYClassID = cast(sysvalue as int) from sysconfig where upper([sysname]) = 'YCLASSID'
  if @Y_ID is null set @Y_ID = 0 
  if @Y_ID = 0
  begin
    RAISERROR('未设置当前机构，请在系统设置中指定当前机构',16,1)
    return-1	
  end
 
 if exists(select * from storages where Y_ID = 0 and class_id <>'000000' and deleted = 0)
 begin
    RAISERROR('存在未指定机构的仓库，请在仓库资料中指定隶属机构',16,1)
    return-1	
 end

end


if @nUse = 0
begin
  select @Y_ID = company_id, @szYClassID = class_id from company where class_id = '000001'
  if @Y_ID is null set @Y_ID = 0 
  if @Y_ID = 0
  begin
    RAISERROR('基本数据结构机构表未升级成功，请重新升级数据库',16,1)
    return -1	
  end
end

return 0
GO
