
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-12-19*/
/* Description:	定制销售排行榜*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepDZSaleSort]
	@BeginDate 	  DATETIME,/*开始时间*/
	@EndDate	 	  DATETIME,/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szParent_ID	VARCHAR(30)='',/*产品父类ID*/
	@szListFlag		VARCHAR(1)='L',/*分级显示*/
	@nSortType    INT=0,           /*查询分级*/
	@dMlTotal			NUMERIC(25,8) OUTPUT,/*总销售金额*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
	@nLocation_Id   INT=0,        /*货位ID*/
    @nYClassid                 varchar(100)='',
    @nloginEID               int=0,
    @nR_id   int = 0 /*片区*/
AS
BEGIN
/*Params Ini begin*/
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szParent_ID is null  SET @szParent_ID = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @nSortType is null  SET @nSortType = 0
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @nLocation_Id is null  SET @nLocation_Id = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @nR_id is null  SET @nR_id = 0
/*Params Ini end*/
	SET NOCOUNT ON;

SELECT     pt.Unitname1, pt.class_id, pt.serial_number, pt.name, pt.alias, pt.retailprice, pt.standard, pt.Factory AS makearea, pt.deduct, pt.TC1, pt.TC2, pt.tcmoney, 
                      pt.Inputman, pt.Inputdate, pt.SHQTY, ISNULL(bx.quantity, 0) AS quantity, ISNULL(bx.SaleTotal, 0) AS SaleTotal, ISNULL(bx.taxtotal, 0) AS taxtotal, 
                      ISNULL(bx.SendQTY, 0) AS SendQTY, ISNULL(bx.SendCostTotal, 0) AS SendCostTotal, CAST(ISNULL(bx.SendTotal, 0) AS NUMERIC(25,8)) AS SendTotal, 
                      CAST(ISNULL(bx.CostTotal, 0) AS numeric(18, 8)) AS CostTotal, ABS(CASE WHEN ISNULL(SUM(SendQTY), 0) <> 0 THEN ISNULL(SUM([SendCostTotal]), 
                      0) / ISNULL(SUM(SendQTY), 0) ELSE 0 END) AS CostPrice, ISNULL(bx.taxtotal - bx.SaleTotal, 0) AS setotal, ISNULL(bx.SendTotal - bx.SendCostTotal, 0) 
                      AS mltotal, CAST(ISNULL((bx.SendTotal - bx.SendCostTotal) / bx.SendTotal * 100, 0) AS NUMERIC(25,8)) AS ratio, CAST(ISNULL((bx.SendTotal - bx.SendCostTotal) 
                      / bx.SendTotal * 100, 0) AS NUMERIC(25,8)) AS mlrate, pt.p_id AS product_id, pt.child_number, pt.Custompro1, pt.Custompro2, pt.Custompro3, pt.Custompro4, 
                      pt.Custompro5
FROM         (SELECT     p.makearea, p.child_number, p.product_id AS p_id, p.class_id, p.serial_number, p.name, p.alias, ISNULL(c.retailprice, 0) AS retailprice, 
                                              p.standard, p.Factory, u.name AS Unitname1, p.deduct, p.TC1, p.TC2, p.tcmoney, p.Inputman, p.Inputdate, ISNULL(SUM(s.quantity), 0) 
                                              AS SHQTY, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, p.Custompro5
                       FROM          dbo.storehouse AS s RIGHT OUTER JOIN
                                              dbo.products AS p LEFT OUTER JOIN
                                              dbo.unit AS u INNER JOIN
                                              dbo.price AS c ON u.unit_id = c.u_id ON p.product_id = c.p_id AND p.unit1_id = u.unit_id ON s.p_id = p.product_id
                       GROUP BY p.makearea, p.child_number, p.product_id, p.class_id, c.retailprice, p.name, p.serial_number, p.alias, p.standard, p.Factory, u.name, 
                                              p.deduct, p.TC1, p.TC2, p.tcmoney, p.Inputman, p.Inputdate, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                                              p.Custompro5
                       HAVING      (p.class_id LIKE @szpclass_id)
                        AND (p.Factory LIKE @szcclass_id)) AS pt LEFT OUTER JOIN
                          (SELECT     p_id, SUM(quantity * dir) AS quantity, SUM(totalmoney * dir) AS SaleTotal, SUM(taxtotal * dir) AS taxtotal, SUM(SendQTY * dir) 
                                                   AS SendQTY, SUM(SendCostTotal * dir) AS SendCostTotal, SUM(SendQTY * totalmoney / quantity * dir) AS SendTotal, 
                                                   SUM(quantity * costprice * dir) AS CostTotal
                            FROM          (SELECT     stm.p_id, stm.quantity, stm.costprice, stm.totalmoney, stm.taxtotal, stm.SendQTY, stm.SendCostTotal, B.billtype, 
                                                                           CASE WHEN b.billtype IN (10, 12, 32, 112, 53, 16, 210) THEN 1 ELSE - 1 END AS dir
                                                    FROM          dbo.salemanagebill AS stm INNER JOIN
                                                                           dbo.billidx AS B ON B.billid = stm.bill_id LEFT OUTER JOIN
                                                                           dbo.employees AS RE ON RE.emp_id = stm.RowE_id LEFT OUTER JOIN
                                                                           dbo.storages AS S ON S.storage_id = stm.ss_id LEFT OUTER JOIN
                                                                           dbo.clients AS C ON B.c_id = C.client_id LEFT OUTER JOIN
                                                                           dbo.employees AS E ON B.inputman = E.emp_id LEFT OUTER JOIN
                                                                           dbo.company AS Y ON Y.company_id = B.Y_ID LEFT OUTER JOIN
                                                                           dbo.Region AS R ON B.region_id = R.region_id
                                                    WHERE      (B.billtype IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)) AND (stm.p_id > 0) AND (B.billstates = 0) AND (stm.AOID IN (0, 
                                                                           5)) AND (B.billdate BETWEEN @BeginDate AND @EndDate) AND (B.region_id BETWEEN CASE @nR_ID WHEN 0 THEN 0 ELSE @nR_ID END AND 
                      CASE @nR_ID WHEN 0 THEN 0x7fffffff ELSE @nR_ID END)) AS bi
                            GROUP BY p_id) AS bx ON pt.p_id = bx.p_id
GROUP BY pt.class_id, pt.serial_number, pt.name, pt.alias, pt.retailprice, pt.standard, pt.Factory, pt.Unitname1, pt.deduct, pt.TC1, pt.TC2, pt.tcmoney, 
                      pt.Inputman, pt.Inputdate, pt.SHQTY, bx.quantity, bx.SaleTotal, bx.taxtotal, bx.SendQTY, bx.SendCostTotal, bx.SendTotal, bx.CostTotal, pt.p_id, 
                      pt.child_number, pt.makearea, pt.Unitname1, pt.Custompro1, pt.Custompro2, pt.Custompro3, pt.Custompro4, pt.Custompro5
HAVING      (pt.child_number = 0)
return 0
END
GO
