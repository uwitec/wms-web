







CREATE PROCEDURE [ts_L_insUserReport]
	(@ID		[int],
	 @Name	[varchar](50),
	 @Memo	[varchar](250),
	 @Data	[text],
	 @Type	[int],
	 @Tag		[int],
	 @Ins		[Char](1))
AS 

if Upper(@ins)='I'
begin
	if exists (select [Type] from UserReport where [Type]=@Type)
	begin
		UPDATE [UserReport] 
		
		SET	 [Name]  = @Name,
			 [Memo] = @Memo,
			 [Data]  = @Data,
			 [Type]  = @Type,
			 [Tag]	 = @Tag 
		WHERE 
			([Type]  = @Type)
	end else
	begin
		INSERT INTO [UserReport] 
			 ( [Name],
			 [Memo],
			 [Data],
			 [Type],
			 [Tag]) 
		 
		VALUES 
			( @Name,
			 @Memo,
			 @Data,
			 @Type,
			 @Tag)
	end	
end else
begin
	DELETE [UserReport]	WHERE  [Type]	 = @Type
end
GO
