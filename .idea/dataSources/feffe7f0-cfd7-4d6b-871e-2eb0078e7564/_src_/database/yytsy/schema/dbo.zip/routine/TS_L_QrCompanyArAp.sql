



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
机构应收账款、应付账款
********************************************/
CREATE PROCEDURE TS_L_QrCompanyArAp
( @szYClassid  	VARCHAR(30)='000000',
  @szListFlag CHAR(1)='L',
  @BeginDate  varchar(50),
  @EndData    varchar(50),
  @EClass_id  varchar(30)='',
  @nloginEID  int=0,
  @szY_id     int=0,
  @ncompanyarap int=0    /*机构应收应付是否分开查询 0：不分开 1：分开 2010-04-14*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szYClassid is null  SET @szYClassid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @EClass_id is null  SET @EClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @szY_id is null  SET @szY_id = 0
if @ncompanyarap is null  SET @ncompanyarap = 0    /*机构应收应付是否分开查询 0：不分开 1：分开 2010-04-14*/
/*Params Ini end*/
SET NOCOUNT ON

  Declare @Companytable INTEGER,@SONNUM INTEGER
  Declare @SQLScript varchar(8000)
  declare @y_id int
  select @Y_ID=@szY_id
  
 
  create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      
      insert #Companytable (id) values(2)  /*解决分支机构能查到对总公司的应付账款*/
   end
/*---分支机构授权*/

if @ncompanyarap=0
begin
select Y.* into ##YArAp from

(SELECT b.YClass_id,
    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal]
    FROM (
    SELECT a.[YClass_ID],
    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])>0 THEN SUM(a.[Artotal]-a.[Aptotal]) ELSE 0 END, 0) AS [Artotal], 
    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])<0 THEN -(SUM(a.[Artotal]-a.[Aptotal])) ELSE 0 END, 0) AS [Aptotal], 
    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])>0 THEN SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowArTotal], 
    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])<0 THEN -SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowApTotal], 
    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal]
    FROM (select * from ( select isnull(Y.class_id,'') as YClass_ID,Y.Child_Number,Y.Deleted,Yb.* 
		          FROM CompanyBalance Yb 
			  left join company y on y.company_id = yb.c_id  
                          where c_id<>@Y_id and Y_id=@Y_id
			 ) aa
                     WHERE [Child_Number]=0 AND [Deleted]<>1  and ((@szYClassid in ('','000000'))or (YClass_ID like @szYClassid+'%'))
          ) a 

          LEFT JOIN
          ( SELECT AD.[YClass_ID] AS Class_ID,
             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginApTotal],

             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate] BETWEEN @BeginDate AND @EndData THEN [JdMoney] END), 0) AS [NowArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate] BETWEEN @BeginDate AND @EndData THEN [JdMoney] END), 0) AS [NowApTotal], 

             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<=@EndData THEN [JdMoney] END), 0) AS [EndArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<=@EndData THEN [JdMoney] END), 0) AS [EndApTotal]

             FROM (SELECT [BILLID], [AClass_ID], [JdMoney],isnull(Y.class_id,'') as YClass_id FROM VW_C_ADetail 
                    Left join Company Y on c_id=Y.Company_id
                    WHERE [AClass_ID] IN ('000001000010', '000002000007') and Y_id=@Y_id) AD
             INNER join 
                  (SELECT [BillID], [BillDate],[eclass_id] FROM VW_C_BILLIDX 
                    WHERE [BillStates]='0' and billtype in (150,151,155,160,161,165,171,172,173,174)
                    and Y_id=@Y_id
                    and (@EClass_id='' or eclass_id like @EClass_id+'%')
                   ) BI
             on BI.[BILLID]=AD.[BILLID]
             GROUP BY AD.[YClass_ID]) b
          ON a.[YClass_ID]=b.[Class_ID]  GROUP BY a.[YClass_ID]
) b   GROUP BY b.[YClass_ID]
)Y
end
else  
begin
  select Y.* into ##YArAp1 from

  (SELECT b.YClass_id,
    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal]
    FROM (
    SELECT a.[YClass_ID],
    ISNULL(SUM(a.[Artotal]) , 0) AS [Artotal], 
    ISNULL(SUM(a.[Aptotal]) , 0) AS [Aptotal], 
    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)), 0) AS [BeginArTotal], 
    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[BeginApTotal], 0)), 0) AS [BeginApTotal], 
    ISNULL(SUM(b.[NowArTotal]) , 0) AS [NowArTotal], 
    ISNULL(SUM(b.[NowApTotal]) , 0) AS [NowApTotal], 
    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)), 0) AS [EndArTotal], 
    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[EndApTotal], 0)), 0) AS [EndApTotal]
    FROM (select * from ( select isnull(Y.class_id,'') as YClass_ID,Y.Child_Number,Y.Deleted,Yb.* 
		          FROM CompanyBalance Yb 
			  left join company y on y.company_id = yb.c_id  
                          where c_id<>@Y_id and Y_id=@Y_id
			 ) aa
                     WHERE [Child_Number]=0 AND [Deleted]<>1  and ((@szYClassid in ('','000000'))or (YClass_ID like @szYClassid+'%'))
          ) a 

          LEFT JOIN
          ( SELECT AD.[YClass_ID] AS Class_ID,
             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<@BeginDate THEN [JdMoney] END), 0) AS [BeginApTotal],

             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate] BETWEEN @BeginDate AND @EndData THEN [JdMoney] END), 0) AS [NowArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate] BETWEEN @BeginDate AND @EndData THEN [JdMoney] END), 0) AS [NowApTotal], 

             ISNULL(SUM(CASE WHEN [AClass_ID]='000001000010' AND [BillDate]<=@EndData THEN [JdMoney] END), 0) AS [EndArTotal], 
             ISNULL(SUM(CASE WHEN [AClass_ID]='000002000007' AND [BillDate]<=@EndData THEN [JdMoney] END), 0) AS [EndApTotal]

             FROM (SELECT [BILLID], [AClass_ID], [JdMoney],Y.class_id as Yclass_id FROM VW_C_ADetail
                   Left join Company Y on C_id=Y.Company_id 
                   WHERE [AClass_ID] IN ('000001000010', '000002000007') and Y_id=@Y_id) AD
             inner join
                  (SELECT [BillID], [BillDate],[eclass_id] FROM VW_C_BILLIDX 
                    WHERE [BillStates]='0' and billtype in (150,151,155,160,161,165,171,172,173,174)
                    and Y_id=@Y_id
                    and (@EClass_id='' or eclass_id like @EClass_id+'%')
                   ) BI
 
             on BI.[BILLID]=AD.[BILLID]
             GROUP BY AD.[YClass_ID]) b
          ON a.[YClass_ID]=b.[Class_ID]  GROUP BY a.[YClass_ID]
        ) b   GROUP BY b.[YClass_ID]
   )Y
end

  SELECT @SONNUM=[Child_Number] FROM Company WHERE [Class_ID]=@szYClassid

  IF @SONNUM>0
  BEGIN
    IF @szListFlag='L'  SET @SQLScript=' ON LEFT(b.[Yclass_id], LEN(Y.[class_id]))=Y.[class_id]  WHERE Y.[parent_id]='+CHAR(39)+@szYClassid+CHAR(39)
    IF @szListFlag='A'  SET @SQLScript=' ON b.[Yclass_id]=Y.[class_id] WHERE Y.[child_number]=0 AND Y.[class_id]<>''000000'''
    IF @szListFlag='P'  SET @SQLScript=' ON b.[yclass_id]=Y.[class_id]
			WHERE LEFT(Y.[class_id], LEN('+CHAR(39)+@szYClassid+CHAR(39)+'))='+CHAR(39)+@szYClassid+CHAR(39)
      +' AND Y.[child_number]=0'
  END
  ELSE
  BEGIN
    SELECT @SQLScript=' ON B.[YClass_id]=Y.[Class_id] where Y.[Class_id]='+CHAR(39)+@szYClassid+CHAR(39)  
  END

  if @ncompanyarap=0
  begin 
  SELECT @SQLScript=
     ' select Y.[Company_ID],Y.[Parent_id], Y.[Class_ID], Y.[Child_number], Y.[Name],
              Y.[Alias], Y.[Serial_number], Y.[tel], Y.[opaddress], Y.[manager],
              ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	      ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	      ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	      ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	      ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	      ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	      ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	      ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal] 
        from (select * from Company where Company_id<>'+cast(@Y_id as varchar(50))+' and deleted=0 and 
            ('+CAST(@CompanyTable AS varchar(50))+'=0 or (Company_id in (select [id] from #Companytable)))
            )Y LEFT JOIN ##YArAp b '+@SQLScript+
         ' GROUP BY Y.[Company_ID],Y.[Parent_id], Y.[Class_ID], Y.[Child_number], Y.[Name],
              Y.[Alias], Y.[Serial_number], Y.[tel], Y.[opaddress], Y.[manager]'

  end
  else 
   
  SELECT @SQLScript=
     ' select Y.[Company_ID],Y.[Parent_id], Y.[Class_ID], Y.[Child_number], Y.[Name],
              Y.[Alias], Y.[Serial_number], Y.[tel], Y.[opaddress], Y.[manager],
              ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	      ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	      ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	      ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	      ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	      ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	      ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	      ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal] 
        from (select * from Company where Company_id<>'+cast(@Y_id as varchar(50))+' and deleted=0 and 
            ('+CAST(@CompanyTable AS varchar(50))+'=0 or (Company_id in (select [id] from #Companytable)))
            )Y LEFT JOIN ##YArAp1 b '+@SQLScript+
         ' GROUP BY Y.[Company_ID],Y.[Parent_id], Y.[Class_ID], Y.[Child_number], Y.[Name],
              Y.[Alias], Y.[Serial_number], Y.[tel], Y.[opaddress], Y.[manager]'
  

 /*print (@SQLScript)*/
   exec(@SQLScript)
GOTO SUCCEE
SUCCEE:
  /*drop table ##YArAp*/
  /*drop table ##YArAp1*/
  if @ncompanyarap =0   drop table ##YArAp       
  if @ncompanyarap <>0  drop table ##YArAp1
 RETURN 0
GO
