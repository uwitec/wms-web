
CREATE VIEW dbo.VW_H_SpecialProducts
AS
SELECT     ISNULL(u.name, '') AS UnitName, ISNULL(a.name, '') AS AccountName, 0 AS recprice, 0 AS price1, 0 AS price2, 0 AS price3, 0 AS VIPPrice, 
                      0 AS specialprice, 0 AS lowprice, e.name AS EmpName, sp.product_id, sp.class_id, sp.parent_id, sp.child_number, sp.child_count, sp.serial_number, 
                      sp.name, sp.alias, sp.modal, sp.unit_id, sp.comment, sp.deleted, sp.pinyin, sp.EngName, sp.RowIndex, sp.AccountID, sp.Emp_ID, sp.InputDate, 
                      sp.ModifyDate, sp.RetailPrice, sp.serial_number AS Code
FROM         dbo.SpecialProducts AS sp INNER JOIN
                      dbo.employees AS e ON sp.Emp_ID = e.emp_id LEFT OUTER JOIN
                      dbo.unit AS u ON sp.unit_id = u.unit_id LEFT OUTER JOIN
                      dbo.account AS a ON sp.AccountID = a.account_id
WHERE     (sp.deleted = 0)
GO
