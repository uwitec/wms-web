

/*2.表i_store_in (导入入库明细记录) */
/*单据包括:采购入库单,销售退货单,零售退货单. */
/*退货数量显示为负 */
              
CREATE VIEW VW_I_STORE_IN
AS

SELECT

	1 as id,           			/*//numeric(18, 0)  identity,(自增列)生成导入值时?        */
	ISNULL(B.billNumber,' ') as in_fph,     /*//varchar(30)     not null,(票据号)*/
	B.billDate  as  in_date,      		/*//datetime        not null,(入库日期)*/
	ISNULL(C.serial_number,' ') as mer_search,  /*   //varchar(20)         null,(供货商检索码)*/
	ISNULL(C.name,' ') as mer_name,     	/*//varchar(50)     not null,(供货商名称?)*/
	' ' as jg_type,      			/*//varchar(60)         null,(机构类型)取值见下面附3.*/
	ISNULL(C.licence_No,' ') as work_no,    /*//varchar(50)         null,(经营许可证号)*/
	ISNULL(R.RangeName,' ') as cat_name,     	/*//varchar(20)     not null,(药品大类)取值：西药、中成药、中草药、材料、保健品、器械)*/
	' ' as item_search,  			/*//varchar(20)         null,(项目化学名称检索码)*/
	ISNULL(P.ChemName,' ') as item_name,    		/*//varchar(60)     not null,(项目化学名称)*/
	ISNULL(P.serial_number,' ') as  trade_search, 	/*//varchar(20)         null,(项目通用名称检索码)*/
	ISNULL(P.Name,' ') as trade_name,   	/*//varchar(60)         null,(项目通用名称)*/
	ISNULL(m.medtype,' ') as jx_name,      	/*//varchar(16)         null,(剂型名)取值见下面附1.剂型名称一览*/
	ISNULL(P.standard,' ') as standard,     /*//varchar(50)         null,(规格)*/
	ISNULL(U.NAME,' ') as unit,        	/*//varchar(10)     not null,(单位)*/
	' ' as mfr_search ,  			/*//varchar(10)         null,(厂家名称检索码)*/
	ISNULL(P.Factory,' ') as mfr_name,     	/*//varchar(40)     not null,(厂家名称)  */
	ISNULL(P.PermitCode,' ') as wenhao,     /*//varchar(50)     not null,(批准文号)*/
	' ' as is_import,    			/*//char(1)             null,(1 进口 0 非进口)*/
	ISNULL(R.RangeName,' ') as rang_name,    	/*//varchar(60)     not null,(产口所属范围)取值见下面附2.产品所属范围名称一览*/
	ISNULL(PD.BatchNo,' ') as ypph,         	/*//varchar(30)         null,(药品批号)*/
	PD.validdate as validate,     		/*//datetime            null,(有效期)*/
	(CASE WHEN B.BillType IN(20) THEN ABS(PD.QUANTITY) ELSE -ABS(ABS(PD.QUANTITY)) END) as num,         
        /*//decimal(10, 3)  not null,(数量)*/
	ISNULL(PD.price ,0.000) price,        			/*//decimal(10, 3)  DEFAULT  0  null,(进价)*/
	ISNULL(E.serial_number ,' ') as usercode     			/*//varchar(10)     not null,(操作员编号)*/

FROM  ProductDetail 	PD
INNER JOIN BillIDX 	B 	ON	PD.BillID = B.BillID
INNER JOIN PRODUCTS 	P	ON	P.PRODUCT_ID = PD.P_ID
LEFT  JOIN Clients      C	ON	C.Client_id = PD.Supplier_Id
left  join VW_Range r on p.product_id = r.product_id
left   join VW_MedType m on p.product_id = m.product_id
LEFT  JOIN UNIT		U	ON	PD.UNITID = U.UNIT_ID 
LEFT  JOIN EMPLOYEES	E	ON	B.INPUTMAN=E.EMP_ID
WHERE B.BillType in (20,11,13)
/* 采购入库单,销售出库退货单,零售退货单*/
GO
