create procedure ts_e_WMSQrSelectHoldAndCheck
 @WhereStr varchar (100)='',
 @type varchar(100)=''
as
begin
  if @type='ZCQ' 
  begin
    select  a.Code as zcqcode,a.name as zcqname,a.PinYin as zcqpy ,
			case a.billtype when 0 then '无' when 1 then   '销售出库' when 2 then '门店配送' when 3 then '采购退货' when 4 then '其它出库' end as billtype,
			case a.CyFs when 0 then '自提' when 1 then '企业配送' when 2 then '委托运输' end as cyfstype, 
			case a.priority when 0 then '一般' when 1 then '补货' when 2 then '优先' when 3 then '急救' end as yxjtype,
			case a.LockStatus when 0 then '否' when 1 then '是' end as lockstatus,
			case isnull(b.RoadName,'') when '' then '全部' else isnull(b.RoadName,'') end  as PSRoad,
			a.ID as Store_ZCQ_ID,case a.ifHold when 0 then '否' else '是' end as ifexithold
		    from WMSHold a 
			left join sendRoad b on a.roadid=b.roadid
		    where (a.Code like '%'+@WhereStr+'%'  or a.name like  '%'+@WhereStr+'%' or a.PinYin like '%'+@WhereStr+'%') and
	   	    a.deleted in (0,2)
  end
  if @type='FHT' 
  begin
      select isnull(a.Code,'') as FHTcode, isnull(a.name,'') as FHTname, isnull(a.PinYin,'') as FHTpy ,a.S_id as Store_id,
    				 a.ID as Store_FHT_id,
					 isnull(a.GroupCode,'') as groupnum,Case a.deleted when 0 then '启用' when 2 then '停用' end as fhtstatus,
					 case a.ifuse when 0 then '否' when 1 then  '是' end as ifuse,
					 isnull(a.BillNum,0) as billnum,isnull(a.WorkNum,'') as worknum,
					 isnull(ContainerNo,'') as trunoversn,case IfHold when 0 then '否' when 1 then '是' end as ifexistarea,
					 isnull(a.PgNum,0) as pgnum,a.LockBillNum as lockbillnum,case a.Deleted when 0 then 0 when 2 then 1 end as deleted,
					 isnull(a.IfHold,0) as IfHold
					 from WMSCheckBaseInfo a 
			    	 where (a.Code like '%'+@WhereStr+'%'  or a.name like  '%'+@WhereStr+'%' or a.PinYin like '%'+@WhereStr+'%') and
				     a.deleted in (0,2)
  end 
end
GO
