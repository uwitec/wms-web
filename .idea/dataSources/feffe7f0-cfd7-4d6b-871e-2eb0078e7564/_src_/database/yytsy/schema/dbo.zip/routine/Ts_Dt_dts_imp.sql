/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-05-16*/
/* Description:	门店写入总部下传数据*/
/* 单体门店数据库使用*/
/* =============================================*/
CREATE PROCEDURE [dbo].[Ts_Dt_dts_imp]
  @e_id int
AS
BEGIN
  set nocount on
  begin tran
  declare @c_id int
  set @c_id =isnull((select client_id from clients  where name='总公司配送' and deleted=0 ),0)   
  /*-插入上次未添加的商品  */
  insert into  Dtmangedatadts 
  select * from DtmangedatadtsINI   where RowGUID not in(select RowGUID from Dtmangedatadts)
  /*--修改配送的商品是否存在基本资料中  1:存在 0:需要添加*/
  update Dtmangedatadts  set isvalid=1
  from Dtmangedatadts a, products b
  where a.proname=b.name and a.permitcode=b.permitcode and b.deleted=0
  /*--删除 已经过账和已经在草稿箱中的数据*/
  delete billdtsidx  where billid in (select b.billid from billidx a,billdtsidx b  where a.GUID=b.GUID)
  delete billdtsidx  where billid in (select b.billid from billdraftidx a,billdtsidx b  where a.GUID=b.GUID)
  
  delete salemanagebilldts where bill_id  not in (select billid from billdtsidx )
  /*-修改主表数据  */
  update billdtsidx set note='公司配送',GatheringMan=0,billstates=2,billtype=20,c_id=@c_id,sin_id=0,
         sout_id=0,e_id=@e_id,inputman=@e_id,auditman=0          
  where billtype=10
  /*-修改明细  修改 商品ID,基本单位*/
  update salemanagebilldts  set p_id=x.product_id,unitid=x.unit_id
  from(
  select a.product_id,a.name,a.permitcode,b.magbillid,d.unit_id,a.deleted
  from products a 
  inner join Dtmangedatadts b  on a.name=b.proname
  inner join Dtmangedatadts c  on a.permitcode=c.permitcode
  left  join unit d            on d.name  = c.unitname
  ) x,salemanagebilldts y 
  where   x.magbillid=y.smb_id   and x.deleted=0 
  /*---插入草稿箱*/
  insert into billdraftidx
  (
  billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty  
  )
  select billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty
  from billdtsidx
  /*明细*/
  insert into buymanagebilldrf
  (
   bill_id,p_id,batchno,quantity,costprice,discount,discountprice,totalmoney,
   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,price_id,
   ss_id,sd_id,location_id,supplier_id,commissionflag,comment,unitid,taxrate,order_id,total,iotag,
   InvoiceTotal,thqty,newprice,orgbillid,AOID,jsprice,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
   RowGuid,RowE_id,YCostPrice,YGuid,Y_ID,transflag,instoretime,comment2,BatchBarCode,
   scomment,batchprice,buyprice
  )
  select    
  bill_id,p_id,batchno,quantity,discountprice,discount,discountprice,totalmoney,
   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,price_id,
   ss_id,sd_id,0 as location_id,supplier_id,commissionflag,comment,unitid,taxrate,order_id,total,iotag,
   InvoiceTotal,thqty,newprice,smb_id,AOID,jsprice,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
   RowGuid,RowE_id,YCostPrice,YGuid,Y_ID,transflag,instoretime,comment2,BatchBarCode,
   scomment,batchprice,discountprice
  from salemanagebilldts 
  /*--修改billid*/
  update buymanagebilldrf set bill_id=newbillid
  from ( select  b.billid as newbillid,a.billid as oldbillid 
  from billdtsidx a,billdraftidx b
  where a.GUID=b.GUID and b.billtype=20 and b.note='公司配送'  
  ) x,buymanagebilldrf y
  where x.oldbillid=y.bill_id
  /*--  */
  update Dtmangedatadts set  billid=b.bill_id ,magbillid=b.smb_id
  from  Dtmangedatadts a,buymanagebilldrf b
  where a.RowGuid=b.RowGuid     
commit Tran  

END
GO
