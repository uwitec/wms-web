

create procedure ts_M_Autobill   /*单据过账时自动调用 自动生成内部调拨单和配送单*/
(
@nbillid int,
@nE_id int,
@y_id int
)
as 
declare @newbillid int  ,@location_id int, @s_id int,@ss_id int ,@nP_id INT,@nReturnNumber INT
/*set @Y_id=2*/
/*set @nE_id=1*/
/*取得零货库,发货区唯一货位  */
 /**/
 select top 1 @s_id=storage_id from storages where wholeflag=2
 select @location_id=min(loc_id)
 from location
 where s_id=@s_id and deleted=0 and loctype=1 /*发货货位类型*/
      and loc_id not in (select location_id2 from  storemanageBilldrf s,BillDraftidx b where s.bill_id=b.billid and b.billtype in (44)
    UNION 
    select location_id  from  storemanageBilldrf s,BillDraftidx b where s.bill_id=b.billid and b.billtype in (44)
    UNION 
    select location_id  from  salemanageBilldrf s,BillDraftidx b where s.bill_id=b.billid and b.billtype in (212)
    )
 select @location_id=isnull(@location_id,0)
 if @location_id=0 
 BEGIN
    RAISERROR ('无空余可用发货货位，请在货位管理中添加', 16, 1)
    return -1
 END

/*按仓库不同,生成内部移库单,至指定货位,--注明原单号*/
 declare curp cursor scroll for
 select  distinct ss_id
 from salemanagebill s,billidx b where b.billid=s.bill_id  and billtype=210 and billstates=0 and b.billid=@nbillid
 
 open curp
 fetch next from curp into @ss_id
 while  @@fetch_status=0
 begin
  
  INSERT INTO BillDraftidx
  (
  billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
  ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
  department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
  jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id,ZBAuditMan,ZBAuditDate
  )
  select  b.billdate,'',44,0,b.c_id,@nE_id,@ss_id,@s_id,@nE_id,@nE_id,
  isnull(s.costtotal,0),isnull(s.costtotal,0),0,isnull(s.quantity,0),0,0,2,0,
  0,0  ,0 ,0 ,0  ,0,'由销售单自动生成内部移库 '+ c.name+b.billnumber  ,'' ,
  0,0 ,'',0, 0,0,isnull(s.quantity,0),0,@Y_id,ZBAuditMan,ZBAuditDate
  
  from billidx b left join 
   (select bill_id, isnull(sum(costprice*quantity),0) costtotal,isnull(sum(quantity),0) quantity 
   from  salemanagebill  where  ss_id=@ss_id  and bill_id=@nbillid  group by bill_id) s
   on  b.billid=s.bill_id
  left join clients c  on  c.client_id=b.c_id
  where  billtype=210 and billstates=0 and b.billid=@nbillid
   

  SET  @newbillid=@@IDENTITY
  
  
  INSERT INTO storemanageBilldrf
  (
   bill_id  ,p_id  ,batchno  ,quantity  ,costprice,costtotal  ,price ,totalmoney  ,retailprice  ,
   retailmoney  ,makedate  ,validdate  ,price_id ,ss_id ,sd_id ,location_id  ,supplier_id  ,
   commissionflag  ,comment  ,unitid ,location_id2, qualitystatus,iotag, total, invoiceTotal , 
    OrgBillID,Aoid,SendQTY,SendCostTotal,Y_id, instoretime
  )
   select @newbillid 
   ,s.p_id  ,s.batchno  ,s.quantity  ,s.costprice,s.costprice*s.quantity  ,s.costprice ,s.costprice*s.quantity  ,0  ,
   0 , s.makedate  ,s.validdate  ,0 ,@ss_id  ,@s_id  ,s.location_id  ,s.supplier_id  ,
   s.commissionflag ,'由销售单自动生成内部移库 '+b.billnumber ,s.unitid  ,@location_id, '合格',0, s.costprice*s.quantity , 0 ,
   0,0,s.quantity,s.costprice*s.quantity ,s.Y_id, s.instoretime

  from salemanagebill s,billidx b ,clients c 
  where b.billid=s.bill_id  and billtype=210 and billstates=0 and ss_id=@ss_id and c.client_id=b.c_id and b.billid=@nbillid


  IF @@ROWCOUNT=0 Goto SysError
  
	insert msgcenter([msgtype],[billid],[billtype])
	values
	(1,@newbillid,44)

  /*自动记账(不用)*/
  
  /*EXECUTE ts_c_BillAudit @NEWbill_id,@nP_id output,@nReturnNumber output,44*/
  /*IF @nReturnNumber<>0 Goto SysError*/
  /*RETURN 0*/
      

 fetch next from curp into @ss_id
 end
 close curp 
 deallocate curp 

/*将指定发货位上的货,生成发货单 注明原单号*/

 INSERT INTO BillDraftidx
 (
 billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
 ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
 department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
 jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id,WholeQty,PartQty,ZBAuditMan,ZBAuditDate
 )
 select  b.billdate,'',212,0,b.c_id,@nE_id,@ss_id,@s_id,@nE_id,@nE_id,
 b.ysmoney,b.ysmoney,0,b.quantity,0,0,3,b.billid,
 0,0  ,0 ,0 ,0  ,0,'由销售单自动生成发货单 '+ c.name+b.billnumber  ,'' ,
 0,0 ,'',0, 0,0,b.quantity,0,@Y_id,b.WholeQty,b.PartQty,ZBAuditMan,ZBAuditDate
 
 from billidx b ,clients c 
 where  billtype=210 and billstates=0 and c.client_id=b.c_id and b.billid=@nbillid
 
 SET  @newbillid=@@IDENTITY
 INSERT INTO [salemanagebilldrf](
  [bill_id], [p_id], [batchno], [quantity], [costprice], [saleprice], [discount], [discountprice], [totalmoney], 
 [taxprice], [taxtotal], [taxmoney], [retailprice], [retailtotal], [makedate], [validdate], [qualitystatus], [price_id], 
 [ss_id], [sd_id], [location_id], [supplier_id], [commissionflag], [comment], [unitid], [taxrate], [order_id], [total], 
 [iotag], [InvoiceTotal], [thqty], [newprice], [orgbillid], [AOID], [jsprice], [invoice], [invoiceno], [PriceType], [SendQTY],
  [SendCostTotal],  [YCostPrice],  [Y_ID], [transflag], [instoretime],YGuid)

 SELECT   @newbillid, [p_id], [batchno], s.[quantity], [costprice], [saleprice], s.discount, [discountprice], [totalmoney],
  [taxprice], [taxtotal], [taxmoney], [retailprice], [retailtotal], [makedate], [validdate], [qualitystatus], [price_id], 
 @s_id, [sd_id], @location_id, [supplier_id], [commissionflag], '由销售单自动生成发货单 '+b.billnumber, [unitid], s.[taxrate],0, [total], 
 [iotag], s.[InvoiceTotal], [thqty], [newprice],  s.smb_id, [AOID], [jsprice],s.[invoice], s.[invoiceno], [PriceType], s.[quantity],
   s.[quantity]*s.costprice,  [YCostPrice],  s.[Y_ID],0, [instoretime],NEWID()
 from salemanagebill s,billidx b ,clients c 
 where b.billid=s.bill_id  and billtype=210 and billstates=0 and c.client_id=b.c_id and b.billid=@nbillid
 
 IF @@ROWCOUNT=0 Goto SysError1
 
 return 0

SysError:
 /*RAISERROR ('自动生成内部移库单错误!', 16, 1)*/
 RETURN -25

SysError1:
/* RAISERROR ('自动生成发货单错误!', 16, 1)*/
 RETURN -26
GO
