
CREATE	       PROCEDURE Ts_K_GetsysTnotes
(
	@iType      INT,  
	@iId        INT	
)
/*with encryption*/
AS
	IF @iType = 1 
	BEGIN
		SELECT s.Nid, s.magbillid, s.billtype, s.updateman, s.updatedate, s.notes,
		       s.remake, e.name AS ename, c.name AS cname
		FROM   (
		           SELECT * FROM   sysTnotes s WHERE  s.billtype = 1 AND s.magbillid = @iId
		       ) s
		       LEFT JOIN employees e
		            ON  s.updateman = e.emp_id
		       LEFT JOIN clients c
		            ON  s.magbillid = c.client_id
		ORDER BY
		       s.updatedate DESC
	END
	ELSE
    IF @iType = 0 
	BEGIN
		SELECT s.Nid, s.magbillid, s.billtype, s.updateman, s.updatedate, s.notes,
		       s.remake, e.name AS ename, c.name AS cname
		FROM   (
		           SELECT * FROM   sysTnotes s WHERE  s.billtype = 0 AND s.magbillid = @iId
		       ) s
		       LEFT JOIN employees e
		            ON  s.updateman = e.emp_id
		       LEFT JOIN products c
		            ON  s.magbillid = c.product_id
		ORDER BY
		       s.updatedate DESC	
	END
	ELSE
	BEGIN
		SELECT s.Nid, s.magbillid, s.billtype, s.updateman, s.updatedate, s.notes,
		       s.remake, e.name AS ename, c.name AS cname
		FROM   (
		           SELECT * FROM   sysTnotes s WHERE  s.billtype = 2 AND s.magbillid = @iId
		       ) s
		       LEFT JOIN employees e
		            ON  s.updateman = e.emp_id
		       LEFT JOIN company c
		            ON  s.magbillid = c.company_id
		ORDER BY
		       s.updatedate DESC	
	END
GO
