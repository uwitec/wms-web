/************************************************************

--功能: 
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_TaskListUpToDts]
( @y_id int = 0
)

AS 
/*Params Ini begin*/
if @y_id is null  SET @y_id = 0
/*Params Ini end*/
  truncate table TaskListUpDts
  
  delete tasklistUp where TranType = 1 and OperType = 0 and TableType in ('A', 'P', 'T','B')
  
  insert into tasklistupDts(taskdate,Y_ID,billguid,rowGuid,tabletype,OperType,tranType,tranflag,TGUID)
         select taskdate, Y_ID,BillGuid,RowGuid,TableType,OperType,TranType,Tranflag,TGUID
           from tasklistup where Trantype = 1 and tranflag = 1 and (@y_id = 0 or Y_ID = @y_id)  
  if @@Error <> 0 Return -1
GO
