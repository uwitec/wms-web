
/* =============================================*/
/* Author:  Huang.Y*/
/* Create date: 2011-4-14*/
/* Description: 新品采购查询*/
/* =============================================*/
CREATE PROCEDURE TS_H_RepBuyCount 
 @BeginDate  varchar(10) = '', 
 @EndDate  varchar(10) = '',
 @Storage  int = 0, 
 @Client   int = 0
AS
BEGIN
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @Storage is null  SET @Storage = 0
if @Client is null  SET @Client = 0
/*Params Ini end*/
 SET NOCOUNT ON;

 SELECT     b.p_id, p.serial_number, p.name, p.alias, p.standard, p.makearea,isnull(PB.e_name,'')e_name ,isnull(PB.C_Name,'')C_Name, CAST(ISNULL(m.name, '') AS varchar) AS mt_name, u.name AS unit, 
                      p.permitcode, SUM(b.quantity * CASE WHEN billtype IN (21, 221) THEN - 1 ELSE 1 END) AS quantity, SUM(b.totalmoney * CASE WHEN billtype IN (21, 
                      221) THEN - 1 ELSE 1 END) AS total, SUM(b.SendQTY * CASE WHEN billtype IN (21, 221) THEN - 1 ELSE 1 END) AS qty
 FROM         dbo.billidx AS i INNER JOIN
        dbo.buymanagebill AS b ON i.billid = b.bill_id INNER JOIN
        dbo.products AS p ON b.p_id = p.product_id INNER JOIN
        dbo.unit AS u ON p.unit1_id = u.unit_id LEFT OUTER JOIN
	    (
			select P_id as baseinfo_id,name from ProductCategory p  
			inner join customCategory c on p.PComent3 = c.class_id
			and c.deleted = 0 and Child_Number = 0 and Category_id = 3
	    )m on p.product_id = m.baseinfo_id left join 
        dbo.vw_productbalance  PB ON P.product_id = PB.p_id and i.Y_ID=PB.Y_id 
 WHERE     (p.buycount = 1) AND (i.billstates = '0') AND (i.C_ID = @Client OR @Client = 0) AND (b.ss_id = @Storage OR @Storage = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate)
		AND (i.Billtype in (20, 21, 220, 221))
 GROUP BY b.p_id, p.name, p.alias, p.standard, p.makearea, m.name, u.name, p.permitcode, p.serial_number,PB.e_name ,PB.C_Name 
END
GO
