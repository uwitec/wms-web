
/* =============================================*/
/* Author:		zjx*/
/* Create date: 2017.05.25*/
/* Description:	取得可开数量*/
/* =============================================*/
CREATE FUNCTION FN_WMSGetAvlqty 
(
	@nPid int ,
	@nSid int ,
	@sPname varchar(8000),
	@bStopSale int    /*这儿如果是3，表示不统计不合格品库*/
)
RETURNS 
@AvlQty TABLE 
(
    [s_id] [int] NOT NULL,
	[p_id] [int] NOT NULL,
	[supplier_id] [int] NOT NULL,
	[quantity] numeric(25,8) NOT NULL,
	[costprice] numeric(25,8) NOT NULL,
	[batchno] [varchar](20) NOT NULL,
	[makedate] [datetime] NOT NULL,
	[instoretime] [datetime] NOT NULL,
	[validdate] [datetime] NOT NULL,
	[commissionflag] [tinyint] NOT NULL,
	[Y_ID] [int] NOT NULL,
	[storeQty] numeric(25,8) NOT NULL,
	[BatchBarCode] [varchar](30) NOT NULL,
	[scomment] [varchar](80) NOT NULL,
	[batchprice]  numeric(25,8) NOT NULL,
	[factoryid] [int] not null,
	[costtaxprice]  numeric(25,8) not null,/*成本含税单价*/
	[costtaxtotal] numeric(25,8) NOT NULL,/*成本含税金额  --这儿金额不能作为批次的判断，每个单据的数量不同，金额肯定不同*/
	[costtaxrate]  numeric(25,8) NOT NULL/*成本税率*/
)
AS
BEGIN

	DECLARE @SFlag INT /*= 0   --为1表示不统计不合格品库，默认为0*/
        select @SFlag = 0/*zjx--2017-01-02-SQL2000不支持局部变量边定义边赋值*/
    
	IF @nPid IS NULL SET @nPid = 0
	IF @nSid IS NULL SET @nSid = 0
	IF @sPname IS NULL SET @sPname = ''
	IF @bStopSale IS NULL SET @bStopSale = 1
	
	if @bStopSale = 3   /*为3时特殊处理，不统计不合格品库*/
	begin
		set @SFlag = 1
		SET @bStopSale = 1    /*把@bStopSale置为默认状态*/
	end
	else
		set @SFlag = 0	

	DECLARE @nCalcMode int
	DECLARE @SplitBill int
	set @SplitBill=-1
    SELECT @SplitBill = sysvalue FROM sysconfigtmp WHERE sysname = 'YSendMergeBatchSplitBill'
	/*XXX。2017-01-12 用一个表变量来存储后面多次用函数调用的值,测试在数据量较小的情况下，几百条一下，速度加快很明显*/
	declare @tmp_FN_FindProducts TABLE (PRODUCT_ID int )

	SET @nCalcMode = -1

	SELECT @nCalcMode = sysvalue FROM sysconfig WHERE sysname = 'CheckSaleQty'
	insert  @tmp_FN_FindProducts
    SELECT PRODUCT_ID   FROM DBO.FN_FindProducts(@sPname) 

	IF @nPid = 0 AND @sPname = ''
		SET @nPid = -1

	/* 指定了PID*/
	IF @sPname = ''
	BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			    if @SplitBill=0
			    begin
						INSERT INTO @AvlQty
						SELECT  s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
										commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
										MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
						FROM      (
									   SELECT   s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
														 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
										FROM      dbo.storehouse
										WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
										UNION ALL
										SELECT  b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
														 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.OrderBill AS b INNER JOIN
														 dbo.orderidx AS i ON b.bill_id = i.billid
										WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
										UNION ALL
										SELECT   sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
														 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.storemanagebilldrf AS sb INNER JOIN
														 dbo.billdraftidx AS b ON sb.bill_id = b.billid
										WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
										UNION ALL
										SELECT  b.S_id,  b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
														 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.GSPbilldetail AS b INNER JOIN
														 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
										UNION ALL
										SELECT   b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
														 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
										FROM      dbo.GSPbilldetail AS b INNER JOIN
														 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								
									) AS a
						  GROUP BY  s_id,p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			     end
			     else
			     begin
			            INSERT INTO @AvlQty
						SELECT  0 as s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
										commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
										MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
						FROM      (
									   SELECT    p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
														 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
										FROM      dbo.storehouse
										WHERE   (@nPid = -1 OR p_id = @nPid) AND (((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
										UNION ALL
										SELECT   b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
														 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.OrderBill AS b INNER JOIN
														 dbo.orderidx AS i ON b.bill_id = i.billid
										WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid)
										UNION ALL
										SELECT   sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
														 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.storemanagebilldrf AS sb INNER JOIN
														 dbo.billdraftidx AS b ON sb.bill_id = b.billid
										WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) 
										UNION ALL
										SELECT   b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
														 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
										FROM      dbo.GSPbilldetail AS b INNER JOIN
														 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) 
										UNION ALL
										SELECT   b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
														 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
										FROM      dbo.GSPbilldetail AS b INNER JOIN
														 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid)
								
									) AS a
						  GROUP BY  p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			     end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			      if @SplitBill=0
			      begin
								INSERT INTO @AvlQty
								SELECT  s_id,p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
												commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
												MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
								FROM      (
												 SELECT   s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
																 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
																 ,costtaxprice,taxrate as taxrate
												 FROM      dbo.storehouse
												 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(2,1))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
												 UNION ALL
												 SELECT  b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
																 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.OrderBill AS b INNER JOIN
																 dbo.orderidx AS i ON b.bill_id = i.billid
												 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
												 UNION ALL
												 SELECT  sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
																 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
																 dbo.billdraftidx AS b ON sb.bill_id = b.billid
												 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
												 UNION ALL
												 SELECT  b.S_id,  b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
																 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.GSPbilldetail AS b INNER JOIN
																 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
												 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
												 
												 UNION ALL
												 SELECT b.S_id,  b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
																 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
												 FROM      dbo.GSPbilldetail AS b INNER JOIN
																 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
												 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
											
											) AS a
								GROUP BY s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			         end
			         else
			         begin
			                   INSERT INTO @AvlQty
								SELECT 0 as s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
												commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
												MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
								FROM      (
												 SELECT    p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
																 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
																 ,costtaxprice,taxrate as taxrate
												 FROM      dbo.storehouse
												 WHERE   (@nPid = -1 OR p_id = @nPid) AND (((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(2,1))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
												 UNION ALL
												 SELECT  b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
																 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.OrderBill AS b INNER JOIN
																 dbo.orderidx AS i ON b.bill_id = i.billid
												 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) 
												 UNION ALL
												 SELECT  sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
																 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
																 dbo.billdraftidx AS b ON sb.bill_id = b.billid
												 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid)
												 UNION ALL
												 SELECT   b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
																 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
												 FROM      dbo.GSPbilldetail AS b INNER JOIN
																 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
												 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) 
												 
												 UNION ALL
												 SELECT   b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
																 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
												 FROM      dbo.GSPbilldetail AS b INNER JOIN
																 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
												 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid)
											
											) AS a
								GROUP BY p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			         end
			END
			ELSE
			/* 不检测*/
			BEGIN
			    if @SplitBill=0
			    begin
						INSERT INTO @AvlQty
						SELECT  s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
										commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
										MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
						FROM      (
										SELECT  s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
														 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
														 ,costtaxprice,taxrate as taxrate
										 FROM      dbo.storehouse
										 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(2,1))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
										 UNION ALL
										 SELECT b.S_id, b.P_id, b.Supplier_id, - b.InceptQty AS InceptQty, b.CostPrice, b.Batchno, 
														b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,
														costtaxprice,costtaxrate as  TaxRate 
										 FROM      dbo.GSPbilldetail AS b INNER JOIN
														dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   ((i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0)) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									) AS a
						GROUP BY s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
		        end
		        else
		        begin
		               INSERT INTO @AvlQty
						SELECT  0 as s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
										commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
										MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
						FROM      (
										SELECT   p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
														 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
														 ,costtaxprice,taxrate as taxrate
										 FROM      dbo.storehouse
										 WHERE   (@nPid = -1 OR p_id = @nPid) AND (((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(2,1))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
										 UNION ALL
										 SELECT  b.P_id, b.Supplier_id, - b.InceptQty AS InceptQty, b.CostPrice, b.Batchno, 
														b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,
														costtaxprice,costtaxrate as  TaxRate 
										 FROM      dbo.GSPbilldetail AS b INNER JOIN
														dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
										WHERE   ((i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0)) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid)
									) AS a
						GROUP BY p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
		        end
		 END
	END
	ELSE
	BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			     if @SplitBill=0
			     begin
			        INSERT INTO @AvlQty
					SELECT s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
					                SELECT  s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE
									((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									UNION ALL
									SELECT b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									(@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND 
									(@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT b.S_id,  b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									(@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY s_id,  p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate
			    end
			    else
			    begin
			        INSERT INTO @AvlQty
					SELECT 0 as s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
					                SELECT   p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE
									(((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									UNION ALL
									SELECT b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) 
									UNION ALL
									SELECT  sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) 
									UNION ALL
									SELECT   b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) 
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY  p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate 
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			      if @SplitBill=0
			      begin
			        INSERT INTO @AvlQty
					SELECT s_id,  p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
					                 SELECT  s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE  
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT  sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND 
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT  b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND 
									 (@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
		         end
		         else
		         begin
		            INSERT INTO @AvlQty
					SELECT  0 as s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
					                 SELECT  p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) 
									 UNION ALL
									 SELECT  sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3')
									 UNION ALL
									 SELECT  b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) 
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
		         end
			END
			ELSE
			/* 不检测*/
			BEGIN
			   if @SplitBill=0
			   begin
					INSERT INTO @AvlQty
					SELECT s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
									SELECT s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
					GROUP BY s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			  end
			  else
			  begin
			      INSERT INTO @AvlQty
					SELECT  0 as s_id,  p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (
									SELECT    p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND (((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag in(1,2))))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
					GROUP BY p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
	
			  end
			END
	END
	RETURN 
END
GO
