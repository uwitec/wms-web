
CREATE PROCEDURE ts_T_LimitBulidBill(
    @Billtype    INT,
    @s_id        INT,
    @Bille       INT,
    @nMergeMode  INT = 0,
    @nY_id       INT = 0,
    @c_id        INT,
    @flid        INT,	/*条件id*/
    @nret        INT OUTPUT
)
AS
/*Params Ini begin*/
if @nMergeMode is null  SET @nMergeMode = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/
	/**/
	DECLARE @nretbill     INT,
	        @szPeriod     VARCHAR(30),
	        @lPeriod      INT,
	        @lBillRet     INT,
	        @toDay        VARCHAR(12)
	
	DECLARE @lP_id        INT,
	        @ls_id        INT,
	        @dAdjNum      NUMERIC(25,8),
	        @lTmp         INT,
	        @nTableTag    INT,
	        @B_id         INT,
	        @FactoryId    INT
	
	DECLARE @price        NUMERIC(25,8),
	        @Total        NUMERIC(25,8),
	        @Unitid       INT,
	        @retailPrice  NUMERIC(25,8)
	
	DECLARE @TaxRate      NUMERIC(3, 2),
	        @sysTaxRate   NUMERIC(3, 2),
	        @TaxPrice     NUMERIC(25,8),
	        @TaxTotal     NUMERIC(25,8),
	        @Taxmoney     NUMERIC(25,8)
	
	DECLARE @nreturn      INT
	DECLARE @GUID         UNIQUEIDENTIFIER
	DECLARE @begintime    DATETIME,
	        @endtime      DATETIME 
	
	/*declare @c_id int*/
	SET @GUID = NEWID()
	SET @nret = -1
	IF OBJECT_ID('tempdb..#P') IS NOT NULL
	    DROP TABLE #P
	
	CREATE TABLE #P
	(
		p_id         INT,
		sin_id       INT,
		supplier_id  INT,
		Lowprice     MONEY,
		unit1_id     INT,
		retailprice  MONEY,
		taxrate      NUMERIC(25,8),
		CEqty        INT,
		FactoryId    INT
	)
	
	
	EXEC ts_GetSysValue 'AccountPeriod',
	     @szPeriod OUTPUT
	
	SELECT @begintime = fl.beginTime,
	       @endtime = fl.EndTime
	FROM   FLCondition fl
	       LEFT JOIN flCdetail fc
	            ON  fl.id = fc.FC_id
	       LEFT JOIN flprovider fp
	            ON  fl.RP_id = fp.RP_id
	WHERE  fp.C_id = @c_id
	       AND fl.id = @flid
	/*AND fl.FLStates = 0 */
	
	SET @sysTaxRate = -1
	IF EXISTS(
	       SELECT 1
	       FROM   sysconfig
	       WHERE  [sysname] = 'UseSameTaxRate'
	              AND [sysvalue] = '1'
	   )
	    SELECT @sysTaxRate = CAST(CAST(sysvalue AS NUMERIC(25,8)) / 100 AS NUMERIC(3, 2))
	    FROM   sysconfig
	    WHERE  [sysname] = 'TaxRate'
	           AND [Y_ID] = 0
	
	SET @lperiod = CAST(@szPeriod AS INT)
	/*   采购入库单*/
	IF @billtype = 20
	    SET @nTableTag = 0 
	/*   采购合同*/
	IF @billtype = 22
	   OR @Billtype = 26
	    SET @nTableTag = 4
	
	SET @toDay = CONVERT(VARCHAR(10), GETDATE(), 20)
	
	IF EXISTS (
	       SELECT 1
	       FROM   FLCondition fl
	              INNER JOIN products p
	                   ON  fl.P_id = p.product_id
	       WHERE  fl.id = @flid
	              AND p.child_number = 0
	   )
	BEGIN
	    INSERT #P
	      (
	        p_id,
	        sin_id,
	        supplier_id,
	        Lowprice,
	        unit1_id,
	        retailprice,
	        taxrate,
	        CEqty,
	        FactoryId
	      )
	    SELECT p.product_id,
	           ISNULL(D.sin_id, 0) AS sin_id,
	           ISNULL(D.supplier_id, fl.C_id) AS supplier_id,
	           p.Lowprice,
	           p.unit1_id,
	           p.retailprice,
	           CAST(p.taxrate / 100 AS NUMERIC(4, 2)) AS taxrate,
	           ISNULL(
	               (
	                   CASE 
	                        WHEN fl.quantity = 0 THEN ((fl.BuyTotal -D.FlSJBuyTotal) / D.buyprice)
	                        ELSE (fl.quantity -D.FlSjQty)
	                   END
	               ),
	               CASE 
	                    WHEN fl.quantity > 0 THEN fl.quantity
	                    ELSE (
	                             CASE 
	                                  WHEN fl.BuyTotal > 0 THEN (fl.BuyTotal / p.recprice)
	                                  ELSE (
	                                           CASE 
	                                                WHEN fl.BackTotal > 0 THEN 
	                                                     fl.BackTotal 
	                                                     / p.recprice
	                                                ELSE 100
	                                           END
	                                       )
	                             END
	                         )
	               END
	           ) AS CEqty,
	           p.factoryc_id
	    FROM   (
	               SELECT bm.p_id,
	                      bd.c_id,
	                      bd.sin_id,
	                      MAX(bm.supplier_id) AS supplier_id,
	                      AVG(bm.buyprice) AS buyprice,
	                      ISNULL(
	                          SUM(
	                              CASE 
	                                   WHEN bd.billtype IN (20, 220) THEN bm.totalmoney
	                                   ELSE -bm.totalmoney
	                              END
	                          ),
	                          0
	                      )FlSJBuyTotal,
	                      ISNULL(
	                          SUM(
	                              CASE 
	                                   WHEN bd.billtype IN (20, 220) THEN CAST(bm.quantity AS INT)
	                                   ELSE -CAST(bm.quantity AS INT)
	                              END
	                          ),
	                          0
	                      )FlSjQty
	               FROM   billidx bd
	                      INNER JOIN buymanagebill bm
	                           ON  bd.billid = bm.bill_id
	                      INNER JOIN products p
	                           ON  p.product_id = bm.p_id
	               WHERE  bd.c_id = @c_id
	                      AND bm.p_id IN (SELECT fl.P_id
	                                      FROM   FLCondition fl
	                                             INNER JOIN flprovider fp
	                                                  ON  fl.RP_id = fp.RP_id
	                                      WHERE  fp.C_id = @c_id
	                                             AND fl.id = @flid)
	                      AND bd.billdate BETWEEN @beginTime AND @EndTime
	                      AND bd.billtype IN (20, 21, 220, 221)
	                      AND bd.billstates = 0
	               GROUP BY
	                      bm.p_id,
	                      bd.c_id,
	                      bd.sin_id
	           )D
	           RIGHT JOIN FLCondition fl
	                ON  fl.P_id = D.p_id
	           INNER JOIN vw_Products p
	                ON  fl.p_id = p.product_id
	    WHERE  fl.id = @flid
	           AND ISNULL(
	                   (
	                       CASE 
	                            WHEN fl.quantity = 0 THEN ((fl.BuyTotal -D.FlSJBuyTotal) / D.buyprice)
	                            ELSE (fl.quantity -D.FlSjQty)
	                       END
	                   ),
	                   CASE 
	                        WHEN fl.quantity > 0 THEN fl.quantity
	                        ELSE (
	                                 CASE 
	                                      WHEN fl.BuyTotal > 0 THEN (fl.BuyTotal / p.recprice)
	                                      ELSE (
	                                               CASE 
	                                                    WHEN fl.BackTotal > 0 THEN 
	                                                         fl.BackTotal 
	                                                         / p.recprice
	                                                    ELSE 100
	                                               END
	                                           )
	                                 END
	                             )
	                   END
	               ) > 0
	END
	ELSE
	BEGIN
	    INSERT #P
	      (
	        p_id,
	        sin_id,
	        supplier_id,
	        Lowprice,
	        unit1_id,
	        retailprice,
	        taxrate,
	        CEqty,
	        FactoryId
	      )
	    SELECT p.product_id,
	           ISNULL(D.sin_id, 0) AS sin_id,
	           ISNULL(D.supplier_id, fl.C_id) AS supplier_id,
	           p.Lowprice,
	           p.unit1_id,
	           p.retailprice,
	           CAST(p.taxrate / 100 AS NUMERIC(4, 2)) AS taxrate,
	           ISNULL(
	               (
	                   CASE 
	                        WHEN fl.quantity = 0 THEN ((fl.BuyTotal -D.FlSJBuyTotal) / P.recprice)
	                        ELSE (fl.quantity -D.FlSjQty)
	                   END
	               ),
	               CASE 
	                    WHEN fl.quantity > 0 THEN fl.quantity
	                    ELSE (
	                             CASE 
	                                  WHEN fl.BuyTotal > 0 THEN (fl.BuyTotal / p.recprice)
	                                  ELSE (
	                                           CASE 
	                                                WHEN fl.BackTotal > 0 THEN 
	                                                     fl.BackTotal 
	                                                     / p.recprice
	                                                ELSE 100
	                                           END
	                                       )
	                             END
	                         )
	               END
	           ) AS CEqty,
	           p.factoryc_id
	    FROM   (
	               SELECT bm.p_id,
	                      bd.c_id,
	                      bd.sin_id,
	                      MAX(bm.supplier_id) AS supplier_id,
	                      AVG(bm.buyprice) AS buyprice,
	                      ISNULL(
	                          SUM(
	                              CASE 
	                                   WHEN bd.billtype IN (20, 220) THEN bm.totalmoney
	                                   ELSE -bm.totalmoney
	                              END
	                          ),
	                          0
	                      )FlSJBuyTotal,
	                      ISNULL(
	                          SUM(
	                              CASE 
	                                   WHEN bd.billtype IN (20, 220) THEN CAST(bm.quantity AS INT)
	                                   ELSE -CAST(bm.quantity AS INT)
	                              END
	                          ),
	                          0
	                      )FlSjQty
	               FROM   billidx bd
	                      INNER JOIN buymanagebill bm
	                           ON  bd.billid = bm.bill_id
	                      INNER JOIN products p
	                           ON  p.product_id = bm.p_id
	               WHERE  bd.c_id = @c_id
	                      AND bm.p_id IN (SELECT fc.p_id
	                                      FROM   FLCondition fl
	                                             INNER JOIN flCdetail fc
	                                                  ON  fl.id = fc.FC_id
	                                             INNER JOIN flprovider fp
	                                                  ON  fl.RP_id = fp.RP_id
	                                      WHERE  fp.C_id = @c_id
	                                             AND fl.id = @flid)
	                      AND bd.billdate BETWEEN @begintime AND @endtime
	                      AND bd.billtype IN (20, 21, 220, 221)
	                      AND bd.billstates = 0
	               GROUP BY
	                      bm.p_id,
	                      bd.c_id,
	                      bd.sin_id
	           )D
	           RIGHT JOIN (
	                    SELECT m.id,
	                           m.RP_id,
	                           m.C_id,
	                           n.P_id,
	                           m.quantity,
	                           m.price,
	                           m.BuyTotal,
	                           m.BackTotal,
	                           m.[Month],
	                           m.beginTime,
	                           m.EndTime,
	                           m.intendTime,
	                           m.alarmTime,
	                           m.FLModulus,
	                           m.FLStates,
	                           m.Flrelation,
	                           m.Formula,
	                           m.Flmoney,
	                           m.Fljsmode,
	                           m.FlSjQty,
	                           m.FlSJBuyTotal,
	                           m.FlSJBackTotal,
	                           m.FlCondition
	                    FROM   FLCondition m
	                           INNER JOIN flCdetail n
	                                ON  m.id = n.FC_id
	                ) fl
	                ON  fl.P_id = D.p_id
	           INNER JOIN vw_Products p
	                ON  fl.p_id = p.product_id
	    WHERE  fl.id = @flid
	           AND ISNULL(
	                   (
	                       CASE 
	                            WHEN fl.quantity = 0 THEN ((fl.BuyTotal -D.FlSJBuyTotal) / P.recprice)
	                            ELSE (fl.quantity -D.FlSjQty)
	                       END
	                   ),
	                   CASE 
	                        WHEN fl.quantity > 0 THEN fl.quantity
	                        ELSE (
	                                 CASE 
	                                      WHEN fl.BuyTotal > 0 THEN (fl.BuyTotal / p.recprice)
	                                      ELSE (
	                                               CASE 
	                                                    WHEN fl.BackTotal > 0 THEN 
	                                                         fl.BackTotal 
	                                                         / p.recprice
	                                                    ELSE 100
	                                               END
	                                           )
	                                 END
	                             )
	                   END
	               ) > 0
	END
	IF NOT EXISTS (
	       SELECT 1
	       FROM   #P
	   )
	    RETURN -1
	
	/*获取单据编号。-add by Wsj-2017-02-09-tfsbug45377 */
	declare @szBillSN varchar(200)
	exec TS_H_CreateBillSN @Billtype, 1, null, @Bille, @Bille, @szBillSN output
	
	/*生成表头*/
	
	/* 生成billdraftidx */
	EXEC Ts_b_InsertBillIndexDraft @nretbill OUTPUT,
	     0,
	     @ntableTag,
	     0,
	     @today,
	     @szBillSN,
	     @Billtype,
	     0,
	     @c_id,
	     @Bille,
	     0,
	     0,
	     0,
	     @Bille,
	     0,
	     0,
	     0,
	     0,
	     @lperiod,
	     '2',
	     0,
	     0,
	     0,
	     0,
	     @today,
	     @today,
	     0,
	     '0',
	     '【返利差额查询报表生成】',
	     '',
	     0,
	     '',
	     0,
	     0,
	     0,
	     0,
	     0,
	     0,
	     0,
	     0,
	     0,
	     0,
	     '1111111',
	     @nY_id,
	     '',
	     '',
	     '',
	     0,
	     0,
	     0
	
	IF (@nretbill <> -1 AND @nretbill <> 0)
	BEGIN
	    SET @nret = @nretbill 
	    IF @Billtype IN (22, 26)
	    BEGIN
	        DECLARE Limit_cur  CURSOR  
	        FOR
	            SELECT *
	            FROM   #P
	        
	        OPEN Limit_cur
	        FETCH NEXT FROM Limit_cur INTO @lp_id,@lS_id,@B_id,@price,@unitid,@retailPrice,
	        @taxrate,@dAdjNum,@FactoryId                                                                                                                                                                                                                         
	        
	        WHILE @@fetch_status = 0
	        BEGIN
	            SET @total = @DAdjNum * @price
	            IF @sysTaxRate > -1
	                SET @TaxRate = @sysTaxRate /*取系统设置税率 */
	            SET @TaxPrice = CAST(@price * (1 + @Taxrate) AS NUMERIC(25,8))
	            SET @TaxTotal = CAST(@dAdjNum * @TaxPrice AS NUMERIC(25,8))
	            SET @Taxmoney = @TaxTotal -@Total
	            
	            EXEC Ts_b_InsertBillDetailDraft @lBillret OUTPUT,
	                 @nTableTag,
	                 0,
	                 @nret,
	                 0,
	                 @lp_id,
	                 '',
	                 @DAdjNum,
	                 @price,
	                 @price,
	                 @total,
	                 1,
	                 @price,
	                 @total,
	                 @taxprice,
	                 @taxtotal,
	                 @Taxmoney,
	                 @retailprice,
	                 0,
	                 0,
	                 0,
	                 '合格',
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 @b_id,
	                 0,
	                 '',
	                 @unitid,
	                 @TaxRate,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 @Bille,
	                 @GUID,
	                 '0',
	                 '',
	                 @nY_id,
	                 0,
	                 0,
                     '', 
                     '',
                     0,
                     '',
                     0x0,
                     '',
                     '',
                     @FactoryId
	            
	            IF @lBillret = -1
	            BEGIN
	                EXEC Ts_b_DeleteBillDraft @ltmp OUTPUT,
	                     @nTableTag,
	                     @nret
	                
	                RETURN -1
	            END
	            
	            FETCH NEXT FROM Limit_cur INTO @lp_id,@lS_id,@B_id,@price,@unitid,
	            @retailPrice, @taxrate,@dAdjNum,@FactoryId
	        END
	        
	        CLOSE Limit_cur
	        DEALLOCATE Limit_cur
	        
	        IF @nMergeMode = 1
	        BEGIN
	            EXEC ts_c_SplitBill @Billtype,
	                 @nret,
	                 @nMergeMode,
	                 @nreturn OUTPUT
	            
	            IF @nreturn = 0
	                EXEC Ts_b_DeleteBillDraft @ltmp OUTPUT,
	                     @nTableTag,
	                     @nret
	        END
	        /*zh 10.08.13,@nret+1(采购合同生成单据号为单号) */
	        UPDATE orderidx
	        SET    ysmoney = O.tax,
	               quantity = O.Qty
	        FROM   (
	                   SELECT SUM(o.taxtotal)tax,
	                          SUM(O.quantity)Qty
	                   FROM   OrderBill O
	                   WHERE  O.bill_id = (@nret + 1)
	               )O
	        WHERE  orderidx.billid = (@nret + 1)
	    END
	    ELSE
	        /*采购入库单*/
	    BEGIN
	        DECLARE Limit_cur  CURSOR  
	        FOR
	            SELECT p_id,
	                   sin_id,
	                   Lowprice,
	                   unit1_id,
	                   retailprice,
	                   taxrate,
	                   CEqty,
	                   FactoryId   
	            FROM   #P
	        
	        OPEN Limit_cur
	        FETCH NEXT FROM Limit_cur INTO @lp_id,@lS_id,@price,@unitid,@retailPrice, 
	        @taxrate,@dAdjNum,@FactoryId                                                                                                                                                                                                                         
	        
	        WHILE @@fetch_status = 0
	        BEGIN
	            SET @total = @DAdjNum * @price
	            IF @sysTaxRate > -1
	                SET @TaxRate = @sysTaxRate /*取系统设置税率 */
	            SET @TaxPrice = CAST(@price * (1 + @TaxRate) AS NUMERIC(25,8))
	            SET @TaxTotal = CAST(@dAdjNum * @TaxPrice AS NUMERIC(25,8)) 
	            SET @Taxmoney = @TaxTotal -@Total
	            
	            EXEC Ts_b_InsertBillDetailDraft @lBillret OUTPUT,
	                 @nTableTag,
	                 0,
	                 @nret,
	                 0,
	                 @lp_id,
	                 '',
	                 @DAdjNum,
	                 @price,
	                 @price,
	                 @total,
	                 1,
	                 @price,
	                 @total,
	                 @taxprice,
	                 @taxtotal,
	                 @Taxmoney,
	                 @retailprice,
	                 0,
	                 0,
	                 0,
	                 '合格',
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 '',
	                 @unitid,
	                 @TaxRate,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 0,
	                 @Bille,
	                 @GUID,
	                 '0',
	                 '',
	                 @nY_id,
	                 0,
	                 0,
                     '', 
                     '',
                     0,
                     '',
                     0x0,
                     '',
                     '',
                     @FactoryId
	            
	            IF @lBillret = -1
	            BEGIN
	                EXEC Ts_b_DeleteBillDraft @ltmp OUTPUT,
	                     @nTableTag,
	                     @nret
	                
	                RETURN -1
	            END
	            
	            FETCH NEXT FROM Limit_cur INTO @lp_id,@lS_id,@price,@unitid,@retailPrice, 
	            @taxrate,@dAdjNum,@FactoryId
	        END
	        
	        CLOSE Limit_cur
	        DEALLOCATE Limit_cur
	    END
	END
GO
