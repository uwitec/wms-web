

CREATE procedure TS_D_InsDRYDBillidx
@OperatorNo INT,
@BATCHNO VARCHAR(30),
@SignStatus INT,
@SignInNo VARCHAR(80),
@SignOutNo VARCHAR(80)    
AS

  IF @OperatorNo IS NULL SET @OperatorNo=0
  IF @BATCHNO IS NULL SET @BATCHNO=''
  IF @SignStatus IS NULL SET @SignStatus=0
  IF @SignInNo IS NULL SET @SignInNo=''
  IF @SignOutNo IS NULL SET @SignOutNo=''

  IF @SignStatus = 0
  BEGIN
	IF NOT EXISTS(SELECT 1 FROM DRYDBillidx WHERE OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO)
	BEGIN
	  INSERT INTO DRYDBillidx
	   (OperatorNo,BATCHNO,SignStatus,SignInDate,SignInNo)
	  SELECT @OperatorNo,@BATCHNO,@SignStatus,GETDATE(),@SignInNo
	END  
  END
  IF @SignStatus = 1
  BEGIN  
    UPDATE DRYDBillidx SET 
    SignOutDate=GETDATE()
    ,SignStatus=1
    ,SignOutNo=@SignOutNo
    WHERE OperatorNo=@OperatorNo AND BATCHNO=@BATCHNO
  END
GO
