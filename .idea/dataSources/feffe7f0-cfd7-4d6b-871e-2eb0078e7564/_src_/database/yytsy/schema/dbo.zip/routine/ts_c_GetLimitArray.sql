



create   PROCEDURE ts_c_GetLimitArray
AS
set nocount on

SELECT  gid as e_id,[name] as empname,permission,comment,' ' as 'serial_number', ' ' as 'password',ProductInfor,ClientInfor,PriceInfor
  ,limPlugin as permPlugin /*added by ZhanXinYun@2010-10-25*/
FROM limgroup 
ORDER BY gid
GO
