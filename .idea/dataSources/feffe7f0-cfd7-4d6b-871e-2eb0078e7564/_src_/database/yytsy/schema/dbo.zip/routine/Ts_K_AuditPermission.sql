
CREATE   PROCEDURE Ts_K_AuditPermission
(
	@nPermissionId   INT,
	@nAuditId  	     INT = 0,
	@szAuditReason   VARCHAR(800),
	@nAuditStates    INT
)
/*with encryption*/
AS
BEGIN
	UPDATE EmployeesPermission 
		SET Audit_Id = @nAuditId, AuditDate = GETDATE(), AuditStates = @nAuditStates, AuditReason = @szAuditReason
	WHERE Permission_Id =@nPermissionId
	
	IF @nAuditStates = 1
	BEGIN
		/*获取用户原有权限信息*/
		DECLARE @Temp TABLE(PermissionId INT, lim IMAGE, ProductInfo TEXT, ClientInfo TEXT, PriceInfo TEXT)
		
		INSERT INTO @Temp(PermissionId, lim, ProductInfo, ClientInfo, PriceInfo)
		SELECT @nPermissionId, e.lim, ee.ProductInfor, ee.ClientInfor, ee.PriceInfor
		  FROM employees e, EmplimitEx ee 
		WHERE e.emp_id = ee.e_id AND e.emp_id IN (SELECT Emp_Id FROM EmployeesPermission 
		                                          WHERE Permission_Id = @nPermissionId)
		/*获取用户原有权限信息*/
		
		UPDATE a SET a.lim = b.lim FROM Employees a, (SELECT Emp_Id, lim, limPlugin
														FROM EmployeesPermission WHERE Permission_Id = @nPermissionId) b 
		WHERE a.emp_id = b.Emp_Id
		
		UPDATE a SET a.ProductInfor = b.ProductInfo, a.ClientInfor = b.ClientInfo, a.PriceInfor = b.PriceInfo 
			FROM EmplimitEx a, (SELECT Emp_Id, ProductInfo, ClientInfo, PriceInfo
									FROM EmployeesPermission WHERE Permission_Id = @nPermissionId) b 
		WHERE a.e_id = b.Emp_Id	
		
	    /*将用户原有权限信息写回申请表，用作比对申请前后权限差异*/
		UPDATE a
		SET a.lim = b.lim,
			a.ProductInfo = b.ProductInfo,
			a.ClientInfo = b.ClientInfo,
			a.PriceInfo = b.PriceInfo
		FROM EmployeesPermission a, @Temp b
		WHERE a.Permission_Id = b.PermissionId
		/*--将用户原有权限信息写回申请表，用作比对申请前后权限差异*/
	END
	
END
GO
