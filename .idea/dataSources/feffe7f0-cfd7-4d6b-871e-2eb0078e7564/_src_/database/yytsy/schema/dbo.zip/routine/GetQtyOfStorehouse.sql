
CREATE  FUNCTION GetQtyOfStorehouse(@YId INT, @PId INT, @SupplierId INT)  
RETURNS numeric(25,8)
AS  
BEGIN 
	/*待退厂库里的库存，在付款计划列表里使用*/
	DECLARE @Result numeric(25,8)
	
	SELECT @Result = SUM(s.quantity) 
		FROM storehouse s INNER JOIN storages b ON s.s_id = b.storage_id
	WHERE s.Y_ID = @YId AND s.p_id = @PId AND s.supplier_id = @SupplierId AND b.qualityFlag = 2
	
	IF @Result IS NULL
		SET @Result = 0.00
	
	RETURN @Result
END
GO
