
CREATE	       PROCEDURE Ts_K_GetOOSCatalog
(
	@BeginDate  DATETIME,  
	@EndDate    DATETIME,
	@PClassID   VARCHAR(30) = '%',
	@CClassID   VARCHAR(30) = '%',
	@YClassID   VARCHAR(30) = '%',
	@PlanALL    INT = 0,
	@SaleALL    INT = 0	
)
/*with encryption*/
AS
	SELECT p.class_id, p.serial_number, p.name AS PName, p.alias, p.[standard], p.Unit1Name,p.unit1_id,  
		   p.MedName, p.makearea, p.permitcode, e.name AS EName, i.name AS Inputman, 
           o.OOSId, o.ProductId, o.CompanyId, o.ClientId, o.EId, o.OOSQty, o.PlanQty,
           o.SaleQty, o.InputDate, o.InputManId, o.[Deleted], o.ModifyDate, o.CreateDate, 
           y.name AS YName, c.name AS CName,p.unit1_id as unitid, 
           ISNULL(dbo.GetOOSCatalogStorehouse(o.ProductId), 0) AS Qty,
           CASE WHEN (o.OOSQty < o.PlanQty) THEN 0 ELSE (o.OOSQty - o.PlanQty) END AS fQty,
           ISNULL(v.c_id, 0) AS SupplierId, o.Remark    
    FROM OOSCatalog o INNER JOIN vw_products p ON o.ProductId = p.product_id
                      LEFT JOIN company y ON o.CompanyId = y.company_id
                      LEFT JOIN clients c ON o.ClientId = c.client_id
                      LEFT JOIN employees e ON o.EId = e.emp_id
                      LEFT JOIN employees i ON o.InputManId = i.emp_id
                      LEFT JOIN (SELECT DISTINCT a.p_id, a.c_id 
									FROM buypricehis a INNER JOIN (SELECT p_id, MAX(ModifyDate) AS ModifyDate 
									                               FROM buypricehis WHERE Y_ID = 2 GROUP BY p_id) AS b 
									                   ON  a.p_id = b.p_id AND a.ModifyDate = b.ModifyDate) v ON o.ProductId = v.p_id
    WHERE o.[Deleted] = 0 AND p.[deleted] = 0 AND o.InputDate BETWEEN @BeginDate AND @EndDate AND
          (@PlanALL = 0 OR (o.OOSQty > o.PlanQty)) AND (@SaleALL = 0 OR (o.OOSQty > o.SaleQty)) AND
          p.class_id LIKE @PClassID AND ISNULL(c.class_id, '') LIKE @CClassID AND ISNULL(y.class_id, '') LIKE @YClassID
GO
