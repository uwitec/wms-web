

CREATE	 PROC [dbo].[TS_S_ImportPhoneBook]
(@Group_id INT = 0, @SourceType INT = 0, @SourceID INT = 0)
/*with encryption*/
AS
BEGIN
/*Params Ini begin*/
if @Group_id is null  SET @Group_id = 0 
if @SourceType is null SET @SourceType = 0
if @SourceID is null SET @SourceID = 0
/*Params Ini end*/
	IF @SourceType = 1 /*往来单位*/
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   PhoneBook
	           WHERE  SourceType = @SourceType
	                  AND SourceID = @SourceID
	                  AND Group_id = @Group_id
	       )
	    BEGIN
	        UPDATE PhoneBook
	        SET    [Name] = c.Contact_personal,
	               [PhoneNo] = c.Phone_Number,
	               [ClientName] = c.[Name],
	               /*                             [Email]      = c.[Email],*/
	               /*                             [QQ]         = c.[QQ],*/
	               [Comment] = c.[Comment]
	        FROM   PhoneBook p,
	               Clients c
	        WHERE  SourceType = @SourceType
	               AND Group_id = @Group_id
	               AND SourceID = @SourceID
	               AND p.SourceID = c.Client_ID
	    END
	    ELSE
	    BEGIN
	        INSERT INTO phonebook
	          (
	            [Name],
	            PhoneNO,
	            ClientName,
	            Email,
	            QQ,
	            Comment,
	            Group_ID,
	            SourceType,
	            SourceID
	          )
	        SELECT [Contact_personal],
	               phone_number,
	               [Name],
	               '',
	               '',
	               Comment,
	               @Group_ID,
	               @SourceType,
	               Client_ID
	        FROM   clients
	        WHERE  DELETED = 0
	               AND child_count = 0
	               AND Client_ID = @SourceID
	    END
	END
	ELSE
	IF @SourceType = 2 /*会员*/
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   PhoneBook
	           WHERE  SourceType = @SourceType
	                  AND SourceID = @SourceID
	                  AND Group_id = @Group_id
	       )
	    BEGIN
	        UPDATE PhoneBook
	        SET    [Name] = c.[Name],
	               [PhoneNo] = c.Tel,
	               [ClientName] = '',
	               [Email] = '',
	               [QQ] = '',
	               [Comment] = c.[Comment]
	        FROM   PhoneBook p,
	               VIPCard c
	        WHERE  SourceType = @SourceType
	               AND Group_id = @Group_id
	               AND SourceID = @SourceID
	               AND p.SourceID = c.VIPCardID
	    END
	    ELSE
	    BEGIN
	        INSERT INTO phonebook
	          (
	            [Name],
	            PhoneNO,
	            ClientName,
	            Email,
	            QQ,
	            Comment,
	            Group_ID,
	            SourceType,
	            SourceID
	          )
	        SELECT [Name],
	               [Tel],
	               '' AS ClientName,
	               '' AS Email,
	               '' AS QQ,
	               Comment,
	               @Group_ID,
	               @SourceType,
	               VIPCardID
	        FROM   VIPCard
	        WHERE  VIPCardID = @SourceID
	    END
	END
	ELSE 
	IF @SourceType = 3 /*职员*/
	BEGIN
	    IF EXISTS(
	           SELECT *
	           FROM   PhoneBook
	           WHERE  SourceType = @SourceType
	                  AND SourceID = @SourceID
	                  AND Group_id = @Group_id
	       )
	    BEGIN
	        UPDATE PhoneBook
	        SET    [Name] = c.[Name],
	               [PhoneNo] = c.Phone,
	               [ClientName] = '',
	               [Email] = '',
	               [QQ] = '',
	               [Comment] = c.[Comment]
	        FROM   PhoneBook p,
	               employees c
	        WHERE  SourceType = @SourceType
	               AND Group_id = @Group_id
	               AND SourceID = @SourceID
	               AND p.SourceID = c.emp_ID
	    END
	    ELSE
	    BEGIN
	        INSERT INTO phonebook
	          (
	            [Name],
	            PhoneNO,
	            ClientName,
	            Email,
	            QQ,
	            Comment,
	            Group_ID,
	            SourceType,
	            SourceID
	          )
	        SELECT [Name],
	               Phone,
	               '' AS ClientName,
	               '' AS EMail,
	               '' AS QQ,
	               Comment,
	               @Group_ID,
	               @SourceType,
	               emp_ID
	        FROM   employees
	        WHERE  Child_Count = 0
	               AND DELETED = 0
	               AND emp_ID = @SourceID
	    END
	END
END
GO
