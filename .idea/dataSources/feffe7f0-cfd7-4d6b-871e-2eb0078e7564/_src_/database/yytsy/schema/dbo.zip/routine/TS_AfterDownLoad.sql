

CREATE  PROCEDURE [dbo].[TS_AfterDownLoad] 
  @PosID int
AS
BEGIN
  DECLARE @s_id INT  /*默认仓库	*/

  /*未能传输成功的店间调拨单重置传输标记	*/
  update billdraftidx set transflag = 0 from DownBillLog_dts d where billstates = 0 and transflag = 1 and UpOrDown = 1 and GUID = BillGuid and billdraftidx.Y_ID = d.y_id
  TRUNCATE TABLE DownBillLog_dts	
  	
  /*下传的单据不再上传*/
  UPDATE BillIdx_Dts SET transflag = 2	
	
  /*由于分公司Company表不下传,机构中指定门店为总公司的认为是分公司	*/
  DECLARE @y_id INT
  SELECT @y_id = ISNULL(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'y_id'

  DECLARE @YTYPE INT
  SET @YTYPE = 0
  SELECT @YTYPE = Ytype FROM company WHERE company_id = @y_id

  /*处理同时会上传和下载的表billlog*/
  delete from billlog where billguid in (select billguid from billlog_dts)
  insert into billlog(BillGuid, Bill_ID, BillType, UpOrDown, y_id, Status, ErrCount, InDateTime, ErrFlag, p_id, billnumber, billdate, transflag)
    select BillGuid, Bill_ID, BillType, UpOrDown, y_id, Status, ErrCount, InDateTime, ErrFlag, p_id, billnumber, billdate, 1 from billlog_dts


/*XXX.2017-05-03  去掉该自定义类别关联表 customCategoryMapping*/
	/*IF @YTYPE = 2
	BEGIN
		-- 往来单位经营范围
		SELECT * INTO #CR
		FROM customCategoryMapping WHERE category_id IN (SELECT ID FROM customCategory WHERE Typeid = 1)

		TRUNCATE TABLE customCategoryMapping

		INSERT INTO customCategoryMapping(category_id, baseinfo_id, deleted, BaseTypeid)
		SELECT category_id, baseinfo_id, deleted, BaseTypeid
		FROM customCategoryMapping_dts WHERE category_id NOT IN(SELECT ID FROM customCategory_dts WHERE Typeid = 1)

		INSERT INTO customCategoryMapping(category_id, baseinfo_id, deleted, BaseTypeid)
		SELECT category_id, baseinfo_id, deleted, BaseTypeid
		FROM #CR

		DROP TABLE #CR
	END
	ELSE
	BEGIN
		TRUNCATE TABLE customCategoryMapping
		INSERT INTO customCategoryMapping(category_id, baseinfo_id, deleted, BaseTypeid)
		SELECT category_id, baseinfo_id, deleted, BaseTypeid
		FROM customCategoryMapping_dts
	END
	*/

  /*职员扩展权限表双主键单独处理*/
  DELETE FROM EmplimitEx WHERE smb_id IN (
    SELECT c.smb_id FROM EmplimitEx c INNER JOIN EmplimitEx_dts d ON c.e_id = d.e_id AND c.orderIndex = d.orderIndex)
  INSERT INTO EmplimitEx(e_id, orderIndex, lim, ProductInfor, ClientInfor, PriceInfor)
    SELECT e_id, orderIndex, lim, ProductInfor, ClientInfor, PriceInfor FROM EmplimitEx_dts  
  
  /*公告表*/
  DELETE FROM AfficheRec WHERE RowGuid IN (SELECT RowGuid FROM AfficheRec_dts) 
  INSERT INTO AfficheRec(AffContent, AffDate, AffTitle, DFlag, EID, YID, RowGuid, AffContentNew)
	SELECT AffContent, AffDate, AffTitle, DFlag, EID, YID, RowGuid, AffContentNew FROM AfficheRec_dts
	
  /*机构应收应付*/
  DELETE c FROM Companybalance c WHERE EXISTS(SELECT * FROM Companybalance_dts d WHERE c.y_id=d.y_id AND c.c_id=d.c_id)
  INSERT INTO Companybalance(y_id, c_id, credit_total, sklimit, artotal, artotal_ini, aptotal, aptotal_ini, pre_artotal, pre_artotal_ini, pre_aptotal, pre_aptotal_ini, OpenAccount, APCredit_total) 
	SELECT y_id, c_id, credit_total, sklimit, artotal, artotal_ini, aptotal, aptotal_ini, pre_artotal, pre_artotal_ini, pre_aptotal, pre_aptotal_ini, OpenAccount, APCredit_total 
	FROM Companybalance_dts	
  /*解决门店机构信用额度显示*/
  IF NOT EXISTS(SELECT * FROM Companybalance WHERE y_id = @PosID AND c_id = @PosID)	
	  INSERT INTO Companybalance(y_id, c_id, credit_total, sklimit, artotal, artotal_ini, aptotal, aptotal_ini, pre_artotal, pre_artotal_ini, pre_aptotal, pre_aptotal_ini, OpenAccount, APCredit_total) 
		SELECT @PosID, c_id, credit_total, sklimit, artotal, artotal_ini, aptotal, aptotal_ini, pre_artotal, pre_artotal_ini, pre_aptotal, pre_aptotal_ini, OpenAccount, APCredit_total 
		FROM Companybalance_dts
		WHERE y_id = 2 AND c_id = @PosID
  ELSE 
    BEGIN
  	   DECLARE @credit_total NUMERIC(18,8)
  	   select @credit_total = ISNULL(credit_total,0) FROM Companybalance_dts WHERE y_id = 2 AND c_id = @PosID
  	   if @credit_total is null   /*XXX.2017-02-06 处理特殊情况，这儿可能为空*/
  	   set @credit_total = 0
       UPDATE Companybalance SET credit_total = @credit_total WHERE y_id = @PosID AND c_id = @PosID 
    END   	 
  
  /*门店,加盟店,内部机构下传的数据处理*/
  IF @y_id <> 2
  begin		
  	/*获取机构类型和默认仓库 */
    DECLARE @PosType INT
    SELECT @PosType = ISNULL(Ytype,-1) FROM company WHERE company_id = @PosID
         
    SELECT @s_id = IsNull(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'CenterSID' AND Y_ID = @y_id
    
    /*过帐前 加盟店机构类单据，先将仓库替换为加盟店默认仓库*/
    if @PosType IN (2)
      UPDATE BillIdx_Dts SET sin_id=@s_id WHERE billtype IN (150,151,152,153,160,161,162,163)  	
  	
    /*下传单据处理  生成发货单*/
    Exec TS_H_DtsDownBillDeal

	/*生成门店对账报表*/
	exec TS_L_CompareOfCompanySale @PosID,0
	
  	/*单独处理TransDim*/
  	DELETE FROM TransDim WHERE PosID IN (SELECT PosID FROM TransDim_Dts)
  	INSERT INTO TransDim(PosID, TransName, Up, Down) 
  	  SELECT PosID, TransName, Up, Down FROM TransDim_Dts 
  	TRUNCATE TABLE TransDim_Dts	

  	/*处理PosPrice表*/
  	/*SET IDENTITY_INSERT PosPrice ON*/
  	/*DELETE FROM PosPrice WHERE price_id IN (SELECT price_id FROM PosPrice_Dts)*/
	DELETE FROM PosPrice WHERE price_id IN (SELECT p.price_id FROM PosPrice_Dts d INNER JOIN PosPrice p ON d.Y_ID = p.Y_ID and d.u_id = p.u_id AND d.p_id = p.p_id)
  	INSERT INTO PosPrice(pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid, Y_ID)
      SELECT pos_id, p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid, Y_ID FROM PosPrice_Dts
    TRUNCATE TABLE PosPrice_Dts	
    /*SET IDENTITY_INSERT PosPrice OFF	*/

    /*处理SysConfig  开账后才覆盖*/
    IF EXISTS(SELECT * FROM Companybalance WHERE OpenAccount=1 AND c_id=0 AND y_id=@PosID)
    BEGIN 
    	DELETE FROM SysConfig WHERE SYSNAME IN (SELECT SYSNAME FROM SysConfig_Dts)
    	INSERT INTO sysconfig(SYSNAME,sysvalue,comment,sysflag,y_id) 
    	  SELECT SYSNAME,sysvalue,comment,sysflag,y_id FROM SysConfig_Dts  
    END

    /*覆盖门店库存 必须开账后才执行*/
    declare @OpenAccount int
    select @OpenAccount=OpenAccount from CompanyBalance where y_id=@PosID and c_id=0
    if @OpenAccount=1 and @PosID<>2
    begin
      /*如果是下传总部库存	*/
      IF exists(SELECT * FROM TransDim WHERE PosID = @PosID AND TransName = 'ZBStorehouse' AND Down = 1)
        AND exists(SELECT * FROM StoreHouse_dts WHERE Y_ID = 2)
		  BEGIN
      		DELETE FROM storehouse WHERE Y_ID = 2
		  END
      ELSE
      	BEGIN
      		DELETE FROM storehouse_dts WHERE Y_ID = 2
      	END
      
      /*如果是下传门店库存*/
      if exists(select storehouse_id from storehouse_dts) AND EXISTS(SELECT * FROM TransDim WHERE PosID = @PosID AND TransName = 'PosStorehouse' AND Down = 1)
		  begin
			DELETE FROM storehouse WHERE Y_ID = @PosID
		  END
	  ELSE 
	  	  BEGIN
	  	  	DELETE FROM storehouse_dts WHERE Y_ID = @PosID
	  	  END	
        insert into storehouse(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, SendFlag, BatchBarCode, scomment, batchprice, costtaxprice, costtaxtotal, factoryid, taxrate)
          select location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, SendFlag, BatchBarCode, scomment, batchprice, costtaxprice, costtaxtotal, factoryid, taxrate from storehouse_dts
        TRUNCATE TABLE storehouse_dts
        
    end

    /*处理调价单  select * from PriceIdx  select * from Pricebill*/
    DELETE FROM PriceIdx WHERE guid IN (SELECT guid FROM PriceIdx_Dts)
    DELETE FROM PriceBill WHERE Bill_ID NOT IN (SELECT billid FROM PriceIdx)
  
    INSERT INTO PriceIdx(billdate, billnumber, billtype, e_id, auditman, inputman, period, billstates, order_id, department_id, posid, region_id, auditdate, note, summary, ArAptotal, guid, Y_ID) 
      select billdate, billnumber, billtype, e_id, auditman, inputman, period, billstates, order_id, department_id, posid, region_id, auditdate, note, summary, ArAptotal, guid, Y_ID FROM PriceIdx_Dts
    INSERT INTO PriceBill(Bill_ID, P_ID, Price_ID, UnitID, retailprice, Price1, Price2, Price3, Price4, glprice, gpprice, specialprice, recprice, lowprice, Comment, Y_Id, oldretailprice)
      SELECT (SELECT BillID FROM priceidx WHERE guid=(SELECT guid FROM PriceIdx_Dts WHERE billid=PriceBill_Dts.Bill_ID) ),
             P_ID, Price_ID, UnitID, retailprice, Price1, Price2, Price3, Price4, glprice, gpprice, specialprice, recprice, lowprice, Comment, Y_Id, oldretailprice 
        FROM PriceBill_Dts 
  
    TRUNCATE TABLE PriceIdx_Dts
    TRUNCATE TABLE PriceBill_Dts

    /*价格表无删除标记要单独处理*/
    DELETE FROM price WHERE p_id IN (SELECT p_id FROM Price_Dts)
    INSERT INTO price(p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid)
      SELECT p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid FROM Price_Dts
    TRUNCATE TABLE Price_Dts
  
    /*条码表无删除标记要单独处理*/
    DELETE FROM barcode WHERE p_id IN (SELECT p_id FROM barcode_Dts)
    INSERT INTO barcode(p_id, barcode, AutoCode, unitid, BarcodeType, codetype)
      SELECT p_id, barcode, AutoCode, unitid, BarcodeType, codetype FROM barcode_Dts 
    TRUNCATE TABLE barcode_Dts 
  END
  
  /*当是分公司时候*/
  else IF @y_id = 2 
  BEGIN
  	/*处理TransDim的y_id=2     SELECT * FROM TransDim*/
  	DELETE FROM TransDim WHERE PosID = 2 AND TransName IN (SELECT TransName FROM TransDim_Dts)
  	INSERT INTO TransDim(PosID, TransName, Up, Down) 
  	  SELECT @y_id, TransName, Up, Down FROM TransDim_Dts 
  	TRUNCATE TABLE TransDim_Dts
  	
  	/*分公司职员表*/
  	DELETE FROM employees WHERE emp_id IN (SELECT emp_id FROM employees_Dts)
  	SET IDENTITY_INSERT employees ON
  	INSERT INTO employees(emp_id, class_id, parent_id, child_number, child_count, name, alias, serial_number, dep_id, phone, address, comment, aplimit, arlimit, aptotal, artotal, discountlimit, ls, th, pinyin, deleted, LowPrice, HighPrice, SNCount, GSPSNCount, Study, Duty, GraduateDate, Teach, szWork, InDate, lim, deduct, RowIndex, IdCard, CertNo, Tp_ID, Y_ID, GradeId)
  	  SELECT emp_id, class_id, parent_id, child_number, child_count, name, alias, serial_number, dep_id, phone, address, comment, aplimit, arlimit, aptotal, artotal, discountlimit, ls, th, pinyin, deleted, LowPrice, HighPrice, SNCount, GSPSNCount, Study, Duty, GraduateDate, Teach, szWork, InDate, lim, deduct, RowIndex, IdCard, CertNo, Tp_ID, @y_id, GradeId FROM employees_Dts 
  	SET IDENTITY_INSERT employees OFF
  	TRUNCATE TABLE employees_Dts
	
  	/*把总公司PosPrice替换分公司Price 第一次同步是所有价格，后期价格同步条件只在总部的最低售价或零售价变化后 */
  	/*select* from price select * from posprice_dts   	*/
  	/*DELETE FROM price WHERE price_id IN (SELECT p.price_id FROM Price p INNER JOIN PosPrice_Dts dts ON p.p_id=dts.p_id AND p.u_id=dts.u_id)*/
  	
  	INSERT INTO price(p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid)
  	  SELECT p_id, u_id, retailprice, recprice, price1, price2, price3, price4, gpprice, glprice, specialprice, unittype, lowprice, lastprice, lasttime, billid FROM PosPrice_Dts
  	   WHERE price_id NOT in (SELECT dts.price_id FROM Price p INNER JOIN PosPrice_Dts dts ON p.p_id=dts.p_id AND p.u_id=dts.u_id)               
  	                 
  	UPDATE price SET retailprice=dts.retailprice,
  	                 lowprice=dts.lowprice
  	  FROM price p INNER join PosPrice_Dts dts ON p.p_id = dts.p_id AND p.u_id =dts.u_id                                  
  	    
    TRUNCATE TABLE PosPrice_Dts		
    /*xxx.这一段是给客户特殊处理下传价格跟踪（所有门店保持一致）	*/
 /*   
    --下传价格跟踪表
    TRUNCATE TABLE buypricehis    --先清空跟踪表
    update buypricehis_dts set y_id = @y_id
    
 /*   update buypricehis set BuyPrice= bt.BuyPrice,ModifyDate = bt.ModifyDate,BillType = bt.BillType,E_id = bt.E_id,
				discount = bt.discount,discountprice =bt.discountprice,taxrate = bt.taxrate,taxprice=bt.taxprice
    from buypricehis_dts bt  
	where buypricehis.c_id=bt.C_id and buypricehis.p_id=bt.P_id and buypricehis.unit_id=bt.unit_id and buypricehis.y_id = bt.y_id
			and buypricehis.ModifyDate < bt.ModifyDate    
*/

    insert into buypricehis(c_id, p_id, unit_id, BuyPrice, ModifyDate, quantity, BillType, Y_ID, E_id, discount, discountprice, taxrate, taxprice)
    select c_id, p_id, unit_id, BuyPrice, ModifyDate, quantity, BillType, Y_ID, E_id, discount, discountprice, taxrate, taxprice
    from buypricehis_dts


	TRUNCATE TABLE buypricehis_dts
	
	*/
    /*条码表无删除标记要单独处理*/
    DELETE FROM barcode WHERE p_id IN (SELECT p_id FROM barcode_Dts)
    INSERT INTO barcode(p_id, barcode, AutoCode, unitid, BarcodeType, codetype)
      SELECT p_id, barcode, AutoCode, unitid, BarcodeType, codetype FROM barcode_Dts 
    TRUNCATE TABLE barcode_Dts 
    
    /*分公司机构发货单c_id要替换成2 select * from billidx*/
    SELECT @s_id = IsNull(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'CenterSID' AND Y_ID = 2
    UPDATE BillIdx_Dts SET c_id=@PosID,sin_id=@s_id WHERE billtype IN (150,151,152,153,160,161,162,163)
    /*下传单据处理  生成发货单*/
    Exec TS_H_DtsDownBillDeal      
  END
  
  
  /*更改单据确认状态  3为确认*/
  /*UPDATE billidx SET transflag = 3 WHERE GUID IN (SELECT billguid FROM BillLog WHERE Status = 0) */
  /*                                   AND transflag = 1*/
  UPDATE billidx SET transflag = 3 FROM billidx b,BillLog bg 
    WHERE b.GUID = bg.BillGuid AND b.billtype = bg.BillType 
      AND b.TransFlag = 1 AND bg.Status = 0
  UPDATE billidx SET transflag = 0 WHERE GUID NOT IN (SELECT billguid FROM BillLog WHERE Status = 0)
                                     AND transflag = 1  
                                      
  UPDATE Integralidx SET transflag = 3 FROM Integralidx b,BillLog bg 
    WHERE b.billguid = bg.BillGuid AND bg.BillType in (12, 13) 
          and b.transflag <> 3 AND bg.Status = 0
  
  /*zjx--20170518--如果商品没有在PRICE表里的，将插入到PRICE表中*/
   insert into price(p_id,u_id,retailprice,recprice,price1,price2,price3,price4,gpprice,glprice,specialprice,unittype,
	     lowprice,lastprice,lasttime,billid )
   select  product_id,unit1_id,0,0,0,0,0,0,0,0,0,1,0,0,0,0 from products where product_id<>1 and product_id not in 
	  (select p_id from price) 
                                           
  TRUNCATE TABLE billlog_dts   
end
GO
