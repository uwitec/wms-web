




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/****************************************
月结存和反月结存
****************************************/
CREATE	PROCEDURE TS_C_MonthSettleAccount
(	@cMode      VARCHAR(1),
    @MonthName  VARCHAR(50),
	@EndDate    DATETIME,
	@comment    VARCHAR(50),
    @Y_id       Int
)  
/*with encryption*/

AS 
  SET NOCOUNT ON
  DECLARE @nperiod INT, @BeginDate DATETIME, @SQLScript VARCHAR(200),@szAccountPeriod CHAR(2)
  Declare @accountY_id int,@szyear varchar(10)
  select @accountY_id = sysvalue from sysconfig where [sysname] = 'Y_ID'
  if exists(select 1 from company where Ytype = 1 and  @Y_id <> @accountY_id)
    Return -5
  
  if OBJECT_ID('temp..#yidtmp') is not null
    drop table #yidtmp
  select  cast(0 as int) as Y_ID into #yidtmp
  

/*所有自营店和总部一起结存*/
  if @accountY_id = @Y_ID
  begin
    insert into #yidtmp(Y_ID) select company_id from company where company_id = @Y_ID or (superior_id = @Y_ID and Ytype = 1)
  end
  else
    insert into #yidtmp(Y_ID) select @Y_ID
  
  
  
BEGIN TRAN Mth
/*月结存*/
  IF @cMode='E'
  BEGIN
  /*  IF EXISTS(SELECT * FROM MonthSettleInfo WHERE [monthname]=@MonthName and Y_id=@Y_id) --期号相同，返回*/
  /*    GOTO Error03*/
    SELECT @BeginDate=[begindate], @nperiod=[period] FROM Monthsettleinfo WHERE [monthname]='本期' and Y_id=@Y_id
    IF @BeginDate>@EndDate GOTO Error02 
    
    set @szyear=DATEPART(YEAR,@BeginDate)

	if exists(select 1 from MonthSettlehis where accountyear=@szyear and period=@nperiod and y_id in (select Y_ID from #yidtmp)) /*期号相同，返回*/
	goto error03 
    
    
/*    IF @nperiod<12 */
    BEGIN
    	INSERT INTO Monthsettleinfo(yearname,[monthname], [begindate], [enddate], [period], [comment],[Y_id])
    	select @szyear,@monthname, @begindate, @EndDate, @nperiod, @comment, y_id from #yidtmp where y_id <> 0
        
    	IF @@ROWCOUNT<> 0
    	BEGIN   
    		SET @szAccountPeriod=RIGHT(@nperiod+100,2)
    		/*SET @SQLScript='UPDATE account SET total_'+@szAccountPeriod+'=[cur_total]'*/
    		/*EXEC(@SQLScript) */
    		/*IF @@ERROR<>0 GOTO Error*/
    		
    		insert into MonthSettlehis(jcdate,accountyear,period,aid,total,begindate,enddate,y_id)
    		select GETDATE(),@szyear,@nperiod,a_id,cur_total,@BeginDate,@EndDate,y_id
    		from accountbalance 
    		where y_id in (select y_id from #yidtmp)
    		
			IF @nperiod<12 SELECT @nperiod=@nperiod+1 else set @nperiod=1/*如果=12，期号设置为1*/
			
    		UPDATE Monthsettleinfo SET yearname=DATEPART(YEAR,DATEADD(DAY, 1, @EndDate)), [begindate]=DATEADD(DAY, 1, @EndDate), [period]=@nperiod,EndDate=null WHERE [monthname]='本期' and Y_Id in (select Y_ID from #yidtmp)
    		IF @@ERROR<>0 GOTO Error
    		EXEC TS_SetSysValue 'AccountPeriod', @nperiod,@Y_id
    		IF @@ERROR<>0 GOTO Error
       
			UPDATE BillIDX SET [Period]=@nPeriod WHERE billdate > @EndDate and Y_Id in (select Y_ID from #yidtmp)
			IF @@ERROR<>0 GOTO Error

    	END 
      ELSE GOTO Error
    END 
/*    ELSE
    BEGIN
    	UPDATE Monthsettleinfo SET Enddate=@EndDate WHERE [MonthName]='本期' and Y_Id in (select Y_ID from #yidtmp)
    	IF @@ERROR<>0 GOTO Error
    	SET @szAccountPeriod=RIGHT(@nperiod+100, 2)
    	IF @@ERROR<>0 GOTO Error
    	SET @SQLScript='UPDATE account SET total_'+@szAccountPeriod+'=[cur_total]'
    	EXEC(@SQLScript) 
    	IF @@ERROR<>0 GOTO Error
    END
*/    
    SET @monthname='0'
    SELECT @monthname=[sysvalue] FROM sysconfig WHERE [sysname]='billsnlex3'
    IF @monthname='1'
    BEGIN
      UPDATE billsnstyle SET [sncount]=0
      UPDATE sysconfig SET [sysvalue]=0 WHERE [sysname]='billsncount'
    END
    
    SET @monthname='0'
    SELECT @monthname=sysvalue FROM sysconfig WHERE [sysname]='gspsnlex3'
    IF @monthname='1'
    BEGIN
      UPDATE gspsnstyle SET [sncount]=0
      UPDATE sysconfig SET [sysvalue]=0 WHERE [sysname]='gspsncount'
    END
  END
  ELSE
  BEGIN
/*反月结存*/
    declare @ncount1 int
    set @ncount1=0
    select @ncount1=COUNT(*) from MonthSettleInfo
    if @ncount1=1 goto error04
    
    
    SELECT @BeginDate=[begindate], @nperiod=[period],@szyear=yearname FROM Monthsettleinfo WHERE [monthname]='本期'  and Y_ID = @Y_id
    /*IF @BeginDate>@EndDate GOTO Error02 */
    
    
    DELETE FROM Monthsettleinfo WHERE [monthname]='本期' and Y_Id in (select Y_ID from #yidtmp) and yearname=@szyear
	IF @@ERROR<>0 GOTO Error
    
    IF @nperiod<=1  
    begin
      /*set @nperiod=12 */
      select @szyear=yearname,@nperiod=period from monthsettleinfo where DATEADD(day,-1,@BeginDate) between begindate and enddate and y_id=@y_id
	end
	else
	begin
	  /*SET @nperiod=@nperiod-1*/
      select @szyear=yearname,@nperiod=period from monthsettleinfo where DATEADD(day,-1,@BeginDate) between begindate and enddate and y_id=@y_id
	end
    
	
	delete from MonthSettlehis where accountyear=@szyear and period=@nperiod and Y_Id in (select Y_ID from #yidtmp)
	IF @@ERROR<>0 GOTO Error

    UPDATE Monthsettleinfo SET [monthname]='本期', [enddate]=null WHERE [period]=@nperiod and Y_Id in (select Y_ID from #yidtmp) and yearname=@szyear and yearname=@szyear
	IF @@ERROR<>0 GOTO Error
	EXEC TS_SetSysValue 'AccountPeriod', @nperiod
	IF @@ERROR<>0 GOTO Error
	select @BeginDate=begindate from MonthSettleInfo where [monthname]='本期' and Y_Id in (select Y_ID from #yidtmp) and yearname=@szyear
    UPDATE BillIDX SET [period]=@nperiod WHERE [billdate] >= @BeginDate and Y_Id in (select Y_ID from #yidtmp)
	IF @@ERROR<>0 GOTO Error
  END

  COMMIT TRAN Mth
  RETURN 0

Error:
	ROLLBACK TRAN Mth
	RETURN -1
	
Error02:
/*开始日期小于结束日期*/
	ROLLBACK TRAN Mth
  RETURN -2

Error03:
/*该会计期名已存在*/
	ROLLBACK TRAN Mth
 	RETURN -3 

Error04:
/*已经达到开账日期*/
	ROLLBACK TRAN Mth
 	RETURN -4
Error05:
/*不能反月结存期号为1的帐本*/
	ROLLBACK TRAN Mth
 	RETURN -5
GO
