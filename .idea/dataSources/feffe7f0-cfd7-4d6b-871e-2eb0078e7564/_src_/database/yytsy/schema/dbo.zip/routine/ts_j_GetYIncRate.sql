/************************************************************

--功能：按机构发货方式加价率   
--创建人：Zhou JiLin 
--创建时间：2014-05-07  
--最后修改: 2014-05-07

参数说明：nMode 2 按机构加价率， 3 按商品加价率

**************************************************************/

CREATE	 PROCEDURE ts_j_GetYIncRate
	(
      @nY_ID int = 0,
      @nP_id int = 0,
      @nMode int = 0
     )
AS
  declare @nIncMode int
   
  if @nMode = 2
    select incRate from company where company_id=@nY_ID
  else 
  if @nMode = 3
  begin
    select @nIncMode = incRateMode from company where company_id=@nY_ID
    select  Case @nIncMode when 1 then incRate when 2 then incRate2
                           when 3 then incRate3  else 1 end as incRate    
      from products where product_id = @nP_id         
  end
  else 
    select 1 as incRate
GO
