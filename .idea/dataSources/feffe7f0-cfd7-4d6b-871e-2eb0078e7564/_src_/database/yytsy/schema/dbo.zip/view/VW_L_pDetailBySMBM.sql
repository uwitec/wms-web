

CREATE VIEW DBO.VW_L_pDetailBySMBM
AS
SELECT 
   sm.smb_id AS [pd_id],
   sm.bill_id AS [billid],
   sm.p_id AS [p_id], 
   sm.ss_id AS [s_id],
   sm.sd_id as [sd_id],
   p.Class_id as PClass_id,
   (case when dbo.billidx.BillType in(10,12,16,110,112,210,212) then -sm.quantity else sm.quantity end) AS [quantity],
   sm.saleprice AS [price],
   (case when dbo.billidx.billtype in(10,12,16,110,112,210,212) then -(sm.total) else (sm.total) end) AS [total],
   sm.costprice AS [costprice],
   sm.discountprice AS [discountPrice],
   (case when dbo.billidx.BillType in(10,12,16,110,112,210,212) then -sm.[quantity]*sm.[costprice] else sm.[quantity]*sm.[costprice] end) AS [costtotal],
   (case when dbo.billidx.BillType in(10,12,16,110,112,210,212) then -sm.totalmoney else sm.totalmoney end) AS totalmoney,
   sm.taxprice AS [taxprice],
   (case when dbo.billidx.billtype in(10,12,16,110,112,210,212) then (-sm.taxtotal) else sm.taxtotal end) AS [taxtotal],
   (case when dbo.billidx.billtype in(10,12,16,110,112,210,212) then (-sm.SendQTY) else sm.SendQTY end) as SendQTY,   
   (case when dbo.billidx.billtype in(10,12,16,110,112,210,212) then (-sm.SendCostTotal) else sm.SendCostTotal end) as SendCostTotal,
   sm.batchno AS [batchno],
   sm.makedate AS [makedate],
   sm.validdate AS [validdate],
   sm.commissionflag AS [commissionflag],
   sm.supplier_id AS [supplier_id],
   sm.location_id AS [location_id],
   0 AS [storetype],
   sm.price_id AS [price_id],
   sm.order_id AS [order_id],
   sm.unitid AS [unitid],
   sm.smb_id AS [smb_id],
   sm.comment AS [comment],
   sm.jsprice AS [jsprice],
   0 AS  [oldcommissionflag],
   sm.aoid,/*0 as aoid,*/
   isnull(storages_2.class_id,'') AS sclass_id, 
   isnull(storages_1.class_id,'') AS sdClass_id,
   isnull(storages_2.name,'')  AS sname,
   isnull(storages_1.name,'') AS sdname, 
   ISNULL(p.[name],'') AS pname,p.makearea,p.standard,
   isnull(l.loc_name,'') AS locname,
   isnull(c.class_id,'') as CClass_id,
   isnull(c.[name],'') AS suppliername,
   retailprice,
   retailtotal,
   isnull(e.class_id,'') as REClass_id,
   isnull(e.[name],'') as REname,
   sm.rowe_id

FROM 
   dbo.salemanagebill sm

   LEFT OUTER JOIN
       dbo.products p ON sm.p_id = p.product_id
   LEFT OUTER JOIN
       dbo.storages storages_1 ON 
       sm.sd_id = storages_1.storage_id 
      LEFT OUTER JOIN
      dbo.storages storages_2 ON  sm.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON  sm.unitid = u.unit_id
      LEFT OUTER JOIN
      location l on sm.location_id=l.loc_id
      LEFT OUTER JOIN
      clients c on sm.supplier_id=c.client_id
      LEFT OUTER JOIN
      employees e on sm.rowe_id=e.emp_id,

    dbo.billidx
    WHERE dbo.billidx.[billstates]='0' AND dbo.billidx.[billtype] IN (10,11,12,13,32,110,111,112,16,17,210,211,212)
    AND sm.bill_id=dbo.billidx.billid and sm.aoid in (0, 5,7) and p_id>0
union all

SELECT 
   bm.smb_id AS [pd_id],
   bm.bill_id AS [billid],
   bm.p_id AS [p_id],/*产品ID */
   bm.ss_id AS [s_id],/*库房ID*/
   bm.sd_id AS [sd_id],
   p.Class_id as Pclass_id,
   case when dbo.billidx.BillType in(21,25,121,122,221) then -bm.quantity else bm.quantity end AS [quantity],
   bm.buyprice AS [price],
   case when dbo.billidx.billtype in(21,25,121,122,221) then -(bm.total) else (bm.total) end AS [total],
   bm.costprice AS [costprice],
   bm.discountprice AS [discountPrice],
   case when dbo.billidx.BillType in(21,25,121,122,221) then -bm.quantity*bm.costprice else bm.quantity*bm.costprice end AS [costtotal],
   case when dbo.billidx.BillType in(21,25,121,122,221) then -bm.totalmoney else bm.totalmoney end AS totalmoney,
   bm.taxprice AS [taxprice],
   case when dbo.billidx.billtype in(21,25,121,122,221) then (-bm.taxtotal) else bm.taxtotal end AS [taxtotal],
   case when dbo.billidx.billtype in(21,25,121,122,221) then (-bm.SendQTY) else bm.SendQTY end as SendQTY,   
   case when dbo.billidx.billtype in(21,25,121,122,221) then (-bm.SendCostTotal) else bm.SendCostTotal end as SendCostTotal,
   bm.batchno AS [batchno],
   bm.makedate AS [makedate],
   bm.validdate AS [validdate],
   bm.commissionflag AS [commissionflag],
   bm.supplier_id AS [supplier_id],        
   bm.location_id AS [location_id],
   0 AS [storetype],
   bm.price_id AS [price_id],  
   bm.order_id AS [order_id],
   bm.unitid AS [unitid],
   bm.smb_id AS [smb_id],
   bm.comment AS [comment],
   bm.jsprice AS [jsprice],
   0 AS  [oldcommissionflag],
   bm.aoid,/*0 as aoid,*/
   isnull(storages_2.class_id,'') AS ssclass_id, 
   isnull(storages_1.class_id,'') AS sdclass_id, 
   isnull(storages_2.name,'') AS ssname, 
   isnull(storages_1.name,'') AS sdname,
   ISNULL(p.[name],'') AS pname,p.makearea,p.standard,
   isnull(l.loc_name,'') as locname,
   isnull(c.class_id,'') as CClass_id,
   isnull(c.[name],'') as suppliername,
   retailprice,
   retailtotal,
   isnull(e.class_id,'') as REClass_id,
   isnull(e.[name],'') as REname,
   bm.rowe_id

FROM 
   dbo.buymanagebill bm
   LEFT OUTER JOIN
       dbo.products p ON bm.p_id = p.product_id
   LEFT OUTER JOIN
   dbo.storages storages_1 ON bm.sd_id = storages_1.storage_id
   LEFT OUTER JOIN
   dbo.storages storages_2 ON bm.ss_id = storages_2.storage_id
   LEFT OUTER JOIN
   unit u ON  bm.unitid = u.unit_id
   LEFT OUTER JOIN
   location l on bm.location_id=l.loc_id
   LEFT OUTER JOIN
   clients  c on bm.supplier_id=c.client_id
   LEFT OUTER JOIN
   employees e on bm.rowe_id=e.emp_id,

   dbo.billidx
   WHERE dbo.billidx.[billstates]='0' AND dbo.billidx.[billtype] IN (20,21,35,120,121,122,24,25,220,221,222)
   AND bm.bill_id=dbo.billidx.billid and bm.aoid in (0, 5,7) and p_id>0
UNION

SELECT 
   tm.smb_id AS [pd_id],
   tm.bill_id AS [billid],
   tm.p_id AS [p_id], 
   tm.ss_id AS [s_id],
   tm.sd_id AS [sd_id],
   p.Class_id as PClass_id,
   (case when dbo.billidx.BillType in(53,56) then -tm.quantity else tm.quantity end) AS [quantity],
   tm.saleprice AS [price],
   (case when dbo.billidx.billtype in(53,56) then -(tm.total) else (tm.total) end) AS [total],
   tm.costprice AS [costprice],
   tm.discountprice AS [discountPrice],
   (case when dbo.billidx.BillType in(53,56) then -tm.quantity*tm.costprice else tm.quantity*tm.costprice end) AS [costtotal],
   (case when dbo.billidx.BillType in(53,56) then -tm.totalmoney else tm.totalmoney end) AS totalmoney, 
   tm.taxprice AS [taxprice],
   (case when dbo.billidx.billtype in(53,56) then (-tm.taxtotal) else tm.taxtotal end) AS [taxtotal],
   (case when dbo.billidx.billtype in(53,56) then (-tm.SendQTY) else tm.SendQTY end) as SendQTY,   
   (case when dbo.billidx.billtype in(53,56) then (-tm.SendCostTotal) else tm.SendCostTotal end) as SendCostTotal,
   tm.batchno AS [batchno],
   tm.makedate AS [makedate],
   tm.validdate AS [validdate],
   tm.commissionflag AS [commissionflag],
   tm.supplier_id AS [supplier_id],
   tm.location_id AS [location_id],
   0 AS [storetype],
   tm.price_id AS [price_id],
   tm.order_id AS [order_id],
   tm.unitid AS [unitid],
   tm.smb_id AS [smb_id],
   tm.comment AS [comment],
   0 AS [jsprice],
   0 AS  [oldcommissionflag],
   tm.aoid,/*0 as aoid,*/
   ISNULL(storages_2.class_id, '') AS sclass_id,
   ISNULL(storages_1.class_id, '') AS sdclass_id,
   ISNULL(storages_2.name, '')     AS sname,
   ISNULL(storages_1.name, '')     AS sdname,
   ISNULL(p.[name],'') AS pname,p.makearea,p.standard,
    ('') AS locname,
   isnull(c.class_id,'') as CClass_id,
   ISNULL(c.name, '')  AS suppliername,
   retailprice,
   retailtotal,
   isnull(e.class_id,'') as REClass_id,
   isnull(e.[name],'') as REname,
   tm.rowe_id

FROM 
   TranManagebill tm
   LEFT  JOIN
       dbo.products p ON tm.p_id = p.product_id
   LEFT  JOIN
       dbo.clients  C ON tm.supplier_id = c.client_id
   LEFT  JOIN
      storages storages_1 ON  tm.sd_id = storages_1.storage_id
   LEFT  JOIN
      storages storages_2 ON  tm.ss_id = storages_2.storage_id 
   LEFT  JOIN
      dbo.unit u     ON tm.unitid = u.unit_id
   LEFT OUTER JOIN
   employees e on tm.rowe_id=e.emp_id,
   dbo.billidx
    WHERE dbo.billidx.[billstates]='0' AND dbo.billidx.[billtype] IN (53,54,55,56)
    AND tm.bill_id=dbo.billidx.billid and tm.aoid in (0, 5,7) and p_id>0

union ALL
SELECT 
   smb.smb_id AS [pd_id],
   smb.bill_id AS [billid],
   smb.p_id AS [p_id], 
   smb.ss_id AS [s_id],
   smb.sd_id AS [sd_id],
   p.Class_id as PClass_id,
   (case when dbo.billidx.BillType in(41,49) then -smb.quantity else smb.quantity end) AS [quantity],
   smb.price AS [price],
   (case when dbo.billidx.billtype in(41,49) then -(smb.total) else (smb.total) end) AS [total],
   smb.costprice AS [costprice],
   smb.costprice AS [discountPrice],
   (case when dbo.billidx.BillType in(41,49) then -smb.quantity*smb.costprice else smb.quantity*smb.costprice end) AS [costtotal],
   (case when dbo.billidx.billtype in(41,49) then -smb.totalmoney else smb.totalmoney end) AS totalmoney,
   0 AS [taxprice],
   0 AS [taxtotal],
   (case when dbo.billidx.billtype in(41,49) then (-smb.SendQTY) else smb.SendQTY end) as SendQTY,   
   (case when dbo.billidx.billtype in(41,49) then (-smb.SendCostTotal) else smb.SendCostTotal end) as SendCostTotal,

   smb.batchno AS [batchno],
   smb.makedate AS [makedate],
   smb.validdate AS [validdate],
   smb.commissionflag AS [commissionflag],
   smb.supplier_id AS [supplier_id],
   smb.location_id AS [location_id],
   0 AS [storetype],
   smb.price_id AS [price_id],
   0 AS [order_id],
   smb.unitid AS [unitid],
   smb.smb_id AS [smb_id],
   smb.comment AS [comment],
   0 AS [jsprice],
   0 AS  [oldcommissionflag],
   smb.aoid,/*0 as aoid,*/
    ISNULL(storages_2.class_id, '') AS sclass_id,
    ISNULL(storages_1.class_id, '') AS sdclass_id, 
    ISNULL(storages_2.name, '')     AS sname,
    ISNULL(storages_1.name, '')     AS sdname, 
    ISNULL(p.[name],'') AS pname,p.makearea,p.standard,
    ('') AS locname,
    ('') as CClass_id,
    ('') AS suppliername,
   0 as retailprice,
   0 as retailtotal,
   isnull(e.class_id,'') as REClass_id,
   isnull(e.[name],'') as REname,
   smb.rowe_id
FROM 
   storemanagebill smb
   LEFT OUTER JOIN
       dbo.products p      ON smb.p_id = p.product_id
   LEFT OUTER JOIN
       storages storages_1 ON smb.sd_id = storages_1.storage_id
   LEFT OUTER JOIN
       storages storages_2 ON smb.ss_id = storages_2.storage_id
   LEFT OUTER JOIN
       unit u              ON smb.unitid = u.unit_id
   LEFT OUTER JOIN
   employees e on smb.rowe_id=e.emp_id,

   dbo.billidx
   WHERE dbo.billidx.[billstates]='0' AND dbo.billidx.[billtype] IN (41,42,44,45,48,49)
   AND smb.bill_id=dbo.billidx.billid and smb.aoid in (0, 5,7) and p_id>0
GO
