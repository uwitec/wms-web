
CREATE VIEW dbo.VW_H_AvlStoreQty
AS
SELECT   s.p_id, s.costprice, s.makedate, s.validdate, s.location_id, s.supplier_id, s.commissionflag, s.instoretime, s.s_id, 
                s.batchno, s.quantity - ISNULL(b_1.qty, 0) AS qty, s.Y_ID, s.BatchBarCode, s.scomment, s.batchprice
FROM      dbo.storehouse AS s INNER JOIN vw_avlSid aa
			ON S.s_id = aa.s_id	LEFT OUTER JOIN
                    (SELECT   p_id, SUM(quantity) AS qty, costprice, makedate, validdate, location_id, supplier_id, commissionflag, 
                                     instoretime, ss_id, batchno
                     FROM      (SELECT   b.p_id, b.quantity, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.commissionflag, b.instoretime, b.ss_id, b.batchno
                                      FROM      dbo.billdraftidx AS i INNER JOIN
                                                      dbo.salemanagebilldrf AS b ON i.billid = b.bill_id
                                      WHERE   (i.billtype IN (10, 210, 150, 152)) AND NOT EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'GspStandardProcess' AND sysvalue = '1')
                                      UNION ALL
                                      SELECT   b.p_id, b.quantity, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.commissionflag, b.instoretime, b.ss_id, b.batchno
                                      FROM      dbo.orderidx AS i INNER JOIN
                                                      dbo.OrderBill AS b ON i.billid = b.bill_id
                                      WHERE   (i.billtype IN (14)) AND (i.billstates <> '0') AND EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'GspStandardProcess' AND sysvalue = '1')
                                      UNION ALL
                                      SELECT   b.p_id, b.ApplicantQty, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.commisionflag, b.instoretime, b.s_id, b.batchno
                                      FROM      dbo.GSPbillidx AS i INNER JOIN
                                                      dbo.GSPbilldetail AS b ON i.Gspbillid = b.Gspbill_id
                                      WHERE   (i.billtype IN (561)) AND EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'GspStandardProcess' AND sysvalue = '1')
                                      UNION ALL
                                      SELECT   b.p_id, b.quantity, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.commissionflag, b.instoretime, b.ss_id, b.batchno
                                      FROM      dbo.billdraftidx AS i INNER JOIN
                                                      dbo.buymanagebilldrf AS b ON i.billid = b.bill_id
                                      WHERE   (i.billtype IN (21, 221)) AND NOT EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'GspStandardProcess' AND sysvalue = '1')
                                      UNION ALL
                                      SELECT   b.p_id, b.Yqty, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.CommisionFlag, b.instoretime, b.s_id, b.batchno
                                      FROM      dbo.GSPbillidx AS i INNER JOIN
                                                      dbo.GSPbilldetail AS b ON i.Gspbillid = b.Gspbill_id
                                      WHERE   (i.billtype IN (541) AND (i.BillStates IN(10, 14))
											AND B.OrgBillid NOT IN(SELECT OrgBillid FROM salemanagebilldrf WHERE bill_id IN (SELECT BILLID FROM billdraftidx WHERE BillType IN(150, 152)))
											AND B.OrgBillid NOT IN(SELECT OrgBillid FROM salemanagebill WHERE bill_id IN (SELECT BILLID FROM billidx WHERE BillType IN(150, 152)))
											)
                                      UNION ALL
                                      SELECT   b.p_id, b.quantity, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, 
                                                      b.commissionflag, b.instoretime, b.ss_id, b.batchno
                                      FROM      dbo.billdraftidx AS i INNER JOIN
                                                      dbo.storemanagebilldrf AS b ON i.billid = b.bill_id
                                      WHERE   (i.billtype IN (44, 45))) AS a
                     GROUP BY p_id, costprice, makedate, validdate, location_id, supplier_id, commissionflag, instoretime, ss_id, 
                                     batchno) AS b_1 ON s.validdate = b_1.validdate AND s.commissionflag = b_1.commissionflag AND 
                s.instoretime = b_1.instoretime AND s.makedate = b_1.makedate AND s.batchno = b_1.batchno AND 
                s.costprice = b_1.costprice AND s.supplier_id = b_1.supplier_id AND s.s_id = b_1.ss_id AND 
                s.location_id = b_1.location_id AND s.p_id = b_1.p_id
			WHERE S.stopsaleflag = 0
GO
