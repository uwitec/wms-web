

CREATE VIEW dbo.vw_L_MemberCard
AS
SELECT m.*, isnull(t .ctypeid, 0) AS ctypeid, isnull(t .typename, '') AS ttypeName, 
      isnull(t .discount, 0) AS tdiscount, isnull(t .comment, '') AS tComment, 
      isnull(t .Autodiscount, 0) AS tAutoDiscount, 
      Typename = CASE m.cardtype WHEN 0 THEN '会员卡' WHEN 1 THEN '打折卡' WHEN 2
       THEN '储值卡' END
FROM dbo.membercard m LEFT OUTER JOIN
      dbo.cardtype t ON m.DiscountType = t .CTypeId
GO
