create procedure Ts_E_GetCategoryYPCId
    @TableName varchar(100),
    @categoryClass varchar(100),
    @CategoryId    int
as
  DECLARE @cColName varchar(100)
  DECLARE @szSql varchar(2000)
begin
   set @cColName = dbo.GetColName(@CategoryId,@TableName)  
   if @TableName='ProductCategory'
   begin
	    set @szSql =  'select  P_id as pcy_id  from ProductCategory where ' + 
		' ' + @cColName + ' in (select type  from DecodeStr(''' +@categoryClass +'''))'  
		exec (@szSql)
   end
   if @TableName='ClientCategory'
   begin
	    set @szSql =  'select  C_id as pcy_id  from ClientCategory where ' + 
		' ' + @cColName + ' in (select type  from DecodeStr(''' +@categoryClass +'''))'  
		exec (@szSql)
   end
   if @TableName='CompanyCategory'
   begin
		set @szSql =  'select  Y_id as pcy_id  from CompanyCategory where ' + 
		' ' + @cColName + ' in (select type  from DecodeStr(''' +@categoryClass +'''))'  
		exec (@szSql)
   end
end
GO
