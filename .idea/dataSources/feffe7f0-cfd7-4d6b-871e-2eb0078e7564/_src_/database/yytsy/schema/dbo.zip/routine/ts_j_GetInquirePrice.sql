/************************************************************

--功能：读取报价单价格   
--创建人：Zhou JiLin 
--创建时间：2009-08-08  
--最后修改:

参数说明：

**************************************************************/

CREATE PROCEDURE [ts_j_GetInquirePrice]
	(
	  @c_id int, 
	  @P_ID int, 
	  @u_id int, 
	  @Y_ID int,
	  @QrMode int /*0, 销售 1采购*/
     )
AS
declare @nRet int 
declare @dtToday datetime, @i int, @nUnitID int /*@billdate datetime, @price NUMERIC(25,8) */
set @dtToday = cast(cast(GETDATE() as  varchar(10)) as datetime)
if @QrMode = 0 set @QrMode = 18
if @QrMode = 1 set @QrMode = 27
set @nRet = -1



/*declare @retailprice numeric(8,4),@GPprice numeric(8,4),@GLprice numeric(8,4)
declare @PosPrice int
exec ts_GetSysValue 'PosPrice',@PosPrice out,2

if @PosPrice=0 
  select @retailprice=isnull(retailprice,0),@GPprice=ISNULL(gpprice,0),@Glprice=ISNULL(glprice,0)
    from price pc,products p where p_id=@P_ID and pc.p_id=p.product_id  and pc.u_id=@u_id
else
  select @retailprice=isnull(retailprice,0),@GPprice=ISNULL(gpprice,0),@Glprice=ISNULL(glprice,0)
    from PosPrice pc,products p where p_id=@P_ID and pc.Y_id=@Y_ID and pc.p_id=p.product_id and pc.u_id=@u_id
*/

if OBJECT_ID('tempdb..#Inquiretmp') is not null
  drop table #Inquiretmp
  
  select idx.billid, idx.billdate, mx.p_id, mx.price, mx.unitid into #Inquiretmp
    from (select billid, billdate from PRICEINQUIREIDX where Y_id = @Y_ID and c_id = @c_id and billtype = @Qrmode and @dtToday>= begindate and @dtToday <= endDate and billstates=3) idx
    inner join (select bill_id, p_id, price, unitid from PriceInquireBill where y_id = @Y_ID and p_id = @P_ID) mx 
    on idx.billid = mx.bill_id


if exists(select * from #Inquiretmp where unitid = @u_id)
begin
  select top 1 price, billdate /*,@retailprice as retailprice, @GPprice as Gpprice, @Glprice as Glprice*/
    from #Inquiretmp where unitid = @u_id order by billid desc
  if @@ROWCOUNT =1 set @nRet = 0
end
if OBJECT_ID('tempdb..#Inquiretmp') is not null
  drop table #Inquiretmp
  
return @nRet
GO
