







CREATE PROCEDURE ts_c_DelAccount
(
	@dbid int
)
 AS
set nocount on
delete from tsaccount where aid=@dbid
GO
