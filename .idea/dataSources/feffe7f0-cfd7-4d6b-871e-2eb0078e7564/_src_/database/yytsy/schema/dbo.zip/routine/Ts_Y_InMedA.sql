/************************************************************
--过程名称：Ts_Y_InMedA
--功能    ：医保药品目录下载写入本地药品基本资料
--创建人  ：YANRUI 
--创建时间：2013-12-20  
**************************************************************/
CREATE	  PROCEDURE [dbo].[Ts_Y_InMedA]
(@A0  varchar(14),
 @A1  varchar(20),
 @A2  varchar(200),
 @A3  varchar(14),
 @A4  varchar(100),
 @A5  varchar(14),
 @A6  varchar(100),
 @A7  varchar(4),
 @A8  varchar(3),
 @A9  varchar(3),
 @A10 varchar(3),
 @A11 varchar(3),
 @A12 varchar(12),
 @A13 varchar(12),
 @A14 varchar(12),
 @A15 varchar(12),
 @A16 varchar(12),
 @A17 varchar(12),
 @A18 varchar(12),
 @A19 varchar(20),
 @A20 varchar(12),
 @A21 varchar(14),
 @A22 varchar(8),
 @A23 varchar(14),
 @A24 varchar(8),
 @A25 varchar(14),
 @A26 varchar(3),
 @A27 varchar(200),
 @A28 varchar(3),
 @A29 varchar(20),
 @A30 varchar(3),
 @A31 varchar(12),
 @A32 varchar(12),
 @A33 varchar(3),
 @A34 varchar(12),
 @A35 varchar(12),
 @A36 varchar(12),
 @A37 varchar(12), 
 @A38 varchar(12),
 @A39 varchar(12),
 @A40 varchar(12),
 @A41 varchar(12),
 @A42 varchar(12),
 @A43 varchar(12),
 @A44 varchar(12),
 @A45 varchar(3), 
 @A46 varchar(3),
 @A47 varchar(3),
 @A48 varchar(3),
 @A49 varchar(3),
 @A50 varchar(14),
 @A51 varchar(400) 
)
as
 declare @cts int
 set @cts=(select count(1) from MedicaDictionaryA1 where A0=@A0)	
 if  @cts<=0 
 begin
    insert into MedicaDictionaryA1
    (A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A20,A21,A22,A23,A24,A25,A26,
     A27,A28,A29,A30,A31,A32,A33,A34,A35,A36,A37,A38,A39,A40,A41,A42,A43,A44,A45,
     A46,A47,A48,A49,A50,A51)
	 VALUES
    (@A0,@A1,@A2,@A3,@A4,@A5,@A6,@A7,@A8,@A9,@A10,@A11,@A12,@A13,@A14,@A15,@A16,@A17,@A18,@A19,@A20,
    @A21,@A22,@A23,@A24,@A25,@A26,@A27,@A28,@A29,@A30,@A31,@A32,@A33,@A34,@A35,@A36,@A37,@A38,
    @A39,@A40,@A41,@A42,@A43,@A44,@A45,@A46,@A47,@A48,@A49,@A50,@A51)  
 end
 else
 begin
   update MedicaDictionaryA1 
    set  A1=@A1,A2=@A2,A3=@A3,A4=@A4,A5=@A5,A6=@A6,A7=@A7,A8=@A8,
    A9=@A9,A10=@A10,A11=@A11,A12=@A12,A13=@A13,A14=@A14,A15=@A15,
    A16=@A16,A17=@A17,A18=@A18,A19=@A19,A20=@A20,A21=@A21,A22=@A22,
    A23=@A23,A24=@A24,A25=@A25,A26=@A26,A27=@A27,A28=@A28,A29=@A29,
    A30=@A30,A31=@A31,A32=@A32,A33=@A33,A34=@A34,A35=@A35,A36=@A36,
    A37=@A37,A38=@A38,A39=@A39,A40=@A40,A41=@A41,A42=@A42,A43=@A43,
    A44=@A44,A45=@A45,A46=@A46,A47=@A47,A48=@A48,A49=@A49,A50=@A50,
    A51=@A51   
   where A0=@A0
 end
GO
