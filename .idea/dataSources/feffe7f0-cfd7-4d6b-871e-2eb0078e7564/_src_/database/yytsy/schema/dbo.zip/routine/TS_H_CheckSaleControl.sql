
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-7-3*/
/* Description:	检测往来单位是否满足开单条件*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_CheckSaleControl] 
	@c_id int,
	@y_id int,
	@nRet int output
AS
BEGIN
	SET NOCOUNT ON;
	
	set @nRet = 0

	declare @nSaleControlType int	/* 0: 不检测，1：收款期限，2：信用额度，3：收款期限、信用额度*/
	select @nSaleControlType = sysvalue from sysconfig where sysname = 'SaleControl' and Y_ID = 0
	
	declare @nCredit NUMERIC(25,8)
	declare @nRest NUMERIC(25,8)
	
	if @nSaleControlType = 0
		set @nRet = 0
	else
	begin
		if @nSaleControlType in (1, 3)
		begin
			if exists(select 0 from billidx where c_id = @c_id and skdate <= GETDATE() and billstates = '0' and billtype in(10, 210) and jsye > 0 and skdate > '1900-1-1' and Y_ID = @y_id)
				set @nRet = -1
		end
		if @nSaleControlType in (2, 3)
		begin
			select @nCredit = credit_total, @nRest = credit_total - (artotal - aptotal + pre_aptotal - pre_artotal) from Clientsbalance where Y_id = @y_id and C_ID = @c_id
			if @nCredit <> 0 and @nRest < 0
				set @nRet = -1
		end
	end
END
GO
