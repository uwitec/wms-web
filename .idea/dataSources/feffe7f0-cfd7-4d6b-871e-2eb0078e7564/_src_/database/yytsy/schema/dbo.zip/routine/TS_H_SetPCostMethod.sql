
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-8-19*/
/* Description:	设置商品成本核算法*/
/* =============================================*/
CREATE PROCEDURE TS_H_SetPCostMethod
	@Pid			int,		/* 商品ID*/
	@CostMethod		int,		/* 成本核算法 0:移动加权，1:先进先出，2:后进先出，3:手工指定*/
	@WithChildren	bit			/* 是否包括下级商品*/
AS
BEGIN
	SET NOCOUNT ON;

	declare @szOpenAccount varchar(60)
	declare @class_id varchar(30)
	select @class_id = class_id from products where product_id = @Pid
	CREATE TABLE #tmpP(product_id INT)
	if @WithChildren = 1
		INSERT INTO #tmpP SELECT product_id from products where class_id like @class_id + '%' 
		and product_id not in (select distinct p_id from productdetail)
		and product_id not in (select distinct p_id from storehouseini) /*add by luowei 2011-10-19 :有期初信息的商品不允许修改成本算法*/
		and product_id not in (select distinct p_id from storedxini) 
		and product_id not in (select distinct p_id from storebrrowini)
	else
	begin
	if(   not exists(select p_id from productdetail where p_id = @Pid)
	  and not exists(select p_id from storehouseini where p_id = @Pid)
	  and not exists(select p_id from storedxini where p_id = @Pid)
	  and not exists(select p_id from storebrrowini where p_id = @Pid))
	begin          
		INSERT INTO #tmpP VALUES(@Pid)
    end		
    end		
		
	/* 改为移动加权*/
	if @CostMethod = 0
	begin
		exec ts_GetSysValue 'OpenAccount', @szOpenAccount output, 2
		/* 是否开账*/
		if @szOpenAccount = '1'
		begin
			SELECT     p_id, s_id, SUM(quantity) AS quantity, AVG(costprice) AS costprice, Y_ID, SUM(costtotal) AS costtotal
			INTO #tmpStorehouse
			FROM         dbo.storehouse
			WHERE     (stopsaleflag = 0) AND p_id IN (select product_id from #tmpP)
			GROUP BY p_id, s_id, Y_ID
			
			DELETE FROM storehouse WHERE (stopsaleflag = 0) AND p_id IN (select product_id from #tmpP)
			INSERT INTO storehouse(p_id, s_id, quantity, costprice, costtotal, y_id, makedate, validdate, instoretime, yhdate)
			SELECT p_id, s_id, quantity, costprice, costtotal, y_id, '1899-12-30', '1899-12-30', CONVERT(varchar(10), GETDATE(), 120), CONVERT(varchar(10), GETDATE(), 120) FROM #tmpStorehouse
		end
		else
		begin
			SELECT     p_id, s_id, SUM(quantity) AS quantity, AVG(costprice) AS costprice, Y_ID, SUM(costtotal) AS costtotal
			INTO #tmpStorehouseini
			FROM         dbo.storehouseini
			WHERE     (stopsaleflag = 0) AND p_id IN (select product_id from #tmpP)
			GROUP BY p_id, s_id, Y_ID
			
			DELETE FROM storehouseini WHERE (stopsaleflag = 0) AND p_id IN (select product_id from #tmpP)
			INSERT INTO storehouseini(p_id, s_id, quantity, costprice, costtotal, y_id, makedate, validdate, instoretime, yhdate)
			SELECT p_id, s_id, quantity, costprice, costtotal, y_id, '1899-12-30', '1899-12-30', CONVERT(varchar(10), GETDATE(), 120), CONVERT(varchar(10), GETDATE(), 120) FROM #tmpStorehouseini
		end
	end
	
	update products set costmethod = @CostMethod,LastUpDate= CONVERT(varchar(10), GETDATE(), 120) where product_id in (select product_id from #tmpP)
END
GO
