
CREATE	PROCEDURE [Ts_K_InsBillToGsp]
	(@BillType 	[int],
	 @GspType	[int],
	 @GSPPropert	[binary](50)
	 )

AS 
if  not exists(Select * from BillToGsp where BillType=@billtype and Gsptype=@Gsptype)
begin
	INSERT INTO [BillToGsp] 
		 ( [billType],
		 [GspType],
		 [GspPropert]
		 ) 
	 
	VALUES 
		( @BillType,
		 @GspType,
		 @GspPropert
		 )
end else
begin
	UPDATE [BillToGsp] 
	
	SET	 [GspPropert]	 = @gspPropert	
	
	WHERE 
		( Gsptype=@Gsptype and Billtype=@BillType)
end
GO
