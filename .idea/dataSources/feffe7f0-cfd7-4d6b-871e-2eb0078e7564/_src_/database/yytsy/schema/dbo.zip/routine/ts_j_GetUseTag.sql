/************************************************************

--功能：判断当前机构在总部账套中是否实时连接进行过业务
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：
 @nRet 返回值说明
	   2: 存在业务数据　
	   1:　不存在业务数据
	   0: 未确定的状态
       -1:执行失败，发生异常
**************************************************************/

CREATE	 PROCEDURE ts_j_GetUseTag
	(
	  @nY_ID int
    )
AS 

/*总部存在数据时以总部为准*/
if exists(select 1 from billidx where Y_ID = @nY_ID)
  Return 2
if exists(select 1 from billdraftidx where Y_ID = @nY_ID)
  Return 2
if exists(select 1 from productdetail where Y_ID = @nY_ID)
  Return 2  
if exists(select 1 from accountdetail where Y_ID = @nY_ID)
  Return 2
if exists(select 1 from storehouse where Y_ID = @nY_ID and SendFlag=0)
  Return 2 
if exists(select 1 from storeDX where Y_ID = @nY_ID)
  Return 2
if exists(select 1 from storebrrow where Y_ID = @nY_ID)
  Return 2
if exists(select 1 from OtherStorehouse where Y_ID = @nY_ID)
  Return 2
            
return 1
GO
