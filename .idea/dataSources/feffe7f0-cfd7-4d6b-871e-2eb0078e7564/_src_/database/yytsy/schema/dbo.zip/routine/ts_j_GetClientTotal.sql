

CREATE	 PROCEDURE [ts_j_GetClientTotal]
	(
	 @nCID int,
	 @nIVType int = 0 /*0 销售类 1 采购类 3财务类*/
        )
AS 
/*Params Ini begin*/
if @nIVType is null  SET @nIVType = 0
/*Params Ini end*/

declare @szBilltype varchar(120)

  if @nIVType = 0 set @szBilltype = '10,11,12,13,16,17,18,32,112' else     /*销售类*/
  if @nIVType = 1 set @szBilltype = '20,21,24,25,28,35,122' else
                  set @szBilltype = '0' 



  select 
         Total = isnull(Sum(case when billtype in (11,13,21,24,25) then  -ysmoney
 	                         else ysmoney
                            end), 0),
         YKTotal = isnull(sum(case when(invoice in (2,3)) and (billtype in (11,13,21,24,25)) then -ysmoney
                                   when (invoice in (2,3)) and (not (billtype in (11,13,21,24,25))) then ysmoney
                                   else 0
                              end),0), 
         OverTotal =isnull(sum(jsinvoiceTotal),0)                        	
 
    from billidx
    where c_id = @nCID and 
	  billtype in (select type from dbo.decodestr(@szBilltype))

  return 0
GO
