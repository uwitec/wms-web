



create  PROCEDURE ts_c_GetLoginUser2
  @nY_ID int =0
AS
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
set nocount on

declare @nCount int

set @nCount=0
select @nCount=count(*) from employees

if @ncount=0 
insert into employees(class_id,parent_id,[name],[alias],child_number,child_count) values('000000','root','管理员','管理员',0,0)


set @nCount=0
select @nCount=count(*) from limgroup

if @ncount=0 
begin
	truncate table limgroup
	insert into limgroup([name],comment) values('管理员组','系统管理员')
end

SELECT  employees.[Name] as 'empname', employees.serial_number as 'serial_number', cast([users].loginpass as varchar(60)) as 'password', 
 employees.emp_id AS e_id,employees.lim as permission, users.USERPIN as USERPIN,users.[isBinding] as isBinding,users.[serialNumber]
 ,employees.class_ID,employees.Y_ID,users.ProductInfor,users.ClientInfor,users.priceInfor
 ,YName=isnull(Company.[Name],''),YClass_id=isnull(Company.Class_id,''),
 posdatamode = ISNULL(company.posdatamode, 1),superior_id = ISNULL(company.superior_id, 0)
FROM employees left outer join /*显示所有用户*/
      users ON employees.emp_id = users.e_id
left join Company on Company.Company_id = employees.Y_ID
where employees.deleted=0 AND employees.child_number = 0
      and CAST(Y_ID as varchar(50)) like (case when (@nY_ID=0) then '%%' else  CAST(@nY_ID as varchar(50)) end)
ORDER BY users.[user_id]
GO
