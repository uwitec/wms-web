

CREATE PROCEDURE  [Ts_L_InsSaleRange]
(	@szName    varchar(30),
    @szCode    varchar(30),
    @szPinyin  varchar(30),
    @szMode      int
 )
AS
if @szMode=1
begin
	if exists(select * from SaleRange where ([Name]=@szName or code=@szCode) and deleted=0)
	begin
		RAISERROR('输入编号或名称重复！',16,1) 
		return 0 
	end
	Insert Into 
		SaleRange ([Name],pinyin,code)
	Values
		(@szName,@szPinyin,@szCode)
end
else
if @szMode=2
begin
  if exists(select * from SaleRange2 where ([Name]=@szName or code=@szCode) and deleted=0)
	begin
		RAISERROR('输入编号或名称重复！',16,1) 
		return 0 
	end
	Insert Into 
		SaleRange2 ([Name],pinyin,code)
	Values
		(@szName,@szPinyin,@szCode)
end
if @@rowcount=0 
begin
	RAISERROR('数据库写入数据失败!',16,1) 
	return 0 
end else
return @@identity
GO
