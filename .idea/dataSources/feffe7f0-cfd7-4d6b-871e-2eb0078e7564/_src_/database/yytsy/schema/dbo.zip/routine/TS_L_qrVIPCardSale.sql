


CREATE       procedure TS_L_qrVIPCardSale 
  @BeginDate varchar(50),
  @EndDate varchar(50),
  @VIPCardID int=0,
  @CT_ID int=0,
  @YID int=0,
  @nQrMode int =1
  
as
/*Params Ini begin*/
if @VIPCardID is null  SET @VIPCardID = 0
if @CT_ID is null  SET @CT_ID = 0
if @YID is null  SET @YID = 0
if @nQrMode is null  SET @nQrMode = 1
/*Params Ini end*/

if @nQrMode = 0
begin
  select idx.billdate,
         idx.billtype,
         idx.billstates,
         idx.VipcardID,
         saleprice, 
         quantity,
         SaleTotal,
         CostPrice, 
         TotalMoney, 
         TaxTotal,
         aoid
    into #Sale1
    from(select idx.billdate,idx.billtype,idx.billstates,idx.vipcardID, 
           (case when billtype in (12) then saleprice else -saleprice end) saleprice, 
            sale.quantity,
           cast((case when billtype in (12) then total else -total end ) as NUMERIC(25,8)) SaleTotal, 
           (case when billtype in (12) then CostPrice else -CostPrice end) CostPrice,
           cast((case when billtype in (12) then TotalMoney else -TotalMoney end) as NUMERIC(25,8)) TotalMoney, 
           cast((case when billtype in (12) then TaxTotal else -TaxTotal end)as NUMERIC(25,8)) TaxTotal,aoid
        from Retailbillidx idx 
         left join  RetailBill sale on idx.billid=sale.bill_id
         where    (idx.billtype in (12,13))
            and (convert(varchar(10),idx.billdate,120) between @BeginDate and @EndDate) 
            and idx.billstates=0 and idx.vipcardid <> 0 
            and sale.p_id>0
        ) idx

  select    card.VIPCardID,
            card.CardNo,
            card.Name,
            card.Sex,
            card.Tel,
            card.Birthday,
            card.Address,
            card.IDCard,
            card.ct_id,
            card.ctName,
            card.Y_id,
            ISNULL(Y.[Name],'') as Yname,
            card.IniMoney,
            card.TotalBuyMoney,
            card.SaveMoney,
            card.RemainderMoney,
            MAX(UsedVip.UsedVipTotal) as UsedVipTotal,
            sum(case when aoid in (0,5) then sale.SaleTotal else 0 end) as saletotal,
            cast(round(sum(sale.CostPrice*sale.quantity),2) as NUMERIC(25,8)) as CostPriceTotal,
            sum(case when aoid in (0,5) then sale.TotalMoney else 0 end) as TotalMoney,
            sum(case when aoid in (0,5) then sale.TaxTotal else 0 end) as TaxTotal,
            round(sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)-sum(sale.CostPrice*sale.quantity),2) as Vantage,
            (case when sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)<>0 then
               Round( round(sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)-sum(sale.CostPrice*sale.quantity),2)*100/sum(case when aoid in (0,5) then sale.TaxTotal else 0 end),2 )
             else
               0
             end ) as VantageRate
   from VW_VIPCard card  
                        right join #Sale1 sale on card.VIPCardID=sale.VipcardID   
                        left  join company Y on card.Y_id=Y.Company_ID
                        left  join 
                        (
				select vipcardid, sum(VipUseTotal.total) as UsedVipTotal from billidx i,
				(
				   select bill_id,sum(isnull(total,0)) as total  from  salemanagebill s 
				   where p_id = -64 group by bill_id
				)  VipUseTotal
				
				where i.billid = VipUseTotal.bill_id and i.billstates= 0 
                                      and i.billdate between @BeginDate and @EndDate
                                      AND(i.Y_id=@YID or @YID=0)
                                group by vipcardid
                         ) UsedVip on card.VIPCardID = UsedVip.vipcardid
              
   where (card.Y_id=@YID or @YID=0) 
     and (card.VIPCardID=@VIPCardID or @VIPCardID=0)
     and (card.ct_id=@CT_ID or @CT_ID=0)
     and  card.deleted=0
   group by card.VIPCardID,
            card.CardNo,
            card.Name,
            card.Sex,
            card.Tel,
            card.Birthday,
            card.Address,
            card.IDCard,
            card.ct_id,
            card.ctName,
            card.Y_id,
            Y.[Name],
            card.IniMoney,
            card.TotalBuyMoney,
            card.SaveMoney,
            card.RemainderMoney
end 
else begin 
  select idx.billdate,
         idx.billtype,
         idx.billstates,
         idx.VipcardID,
         saleprice, 
         quantity,
         SaleTotal,
         CostPrice, 
         TotalMoney, 
         TaxTotal,
         aoid
    into #Sale
    from(select idx.billdate,idx.billtype,idx.billstates,idx.vipcardID, 
           (case when billtype in (12) then saleprice else -saleprice end) saleprice, 
            sale.quantity,
           (case when billtype in (12) then total else -total end ) SaleTotal, 
           (case when billtype in (12) then CostPrice else -CostPrice end) CostPrice,
           (case when billtype in (12) then TotalMoney else -TotalMoney end) TotalMoney, 
           (case when billtype in (12) then TaxTotal else -TaxTotal end) TaxTotal,aoid
         from billidx idx 
         left join  salemanagebill sale on idx.billid=sale.bill_id
         where    (idx.billtype in (12,13))
            and (convert(varchar(10),idx.billdate,120) between @BeginDate and @EndDate) 
            and idx.billstates=0 and idx.vipcardid <> 0 
            and sale.p_id>0
       union all
           select VP.billdate,VP.billtype,0 as billstates,VP.cardID as vipcardID, 
           (case when billtype in (12) then VP.price else -VP.price end) saleprice, 
            VP.quantity,
           (case when billtype in (12) then VP.Total  else -VP.Total end ) SaleTotal, 
           (case when (billtype in (12) and VP.Quantity<>0) then (VP.costtotal/VP.Quantity) else -(VP.costtotal/VP.Quantity) end) CostPrice,
           (case when billtype in (12) then (VP.Quantity*VP.price) else -(VP.Quantity*VP.price) end) TotalMoney, 
           (case when billtype in (12) then (VP.Price*VP.Quantity) else -(VP.Price*VP.Quantity) end) TaxTotal,VP.aoid as aoid 
         from VipDetail  VP    
         where    (VP.billtype in (12,13))
            and (convert(varchar(10),VP.billdate,120) between @BeginDate and @EndDate) 
            and VP.cardid <> 0 
            and VP.p_id>0 
        ) idx

  select    card.VIPCardID,
            card.CardNo,
            card.Name,
            card.Sex,
            card.Tel,
            card.Birthday,
            card.Address,
            card.IDCard,
            card.ct_id,
            card.ctName,
            card.Y_id,
            ISNULL(Y.[Name], '') as Yname,
            card.IniMoney,
            card.TotalBuyMoney,
            card.SaveMoney,
            card.RemainderMoney,
            MAX(UsedVip.UsedVipTotal) as UsedVipTotal,
            sum(case when aoid in (0,5) then sale.SaleTotal else 0 end) as saletotal,
            round(sum(sale.CostPrice*sale.quantity),2) as CostPriceTotal,
            sum(case when aoid in (0,5) then sale.TotalMoney else 0 end) as TotalMoney,
            sum(case when aoid in (0,5) then sale.TaxTotal else 0 end) as TaxTotal,
            round(sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)-sum(sale.CostPrice*sale.quantity),2) as Vantage,
            (case when sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)<>0 then
               Round( round(sum(case when aoid in (0,5) then sale.TaxTotal else 0 end)-sum(sale.CostPrice*sale.quantity),2)*100/sum(case when aoid in (0,5) then sale.TaxTotal else 0 end),2 )
             else
               0
             end ) as VantageRate
   from VW_VIPCard card right join #Sale sale on card.VIPCardID=sale.VipcardID   
                        left  join company Y on card.Y_id=Y.Company_ID
                        left  join 
                        (
				select vipcardid, sum(VipUseTotal.total) as UsedVipTotal from billidx i,
				(
				   select bill_id,sum(isnull(total,0)) as total  from  salemanagebill s 
				   where p_id = -64 group by bill_id
				)  VipUseTotal
				
				where i.billid = VipUseTotal.bill_id and i.billstates= 0 
                                      and i.billdate between @BeginDate and @EndDate
                                      AND(i.Y_id=@YID or @YID=0) 
                                group by vipcardid
                         ) UsedVip on card.VIPCardID = UsedVip.vipcardid              
   where (card.Y_id=@YID or @YID=0) 
     and (card.VIPCardID=@VIPCardID or @VIPCardID=0)
     and (card.ct_id=@CT_ID or @CT_ID=0)
     and  card.deleted=0
   group by card.VIPCardID,
            card.CardNo,
            card.Name,
            card.Sex,
            card.Tel,
            card.Birthday,
            card.Address,
            card.IDCard,
            card.ct_id,
            card.ctName,
            card.Y_id,
            Y.[Name],
            card.IniMoney,
            card.TotalBuyMoney,
            card.SaveMoney,
            card.RemainderMoney
   
end
GO
