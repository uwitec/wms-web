
create proc [dbo].[ts_q_uprangecdtbm]
(
    @c_id int = 0,
    @r_id int = 0,
    @cdt_type int =0,
    @cdt_time int =0,
    @cdt_date datetime =0,
    @e_id int=0
)

as

set nocount on

if exists(select cdt_id from rangeconditionbm where c_id=@c_id and r_id=@r_id)
  update rangeconditionbm set cdt_type=@cdt_type,cdt_time=@cdt_time,
                              cdt_date=@cdt_date,@e_id=e_id,setdate=getdate()
                          where c_id=@c_id and r_id=@r_id
else
  insert rangeconditionbm (c_id,r_id,cdt_type,cdt_time,cdt_date,e_id,setdate) values
                           (@c_id,@r_id,@cdt_type,@cdt_time,@cdt_date,@e_id,getdate())
GO
