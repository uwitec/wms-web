/************************************************************

--功能：计算会员卡积分  
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [TS_j_UpDateVipFlag]
	(
	  @VipCardID int
     )
AS 
  
  update billidx set ArApTotal=2 from billidx bi, billunitetmp t where bi.billid = t.billid and bi.VIPCardID = @VipCardID and t.VipFlag = 2
  delete billunitetmp where vipflag = 2  and vipcardid = @VipCardID
		 	 		
return 0
GO
