 Create procedure [dbo].[Ts_T_InsSendRoad]
 (                      
    @RoadName   varchar(30),
	@RoadCode   varchar(20),
	@RoadComment varchar(200)
 ) 
AS

if exists(select 1 from SendRoad where  RoadCode=@RoadCode and deleted=0)
begin
     
	RAISERROR('输入编号重复！',16,1) 
	return -2
end

insert into [dbo].[SendRoad]
(RoadName,RoadCode,RoadComment)
Values 
(@RoadName,@RoadCode,@RoadComment)

 
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return -3
end
return 0
 GO
