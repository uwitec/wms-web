
CREATE PROCEDURE Ts_k_InsertGSPbillDetail(
    @nRET              INT OUTPUT,			/*返回Gspbillid，错误返回-1*/
    @nID               INT,                 /*行号*/
    @Gspbill_id        INT,                 /*Gspbill_id*/
    @p_id              INT,                 /*商品ID*/
    @makedate          DATETIME,			/*生产日期*/
    @validdate         DATETIME,			/*有效期*/
    @batchno           VARCHAR(20) = '',	/*批号*/
    @unit_id           INT = 0,				/*单位ID*/
    @Yqty              NUMERIC(25,8),		/*原单数量*/
    @eligibleqty       NUMERIC(25,8),		/*合格数量*/
    @uneligibleqty     NUMERIC(25,8),		/*不合格数量*/
    @inceptqty         NUMERIC(25,8),		/*收货数量*/
    @refuseqty         NUMERIC(25,8),		/*拒收数量*/
    @pickqty           NUMERIC(25,8),		/*拣货数量*/
    @checkqty          NUMERIC(25,8),		/*复核数量*/
    @sampleqty         NUMERIC(25,8),		/*抽样数量*/
    @applicantqty      NUMERIC(25,8),		/*申退数量*/
    @thqty             NUMERIC(25,8),		/*可退数量*/
    @Ytaxprice         NUMERIC(25,8),		/*订单税后价*/
    @price             NUMERIC(25,8),		/*单价*/
	@discountprice     NUMERIC(25,8),		/*折后价*/
    @taxprice          NUMERIC(25,8),		/*税后价*/
    @pricediscrepancy  NUMERIC(25,8),		/*税后价差                                      		                                     		*/
    @total             NUMERIC(25,8),		/*金额*/
	@discount          NUMERIC(25,8),		/*折扣*/
    @discounttotal     NUMERIC(25,8),		/*折后金额*/
    @taxRate           NUMERIC(25,8),		/*税率      */
    @taxmoney          NUMERIC(25,8),		/*税额 */
	@taxTotal          NUMERIC(25,8),		/*税后金额*/
    @CostPrice         NUMERIC(25,8),		/*成本价  */
	@inceptstate       VARCHAR(20),         /*收货状态*/
	@refusereason      VARCHAR(100),        /*拒收原因*/
	@uneligiblereason  VARCHAR(100),		/*不合格原因*/
	@uneligibletransactor VARCHAR(100),	    /*不合格处理意见 */
	@checkaccept	   VARCHAR(100),	    /*验收结论*/
	@checkreport       VARCHAR(3000),	    /*检验报告*/
	@returnreason	   VARCHAR(100),        /*退回原因*/
	@checkstate        VARCHAR(200),         /*复核状态*/
	@checkreason       VARCHAR(100),        /*复核结论*/
	@s_id              INT,                 /*仓库*/
	@location_id       INT,                 /*货位*/
	@supplier_id       INT,                 /*供应商*/
	@instoretime       DATETIME,            /*入库时间*/
	@cansaleqty        NUMERIC(25,8),      /*可开数量*/
	@BatchBarCode      VARCHAR(30),         /*批次条码*/
	@Batchcomment      VARCHAR(100),        /*批次备注*/
	@batchprice        NUMERIC(25,8),      /*批次限价*/
	@Iscold            SMALLINT,            /*是否冷藏药品*/
	@Isspec            SMALLINT ,           /*是否特殊药品*/
	@comment           VARCHAR(100),        /*备注*/
	@comment2          VARCHAR(100),        /*备注2*/
	@y_id              INT,                 /*业务机构*/
	@aoid              INT,                 /*赠送类型*/
	@sfdacounts        INT,                 /*监管码条数  */
	@orgbillid         INT,                 /*原单smbid*/
	@Yrowguid          UNIQUEIDENTIFIER = 0x0,  /*原单guid*/
	@commisionflag     INT,                  /* 代销标志*/
	@factoryid         int, /*生成厂家ID*/
	@costtaxrate       NUMERIC(25,8), /*成本税率*/
	@costtaxprice      NUMERIC(25,8),/*成本含税单价*/
	@costtaxtotal      NUMERIC(25,8), /*成本含税金额*/
	@OldOrderQty       NUMERIC(25,8),/*原订单数量*/
	@OldOrderUnit      varchar(100),/*原订单单位*/
	@OldOrderUnitId    int ,/*原订单单位id*/
	@OldOrderUnitRate  numeric(25,8),/*原订单单位换算率*/
	@WHOLEQTY		   numeric(25,8) ,/*整货数量*/
	@PARTQTY		   numeric(25,8),  /*零货数量*/
	@QUANLITYSTATUS  VARCHAR(20)/*质量状况*/
)
AS
BEGIN
	DECLARE @szError VARCHAR(500),@validpname VARCHAR(200)
	IF @makedate < 10
	    SET @makedate = 0
	IF @validdate < 10
	    SET @validdate = 0
	/*批次:入库时间只精确到天*/
    SET @InStoreTime = (DATENAME(YEAR, @InStoreTime) + '-' + DATENAME(MONTH, @InStoreTime) + '-' + DATENAME(DAY, @InStoreTime))
	SET @nRET = -1
	
	DECLARE @BillType INT
    SELECT @BillType = g.BillType FROM GSPbillidx g WHERE g.Gspbillid = @Gspbill_id
		
	IF @billtype IN (511,513) and (@makedate <> 0)
	begin
	  if exists(select 1 from products where product_id = @p_id and ((@makedate > Registervalid and Registervalid > 0) or (@makedate > PerCodevalid  and PerCodevalid > 0)))
	  begin
		select @validpname = name from products where product_id = @p_id
		set @szError = '商品【'+@validpname+'】生产日期超出【注册证号有效期】或【批准文号有效期】'
		RAISERROR(@szError, 16, 1)
		return -100 
	  end
	end

	
	
	IF EXISTS(SELECT 1 FROM sysconfig WHERE sysname = 'CtrlStoreCondition' AND sysvalue = '1')
	BEGIN
		/*严格控制温度条件开关打开后，入库类单据控制仓库与商品温度条件一致		*/
		IF (@s_id > 0) AND (@BillType IN (511, 512, 513, 514, 521, 522, 523, 524, 531))
		BEGIN
			IF NOT EXISTS(SELECT 1 FROM (SELECT p.StoreCondition FROM Products p WHERE p.product_id = @p_id) a 
											INNER JOIN (SELECT s.storeCondition FROM storages s WHERE s.storage_id = @s_id) b 
													ON a.StoreCondition = b.storeCondition)
			BEGIN
				SELECT @validpname = name FROM products WHERE product_id = @p_id
				set @szError = '第 ' + CAST(@nID AS varchar(10)) + ' 行商品【' + @validpname + '】温度条件与仓库温度条件不一致！'
				RAISERROR(@szError, 16, 1)		
			END
		END
	END
		
	IF @location_id > 0
	BEGIN
		select @validpname = name from products where product_id = @p_id
		IF NOT EXISTS(SELECT * FROM Location WHERE loc_id = @location_id AND s_id = @s_id)
		BEGIN
			set @szError = '第 ' + CAST(@nID AS varchar(10)) + ' 行商品【' + @validpname + '】货位不正确！'
			RAISERROR(@szError, 16, 1)		
		END
	END
	
	IF @inceptstate = '收货' 
		SET @inceptstate = '0'
	ELSE
		SET @inceptstate = '1'

	INSERT INTO GSPbilldetail
	(   Gspbill_id, p_id, makedate, validdate, batchno,
		unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty,
		refuseqty, pickqty, checkqty, sampleqty, applicantqty,
		thqty, Ytaxprice, price, DiscountPrice, taxprice,
		pricediscrepancy, total, discount, discounttotal, TaxRate,
		taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason,
		uneligibletransactor, checkaccept, checkreport, returnreason, checkstate,
		checkreason, s_id, location_id, supplier_id, instoretime,
		cansaleqty, BatchBarCode, Batchcomment, batchprice, Iscold,
		Isspec, comment, comment2, y_id, aoid,
		sfdacounts, orgbillid, Yrowguid, commisionflag, CostPrice,factoryid,costtaxprice,costtaxrate,costtaxtotal,
		OldOrderQty,OldOrderUnit,OldOrderUnitId,OldOrderUnitRate,WholeQty,PartQty,qualitystatus
	)
	VALUES
	(   @Gspbill_id, @p_id, @makedate, @validdate, @batchno,
		@unit_id, @Yqty, @eligibleqty, @uneligibleqty, @inceptqty,
		@refuseqty, @pickqty, @checkqty, @sampleqty, @applicantqty,
		@thqty, @Ytaxprice, @price, @discountprice, @taxprice,
		@pricediscrepancy, @total, @discount, @discounttotal, @taxRate,
		@taxmoney, @taxTotal, @inceptstate, @refusereason, @uneligiblereason,
		@uneligibletransactor, @checkaccept, @checkreport, @returnreason, @checkstate,
		@checkreason, @s_id, @location_id, @supplier_id, @instoretime,
		@cansaleqty, @BatchBarCode, @Batchcomment, @batchprice, @Iscold,
		@Isspec, @comment, @comment2, @y_id, @aoid,
		@sfdacounts, @orgbillid, @Yrowguid, @commisionflag, @CostPrice,@factoryid,@costtaxprice,@costtaxrate,@costtaxtotal,
		@OldOrderQty,@OldOrderUnit,@OldOrderUnitId,@OldOrderUnitRate,@WHOLEQTY,@PARTQTY,@QUANLITYSTATUS
	)
	
	SET @nRET = @@ROWCOUNT
END
GO
