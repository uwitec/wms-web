
CREATE PROCEDURE [dbo].[Ts_K_CheckSfdaCode]
(
    @SfdaCode   VARCHAR(20),
    @SId        INT,
    @YId        INT,
    @EId        INT
)
AS
BEGIN
	SELECT s.P_Id AS Product_Id FROM Sfda_List s WHERE s.Sfda_Code = @SfdaCode AND s.S_Id = @SId AND s.[Deleted] = 0 
END
GO
