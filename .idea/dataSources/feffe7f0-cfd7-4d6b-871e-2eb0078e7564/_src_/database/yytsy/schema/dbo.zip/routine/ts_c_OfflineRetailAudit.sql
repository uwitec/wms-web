
/*
-102 单据保存出错
*/

CREATE proc ts_c_OfflineRetailAudit
(
	@nBillId int,
	@nP_id int output,
	@nReturnNumber int output,
	@nVchtype int
)
as
/*
离线版本门店零售单过账:
1.从RetailBillIdx中搬移数据到YRetailBillIdx3
2.不产生ProductDeail 和 AccountDetail
3.产生库存和积分
*/
set nocount on
declare @nNewBillId int 	


/*1.从RetailBillIdx中搬移数据到YRetailBillIdx*/
	exec @nReturnNumber=ts_c_OfflineRetailToHis @nBillId,@nNewBillId output
	if @nReturnNumber<>0 return -102
	
	
	exec ts_c_OfflineBillAudit @nNewBillId,@nP_id out,@nReturnNumber out,@nVchtype
	if @nReturnNumber<>0
	begin
		delete from YRetailBillIdx where billid=@nNewBillId	
		delete from YRetailBill where bill_id=@nNewBillId	
		delete from retailbillidx where billid=@nBillid
		delete from retailbill where bill_id=@nBillid
	end else
	begin
		update retailbillidx set billstates='0' where billid=@nBillid /*修改原零售单标记*/
    end
GO
