
CREATE	    VIEW dbo.vw_pfstorehouse
AS
SELECT * FROM storehouse
GO
