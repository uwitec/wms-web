
CREATE PROCEDURE Ts_T_FLdifference(
    @nid          INT,	/*返利条件id*/
    @begintime    DATETIME = 0,	/*开始时间*/
    @Endtime      DATETIME = 0,	/*结束时间*/
    @Cid          INT,	/*供应商ID */
    @p_id         INT,	/*商品ID*/
    @XYnumber     VARCHAR(30),	/*返利协议编号*/
    @szParent_ID  VARCHAR(30) = '' /*商品父类ID*/
)
AS
/*Params Ini begin*/
if @begintime is null  SET @begintime = 0
if @Endtime is null  SET @Endtime = 0
if @szParent_ID is null  SET @szParent_ID = ''
/*Params Ini end*/
	DECLARE @begindate  DATETIME,
	        @enddate    DATETIME
	
	IF @nid = 0
	BEGIN
	    SET @begindate = @begintime
	    SET @enddate = @Endtime
	END
	ELSE
	BEGIN
	    SELECT @begindate = beginTime,
	           @enddate = EndTime
	    FROM   FLCondition
	    WHERE  id = @nid
	END
	IF @szParent_ID = '000000'
	BEGIN
	    SELECT c.serial_number AS cserial,
	           c.client_id,
	           c.name AS cname,
	           c.alias AS calias,
	           ISNULL(c.phone_number, '')phone_number,
	           ISNULL(a.CName, '') AS contact_personal,
	           CAST(0 AS NUMERIC(25,8))buyprice,
	           d.product_id,
	           d.class_id,
	           d.serial_number AS pserial,
	           d.name,
	           d.alias AS palias,
	           d.Factory,
	           d.[standard],
	           d.medtype,
	           d.trademark,
	           d.unit1_id,
	           (
	               CASE 
	                    WHEN (b.FlSJQty <> 0)
	               AND (d.child_number = 0) THEN 0 ELSE d.child_number END
	           )child_number,
	           d.comment,
	           d.permitcode,
	           b.id,
	           b.quantity,
	           b.BuyTotal,
	           b.BackTotal,
	           b.FlSjQty,
	           b.FlSJBuyTotal,
	           b.FlSJBackTotal,
	           b.price,
	           b.beginTime,
	           b.EndTime,
	           (
	               CASE 
	                    WHEN b.BackTotal = 0 THEN 0
	                    ELSE (b.BackTotal -b.FlSJBackTotal)
	               END
	           )CEBmoney,
	           (
	               CASE 
	                    WHEN b.BuyTotal = 0 THEN 0
	                    ELSE (b.BuyTotal -b.FlSJBuyTotal)
	               END
	           )CETotal,
	           (
	               CASE 
	                    WHEN b.quantity = 0 THEN 0
	                    ELSE (b.quantity -b.FlSjQty)
	               END
	           )CEqty,
	           d.[makearea]
	    FROM   RebehoofProtocol a
	           INNER JOIN FLCondition b
	                ON  a.id = b.RP_id
	           INNER JOIN clients c
	                ON  a.c_id = c.client_id
	           INNER JOIN products d
	                ON  b.P_id = d.product_id
	    WHERE  @begindate <= b.EndTime
	           AND @enddate >= b.beginTime
	           AND (
	                   (SUBSTRING(b.Flrelation, 1, 1) = '1')
	                   OR (SUBSTRING(b.Flrelation, 3, 1) = '1')
	                   OR (SUBSTRING(b.Flrelation, 4, 1) = '1')
	               )
	           AND (
	                   @XYnumber = '0000'
	                   OR UPPER(a.serial_number) LIKE '%' + UPPER(@XYnumber) +
	                      '%'
	               )
	           AND (@p_id = 0 OR b.P_id = @p_id)
	END
	ELSE
	BEGIN
	    IF EXISTS (
	           SELECT 1
	           FROM   products
	           WHERE  class_id = @szParent_ID
	                  AND child_number = 0
	       )
	    BEGIN
	        SELECT c.serial_number AS cserial,
	               c.client_id,
	               c.name AS cname,
	               c.alias AS calias,
	               c.phone_number,
	               c.contact_personal,
	               bm.buyprice,
	               p.product_id,
	               p.class_id,
	               p.serial_number AS pserial,
	               p.name,
	               p.alias AS palias,
	               p.Factory,
	               p.[standard],
	               p.medtype,
	               p.trademark,
	               p.unit1_id,
	               p.child_number,
	               p.comment,
	               p.permitcode,
	               @nid AS id,
	               0 AS quantity,
	               0.0000 AS BuyTotal,
	               0.0000 AS BackTotal,
	               CAST(bm.quantity AS NUMERIC(25,8)) AS FlSjQty,
	               bm.totalmoney AS FlSJBuyTotal,
	               0.0000 AS FlSJBackTotal,
	               0.0000 AS price,
	               bd.billdate AS beginTime,
	               bd.billdate AS EndTime,
	               0.0000 AS CEBmoney,
	               0.0000 AS CETotal,
	               0.0000 AS CEqty,
	               p.[makearea]
	        FROM   billidx bd
	               INNER JOIN buymanagebill bm
	                    ON  bd.billid = bm.bill_id
	               INNER JOIN products p
	                    ON  p.product_id = bm.p_id
	               INNER JOIN clients c
	                    ON  bd.c_id = c.client_id
	        WHERE  bd.c_id IN (SELECT fp.c_id
	                           FROM   flprovider fp
	                                  INNER JOIN FLCondition fl
	                                       ON  fp.RP_id = fl.RP_id
	                           WHERE  fl.id = @nid)
	               AND bd.billtype IN (20, 21, 220, 221)
	               AND p.class_id = @szParent_ID
	               AND bd.billstates = 0
	               AND bd.billdate BETWEEN @begindate AND @enddate
	    END
	    ELSE
	    BEGIN
	        SELECT c.serial_number AS cserial,
	               c.client_id,
	               c.name AS cname,
	               c.alias AS calias,
	               c.phone_number,
	               c.contact_personal,
	               bm.buyprice,
	               p.product_id,
	               p.class_id,
	               p.serial_number AS pserial,
	               p.name,
	               p.alias AS palias,
	               p.Factory,
	               p.[standard],
	               p.medtype,
	               p.trademark,
	               p.unit1_id,
	               p.child_number,
	               p.comment,
	               p.permitcode,
	               @nid AS id,
	               0 AS quantity,
	               0.0000 AS BuyTotal,
	               0.0000 AS BackTotal,
	               CAST(bm.quantity AS NUMERIC(25,8)) FlSjQty,
	               bm.totalmoney AS FlSJBuyTotal,
	               0.0000 AS FlSJBackTotal,
	               0.0000 AS price,
	               bd.billdate AS beginTime,
	               bd.billdate AS EndTime,
	               0.0000 AS CEBmoney,
	               0.0000 AS CETotal,
	               0.0000 AS CEqty,
	               p.[makearea]
	        FROM   billidx bd
	               INNER JOIN buymanagebill bm
	                    ON  bd.billid = bm.bill_id
	               INNER JOIN products p
	                    ON  p.product_id = bm.p_id
	               INNER JOIN clients c
	                    ON  bd.c_id = c.client_id
	        WHERE  bd.c_id IN (SELECT fp.c_id
	                           FROM   flprovider fp
	                                  INNER JOIN FLCondition fl
	                                       ON  fp.RP_id = fl.RP_id
	                           WHERE  fl.id = @nid)
	               AND bd.billtype IN (20, 21, 220, 221)
	               AND p.parent_id LIKE @szParent_ID + '%'
	               AND bd.billstates = 0
	               AND bd.billdate BETWEEN @begindate AND @enddate
	    END
	END
GO
