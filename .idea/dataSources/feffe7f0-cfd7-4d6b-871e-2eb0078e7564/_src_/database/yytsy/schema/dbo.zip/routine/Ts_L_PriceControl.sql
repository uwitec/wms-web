





CREATE	PROCEDURE Ts_L_PriceControl 
(
@DbName		varchar(30),
@Posid		int,
@szPName	varchar(80),
@UnitType	int,
@Parentid	varchar(36),
@szList		varchar(1),
@nYClassID       varchar(50)='',
@nloginEID      int=0,
@nMLRateType     INT = 0 /*by zhangke 毛利率计算类型*/
)
AS
/*Params Ini begin*/
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @nMLRateType is null  SET @nMLRateType = 0
/*Params Ini end*/
 Declare @Companytable INTEGER

 create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
declare @classid varchar(50)
declare @classNum int
if @szPName <>'%' 
begin
  set @classNum=(select COUNT(class_id) from products  where name like @szPName and child_count>0)
  if  @classNum > 1
  begin 
     set @classid = (select top 1 class_id from products  where name like @szPName and child_count>0)
     set @classid =@classid+'%' 
  end   
  else
  begin
     set @classid =(select class_id from products  where name like @szPName and child_count>0) 
     set @classid =@classid+'%'  
  end     
end
else
   set @classid='0%'  

if @dbName='PRICE'
begin
	SELECT p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id, p.product_id,p.Child_number,p.serial_number as code,p.[name],p.Standard,ISNULL(M.name,'')[MedName],
               P.makeArea,P.permitCode,
               ISNULL(u1.name, '')Unit1Name,ISNULL(u0.name, '')Unit2Name, ISNULL(u2.name, '')Unit3Name,ISNULL(u3.name, '')Unit4Name,
               isnull(pr.recPrice,0)recPrice,isnull(pr.retailPrice,0)retailPrice,isnull(pr.specialPrice,0)specialPrice,
               isnull(pr.gpPrice,0)gpPrice,  isnull(pr.glPrice,0)glPrice,        isnull(pr.Price1,0)Price1,
               isnull(pr.Price2,0)Price2,    isnull(pr.Price3,0)Price3,          isnull(pr.Price4,0)Price4,
               isnull(pr.p_id,0)p_id,        isnull(pr.U_id,0)U_id,              isnull(pr.Price_id,0)Price_id,
               isnull(pr.LowPrice,0)LowPrice,
               CONVERT(   NUMERIC(18, 3),
                          ROUND(
                              (   CASE WHEN (   @nMLRateType = 0 AND pr.retailprice > 0 AND pr.recprice > 0) THEN (pr.retailprice - pr.recprice) / pr.retailprice
                                       ELSE (   CASE WHEN (@nMLRateType = 1 AND pr.price1 > 0 AND pr.recprice > 0) THEN (pr.price1 - pr.recprice) / pr.price1
                                                     ELSE (   CASE WHEN (@nMLRateType = 2 AND pr.price2 > 0 AND pr.recprice > 0) THEN (pr.price2 - pr.recprice) / pr.price2
                                                                   ELSE (   CASE WHEN (@nMLRateType = 3 AND pr.price3 > 0 AND pr.recprice > 0) THEN (pr.price3 - pr.recprice) / pr.price3
                                                                                 ELSE (   CASE WHEN (@nMLRateType = 4 AND pr.price4 > 0 AND pr.recprice > 0) THEN (pr.price4 - pr.recprice) / pr.price4
                                                                                               ELSE (   CASE WHEN (@nMLRateType = 5 AND pr.gpprice > 0 AND pr.recprice > 0) THEN (pr.gpprice - pr.recprice) / pr.gpprice
                                                                                                             ELSE (   CASE WHEN (@nMLRateType = 6 AND pr.glprice > 0 AND pr.recprice > 0) THEN (pr.glprice - pr.recprice) / pr.glprice
                                                                                                                           ELSE (   CASE WHEN (   @nMLRateType = 7 AND pr.specialprice > 0 AND pr.recprice > 0
                                                                                                                                              ) THEN (pr.specialprice - pr.recprice) / pr.specialprice ELSE  0.000
                                                                                                                                    END
                                                                                                                                )
                                                                                                                      END
                                                                                                                  )
                                                                                                        END
                                                                                                    )
                                                                                          END
                                                                                      )
                                                                            END
                                                                        )
                                                              END
                                                          )
                                                END
                                            )
                                  END
                              ) * 100,
                              3
                          )
                      ) 
                AS MLRate 
	FROM products p LEFT JOIN price   pr  ON p.product_id = pr.p_id
                        left   join 
						  (
							select p_id as baseinfo_id,isnull(c.name,'') as name from ProductCategory p 
							left join customCategory c on p.PComent3 = c.class_id 
                            where Category_id = 3 and c.deleted = 0  /*剂型*/
						  )m on p.product_id = m.baseinfo_id
                        LEFT JOIN unit    u1  ON p.unit1_id = u1.unit_id
                        LEFT JOIN unit    u0  ON p.unit2_id = u0.unit_id
                        LEFT JOIN unit    u2  ON p.unit3_id = u2.unit_id
                        LEFT JOIN unit    u3  ON p.unit4_id = u3.unit_id                        
    /*P.Name Like @szPName  and pr.unitType=@unittype and p.Child_Number=0  and p.deleted=0                    */
	Where ((P.alias Like @szPName) or (p.class_id like @classid)) and pr.unitType=@unittype and p.Child_Number=0  and p.deleted=0 and IsSplit = 0
end

if @dbName='POSPRICE'
begin
	if @szList='L'
	begin
	SELECT  p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id,p.serial_number as code, ISNULL(u0.name, '')Unit2Name, ISNULL(u2.name, '')Unit3Name,ISNULL(u3.name, '')Unit4Name,
            tx.name as TaxRate, p.StorageCon, p.packStd, p.r_id, p.Gross, 
            p.GMP, p.OTCType, p.deduct, p.ModifyDate, p.MaintainDay, p.MaintainType, 
	        p.LatinName, p.ChemName, p.EngName, p.costmethod, m.baseinfo_id as medtype, p.gspflag, 
	        p.otcflag, p.validcheck, p.firstcheck, p.pinyin, p.deleted, p.comment, p.validday, 
	        p.validmonth, p.rate4, p.rate3, p.rate2, p.unit4_id, p.unit3_id, p.unit2_id, p.unit1_id, 
	        p.makearea, p.trademark, p.permitcode, p.modal, p.standard, p.alias, p.name, 
	        p.serial_number, p.child_count, p.child_number, p.parent_id, p.class_id, p.product_id, 
	        '' as MedCode, ISNULL(m.name,'')MedName, ISNULL(u1.name, '')Unit1Name, 
            isnull(pr.price_id,0) price_id,isnull(pr.Y_id,0) pos_id,
		    isnull(pr.p_id,0) p_id,isnull(pr.u_id,0) u_id,isnull(pr.retailprice,0) retailprice,
		    isnull(pr.recPrice,0) recPrice,isnull(pr.price1,0) price1,isnull(pr.price2,0) price2,
		    isnull(pr.price3,0) price3,isnull(pr.price4,0) price4,isnull(pr.gpprice,0) gpprice,
		    isnull(pr.glprice,0) glprice,isnull(pr.specialprice,0) specialprice,
		    isnull(pr.unittype,0) unitType,isnull(pr.Lowprice,0) Lowprice,
		    CONVERT(   NUMERIC(18, 3),
                          ROUND(
                              (   CASE WHEN (   @nMLRateType = 0 AND pr.retailprice > 0 AND pr.recprice > 0) THEN (pr.retailprice - pr.recprice) / pr.retailprice
                                       ELSE (   CASE WHEN (@nMLRateType = 1 AND pr.price1 > 0 AND pr.recprice > 0) THEN (pr.price1 - pr.recprice) / pr.price1
                                                     ELSE (   CASE WHEN (@nMLRateType = 2 AND pr.price2 > 0 AND pr.recprice > 0) THEN (pr.price2 - pr.recprice) / pr.price2
                                                                   ELSE (   CASE WHEN (@nMLRateType = 3 AND pr.price3 > 0 AND pr.recprice > 0) THEN (pr.price3 - pr.recprice) / pr.price3
                                                                                 ELSE (   CASE WHEN (@nMLRateType = 4 AND pr.price4 > 0 AND pr.recprice > 0) THEN (pr.price4 - pr.recprice) / pr.price4
                                                                                               ELSE (   CASE WHEN (@nMLRateType = 5 AND pr.gpprice > 0 AND pr.recprice > 0) THEN (pr.gpprice - pr.recprice) / pr.gpprice
                                                                                                             ELSE (   CASE WHEN (@nMLRateType = 6 AND pr.glprice > 0 AND pr.recprice > 0) THEN (pr.glprice - pr.recprice) / pr.glprice
                                                                                                                           ELSE (   CASE WHEN (   @nMLRateType = 7 AND pr.specialprice > 0 AND pr.recprice > 0
                                                                                                                                              ) THEN (pr.specialprice - pr.recprice) / pr.specialprice ELSE  0.000
                                                                                                                                    END
                                                                                                                                )
                                                                                                                      END
                                                                                                                  )
                                                                                                        END
                                                                                                    )
                                                                                          END
                                                                                      )
                                                                            END
                                                                        )
                                                              END
                                                          )
                                                END
                                            )
                                  END
                              ) * 100,
                              3
                          )
                      ) 
                AS MLRate
	FROM  products p
          LEFT JOIN   (select price_id,Y_id,p_id,u_id,retailprice,recPrice,price1,price2,
                              price3,price4,gpprice,glprice,specialprice,unittype,Lowprice
		         from  POSprice 
		        where unitType=@unittype and Y_id = @Posid
                      )pr  ON p.product_id = pr.p_id
          left   join 
		  (
			select p_id as baseinfo_id,isnull(c.name,'') as name from ProductCategory p 
            left join customCategory c on p.PComent3 = c.class_id 
            where Category_id = 3 and c.deleted = 0  /*剂型*/
		  )m on p.product_id = m.baseinfo_id
		  left   join 
	      (
			select p_id as baseinfo_id,isnull(c.name,0) as name from ProductCategory p 
            left join customCategory c on p.PComent2 = c.class_id 
            where Category_id = 2 and c.deleted = 0  /*税率*/
	      )tx on p.product_id = tx.baseinfo_id
          LEFT JOIN  unit    u1  ON p.unit1_id = u1.unit_id
          LEFT JOIN  unit    u0  ON p.unit2_id = u0.unit_id
          LEFT JOIN  unit    u2  ON p.unit3_id = u2.unit_id
          LEFT JOIN  unit    u3  ON p.unit4_id = u3.unit_id 
        WHERE parent_id=@Parentid and p.deleted=0 and IsSplit = 0
	end
	if @szList='A'
	begin
	SELECT  p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id,p.serial_number as code, ISNULL(u0.name, '')Unit2Name, ISNULL(u2.name, '')Unit3Name,ISNULL(u3.name, '')Unit4Name,
            tx.name as TaxRate, p.StorageCon, p.packStd, p.r_id, p.Gross, 
            p.GMP, p.OTCType, p.deduct, p.ModifyDate, p.MaintainDay, p.MaintainType, 
	        p.LatinName, p.ChemName, p.EngName, p.costmethod, m.baseinfo_id as medtype, p.gspflag, 
	        p.otcflag, p.validcheck, p.firstcheck, p.pinyin, p.deleted, p.comment, p.validday, 
	        p.validmonth, p.rate4, p.rate3, p.rate2, p.unit4_id, p.unit3_id, p.unit2_id, p.unit1_id, 
	        p.makearea, p.trademark, p.permitcode, p.modal, p.standard, p.alias, p.name, 
	        p.serial_number, p.child_count, p.child_number, p.parent_id, p.class_id, p.product_id, 
	        '' as MedCode, ISNULL(m.name,'')MedName, ISNULL(u1.name, '')Unit1Name, 
            isnull(pr.price_id,0) price_id,isnull(pr.Y_id,0) pos_id,
		    isnull(pr.p_id,0) p_id,isnull(pr.u_id,0) u_id,isnull(pr.retailprice,0) retailprice,
		    isnull(pr.recPrice,0) recPrice,isnull(pr.price1,0) price1,isnull(pr.price2,0) price2,
		    isnull(pr.price3,0) price3,isnull(pr.price4,0) price4,isnull(pr.gpprice,0) gpprice,
		    isnull(pr.glprice,0) glprice,isnull(pr.specialprice,0) specialprice,
		    isnull(pr.unittype,0) unitType,isnull(pr.Lowprice,0) Lowprice,
		    CONVERT(   NUMERIC(18, 3),
                          ROUND(
                              (   CASE WHEN (   @nMLRateType = 0 AND pr.retailprice > 0 AND pr.recprice > 0) THEN (pr.retailprice - pr.recprice) / pr.retailprice
                                       ELSE (   CASE WHEN (@nMLRateType = 1 AND pr.price1 > 0 AND pr.recprice > 0) THEN (pr.price1 - pr.recprice) / pr.price1
                                                     ELSE (   CASE WHEN (@nMLRateType = 2 AND pr.price2 > 0 AND pr.recprice > 0) THEN (pr.price2 - pr.recprice) / pr.price2
                                                                   ELSE (   CASE WHEN (@nMLRateType = 3 AND pr.price3 > 0 AND pr.recprice > 0) THEN (pr.price3 - pr.recprice) / pr.price3
                                                                                 ELSE (   CASE WHEN (@nMLRateType = 4 AND pr.price4 > 0 AND pr.recprice > 0) THEN (pr.price4 - pr.recprice) / pr.price4
                                                                                               ELSE (   CASE WHEN (@nMLRateType = 5 AND pr.gpprice > 0 AND pr.recprice > 0) THEN (pr.gpprice - pr.recprice) / pr.gpprice
                                                                                                             ELSE (   CASE WHEN (@nMLRateType = 6 AND pr.glprice > 0 AND pr.recprice > 0) THEN (pr.glprice - pr.recprice) / pr.glprice
                                                                                                                           ELSE (   CASE WHEN (   @nMLRateType = 7 AND pr.specialprice > 0 AND pr.recprice > 0
                                                                                                                                              ) THEN (pr.specialprice - pr.recprice) / pr.specialprice ELSE  0.000
                                                                                                                                    END
                                                                                                                                )
                                                                                                                      END
                                                                                                                  )
                                                                                                        END
                                                                                                    )
                                                                                          END
                                                                                      )
                                                                            END
                                                                        )
                                                              END
                                                          )
                                                END
                                            )
                                  END
                              ) * 100,
                              3
                          )
                      ) 
                AS MLRate
	FROM  products p
          LEFT JOIN   (select price_id,Y_id,p_id,u_id,retailprice,recPrice,price1,price2,
                              price3,price4,gpprice,glprice,specialprice,unittype,Lowprice
		         from  POSprice 
		        where unitType=@unittype and Y_id = @Posid
                      )pr  ON p.product_id = pr.p_id
          left   join 
		  (
			select p_id as baseinfo_id,isnull(c.name,'') as name from ProductCategory p 
            left join customCategory c on p.PComent3 = c.class_id 
            where Category_id = 3 and c.deleted = 0  /*剂型*/
		  )m on p.product_id = m.baseinfo_id
		  left   join 
	      (
			select p_id as baseinfo_id,isnull(c.name,0) as name from ProductCategory p 
            left join customCategory c on p.PComent2 = c.class_id 
            where Category_id = 2 and c.deleted = 0  /*税率*/
	      )tx on p.product_id = tx.baseinfo_id
          LEFT JOIN  unit    u1  ON p.unit1_id = u1.unit_id
          LEFT JOIN  unit    u0  ON p.unit2_id = u0.unit_id
          LEFT JOIN  unit    u2  ON p.unit3_id = u2.unit_id
          LEFT JOIN  unit    u3  ON p.unit4_id = u3.unit_id 
	Where Child_number=0 and p.deleted=0 and IsSplit = 0
	end
	if @szList='P'
	begin
	SELECT  p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id,p.serial_number as code, ISNULL(u0.name, '')Unit2Name, ISNULL(u2.name, '')Unit3Name,ISNULL(u3.name, '')Unit4Name,
            tx.name as TaxRate, p.StorageCon, p.packStd, p.r_id, p.Gross, 
            p.GMP, p.OTCType, p.deduct, p.ModifyDate, p.MaintainDay, p.MaintainType, 
	        p.LatinName, p.ChemName, p.EngName, p.costmethod,m.baseinfo_id as medtype, p.gspflag, 
	        p.otcflag, p.validcheck, p.firstcheck, p.pinyin, p.deleted, p.comment, p.validday, 
	        p.validmonth, p.rate4, p.rate3, p.rate2, p.unit4_id, p.unit3_id, p.unit2_id, p.unit1_id, 
	        p.makearea, p.trademark, p.permitcode, p.modal, p.standard, p.alias, p.name, 
	        p.serial_number, p.child_count, p.child_number, p.parent_id, p.class_id, p.product_id, 
	        '' as MedCode, ISNULL(m.name,'')MedName, ISNULL(u1.name, '')Unit1Name, 
            isnull(pr.price_id,0) price_id,isnull(pr.Y_id,0) pos_id,
		    isnull(pr.p_id,0) p_id,isnull(pr.u_id,0) u_id,isnull(pr.retailprice,0) retailprice,
		    isnull(pr.recPrice,0) recPrice,isnull(pr.price1,0) price1,isnull(pr.price2,0) price2,
		    isnull(pr.price3,0) price3,isnull(pr.price4,0) price4,isnull(pr.gpprice,0) gpprice,
		    isnull(pr.glprice,0) glprice,isnull(pr.specialprice,0) specialprice,
		    isnull(pr.unittype,0) unitType,isnull(pr.Lowprice,0) Lowprice,
		    CONVERT(   NUMERIC(18, 3),
                          ROUND(
                              (   CASE WHEN (   @nMLRateType = 0 AND pr.retailprice > 0 AND pr.recprice > 0) THEN (pr.retailprice - pr.recprice) / pr.retailprice
                                       ELSE (   CASE WHEN (@nMLRateType = 1 AND pr.price1 > 0 AND pr.recprice > 0) THEN (pr.price1 - pr.recprice) / pr.price1
                                                     ELSE (   CASE WHEN (@nMLRateType = 2 AND pr.price2 > 0 AND pr.recprice > 0) THEN (pr.price2 - pr.recprice) / pr.price2
                                                                   ELSE (   CASE WHEN (@nMLRateType = 3 AND pr.price3 > 0 AND pr.recprice > 0) THEN (pr.price3 - pr.recprice) / pr.price3
                                                                                 ELSE (   CASE WHEN (@nMLRateType = 4 AND pr.price4 > 0 AND pr.recprice > 0) THEN (pr.price4 - pr.recprice) / pr.price4
                                                                                               ELSE (   CASE WHEN (@nMLRateType = 5 AND pr.gpprice > 0 AND pr.recprice > 0) THEN (pr.gpprice - pr.recprice) / pr.gpprice
                                                                                                             ELSE (   CASE WHEN (@nMLRateType = 6 AND pr.glprice > 0 AND pr.recprice > 0) THEN (pr.glprice - pr.recprice) / pr.glprice
                                                                                                                           ELSE (   CASE WHEN (   @nMLRateType = 7 AND pr.specialprice > 0 AND pr.recprice > 0
                                                                                                                                              ) THEN (pr.specialprice - pr.recprice) / pr.specialprice ELSE  0.000
                                                                                                                                    END
                                                                                                                                )
                                                                                                                      END
                                                                                                                  )
                                                                                                        END
                                                                                                    )
                                                                                          END
                                                                                      )
                                                                            END
                                                                        )
                                                              END
                                                          )
                                                END
                                            )
                                  END
                              ) * 100,
                              3
                          )
                      ) 
                AS MLRate
	FROM  products p
          LEFT JOIN   (select price_id,Y_id,p_id,u_id,retailprice,recPrice,price1,price2,
                              price3,price4,gpprice,glprice,specialprice,unittype,Lowprice
		         from  POSprice 
		        where unitType=@unittype and Y_id = @Posid
                      )pr  ON p.product_id = pr.p_id
          left   join 
		  (
			select p_id as baseinfo_id,isnull(c.name,'') as name from ProductCategory p 
            left join customCategory c on p.PComent3 = c.class_id 
            where Category_id = 3 and c.deleted = 0  /*剂型*/
		  )m on p.product_id = m.baseinfo_id
		  left   join 
	      (
			select p_id as baseinfo_id,isnull(c.name,0) as name from ProductCategory p 
            left join customCategory c on p.PComent2 = c.class_id 
            where Category_id = 2 and c.deleted = 0  /*税率*/
	      )tx on p.product_id = tx.baseinfo_id
          LEFT JOIN  unit    u1  ON p.unit1_id = u1.unit_id
          LEFT JOIN  unit    u0  ON p.unit2_id = u0.unit_id
          LEFT JOIN  unit    u2  ON p.unit3_id = u2.unit_id
          LEFT JOIN  unit    u3  ON p.unit4_id = u3.unit_id 
	Where Child_number=0 and left(Class_id,len(@parentid))=@parentid and p.deleted=0 and IsSplit = 0
	end
	if @szList='Q'
	begin
	SELECT  p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id,p.serial_number as code, ISNULL(u0.name, '')Unit2Name, ISNULL(u2.name, '')Unit3Name,ISNULL(u3.name, '')Unit4Name,
            tx.name as TaxRate, p.StorageCon, p.packStd, p.r_id, p.Gross, 
            p.GMP, p.OTCType, p.deduct, p.ModifyDate, p.MaintainDay, p.MaintainType, 
	        p.LatinName, p.ChemName, p.EngName, p.costmethod, m.baseinfo_id as medtype, p.gspflag, 
	        p.otcflag, p.validcheck, p.firstcheck, p.pinyin, p.deleted, p.comment, p.validday, 
	        p.validmonth, p.rate4, p.rate3, p.rate2, p.unit4_id, p.unit3_id, p.unit2_id, p.unit1_id, 
	        p.makearea, p.trademark, p.permitcode, p.modal, p.standard, p.alias, p.name, 
	        p.serial_number, p.child_count, p.child_number, p.parent_id, p.class_id, p.product_id, 
	        '' as MedCode, ISNULL(m.name,'')MedName, ISNULL(u1.name, '')Unit1Name, 
            isnull(pr.price_id,0) price_id,isnull(pr.Y_id,0) pos_id,
		    isnull(pr.p_id,0) p_id,isnull(pr.u_id,0) u_id,isnull(pr.retailprice,0) retailprice,
		    isnull(pr.recPrice,0) recPrice,isnull(pr.price1,0) price1,isnull(pr.price2,0) price2,
		    isnull(pr.price3,0) price3,isnull(pr.price4,0) price4,isnull(pr.gpprice,0) gpprice,
		    isnull(pr.glprice,0) glprice,isnull(pr.specialprice,0) specialprice,
		    isnull(pr.unittype,0) unitType,isnull(pr.Lowprice,0) Lowprice,
		    CONVERT(   NUMERIC(18, 3),
                          ROUND(
                              (   CASE WHEN (   @nMLRateType = 0 AND pr.retailprice > 0 AND pr.recprice > 0) THEN (pr.retailprice - pr.recprice) / pr.retailprice
                                       ELSE (   CASE WHEN (@nMLRateType = 1 AND pr.price1 > 0 AND pr.recprice > 0) THEN (pr.price1 - pr.recprice) / pr.price1
                                                     ELSE (   CASE WHEN (@nMLRateType = 2 AND pr.price2 > 0 AND pr.recprice > 0) THEN (pr.price2 - pr.recprice) / pr.price2
                                                                   ELSE (   CASE WHEN (@nMLRateType = 3 AND pr.price3 > 0 AND pr.recprice > 0) THEN (pr.price3 - pr.recprice) / pr.price3
                                                                                 ELSE (   CASE WHEN (@nMLRateType = 4 AND pr.price4 > 0 AND pr.recprice > 0) THEN (pr.price4 - pr.recprice) / pr.price4
                                                                                               ELSE (   CASE WHEN (@nMLRateType = 5 AND pr.gpprice > 0 AND pr.recprice > 0) THEN (pr.gpprice - pr.recprice) / pr.gpprice
                                                                                                             ELSE (   CASE WHEN (@nMLRateType = 6 AND pr.glprice > 0 AND pr.recprice > 0) THEN (pr.glprice - pr.recprice) / pr.glprice
                                                                                                                           ELSE (   CASE WHEN (   @nMLRateType = 7 AND pr.specialprice > 0 AND pr.recprice > 0
                                                                                                                                              ) THEN (pr.specialprice - pr.recprice) / pr.specialprice ELSE  0.000
                                                                                                                                    END
                                                                                                                                )
                                                                                                                      END
                                                                                                                  )
                                                                                                        END
                                                                                                    )
                                                                                          END
                                                                                      )
                                                                            END
                                                                        )
                                                              END
                                                          )
                                                END
                                            )
                                  END
                              ) * 100,
                              3
                          )
                      ) 
                AS MLRate
	FROM  products p
          LEFT JOIN   (select price_id,Y_id,p_id,u_id,retailprice,recPrice,price1,price2,
                              price3,price4,gpprice,glprice,specialprice,unittype,Lowprice
		         from  POSprice 
		        where unitType=@unittype and Y_id = @Posid
                      )pr  ON p.product_id = pr.p_id
          left   join 
		  (
			select p_id as baseinfo_id,isnull(c.name,'') as name from ProductCategory p 
            left join customCategory c on p.PComent3 = c.class_id 
            where Category_id = 3 and c.deleted = 0  /*剂型*/
		  )m on p.product_id = m.baseinfo_id
		  left   join 
	      (
			select p_id as baseinfo_id,isnull(c.name,0) as name from ProductCategory p 
            left join customCategory c on p.PComent2 = c.class_id 
            where Category_id = 2 and c.deleted = 0  /*税率*/
	      )tx on p.product_id = tx.baseinfo_id
          LEFT JOIN  unit    u1  ON p.unit1_id = u1.unit_id
          LEFT JOIN  unit    u0  ON p.unit2_id = u0.unit_id
          LEFT JOIN  unit    u2  ON p.unit3_id = u2.unit_id
          LEFT JOIN  unit    u3  ON p.unit4_id = u3.unit_id 
	/*where p.[Name] Like @szPName and p.child_number=0 and p.deleted=0*/
	  Where ((P.[alias] Like @szPName) or (P.[Name] Like @szPName) or (p.class_id like @classid)) and p.Child_Number=0  and p.deleted=0 and IsSplit = 0
	end
end

/*门店单品价格分析*/
if @dbName='POSDPPRICE'
begin

	select 
		s.[Name] as PosName,pp.UnitName,p.unit1_id,p.unit2_id,p.unit3_id,p.unit4_id,
		p.product_id,p.name as PName,
		isnull(pp.retailprice,0)retailprice, isnull(pp.price1,0)price1, isnull(pp.price2,0)price2, 
		isnull(pp.price3,0)price3, isnull(pp.price4,0)price4, isnull(pp.gpprice,0)gpprice, isnull(pp.glprice,0)glprice, 
		isnull(pp.specialprice,0)specialprice, isnull(pp.recprice,0)recprice, isnull(pp.lowprice,0)lowprice
		from      Company 	s   
		left join vw_L_POSprice pp on pp.Y_id=s.Company_id 
		left join products p on p.product_id=pp.p_id
		where  s.deleted=0 and p.Class_id=@szPName and pp.UnitType=@UnitType and p.IsSplit = 0
                AND (@nYClassID='' or S.class_ID like @nYClassID+'%')
	        AND (@CompanyTable=0 or ((@nYClassID<>'') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.class_id like u.psc_id+'%'))))


end
GO
