/************************************************************
--过程名称：Ts_T_ClientbySendid
--功能：通过往来单位id和配送单id分类往来单位
--创建人：XXX

备注：
**************************************************************/
create proc [dbo].[Ts_T_ClientbySendid]
( /*@BeginDate  [datetime], */
  /*@EndDate    [datetime],*/
  @szbillid   VARCHAR(30) = '' /*条件(物流单的id串)*/
/*  @BillCode   varchar(20) ,*/
/*  @Emp        int = 0,*/
/*  @Sendid     int = 0,*/
/*  @Customer   int = 0,*/
)

as
	select rtrim(ltrim(convert(VARCHAR(50),(str(Sendid) + '-'+ rtrim(ltrim(str(c_id))))))) as Ckeyid, Sendid,c.* from
	   (select Sendid,c_id from billidx 
	    where Sendid in (select CAST(szTYPE as int) as Sendid from dbo.DecodeToStr(@szBillid)) 
	    group by Sendid,c_id  
	   ) sc
		left join clients c on c.client_id = sc.c_id
	order by Sendid
		
    /*select * from clients where client_id in ( select c_id from #t )*/
GO
