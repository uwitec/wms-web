

CREATE VIEW dbo.vw_j_BillToGsp
AS
SELECT a.ID, a.BillType, a.Gsptype, a.sysFlag, v.FormStyle,a.storetype, 
      a.gsppropert,a.OTCType,
      v.Name as DestName
FROM dbo.BillToGsp a INNER JOIN
      GspVchType v ON a.GSPType = v.GspType
GO
