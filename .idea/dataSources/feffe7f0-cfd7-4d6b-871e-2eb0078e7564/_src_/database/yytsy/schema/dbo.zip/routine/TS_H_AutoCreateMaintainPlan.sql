
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-8-15*/
/* Description:	自动生成养护计划*/
/* =============================================*/
CREATE PROCEDURE TS_H_AutoCreateMaintainPlan(@PlanId INT) 
AS
BEGIN
	SET NOCOUNT ON;

	IF @PlanId = -1
	BEGIN
		/*等于-1时查询适合条件的全部计划模板*/
		SELECT   plan_id, planType
		FROM     dbo.GspMaintainPlan
		WHERE    ((runDate = DATEPART(dd, GETDATE())) OR (runDate = 0)) AND (execDate < CONVERT(varchar(10), GETDATE(), 120))
		or ((DATEPART(MM,execDate)<>DATEPART(MM,GETDATE())) and (execDate < CONVERT(varchar(10), GETDATE(), 120))) and (runDate < DATEPART(dd, GETDATE())) 
		order by planDate
	END
	ELSE
	BEGIN
		/*根据ID获取计划模板*/
			declare @Name varchar(100)
		declare @nplanId int
		declare @nSid int
		declare @nLid int
		declare @nMedType int
		declare @nQty NUMERIC(25,8)
		declare @sGspProp varchar(500)
		declare @nInstoreDays int
		declare @bNearValid bit
		declare @bKeyProduct bit
		declare @bFirst bit
		declare @bLastMaintain bit
		declare @nPlanType int
		declare @MaintainEId int
		declare @MaintainEName varchar(80)
		DECLARE @bScattered BIT
		DECLARE @Max INT
		declare @IsValuedProduct INT
		DECLARE @YId INT 
	            
		declare @nNearDays int
		exec ts_GetSysValue 'NearValidDay', @nNearDays output, 0

		CREATE TABLE #t(
			sh_id int
		)
		
		declare curPlan cursor for
		SELECT   plan_id, s_id, loc_id, med_type, qty, gspProp, instoreDays, isNearValid, isKeyProduct, isFirst, 
				 isLastMaintain, planType, NAME, MaintainEId, MaintainEName, isScattered, iMax, IsValuedProduct, YId
		FROM     dbo.GspMaintainPlan
		WHERE    plan_id = @PlanId
		open curPlan
		fetch next from curPlan into @nplanId, @nSid, @nLid, @nMedType, @nQty, @sGspProp, @nInstoreDays, @bNearValid, 
									 @bKeyProduct, @bFirst, @bLastMaintain, @nPlanType, @Name, @MaintainEId, @MaintainEName, 
									 @bScattered, @Max, @IsValuedProduct, @YId
		while @@fetch_status=0
		begin
			update GspMaintainPlan set execDate = GETDATE() where plan_id = @nplanId
			
			if @nPlanType IN (0, 2)
			begin
				INSERT INTO #t

				SELECT STOREHOUSE_ID
				FROM      dbo.storehouse AS s INNER JOIN
								dbo.products AS p ON s.p_id = p.product_id
								left   join 
								  (
										select name,category_id,b.P_id from customCategory a inner join ProductCategory b on a.class_id=b.PComent1 where a.baseType=0 and Category_id=1 and a.deleted=0
								  )m on p.product_id = m.P_id
				WHERE   (s.quantity >= @nQty) AND (s.instoretime < GETDATE() - @nInstoreDays) AND (s.yhdate < GETDATE() - @nInstoreDays)
						AND (p.gspflag IN (select * from DecodeToStr(@sGspProp))) AND (s.s_id = @nSid OR @nSid = 0) AND (s.location_id = @nLid OR @nLid = 0)
						AND (m.category_id = @nMedType OR @nMedType = 0
						) and p.MaintainType = 0 and ((s.validdate - GETDATE() > @nNearDays) or (convert(varchar(10),s.validdate,120) = '1900-01-01'))
						AND (s.Y_ID = @YId OR @YId = 0)
			end
			else
			if @nPlanType IN (1, 3)
			begin
				INSERT INTO #t
				SELECT STOREHOUSE_ID
				FROM      dbo.storehouse AS s INNER JOIN
								dbo.products AS p ON s.p_id = p.product_id
								left   join 
								  (
										select name,category_id,b.P_id from customCategory a inner join ProductCategory b on a.class_id=b.PComent1 where a.baseType=0 and Category_id=1 and a.deleted=0
								  )m on p.product_id = m.P_id
				WHERE   (s.quantity >= @nQty) AND ((s.validdate - GETDATE() <= @nNearDays AND @bNearValid = 1 and s.validdate > GETDATE()) 
						or (p.MaintainType = 1 AND @bKeyProduct = 1)
						or ((p.firstcheck = 1 OR p.product_id IN (SELECT DISTINCT g.P_ID 
																  FROM GspTable g 
																  WHERE g.GspType = 2203 AND g.CheckState = 2 AND 
																		g.P_ID > 0 AND g.BillDate > GETDATE() - 365)) AND @bFirst = 1) 
						or (s.p_id in (select p_id from GspMaintainP) AND @bLastMaintain = 1)
						or (p.IsValuedProduct=@IsValuedProduct and @IsValuedProduct=1)) /*zfl 养护计划模板增加贵细药品的过滤*/
						AND (p.gspflag IN (select * from DecodeToStr(@sGspProp))) AND (s.s_id = @nSid OR @nSid = 0) AND (s.location_id = @nLid OR @nLid = 0)
						AND (m.category_id = @nMedType OR @nMedType = 0
						)
						AND (s.Y_ID = @YId OR @YId = 0)
				UNION
				SELECT STOREHOUSE_ID 
				FROM	dbo.storehouse s INNER JOIN storages s2 ON s.s_id = s2.storage_id
				WHERE   s2.WholeFlag = 3 AND @bScattered = 1 AND (s.s_id = @nSid OR @nSid = 0) AND (s.Y_ID = @YId OR @YId = 0)
				        and dateadd(month,1,s.yhdate)<=GETDATE()		
			end
		fetch next from curPlan into @nplanId, @nSid, @nLid, @nMedType, @nQty, @sGspProp, @nInstoreDays, @bNearValid, 
									 @bKeyProduct, @bFirst, @bLastMaintain, @nPlanType, @Name, @MaintainEId, @MaintainEName, 
									 @bScattered, @Max, @IsValuedProduct, @YId
		end
		Close curPlan
		deallocate curPlan
		SELECT  s.p_id,s.location_id, p.name, p.alias, p.serial_number, ISNULL(m.name, '') AS mt_name, p.standard, p.trademark, p.Factory, p.makearea, 
		        p.permitcode, s.makedate, s.validdate, s.batchno, 
		        /*u.name AS unitName, */
		        CASE WHEN sg.WholeFlag = 3 THEN ISNULL(clu.name, '') ELSE u.name END AS unitName,
		        s.quantity, sg.name AS sName, ISNULL(lc.loc_name, '') as lname, s.instoretime, p.StorageCon, s.s_id, p.gspflag, p.validday, p.validmonth, @nPlanType AS PlanType, 
		        @Name AS PlanName, @MaintainEId AS MaintainEId, @MaintainEName AS MaintainEName,
		        @Max AS iMax, p.gspflag, ISNULL(sg.Y_ID, 0) AS Y_ID,isnull(gys.name,'') as gysname
		FROM    (SELECT * FROM dbo.storehouse WHERE storehouse_id IN (SELECT sh_id FROM #t)) AS s 
					INNER JOIN dbo.products AS p ON s.p_id = p.product_id 
					INNER JOIN dbo.storages AS sg ON s.s_id = sg.storage_id 
					LEFT join dbo.location as lc on s.location_id = lc.loc_id
					INNER JOIN dbo.unit AS u ON p.unit1_id = u.unit_id 
					left   join 
					  (
							select name,category_id,b.P_id from customCategory a inner join ProductCategory b on a.class_id=b.PComent1 where a.baseType=0 and Category_id=1 and a.deleted=0
					  )m on p.product_id = m.P_id
	    			LEFT JOIN dbo.unit AS clu ON p.cldw = clu.unit_id	
	    			left join clients as gys  on s.supplier_id=gys.client_id 
					order by s.yhdate, s.p_id
		DROP TABLE #t	
	END
END
GO
