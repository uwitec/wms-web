CREATE PROCEDURE Ts_K_GetDeductTemplateReportMaster(@TId INT)
AS
BEGIN
	DECLARE @Type INT
	SELECT @Type = ISNULL(s.[Type], 0) FROM Deduct_Template s WHERE s.TId = @TId
	
	IF @Type = 0
	BEGIN
		/*职员*/
		SELECT NEWID() AS KeyId, b.BaseInfoId, a.TId, a.[Type], a.Name, a.Comment, e.name AS EName, e1.name AS ModifyEName, a.ModifyDate
		  FROM Deduct_Template a INNER JOIN Deduct_TemplateIds b ON a.TId = b.TId 
								 INNER JOIN employees e ON b.BaseInfoId = e.emp_id
								 INNER JOIN employees e1 ON a.ModifyEId = e1.emp_id
		WHERE a.TId = @TId	
	END
	ELSE
	BEGIN
		/*机构*/
		SELECT NEWID() AS KeyId, b.BaseInfoId, a.TId, a.[Type], a.Name, a.Comment, e.name AS EName, e1.name AS ModifyEName, a.ModifyDate
		  FROM Deduct_Template a INNER JOIN Deduct_TemplateIds b ON a.TId = b.TId 
								 INNER JOIN company e ON b.BaseInfoId = e.company_id 
								 INNER JOIN employees e1 ON a.ModifyEId = e1.emp_id
		WHERE a.TId = @TId	
	END
END
GO
