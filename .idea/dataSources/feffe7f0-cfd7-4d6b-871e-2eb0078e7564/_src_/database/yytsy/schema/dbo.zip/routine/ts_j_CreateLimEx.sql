
CREATE PROCEDURE [dbo].[ts_j_CreateLimEx]
 (
  @nMode int = 0
 )

AS 
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
/*Params Ini end*/

if @nMode in (0, 1)
begin
  insert into EmplimitEx(e_id, orderIndex, lim, ProductInfor, ClientInfor, PriceInfor)
    select emp_id, 0, 0, '', '', '' 
      from employees  
      where  emp_id not in (select e_id from EmplimitEx) and deleted = 0
      
      update EmplimitEx set 
ProductInfor='商品全名,通用名,拼音码,英文名,化学名,拉丁名,商品编码,规格,批准文号,产地,药品种类,有效期(月),打印类别,剂型,有效期(天),装箱规格,储藏条件,GSP属性,非处方药,提成比例,养护,养护天数,门店养护天数,注册商标,注册证号,默认货位,生产许可证号,生产厂家,商品税率,单位,主供货商,主采购员,备注,GMP达标,首营药品,处方药,生成自动编码,价格修改,价格查看,提成方式,自定义属性,基本药物,价格保护,销售加价率1,销售加价率2,销售加价率3,温度条件,贮藏,电子监管,检验报告,特管药品控制,贵细药品,中药,采购基数,请货基数,包装,辅助税率,税务分类编号',
ClientInfor='名称,简名,拼音码,编号,首营企业,片区,类型,业务员,联系电话,仓库地址,联系人,邮编,税号,开户行及帐号,价格方式,收付款期限(天),应收合计,应付合计,预收合计,预付合计,期初应收,期初应付,期初预收,期初预付,信用额度,认证类型,GSP证书号,GMP证书号,企业许可证,销售加价率,创建日期,自定义属性,备注,经营范围,所属信息,证照期限,自定义证照,在途周期,注册地址,结算方式,结算周期',
PriceInfor='1111111111'
where e_id=1

end

if @nMode in (0, 2)
begin
  insert into limgroupEx(gid, orderIndex, permission)
    select gid, 0, 0 
      from limgroup  
      where  gid not in (select gid from limgroupEx)
end
GO
