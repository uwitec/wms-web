


/*增加对商品不同状态的查询支持   wsk 2007-06-06*/
create PROCEDURE Ts_L_QrBaseInfo
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找 6:在零成本库存余量显示总部库存余量*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0,
 @s_id int= 0       /*仓库的id*/
 )       
 AS
/*Params Ini begin*/
if @szWhere is null  SET @szWhere = '2'
if @E_id is null  SET @E_id = 0
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_ID is null  SET @nY_ID = 0
if @nLoginid is null  SET @nLoginid = 0

if @tablename = 'PRODUCTS2'
 exec Ts_L_QrBaseInfo_PRODUCTS2 @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid,@s_id

if Upper(@TableName)='PRODUCTS'
 exec Ts_L_QrBaseInfo_PRODUCTS @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid



if Upper(@TableName)='EMPLOYEES'
 exec Ts_L_QrBaseInfo_EMPLOYEES @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='CLIENTS'
 exec Ts_L_QrBaseInfo_CLIENTS @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='STORAGES'
 exec Ts_L_QrBaseInfo_STORAGES @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='ACCOUNT'
 exec Ts_L_QrBaseInfo_ACCOUNT @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='LOCATION'
 exec Ts_L_QrBaseInfo_LOCATION @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='COMPANY'
 exec Ts_L_QrBaseInfo_COMPANY @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='REGION'
 exec Ts_L_QrBaseInfo_REGION @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


/*---出库复核批次条码*/
if Upper(@tablename) = 'PRODUCTSBC'
 exec Ts_L_QrBaseInfo_PRODUCTSBC @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


if Upper(@TableName)='STOCKAREA'
 exec Ts_L_QrBaseInfo_STOCKAREA @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid


IF UPPER(@TableName) = 'CONSIGNDEPT'
 exec Ts_L_QrBaseInfo_CONSIGNDEPT @TableName,@szName,@szWhere,@E_id,@nShowStatus,@nFilterY, @nY_ID, @nLoginid
GO
