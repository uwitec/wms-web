




CREATE FUNCTION GetClassId(@nFlag int,@nId int)
RETURNS  varchar(36) 
AS  
BEGIN 
	declare @ClassId varchar(36)
	if @nFlag=0 select @Classid=Class_id from account where account_id=@nid and deleted=0
	if @nFlag=1 select  @ClassId=Class_id from products where product_id=@nid and deleted<>1
	if @nFlag=2 select @Classid=Class_id from clients where client_id=@nid and deleted=0
	if @nFlag=3 select @Classid=Class_id from employees where emp_id=@nid and deleted=0
	if @nFlag=4 select @Classid=Class_id from storages where storage_id=@nid and deleted=0
	return(@ClassId)
END
GO
