




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
历史单据和草稿查询
@BeginDate   开始时间
@EndDate		 结束时间
@szBillType  单据类型
@nC_id			 客户的ID号
@nE_id			 职员的ID号
@nSs_id 		 经手人ID号
@nSd_id 		 审核人ID号
@PosId			 0 配送中心单据，<>0 门店单据
@cMode			 0 以单据日期来过滤, 1以单据过帐日期过滤
@nFlag			 0 已过帐单据, 1草稿
@nZd_id			 制单人ID号

********************************************/
CREATE PROCEDURE [Ts_M_QrOfflineBillIDX]
(	@BeginDate  DATETIME=0,
	@EndDate		DATETIME=0,
	@szBillType VARCHAR(1000)='',
	@nC_ID			INT=0,
	@nE_ID			INT=0,
	@nSs_ID 		INT=0,
	@nSd_ID 		INT=0,
	@PosId			INT=0,
	@cMode			INT=0,
	@nFlag			INT=0,
	@nZd_ID			INT=0,
	@nCompanyClass_id       varchar(50)='',
    @nloginEID              int=0,
    @Searchtype             int=0,
    @isUpdate               int=1,/*1:查询YRetailBillIdx 2:查询ybilldraftidx*/
	@nY_ID			INT=0
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szBillType is null  SET @szBillType = ''
if @nC_ID is null  SET @nC_ID = 0
if @nE_ID is null  SET @nE_ID = 0
if @nSs_ID is null  SET @nSs_ID = 0
if @nSd_ID is null  SET @nSd_ID = 0
if @PosId is null  SET @PosId = 0
if @cMode is null  SET @cMode = 0
if @nFlag is null  SET @nFlag = 0
if @nZd_ID is null  SET @nZd_ID = 0
if @nCompanyClass_id is null  SET @nCompanyClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @Searchtype is null  SET @Searchtype = 0
if @isUpdate is null  SET @isUpdate = 1
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
SET NOCOUNT ON
  set @EndDate=@EndDate+1
  
  IF @nCompanyClass_id<>'' select @nCompanyClass_id=@nCompanyClass_id+'%'
  else  select @nCompanyClass_id='%%'  
    
  DECLARE @SQLScript VARCHAR(8000), @szC_ID VARCHAR(30), @szE_ID VARCHAR(30), @szY_ID VARCHAR(100)
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  /*set @szC_ID='' set @szE_ID='' set @szY_ID=''*/
  SELECT @szC_ID=[Class_ID] FROM Clients WHERE [Client_ID]=@nC_ID
  SELECT @szE_ID=[Class_ID] FROM Employees WHERE [Emp_ID]=@nE_ID
  SELECT @szY_ID=[Class_ID] FROM Company WHERE [Company_ID]=@nY_ID


  Declare @Filtertype varchar(100)
  select @Filtertype=''
/*
  if @Searchtype=0
     select @Filtertype=''
  else if @Searchtype=1
     select @Filtertype=' and b.billtype not in (150,151,155,160,161,165) '
  else if @Searchtype=2
     select @Filtertype=' and b.billtype in (150,151,155,160,161,165) '
*/
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
     Insert #Clienttable ([id]) select 0
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      Insert #Companytable ([id]) select 0
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      Insert #storagestable ([id]) select 0
   end
/*---仓库授权*/



if (@isUpdate = 1)
BEGIN
   SELECT  @SQLScript=' SELECT  DISTINCT 
        b.billID, b.billtype, b.billdate, b.billstates, b.billnumber, b.skdate,
        b.inputman, b.auditman, b.GatheringMan, b.note, b.SUMmary, b.quantity, 
        ysmoney=case  when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.ysmoney else b.ysmoney end, b.ssmoney, b.araptotal, b.taxrate, b.auditdate, 
        b.[sout_id], b.[sin_id],
        (case when billtype in (122,112) then '' '' else b.[ssname] end)ssname ,
        (case when billtype in (122,112) then '' '' else b.[sdname] end)sdname,
        CASE WHEN b.billtype IN (44, 45) THEN b.ssname when b.billtype in (171,172,173,174) Then '''' ELSE b.cname END AS cname,
    		b.ename AS employeename, 
    		b.auditmanname,
    		b.inputmanname,
    		b.aname AS accountname,
    		b.departmentname,
    		b.regionname,
		b.GatheringManName,
        isnull(p.printcount,0) as printcount,
        b.Y_id ,b.guid,b.YName,
        '' '' as B_CustomName1, '' '' as B_CustomName2, '' '' as B_CustomName3,b.transflag
         ,0 as inputman,0 as QualityAudit, GETDATE() as QualityAuditdate, '' '' as QualityAuditer, 
          '' '' as wtEname, cast(0 as NUMERIC(25,8)) as overtotal,
         (case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype , '''' as SendCName
        FROM vw_c_BillIdx b inner join (select mdbillid from upBillList where dcFlag = 0) up on b.billid =up.mdbillid         
        left join vw_c_printcount p on b.billid=p.Rep_id'
end 
else if (@isUpdate = 2)  
begin
   SELECT  @SQLScript=' SELECT  DISTINCT 
        b.billID, b.billtype, b.billdate, b.billstates, b.billnumber, b.skdate,
        b.inputman, b.auditman, b.GatheringMan, b.note, b.SUMmary, b.quantity, 
        ysmoney=case  when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.ysmoney else b.ysmoney end, b.ssmoney, b.araptotal, b.taxrate, b.auditdate, 
        b.[sout_id], b.[sin_id],
        (case when billtype in (122,112) then '' '' else b.[ssname] end)ssname ,
        (case when billtype in (122,112) then '' '' else b.[sdname] end)sdname,
        CASE WHEN b.billtype IN (44, 45) THEN b.ssname when b.billtype in (171,172,173,174) Then '''' ELSE b.cname END AS cname,
    		b.ename AS employeename, 
    		b.auditmanname,
    		b.inputmanname,
    		b.aname AS accountname,
    		b.departmentname,
    		b.regionname,
		b.GatheringManName,
        isnull(p.printcount,0) as printcount,
        b.Y_id ,b.guid,b.YName,
        b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,b.transflag
        ,0 as inputman,0 as QualityAudit, GETDATE() as QualityAuditdate, '' '' as QualityAuditer, 
         '' '' as wtEname, cast(0 as NUMERIC(25,8)) as overtotal,
          (case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype , '''' as SendCName
        FROM vw_c_Ybilldraftidx b left join vw_c_printcount p on b.billid=p.Rep_id'
end 
   IF  @cMode=0 
   BEGIN
       SET @SQLScript=@SQLScript+' WHERE (b.billdate between '
           +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
           +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'
   END ELSE
   BEGIN
       SET @SQLScript=@SQLScript+' WHERE (b.auditdate between '
           +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
           +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'
   END
   IF  @szBillType<>''
       SET @SQLScript=@SQLScript+@szBillType
   IF  @nC_id<>0 
       SET @SQLScript=@SQLScript+'and billtype not in (150,151,155,160,161,165) and left(b.cclass_id, len('+CHAR(39)+@szC_ID+CHAR(39)+'))='+CHAR(39)+@szC_ID+CHAR(39)
   IF  @nE_id<>0
       SET @SQLScript=@SQLScript+' and left(b.eclass_id, len('+CHAR(39)+@szE_ID+CHAR(39)+'))='+CHAR(39)+@szE_ID+CHAR(39)
   IF  @nY_id<>0 
       SET @SQLScript=@SQLScript+'and billtype  in (150,151,155,160,161,165) and left(b.CYclass_id, len('+CHAR(39)+@szY_ID+CHAR(39)+'))='+CHAR(39)+@szY_ID+CHAR(39)
  

   IF  @nSs_id<>0
       SET @SQLScript=@SQLScript+' and b.sin_id='+CHAR(39)+CAST(@nSs_id AS VARCHAR)+CHAR(39)

   IF  @nZd_id<>0
       SET @SQLScript=@SQLScript+' and b.inputman='+CHAR(39)+CAST(@nZd_id AS VARCHAR)+CHAR(39)
   
   if @employeestable<>0
   set @SQLScript=@SQLScript+' AND (b.E_id in (select [id] from #employeestable))'
   
   if @Storetable<>0 
   set @SQLScript=@SQLScript+' AND (b.sin_id in (select [id] from #storagestable))' 
  
   if @ClientTable<>0 
   set @SQLScript=@SQLScript+' AND (b.c_id in (select [id] from #Clienttable))'

   if @Companytable<>0
   set @SQLScript=@SQLScript+' AND (b.Y_id in (select [id] from #Companytable))  '   

   set @SQLScript=@SQLScript+@Filtertype


   SET @SQLScript=@SQLScript+' and b.YClass_ID like '+CHAR(39)+@nCompanyClass_id+CHAR(39)+'  ORDER BY [billdate]'
 

  
   EXEC(@SQLScript)
 GOTO Succee



Succee:
  RETURN  0
GO
