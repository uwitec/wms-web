
CREATE	  PROCEDURE ts_L_QrStoreLimit
(@s_id	int,
@parentID	varchar(30),
@szListFlag	char(1),
@begindate datetime,
@enddate	 datetime,
@isNoPurchase    int=0,
@isNoSend        int=0,
@szY_id          int=0,
@nsa_id          int=0
)
 AS
/*Params Ini begin*/
if @isNoPurchase is null  SET @isNoPurchase = 0
if @isNoSend is null  SET @isNoSend = 0
if @szY_id is null  SET @szY_id = 0
if @nsa_id is null SET @nsa_id = 0
/*Params Ini end*/
set nocount on

DECLARE @szPareID VARCHAR(30)
IF @s_id = 0
    SET @szPareID = '000000'
ELSE
	SELECT @szPareID = class_id + '%' FROM storages WHERE storage_id = @s_id

declare @daydiff int
declare @szsql varchar(8000),@szsql2 varchar(8000),@sqlNoPurchase varchar(100),@sqlNoSend varchar(100)
declare @sqlNoPurchase2 varchar(100),@sqlNoSend2 varchar(100)
set @daydiff=datediff(day,@begindate,@enddate)

if @daydiff=0 set @daydiff=1
  
 IF @isNopurchase=0
 begin
   set @sqlNopurchase='+0'
   set @sqlNopurchase2='+0'
 end
  else
 begin
   set @sqlNopurchase=' +isnull(sum(bm.NopurchaseQTY),0)'
   set @sqlNopurchase2=' +isnull(bm.NopurchaseQTY,0)'
 end
 
  IF @isNosend=0
  begin
    set @sqlNosend='-0'
    set @sqlNosend2='-0'  
  end
  else
  begin
    set @sqlNoSend=' -isnull(sum(sm.NosendQTY),0)'
    set @sqlNosend2=' -isnull(sm.NosendQTY,0)'
  end
if @szListFlag='L'  goto ListLeavel
if @szListFlag='A'	goto ListAll
if @szListFlag='P'	goto ListPart
if @szListFlag='U'	goto ListUpper
if @szListFlag='V'	goto listLow
if @szListFlag='N'      goto listNoneQuantity

return 0
listLeavel:
begin
	select a.product_id,a.parent_id,a.child_count,a.serial_number,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,
		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,a.retailprice,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
                a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,g.AccountComment as factory,
		cast(isnull(sum(b.quantity),0)	as NUMERIC(25,8)) as Qty,
		cast(isnull(sum(b.quantity),0)*isnull(a.retailprice,0) as NUMERIC(25,8)) as retailtotal,
		isnull(sum(d.upperlimit),0) as upperLimit,
		isnull(sum(d.lowLimit),0) as lowlimit,
		isnull(sum(d.AdjQty),0) as AdjQty,
		ISNULL(SUM(d.bywayday),0) as bywayday,
		ISNULL(SUM(d.planday),0) as Planday,
		ISNULL(f.TraceCName, '') AS TraceCName, 
		ISNULL(f.TraceEName, '') AS TraceEName	
		from (select * from vw_Products p left join 
		       (select * from vw_productbalance  where  Y_id=@szY_id )pb on p.product_id=pb.p_id
               )  a 
               
		     left join	(SELECT products.class_id, ISNULL(SUM(storehouse.quantity), 0) AS quantity
		              	 FROM   (SELECT a.s_id,a.location_id, a.y_id, a.p_id, a.quantity, b.class_id
		              	            FROM   storehouse a INNER JOIN storages b ON  a.s_id = b.storage_id
		              	        ) storehouse
		              	        INNER JOIN products
		              	             ON  storehouse.p_id = products.product_id
		              	        LEFT JOIN location l on storehouse.s_id = l.s_id and storehouse.location_id = l.loc_id 
		              	 WHERE  products.deleted <> 1 AND (@szPareID = '000000' OR storehouse.class_id LIKE @szPareID) AND Y_id = @szY_id
		              	 AND (@nsa_id = 0 or sa_id = @nsa_id)
		              	 GROUP BY products.class_id
					) as b 
			  on LEFT(b.[class_id], LEN(a.[class_id]))=a.[class_id]      /*(a.product_id=b.product_id)*/
		     left join (select c.P_id,isnull(sum(c.upperlimit),0) as upperlimit,
				isnull(SUM(c.lowLimit), 0) as LowLimit, 
				isnull(SUM(c.AdjQty), 0) as AdjQty, 
				ISNULL(SUM(c.bywayday), 0) as bywayday,
				ISNULL(SUM(c.planday), 0) as planday
				from StoreLimit c 
				Where (c.S_id=@s_id) and Y_id=@szY_id and (@nsa_id = 0 or sa_id = @nsa_id)
				group by c.P_id
				) as d
			  on (a.product_id=d.P_id)
			  LEFT JOIN ( SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
						  (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
						  FROM buypricehis b WHERE b.Y_ID = @szY_id GROUP BY b.p_id) a 
						  INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
						  INNER JOIN clients c ON b.c_id = c.client_id
						  INNER JOIN employees e ON b.E_id = e.emp_id) f ON a.product_id = f.p_id
			  LEFT join basefactory g on a.factoryc_id=g.CommID
		where  a.parent_id=@Parentid
		group by a.product_id,a.parent_id,a.child_count,a.serial_number,a.Factory,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,
		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,a.retailprice,
        a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
        a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,g.AccountComment,
        ISNULL(f.TraceCName, ''), ISNULL(f.TraceEName, '')
		order by a.product_id
return 0
end

ListAll:
begin
	select a.product_id,a.parent_id,a.child_count,a.serial_number,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,
		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,a.retailprice,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
                a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,g.AccountComment as Factory,
		cast(isnull(sum(b.quantity),0)	as NUMERIC(25,8)) as Qty,
		cast(isnull(sum(b.quantity),0)*isnull(a.retailprice,0) as NUMERIC(25,8)) as retailtotal,
		isnull(sum(d.upperlimit),0) as upperLimit,
		isnull(sum(d.lowLimit),0) as lowlimit,
		isnull(sum(d.AdjQty),0) as AdjQty,
		ISNULL(SUM(d.bywayday),0) as bywayday,
		ISNULL(SUM(d.planday),0) as Planday,
		ISNULL(f.TraceCName, '') AS TraceCName, 
		ISNULL(f.TraceEName, '') AS TraceEName		
		from (select * from vw_Products p left join 
		       (select * from vw_productbalance  where  Y_id=@szY_id )pb on p.product_id=pb.p_id
               )  a 
		     left join	(SELECT products.product_id, ISNULL(SUM(storehouse.quantity), 0) AS quantity
		              	 FROM   (SELECT a.s_id,a.location_id, a.y_id, a.p_id, a.quantity, b.class_id
		              	            FROM   storehouse a INNER JOIN storages b ON  a.s_id = b.storage_id
		              	        ) storehouse
		              	        INNER JOIN products
		              	             ON  storehouse.p_id = products.product_id
		              	        LEFT JOIN location l on storehouse.s_id = l.s_id and storehouse.location_id = l.loc_id      
		              	 WHERE  products.deleted <> 1 AND (@szPareID = '000000' OR storehouse.class_id LIKE @szPareID) AND Y_id = @szY_id
		              	 AND (@nsa_id = 0 or sa_id = @nsa_id)
		              	 GROUP BY products.product_id
					) as b 
			  on (a.product_id=b.product_id)
		     left join (select c.P_id,isnull(sum(c.upperlimit),0) as upperlimit,
				isnull(SUM(c.lowLimit), 0) as LowLimit, 
				isnull(SUM(c.AdjQty), 0) as AdjQty,
				ISNULL(SUM(c.bywayday), 0) as bywayday,
				ISNULL(SUM(c.planday), 0) as planday
				from StoreLimit c 
				Where (c.S_id=@s_id) and Y_id=@szY_id and (@nsa_id = 0 or sa_id = @nsa_id)
				group by c.P_id
				) as d
			  on (a.product_id=d.P_id)
			  LEFT JOIN ( SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
						  (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
						  FROM buypricehis b WHERE b.Y_ID = @szY_id GROUP BY b.p_id) a 
						  INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
						  INNER JOIN clients c ON b.c_id = c.client_id
						  INNER JOIN employees e ON b.E_id = e.emp_id) f ON a.product_id = f.p_id
			  LEFT join basefactory g on a.factoryc_id=g.CommID
		where a.Child_number=0
		group by a.product_id,a.parent_id,a.child_count,a.serial_number,g.AccountComment,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,
		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,a.retailprice,
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
                a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,a.Factory,
                ISNULL(f.TraceCName, ''), ISNULL(f.TraceEName, '')
		order by a.product_id
return 0
end

ListPart:
begin
	select a.product_id,a.parent_id,a.child_count,a.serial_number,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,

		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,a.retailprice,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
                a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,g.AccountComment as Factory,
		cast(isnull(sum(b.quantity),0)	as NUMERIC(25,8)) as Qty,
		cast(isnull(sum(b.quantity),0)*isnull(a.retailprice,0) as NUMERIC(25,8)) as retailtotal,
		isnull(sum(d.upperlimit),0) as upperLimit,
		isnull(sum(d.lowLimit),0) as lowlimit,
		isnull(sum(d.AdjQty),0) as AdjQty,
		ISNULL(SUM(d.bywayday),0) as bywayday,
		ISNULL(SUM(d.planday),0) as Planday,
		ISNULL(f.TraceCName, '') AS TraceCName, 
		ISNULL(f.TraceEName, '') AS TraceEName		
		from (select * from vw_Products p left join 
		       (select * from vw_productbalance  where  Y_id=@szY_id )pb on p.product_id=pb.p_id
               )  a 
		     left join	(SELECT products.product_id, ISNULL(SUM(storehouse.quantity), 0) AS quantity
		              	 FROM   (SELECT a.s_id,a.location_id, a.y_id, a.p_id, a.quantity, b.class_id
		              	            FROM   storehouse a INNER JOIN storages b ON  a.s_id = b.storage_id
		              	        ) storehouse
		              	        INNER JOIN products
		              	             ON  storehouse.p_id = products.product_id
		              	        LEFT JOIN location l on storehouse.s_id = l.s_id and storehouse.location_id = l.loc_id     
		              	 WHERE  products.deleted <> 1 AND (@szPareID = '000000' OR storehouse.class_id LIKE @szPareID) AND Y_id = @szY_id
		              	 AND (@nsa_id = 0 or sa_id = @nsa_id)
		              	 GROUP BY products.product_id
					) as b 
			  on (a.product_id=b.product_id)
		     left join (select c.P_id,isnull(sum(c.upperlimit),0) as upperlimit,
				isnull(SUM(c.lowLimit), 0) as LowLimit, 
				isnull(SUM(c.AdjQty), 0) as AdjQty,
				ISNULL(SUM(c.bywayday), 0) as bywayday,
				ISNULL(SUM(c.planday), 0) as planday
				from StoreLimit c 
				where (c.S_id=@s_id) and Y_id=@szY_id and (@nsa_id = 0 or sa_id = @nsa_id)
				group by c.P_id
				) as d
			  on (a.product_id=d.P_id)
			  LEFT JOIN ( SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
						  (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
						  FROM buypricehis b WHERE b.Y_ID = @szY_id GROUP BY b.p_id) a 
						  INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
						  INNER JOIN clients c ON b.c_id = c.client_id
						  INNER JOIN employees e ON b.E_id = e.emp_id) f ON a.product_id = f.p_id
			 left join basefactory g on a.factoryc_id=g.CommID
		where left(a.class_id,len(@parentID))=@parentID and a.Child_number=0
		group by a.product_id,a.parent_id,a.child_count,a.serial_number,g.AccountComment,a.permitCode,a.trademark,a.ValidMonth,a.ValidDay,a.Comment,
		a.Pinyin,a.firstCheck,a.validCheck,a.otcFlag,a.GspFlag,a.CostMethod,
		a.class_id,a.child_number,a.[name],a.code,a.alias,a.standard,a.medname,a.medtype,
		a.makearea,a.unit1name,a.c_name,a.e_name,a.recprice,a.retailprice,
                a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
                a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.rname,a.Factory,
                ISNULL(f.TraceCName, ''), ISNULL(f.TraceEName, '')
		order by a.product_id
return 0
end


listUpper:


if @s_id=0 
begin
    SET @szsql='update storelimit set adjqty=0 where p_id not  in (select p_id from storelimit a where a.s_id=0 and a.LowLimit<(SELECT isnull(SUM(b.quantity), 0)'+@sqlNopurchase+@sqlNoSend+'
		 FROM storehouse b  
                 left join
                 (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                  where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)bm
                  on bm.p_id=b.p_id
  
                 left join
                 (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                 where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)SM
                 on SM.p_id=b.p_id

                WHERE	b.p_id=a.P_id))'
    print @szsql
    exec(@szsql)

   SET @szsql=' SELECT a.*,c.*,isnull(b.qty,0) qty,(isnull(b.qty,0)*isnull(c.retailprice,0))retailtotal,cast(0 as NUMERIC(25,8)) as buyorderqty,cast(0 as NUMERIC(25,8)) as saleorderqty,cast(0 as NUMERIC(25,8)) as alldaysaleqty,
          0.0000 as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,
		ISNULL(g.TraceCName, '''') AS TraceCName, 
		ISNULL(g.TraceEName, '''') AS TraceEName
    
    FROM storeLimit a 
	left join (select * from vw_Products p left join 
	             (select * from vw_productbalance  where  Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 )c on a.p_id=c.Product_id

        left join 
        (select isnull(sum(quantity),0) qty,p_id from storehouse b where Y_id='+cast(@szY_id as varchar(50))+' group by p_id)as b
         on b.p_id=a.p_id
        
        left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
         where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
         where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id 
        
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@szY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id '
     
     Set @szsql2='where a.Y_id='+cast(@szY_id as varchar(50))+' and a.upperlimit>0 and a.s_id=0 and c.alert=0 and a.UpperLimit< (isnull(b.qty,0) '+@sqlNoPurchase2+@sqlNoSend2+')'
     print (@szsql+@szsql2)
     exec(@szsql+@szsql2)

end else 
begin
   IF EXISTS(SELECT * FROM storages s WHERE s.storage_id = @s_id AND s.child_number = 0) 
   BEGIN 
    SET @szsql='update storelimit set adjqty=0 where p_id not in (select p_id from storelimit a where a.s_id='+cast(@s_id as varchar(50))+' and LowLimit<(SELECT isnull(SUM(b.quantity)'+@sqlNoPurchase+@sqlNoSend+', 0)
		 FROM storehouse b
                 left join
                 (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                  where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
                  on bm.p_id=b.p_id
  
                 left join
                 (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                 where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)SM
                 on SM.p_id=b.p_id

		 WHERE	b.p_id=a.P_id))'
    /*print @szsql*/
    exec(@szsql)

    SET @szsql=' SELECT a.*,c.*,isnull(b.qty,0) qty,(isnull(b.qty,0)*isnull(c.retailprice,0))retailtotal,cast(0 as NUMERIC(25,8)) as buyorderqty,cast(0 as NUMERIC(25,8)) as saleorderqty, cast(0 as NUMERIC(25,8)) as alldaysaleqty,
       0.0000 as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,
		ISNULL(g.TraceCName, '''') AS TraceCName, 
		ISNULL(g.TraceEName, '''') AS TraceEName
       FROM (select P_id,S_id,Y_ID,ByWayDay,PlanDay, sum(UpperLimit) as UpperLimit,SUM(LowLimit) as LowLimit, sum(AdjQty) AS AdjQty from StoreLimit group by P_id,S_id,Y_ID,ByWayDay,PlanDay) a 
        left join (select * from vw_Products p left join 
	             (select * from vw_productbalance  where Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 )c on a.p_id=c.Product_id

        left join
        (select isnull(sum(quantity),0) qty,p_id from storehouse b  where s_id='+cast(@s_id as varchar(50))+' and Y_id='+cast(@szY_id as varchar(50))+' group by p_id) as b
         on b.p_id=a.p_id

        left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
         where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
         where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id  
        
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@szY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id '

    SET @szsql2='where a.Y_id='+cast(@szY_id as varchar(50))+' and a.upperlimit>0 and c.alert=0 and a.S_id='+cast(@s_id as varchar(50))+' and a.UpperLimit< (isnull(b.qty,0) '+@sqlNoPurchase2+@sqlNoSend2+')'
 
   /*print(@szsql+@szsql2)*/
    exec(@szsql+@szsql2) 
   END
   ELSE
   BEGIN
   	 /*仓库选择的是类别*/
   	 SET @szsql=' SELECT a.*,c.*,isnull(b.qty,0) qty,(isnull(b.qty,0)*isnull(c.retailprice,0))retailtotal,cast(0 as NUMERIC(25,8)) as buyorderqty,cast(0 as NUMERIC(25,8)) as saleorderqty, cast(0 as NUMERIC(25,8)) as alldaysaleqty,
       0.0000 as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,
		ISNULL(g.TraceCName, '''') AS TraceCName, 
		ISNULL(g.TraceEName, '''') AS TraceEName
       FROM storeLimit a 
        left join (select * from vw_Products p left join 
	             (select * from vw_productbalance  where Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 )c on a.p_id=c.Product_id

        left join
        (select isnull(sum(quantity),0) qty,p_id from storehouse b,storages s  where s.storage_id = b.s_id AND s.class_id like '''+@szPareID+''' and b.Y_id='+cast(@szY_id as varchar(50))+' group by p_id) as b
         on b.p_id=a.p_id

        left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
         where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
         where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id  
        
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@szY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id '

     SET @szsql2='where a.Y_id='+cast(@szY_id as varchar(50))+' and a.upperlimit>0 and c.alert=0 and a.S_id='+cast(@s_id as varchar(50))+' and a.UpperLimit< (isnull(b.qty,0) '+@sqlNoPurchase2+@sqlNoSend2+')'
     exec(@szsql+@szsql2)   
   END    
end
return 0

listLow:
if @s_id=0 
begin
    SET @szsql='update storelimit set adjqty=0 where p_id not  in (select p_id from storelimit a where a.s_id=0 and a.LowLimit>(SELECT isnull(SUM(b.quantity) '+@sqlNoPurchase+@sqlNoSend+ ', 0)
                FROM storehouse b 
                left join
                 (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                  where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
                on bm.p_id=b.p_id
  
                left join
                 (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                 where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
                on SM.p_id=b.p_id 
   
                WHERE b.p_id=a.P_id))'
    /*print @szsql*/
    exec(@szsql)

    SET @szsql='SELECT a.*,c.*,isnull(b.qty,0) qty,isnull(d.buyorderqty,0) as buyorderqty,isnull(e.saleorderqty,0) as saleorderqty,cast(f.daysaleqty as NUMERIC(25,8)) as Alldaysaleqty,
                cast(isnull(f.daysaleqty,0)/'+cast(@daydiff as varchar(50))+' as NUMERIC(25,8)) as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,
		ISNULL(g.TraceCName, '''') AS TraceCName, 
		ISNULL(g.TraceEName, '''') AS TraceEName
                FROM storeLimit a 
	left join (select * from vw_Products p left join 
	             (select * from vw_productbalance  where  Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 )c on a.p_id=c.Product_id

	left join 
        (select isnull(sum(quantity),0) qty,p_id from storehouse b where Y_id='+cast(@szY_id as varchar(50))+' group by p_id) as b
        on b.p_id=a.p_id 

--采购订货数量
	left join 
        (select isnull(sum(b.quantity-b.comeqty),0) buyorderqty,p_id  from orderidx a,orderbill b
         where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=22 group by p_id)as d
         on d.p_id=a.p_id 

--销售订货数量
	left join 
        (select isnull(sum(b.quantity-b.comeqty),0) saleorderqty,p_id from orderidx a,orderbill b
         where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=14 group by p_id)as e 
         on e.p_id=a.p_id 
--日均销量
        left join
        (select isnull(sum(case when b.billtype in (10,12,210) then p.quantity else -p.quantity end),0) daySaleQty,p_id  
           from billidx b,salemanagebill p 
	 where b.billid=p.bill_id and b.billtype in (10,11,12,13,210,211) and b.billstates=''0'' and b.Y_id='+cast(@szY_id as varchar(50))+' 
          and b.billdate between '''+cast(@begindate as varchar(50))+'''and '''+ cast(@enddate as varchar(50)) +''' group by p_id) as f 
         on f.p_id=a.p_id '
/*未到货数量*/
 SET  @szsql2=' left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
         where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
--未发货数量  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
         where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id  
        left join storelimit st on a.slid=st.slid    
        
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@szY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id 
	    
	where a.Y_id='+cast(@szY_id as varchar(50))+' and a.upperlimit>st.lowlimit  and c.alert=0 and a.LowLimit>(isnull(b.qty,0) '+@sqlNoPurchase2+@sqlNoSend2+')'
      /*print (@szsql+@szsql2)*/
    exec(@szsql+@szsql2)

end else
begin
    SET @szsql=' update storelimit set adjqty=0 where p_id not in (select p_id from storelimit a where a.s_id='+cast(@s_id as varchar(50))+' and  ('+cast(@nsa_id as varchar(50))+' = 0 or a.sa_id = '+cast(@nsa_id as varchar(50))+') and LowLimit>(SELECT isnull(SUM(b.quantity), 0) ' +@sqlNoPurchase+@sqlNoSend+'
                 FROM storehouse b  

                 left join
                 (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                  where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
                  on bm.p_id=b.p_id
  
                 left join
                 (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                 where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
                 on SM.p_id=b.p_id

                 WHERE  b.p_id=a.P_id)) '

      /*print @szsql*/
    exec(@szsql)

   SET @szsql='SELECT a.*,c.*,isnull(b.qty,0) qty,isnull(d.buyorderqty,0) as buyorderqty,isnull(e.saleorderqty,0) as saleorderqty,cast(f.daysaleqty as NUMERIC(25,8)) as alldaysaleqty,
              cast(isnull(f.daysaleqty,0)/'+cast(@daydiff as varchar(50))+' as NUMERIC(25,8)) as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY,
		ISNULL(g.TraceCName, '''') AS TraceCName, 
		ISNULL(g.TraceEName, '''') AS TraceEName
              FROM storeLimit a 
	      left join (select * from vw_Products p left join 
	             (select * from vw_productbalance  where  Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 )c on a.p_id=c.Product_id

	left join 
        (select isnull(sum(quantity),0) qty,p_id from storehouse b
        left join location l on l.loc_id = b.location_id and l.s_id = b.s_id
        where b.s_id='+cast(@s_id as varchar(50))+' and b.Y_id='+cast(@szY_id as varchar(50))+' and  ('+cast(@nsa_id as varchar(50))+' = 0 or l.sa_id = '+cast(@nsa_id as varchar(50))+') group by p_id)as b
         on b.p_id=a.p_id 

--采购订货数量
	left join 
        (select isnull(sum(b.quantity-b.comeqty),0) buyorderqty,p_id from orderidx a,orderbill b where a.billstates=''3''
         and a.billid=b.bill_id and a.billtype=22 and a.Y_id='+cast(@szY_id as varchar(50))+'  group by p_id)as d
         on d.p_id=a.p_id 

--销售订货数量
	left join 
        (select isnull(sum(b.quantity-b.comeqty),0) saleorderqty,p_id from orderidx a,orderbill b
         where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+'  and a.billtype=14  group by p_id)as e
         on e.p_id=a.p_id 
--日均销量
        left join
        (select isnull(sum(case when b.billtype in (10,12,210) then p.quantity else -p.quantity end),0) daySaleQty,p_id
           from billidx b,salemanagebill p 
	 where b.billid=p.bill_id and b.billtype in (10,11,12,13,210,211) and b.billstates=''0'' and b.Y_id='+cast(@szY_id as varchar(50))+' 
           and b.billdate between  '''+cast(@begindate as varchar(50))+'''and '''+ cast(@enddate as varchar(50)) +'''
         group by p_id)as f
         on f.p_id=a.p_id '

/*未到货数量*/
SET  @szsql2=' left join
        (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
         where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
         on bm.p_id=a.p_id
--未发货数量  
        left join
        (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
         where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
        on SM.p_id=a.p_id
        left join storelimit st on a.slid=st.slid    
        
        LEFT JOIN
        (SELECT a.p_id, e.name AS TraceEName, c.name AS TraceCName FROM 
	    (SELECT DISTINCT b.p_id, MAX(b.ModifyDate) AS ModifyDate 
	    FROM buypricehis b WHERE b.Y_ID = '+cast(@szY_id as varchar(50))+' GROUP BY b.p_id) a 
	    INNER JOIN buypricehis b ON a.p_id = b.p_id AND a.modifydate = b.ModifyDate
	    INNER JOIN clients c ON b.c_id = c.client_id
	    INNER JOIN employees e ON b.E_id = e.emp_id) g ON g.p_id = a.p_id 

	where a.Y_id='+cast(@szY_id as varchar(50))+' and a.upperlimit>st.lowlimit and c.alert=0 and a.S_id='+cast(@s_id as varchar(50))+' and ('+cast(@nsa_id as varchar(50))+' = 0 or a.sa_id = '+cast(@nsa_id as varchar(50))+') and a.LowLimit>(isnull(b.qty,0) '+@sqlNoPurchase2+@sqlNoSend2+')'
  /*print (@szsql+@szsql2)*/
   exec(@szsql+@szsql2)
end
return 0


 listNoneQuantity:
 if @s_id=0 
 begin
     SET @szsql='update storelimit set adjqty=0 where p_id not  in (select p_id from storelimit a where a.s_id=0 and a.LowLimit>(SELECT isnull(SUM(b.quantity) '+@sqlNoPurchase+@sqlNoSend+ ', 0)
                 FROM storehouse b 
                 left join
                  (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                   where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
                 on bm.p_id=b.p_id
   
                 left join
                  (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                  where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
                 on SM.p_id=b.p_id 
    
                 WHERE b.p_id=a.P_id))'
     /* print @szsql*/
     exec(@szsql)
 
     SET @szsql='SELECT a.p_id,a.s_id,a.upperlimit,a.adjqty,p1.nonequantity as lowlimit,p.*,isnull(b.qty,0) qty,isnull(d.buyorderqty,0) as buyorderqty,isnull(e.saleorderqty,0) as saleorderqty,cast(f.daysaleqty as NUMERIC(25,8)) as alldaysaleqty,
                 cast(isnull(f.daysaleqty,0)/'+cast(@daydiff as varchar(50))+' as NUMERIC(25,8)) as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY
                 FROM (select * from vw_Products p left join 
	             (select * from vw_productbalance  where  Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 ) p
         left join products p1 on p.product_id=p1.product_id
 	left join 
         (select isnull(sum(quantity),0) qty,p_id from storehouse b where Y_id='+cast(@szY_id as varchar(50))+' group by p_id) as b
         on b.p_id=p.product_id 
         left join storelimit a on p.product_id=a.p_id
 --采购订货数量
 	left join 
         (select isnull(sum(b.quantity-b.comeqty),0) buyorderqty,p_id  from orderidx a,orderbill b
          where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=22 group by p_id)as d
          on d.p_id=p.product_id 
 --销售订货数量
 	left join 
         (select isnull(sum(b.quantity-b.comeqty),0) saleorderqty,p_id from orderidx a,orderbill b
          where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=14 group by p_id)as e 
          on e.p_id=p.product_id 
 --日均销量
         left join
         (select isnull(sum(case when b.billtype in (10,12,210) then p.quantity else -p.quantity end),0) daySaleQty,p_id  
            from billidx b,salemanagebill p 
 	 where b.billid=p.bill_id and b.billtype in (10,11,12,13,210,211) and b.billstates=''0'' and b.Y_id='+cast(@szY_id as varchar(50))+' 
           and b.billdate between '''+cast(@begindate as varchar(50))+'''and '''+ cast(@enddate as varchar(50)) +''' group by p_id) as f 
          on f.p_id=p.product_id '
 /*未到货数量*/
  SET  @szsql2=' left join
         (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
          where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
          on bm.p_id=p.product_id
 --未发货数量  
         left join
         (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
          where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)SM
         on SM.p_id=p.product_id      
         where p.nonequantity>(isnull(b.qty,0)) and p.nonequantity>0'
     /*print (@szsql+@szsql2)*/
     exec(@szsql+@szsql2)
 
end else
begin
    SET @szsql=' update storelimit set adjqty=0 where p_id not in (select p_id from storelimit a where a.s_id='+cast(@s_id as varchar(50))+' and LowLimit>(SELECT isnull(SUM(b.quantity), 0) ' +@sqlNoPurchase+@sqlNoSend+'
                 FROM storehouse b  

                 left join
                 (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
                  where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
                  on bm.p_id=b.p_id
  
                 left join
                 (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
                 where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)SM
                 on SM.p_id=b.p_id

                 WHERE  b.p_id=a.P_id)) '

      /*print @szsql*/
    exec(@szsql)
     SET @szsql='SELECT a.p_id,a.s_id,a.upperlimit,a.adjqty,p1.nonequantity as lowlimit,p.*,isnull(b.qty,0) qty,isnull(d.buyorderqty,0) as buyorderqty,isnull(e.saleorderqty,0) as saleorderqty,cast(f.daysaleqty as NUMERIC(25,8)) as Alldaysaleqty,
                 cast(isnull(f.daysaleqty,0)/'+cast(@daydiff as varchar(50))+' as NUMERIC(25,8)) as daysaleqty,isnull(bm.NoPurchaseQTY,0)NoPurchaseQTY,isnull(sm.NoSendQTY,0)NoSendQTY
                 FROM (select * from vw_Products p left join 
	             (select * from vw_productbalance  where  Y_id='+cast(@szY_id as varchar(20))+')pb on p.product_id=pb.p_id
                 ) p
         left join products p1 on p.product_id=p1.product_id
 	left join 
         (select isnull(sum(quantity),0) qty,p_id from storehouse b where Y_id='+cast(@szY_id as varchar(50))+' and s_id='+cast(@s_id as varchar(50))+' group by p_id) as b
         on b.p_id=p.product_id 
         left join storelimit a on p.product_id=a.p_id
 --采购订货数量
 	left join 
         (select isnull(sum(b.quantity-b.comeqty),0) buyorderqty,p_id  from orderidx a,orderbill b
          where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=22 group by p_id)as d
          on d.p_id=p.product_id 
 --销售订货数量
 	left join 
         (select isnull(sum(b.quantity-b.comeqty),0) saleorderqty,p_id from orderidx a,orderbill b
          where a.billstates=''3'' and a.billid=b.bill_id and a.Y_id='+cast(@szY_id as varchar(50))+' and a.billtype=14 group by p_id)as e 
          on e.p_id=p.product_id 
 --日均销量
         left join
         (select isnull(sum(case when b.billtype in (10,12,210) then p.quantity else -p.quantity end),0) daySaleQty,p_id  
            from billidx b,salemanagebill p 
 	 where b.billid=p.bill_id and b.billtype in (10,11,12,13,210,211) and b.billstates=''0'' and b.Y_id='+cast(@szY_id as varchar(50))+' 
           and b.billdate between '''+cast(@begindate as varchar(50))+'''and '''+ cast(@enddate as varchar(50)) +''' group by p_id) as f 
          on f.p_id=p.product_id '
 /*未到货数量*/
  SET  @szsql2=' left join
         (select p_id ,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoPurchaseQTY  from buymanagebill
          where  bill_id In (select billid from billidx where billtype=220 and Y_id='+cast(@szY_id as varchar(50))+' and billstates=0) and thqty>SendQTY Group by p_id)bm
          on bm.p_id=p.product_id
 --未发货数量  
         left join
         (select p_id,ISNULL(SUM(thqty),0)-ISNULL(SUM(SendQTY),0)as NoSendQTY from salemanagebill
          where bill_id IN (select billid from billidx where billtype=210 and Y_id='+cast(@szY_id as varchar(50))+'  and billstates=0) and thqty>SendQTY Group by p_id)SM
         on SM.p_id=p.product_id      
         where a.s_id='+cast(@s_id as varchar(50))+' and p.nonequantity>(isnull(b.qty,0)) and p.nonequantity>0'
     /*print (@szsql+@szsql2)*/
     exec(@szsql+@szsql2)
 
end
return 0
GO
