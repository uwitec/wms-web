/* 功能：近效期禁销禁采商品一览表 add by zfl 2014-12-05*/

CREATE PROCEDURE TS_z_RepForbidSaleBuy
( 
  @BillType integer, /*单据类型*/
  @nPid integer=0, /*商品id*/
  @storehouse_id integer=0 /*批次*/
)
AS
BEGIN
  declare @day integer
  select @day=[Day] from StopSaleDay where billtype = @BillType

  select s.storehouse_id,p.name as pname, p.serial_number as pcode, s.batchno, convert(varchar(10),s.makedate,20) as makedate, 
         convert(varchar(10),s.validdate,20) as validdate, s.quantity as sqty,  
         Case isnull(cf.storehouse_id,0) when 0 then '是' else '否' end as islock, 
         isnull(o.quantity,0) as billqty, sg.name as kname, l.loc_name as lname,s.p_id AS Product_id,p.name 
  from storehouse  s 
    left join products p on p.product_id = s.p_id
    LEFT JOIN (select * from dbo.fn_getavlqty(0, 0, '', 1)) o 
		ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id 
			and o.validdate=s.validdate and o.makedate=s.makedate
			AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
			AND O.s_id = S.s_id
    left join storages sg on s.s_id=sg.storage_id 
    left join location l on s.location_id=l.loc_id
    left join clearForbidSaleBuy cf on s.storehouse_id=cf.storehouse_id and cf.billtype = @BillType 
  where s.validdate < dateadd(day,@day,convert(varchar(10),getdate(),20)) 
    and s.validdate >= convert(varchar(10),getdate(),20)
    and ((s.p_id = @nPid) or (@nPid=0)) 
    and ((s.storehouse_id = @storehouse_id) or (@storehouse_id=0)) 
  /*hy：效期是6号 提前一天禁止就是5号可以开单，6号不能开单*/
END
GO
