
CREATE  PROCEDURE ts_c_AuditP 
(
	@nBillId int,
	@nP_idOut int output,
	@nReturnNumber int output,
	@nMode smallint=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
/*Params Ini end*/
/*-----Costing method------------*/
	declare @AVERAGE smallint
	declare @FIFO    smallint
	declare @LIFO    smallint
	declare @HAND    smallint

	select @AVERAGE=0
	select @FIFO   =1
	select @LIFO   =2
	select @HAND   =3
/*-------------------*/
	declare @nP_id int,@nS_id int,@nL_id int,@dQuantity NUMERIC(25,8),@dPrice NUMERIC(25,8),@dTotal NUMERIC(25,8),@dStoretype tinyint,@szBatchno varchar(20),@nStoretype int,@tBilldate datetime,
	@nC_id int ,@nA_id int ,@nE_id int,@nCostType int,@nPriceId int,@szPeriod varchar(2),@nSupplier_id int,@nCommissionflag int,@dCostTotalOut NUMERIC(25,8),@dTaxTotalOut NUMERIC(25,8),@nBillType int,@nUnitid int,@nOrderId numeric(10,0)
	declare @tMakeDate datetime,@tValidDate datetime,@tMakeDateTemp datetime,@tValidDateTemp datetime,@dQtyIn NUMERIC(25,8),@dCostTotalIn NUMERIC(25,8),@dCostPriceIn NUMERIC(25,8),
	@dTemp NUMERIC(25,8),@nCostMethod int,@dPricetemp NUMERIC(25,8)
	declare @cUseSameCostMethod char(1),@cUseSalePriceTrace char(1),@cUseBuyPriceTrace char(1),@smb_id numeric(10,0)
	declare @dYsmoney NUMERIC(25,8),@dSsMoney NUMERIC(25,8), @dTaxPrice NUMERIC(25,8), @nPriceTrace INT
	declare @vchtype int,@lastprice NUMERIC(25,8)
    	declare @tInStoreTime datetime
	declare @y_id int
	declare @batchbarcode varchar(80),@scomment varchar(80),@batchprice NUMERIC(25,8),@factoryid int,@taxprice NUMERIC(25,8),@taxtotal NUMERIC(25,8),@taxrate NUMERIC(25,8)
	declare @costtaxprice NUMERIC(25,8),@costtaxrate NUMERIC(25,8),@costtaxtotal NUMERIC(25,8) /*成本含税单价，成本含税税率，成本含税金额*/
	declare @nNoBatch bit
	declare @bForceBuyOrder bit
  
  declare @oldcommissionflag int/*解决商品属性导致不能退货的问题 zc 2005-07*/
  declare @cRetailNoBatchno char(1)
	declare @aoid int	/*辅助业务标志*/
	declare @nTracePriceAdjust int /* 价格是否跟踪结算调价*/
	
	DECLARE @nStandardGspProcess int	/* 是否启用GSP标准流程*/
	SET @nStandardGspProcess = 0
	SELECT @nStandardGspProcess = sysvalue FROM sysconfigtmp WHERE sysname = 'GspStandardProcess'

	set @nNoBatch = 0
	set @vchtype=0
  set @cRetailNoBatchno='0'
	select @vchtype=billtype,@tBilldate=billdate, @y_id=Y_ID from billidx where billid=@nBillid	
	if @vchtype = 50	/* 得到盘点单是否按批次盘点*/
	begin
		select @nNoBatch = nobatch from pdplanidx where pdidx = (select order_id from billidx where billid=@nBillid)
	end
  /*--------得到成本核算法*/
	exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
	if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
		exec ts_getsysvalue 'CostMethod',@nCostMethod out
	/*--------是否使用销价跟踪*/
	exec ts_getsysvalue 'UseBuyTrace',@cUseBuyPriceTrace out 
	exec ts_getsysvalue 'UseSaleTrace',@cUseSalePriceTrace out 

	if (@cUseBuyPriceTrace=1) or(@cUseSalePriceTrace=1) exec ts_getsysvalue 'PriceTrace',@nPriceTrace out 
	/*--------是否使用进价跟踪*/
	
	/* 强制控制采购合同*/
	exec ts_getsysvalue 'ForceBuyOrder', @bForceBuyOrder out


  /*零售不管理批次*/
	exec ts_getsysvalue 'RetailNoBatchno',@cRetailNoBatchno out

	exec ts_GetSystmpValue 'TracePriceAdjust', 0, @nTracePriceAdjust out

	select @nReturnNumber=-1
			
	declare pdetail_cursor cursor local scroll scroll_locks  for
	select p.p_id,p.s_id,p.quantity,p.costprice,p.costtotal,p.storetype,p.batchno,p.supplier_id,p.unitid,p.makedate,p.validdate,p.commissionflag,p.location_id,p.unitid,p.price,p.order_id,p.smb_id,
	b.c_id,b.a_id,p.Rowe_id,b.billtype, p.TaxPrice,p.oldcommissionflag,p.aoid,InStoreTime,p.y_id,
	p.batchbarcode,p.scomment,p.batchprice,p.factoryid,p.costtaxprice,p.costtaxtotal,p.costtaxrate
	from productdetailtmp p,billidx b where b.billid=@nBillId and p.billid=b.billid
	order by p.pd_id
	for update
	open pdetail_cursor

	fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
	@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id,
	@batchbarcode ,@scomment ,@batchprice,@factoryid,@costtaxprice,@costtaxtotal,@costtaxrate 
	while @@FETCH_STATUS=0
	begin
    if @nStoreType<>3
    begin
		if @cUseSameCostMethod='0' /*系统不使用统一成本核算，得到该商品成本算法*/
			set @nCostMethod=dbo.GetcostNo(@nP_id)
		if @nS_id=0 and @nbilltype not in (30,31,32,33,34,35)
		begin
			if @dPrice = 0
			  begin
				set @nReturnnumber=-17    /*单价为空的时候，不能过账*/
				goto error		  
			  end  
			  else
			  begin
				set @nReturnnumber=-10
				goto error
			  end
		end
		/*if @nBilltype=12 and @cRetailNoBatchno='1'*/
		/*begin*/
		/*	set @dCosttotalIn=0*/
		/*	set @nCostMethod=4*/
		/*end*/
		/* 盘点不管批次则改成本核算为先进先出*/
		if @nBillType = 50 and @nNoBatch = 1
		begin
			set @nCostMethod = 4
		end
		exec ts_c_ModifyP @nBillType,@nCostMethod,@nP_id,@nS_id,@nL_id output,@nStoreType,@nUnitId,@szBatchNo,'',@dQtyIn,@dCostTotalIn,
		@dCostPriceIn output,@tMakeDate output,@tValidDate output,@nSupplier_id output,@nCommissionflag output,@dCostTotalOut output,@nReturnNumber output,@nBillId,@OldCommissionflag,@tInStoreTime output,@y_id,@batchbarcode ,@scomment ,@batchprice,@factoryid,@costtaxprice,@costtaxtotal,@costtaxrate,
		@dTaxTotalOut output
		if @@error<>0 goto error
		if @nReturnNumber<>0 goto error
		if @nMode=0
		begin
			if @nCostMethod in ('1','2','3','4') and @dQtyIn<0 select @dCostTotalOut=-@dCostTotalOut
			if @nCostMethod in ('0','1','2','4') 
/*			select @dPricetemp=abs(@dCostTotalOut/@dQtyIn) 2004-07-19曾川改负库存问题*/
			  select @dPricetemp=@dCostTotalOut/@dQtyIn
			else
			begin	
				if @dCostPriceIn<>0 
					select @dPricetemp=@dCostPriceIn
				else
					select @dPricetemp=abs(@dCostTotalOut/@dQtyIn)
			end

/*			select @dTemp=abs(@dCostTotalOut),@tMakeDateTemp=@tMakeDate,@tValidDateTemp=@tValidDate 2004-07-19曾川改负库存问题*/
			select @dTemp=@dCostTotalOut,@tMakeDateTemp=@tMakeDate,@tValidDateTemp=@tValidDate /*2004-07-19曾川改负库存问题*/
			update productdetailtmp 
			set costprice=@dPricetemp,costtotal=@dCostTotalOut,makedate=@tMakeDate,validdate=@tValidDate,commissionflag=@nCommissionflag,
				supplier_id=@nSupplier_id,Instoretime=@tInstoretime ,SendCostTotal=SendQTY*@dPricetemp,location_id=@nL_id,Factoryid=@factoryid	
			where current of pdetail_cursor
			if @smb_id>0 
			begin
				exec @nReturnNumber=ts_c_modifycostprice @nBillType,@smb_id,@dPricetemp
  				if @nReturnNumber<>0 goto error
			end

			if (@nBillType=44)        /*如果是同价调拨单 成本价=单价*/
			begin
				update productdetailtmp set price=@dPricetemp,total=@dCostTotalOut where current of pdetail_cursor
			end

		  if @aoid=0	/*正常业务价格才跟踪*/
		  begin
			if @nBillType in (20,222,122) /*修改最近进价*/
			begin
            select @lastprice=0  
            select @lastprice=recprice from price 
            where p_id=@nP_Id and u_id=@nunitid
            if @nPriceTrace =0 and @lastprice<>@dPrice /*如果进价不发生变化则不更新进价*/
            begin  /*单价*/
    					update price set recprice=@dPrice,lastprice=@lastprice,lasttime=convert(varchar(10),getdate(),21),billid=@nbillid
  	  				where p_id=@nP_Id and u_id=@nunitid
            end else
            if @nPriceTrace =1 and @lastprice<>@dPrice 
            begin  /*单价*/
    					update price set recprice=@dPrice,lastprice=@lastprice,lasttime=convert(varchar(10),getdate(),21),billid=@nbillid
  	  				where p_id=@nP_Id and u_id=@nunitid            
            end else
            if @nPriceTrace =2 and @lastprice<>@dTaxPrice 
            begin  /*税率、税后单价*/
    					update price set recprice=@dTaxPrice,lastprice=@lastprice,lasttime=convert(varchar(10),getdate(),21),billid=@nbillid
  	  				where p_id=@nP_Id and u_id=@nunitid            
            end else
            begin
              update price set lasttime=convert(varchar(10),getdate(),21),billid=@nbillid
  	  				where p_id=@nP_Id and u_id=@nunitid
            end
  			end
  				if ((@nBillType in (10,210,231,112,53)) and  @cUseSalePriceTrace=1)
					or (@nTracePriceAdjust = 1 and @nBillType in (16))
  				begin
  					/*if @nPriceTrace =0*/
  					exec ts_c_SaleBuyPriceTrace 'S',@smb_id
  					/*else*/
  					/*if @nPriceTrace =2*/
  					/*exec ts_c_SaleBuyPriceTrace 'S',@nC_id,@nP_id,@nUnitid,@dTaxPrice,@dQtyIn,@nE_id,@y_id*/
  				end
  				if (@nBillType in (45)) and  @cUseSalePriceTrace=1 and @dQtyIn>0 /*变价调拨跟踪调拨价格*/
  				begin
            exec ts_c_SaleBuyPriceTrace 'C',@smb_id
  				end
  				if (@nBillType in (20,220,241,122)) and  @cUseBuyPriceTrace=1
  				begin
  					/*if @nPriceTrace =0*/
  					exec ts_c_SaleBuyPriceTrace 'B',@smb_id
  					/*else*/
  					/*if @nPriceTrace =2*/
  					/*exec ts_c_SaleBuyPriceTrace 'B',@nC_id,@nP_id,@nUnitid,@dTaxPrice,@dQtyIn,@nE_id,@y_id*/
  				end
        end
				if @nBillType in (20,222,48,42,11,120,44,45,51,55,160,150,152,162) and @dQtyin>0 and @nStoreType=0  exec ts_c_LocationTrace @nP_id,@nS_id,@nL_id,@tBilldate,@nBillType, @y_id


                if @nBillType in (20) and @bForceBuyOrder = 1 AND @nStandardGspProcess = 0
				begin
					if exists (select 0 from OrderBill where smb_id = @nOrderId and ComeQty + abs(@dQtyin) > quantity)
					begin
						set @nReturnNumber = -40
						goto error
					end
				end
				if @nBillType in (10,20,212,222) and @nOrderid > 0
				BEGIN
					IF @nBillType <> 20 OR @nStandardGspProcess = 0
						update orderbill set comeqty=comeqty+abs(@dQtyin),comedate=@tBilldate where smb_id=@nOrderid
				END
				if @nBillType in (150, 152) and @nOrderId > 0 and @nStandardGspProcess = 1
				begin
					update orderbill set ComeQty = ComeQty + abs(@dQtyin), comedate=@tBilldate where smb_id=@nOrderid
					declare @nTranId int
					select @nTranId = orgbillid from OrderBill where smb_id = @nOrderId
					if @nTranId > 0
						update TranBill set /*ComeQty = ComeQty + abs(@dQtyin),*/ comedate=@tBilldate where smb_id=@nTranId 
						/*这儿直接移到配送订单审核就写会完成数量*/
				end
				
				if @nBillType IN (10)
				begin
				  declare @oosQty NUMERIC(25,8)
				  select @oosQty = SUM(oosqty)  from OOSCatalog 
				   where Inflag <> 2 and OutDisposeflag = 0 and ProductId = @nP_id and ClientId = @nC_id 				    
				  if   @dQuantity >= @oosQty
				    update OOSCatalog set Inflag = 1, OutDisposeflag = 2, OutDisposeDate =GETDATE(), OutDisposeMan = @nE_id, SaleBillType = 10				  
				      where Inflag <> 2 and OutDisposeflag = 0 and ProductId = @nP_id and ClientId = @nC_id
				   else
				     update OOSCatalog set Inflag = 1, OutDisposeflag = 1, OutDisposeDate =GETDATE(), OutDisposeMan = @nE_id, SaleBillType = 10				  
				       where Inflag <> 2 and OutDisposeflag = 0 and ProductId = @nP_id and ClientId = @nC_id  				       				   
				end	 
				if @nBillType IN (20)
				begin
				  update OOSCatalog set InStoreDate = GETDATE()
				   where Inflag = 1 and InDisposeflag = 1 and ProductId = @nP_id and PlanQty <> 0 and InStoreDate < 10
				end	 
													 
				if @nBillType in (150,152,44,45) and @nOrderid>0 and @nStandardGspProcess = 0
					 update tranbill set comeqty=comeqty+abs(@dQtyin),comedate=@tBilldate where smb_id=@nOrderid

				if @nBilltype in (11,13,111,21,121,54,56,151,161,153,163)/*处理退货*/
				begin
					exec ts_c_ProcessTh @nBilltype,@smb_id,@nMode,@nReturnNumber out
					if @nReturnNumber<>0 or @@error<>0 goto error
				end

				fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
				@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id,@batchbarcode ,@scomment ,@batchprice,@factoryid,@costtaxprice,@costtaxtotal,@costtaxrate 

				if (@nBillType in(44,110,111,30,31)) and @dQtyIn>0
				begin
					select @dCostTotalIn=-@dTemp,@tMakeDate=@tMakeDateTemp,@tValidDate=@tValidDateTemp
				end
				if (@nBillType in(43,45)) and @dQtyIn>0
				begin
					select @tMakeDate=@tMakeDateTemp,@tValidDate=@tValidDateTemp
				end
				if (@nBillType in(51)) and @dQtyIn>0
				begin
					select @dCostTotalIn=-@dTemp
				end
			end 
			else
			begin
				if @nBilltype in (11,13,111,21,121,54,56,151,161,153,163)/*处理退货*/
				begin
					exec ts_c_ProcessTh @nBilltype,@smb_id,@nMode,@nReturnNumber out
					if @nReturnNumber<>0 or @@error<>0 goto error
				end

				if @nBillType in (10,20,212,222) and @nOrderid > 0
				BEGIN
					IF @nBillType <> 20 OR @nStandardGspProcess = 0
						update orderbill set comeqty = comeqty - abs(@dQtyin),comedate=@tBilldate where smb_id=@nOrderid
				END
				if @nBillType in (150,152) and @nOrderid>0 
				begin
					if @nStandardGspProcess = 0
						update tranbill set comeqty = comeqty-abs(@dQtyin),comedate=@tBilldate where smb_id=@nOrderid
					else
					begin
						update orderbill set ComeQty = ComeQty - abs(@dQtyin), comedate=@tBilldate where smb_id=@nOrderid
						select @nTranId = orgbillid from OrderBill where smb_id = @nOrderId
						if @nTranId > 0
							update TranBill set ComeQty = ComeQty - abs(@dQtyin), comedate= @tBilldate where smb_id=@nTranId
					end
				end


				fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
				@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id,@batchbarcode ,@scomment ,@batchprice,@factoryid,@costtaxprice,@costtaxtotal,@costtaxrate 
			end
		end else if @nStoreType=3/*零成本出入库*/
		begin
  				exec ts_y_ModifyPForNoCost @nP_id,@nS_id,@dQtyIn,@nReturnNumber output,@nBillType,@y_id
  				if @@error<>0 goto error
  				if @nReturnNumber<>0 goto error
				/*处理自营店发货单过账没有更新机构配送订单的状态问题*/
				if @nBillType in (150, 152) and @nOrderId > 0 and @nStandardGspProcess = 1
				begin
						update orderbill set ComeQty = ComeQty + abs(@dQtyin), comedate=@tBilldate where smb_id=@nOrderid
						declare @nTranIdd int
						select @nTranIdd = orgbillid from OrderBill where smb_id = @nOrderId
						if @nTranId > 0
							update TranBill set /*ComeQty = ComeQty + abs(@dQtyin),*/ comedate=@tBilldate where smb_id=@nTranIdd 
							/*这儿直接移到配送订单审核就写会完成数量*/
				end
				/*zjx--2017-06-14--tfs48566--处理销售订单/采购订单.做零成本赠品，销售出库单/采购入库单数量全部过帐后，订单还是已审核未完成的状态*/
				IF @nBillType in (10,20)  and @nOrderid>0
				begin
						update orderbill set comeqty=comeqty+abs(@dQtyin),comedate=@tBilldate where smb_id=@nOrderid
			    end
					fetch next from pdetail_cursor into @nP_id,@nS_id,@dQtyIn,@dCostpriceIn,@dCostTotalIn,@nStoretype,@szBatchno,@nSupplier_id,@nUnitId,@tMakeDate,@tValidDate,@nCommissionflag,@nL_Id,@nunitid,@dPrice,@nOrderid,@smb_id,
					@nC_id,@nA_id,@nE_id,@nBillType, @dTaxPrice,@oldcommissionflag,@aoid,@tInStoreTime,@y_id,@batchbarcode ,@scomment ,@batchprice,@factoryid,@costtaxprice,@costtaxtotal,@costtaxrate 
		end
	end

	if @vchtype in (16,17,24,25)/*处理退货*/
	begin
		exec ts_c_ProcessTh @vchtype,@nBillId,@nMode,@nReturnNumber out
		if @nReturnNumber<>0 or @@error<>0 goto error
	end

	/*mixb 处理退货,收货:*/
	if @vchtype in (221,222)
	begin
		declare BMB_cursor cursor local scroll scroll_locks  for
		select S.smb_id,b.billtype
		from BuyManageBill S,billidx b where  b.billid=@nBillId and S.bill_id=b.billid
		order by S.smb_id
		for update
		open BMB_cursor

		fetch next from BMB_cursor into @smb_id,@nBillType
		while @@FETCH_STATUS=0
		begin
			exec ts_c_ProcessTh @nBilltype,@smb_id,@nMode,@nReturnNumber out
			if @nReturnNumber<>0 or @@error<>0 goto error
			fetch next from BMB_cursor into @smb_id,@nBillType
			end

      		Close BMB_cursor
			deallocate BMB_cursor
	end
/*-----------------------*/
	/*mixb 处理退货,发货:*/
	if @vchtype in (211,212)
	begin
		declare SMB_cursor cursor local scroll scroll_locks  for
		select S.smb_id,b.billtype
		from SaleManageBill S,billidx b where  b.billid=@nBillId and S.bill_id=b.billid
		order by S.smb_id
		for update
		open SMB_cursor

		fetch next from SMB_cursor into @smb_id,@nBillType
		while @@FETCH_STATUS=0
		begin
			exec ts_c_ProcessTh @nBilltype,@smb_id,@nMode,@nReturnNumber out
			if @nReturnNumber<>0 or @@error<>0 goto error
			fetch next from SMB_cursor into @smb_id,@nBillType
			end

      		Close SMB_cursor
			deallocate SMB_cursor
	end
	/*-----------------------*/
	
	/*搬移库存明细*/
	insert into productdetail
		(	[billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],[price_id],unitid,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice, order_id,factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal)			
	select	[billid],[p_id],[s_id],[quantity],[price],[total],[costprice],[costtotal],[taxprice],[taxtotal],[batchno],[makedate],[validdate],[commissionflag],[supplier_id],[location_id],[storetype],[price_id],unitid,smb_id,comment,jsprice,aoid, RowGuid, RowE_id,SendQTY, SendCostTotal, retailtotal, y_id, InStoreTime, thQty, cxType, retailprice,batchbarcode,scomment,batchprice, order_id,factoryid,taxrate,costtaxprice,costtaxrate,costtaxtotal
	from productdetailtmp
	where billid=@nBillId
	
	if @@ERROR<>0 goto error

/*yypeng-2017-03-16 09:56:15- 这样检测影响过账速度*/
	IF EXISTS(SELECT * FROM productdetailtmp WHERE BILLID = @nBillId) AND (NOT EXISTS(SELECT 1 FROM productdetail WHERE BILLID = @nBillId))
			GOTO ERROR

	Close pdetail_cursor
	deallocate pdetail_cursor
	select @nReturnNumber=0
	select @nP_idOut=0
	return 0



error:
	Close pdetail_cursor
	deallocate pdetail_cursor
	select @nP_IdOut=@nP_id
	return @nReturnNumber
GO
