

CREATE PROCEDURE TS_L_OutOfCheck
(
  @szbegindate varchar(50),
  @szenddate  varchar(50),
  @nFlag int = 0,   /*标示 0 正常单据，1 草稿单据*/
  @nS_id int = 0,
  @nC_id int = 0,
  @nY_id int = 0,
  @nloginEID int = 0 
)
AS 
begin
  
/*------初始化授权信息*/
declare @Storetable int
create table #storagestable([id] int)
/*------初始化授权信息*/




/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

  declare @IsDraft int
  declare @nbillstates int 
  if @nFlag = 0
  begin  
    set @IsDraft = 0
    set @nbillstates = 0 
    select * from vw_c_billidx where 
   billdate>=@szbegindate and billdate<=@szenddate and billstates=@nbillstates  
   and billtype in (10,21,53,44,45,49,110,121,212,150,152,161,163) 
   and billid not in (select distinct billid from checkidx where IsDraft = @IsDraft) 
   and (@nC_id = 0 or c_id = @nC_id)
   and (@nS_id = 0 or sout_id = @nS_id)
   and (@nY_id = 0 or Y_ID = @nY_id)
   and (@Storetable = 0 or exists(select 1 from #storagestable where id = sout_id))  
    
    
  end
  if @nFlag = 1
  begin  
    set @IsDraft = 1
    set @nbillstates = 3
    select * from vw_c_billdraftidx where 
   billdate>=@szbegindate and billdate<=@szenddate and billstates=@nbillstates  
   and billtype in (10,21,53,44,45,49,110,121,212,150,152,161,163) 
   and billid not in (select distinct billid from checkidx where IsDraft = @IsDraft) 
   and (@nC_id = 0 or c_id = @nC_id)
   and (@nS_id = 0 or sout_id = @nS_id)
   and (@nY_id = 0 or Y_ID = @nY_id)
   and (@Storetable = 0 or exists(select 1 from #storagestable where id = sout_id))  
  end  
  
  

   
end
GO
