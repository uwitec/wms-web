/***************************************************
会员消费明细，txy，2008－12－04
****************************************************/
CREATE PROCEDURE [TS_L_qrVIPBuyProDetail]
( 
  @BeginDate   varchar(30)='',
  @EndDate     varchar(30)='',
  @begintime   varchar(30)='',
  @endtime     varchar(30)='',
  @CardID      int=0,
  @cardtype    int=0,
  @YID       int=0,
  @E_ID        int=0,
  @szPClass_ID varchar(250)=''

)
 AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @begintime is null  SET @begintime = ''
if @endtime is null  SET @endtime = ''
if @CardID is null  SET @CardID = 0
if @cardtype is null  SET @cardtype = 0
if @YID is null  SET @YID = 0
if @E_ID is null  SET @E_ID = 0
if @szPClass_ID is null  SET @szPClass_ID = ''
/*Params Ini end*/
select idx.billdate,     idx.billnumber,        idx.billtype,     idx.Y_ID,  idx.billstates,
       idx.note,         e1.name as e_id ,      e2.name  as IdxInputman,     VI.VIPCardID,     
       VI.CardNo,        VI.Name,                VI.Sex,           VI.Address,        
       VI.Comment,       VI.IniMoney,
       VI.TotalBuyMoney, VI.SaveMoney,          VI.IntergralYE,   VI.IniIntergral,
       VI.RemainderMoney,VI.Tel,VI.BuyCount AS VIPSaleCS,
       (select name from VIPCardType where ct_id=VI.CT_ID) as CardTypeName,
       P.name as Pname,  P.serial_number as PCode,
       P.Alias,          P.Engname,             P.PermitCode,     P.modal,
       P.Inputman,       P.Inputdate,           P.Custompro1,     p.Custompro2,
       P.Custompro3,     p.Custompro4,          P.Custompro5,
       P.MakeArea,       p.standard,isnull(p.comment,'') as comments,isnull(f.AccountComment,'') as factoryname,
       SM.bill_id,SM.p_id,SM.batchno,       
       SM.loc_code,
       SM.locationName,
       SM.storage_code,
       SM.StoragesName,
       SM.supplier_code,
       SM.SupplierName,
       SM.makedate,
       SM.validdate,
       SM.commissionflag,
       isnull(UsedVipTotal,0) as UsedVipTotal,                
       case when idx.billtype in (12) then sm.quantity else -sm.quantity end as quantity,
      (case when (idx.billtype in(12)) then  SM.taxtotal else -SM.taxtotal end) as Totalmoney,
       case when idx.billtype in (12) then SM.costtaxprice else -sm.costtaxprice end as costprice,
       case when idx.billtype in (12) then SM.SalePrice else -sm.saleprice end as saleprice,      
       case when (idx.billtype in (12)) then  SM.taxprice else -SM.taxprice end  as  DiscountPrice,
       discount, 
      (case when (idx.billtype in(12)) then (SM.costtaxprice*SM.quantity) else -(SM.costtaxprice*SM.quantity) end) as CostTotal,
      (case when (idx.billtype in(12)) then (SM.taxtotal-(SM.costtaxprice*SM.quantity)) else -(SM.taxtotal-(SM.costtaxprice*SM.quantity)) end) as LrTotal,
       (select name from Company  where Company_ID=idx.Y_ID) as YName,
        p.unitname as unitName,
       (case when (SM.taxtotal-(SM.costtaxprice*SM.quantity))<>0 and SM.taxtotal<>0 and idx.billtype in (12) then round((SM.taxtotal-(SM.costtaxprice*SM.quantity))/SM.taxtotal*100,4)
             when (SM.taxtotal-(SM.costtaxprice*SM.quantity))<>0 and SM.taxtotal<>0 and idx.billtype in (13) then round ((SM.taxtotal-(SM.costtaxprice*SM.quantity))/(-SM.taxtotal)*100,4) else 0 end) as LrRate,
       (select jdmoney from VW_X_Adetail where AClass_ID like '000004000003000004%' and billid=idx.billid) as zrTotal
from billidx idx
left join VIPCard VI         on idx.Vipcardid=VI.VIPCardID
left join  (
             select bill_id,p_id,quantity,Costprice,saleprice,discount,discountprice,batchno,
                    
               loc_code=(select isnull(Loc_code,'') from Location l where location_id=l.loc_id),
		    locationName=(select IsNull(Loc_Name,'') from location l where location_id=l.loc_id),
		    storage_code=(select isnull(serial_number,'') from storages s where ss_id=s.storage_id),
		    StoragesName=(select IsNull(Name,'') from storages s where ss_id=s.storage_id),
		    supplier_code=(select IsNull(serial_number,'') from clients c where supplier_id=c.client_id),
		    SupplierName=(select IsNull(Name,'') from clients c where supplier_id=c.client_id),
		    makedate,
		    validdate,
		    commissionflag,        
            case when aoid=0 then totalmoney else 0 end as totalmoney,
            taxprice,costtaxprice,    case when aoid=0 then taxtotal else 0 end as taxtotal,
            taxmoney,   retailprice,  retailtotal,ss_id,unitid,RowE_id,
            case when aoid=0 then total else 0 end as total
             from salemanagebill 
             where (@Yid=0 or Y_id=@Yid) and bill_id in (select billid from billidx where billtype in (12,13) and billdate between @BeginDate  and @EndDate and CONVERT(varchar(100), RetailDate, 24) between @begintime and @endtime ) 
               and p_id>0
                 )  SM  on SM.bill_id=idx.billid
left join (select p.*,u.name as unitname from products p,unit u where p.unit1_id=u.unit_id) P on P.Product_id=SM.P_ID
left join basefactory f on p.factoryc_id=f.CommID
left join employees e1 on sm.RowE_id= e1.emp_id 
left join employees e2 on idx.inputman = e2.emp_id
left join 
        ( select VipUseTotal.bill_id,total as UsedVipTotal,p_id from
		(
		   select bill_id,sum(isnull(taxtotal,0)) as total  from  salemanagebill s 
						    where p_id = -64 group by bill_id
		) VipUseTotal,
		(
		  select bill_id,min(p_id) as p_id from salemanagebill
		                                 where p_id>0 group by bill_id
		)MinP_id  where VipUseTotal.bill_id = MinP_id.bill_id
        )UsedVip on (idx.billid=UsedVip.bill_id and p.product_id=UsedVip.p_id)

where idx.billdate between @BeginDate and @EndDate and billstates=0 and 
      CONVERT(varchar(100), idx.RetailDate, 24) between @begintime and @endtime and
      idx.billtype in(12,13)  and  vi.CardNo<>'' and 
     (VI.ct_id=@cardtype or @cardtype=0) and
      SM.P_ID in     (select product_id from products 
                      where left(Class_id,len(@szPClass_ID))=@szPClass_ID) and
      idx.Vipcardid<>0  and
     (idx.e_id=@E_ID or @E_ID=0) and
     (idx.Y_ID=@YID or @YID=0)  and
     (idx.Vipcardid=@CardID or @CardID=0)
union  all
  select VP.billdate,     VP.billnumber,        VP.billtype,     VP.Y_ID,  '0' as billstates,
       '' as note,        '' as e_id ,          '' as IdxInputman ,   VI.VIPCardID,      
       VI.CardNo,        VI.Name,   VI.Sex,           VI.Address,    VI.Comment,     VI.IniMoney,
       VI.TotalBuyMoney, VI.SaveMoney,          VI.IntergralYE,   VI.IniIntergral,
       VI.RemainderMoney,VI.Tel,VI.BuyCount AS VIPSaleCS,
       (select name from VIPCardType where ct_id=VI.CT_ID) as CardTypeName,
       P.name as Pname,  P.serial_number as PCode,
       P.Alias,          P.Engname,             P.PermitCode,     P.modal,
       P.Inputman,       P.Inputdate,           P.Custompro1,     p.Custompro2,
       P.Custompro3,     p.Custompro4,          P.Custompro5,
       P.MakeArea,       p.standard,isnull(p.comment,'') as comments,isnull(f.AccountComment,'') as factoryname,
       Vp.Billid as Bill_id,VP.p_id,'' as batchno,                
       '' as loc_code,
       '' as locationName,
       '' as storage_code,
       '' as StoragesName,
       '' as supplier_code,
       '' as SupplierName,
       '' as makedate,
       '' as validdate,
       '' as commissionflag,
       0  as UsedVipTotal,                 
	    case when VP.billtype in (12) then cast(VP.quantity AS [numeric](18, 4)) else -cast(VP.quantity AS [numeric](18, 4)) end as quantity,
	   (case when (VP.billtype in(12)) then  cast((VP.Quantity*VP.price) as [numeric](18, 4)) else -cast((VP.Quantity*VP.price) as [numeric](18, 4)) end) as Totalmoney,
	   (case when (billtype in (12) and VP.Quantity<>0) then cast((VP.costtotal/VP.Quantity) as NUMERIC(25,8)) else -cast((VP.costtotal/VP.Quantity) as NUMERIC(25,8)) end) as costprice,
		case when VP.billtype in (12) then VP.Price else -VP.price end as saleprice,      
		case when (VP.billtype in (12) and VP.Quantity<>0)  then  cast((VP.discounttotal/VP.Quantity) as NUMERIC(25,8)) else -cast((VP.discounttotal/VP.Quantity) as NUMERIC(25,8)) end  as  DiscountPrice,
		1 as discount, 
	   (case when (VP.billtype in(12)) then cast(VP.costtotal as NUMERIC(25,8)) else -cast(VP.costtotal as NUMERIC(25,8)) end) as CostTotal,
	   (case when (VP.billtype in(12)) then cast(((VP.Quantity*VP.price)-VP.costtotal) as NUMERIC(25,8)) else -cast(((VP.Quantity*VP.price)-VP.costtotal) as NUMERIC(25,8)) end)  as LrTotal,
	   (select name from Company  where Company_ID=VP.Y_ID) as YName,
		p.unitname as unitName,
		(case when ((VP.Quantity*VP.price)-VP.costtotal)<>0 and (VP.Quantity*VP.price)<>0 and  VP.billtype in (12) then round(cast(((VP.Quantity*VP.price)-VP.costtotal)/(VP.Quantity*VP.price)*100 as NUMERIC(25,8)),4)
		 when ((VP.Quantity*VP.price)-VP.costtotal)<>0  and (VP.Quantity*VP.price)<>0 and VP.billtype in (13) then round (cast(((VP.Quantity*VP.price)-VP.costtotal)/(-(VP.Quantity*VP.price))*100 AS NUMERIC(25,8)),4)  else 0 end) as LrRate,
		(select jdmoney from VW_X_Adetail where AClass_ID like '000004000003000004%' and billid=VP.billid) as zrTotal
from VipDetail VP
left join VIPCard VI         on VP.cardid=VI.VIPCardID
left join (select p.*,u.name as unitname from products p,unit u where p.unit1_id=u.unit_id) P on P.Product_id=VP.P_ID
left join basefactory f on p.factoryc_id=f.CommID
where VP.billdate between @BeginDate and @EndDate  and
      CONVERT(varchar(100), VP.billdate , 24) between @begintime and @endtime  and
      VP.billtype in(12,13)  and  vi.CardNo<>''  and 
     (VI.ct_id=@cardtype or @cardtype=0) and
      VP.P_id in  (select product_id from products 
                      where left(Class_id,len(@szPClass_ID))=@szPClass_ID) and
      VP.cardid<>0  and
     (VP.e_id=@E_ID or @E_ID=0) and
     (VP.Y_ID=@YID or @YID=0)  and
     (VP.cardid=@CardID or @CardID=0)
GO
