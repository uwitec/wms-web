




/*
--------Return values--------
	 0: 成功
	-1: 负库存
	-2:
	-3: 数量为零
	-4: 期初不能修改
	-5: 无成本价
  -6: 异常错误
  -7: 已经开帐，数据不能修改
-----------------------------
*/

CREATE	       PROCEDURE ts_c_ModifyA
(
	@nBillType	numeric(4, 0),	/*单据类型号*/
	@nA_id			int,					/*帐户id*/
	@nC_id			int,					/*往来单位id*/
	@nE_id			int,					/*内部职员id*/
	@szPeriod	varchar(2),	/*会计期号*/
	@dTotal 		NUMERIC(25,8),	/*总金额*/
	@ReturnNumber int output,    /*返回代码*/
	@nY_ID			int=0	
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
	set nocount on
  /*------Some account id*/
	declare
		@Asset_Id			int,				/*2	【资产合计】*/
		@Products_Id		int,				/*3	『库存商品总值合计』*/
		@FixedAsset_id	int,				/*4	『固定资产合计』*/
		@FixedAsset1_id int,				/*5	 固定资产__甲*/
		@Cash_id				int,				/*6	 现    金*/
																/*7	『全部银行存款合计』*/
																/*8	银行户头_1*/
		@ArTotal_Id		int,				/*9	『应收款合计』*/
		@YArTotal_Id	int,				/*70	『内部应收款』*/
		@Lendout_Id		int ,				/*10	『借出商品』*/
		@Dt_Expens_Id	int,				/* 11	待摊费用*/
		@Wt_Comm_Id		int,				/*12	委托代销商品*/
		@St_Comm_Id		int,				/*13	受托代销商品*/
																/*14	【负债合计】*/
		@ApTotal_Id		int,				/*15	『应付帐款合计』*/
		@YApTotal_Id	int,				/*71	『内部应付款』    */
		@Brrowin_Id		int,				/*16	『借入商品』*/
		@DxTotal_Id		int,				/*17	代销商品款*/
																/*18	应交税金*/
																/*19	【收入类】*/
		@SaleIncome_Id	int					/*20	『销售收入』*/
																/*21	『商品类收入』*/
		/*Product_22	商品报溢收入
		
		23	商品获赠收入
		24	成本调价收入
		25	进货退货差价
		26	变价调拨差价
		27	商品拆装差价
		28	借转进货结算与成本差
		29	受托代销结算差价
		30	『其它收入』
		31	调帐收入
		32	利息收入
		33	其它....
		34	【支出类】
		35	『销售成本』
		36	『商品类支出』
		37	商品报损
		38	商品赠出
		39	『费用合计』
		40	调帐亏损
		41	固定资产折旧
		42	其它....
		43	【所有者权益】
		44	实收资本
		45	资本公积
		46	盈余公积
		47	本年利润
		48	利润分配
		49	【利润】
		54	进项税
		55	销项税
		*/

	select	@Asset_Id			=2				/*	【资产合计】*/
	select	@Products_Id	=3				/*	『库存商品总值合计』*/
	select	@FixedAsset_id=4			/*	『固定资产合计』*/
	select	@Cash_id=6						/*	 现    金*/
																/*7	『全部银行存款合计』*/
																  /*8	银行户头_1*/
	select	@ArTotal_Id		=9				/*9	『应收款合计』*/
	/*select	@YArTotal_Id	=70				--70	『内部应收款』*/
	select	@YArTotal_Id=account_id from account where class_id='000001000010'
	select	@Lendout_Id		=10				/*10	『借出商品』*/
	select	@Dt_Expens_Id	=11			  /*11	待摊费用*/
	select	@Wt_Comm_Id		=12				/*12	委托代销商品*/
	select	@St_Comm_Id		=13				/*13	受托代销商品*/
																  /*14	【负债合计】*/
	select	@ApTotal_Id		=15				/*15	『应付帐款合计』*/
	/*select  @YApTotal_Id	=71			    --71	『内部应付款』*/
	select	@YApTotal_Id=account_id from account where class_id='000002000007'
	select	@Brrowin_Id		=16				/*16	『借入商品』*/
	select	@DxTotal_Id		=17				/*17	代销商品款*/
																  /*18	应交税金*/
																  /*19	【收入类】*/
	select	@SaleIncome_Id=20			  /*20	『销售收入』*/

        declare @Pre_Ar INT,  /*预收科目*/
                @Pre_Ap INT   /*预付科目*/
                

        select @Pre_Ar = Account_ID from Account where Class_Id = '000002000005'
        select @Pre_Ap = Account_ID from Account where Class_Id = '000001000009'   

  declare @dTotalTemp NUMERIC(25,8),@dTotalArTemp NUMERIC(25,8),@dTotalApTemp NUMERIC(25,8)
  declare @dTotalAr NUMERIC(25,8),@dTotalAp NUMERIC(25,8)
  declare @nControlAPCredit int, @nYSuperior_id int
  select @dTotalTemp=0
  select @nControlAPCredit=0  
  
/*检查"账务信息表"中是否有该机构的记录。没有记录,就插入记录。*/
  exec ts_c_CreateBalance @nY_ID,@nC_ID
/*控制“二者皆是”往来单位信用额度金额不抵消*/
  if exists(select 1 from company where company_id = @nY_ID and Ytype = 1)
    if exists(select 1 from sysconfig where [sysname] ='Y_ID' and sysvalue <> @nY_ID)
    begin
      select @nY_ID = superior_id from company where company_id = @nY_ID 
      exec ts_c_CreateBalance @nY_ID,@nC_ID
    end 
     
  select @nControlAPCredit=CAST(sysvalue as int) from sysconfig where[sysname] ='ControlAPCredit'
  
  if @nBillType in (152,153)
    select @nYSuperior_id = superior_id from company where company_id = @nC_id
  else
    select @nYSuperior_id = 0 

  	if (@nA_id in (@ArTotal_Id,@YArTotal_Id)) and @nC_id<>0
	begin
		if @szperiod=''
		begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,152,153,162,163)
      				select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from ClientsBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else 
				select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from CompanyBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
				
			if (@nControlAPCredit=0) /*控制“二者皆是”往来单位信用额度金额不抵消*/
			begin
				select @dTotaltemp=@dTotalArTemp+@dTotal-@dTotalApTemp
				if @dTotalTemp>0
      				begin
					if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
						update ClientsBalance set artotal=@dTotaltemp,aptotal=0 where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0		*/
					else 
						update CompanyBalance set artotal=@dTotaltemp,aptotal=0 where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total+@dTotal-@dTotalApTemp where a_id=@ArTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalApTemp where a_id=@ApTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
				end else
      				begin
					if  @nBillType not in (150,151,155,160,161,165,171,172,173,174)
						update clientsBalance set artotal=0,aptotal=-@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					else  
						update CompanyBalance set artotal=0,aptotal=-@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalArtemp-@dtotal where a_id=@ApTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalArTemp where a_id=@ArTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
      				end
      		end else
      		begin
      			select @dTotaltemp=@dTotalArTemp+@dTotal  /*控制“二者皆是”往来单位信用额度金额不抵消*/
				if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
					update ClientsBalance set artotal=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0		*/
				else 
				    update CompanyBalance set artotal=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
				if @@rowcount=0 Goto SysError
				update accountBalance set cur_total=cur_total+@dTotal where a_id=@ArTotal_id and Y_ID=@nY_ID /*and deleted=0*/
				if @@rowcount=0 Goto SysError	    
      		end
      		
			if @nE_id<>0
			begin
	      			select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from employees where emp_id=@nE_id and deleted<>1
				select @dTotaltemp=@dTotalArTemp+@dTotal-@dTotalApTemp
				if @dTotalTemp>0
					update employees set artotal=@dTotaltemp,aptotal=0 where emp_id=@nE_id and deleted<>1
				else
					update employees set artotal=0,aptotal=-@dTotaltemp where emp_id=@nE_id and deleted<>1
				if @@rowcount=0 Goto SysError
      			end
			end else
		begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174, 162,163)
		      		select @dTotaltemp=isnull(sum(artotal_ini),0) from clientsBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else 
				select @dTotaltemp=isnull(sum(artotal_ini),0) from companyBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174, 162,163)
				update clientsBalance set artotal_ini=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else 
				update companyBalance set artotal_ini=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			if @@rowcount=0 Goto SysError	
			select @dTotaltemp=isnull(sum(ini_total),0) from accountBalance where a_id=@ArTotal_Id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			update accountBalance set ini_total=@dTotaltemp where a_id=@ArTotal_Id and Y_ID=@nY_ID /*and deleted=0*/
			if @@rowcount=0 Goto SysError else goto success
		end
	end else if (@nA_id in (@ApTotal_Id,@YApTotal_Id)) and @nC_id<>0
	begin
		if @szperiod=''
		begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	      			select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from clientsBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else 
	      			select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from companyBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			if (@nControlAPCredit=0) /*控制“二者皆是”往来单位信用额度金额不抵消*/
			begin
				select @dTotaltemp=@dTotalApTemp+@dTotal-@dTotalArTemp
				if @dTotalTemp>0
      				begin
					if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
						update clientsBalance set aptotal=@dTotaltemp,artotal=0 where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					else 
						update companyBalance set aptotal=@dTotaltemp,artotal=0 where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total+@dTotal-@dTotalArTemp where a_id=@ApTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalArTemp where a_id=@ArTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
				end else
      				begin
					if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
						update clientsBalance set aptotal=0,artotal=-@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					else
						update companyBalance set aptotal=0,artotal=-@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalAptemp-@dtotal where a_id=@ArTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
					update accountBalance set cur_total=cur_total-@dTotalApTemp where a_id=@ApTotal_id and Y_ID=@nY_ID /*and deleted=0*/
					if @@rowcount=0 Goto SysError
      				end
      	    end else
      		begin
      		    select @dTotaltemp=@dTotalApTemp+@dTotal   /*控制“二者皆是”往来单位信用额度金额不抵消*/
      		    if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
				  update clientsBalance set aptotal=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			    else 
				  update companyBalance set aptotal=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			    if @@rowcount=0 Goto SysError   
			    update accountBalance set cur_total=cur_total+@dTotal where a_id=@ApTotal_id and Y_ID=@nY_ID /*and deleted=0*/
			    if @@rowcount=0 Goto SysError
      		end
			if @nE_id<>0
			begin
	      			select @dTotalArTemp=isnull(sum(artotal),0),@dTotalApTemp=isnull(sum(aptotal),0)
				from employees where emp_id=@nE_id and deleted<>1
				select @dTotaltemp=@dTotalApTemp+@dTotal-@dTotalArTemp
				if @dTotalTemp>0
					update employees set aptotal=@dTotaltemp,artotal=0 where emp_id=@nE_id and deleted<>1
				else
					update employees set aptotal=0,artotal=-@dTotaltemp where emp_id=@nE_id and deleted<>1
				if @@rowcount=0 Goto SysError
      			end
		end else
		begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	      			select @dTotaltemp=isnull(sum(aptotal_ini),0) from clientsBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else
				select @dTotaltemp=isnull(sum(aptotal_ini),0) from companyBalance where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
				update clientsBalance set aptotal_ini=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			else
				update CompanyBalance set aptotal_ini=@dTotaltemp where c_id=@nC_id and Y_ID=@nY_ID /*and deleted=0*/
			if @@rowcount=0 Goto SysError 
	
	   		select @dTotaltemp=isnull(sum(ini_total),0) from accountBalance where a_id=@ApTotal_Id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			update accountBalance set ini_total=@dTotaltemp where a_id=@ApTotal_Id and Y_ID=@nY_ID /*and deleted=0*/
			if @@rowcount=0 Goto SysError else goto success
		end
	end else 
	begin
		if @szperiod='' 
		begin
      		select @dTotaltemp=isnull(sum(cur_total),0) from accountBalance where a_id=@nA_id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			update accountBalance set cur_total=@dTotaltemp where a_id=@nA_id  and Y_ID=@nY_ID /*and deleted=0							*/
			if @@rowcount=0 Goto SysError
		end else
		begin
			select @dTotaltemp=isnull(sum(ini_total),0) from accountBalance where a_id=@nA_id and Y_ID=@nY_ID /*and deleted=0*/
			select @dTotaltemp=@dTotaltemp+@dTotal
			update accountBalance set ini_total=@dTotaltemp where a_id=@nA_id and Y_ID=@nY_ID /*and deleted=0*/
			if @@rowcount=0 Goto SysError
		end


	       /*需要判断预收、预付余额*/
	       declare @atotal NUMERIC(25,8)
	       select @atotal = 0
	
	       if  @nA_id = @Pre_Ar
	       begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	         		select @atotal = Pre_artotal + ISNULL(@dTotal,0) FROM CLientsBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0             */
			else
				select @atotal = Pre_artotal + ISNULL(@dTotal,0) FROM CompanyBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0             */
	         	if @atotal < 0 goto ErrorArShort
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	         		update ClientsBalance set Pre_artotal = Pre_artotal + ISNULL(@dTotal,0) from ClientsBalance where C_ID = @nC_id  and Y_ID=@nY_ID /*AND deleted = 0    */
			else
				update CompanyBalance set Pre_artotal = Pre_artotal + ISNULL(@dTotal,0) from CompanyBlance where C_ID = @nC_id  and Y_ID=@nY_ID /*AND deleted = 0    */
	       end
	       else if @nA_id = @Pre_Ap 
	       begin
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	         		select @atotal = Pre_aptotal + ISNULL(@dTotal,0) FROM CLientsBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0             */
			else
	         		select @atotal = Pre_aptotal + ISNULL(@dTotal,0) FROM CompanyBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0             */
	         	if @atotal < 0 goto ErrorApShort
			if  @nBillType not in (150,151,155,160,161,165,171,172,173,174,162,163)
	         		update ClientsBalance set Pre_aptotal = Pre_aptotal + ISNULL(@dTotal,0) from ClientsBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0             */
			else
				update CompanyBalance set Pre_aptotal = Pre_aptotal + ISNULL(@dTotal,0) from CompanyBalance where C_ID = @nC_id and Y_ID=@nY_ID /*AND deleted = 0 */
	       end
     end 

Success:
  set @ReturnNumber=0
 return 0

Error:
  set @ReturnNumber=-1
	return -1

InputCostPriceError:
  set @ReturnNumber=-5
	return -5

SysError:
  set @ReturnNumber=-6
	return -6

ErrorAccountOpen:
  set @ReturnNumber=-7
	return -7

ErrorApShort:
  set @ReturnNumber=-31
  return -31 
ErrorArShort:
  set @ReturnNumber=-32
  return -31
GO
