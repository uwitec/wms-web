CREATE	 PROCEDURE ts_I_InsPayMentBill
@bill_id int,
@y_id int,
@p_id int,
@buybill_id int,
@buydetai_id int
as
begin
  insert into PayMentBill(
  Bill_Id, Y_id, P_id, BuyBill_id, BuyDetai_ID
  )values
  (@bill_id,@y_id,@p_id,@buybill_id,@buydetai_id
  )
end
GO
