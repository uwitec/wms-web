/* =============================================*/
/* Author:		<YH>*/
/* Create date: <2015-01-04>*/
/* Description:	<零售低于成本价/不按零售价销售的商品销售分析>*/
/* =============================================*/
create PROCEDURE TS_Y_REPSaleUnderCostPrice  
 (   @BeginDate     VARCHAR(10)='',  
     @EndDate     VARCHAR(10)='',  
     @nPID     INT=0,  
     @nYClassid        varchar(50)='',  
     @nloginEID        int=0,  
     @saleman          int=0,  
     @nSID             int=0,  /*仓库*/  
     @ntype            int=0/*0代表低于成本价 1代表不按零售价销售, 2低于零售价, 3低于成本价且低于零售价*/  
 )  
AS  
BEGIN  
 /* SET NOCOUNT ON added to prevent extra result sets from*/  
 /* interfering with SELECT statements.*/  
 SET NOCOUNT ON;  
  
      
   Declare @Companytable varchar(100)  
   Declare @yid int  
     
   if OBJECT_ID('tempdb..#Companytable') is not null  
    drop table #Companytable   
   create table #Companytable([id] int)  
     
  /*---分支机构授权*/  
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y')   
       or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and 

u.psc_id='000000')   
    begin  
       set @Companytable=0  
    end  
    else  
    begin  
       set @Companytable=1       
       Insert #Companytable ([id]) select Company_id from Company C where   
       exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id 

like u.psc_id+'%')  
    end  
   
 /*  if @nYClassid <>''   
   begin  
      select @yid=company_id from company where class_id=@nYClassid  
   end  
   else  
   begin  
      set @yid=0  
   end*/  
  if @ntype=0   
  begin  
     select a.billdate,
            a.billid,
            a.billnumber,
            a.billtype,
            a.inputman,
            a.saleman,
            a.code,
            a.standard,  
            a.makearea,
            a.Factory,
            isnull(a.unitname,'') as unitname,
            isnull(a.storagename,'') as storagename,
            a.validdate,
            a.batchno,
            a.quantity,
            a.saleprice,
            a.costprice,  
            a.taxtotal,
            a.instoretime,
            a.Y_ID,
            a.costtaxtotal,
            a.retailprice,
            a.YName,
            a.pname,  /*商品通用名*/
            a.name,    /*商品全名*/
            a.comment /*商品备注*/
            from(  
               SELECT b.billdate,
                      b.billid,
                      b.billnumber,
                      b.billtype,
                      b.inputman, 
                      e.name as saleman,
                      case when s.AOID = 8 then sp.code else p.serial_number end as code,
                      case when s.AOID = 8 then sp.alias else p.alias end as pname,             /*商品通用名 */
                      case when s.AOID = 8 then sp.name else p.name end as name,                /*商品名 */
                      case when s.AOID = 8 then sp.comment else p.comment end as comment,       /*商品备注*/
                      case when s.AOID = 8 then '' else p.standard end as standard,
                      case when s.AOID = 8 then '' else p.makearea end as makearea,
                      case when s.AOID = 8 then sp.unitname else u.name end as unitname,  
                      case when s.AOID = 8 then '' else g.name end AS storagename,
        s.validdate,s.batchno,  
        s.quantity,s.taxprice as saleprice,s.costtaxprice as costprice, s.taxtotal,
        case when s.AOID = 8 then '' else s.instoretime end as instoretime,b.Y_ID 

        ,s.costtaxtotal,y.name as YName , s.retailprice,
        case when s.AOID = 8 then '' else isnull(f.AccountComment,'') end as Factory  
        FROM salemanagebill AS S  
        left join dbo.billidx as b on b.billid=s.bill_id   
        left join company  y on b.Y_ID=y.company_id  
        left join dbo.products as p on p.product_id=s.p_id
        left join VW_H_SpecialProducts sp on s.p_id = sp.product_id 
        left join dbo.employees as e on e.emp_id=b.e_id/*销售员*/  
        left join dbo.storages   as g on g.storage_id=b.sout_id /*仓库*/  
        left join dbo.unit        as u on u.unit_id=s.unitid
        left join BaseFactory     as f on f.CommID = p.factoryc_id
        where b.billtype=12 and s.p_id>0   
        /*and s.saleprice<s.costprice */  
        and s.taxtotal<s.costtaxtotal  
        and  b.[Billdate] BETWEEN @BeginDate AND @EndDate  
        and billstates=0  and ((@nPID=0) or(s.p_id=@nPID))/*商品*/  
        and ((@saleman=0)or(b.e_id=@saleman))/*销售员*/  
        and ((@nYClassid='')or(y.class_id like @nYClassid+'%'))  
        /*and ((@nYClassid='')or(b.Y_ID=@yid))*/  
        and ((@nSID =0) or (b.sout_id=@nSID ))
     )  
        as a    where ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))    
  end  
  if @ntype=1   
  begin  
     
    select a.billdate,
           a.billid,
           a.billnumber,
           a.billtype,
           a.inputman,
           a.saleman,
           a.code,
           a.standard,  
           a.makearea,
           a.Factory,
           isnull(a.unitname,'') as unitname,
           isnull(a.storagename,'') as storagename,
           a.validdate,
           a.batchno,
           a.quantity,
           a.saleprice,
           a.costprice,  
           a.taxtotal,
           a.instoretime,
           a.Y_ID,
           a.retailprice,
           a.retailtotal,
           a.costtaxtotal,
           a.pname,     /*商品通用名*/
           a.name,      /*商品名*/
           a.comment    /*商品备注*/
            from(  
         SELECT b.billdate,
                b.billid,
                b.billnumber,
                b.billtype,
                b.inputman, 
                e.name as saleman,
                case when s.AOID = 8 then sp.code else p.serial_number end as code,
                case when s.AOID = 8 then sp.alias else p.alias end as pname,             /*商品通用名 */
                case when s.AOID = 8 then sp.name else p.name end as name,                /*商品名 */
                case when s.AOID = 8 then sp.comment else p.comment end as comment,       /*商品备注*/
                case when s.AOID = 8 then '' else p.standard end as standard,
                case when s.AOID = 8 then '' else p.makearea end as makearea,
                case when s.AOID = 8 then sp.unitname else u.name end as unitname, 
                case when s.AOID = 8 then '' else g.name end AS storagename,
                s.validdate,
                s.batchno,  
                s.quantity,
                s.taxprice as saleprice, 
                s.costtaxprice as costprice, 
                s.taxtotal, 
                case when s.AOID = 8 then '' else s.instoretime end as instoretime,
                b.Y_ID,
                s.retailprice,
                s.retailtotal,
                s.costtaxtotal,
                case when s.AOID = 8 then '' else isnull(f.AccountComment,'') end as Factory  
        FROM salemanagebill AS S   
        left join dbo.billidx as b on b.billid=s.bill_id   
        left join dbo.products as p on p.product_id=s.p_id
        left join VW_H_SpecialProducts sp on s.p_id = sp.product_id  
        left join dbo.employees as e on e.emp_id=b.e_id/*销售员*/  
        left join dbo.storages   as g on g.storage_id=b.sout_id /*仓库*/  
        left join dbo.unit        as u on u.unit_id=s.unitid  
        left join company  as y on b.Y_ID=y.company_id
        left join BaseFactory     as f on f.CommID = p.factoryc_id          
        where b.billtype=12 and s.p_id>0   
        and s.saleprice<>s.retailprice  
        and  b.[Billdate] BETWEEN @BeginDate AND @EndDate  
        and billstates=0  and ((@nPID=0) or(s.p_id=@nPID))/*商品*/  
        and ((@saleman=0)or(b.e_id=@saleman))/*销售员*/  
       /* and ((@nYClassid='')or(b.Y_ID=@yid))*/  
         and ((@nYClassid='')or(y.class_id like @nYClassid+'%'))  
        and ((@nSID =0) or (b.sout_id=@nSID )))  
        as a    where ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))    
     
  end  

  if @ntype=2   
  begin  
     
    select a.billdate,
           a.billid,
           a.billnumber,
           a.billtype,
           a.inputman,
           a.saleman,
           a.code,
           a.standard,  
           a.makearea,
           a.Factory,
           isnull(a.unitname,'') as unitname,
           isnull(a.storagename,'') as storagename,
           a.validdate,
           a.batchno,
           a.quantity,
           a.saleprice,
           a.costprice,  
           a.taxtotal,
           a.instoretime,
           a.Y_ID,
           a.retailprice,
           a.retailtotal,
           a.costtaxtotal,
           a.YName,
           a.pname,     /*商品通用名*/
           a.name,      /*商品名*/
           a.comment    /*商品备注*/
            from(  
         SELECT b.billdate,
                b.billid,
                b.billnumber,
                b.billtype,
                b.inputman, 
                e.name as saleman,
                case when s.AOID = 8 then sp.code else p.serial_number end as code,
                case when s.AOID = 8 then sp.alias else p.alias end as pname,             /*商品通用名 */
                case when s.AOID = 8 then sp.name else p.name end as name,                /*商品名 */
                case when s.AOID = 8 then sp.comment else p.comment end as comment,       /*商品备注*/
                case when s.AOID = 8 then '' else p.standard end as standard,
                case when s.AOID = 8 then '' else p.makearea end as makearea,
                case when s.AOID = 8 then sp.unitname else u.name end as unitname, 
                case when s.AOID = 8 then '' else g.name end AS storagename, 
                s.validdate,
                s.batchno,  
                s.quantity,
                s.taxprice as saleprice, 
                s.costtaxprice as costprice, 
                s.taxtotal, 
                case when s.AOID = 8 then '' else s.instoretime end as instoretime,
                b.Y_ID,
                s.retailprice,
                s.retailtotal,
                s.costtaxtotal,
                y.name as YName,
                case when s.AOID = 8 then '' else isnull(f.AccountComment,'') end as Factory  
        FROM salemanagebill AS S   
        left join dbo.billidx as b on b.billid=s.bill_id   
        left join dbo.products as p on p.product_id=s.p_id
        left join VW_H_SpecialProducts sp on s.p_id = sp.product_id  
        left join dbo.employees as e on e.emp_id=b.e_id/*销售员*/  
        left join dbo.storages   as g on g.storage_id=b.sout_id /*仓库*/  
        left join dbo.unit        as u on u.unit_id=s.unitid  
        left join company  as y on b.Y_ID=y.company_id 
        left join BaseFactory     as f on f.CommID = p.factoryc_id         
        where b.billtype=12 and s.p_id>0   
        and s.saleprice< s.retailprice  
        and  b.[Billdate] BETWEEN @BeginDate AND @EndDate  
        and billstates=0  and ((@nPID=0) or(s.p_id=@nPID))/*商品*/  
        and ((@saleman=0)or(b.e_id=@saleman))/*销售员*/  
       /* and ((@nYClassid='')or(b.Y_ID=@yid))*/  
         and ((@nYClassid='')or(y.class_id like @nYClassid+'%'))  
        and ((@nSID =0) or (b.sout_id=@nSID )))  
        as a    where ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))    
     
  end    
      
   if @ntype=3   
  begin  
     
    select a.billdate,
           a.billid,
           a.billnumber,
           a.billtype,
           a.inputman,
           a.saleman,
           a.code,
           a.standard,  
           a.makearea,
           a.Factory,
           isnull(a.unitname,'') as unitname,
           isnull(a.storagename,'') as storagename,
           a.validdate,
           a.batchno,
           a.quantity,
           a.saleprice,
           a.costprice,  
           a.taxtotal,
           a.instoretime,
           a.Y_ID,
           a.retailprice,
           a.retailtotal,
           a.costtaxtotal,
           a.YName,
           a.pname,     /*商品通用名*/
           a.name,      /*商品名*/
           a.comment    /*商品备注*/
            from(  
         SELECT b.billdate,
                b.billid,
                b.billnumber,
                b.billtype,
                b.inputman, 
                e.name as saleman,
                case when s.AOID = 8 then sp.code else p.serial_number end as code,
                case when s.AOID = 8 then sp.alias else p.alias end as pname,             /*商品通用名 */
                case when s.AOID = 8 then sp.name else p.name end as name,                /*商品名 */
                case when s.AOID = 8 then sp.comment else p.comment end as comment,       /*商品备注*/
                case when s.AOID = 8 then '' else p.standard end as standard,
                case when s.AOID = 8 then '' else p.makearea end as makearea,
                case when s.AOID = 8 then sp.unitname else u.name end as unitname,  
                case when s.AOID = 8 then '' else g.name end AS storagename, 
                s.validdate,
                s.batchno,  
                s.quantity,
                s.taxprice as saleprice, 
                s.costtaxprice as costprice, 
                s.taxtotal, 
                case when s.AOID = 8 then '' else s.instoretime end as instoretime,
                b.Y_ID,
                s.retailprice,
                s.retailtotal,
                s.costtaxtotal,
                y.name as YName,
                case when s.AOID = 8 then '' else isnull(f.AccountComment,'') end as Factory  
        FROM salemanagebill AS S   
        left join dbo.billidx as b on b.billid=s.bill_id   
        left join dbo.products as p on p.product_id=s.p_id
        left join VW_H_SpecialProducts sp on s.p_id = sp.product_id  
        left join dbo.employees as e on e.emp_id=b.e_id/*销售员*/  
        left join dbo.storages   as g on g.storage_id=b.sout_id /*仓库*/  
        left join dbo.unit        as u on u.unit_id=s.unitid  
        left join company  as y on b.Y_ID=y.company_id  
        left join BaseFactory     as f on f.CommID = p.factoryc_id
        where b.billtype=12 and s.p_id>0   
        and s.saleprice< s.retailprice
        and s.taxtotal< s.costtaxtotal   
        and  b.[Billdate] BETWEEN @BeginDate AND @EndDate  
        and billstates=0  and ((@nPID=0) or(s.p_id=@nPID))/*商品*/  
        and ((@saleman=0)or(b.e_id=@saleman))/*销售员*/  
       /* and ((@nYClassid='')or(b.Y_ID=@yid))*/  
         and ((@nYClassid='')or(y.class_id like @nYClassid+'%'))  
        and ((@nSID =0) or (b.sout_id=@nSID )))  
        as a    where ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))    
     
  end      
    drop table #Companytable  
    
END
GO
