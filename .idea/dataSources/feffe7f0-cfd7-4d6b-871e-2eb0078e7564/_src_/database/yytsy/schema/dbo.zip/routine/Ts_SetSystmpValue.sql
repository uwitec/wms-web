
CREATE	procedure Ts_SetSystmpValue
(
	@szSysName varchar(60),
	@szSysValue varchar(80),
	@nY_ID int = 0
)  
AS
SET NOCOUNT ON  
if @nY_ID is null  SET @nY_ID = 0

IF EXISTS (SELECT sysvalue FROM sysconfigtmp WHERE [sysname]=@szSysName and y_id = @nY_ID)
    UPDATE sysconfigtmp SET [sysvalue]=@szSysValue WHERE [sysname]=@szSysName and y_id = @nY_ID
ELSE
    INSERT INTO sysconfigtmp (sysvalue, sysname, y_id, sysflag)VALUES(@szSysValue,@szSysName, @nY_ID, 0)

IF @@ROWCOUNT>0 
    RETURN 0
ELSE 
    RETURN -1
GO
