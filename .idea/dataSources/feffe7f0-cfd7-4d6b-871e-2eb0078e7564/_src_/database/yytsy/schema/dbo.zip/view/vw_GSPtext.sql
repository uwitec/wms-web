
CREATE	VIEW dbo.vw_GSPtext
AS
SELECT a.GSPID, 
       a.GSPType, 
       a.BillCode, 
       a.BillE, 
       a.BillId,
       a.BillType,
       a.BillDate, 
       a.Comment, 
       a.CheckState, 
       a.[sign],
       a.gsptext, 
       a.GspVer,
       a.y_id,
       checkCase = CASE a.CheckState WHEN 0 THEN '' WHEN 2 THEN '√' WHEN 1 THEN '⊙'END, 
       a.checkflag,
       gvt.name as CGspType, 
       c.name AS YName
FROM dbo.GspTable a, company c, GspVchType gvt 
WHERE a.Y_ID = c.company_id
  and a.GspType = gvt.GspType
GO
