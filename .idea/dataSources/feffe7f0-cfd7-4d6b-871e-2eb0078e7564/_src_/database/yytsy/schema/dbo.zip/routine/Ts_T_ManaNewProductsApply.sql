
CREATE PROCEDURE [Ts_T_ManaNewProductsApply]
(
  @alias		[varchar](80),
  @name	        [varchar](80),
  @standard	    [varchar](100),
  @makearea	    [varchar](60),
  @PackStd      [varchar](60),
  @trademark    [varchar](50),
  @RegisterNo   [varchar](500),
  @permitcode   [varchar](50),
  @pack         [varchar](100),
  @Factory      [varchar](80),
  @AppNum       NUMERIC(25,8),
  @ArrivalNum   NUMERIC(25,8),
  @ValideDate   [datetime],
  @Comment      [varchar](200),
  @InputYID     [int],
  @InputEID     [int],
  @InPutDate    [datetime],
  @RecNum       [int],
  @OType        [int]
)

AS 
  /*新增/修改*/
  if @OType = 0 
  begin
    /*新增 */
    if @RecNum <= 0 
    begin
      Insert into NewProductsApplyRec (name, alias, [standard], makearea, PackStd, trademark, RegisterNo, pack, permitcode,
                                       Factory, AppNum, ValideDate, Comment, InputYID, InputEID, InPutDate)
                                      Values 
                                      (@name, @alias, @standard, @makearea, @PackStd, @trademark, @RegisterNo, @pack, @permitcode,
                                       @Factory, @AppNum, @ValideDate, @Comment, @InputYID, @InputEID, @InPutDate) 
    end
    /*修改*/
    else 
    begin
      Update NewProductsApplyRec set name = @name, alias = @alias, [standard] = @standard, makearea = @makearea, PackStd = @PackStd, 
                                     trademark = @trademark, RegisterNo = @RegisterNo, pack = @pack, permitcode = @permitcode, 
                                     Factory = @Factory, AppNum = @AppNum, ValideDate = @ValideDate, Comment = @Comment, 
                                     InputYID = @InputYID, InputEID = @InputEID, InPutDate = @InPutDate
      where RecNum = @RecNum   
    end
  end
  /*删除*/
  else if @OType = 1 
  begin
    Update NewProductsApplyRec set [DFlag] = 1 where RecNum = @RecNum 
  end
GO
