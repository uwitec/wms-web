
CREATE PROCEDURE Ts_k_GetGSPReportFromGSPBill(@GSPBillId INT, @GSPVchType INT, @IsDraft int = 1)
AS
BEGIN
	if @IsDraft is null set @IsDraft = 1
    IF @GSPVchType = 12 /*从零售单查询GSP关联*/
    begin
		SELECT *
		FROM   vw_GspIndex gt
		WHERE  gt.BillId = @GSPBillId AND gt.BillType = @GSPVchType	   
		union all 
		select * 
		from vw_GspIndex gt  
		where gt.BillId IN (
		                     select orgbillid from billidx b 
		                     left join salemanagebill s on b.billid = s.bill_id 
		                     where b.billid = @GSPBillId and orgbillid > 0
		                   ) AND gt.BillType = 39	/*拆零关联得要过滤出拆零单号 */
    end
    else
    begin
		IF @GSPVchType IN (10, 11, 20, 21, 150, 152, 153, 151, 160, 161, 162, 163)
			SET @IsDraft = 0

		SELECT distinct G.* FROM vw_GspIndex G
		INNER JOIN (SELECT * FROM VW_BILLTRACE WHERE traceGuid in (SELECT traceGuid FROM VW_BILLTRACE WHERE billId = @GSPBillId AND billType = @GSPVchType AND isDraft = @IsDraft)) B
		ON G.billid = B.billId AND G.BillType = B.billType
	end
END
GO
