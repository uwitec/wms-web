
create procedure Ts_L_ValidVipAnalytical
(
  @PreBeginDate datetime = 0,
  @PreEndDate datetime = 0,
  @NowBeginDate datetime = 0,
  @NowEndDate datetime = 0
)
AS
BEGIN
     
   select *,cast((CASE PreComPrice WHEN 0 THEN 0 ELSE (Cast(PreVipComPrice as NUMERIC(25,8))/Cast(PreComPrice as NUMERIC(25,8))) END)*100 as numeric(18,2)) AS PreVipComPricePercent,
            cast((CASE NowComPrice WHEN 0 THEN 0 ELSE (Cast(NowVipComPrice as NUMERIC(25,8))/cast(NowComPrice as NUMERIC(25,8))) END)*100 as numeric(18,2)) AS NowVipComPricePercent
    from 
   (  
   select name,area,PreVipNumber,PreValidVipNmuber,cast((CASE PreVipNumber WHEN 0 THEN 0 ELSE (CAST(PreValidVipNmuber AS NUMERIC(25,8))/CAST(PreVipNumber AS NUMERIC(25,8))) END)*100 AS numeric(18,2)) AS PreVipNumberPercent,
          PreComNumber,PreComVipNumber,cast((CASE PreComNumber WHEN 0 THEN 0 ELSE (cast(PreComVipNumber as NUMERIC(25,8))/cast(PreComNumber as NUMERIC(25,8))) END)*100 as numeric(18,2)) AS PreComNumberPercent,
          PreYsmoney,PreVipYsmoney,cast((CASE PreYsmoney WHEN 0 THEN 0 ELSE (PreVipYsmoney/PreYsmoney) END) as numeric(18,2))*100 AS PreVipYsmoneyPercent,
          CAST((CASE PreComNumber WHEN 0 THEN 0 ELSE (PreYsmoney/PreComNumber) END) AS NUMERIC(18,2)) AS PreComPrice,
          CAST((CASE PreComVipNumber WHEN 0 THEN 0 ELSE (PreVipYsmoney/PreComVipNumber) END) AS NUMERIC(18,2)) AS PreVipComPrice, 
          NowVipNumber,NowValidVipNumber,cast((CASE NowVipNumber WHEN 0 THEN 0 ELSE (cast(NowValidVipNumber as NUMERIC(25,8))/cast(NowVipNumber as NUMERIC(25,8))) END)*100 as numeric(18,2)) AS NowVipNumberPercent,
          NowComNumber,NowComVipNumber,cast((case NowComNumber when 0 then 0 else (cast(NowComVipNumber as NUMERIC(25,8))/cast(NowComNumber as NUMERIC(25,8))) end)*100 as numeric(18,2)) as NowVipComNumberPercent,
          NowYsmoney,NowVipYsmoney,cast((case NowYsmoney when 0 then 0 else (NowVipYsmoney/NowYsmoney) end)*100 as numeric(18,2)) as NowVipYsmoneyPercent,
          CAST((case NowComNumber when 0 then 0 else (NowYsmoney/NowComNumber) end) AS NUMERIC(18,2)) as NowComPrice,
          CAST((case NowComVipNumber when 0 then 0 else (NowVipYsmoney/NowComVipNumber) end) AS NUMERIC(18,2)) as NowVipComPrice,
          VipAddNumber,cast((case PreVipNumber when 0 then 0 else (cast(VipAddNumber as NUMERIC(25,8))/cast(PreVipNumber as NUMERIC(25,8))) end)*100 as numeric(18,2)) as VipAddPercent
         from  
        (
         select  c.name,isnull(Region.name,'') as area,
         isnull(PreVipNumber,0) as PreVipNumber,isnull(pret.PreValidVipNmuber,0) as PreValidVipNmuber,
         isnull(PreCom.PreComNumber,0) as PreComNumber,isnull(PreVipCom.PreComVipNumber,0) as PreComVipNumber,
         isnull(PreCom.PreYsmoney,0) as PreYsmoney,isnull(PreVipCom.PreVipYsmoney,0) as PreVipYsmoney,
         isnull(NowVipNumber,0) as NowVipNumber,isnull(NowT.NowValidVipNumber,0) as NowValidVipNumber,
         isnull(NowCom.NowComNumber,0) as NowComNumber,isnull(NowVipCom.NowComVipNumber,0) as NowComVipNumber,
         isnull(NowCom.NowYsmoney,0) as NowYsmoney,isnull(NowVipCom.NowVipYsmoney,0) as NowVipYsmoney,
         isnull((VipNumber.NowVipNumber-VipNumber.PreVipNumber),0) AS VipAddNumber
   from company C
   Left Join 
  /*-------上期会员总数和本期会员总数*/
  (
  select Y_ID ,SUM(PreVipNumber) AS PreVipNumber,SUM(NowVipNumber) AS NowVipNumber  
  FROM(
	  select Y_ID,(case when BulidDate <=@PreEndDate then 1 else 0 end) as PreVipNumber,
				  (Case when BulidDate <= @NowEndDate then 1 else 0 end) as NowVipNumber
	   from VIPCard  
   ) T GROUP BY Y_ID
   ) VipNumber on c.company_id = VipNumber.Y_ID
  Left Join
  ( 
  /*-------上期有效会员 */
  SELECT Y_ID,COUNT(VIPCardID) AS PreValidVipNmuber FROM (
   select Y_ID,VIPCardID,COUNT(VIPCardID) as bc from billidx where billtype = 12 and VIPCardID <> 0 
       and billdate between @PreBeginDate and @PreEndDate and billstates = 0 group by Y_ID,VIPCardID
       ) PreT group by Y_ID
   ) PreT ON C.company_id = PreT.Y_ID
   Left Join
   /*-----上期来客数*/
   (
    select Y_ID,COUNT(billid) as PreComNumber,sum(ysmoney) as PreYsmoney FROM BillIdx  where billtype = 12
	   and billdate between @PreBeginDate and @PreEndDate and billstates = 0
	   group by Y_ID
   ) PreCom on c.company_id = PreCom.Y_ID
       
   Left Join
   (
       /*-------上期会员来客数 */
    select Y_ID,COUNT(billid) as PreComVipNumber,sum(ysmoney) as PreVipYsmoney from billidx where billtype = 12 and VIPCardID <> 0 
       and billdate between @PreBeginDate and @PreEndDate and billstates = 0 group by Y_ID
   ) PreVipCom on c.company_id = PreVipCom.Y_ID   
   
   Left Join
   (
  /*-------本期有效会员*/
  SELECT Y_ID,COUNT(VIPCardID) AS NowValidVipNumber FROM (
   select Y_ID,VIPCardID,COUNT(VIPCardID) as nc from billidx where billtype = 12 and VIPCardID <> 0 
       and billdate between @NowBeginDate and @NowEndDate and billstates = 0 group by Y_ID,VIPCardID    
     ) NowT group by Y_ID
   ) NowT ON C.company_id = NowT.Y_ID
   Left Join
   (
   /*------本期来客数*/
     select Y_ID,COUNT(billid) as NowComNumber,sum(ysmoney) as NowYsmoney FROM BillIdx  where billtype = 12
   and billdate between @NowBeginDate and @NowEndDate and billstates = 0
   group by Y_ID
   ) NowCom on c.company_id = NowCom.Y_ID
   Left join
   (
       /*-------本期会员来客数*/
   select Y_ID,COUNT(billid) as NowComVipNumber,sum(ysmoney) as NowVipYsmoney from billidx where billtype = 12 and VIPCardID <> 0 
       and billdate between @NowBeginDate and @NowEndDate and billstates = 0 group by Y_ID 
   ) NowVipCom on c.company_id = NowVipCom.Y_ID  
   Left join
   Region on c.region_id = Region.region_id
   where c.child_number = 0 and c.deleted = 0
   ) T 
 ) TT     
        
END
GO
