create procedure ts_e_DeltedWMSBaseinfo
  @id integer =0,
  @SType       varchar(10) /*'KQ' 表示库区，'QY' 表示区域，'HW'表示货位*/
as 
begin
  if @SType ='KQ'
  begin
    update stockArea set deleted=1 where sa_id=@id
  end
  if @SType ='QY'
  begin
     update WMSRegion set deleted=1 where id=@id
     update WMSMedtype set deleted=1 where StoreQYHWID=@id and Flag=1
  end
  if @SType ='HW'
  begin
     update location set deleted=1 where loc_id=@id
     update WMSMedtype set deleted=1 where StoreQYHWID=@id and Flag=2
  end
end
GO
