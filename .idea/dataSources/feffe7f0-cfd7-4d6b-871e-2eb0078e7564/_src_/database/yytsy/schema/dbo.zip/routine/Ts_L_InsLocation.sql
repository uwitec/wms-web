
CREATE PROCEDURE [Ts_L_InsLocation]
	(@s_id		[int],
	 @loc_code	[varchar](30),
	 @loc_name	[varchar](30),
	 @loc_comment	[varchar](20),
     @slf_id    int,
     @LocType	int,
     @said      int
)

AS 
INSERT INTO [location] 
	 ( [s_id],
	 [loc_code],
	 [loc_name],
	 [loc_comment],
     [Shelfid],
     LocType, 
     sa_id) 
 
VALUES 
	( @s_id,
	 @loc_code,
	 @loc_name,
	 @loc_comment,
     @slf_id,
     @LocType,
     @said)
     
if @@rowCount=0 
	return -1
else 
	return @@IDENTITY
GO
