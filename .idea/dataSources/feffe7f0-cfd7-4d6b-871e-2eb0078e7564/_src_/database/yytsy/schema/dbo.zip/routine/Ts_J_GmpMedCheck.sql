

CREATE	PROCEDURE [Ts_J_GmpMedCheck]
	(@C_id 	[int],
	 @MT_id	[int])

AS

  if @MT_id = 0
  begin
    select 1 as checkflag
    return 0 
  end
   
  if exists(select 1 from clients where Ent_type <> 1 and  client_id = @C_id)
  begin
    select 1 as checkflag
    return 0 
  end  

  select 1 as checkflag
    from GMPIndex g
    inner join GMPMedtype gm on g.g_id = gm.ga_id
    where g.c_id = @C_id and gm.mt_id = @MT_id and validdate >  cast(floor(cast(GETDATE() as NUMERIC(25,8))) as datetime)
  return 0
GO
