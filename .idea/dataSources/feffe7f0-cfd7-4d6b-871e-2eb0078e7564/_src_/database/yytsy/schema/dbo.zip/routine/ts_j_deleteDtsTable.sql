
/*在生成数据包后运行，清除dts表数据*/
create proc ts_j_deleteDtsTable
(
	@nType int  /*0,总部 1分支机构*/
)
/*with encryption*/
as

if @nType = 0
begin
  truncate table billdtsidx
  truncate table tranmanagebilldts
  truncate table storemanagebilldts
  truncate table salemanagebilldts
  truncate table priceidxdts
  truncate table pricebilldts
  truncate table Accountbalancedts
  truncate table Clientsbalancedts
  truncate table Companybalancedts
	truncate table OtherStorehouseinidts
	truncate table storebrrowinidts
	truncate table storedxinidts
	truncate table storehouseinidts
end
else if @nType = 1
begin
   	truncate table billdtsidx
	truncate table salemanagebilldts
	truncate table buymanagebilldts
	truncate table tranbilldts
	truncate table tranidxdts
        truncate table priceidxdts
        truncate table pricebilldts
	truncate table Accountbalancedts
	truncate table Clientsbalancedts
	truncate table Companybalancedts
        truncate table OtherStorehousedts
  	truncate table OtherStorehouseinidts
 	truncate table storebrrowdts
	truncate table storebrrowinidts
	truncate table storedxdts
	truncate table storedxinidts
	truncate table storehousedts
	truncate table storehouseinidts
        /*truncate table YProductdetaildts---QLee 2010.8.16 修改starteam bug 2763 yyt升级脚本8.7已将此表删除*/
        /*truncate table YAccountdetaildts---QLee 2010.8.16 修改starteam bug 2763 yyt升级脚本8.7已将此表删除*/
        truncate table TaskListUpDts
end
GO
