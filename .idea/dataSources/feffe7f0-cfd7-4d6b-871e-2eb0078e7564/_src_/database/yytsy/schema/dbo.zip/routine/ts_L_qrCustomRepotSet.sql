
create proc ts_L_qrCustomRepotSet

@Rid int=0
as
/*Params Ini begin*/
if @Rid is null  SET @Rid = 0
/*Params Ini end*/

select *,(case when paratype=0 then '文本' when paratype=1 then '选择框' when paratype=2 then '日期' else '时间' end)Ptypename
,
(case when basetype='btBtype' then '选择往来单位'
      when basetype='btProduct' then '选择商品信息'
      when basetype='btEmployee' then '选择人员'
      when basetype='btStock' then '选择仓库'
      when basetype='btLocation' then '选择货位'
      when basetype='btDept' then '选择部门'
      when basetype='btZone' then '选择片区'
      when basetype='btColor' then '选择分支机构'
   else ''  
  end   
)Btypename,
  (case when Flag=0 then '默认' else '自定义' end)FlagName
 from CustomRepotSet
 where (@Rid=0 or (Rid=@Rid))
GO
