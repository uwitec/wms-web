/************************************************************
--过程名称：药品黑名单添加修改
--功能：增加和修改药品黑名单
--创建人：LUO XIAOTIAN 
--创建时间：2010-11-26  
--最后修改:


参数说明：
		  @product_id  --0为添加，不为0是修改

备注：
**************************************************************/
create proc [dbo].[Ts_T_InsOrUpdateBlacklist]
(   @product_id int,
    @serial_number [varchar](26),/*药品编号*/
    @name [varchar](80), /*药品名称*/
	@alias [varchar](30) , /*通用名*/
	@Pinyin [varchar](30),/*拼音名*/
	@EngName [varchar](50) ,/*英文名*/
	@ChemName [varchar](50) ,/*化学名*/
	@LatinName [varchar](50) ,/*拉丁名*/
	@standard [varchar](20),/*规格*/
	@permitcode [varchar](50),/*批准文号*/
	@makearea [varchar](60) ,/*产地*/
	@Factory [varchar](80) , /*生产厂家*/
	@comment [varchar](250) /*备注*/
)
as

if @product_id = 0
begin
    if @name = '' or @permitcode ='' or @serial_number= ''
    begin
      RAISERROR('为数据完整，带*号的数据必须录入！',16,1)
      return -1
    end
    if exists(select 1 from  ProductBlacklist where permitcode=@permitcode )
	begin
	  RAISERROR('批准文号不允许有重复，请重新填写批准文号！',16,1)
	  return-1
	end
	if exists(select 1 from  ProductBlacklist where name=@name )
	begin
	  RAISERROR('药品名称不有重复，请重新填写药品名称！',16,1)
	  return-1
	end
	
	INSERT INTO [dbo].[ProductBlacklist]
	( [serial_number], 
	  [name] ,
	  [alias] ,
	  [PinYin],
	  [EngName], 
	  [ChemName],
	  [LatinName],
	  [standard],
	  [permitcode] ,
	  [makearea],
	  [Factory] ,
	  [comment]
	)
	Values
	(   @serial_number,
		@name ,
 		@alias ,
 		@Pinyin,
 		@EngName ,
 		@ChemName ,
 		@LatinName ,
 		@standard ,
 		@permitcode,
 		@makearea ,
 		@Factory ,
 		@comment 
	)
end else
if @name = '' or @permitcode ='' or @serial_number= ''
    begin
      RAISERROR('为数据完整，带*号的数据必须录入！',16,1)
      return -1
    end

begin
  if exists(select 1 from  ProductBlacklist where permitcode=@permitcode and product_id<>@product_id  )
begin
  RAISERROR('批准文号不允许有重复，请重新填写批准文号！',16,1)
  return-1
end
  update ProductBlacklist 
  set    [serial_number]=@serial_number,
		 [name]=@name,
		 [alias]=@alias,
		 [PinYin]=@Pinyin,
		 [EngName]=@EngName,
		 [ChemName]=@ChemName,
		 [LatinName]=@LatinName,
		 [standard]=@standard,
		 [permitcode]=@permitcode,
		 [makearea]=@makearea,
		 [Factory]=@Factory,
		 [comment]=@comment
  where [product_id]=@product_id

end

update products set deleted = 2   where (permitcode = @permitcode or serial_number =@serial_number or name = @name) and child_number = 0
GO
