
CREATE PROC TS_M_SelVIPCard
(
  @CT_ID        int,
  @CardNo  	varchar(60) ='',    /*修改CardNo*/
  @Name  	varchar(50) ='',
  @Tel  	varchar(80) ='',    /*修改Tel*/
  @IDCard  	varchar(50) ='',
  @VipCardID    int=0  ,          /*会员卡ID*/
  @isslur       int=0,
  @nCurMinID    int , 
  @nCurMaxID    int ,
  @nDirection   int ,  /*方向 1 next, -1 up*/
  @nPageSize    int output, /*用于控制序号*/
  @npagecount   int output,
  @nMinID		int output, 
  @nMaxID       int output,
  @szFilter varchar(1000) = '' /*过滤条件*/
 ) 
AS
/*Params Ini begin*/
if @CardNo is null  SET @CardNo = ''
if @Name is null  SET @Name = ''
if @Tel is null  SET @Tel = ''
if @IDCard is null  SET @IDCard = ''
if @VipCardID is null  SET @VipCardID = 0  
if @isslur is null  SET @isslur = 0
/*Params Ini end*/

DECLARE @SQL varchar(8000)
DECLARE @SQL1 VARCHAR(8000)


IF (@CardNo='') SET @CardNo='%%' ELSE SET @CardNo='%'+@CardNo+'%'
IF (@Name  ='') SET @Name='%%' ELSE SET @Name='%'+@Name+'%'
IF (@Tel   ='') SET @Tel='%%' ELSE SET @Tel='%'+@Tel+'%'
IF (@IDCard='') SET @IDCard='%%' ELSE SET @IDCard='%'+@IDCard+'%'
IF (@szFilter = '-1') SET @szFilter = ''

set @npagecount = 0
set @nMinID = 0
set @nMaxID = 0
set @npagesize = 10000




if @CardNo = '%%' and @Name ='%%' and @Tel='%%' and @IDCard='%%' and @VipCardID=0 and @szFilter = ''
begin
  /*select @nMinID = MIN(VIPCardID),  @nMaxid = max(vipcardid), @npagecount = count(1) from vipcard where deleted <> 1 and (@CT_ID=0 or ((@ct_id<>0) and ct_id=@ct_id))*/
  /*@nMaxid没发现特别用处，挪用为总条数*/
  select @nMinID = MIN(VIPCardID), @nMaxid = count(1), @npagecount = count(1) from vipcard where deleted <> 1 and (@CT_ID=0 or ((@ct_id<>0) and ct_id=@ct_id))
  if  @npagecount % @npagesize > 0
    set @npagecount =  cast(@npagecount/@npagesize as int) + 1
  else  
    set @npagecount =  cast(@npagecount/@npagesize as int) 
  if @nDirection = -1
  begin
    if OBJECT_ID('tempdb..#vipcaridtmp') is not null
      drop table #vipcaridtmp
    select top 10000 VIPCardid into #vipcaridtmp
      from VIPCard 
      where Deleted <> 1 and (@CT_ID=0 or ((@ct_id<>0) and ct_id=@ct_id)) and VIPCardID < @nCurMinID	 
      order by vipcardid desc 
    select @nCurMaxID = MIN(vipcardid) -1 from #vipcaridtmp  
  end
  
  if  @nMinID is null set @nMinID = 0
  if @nMaxID is null set @nMaxID = 0
          
  SET @SQL='SELECT top '+CAST(@npagesize as varchar)+' V.[VIPCardID], V.[CardNo], V.[Name], V.[sex], V.[Tel], V.[Birthday], V.[Address],  
			v.code1,v.code2,v.code3,v.birthDay2,v.height,v.[weight],v.bloodtype,v.QQ,v.Email,v.Education,v.SocialNO,      
		    V.[Comment], V.[IDCard], V.[CT_ID],ct.Name AS CTName, V.[BulidDate], V.[ValidityDate], V.[Pos_Id], ISNULL(S.[PosName],'''')PosName,
	     	V.[E_id],ISNULL(E.[Name],'''')[ENAME], V.[IniMoney],cast(V.LoginPass as int)LoginPass,V.Pinyin,
		    V.[TotalBuyMoney], V.[SaveMoney], V.[IntergralYE], V.[IniIntergral], V.[Integral], ct.isbank,ct.isIntegral,
		    V.[SwapIntegral], V.[BuyCount] ,V.Deleted,V.RemainderMoney,V.Y_id,isnull(Y.name,'''')Y_name,
			V.Lose,V.StopUse,V.islock, cast(0 as NUMERIC(25,8)) AS todaySale,
			(case when V.Lose=0 then '''' else ''√'' end)showLose,
			(case when V.StopUse=0 then '''' else ''√'' end)showStopUse,
			(case when V.islock=0 then '''' else ''√'' end)showislock,
			V.Integral + V.SwapIntegral AS TotalIntegral ,v.small,
		    V.IntroducerID, IntroName = IsNull((select IsNull(x.name, '''') from VIPCard x where x.VIPCardID = V.IntroducerID), ''''), 
		    V.RetailHint 
		FROM [VIPCard] V inner join VIPcardtype ct on ct.ct_id=v.ct_id
		LEFT JOIN SHOP		S ON V.Pos_Id=S.PosId 
		LEFT JOIN Employees	E ON E.Emp_Id=V.E_Id
		LEFT JOIN Company       Y ON Y.company_id=V.Y_id '
						
 	 SET @SQL=@SQL+ ' WHERE V.Deleted<>1 ' 
 	     + ' and vipcardid >'+ cast(@nCurMaxID as varchar)		
 	      	      	     							
   if (@ct_id<>0) set @SQL=@SQL+' and v.ct_id='+cast(@ct_id as varchar(50))	
   set @sql=@sql+' order by vipcardid'	
   EXEC (@SQL)
      		    
end
else 
begin
    /*
	SET @SQL='SELECT V.[VIPCardID], V.[CardNo], V.[Name], V.[sex], V.[Tel], V.[Birthday], V.[Address],
	     v.code1,v.code2,v.code3,v.birthDay2,v.height,v.[weight],v.bloodtype,v.QQ,v.Email,v.Education,v.SocialNO,
		V.[Comment], V.[IDCard], V.[CT_ID],ct.Name AS CTName, V.[BulidDate], V.[ValidityDate], V.[Pos_Id], ISNULL(S.[PosName],'''')PosName,
		V.[E_id],ISNULL(E.[Name],'''')[ENAME], V.[IniMoney],cast(V.LoginPass as int)LoginPass,V.Pinyin,
		V.[TotalBuyMoney], V.[SaveMoney], V.[IntergralYE], V.[IniIntergral], V.[Integral], ct.isbank,ct.isIntegral,
		V.[SwapIntegral], V.[BuyCount] ,V.Deleted,V.RemainderMoney,V.Y_id,isnull(Y.name,'''')Y_name,
			V.Lose,V.StopUse,V.islock,
			(case when V.Lose=0 then '''' else ''√'' end)showLose,
			(case when V.StopUse=0 then '''' else ''√'' end)showStopUse,
			(case when V.islock=0 then '''' else ''√'' end)showislock,
			V.Integral + V.SwapIntegral AS TotalIntegral ,v.small
		FROM [VIPCard] V inner join VIPcardtype ct on ct.ct_id=v.ct_id
		LEFT JOIN SHOP		S ON V.Pos_Id=S.PosId 
		LEFT JOIN Employees	E ON E.Emp_Id=V.E_Id
			LEFT JOIN Company       Y ON Y.company_id=V.Y_id '			

	if @isslur=0
	 SET @SQL=@SQL+ ' WHERE V.CardNo LIKE ' + CHAR(39) + @CardNo + CHAR(39)
		+'    AND V.Name LIKE ' + CHAR(39) + @Name + CHAR(39)
		+'    AND V.Tel LIKE ' + CHAR(39) + @Tel + CHAR(39)
		+'    AND V.IDCard LIKE ' + CHAR(39) + @IDCard + CHAR(39)
		+'    AND V.Deleted<>1 '
	else
	 SET @SQL=@SQL+ ' WHERE (V.CardNo LIKE ' + CHAR(39) + @CardNo + CHAR(39)
		+'    or V.Name LIKE ' + CHAR(39) + @Name + CHAR(39)
		+'    or V.Tel LIKE ' + CHAR(39) + @Tel + CHAR(39)
		+'    or V.IDCard LIKE ' + CHAR(39) + @IDCard + CHAR(39)
                +'    or V.PinYin LIKE '  + CHAR(39) + @CardNo + CHAR(39)
		+'    ) AND V.Deleted<>1 '
	 
	if (@ct_id<>0) set @SQL=@SQL+' and v.ct_id='+cast(@ct_id as varchar(50))
	if (@VipCardID<>0) set @SQL=@SQL+'and V.vipcardid='+cast(@VipCardID as varchar(50))
	
	--前端的过滤条件要对全部数据进行过过滤。关联ID：29793
	if @szFilter <> '' set @SQL = @SQL + ' and (' + @szFilter + ')'
	 
	--set @sql=@sql+' order by cardNO'
    --会员卡模糊查询增加当天消费金额 add by luowei 2013-04-09
    SET @SQL1 = 'LEFT JOIN  ( select VIPCardID,sum(case billtype when 13 then -ysmoney else ysmoney end) as ''todaySale''  from billidx 
				where billtype in (12,13) and billstates = 0 and billdate = left(convert(varchar,GETDATE(),121),10)
				group by VIPCardID ) S ON S.VIPCardID =  V.VIPCardID'
    
	--PRINT(@SQL)
	EXEC ('SELECT V.*, cast(ISNULL(S.todaySale,0) as NUMERIC(25,8)) AS todaySale FROM (' + @SQL +') V ' + @SQL1 + ' order by cardNO')
	*/
	

    /*前端的数据过滤和清除过滤，客户要求不按原来的对客户端数据过滤，而是直接在后台数据库过滤，故有如下更改，以上为原有代码。关联ID：29793*/
    SELECT V1.*, ISNULL(S1.todaySale,0) AS todaySale INTO #QueryData FROM
       (
       SELECT V.[VIPCardID], V.[CardNo], V.[Name], V.[sex], V.[Tel], V.[Birthday], V.[Address],
	          v.code1,v.code2,v.code3,v.birthDay2,v.height,v.[weight],v.bloodtype,v.QQ,v.Email,v.Education,v.SocialNO,
		      V.[Comment], V.[IDCard], V.[CT_ID],ct.Name AS CTName, V.[BulidDate], V.[ValidityDate], V.[Pos_Id], ISNULL(S.[PosName],'')PosName,
		      V.[E_id],ISNULL(E.[Name],'')[ENAME], V.[IniMoney],cast(V.LoginPass as int)LoginPass,V.Pinyin,
		      V.[TotalBuyMoney], V.[SaveMoney], V.[IntergralYE], V.[IniIntergral], V.[Integral], ct.isbank,ct.isIntegral,
		      V.[SwapIntegral], V.[BuyCount] ,V.Deleted,V.RemainderMoney,V.Y_id,isnull(Y.name,'')Y_name,
			  V.Lose,V.StopUse,V.islock,
			  (case when V.Lose=0 then '' else '√' end)showLose,
			  (case when V.StopUse=0 then '' else '√' end)showStopUse,
			  (case when V.islock=0 then '' else '√' end)showislock,
			  V.Integral + V.SwapIntegral AS TotalIntegral ,v.small,
		      V.IntroducerID, IntroName = ISNULL((select IsNull(x.name, '') from VIPCard x where x.VIPCardID = V.IntroducerID), ''), 
		      V.RetailHint
	    FROM [VIPCard] V inner join VIPcardtype ct on ct.ct_id=v.ct_id
		                 LEFT JOIN SHOP	S ON V.Pos_Id=S.PosId 
		                 LEFT JOIN Employees E ON E.Emp_Id=V.E_Id
			             LEFT JOIN Company Y ON Y.company_id=V.Y_id 			            
        WHERE 1=1 
          AND ((@isslur = 0 AND (V.CardNo LIKE @CardNo AND V.Name LIKE @Name AND V.Tel LIKE @Tel AND V.IDCard LIKE @IDCard))
                or
               (@isslur = 1 AND (V.CardNo LIKE @CardNo or V.Name LIKE @Name or V.Tel LIKE @Tel or V.IDCard LIKE @IDCard or V.PinYin LIKE @CardNo)))                            
		  AND V.Deleted<>1 
	      AND ((@ct_id = 0) or (@ct_id <> 0 and v.ct_id = @ct_id))
	      AND ((@VipCardID = 0) or (@VipCardID <> 0 and V.vipcardid = @VipCardID))
	  ) V1
	  LEFT JOIN
	  ( 
	  SELECT VIPCardID, sum(case billtype when 13 then -ysmoney else ysmoney end) as todaySale 
	   FROM billidx 
	   WHERE billtype in (12,13) and billstates = 0 and billdate = left(convert(varchar,GETDATE(),121),10)
	   GROUP BY VIPCardID 
	  ) S1 ON S1.VIPCardID = V1.VIPCardID /*会员卡模糊查询增加当天消费金额 add by luowei 2013-04-09*/
	ORDER BY cardNO
	
	/*前端的过滤条件要对全部数据进行过过滤。关联ID：29793*/
	SET @SQL = 'SELECT * FROM #QueryData WHERE 1=1'
	IF @szFilter <> '' 
	  SET @SQL = @SQL + ' and (' + @szFilter + ')'	
	EXEC(@SQL)	
	
	IF object_id(N'#QueryData', N'U') is not null  
      DROP TABLE #QueryData 
	 		     
 END
GO
