







/*
	检查单据所含基本资料合法性
	返回值：
	-9：商品已删除
	-10：仓库已删除
	-11：职员已删除
	-12：往来单位已删除
	-13: 会计科目已删除
	-14: 货位已删除
	-15：商品单位已删除
*/

CREATE proc ts_c_validcheck
(
	@nBillId numeric(10,0),
        @nBilltype int
)
AS


  declare @IntegralTotal numeric(16,4)
  declare @CardID int
/*set nocount on*/

 if @nBilltype in (150,151,155,160,161,165,171,172,173,174,152,153,162,163)
 begin
   if exists(select c_id from accountdetail where billid=@nBillId and c_id in (select Company_id from Company where deleted=1 and child_number=0))		return -33
   if exists(select c_id from billidx where billid=@nBillId and c_id in (select Company_id from Company where deleted=1 and child_number=0))					return -33
 end
 else
 begin
   if exists(select c_id from accountdetail where billid=@nBillId and c_id in (select client_id from clients where deleted=1 and child_number=0))		return -12
   if exists(select c_id from billidx where billid=@nBillId and c_id in (select client_id from clients where deleted=1 and child_number=0))					return -12
 end
		if exists(select p_id from productdetail where billid=@nBillId and p_id in (select product_id from products where deleted=1 and child_number=0))	return -9
        if exists(select p_id from productdetail where billid=@nBillId and p_id in (select product_id from products where deleted=2 and child_number=0)) and @nBilltype in(20,220)	return -34		
		if exists(select s_id from productdetail where billid=@nBillId and s_id in (select storage_id from storages where deleted=1 and child_number=0))	return -10
		if exists(select e_id from billidx where billid=@nBillId and e_id in (select emp_id from employees where deleted=1 and child_number=0)) 					return -11
		if exists(select inputman from billidx where billid=@nBillId and inputman in (select emp_id from employees where deleted=1 and child_number=0)) 	return -11
		if exists(select auditman from billidx where billid=@nBillId and auditman in (select emp_id from employees where deleted=1 and child_number=0)) 	return -11
		if exists(select a_id from billidx where billid=@nBillId and a_id in (select account_id from account where deleted=1 and child_number=0))				return -13
		if exists(select a_id from accountdetail where billid=@nBillId and a_id in (select account_id from account where deleted=1 and child_number=0)) 	return -13
		if exists(select location_id from productdetail where billid=@nBillId and location_id in (select loc_id from location where deleted=1)) 					return -14
		if exists(select unitid from productdetail where billid=@nBillId and unitid in (select unit_id from unit where deleted=1))							return -15
/* 以下脚本移到ts_c_retailAudit.sql
                                               --zhh添加，积分兑换赠品，积分不够的情况
                select @CardID=isNull(m.CardID,-9999),@IntegralTotal=isnull(Integral,0) from MemberCard m,BillIdx bi where m.CardID=bi.Order_ID and bi.BillType=12 and bi.BillID=@nBillID
                if @cardID>=0  --找到会员卡 
                begin
                  select @IntegralTotal=@IntegralTotal+(select sum(isnull(pd.Quantity,0)*p.Integral) 
					                  from ProductDetail pd,Products p
					                  where pd.p_id=p.Product_id and pd.aoid in(7,6) and pd.BillID=@nBillID)
                  if @IntegralTotal<0  return -16 
                end
*/
                /*if exists(select vip.id 
                           from VipDetail vip,BillIdx bi, MemberCard m 
                           where vip.Billid=bi.BillID and m.CardID=vip.CardID   
                             and vip.BillId=@nBillID and bi.BillType=12 and vip.aoid in (7,6) and vip.integral<0 and m.IntergralTotal<0) */    
                      
		return 0
GO
