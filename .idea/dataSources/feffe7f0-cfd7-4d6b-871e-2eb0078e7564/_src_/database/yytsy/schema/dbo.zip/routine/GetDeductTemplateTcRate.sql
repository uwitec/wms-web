
CREATE FUNCTION GetDeductTemplateTcRate
(
	@TId                INT,
	@Begin				DATETIME,
	@End				DATETIME,
	@EorY				INT,              /*0职员，1机构*/
	@FormulaType		INT,
	@CategoryId			INT,              /*类别Id或商品Id*/
	@BaseInfoId			INT,              /*职员Id或机构Id*/
	@BeginNum			numeric(25,8),
	@EndNum				numeric(25,8), 
	@Rate				numeric(25,8),
	@FormulaBeginDate	DATETIME,         /*特殊数量提成与特殊金额提成使用日期区间*/
	@FormulaEndDate	    DATETIME          /*特殊数量提成与特殊金额提成使用日期区间*/
)
RETURNS VARCHAR(800)
AS
BEGIN
	/*'3.25;66.459|94.34#65.3' 返回值格式：3.25张数；66.459行数(提成总基数)；94.34阶段基数；65.3阶段提成额*/
	DECLARE @sResult VARCHAR(800)
	DECLARE @Result numeric(25,8), @Temp numeric(25,8), @Sum  numeric(25,8), @BillCount numeric(25,8), @NotCX BIT
	SET @Result = 0
	SELECT @NotCX = NotCX FROM Deduct_Formula WHERE TId = @TId AND [Type] = @FormulaType
		
	IF (@EndNum <= 0) OR (@Rate <= 0)
	BEGIN
		/*不计算*/
		SET @BillCount = 0
		SET @Temp = 0
		SET @Sum = 0
		SET @Result = 0	
	END	
	ELSE
	BEGIN
	  /*XXX.根据自定义类别id，建立满足条件的商品临时表*/
	  
	  if @FormulaType in (1,2,3,4)
	  begin
	    DECLARE @cColName VARCHAR(100)
	    DECLARE @idlen int
	    set @cColName = ''
	    declare @TmpP TABLE ([pid] [int] NOT NULL DEFAULT(0))
	  
		DECLARE @info_ID INT
		DECLARE @classid varchar(100)
		DECLARE @szSql varchar(2000)
		SELECT @info_ID = Category_id,@classid = class_id
		FROM customCategory WHERE ID  = @CategoryId
	    
		IF @classid IS NULL SET @classid = ''
		set @idlen = LEN(@classid)
		if @idlen = 0 set @idlen = 2
   
		/*set @cColName = dbo.GetColName(@info_ID,'ProductCategory')  */
		if @info_ID = 1
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent1,@idlen) = @classid
		end
		else if @info_ID = 2
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent2,@idlen) = @classid
		end          
		else if @info_ID = 3
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent4,@idlen) = @classid
		end 
		else if @info_ID = 4
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent4,@idlen) = @classid
		end
		else if @info_ID = 5
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent5,@idlen) = @classid
		end
		else if @info_ID = 6
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent6,@idlen) = @classid
		end
		else if @info_ID = 7
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent7,@idlen) = @classid
		end
		else if @info_ID = 8
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent8,@idlen) = @classid
		end
		else if @info_ID = 9
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent9,@idlen) = @classid
		end
		else if @info_ID = 10
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent10,@idlen) = @classid
		end
		else if @info_ID = 11
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent11,@idlen) = @classid
		end
		else if @info_ID = 12
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent12,@idlen) = @classid
		end
		else if @info_ID = 13
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent13,@idlen) = @classid
		end
		else if @info_ID = 14
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent14,@idlen) = @classid
		end
		else if @info_ID = 15
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent15,@idlen) = @classid
		end
		else if @info_ID = 16
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent16,@idlen) = @classid
		end
		else if @info_ID = 17
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent17,@idlen) = @classid
		end
		else if @info_ID = 18
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent18,@idlen) = @classid
		end
		else if @info_ID = 19
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent19,@idlen) = @classid
		end
		else if @info_ID = 20
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent20,@idlen) = @classid
		end
		else if @info_ID = 21
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent21,@idlen) = @classid
		end
		else if @info_ID = 22
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent22,@idlen) = @classid
		end
		else if @info_ID = 23
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent23,@idlen) = @classid
		end
		else if @info_ID = 24
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent24,@idlen) = @classid
		end
		else if @info_ID = 25
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent25,@idlen) = @classid
		end
		else if @info_ID = 26
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent26,@idlen) = @classid
		end
		else if @info_ID = 27
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent27,@idlen) = @classid
		end
		else if @info_ID = 28
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent28,@idlen) = @classid
		end
		else if @info_ID = 29
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent29,@idlen) = @classid
		end
		
		else if @info_ID = 30
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent30,@idlen) = @classid
		end
		else if @info_ID = 31
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent31,@idlen) = @classid
		end
		else if @info_ID = 32
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent32,@idlen) = @classid
		end
		else if @info_ID = 33
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent33,@idlen) = @classid
		end
		else if @info_ID = 34
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent34,@idlen) = @classid
		end
		else if @info_ID = 35
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent35,@idlen) = @classid
		end
		else if @info_ID = 36
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent36,@idlen) = @classid
		end
		else if @info_ID = 37
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent37,@idlen) = @classid
		end
		else if @info_ID = 38
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent38,@idlen) = @classid
		end
		else if @info_ID = 39
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent39,@idlen) = @classid
		end
		
		else if @info_ID = 40
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent40,@idlen) = @classid
		end
		else if @info_ID = 41
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent41,@idlen) = @classid
		end
		else if @info_ID = 42
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent42,@idlen) = @classid
		end
		else if @info_ID = 43
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent43,@idlen) = @classid
		end
		else if @info_ID = 44
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent44,@idlen) = @classid
		end
		else if @info_ID = 45
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent45,@idlen) = @classid
		end
		else if @info_ID = 46
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent46,@idlen) = @classid
		end
		else if @info_ID = 47
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent47,@idlen) = @classid
		end
		else if @info_ID = 48
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent48,@idlen) = @classid
		end
		else if @info_ID = 49
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent49,@idlen) = @classid
		end
		else if @info_ID = 50
		begin
			INSERT INTO @TmpP(pid) 
			select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.PComent50,@idlen) = @classid
		end
	  end
			
		IF @EorY = 0
		BEGIN
			/*职员*/
			IF @FormulaType = 0 /*单品提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN a.billtype IN (11, 13, 151, 153) THEN -a.quantity ELSE a.quantity END)
				FROM   (
				           SELECT b.billtype, bi.p_id, bi.batchno, bi.quantity
				           FROM   billidx b,
				                  salemanagebill bi
				           WHERE  b.billid = bi.bill_id
				                  AND b.billstates = 0
				                  AND bi.AOID = 0
				                  AND bi.p_id = @CategoryId
				                  AND b.billdate BETWEEN @Begin AND @End
				                  AND bi.RowE_id = @BaseInfoId
				                  AND b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
				       ) a
				       INNER JOIN (
				                SELECT b.CategoryId, b.BatchNo
				                FROM Deduct_Formula a, Deduct_FormulaDetail b
				                WHERE a.FId = b.FId AND a.TId = @TId AND a.[Type] = @FormulaType AND b.CategoryId = @CategoryId
				            ) b
				            ON  a.p_id = b.CategoryId
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 1/*销售金额提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN (b.billtype IN (11, 13, 151, 153)) 
				                  THEN -(CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE s.taxtotal END) ELSE 
				                  	     (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE s.taxtotal END) END) 	
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND s.p_id > 0 AND b.e_id = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id IN (SELECT pid FROM @TmpP) 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 2/*回款金额提成*/
			BEGIN
				SELECT @Sum = SUM(a.jstotal)
				FROM ( 
					/*
					SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF("d", b.billdate, bb.billdate) > c.sklimit THEN 0 ELSE j.jstotal END) 
					       ELSE j.jstotal END AS jstotal 
					FROM jsbdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.e_id = @BaseInfoId AND
					      b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND bb.BillDate BETWEEN @Begin AND @End
					UNION ALL
					*/
                    SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 
                                ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE j.jstotal END) END) 
					       ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE j.jstotal END) END AS jstotal
					FROM jspdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					                 INNER JOIN salemanagebill s ON j.detail_id = s.smb_id AND j.xsd_bid = s.bill_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.e_id = @BaseInfoId AND 
						  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
						  bb.BillDate BETWEEN @Begin AND @End AND 
						  s.p_id IN (SELECT pid FROM @TmpP) 
				) a 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END	
			END
			ELSE
			IF @FormulaType = 3 /*销售毛利提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN (b.billtype IN (11, 13, 151, 153)) 
				                  THEN -(CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (s.TaxTotal -s.costtaxtotal) END) ELSE 
				                  	     (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (s.TaxTotal -s.costtaxtotal) END) END)	
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND s.p_id > 0 AND b.e_id = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND
					  s.p_id IN (SELECT pid FROM @TmpP)  	
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 4 /*回款毛利提成*/
			BEGIN
				SELECT @Sum = SUM(a.jstotal)
				FROM ( 
					SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 
                           ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE 
                           (CASE WHEN j.billtype IN (11, 13, 151, 153) THEN -(ABS(j.jstotal) - s.costtaxtotal) ELSE j.jstotal -s.costtaxtotal END) END) END) 
					       ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (
						       (CASE WHEN j.billtype IN (11, 13, 151, 153) THEN -(ABS(j.jstotal) - s.costtaxtotal) ELSE j.jstotal -s.costtaxtotal END)   	
					       ) END)
					       END AS jstotal
					FROM jspdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					                 INNER JOIN salemanagebill s ON j.detail_id = s.smb_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.e_id = @BaseInfoId AND 
						  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
						  bb.BillDate BETWEEN @Begin AND @End AND 
						  s.p_id IN (SELECT pid FROM @TmpP) 
				) a 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 5 /*单据量提成			*/
			BEGIN
				SELECT @Sum = COUNT(*)
                FROM   (   SELECT b.inputman FROM billidx b, buymanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND
                                 b.billdate BETWEEN @Begin AND @End AND b.inputman = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
                           UNION ALL
                           SELECT b.inputman FROM billidx b, salemanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND
                                 b.billdate BETWEEN @Begin AND @End AND b.inputman = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
                           UNION ALL
                           SELECT b.inputman FROM orderidx b, OrderBill bi 
                           WHERE b.billid = bi.bill_id AND b.billdate BETWEEN @Begin AND @End AND 
                                 b.billstates IN (0, 3) AND b.order_id = 0 AND b.inputman = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) 
                           UNION ALL
                           SELECT b.inputman FROM GSPbillidx b, GSPbilldetail bi 
                           WHERE b.Gspbillid = bi.Gspbill_id AND b.billdate BETWEEN @Begin AND @End AND 
                                 b.billstates = 15 AND b.inputman = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)             
                       )a
               	IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 6 /*特殊数量提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN b.billtype IN (11, 13, 151, 153) THEN -s.quantity ELSE s.quantity END)
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND b.e_id = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id = @CategoryId 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 7 /*特殊金额提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN b.billtype IN (11, 13, 151, 153) THEN -s.taxtotal ELSE s.taxtotal END)
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND b.e_id = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id = @CategoryId 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
						  if @BeginNum = 0     /*修改 提成起始金额0开始 提成基数+1问题 Wsj 2016.09.27 bug 41347*/
						  begin
						    set @Temp = @EndNum
						  end
						  else
						  begin
							SET @Temp = @EndNum - @BeginNum + 1
						  end
						END
						ELSE
						BEGIN
						 if @BeginNum = 0
						 begin
						    set @Temp = @Sum
						 end
						 else
						 begin
							SET @Temp = @Sum - @BeginNum + 1
						 end
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END	
			END
			ELSE
			IF @FormulaType = 8 /*批次提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN a.billtype IN (11, 13, 151, 153) THEN -a.quantity ELSE a.quantity END)
				FROM   (
				           SELECT b.billtype, bi.p_id, bi.batchno, bi.quantity
				           FROM   billidx b,
				                  salemanagebill bi
				           WHERE  b.billid = bi.bill_id
				                  AND b.billstates = 0
				                  AND bi.p_id = @CategoryId
				                  AND b.billdate BETWEEN @Begin AND @End
				                  AND b.e_id = @BaseInfoId
				                  AND b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
				       ) a
				       INNER JOIN (
				                SELECT b.CategoryId, b.BatchNo
				                FROM Deduct_Formula a, Deduct_FormulaDetail b
				                WHERE a.FId = b.FId AND a.TId = @TId AND a.[Type] = @FormulaType AND b.CategoryId = @CategoryId
				            ) b
				            ON  a.p_id = b.CategoryId
				            AND a.batchno = b.BatchNo
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
		END
		ELSE
		IF @EorY = 1
		BEGIN
			/*机构*/
			IF @FormulaType = 0 /*单品提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN a.billtype IN (11, 13, 151, 153) THEN -a.quantity ELSE a.quantity END)
				FROM   (
				           SELECT b.billtype, bi.p_id, bi.batchno, bi.quantity
				           FROM   billidx b,
				                  salemanagebill bi
				           WHERE  b.billid = bi.bill_id
				                  AND b.billstates = 0
				                  AND bi.AOID = 0
				                  AND bi.p_id = @CategoryId
				                  AND b.billdate BETWEEN @Begin AND @End
				                  AND b.Y_ID = @BaseInfoId
				                  AND b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
				       ) a
				       INNER JOIN (
				                SELECT b.CategoryId, b.BatchNo
				                FROM Deduct_Formula a, Deduct_FormulaDetail b
				                WHERE a.FId = b.FId AND a.TId = @TId AND a.[Type] = @FormulaType AND b.CategoryId = @CategoryId
				            ) b
				            ON  a.p_id = b.CategoryId
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 1/*销售金额提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN (b.billtype IN (11, 13, 151, 153)) 
				                  THEN -(CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE s.taxtotal END) ELSE 
				                  	     (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE s.taxtotal END) END) 	
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND s.p_id > 0 AND b.Y_ID = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id IN (SELECT pid FROM @TmpP) 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 2/*回款金额提成*/
			BEGIN
				SELECT @Sum = SUM(a.jstotal)
				FROM ( 
					/*
					SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF("d", b.billdate, bb.billdate) > c.sklimit THEN 0 ELSE j.jstotal END) 
					       ELSE j.jstotal END AS jstotal 
					FROM jsbdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.e_id = @BaseInfoId AND
					      b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND bb.BillDate BETWEEN @Begin AND @End
					UNION ALL
					*/
                    SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 
                                ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE j.jstotal END) END) 
					       ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE j.jstotal END) END AS jstotal
					FROM jspdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					                 INNER JOIN salemanagebill s ON j.detail_id = s.smb_id AND j.xsd_bid = s.bill_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.Y_ID = @BaseInfoId AND 
						  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
						  bb.BillDate BETWEEN @Begin AND @End AND 
						  s.p_id IN (SELECT pid FROM @TmpP) 
				) a 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 3 /*销售毛利提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN (b.billtype IN (11, 13, 151, 153)) 
				                  THEN -(CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (s.TaxTotal -s.costtaxtotal) END) ELSE 
				                  	     (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (s.TaxTotal - s.costtaxtotal) END) END)	
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @Begin AND @End AND b.BillStates = 0 AND s.p_id > 0 AND b.Y_ID = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND
					  s.p_id IN (SELECT pid FROM @TmpP) 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END	
			END
			ELSE
			IF @FormulaType = 4 /*回款毛利提成*/
			BEGIN
				SELECT @Sum = SUM(a.jstotal)
				FROM ( 
					SELECT CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 
                           ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE 
                           (CASE WHEN j.billtype IN (11, 13, 151, 153) THEN -(ABS(j.jstotal) - s.costtaxtotal) ELSE j.jstotal -s.costtaxtotal END) END) END) 
					       ELSE (CASE WHEN (s.CxGuid <> '00000000-0000-0000-0000-000000000000' AND @NotCX = 1) THEN 0 ELSE (
						       (CASE WHEN j.billtype IN (11, 13, 151, 153) THEN -(ABS(j.jstotal) -s.costtaxtotal) ELSE j.jstotal -s.costtaxtotal END)   	
					       ) END)
					       END AS jstotal
					FROM jspdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					                 INNER JOIN salemanagebill s ON j.detail_id = s.smb_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND bb.Y_ID = @BaseInfoId AND 
						  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
						  bb.BillDate BETWEEN @Begin AND @End AND 
						  s.p_id IN (SELECT pid FROM @TmpP) 
				) a 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END	
			END
			ELSE
			IF @FormulaType = 5 /*单据量提成			*/
			BEGIN
				SELECT @Sum = COUNT(*)
                FROM   (   SELECT b.inputman FROM billidx b, buymanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND
                                 b.billdate BETWEEN @Begin AND @End AND b.Y_ID = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
                           UNION ALL
                           SELECT b.inputman FROM billidx b, salemanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND
                                 b.billdate BETWEEN @Begin AND @End AND b.Y_ID = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
                           UNION ALL
                           SELECT b.inputman FROM orderidx b, OrderBill bi 
                           WHERE b.billid = bi.bill_id AND b.billdate BETWEEN @Begin AND @End AND 
                                 b.billstates IN (0, 3) AND b.order_id = 0 AND b.Y_ID = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) 
                           UNION ALL
                           SELECT b.inputman FROM GSPbillidx b, GSPbilldetail bi 
                           WHERE b.Gspbillid = bi.Gspbill_id AND b.billdate BETWEEN @Begin AND @End AND 
                                 b.billstates = 15 AND b.Y_ID = @BaseInfoId AND bi.p_id > 0 AND
                                 b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)             
                       )a
               	IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 6 /*特殊数量提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN b.billtype IN (11, 13, 151, 153) THEN -s.quantity ELSE s.quantity END)
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @FormulaBeginDate AND @FormulaEndDate AND b.BillStates = 0 AND b.Y_ID = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id = @CategoryId 
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 7 /*特殊金额提成*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN b.billtype IN (11, 13, 151, 153) THEN -s.taxtotal ELSE s.taxtotal END)
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id 
				WHERE b.billdate BETWEEN @FormulaBeginDate AND @FormulaEndDate AND b.BillStates = 0 AND b.Y_ID = @BaseInfoId AND
					  b.billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType) AND 
					  s.p_id = @CategoryId
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
						     if @BeginNum = 0  /*修改 提成起始金额0开始 提成基数+1问题 Wsj 2016.09.27 bug 41347*/
						     begin
						       set @Temp = @EndNum
						     end
						     else
						     begin
							   SET @Temp = @EndNum - @BeginNum + 1
							 end
						END
						ELSE
						BEGIN
						    if @BeginNum = 0 
						    begin
						      set @Temp = @Sum
						    end
						    else
						    begin
							  SET @Temp = @Sum - @BeginNum + 1
							end
						END
						SET @Result = @Result + (@Temp / 100 * @Rate)
					END 	
				END
			END
			ELSE
			IF @FormulaType = 8 /*批次提成		*/
			BEGIN
				SELECT @Sum = SUM(CASE WHEN a.billtype IN (11, 13, 151, 153) THEN -a.quantity ELSE a.quantity END)
				FROM   (
				           SELECT b.billtype, bi.p_id, bi.batchno, bi.quantity
				           FROM   billidx b,
				                  salemanagebill bi
				           WHERE  b.billid = bi.bill_id
				                  AND b.billstates = 0
				                  AND bi.p_id = @CategoryId
				                  AND b.billdate BETWEEN @Begin AND @End
				                  AND b.Y_ID = @BaseInfoId
				                  AND b.Billtype IN (SELECT VchType FROM Deduct_TemplateVchType WHERE FormulaType = @FormulaType)
				       ) a
				       INNER JOIN (
				                SELECT b.CategoryId, b.BatchNo
				                FROM Deduct_Formula a, Deduct_FormulaDetail b
				                WHERE a.FId = b.FId AND a.TId = @TId AND a.[Type] = @FormulaType AND b.CategoryId = @CategoryId
				            ) b
				            ON  a.p_id = b.CategoryId
				            AND a.batchno = b.BatchNo
				IF @Sum > 0
				BEGIN
					IF @Sum >= @BeginNum
					BEGIN
						IF @Sum >= @EndNum
						BEGIN
							SET @Temp = @EndNum - @BeginNum + 1
						END
						ELSE
						BEGIN
							SET @Temp = @Sum - @BeginNum + 1
						END
						SET @Result = @Result + (@Temp * @Rate)
					END 	
				END
			END
		END
	END	
	IF @FormulaType <> 5
		SET @BillCount = 0
	IF @BillCount IS NULL
		SET @BillCount = 0
	IF @Sum IS NULL
		SET @Sum = 0
	IF @Temp IS NULL
		SET @Temp = 0	
	IF @Result IS NULL
		SET @Result = 0	
				
	SET @sResult = CAST(@BillCount AS VARCHAR) + ';' + CAST(@Sum AS VARCHAR) + '|' + CAST(@Temp AS VARCHAR) + '#' + CAST(@Result AS VARCHAR)			
	
	RETURN @sResult	
END
GO
