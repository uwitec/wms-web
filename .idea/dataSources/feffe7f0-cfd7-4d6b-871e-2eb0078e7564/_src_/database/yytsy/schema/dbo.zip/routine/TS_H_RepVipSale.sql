/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2015-7-9*/
/* Description:	会员卡查询*/
/* =============================================*/
CREATE PROCEDURE TS_H_RepVipSale 
	@BeginDate	datetime = 0,
	@EndDate	datetime = 0,
	@Yid		int = 0
AS
BEGIN
	IF @BeginDate IS NULL SET @BeginDate = 0
	IF @EndDate IS NULL SET @EndDate = '9999-12-31'
	IF @Yid IS NULL SET @Yid = 0

	SELECT   y.name, a1.taxtotal, a2.taxtotal AS VipTaxTotal, a2.taxtotal / a1.taxtotal * 100 AS VipSalePart, b_1.NewVipCount
	FROM      dbo.company AS y LEFT OUTER JOIN
		(SELECT   name, SUM(taxtotal * dir) AS taxtotal, Y_ID
			FROM      (SELECT   y.name, b.taxtotal, i.Y_ID, i.billtype, 1 - (i.billtype - 12) * 2 AS dir
							FROM      dbo.salemanagebill AS b INNER JOIN
											dbo.billidx AS i ON b.bill_id = i.billid INNER JOIN
											dbo.company AS y ON i.Y_ID = y.company_id
							WHERE   (i.billstates = '0') AND (i.billdate BETWEEN @BeginDate AND
											@EndDate) AND (i.billtype IN (12, 13)) AND (b.p_id > 0)) 
							AS a
			GROUP BY name, Y_ID) AS a1 ON y.company_id = a1.Y_ID LEFT OUTER JOIN
		(SELECT   name, SUM(taxtotal * dir) AS taxtotal, Y_ID
			FROM      (SELECT   y.name, b.taxtotal, i.Y_ID, i.billtype, 1 - (i.billtype - 12) * 2 AS dir
							FROM      dbo.salemanagebill AS b INNER JOIN
											dbo.billidx AS i ON b.bill_id = i.billid INNER JOIN
											dbo.company AS y ON i.Y_ID = y.company_id
							WHERE   (i.VIPCardID > 0) AND (i.billstates = '0') AND (i.billdate BETWEEN @BeginDate AND
											@EndDate) AND 
											(i.billtype IN (12, 13)) AND (b.p_id > 0)) AS a_1
			GROUP BY name, Y_ID) AS a2 ON a1.Y_ID = a2.Y_ID LEFT OUTER JOIN
		(SELECT   Y_ID, COUNT(VIPCardID) AS NewVipCount
			FROM      dbo.VIPCard
			WHERE   (BulidDate BETWEEN @BeginDate AND
											@EndDate)
			GROUP BY Y_ID
			HAVING   (Y_ID > 0)) AS b_1 ON a1.Y_ID = b_1.Y_ID
		WHERE (@Yid = 0 OR Y.company_id = @Yid) AND (y.child_number = 0) AND (y.deleted = 0)
END
GO
