
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-2*/
/* Description:	查询挂号单内容*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_SelRegisterBill]
	@BillID	int
AS
BEGIN
	SET NOCOUNT ON;

SELECT     dbo.vw_h_WorkPlan.WorkDay, dbo.vw_h_WorkPlan.dayPartName, dbo.vw_h_WorkPlan.DeptName, dbo.vw_h_WorkPlan.EmpName, 
                      dbo.Patients.Name, dbo.Patients.sex, dbo.Patients.Tel, dbo.Patients.Birthday, dbo.Patients.Job, dbo.Patients.Address, dbo.Patients.IDCard, 
                      dbo.Registered.Comment, dbo.GetAge(dbo.Patients.Birthday, dbo.Registered.RegDate) AS age
FROM         dbo.Registered INNER JOIN
                      dbo.vw_h_WorkPlan ON dbo.Registered.RegWorkPlan = dbo.vw_h_WorkPlan.Plan_ID INNER JOIN
                      dbo.Patients ON dbo.Registered.Patient_ID = dbo.Patients.PatientID
where      dbo.Registered.bill_id = @billID
END
GO
