
CREATE VIEW dbo.vw_L_Company
AS
SELECT c.*,
       isnull(YB.credit_total,0)credit_total,isnull(YB.sklimit,0)sklimit,isnull(YB.artotal,0)artotal,
       isnull(YB.artotal_ini,0)artotal_ini,  isnull(YB.aptotal,0)aptotal,isnull(YB.aptotal_ini,0)aptotal_ini,
       isnull(YB.pre_artotal,0)pre_artotal,  isnull(YB.pre_artotal_ini,0)pre_artotal_ini,
       isnull(YB.pre_aptotal,0)pre_aptotal,  isnull(YB.pre_aptotal_ini,0)pre_aptotal_ini,
       Ytypename=(case when c.Ytype=0 then '分公司'  when c.Ytype=1 then '门店' end),
       isnull(Y.name,'总公司') as superiorname
FROM dbo.company Y
right  join company c on Y.company_id = c.superior_id 
Left Join 
      (select C_id,MAX(credit_total)credit_total,MAX(sklimit)sklimit,sum(artotal)artotal,sum(artotal_ini)artotal_ini,
                   sum(aptotal)aptotal          ,sum(aptotal_ini)aptotal_ini            ,sum(pre_artotal)pre_artotal
                  ,sum(pre_artotal_ini)pre_artotal_ini,sum(pre_aptotal)pre_aptotal,sum(pre_aptotal_ini)pre_aptotal_ini
             from Companybalance where Y_id in (select sysvalue from sysconfig where [sysname]='Y_id') Group by C_id )YB on YB.c_id=c.company_id
GO
