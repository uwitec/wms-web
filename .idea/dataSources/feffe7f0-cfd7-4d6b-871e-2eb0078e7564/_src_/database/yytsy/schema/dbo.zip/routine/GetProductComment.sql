
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-5-13*/
/* Description:	根据商品数量获取备注*/
/* =============================================*/
CREATE FUNCTION [dbo].[GetProductComment] 
(
	@PID		int,
	@QTY		numeric(25,8)
)
RETURNS varchar(200)
AS
BEGIN
	DECLARE @Result varchar(200)
	declare @rate numeric(25,8)
	declare @unit varchar(50)
	
	set @Result = ''
	while @QTY > 0
	begin
		set @rate = 1
		select top 1 @rate = rate, @unit = name from(
		SELECT     1 AS rate, u1.name
		FROM         dbo.products AS p INNER JOIN
							  dbo.unit AS u1 ON p.unit1_id = u1.unit_id
		WHERE     (p.product_id = @PID)
		union all
		SELECT     rate2, u1.name
		FROM         dbo.products AS p INNER JOIN
							  dbo.unit AS u1 ON p.unit2_id = u1.unit_id
		WHERE     (p.product_id = @PID)
		union all
		SELECT     rate3, u1.name
		FROM         dbo.products AS p INNER JOIN
							  dbo.unit AS u1 ON p.unit3_id = u1.unit_id
		WHERE     (p.product_id = @PID)
		union all
		SELECT     rate4, u1.name
		FROM         dbo.products AS p INNER JOIN
							  dbo.unit AS u1 ON p.unit4_id = u1.unit_id
		WHERE     (p.product_id = @PID)) t
		where t.rate <= @qty
		order by t.rate desc
		if @rate <> 1
		begin
			set @Result = @Result + ISNULL(cast(floor(@QTY / @rate) as varchar) + '(' + @unit + '),', '')
			set @qty = @qty - floor(@QTY / @rate) * @rate
		end
		else
		begin
			set @Result = @Result + ISNULL(cast(cast(@QTY as real) as varchar) + '(' + @unit + '),', '')
			set @qty = @qty - @QTY
		end
	end
	if Len(@Result) > 0
		set @Result = substring(@Result, 1, Len(@Result) - 1)
	return @Result
END
GO
