


/*
--拆零方式:按批次排序方式
--拆零,生成的同价配送单自动过账.
*/

CREATE  procedure ts_M_SplitWholeQty
(
	@nP_id int,
	@nWholeSid int,
	@nOtherSid int,
	@nE_id	int,
	@Y_id int,
	@nLocid int,
	@draft int = 0    /*-是否存草稿 0 不存草稿，1 存草稿 */
)
/*with encryption*/
AS
DECLARE @WholeUnit_id int,
	@BatchOrder int, 
	@SplitQty NUMERIC(25,8),
	@unit1_id int,@unit2_id int,@unit3_id int,@unit4_id int,
	@WholeRate NUMERIC(25,8),
	@WhOleQty  numeric(25,8),
	@storehouse_id int,
	@bill_id int,
	@batchno varchar(100),
	@costprice NUMERIC(25,8),@costtotal NUMERIC(25,8),
	@makedate datetime,@validdate datetime,
  	@nReturnNumber int ,
	@location_id int ,
	@supplier_id int,@commissionflag int,
        @MinDate datetime, @instoretime datetime,
    @nBillCount int,
    @nProduct_id int,
    @szBillnumber varchar(30),
	@nBatchPrice NUMERIC(25,8),
	@sBatchBarcode varchar(30),
	@sComment varchar(80),
	@FactoryId int,
	@costtaxprice NUMERIC(25,8),
	@costtaxrate NUMERIC(25,8),
	@costtaxtotal NUMERIC(25,8)

SET 	@WholeUnit_id=0
SET 	@BatchOrder=0
SET 	@SplitQty=0  /*--判断整货库中,整货数量是否够拆零*/
SET	@nReturnNumber=0
SET 	@location_id=0
SET 	@supplier_id=0
SET	@commissionflag=0
SET     @MinDate = '1900-01-01'
set @nProduct_id=@nP_id

DECLARE @GetDate varchar(20)
select @GetDate =(cast( YEAR (getdate()) as varchar(4))+'-'+cast( MONTH (getdate()) as varchar(4))
	+'-'+ cast( DAY (getdate()) as varchar(4)) )

IF not Exists(select * from storages where storage_id=@nWholeSid and WholeFlag=1) 
BEGIN
   RAISERROR ('"整货仓库类型"设置不正确,请检查!', 16, 1)
   return -1
END

IF not Exists(select * from storages where storage_id=@nOtherSid and WholeFlag=2) 
BEGIN
   RAISERROR ('"零货仓库类型"设置不正确,请检查!', 16, 1)
   return -1
END

/*整货单位换算比率*/
select 	@WholeUnit_id=WholeUnit_id,@unit1_id=unit1_id,@unit2_id=unit2_id,
	@unit3_id=unit3_id,@unit4_id=unit4_id 
from products where product_id=@nP_id

if (@WholeUnit_id=@unit1_id) or (@WholeUnit_id=0) 
    select @WholeRate=1
if (@WholeUnit_id=@unit2_id) 
    select @WholeRate=rate2  from products where product_id=@nP_id 
if (@WholeUnit_id=@unit3_id) 
    select @WholeRate=rate3  from products where product_id=@nP_id 
if (@WholeUnit_id=@unit4_id) 
    select @WholeRate=rate4  from products where product_id=@nP_id 
    
if @WholeRate=0 set @WholeRate=1
set @WhOleQty=1*@WholeRate
/*拆零方式:按批次排序方式*/
select @BatchOrder=isnull(sysvalue,0) from sysconfig where sysname='BatchOrder'

/*判断整货库中,整货数量是否够拆零 */
IF @BatchOrder=0
BEGIN
   	select top 1 @SplitQty=quantity,@storehouse_id=storehouse_id from storehouse 
	where s_id=@nWholeSid and p_id=@nP_id and Y_ID = @Y_id
	      and ((quantity/@WholeRate)>=1) and (validdate > getdate()  or validdate <= @MinDate)
	order by validdate 
END ELSE 
BEGIN
   	select top 1 @SplitQty=quantity,@storehouse_id=storehouse_id from storehouse 
	where s_id=@nWholeSid and p_id=@nP_id and Y_ID = @Y_id
	      and ((quantity/@WholeRate)>=1) and (validdate > getdate()  or validdate <= @MinDate)   
	order by storehouse_id 
END
IF (@SplitQty<=0)
BEGIN
   RAISERROR ('"整货仓库"拆零数量不够,请检查!', 16, 1)
   return -1
END

/*判断可开数量 add by luowei 2013-09-23*/
set @storehouse_id = 0
select top 1 @storehouse_id = isnull(batchid,0)  from (
  	SELECT s.storehouse_id AS batchid,s.quantity,(s.quantity+ISNULL(o.quantity,0)+isnull(saleqty,0)) as salequantity,s.costtotal,
        s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,s.stopsaleflag,s.supplier_id,s.location_id,s.y_id,
        ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,s.instoretime,tx.name as taxrate,s.s_id as s_id,p.Factory,p.comment,
        st.Name as sName
	,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,
	batchbarcode,scomment,batchprice
			 FROM 
			 (
			   select storehouse_id,S.location_id,S.s_id,S.p_id,S.supplier_id,S.quantity,isnull(MX.quantity,0) as saleqty,0 as nowqty,S.costprice,costtotal,S.batchno,S.makedate,S.instoretime,
			   S.validdate,S.commissionflag,stopsaleflag,S.Y_ID,BatchBarCode,scomment,batchprice,inorder from storehouse s
	            left join 
	            (
	              select p_id,location_id2 as location_id,sd_id as s_id,supplier_id,costprice,batchno,makedate,instoretime,validdate,commissionflag,Y_ID
	              ,SUM(quantity) as quantity from storemanagebilldrf where exists(select 1 from billdraftidx idx where idx.billid = bill_id and billtype = 44)
	              group by p_id,location_id2,sd_id,supplier_id,costprice,batchno,makedate,
	              instoretime,validdate,commissionflag,Y_ID
	            ) MX  on mx.p_id = s.p_id and mx.location_id = s.location_id and mx.s_id = s.s_id and mx.supplier_id = s.supplier_id
	      	    and mx.costprice = s.costprice and mx.batchno = s.batchno and mx.makedate = s.makedate and mx.instoretime = s.instoretime and mx.validdate = s.validdate and
	      	    mx.commissionflag = s.commissionflag and mx.Y_ID = s.Y_ID
	            union all
	            select  -99 as storehouse_id,location_id2 as location_id,sd_id as s_id,mx.p_id,mx.supplier_id,0 as quantity,sum(mx.quantity) as saleqty,sum(isnull(s.quantity,0)) as nowqty,mx.costprice,
	      	    0 as costtotal,mx.batchno,mx.makedate,mx.instoretime,mx.validdate,mx.commissionflag,0 as stopsaleflag,mx.y_id,
	      	    '' as batchbarcode,'由同价调拨草稿生成' as scomment,0 as batchprice,99999999 as inorder
	      	    from storemanagebilldrf mx 
	      	    left join storehouse s on mx.p_id = s.p_id and mx.location_id2 = s.location_id and mx.sd_id = s.s_id and mx.supplier_id = s.supplier_id
	      	    and mx.costprice = s.costprice and mx.batchno = s.batchno and mx.makedate = s.makedate and mx.instoretime = s.instoretime and mx.validdate = s.validdate and
	      	    mx.commissionflag = s.commissionflag and mx.Y_ID = s.Y_ID 
	      	    where exists(select 1 from billdraftidx idx where idx.billid = mx.bill_id and billtype = 44)
	      	    group by location_id2,sd_id,mx.p_id,mx.supplier_id,mx.costprice,mx.batchno,mx.makedate,mx.instoretime,mx.validdate,mx.commissionflag,mx.y_id 
			 ) s 
				LEFT JOIN 
				clients c ON s.supplier_id=c.client_id 
				LEFT JOIN locatiON l ON s.location_id=l.loc_id 
				LEFT JOIN Storages st ON s.s_id=st.storage_id				
				LEFT JOIN dbo.outbatchByP(@nP_id) o
				ON o.p_id=s.p_id and o.s_id=s.s_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate 
        AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime = s.instoretime
        LEFT JOIN 
        products p ON s.P_ID=p.product_ID
        left   join 
	    (
			select P_id as baseinfo_id,name from ProductCategory p  
			inner join customCategory c on p.PComent2 = c.class_id
			and c.deleted = 0 and Child_Number = 0 and Category_id = 2
	     )tx on p.product_id = tx.baseinfo_id
	LEFT JOIN ForbiddenBatch FB 
		ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
		WHERE 
		s.stopsaleflag=0 and s.p_id=@nP_id  and s.Y_ID=@Y_id and st.WholeFlag=1 
) tb where salequantity > 0 and salequantity>=@WhOleQty and s_id = @nWholeSid  order by validdate,makedate		


    if @storehouse_id = 0 
	begin
	    declare @szPname varchar(20)
	    declare @szError varchar(100)
	    select @szPname = name from products where product_id = @nP_id
		set @szError = '商品【'+@szPname+'】的开票数量大于可开数量，可能出现负库存。' 
		raiserror(@szError,16,1) 
		return -100
	end			



/*拆零,生成的同价配送单自动过账. select * from storehouse*/
select  @costtotal=@WholeRate*costprice,@batchno=batchno,@costprice=costprice,@makedate=makedate,
	@validdate=validdate,@supplier_id=supplier_id,@location_id=location_id,
	@commissionflag=commissionflag, @instoretime = instoretime, @nBatchPrice = batchprice, @sBatchBarcode = BatchBarCode,
	@sComment = scomment,@FactoryId=FactoryId,@costtaxprice=costtaxprice,@costtaxrate=taxrate,@costtaxtotal=costtaxtotal
from storehouse where storehouse_id=@storehouse_id 

/*set @nBillCount=0
select @nBillCount=isnull(SNCount,0) from BillSNStyle where billtype=44 and Y_ID=0 --取得单据计数，生成单据编号
set @nBillCount=@nBillCount+1
set @szBillnumber=''
*/
exec TS_H_CreateBillSN 44, 1, null, @nE_id, 0, @szBillnumber output, @Y_id

/*set @szBillnumber='TJ'+'-'+CONVERT(varchar(10),GETDATE(),21)+'-'+CAST(@nBillCount as varchar)*/

/*------------------------启用库管流程，生成的调拨单草稿状态置为未审核 add by luowei 2013-08-13*/
declare @billtype  int
declare @auditman int
set @billtype = 3
set @auditman = @nE_id
if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and (@draft = 1)
begin
  set @auditman = 0 
  set @billtype = 2
end

/*货位跟踪*/
if @nLocid=0 
begin
  select @nLocid=isnull(l_id,0) from locationtrace where p_id=@nP_id and s_id=@nOtherSid and billtype=44 and y_id=@Y_id 
end

/* 货位跟踪不成功取默认零货货位*/
if @nLocid = 0
	select @nLocid = pb.SingleLoc
	FROM      dbo.productbalance AS pb INNER JOIN
					dbo.location AS l ON pb.SingleLoc = l.loc_id
	WHERE   (l.s_id = @nOtherSid) AND (pb.Y_id = @Y_id) AND (pb.p_id = @nP_id)

INSERT INTO BillDraftidx
(
billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id,ZBAuditMan,ZBAuditDate
)
VALUES
(
@GetDate ,@szBillnumber,44,0,0,@nE_id,@nWholeSid,@nOtherSid,@auditman,@nE_id,
@costtotal  ,@costtotal  ,0,1*@WholeRate , 0  ,0	,@billtype ,0 ,
0,0  ,0 ,0 ,0  ,0,'自动拆零'  ,'' ,
0,0 ,'',0, 0,0,1*@WholeRate,0,@Y_id,0,'1900-01-01'
)

SET  @bill_id=@@IDENTITY

INSERT INTO storemanageBilldrf
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice,costtotal  ,price ,totalmoney  ,retailprice  ,
 retailmoney  ,makedate  ,validdate  ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,
 commissionflag  ,comment  ,unitid ,location_id2, qualitystatus,iotag, total, invoiceTotal , 
  OrgBillID,Aoid,SendQTY,SendCostTotal,Y_id, instoretime, BatchBarCode, scomment, batchprice,
 FactoryId,costtaxprice,costtaxrate,costtaxtotal 
)
VALUES
(
 @bill_id  ,@nP_id  ,@batchno  ,1*@WholeRate  ,@costprice,@costtotal  ,@costprice ,@costtotal  ,0  ,
 0 , @makedate  ,@validdate  ,0	,@nWholeSid  ,@nOtherSid  ,@location_id  ,@supplier_id  ,
 @commissionflag ,'自动拆零'	,@unit1_id  ,@nLocid, '合格',0, @costtotal, 0 ,
 0,0,1*@WholeRate,@costtotal,@Y_id, @instoretime, @sBatchBarcode, @sComment, @nBatchPrice,
 @FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
IF @@ROWCOUNT=0 Goto SysError

/*自动过账*/
if (@draft = 0)
begin 
	EXECUTE ts_c_BillAudit @bill_id,@nP_id output,@nReturnNumber output,44
	IF @nReturnNumber<>0 Goto SysError
end
/*增加单据编号计数*/
update BillSNStyle  set SNCount=SNCount+1 where billtype=44 and Y_ID=@Y_id

/*更新货位跟踪*/
if exists (  select * from locationtrace where p_id=@nProduct_id and s_id=@nOtherSid and billtype=44 and y_id=@Y_id and l_id = @nLocid) and @nLocid<>0
  update LocationTrace set l_id=@nLocid where p_id=@nProduct_id and s_id=@nOtherSid and billtype=44 and y_id=@Y_id and l_id = @nLocid
else if @nLocid<>0
  insert LocationTrace(p_id,s_id,l_id,billtype,y_id)
  values
  (@nProduct_id,@nOtherSid,@nLocid,44,@Y_id)

 IF @@ERROR=0

RETURN @bill_id


SysError:
	EXEC Ts_b_DeleteBillDraft @nReturnNumber output, 2, @bill_id
	RAISERROR ('自动生成的同价配送单错误!', 16, 1)
	RETURN -1
GO
