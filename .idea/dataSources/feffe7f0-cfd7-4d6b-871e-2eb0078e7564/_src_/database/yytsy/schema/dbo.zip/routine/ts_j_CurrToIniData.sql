
/*总部当前库存生成到期初数据*/
create proc ts_j_CurrToIniData
(
	@nY_id    		int = 0/*机构id号*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/
set nocount on
truncate table accountbalanceDts
truncate table ClientsbalanceDts
truncate table CompanybalanceDts
truncate table OtherStorehouseinidts
truncate table storebrrowinidts
truncate table storedxinidts
truncate table storehouseinidts

begin tran CreateIniData

if @nY_id = 0 /*总部传盘方式*/
begin
  insert into accountbalanceDts(y_id, a_id, ini_total) select y_id, a_id, cur_total from accountbalance
  
  insert into ClientsbalanceDts(Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id) 
    select Y_id, C_ID, credit_total, sklimit, artotal, aptotal, pre_artotal, pre_aptotal, e_id from Clientsbalance
  
  insert into CompanybalanceDts(y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini)
    select y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini from Companybalance
   
  insert into OtherStorehouseinidts(location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid)
    select location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid from OtherStorehouse
  
  insert into storebrrowinidts(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storebrrow
  
  insert into storedxinidts(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storedx
  
  insert into storehouseinidts(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID)
    select location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID from storehouse
    where SendFlag = 0
      
end

if @nY_id<>0 /*远程登录 */
begin
  insert into accountbalanceDts(y_id, a_id, ini_total) select y_id, a_id, cur_total from accountbalance where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
  
  insert into ClientsbalanceDts(Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id) 
    select Y_id, C_ID, credit_total, sklimit, artotal, aptotal, pre_artotal, pre_aptotal, e_id from Clientsbalance where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
  
  insert into CompanybalanceDts(y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini)
    select y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini from Companybalance where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
   
  insert into OtherStorehouseinidts(location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid)
    select location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid from OtherStorehouse where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
  
  insert into storebrrowinidts(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storebrrow where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
  
  insert into storedxinidts(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
    select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storedx where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
  
  insert into storehouseinidts(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID)
    select location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID from storehouse where y_id in (select company_id from company where  superior_id = @nY_id or company_id = @nY_id)
    and SendFlag = 0
    
end
commit tran CreateIniData
return 0
GO
