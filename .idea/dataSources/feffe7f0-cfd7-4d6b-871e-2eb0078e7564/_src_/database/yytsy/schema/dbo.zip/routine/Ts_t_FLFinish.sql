Create procedure Ts_t_FLFinish
(@fcid int)
AS
declare @Rpid int 
  select @Rpid=RP_id from FLCondition where id=@fcid 
  update FLCondition set FLStates=2 where id=@fcid
  if not exists(select 1 from FLCondition where id=@fcid and FLStates=1)
    update RebehoofProtocol set States=2 where id=@Rpid
GO
