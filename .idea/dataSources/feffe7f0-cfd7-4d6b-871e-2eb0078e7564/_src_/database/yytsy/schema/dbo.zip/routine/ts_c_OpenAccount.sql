
/*exec ts_c_OpenAccount 2*/
CREATE PROCEDURE ts_c_OpenAccount
(
  @nPubY_ID int
)  
AS
  /*------Some account id*/
	declare 
		@Asset_Id 			int, 				/*2	【资产合计】*/
		@Products_Id 		int,				/*3	『库存商品总值合计』*/
		@FixedAsset_id 	int,				/*4	『固定资产合计』*/
		@FixedAsset1_id int,				/*5	 固定资产__甲*/
		@Cash_id 				int,				/*6	 现    金*/
																/*7	『全部银行存款合计』*/
																/*8	银行户头_1*/
		@ArTotal_Id 		int,				/*9	『应收款合计』*/
		@Lendout_Id 		int ,				/*10	『借出商品』*/
		@Dt_Expens_Id 	int,				/* 11	待摊费用*/
		@Wt_Comm_Id 		int,				/*12	委托代销商品*/
		@St_Comm_Id 		int,				/*13	受托代销商品*/
																/*14	【负债合计】*/
		@ApTotal_Id 		int,				/*15	『应付帐款合计』*/
		@Brrowin_Id 		int,				/*16	『借入商品』*/
		@DxTotal_Id 		int,				/*17	代销商品款*/
																/*18	应交税金*/
																/*19	【收入类】*/
		@SaleIncome_Id 	int					/*20	『销售收入』*/
																/*21	『商品类收入』*/
		/*Product_22	商品报溢收入
		
		23	商品获赠收入
		24	成本调价收入
		25	进货退货差价
		26	变价调拨差价
		27	商品拆装差价
		28	借转进货结算与成本差
		29	受托代销结算差价
		30	『其它收入』
		31	调帐收入
		32	利息收入
		33	其它....
		34	【支出类】
		35	『销售成本』
		36	『商品类支出』
		37	商品报损
		38	商品赠出
		39	『费用合计』
		40	调帐亏损
		41	固定资产折旧
		42	其它....
		43	【所有者权益】
		44	实收资本
		45	资本公积
		46	盈余公积
		47	本年利润
		48	利润分配
		49	【利润】
		54	进项税
		55	销项税
		*/

	select	@Asset_Id			=2				/*	【资产合计】*/
	select	@Products_Id	=3				/*	『库存商品总值合计』*/
	select	@FixedAsset_id=4  			/*	『固定资产合计』*/
	select	@Cash_id=6				  		/*	 现    金*/
															  	/*7	『全部银行存款合计』*/
																  /*8	银行户头_1*/
	select	@ArTotal_Id		=9				/*9	『应收款合计』*/
	select	@Lendout_Id		=10				/*10	『借出商品』*/
	select	@Dt_Expens_Id	=11			  /*11	待摊费用*/
	select	@Wt_Comm_Id		=12				/*12	委托代销商品*/
	select	@St_Comm_Id		=13				/*13	受托代销商品*/
																  /*14	【负债合计】*/
	select	@ApTotal_Id		=15				/*15	『应付帐款合计』*/
	select	@Brrowin_Id		=16				/*16	『借入商品』*/
	select	@DxTotal_Id		=17				/*17	代销商品款*/
																  /*18	应交税金*/
																  /*19	【收入类】*/
	select	@SaleIncome_Id=20			  /*20	『销售收入』*/
/*----------------*/
	declare @nLevealLen int
	declare @Y_ID int, @szYClassID varchar(30)
        select @Y_ID = cast(sysvalue as int) from sysconfig where upper([sysname]) = 'Y_ID'
        if @Y_ID = 0 or @Y_ID is null
        begin
 	  RAISERROR ('未指定当前机构，不允许开账！',16,1)
	  Return -1	
        end
        select @szYClassID = sysvalue from sysconfig where upper([sysname]) = 'YCLASSID'


begin tran openaccount
	select @nLevealLen=len(class_id) from account where account_id=1
	declare @OpenAccount int,@nCostingMethod int
	/*exec ts_GetSysValue 'OpenAccount',@szOpenAccount out*/
	select @OpenAccount = openaccount from Companybalance where y_id = @nPubY_ID and c_id = 0 
	if @OpenAccount=1 goto error
	if @Y_ID = @nPubY_ID
	  exec ts_SetSysValue 'OpenAccount','1',@nPubY_ID
	exec ts_SetSysValue 'AccountPeriod','1',@nPubY_ID
	set @Y_ID = @nPubY_ID


/*begin处理开账，将对应的自营店全部开账*/

  if object_id('tempdb..#OpenCompany') is not null
    drop table #OpenCompany

  select company_id as Y_ID into  #OpenCompany 
    from company 
    where (ytype = 1 and superior_id  = @Y_ID) or company_id = @Y_ID


    declare @nOpenY_ID int
    declare Open_Account cursor scroll for
	select Y_ID from #OpenCompany
	open Open_Account
	fetch next from Open_Account into @nOpenY_ID
	while @@FETCH_STATUS=0	
	begin
	
          Insert accountbalance(Y_id,a_id)
            select @nOpenY_ID, account_id from account
            where account_id not in (select a_id from accountbalance where Y_id=@nOpenY_ID)                 
         
	  if exists(select 1 from Companybalance where y_id = @nOpenY_ID and c_id = 0 and openaccount = 0)
	    update Companybalance set Openaccount = 1 where y_id = @nOpenY_ID and c_id = 0
	  else
	    insert into Companybalance(y_id, c_id, Openaccount) values(@nOpenY_ID, 0, 1)
	        
	  fetch next from Open_Account into @nOpenY_ID
	end
     Close Open_Account
     deallocate Open_Account
	   	        	       
/*end处理开账，将对应的自营店全部开账	    */
	    
	declare @dTotaltemp NUMERIC(25,8),@dTotaltempAp NUMERIC(25,8),@dTotaltempAr NUMERIC(25,8),@dAssetTotal NUMERIC(25,8),@dDebtTotal NUMERIC(25,8)
	
/*库存商品合计*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storehouseini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.y_id in (select Y_ID from #OpenCompany)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Products_Id and y_id = @Y_ID  
	if @@error<>0 goto error
/*受托代销商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storedxini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=2 and s.y_id in (select Y_ID from #OpenCompany)
/*	update account set ini_total=@dTotaltemp where account_id=@St_Comm_Id */
/*	if @@error<>0 goto error*/
	update accountbalance set ini_total=@dTotaltemp where a_id=@DxTotal_Id and y_id = @Y_ID
	if @@error<>0 goto error
/*委托代销商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storedxini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=1 and s.y_id in (select Y_ID from #OpenCompany)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Wt_Comm_Id and y_id = @Y_ID
	if @@error<>0 goto error
/*借进商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storebrrowini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=4 and s.y_id in (select Y_ID from #OpenCompany)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Brrowin_Id and y_id = @Y_ID
	if @@error<>0 goto error
/*	update account set ini_total=ini_total+@dTotaltemp where account_id=@Products_Id */
/*	if @@error<>0 goto error*/

/*借出商品	*/
	select @dTotaltemp=isnull(sum(s.costtotal),0) from products p,storebrrowini s 
	where p.product_id=s.p_id and p.deleted<>1 and s.commissionflag=3 and s.y_id in (select Y_ID from #OpenCompany)
	update accountbalance set ini_total=@dTotaltemp where a_id=@Lendout_Id and y_id = @y_id
	if @@error<>0 goto error
/*应收应付期初资产负债表*/
        /*往来单位	*/
	select @dTotaltempAp=isnull(sum(aptotal_ini),0),@dTotaltempAr=isnull(sum(artotal_ini),0) from clientsbalance 
	where  c_id in (select client_id from clients where deleted<>1 and child_number=0) and y_id = @Y_ID
	update accountbalance set ini_total=@dTotaltempAp where a_id=@ApTotal_Id and y_id = @Y_ID 
	if @@error<>0 goto error
	update accountbalance set ini_total=@dTotaltempAr where a_id=@ArTotal_Id and y_id = @Y_ID 
	if @@error<>0 goto error

	/*机构,自营店之间可能互相调货，需要特殊处理*/

        select @dTotaltempAp=isnull(sum(aptotal_ini),0),@dTotaltempAr=isnull(sum(artotal_ini),0) from companybalance 
	where  c_id in (select company_id from company where deleted=0 and child_number=0) and y_id = @y_id
	update accountbalance set ini_total= ini_total + @dTotaltempAp where a_id=@ApTotal_Id and y_id = @Y_ID 
	if @@error<>0 goto error
	update accountbalance set ini_total=ini_total + @dTotaltempAr where a_id=@ArTotal_Id and y_id = @Y_ID 
	if @@error<>0 goto error


/*资产合计	*/
	select @dAssetTotal=isnull(sum(ini_total),0) from accountbalance where a_id in (select account_id from account where left(class_id,@nLevealLen)='000001' and deleted=0 and child_number=0) and y_id = @y_id
	if @@error<>0 goto error
/*负债合计*/
	select @dDebtTotal=isnull(sum(ini_total),0) from accountbalance where a_id in(select account_id from account where left(class_id,@nLevealLen)='000002' and deleted=0 and child_number=0) and y_id =@y_id
	if @@error<>0 goto error
/*实收资本=资产－负债*/
	update accountbalance set ini_total=@dAssetTotal-@dDebtTotal where a_id in (select account_id from account where class_id='000005000001') and y_id = @y_id
	if @@error<>0 goto error
	
	update accountbalance Set cur_total=ini_total where y_id = @y_id
	if @@error<>0 goto error

	update clientsbalance set pre_artotal=pre_artotal_ini,pre_aptotal=pre_aptotal_ini,artotal=artotal_ini,aptotal=aptotal_ini where y_id = @y_id
	if @@error<>0 goto error
   
	/*注意处理互相调货*/
        update  companybalance set pre_artotal=pre_artotal_ini,pre_aptotal=pre_aptotal_ini,artotal=artotal_ini,aptotal=aptotal_ini where y_id = @y_id
	if @@error<>0 goto error

	update employees set artotal=0,aptotal=0 where y_id in (select Y_ID from #OpenCompany)
	if @@error<>0 goto error
	
	exec ts_getsysvalue 'UseSameCostMethod',@ncostingmethod out /*是否使用同一成本核算法*/
	if @ncostingmethod=1/*使用同一成本核算法*/
	begin
		exec ts_getsysvalue 'CostMethod',@ncostingmethod out
		if @ncostingmethod=0 
		begin
			insert into storehouse (p_id,s_id,quantity,costprice,costtotal,inorder, y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
			select p_id,s_id,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,
			sum(costtotal) as costtotal,0 as inorder, y_id,
			MAX(taxrate) as taxrate, (case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,
			SUM(costtaxtotal) as costtaxtotal,factoryid from storehouseini where y_id in (select Y_ID from #OpenCompany) group by p_id,s_id,y_id,factoryid
			if @@error<>0 goto error
			insert into storedx (p_id,c_id,commissionflag,quantity,costprice,costtotal,inorder,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
			select p_id,c_id,commissionflag,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,
			sum(costtotal) as costtotal,0 as inorder,y_id,
			MAX(taxrate) as taxrate,(case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,
			SUM(costtaxtotal) as costtaxtotal,factoryid from storedxini where y_id in (select Y_ID from #OpenCompany) group by p_id,c_id,commissionflag,y_id,factoryid
			if @@error<>0 goto error
			insert into storebrrow (p_id,c_id,commissionflag,quantity,costprice,costtotal,inorder,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
			select p_id,c_id,commissionflag,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,
			sum(costtotal) as costtotal,0 as inorder,y_id,
			MAX(taxrate) as taxrate,(case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,
			SUM(costtaxtotal) as costtaxtotal,factoryid from storebrrowini where y_id in (select Y_ID from #OpenCompany) group by p_id,c_id,commissionflag,y_id,factoryid
			if @@error<>0 goto error
		end 
		else
		begin
			insert into storehouse(location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,y_id,batchbarcode ,scomment ,batchprice,taxrate,costtaxprice,costtaxtotal,factoryid)
			select location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,y_id,batchbarcode ,scomment ,batchprice,
			taxrate as taxrate,costtaxprice,costtaxtotal as costtaxtotal,factoryid from storehouseini where y_id in (select Y_ID from #OpenCompany)
			if @@error<>0 goto error
			insert into storedx(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,batchbarcode ,scomment ,batchprice,taxrate,costtaxprice,costtaxtotal,factoryid) 
			select 0,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,batchbarcode ,scomment ,batchprice,
						taxrate as taxrate,costtaxprice,costtaxtotal,factoryid from storedxini where y_id in (select Y_ID from #OpenCompany)
			if @@error<>0 goto error
			insert into storebrrow(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
			select 0,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,
						taxrate as taxrate,costtaxprice,costtaxtotal,factoryid from storebrrowini where y_id in (select Y_ID from #OpenCompany)
			if @@error<>0 goto error
		end
	end else
	begin
		insert into storehouse (p_id,s_id,quantity,costprice,costtotal,inorder,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
		select p_id,s_id,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,sum(costtotal) as costtotal,0 as inorder,y_id,
		MAX(taxrate) as taxrate,(case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,SUM(costtaxtotal) as costtaxtotal,factoryid 
		from storehouseini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod='0') and y_id in (select Y_ID from #OpenCompany)
		group by p_id,s_id,y_id,factoryid
		if @@error<>0 goto error
		insert into storehouse(location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,y_id,batchbarcode ,scomment ,batchprice,taxrate,costtaxprice,costtaxtotal,factoryid)
		select location_id,p_id,s_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,yhdate,y_id,batchbarcode ,scomment ,batchprice,
		 taxrate, costtaxprice, costtaxtotal,factoryid
		from storehouseini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod<>'0') and y_id in (select Y_ID from #OpenCompany)
		if @@error<>0 goto error

		insert into storedx (p_id,c_id,commissionflag,quantity,costprice,costtotal,inorder,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
		select p_id,c_id,commissionflag,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,sum(costtotal) as costtotal,0 as inorder,y_id,MAX(taxrate) as taxrate,(case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,SUM(costtaxtotal) as costtaxtotal,factoryid
		from storedxini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod='0') and y_id in (select Y_ID from #OpenCompany)
		group by p_id,c_id,commissionflag,y_id,factoryid
		if @@error<>0 goto error
		insert into storedx(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,batchbarcode ,scomment ,batchprice,taxrate,costtaxprice,costtaxtotal,factoryid) 
		select 0,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,batchbarcode ,scomment ,batchprice,
		 taxrate, costtaxprice, costtaxtotal,factoryid
		from storedxini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod<>'0') and y_id in (select Y_ID from #OpenCompany)
		if @@error<>0 goto error

		insert into storebrrow (p_id,c_id,commissionflag,quantity,costprice,costtotal,inorder,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
		select p_id,c_id,commissionflag,sum(quantity) as quantity,(case sum(quantity) when 0 then 0 else sum(costtotal)/sum(quantity) end) as costprice,sum(costtotal) as costtotal,0 as inorder,y_id,MAX(taxrate) as taxrate,(case sum(quantity) when 0 then 0 else sum(costtaxtotal)/sum(quantity) end) as costtaxprice,SUM(costtaxtotal) as costtaxtotal,factoryid 
		from storebrrowini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod='0') and y_id in (select Y_ID from #OpenCompany)
		group by p_id,c_id,commissionflag,y_id,factoryid
		if @@error<>0 goto error
		insert into storebrrow(location_id,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,taxrate,costtaxprice,costtaxtotal,factoryid) 
		select 0,p_id,c_id,supplier_id,quantity,costprice,costtotal,batchno,makedate,validdate,instoretime,commissionflag,stopsaleflag,inorder,oldcommissionflag,y_id,
		 taxrate, costtaxprice,costtaxtotal,factoryid
		from storebrrowini 
		where p_id in (select product_id from products where child_number=0 and deleted<>1 and costmethod<>'0') and y_id in (select Y_ID from #OpenCompany)
		if @@error<>0 goto error
	end


  	insert into OtherStorehouse(p_id,quantity,y_id) select p_id,quantity,y_id from OtherStorehouseini where y_id in (select Y_ID from #OpenCompany)
        if Exists(select * from monthsettleinfo where Y_ID=@nPubY_ID )
	   update monthsettleinfo set begindate=convert(varchar(10),getdate(),20),period=1 where Y_ID in (select Y_ID from #OpenCompany)
	else 
	begin
	   declare @tmpbegindate varchar(50)
	   set @tmpbegindate =DATENAME (year,getdate())+'-'+DATENAME (month,getdate())+'-'+DATENAME (day,getdate())
	   INSERT INTO Monthsettleinfo([monthname], [begindate], [period], [comment],[Y_id])
    	   VALUES('本期', @tmpbegindate, 1, '',@nPubY_ID)
	end

    update sysconfig set sysvalue='1' where [sysname]='isupdatefiliale' 
       
	if @szYClassID <> '000001'
	if exists(select 1 from company where company_id = @y_id and Ytype <> 1)
    begin
      delete tasklistup where y_id = 0 and opertype = -99
      insert into tasklistup(y_id, opertype) values(@y_id, -100)
    end
 
   declare @YClass_id varchar(50)
   select @YClass_id=Class_id from company where Company_id=@nPubY_ID
   exec TS_C_QrZcfz 3,0,0,0,0,0,1,@YClass_id
commit tran openaccount
return 0

error:
	rollback tran openaccount
	return -1
GO
