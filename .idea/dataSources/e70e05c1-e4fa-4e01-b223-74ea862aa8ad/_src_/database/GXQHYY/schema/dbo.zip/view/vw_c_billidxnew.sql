/*
   赠品计算到总数量里面
*/

create view dbo.vw_c_billidxnew
as
select [billid]
      ,[billdate]
      ,[billnumber]
      ,[billtype]
      ,[a_id]
      ,[c_id]
      ,b.e_id
      ,sout_id= Case when b.billtype in (112,122) then 0 else b.sout_id end
      ,sin_id = Case when b.billtype in (112,122) then 0 else b.sin_id end
      ,b.[auditman]
      ,[inputman]
      ,[ysmoney]
      ,[ssmoney]
      /*,[quantity]*/
      ,isnull(xz.Tqty, 0) as  [quantity]
      ,[taxrate]
      ,[period]
      ,[billstates]
      ,[order_id]
      ,[department_id]
      ,b.[posid]
      ,b.region_id
      ,[auditdate]
      ,[skdate]
      ,[jsye]
      ,[jsflag]
      ,[note]
      ,[summary]
      ,[invoice]
      ,[transcount]
      ,[lasttranstime]
      ,[GUID]
      ,[InvoiceTotal]
      ,[InvoiceNO]
      ,[BusinessType]
      ,[jsInvoiceTotal]
      ,[SendQTY]
      ,[GatheringMan]
      ,[VIPCardID]
      ,[ArAptotal]
      ,b.Y_ID
      ,[transflag]
      ,[begindate]
      ,[Enddate]
      ,[integral]
      ,[integralYE]
      ,[B_CustomName1]
      ,[B_CustomName2]
      ,[B_CustomName3]
      ,[ImportJscw]
      ,[JscwGuid]
      ,[RetailDate]
      ,[sendC_id]
      ,[Sendid]
      ,[WholeQty]
      ,[PartQty],
      invoicetype=(
      case B.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.[name] else CY.[name] END), '') as cname,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.address else CY.opaddress end),'') as cAddress,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.contact_personal else CY.manager end), '') as cContact_personal,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.phone_Number else CY.tel end), '') as cPhone_Number,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.class_id else  CY.class_id end), '')cclass_id,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165) then clients.serial_number else CY.serial_number end), '')Cnumber, 
      isnull(dbo.account.name, '') as aname, isnull(dbo.employees.name, '') as ename,isnull(employees.serial_number, '')enumber,
      isnull(employees.dep_id,0)dep_id, isnull(dbo.account.class_id,'') as aclass_id,
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      isnull(ss.[name],'') as ssname, 
      isnull(sd.[name],'') as sdname,
      isnull(empg.[Name],'') as GatheringManName,
      isnull(empg.[class_id],'') as GatheringManclass_id,
      isnull(Y.Class_ID,'') as YClass_ID,
      isnull(Y.[name],'') as Yname,
      isnull((case when b.billtype in (150,151,152,153,155,160,161,162,163,165) then CY.Class_ID else '' end),'') as CYClass_ID,
      isnull(dbo.clients.RoadID, 0) as RoadID, isnull(dbo.clients.szOrdernum, '') as szOrdernum
      
from billidx b left outer join
      dbo.account on B.a_id = dbo.account.account_id left outer join
      dbo.clients on B.c_id = dbo.clients.client_id left outer join
      dbo.employees on B.e_id = dbo.employees.emp_id
      left outer join employees emp on B.inputman=emp.emp_id
      left outer join employees empa on B.auditman=empa.emp_id
      left outer join employees empg on B.gatheringman=empg.emp_id
      left outer join department dep on B.department_id=dep.departmentid
      left outer join region reg on B.region_id=reg.region_id
      left outer join storages ss on B.sout_id=ss.storage_id
      left outer join storages sd on B.sin_id=sd.storage_id
      left outer join Company  Y  on B.Y_id=Y.Company_id
      left Outer join Company  CY  on B.C_id=CY.company_id
      left Outer join
      ( 
      select bill_id,sum(quantity) as Tqty from salemanagebill 
      where p_id>0
      group by bill_id
      ) xz   on  B.billid=xz.bill_id
GO
