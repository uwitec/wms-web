

CREATE VIEW dbo.vw_c_mainstorage
AS
SELECT dbo.storages.*
FROM dbo.storages
WHERE (flag = 0) AND (deleted = 0) AND (child_number = 0)
GO
