


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

库存商品分布统计
最后的修改日期 2003-12-17

********************************************/
CREATE PROCEDURE TS_C_QrProductFb
(	@nP_ID       INT,
	@szParent_id VARCHAR(30),
	@szPeriod		 VARCHAR(1)='',
        @nYClassid                 varchar(100)='',
        @nloginEID               int=0,
    @AuthorizeC  int = 0        /*XXX.2016-11-11 TFS.42748 有的库存分布入口查询在开启定制开关就不做机构授权控制,100为不控制*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szPeriod is null  SET @szPeriod = ''
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @AuthorizeC is null  SET @AuthorizeC = 0

/*Params Ini end*/
  SET NOCOUNT ON

  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
  DECLARE @szPClass_id VARCHAR(30), @nSelOtherPos int
  select @nSelOtherPos = CAST(sysvalue as int) from sysconfigtmp where [sysname]  = 'SelOtherPos'
  if @nSelOtherPos is null set @nSelOtherPos = 0
  /*xzdong-2016-11-11-TFS42745-（科开）单品库存查询-库存分布增加‘零售价’和‘零售金额’*/
  declare @price numeric(25,8)
  if(@nP_ID<>0)
    select top 1 @price = retailprice from price  where p_id=@nP_ID order by unittype   /*XXX.2017-01-10 这儿在数据中存在基本单位的时候应该读取基本单位的价格*/
  else
    set @price = 0.0
    
 /*@nSelOtherPos =1 不判断授权*/
 
 declare @AuthorizeCompany int 
 
 select @AuthorizeCompany = sysvalue from sysconfigtmp where sysname = 'KK_AuthorizeCompany'
 if @AuthorizeCompany is null set @AuthorizeCompany = 0

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
      or (@nSelOtherPos = 1)
      or (@AuthorizeC = 100 and @AuthorizeCompany =1)
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
   
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000')
      or (@nSelOtherPos = 1)
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
   end
/*---仓库授权*/


  SELECT	@szPClass_id=class_id FROM products WHERE product_id=@nP_ID

  IF @szPeriod='' AND @nP_ID=0
  BEGIN
  SELECT *, 0.0 as retailprice, 0.0 as retailtotal FROM 
     (SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 


        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouse s,storages sto,products p,company Y 
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and p.deleted<>1 
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  LEFT(p.class_id,LEN(s.class_id))=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number<>0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,s.sy_name
  	UNION ALL
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
         LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouse s,storages sto,products p,company Y 
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  p.class_id=s.class_id 
  	WHERE s.parent_id=@szParent_id and s.child_number=0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,SY_name
        
        )S 
     order by S.[class_ID]
  END 
  ELSE IF @szPeriod='' AND @nP_ID<>0
  BEGIN
  SELECT *, @price as retailprice,s.quantity*@price as retailtotal FROM
     (SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouse s,storages sto,products p,company Y 
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  LEFT(p.class_id,LEN(s.class_id))=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number<>0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,s.SY_name
  	UNION all
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
         LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouse s,storages sto,products p,company Y 
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  p.class_id=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number=0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,s.SY_name

     )S
    order by s.[class_id]
  END 
  ELSE IF @szPeriod<>'' AND @nP_ID=0
  BEGIN
  SELECT *, @price as retailprice,s.quantity*@price as retailtotal FROM
     (
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouseini s,storages sto,products p,company Y 
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  LEFT(p.class_id,LEN(s.class_id))=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number<>0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,SY_name
  	UNION ALL
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where  s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouseini s,storages sto,products p ,company Y
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  p.class_id=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number=0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,SY_name
  	)S
  order by s.[class_id]
  END
  ELSE 
  BEGIN
  SELECT *, @price as retailprice,s.quantity*@price as retailtotal FROM
     (
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouseini s,storages sto,products p ,company Y
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  LEFT(p.class_id,LEN(s.class_id))=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number<>0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,SY_name
  	UNION  ALL
  	SELECT s.class_id,s.child_number,s.[name],s.serial_number,ISNULL(SUM(p.quantity),0) AS quantity,ISNULL(SUM(p.costtotal),0) AS costtotal,SY_name
  	FROM (select * from dbo.vw_Storage s where  s.WholeFlag<>3 and (@nYClassid='' or YClass_ID like @nYClassid+'%' or YClass_id='')
        AND (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
        )s 
        LEFT join
  	(
  		SELECT sto.class_id,ISNULL(SUM(s.quantity),0) AS quantity,ISNULL(SUM(s.costtotal),0) AS costtotal 
  		FROM storehouseini s,storages sto,products p ,company Y
  		WHERE s.s_id=sto.storage_id and sto.deleted=0 and p.product_id=s.p_id and LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id and p.deleted<>1
                and s.Y_ID=Y.Company_id and (Y.class_id like @nYClassid+'%' or @nYClassid='')
  		GROUP BY sto.class_id
  	) AS p
  	ON  p.class_id=s.class_id
  	WHERE s.parent_id=@szParent_id and s.child_number=0 and s.deleted=0
  	GROUP BY s.class_id,s.child_number,s.[name],s.serial_number,SY_name
  	)S
  order by s.[class_id]
  END

  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
