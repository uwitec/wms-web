


CREATE	TRIGGER delOrderdrfdetail ON [dbo].[OrderBill]
FOR  delete
AS
 delete from OrderDraft where orgsmb_id in (select smb_id from deleted)
GO
