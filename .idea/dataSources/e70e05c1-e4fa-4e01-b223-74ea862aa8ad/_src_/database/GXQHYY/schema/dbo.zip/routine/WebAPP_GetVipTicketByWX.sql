

/*====================================*/
/*微会员领取优惠券*/
/*select * from wx_vip_ticket*/
/*====================================*/
CREATE PROCEDURE dbo.WebAPP_GetVipTicketByWX
(
@chvid			int,
@chvopenid		varchar(100),
@chvcardid		int,
@chvnumber		varchar(20)
)
/*$Encode$--*/
 AS

declare @chvoutMsg varchar(200)
select @chvoutMsg='领取成功'
declare @chvtotal numeric(18,2),@chvendday int,@useflag int,@chvbegindate datetime,@chvenddate datetime,@remark varchar(255)
select @chvtotal=0,
@chvendday=0,
@useflag=0,
@chvbegindate='1900-01-01',
@chvenddate='1900-01-01',
@remark=''

declare @chvtypeid int,@t_name varchar(50)
declare @chvtempcardid int,@usecontent varchar(255)

select @chvtempcardid=VIPCardID from VIPCardBind where WeiXinNo=@chvopenid
if @chvtempcardid<>@chvcardid
begin
	select @chvoutMsg='会员信息不合法，无法领取'
	select @chvoutMsg as outMsg,-1 as reCode
	return -1
end
	
if not exists(select 1 from wx_vip_ticket t where t.id=@chvid 
	and not exists(select 1 from wx_vip_getticket g where t.id=g.t_id and g.cardid=@chvcardid)
	and t.deleted=0 and (t.endday>0 or (DATEDIFF(dd , t.enddate, GETDATE())<=0))
)
begin
	select @chvoutMsg='优惠券无效，请重新刷新页面'
	select @chvoutMsg as outMsg,-1 as reCode
	return -1
end
else
begin
	select @chvtotal=t.total,@chvendday=t.endday,@t_name=t.name,
		@chvbegindate=CONVERT(varchar(10),case when t.endday>0 then GETDATE() else t.begindate end,20),
		@chvenddate=CONVERT(varchar(10),case when t.endday>0 then DATEADD(dd,t.endday,GETDATE()) else t.enddate end,20),
		@remark=t.content,
		@useflag=t.useflag,
		@usecontent=case when t.useflag>0 then '单笔消费【'+CAST(t.useflag as varchar)+'】' else '不限制' end 
		from wx_vip_ticket t where t.id=@chvid 
		/*select * from wx_vip_getticket*/
	insert into wx_vip_getticket(cardid,t_id,t_name,total,usecontent,remark,begindate,enddate,number)
		values(@chvcardid,@chvid,@t_name,@chvtotal,@usecontent,@remark,@chvbegindate,@chvenddate,@chvnumber)	
end

select @chvoutMsg as outMsg,@@error as reCode
return @@error
GO
