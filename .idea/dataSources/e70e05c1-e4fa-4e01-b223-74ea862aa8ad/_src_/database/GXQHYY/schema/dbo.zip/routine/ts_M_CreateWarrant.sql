
CREATE PROCEDURE [dbo].[ts_M_CreateWarrant] 
(
@Filter int,  /*过滤已经生成过的凭证*/
@Type int,
@S_ID int,
@BeginDate varchar(50),
@EndDate varchar(50),
@Summary varchar(500),
@BillType varchar(100),
@BillNumber varchar(100)/*报损,报溢,调拨单不能按单据编号来生成凭证*/
)
AS

/* 查询报损凭证/调拨凭证的数据*/
declare @BillCount Int
declare @YsMoney  numeric(25,8)/*零售金额*/
declare @CostTotal   numeric(25,8)/*成本金额*/
declare @Sql     varchar(1000)

if @BillNumber=''
  set @Sql='select * INTO ##BillIdx From BillIdx BI '
    + ' where BI.BillDate between  '+ char(39) + @BeginDate + char(39)
    + ' and ' + char(39) + @EndDate + char(39)
    + ' and BI.BillType in('+ @BillType + ') and BI.BillStates=0 '
    + ' and BI.sin_id='+cast(@S_ID as varchar(50))
else
  set @Sql='select * INTO ##BillIdx From BillIdx BI '
    + ' where BI.BillStates=0 and BI.BillNumber =' + char(39) + @BillNumber +char(39) 
    + ' and BI.BillType in('+ @BillType + ')'
/*print @Sql return 0*/
Execute(@Sql)


set @BillCount=0 
set @YsMoney=0   
set @CostTotal=0 

/*调拨凭证TotalMoney,RetailMoney,*/
if @Type=2 
begin
  if (@Filter=1)
  begin
            /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 
    where BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0) 
            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid
    where BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0)
  end else   
  begin
            /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 
            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid
  end  

end

/*报损凭证*/
if @Type=3
begin
  if (@Filter=1)
  begin
            /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 
    where BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0) 
            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid
    where BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0)
  end else   
  begin
            /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 

            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid

  end
end

/*报溢凭证*/
if @Type=4
begin
  if (@Filter=1)
  begin
              /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 
    where BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0) 
            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid
    where  BI.BillId not in(Select WB.BillID From WarrantBill WB left join WarrantIDX  WI ON WB.W_ID=WI.W_ID 
       Where WI.Deleted=0)
  end else   
  begin
            /*附件单数*/
    select @BillCount=count(*) From ##BillIdx BI 
            /*零售金额*/
    select @YsMoney=Sum(SB.RetailMoney),@CostTotal=Sum(SB.CostPrice*SB.quantity) from storemanageBill SB 
    Inner join ##BillIdx BI ON SB.bill_id=bi.billid
  end
end

/*生成数据*/
SELECT [serialno]=0,[W_ID]=0, [Type]=@Type, [Summary]=@Summary, [BillCount]=isnull(@BillCount,0.000),
[YsMoney]=Cast(isnull(@YsMoney,0) as numeric(25,8)) , [MoneyTotal]=0.0000, [TaxTotal]=0.0000, 
[CostTotal]=Cast(isnull(@CostTotal,0) as numeric(25,8)), 
[Profit]=0.0000, [CreateDate]=getDate(), [Deleted]=0 ,[WarrantNO]=@BillNumber

drop table ##BillIdx
GO
