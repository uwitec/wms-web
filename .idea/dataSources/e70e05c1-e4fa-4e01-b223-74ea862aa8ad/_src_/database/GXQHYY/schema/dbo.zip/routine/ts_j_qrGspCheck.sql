
create proc ts_j_qrGspCheck
(
  @nc_id int,
  @np_id int,
  @szBathNo varchar(30),
  @nBilltype int,
  @szAlert varchar(300) output
)
/*with encryption*/
as
set nocount on
 
declare @szCName varchar(200), @szPName varchar(200), @nCheckFJ int

select @nCheckFJ = CAST(sysvalue as int)  from sysconfigtmp where [sysname] = 'fjGspCtrl'
if @nCheckFJ is null set @nCheckFJ = 0
if @nCheckFJ = 0 return 0

set @szAlert=''
select @szCName=[name] from clients where client_id=@nc_id and deleted=0
select @szPName=[name] from products where product_id = @np_id and deleted=0

if @nBilltype in (10, 20)
begin
  	if exists (select 1 from GspTable where p_id=@np_id  and GspType =2203 and checkflag = 0)
	begin
	  set @szAlert='【'+@szPName+'】的'+'首营品种表审批结果不合格，不能进行此业务！' 	
	  return 0
	end  
end


if @nBilltype in (21)
begin
  	if exists (select 1 from GspTable where szid = CAST(@nc_id as varchar(10)) and p_id=@np_id  and szid2=@szBathNo and GspType =2208 and checkflag = 0)
	begin
	  set @szAlert='【'+@szPName+'】的'+'购进药品退货通知单审批结果不合格，不能进行此业务！' 	
	  return 0
	end  
end


if @nBilltype in (11)
begin
  	if exists (select 1 from GspTable where szid = CAST(@nc_id as varchar(10)) and p_id=@np_id and szid2=@szBathNo and GspType =2273 and checkflag = 0)
	begin
	  set @szAlert='【'+@szPName+'】的'+'已销药品退货通知单审批结果不合格，不能进行此业务！' 	
	  return 0
	end  
end
  
return 0
GO
