

CREATE PROCEDURE Ts_K_PurchasePriceAnalysis(@Begin DATETIME, @End DATETIME, @YId INT, @SupplierId INT, @EId INT, @Filter INT, @CgId INT, @szID VARCHAR(3000))
AS
BEGIN
	/*DECLARE #ProductList TABLE (CgId INT, PId INT)*/
	CREATE TABLE #ProductList (CgId INT, PId INT)
	IF @szID = ''
	BEGIN
		INSERT INTO #ProductList(CgId, PId)
		SELECT 0, product_id FROM vw_Products	
	END
	ELSE
	BEGIN
		DECLARE @ClassId VARCHAR(30)
		SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CgId
		
		INSERT INTO #ProductList(CgId, PId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE cg.class_id LIKE @ClassId AND cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (0, -1) AND 
			  (@szID = '' OR cg.id IN (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szID)))	and cm.deleted=0
	END
		
	
	/*从入库类单据中获取时间段内入库的商品*/
	/*DECLARE #PurchasePId TABLE (PId INT, PurchaseDate2 DATETIME, SmbId2 INT)*/
	CREATE TABLE #PurchasePId (PId INT, PurchaseDate2 DATETIME, SmbId2 INT)
	
	INSERT INTO #PurchasePId(PId, PurchaseDate2, SmbId2)
	SELECT s.p_id, MAX(b.billdate) AS PurchaseDate2, MAX(s.smb_id) AS SmbId2
	  FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
	                 INNER JOIN #ProductList p ON s.p_id = p.PId
	WHERE b.billstates = 0 AND b.billtype IN (20, 160, 162) AND b.Y_ID = @YId AND 
	      b.billdate BETWEEN @Begin AND @End 
    GROUP BY s.p_id
    
	
	/*DECLARE #PurchaseRecord TABLE (PId INT, PurchaseDate1 DATETIME, SmbId1 INT, PurchaseDate2 DATETIME, SmbId2 INT, StockQty numeric(25,8))*/
	CREATE TABLE #PurchaseRecord (PId INT, PurchaseDate1 DATETIME, SmbId1 INT, PurchaseDate2 DATETIME, SmbId2 INT, StockQty numeric(25,8))
	
	INSERT INTO #PurchaseRecord(PId, PurchaseDate1, SmbId1, PurchaseDate2, SmbId2, StockQty)
	SELECT g.PId, PurchaseDate1, SmbId1, g.PurchaseDate2, g.SmbId2, SUM(ISNULL(s.quantity, 0.00)) AS StockQty  
		FROM (
			SELECT k.PId, k.PurchaseDate2, k.SmbId2, MAX(k.PurchaseDate1) AS PurchaseDate1, MAX(k.SmbId1) AS SmbId1 
				FROM (
					SELECT a.PId, a.PurchaseDate2, a.SmbId2, 
						   ISNULL(b.billdate, a.PurchaseDate2) AS PurchaseDate1,
						   ISNULL(b.SmbId1, a.SmbId2) AS SmbId1  
						FROM #PurchasePId a LEFT JOIN (
												SELECT s.p_id, b.billdate, s.smb_id AS SmbId1
												  FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
												WHERE b.billstates = 0 AND b.billtype IN (20, 160, 162) AND b.Y_ID = @YId AND 
													  s.p_id IN (SELECT PId FROM #PurchasePId)
						) b ON a.PId = b.p_id AND a.SmbId2 <> b.SmbId1
				) k GROUP BY k.PId, k.PurchaseDate2, k.SmbId2
		) g LEFT JOIN storehouse s ON g.PId = s.p_id AND s.Y_ID = @YId
	GROUP BY g.PId, PurchaseDate1, SmbId1, g.PurchaseDate2, g.SmbId2
	
	DECLARE @Days INT
	SET @Days = ABS(DATEDIFF(DAY, @Begin, @End)) + 1
	IF @Days = 0
		SET @Days = 1
	
	SELECT i.PId, i.serial_number, i.name, i.alias, i.[standard], i.permitcode, i.makearea, i.Factory, i.UnitName,
		   i.StockQty, i.PurchaseDate1, i.PurchaseDate2, i.PurchaseCycle, i.PurchasePrice1, i.PurchasePrice2, i.UpRate,
		   i.PurchaseQty2, i.PurchaseTotal1, i.PurchaseTotal2, i.UpTotal, i.Supplier1, i.Supplier2, i.EName1, i.EName2,
		   i.AvgDaySale, CAST(CASE WHEN i.AvgDaySale = 0 THEN 0 ELSE (i.StockQty / i.AvgDaySale) END AS INT) AS CanSaleDay,
		   i.PurchaseQty1, i.PurchaseQty2
		FROM (	
			SELECT a.PId, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea, p.Factory, u.name AS UnitName, a.StockQty,
				   CONVERT(VARCHAR(100), a.PurchaseDate1, 23) AS PurchaseDate1, CONVERT(VARCHAR(100), a.PurchaseDate2, 23) AS PurchaseDate2, 
				   CAST(DATEDIFF(DAY, a.PurchaseDate1, a.PurchaseDate2) AS INT) AS PurchaseCycle,
				   b.costprice AS PurchasePrice1, s.costprice AS PurchasePrice2, 
				   CASE WHEN b.costprice <> 0 THEN CONVERT(DECIMAL(18, 2), (s.costprice - b.costprice) / b.costprice * 100)
						ELSE 0.00 END AS UpRate, 
				   b.quantity AS PurchaseQty1, s.quantity AS PurchaseQty2, b.total AS PurchaseTotal1,
				   s.total AS PurchaseTotal2, (s.costprice - b.costprice) * s.quantity AS UpTotal, 
				   ISNULL(c1.name, '') AS Supplier1, ISNULL(c2.name, '') AS Supplier2,
				   ISNULL(e1.name, '') AS EName1, ISNULL(e2.name, '') AS EName2,
					/*CAST(dbo.GetSaleBreakOffAnalysisInfo(4, @YId, a.PId, @Begin, @End, @Days) AS numeric(25,8)) AS AvgDaySale*/
					aa.AvgDaySale
					FROM #PurchaseRecord a 
					left join 
					(SELECT  a.PId,SUM(s.quantity)/@Days AvgDaySale
					FROM #PurchaseRecord a inner join salemanagebill s  on  s.p_id = a.PId
					INNER JOIN billidx b ON b.billid = s.bill_id
					WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (10, 12, 150, 152) AND 
						b.billdate BETWEEN @Begin AND @End	
					group by a.PId) aa on a.PId=aa.PId
				   INNER JOIN buymanagebill b ON a.SmbId1 = b.smb_id
				   INNER JOIN buymanagebill s ON a.SmbId2 = s.smb_id
				   INNER JOIN products p ON a.PId = p.product_id
				   INNER JOIN unit u ON p.unit1_id = u.unit_id
				   LEFT JOIN clients c1 ON b.supplier_id = c1.client_id
				   LEFT JOIN clients c2 ON s.supplier_id = c2.client_id
				   LEFT JOIN employees e1 ON b.RowE_id = e1.emp_id
				   LEFT JOIN employees e2 ON s.RowE_id = e2.emp_id
			WHERE (s.RowE_id = @EId OR @EId = 0) AND (s.supplier_id = @SupplierId OR @SupplierId = 0) AND
				  (b.costprice <> s.costprice OR @Filter = 0)
		) i 
		DROP TABLE #ProductList
		DROP TABLE #PurchasePId
		DROP TABLE #PurchaseRecord
END
GO
