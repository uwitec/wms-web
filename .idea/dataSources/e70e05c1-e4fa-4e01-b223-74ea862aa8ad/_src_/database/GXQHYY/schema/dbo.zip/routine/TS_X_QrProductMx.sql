

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
CREATE PROCEDURE [TS_X_QrProductMx]
( @Begindate     VARCHAR(10)='',
  @Enddate       VARCHAR(10)='',
  @nS_ID         INT=0,
  @nYClassid                 varchar(100)='',
  @nloginEID               int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = ''
if @Enddate is null  SET @Enddate = ''
if @nS_ID is null  SET @nS_ID = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
SET NOCOUNT ON 
  Declare @Companytable INTEGER,@Storetable integer

  create table #Companytable([id] int)
  create table #storagestable([id] int)

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


  SELECT p.[product_id], p.[code], p.[name] AS [pname], p.[standard], p.[medtype],
    (-1) AS [billtype], (-1) AS [billID], (0) AS [billdate], p.[code] AS [billnumber], 
    (0) AS InputMan,
    ('') AS [name], ('') AS [unitname1], (0) AS [quantity], (0) AS [costtotal], (0) as [taxtotal],(0) as [Y_id]
  FROM VW_C_Products p WHERE [child_number]=0
  UNION ALL
  SELECT p.[product_id], ('') AS [code], ('') AS [pname], ('') AS [standard], ('') AS [medtype],
    (-2) AS [billtype], (-2) AS [billID], (1) AS [billdate], ('') AS [billnumber],
    (0) AS InputMan,
    ('') AS [name], p.[unitname1],
  ISNULL(a.[quantity],0)+ISNULL(b.[quantity],0) AS [quantity], 
  ISNULL(a.[costtotal],0)+ISNULL(b.[costtotal],0) AS [costtotal], 
  ISNULL(a.[Taxtotal],0)+ISNULL(b.[Taxtotal],0) AS [Taxtotal],isnull(b.Y_id,0) as Y_id 
  FROM VW_C_Products p
  LEFT JOIN
  (
/*期初库存*/
        SELECT p.[product_id],
        ISNULL(SUM(si.[quantity]),0) AS [quantity], ISNULL(SUM(si.[costtotal]),0) AS [costtotal],
        ISNULL(SUM(si.costtaxtotal), 0) AS [TaxTotal],si.Y_id
        FROM StoreHouseIni si, VW_C_Products p, Storages s
        WHERE si.[p_id]=p.[product_id] AND si.[s_id]=s.[storage_id] AND s.[storage_id]=@ns_id	
    	and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))
    	and ((@Storetable=0) OR (si.s_id in (select [id] from #storagestable)))
        GROUP BY p.[product_id],si.Y_id
  ) a
  ON p.[product_id]=a.[product_id]
  LEFT JOIN 
  (
/*开始日期库存  */
     SELECT [product_id],
     ISNULL(SUM([quantity]),0) AS [quantity], ISNULL(SUM([costtotal]),0) AS [costtotal], 
     ISNULL(SUM([Taxtotal]),0) AS [Taxtotal], Y_id
     FROM(   SELECT * FROM (
		     SELECT p.[product_id],
		     ISNULL(SUM(pd.[quantity]),0) AS [quantity], ISNULL(SUM(pd.[costtotal]),0) AS [costtotal], 
		     ISNULL(SUM(pd.[costtaxtotal]),0) AS [Taxtotal], pd.Y_id
		     FROM  VW_C_Pdetail pd, VW_C_BillIDX bi,VW_C_Products p
		     WHERE bi.[billdate]<@BeginDate AND bi.[billstates]='0'AND pd.[billid]=bi.[billid] 
		     AND pd.[p_id]=p.[product_id] AND pd.[storetype]=0 AND pd.[s_id]=@ns_id 
		     and ((@Companytable=0)or (pd.Y_id in (select [id] from #Companytable)))
		     and ((@Storetable=0) OR (pd.s_id in (select [id] from #storagestable)))
	     	     GROUP BY p.[product_id], pd.Y_id 
	     ) A1
     ) AA
     GROUP BY AA.[product_id],Y_id
  ) b
  ON p.[product_id]=b.[product_id]
  WHERE p.[deleted]<>1 AND p.[child_number]=0 
  UNION ALL
/*起始日期明细*/
  SELECT * FROM 
  (
	  SELECT * FROM (
		  SELECT p.[product_id], ('') AS [code], ('') AS [pname], ('') AS [standard], ('') AS [medtype], 
		    bi.[billtype], bi.[billid], bi.[billdate], bi.[billnumber], 
		    bi.[inputman],
		    bi.[cname] AS [name], p.[unitname1],
		    ISNULL(SUM(pd.[quantity]),0) AS [quantity], ISNULL(SUM(pd.[costtotal]),0) AS [costtotal], 
		    ISNULL(SUM(pd.[costtaxtotal]),0) AS [Taxtotal], bi.Y_id
		  FROM  VW_C_Pdetail pd, VW_C_BillIDX bi, VW_C_Products p, Storages s
		  WHERE bi.[billdate]>=@BeginDate AND bi.[billdate]<=@EndDate AND bi.[billstates]='0'
		  AND pd.[billid]=bi.[billid] AND pd.[p_id]=p.[product_id] AND s.[storage_id]=pd.[s_id] 
		  AND pd.[storetype]=0 AND pd.[s_id]=@ns_id
		  and ((@Companytable=0)or (pd.Y_id in (select [id] from #Companytable)))
		  and ((@Storetable=0) OR (pd.s_id in (select [id] from #storagestable)))
		  GROUP BY bi.[billid],p.[product_id],bi.[billtype],bi.[billdate],bi.[billnumber],bi.[inputman], 
		  bi.[cname],p.[unitname1], bi.Y_id
	   ) A1
  ) BB 
  UNION ALL
/*期末库存*/
  SELECT p.[product_id],('') AS [code], ('') AS [pname], ('') AS [standard], ('') AS [medtype], 
    (-3) AS [billtype], (-3) AS [billID], '2600-08-17' AS [billdate], ('') AS [billnumber],
    (0) AS InputMan,
    ('') AS [name], p.[unitname1], (0) AS [quantity], (0) AS [costtotal],  (0) AS [Taxtotal],(0) AS [Y_id]
  FROM VW_C_Products p
  WHERE p.[child_number]=0
  UNION ALL
/*当前库存*/
  SELECT p.[product_id],('') AS [code], ('') AS [pname], ('') AS [standard], ('') AS [medtype], 
    (-4) AS [billtype], (-4) AS [billID], '2600-08-18' AS [billdate], ('') AS [billnumber],
    (0) AS InputMan,
    ('') AS [name], p.[unitname1],
    ISNULL(a.[quantity],0) AS [quantity],ISNULL(a.[costtotal],0) AS [costtotal],
    ISNULL(a.[costtotal]  ,0) AS [Taxtotal],isnull(a.Y_id,0) as Y_id
  FROM VW_C_Products p
  LEFT JOIN 
  (
    SELECT p.[product_id],
    ISNULL(SUM(si.[quantity]),0) AS [quantity],ISNULL(SUM(si.[costtotal]),0) AS [costtotal], 
    ISNULL(SUM(si.costtaxtotal),0) AS [taxtotal],si.Y_id
    FROM StoreHouse si, VW_C_Products p, Storages s
    WHERE si.[p_id]=p.[product_id] AND si.[s_id]=s.[storage_id] AND s.[storage_id]=@ns_id
    GROUP BY p.[product_id],si.Y_id
  ) a
  ON p.[product_id]=a.[product_id]
  WHERE p.[child_number]=0
  ORDER BY [product_id], [billdate]

  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
