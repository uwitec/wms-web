
CREATE	PROCEDURE [Ts_L_UpdateClients]
	(@client_id	[int],
	 @serial_number 	[varchar](26),
	 @name	[varchar](80),
	 @alias 	[varchar](30),
	 @region_id	[int],
	 @phone_number	[varchar](100),
	 @address	[varchar](80),
	 @zipcode	[varchar](10),
	 @contact_personal	[varchar](20),
	 @tax_number	[varchar](50),
	 @acount_number 	[varchar](2000),
	 @credit_total	[numeric],
         @APcredit_total [numeric],  
	 @pinyin	[varchar](80),
	 @pricemode	[smallint],
	 @sklimit	[smallint],
	 @artotal	numeric(25,8),
	 @artotal_ini	numeric(25,8),
	 @aptotal	numeric(25,8),
	 @aptotal_ini	numeric(25,8),
	 @pre_artotal	numeric(25,8),
	 @pre_artotal_ini	numeric(25,8),
	 @pre_aptotal	numeric(25,8),
	 @pre_aptotal_ini	numeric(25,8),
	 @firstcheck	[bit],
	 @comment	[varchar](256),
	 @csflag	[char](1),
	 @ceType	[Tinyint],
	 @GSPNO		[varchar](30),
	 @GMPNo		[varchar](30),
	 @incRate	numeric(25,8)=1,
	 @Licence_no [varchar](512),          	/*企业许可证*/
	 @Ent_type   int,          		/*所属类型*/
	 @City_id    [varchar](32),       	/*所属市区辖区编码*/
	 @City_name  [varchar](512),         	/*所属市区辖区*/
	 @boro_id    [varchar](32),         	/*所属县区辖区编码*/
	 @boro_name  [varchar](512),       	/*所属县区辖区*/
	 @e_id       int,
	 @createDate varchar(100),
	 @C_Customname1 varchar(100),           /*自定义属性1*/
	 @C_Customname2 varchar(100),           /*自定义属性2*/
	 @C_Customname3 varchar(100),           /*自定义属性3*/
	 @C_Customname4 varchar(100),           /*自定义属性4*/
	 @C_Customname5 varchar(100),            /*自定义属性5*/
     @clienttype_id  [int],                 /*客户类型ID*/
	 @cardID         [int],                 /*会员卡ID*/
	 @consignBook_no varchar (80),         /*委托书编号*/
	 @organCard_no   varchar (80),         /*组织机构证书编号*/
	 @BusinessLicence_no  varchar (80),    /*营业执照编号*/
	 @MassConfer_no   varchar (128),       /**/
	 @Cer_CustomNO1   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO2   varchar (128),
	 @Cer_CustomNO3   varchar (128),
	 @Cer_CustomNO4   varchar (128),
	 @Cer_CustomNO5   varchar (128),
	 @Y_id           [int],                /*分支机构ID*/
	 @ByWayDay       [int],
	 @Roadline       [int],               /*配送线路*/
	 @RoadOrder      varchar(5),           /*线路顺序号*/
	 @OrderCredit     [bit],                  /*是否允许下订单。0为允许下订单，1为不允许。*/
	 @discount       numeric(25,8),             /*单位折扣  2012-02-17*/
	 @ElecCode       [bit],	/* 电子监管码*/
	 @AddressZC		varchar (128),				/*注册地址*/
         @Quality_Personal VARCHAR(20),      /*质量负责人*/
         @Quality_Phone    VARCHAR(100),       /*质量负责人电话*/
         @QQ               VARCHAR(30),       /*QQ号*/
	 @ModifyEId      [INT],                /*录入人Id*/
	 @Cer_CustomNO6   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO7   varchar (128),
	 @Cer_CustomNO8   varchar (128),
	 @Cer_CustomNO9   varchar (128),
	 @Cer_CustomNO10   varchar (128),
	 @CreateMan varchar (50),
	 @zljgPeople  varchar(50),          /*质量机构负责人*/
	 @zljgphone  varchar(50),             
	 @cwPeople  varchar(50),            /*财务负责人*/
	 @cwphone  varchar(50), 
	 @zlglPeople  varchar(50),          /*质量管理员*/
	 @zlglphone  varchar(50), 
	 @storePeople  varchar(50),         /*仓库负责人*/
	 @storephone  varchar(50),
	 @BalanceMode  INT,                  /*结算方式 	*/
	 @refEntSeqNo varchar(100),           /*电子监管企业标识*/
	 @partnerSeqNo varchar(100),           /*电子监管网ID*/
	 @legalpeople varchar(50),          /*法人代表*/
     @legalphone varchar(50)            /*法人代表电话*/
	)
AS 
/*Params Ini begin*/
if @incRate is null  SET @incRate = 1
/*Params Ini end*/
/*declare @szY_ID varchar(50)*/
declare @isopenDate int

if exists(select * from Clients where serial_number=@serial_number and [client_id]<> Abs(@client_id) and deleted =0)
begin
	RAISERROR('编号重复！不能添加！！',16,1)
	return -2
end

IF @client_id < 0 
BEGIN
	EXEC Ts_L_UpdateClients_His @client_id OUTPUT,
		@serial_number,
		@name,
		@alias,
		@region_id,
		@phone_number,
		@address,
		@zipcode,
		@contact_personal,
		@tax_number,
		@acount_number,
		@credit_total,
		@APcredit_total,
		@pinyin,
		@pricemode,
		@sklimit,
		@artotal,
		@artotal_ini,
		@aptotal,
		@aptotal_ini,
		@pre_artotal,
		@pre_artotal_ini,
		@pre_aptotal,
		@pre_aptotal_ini,
		@firstcheck,
		@comment,
		@csflag,
		@ceType,
		@GSPNO,
		@GMPNo,
		@incRate,
		@Licence_no,
		@Ent_type,
		@City_id,
		@City_name,
		@boro_id,
		@boro_name,
		@e_id,
		@createDate,
		@C_Customname1,
		@C_Customname2,
		@C_Customname3,
		@C_Customname4,
		@C_Customname5,
		@clienttype_id,
		@cardID,
		@consignBook_no,
		@organCard_no,
		@BusinessLicence_no,
		@MassConfer_no,
		@Cer_CustomNO1,
		@Cer_CustomNO2,
		@Cer_CustomNO3,
		@Cer_CustomNO4,
		@Cer_CustomNO5,
		@Y_id,
		@ByWayDay,
		@Roadline,
		@RoadOrder,
		@OrderCredit,
		@discount,
		@ElecCode,
		@AddressZC,
		@Quality_Personal,
		@Quality_Phone,
		@QQ,
		@ModifyEId,
		@Cer_CustomNO6,
		@Cer_CustomNO7,
		@Cer_CustomNO8,
		@Cer_CustomNO9,
		@Cer_CustomNO10,
		@CreateMan,
		@zljgPeople,
		@zljgphone,
		@cwPeople,
		@cwphone,
		@zlglPeople,
		@zlglphone,
		@storePeople,
		@storephone,
		@BalanceMode,
		@refEntSeqNo,
		@partnerSeqNo,
		@legalpeople,          /*法人代表*/
        @legalphone            /*法人代表电话*/
END
ELSE
BEGIN
	UPDATE [clients] 

	SET	 [serial_number]	= @serial_number,
		 [name] 		= @name,
		 [alias]			= @alias,
		 [region_id]		= @region_id,
		 [phone_number] = @phone_number,
		 [address]		= @address,
		 [zipcode]		= @zipcode,
		 [contact_personal]	= @contact_personal,
		 [tax_number]		= @tax_number,
		 [acount_number]	= @acount_number,
		 [credit_total] 	= @credit_total,
		 [pinyin]			= @pinyin,
		 [pricemode]		= @pricemode,
		 [sklimit]			= @sklimit,
		/* [artotal]		= @artotal,*/
		 [artotal_ini]		= @artotal_ini,
		/* [aptotal]		= @aptotal,*/
		 [aptotal_ini]		= @aptotal_ini,
		/* [pre_artotal]		= @pre_artotal,*/
		 [pre_artotal_ini]	= @pre_artotal_ini,
		/* [pre_aptotal]		= @pre_aptotal,*/
		 [pre_aptotal_ini]	= @pre_aptotal_ini,
		 [firstcheck]		= @firstcheck,
		 [comment]		= @comment,
		 [csflag]		= @csflag ,
		 [ceType]		= @ceType,
 		 [GspNo]		= @GSPNO,
		 [gmpno]		= @GMPNo,
		 [incRate]		= @incRate,
		 [Licence_no]		= @Licence_no,          	/*企业许可证*/
		 [Ent_type]		= @Ent_type,          		/*所属类型*/
		 [City_id]		= @City_id,       		/*所属市区辖区编码*/
		 [City_name]		= @City_name,         		/*所属市区辖区*/
		 [boro_id]		= @boro_id,         		/*所属县区辖区编码*/
		 [boro_name]		= @boro_name,         		/*所属县区辖区*/
		 [e_id]                 = @e_id,
		 [createDate]	        = @createDate, 
		 [C_Customname1]	= @C_Customname1,                /*自定义属性1*/
		 [C_Customname2]        = @C_Customname2,                /*自定义属性2*/
		 [C_Customname3]	= @C_Customname3,               /*自定义属性3*/
   		 [C_Customname4]	= @C_Customname4,                /*自定义属性4*/
  		 [C_Customname5]        = @C_Customname5,                /*自定义属性5*/
 		 [clienttype_id]        = @clienttype_id,                /*客户类型ID*/
		 [card_ID]              = @cardID,                        /*会员卡ID*/
		 [consignBook_no]       = @consignBook_no,             /*委托书编号*/
		 [organCard_no]         = @organCard_no,                /*组织机构证书编号*/
		 [BusinessLicence_no]   = @BusinessLicence_no,         /*营业执照编号  TT*/
		 [MassConfer_no]        = @MassConfer_no,
		 [Cer_CustomNO1]        = @Cer_CustomNO1,
		 [Cer_CustomNO2]        = @Cer_CustomNO2,
		 [Cer_CustomNO3]        = @Cer_CustomNO3,
		 [Cer_CustomNO4]        = @Cer_CustomNO4,
		 [Cer_CustomNO5]        = @Cer_CustomNO5,
		 [ByWayDay]				= @ByWayDay, 
		 [RoadID]               = @Roadline,
		 [szOrdernum]           = @RoadOrder,  
		 [OrderCredit]          = @OrderCredit,
		 [discount]             = @discount,
		 ElecCode               = @ElecCode,
		 AddressZC = @AddressZC,
		 Quality_Personal       = @Quality_Personal,
		 Quality_Phone          = @Quality_Phone,
		 QQ                     = @QQ,
		 ModifyEId              = @ModifyEId,
		 [Cer_CustomNO6]        = @Cer_CustomNO6,
		 [Cer_CustomNO7]        = @Cer_CustomNO7,
		 [Cer_CustomNO8]        = @Cer_CustomNO8,
		 [Cer_CustomNO9]        = @Cer_CustomNO9,
		 [Cer_CustomNO10]        = @Cer_CustomNO10,
		 [zljgPeople]=@zljgPeople,
		 [zljgphone]=@zljgphone,
		 [cwPeople]=@cwPeople,
		 [cwphone]=@cwphone,
		 [zlglPeople]=@zlglPeople,
		 [zlglphone]=@zlglphone,
		 [storePeople]=@storePeople,
		 [storephone]=@storephone,
		 [refEntSeqNo]	= @refEntSeqNo,
		 [partnerSeqNo] = @partnerSeqNo,
		 [legalpeople] = @legalpeople,          /*法人代表*/
         [legalphone] = @legalphone            /*法人代表电话*/

	WHERE 
		( [client_id]		= @client_id)

		if exists(select * from Clientsbalance where Y_id=@Y_id and c_id=@client_id)
		begin
		UPDATE Clientsbalance 
	
		SET	 [credit_total] 	= @credit_total,

					 [APcredit_total]       = @APcredit_total,

			 [sklimit]		= @sklimit,

			 [artotal_ini]		= @artotal_ini,

			 [aptotal_ini]		= @aptotal_ini,

			 [pre_artotal_ini]	= @pre_artotal_ini,

			 [pre_aptotal_ini]	= @pre_aptotal_ini,
				 [e_id]                 = @e_id,
			 [BalanceMode]      = @BalanceMode    
		WHERE 
			( [c_id]		= @client_id  AND
				  Y_id                  = @Y_id)  
		end
		else
		begin
	
		INSERT Clientsbalance(Y_id,C_ID,credit_total,APcredit_total,sklimit,artotal,artotal_ini,aptotal,aptotal_ini,pre_artotal,
						 pre_artotal_ini,pre_aptotal,pre_aptotal_ini,e_id, BalanceMode)
		  VALUES(@Y_id,@client_id,@credit_total,@APcredit_total,@sklimit,0,@artotal_ini,0,@aptotal_ini,0,
						 @pre_artotal_ini,0,@pre_aptotal_ini,@e_id, @BalanceMode)
		end
		if @Ent_type=1 
		begin
		  if not exists (select * from basefactory where (AccountComment=@name) or (AccountComment=@alias))
		  begin
			  insert into accountcomment(AccountComment,pinyin)
			  values(@name,@pinyin)
		  end
		  else
		  begin
			  update accountcomment set AccountComment=@name,pinyin=@pinyin  where (AccountComment=@name) or (AccountComment=@alias)
		  end
		end
	END
GO
