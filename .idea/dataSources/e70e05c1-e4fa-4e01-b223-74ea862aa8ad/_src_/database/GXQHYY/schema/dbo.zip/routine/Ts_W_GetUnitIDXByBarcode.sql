
CREATE PROCEDURE Ts_W_GetUnitIDXByBarcode
(@nPID INT,
 @nUID INT,
 @szMemoryBarcode VARCHAR(100)
)
AS

SET NOCOUNT ON

DECLARE @nUnitID INT
DECLARE @szBarcode VARCHAR(100)

SELECT @nUnitID = 0,  @szBarcode =''

IF PATINDEX('%''%',@szMemoryBarcode) > 0 SET @szMemoryBarcode = '**'
IF @szMemoryBarcode = '%' SET @szMemoryBarcode = '['+@szMemoryBarcode+']'


IF (@szMemoryBarcode <> '') AND 
  EXISTS(SELECT UnitID, Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND Barcode LIKE '%'+@szMemoryBarcode+'%')
BEGIN
  SELECT TOP 1 @nUnitID=UnitID, @szBarcode=Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND Barcode LIKE '%'+@szMemoryBarcode+'%'
END ELSE
BEGIN
  IF EXISTS(SELECT UnitID, Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND BarcodeType=1)
    (SELECT TOP 1 @nUnitID=UnitID, @szBarcode=Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND BarcodeType=1)
  ELSE IF EXISTS(SELECT Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND UnitID=@nUID)
    (SELECT TOP 1 @nUnitID=0, @szBarcode=Barcode FROM Barcode WHERE P_ID=@nPID AND UnitID>0 AND UnitID=@nUID)
END

SELECT @nUnitID, @szBarcode

RETURN 0
GO
