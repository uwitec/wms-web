




/*保存会员卡和微信号绑定*/
CREATE PROCEDURE [WebAPP_VipQryInfo]
(
    @weixinno		varchar(30),	
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
select @chvErrMsg=''
declare @vipcardid int
declare @ticket int/*是否有优惠券*/
select @vipcardid=VipCardID from VIPCardBind where weixinno=@weixinno
if isnull(@vipcardid,0)=0
begin
	select '没有找到对应的会员卡号' as outMsg
	return -1
end
select @ticket=0
if exists(select 1 from wx_vip_ticket t
	where not exists( select 1 from wx_vip_getticket g where g.t_id=t.id and g.cardid=@vipcardid) and t.deleted=0 and (DATEDIFF(dd , t.enddate , GETDATE())<=0 or t.endday>0)) 
begin
	select @ticket=1
end

select VIPCardID,CardNo,Name,sex,Tel,Integral-SwapIntegral as curIntegral,TotalBuyMoney,BuyCount,[name],birthday,sex,SaveMoney,@ticket as ticket from vipcard where vipcardid=@vipcardid


return 0
GO
