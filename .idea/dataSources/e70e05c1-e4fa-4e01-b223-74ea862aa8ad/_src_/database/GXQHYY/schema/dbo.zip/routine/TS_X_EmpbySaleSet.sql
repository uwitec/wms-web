
/* 查看职员月销售完成情况
  xxx 2015-01-30
*/

create procedure TS_X_EmpbySaleSet
(
  @szbegindate varchar(20),  /*通过开始，结束时间来确定时间区域*/
  @szenddate varchar(20),
  @Eclass_id varchar(30) = '', /*职员class_id*/
  @OperatorID int              /*操作员id*/
)

as
begin
/*----------授权控制----------------------*/
declare @ClientTable int, @Companytable int,@employeestable int 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*----------授权控制结束-------------------*/

declare @c_id int
declare @e_id int
declare @y_id int
 
 /* 
if @YClass_id = ''
  set @y_id = 0
else
  select @y_id = company_id from company where class_id = @YClass_id*/
  
if @Eclass_id = '' 
  set @e_id = 0 
else
  select @e_id = emp_id from employees where class_id = @Eclass_id      


  /*---------------创建临时表用于存储需要的结构---------------*/
  create table #tmp
               (
                 e_id int,	/*职员*/
                 class_id varchar(60),
                 [职员|名称] varchar(100),
                 [职员|隶属机构]   varchar(50),
                 [职员|部门] varchar(100),
                 [职员|联系电话] varchar(100)           
               )
   declare @vardatedeff int  /*时间差变量*/
   declare @monthvalue varchar(20)
   declare @month varchar(50)  /*月份列名称*/
   declare @sql varchar(500)
   
   set @vardatedeff = 0
   set @monthvalue = 0
   set @monthvalue = @szbegindate
   set @sql = ''
   set @month = ''
   set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差*/
       
   while(@vardatedeff>0)
   begin
     set @month = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月' /*得到年月份列*/
     set @sql =' ALTER TABLE #tmp Add ['+@month+'|任务额度'+'] numeric(25,8) not NULL default(0) 
			     ALTER TABLE #tmp Add ['+@month+'|完成额度'+'] numeric(25,8) not NULL default(0)  
			     ALTER TABLE #tmp Add ['+@month+'|完成比例'+'] numeric(25,8) not NULL default(0)'
     exec (@sql)
     /*print @sql*/
     set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20)  
     set @vardatedeff = @vardatedeff -1
   end
   
  /* -----------插入合计
   set @sql =  'ALTER TABLE #tmp Add [合计] numeric(25,8) not NULL default(0)' +
   			   'ALTER TABLE #tmp Add [|完成合计] numeric(25,8) not NULL default(0)' 
			   	
   exec(@sql)   */			   
   	
   /*----------创建临时表 end-----------------*/
   
   /*-将查询的职员全部类别插入临时表中*/
   insert #tmp(e_id,class_id,[职员|名称],[职员|隶属机构],[职员|部门],[职员|联系电话]) 
   select emp_id,e.class_id,e.name ,isnull(c.name,''), isnull(d.name,''), e.phone from employees e 
		left join department d on e.dep_id = d.departmentId
		left join company c on e.Y_ID = c.company_id 
   where e.deleted = 0 and(@e_id = 0 or e.emp_id= @e_id) and e.class_id <> '000000' order by emp_id
   
   /*----------获取选择时间段内的职员销售情况-----------------*/
  SELECT emp_id as e_id,ed.class_id as Class_ID,ISNULL(sm.MMdate,'') AS MMdate,
		 ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
		 ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
		 ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],
		 ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
		 ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
		 ISNULL(cast(SUM(SM.[SendTotal]) as numeric(25,8)),0) AS [SendTotal],
		 ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

		 ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
		 ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
		 (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

    INTO  #t
	from
	(
	   select emp_id,class_id from employees e 
	   where e.deleted = 0 and (@e_id = 0 or e.emp_id= @e_id) 
	   ) as ed
	LEFT JOIN
	(SELECT YPD.[RowE_ID],YPD.MMdate,
	        ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]  ELSE -YPD.[QUANTITY] END), 0) AS [QUANTITY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TAXTOTAL]  ELSE -YPD.[TAXTOTAL] END), 0) AS [TAXTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[TOTALMONEY] ELSE  -YPD.[TOTALMONEY] END),0) AS [SALETOTAL],
		
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0) AS [SENDQTY],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[SENDCOSTTOTAL]  ELSE -YPD.[SENDCOSTTOTAL] END),0) AS [SENDCOSTTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY  ELSE -YPD.SENDQTY*YPD.[TOTALMONEY]/YPD.QUANTITY END),0) AS [SENDTOTAL],
			ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (10,12,32,112,53,16,210)  THEN YPD.[QUANTITY]*YPD.[COSTPRICE]  ELSE -YPD.[QUANTITY]*YPD.[COSTPRICE] END), 0) AS [COSTTOTAL]
       FROM  
         (SELECT sm.RowE_id,sm.quantity,costprice,totalmoney,taxtotal,
                 sm.SendQTY,sm.SendCostTotal,B.billtype,SUBSTRING(convert(varchar(20),b.billdate,20),1,7) as MMdate   
            FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数                 */
            LEFT JOIN billidx   b  on sm.bill_id=b.billid
            LEFT JOIN Products  p  on p.product_id=SM.p_id
            LEFT JOIN employees RE on re.emp_id=SM.RowE_id
            LEFT JOIN storages  S  on S.storage_id=SM.ss_id
            LEFT JOIN Clients   C  on B.c_id=c.client_id
            LEFT JOIN employees E  on b.inputman=E.emp_id 
            LEFT JOIN Company   Y  on Y.Company_id=b.y_id            
            WHERE ([Billdate] BETWEEN   @szbegindate AND  @szenddate) and 
                  B.[billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and
                  [Billstates]=0 AND aoid in (0,5) and p_id>0  

          
         )YPD
       GROUP BY YPD.[ROWE_ID], YPD.MMdate
       ) SM on ed.emp_id = SM.RowE_id
       GROUP BY emp_id, Class_ID,sm.MMdate
       ORDER BY emp_id, SM.MMdate
            	  
	
	declare @upmonth varchar(20)
	declare @upyear varchar(20)
	declare @monthcolset varchar(50)
	declare @monthcolTotal varchar(50)
	declare @monthcolRata varchar(50)
	declare @monthsetValue numeric(18,2)
	declare @monthTotalValue numeric(18,2)	
	declare @upsql varchar(500)
	
	set @monthvalue = @szbegindate
	set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差            */
	while(@vardatedeff>0)
	begin
	  if LEN(convert(varchar(10),DATEPART(MM,@monthvalue))) =1 
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+'0'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	  else
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	   
	   /*XXX.2017-02-20  用来处理年月的对应关系（用时间月和职员id 关联是不唯一的），不然报表会错误*/
	  set @upyear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'
	      
	  set @monthcolset = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|任务额度'  /*得到月份列*/
	  set @monthcolTotal = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|完成额度' /*得到月份列*/
	  set @monthcolRata =  convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|完成比例' /*得到月份列*/
	  /*取设置的对应值select * from employeesSalesTotal*/
	  set @monthsetValue = 0
	  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 1
	  	  set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[OneM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	    /*select @monthsetValue = OneM  from employeesSalesTotal WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 2
		set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[twoM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	    /*select @monthsetValue = twoM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年' */
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 3
	  set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[threeM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	/*    select @monthsetValue = threeM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 4
	  set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[fourM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
/*	    select @monthsetValue = fourM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 5
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[fiveM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	   /* select @monthsetValue = fiveM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 6
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[sixM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	  /*  select @monthsetValue = sixM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 7
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[sevenM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	  /*  select @monthsetValue = sevenM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 8
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[eightM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	  /*  select @monthsetValue = eightM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 9
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[nineM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	  /*  select @monthsetValue = nineM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 10
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[tenM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	  /*  select @monthsetValue = tenM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 11
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[elenM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	 /*   select @monthsetValue = elenM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	  else  if convert(varchar(10),DATEPART(MM,@monthvalue)) = 12
	    set @upsql = 'update #tmp set ['+@monthcolset+'] = isnull(e.[twentyM],0)  from #tmp left join employeesSalesTotal e on #tmp.e_id = e.e_id and  e.OneYear = ''' + @upyear + ''''
	 /*   select @monthsetValue = twentyM  from employeesSalesTotal  WHERE OneYear = convert(varchar(10),DATEPART(YYYY,@monthvalue))+ '年'*/
	 exec(@upsql)		
		/*END--取设置的对应值*/

	  set @upsql = 'update #tmp set ['+@monthcolTotal+'] = #t.[TaxTotal] from #t where #t.e_id = #tmp.e_id and #t.MMdate ='+CHAR(39)+@upmonth+CHAR(39)
	  exec(@upsql)
	
	/* update #tmp set @monthcolset= #t.[TaxTotal],@monthcolTotal =  (cast( @monthsetValue  as numeric(25,8))) from #t where #t.e_id = #tmp.e_id and #t.MMdate =@upmonth*/
	  /****更新比率（注意未设置额度的就不能算比率）*****/
	  
	  set @upsql = 'update #tmp set ['+@monthcolRata+'] = ['+@monthcolTotal+']/['+@monthcolset+']  from #t where #t.e_id = #tmp.e_id and #t.MMdate ='+CHAR(39)+@upmonth+CHAR(39) + '  and ['+@monthcolset+'] > 0'
	  /*print @upsql*/
	  exec(@upsql)	  
	  set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20) 
	  set @vardatedeff = @vardatedeff -1
	end  
		
	SELECT * FROM #tmp
    drop table #tmp
    drop table #t            
end
GO
