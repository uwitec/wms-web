

/********************************/
/*******拣货无库存商品差错查询**********/
/********add by luowei 2013-10-15***********/
/********************************/


create procedure TS_L_RepJHQtyErrorSelect
(
   @szbegindate varchar(20),  /*-开始时间*/
   @szenddate   varchar(20),  /*-结束时间*/
   @nc_id       int,          /*-往来单位id*/
   @ne_id       int           /*-职员id*/
)
as
begin

	/*-------拣货单库存不足未过账单据（未启用'jhBillAudit'） */
	select i.billnumber,billdate,cx.checkdate as auditdate,p.product_id,p.name,p.serial_number,p.standard,p.makearea,p.permitcode,isnull(p.MedName,'') as medtype,u.name as unitname,sm.quantity as billqty,
	(sm.quantity-sm.SendQTY) as needqty,sm.SendQTY,sm.saleprice,((sm.quantity-sm.SendQTY)*saleprice) as needtotal,
	PackStd,l.loc_name,s.name as storagename,cname,ename,i.note
	 from salemanagebilldrf sm 
	inner join vw_c_billdraftidx i on sm.bill_id = i.billid
	left join vw_Products p on sm.p_id = p.product_id
	left join storages s on sm.ss_id = s.storage_id
	left join location l on sm.location_id = l.loc_id
	left join unit u on sm.unitid = u.unit_id
	left join (select * from checkidx where IsDraft = 1) cx on sm.bill_id = cx.billid
	where sm.AOID = 7 and sm.batchprice = 0 
	      and i.billdate between @szbegindate and @szenddate  
	      and (@nc_id = 0 or i.c_id = @nc_id)
	      and (@ne_id = 0 or i.e_id = @ne_id)

	union all 
	/*--拣货单库存不足过账单据(启用'jhBillAudit')*/
	select i.billnumber,i.billdate,cx.checkdate as auditdate,p.product_id,p.name,p.serial_number,p.standard,p.makearea,p.permitcode,isnull(p.MedName,'') as medtype,u.name as unitname,(sm.quantity+batchprice) as billqty,
	batchprice as needqty,sm.SendQTY,sm.saleprice,(batchprice*saleprice) as needtotal,
	PackStd,l.loc_name,s.name as storagename,cname,ename,i.note
	 from salemanagebilldrf sm 
	inner join vw_c_billdraftidx i on sm.bill_id = i.billid
	left join vw_Products p on sm.p_id = p.product_id
	left join storages s on sm.ss_id = s.storage_id
	left join location l on sm.location_id = l.loc_id
	left join unit u on sm.unitid = u.unit_id
	left join (select * from checkidx where IsDraft = 1) cx on sm.bill_id = cx.billid
	where sm.AOID = 7 and sm.batchprice <> 0
	and i.billdate between @szbegindate and @szenddate  
    and (@nc_id = 0 or i.c_id = @nc_id)
    and (@ne_id = 0 or i.e_id = @ne_id)

end
GO
