CREATE FUNCTION vtLogisticsHaveColdMedi
(
	@BillId    INT,
	@BillType  INT 
)
RETURNS INT
AS
BEGIN
	DECLARE @Result INT 
	SET @Result = -1
	IF @BillType IN (10, 11, 212, 21, 150, 152)
	BEGIN
		IF EXISTS(SELECT TOP 1 s.smb_id FROM salemanagebill s INNER JOIN products p ON s.p_id = p.product_id 
		          WHERE s.bill_id = @BillId AND p.StoreCondition = 2)
		  SET @Result = 1
	END
	ELSE
	IF @BillType IN (21)
	BEGIN
		IF EXISTS(SELECT TOP 1 s.smb_id FROM buymanagebill s INNER JOIN products p ON s.p_id = p.product_id 
		          WHERE s.bill_id = @BillId AND p.StoreCondition = 2)
		  SET @Result = 1
	END
	ELSE
	IF @BillType = 186	
	BEGIN
		IF EXISTS(
		       SELECT TOP 1 a.Flag
		       FROM   (
		                  SELECT dbo.vtLogisticsHaveColdMedi(b.billid, b.billtype) AS 
		                         Flag
		                  FROM   billidx b
		                  WHERE  b.billid IN (SELECT s.billid
		                                      FROM   Sendmangebill s
		                                      WHERE  s.sendid = @BillId)
		              ) a
		       WHERE  a.Flag > 0
		   )
			SET @Result = 1 
	END
	RETURN @Result 
END
GO
