
Create FUNCTION [dbo].[OutBatchByP_Fliter] (@nP_id int,@ntag int)  
returns @retSaleQty table 
  (
   bill_id int,
   p_id int,
   s_id int,
   batchno varchar(50),
   supplier_id int,
   location_id int,
   commissionflag int,
   costprice numeric(25,8),
   validdate datetime,
   quantity numeric(25,8),
   instoretime datetime
  )
AS  
begin
  declare @CheckSaleQty char(1)
	declare @nCalcOrder int
	set @nCalcOrder = 0
	set @CheckSaleQty='0'
	select @CheckSaleQty=sysvalue from sysconfig where [sysname]='CheckSaleQty'/*存草稿是是否检测可开数量*/
	if exists(select * from sysconfigtmp where sysname = 'GspStandardProcess' and sysvalue = '1')
		set @nCalcOrder = 1
  if @CheckSaleQty='0' or @CheckSaleQty='1'
  begin
    insert @retSaleQty  
    select k.bill_id,k.p_id,k.ss_id as s_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate,isnull(sum(quantity),0) as quantity, k.instoretime
    from (
     select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
     from salemanagebilldrf sb,billdraftidx b 
     where (@nCalcOrder = 0) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and sb.aoid in (0,7)
     and (@ntag = 0 or  not exists(select 1 from billdraftidx where billid = sb.invoiceno and billtype = 44))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all 
     select sb.invoiceno as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
     from salemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and sb.aoid in (0,7)
     and (@ntag <>0 and exists(select 1 from billdraftidx where billid = sb.invoiceno and billtype = 44))
     group by sb.invoiceno,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all   
     select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (21,121,221) then -sb.quantity else sb.quantity end) as quantity
     from buymanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (21,121,221) and sb.aoid in (0,7)
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id, sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (40,41,44,45,47,49) then -sb.quantity else sb.quantity end) as quantity
     from storemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (40,41,44,45,49) and sb.aoid in (0,7) 
     and (@ntag = 0 or (@ntag<> 0 and sb.comment <> '自动拆零'))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id, sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (51) then -sb.quantity else sb.quantity end) as quantity
     from storemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (51) and sb.aoid in (0,7) and sb.iotag = 1 
     and (@ntag = 0 or (@ntag<> 0 and sb.comment <> '自动拆零'))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (53,56) then -sb.quantity else sb.quantity end) as quantity
     from tranmanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (53,56) and sb.aoid in (0,7)
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select  0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (14) then -sb.quantity else sb.quantity end) as quantity
    	from OrderBill sb,orderidx b 
    	where (@nCalcOrder = 1) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (14) and b.billstates <> 0
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    ) k
    group by k.bill_id,k.p_id,k.ss_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate, k.instoretime
    
  end else if @CheckSaleQty='2'
  begin
    insert @retSaleQty  
    select k.bill_id,k.p_id,k.ss_id as s_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate,isnull(sum(quantity),0) as quantity, k.instoretime
    from (
     select 0 as bill_id ,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
     from salemanagebilldrf sb,billdraftidx b 
     where  (@nCalcOrder = 0) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and b.billstates in ('3','7','8') and sb.aoid in (0,7)
     and (@ntag = 0 or not exists(select 1 from billdraftidx where billid = sb.invoiceno and billtype = 44))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select sb.invoiceno as bill_id ,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
     from salemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and b.billstates in ('3','7','8') and sb.aoid in (0,7)
     and (@ntag <> 0 and exists(select 1 from billdraftidx where billid = sb.invoiceno and billtype = 44))
     group by sb.invoiceno,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all 
     select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (21,121,221) then -sb.quantity else sb.quantity end) as quantity
     from buymanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (21,121,221) and b.billstates in ('3','7','8') and sb.aoid in (0,7)
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id, sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (40,41,44,45,47,49) then -sb.quantity else sb.quantity end) as quantity
     from storemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (40,41,44,45,49) and b.billstates='3' and sb.aoid in (0,7)
     and (@ntag = 0 or (@ntag <> 0 and sb.comment <> '自动拆零'))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id, sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (51) then -sb.quantity else sb.quantity end) as quantity
     from storemanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (51) and b.billstates='3' and sb.aoid in (0,7) and iotag = 1
     and (@ntag = 0 or (@ntag <> 0 and sb.comment <> '自动拆零'))
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
     union all
     select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
     sum(case when b.billtype in (53,56) then -sb.quantity else sb.quantity end) as quantity
     from tranmanagebilldrf sb,billdraftidx b 
     where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (53,56) and b.billstates='3' and sb.aoid in (0,7)
     group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select 0 as bill_id,sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (14) then -sb.quantity else sb.quantity end) as quantity
    	from OrderBill sb,orderidx b 
    	where (@nCalcOrder = 1) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (14) and b.billstates in ('3')
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    ) k
    group by k.bill_id,k.p_id,k.ss_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate, k.instoretime
  end
  return
end
GO
