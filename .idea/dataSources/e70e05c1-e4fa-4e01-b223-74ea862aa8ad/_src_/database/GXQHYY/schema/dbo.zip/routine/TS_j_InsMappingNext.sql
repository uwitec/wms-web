
/*添加自定义类别  zjl 2013-05-08*/
create  PROCEDURE TS_j_InsMappingNext
(	
	@CG_ID 		int,
	@info_ID	int=0,
	@CpType     int/*判断是单位还是商品还是机构*/
)
AS




declare @nRet int
set @nRet = 0
declare @szClass_id varchar(12)
declare @id int
/*if @CpType=0 
begin
	select @szClass_id = class_id from customCategory where id = @CG_ID
	if exists(select 1 from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid<>0 and baseinfo_id = @info_ID)  
	begin
	  set @nRet = -1
	  RAISERROR('在同一类别组下不允许重复添加多个类别！',16,1)
	  return @nRet                
	end
end*/
set nocount on
 /* if not exists(select 1 from customCategoryMapping   where category_id = @CG_ID and baseinfo_id = @info_ID) */
/*  begin*/
    if @CpType=0 
    begin 
        select @szClass_id = class_id from customCategory where id = @CG_ID
       
        if exists(select 1 from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0)  
	    begin
	        select @id=cm.id from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0
	     
	       update  customCategoryMapping set deleted=1  where id=@id  
	       insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,0,0)
           select @nRet= @@IDENTITY
        end
        else
        begin
           insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,0,0)
           select @nRet= @@IDENTITY
        end
    end
    if @CpType=1 
    begin
        select @szClass_id = class_id from customCategory where id = @CG_ID
        
        if exists(select 1 from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0)  
	    begin
	        select @id=cm.id from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0
	       
	       update  customCategoryMapping set deleted=1  where id=@id  
	       insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,1,0)
            select @nRet= @@IDENTITY
        end
        else
        begin
           insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,1,0)
           select @nRet= @@IDENTITY
        end
    end
    if @CpType=2
    begin
      select @szClass_id = class_id from customCategory where id = @CG_ID
        if exists(select 1 from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0)  
	    begin
	        select @id=cm.id from customCategoryMapping cm 
			   inner join customCategory cg on cm.category_id = cg.id 
			   where LEFT(cg.class_id, 2) = LEFT(@szClass_id, 2) and  cg.typeid=0 and baseinfo_id = @info_ID and cm.deleted=0
	       update  customCategoryMapping set deleted=1 where id=@id  
	       insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,2,0)
           select @nRet= @@IDENTITY
        end
        else
        begin
           insert into customCategoryMapping(category_id, baseinfo_id,BaseTypeid,deleted)
           values(@CG_ID, @info_ID,2,0)
            select @nRet= @@IDENTITY
        end
    end
 /* end   */
/* else */
  /*  set @nRet = 1        */

return @nRet
GO
