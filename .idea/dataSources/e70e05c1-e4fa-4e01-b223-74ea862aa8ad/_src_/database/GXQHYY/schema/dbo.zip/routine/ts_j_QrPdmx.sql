/************************************************************

--功能：直接录入盘点数据时查询盘点明细   
--创建人：Zhou JiLin 
--创建时间：2010-11-03  
--最后修改:
--修改说明：

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_QrPdmx]
  ( @nP_id int,
    @nPdidx int,
    @nPDflag int = 2
  )
AS 
/*Params Ini begin*/
if @nPDflag is null  SET @nPDflag = 2
/*Params Ini end*/

  select s.name  as sname, pd.*, p.name, p.serial_number, p.standard, p.makearea, isnull(l.loc_name, ' ') as loc_name
    from PdPlan pd 
    left join storages s on pd.s_id = s.storage_id 
    left join products p on pd.p_id = p.product_id
    left join location l on pd.location_id = loc_id
      where (@nP_id = 0 or pd.p_id = @nP_id) and pd.pdidx = @nPdidx and (@nPDflag = 2 or pd.PDFlag = @nPDflag)
GO
