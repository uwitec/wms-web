
CREATE PROCEDURE Ts_K_PaymentRequestCreatePaymentBill(
	@nRet          INT OUTPUT, 
	@nType	       INT,           /*类型，0业务部经理审核；1业务总经理审核*/
	@EId           INT,           /*审核人ID*/
	@RequestId     INT            /*付款申请单Id*/
)
AS
BEGIN
	/*付款申请单生成付款单*/
	DECLARE @szError VARCHAR(800)
	SET @nRet = 0
	
	IF @nType = 0
	BEGIN
		/*检查业务部经理是否已经审核过单据*/
		IF EXISTS(SELECT 1 FROM PaymentRequestIdx a WHERE a.BillId = @RequestId AND a.B_Id > 0)
		BEGIN
			SET @nRet = -1
			RAISERROR('业务部经理已经审核过此单据！', 16, 1)
			RETURN -1
		END
	END
	ELSE
	IF @nType = 1
	BEGIN
		/*检查业务总经理是否已经审核过单据*/
		IF EXISTS(SELECT 1 FROM PaymentRequestIdx a WHERE a.BillId = @RequestId AND a.Z_Id > 0)
		BEGIN
			SET @nRet = -2
			RAISERROR('业务总经理已经审核过此单据！', 16, 1)
			RETURN -2
		END	
	END
	ELSE
	BEGIN
		SET @nRET = -99
		RAISERROR('执行参数类型错误！', 16, 1)
		RETURN -99	
	END
	
	/*检查申请单状态是否处于可审核状态中*/
	IF EXISTS(SELECT 1 FROM PaymentRequestIdx a WHERE a.BillId = @RequestId AND a.BillStates IN (2, 3))
	BEGIN
		SET @nRet = -3
		RAISERROR('此单据已审核或未通过，不允许重复操作！', 16, 1)
		RETURN -3
	END	
	
	DECLARE @States INT
	
	BEGIN TRAN CreatePaymentBill
	
	IF @nType = 0
		UPDATE PaymentRequestIdx SET B_Id = @EId, B_AuditDate = GETDATE(), BillStates = 1 WHERE BillId = @RequestId
	ELSE
		UPDATE PaymentRequestIdx SET Z_Id = @EId, Z_AuditDate = GETDATE(), BillStates = 1 WHERE BillId = @RequestId
	
	
	
	IF EXISTS(SELECT 1 FROM PaymentRequestIdx a WHERE a.BillId = @RequestId AND a.B_Id > 0 AND a.Z_Id > 0 AND a.BillStates IN (0, 1))
	BEGIN
		/*两个经理都审核了，生成付款单*/
		UPDATE PaymentRequestIdx SET BillStates = 2 WHERE BillId = @RequestId
		
		DECLARE @szBillNumber VARCHAR(200), @szRequestNumber VARCHAR(200)
		DECLARE @YId INT, @PayBillId INT
		DECLARE @GUID UNIQUEIDENTIFIER
		
		SET @GUID = NEWID()
		SELECT @szRequestNumber = BillNumber, @YId = YId
		  FROM PaymentRequestIdx WHERE BillId = @RequestId
		EXEC TS_H_CreateBillSN;1 23, 1, NULL, 0, 0, @szBillNumber OUTPUT, @YId
		
		INSERT INTO billdraftidx
		(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, 
		 quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag,
		 note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan,
		 VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate,
		 sendC_id, WholeQty, PartQty, DPdate, QualityAudit, QualityAuditDate, YGuid, financeAudit, financeAuditDate, FollowNumber, TicketDate, BalanceMode)
		SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, 23, 0, C_Id, @EId, 0, 0, 0, @EId, Total, Total,
		       0, 0, 0, 2, 0, 0, 0, 0, '1900-01-01', '1900-01-01', 0, 'P',
		       '付款申请单【' + @szRequestNumber + '】生成', '付款申请单【' + @szRequestNumber + '】生成', 0, 0, '1900-01-01', @GUID, 0, '', 0, 0, 0, @EId,
		       0, 0, @YId, 0, '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 
		       0, 0, 0, '1900-01-01', 0, '1900-01-01', 0x0, 0, '1900-01-01', '', '1900-01-01', -1
			FROM PaymentRequestIdx 
		WHERE BillId = @RequestId 	
		
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -4
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单主表出错！', 16, 1)
			RETURN -4
		END
		SET @PayBillId = @@identity 
		
		INSERT INTO financebilldrf
		(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, 
		 InvoiceTotal, RowGuid, Y_Id, Conclusion, factoryid, costtaxprice, costtaxrate, costtaxtotal)
		SELECT @PayBillId, 6, C_Id, Total, 0, '', '', '', 
		       0, NEWID(), @YId, '', 0, 0, 0, 0
		  FROM PaymentRequestIdx 
		WHERE BillId = @RequestId
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -5
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单明细表出错！', 16, 1)
			RETURN -5
		END
		
		INSERT INTO jspdetail
		(c_id, skd_bid, xsd_bid, billtype, quantity, jstotal, detail_id, yj_quantity,
		 flag, billguid, Y_Id, skdGuid, xsdGuid, DetailGuid, RowGuid, transflag)
		SELECT b.c_id, @PayBillId, b.billid, b.billtype, s.quantity, s.taxtotal, s.smb_id, 0,
		       1, b.GUID, @YId, @GUID, b.GUID, s.RowGuid, NEWID(), 0    
			FROM PaymentRequestBill p 
				INNER JOIN billidx b ON p.Bill_Id = b.billid 
				INNER JOIN buymanagebill s ON s.smb_id = p.Detail_id
		WHERE p.PaymentRequestId = @RequestId
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -6
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单按行结算明细表出错！', 16, 1)
			RETURN -6
		END
		UPDATE PaymentRequestIdx 
			SET PaymentBillId = @PayBillId 
		WHERE BillId = @RequestId 
		
		SET @nRet = 1
	END	
	COMMIT TRAN CreatePaymentBill
	
	
	
	
END
GO
