




CREATE  FUNCTION [OutBatchNotS] ( )  
RETURNS table
AS
 return (
 select k.p_id,  isnull(sum(quantity),0) as quantity
 /*,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,*/
 from (
  select sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate,
  sum(case when b.billtype in (10,110)  then -sb.quantity else sb.quantity end) as quantity
  from salemanagebilldrf sb,billdraftidx b 
  where sb.bill_id=b.billid   and b.billtype in (10,110) and sb.aoid in (0,7)
  group by sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate
  union all 
  select sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate,
  sum(case when b.billtype in (21,121) then -sb.quantity else sb.quantity end) as quantity
  from buymanagebilldrf sb,billdraftidx b 
  where sb.bill_id=b.billid  and b.billtype in (21,121) and sb.aoid in (0,7)
  group by sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate
  union all
  select sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate,
  sum(case when b.billtype in (40,41,44,45,47,49) then -sb.quantity else sb.quantity end) as quantity
  from storemanagebilldrf sb,billdraftidx b 
  where sb.bill_id=b.billid  and b.billtype in (40,41,44,45,49) and sb.aoid in (0,7)
  group by sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate
  union all
  select sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate,
  sum(case when b.billtype in (53) then -sb.quantity else sb.quantity end) as quantity
  from tranmanagebilldrf sb,billdraftidx b 
  where sb.bill_id=b.billid and b.billtype in (53) and sb.aoid in (0,7)
  group by sb.p_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate
 ) k
 group by k.p_id
/* group by k.p_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice*/
 )
GO
