
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_CLIENTS
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/


select * into #C from FilterClient(@nY_ID)/*yypeng-2017-04-17--优化直接选择往来单位慢的情况*/


  if @nShowStatus =-100
  begin
	select * from #C where  deleted =0  and Parent_id=@parent_id
  end else
  begin
	begin
	  set @ClientFlags = SUBSTRING(@szWhere, 1, 1) 
	  if @szListFlag=''  goto ListLeavelc1
	  if @szListFlag='A' goto ListAllc1
	  if @szListFlag='P' goto ListPartc1
	  if @szListFlag='S' goto SearchAllc1
	  return 0 
	  listLeavelc1:
		/*if @szWhere='0' or @szWhere='1'*/
		if (@ClientFlags = '0') or (@ClientFlags = '1')
			select distinct c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0 OR Parent_id=@parent_id) u
				on c.client_id = u.Client_ID
			where (c.parent_id=@parent_id) and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0)) and (csFlag=@ClientFlags or csFlag=2) 
		else
		if SUBSTRING(@szWhere, 1, 1) = '3'
		begin
			set @nFilterY = CAST(SUBSTRING(@szWhere, 3, 10) as int)
			select distinct c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0 OR Parent_id=@parent_id) u
				on c.client_id = u.Client_ID
			where (c.parent_id=@parent_id) and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0)) and (csFlag=0 or csFlag=2) 
				and (c.jsdw_id > 0) and (c.jsdw_id = @nFilterY OR @nFilterY = 0)
		end
		else

			select distinct c.* 

			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0 OR Parent_id=@parent_id) u
				on c.client_id = u.Client_ID
			where (c.Parent_id=@parent_id) and ((@nShowStatus =0 and c.deleted in(0,4,5)) or (@nShowStatus =1 and c.deleted = 0))
		return 0
	  listAllc1:
		   if @ClientFlags='0' or @ClientFlags='1'
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			where (c.child_number=0) and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0)) and (csFlag=@ClientFlags or csFlag=2)
		   else
		if SUBSTRING(@szWhere, 1, 1) = '3'
		begin
			set @nFilterY = CAST(SUBSTRING(@szWhere, 3, 10) as int)
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			where (c.child_number=0) and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0)) and (csFlag=0 or csFlag=2)
				and c.jsdw_id > 0 and (c.jsdw_id = @nFilterY OR @nFilterY = 0)
		end
		   else
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			and (c.child_number=0)  and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0))
		   return 0
	  listPartc1:
		   if @ClientFlags='0' or @ClientFlags='1'
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			where (c.child_number=0) and (left(c.Parent_id,len(@parent_id))=@parent_id) and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0)) and (csFlag=@ClientFlags or csFlag=2) 
		   else
		if SUBSTRING(@szWhere, 1, 1) = '3'
		begin
			set @nFilterY = CAST(SUBSTRING(@szWhere, 3, 10) as int)
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			where (c.child_number=0) and (left(c.Parent_id,len(@parent_id))=@parent_id) and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0)) and (csFlag=0 or csFlag=2) 
				and c.jsdw_id > 0 and (c.jsdw_id = @nFilterY OR @nFilterY = 0)
		end
		   else
			select c.* 
			from #C c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
			ON c.client_id=u.client_id
			where (c.child_number=0) and (left(c.parent_id,len(@parent_id))=@parent_id) and (@nShowStatus = 0 or (@nShowStatus = 1 and c.deleted = 0))
		   return 0
	  SearchAllc1:
	   set @sql='select distinct c.* 
		from FilterClient('+cast(@nY_ID as varchar(10))+') c Inner join (select client_id from AuthorizeClients('+cast(@E_id as varchar(10))+') where Child_Number=0) u
			ON c.client_id=u.client_id
		where (c.child_number=0)  and '+@szWhere
	   if @nShowStatus = 1 
		 set @sql=@sql + 'and c.deleted = 0'
	   exec (@sql)
	   return 0
 end
 end
GO
