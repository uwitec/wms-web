

CREATE FUNCTION GetRetailRate(@szProduct_id int=0,@nUnitMode int =1)
RETURNS varchar(80) 
AS

BEGIN 

declare @RetailPrice numeric(25,8)

if @nUnitMode=1
  select @RetailPrice=1
if @nUnitMode=2
  select @RetailPrice=isnull(Rate2,0) from products p where p.Product_id=@szProduct_id 
if @nUnitMode=3
  select @RetailPrice=isnull(Rate3,0) from products p where p.Product_id=@szProduct_id 
if @nUnitMode=4
  select @RetailPrice=isnull(Rate4,0) from products p where p.Product_id=@szProduct_id 

RETURN( cast(@RetailPrice as varchar(80) )  )



	
END
GO
