

CREATE	VIEW dbo.vw_b_unit
AS
SELECT unit_id as u_id, name as u_name
FROM unit
WHERE deleted = 0
GO
