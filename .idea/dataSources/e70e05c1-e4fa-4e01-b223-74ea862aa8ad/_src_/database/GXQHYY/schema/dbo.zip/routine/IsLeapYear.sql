
CREATE FUNCTION IsLeapYear( @AYear  INT)
RETURNS BIT AS  
BEGIN 
  IF (@AYear % 4 = 0) and ((@AYear % 100 <> 0) or (@AYear % 400 = 0))  RETURN 1 
  RETURN 0
END
GO
