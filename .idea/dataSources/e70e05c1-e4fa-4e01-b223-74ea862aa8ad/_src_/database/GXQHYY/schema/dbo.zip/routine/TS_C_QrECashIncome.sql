



/*职员现金回款明细*/
CREATE PROCEDURE [TS_C_QrECashIncome]
( @BeginDate 	DATETIME=0,
  @EndDate	DATETIME=0,
  @nEmployeeID  INT=0,
  @nEmpID 	INT=0,
  @nAuditID     INT=0,         
  @nInputID     INT=0,
  @nGetMoneyID  Int=0,
  @nYClassID    varchar(50)='',
  @nloginEID    int=0,
  @isaddDate    int=0/*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nEmployeeID is null  SET @nEmployeeID = 0
if @nEmpID is null  SET @nEmpID = 0
if @nAuditID is null  SET @nAuditID = 0
if @nInputID is null  SET @nInputID = 0
if @nGetMoneyID is null  SET @nGetMoneyID = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
SET NOCOUNT ON

  Declare @Companytable int,@employeestable int


  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/
IF @nYClassID=''   select @nYClassID='%%'  else  select @nYClassID=@nYClassID+'%'


BEGIN
    SELECT E.[Emp_ID], E.[Serial_Number], E.[Class_ID], E.[Name], E.[Alias],
           ISNULL(SUM(B.[SaleAlltotal])              ,0) AS [SaleAlltotal],
           ISNULL(SUM(B.[ArAlltotal]-B.[ApAlltotal]) ,0) AS [ArAlltotal],
           ISNULL(SUM(B.[SaleTotal])                 ,0) AS [SaleTotal],
	   ISNULL(SUM(B.[SalebackTotal])             ,0) AS [SalebackTotal],
	   ISNULL(SUM(B.[Brsaletotal])               ,0) AS [BrsaleTotal],
	   ISNULL(SUM(B.[Retailtotal])               ,0) AS [RetailTotal],
	   ISNULL(SUM(B.[Retailbacktotal])           ,0) AS [RetailbackTotal],
	   ISNULL(SUM(B.[AdujstTotal])               ,0) AS [AdujstTotal],
	   ISNULL(SUM(B.[AdujstBackTotal])           ,0) AS [AdujstBackTotal],
	   ISNULL(SUM(B.[Sktotal])                   ,0) AS [SkTotal],
	   ISNULL(SUM(abs(B.[Fktotal]))              ,0) AS [FkTotal],
           ISNULL(SUM(B.[TrangetTotal])              ,0) AS [TrangetTotal],
	   ISNULL(SUM(B.[TranbackTotal])             ,0) AS [TranbackTotal],
	   ISNULL(SUM(B.[Commissiontotal])           ,0) AS [CommissionTotal],
	   ISNULL(SUM(B.[Othertotal])                ,0) AS [OtherTotal]
    FROM
        (SELECT E.[Emp_ID], E.[Serial_Number], E.[Class_ID], E.[Name], E.[Alias]
         FROM Employees  E
         WHERE (E.[Child_Number]=0 AND E.[Deleted]=0) AND (@nEmployeeID=0 or E.[Emp_ID]=@nEmployeeID)
         AND (@employeestable=0 or E.[Emp_ID] in (select [id] from #employeestable))        
        ) AS E 
	LEFT JOIN
        (SELECT E.[Emp_ID],
	   (0)                                                           AS [SaleAlltotal],
	   (0)                                                           AS [ArAlltotal],
	   (0)                                                           AS [ApAlltotal],
	   SUM(CASE WHEN BI.[Billtype] in (10,210)  THEN AD.[JDMoney] ELSE 0 END) AS [Saletotal],
	   SUM(CASE WHEN BI.[Billtype] in (11,212)  THEN AD.[JDMoney] ELSE 0 END) AS [SalebackTotal],
	   SUM(CASE WHEN BI.[Billtype]=32           THEN AD.[JDMoney] ELSE 0 END) AS [BrsaleTotal],
	   SUM(CASE WHEN BI.[Billtype]=12           THEN AD.[JDMoney] ELSE 0 END) AS [RetailTotal],
	   SUM(CASE WHEN BI.[Billtype]=13           THEN AD.[JDMoney] ELSE 0 END) AS [RetailbackTotal],
	   SUM(CASE WHEN BI.[Billtype]=16           THEN AD.[JDMoney] ELSE 0 END) AS [AdujstTotal],
	   SUM(CASE WHEN BI.[Billtype]=17           THEN AD.[JDMoney] ELSE 0 END) AS [AdujstBackTotal],
	   SUM(CASE WHEN BI.[Billtype]=15           THEN AD.[JDMoney] ELSE 0 END) AS [SkTotal],
	   SUM(CASE WHEN BI.[Billtype]=23           THEN AD.[JDMoney] ELSE 0 END) AS [FkTotal],
           SUM(CASE WHEN BI.[Billtype]=53           THEN AD.[JDMoney] ELSE 0 END) AS [TrangetTotal],
	   SUM(CASE WHEN BI.[Billtype]=54           THEN AD.[JDMoney] ELSE 0 END) AS [TranbackTotal],
	   SUM(CASE WHEN BI.[Billtype]=112          THEN AD.[JDMoney] ELSE 0 END) AS [CommissionTotal],
           SUM(CASE WHEN BI.[Billtype] NOT IN (10, 32, 11, 12, 13, 16, 17, 15, 23,53,54, 112,210,212) 
              THEN AD.[JDMoney] ELSE 0 END) AS [OtherTotal]
         FROM (SELECT AD.Billid,AD.A_id,AD.JDmoney,isnull(Y.class_id,'') as Yclass_id  FROM ACCOUNTDetail AD
               Inner join COMPANY Y ON Y.company_id=AD.Y_id
               where Y.class_id like @nYClassID
               UNION               
               SELECT YAD.billid,YAD.a_id,YAD.jdmoney,isnull(Y.class_id,'') as Yclass_id  from YACCOUNTDETAIL YAD
               Inner join COMPANY Y ON Y.company_id=YAD.Y_id
               where Y.class_id like @nYClassID
              ) AD
         LEFT JOIN VW_C_BillIDX BI ON AD.[BillID]=BI.[BillID]
         INNER JOIN (SELECT E.Emp_ID from Employees E where Deleted=0)E   ON E.[Emp_ID]=BI.[E_ID]
         WHERE BI.YClass_id like @nYClassID and BI.[Billstates]=0 AND AD.[A_ID]=6  AND BI.[Billdate] BETWEEN @BeginDate AND  @EndDate 
         AND (@nEmpID=0 or BI.[E_ID]=@nEmpID)
         AND (@nAuditID=0 or BI.[AuditMan]=@nAuditID)
         AND (@nInputID=0 or BI.[InputMan]=@nInputID)
         AND (@nGetMoneyID=0 or BI.[GatheringMan]=@nGetMoneyID)
         
         AND (@employeestable=0 or BI.[E_ID] in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[AuditMan]in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[InputMan] in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[GatheringMan] in (select [id] from #employeestable))
         AND (@Companytable=0   or BI.[Y_id] in (select [id] from #Companytable))
         GROUP BY E.[Emp_ID]
         UNION
         SELECT E.[Emp_ID],
		 SUM(CASE WHEN AD.[A_ID]=20  THEN AD.[JDMoney] ELSE 0 END) AS [SaleAlltotal],
		 SUM(CASE WHEN AD.[A_ID]=9   THEN AD.[JDMoney] ELSE 0 END) AS [ArAlltotal],
		 SUM(CASE WHEN AD.[A_ID]=15  THEN AD.[JDMoney] ELSE 0 END) AS [ApAlltotal],
		 (0) AS [Saletotal],
		 (0) AS [SalebackTotal],
		 (0) AS [BrsaleTotal],
		 (0) AS [RetailTotal],
		 (0) AS [RetailbackTotal],
		 (0) AS [AdujstTotal],
		 (0) AS [AdujstBackTotal],
		 (0) AS [SkTotal],
		 (0) AS [FkTotal],
                 (0) AS [TrangetTotal],
		 (0) AS [TranbackTotal],
		 (0) AS [CommissionTotal],
                 (0) AS [OtherTotal]
         FROM (SELECT AD.Billid,AD.A_id,AD.JDmoney,isnull(Y.class_id,'') as Yclass_id  FROM ACCOUNTDetail AD
               Inner join COMPANY Y ON Y.company_id=AD.Y_id
               where Y.class_id like @nYClassID
               UNION ALL              
               SELECT YAD.billid,YAD.a_id,YAD.jdmoney,isnull(Y.class_id,'') as Yclass_id  from YACCOUNTDETAIL YAD
               Inner join COMPANY Y ON Y.company_id=YAD.Y_id
               where Y.class_id like @nYClassID
              ) AD
         LEFT JOIN VW_C_BillIDX BI ON AD.[BillID]=BI.[BillID]
         INNER JOIN (select E.[Emp_ID] from Employees E where deleted=0 and child_number=0)E    ON E.[Emp_ID]=BI.[E_ID]
  	 WHERE BI.YClass_id like @nYClassID and BI.[Billstates]=0 AND  AD.[A_ID] IN (9, 15, 20)  AND BI.[Billdate] BETWEEN @BeginDate AND  @EndDate
         AND (@nEmpID=0 or BI.[E_ID]=@nEmpID)
         AND (@nAuditID=0 or BI.[AuditMan]=@nAuditID)
         AND (@nInputID=0 or BI.[InputMan]=@nInputID)
         AND (@nGetMoneyID=0 or BI.[GatheringMan]=@nGetMoneyID)
         
         AND (@employeestable=0 or BI.[E_ID] in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[AuditMan]in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[InputMan] in (select [id] from #employeestable))
         AND (@employeestable=0 or BI.[GatheringMan] in (select [id] from #employeestable))
         AND (@Companytable=0   or BI.[Y_id] in (select [id] from #Companytable)) 
         GROUP BY E.[Emp_ID]
        ) AS B
      ON E.[Emp_ID]=B.[Emp_ID]
      GROUP BY E.[Emp_ID], E.[Serial_Number], E.[Class_ID], E.[Name], E.[Alias]
      ORDER BY E.[Emp_ID]
END
GO
