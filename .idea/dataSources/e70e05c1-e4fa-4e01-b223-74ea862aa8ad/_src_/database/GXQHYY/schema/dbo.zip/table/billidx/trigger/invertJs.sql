

CREATE  TRIGGER invertJs ON [dbo].[billidx]
FOR  UPDATE
AS
declare @nBilltype int ,@nBillid int,@szJsFlag varchar(2),@cBillStates char(1),@nReturnNumber int,@nCid int,@nEid int,@nY_ID int,@nGatheringMan int
declare @nOldEid int,@nOldGatheringMan int
if update(billstates)
begin
 select @nBilltype=billtype,@nBillid=billid,@szjsflag=jsflag ,@cBillStates=billstates,@nCid=c_id,@nEid=e_id , @nY_id = y_id,@nGatheringMan=GatheringMan
 from inserted
 if @nBilltype in (15,23,155,165,170) and @cBillStates in('1')
 begin
  exec @nReturnNumber=ts_c_SFKJs @nBillid,@nBilltype,@szJsFlag,'1'
  if @nReturnNumber<>0 rollback tran
 end
 if @nbilltype in (53,44,45) and @cBillStates in('1')
 begin
  delete from tasklist where billid=@nbillid
 end
 if @nBilltype not in (12,13) and @cBillStates='0'
 begin
  if exists(select top 1 * from traceemployee where c_id=@nCid and vchtype=@nbilltype and y_id = @ny_ID)
  begin
   select @nOldEid=e_id,@nOldGatheringMan=GatheringMan from traceemployee where c_id=@nCid and vchtype=@nbilltype and y_id = @ny_ID
   if (@nOldEid<>@nEid)or(@nOldGatheringMan<>@nGatheringMan) update traceemployee set e_id=@nEid,GatheringMan=@nGatheringMan where c_id=@nCid and vchtype=@nbilltype and y_id = @ny_ID
  end else
  begin
   insert TraceEmployee(c_id,vchtype,e_id,y_id,GatheringMan) values (@ncid,@nbilltype,@neid,@nY_ID,@nGatheringMan)
  end
 end 
end
GO
