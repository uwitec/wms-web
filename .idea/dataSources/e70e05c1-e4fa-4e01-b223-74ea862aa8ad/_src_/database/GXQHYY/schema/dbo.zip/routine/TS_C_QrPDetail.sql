
/*TS_C_QrPDetail '2015-05-01 00:00:00','2017-05-25 00:00:00',13,2,4,0,0,0,0,0,'000001',2,0*/
/******************************************

库存商品明细帐本

********************************************/
CREATE  PROCEDURE TS_C_QrPDetail
(	@BeginDate 	  DATETIME,
	@EndDate 	  DATETIME,
	@nP_Id 		  INT=0,
	@nS_Id 		  INT=0,
	@nStoreType       INT=0,
	@nCommissionflag  INT=0,
  	@nBillType        INT=0,
  	@nOrderType       INT=0,
	@iniQuantity 	  numeric(25,8) OUTPUT,
	@iniCostTotal     numeric(25,8) OUTPUT,
        @nYClassID        varchar(100)='',
        @nloginEID        int=0,
        @isaddDate        int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nP_Id is null  SET @nP_Id = 0
if @nS_Id is null  SET @nS_Id = 0
if @nStoreType is null  SET @nStoreType = 0
if @nCommissionflag is null  SET @nCommissionflag = 0
if @nBillType is null  SET @nBillType = 0
if @nOrderType is null  SET @nOrderType = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000), 
    @dTempTotal numeric(25,8), @dTempQuantity numeric(25,8),
    @szPClass_id VARCHAR(30),@szSClass_id VARCHAR(30)

  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
  Declare @isfinally int
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


	SELECT @szPClass_id=[class_id] FROM products WHERE [product_id]=@nP_Id

	IF @nS_id<>0 
	BEGIN
		IF @nStoretype in (0,3,4) SELECT @szSClass_id=[class_id] FROM storages WHERE [storage_id]=@nS_id
		IF @nStoretype=1 SELECT @szSClass_id=[class_id] FROM clients WHERE [client_id]=@nS_id
		IF @nStoretype=2 SELECT @szSClass_id=[class_id] FROM clients WHERE [client_id]=@nS_id
	END
        
        IF @nYClassID='' select @nYClassID='%%' else select @nYClassID=@nYClassID+'%'
	SELECT @iniQuantity=0
        SELECT @iniCostTotal=0
	SELECT @dTempQuantity=0
	SELECT @dTempTotal=0

IF @nS_id<>0 
BEGIN

/*当前仓库*/
  IF @nStoreType in (0, 4)
  BEGIN
/*取起始时间段内的变化量*/
  SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0), @dTempQuantity=ISNULL(SUM(b.quantity),0) 
  FROM 
	(
	 select isnull(p.costtotal,0) costtotal,isnull(p.quantity,0) quantity,b.c_id,p.Y_id,RowE_id,p.s_id  from  productdetail p
         left join billidx b on b.billid=p.billid
	 where b.billdate<@BeginDate  and p.aoid in (0,5,7) AND p.[Storetype]=0 AND P_id=@nP_Id AND p.s_id=@nS_Id
	)b
  left join clients c   on b.c_id    =c.client_id
  left join company Y   on b.Y_id    =Y.company_id
  left join employees E on B.RowE_id =E.emp_id
  left join storages S  on b.s_id    =s.storage_id
  where (@nYClassID='' or Y.Class_id like @nYClassID)
  AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
  AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%')))) 
  AND   (@employeestable=0 OR ((E.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and E.class_id like u.psc_id+'%'))))
  AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and S.class_id like u.psc_id+'%'))))
 
/*取期初数量	*/
  select @iniQuantity=ISNULL(SUM(s.quantity),0),
         @iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM 
         (select * from vw_c_storehouseini S where (@nYClassID='' or (s.YClass_id like @nYClassID+'%'))
         AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
	 AND (@Storetable=0 OR ((s.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.sclass_id like u.psc_id+'%'))))
         )s

	WHERE LEFT(s.class_id,LEN(@szPClass_id))=@szPClass_id AND LEFT(s.sclass_id,LEN(@szSClass_id)) = @szSClass_id
			
	SELECT @iniQuantity=@iniQuantity+@dTempQuantity
	SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
  END else

/*代销仓库*/
  IF @nStoreType=1
  BEGIN
/*取起始时间段内的变化量*/
   SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0) 
   FROM 			
      (
       select isnull(p.costtotal,0) as costtotal,isnull(p.quantity,0) as quantity,b.c_id,p.Y_id,RowE_id,s_id  from vw_c_pdetail p
       inner join vw_c_billidx b on p.billid=b.billid
       where  b.Yclass_id like @nYClassID and b.billdate<@BeginDate and p.storetype=@nStoreType  AND p.commissionflag=@nCommissionFlag AND aoid in (0,5,7)        
       AND P_id=@nP_Id AND p.s_id=@nS_Id
      )b
  left join clients c   on b.c_id    =c.client_id
  left join company Y   on b.Y_id    =Y.company_id
  left join employees E on B.RowE_id =E.emp_id
  left join storages S  on b.s_id    =s.storage_id
  where    
        (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
  AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%')))) 
  AND   (@employeestable=0 OR ((E.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and E.class_id like u.psc_id+'%'))))
  AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and S.class_id like u.psc_id+'%'))))

/*取期初数量	*/
   SELECT @iniQuantity=ISNULL(SUM(s.quantity),0),@iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM 
      (select * from vw_c_storedxini s where (@nYClassID='' or s.YClass_id like @nYClassID)
       AND (@ClientTable=0 or ((s.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and s.cclass_id  like u.psc_id+'%'))))
       AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
      )s
   WHERE LEFT(s.pclass_id,LEN(@szPClass_id))=@szPClass_id 
   AND commissionflag=@nCommissionFlag               
			
   SELECT @iniQuantity=@iniQuantity+@dTempQuantity
   SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
  END else

/*借进借出仓库*/
  IF @nStoreType=2
  BEGIN
/*取起始时间段内的变化量*/
  SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0)
  FROM 
    (
     select  ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity   from vw_c_pdetail p, 
       (select * from vw_c_billidx b where  
        (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id  like u.psc_id+'%'))))
       )b
     WHERE p.billid=b.billid AND b.billdate<@BeginDate AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id 
       AND LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id AND storetype=@nStoreType AND commissionflag=@nCommissionFlag  
    )b

/*取期初数量	*/
   SELECT @iniQuantity=ISNULL(SUM(s.quantity),0),@iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM 
          (select * from vw_c_storebrrowini s where  (@nYClassID='' or s.YClass_id like @nYClassID+'%')
           AND (@ClientTable=0 or ((s.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and s.cclass_id  like u.psc_id+'%'))))
	   AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
          ) s 
   WHERE LEFT(s.pclass_id,LEN(@szPClass_id))=@szPClass_id  AND commissionflag=@nCommissionFlag

   SELECT @iniQuantity=@iniQuantity+@dTempQuantity
   SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
   END else

/*零成本仓库*/
   IF @nStoreType=3
   BEGIN
/*取起始时间段内的变化量*/
       SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0)
       FROM 
          (
           select ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity,c_id,p.Y_id,RowE_id,s_id  from vw_c_pdetailzero p
           inner join vw_c_billidx b on p.billid =b.billid
           where (@nYClassID='' or b.YClass_id like @nYClassID+'%') and p.aoid in (5,6)
                AND    b.billdate<@BeginDate AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id
                AND    p.[Storetype]=@nStoreType AND    LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id     
          )b
       left join clients c   on b.c_id    =c.client_id
       left join company Y   on b.Y_id    =Y.company_id
       left join employees E on B.RowE_id =E.emp_id
       left join storages S  on b.s_id    =s.storage_id
       where          (@employeestable=0 OR ((e.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and e.class_id like u.psc_id+'%'))))
          	AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
          	AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
 	  	AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%'))))

                        
/*取期初数量	*/
	SELECT @iniQuantity=ISNULL(SUM(quantity),0),@iniCostTotal=ISNULL(SUM(costtotal),0) 
        FROM 
        (select * from vw_c_otherstorehouseini s 
         where (@nYClassID='' or s.YClass_id like @nYClassID+'%') and 
         (@Storetable=0 OR ((s.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.sclass_id like u.psc_id+'%'))))

         )s
	WHERE LEFT(class_id,LEN(@szPClass_id))=@szPClass_id AND LEFT(sclass_id,LEN(@szSClass_id)) = @szSClass_id
	
	SELECT @iniQuantity=@iniQuantity+@dTempQuantity
	SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
   END
END  ELSE /*-----仓库为0*/
BEGIN
/*代销仓库*/
     IF @nStoreType in (0, 4)
     BEGIN
/*取起始时间段内的变化量*/
	SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0) FROM 
        (
         select ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity,c_id,p.Y_id,RowE_id,s_id  from  dbo.vw_c_pdetail p
         inner join vw_c_billidx b on b.billid=p.billid 
         where (@nYClassID='' or b.YClass_id like @nYClassID+'%') and p.aoid in (0,5,7)
         and b.billdate<@BeginDate  AND p.[Storetype]=0  AND LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id
         /*AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id  */
        )b
        left join clients c   on b.c_id    =c.client_id
        left join company Y   on b.Y_id    =Y.company_id
        left join employees E on B.RowE_id =E.emp_id
        left join storages S  on b.s_id    =s.storage_id

	WHERE  
               (@employeestable=0 OR ((e.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and e.class_id like u.psc_id+'%'))))
         AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
         AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
	 AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%')))) 

/*取期初数量	*/
			SELECT @iniQuantity=ISNULL(SUM(s.quantity),0),@iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM 
                        (select * from vw_c_storehouseini S where (@nYClassID='' or (s.YClass_id like @nYClassID+'%'))
		        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
		        AND (@Storetable=0 OR ((s.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.sclass_id like u.psc_id+'%'))))
                         )S 

                         WHERE LEFT(s.class_id,LEN(@szPClass_id))=@szPClass_id/* AND LEFT(s.sclass_id,LEN(@szSClass_id)) = @szSClass_id */
	
			SELECT @iniQuantity=@iniQuantity+@dTempQuantity
			SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
		END else

/*当前仓库*/
		IF @nStoreType=1
		BEGIN
/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0) FROM 
                        (
			 select ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity,c_id,p.Y_id,RowE_id,s_id  from  dbo.vw_c_pdetail p
			 inner join vw_c_billidx b on p.billid = b.billid
			 where (@nYClassID='' or b.YClass_id like @nYClassID+'%') and p.aoid in (0,5,7)
			 AND  b.billdate<@BeginDate  AND p.[Storetype]=@nStoreType 
                         AND p.commissionflag=@nCommissionFlag /*AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id */
			 AND LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id 
                         )b
			 left join clients c   on b.c_id    =c.client_id
                         left join company Y   on b.Y_id    =Y.company_id
                         left join employees E on B.RowE_id =E.emp_id
                         left join storages S  on b.s_id    =s.storage_id
 
			WHERE 
                                (@employeestable=0 OR ((e.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and e.class_id like u.psc_id+'%'))))
	                  AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
	                  AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
	         	  AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%'))))
/*取期初数量	*/
			SELECT @iniQuantity=ISNULL(SUM(s.quantity),0),@iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM
                        (select * from vw_c_storedxini s where (@nYClassID='' or s.YClass_id like @nYClassID+'%')
		        AND (@ClientTable=0 or ((s.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and s.cclass_id  like u.psc_id+'%'))))
		        AND (@CompanyTable=0 or ((s.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and s.Yclass_id like u.psc_id+'%'))))
                         )s
			WHERE LEFT(s.pclass_id,LEN(@szPClass_id))=@szPClass_id  AND commissionflag=@nCommissionFlag 		
			SELECT @iniQuantity=@iniQuantity+@dTempQuantity
			SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
		END else

/*借进借出仓库*/
		IF @nStoreType=2
		BEGIN
/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0) FROM 
                        (
			 select ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity,c_id,p.Y_id,RowE_id,s_id  from  dbo.vw_c_pdetail p
			 inner join vw_c_billidx b on b.billid=p.billid 
                         where (@nYClassID='' or b.YClass_id like @nYClassID+'%') and p.aoid in (0,5,7) 
		         AND b.billdate<@BeginDate  AND p.[Storetype]=@nStoreType 
                         AND p.commissionflag=@nCommissionFlag /*AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id */
			 AND LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id 
                         )b
 			 left join clients c   on b.c_id    =c.client_id
                         left join company Y   on b.Y_id    =Y.company_id
                         left join employees E on B.RowE_id =E.emp_id
                         left join storages S  on b.s_id    =s.storage_id
			 where   
			        (@employeestable=0 OR ((e.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and e.class_id like u.psc_id+'%'))))
	                  AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
	                  AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
	         	  AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%'))))
/*取期初数量	*/
			SELECT @iniQuantity=ISNULL(SUM(quantity),0),@iniCostTotal=ISNULL(SUM(costtotal),0) FROM vw_c_storebrrowini 
			WHERE LEFT(pclass_id,LEN(@szPClass_id))=@szPClass_id AND commissionflag=@nCommissionFlag
			
			SELECT @iniQuantity=@iniQuantity+@dTempQuantity
			SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
		END else

/*零成本仓库*/
		IF @nStoreType=3
		BEGIN
/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(b.costtotal),0),@dTempQuantity=ISNULL(SUM(b.quantity),0) FROM 
                        (
                         select ISNULL(p.costtotal,0) as costtotal,ISNULL(p.quantity,0) as quantity,c_id,p.Y_id,RowE_id,s_id  from  dbo.vw_c_pdetailzero p
                         inner join vw_c_billidx b on b.billid = p.billid 
                         where (@nYClassID='' or b.YClass_id like @nYClassID+'%') and p.aoid in (5,6)
		         AND b.billdate<@BeginDate 
                         AND p.[Storetype]=@nStoreType /*AND LEFT(p.sclass_id,LEN(@szSClass_id)) = @szSClass_id */
			 AND LEFT(p.class_id,LEN(@szPClass_id))=@szPClass_id 
                         )b
  			 left join clients c   on b.c_id    =c.client_id
                         left join company Y   on b.Y_id    =Y.company_id
                         left join employees E on B.RowE_id =E.emp_id
                         left join storages S  on b.s_id    =s.storage_id
		        WHERE 
	                        (@employeestable=0 OR ((e.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and e.class_id like u.psc_id+'%'))))
	                  AND   (@Storetable=0 OR ((s.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.class_id like u.psc_id+'%'))))
	                  AND   (@ClientTable=0 or ((c.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and c.class_id  like u.psc_id+'%'))))
	         	  AND   (@CompanyTable=0 or ((Y.class_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Y.class_id like u.psc_id+'%'))))
                       
			SELECT @iniQuantity=ISNULL(SUM(s.quantity),0),@iniCostTotal=ISNULL(SUM(s.costtotal),0) FROM 
                        (select * from vw_c_otherstorehouseini s 
                         where (@nYClassID='' or s.YClass_id like @nYClassID+'%') and
		         (@Storetable=0 OR ((s.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and s.sclass_id like u.psc_id+'%'))))
                         )s

                         WHERE LEFT(s.class_id,LEN(@szPClass_id))=@szPClass_id /*AND LEFT(s.Sclass_id,LEN(@szSClass_id))=@szSClass_id*/
	
			SELECT @iniQuantity=@iniQuantity+@dTempQuantity
			SELECT @iniCostTotal=@iniCostTotal+@dTempTotal
			
		END
	END

  if @nStoreType in (0, 1, 2)
  begin
   print '11111111111'
  	SELECT @SQLScript='
      SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
      b.note as [note], b.summary as [SUMmary], b.[billstates], b.[quantity], b.[costtotal], b.[taxtotal], b.[batchno],
      b.[validdate], b.[makedate], b.[costprice],b.[comment],b.invoicetype, b.[smb_id],
  		[employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		[accountname],
  		[productname],
  		b.[cname],
  		[storagename],
  		[locationname],
  		[suppliername],
  		[inouttype],
		b.PName,class_id,storetype,sclass_id,commissionflag,isnull(factory,'''') as factory,
		pcomment,standard,makedate,alias,serial_number,makearea,
		case when b.billtype in (20,162) then  b.[quantity] else 0.00 end as buyqty,
		0.00 as buyotherqty,
		case when b.billtype in (12,152) then  abs(b.[quantity]) else 0.00 end as saleqty,0.00 as saleotherqty
      FROM
      (
       SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
       b.[note], b.[SUMmary], b.[billstates],p.[quantity], p.[costtotal], p.[taxtotal], p.[batchno],
       p.[validdate], p.[makedate], p.[costprice],p.[comment],p.[pcomment] as pcomment, p.[standard],
       p.[serial_number],p.[alias],p.[makearea],
       b.invoicetype,p.[smb_id],
  		b.[ename] AS [employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		b.[aname] AS [accountname],
  		p.[pname] AS [productname],
  		b.[cname],
  		[storagename]= CASE 
  		WHEN p.[storetype]=0 THEN p.[sname]
  		else b.[cname]
  		END,
  		ISNULL((SELECT [loc_name] FROM location l WHERE l.[loc_id]=p.[location_id]),'''') AS [locationname],
  		ISNULL((SELECT [name] FROM clients c WHERE c.[client_id]=p.[supplier_id]),'''') AS [suppliername],
  		[inouttype]=CASE p.[commissionflag]
  		WHEN 0 THEN ''一般''
  		WHEN 1 THEN ''委托代销''
  		WHEN 2 THEN ''受托代销''
  		WHEN 3 THEN ''借出''
  		WHEN 4 THEN ''借进''
  		END,
		P.PName,p.class_id,p.storetype,p.sclass_id,p.commissionflag,b.auditdate,isnull(p.factory,'''') as factory
      FROM
      (  select p.* from VW_C_Pdetail p left join company y on p.y_id=company_id
         where ('+char(39)+@nYClassID+char(39)+'= ''''  or y.class_id like '''+@nYClassID+'''+''%'') AND 
        ('+cast(@employeestable as varchar(50))+'=0 OR ((p.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and p.Reclass_id like u.psc_id+''%''))))
        AND ('+cast(@Storetable as varchar(50))+'=0     OR ((p.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and p.sclass_id like u.psc_id+''%''))))
       )p

       INNER JOIN 
      (select * from VW_C_BILLIDX B  where ('+char(39)+@nYClassID+char(39)+'= ''''  or b.YClass_id like '''+@nYClassID+'''+''%'') AND 
        ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
       AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
      ) b

      ON p.[billid]=b.[billid]
      WHERE b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)
        +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'
     
--     AND ('+cast(@employeestable as varchar(50))+'=0 OR ((b.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and b.Reclass_id like u.psc_id+''%''))))
--     AND ('+cast(@Storetable as varchar(50))+'=0     OR ((b.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and b.sclass_id like u.psc_id+''%''))))
--     AND ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
--     AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
      )b where  b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
  print @SQLScript
  end else
  if @nStoreType =3
  begin
  	SELECT @SQLScript='
      SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
      b.note as [note], b.summary as [SUMmary], b.[billstates], b.[quantity], b.[costtotal], b.[taxtotal], b.[batchno],
      b.[validdate], b.[makedate], b.[costprice],b.[comment],b.invoicetype, b.[smb_id],
      case when b.billtype in (20,162) then  b.[quantity] else 0.00 end as buyqty,
		0.00 as buyotherqty,
		case when b.billtype in (12,152) then  abs(b.[quantity]) else 0.00 end as saleqty,0.00 as saleotherqty,
  		b.[employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		b.accountname AS [accountname],
  		b.[pname] AS [productname],
  		b.[cname],
  		[storagename],
  	        [locationname],
  		[suppliername],
  		[inouttype],b.PName,class_id,storetype,sclass_id,commissionflag,
  		b.[standard],b.[serial_number],b.[alias],b.[factory],b.[pcomment],b.[makearea]
      FROM 
      (
        SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
        b.[note], b.[SUMmary], b.[billstates], p.[quantity], p.[costtotal], p.[taxtotal], p.[batchno],
        p.[validdate], p.[makedate], p.[costprice],p.[comment], b.invoicetype,p.[smb_id],
        p.[standard],p.[serial_number],p.[alias],p.[factory],p.[pcomment],p.[makearea],
  		b.[ename] AS [employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		b.[aname] AS [accountname],
  		p.[pname] AS [productname],
  		b.[cname],
  		[storagename]= CASE 
  		WHEN p.[storetype] in (0,3) THEN p.[sname]
  		else b.[cname]
  		END,
  		ISNULL((SELECT [loc_name] FROM location l WHERE l.[loc_id]=p.[location_id]),'''') AS [locationname],
  		ISNULL((SELECT [name] FROM clients c WHERE c.[client_id]=p.[supplier_id]),'''') AS [suppliername],
  		[inouttype]=CASE p.[commissionflag]
  		WHEN 0 THEN ''一般''
  		WHEN 1 THEN ''委托代销''
  		WHEN 2 THEN ''受托代销''
  		WHEN 3 THEN ''借出''
  		WHEN 4 THEN ''借进''
  		END,
		P.PName,p.class_id,p.storetype,p.sclass_id,p.commissionflag,b.auditdate
      FROM (select p.* from VW_C_Pdetailzero p left join company y on p.y_id=company_id
             where ('+char(39)+@nYClassID+char(39)+'= ''''  or y.class_id like '''+@nYClassID+'''+''%'') AND 
            ('+cast(@employeestable as varchar(50))+'=0 OR ((p.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and p.Reclass_id like u.psc_id+''%''))))
            AND ('+cast(@Storetable as varchar(50))+'=0     OR ((p.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and p.sclass_id like u.psc_id+''%''))))
           )p

           INNER JOIN 
           (select * from VW_C_BILLIDX B 
           where ('+char(39)+@nYClassID+char(39)+'='''' or b.YClass_id like '''+@nYClassID+'''+''%'')  
           AND ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
           AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
           ) b

           ON p.[billid]=b.[billid]
           WHERE b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'
           


--     AND ('+cast(@employeestable as varchar(50))+'=0 OR ((b.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and b.Reclass_id like u.psc_id+''%''))))
--     AND ('+cast(@Storetable as varchar(50))+'=0     OR ((b.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and b.sclass_id like u.psc_id+''%''))))
--     AND ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
--     AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
      )b  where  b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
  end
  else if @nStoreType = 4
  begin
    
  	SELECT @SQLScript='
      SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
      b.note as [note], b.summary as [SUMmary], b.[billstates], b.[quantity], b.[costtotal], b.[taxtotal], b.[batchno],
      b.[validdate], b.[makedate], b.[costprice],b.[comment],b.invoicetype, b.[smb_id],
  		[employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		[accountname],
  		[productname],
  		b.[cname],
  		[storagename],
  		[locationname],
  		[suppliername],
  		[inouttype],
		b.PName,class_id,storetype,sclass_id,commissionflag,b.clientAddress, b.cphone, b.ysfs,
		b.[standard],b.[serial_number],b.[alias],b.[factory],b.[pcomment],b.[makearea],
		case when b.billtype in (20,162) then  b.[quantity] else 0.00 end as buyqty,
		0.00 as buyotherqty,
		case when b.billtype in (12,152) then  abs(b.[quantity]) else 0.00 end as saleqty,0.00 as saleotherqty
      FROM
      (
       SELECT b.[billid], b.[billtype], b.[billdate], b.[billnumber], b.[inputman], b.[auditman], 
       b.[note], b.[SUMmary], b.[billstates], p.[quantity], p.[costtotal], p.[taxtotal], p.[batchno],
       p.[validdate], p.[makedate], p.[costprice],p.[comment], b.invoicetype,p.[smb_id],
  		b.[ename] AS [employeename],
  		b.[auditmanname],
  		b.[inputmanname],
  		b.[aname] AS [accountname],
  		p.[pname] AS [productname],
  		p.scname as ysfs,
  		b.[cname],
  		[storagename]= CASE 
  		WHEN p.[storetype]=0 THEN p.[sname]
  		else b.[cname]
  		END,
  		ISNULL((SELECT [loc_name] FROM location l WHERE l.[loc_id]=p.[location_id]),'''') AS [locationname],
  		ISNULL((SELECT [name] FROM clients c WHERE c.[client_id]=p.[supplier_id]),'''') AS [suppliername],
  		isnull(cds.name, '''') as clientAddress, isnull(cds.phone_number, '''') as cPhone,
  		[inouttype]=CASE p.[commissionflag]
  		WHEN 0 THEN ''一般''
  		WHEN 1 THEN ''委托代销''
  		WHEN 2 THEN ''受托代销''
  		WHEN 3 THEN ''借出''
  		WHEN 4 THEN ''借进''
  		END,
		P.PName,p.class_id,p.storetype,p.sclass_id,p.commissionflag,b.auditdate,
		p.[standard],p.[serial_number],p.[alias],p.[factory],p.[pcomment],p.[makearea]
      FROM
      (  select p.* from VW_C_Pdetail p left join company y on p.y_id=company_id
         where ('+char(39)+@nYClassID+char(39)+'= ''''  or y.class_id like '''+@nYClassID+'''+''%'') AND 
        ('+cast(@employeestable as varchar(50))+'=0 OR ((p.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and p.Reclass_id like u.psc_id+''%''))))
        AND ('+cast(@Storetable as varchar(50))+'=0     OR ((p.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and p.sclass_id like u.psc_id+''%''))))
       )p

       INNER JOIN 
      (select * from VW_C_BILLIDX B  where ('+char(39)+@nYClassID+char(39)+'= ''''  or b.YClass_id like '''+@nYClassID+'''+''%'') AND 
        ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
       AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
      ) b
      ON p.[billid]=b.[billid]
      left join  clients cds on b.sendc_id = cds.client_id
      WHERE b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)
        +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'
--     AND ('+cast(@employeestable as varchar(50))+'=0 OR ((b.Reclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and b.Reclass_id like u.psc_id+''%''))))
--     AND ('+cast(@Storetable as varchar(50))+'=0     OR ((b.sclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''S'' and b.sclass_id like u.psc_id+''%''))))
--     AND ('+cast(@ClientTable as varchar(50))+'=0 or ((b.cclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and b.cclass_id  like u.psc_id+''%''))))
--     AND ('+cast(@CompanyTable as varchar(50))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))
      )b where  b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
  
    set @nStoreType = 0
  end

/*加入商品的条件*/
  IF @nP_id<>0 SELECT @SQLScript=@SQLScript+' AND LEFT(b.[class_id],LEN('+CHAR(39)
    +@szPClass_id+CHAR(39)+'))='+CHAR(39)+@szPClass_id+CHAR(39) 
/*加入仓库的条件*/
  IF @nS_id<>0 SELECT @SQLScript=@SQLScript+' AND LEFT(b.[sclass_id],LEN('+CHAR(39)
    +@szSClass_id+CHAR(39)+'))='+CHAR(39)+@szSClass_id+CHAR(39)
/*加入仓库类型的条件*/
  SELECT @SQLScript=@SQLScript+' AND b.[storetype]='+CAST(@nStoreType AS  VARCHAR) 
/*加入借贷标志的条件  */
  IF @nCommissionFlag<>0 SELECT @SQLScript=@SQLScript+' AND b.[commissionflag]='
    +CAST(@nCommissionFlag AS  VARCHAR) 
/*加入单据类型的条件  */
  IF @nBillType<>0 SELECT @SQLScript=@SQLScript+'AND b.[billtype]='+CAST(@nBillType AS VARCHAR) 
/*加入排序的条件*/
  IF @nOrderType=0 SELECT @SQLScript=@SQLScript+' ORDER BY b.[billdate],b.billid'
  ELSE 
  SELECT @SQLScript=@SQLScript+' ORDER BY  b.auditdate'


PRINT @SQLScript
  EXEC(@SQLScript)
  GOTO Succee

Succee:
  RETURN 0
GO
