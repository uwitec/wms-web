
CREATE       PROCEDURE [Ts_X_InsEmpSetSales]
 (  @mode int = 0,					/*0表示添加1表示修改*/
	@E_id [int] ,				/* 职员id*/
	/*@p_id [int] ,				-- 商品id   为0的时候表示总额度，其它就是对应商品的额度*/
	@OneYear [varchar] (30) ,			/* 年度*/
	@OneM numeric(25,8) ,		/*1月份  （金额）*/
	@twoM numeric(25,8) ,
	@threeM numeric(25,8) ,
	@fourM numeric(25,8) ,
	@fiveM numeric(25,8) ,
	@sixM numeric(25,8) ,
	@sevenM numeric(25,8) ,
	@eightM numeric(25,8) ,
	@nineM numeric(25,8) ,
	@tenM numeric(25,8) ,
	@elenM numeric(25,8) ,
	@twentyM numeric(25,8) 		/*12月份	*/
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/

if @mode = null set @mode = 0
if @E_id = null set @E_id = 0

if @mode = 0 /*添加*/
begin
if @E_id > 0 
begin
	if exists(select 1 from employeesSalesTotal where E_id=@E_id  and OneYear = @OneYear)
	begin
	 /*RAISERROR('该职员该商品本年度的销售额度已经存在！不能添加！！',16,1)*/
	 return -2
	end
	
  INSERT INTO [employeesSalesTotal] 
	  (
	[E_id] ,				/* 职员id*/
	[OneYear],			/* 年度*/
	[OneM] ,		/*1月份  （金额）*/
	[twoM] ,
	[threeM] ,
	[fourM] ,
	[fiveM] ,
	[sixM],
	[sevenM] ,
	[eightM] ,
	[nineM],
	[tenM],
	[elenM] ,
	[twentyM] 		/*12月份	*/
	  )
	 
  VALUES 
	 (
	@E_id ,				/* 职员id*/
	@OneYear,			/* 年度*/
	@OneM ,		/*1月份  （金额）*/
	@twoM ,
	@threeM ,
	@fourM ,
	@fiveM ,
	@sixM,
	@sevenM ,
	@eightM ,
	@nineM,
	@tenM,
	@elenM ,
	@twentyM 		/*12月份	*/
	  )
	/*if @@rowCount=0 */
  return @@identity	
end
end
else if @mode = 1
begin
  update employeesSalesTotal set 
  	OneM=@OneM ,		/*1月份  （金额）*/
	twoM=@twoM ,
	threeM=@threeM ,
	fourM=@fourM ,
	fiveM=@fiveM ,
	sixM=@sixM,
	sevenM=@sevenM ,
	eightM=@eightM ,
	nineM=@nineM,
	tenM=@tenM,
	elenM=@elenM,
	twentyM =@twentyM		/*12月份	*/
	
  where E_id=@E_id  and OneYear = @OneYear 
  
  return @@ROWCOUNT
end
GO
