

CREATE  TRIGGER [DeleteShop] ON [dbo].[Shop] 
FOR  UPDATE
AS
if update(deleted)
begin
	delete from ReplicationAuthorize where posid in (select posid from inserted where deleted=1)
end
GO
