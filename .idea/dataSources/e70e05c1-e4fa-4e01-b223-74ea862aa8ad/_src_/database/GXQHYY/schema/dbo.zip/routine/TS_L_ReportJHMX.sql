/****************************/
/*******拣货复核明细查询 **********/
/********add by luowei 2013-10-19**********/
/****************************/



create procedure TS_L_ReportJHMX
(
   @szbegindate varchar(50),
   @szenddate varchar(50),
   @ns_id int,
   @nc_id int,
   @njhr_id int,
   @nfhr_id int
)
AS
begin

   select t.*,isnull(cast(round((t.quantity/rate.rate),0,1) as int),0) as wholeqty from (
	/*-------销售出库单未过账*/
	select isnull(cx.checkdate,'') as CheckDate,e.name as jhename,isnull(ce.name,'') as CheckName,isnull(i.billdate,0) as billdate,isnull(idraft.billnumber,'商品全部漏检货或无库存') as billnumber,c.name as cname,s.name as sname,
		  p.product_id,p.serial_number,p.name as pname,standard,makearea,p.permitcode,medname,PackStd,Unit1Name,sm.batchno,sm.validdate,isnull(l.loc_name,'') as loc_name ,
		  sm.quantity,(sm.quantity*sm.saleprice) as saletotal,i.billid,i.billtype,i.auditman,i.Y_ID,i.VIPCardID as states
	from salemanagebilldrf sm
	inner join (
	              select * from billdraftidx where billtype = 254 and VIPCardID = 6 and (@njhr_id = 0 or integral = @njhr_id) and (@nfhr_id = 0 or integralYE = @nfhr_id) and (@ns_id = 0 or sout_id = @ns_id)
	              and billdate between @szbegindate and @szenddate and (@nc_id = 0 or c_id = @nc_id)
	            ) i on sm.bill_id = i.billid
	left join employees e on e.emp_id = i.integral 
	left join employees a on a.emp_id = i.auditman
	left join storages s on s.storage_id = i.sout_id 
	left join (
	              select * from billdraftidx where billtype = 10 and billdate between @szbegindate and @szenddate and (@nc_id = 0 or c_id = @nc_id)
	            ) idraft on idraft.GUID = i.InvoiceNO 
	left join clients c on c.client_id = i.c_id
	left join vw_Products p on p.product_id = sm.p_id
	left join location l on l.loc_id = sm.location_id
	left join (select * from checkidx where IsDraft = 1) cx on cx.billid = sm.bill_id
	left join employees ce on cx.checkman = ce.emp_id 

	union all

	/*--------销售出库单过账*/
	select isnull(cx.checkdate,'') as CheckDate,e.name as jhename,isnull(ce.name,'') as CheckName,i.billdate,isnull(idex.billnumber,'商品全部漏检货或无库存'),c.name as cname,s.name as sname,
	   p.product_id,p.serial_number,p.name as pname,standard,makearea,P.permitcode,medname,PackStd,Unit1Name,sm.batchno,sm.validdate,isnull(l.loc_name,'') as loc_name ,
		  sm.quantity,(sm.quantity*sm.saleprice) as saletotal,i.billid,i.billtype,i.auditman,i.Y_ID,i.VIPCardID as  states
	from salemanagebilldrf sm
	inner join (
	                select * from billdraftidx where billtype = 254 and VIPCardID = 6 and (@njhr_id = 0 or integral = @njhr_id) and (@nfhr_id = 0 or integralYE = @nfhr_id)  and (@ns_id = 0 or sout_id = @ns_id)
	                and billdate between @szbegindate and @szenddate and (@nc_id = 0 or c_id = @nc_id)
	           ) i on sm.bill_id = i.billid
	left join employees e on e.emp_id = i.integral 
	left join employees a on a.emp_id = i.auditman 
	left join storages s on s.storage_id = i.sout_id 
	left join (
	               select * from billidx where billtype = 10 and billdate between @szbegindate and @szenddate and (@nc_id = 0 or c_id = @nc_id)
	            ) idex on idex.GUID = i.InvoiceNO 
	left join clients c on c.client_id = i.c_id
	left join vw_Products p on p.product_id = sm.p_id
	left join location l on l.loc_id = sm.location_id
	left join (select * from checkidx where IsDraft = 1) cx on cx.billid = sm.bill_id
	left join employees ce on cx.checkman = ce.emp_id 
	
	) t 
	left join 
	
	(
	  select p.product_id,p.WholeUnit_id,p.rate2 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit2_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate3 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit3_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate4 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit4_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
	) RATE on t.product_id = rate.product_id
	where billnumber <> '商品全部漏检货或无库存'

end
GO
