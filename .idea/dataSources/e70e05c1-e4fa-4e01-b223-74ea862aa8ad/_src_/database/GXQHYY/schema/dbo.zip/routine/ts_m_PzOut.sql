

CREATE  proc ts_m_PzOut
(
    @nBillIDList varchar(8000)
)
/*with encryption*/
as
SET NOCOUNT ON
declare @SQL varchar(8000)

exec ('truncate table pzout')

set @SQL='			
insert pzout(billdate,pzlb,pznumber,pzfj,pzcomment,kmcode,jfmoney,dfmoney,gysnumber,ccode) 
select GETDATE(),(case max(a.aclass_id) when ''000001000003'' then ''现''when ''000001000004'' then ''银'' else ''转''end),
max(b.billnumber),0,max(note), ISNULL(max(k.serialnumber),''''),
(case when (left(max(a.aclass_id),6)=''000001'' or left(max(a.aclass_id),6)=''000004'') then ABS(sum(a.jdmoney)) else 0 end),
(case when (left(max(a.aclass_id),6)=''000002'' or left(max(a.aclass_id),6)=''000003'') then ABS(sum(a.jdmoney)) else 0 end),
'''',isnull(max(d.serialnumber),'''')
from vw_c_adetail  a 
left join billidx b on b.billid=a.billid 
left join kmdz k on k.a_id=a.a_id and k.[type]=''U''
left join dwdz d on d.c_id=a.c_id and d.[type]=''U''
where a.billid in('+@nBillIDList +')
group by a.a_id '
/*print (@SQL)*/
exec (@SQL)
GO
