

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/****************************************

万能单据查询
药易通62的中间键要改

****************************************/
CREATE	PROCEDURE TS_C_QrAllBill
(       @lMode              INT,/*0 单据查询,1 草稿查询*/
        @Begindate 	    DATETIME,
	@EndDate	    DATETIME,
	@szC_id		    VARCHAR(30)='',/*往来单位*/
	@szZd_id	    VARCHAR(30)='', /*制单人*/
	@szE_id		    VARCHAR(30)='',/*经手人*/
	@szP_id		    VARCHAR(30)='',/*商品ID*/
	@szSh_id	    VARCHAR(30)='',/*审核人*/
	@szSs_id 	    VARCHAR(30)='',/*出仓库*/
	@szSd_id 	    VARCHAR(30)='',/*入仓库 */
	@szBillcode	    VARCHAR(60)='',
	@szComment	    VARCHAR(300)='',
	@nBilltype	    INT=0,
        @szCompanYclass_id  VARCHAR(30)='',
	@isupdate           INT=0,
        @Searchtype         Int=0,
        @nloginEID          int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szC_id is null  SET @szC_id = ''
if @szZd_id is null  SET @szZd_id = ''
if @szE_id is null  SET @szE_id = ''
if @szP_id is null  SET @szP_id = ''
if @szSh_id is null  SET @szSh_id = ''
if @szSs_id is null  SET @szSs_id = ''
if @szSd_id is null  SET @szSd_id = ''
if @szBillcode is null  SET @szBillcode = ''
if @szComment is null  SET @szComment = ''
if @nBilltype is null  SET @nBilltype = 0
if @szCompanYclass_id is null  SET @szCompanYclass_id = ''
if @isupdate is null  SET @isupdate = 0
if @Searchtype is null  SET @Searchtype = 0
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
  SET NOCOUNT ON

  DECLARE @SQLScript VARCHAR(8000)

  Declare @Filtertype varchar(100)
  if @Searchtype=0
     select @Filtertype=''
  else if @Searchtype=1
     select @Filtertype=' and b.billtype not in (150,151,155,160,161,165)  '
  else if @Searchtype=2
     select @Filtertype=' and b.billtype in (150,151,153,155,160,161,165)  '

  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100)
  Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@Filteemployees  varchar(8000),@FilteStore   varchar(8000)

  select  @FilteClient='',@FilteCompany='',@Filteemployees ='',@FilteStore =''
 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
     insert #Clienttable ([id]) select 0
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      insert #storagestable ([id]) select 0
   end
  IF @ClientTable<>0     set @FilteClient='and (b.c_id in (select [id]  FROM #Clienttable ))'
  IF @Companytable<>0    set @FilteCompany=' and (b.Y_ID in (select [id] from #Companytable ))'
  IF @employeestable<>0  set @Filteemployees= ' and (b.E_id in (select [id] from #employeestable))'
  IF @storetable<>0      set @FilteStore=' and ( (b.sout_id in (select [ID] from #storagestable)) or (b.sin_id in (select [ID] from #storagestable)) )'
 
  IF @szC_id<>''   	   	SELECT @szC_id=ISNULL(@szC_id, '%')+'%'
  IF @szZd_id<>''  		SELECT @szZd_id=ISNULL(@szZd_id, '%')+'%'
  IF @szE_id<>''   		SELECT @szE_id=ISNULL(@szE_id, '%')+'%'
  IF @szP_id<>''   		SELECT @szP_id=ISNULL(@szP_id, '%')+'%'
  IF @szSh_id<>''  		SELECT @szSh_id=ISNULL(@szSh_id, '%')+'%'
  IF @szSs_id<>''  		SELECT @szSs_id=ISNULL(@szSs_id, '%')+'%'
  IF @szSd_id<>''  		SELECT @szSd_id=ISNULL(@szSd_id, '%')+'%'
  IF @szCompanYclass_id<>''     SELECT @szCompanYclass_id=ISNULL(@szCompanYclass_id,'%')+'%'

/*  select Product_ID,Class_ID into #Products from Products*/

IF @lMode=0
  BEGIN
 /*   SELECT * INTO #BillIDX FROM VW_C_BillIDX WHERE [billdate] BETWEEN @BeginDate AND @EndDate*/
    SELECT @SQLScript='SELECT DISTINCT b.[billid], b.[billtype], b.[billdate], b.[billstates],
      b.[billnumber], b.[inputman], b.[auditman], b.[note], b.[summary], b.[quantity],
      (case when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.ysmoney else b.ysmoney end)[ysmoney],
      (case when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.[ssmoney] else b.ssmoney end) as ssmoney,
      -- (abs(ysmoney)-abs(jsye)) as ssmoney,    ---不能这样搞 退回的单据 实收金额变成 正数
       b.[araptotal], b.[taxrate], b.[auditdate],
      CASE WHEN b.[billtype] IN (44, 45) THEN b.[ssname] ELSE b.[cname] END AS [cname],
  		b.[ename] AS [employeename],
   		b.[auditmanname],
   		b.[inputmanname],
   		b.[aname] AS [accountname],
   		b.[departmentname],
   		b.[regionname],b.Y_id,b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,b.skdate,b.transflag,
   		(case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype,
   		isnull(b.sendcname,'''') as sendcname 
     	FROM vw_c_billidx b LEFT JOIN 
      (SELECT DISTINCT bm.[Bill_ID], p.[Class_ID],bm.aoid FROM BuyManageBill bm, Products p, BillIDX b
       WHERE bm.[P_ID]=p.[Product_ID] and bm.bill_id=b.billid 
       UNION
      SELECT DISTINCT sm.[Bill_ID], p.[Class_ID],sm.aoid FROM SaleManageBill sm, Products p, BillIDX b
       WHERE sm.[P_ID]=p.[Product_ID] and sm.bill_id=b.billid 
       UNION
      SELECT DISTINCT st.[Bill_ID], p.[Class_ID],st.aoid FROM StoreManageBill st, Products p, BillIDX b
       WHERE st.[P_ID]=p.[Product_ID] and st.bill_id=b.billid 
       UNION
      SELECT DISTINCT gc.[Bill_ID], p.[Class_ID],gc.aoid FROM GoodsCheckBill gc, Products p, BillIDX b
       WHERE gc.[P_ID]=p.[Product_ID] and gc.bill_id=b.billid 
       UNION
      SELECT DISTINCT tm.[Bill_ID], p.[Class_ID],tm.aoid FROM TranManagebill tm, Products p, BillIDX b
       WHERE tm.[P_ID]=p.[Product_ID] and tm.bill_id=b.billid 
      ) pd ON b.[BillID]=pd.[Bill_ID]'
      +' WHERE (b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)
      +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

END ELSE 
  BEGIN
    /*SELECT * INTO #BillDraftIDX FROM VW_C_BillDraftIDX WHERE [billdate] BETWEEN @BeginDate AND @EndDate*/
    SELECT @SQLScript='SELECT DISTINCT b.[billid], b.[billtype], b.[billdate], b.[billstates],
      b.[billnumber], b.[inputman], b.[auditman], b.[note], b.[summary], b.[quantity],
      b.[ysmoney], b.[ssmoney], b.[araptotal], b.[taxrate], b.[auditdate],
      CASE WHEN b.[billtype] IN (44, 45) THEN b.[ssname] ELSE b.[cname] END AS [cname],
  		b.[ename] AS [employeename],
   		b.[auditmanname],
   		b.[inputmanname],
   		b.[aname] AS [accountname],
   		b.[departmentname],
   		b.[regionname],b.Y_id,b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,b.skdate,b.transflag,
   		(case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype,
   		isnull(b.sendcname,'''') as sendcname 
     	FROM VW_C_BillDraftIDX b LEFT JOIN 
      (SELECT DISTINCT bm.[Bill_ID], p.[Class_ID],bm.aoid FROM BuyManageBillDrf bm, Products p, BillDraftIDX b
       WHERE bm.[P_ID]=p.[Product_ID] and bm.bill_id=b.billid 
       UNION
      SELECT DISTINCT sm.[Bill_ID], p.[Class_ID],sm.aoid FROM SaleManageBillDrf sm, Products p, BillDraftIDX b
       WHERE sm.[P_ID]=p.[Product_ID] and sm.bill_id=b.billid 
       UNION
      SELECT DISTINCT st.[Bill_ID], p.[Class_ID],st.aoid FROM StoreManageBillDrf st, Products p, BillDraftIDX b
       WHERE st.[P_ID]=p.[Product_ID] and st.bill_id=b.billid 
       UNION
      SELECT DISTINCT gc.[Bill_ID], p.[Class_ID],gc.aoid FROM GoodsCheckBillDrf gc, Products p, BillDraftIDX b
       WHERE gc.[P_ID]=p.[Product_ID] and gc.bill_id=b.billid 
       UNION
      SELECT DISTINCT tm.[Bill_ID], p.[Class_ID],tm.aoid FROM TranManagebillDrf tm, Products p, BillDraftIDX b
       WHERE tm.[P_ID]=p.[Product_ID] and tm.bill_id=b.billid 
      ) pd ON b.[BillID]=pd.[Bill_ID]'
      +' WHERE (b.[billdate] BETWEEN '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)
      +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

  END

  IF @szC_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[cclass_id] LIKE '+CHAR(39)+@szC_id+CHAR(39)
  IF @szE_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[eclass_id] LIKE '+CHAR(39)+@szE_id+CHAR(39)
  IF @szZd_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[inputmanclass_id] LIKE '+CHAR(39)+@szZd_id+CHAR(39)
  IF @szSh_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[auditmanclass_id] LIKE '+CHAR(39)+@szSh_id+CHAR(39)
  IF (@szP_id<>'') and (@isupdate=0) SELECT @SQLScript=@SQLScript+' AND pd.aoid<>8 and  pd.[class_id] LIKE '+CHAR(39)+@szP_id+CHAR(39)
  IF @szSs_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[ssclass_id] LIKE '+CHAR(39)+@szSs_id+CHAR(39)
  IF @szSd_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[sdclass_id] LIKE '+CHAR(39)+@szSd_id+CHAR(39)
  IF @szBillcode<>'' SELECT @SQLScript=@SQLScript+' AND b.[billnumber] LIKE '+CHAR(39)+'%'+@szBillcode+'%'+CHAR(39)
  IF @szcomment<>'' SELECT @SQLScript=@SQLScript+' AND b.[note] LIKE '+CHAR(39)+'%'+@szcomment+'%'+CHAR(39)
  IF @szCompanYclass_id<>'' SELECT @SQLScript=@SQLScript+' AND b.[Yclass_id] LIKE '+CHAR(39)+@szCompanYclass_id+CHAR(39)
  IF @nBilltype<>0 SELECT @SQLScript=@SQLScript+' AND b.[billtype]='+CAST(@nBilltype AS VARCHAR)
    ELSE SELECT @SQLScript=@SQLScript+' AND b.[billtype] NOT IN (58, 157, 158, 159, 166)'

    SELECT @SQLScript=@SQLScript+@Filtertype
    /*草稿中过滤(业务开单):状态=8,9*/
    SET @SQLScript=@SQLScript+' and b.BillStates not in (7,8,9) '

	SELECT @SQLScript=@SQLScript+' ORDER BY b.[billdate] '


  /*PRINT @SQLScript*/
  EXEC (@SQLScript)
  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
