


CREATE   TRIGGER [DeleteStock] ON [dbo].[storages] 
FOR UPDATE
AS
if update(deleted)
begin
	delete from location where s_id in (select storage_id from inserted where deleted=1)
	update shop set deleted=1 where s_id in (select storage_id from inserted where deleted=1)
end
GO
