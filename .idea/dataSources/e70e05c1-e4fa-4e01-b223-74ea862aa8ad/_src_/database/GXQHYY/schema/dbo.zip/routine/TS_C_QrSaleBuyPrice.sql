

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

单品进价售价查询
@nMode =0 采购价查询
@nMode =1 销售价查询

********************************************/
CREATE PROCEDURE TS_C_QrSaleBuyPrice 
( @BeginDate DATETIME,
  @EndDate   DATETIME,
  @nP_id INT,
  @nC_id INT,
  @nE_id INT,
  @nS_id INT,
  @nMode INT=0,
  @nYClassid            varchar(100)='',
  @nloginEID            int=0,
  @isaddDate            int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移 //暂时关闭 */
)
/*with encryption*/
AS   
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
	/*SET NOCOUNT ON*/
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
IF (@nMode=0) OR (@nMode=2)
BEGIN
SELECT YPBM.*,isnull(C.[name],'')cname,isnull(RE.[name],'')ename,isnull(p.[name],'')Pname
       ,p.standard,p.makearea,isnull(m.name,'') AS medtype,u.[name] AS uname,
       ISNULL(l.loc_name, '') AS lname,isnull(s.[name],'')sname,
       rate=CASE WHEN YPBM.unitid=p.unit1_id THEN 1 
                 WHEN YPBM.unitid=p.unit2_id THEN rate2
                 WHEN YPBM.unitid=p.unit3_id THEN rate3
                 WHEN YPBM.unitid=p.unit4_id THEN rate4 END,
       isnull(YPBM.factory,'') as factory,
       YPBM.costtaxrate,YPBM.costtaxprice,YPBM.costtaxtotal
FROM
   (SELECT ISNULL(b.billdate,'') AS billdate,b.billtype,b.billid,b.billnumber,b.inputman,b.auditman,b.c_id, b.note,b.Y_id,
           a.ss_id as s_id ,a.location_id,a.unitid,a.RowE_id,
           cast(isnull(a.totalmoney/a.quantity,0) as numeric(25,8)) AS price, cast(isnull(a.costprice, 0) as numeric(25,8)) AS costprice,
           cast(isnull(a.taxtotal/a.quantity,0) as numeric(25,8))  AS taxprice,isnull(a.batchno,'') AS batchno,
           a.quantity  AS [quantity],
           a.SendQTY   AS [SendQTY],
           a.SendCostTotal  AS [SendCostTotal],
           a.P_id as Product_id,
           isnull(f.AccountComment,'') as factory,
           cast(isnull(a.costtaxprice, 0) as numeric(25,8)) AS costtaxprice,
           cast(isnull(a.costtaxrate, 0) as numeric(25,8)) AS costtaxrate,
           cast(isnull(a.costtaxtotal, 0) as numeric(25,8)) AS costtaxtotal
    FROM  buymanagebill a  
        
    Inner JOIN 
          (select * from billidx where  billtype in (20,122,220) and
                           (billdate BETWEEN @begindate AND @EndDate) and
                            billstates=0
           )b ON b.billid=a.bill_id
    left join basefactory f on a.FactoryId=f.CommID 
    WHERE aoid in (0,5) and a.p_id>0
        AND (@nP_id=0 or a.p_id=@nP_id)
        AND (@nC_id=0 or b.c_id=@nC_id)
        AND (@nE_id=0 or a.Rowe_id=@nE_id)
        AND (@nS_id=0 or a.ss_id=@nS_id)
        AND (@nYClassid='' OR b.Y_id in (select Company_id from Company where class_id like @nYClassid+'%'))

   )YPBM   
	  LEFT  JOIN  products  p  ON p.product_id=YPBM.Product_id 
	  left   join 
	  (
			select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on p.product_id = m.baseinfo_id
	  LEFT  JOIN  unit      u  ON u.unit_id=p.unit1_id
	  LEFT  JOIN  location  l  ON l.loc_id=YPBM.location_id 
      LEFT  JOIN  employees RE ON RE.Emp_id=YPBM.RowE_id
      LEFT  JOIN  Clients   C  ON C.Client_id=YPBM.c_id 
      LEFT  JOIN  storages  S  ON S.storage_id=YPBM.s_id
   WHERE ((@Companytable=0)or (YPBM.Y_id in (select [id] from #Companytable)))
     AND ((@ClientTable=0) or (YPBM.c_id in (select [id] from #Clienttable)))
     AND ((@Storetable=0) OR (YPBM.s_id in (select [id] from #storagestable))) 
     AND ((@employeestable=0) OR (YPBM.RowE_id in (select [id] from #employeestable)))
END
ELSE
BEGIN
/*exec ts_c_qrSaleBuyPrice '2015-02-01 00:00:00','2015-02-05 00:00:00',2,0,0,0,1,'',2,0*/
SELECT YPBM.*,isnull(C.[name],'')cname,isnull(RE.[name],'')ename,isnull(p.[name],'')Pname
       ,p.standard,p.makearea,isnull(m.name,'') AS medtype,u.[name] AS uname,
       ISNULL(l.loc_name, '') AS lname,isnull(s.[name],'')sname,
       rate=CASE WHEN YPBM.unitid=p.unit1_id THEN 1 
                 WHEN YPBM.unitid=p.unit2_id THEN rate2
                 WHEN YPBM.unitid=p.unit3_id THEN rate3
                 WHEN YPBM.unitid=p.unit4_id THEN rate4 END,
                 isnull(YPBM.factory,'') as factory,
                 YPBM.costtaxrate,YPBM.costtaxprice,YPBM.costtaxtotal
FROM
   (SELECT ISNULL(b.billdate,'') AS billdate,b.billtype,b.billid,b.billnumber,b.inputman,b.auditman,b.c_id, b.note,b.Y_id,
           a.ss_id as s_id ,a.location_id,a.unitid,a.RowE_id,
           cast(isnull(a.totalmoney/a.quantity,0) as numeric(25,8)) AS price, cast(isnull(a.costprice, 0) as numeric(25,8)) AS costprice,
           cast(isnull(a.taxtotal/a.quantity,0) as numeric(25,8))  AS taxprice,isnull(a.batchno,'') AS batchno,
           a.quantity  AS [quantity],
           a.SendQTY   AS [SendQTY],
           a.SendCostTotal  AS [SendCostTotal],
           a.P_id as Product_id,F.AccountComment as factory,
           cast(isnull(a.costtaxprice, 0) as numeric(25,8)) AS costtaxprice,
           cast(isnull(a.costtaxrate, 0) as numeric(25,8)) AS costtaxrate,
           cast(isnull(a.costtaxtotal,0) as numeric(25,8))  AS costtaxtotal
    /*FROM  FilterSalemanagebill(@nloginEID) a  */
    FROM salemanagebill A LEFT JOIN basefactory f on A.factoryid=f.CommID /*XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
        
    Inner JOIN 
          (select * from billidx where  billtype in (10, 12,53,112,210) and
                           (billdate BETWEEN @begindate AND @EndDate) and
                            billstates=0
           )b ON b.billid=a.bill_id 
    WHERE aoid in (0,5) and a.p_id>0
        AND (@nP_id=0 or a.p_id=@nP_id)
        AND (@nC_id=0 or b.c_id=@nC_id)
        AND (@nE_id=0 or a.Rowe_id=@nE_id)
        AND (@nS_id=0 or a.ss_id=@nS_id)
        AND (@nYClassid='' OR b.Y_id in (select Company_id from Company where class_id like @nYClassid+'%'))
   )YPBM   
	  LEFT  JOIN  products  p  ON  p.product_id=YPBM.Product_id 
	  left   join 
	  (
			select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on p.product_id = m.baseinfo_id
	  LEFT  JOIN  unit      u  ON  u.unit_id=p.unit1_id
	  LEFT  JOIN  location  l  ON  l.loc_id=YPBM.location_id 
          LEFT  JOIN  employees RE ON  RE.Emp_id=YPBM.RowE_id
          LEFT  JOIN  Clients   C  ON  C.Client_id=YPBM.c_id 
          LEFT  JOIN  storages  S  ON  S.storage_id=YPBM.s_id
   WHERE ((@Companytable=0)or (YPBM.Y_id in (select [id] from #Companytable)))
     AND ((@ClientTable=0) or (YPBM.c_id in (select [id] from #Clienttable)))
     AND ((@Storetable=0) OR (YPBM.s_id in (select [id] from #storagestable))) 
     AND ((@employeestable=0) OR (YPBM.RowE_id in (select [id] from #employeestable)))
END
GO
