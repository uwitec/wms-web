/************拣货流程信息检查*************/
/***********add by luowei 2014-02-18*****/

create procedure TS_L_CheckJhInfo
(
   @norder_id int,  /*--原始单据id*/
   @nbill_id int,   /*--新单据id*/
   @nflag  int,  /*--nflag : 1 检查拆分的销售出库单*/
   @noutInfo int out 
)
as
begin
   
    set @noutInfo = 0 
   
   if @nflag = 1 /*检查拆分的销售出库单*/
   begin
     if not exists(select 1 from billdraftidx where billid = @nbill_id and posid = @norder_id and billtype = 10)
       set @noutInfo = -1  /* -1表示销售出库单拆分失败*/
     else
     begin
       /*-- 判断新单据中仓库简名是分组正确*/
       declare @ncount int
       set @ncount = 0
       select @ncount = count(alias) from (SELECT   s.alias
			FROM      dbo.salemanagebilldrf AS sb INNER JOIN
							dbo.storages AS s ON sb.ss_id = s.storage_id
			WHERE   (sb.bill_id = @nbill_id) AND (sb.p_id > 0) AND (sb.ss_id > 0)
			GROUP BY s.alias ) t
			
	   if @ncount <> 1 		
	     set @noutInfo = -1
	  else		
         set @noutInfo = 0
     end  
   end
   
   if @nflag = 2  /*检查销售出库单是否正常生成拣货单*/
   begin
     if not exists(select 1 from billdraftidx where billid = @nbill_id and order_id = @norder_id and billtype = 254)
       set @noutInfo = -2
     else
       set @noutInfo = 0
   end
   
   
   
   return 0
   


end
GO
