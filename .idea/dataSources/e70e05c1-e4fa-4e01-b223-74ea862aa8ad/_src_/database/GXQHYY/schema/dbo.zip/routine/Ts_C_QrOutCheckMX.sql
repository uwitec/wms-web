




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
出库复核查询明细
@BeginDate   开始时间
@EndDate     结束时间
@sout_id     出货仓库id
@c_id        客户id
@AuditMan    复核审核人
@CheckMan    复核人
@CasedMan    装箱人
@QueryType   0 入库复核单据，1 出库复核单据
********************************************/
CREATE PROCEDURE [Ts_C_QrOutCheckMX]
(	@BeginDate      VARCHAR(50) = '',
	@EndDate		VARCHAR(50) = '',
	@sout_id		INT=0,
	@c_id			INT=0,
	@AuditMan 		INT=0,
	@CheckMan 		INT=0,
	@CasedMan 		INT=0,
	@QueryType      INT=0,
    @Y_id           INT=0
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @sout_id is null  SET @sout_id = 0
if @c_id is null  SET @c_id = 0
if @AuditMan is null  SET @AuditMan = 0
if @CheckMan is null  SET @CheckMan = 0
if @CasedMan is null  SET @CasedMan = 0
if @QueryType is null  SET @QueryType = 0
if @Y_id is null  SET @Y_id = 0
/*Params Ini end*/
	SET NOCOUNT ON
  
  DECLARE @SQLScript VARCHAR(8000)
  DECLARE @SQLScript1 VARCHAR(8000)

  SELECT  @SQLScript='select bb.BillNumber,bb.BillDate,bb.AuditDate,bb.Billtype,bb.BillID,bb.sOut_ID,bb.c_id,bb.ssName,bb.cName,bb.CheckDate,bb.AuditName,bb.CheckName,bb.casedname,bb.CheckMan,bb.AuditMan,bb.CasedMan,
                         pp.p_id,pp.code,pp.[name],pp.alias,pp.standard,pp.makearea,pp.permitcode,pp.medtype,pp.unitname1,pp.locname,pp.location_id,
                         pp.batchno,pp.validdate,pp.quantity,pp.costTotal,bb.BillStates,bb.InputMan
                       from 
                         (select vb.BillNumber,vb.BillDate,vb.AuditDate,vb.Billtype,vb.BillID,vb.BillStates,vb.InputMan,vb.sOut_ID,vb.c_id,vb.ssName,vb.cName,
                                 ci.CheckDate,e1.name as AuditName,e2.name as CheckName,ci.CheckMan,ci.AuditMan,ci.CasedMan,case when e3.name is null then '''' else e3.name end as casedname 
                            from CheckIdx ci 
                            left join vw_c_billidx vb on ci.Billid=vb.Billid
                            left join Employees e1 on ci.AuditMan=e1.emp_id
                            left join Employees e2 on ci.CheckMan=e2.emp_id
                            left join Employees e3 on ci.casedMan=e3.emp_id)as bb, 
                         (select pd.BillID,pd.p_id,vp.code,vp.[name],vp.alias,vp.standard,vp.makearea,vp.permitcode,vp.medtype,vp.unitname1,pd.locname,pd.location_id,
                            pd.batchno,pd.validdate,abs(pd.quantity) as quantity,abs(pd.taxtotal)as costTotal 
                            from vw_c_products vp,vw_c_pdetail pd 
                            where pd.Y_id='+CHAR(39)+convert(varchar(10),@Y_ID)+CHAR(39)+' AND 
                            vp.product_id=pd.p_id '
    IF  @QueryType = 0                        
        SET @SQLScript = @SQLScript + ' and pd.quantity > 0 '
    IF  @QueryType = 1                        
        SET @SQLScript = @SQLScript + ' and pd.quantity < 0 '
        
    SET @SQLScript = @SQLScript + ')as pp
                       where bb.auditman > 0 and bb.checkman > 0 and pp.Billid=bb.billid and CheckDate between 
                            CONVERT(DATETIME,'''+@BeginDate+''') and  CONVERT(DATETIME,'''+@EndDate+''') '


	IF  @C_id<>0 
		SET @SQLScript=@SQLScript+' and c_id='+convert(varchar(10),@C_ID)
	IF  @sout_id<>0 
		SET @SQLScript=@SQLScript+' and sout_id='+convert(varchar(10),@sout_id)
	IF  @AuditMan<>0 
		SET @SQLScript=@SQLScript+' and AuditMan='+convert(varchar(10),@AuditMan)
	IF  @CheckMan<>0 
		SET @SQLScript=@SQLScript+' and CheckMan='+convert(varchar(10),@CheckMan)
    IF  @CasedMan<>0 
		SET @SQLScript=@SQLScript+' and CasedMan='+convert(varchar(10),@CasedMan)	
		
		
  SELECT @SQLScript1 = ' (select p.product_id,p.WholeUnit_id,p.rate2 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit2_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate3 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit3_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate4 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit4_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 ) RATE'					 	

/*PRINT @SQLScript*/
  EXEC( ' select isnull(cast(round((t.quantity/rate.rate),0,1) as int),0) as wholeqty ,t.*  from ( '+@SQLScript + ') t left join '+@SQLScript1+' on t.p_id = rate.product_id ')
 	GOTO Succee


Succee:
  RETURN  0
GO
