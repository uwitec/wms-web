
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-4-26*/
/* Description:	获取指定单据类型的单据编号*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_CreateBillSN] 
	@BillType int, 
	@IsUpdate bit,
	@BillDate datetime,
	@EmpID int,
	@InputID int,
	@BillSN varchar(200) output,
	@YId int = 0
AS
BEGIN
	SET NOCOUNT ON;

	if @BillDate IS NULL SET @BillDate = getdate()
	IF @YId IS NULL SET @YId = 0
	
	DECLARE	@return_value int
	DECLARE @nRet int
	DECLARE @nSnTag int
	DECLARE @szPrefix varchar(20)

	/* 取机构前缀*/
	SET @szPrefix = ''
	SELECT @szPrefix = prefix FROM company WHERE company_id = @YId

	BEGIN TRAN
			
		IF @BillType BETWEEN 501 AND 599
			SET @nSnTag = 20
		ELSE
			SET @nSnTag = 0

		/* 获取单据编号样式*/
		EXEC	@return_value = [dbo].[ts_b_GetBillSN]
				@nRet = @nRet OUTPUT,
				@szSN = @BillSN OUTPUT,
				@nBILLTYPE = @BillType,
				@nTAG = @nSnTag,
				@nEmpID = @EmpID			
					
		declare @iSt int
		declare @iEd int
		declare @iLen int
		declare @szCount varchar(10)
		declare @bAM bit
		declare @szMonth varchar(10)
		declare @szTmp varchar(200)
		declare @cTmp char(1)
		
		declare @cLast char(1)
		declare @sLast varchar(50)

		set @szTmp = ''
		set @cLast = ''
		set @sLast = ''
		
		/* 判断是否显示上午/下午*/
		if CHARINDEX('ampm', @BillSN) > 0
			set @bAM = 1
		else
			set @bAM = 0
		/* 获取中文月份*/
		select @szMonth = CASE DATEPART(M, @BillDate) WHEN 1 then '一月' WHEN 2 THEN '二月' WHEN 3 THEN '三月' 
			WHEN 4 THEN '四月' WHEN 5 THEN '五月' WHEN 6 THEN '六月' WHEN 7 THEN '七月' WHEN 8 THEN '八月' 
			WHEN 9 THEN '九月' WHEN 10 THEN '十月' WHEN 11 THEN '十一月' ELSE '十二月' end
		/* 替换换行符*/
		set @BillSN = REPLACE(@billSN, CHAR(13), '')
		set @BillSN = REPLACE(@billSN, CHAR(10), '')
		
		set @iLen = LEN(@BillSN)
		while @iLen > 0
		begin
			/* 取剩余字符串的第一位*/
			set @cTmp = SUBSTRING(@BillSN, 1, 1)
			/* 如果与上一位相同则附加到未处理字符串*/
			if LOWER(@cTmp) = @cLast
			begin
				set @sLast = @sLast + @cLast
				set @BillSN = SUBSTRING(@BillSN, 2, 200)
				set @iLen = @iLen - 1
			end
			else
			begin
				/* 如果遇到ampm则处理为上午/下午*/
				if @cLast = 'a' and LOWER(SUBSTRING(@BillSN, 1, 3)) = 'mpm'
				begin
					set @szTmp = @szTmp + CASE WHEN DATEPART(HH, @BillDate) < 12 THEN '上午' ELSE '下午' END
					set @BillSN = SUBSTRING(@BillSN, 4, 200)
					set @sLast = ''
					set @cLast = ''
					set @iLen = @iLen - 4
				end
				else
				/* 处理时间字符串*/
				if @cLast in ('m', 'y', 'd', 'h', 'n', 's')
				begin
					if @cLast = 'm'
						select @sLast = CASE LEN(@sLast) WHEN 1 THEN CAST(DATEPART(M, @BillDate) AS CHAR(1)) WHEN 2 THEN DATENAME(MM, @BillDate) ELSE @szMonth END
					else
					if @cLast = 'y'
						select @sLast = CASE LEN(@sLast) WHEN 1 THEN DATEPART(YY, @BillDate) WHEN 2 THEN DATEPART(YY, @BillDate) ELSE DATEPART(YYYY, @BillDate) END
					else
					if @cLast = 'd'
						select @sLast = CASE LEN(@sLast) WHEN 1 THEN DATENAME(D, @BillDate) WHEN 2 THEN dbo.PadLeft(DATENAME(DD, @BillDate), 2, '0') ELSE DATENAME(WEEKDAY, @BillDate) END
					if @cLast = 'h'
					begin
						if @bAM = 1
							select @sLast = dbo.PadLeft(CASE DATEPART(HH, @BillDate) WHEN 12 THEN 12 ELSE DATEPART(HH, @BillDate) % 12 END, LEN(@sLast), '0')
						else
							select @sLast = dbo.PadLeft(DATEPART(HH, @BillDate), LEN(@sLast), '0')
					end
					else
					if @cLast = 'n'
						select @sLast = dbo.PadLeft(DATEPART(N, @BillDate), LEN(@sLast), '0')
					else
					if @cLast = 's'
						select @sLast = dbo.PadLeft(DATEPART(S, @BillDate), LEN(@sLast), '0')
					set @szTmp = @szTmp + @sLast
					set @cLast = LOWER(@cTmp)
					set @sLast = @cLast
					set @BillSN = SUBSTRING(@BillSN, 2, 200)
					set @iLen = @iLen - LEN(@sLast)
				end
				else
				begin
					if @cLast = '['
					begin
						set @iEd = CHARINDEX(']', @BillSN, 2)
						set @szCount = dbo.PadLeft(@nRet + 1, @iEd - 1, '0')
						set @szTmp = @szTmp + @szCount
						set @BillSN = SUBSTRING(@BillSN, @iEd + 1, 200)
						set @iLen = @iLen - @iEd
						set @cLast = ''
						set @sLast = ''
					end
					else
					if @cLast = '"'
					begin
						set @iEd = CHARINDEX('"', @BillSN, 2)
						if @iEd <= 0
							set @iEd = 200
						set @szTmp = @szTmp + SUBSTRING(@BillSN, 1, @iEd - 1)
						set @BillSN = SUBSTRING(@BillSN, @iEd + 1, 200)
						set @iLen = @iLen - @iEd
						set @cLast = ''
						set @sLast = ''
					end
					else
					begin
						set @szTmp = @szTmp + @sLast
						if @cTmp = '"'
						begin
							set @iEd = CHARINDEX('"', @BillSN, 2)
							if @iEd <= 0
								set @iEd = 200
							set @szTmp = @szTmp + SUBSTRING(@BillSN, 2, @iEd - 2)
							set @BillSN = SUBSTRING(@BillSN, @iEd + 1, 200)
							set @iLen = @iLen - @iEd
							set @cLast = ''
							set @sLast = ''
						end
						else
						if @cTmp = '['
						begin
							set @iEd = CHARINDEX(']', @BillSN, 2)
							set @szCount = dbo.PadLeft(@nRet + 1, @iEd - 2, '0')
							set @szTmp = @szTmp + @szCount
							set @BillSN = SUBSTRING(@BillSN, @iEd + 1, 200)
							set @iLen = @iLen - @iEd
							set @cLast = ''
							set @sLast = ''
						end
						else
						begin
							set @cLast = @cTmp
							set @sLast = @cLast
							set @BillSN = SUBSTRING(@BillSN, 2, 200)
							set @iLen = @iLen - 1
						end
					end
				end
			end
		end
		
		set @szTmp = REPLACE(@szTmp, '经手人编码', ISNULL((select serial_number from employees where emp_id = @EmpID), ''))
		set @szTmp = REPLACE(@szTmp, '制单人编码', ISNULL((select serial_number from employees where emp_id = @InputID), ''))
		
		set @BillSN = @szPrefix + @szTmp
		
		if @IsUpdate = 1
		begin
			SET @nSnTag = @nSnTag + 1
			exec ts_b_GetBillSN @nRet output, @szTmp, @BillType, @nSnTag,@EmpID
		end
		
	COMMIT TRAN
END
GO
