
CREATE FUNCTION GetTcRateParent
(
	@Parent_Id  VARCHAR(30) = '000000',
	@begindate  VARCHAR(50),
	@enddate    VARCHAR(50),
	@Employee   VARCHAR(100) = '',
	@nloginEID  INT = 0,
	@YClass_id  VARCHAR(100) = ''
)
RETURNS numeric(25,8)
AS
BEGIN
	DECLARE @Re numeric(25,8)
	SET @Re = 0
	IF EXISTS(
	       SELECT 1
	       FROM   employees
	       WHERE  class_id LIKE @Parent_Id + '%'
	              AND Tp_ID > 0
	              AND child_number = 0
	              AND DELETED = 0
	   )
	BEGIN
	    DECLARE @Companytable    INTEGER,
	            @employeestable  INTEGER
	    
	    DECLARE @Companytb       TABLE ([id] INT)
	    DECLARE @employeestb     TABLE ([id] INT)
	    /*---分支机构授权*/
	    IF NOT EXISTS(
	           SELECT *
	           FROM   userauthorize u
	           WHERE  u.e_id = @nloginEID
	                  AND u.Type = 'Y'
	       )
	       OR EXISTS(
	              SELECT *
	              FROM   userauthorize u
	              WHERE  u.e_id = @nloginEID
	                     AND u.Type = 'Y'
	                     AND u.psc_id = '000000'
	          )
	    BEGIN
	        SET @Companytable = 0
	    END
	    ELSE
	    BEGIN
	        SET @Companytable = 1
	        INSERT @Companytb
	          (
	            [id]
	          )
	        SELECT Company_id
	        FROM   Company C
	        WHERE  EXISTS(
	                   SELECT u.psc_id
	                   FROM   userauthorize u
	                   WHERE  u.e_id = @nloginEID
	                          AND u.Type = 'Y'
	                          AND C.class_id LIKE u.psc_id + '%'
	               )
	    END
	    /*---分支机构授权*/
	    /*---职员授权*/
	    IF NOT EXISTS(
	           SELECT *
	           FROM   userauthorize u
	           WHERE  u.e_id = @nloginEID
	                  AND u.Type = 'E'
	       )
	       OR EXISTS(
	              SELECT *
	              FROM   userauthorize u
	              WHERE  u.e_id = @nloginEID
	                     AND u.Type = 'E'
	                     AND u.psc_id = '000000'
	          )
	    BEGIN
	        SET @employeestable = 0
	    END
	    ELSE
	    BEGIN
	        SET @employeestable = 1
	        INSERT @employeestb
	          (
	            [id]
	          )
	        SELECT emp_id
	        FROM   employees C
	        WHERE  EXISTS(
	                   SELECT u.psc_id
	                   FROM   userauthorize u
	                   WHERE  u.e_id = @nloginEID
	                          AND u.Type = 'E'
	                          AND C.class_id LIKE u.psc_id + '%'
	               )
	    END 
	    /*---职员授权*/
	    
	    SELECT @Re = ISNULL(SUM(SumToTal.TcToTal), 0)
	    FROM   (
	               SELECT VE.emp_id,
	                      ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS 
	                      TcToTal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID
	                          FROM   Employees VE
	                                 LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                 LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                 LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                          WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                 AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_Id + '%') 
	                                      OR (@Employee <> '' AND VE.[name] = @Employee))
	                                 AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                 AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                                 AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 7 AND VE.Tp_ID > 0
	                      )VE
	                      LEFT JOIN (
	                               SELECT a.inputman AS e_id, COUNT(*) AS mTotal
	                               FROM   (   SELECT b.inputman FROM billidx b, buymanagebill bi 
                                              WHERE b.billid = bi.bill_id AND b.billstates = 0 AND b.order_id = 0 AND
                                                    b.billdate BETWEEN @BeginDate AND @EndDate AND
                                                    b.Billtype IN (10, 11, 12, 13, 210, 211, 20, 21, 220, 221)
                                              UNION ALL
                                              SELECT b.inputman FROM billidx b, salemanagebill bi 
                                              WHERE b.billid = bi.bill_id AND b.billstates = 0 AND b.order_id = 0 AND
                                                    b.billdate BETWEEN @BeginDate AND @EndDate AND
                                                    b.Billtype IN (10, 11, 12, 13, 210, 211, 20, 21, 220, 221)       
	                                      )a
	                               GROUP BY inputman
	                           ) AS bi
	                           ON  bi.e_id = ve.emp_id
	               UNION ALL
	               SELECT VE.emp_id,
	                      ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS 
	                      TcToTal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID
	                          FROM   Employees VE
	                                 LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                 LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                 LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                          WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                 AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_Id + '%') 
	                                      OR (@Employee <> '' AND VE.[name] = @Employee))
	                                 AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                 AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                                 AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 6 AND VE.Tp_ID > 0
	                      )VE
	                      LEFT JOIN (
	                               SELECT a.inputman AS e_id, COUNT(*) AS mTotal
	                               FROM   (   SELECT inputman
	                                          FROM   BillIdx
	                                          WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0 AND order_id = 0
	                                                 AND Billtype IN (10, 11, 12, 13, 210, 211, 20, 21, 220, 221)
	                                      )a
	                               GROUP BY inputman
	                           ) AS bi
	                           ON  bi.e_id = ve.emp_id
	               UNION ALL
	               SELECT VE.emp_id,
	                      ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS 
	                      TcToTal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID
	                          FROM   Employees VE
	                                 LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                 LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                 LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                          WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                 AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_Id + '%') 
	                                      OR (@Employee <> '' AND VE.[name] = @Employee))
	                                 AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                 AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                                 AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 0 AND VE.Tp_ID > 0
	                      )VE
	                      LEFT JOIN (
	                               SELECT a.e_id, SUM(CASE WHEN (BillType IN (11, 13, 54, 211)) THEN -a.YsMoney ELSE a.YsMoney END) AS mTotal
	                               FROM   (   SELECT e_id, billtype, ysmoney
	                                          FROM   BillIdx
	                                          WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0
	                                                 AND [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)
	                                      )a
	                               GROUP BY e_id
	                           ) AS bi
	                           ON  bi.e_id = ve.emp_id
	               UNION ALL
	               SELECT VE.emp_id, ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID
	                          FROM   Employees VE
	                                 LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                 LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                 LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                          WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                 AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_ID + '%') 
	                                     OR (@Employee <> '' AND VE.[name] = @Employee))
	                                 AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                 AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                                 AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 5
	                      )VE
	                      LEFT JOIN (
	                               SELECT a.e_id, SUM(CASE WHEN (BillType IN (11, 13, 54, 211)) THEN -a.YsMoney ELSE a.YsMoney END) AS mTotal
	                               FROM   (   SELECT e_id, billtype, ysmoney
	                                          FROM   BillIdx
	                                          WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0
	                                                 AND [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)
	                                      )a
	                               GROUP BY e_id
	                           ) AS bi
	                           ON  bi.e_id = ve.emp_id
	               UNION ALL
	               SELECT VE.emp_id, ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID	                                 
	                          FROM   Employees VE
	                                 LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                 LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                 LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                          WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                 AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 1
	                                 AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_ID + '%') 
	                                    OR (@Employee <> '' AND VE.[name] = @Employee))
	                                 AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                 AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                      )VE
	                      LEFT JOIN (
	                               SELECT b.e_id, ISNULL(SUM(a.jdmoney), 0) AS mTotal
	                               FROM   accountdetail a
	                                      INNER JOIN billidx b ON  a.billid = b.billid
	                               WHERE  a.jdmoney > 0
	                                      AND a.a_id IN (SELECT account_id
	                                                     FROM   account
	                                                     WHERE  parent_id LIKE '000001000004%' OR  account_id = 6)
	                                      AND b.AuditDate BETWEEN @BeginDate AND @EndDate AND b.billstates = 0
	                               GROUP BY b.e_id
	                           ) BI
	                           ON  bi.e_id = ve.emp_id 
	               UNION ALL 
	               SELECT sp.emp_id, SUM(dbo.GetTcRate(sp.mTotal, sp.f_id)) AS TcTotal
	               FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id,
	                                 CASE WHEN ISNULL(tpo.FtcType, TcType) = 2 THEN sbbi.mSLTotal
	                                      ELSE (   CASE WHEN ISNULL(tpo.FtcType, TcType) = 3 THEN sbbi.mJETotal
	                                                    ELSE (CASE WHEN ISNULL(tpo.FtcType, TcType) = 4 THEN sbbi.mMLTotal ELSE 0 END)
	                                               END
	                                           )
	                                 END AS mTotal,
	                                 ISNULL(tpo.F_id, ve.f_id) AS f_id
	                          FROM   (   SELECT VE.emp_id, ve.tp_id, ve.class_id, ve.parent_id, TP.F_ID, ISNULL(f.tcType, -1)tcType	                                            
	                                     FROM   Employees VE
	                                            LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
	                                            LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
	                                            LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
	                                     WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM @Companytb)))
	                                            AND VE.Deleted = 0 AND VE.Child_Number = 0 AND TcType IN (2, 3, 4)
	                                            AND ((@Employee = '' AND VE.Parent_id LIKE @Parent_ID + '%')
	                                                    OR (@Employee <> '' AND VE.[name] = @Employee))
	                                            AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
	                                            AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM @employeestb)))
	                                 )VE
	                                 LEFT JOIN (
	                                          SELECT a.e_id, a.p_id,
	                                                 SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -a.Quantity ELSE a.Quantity END) AS mSLTotal,
	                                                 SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -a.TaxTotal ELSE a.TaxTotal END) AS mJETotal,
	                                                 SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -(a.TaxTotal -(a.costPrice * a.Quantity))
	                                                          ELSE (a.TaxTotal -(a.costPrice * a.Quantity))
	                                                     END) AS mMLTotal
	                                          FROM   (   SELECT bi.billtype, sb.RowE_id AS e_id, sb.p_id, sb.quantity, sb.taxtotal, sb.costPrice
	                                                     FROM   saleManageBill 
	                                                            sb,
	                                                            BillIdx bi
	                                                     WHERE  [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211) AND sb.AOID IN (0, 5)
	                                                            AND BillDate  BETWEEN @BeginDate  AND @EndDate AND BillStates =  0 AND sb.Bill_id =  bi.BillID
	                                                 )a
	                                          GROUP BY a.p_id, a.e_id
	                                      ) AS SBBI
	                                      ON  sbbi.e_id = ve.emp_id
	                                 LEFT JOIN (SELECT b.*, a.tcType AS FtcType FROM TcFormula a, TcProjectOther b 
                                                WHERE  a.Formula_id = b.F_id) tpo ON  ve.tp_id = tpo.Tp_id AND sbbi.p_id = tpo.p_id
	                      ) Sp
	               GROUP BY sp.emp_id	                      
	           ) SumTotal
	END
	
	RETURN(@Re)
END
GO
