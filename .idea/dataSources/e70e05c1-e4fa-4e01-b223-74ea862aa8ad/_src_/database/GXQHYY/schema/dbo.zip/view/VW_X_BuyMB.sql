
CREATE   VIEW [VW_X_BuyMB]
AS
SELECT BI.*, 
  ISNULL(P.[Product_id]  ,'') AS [PID],
  ISNULL(P.[Name]  ,'') AS [PName],    
  ISNULL(P.[Class_ID]  ,'') AS [PClass_ID],
  ISNULL(P.[Parent_ID],'')  AS [Pparent_ID],
  ISNULL(P.[serial_number]  ,'') AS [serial_number],
  ISNULL(P.[alias]  ,'') AS [alias],
  ISNULL(P.[standard]  ,'') AS [standard],
  ISNULL(P.[modal]  ,'') AS [modal],
  ISNULL(P.[permitcode]  ,'') AS [permitcode],
  ISNULL(P.[makearea]  ,'') AS [makearea],
  
  ISNULL(SS.[Name] ,'') AS [SSName],   ISNULL(SS.[Class_ID] ,'') AS [SSClass_ID],
  ISNULL(SD.[Name] ,'') AS [SDName],   ISNULL(SD.[Class_ID] ,'') AS [SDClass_ID],
  ISNULL(U.[Name]  ,'') AS [UnitName], ISNULL(L.[Loc_Name]  ,'') AS [LocName],
  ISNULL(C.[Name]  ,'') AS [SupplierName]/*,*/

FROM BuyManageBill BI
  LEFT JOIN Products P  ON BI.[P_ID]=P.[Product_ID] 
  LEFT JOIN Storages SD ON BI.[SD_ID]=SD.[Storage_ID] 
  LEFT JOIN Storages SS ON BI.[SS_ID]=SS.[Storage_ID]
  LEFT JOIN Unit U      ON BI.[UnitID]=U.[Unit_ID]
  LEFT JOIN Location L  ON BI.[Location_ID]=L.[Loc_ID]
  LEFT JOIN ClientS C   ON BI.[Supplier_ID]=C.[Client_ID]

WHERE  [P_ID] > 0
GO
