

create view dbo.vw_c_billidx
as
select b.[billid]
      ,b.[billdate]
      ,b.[billnumber]
      ,b.[billtype]
      ,b.[a_id]
      ,b.[c_id]
      ,b.e_id
      ,sout_id= Case when b.billtype in (112,122) then 0 else b.sout_id end
      ,sin_id = Case when b.billtype in (112,122) then 0 else b.sin_id end
      ,b.[auditman]
      ,b.[inputman]
      ,b.[ysmoney]
      ,b.[ssmoney]
      ,b.[quantity]
      ,b.[taxrate]
      ,b.[period]
      ,b.[billstates]
      ,b.[order_id]
      ,b.[department_id]
      ,b.[posid]
      ,b.region_id
      ,b.[auditdate]
      ,b.[skdate]
      ,b.[jsye]
      ,b.[jsflag]
      ,b.[note]
      ,b.[summary]
      ,b.[invoice]
      ,b.[transcount]
      ,b.[lasttranstime]
      ,b.[GUID]
      ,b.[InvoiceTotal]
      ,b.[InvoiceNO]
      ,b.[BusinessType]
      ,b.[jsInvoiceTotal]
      ,b.[SendQTY]
      ,b.[GatheringMan]
      ,b.[VIPCardID]
      ,b.[ArAptotal]
      ,b.Y_ID
      ,b.[transflag]
      ,b.[begindate]
      ,b.[Enddate]
      ,b.[integral]
      ,b.[integralYE]
      ,b.[B_CustomName1]
      ,b.[B_CustomName2]
      ,b.[B_CustomName3]
      ,b.[ImportJscw]
      ,b.[JscwGuid]
      ,b.[RetailDate]
      ,b.[sendC_id]
      ,b.[Sendid]
      ,b.[WholeQty]
      ,b.[PartQty]
      ,b.[yguid]
      ,b.[BalanceMode],
      invoicetype=(
      case B.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.[name] else CY.[name] END), '') as cname,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.address else CY.opaddress end),'') as cAddress,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.contact_personal else CY.manager end), '') as cContact_personal,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.phone_Number else CY.tel end), '') as cPhone_Number,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.class_id else  CY.class_id end), '')cclass_id,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.serial_number else CY.serial_number end), '')Cnumber, 
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.C_Customname1 else '' END), '') as C_Customname1,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.C_Customname2 else '' END), '') as C_Customname2,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.C_Customname3 else '' END), '') as C_Customname3,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.C_Customname4 else '' END), '') as C_Customname4,
      isnull((case when b.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.C_Customname5 else '' END), '') as C_Customname5,
      isnull(dbo.account.name, '') as aname, isnull(dbo.employees.name, '') as ename,isnull(employees.serial_number, '')enumber,
      isnull(employees.dep_id,0)dep_id, isnull(dbo.account.class_id,'') as aclass_id,
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      isnull(ss.[name],'') as ssname, 
      isnull(sd.[name],'') as sdname,
      isnull(empg.[Name],'') as GatheringManName,
      isnull(empg.[class_id],'') as GatheringManclass_id,
      isnull(Y.Class_ID,'') as YClass_ID,
      isnull(Y.[name],'') as Yname,
      isnull((case when b.billtype in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then CY.Class_ID else '' end),'') as CYClass_ID,
      dbo.clients.RoadID,dbo.clients.szOrdernum,
      b.QualityAudit, b.QualityAuditDate, isnull(eQuality.[name],'') as QualityAuditer,
      isnull((case when b.billtype in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then yb.artotal else cb.artotal end), 0) as arTotal,
      isnull((case when b.billtype in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then yb.aptotal else cb.aptotal end), 0) as apTotal,
      ISNULL(wt.saleEName, '') as wtEName, FollowNumber, TicketDate,sds.name as sendcname

from billidx b left outer join
      dbo.account on B.a_id = dbo.account.account_id left outer join
      dbo.clients on B.c_id = dbo.clients.client_id left outer join
      dbo.employees on B.e_id = dbo.employees.emp_id
      left outer join employees emp on B.inputman=emp.emp_id
      left outer join employees empa on B.auditman=empa.emp_id
      left outer join employees empg on B.gatheringman=empg.emp_id
      left outer join employees eQuality on B.QualityAudit=eQuality.emp_id
      left outer join department dep on B.department_id=dep.departmentid
      left outer join region reg on B.region_id=reg.region_id
      left outer join storages ss on B.sout_id=ss.storage_id
      left outer join storages sd on B.sin_id=sd.storage_id
      left outer join Company  Y  on B.Y_id=Y.Company_id
      left Outer join Company  CY  on B.C_id=CY.company_id 
      left join Clientsbalance cb on b.c_id = cb.C_ID and b.Y_ID = cb.Y_id
      left join Companybalance yb on b.c_id = yb.c_id and b.Y_ID = yb.y_id
      left join orderidx oidx on b.order_id = oidx.billid
      left join wtorder  wt on oidx.WT_ID = wt.WT_ID   
      left join clients  sds on b.sendC_id=sds.client_id
GO
