

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
CREATE PROCEDURE [TS_C_QrInvoiceNew]
( @BeginDate 	       DATETIME=0,
  @EndDate	         DATETIME=0,
  @szCClassID	       VARCHAR(30)='',
  @szPClassID        VARCHAR(30)='',
  @szEClassID        VARCHAR(30)='',
  @szInputmanclassID VARCHAR(30)='',  
  @InvoiceNo	       VARCHAR(50)='',
  @InvoiceInput      INT=0,
  @InvoiceAudit      INT=0,
  @nInvoiceType	     INT=0,/*发票类型*/
  @nBillORProduct    INT=0,/*按单据还是按商品*/
  @nSaleOrBuy        INT=0,/*发票种类 进货或者是销售*/
  @nMode             INT=0,/*0  已开票单据 1未开票单据*/
  @nDateType         INT=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szCClassID is null  SET @szCClassID = ''
if @szPClassID is null  SET @szPClassID = ''
if @szEClassID is null  SET @szEClassID = ''
if @szInputmanclassID is null  SET @szInputmanclassID = ''
if @InvoiceNo is null  SET @InvoiceNo = ''
if @InvoiceInput is null  SET @InvoiceInput = 0
if @InvoiceAudit is null  SET @InvoiceAudit = 0
if @nInvoiceType is null  SET @nInvoiceType = 0
if @nBillORProduct is null  SET @nBillORProduct = 0
if @nSaleOrBuy is null  SET @nSaleOrBuy = 0
if @nMode is null  SET @nMode = 0
if @nDateType is null  SET @nDateType = 0
/*Params Ini end*/
SET NOCOUNT ON 
/*0:发票模块中采购类单据按商品开票  1:发票模块中销售类单据按商品开票*/
/*2:采购类单据中按商品开票         3:销售类单据中按商品开票*/
/*4:发票模块中按单开票             5:单据中按单开票*/
DECLARE 
  @SQLScript VARCHAR(8000)

  SET @SQLScript=' 
    SELECT 
      0 as SerialNo,
      '' '' as BillName,       
      VI.*,
      ISNULL(VP.[Name]      ,'''') AS [Pname],
      ISNULL(VP.[Unitname1] ,'''') AS [Unitname1],
      ISNULL(VP.[Standard]  ,'''') AS [Standard],
      ISNULL(VP.[Modal]  ,'''')    AS [Modal],
      ISNULL(VP.[Makearea]  ,'''') AS [Makearea]

    From VW_C_Invoice VI 
    LEFT JOIN VW_X_Products VP ON VI.[P_ID]=VP.[Product_ID]
    WHERE VI.AOID IN (0,8) '
  /*    ISNULL(VP.[Serial_Number]      ,'''') AS [Serial_Number]*/

  IF @nDateType=0 
     SET @SQLScript=@SQLScript+ '	AND (VI.[Billdate] BETWEEN '
       +CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 21)+CHAR(39)+' AND '
       +CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 21)+CHAR(39)+')' 
  IF @nDateType=1
     SET @SQLScript=@SQLScript+ '	AND (VI.[Invoicedate] BETWEEN '
       +CHAR(39)+CONVERT(VARCHAR(10), @BeginDate, 21)+CHAR(39)+' AND '
       +CHAR(39)+CONVERT(VARCHAR(10), @EndDate, 21)+CHAR(39)+')' 
  		
  IF @szCClassID<>'' 
  	SET @SQLScript=@SQLScript+' AND VI.[Cclass_ID] LIKE '+CHAR(39)+@szCClassID+'%'+CHAR(39)
  IF @szPClassID<>'' 
  	SET @SQLScript=@SQLScript+' AND VP.[Class_ID] LIKE '+CHAR(39)+@szPClassID+'%'+CHAR(39)
  IF @szEClassID<>'' 
  	SET @SQLScript=@SQLScript+' AND VI.[Eclass_ID] LIKE '+CHAR(39)+@szEClassID+'%'+CHAR(39)
  IF @szInputmanclassID<>'' 
  	SET @SQLScript=@SQLScript+' AND VI.[Inputmanclass_ID] LIKE '+CHAR(39)+@szInputmanclassID+'%'+CHAR(39)
  IF @InvoiceNo<>'' 
  	SET @SQLScript=@SQLScript+' AND VI.[InvoiceNo] LIKE '+CHAR(39)+'%'+@InvoiceNo+'%'+CHAR(39)
  IF @InvoiceInput<>0 
  	SET @SQLScript=@SQLScript+' AND VI.[Invoiceinput]='+CAST(@InvoiceInput AS VARCHAR)
  IF @InvoiceAudit<>0 
  	SET @SQLScript=@SQLScript+' AND VI.[InvoiceAudit]='+CAST(@InvoiceAudit AS VARCHAR)
  IF @nInvoiceType<>0
  	SET @SQLScript=@SQLScript+' AND VI.[Invoice]='+CAST(@nInvoiceType AS VARCHAR)
  
  IF @nSaleOrBuy=0
  	SET @SQLScript=@SQLScript+' AND [Billtype] IN (10,11,15,16,17,18,20,21,23,24,25,28,32,35,112,122)'
  IF @nSaleOrBuy=1
  	SET @SQLScript=@SQLScript+' AND [Billtype] IN (10,11,16,17,18,32,112)'
  IF @nSaleOrBuy=2
  	SET @SQLScript=@SQLScript+' AND [Billtype] IN (20,21,24,25,28,35,122)'
  IF @nSaleOrBuy=3
  	SET @SQLScript=@SQLScript+' AND [Billtype] IN (15,23)'
  IF @nMode=0
  BEGIN
  	SET @SQLScript=@SQLScript+' AND VI.[Invoicetotal]<>0'
    IF @nBillORProduct = 1
    	SET @SQLScript=@SQLScript+' AND VI.[FlagIdx] in (5,4)'	
    IF @nBillORProduct = 2
	    SET @SQLScript=@SQLScript+' AND VI.[FlagIdx] in (0,1,2,3)'
  END
  IF @nMode=1
  BEGIN
  	SET @SQLScript=@SQLScript+' AND VI.[Invoicetotal]=0'
    IF @nBillORProduct = 1
    	SET @SQLScript=@SQLScript+' AND VI.[FlagIdx] IN (5,4) AND VI.[BillID] NOT IN
        (SELECT DISTINCT [BillID] FROM Invoice
         UNION ALL
         SELECT [BillID] FROM BillIDX WHERE Invoicetotal<>0
         UNION ALL
         SELECT [BillID] FROM BillIDX BI, SaleManageBill SM WHERE BI.[BillID]=SM.[Bill_ID] AND SM.Invoicetotal<>0
         UNION ALL
         SELECT [BillID] FROM BillIDX BI, BuyManageBill BM WHERE BI.[BillID]=BM.[Bill_ID] AND BM.Invoicetotal<>0
         )'
    IF @nBillORProduct IN (0,2)
	    SET @SQLScript=@SQLScript+' AND VI.[FlagIdx] IN (0,1,2,3) AND VI.[BillID] NOT IN
        (SELECT DISTINCT [BillID] FROM Invoice WHERE SMB_ID=0
         UNION ALL
         SELECT [BillID] FROM BillIDX WHERE Invoicetotal<>0
         ) AND  
        VI.[SMB_ID] NOT IN (SELECT IV.SMB_ID FROM INVOICE IV WHERE IV.BILLID=VI.BILLID AND IV.SMB_ID > 0) 
         '
  END 



  SET @SQLScript = @SQLScript + ' ORDER BY vi.Invoicedate desc, FlagIdx'
/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
