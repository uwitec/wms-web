create procedure E_ProductsCustomCategoryFx
  @y_id integer=0,     /*机构*/
  @stopcheckd integer=0,/*是否停用*/
  @CategoryGroupClassidOne    varchar(1000),/*选中类别组一 class_id*/
  @CategoryCheckOne           integer=0,/*选中大 1，中 2，小 3*/
  @CategoryOne_id             varchar(1000),/*选中的类别组ID号*/
  
  @CategoryGroupClassidTwo    varchar(1000),/*选中类别组二 class_id*/
  @CategoryCheckTwo           integer=0,/*选中大 1，中 2，小 3*/
  @CategoryTwo_id             varchar(1000),/*选中的类别组ID号*/
  
  @CategoryGroupClassidThree    varchar(1000),/*选中类别组三 class_id*/
  @CategoryCheckThree          integer=0,/*选中大 1，中 2，小 3*/
  @CategoryThree_id             varchar(1000)/*选中的类别组ID号*/
  
as 
Create Table #CategoryALL
  (
    RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
    CategoryId            INT     NULL DEFAULT(0), /*类ID*/
    CategoryClassId       varchar (100)    NULL DEFAULT(''),/*-类别ClassId*/
    CategoryName          varchar (100)    NULL DEFAULT(''),/*-类别名称*/
    ZPgNum                INT   NULL DEFAULT(0), /*总品规数*/
    GMl                   INT   NULL DEFAULT(0), /*配送单(制单人)*/
    ZML                   INT   NULL DEFAULT(0), /*-商品类别组名称*/
    DML                   INT   NULL DEFAULT(0), /*-机构类别名称*/
    FML                   INT   NULL DEFAULT(0), /*配送单目标机构         */
  )
create table #CategoryThree_id
(
  RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
  class_id              varchar (100)    NULL DEFAULT(''),
  id                    INT   NULL DEFAULT(0)
)
create table #CategoryTwo_id
(
  RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
  class_id              varchar (100)    NULL DEFAULT(''),
  id                    INT   NULL DEFAULT(0)
)
begin
  declare @LENone   int
  declare @LENTwo    int
  declare @LENThree    int
  declare @code int
  declare @swarajprice int /*独立物价*/
  declare @gid int
  declare @zid int
  declare @did int
  declare @fid int
  set @LENone = 0
  set @LENTwo = 0
  set @LENThree = 0
  set @code = 1
  set @swarajprice = 0 
  /*查找毛利区间表中的预估毛利区间取值 例如：1 ：零售价，2：预设售价1,3：预设售价2 .....*/
  select @code=code from 
  (
   select distinct code from mlRataRoom
  ) a
   /*通过所选择机构查询是否启用独立物价*/
  select @swarajprice=swarajPrice from company  where company_id=@y_id
  /*-处理类别组一*/
  if @CategoryCheckOne=3 
  begin
    if exists(select 1 from customCategory where class_id like @CategoryGroupClassidOne + '%' and LEN(class_id) = 8)
		SET @LENone=8
  end
  
  if  (@CategoryCheckOne=2) or (@LENone<>8)
  begin
       if exists(select 1 from customCategory where class_id like  @CategoryGroupClassidOne + '%' and LEN(class_id) = 6)
		SET @LENone=6
  end

  if  (@CategoryCheckOne=1) or (@LENone<>6 and @LENone<>8 )  
  begin
       if exists(select 1 from customCategory where class_id like  @CategoryGroupClassidOne  + '%' and LEN(class_id) = 4)
		SET @LENone=4
  end
 /*处理类别组一*/
  insert into #CategoryALL(CategoryId,CategoryName,CategoryClassId)
  select distinct a.id,a.name,a.class_id from customCategory a inner join
	  (
	   select a.id,isnull(b.baseinfo_id,'') as baseinfo_id,name,a.class_id from 
				 (select * from customCategory where deleted=0) a 
				 left join (select * from customCategoryMapping where deleted=0  and BaseTypeid=0) b on a.id=b.category_id                       
			   where a.deleted=0   and a.id in (select szTYPE from  dbo.DecodeToStr(@CategoryOne_id))
      )b  on  a.class_id LIKE b.class_id + '%' and len(a.class_id)=@LENone
  /*处理类别组一*/
   SELECT id  
   into #CategoryOne_id
    FROM customCategory x INNER JOIN 
       (    
          SELECT class_id 
            FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryOne_id))
       ) b  ON x.class_id LIKE b.class_id + '%' where x.Child_Number = 0 and x.deleted=0
   /*处理类别组二*/
   insert into  #CategoryTwo_id  
   SELECT class_id,id FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryTwo_id))
   /*处理类别组三*/
   insert into #CategoryThree_id(class_id,id)
   SELECT class_id,id   FROM  customCategory a
               where id in (select szTYPE from  dbo.DecodeToStr(@CategoryThree_id))
    /*-毛利区间高中低取值*/
    select  name,id, baseinfo_id,class_id,mlqj into #MLQJ  from 
    (
    select a.name,a.id, a.baseinfo_id as baseinfo_id,a.class_id,
			case  when @code=1 then  (isnull(retailprice,0)-isnull(i.taxprice,0))/nullif(retailprice,0)
	              when @code=2 then  (isnull(price1,0)-isnull(taxprice,0))/nullif(price1,0)
	              when @code=3 then  (isnull(price2,0)-isnull(taxprice,0))/nullif(price2,0)
	              when @code=4 then  (isnull(price3,0)-isnull(taxprice,0))/nullif(price3,0)
	              when @code=5 then  (isnull(price4,0)-isnull(taxprice,0))/nullif(price4,0)
	              when @code=6 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              when @code=7 then  (isnull(gpprice,0)-isnull(taxprice,0))/nullif(gpprice,0)
	              end as  mlqj   from 
			(
			  select a.name,a.id, b.baseinfo_id as baseinfo_id,retailprice,price1,price2,
			         price3,price4,gpprice ,glprice, a.class_id from 
						 (select * from customCategory where deleted=0 ) a 
						 left join (select * from customCategoryMapping where deleted=0 and BaseTypeid=0) b on a.id=b.category_id         
						 left join 
						 (
						     select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from price where unittype=1 and @swarajprice=0
	                         union all
	                         select retailprice,price1,price2,price3,price4,gpprice,glprice,p_id from PosPrice where unittype=1 and @swarajprice=1  and Y_ID=@y_id
						 ) d on b.baseinfo_id=d.p_id       
					   where a.deleted=0  and a.id in (select id from #CategoryOne_id)
			           
			)a left join 
			(
				select c.smb_id,c.p_id,b.taxprice from
				(
				select MAX(smb_id) smb_id,p_id from 
				buymanagebill where p_id>0 group by p_id 
				)c
				left join buymanagebill b on c.smb_id= b.smb_id
				left join billidx bx on b.bill_id= bx.billid and bx.billtype=20							
			 )i on a.baseinfo_id=i.p_id
	) d inner join (
						 select product_id,deleted  from products  where IsSplit=0 and deleted<>1
				   ) z on d.baseinfo_id=z.product_id
				   where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)/*是否停用*/
						 
    select * into #CategoryFind from #CategoryALL
    truncate table #CategoryALL
    insert into #CategoryALL(CategoryId,CategoryName,CategoryClassId,ZPgNum,GMl,ZML,DML,FML) 
    select CategoryId,CategoryName,CategoryClassId,isnull(y.zpgnum,0) as zpgnum
    ,isnull(e.gml,0) as gml,isnull(f.zml,0) as zml,isnull(h.dml,0) as dml,isnull(i.fml,0) as fml
    from 
	  (
	   select * from  #CategoryFind
      )x 
      left join
      (
        select SUM(zpgnum) as  zpgnum,left(class_id,@LENone) as class_id  from 
         (
		  select id,class_id,count(distinct(a.baseinfo_id)) as zpgnum from 
		  (
		   select id,class_id,baseinfo_id from 
		   (
		     select a.id,isnull(b.baseinfo_id,'') as baseinfo_id,name,class_id from 
					 (select * from customCategory where deleted=0) a 
					 left join (select * from customCategoryMapping where deleted=0  and BaseTypeid=0) b on a.id=b.category_id                    
				   where a.deleted=0   and a.id in (select id from  #CategoryOne_id) and baseinfo_id<>0
		   ) m 
		   inner join 
		   (
		     select product_id,deleted  from products
		   ) l  on m.baseinfo_id=l.product_id  where (@stopcheckd=0 ) or (@stopcheckd=1 and deleted<>4)/*是否停用*/
		  )a  group by id,class_id
		 ) r group by left(class_id,@LENone)
      )y on  x.CategoryClassId=class_id
      left join 
      (
       select SUM(gml) as gml,left(class_id,@LENone) as class_id from 
       (
        select count(distinct(baseinfo_id)) as gml,class_id,id  
		from #MLQJ
	    where  isnull(mlqj,0)>=(select minValue/100 from mlRataRoom where name='高')
		group by class_id,id 
	   ) r group by  left(class_id,@LENone)
      ) e on  x.CategoryClassId=e.class_id
      left join 
      (
         select SUM(zml) as zml,left(class_id,@LENone) as class_id from 
         (
			select count(distinct(baseinfo_id)) as zml,class_id,id  
			from  #MLQJ
			where  (select minValue/100 from mlRataRoom where name='中') <= mlqj 
						and isnull(mlqj,0)< (select maxValue/100 from mlRataRoom where name='中')
			group by class_id,id 
		 ) r group by  left(class_id,@LENone)
      ) f on  x.CategoryClassId=f.class_id
      left join 
      (
         select SUM(dml) as dml,left(class_id,@LENone) as class_id from 
         (
				select count(distinct(baseinfo_id)) as dml,class_id,id  
				from  #MLQJ 
				where (select minValue/100 from mlRataRoom where name='低')<=mlqj
					  and  isnull(mlqj,0)<(select maxValue/100 from mlRataRoom where name='低')
				group by class_id,id 
		 ) r group by  left(class_id,@LENone)
      ) h on  x.CategoryClassId=h.class_id
      left join 
      (
        select SUM(fml) as fml,left(class_id,@LENone) as class_id from 
        (
			select count(distinct(baseinfo_id)) as fml,class_id,id  
			from  #MLQJ
			where  mlqj<0/*负毛利*/
			group by class_id,id 
		) r group by  left(class_id,@LENone)
      ) i on  x.CategoryClassId=i.class_id
      
      select distinct b.baseinfo_id ,class_id into #tempThree from 
							   (
								select id,class_id from customCategory  where deleted=0 
							   ) a
							   inner join 
							   (
								select * from customCategoryMapping   where deleted=0 and BaseTypeid=0
							   )b on a.id=b.category_id
							   inner join 
							   (
									select product_id,deleted  from products  where IsSplit=0 and deleted<>1
							   ) z on b.baseinfo_id=z.product_id
									 where (@stopcheckd=0 ) or (@stopcheckd=1 and z.deleted<>4)
   /*处理类别组二*/
   /*动态添加零时表中的列根据选择的类别组*/
    declare @IdOne int
    declare @CategoryClassId varchar(1000)
    declare @sql  varchar(1000)
    declare @colnameOne varchar(1000)
    declare @rowssumFour int
    declare @currentidxFour  int
    select  @currentidxFour=1
    select @rowssumFour=count(*) from #CategoryTwo_id
	 while @currentidxFour<=@rowssumFour
	 begin
	    select @IdOne=id,@CategoryClassId=class_id from #CategoryTwo_id where  RecId=@currentidxFour
	    if @IdOne <> 0
	    begin
	        set @colnameOne ='n2_'+cast(@IdOne as varchar)
		    set @sql =' ALTER TABLE #CategoryALL Add ['+@colnameOne+'] int not NULL default(0) '  
		    exec (@sql)
		    /*-添加一列之后循环零时表中的行，循环修改零时表当前列的每一行品规数的值*/
				declare @nameT varchar(1000)
				declare @RecIdTwo varchar(100)
				declare @CategoryClassIdT varchar(1000)
				declare @str   varchar(8000)
				declare @rwosum int
				declare @currentidx int
			    set @currentidx=1
			    select @rwosum =COUNT(*)  from #CategoryALL
			    while @currentidx<=@rwosum
			    begin
			       select @CategoryClassIdT = CategoryClassId,@RecIdTwo=RecId from #CategoryALL where RecId=@currentidx
			       set @str='
			      update #CategoryALL set '+@colnameOne+'=
			      (
			        select COUNT(distinct a.baseinfo_id) as pgqty from 
			        (
			          select  distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassId+'''+''%'' 
			        ) a inner join 
			        (
			           select distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdT+'''+''%'' 
			        ) b on a.baseinfo_id=b.baseinfo_id
			       ) where RecId='''+@RecIdTwo+''' '
					exec (@str)
					set @currentidx=@currentidx+1
		     end     
		 end	
		set @currentidxFour=@currentidxFour+1	    
    end 
   
   
    /*-处理类别组三  */
    /*动态添加零时表中的列根据选择的类别组*/
		declare @IdThree int
		declare @CategoryClassIdThree varchar(1000)
		declare @sqlThree  varchar(1000)
		declare @colnameThree varchar(1000)
		declare @rowssumThree int
		declare @currentidxthree int			  
       select @currentidxthree=1
       select @rowssumThree=COUNT(*) from #CategoryThree_id  
       while @currentidxthree<=@rowssumThree
	   begin
	     select @IdThree=id,@CategoryClassIdThree=class_id from #CategoryThree_id where  RecId=@currentidxthree
	     if @IdThree <>0
	     begin
	        set @colnameThree ='n3_'+cast(@IdThree as varchar)
		    set @sqlThree =' ALTER TABLE #CategoryALL Add ['+@colnameThree+'] int not NULL default(0) '  
		    exec (@sqlThree)
		    declare @nameThreeT varchar(1000)
			declare @CategoryClassIdThreeT varchar(1000)
			declare @strThree   varchar(8000)
			declare @CurcustormThreeT cursor
			declare @RecIdThree      varchar(100)
			declare @rwosumtwo int
			declare @currentidxtwo int
		    set @currentidxtwo=1
		    select @rwosumtwo =COUNT(*)  from #CategoryALL
			while @currentidxtwo<=@rwosumtwo
		    begin
			      select @CategoryClassIdThreeT = CategoryClassId,@RecIdThree=RecId from #CategoryALL where RecId=@currentidxtwo
			      set @strThree='
			      update #CategoryALL set '+@colnameThree+'=
			      (
			        select COUNT(distinct a.baseinfo_id) as pgqty from 
			        (
			          select   distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdThree+'''+''%'' 
			        ) a inner join 
			        (
			           select  distinct baseinfo_id from #tempThree where class_id like '''+@CategoryClassIdThreeT+'''+''%'' 
			        ) b on a.baseinfo_id=b.baseinfo_id
			       )  where RecId='''+@RecIdThree+''' '
					exec (@strThree)
					set @currentidxtwo=@currentidxtwo+1
		     end    
	   end	
      set @currentidxthree=@currentidxthree+1     
    end  
   select * from #CategoryALL 
   drop table  #tempThree
   drop table  #CategoryALL
   drop table  #CategoryOne_id
   drop table  #CategoryTwo_id
   drop table  #CategoryThree_id
   drop table  #CategoryFind
   drop table  #MLQJ
end

/*exec E_ProductsCustomCategoryFx 2,0,'01',3,'3,11,33,34,35,36,37,38,39,40,41,42,12,43,44,45,46,47,48,49,50,51,13,52,53,54,55,14,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,16,72,73,74,75,76,77,78,79,17,80,81,82,83,84,85,18,86,87,88,89,90,91,92,93,19,94,95,96,97,98,20,99,100,101,102,21,103,104,105,106,22,107,108,109,110,111,23,112,113,24,114,115,116,117,118,119,25,120,121,122,123,124,26,125,126,127,128,129,130,27,131,132,28,133,134,135,136,29,137,138,139,140,141,142,143,30,144,145,146,147,148,149,150,151,152,31,32,4,153,174,175,176,177,178,179,180,181,182,183,154,184,185,186,187,188,189,190,191,192,155,193,194,195,196,156,197,198,199,200,157,201,202,203,204,205,206,207,208,209,210,211,212,158,213,214,215,216,217,218,219,220,159,221,222,223,224,225,226,160,227,228,229,230,231,232,233,234,161,235,236,237,238,239,162,240,241,242,243,163,244,245,246,247,164,248,249,250,251,252,165,253,254,166,255,256,257,258,259,260,167,261,262,263,264,265,168,266,267,268,269,270,271,169,272,273,170,274,275,276,277,171,278,279,280,281,282,283,284,172,285,286,287,288,289,290,291,292,293,173,294,5,295,300,301,302,303,304,305,306,307,308,309,296,310,311,297,312,313,298,314,315,316,317,318,299,319,6,320,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,321,349,350,7,15,351,355,356,357,358,359,360,361,362,363,364,365,366,367,368,352,369,370,371,372,373,374,375,376,353,377,378,379,380,381,354,382,383,384,385,8,386,391,392,393,394,387,395,396,397,398,399,400,388,401,389,402,403,404,390,405,9,406,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,407,437,438,408,439,440,441,442,443,444,10,445,448,449,450,451,446,452,453,454,455,447,456,457,458,459,460,461,462,463,464','02',3,'466,467,468,469,470,471,473,475,476,477,478,655','03',3,'480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,634,635,636'*/
GO
