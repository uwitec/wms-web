
CREATE PROCEDURE [dbo].[TS_j_QrZeroStockIDX]
(	@Begindate      DATETIME='',
	@EndDate		DATETIME='',
	@nC_ID			INT=0,
	@nE_ID			INT=0,
    @nInputman              INT=0,  
    @nY_ID                  INT=0,
    @nLoginEid              INT=0
)
AS
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = ''
if @EndDate is null  SET @EndDate = ''
if @nC_ID is null  SET @nC_ID = 0
if @nE_ID is null  SET @nE_ID = 0
if @nInputman is null  SET @nInputman = 0
if @nY_ID is null  SET @nY_ID = 0
if @nLoginEid is null  SET @nLoginEid = 0
/*Params Ini end*/
SET NOCOUNT ON
 
 
    SELECT 
          B.*, [Billname]='商品缺货单', isnull(c.name, '') as cname,		 
		  isnull(e.[name], '')          AS [Employeename],
		  isnull(eaudit.[name], '')   AS [auditmanname],
		  isnull(eInput.[name], '')   AS [Inputmanname],
		  isnull(d.[name], '') AS [Departmentname],
		  isnull(r.[name], '')     AS [Regionname],
		  cast(0 as numeric(25,8)) as comeqty, cast(0 as numeric(25,8)) as UnComeQty, 
		  cast(0 as numeric(25,8)) as ysmoney, cast(0 as numeric(25,8)) as ssmoney, 
		  cast(0 as numeric(8,2)) as taxrate, ' 'as accountname,0 as serialno
		  
    from zerostockidx b
    left join clients c on b.c_id = c.client_id
    left join employees e on b.e_id = e.emp_id 
    left join employees eaudit on b.auditman = eaudit.emp_id
    left join employees einput on b.inputman=einput.emp_id
    left join company y on b.y_id = y.company_id
    left join department d on b.department_id = d.departmentId
    left join Region r on b.region_id = r.region_id
    where 
      b.billdate between @Begindate and @EndDate and
      (@nC_ID = 0 or b.c_id = @nC_ID) and
      (@nE_ID = 0 or b.e_id = @ne_ID) and
      (@nInputman = 0 or b.Inputman = @nInputman) and
      (@nY_ID = 0 or b.Y_ID = @nY_ID)
          
  RETURN 0
GO
