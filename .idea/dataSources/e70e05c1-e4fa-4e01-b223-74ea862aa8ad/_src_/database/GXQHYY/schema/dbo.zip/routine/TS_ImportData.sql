
CREATE    PROCEDURE [dbo].[TS_ImportData]
  @TableName varchar(100),
  @FileName varchar(1000)
  
AS
begin
/*
BULK INSERT @TableName FROM @FileName
WITH (
   DATAFILETYPE = 'char',
   FIELDTERMINATOR = ',',
   ROWTERMINATOR = '\n'
)
*/
  declare @Begin varchar(100),
          @End varchar(100),
          @Del varchar(100),
          @Insert varchar(500),
          @Sql varchar(1000)
  begin tran
  set @Begin=''
  set @End='' 
  /*if columnproperty(object_id(@Table),@TableKey,'IsIdentity')=1*/
  /*begin*/
  /*  set @Begin = ' SET IDENTITY_INSERT ' + @Table + ' ON ' */
  /*  set @End   = ' SET IDENTITY_INSERT ' + @Table + ' OFF '*/
  /*end  */
  set @Del = ' truncate table '+ @TableName
  set @Insert = ' BULK INSERT ' + @TableName + ' from ''' + @FileName + ''' ' + ' WITH (KEEPIDENTITY) '
  set @Sql = @begin + @Del + @Insert + @End
  /*set @Sql = @Del + @Insert*/

  print @Sql
  Exec(@Sql)
  if @@error = 0
    commit tran
  else 
    rollback tran

end
GO
