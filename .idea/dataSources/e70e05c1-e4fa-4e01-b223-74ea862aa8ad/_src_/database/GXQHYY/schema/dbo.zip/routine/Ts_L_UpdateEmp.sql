











CREATE	 PROCEDURE [Ts_L_UpdateEmp]
	(@emp_id	[int],
	 @name	[varchar](80),
	 @alias 	[varchar](30),
	 @serial_number 	[varchar](26),
	 @dep_id	[int],
	 @phone 	[varchar](60),
	 @address	[varchar](66),
	 @comment	[varchar](256),
	 @aplimit	numeric(25,8),
	 @arlimit	numeric(25,8),
	 @discountlimit 	[numeric](3,2),
	 @pinyin	[varchar](80),
	 @LowPrice	[numeric](5,4),
	 @HighPrice	[numeric](5,4),
	 @Duty		varchar(20),
	 @Study	varchar(20),
	 @GraduateDate Datetime,
	 @Teach	Varchar(20),
	 @szWork	varchar(20),
	 @inDate	Datetime,
	 @Tp_ID  	int,
	 @CertNo	varchar(50),
	 @IdCard	Varchar(20),
         @Deduct        numeric(8,4),
         @Y_id          int,
     @GradeId	int
)

AS 
if exists(select 1 from employees where serial_number=@serial_number and [emp_id]<> @emp_id and deleted =0)
begin
	RAISERROR('编号重复！不允许修改！！',16,1)
	return -2
end

if exists(select 1 from employees where name=@name  and [emp_id]<> @emp_id and deleted =0)
begin
 RAISERROR('名称重复！不能添加！！',16,1)
 return -2
end


UPDATE [employees] 

SET		 [name]  = @name,
	 [alias]	 = @alias,
	 [serial_number]	 = @serial_number,
	 [dep_id]	 = @dep_id,
	 [phone]	 = @phone,
	 [address]	 = @address,
	 [comment]	 = @comment,
	 [aplimit]	 = @aplimit,
	 [arlimit]	 	 = @arlimit,
	 [discountlimit]	 = @discountlimit,
	 [pinyin]	 	 = @pinyin,
	 [LowPrice]	=@LowPrice,
	 [HighPrice]	=@HighPrice,
	 duty		=@Duty,
	 study		=@Study,
	 graduatedate	=@GraduateDate ,
	 Teach		=@Teach,
	 szWork	=@szWork,
	 inDate		=@inDate,
	/* Tp_ID		=@Tp_ID,  提成公式设置转移到单独模块*/
	 [IdCard]	=@idCard,
	 [CertNo]	=@CertNo,
         [Deduct]       =@Deduct,
         Y_id           =@Y_id,
     [GradeId] = @GradeId
WHERE 
	( [emp_id]	 = @emp_id)
GO
