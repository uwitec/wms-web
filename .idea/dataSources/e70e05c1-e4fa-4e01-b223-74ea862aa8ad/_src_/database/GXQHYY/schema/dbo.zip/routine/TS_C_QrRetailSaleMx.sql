

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

--0 销售批次明细表
--1 销售退货批次明细表
--2 处方药明细 zhh add

********************************************/
CREATE PROCEDURE TS_C_QrRetailSaleMx
(	@BeginDate 	DATETIME,
	@EndDate	  DATETIME,
	@nE_id		  INT,
	@nInputMan  INT,
	@nLocation_id	INT,
	@nSortType    INT=0,
    @szOTCcomment     varchar(100)='',
    @nYClassid        varchar(100)='',
    @nloginEID        int=0,
    @nPubPosDataMode  int,  /*0 实时账套、1 独立账套、2 离线账套*/
    @bPubOffLine      int   /*分支机构启用离线*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nSortType is null  SET @nSortType = 0
if @szOTCcomment is null  SET @szOTCcomment = ''
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
  SET NOCOUNT ON
  DECLARE @SQLScript VARCHAR(8000)
  Declare @Companytable INTEGER,@employeestable integer

  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

  IF @nSortType=0 GOTO pSaleMx 	/*销售清单*/
  IF @nSortType=1 GOTO pSaleBackMx/*销售退货清单*/
  IF @nSortType=2 GOTO pOTCSaleMx/*销售处方药清单 zhh add*/

RETURN 0

pSaleMx:
BEGIN
  IF (@nPubPosDataMode<>2) or (@bPubOffLine=1)
  BEGIN
    SELECT 
	CASE WHEN (GROUPING(vs.p_id) = 1) then -1
	            ELSE ISNULL(vs.p_id, 'unknow')
	       end as p_id,
	CASE WHEN (GROUPING(vs.batchno) = 1) then '-1'
	            ELSE ISNULL(vs.batchno, 'unknow')
	       END AS batchno,
	CASE WHEN (GROUPING(vs.location_id) = 1) then -1
	            ELSE ISNULL(vs.location_id, 'unknow')
	       END AS location_id,
	MAX(p.code) AS code,
	MAX(p.[name]) AS pname,
	MAX(p.standard) AS standard,
	MAX(p.makearea) AS makearea,
	MAX(p.unitname1) AS unitname1,
	MAX(p.medtype) AS medtype,
	MAX(p.permitcode) AS permitcode,
	MAX(p.Custompro1) AS Custompro1, 
	MAX(p.Custompro2) AS Custompro2, 
	MAX(p.Custompro3) AS Custompro3, 
	MAX(p.Custompro4) AS Custompro4, 
	MAX(p.Custompro5) AS Custompro5, 
	MAX(vs.validdate) AS validdate,
	MAX(isnull(u.name,'')) AS unitname,
	/*MAX(vs.taxprice) AS taxprice,*/
    dbo.Decimalbits(4,MAX(vs.taxprice))AS taxprice,  /*含税单价*/
	MAX(vs.taxrate*100) AS taxrate,
	MAX(isnull(l.loc_name,'')) AS locname,
	SUM(CASE vb.billtype WHEN 12 THEN vs.quantity ELSE 0 END) AS salequantity,
	SUM(CASE vb.billtype WHEN 12 THEN vs.taxtotal ELSE 0 END) AS saletotal,
	SUM(CASE vb.billtype WHEN 13 THEN vs.quantity ELSE 0 END) AS salebackquantity,
	SUM(CASE vb.billtype WHEN 13 THEN vs.taxtotal ELSE 0 END) AS salebacktotal,
	dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END) ) AS saleprice,
	dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END)) AS backsaleprice,
	/*cast(AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) as numeric(25,8)) AS discountprice,*/
	dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) ) AS discountprice,
	dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END)) AS backdiscountprice,
	dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 12 THEN vs.total-(vs.total*discount) ELSE 0 END)) AS discounttotal,
	dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 13 THEN vs.total-(vs.total*discount) ELSE 0 END)) AS backdiscounttotal,
    dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 12 THEN vs.retailtotal ELSE -vs.retailtotal  END)) AS retailtotal
    FROM Retailbill vs 
      LEFT JOIN unit          u   ON vs.unitid = u.unit_id
      LEFT JOIN location      l   ON vs.location_id = l.loc_id
      LEFT JOIN Retailbillidx vb  ON vs.bill_id=vb.billid 
      LEFT JOIN Company       Y   ON Y.Company_id=vb.Y_id
      LEFT JOIN vw_c_products p   ON p.product_id=vs.p_id
    WHERE vb.billtype in (12,13) AND vb.billstates='0' and vs.p_id>0 and aoid in (0,5)
       and (@nYClassid='' or Y.Class_id like @nYClassid+'%')
       AND (vb.billdate between @BeginDate and @EndDate)
       AND (@nE_id=0 or vs.rowe_id=@nE_id)
       AND (@nInputMan=0 or vb.inputman=@nInputMan)
       AND (@nLocation_id=0 OR  vs.location_id=@nLocation_id)
       AND ((@employeestable=0) OR (vs.RowE_id in (select [id] from #employeestable)))
       AND ((@Companytable=0)or (vb.Y_id in (select [id] from #Companytable))) 
    GROUP BY vs.p_id,vs.location_id,vs.batchno with rollup
   END ELSE
   BEGIN
		SELECT 
		CASE WHEN (GROUPING(vs.p_id) = 1) then -1
					ELSE ISNULL(vs.p_id, 'unknow')
			   end as p_id,
		CASE WHEN (GROUPING(vs.batchno) = 1) then '-1'
					ELSE ISNULL(vs.batchno, 'unknow')
			   END AS batchno,
		CASE WHEN (GROUPING(vs.location_id) = 1) then -1
					ELSE ISNULL(vs.location_id, 'unknow')
			   END AS location_id,
		MAX(p.code) AS code,
		MAX(p.[name]) AS pname,
		MAX(p.standard) AS standard,
		MAX(p.makearea) AS makearea,
		MAX(p.unitname1) AS unitname1,
		MAX(p.medtype) AS medtype,
		MAX(p.permitcode) AS permitcode,
		MAX(p.Custompro1) AS Custompro1, 
		MAX(p.Custompro2) AS Custompro2, 
		MAX(p.Custompro3) AS Custompro3, 
		MAX(p.Custompro4) AS Custompro4, 
		MAX(p.Custompro5) AS Custompro5, 
		MAX(vs.validdate) AS validdate,
		MAX(isnull(u.name,'')) AS unitname,
		/*MAX(vs.taxprice) AS taxprice,*/
		dbo.Decimalbits(4,MAX(vs.taxprice))AS taxprice,  /*含税单价*/
		MAX(vs.taxrate*100) AS taxrate,
		MAX(isnull(l.loc_name,'')) AS locname,
		SUM(CASE vb.billtype WHEN 12 THEN vs.quantity ELSE 0 END) AS salequantity,
		/*SUM(CASE vb.billtype WHEN 12 THEN vs.taxtotal ELSE 0 END) AS saletotal,*/
		dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 12 THEN vs.taxtotal ELSE 0 END)) AS saletotal,
		SUM(CASE vb.billtype WHEN 13 THEN vs.quantity ELSE 0 END) AS salebackquantity,
		/*SUM(CASE vb.billtype WHEN 13 THEN vs.taxtotal ELSE 0 END) AS salebacktotal,*/
		dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 13 THEN vs.taxtotal ELSE 0 END)) AS salebacktotal,
		/*cast(AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END) as numeric(25,8)) AS saleprice,*/
		/*cast(AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END) as numeric(25,8)) AS backsaleprice,*/
		/*cast(AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) as numeric(25,8)) AS discountprice,*/
		/*cast(AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) as numeric(25,8)) AS backdiscountprice,*/
		
		dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END))  AS saleprice,
		dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total/vs.quantity ELSE 0 END))  AS backsaleprice,
		dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=12 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) ) AS discountprice,
		dbo.Decimalbits(2,AVG(CASE WHEN vb.billtype=13 AND  vs.quantity<>0 THEN vs.total*discount/vs.quantity ELSE 0 END) ) AS backdiscountprice,		
		/*SUM(CASE vb.billtype WHEN 12 THEN vs.total-(vs.total*discount) ELSE 0 END) AS discounttotal,*/
		/*SUM(CASE vb.billtype WHEN 13 THEN vs.total-(vs.total*discount) ELSE 0 END) AS backdiscounttotal,*/
		/*SUM(CASE vb.billtype WHEN 12 THEN vs.retailtotal ELSE -vs.retailtotal  END) AS retailtotal*/
		dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 12 THEN vs.total-(vs.total*discount) ELSE 0 END)) AS discounttotal,
		dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 13 THEN vs.total-(vs.total*discount) ELSE 0 END)) AS backdiscounttotal,
		dbo.Decimalbits(3,SUM(CASE vb.billtype WHEN 12 THEN vs.retailtotal ELSE -vs.retailtotal  END)) AS retailtotal
		FROM salemanagebill vs 
		  LEFT JOIN unit          u   ON vs.unitid = u.unit_id
		  LEFT JOIN location      l   ON vs.location_id = l.loc_id
		  LEFT JOIN billidx       vb  ON vs.bill_id=vb.billid 
		  LEFT JOIN Company       Y   ON Y.Company_id=vb.Y_id
		  LEFT JOIN vw_c_products p   ON p.product_id=vs.p_id
		WHERE vb.billtype in (12,13) AND vb.billstates='0' and vs.p_id>0 and aoid in (0,5)
		   and (@nYClassid='' or Y.Class_id like @nYClassid+'%')
		   AND (vb.billdate between @BeginDate and @EndDate)
		   AND (@nE_id=0 or vs.rowe_id=@nE_id)
		   AND (@nInputMan=0 or vb.inputman=@nInputMan)
		   AND (@nLocation_id=0 OR  vs.location_id=@nLocation_id)
		   AND ((@employeestable=0) OR (vs.RowE_id in (select [id] from #employeestable)))
		   AND ((@Companytable=0)or (vb.Y_id in (select [id] from #Companytable))) 
	    GROUP BY vs.p_id,vs.location_id,vs.batchno with rollup 
	   
   END
	
   RETURN 0
END

pSaleBackMx:
BEGIN

/*	select 
	case when (grouping(vs.smb_id) = 1) then 0
	            else isnull(vs.smb_id, 'unknow')
	       end as smb_id,
	case when (grouping(vs.bill_id) = 1) then 0
	            else isnull(vs.bill_id, 'unknow')
	       end as billid,
	max(vb.billdate) as billdate,
	max(vb.billnumber) as billnumber,
	max(p.code) as code,
	max(p.[name]) as pname,
	max(p.standard) as standard,
	max(p.makearea) as makearea,
	max(vb.ename) as ename,
	max(vb.billtype) as billtype,
	max(vb.inputman) as inputman,
	max(vb.auditman) as auditman,
	max(vs.validdate) as validdate,
	max(vs.batchno) as batchno,
	max(vs.unitname) as unitname,
	sum(vs.quantity) as quantity,
	max(vs.taxrate*100) as taxrate,
	max(vs.taxprice) as taxprice,
	sum(vs.taxtotal) as taxtotal

	from vw_c_buymb vs left join vw_c_billidx vb
	on vs.bill_id=vb.billid
	left join vw_c_products p
	on p.product_id=vs.p_id
	where (vb.billdate between @BeginDate and @EndDate) and vb.billtype＝13 and vb.billstates='0' 
	and vb.cclass_id like @szCClass_id 
	group by vs.bill_id,vs.smb_id with rollup
	order by vb.billdate

*/	
  RETURN 0
END

pOTCSaleMx:
BEGIN
  IF (@nPubPosDataMode<>2) or (@bPubOffLine=1)
  BEGIN
    SELECT 
	CASE WHEN (GROUPING(vs.p_id) = 1) then -1
	            ELSE ISNULL(vs.p_id, 'unknow')
	       end as p_id,
	CASE WHEN (GROUPING(vs.batchno) = 1) then '-1'
	            ELSE ISNULL(vs.batchno, 'unknow')
	       END AS batchno,
	CASE WHEN (GROUPING(vs.location_id) = 1) then -1
	            ELSE ISNULL(vs.location_id, 'unknow')
	       END AS location_id,
	MAX(p.code) AS code,
	MAX(p.[name]) AS pname,
	MAX(p.standard) AS standard,
	MAX(p.makearea) AS makearea,
	MAX(p.unitname1) AS unitname1,
	MAX(p.medtype) AS medtype,
	MAX(p.permitcode) AS permitcode,
	MAX(p.Custompro1) AS Custompro1, 
	MAX(p.Custompro2) AS Custompro2, 
	MAX(p.Custompro3) AS Custompro3, 
	MAX(p.Custompro4) AS Custompro4, 
	MAX(p.Custompro5) AS Custompro5, 
	MAX(vs.validdate) AS validdate,
	MAX(isnull(u.name,'')) AS unitname,
	MAX(vs.taxprice) AS taxprice,
	MAX(vs.taxrate*100) AS taxrate,
	MAX(isnull(l.loc_name,'')) AS locname,
        MAX(vs.comment) AS OTCcomment,
	SUM(CASE vb.billtype WHEN 12 THEN vs.quantity ELSE 0 END) AS salequantity,
	SUM(CASE vb.billtype WHEN 12 THEN vs.taxtotal ELSE 0 END) AS saletotal,
	SUM(CASE vb.billtype WHEN 13 THEN vs.quantity ELSE 0 END) AS salebackquantity,
	SUM(CASE vb.billtype WHEN 13 THEN vs.taxtotal ELSE 0 END) AS salebacktotal,
	SUM(CASE vb.billtype WHEN 12 THEN vs.saleprice ELSE 0 END) AS saleprice,
	SUM(CASE vb.billtype WHEN 13 THEN vs.saleprice ELSE 0 END) AS backsaleprice,
	SUM(CASE vb.billtype WHEN 12 THEN vs.discountprice ELSE 0 END) AS discountprice,
	SUM(CASE vb.billtype WHEN 13 THEN vs.discountprice ELSE 0 END) AS backdiscountprice,
	SUM(CASE vb.billtype WHEN 12 THEN vs.quantity*(vs.saleprice-vs.discountprice) ELSE 0 END) AS discounttotal,
	SUM(CASE vb.billtype WHEN 13 THEN vs.quantity*(vs.saleprice-vs.discountprice) ELSE 0 END) AS backdiscounttotal,
        SUM(CASE vb.billtype WHEN 12 THEN vs.retailtotal ELSE -vs.retailtotal  END ) AS retailtotal
    FROM Retailbill vs 
      LEFT JOIN unit          u   ON vs.unitid = u.unit_id
      LEFT JOIN location      l   ON vs.location_id = l.loc_id
      LEFT JOIN Retailbillidx vb  ON vs.bill_id=vb.billid   
      LEFT JOIN Company       Y   ON Y.Company_id=vb.Y_id
      LEFT JOIN vw_c_products p   ON p.product_id=vs.p_id
    WHERE vb.billtype in (12,13) AND vb.billstates='0' and p.otcflag=1 and vs.[P_ID]>0
      AND (vb.billdate between @BeginDate and @EndDate )
      and (@szOTCcomment='' or vs.comment like @szOTCcomment+'%')
      and (@nE_id=0 or  vb.e_id=@nE_id)
      and (@nInputMan=0 or vb.inputman=@nInputMan+'%')
      and (@nLocation_id=0 or vs.location_id=@nLocation_id)
      and (@nYClassid='' or Y.Class_id like @nYClassid+'%')
      AND ((@employeestable=0) OR (vs.RowE_id in (select [id] from #employeestable)))
      AND ((@Companytable=0)or (vb.Y_id in (select [id] from #Companytable)))
      GROUP BY vs.p_id,vs.location_id,vs.batchno with rollup
  END ELSE
  BEGIN
    
	    SELECT 
		CASE WHEN (GROUPING(vs.p_id) = 1) then -1
					ELSE ISNULL(vs.p_id, 'unknow')
			   end as p_id,
		CASE WHEN (GROUPING(vs.batchno) = 1) then '-1'
					ELSE ISNULL(vs.batchno, 'unknow')
			   END AS batchno,
		CASE WHEN (GROUPING(vs.location_id) = 1) then -1
					ELSE ISNULL(vs.location_id, 'unknow')
			   END AS location_id,
		MAX(p.code) AS code,
		MAX(p.[name]) AS pname,
		MAX(p.standard) AS standard,
		MAX(p.makearea) AS makearea,
		MAX(p.unitname1) AS unitname1,
		MAX(p.medtype) AS medtype,
		MAX(p.permitcode) AS permitcode,
		MAX(p.Custompro1) AS Custompro1, 
		MAX(p.Custompro2) AS Custompro2, 
		MAX(p.Custompro3) AS Custompro3, 
		MAX(p.Custompro4) AS Custompro4, 
		MAX(p.Custompro5) AS Custompro5, 
		MAX(vs.validdate) AS validdate,
		MAX(isnull(u.name,'')) AS unitname,
		MAX(vs.taxprice) AS taxprice,
		MAX(vs.taxrate*100) AS taxrate,
		MAX(isnull(l.loc_name,'')) AS locname,
			MAX(vs.comment) AS OTCcomment,
		SUM(CASE vb.billtype WHEN 12 THEN vs.quantity ELSE 0 END) AS salequantity,
		SUM(CASE vb.billtype WHEN 12 THEN vs.taxtotal ELSE 0 END) AS saletotal,
		SUM(CASE vb.billtype WHEN 13 THEN vs.quantity ELSE 0 END) AS salebackquantity,
		SUM(CASE vb.billtype WHEN 13 THEN vs.taxtotal ELSE 0 END) AS salebacktotal,
		SUM(CASE vb.billtype WHEN 12 THEN vs.saleprice ELSE 0 END) AS saleprice,
		SUM(CASE vb.billtype WHEN 13 THEN vs.saleprice ELSE 0 END) AS backsaleprice,
		SUM(CASE vb.billtype WHEN 12 THEN vs.discountprice ELSE 0 END) AS discountprice,
		SUM(CASE vb.billtype WHEN 13 THEN vs.discountprice ELSE 0 END) AS backdiscountprice,
		SUM(CASE vb.billtype WHEN 12 THEN vs.quantity*(vs.saleprice-vs.discountprice) ELSE 0 END) AS discounttotal,
		SUM(CASE vb.billtype WHEN 13 THEN vs.quantity*(vs.saleprice-vs.discountprice) ELSE 0 END) AS backdiscounttotal,
			SUM(CASE vb.billtype WHEN 12 THEN vs.retailtotal ELSE -vs.retailtotal  END ) AS retailtotal
		FROM salemanagebill vs 
		  LEFT JOIN unit          u   ON vs.unitid = u.unit_id
		  LEFT JOIN location      l   ON vs.location_id = l.loc_id
		  LEFT JOIN billidx vb  ON vs.bill_id=vb.billid   
		  LEFT JOIN Company       Y   ON Y.Company_id=vb.Y_id
		  LEFT JOIN vw_c_products p   ON p.product_id=vs.p_id
		WHERE vb.billtype in (12,13) AND vb.billstates='0' and p.otcflag=1 and vs.[P_ID]>0
		  AND (vb.Retaildate between @BeginDate and @EndDate )
		  and (@szOTCcomment='' or vs.comment like @szOTCcomment+'%')
		  and (@nE_id=0 or  vb.e_id=@nE_id)
		  and (@nInputMan=0 or vb.inputman=@nInputMan+'%')
		  and (@nLocation_id=0 or vs.location_id=@nLocation_id)
		  and (@nYClassid='' or Y.Class_id like @nYClassid+'%')
		  AND ((@employeestable=0) OR (vs.RowE_id in (select [id] from #employeestable)))
		  AND ((@Companytable=0)or (vb.Y_id in (select [id] from #Companytable)))
		  GROUP BY vs.p_id,vs.location_id,vs.batchno with rollup 
	
   END
   
  RETURN 0
END
GO
