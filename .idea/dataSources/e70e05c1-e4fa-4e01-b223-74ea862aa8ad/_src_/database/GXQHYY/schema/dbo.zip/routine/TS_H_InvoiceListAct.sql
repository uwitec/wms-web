
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-1-9*/
/* Description:	发票清单操作*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_InvoiceListAct] 
	@Act int,			/* 操作 0: 编辑 1: 查询*/
	@InvoiceID int,		/* 发票单ID*/
	@PID int = 0,
	@UID int = 0,
	@QTY numeric(25,8) = 0,
	@Price numeric(25,8) = 0,
	@Total numeric(25,8) = 0,
	@TaxRate numeric(25,8) = 0,
	@TaxMoney numeric(25,8) = 0,
	@Comment varchar(80) = ''
AS
BEGIN
	SET NOCOUNT ON;

	if @Act = 0
	begin
		insert into invoiceList(invoice_id, p_id, unit_id, qty, price, total, taxrate, taxmoney, comment)
		values(@InvoiceID, @PID, @UID, @QTY, @Price, @Total, @TaxRate, @TaxMoney, @Comment)
	end
	else
	if @Act = 1
	begin
		SELECT     i.id, i.invoice_id, i.p_id, i.unit_id, i.qty, i.price, i.total, i.taxrate, i.taxmoney, i.comment, p.name AS pname, u.name AS uname, p.serial_number, p.alias, 
							  p.standard, p.makearea, ISNULL(u1.name, ' ') AS uname1, ISNULL(u2.name, ' ') AS uname2, ISNULL(u3.name, ' ') AS uname3, ISNULL(u4.name, ' ') 
							  AS uname4, p.unit1_id, p.unit2_id, p.unit3_id, p.unit4_id, p.rate2, p.rate3, p.rate4
		FROM         dbo.invoiceList AS i INNER JOIN
							  dbo.unit AS u ON i.unit_id = u.unit_id INNER JOIN
							  dbo.products AS p ON i.p_id = p.product_id LEFT OUTER JOIN
							  dbo.unit AS u4 ON p.unit4_id = u4.unit_id LEFT OUTER JOIN
							  dbo.unit AS u2 ON p.unit2_id = u2.unit_id LEFT OUTER JOIN
							  dbo.unit AS u3 ON p.unit3_id = u3.unit_id LEFT OUTER JOIN
							  dbo.unit AS u1 ON p.unit1_id = u1.unit_id
		where i.invoice_id = @InvoiceID
	end
END
GO
