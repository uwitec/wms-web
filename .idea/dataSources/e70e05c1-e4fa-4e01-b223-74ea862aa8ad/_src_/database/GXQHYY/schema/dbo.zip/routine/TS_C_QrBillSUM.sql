




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
单据统计查询
最后的修改日期 2003-11-26
@szParid		  父类的ID号
@nC_ID			  仓库ID号
@szPeriod		  '0' 期初 ‘’当前
@szListFlag	  显示方式 A：全部列表 P：部分列表 L: 分级显示
@nCommissiON  3 借进 4 借出
********************************************/
CREATE PROCEDURE TS_C_QrBillSUM
(   @BeginDate  DATETIME,
	@EndDate		DATETIME,
	@nBillType  INT=0,
	@nC_id			INT=0,
	@nE_id			INT=0,
	@nSs_id			INT=0,
	@nSd_id			INT=0,
	@szParid   	    VARCHAR(30)='000000',
	@szListFlag     CHAR(1)='L',
	@nInputman	    INT=0,
	@nY_id          Varchar(50)='',
	@nloginEID      int=0,
	@isaddDate      int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
	@strBusinessType varchar(50)='0', /*商品赠送状态, '0':普通商品; '6':零成本; '7':有成本 (可组合)  */
	@isBuyBack int=0    /*是否包含退货, 0:包含退货, 1:不包含退货	*/
)
/*with encryption*/

AS
/*Params Ini begin*/
if @nBillType is null  SET @nBillType = 0
if @nC_id is null  SET @nC_id = 0
if @nE_id is null  SET @nE_id = 0
if @nSs_id is null  SET @nSs_id = 0
if @nSd_id is null  SET @nSd_id = 0
if @szParid is null  SET @szParid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nInputman is null  SET @nInputman = 0
if @nY_id is null  SET @nY_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @strBusinessType is null set @strBusinessType ='0'
if @isBuyBack is null set @isBuyBack=0
/*Params Ini end*/
  
 /* SET NOCOUNT ON*/
  DECLARE @SQLScript VARCHAR(8000) 
  Declare @isfinally int,@Y_id int
  Declare @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),
          @szsql2      varchar(8000)

  Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@Filteemployees  varchar(8000),@FilteStore   varchar(8000),
          @FilteClient2 varchar(8000),@Filteemployees2 varchar(8000), @FilteStore2 varchar(8000)
                                                                               
  /*Wsj--2016.11.10--商品赠送状态区分*/
  set @strBusinessType = @strBusinessType+',5' 
  select szTYPE into #type from  DecodeToStr(@strBusinessType)                                                                      
  declare @SQLBak varchar(8000)
  if @nBilltype in(20,21,22,35,220,221,222,160,162)
   begin
     if @nBilltype in(35,220,221,222,160,162) 
     set @SQLBak = ' and AOID in(0,5)'
     if @nBilltype in(20,21,22) 
     set @SQLBak = ' and AOID in(select szTYPE from #type) '
   end
   else set @SQLBak = ''
   
   /*采购入库单是否包含退货*/
   declare @ntype varchar(8000)
   if @isBuyBack = 0
   begin
    set @ntype = '20'
   end 
   else
   begin
    set @ntype = '20,21'
   end
   select szTYPE into #billtype from  DecodeToStr(@ntype) 
   set @ntype = ' in (Select szTYPE from #billtype)' 
   
/*
  declare @nPubPosMode varchar(10)  --如果是离线模式
  exec ts_getsysvalue 'PosDataMode',@nPubPosMode out
  
  if @nPubPosMode=2 and @nBilltype=162
       set @nBillType=152
*/
   
  select @Y_id=company_id from company where class_id = @nY_id   
  set @y_id = isnull(@y_id, 2)
  select  @FilteClient='',@FilteCompany='',@Filteemployees ='',@FilteStore ='',
          @FilteClient2='',    @FilteStore2='',@Filteemployees2=''
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
     Insert #Clienttable ([id]) select 0
   end
/*---往来单位授权*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      Insert #storagestable ([id]) select 0
   end
/*---仓库授权*/
 
IF @ClientTable<>0     set @FilteClient='and (a.c_id in (select [id]  FROM #Clienttable ))'
IF @Companytable<>0    set @FilteCompany=' and (a.Y_ID in (select [id] from #Companytable ))'
IF @employeestable<>0  set @Filteemployees= ' and (a.RowE_id in (select [id] from #employeestable))'
IF @storetable<>0      set @FilteStore=' and (a.ss_id in (select [ID] from #storagestable))'
                   
IF  @nBilltype IN (10,11,12,13, 32,210,211,212) 
/*销售出库单,销售出库退货单,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,销售单，销售退货单*/
BEGIN
  
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
  (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,isnull(Y.class_id,'''') as Yclass_id
              from FilterSalemanagebill('+CHAR(39)+cast(@nloginEID as varchar)+CHAR(39)+') sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON sm.bill_id=B.billid
              LEFT JOIN  company Y on sm.Y_id=Y.company_id
              where sm.aoid in (0,5) and sm.p_id>0 and Y.class_id like '''+ @nY_ID +'%''          
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

    	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
    	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
    	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
    	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
    	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

    	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID )t ' 
     
        EXEC(@SQLScript)
				
END 
ELSE IF  @nBilltype IN (151, 153) 
BEGIN
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
  (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id 
              from FilterSalemanagebill('+CHAR(39)+cast(@nloginEID as varchar)+CHAR(39)+') sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON sm.bill_id=B.billid
              where sm.aoid in (0,5) and sm.p_id>0 AND 
                    ('+CAST(@nSs_id AS VARCHAR)+'=0 OR sm.ss_id='+CAST(@nSs_id AS VARCHAR)+') AND 
                    ('+CAST(@nSd_id AS VARCHAR)+'=0 OR sm.sd_id='+CAST(@nSd_id AS VARCHAR)+')      
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

    	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
    	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
    	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
    	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
    	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

    	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID )t ' 
     
        EXEC(@SQLScript)
END ELSE IF @nBilltype IN (20)
/*采购入库单*/
BEGIN
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(case a.billtype when 21 then -quantity else quantity end), 0) AS quantity,
    0 AS diffqty,
    ISNULL(SUM(case a.billtype when 21 then -a.costtotal else a.costtotal end), 0) AS costtotal,
    ISNULL(SUM(case a.billtype when 21 then -a.retailtotal else a.retailtotal end), 0) AS retailtotal,
    ISNULL(SUM(case a.billtype when 21 then -a.taxtotal else a.taxtotal end), 0) AS taxtotal,
    ISNULL(SUM(case a.billtype when 21 then -a.SendQTY else a.SendQTY end),0) AS SendQTY,
    ISNULL(SUM(case a.billtype when 21 then -a.SendTotal else a.SendTotal end),0) AS SendTotal,
    ISNULL(SUM(case a.billtype when 21 then -a.SendCostTotal else a.SendCostTotal end),0) AS SendCostTotal
    FROM 
       (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
        ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,totalmoney,(costprice*(quantity))costtotal,
             retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,B.Y_id,isnull(Y.class_id,'''') as Yclass_id
              from buymanagebill bm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman,Y_ID from billidx 
                 where  billtype '+@ntype+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and billstates=''0''
              )B ON bm.bill_id=B.billid
              LEFT JOIN  company Y on b.Y_id=Y.company_id
              where bm.p_id>0'+@SQLBak+' and Y.class_id like '''+ @nY_ID +'%''                  
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

 	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID) AS t' 
    
    EXEC(@SQLScript)
END ELSE IF  @nBilltype IN (21,35,220,221,222,160,162)	/*xzdong-2016-11-08-TFS42587-采购入库退货统计查询字段调整*/
BEGIN
/*采购入库退货单,受托代销收货,受托代销退货,受托代销结算,采购单，采购退货单，机构、自营店收货*/
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,
    ISNULL(SUM(case a.billtype when 21 then a.totalmoney else a.costtotal end), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
       (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
        ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,totalmoney,(costprice*quantity)costtotal,
             retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,B.Y_id,isnull(Y.class_id,'''') as Yclass_id
              from buymanagebill bm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman,Y_ID from billidx 
                 where  billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and billstates=''0''
              )B ON bm.bill_id=B.billid
              LEFT JOIN  company Y on b.Y_id=Y.company_id
              where bm.p_id>0'+@SQLBak+' and Y.class_id like '''+ @nY_ID +'%''                  
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

 	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID) AS t' 
    
    EXEC(@SQLScript)
END ELSE IF @nBillType IN (161, 163)/*机构、自营店退货*/
BEGIN

SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty, 
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
       (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
        ,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id
              from buymanagebill bm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman,sout_id, sin_id from billidx 
                 where  billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and billstates=''0''
              )B ON bm.bill_id=B.billid
              where bm.aoid in (0,5) and bm.p_id>0 AND 
                    ('+CAST(@nSs_id AS VARCHAR)+'=0 OR b.sout_id='+CAST(@nSs_id AS VARCHAR)+') AND 
                    ('+CAST(@nSd_id AS VARCHAR)+'=0 OR b.sin_id='+CAST(@nSd_id AS VARCHAR)+')                 
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

 	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	/*IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)*/
  	/*IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)*/
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID) AS t' 
  
    EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (30,31,33,34,41,42,43,44,45,46,47,48,49)
BEGIN
/*借出单,借出还回单,借转销售单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
SELECT  @SQLScript='
    SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,costtotal,retailmoney as retailtotal,totalmoney as taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,isnull(Y.class_id,'''') as Yclass_id
              from storemanagebill sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where  billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and billstates=''0''
              )B ON sm.bill_id=B.billid
              LEFT JOIN  company Y on sm.Y_id=Y.company_id
              where sm.aoid in (0,5) and sm.p_id>0 and Y.class_id like '''+ @nY_ID +'%''            
             )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore
  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.ROWE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.pClass_ID) AS t' 
   EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (40)
BEGIN
/*生产组装单*/
SELECT  @SQLScript='
        SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(case a.ioTag when 1 then a.quantity else -a.Quantity end), 0) AS quantity, 
    0 AS diffqty, 
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id 
           FROM
             (select p_id,quantity,costtotal,retailmoney as retailtotal,totalmoney as taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,isnull(Y.class_id,'''') as Yclass_id,iotag
              from storemanagebill sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where   billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and billstates=''0''
              )B ON sm.bill_id=B.billid 
              LEFT JOIN  company Y on sm.Y_id=Y.company_id
              where sm.aoid in (0,5) and sm.p_id>0 and Y.class_id like '''+ @nY_ID+'%''             
             )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.ROWE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.pClass_ID) AS t' 
  EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (14,22,26) /*xzdong-2016-11-09-TFS42597/TFS42598-采购计划/订单统计查询字段调整*/
BEGIN
/*采购合同，销售合同,采购计划*/
SELECT  @SQLScript='
    SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty, 
    ISNULL(SUM(case a.billtype when 14 then a.costtotal else a.totalmoney end), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0)  as sendqty,
    ISNULL(SUM(a.SendTotal),0)  as SendTotal,
    ISNULL(SUM(a.SendCostTotal),0)  as SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,totalmoney,(costprice*quantity) as costtotal, retailtotal,taxtotal,0 as sendqty,0 as sendtotal
                     ,0 as SendCostTotal ,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,ISNULL(Y.CLASS_ID,'''') AS YCLASS_ID
              from orderbill o 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from orderidx 
                 where  billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' and  billstates <>''2''
              )B ON o.bill_id=B.billid
	      LEFT JOIN company Y on Y.company_id=o.Y_id
              where o.p_id>0 '+@SQLBak+' and Y.class_id like '''+ @nY_ID+'%''               
             )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore
        IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  		IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  		IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  		IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  		IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

 	SET @SQLScript=@SQLScript+' GROUP BY a.pClass_ID) AS t' 
 /* print(@SQLScript)*/
   EXEC(@SQLScript)
 
END ELSE IF  @nBilltype IN (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90)
BEGIN
/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买*/
SELECT  @SQLScript='
        SELECT  b.cclass_id as Class_ID,
	    ISNULL(SUM(a.quantity), 0) AS quantity, 
	    ISNULL(SUM(a.totalmoney), 0) AS costtotal
        FROM financebill a 
        INNER JOIN  (select * from vw_c_billidx b
                         WHERE  b.billstates=''0'' and b.billtype='+CAST(@nBillType AS VARCHAR)+'
                         '+@FilteClient+@Filteemployees2+'
                        )b ON b.billid=a.bill_id'
        IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  b.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  b.E_id='+CAST(@nE_id AS VARCHAR)

 	SET @SQLScript=@SQLScript+' GROUP BY  b.cclass_id ' 
  EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (53,54,55,56)
BEGIN
/*配送类单据*/
SELECT  @SQLScript='
    SELECT  * INTO ##mytempdb FROM (SELECT  dbo.products.Class_ID,
			ISNULL(SUM(a.quantity), 0) AS quantity, 
			0 AS diffqty,
			ISNULL(SUM(a.costprice*a.quantity), 0) AS costtotal,
			ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
			ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
            ISNULL(SUM(a.SendQTY), 0) AS SendQTY,
            ISNULL(SUM(a.SendCostTotal), 0) AS SendCostTotal
			FROM vw_c_tranmb a inner join
			dbo.products ON a.p_id = dbo.products.product_id

          INNER JOIN   ( select * from vw_c_billidx b
                           where b.billstates=''0'' and b.billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' b.billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
                        + @FilteClient+
                        ')b ON b.billid=a.bill_id

			WHERE  dbo.products.deleted<>1 '
                        + @Filteemployees
                        + @FilteStore

  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  b.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.ROWE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  b.inputman='+CAST(@ninputman AS VARCHAR)
/*       IF  @nY_id not in ('','000000','%%')   SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''*/

  	SET @SQLScript=@SQLScript+' GROUP BY dbo.products.Class_ID) AS t' 
    EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (30, 31, 32, 33, 34, 35)
BEGIN
/*借出单、借出还回单、借出转销售单、借进单、借进还出单、借进转采购单*/
SELECT  @SQLScript='
       SELECT  * INTO ##mytempdb FROM (SELECT  dbo.products.Class_ID,
			ISNULL(SUM(a.quantity), 0) AS quantity, 
			0 AS diffqty, 
			ISNULL(SUM(a.costprice*a.quantity), 0) AS costtotal,
			ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
			ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
                        0 AS SendQTY,
                        0 AS SendCostTotal
			FROM vw_c_storemb a inner join
			dbo.products ON a.p_id = dbo.products.product_id
          INNER JOIN   ( select * from vw_c_billidx b
                           where   b.billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' b.billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
                        + @FilteClient+
                        ' and b.billstates=''0'' )b ON b.billid=a.bill_id

			WHERE  dbo.products.deleted<>1 '
                        + @Filteemployees
                        + @FilteStore


  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  b.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  b.inputman='+CAST(@ninputman AS VARCHAR)
/*        IF  @nY_id not in ('','000000','%%')   SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''*/

  	SET @SQLScript=@SQLScript+' GROUP BY dbo.products.Class_ID) AS t' 
    EXEC(@SQLScript)

END ELSE IF  @nBilltype IN (46, 47)
BEGIN
/*赠送单，获赠单*/
	SELECT  @SQLScript='
    SELECT  * INTO ##mytempdb FROM (SELECT  dbo.products.Class_ID,
			ISNULL(SUM(a.quantity), 0) AS quantity, 
			0 AS diffqty, 
			ISNULL(SUM(a.costprice*a.quantity), 0) AS costtotal,
			ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
			ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
                        0 AS SendQTY,
                        0 AS SendCostTotal
			FROM vw_storemb a inner join
			dbo.products ON a.p_id = dbo.products.product_id
          INNER JOIN   ( select * from vw_c_billidx b
                           where   b.billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' b.billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)
                        + @FilteClient+
                        ' and  b.billstates=''0'')b ON b.billid=a.bill_id

			WHERE  dbo.products.deleted<>1 '
                        + @Filteemployees
                        + @FilteStore

  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  b.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  b.inputman='+CAST(@ninputman AS VARCHAR)
/*         IF  @nY_id not in ('','000000','%%')   SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''*/

  	SET @SQLScript=@SQLScript+' GROUP BY dbo.products.Class_ID) AS t' 
    EXEC(@SQLScript)
END
ELSE IF  @nBilltype IN (50)
BEGIN
/*库存盘点单*/
SELECT  @SQLScript='
  SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    ISNULL(SUM(a.diffqty), 0) AS diffqty, 
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT e_id,YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id 
           FROM
             (select p_id,quantity,taxmoney as diffqty,(costprice*quantity)costtotal, retailtotal,taxtotal,0 as SendQTY
                     ,0 as SendTotal,0 as SendCostTotal,B.c_id,B.billtype,0 as RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,ISNULL(Y.CLASS_ID,'''') AS YCLASS_ID
              from goodscheckbill g 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where    billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and  billstates=''0''
              )B ON g.bill_id=B.billid
              LEFT JOIN company Y on g.Y_id=Y.company_id
              where g.aoid in (0,5) and g.p_id>0 and Y.class_id like '''+ @nY_ID+'%''             
            
             )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

  	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.e_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)
/*        IF  @nY_id not in ('','000000','%%')   SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''*/

  	SET @SQLScript=@SQLScript+' GROUP BY a.pClass_ID) AS t' 
    /*PRINT @SQLScript*/
    EXEC(@SQLScript)
END
else IF  @nBilltype IN (150) 
BEGIN
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
  (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity,
    0 AS diffqty, 
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id
              from FilterSalemanagebill('+CHAR(39)+cast(@nloginEID as varchar)+CHAR(39)+') sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman,sout_id,sin_id from billidx 
                 where    billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON sm.bill_id=B.billid
              
              where sm.aoid in (0,5) and sm.p_id>0 AND 
                    ('+CAST(@nSs_id AS VARCHAR)+'=0 OR b.sout_id='+CAST(@nSs_id AS VARCHAR)+') AND 
                    ('+CAST(@nSd_id AS VARCHAR)+'=0 OR b.sin_id='+CAST(@nSd_id AS VARCHAR)+')            
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '/*+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore*/

    	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
    	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
    	/*IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.sout_id='+CAST(@nSs_id AS VARCHAR)*/
    	/*IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sin_id='+CAST(@nSd_id AS VARCHAR)*/
    	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

    	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID )t ' 
        EXEC(@SQLScript)	
END
else IF  @nBilltype IN (152) 
BEGIN
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
  (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty, 
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id
              from FilterSalemanagebill('+CHAR(39)+cast(@nloginEID as varchar)+CHAR(39)+') sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where    billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON sm.bill_id=B.billid
              
              where sm.aoid in (0,5) and sm.p_id>0 AND 
                    ('+CAST(@nSs_id AS VARCHAR)+'=0 OR sm.ss_id='+CAST(@nSs_id AS VARCHAR)+') AND 
                    ('+CAST(@nSd_id AS VARCHAR)+'=0 OR sm.sd_id='+CAST(@nSd_id AS VARCHAR)+')            
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '/*+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore*/

    	/*IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)*/
    	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
    	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
    	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
    	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

    	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID )t ' 
        EXEC(@SQLScript)

END

ELSE IF  @nBilltype IN (120,121,122) 
BEGIN
/*受托代销收货,受托代销退货*/
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
   (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,  
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
       (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
        ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,isnull(Y.class_id,'''') as Yclass_id
              from buymanagebill bm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where  billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON bm.bill_id=B.billid
              LEFT JOIN  company Y on bm.Y_id=Y.company_id
              where bm.aoid in (0,5) and bm.p_id>0 and Y.class_id like '''+ @nY_ID +'%''                       
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
          where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

 	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
  	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
  	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
  	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
  	IF  @nInputman<>0	SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

  	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID) AS t' 
 
   EXEC(@SQLScript)

END

ELSE IF  @nBilltype IN (110,111,112) 
/*委托代销发货,委托代销退货,受托代销发货,受托代销退货*/
BEGIN
  
SELECT  @SQLScript='
SELECT  * INTO ##mytempdb FROM 
  (SELECT  a.PClass_ID as Class_id,
    ISNULL(SUM(a.quantity), 0) AS quantity, 
    0 AS diffqty,  
    ISNULL(SUM(a.costtotal), 0) AS costtotal,
    ISNULL(SUM(a.retailtotal), 0) AS retailtotal,
    ISNULL(SUM(a.taxtotal), 0) AS taxtotal,
    ISNULL(SUM(a.SendQTY),0) AS SendQTY,
    ISNULL(SUM(a.SendTotal),0) AS SendTotal,
    ISNULL(SUM(a.SendCostTotal),0) AS SendCostTotal
    FROM 
          (SELECT YPSM.*,isnull(P.Class_id,'''') as PClass_id,isnull(RE.Class_id,'''')REClass_id,isnull(S.Class_id,'''')SClass_id
                     ,isnull(C.Class_id,'''')CClass_id,isnull(E.Class_id,'''')InputmanClass_id
           FROM
             (select p_id,quantity,(costprice*quantity)costtotal,retailtotal,taxtotal,SendQTY
                     ,(SendQTY*totalmoney/quantity)SendTotal,SendCostTotal,B.c_id,B.billtype,RowE_id
                     ,ss_id,sd_id,B.inputman,Y_id,isnull(Y.class_id,'''') as Yclass_id
              from FilterSalemanagebill('+CHAR(39)+cast(@nloginEID as varchar)+CHAR(39)+') sm 
              INNER JOIN
              (select billid,c_id,billtype,Inputman from billidx 
                 where    billtype='+CAST(@nBillType AS VARCHAR)+' and '
                        +' billdate between '+CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
                        +  CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+'and billstates=''0''
              )B ON sm.bill_id=B.billid
              LEFT JOIN  company Y on sm.Y_id=Y.company_id
              where sm.aoid in (0,5) and sm.p_id>0 and Y.class_id like '''+ @nY_ID +'%''         
	     )YPSM 
              LEFT JOIN Products  p  on p.product_id=YPSM.p_id
              LEFT JOIN employees RE on re.emp_id=YPSM.RowE_id
              LEFT JOIN storages  S  on S.storage_id=YPSM.ss_id
              LEFT JOIN Clients   C  on YPSM.c_id=c.client_id
              LEFT JOIN employees E  on YPSM.inputman=E.emp_id 
    )a
       where p_id>0 '+@FilteClient+@FilteCompany+@Filteemployees+@FilteStore

    	IF  @nC_id<>0 	SET @SQLScript=@SQLScript+' and  a.c_id='+CAST(@nC_id AS VARCHAR)
    	IF  @nE_id<>0 	SET @SQLScript=@SQLScript+' and  a.RowE_id='+CAST(@nE_id AS VARCHAR)
    	IF  @nSs_id<>0	SET @SQLScript=@SQLScript+' and  a.ss_id='+CAST(@nSs_id AS VARCHAR)
    	IF  @nSd_id<>0	SET @SQLScript=@SQLScript+' and  a.sd_id='+CAST(@nSd_id AS VARCHAR)
    	IF  @nInputman<>0 SET @SQLScript=@SQLScript+' and  a.inputman='+CAST(@ninputman AS VARCHAR)

    	SET @SQLScript=@SQLScript+' GROUP BY a.PClass_ID )t ' 
        
        EXEC(@SQLScript)
 end


  IF  @szListFlag='L' GOTO ListLeavel
  IF  @szListFlag='A' GOTO ListAll
  IF  @szListFlag='P' GOTO ListPart

ListLeavel:
  SELECT  a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
    a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
		isnull(Max(Vpb.[e_name]),' ')e_name,isnull(Max(Vpb.[C_Name]),' ')C_Name,
		CAST(ISNULL(SUM(b.[Quantity]),0)  AS numeric(25,8)) AS [Quantity],
		CAST(ISNULL(SUM(b.[Costtotal]),0) AS numeric(25,8)) AS [Costtotal],
		CAST(ISNULL(SUM(b.[Retailtotal]),0) AS numeric(25,8)) AS [Retailtotal],
		CAST(ISNULL(SUM(b.[Taxtotal]),0) AS numeric(25,8)) AS [Taxltotal],
                CAST(ISNULL(SUM(b.[SendQTY]),0) AS  numeric(25,8)) AS [SendQTY],
                CAST(ISNULL(SUM(b.[SendCostTotal]),0) AS numeric(25,8)) AS [SendCostTotal],
       CAST(ISNULL(SUM(b.[diffqty]),0)  AS numeric(25,8)) AS [diffqty]  
	  FROM VW_C_Products a 
	  LEFT join	##mytempdb b
	  ON LEFT(b.[Class_ID],LEN(a.[Class_ID]))=a.[Class_ID]
	  LEFT JOIN (select * from vw_productbalance where Y_id = @Y_id) Vpb on a.Product_ID=Vpb.p_id 
		WHERE a.parent_id = @szParid and a.deleted <> 1
		GROUP BY a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
    a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5
	
	ORDER BY a.[Product_ID]

  GOTO Succee

ListAll:
  SELECT  a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
    a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
		isnull(Max(Vpb.[e_name]),'')e_name,isnull(Max(Vpb.[C_Name]),'')C_Name,
		CAST(ISNULL(SUM(b.[Quantity]),0)  AS numeric(25,8)) AS [Quantity],
		CAST(ISNULL(SUM(b.[Costtotal]),0) AS numeric(25,8)) AS [Costtotal],
		CAST(ISNULL(SUM(b.[Retailtotal]),0) AS numeric(25,8)) AS [Retailtotal],
		CAST(ISNULL(SUM(b.[Taxtotal]),0) AS numeric(25,8)) AS [Taxltotal],
                CAST(ISNULL(SUM(b.[SendQTY]),0) AS  numeric(25,8)) AS [SendQTY],
                CAST(ISNULL(SUM(b.[SendCostTotal]),0) AS numeric(25,8)) AS [SendCostTotal],
        CAST(ISNULL(SUM(b.[diffqty]),0)  AS numeric(25,8)) AS [diffqty] 
		FROM VW_C_Products a 
	  LEFT join	##mytempdb b
		ON b.[Class_ID]=a.[Class_ID]
	  LEFT JOIN (select * from vw_productbalance where Y_id = @Y_id) Vpb on a.Product_ID=Vpb.p_id 
		WHERE a.[DELETEd]<>1 and a.[Child_Number]=0 and a.[Product_ID]<>1
		GROUP BY a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
    a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5
	
		ORDER BY a.[Product_ID]

  GOTO Succee

ListPart:
  SELECT  a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
        a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
	   isnull(Max(Vpb.[e_name]),'')e_name,isnull(Max(Vpb.[C_Name]),'')C_Name,
		CAST(ISNULL(SUM(b.[Quantity]),0)  AS numeric(25,8)) AS [Quantity],
		CAST(ISNULL(SUM(b.[Costtotal]),0) AS numeric(25,8)) AS [Costtotal],
		CAST(ISNULL(SUM(b.[Retailtotal]),0) AS numeric(25,8)) AS [Retailtotal],
		CAST(ISNULL(SUM(b.[Taxtotal]),0) AS numeric(25,8)) AS [Taxltotal],
        CAST(ISNULL(SUM(b.[SendQTY]),0) AS  numeric(25,8)) AS [SendQTY],
        CAST(ISNULL(SUM(b.[SendCostTotal]),0) AS numeric(25,8)) AS [SendCostTotal],
        CAST(ISNULL(SUM(b.[diffqty]),0)  AS numeric(25,8)) AS [diffqty] 
		FROM VW_C_Products a 
	   LEFT join	##mytempdb b
		ON b.[Class_ID]=a.[Class_ID]
       LEFT JOIN (select * from vw_productbalance where Y_id = @Y_id) Vpb on a.Product_ID=Vpb.p_id 
		WHERE LEFT(a.[Class_ID], LEN(@szParid))=@szParid and a.[DELETEd]<>1 and a.[Child_Number]=0 
		GROUP BY a.[Product_ID],a.[Class_ID],a.[Child_Number],a.[Name],a.[Code],a.[AliAS],a.[standard],a.[Modal],a.[Makearea],
    a.[Rate2],a.[Rate3],a.[Rate4],a.[Unitname1],a.[Factory],a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5
	
		ORDER BY a.[Product_ID]

  GOTO Succee

Succee:
  drop table ##mytempdb
  drop table #Clienttable
  drop table #Companytable
  drop table #employeestable
  drop table #storagestable
  drop table #billtype
  drop table #type
  RETURN  0
GO
