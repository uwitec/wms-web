

create  TRIGGER  UpdateThqty1 ON [dbo].[buymanagebilldrf] 
FOR INSERT
AS

declare @smb_id int

select @smb_id=smb_id from inserted
update buymanagebilldrf set thqty=quantity,newprice=taxprice where smb_id=@smb_id
GO
