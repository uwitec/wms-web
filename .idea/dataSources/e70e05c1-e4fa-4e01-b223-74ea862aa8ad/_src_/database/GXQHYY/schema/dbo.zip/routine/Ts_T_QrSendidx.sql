/************************************************************
--过程名称：Ts_T_QrSendidx
--功能：查询物流配送单主报表
--创建人：LUO XIAOTIAN 
--创建时间：2010-12-14 
--最后修改:


参数说明：
		   

备注：
**************************************************************/
create proc [dbo].[Ts_T_QrSendidx]
( @begindate [datetime] ,/*开始时间*/
  @enddate   [datetime] ,/*结束时间*/
  @C_id       int,      /*配送客户*/
  @driver    int ,      /*驾驶员*/
  @stevedore int ,       /*装卸工*/
  @checkman  int ,       /*复核人*/
  @States int = 0,     /*物流单运输状态，为2表示为完成的,*/
  @TrafficType VARCHAR(30) = '',	 /*承运方式*/
  @RoadID  INT  = 0 ,    /*配送路线   */
  @code  VARCHAR(200) = ''    /*物流单号 */
)
As
 set @C_id = 0 /*表头往来单位不用来过滤表头信息*/
if @States is null 
 set @States = 0

if @TrafficType is null 
 set @TrafficType = '' 
 
if @RoadID is null 
 set @RoadID = 0  
 
if @code is null set @code = ''

if @code = '' 
begin  
	select 1 as serialno,S.Send_id as billID,S.serial_number as billnumber,S.billDate,S.billstates,S.auditDate,
		   '1' AS summary,1 AS billtype, CAST(1 as numeric(25,8)) as ssmoney ,CAST(2 as [numeric](18, 2)) as [taxrate],
		   S.consign_dep  ,S.wholeNumber,/*cast(S.wholeNumber as numeric(25,8))quantity,*/
		   S.remnantNumber,/*cast(S.remnantNumber AS numeric(25,8)) ysmoney,*/
		   S.trafficMode ,
		  Isnull( l.Driver,'') as Drivername,Isnull( e2.name,'') as departmentname, Isnull( e3.name,'') as accountname, 
		   S.consignee as regionname,S.relationPhone,
		   S.paymentMode as paymentMode,Isnull(e4.name,'') as auditmanname, S.checkman as auditman,S.remark as note,
		   isnull(e5.name,'') as inputmanname,S.inputman ,isnull(c.name,'') as cname,s.lhqty,
		   CASE s.Transportation_States WHEN 0 THEN '待运输' WHEN 1 THEN '运输中' WHEN 2 THEN '已到达' END AS Transportation_States,
		   s.CamionCode, s.Signfor, s.TransportationHour, 
		   CASE CONVERT(VARCHAR(100), s.SendTime, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.SendTime, 120) END AS SendTime, 
		   CASE CONVERT(VARCHAR(100), s.ArriveStation, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.ArriveStation, 120) END AS ArriveStation, 
		   CASE CONVERT(VARCHAR(100), s.ArriveCustomer, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.ArriveCustomer, 120) END AS ArriveCustomer, 
		   CASE s.TransportationType WHEN '0' THEN '常温' WHEN '1' THEN '冷链' END AS TransportationType, 
		   s.DeviceTemperature_Begin, s.ConditionTemperature_Begin, s.ConditionTemperature_End, s.ConditionTemperature_End,
		   s.DetectTemperature, s.AffirmTemperature, s.ProcessTemperature, ISNULL(s.TransportationLimit, 0) AS TransportationLimit, 
		   CASE WHEN (s.SendTime <> 0 AND ISNULL(s.TransportationLimit, 0) <> 0) THEN CONVERT(VARCHAR(100), SendTime + ISNULL(s.TransportationLimit, 0), 120) ELSE '' END AS Arrival,
		   s.TrafficType,s.SendCode
		   from Sendidx S  left join logisticsInfo l on  S.Driver=l.id 
					 left join employees e2 on  S.stevedore =e2.emp_id 
					 left join employees e3 on  S.consigner =e3.emp_id 
					 left join employees e4 on  S.checkman = e4.emp_id
					 left join employees e5 on  S.inputman = e5.emp_id  
					 left join clients   c  on s.C_id=c.client_id
		where S.billDate between cast(@begindate as varchar(10)) and cast(@enddate as varchar(10)) and (@C_id=0 or S.C_id=@C_id)
		and (@driver = 0 or S.Driver = @driver)
		and (@stevedore = 0 or S.stevedore = @stevedore ) 
		and (@checkman = 0 or S.checkman = @checkman )
		and ((@States = 0 and (s.Transportation_States = 0 or s.Transportation_States = 1)) or (s.Transportation_States = @States))
		/*and (@States = '' or (charindex(str(s.Transportation_States),@States,0) > 0))*/
		/*and (@trafficMode = '' or s.trafficMode = @trafficMode or s.trafficMode = '')*/
		AND (S.roadid = @RoadID OR @RoadID = 0)			/*配送线路的判断*/
		AND (@TrafficType = '' or @TrafficType = '[全部]' or isnull(s.TrafficType,'')= '' or charindex(@TrafficType, isnull(s.TrafficType,'')) > 0 )
	    
	/*	AND ((CASE WHEN RTRIM(LTRIM(ISNULL(s.TrafficType, '[全部]'))) = '' THEN '[全部]' ELSE RTRIM(LTRIM(ISNULL(s.TrafficType, '[全部]'))) END) = @TrafficType */
	/*		or @TrafficType = '[全部]' or RTRIM(LTRIM(s.TrafficType)) = '0' or RTRIM(LTRIM(s.TrafficType)) = '')*/

end
else
begin
	select 1 as serialno,S.Send_id as billID,S.serial_number as billnumber,S.billDate,S.billstates,S.auditDate,
		   '1' AS summary,1 AS billtype, CAST(1 as numeric(25,8)) as ssmoney ,CAST(2 as [numeric](18, 2)) as [taxrate],
		   S.consign_dep  ,S.wholeNumber,/*cast(S.wholeNumber as numeric(25,8))quantity,*/
		   S.remnantNumber,/*cast(S.remnantNumber AS numeric(25,8)) ysmoney,*/
		   S.trafficMode ,
		  Isnull( l.Driver,'') as Drivername,Isnull( e2.name,'') as departmentname, Isnull( e3.name,'') as accountname, 
		   S.consignee as regionname,S.relationPhone,
		   S.paymentMode as paymentMode,Isnull(e4.name,'') as auditmanname, S.checkman as auditman,S.remark as note,
		   isnull(e5.name,'') as inputmanname,S.inputman ,isnull(c.name,'') as cname,s.lhqty,
		   CASE s.Transportation_States WHEN 0 THEN '待运输' WHEN 1 THEN '运输中' WHEN 2 THEN '已到达' END AS Transportation_States,
		   s.CamionCode, s.Signfor, s.TransportationHour, 
		   CASE CONVERT(VARCHAR(100), s.SendTime, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.SendTime, 120) END AS SendTime, 
		   CASE CONVERT(VARCHAR(100), s.ArriveStation, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.ArriveStation, 120) END AS ArriveStation, 
		   CASE CONVERT(VARCHAR(100), s.ArriveCustomer, 23) WHEN '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), s.ArriveCustomer, 120) END AS ArriveCustomer, 
		   CASE s.TransportationType WHEN '0' THEN '常温' WHEN '1' THEN '冷链' END AS TransportationType, 
		   s.DeviceTemperature_Begin, s.ConditionTemperature_Begin, s.ConditionTemperature_End, s.ConditionTemperature_End,
		   s.DetectTemperature, s.AffirmTemperature, s.ProcessTemperature, ISNULL(s.TransportationLimit, 0) AS TransportationLimit, 
		   CASE WHEN (s.SendTime <> 0 AND ISNULL(s.TransportationLimit, 0) <> 0) THEN CONVERT(VARCHAR(100), SendTime + ISNULL(s.TransportationLimit, 0), 120) ELSE '' END AS Arrival,
		   s.TrafficType,s.SendCode
		   from Sendidx S  left join logisticsInfo l on  S.Driver=l.id 
					 left join employees e2 on  S.stevedore =e2.emp_id 
					 left join employees e3 on  S.consigner =e3.emp_id 
					 left join employees e4 on  S.checkman = e4.emp_id
					 left join employees e5 on  S.inputman = e5.emp_id  
					 left join clients   c  on s.C_id=c.client_id
		where s.szserial_code = @code
end
GO
