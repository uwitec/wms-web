
CREATE VIEW [vw_c_OtherStorehouseini]
AS
SELECT 
  SH.*, 
  P.[Serial_Number] AS [Code], P.[Name] AS [PName], P.[Class_ID], 
  P.[MakeArea], tx.name as [TaxRate], P.[Validmonth], P.[Permitcode],
  P.[Alias], P.[Standard], m.id as [Medtype], P.[Rate2], P.[Rate3], P.[Rate4],
  P.[Costmethod],
  P.[Modal], P.[TradeMark], P.[PinYin], ISNULL(P.[IsSplit]       ,0)  AS [IsSplit],
  ISNULL(C.[Name]     ,'') AS [CName],     ISNULL(C.[Class_ID]  ,'') AS [CClass_ID], 
  ISNULL(SU.[Name]    ,'') AS [SuppName],  ISNULL(SU.[Class_ID] ,'') AS [SuppClass_ID], 
  ISNULL(S.[Name]     ,'') AS [SName],     ISNULL(S.[Class_ID]  ,'') AS [SClass_ID],
  ISNULL(U1.[Name]    ,'') AS [UnitName1], ISNULL(U2.[Name]     ,'') AS [UnitName2], 
  ISNULL(U3.[Name]    ,'') AS [UnitName3], ISNULL(U4.[Name]     ,'') AS [UnitName4],
  ISNULL(M.name  ,'') AS [MedName],   ISNULL(L.[Loc_Name]  ,'') AS [LocName],
  ISNULL(Y.Class_id   ,'') as YClass_id,   ISNULL(Y.[name]      ,'') as Yname
FROM OtherStorehouseini SH
  LEFT JOIN Storages S ON SH.[S_ID]=S.[Storage_ID] 
  LEFT JOIN Clients SU ON SH.[Supplier_ID]=SU.[Client_ID]
  LEFT JOIN Location L ON SH.[Location_ID]=L.[Loc_ID] 
  LEFT JOIN Clients C  ON SH.[Supplier_ID]=C.[Client_ID] 
  LEFT JOIN Products P ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN Unit U1    ON U1.[Unit_ID]=P.[Unit1_ID]
  LEFT JOIN Unit U2    ON U2.[Unit_ID]=P.[Unit2_ID]
  LEFT JOIN Unit U3    ON U3.[Unit_ID]=P.[Unit3_ID]
  LEFT JOIN Unit U4    ON U4.[Unit_ID]=P.[Unit4_ID]
  left   join 
	  (
			select a.id,name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on p.product_id = m.baseinfo_id
  left   join 
	  (
		select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=3 and b.deleted=0
	  )tx on p.product_id = tx.baseinfo_id
  LEFT JOIN Company  Y  ON Y.company_id= SH.Y_id
WHERE (P.[Deleted]<>1) AND (S.[Deleted]=0)
GO
