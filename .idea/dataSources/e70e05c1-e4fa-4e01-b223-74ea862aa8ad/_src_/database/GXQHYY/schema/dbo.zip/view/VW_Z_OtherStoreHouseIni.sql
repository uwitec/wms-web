
CREATE  VIEW [VW_Z_OtherStoreHouseIni]   
AS
SELECT
  SH.*, 
  P.[Class_ID] AS [PClass_ID] ,   P.[Serial_Number],  P.[Name] AS [PName],   
  P.[Alias],      P.[Standard],   P.[Modal],          P.[TradeMark],    
  P.[MakeArea],   P.[Rate2],      P.[Rate3],          P.[Rate4],         
  P.[Unit1_ID],   P.[Unit2_ID],   P.[Unit3_ID],       P.[Unit4_ID],
  P.[ValidMonth], P.[ValidDay],   P.[Comment],        
  /*P.[CommentA],       */
  /*P.[CommentB],   P.[CommentC],   P.[CommentD],       P.[CommentE],     */
  P.[Packstd],    P.[StorageCon], P.[Deleted],        P.[Deduct],     
  P.[Costmethod], tx.name  as [TaxRate],    P.[RowIndex],       
  ISNULL(C.[Name]     ,'') AS [CName],     ISNULL(C.[Class_ID]  ,'') AS [CClass_ID], 
  ISNULL(SU.[Name]    ,'') AS [SuppName],  ISNULL(SU.[Class_ID] ,'') AS [SuppClass_ID], 
  ISNULL(S.[Name]     ,'') AS [SName],     ISNULL(S.[Class_ID]  ,'') AS [SClass_ID],
  ISNULL(U1.[Name]    ,'') AS [UnitName1], ISNULL(U2.[Name]     ,'') AS [UnitName2], 
  ISNULL(U3.[Name]    ,'') AS [UnitName3], ISNULL(U4.[Name]     ,'') AS [UnitName4],
  ISNULL(M.name  ,'') AS [MedName],   ISNULL(L.[Loc_Name]  ,'') AS [LocName],  
  ISNULL(S.[Name]    ,'') AS [StorageName],ISNULL(Y.[Class_ID]  ,'') AS YClass_ID,
  ISNULL(Y.[Name]    ,'')  AS YName
FROM OtherStoreHouseIni SH
  LEFT JOIN Storages S ON SH.[S_ID]=S.[Storage_ID] AND (S.[Deleted]=0)
  LEFT JOIN Clients SU ON SH.[Supplier_ID]=SU.[Client_ID]
  LEFT JOIN Location L ON SH.[Location_ID]=L.[Loc_ID] 
  LEFT JOIN Clients C  ON SH.[Supplier_ID]=C.[Client_ID] 
  LEFT JOIN Products P ON SH.[P_ID]=P.[Product_ID] AND (P.[Deleted] in (0,2)) 
  LEFT JOIN Unit U1    ON U1.[Unit_ID]=P.[Unit1_ID]
  LEFT JOIN Unit U2    ON U2.[Unit_ID]=P.[Unit2_ID]
  LEFT JOIN Unit U3    ON U3.[Unit_ID]=P.[Unit3_ID]
  LEFT JOIN Unit U4    ON U4.[Unit_ID]=P.[Unit4_ID]
  left   join 
	  (
			select a.id, name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on p.product_id = m.baseinfo_id
  LEFT JOIN Company Y  ON SH.Y_ID=Y.Company_ID
  left   join 
	  (
		select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=3 and b.deleted=0
	  )tx on p.product_id = tx.baseinfo_id
GO
