

CREATE	VIEW dbo.vw_b_region
AS
SELECT region_id as z_id, name as z_name
FROM region
WHERE deleted = 0
GO
