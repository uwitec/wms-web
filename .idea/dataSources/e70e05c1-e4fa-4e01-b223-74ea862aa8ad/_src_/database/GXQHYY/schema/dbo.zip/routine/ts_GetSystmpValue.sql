

CREATE	   procedure ts_GetSystmpValue
(
	@szSysName varchar(60),
	@sysflag int,
	@szSysValue varchar(60) output,
	@nY_ID int = 0
)  
/*with encryption*/
AS  
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
SET NOCOUNT ON
SELECT @szSysValue='0'

SELECT @szSysValue=ISNULL(sysvalue,'0') FROM sysconfigtmp WHERE [sysname]=@szSysName and sysflag=@sysflag and y_id = @nY_ID
order by tagno

RETURN 0
GO
