

/*exec ts_c_qrSaleBuyCost '2002-01-01 00:00:00','2002-01-01 00:00:00',3,2,'000001',2,0,0,0,0*/
/*采购，销售成本表*/
/*nmode=1 采购  		=－1销售*/
/*nmode=2 采购明细 销售明细*/
/*nMode=3 机构发货成本表*/
/*nMode=4 机构发货成本明细表*/
CREATE proc ts_c_qrSaleBuyCost
(
	@begindate 	datetime,
	@enddate 	datetime,
	@nBillid	int=-1,
	@nMode		int=0,
    @nYClassID      varchar(50)='',
    @nloginEID      int=0,
    @isaddDate      int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
    @nLoc_id        int=0,
    @nclentid       int=0,
    @neid           int=0
)
as
/*Params Ini begin*/
if @nBillid is null  SET @nBillid = -1
if @nMode is null  SET @nMode = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @nLoc_id is null  SET @nLoc_id = 0
/*Params Ini end*/
/*set nocount on*/
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
  
  if @nYClassID=''  select  @nYClassID='%%' else select @nYClassID=@nYClassID+'%'
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


/*---------------------------机构发货成本表[只能查询本机构]*/
  if @nMode=3
  begin

   SELECT billid,billdate,billnumber,note,summary,B_CustomName1, B_CustomName2, B_CustomName3,
		  isnull(Y.[NAME],'')cname,isnull(E.[name],'')ename,invoicetype,
          inputman,isnull(IE.[Name],'')inputmanname,billtype, isnull(Y.Class_id,'')YClass_id,isnull(Y.[name],'')Yname ,        
          ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [quantity] else -PD.[quantity] end), 0) AS [quantity],
          ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [costprice]*  [quantity] else -([costprice]*[quantity]) end), 0) AS [costtotal],
		  ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [taxtotal] else -taxtotal end), 0) AS [taxtotal],
		  ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [retailtotal] else -retailtotal end), 0) AS [retailtotal],
		  ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [totalmoney] else -totalmoney end), 0) AS [total],
          ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [SendQTY] else -SendQTY end), 0) AS [SendQTY],
          ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN cast(totalmoney/quantity*[SendQTY] as numeric(25,8)) else -cast(totalmoney/quantity*[SendQTY] as numeric(25,8)) end), 0) AS [SendTotal],
          CAST(ISNULL(SUM(CASE WHEN [billtype] IN (150,152) THEN [SendCostTotal] else -(YCostPrice*SendQty) end), 0) AS numeric(25,8)) AS [SendCostTotal],
          0.00 AS OtherQuantity, 0.00 AS OtherCost,isnull(U.name,'')receivename,
          '' as factory,0.00 as costtaxprice,0.00 as costtaxtotal
     FROM  (select b.billid,b.billdate,b.billnumber,b.note,b.summary,b.c_id,b.e_id,b.inputman,b.billtype,b.invoice,b.Y_id,b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,
                   sm.ss_id,sm.quantity,sm.costprice,sm.taxtotal,sm.retailtotal,sm.totalmoney,sm.SendQTY,sm.SendCosttotal,sm.YCostPrice,
                   invoicetype=(                                                                                          
                   case b.invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
                   sm.costtaxprice,sm.costtaxrate,sm.costtaxtotal,sm.factory
              from FilterSalemanagebill(@nloginEID) sm 
                left join  billidx b  ON sm.bill_id=B.billid
             where  b.billtype in (150,151,152,153) and (b.billdate between @begindate and @enddate) and sm.p_id>0 
                    and b.billstates='0' and sm.aoid in(0,5) and (@nLoc_id=0 or sm.Location_id=@nLoc_id)
           )PD
		   Left join Clients   C  ON PD.c_id=C.Client_id
		   left join employees E  ON PD.e_id=E.emp_id
		   left join employees IE ON PD.inputman=IE.emp_id
		   left join Company   Y  ON Y.Company_id=PD.Y_id
		   left join company   U  ON U.company_id=PD.c_id
    WHERE ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
      AND  ( (@nclentid=0) or (U.company_id=@nclentid))
      AND (@neid = 0 OR @neid = PD.E_id)
      /*AND ((@employeestable=0) OR (PD.E_id in (select [id] from #employeestable)))*/
      AND ((@Storetable=0) OR (PD.ss_id in (select [id] from #storagestable))) 
      AND  Y.Class_id like @nYClassID

    GROUP BY billid,billdate,billnumber,note,summary,c.[name],e.[name],inputman,IE.[name],billtype,invoicetype,Y.Class_id,Y.[name], B_CustomName1, B_CustomName2, B_CustomName3,U.name

	return 0
  end

/*---------------------------机构发货成本明细表*/
  if @nMode=4
  begin
    SELECT b.billdate,isnull(c.[name],'')cname,b.billnumber,isnull(p.[name],'')pname,isnull(s.[name],'')sname,b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,
           p.standard,p.makearea, pd.batchno,pd.costprice,pd.taxprice,pd.price,abs(pd.quantity)quantity,
           abs(pd.costtotal) costtotal, abs(pd.taxtotal)taxtotal, abs(pd.total)total,0 as serialno,
           pd.costtaxprice,abs(pd.costtaxtotal) as costtaxtotal,pd.factory as factory
    FROM billidx b 
      INNER join FilterProductdetail(@nloginEID) pd  on b.billid=pd.billid and pd.y_id=2
      left  join products      p   on pd.p_id = p.product_id
      left  join Clients       C   on C.Client_id=b.c_id
      left  join storages      S   on S.storage_id=pd.s_id
    WHERE   ((@Companytable=0)or (b.Y_id in (select [id] from #Companytable))) 
          AND ((@employeestable=0) OR (b.E_id in (select [id] from #employeestable)))
          AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) 
          AND b.billid=@nbillid and pd.aoid in(0,5)
  return 0
  end
/*--------------------------采购成本表*/
  if @nMode=1
  begin
    SELECT billid,billdate,billnumber,note,summary,
           B_CustomName1, B_CustomName2, B_CustomName3,
           isnull(C.[NAME],'')cname,isnull(E.[name],'')ename,isnull(Y.Class_id,'')YClass_id,isnull(Y.[name],'')Yname ,
           inputman,isnull(IE.[Name],'')inputmanname,billtype,
           invoicetype=(
                   case invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
           ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[quantity] else -PD.[quantity] end), 0) AS [quantity],
           ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[costprice]*PD.[quantity] else -(PD.[costprice]*PD.[quantity]) end), 0) AS [costtotal],
		   ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[taxtotal] else -PD.taxtotal end), 0) AS [taxtotal],
	       ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[retailtotal] else -PD.retailtotal end), 0) AS [retailtotal],
		   ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[totalmoney] else -PD.totalmoney end), 0) AS [total],
		   ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[SendQTY] else -PD.SendQTY end), 0) AS [SendQTY],
           ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN cast(PD.totalmoney/PD.quantity*PD.[SendQTY] as numeric(25,8)) else -cast(PD.totalmoney/PD.quantity*PD.[SendQTY] as numeric(25,8)) end), 0) AS [SendTotal],
           ISNULL(SUM(CASE WHEN [billtype] IN (20,35,122,220,24) THEN PD.[SendCostTotal] else -PD.SendCostTotal end), 0) AS [SendCostTotal],
           0.00 AS OtherQuantity, 0.00 AS OtherCost,'' as receivename,
           0.00 as costtaxprice,0.00 as costtaxtotal,
           ISNULL(pd.factory,'') as factory
      FROM (select b.billid,b.billdate,b.billnumber,b.note,b.summary,b.c_id,b.e_id,b.inputman,b.billtype,b.invoice,b.Y_id,
                   b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,
                   sm.ss_id,sm.quantity,sm.costprice,sm.taxtotal,sm.retailtotal,sm.totalmoney,sm.SendQTY,sm.SendCosttotal,
                   f.AccountComment as factory,sm.costtaxprice,sm.costtaxtotal
              from buymanagebill sm 
                left join  billidx b  ON sm.bill_id=B.billid
                left join  AccountComment f on sm.factoryid=f.CommID
             where (b.billdate between @begindate and @enddate) and sm.p_id>0 and b.billtype in (20,21,35,122,220,221,24,25) and b.billstates='0' and sm.aoid in(0,5)
                 )PD
       Left join Clients   C  ON PD.c_id=C.Client_id
       left join employees E  ON PD.e_id=E.emp_id
       left join employees IE ON PD.inputman=IE.emp_id
       left join Company   Y  ON Y.Company_id=PD.Y_id
     WHERE ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
      AND   Y.Class_id like @nYClassID
      AND  ((@employeestable=0) OR (PD.E_id in (select [id] from #employeestable)))
      AND ((@Storetable=0) OR (PD.ss_id in (select [id] from #storagestable)))      
       /*-加入往来单位,经手人*/
       and ((@nclentid=0) or (PD.c_id=@nclentid))
       and ((@neid =0) or (PD.e_id=@neid )) 
     GROUP BY billid,billdate,billnumber,note,summary,B_CustomName1, B_CustomName2, B_CustomName3,
              c.[name],e.[name],inputman,IE.[name],billtype,invoice,Y.Class_id,Y.[name],pd.factory

    return 0
  end
/*-----------------销售成本表*/
  if @nMode=-1
  begin
    SELECT billid,billdate,billnumber,note,summary,B_CustomName1, B_CustomName2, B_CustomName3,
           isnull(C.[NAME],'')cname,isnull(E.[name],'')ename,isnull(Y.Class_id,'')YClass_id,isnull(Y.[name],'')Yname ,
           inputman,isnull(IE.[Name],'')inputmanname,billtype,
           invoicetype=(
                   case invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[quantity] else -PD.[quantity] end), 0) AS [quantity],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[costprice]*PD.[quantity] else -(PD.[costprice]*PD.[quantity]) end), 0) AS [costtotal],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[taxtotal] else -PD.taxtotal end), 0) AS [taxtotal],
    	   ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[retailtotal] else -PD.retailtotal end), 0) AS [retailtotal],
	       ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[totalmoney] else -PD.totalmoney end), 0) AS [total],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[SendQTY] else -PD.SendQTY end), 0) AS [SendQTY],
           ISNULL(SUM(CASE WHEN PD.Quantity <> 0 THEN (CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN cast(PD.totalmoney/PD.quantity*PD.[SendQTY] as numeric(25,8)) else -cast(PD.totalmoney/PD.quantity*PD.[SendQTY] as numeric(25,8)) END) ELSE 0 END), 0) AS [SendTotal],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[SendCostTotal] else -PD.SendCostTotal end), 0) AS [SendCostTotal],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[OtherQuantity] else -PD.[OtherQuantity] end), 0) AS [OtherQuantity],
           ISNULL(SUM(CASE WHEN [billtype] IN (10,12,32,112,53,16,210) THEN PD.[OtherCost]*PD.[OtherQuantity] else -(PD.[OtherCost]*PD.[OtherQuantity]) end), 0) AS [OtherCost]
           ,'' as receivename,'' as factory,0.00 as costtaxprice,0.00 as costtaxtotal  
      FROM  (select b.billid,b.billdate,b.billnumber,b.note,b.summary,b.c_id,b.e_id,b.inputman,b.billtype,b.invoice,b.Y_id,
					b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,	
                   sm.ss_id,
                   CASE WHEN sm.aoid <> 7 THEN sm.quantity ELSE 0 END AS quantity,
                   CASE WHEN sm.aoid <> 7 THEN sm.costprice ELSE 0 END AS costprice,
                   CASE WHEN sm.aoid <> 7 THEN sm.taxtotal ELSE 0 END AS taxtotal,
                   CASE WHEN sm.aoid <> 7 THEN sm.retailtotal ELSE 0 END AS retailtotal,
                   CASE WHEN sm.aoid <> 7 THEN sm.totalmoney ELSE 0 END AS totalmoney,
                   CASE WHEN sm.aoid <> 7 THEN sm.SendQTY ELSE 0 END AS SendQTY,
                   CASE WHEN sm.aoid <> 7 THEN sm.SendCosttotal ELSE 0 END AS SendCosttotal,
                   CASE WHEN sm.aoid = 7 THEN sm.quantity ELSE 0 END AS OtherQuantity,
                   CASE WHEN sm.aoid = 7 THEN sm.costprice ELSE 0 END AS OtherCost 
              FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                left join  billidx b  ON sm.bill_id=B.billid
             where   b.billtype in (10,11,12,32,13,112, 53,54,210,211,16,17) and(b.billdate between @begindate and @enddate) and sm.p_id>0 and b.billstates='0' and sm.aoid in(0, 5, 7)
               )PD
       Left join Clients   C  ON PD.c_id=C.Client_id
       left join employees E  ON PD.e_id=E.emp_id
       left join employees IE ON PD.inputman=IE.emp_id
       left join Company   Y  ON Y.Company_id=PD.Y_id
     WHERE  Y.Class_id like @nYClassID
       AND ((@employeestable=0) OR (PD.E_id in (select [id] from #employeestable)))
       AND ((@Storetable=0) OR (PD.ss_id in (select [id] from #storagestable))) 
       AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
       /*-加入往来单位,经手人*/
       and ((@nclentid=0) or (PD.c_id=@nclentid))
       and ((@neid =0) or (PD.e_id=@neid )) 
     GROUP BY billid,billdate,billnumber,note,summary,B_CustomName1, B_CustomName2, B_CustomName3,
              c.[name],e.[name],inputman,IE.[name],billtype,invoice,Y.Class_id,Y.[name]

  return 0
  end
/*-----------------采购销售成本明细*/
  if @nMode=2
  begin
    SELECT billdate,isnull(c.[name],'')cname,billnumber,isnull(p.[name],'')pname,isnull(s.[name],'')sname,
           p.standard,p.makearea,pd.batchno,pd.costprice,pd.taxprice,
           pd.price,abs(pd.quantity) as quantity,abs(pd.costtotal) as costtotal,abs(pd.taxtotal) as taxtotal,
           abs(pd.total) as total,ISNULL(pd.factory,'') as factory,ABS(pd.costtaxtotal) as costtaxtotal,pd.costtaxprice
      FROM
          (select b.billid,b.billdate,b.c_id,b.e_id,b.billnumber,pd.p_id,pd.batchno,pd.s_id,pd.costprice,pd.taxprice,
			      /*b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,*/
                  pd.price,pd.quantity,pd.costtotal,pd.taxtotal,b.Y_id,pd.total,pd.factory,pd.costtaxprice,pd.costtaxtotal
             from billidx b
               INNER join  FilterProductdetail(@nloginEID) pd  on b.billid=pd.billid
            where pd.aoid in (0,5)
           )pd
        left  join products  p   on pd.p_id = p.product_id
        left  join Clients   C   on C.Client_id=pd.c_id
        left  join storages  S   on S.storage_id=pd.s_id
        left  join Company   Y   on Y.Company_id=pd.Y_id
     WHERE  pd.billid=@nbillid 
        AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
        and (@Storetable=0     or Pd.s_id in (select id from #storagestable))
        and (@ClientTable=0    or Pd.c_id in (select id from #Clienttable))
        and (@employeestable=0 or Pd.e_id in (select id from #employeestable))
        and (@Companytable=0   or Pd.Y_id in (select id from #Companytable))

	return 0
  end
GO
