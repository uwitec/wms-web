
create FUNCTION [dbo].[MergeRange] 
(
 @col int
)
RETURNS varchar(1000)
AS
BEGIN
 DECLARE @Result varchar(1000)

 SELECT @Result = ISNULL(@Result + '/', '') + r.name
   from customCategoryMapping rc INNER JOIN customCategory r ON rc.category_id = r.id
  where category_id = @col and rc.deleted=0

 RETURN @Result

END
GO
