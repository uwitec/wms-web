
CREATE PROCEDURE Ts_K_PaymentPlanCreatePaymentRequest(
	@nRET          INT OUTPUT, 
	@szBillIds	   VARCHAR(2000), /*要生成付款申请单的单据billid集合 */
	@szSmb_id      VARCHAR(2000),
	@EId           INT,           /*申请人ID*/
	@YId           INT = 2
)
AS
BEGIN
	/*付款计划列表生成付款申请单*/
	DECLARE @szError VARCHAR(800)
	SET @nRET = 0
	
	IF EXISTS(SELECT 1
	          FROM   (   SELECT p.Bill_Id,p.detail_id FROM PaymentRequestIdx i INNER JOIN PaymentRequestBill p ON i.BillId = p.PaymentRequestId
	                     WHERE  i.BillStates <> '3' 
	                 ) r
	                 INNER JOIN (SELECT CAST([STR] AS INT) AS BillId FROM dbo.[Split](@szBillIds, ',')) a ON r.Bill_Id = a.BillId
	                 INNER JOIN (SELECT CAST([STR] AS INT) AS Smb_id FROM dbo.[Split](@szSmb_id, ',')) c ON c.Smb_id = r.detail_id 
	            /*     INNER JOIN buymanagebill b on r.Bill_Id = b.bill_id and FKflag = 1*/
	                 ) 
	                 
	BEGIN
		/*已经生成过付款申请单的单据不能重复生成付款申请单*/
		SELECT TOP 1 @szError = '单据编号为【' + r.billnumber + '】的' + r.Comment +'商品【' + r.name + '】'+ '已经存在于编号为【' + r.PNumber + '】的付款申请单中，不能重复生成！'
	          FROM   (    SELECT i.BillNumber AS PNumber, p.Bill_Id, b.billnumber, v.Comment,pr.name, pr.product_id
	                       FROM PaymentRequestIdx i INNER JOIN PaymentRequestBill p ON i.BillId = p.PaymentRequestId
							                        INNER JOIN billidx b ON p.Bill_Id = b.billid
							                        INNER JOIN VchType v ON b.billtype = v.Vch_ID 
							                        INNER JOIN buymanagebill bm on b.billid = bm.bill_id
							                        INNER JOIN products pr on pr.product_id = bm.p_id
	                     WHERE  i.BillStates <> '3'
	                 ) r
	                 INNER JOIN (SELECT CAST([STR] AS INT) AS BillId FROM dbo.[Split](@szBillIds, ',')) a ON  r.Bill_Id = a.BillId
	    SET @nRET = -1
		IF @szError IS NULL
			SET @szError = 'szError Is NULL'
		RAISERROR(@szError, 16, 1)
		RETURN -1
	END
	
	/*根据往来单位生成付款申请单*/
	DECLARE @SupplierId INT, @PaymentRequestId INT
	DECLARE @BCount numeric(25,8), @PCount numeric(25,8), @Total numeric(25,8)
	DECLARE @szBillNumber VARCHAR(200)
	
	BEGIN TRAN CreatePaymentBill
	
	DECLARE CreateBill CURSOR  
    FOR
		SELECT s.c_id 
			FROM billidx s 
				INNER JOIN (SELECT CAST([STR] AS INT) AS BillId FROM dbo.[Split](@szBillIds, ',') ) a ON s.billid = a.BillId
				INNER JOIN (SELECT smb_id,bill_id from buymanagebill) b ON a.billid= b.bill_id
				INNER JOIN (SELECT CAST([STR] AS INT) AS Smb_id FROM dbo.[Split](@szSmb_id, ',')) c ON c.Smb_id = b.smb_id 
		GROUP BY s.c_id
	OPEN CreateBill
    FETCH NEXT FROM CreateBill INTO @SupplierId                                                                                                      
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @PaymentRequestId = 0
        EXEC TS_H_CreateBillSN;1 255, 1, NULL, 0, 0, @szBillNumber OUTPUT, @YId
        
        INSERT INTO PaymentRequestIdx
        (BillDate, BillNumber, BillType, BillStates, C_Id, E_Id, B_Id, B_AuditDate,
         Z_Id, Z_AuditDate, A_Id, PCount, Total, Comment, YId, CreateDate, PaymentBillId)
        VALUES
        (CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, 255, 0, @SupplierId, @EId, 0, '1900-01-01', 
         0, '1900-01-01', 0, 0, 0, '', @YId, GETDATE(), 0)
        
        IF @@ERROR <> 0
        BEGIN
        	SET @nRET = -9
        	ROLLBACK TRAN CreatePaymentBill
        	RETURN -9
        END
        SET @PaymentRequestId = @@identity
        
        INSERT INTO PaymentRequestBill(PaymentRequestId, Bill_Id, Comment, YId, detail_ID)
        SELECT @PaymentRequestId, s.billid, '', @YId ,b.smb_id  
			FROM billidx s 
				INNER JOIN (SELECT CAST([STR] AS INT) AS BillId FROM dbo.[Split](@szBillIds, ',') ) a ON s.billid = a.BillId
				INNER JOIN (SELECT smb_id,bill_id from buymanagebill) b ON a.billid= b.bill_id
				INNER JOIN (SELECT CAST([STR] AS INT) AS Smb_id FROM dbo.[Split](@szSmb_id, ',')) c ON c.Smb_id = b.smb_id 
        WHERE s.c_id = @SupplierId
        IF @@ERROR <> 0 
        BEGIN
        	SET @nRET = -9
        	ROLLBACK TRAN CreatePaymentBill
        	RETURN -9
        END
        
        
        SELECT @BCount = COUNT(*) FROM billidx WHERE billid in (SELECT CAST([STR] AS INT) AS BillId FROM dbo.[Split](@szBillIds, ','))
        SELECT @PCount = COUNT(s.p_id), @Total = SUM(CASE WHEN b.billtype IN (20) THEN s.taxtotal ELSE -s.taxtotal END)
          FROM PaymentRequestBill p INNER JOIN buymanagebill s ON p.Detail_id = s.smb_id
                                    INNER JOIN billidx b ON s.bill_id = b.billid 
        WHERE p.PaymentRequestId = @PaymentRequestId
        
        IF @BCount IS NULL
			SET @BCount = 0
        IF @PCount IS NULL
			SET @PCount = 0
		IF @Total IS NULL
			SET @Total = 0
        
        UPDATE PaymentRequestIdx 
			SET BCount = @BCount, PCount = @PCount, Total = @Total 
        WHERE BillId = @PaymentRequestId
        
        FETCH NEXT FROM CreateBill INTO @SupplierId 
    END
    CLOSE CreateBill
    DEALLOCATE CreateBill
		
	COMMIT TRAN CreatePaymentBill
END
GO
