
create proc ts_c_qrGspCheck
(
  @nc_id int,
  @szAlert varchar(300) output

)
/*with encryption*/
as
set nocount on 
declare @szCName varchar(200), @nCheckFJ int

declare @szGSPName1 varchar(200)
declare @szGSPName2 varchar(200)
declare @szGSPName3 varchar(200)
declare @szGSPName4 varchar(200)
declare @szGSPName5 varchar(200)

set @szGSPName1 = '自定义证照号1'
set @szGSPName2 = '自定义证照号2'
set @szGSPName3 = '自定义证照号3'
set @szGSPName4 = '自定义证照号4'
set @szGSPName5 = '自定义证照号5'

select @szGSPName1 = sysvalue from sysconfig where sysname = 'Cer_CustomNo1'
select @szGSPName2 = sysvalue from sysconfig where sysname = 'Cer_CustomNo2'
select @szGSPName3 = sysvalue from sysconfig where sysname = 'Cer_CustomNo3'
select @szGSPName4 = sysvalue from sysconfig where sysname = 'Cer_CustomNo4'
select @szGSPName5 = sysvalue from sysconfig where sysname = 'Cer_CustomNo5'

select @nCheckFJ = CAST(sysvalue as int)  from sysconfigtmp where [sysname] = 'fjGspCtrl'
if @nCheckFJ is null set @nCheckFJ = 0


set @szAlert=''
select @szCName=[name] from clients where client_id=@nc_id and deleted=0
/*

[d1] [datetime] NOT NULL ,--许可证
[d2] [datetime] NOT NULL ,--执照
[d3] [datetime] NOT NULL ,--协议
[d4] [datetime] NOT NULL ,
[d5] [datetime] NOT NULL ,
[d6] [datetime] NOT NULL ,
[d7] [datetime] NOT NULL ,
[d8] [datetime] NOT NULL ,
[d9] [datetime] NOT NULL 
*/

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=1)
begin
  set @szAlert='许可证'
end
if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=4)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、营业执照'
  else
    set @szAlert='营业执照'
end
if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=5)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、质量保证协议'
  else
    set @szAlert='质量保证协议'
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=3)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、组织机构代码证'
  else
    set @szAlert='组织机构代码证'
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=6)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、' + @szGSPName1
  else
    set @szAlert= @szGSPName1
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=7)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、' + @szGSPName2
  else
    set @szAlert=@szGSPName2
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=8)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、' + @szGSPName3
  else
    set @szAlert=@szGSPName3
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=9)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、' + @szGSPName4
  else
    set @szAlert=@szGSPName4
end

if exists (select * from ClientReport2 where c_id=@nc_id and validTime<convert(varchar(10),getdate(),20) and validTime>10 and rpn_id=10)
begin
  if @szAlert<>''
    set @szAlert=@szAlert+'、' + @szGSPName5
  else
    set @szAlert=@szGSPName5
end

if @szAlert<>''
begin
  set @szAlert='往来单位【'+@szCName+'】的'+char(13)+char(10)+@szAlert+char(13)+char(10)+'已经过期，不能进行此业务！'  
  return 0
end  
  
if @nCheckFJ = 1 
begin 
	if exists (select 1 from GspTable where szid= cast(@nc_id as varchar(10)) and GspType =2202 and checkflag = 0)
	begin
	  set @szAlert='首营企业审批表'
	end
	
	if exists (select 1 from GspTable where szid= cast(@nc_id as varchar(10)) and GspType =2260 and checkflag = 0)
	begin
	  if @szAlert<>''
		set @szAlert=@szAlert+'、顾客资格审核表'
	  else
		set @szAlert='顾客资格审核表'
	end
	
  if @szAlert<>''
    set @szAlert='往来单位【'+@szCName+'】的'+char(13)+char(10)+@szAlert+char(13)+char(10)+'审批结果不合格，不能进行此业务！' 	
end
  
return 0
GO
