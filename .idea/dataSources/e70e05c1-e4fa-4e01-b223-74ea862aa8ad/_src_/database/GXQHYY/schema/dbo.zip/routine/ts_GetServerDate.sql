

CREATE PROCEDURE ts_GetServerDate 
(
  @Date DateTime out
)
AS
SET @Date = GetDate()
GO
