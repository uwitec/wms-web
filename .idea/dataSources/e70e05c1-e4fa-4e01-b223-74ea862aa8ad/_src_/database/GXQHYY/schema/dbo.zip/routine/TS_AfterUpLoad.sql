

CREATE  PROCEDURE [dbo].[TS_AfterUpLoad] 
  @PosID int
AS
BEGIN  
	SET NOCOUNT ON

/*XXX.这儿都不传到总部了，直接用dts 表处理*/
/*	
 delete table DownBillLog where y_id = @PosID
 insert into DownBillLog(BillGuid,YGuid,BillType,y_id)
 select BillGuid,YGuid,BillType,y_id from DownBillLog_dts
*/	
 /*XXX.2017-04-01 更新没有下传成功单据的状态*/
 update billidx set transflag = 0  where billtype in (150,152) and GUID in (select billguid from DownBillLog_dts)
 
 /*XXX.2017-04-24 店间调拨单没传输成功，重置总部的传输标记 begin*/
 /*更新传到收货方的状态*/
 update billdraftidx set transflag = 0 from DownBillLog_dts d where billstates = 3 and transflag = 1 and GUID = BillGuid and c_id = d.y_id

 /*更新传回发货方的状态*/
 update billdraftidx set transflag = 1 from DownBillLog_dts d where billstates = 0 and transflag = 3 and GUID = BillGuid and billdraftidx.Y_ID = d.y_id
 
 /*end*/
 
 truncate table DownBillLog_dts
  

  /*清除机构发货单的日志,传输状态用传回来的收货单来更新 */
  DELETE FROM BillLog WHERE Billtype IN (150)

  DECLARE @PosType INT
  SELECT @PosType = ISNULL(Ytype,-1) FROM company WHERE company_id = @PosID
  
  DECLARE @s_id INT  /*总部默认仓库 */
  DECLARE @e_id INT  /*总部默认经手人                  */
  SELECT @s_id = IsNull(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'CenterSID' AND Y_ID = 2  
  SELECT @e_id = IsNull(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'CenterEID' AND Y_ID = 2 

  /*处理同时会上传和下载的表billlog*/
  delete from billlog where billguid in (select billguid from billlog_dts)
  insert into billlog(BillGuid, Bill_ID, BillType, UpOrDown, y_id, Status, ErrCount, InDateTime, Errflag, p_id, BillNumber, BillDate, transflag)
    select BillGuid, Bill_ID, BillType, UpOrDown, y_id, Status, ErrCount, InDateTime, Errflag, p_id, BillNumber, BillDate, 1 from billlog_dts
    
  /*接收新品申请单*/
  DELETE FROM NewProductsApplyRec WHERE RowGuid IN (SELECT RowGuid FROM NewProductsApplyRec_dts)
  INSERT INTO NewProductsApplyRec(alias, AppNum, ArrivalNum, Comment, DFlag, Factory, InPutDate, InputEID, InputYID, makearea, name, pack, PackStd, permitcode, pid, RecState, RegisterNo, RowGuid, standard, trademark, ValideDate, TransFlag)
    SELECT alias, AppNum, ArrivalNum, Comment, DFlag, Factory, InPutDate, InputEID, InputYID, makearea, name, pack, PackStd, permitcode, pid, RecState, RegisterNo, RowGuid, standard, trademark, ValideDate, TransFlag FROM NewProductsApplyRec_dts
  TRUNCATE TABLE NewProductsApplyRec_DTS 
  
  /*接收零售异常销售*/
  DELETE FROM AbnormalActLog WHERE RowGuid IN (SELECT RowGuid FROM AbnormalActLog_dts)
  INSERT INTO AbnormalActLog(EID, ActionTag, VchID, PID, ActionType, OldValue, NewValue, ActFlag, FEID, Computer, ActionDate, Comment, BillNumber, AID, transflag, RowGuid)
	SELECT EID, ActionTag, VchID, PID, ActionType, OldValue, NewValue, ActFlag, FEID, Computer, ActionDate, Comment, BillNumber, AID, transflag, RowGuid FROM AbnormalActLog_dts
	

 /*有数据上传才清除*/
 if exists(select 1 from StoreHouse_dts where Y_ID <> 2 and Y_ID  = @PosID)	
 begin 
	  delete storehouse where Y_ID <> 2 and Y_ID  = @PosID and md_stid  = 0           
	  update StoreHouse set s_id= t.s_id, location_id= t.location_id, p_id= t.p_id,
		supplier_id=t.supplier_id , quantity =t.quantity, costprice= t.costprice, costtotal=t.costtotal, 
		batchno= t.batchno, makedate =t.makedate, instoretime = t.instoretime, validdate = t.validdate, commissionflag= t.commissionflag,
		Y_ID = t.Y_ID, BatchBarCode= t.BatchBarCode, batchprice = t.batchprice, costtaxprice = t.costtaxprice,
		costtaxtotal = t.costtaxtotal, factoryid = t.factoryid, taxrate= t.taxrate 
		from storehouse s, StoreHouse_dts t where s.md_stid=t.storehouse_id and s.Y_ID = @PosID and s.Y_ID <> 2 and t.y_id = @posid and
			 (s.s_id <> t.s_id or s.p_id<>t.p_id or s.batchno <> t.batchno or s.quantity <>t.quantity or s.costprice <> t.costprice or 
			 s.makedate <> t.makedate or s.validdate <> t.validdate or s.instoretime <> t.instoretime)              
	  
	  DELETE FROM StoreHouse WHERE Y_ID  <> 2 and Y_ID  = @PosID  and md_stid not in (select storehouse_id from StoreHouse_dts where Y_ID  = @PosID)
	  DELETE FROM StoreHouse_dts WHERE Y_ID  <> 2 and Y_ID  = @PosID  and storehouse_id in (select md_stid from StoreHouse where Y_ID  = @PosID)  
	  
	  INSERT INTO StoreHouse(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, 
						  SendFlag, BatchBarCode, scomment, batchprice, costtaxprice, costtaxtotal, factoryid, taxrate, md_stid)
		SELECT location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, 
						  SendFlag, BatchBarCode, scomment, batchprice, costtaxprice, costtaxtotal, factoryid, taxrate, storehouse_id
		FROM StoreHouse_dts WHERE Y_ID = @PosID and Y_ID  <> 2
 end		
  
 /*XXX.2016-12-20 门店有期初的时候上传期初库存*/
 if exists(select 1 from storehouseini_dts where  Y_ID  = @PosID)	
 begin 
	  delete storehouseini where  Y_ID  = @PosID and md_shid  = 0            	  
	  DELETE FROM storehouseini_dts WHERE  Y_ID  <> @PosID  
	  
	  update storehouseini set s_id= t.s_id, location_id= t.location_id, p_id= t.p_id,
		supplier_id=t.supplier_id , quantity =t.quantity, costprice= t.costprice, costtotal=t.costtotal, 
		batchno= t.batchno, makedate =t.makedate, instoretime = t.instoretime, validdate = t.validdate, commissionflag= t.commissionflag,
		Y_ID = t.Y_ID, BatchBarCode= t.BatchBarCode, batchprice = t.batchprice, costtaxprice = t.costtaxprice,
		costtaxtotal = t.costtaxtotal, factoryid = t.factoryid, taxrate= t.taxrate 
		from storehouseini s, storehouseini_dts t where s.md_shid=t.storehouseini_id and s.Y_ID = @PosID and  t.y_id = @posid and
			 (s.s_id <> t.s_id or s.location_id <>t.location_id or s.p_id<>t.p_id or s.supplier_id <> t.supplier_id or 
			  s.batchno <> t.batchno or s.quantity <>t.quantity or s.costprice <> t.costprice or s.costtotal <> t.costtotal or
			  s.costtaxprice <> s.costtaxprice or s.costtaxtotal <> t.costtaxtotal or s.BatchBarCode <> t.BatchBarCode or
			  s.batchprice <> t.batchprice or s.factoryid <> t.factoryid or s.taxrate <> t.taxrate or
			  s.makedate <> t.makedate or s.validdate <> t.validdate or s.instoretime <> t.instoretime)              
	  
	  DELETE FROM storehouseini WHERE Y_ID  = @PosID  and md_shid not in (select storehouseini_id from storehouseini_dts where Y_ID  = @PosID)
	  DELETE FROM StoreHouseini_dts WHERE  Y_ID  = @PosID  and storehouseini_id in (select md_shid from StoreHouseini where Y_ID  = @PosID)  
	  
	  INSERT INTO StoreHouseini(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID, BatchBarCode, 
                      scomment, batchprice, factoryid, taxrate, costtaxprice, costtaxtotal, md_shid)
		SELECT location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID, BatchBarCode, 
                      scomment, batchprice, factoryid, taxrate, costtaxprice, costtaxtotal, storehouseini_id
		FROM storehouseini_dts WHERE Y_ID = @PosID 
 end  
 
TRUNCATE TABLE storehouseini_dts
 
 /*XXX.2016-12-21 上传其它期初库存*/
 if exists(select 1 from OtherStorehouseini_dts where  Y_ID  = @PosID)	
 begin 
	  delete OtherStorehouseini where  Y_ID  = @PosID and md_oshid  = 0            	  
	  DELETE FROM OtherStorehouseini_dts WHERE  Y_ID  <> @PosID  
	  
	  update OtherStorehouseini set s_id= t.s_id, location_id= t.location_id, p_id= t.p_id,
		supplier_id=t.supplier_id , quantity =t.quantity, costprice= t.costprice, costtotal=t.costtotal, 
		batchno= t.batchno, makedate =t.makedate, instoretime = t.instoretime, validdate = t.validdate, commissionflag= t.commissionflag,
		Y_ID = t.Y_ID, BatchBarCode= t.BatchBarCode, batchprice = t.batchprice,AOID = t.AOID 
		from OtherStorehouseini s, OtherStorehouseini_dts t where s.md_oshid=t.OtherStorehouseini_id and s.Y_ID = @PosID and  t.y_id = @posid and
			 (s.s_id <> t.s_id or s.location_id <>t.location_id or s.p_id<>t.p_id or s.supplier_id <> t.supplier_id or 
			  s.batchno <> t.batchno or s.quantity <>t.quantity or s.costprice <> t.costprice or s.costtotal <> t.costtotal or
			   s.BatchBarCode <> t.BatchBarCode or
			  s.batchprice <> t.batchprice or s.AOID = t.AOID or
			  s.makedate <> t.makedate or s.validdate <> t.validdate or s.instoretime <> t.instoretime)              
	  
	  DELETE FROM OtherStorehouseini WHERE Y_ID  = @PosID  and md_oshid not in (select otherstorehouseini_id from OtherStorehouseini_dts where Y_ID  = @PosID)
	  DELETE FROM OtherStorehouseini_dts WHERE  Y_ID  = @PosID  and OtherStorehouseini_id in (select md_oshid from OtherStorehouseini where Y_ID  = @PosID)  
	  
	  INSERT INTO OtherStorehouseini(location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID, BatchBarCode, 
                      scomment, batchprice, md_oshid)
		SELECT location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID, BatchBarCode, 
                      scomment, batchprice, OtherStorehouseini_id
		FROM OtherStorehouseini_dts WHERE Y_ID = @PosID 
 end  
TRUNCATE TABLE OtherStorehouseini_dts 
 
  
  /*门店,加盟店,内部机构上传业务*/
  IF @PosType IN (1,2,3)
  begin
    /*盘点计划*/
    DELETE FROM pdplanidx WHERE guid IN (SELECT guid from pdplanidx_dts) 
    DELETE FROM pdplan WHERE pdidx NOT IN (SELECT pdidx FROM pdplanidx)  
    
    INSERT INTO pdplanidx(billdate, inputman, k_id, billstates, Y_Id, UsePDA, NoBatch, Guid, TransFlag)
      SELECT billdate, inputman, k_id, billstates, 2, UsePDA, NoBatch, Guid, 2 FROM pdplanidx_dts
    INSERT INTO pdplan(pdidx, location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, spQuantity, PKQuantity, PYQuantity, PDFlag, BatchBarCode, scomment, batchprice, inputdate, RowGuid)
      SELECT (SELECT pdidx FROM pdplanidx WHERE guid=(SELECT guid FROM pdplanidx_Dts WHERE pdidx=pdplan_Dts.pdidx) ),
             location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, yhdate, Y_ID, spQuantity, PKQuantity, PYQuantity, PDFlag, BatchBarCode, scomment, batchprice, inputdate, RowGuid
        FROM pdplan_Dts 
        
    TRUNCATE TABLE pdplanidx_dts
    TRUNCATE TABLE PdPlan_dts 

    /*过帐前 加盟店机构类单据，先将仓库替换为总部默认仓库*/
    if @PosType IN (2)
    begin
      UPDATE BillIdx_Dts SET sin_id=@s_id WHERE billtype IN (150,151,152,153,160,161,162,163)
      UPDATE tranidx_Dts set e_id = @e_id,inputman = @e_id
    end 
    
   
    /*处理单据的自动过账和红冲*/
    Exec TS_H_DtsUpBillDeal
  
    /*处理日结表*/
    DELETE FROM DayAccount WHERE guid IN (SELECT guid FROM DayAccount_Dts)
  
    INSERT INTO DayAccount(Y_ID, BeginDate, EndDate, PosRetailQty, PosRetailTotal, PosBackQty, PosBackTotal, ZBRetailQty, ZBRetailTotal, ZBBackQty, ZBBackTotal, ifValidate, ifDayAccount, GUID, transflag) 
      select Y_ID, BeginDate, EndDate, PosRetailQty, PosRetailTotal, PosBackQty, PosBackTotal, ZBRetailQty, ZBRetailTotal, ZBBackQty, ZBBackTotal, ifValidate, ifDayAccount, GUID, transflag FROM DayAccount_Dts
    INSERT INTO DayAccountDetail(DA_ID, Y_ID, a_id, Total, GUID)
      SELECT (SELECT ID FROM DayAccount WHERE guid=(SELECT guid FROM DayAccount_Dts WHERE ID=DayAccountDetail_Dts.da_ID) ),
             Y_ID, a_id, Total, GUID
        FROM DayAccountDetail_Dts
    /*先插入后再进行删除     */
    DELETE FROM DayAccountDetail WHERE DA_ID NOT IN (SELECT ID FROM DayAccount)
      
    TRUNCATE TABLE DayAccount_Dts
    TRUNCATE TABLE DayAccountDetail_Dts  
    
    /*接收请货单*/
    DELETE FROM tranidx WHERE guid IN (SELECT guid FROM tranidx_Dts)
    DELETE FROM tranbill WHERE bill_id NOT IN (SELECT billid FROM tranidx)
  
    INSERT INTO tranidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, InvoiceTotal, InvoiceNO, BusinessType, GUID, ArAptotal, SendQTY, GatheringMan, Y_ID) 
      select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, InvoiceTotal, InvoiceNO, BusinessType, GUID, ArAptotal, SendQTY, GatheringMan, Y_ID FROM tranidx_Dts
    INSERT INTO tranbill(bill_id, p_id, quantity, retailprice, retailmoney, ComeQty, ComeDate, comment, unitid, RowGuid, Y_ID, Conclusion,factoryid)
      SELECT (SELECT billid FROM tranidx WHERE guid=(SELECT guid FROM tranidx_Dts WHERE billid=tranbill_Dts.bill_id) ),
             p_id, quantity, retailprice, retailmoney, ComeQty, ComeDate, comment, unitid, RowGuid, Y_ID, Conclusion,factoryid
        FROM tranbill_Dts 
  
    TRUNCATE TABLE tranidx_Dts
    TRUNCATE TABLE tranbill_Dts 
 
    /*对账二级明细表 select * from [reconciliationResult]*/
    DELETE FROM reconciliationResult WHERE plan_id IN (SELECT plan_id FROM reconciliationDetail_dts d WHERE reconciliationResult.plan_id=d.plan_id AND reconciliationResult.y_id=d.y_id  AND reconciliationResult.isRemote=d.isRemote)
                                       AND y_id IN (SELECT y_id FROM reconciliationDetail_dts d WHERE reconciliationResult.plan_id=d.plan_id AND reconciliationResult.y_id=d.y_id  AND reconciliationResult.isRemote=d.isRemote)
                                       AND isRemote IN (SELECT isRemote FROM reconciliationDetail_dts d WHERE reconciliationResult.plan_id=d.plan_id AND reconciliationResult.y_id=d.y_id  AND reconciliationResult.isRemote=d.isRemote)
    INSERT INTO reconciliationResult(plan_id, y_id, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, payIn, isRemote, TransFlag)
      SELECT plan_id, y_id, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, payIn, isRemote, 2 FROM reconciliationResult_dts
    
    TRUNCATE TABLE reconciliationResult_dts

    /*对账三级明细表  */
    DELETE FROM reconciliationDetail WHERE plan_id IN (SELECT plan_id FROM reconciliationDetail_dts d WHERE reconciliationDetail.plan_id=d.plan_id AND reconciliationDetail.y_id=d.y_id AND reconciliationDetail.billDate=d.billDate AND reconciliationDetail.isRemote=d.isRemote)
                                       AND y_id IN (SELECT y_id FROM reconciliationDetail_dts d WHERE reconciliationDetail.plan_id=d.plan_id AND reconciliationDetail.y_id=d.y_id AND reconciliationDetail.billDate=d.billDate AND reconciliationDetail.isRemote=d.isRemote)
                                       AND billDate IN (SELECT billDate FROM reconciliationDetail_dts d WHERE reconciliationDetail.plan_id=d.plan_id AND reconciliationDetail.y_id=d.y_id AND reconciliationDetail.billDate=d.billDate AND reconciliationDetail.isRemote=d.isRemote)
                                       AND isRemote IN (SELECT isRemote FROM reconciliationDetail_dts d WHERE reconciliationDetail.plan_id=d.plan_id AND reconciliationDetail.y_id=d.y_id AND reconciliationDetail.billDate=d.billDate AND reconciliationDetail.isRemote=d.isRemote)  
    INSERT INTO reconciliationDetail(plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag)  
      SELECT plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, 2 FROM reconciliationDetail_dts
         
    TRUNCATE TABLE reconciliationDetail_dts

    /*生成门店对账报表*/
    exec TS_L_CompareOfCompanySale @PosID,0

    /*如果全部完成更新对账计划*/
    UPDATE reconciliationPlan SET TransFlag = 1 
      where not EXISTS(SELECT * from reconciliationResult r WHERE r.TransFlag = 0 AND reconciliationPlan.plan_id = r.plan_id)

    /*接收缺货单*/
    DELETE FROM zerostockidx WHERE guid IN (SELECT guid FROM zerostockidx_Dts)
    DELETE FROM ZeroStockBill WHERE bill_id NOT IN (SELECT billid FROM zerostockidx)
  
    INSERT INTO zerostockidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, region_id, auditdate, jsflag, note, summary, Y_ID, guid)
      SELECT billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, quantity, period, billstates, order_id, department_id, posid, region_id, auditdate, jsflag, note, summary, Y_ID, guid FROM zerostockidx_Dts
    INSERT INTO ZeroStockBill(bill_id, p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, comment2, aoid, Y_ID, Conclusion)
      SELECT (SELECT billid FROM zerostockidx WHERE guid=(SELECT guid FROM zerostockidx_Dts WHERE billid=ZeroStockBill_Dts.bill_id) ),
             p_id, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, quantity, ss_id, sd_id, unitid, ComeDate, ComeQty, JSFlag, comment, comment2, aoid, Y_ID, Conclusion
        FROM ZeroStockBill_Dts 
  
    TRUNCATE TABLE zerostockidx_Dts
    TRUNCATE TABLE ZeroStockBill_Dts
    
  end  
  
  /*分公司上传业务*/
  else IF @PosType IN (0)
  BEGIN
  	/*接收请货单*/
    DELETE FROM tranidx WHERE guid IN (SELECT guid FROM tranidx_Dts)
    DELETE FROM tranbill WHERE bill_id NOT IN (SELECT billid FROM tranidx)
  
    INSERT INTO tranidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, InvoiceTotal, InvoiceNO, BusinessType, GUID, ArAptotal, SendQTY, GatheringMan, Y_ID) 
      select billdate, billnumber, billtype, a_id, @PosID, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, InvoiceTotal, InvoiceNO, BusinessType, GUID, ArAptotal, SendQTY, GatheringMan, @PosID FROM tranidx_Dts
    INSERT INTO tranbill(bill_id, p_id, quantity, retailprice, retailmoney, ComeQty, ComeDate, comment, unitid, RowGuid, Y_ID, Conclusion,factoryid)
      SELECT (SELECT billid FROM tranidx WHERE guid=(SELECT guid FROM tranidx_Dts WHERE billid=tranbill_Dts.bill_id) ),
             p_id, quantity, retailprice, retailmoney, ComeQty, ComeDate, comment, unitid, RowGuid, @PosID, Conclusion,factoryid
        FROM tranbill_Dts 
  
    TRUNCATE TABLE tranidx_Dts
    TRUNCATE TABLE tranbill_Dts   

	/*处理分公司发货退货单*/
	UPDATE billidx_dts SET c_id = @PosID WHERE billtype IN (161)

    /*处理单据的自动过账和红冲*/
    Exec TS_H_DtsUpBillDeal
      
  END
  
  /*更改单据确认状态  3为确认*/
  /*UPDATE billidx SET transflag = 3 WHERE GUID IN (SELECT billguid FROM BillLog WHERE Status = 0) */
  /*                                   AND transflag = 1*/
  /*UPDATE billidx SET transflag = 3 FROM billidx b,BillLog bg */
  /*  WHERE b.GUID = bg.BillGuid AND b.billtype = bg.BillType */
  /*    AND b.TransFlag = 1 AND bg.Status = 0*/
  UPDATE billidx SET transflag = 3
  WHERE billid IN (select i.billid from BillLog l
	inner join billidx i
	on l.BillGuid = i.GUID and l.BillType = i.billtype and Status = 0
	and i.TransFlag = 1)

 UPDATE Integralidx SET transflag = 3
  WHERE billguid IN (select i.billguid from Integralidx_dts t
	inner join Integralidx i
	on t.BillGuid = i.billguid and i.transflag = 0)  

  UPDATE billidx SET transflag = 0 WHERE GUID IN (SELECT billguid FROM BillLog WHERE Status <> 0)
                                     AND transflag = 1        
  TRUNCATE TABLE billlog_dts    
   
end
GO
