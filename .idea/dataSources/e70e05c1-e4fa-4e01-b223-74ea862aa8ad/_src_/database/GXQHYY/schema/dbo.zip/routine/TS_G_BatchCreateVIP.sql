

CREATE PROCEDURE TS_G_BatchCreateVIP
  @Sign VARCHAR(50),
  @BeginNum int,
  @Count INT,
  @ct_id INT,
  @ValidDate DATETIME,
  @y_id INT,
  @e_id INT,
  @Len INT,
  @StopUse INT
AS
BEGIN
  DECLARE @begin INT
  DECLARE @End INT
  DECLARE @NewID INT
  DECLARE @PassWord INT
  DECLARE @Comment VARCHAR(100)
  DECLARE @Zero VARCHAR(20)
  SET @begin=0
  SET @End=0
  SET @NewID=0
  SET @PassWord=0
  SET @Comment='由批量制卡自动生成'
  SET @Zero = '000000000000'
  
  SET @begin = @BeginNum
  SET @End = @BeginNum + @Count
  IF LEN(CAST (@end AS VARCHAR(50))) > @Len
  BEGIN 
  	RETURN -2
  end	
  
  if exists (SELECT * FROM VIPCardType WHERE isBank=1 AND ct_id=@ct_id)
  BEGIN 
    SET @PassWord = 111111
    set @Comment = '由批量制卡自动生成,初始密码为:111111'
  END  
  /*检测编号重复*/
  CREATE TABLE #Tmp (CardNo VARCHAR(50))
  WHILE @begin < @End
  BEGIN
   PRINT @begin
   INSERT INTO #Tmp(CardNo) VALUES (@Sign + right(@Zero+cast (@begin AS VARCHAR(50)),@Len) ) 
   set @begin = @begin + 1 
   
  END 
  DECLARE @TmpCount INT
  SET @TmpCount=0
  /*IF EXISTS (SELECT CardNo FROM VIPCard WHERE CardNo IN (SELECT CardNo FROM #Tmp))*/
  SELECT @TmpCount=IsNull(COUNT(*),0) FROM VIPCard v INNER join #Tmp t ON v.CardNo=t.CardNo
  IF @TmpCount > 0
    BEGIN
      DROP TABLE #Tmp 
      /*RAISERROR('生成的号段有重复',16,1)*/
      RETURN -1
      /*PRINT @TmpCount*/
    END  
  ELSE    
    DROP TABLE #Tmp
  /*批量增加*/
  SET @begin = @BeginNum
  SET @End = @BeginNum + @Count
  select @NewID=IsNull(Max(VIPCardID),0)+1 from VIPCard
  
  WHILE @begin < @End
  BEGIN 
   INSERT INTO VIPCard (VIPCardID, CardNo, Comment, CT_ID, BulidDate, ValidityDate, E_id, 
                        LoginPass, Deleted, StopUse, Y_ID, Pos_Id)
               VALUES(@NewID,
                      @Sign + right(@Zero+cast (@begin AS VARCHAR(50)),@Len),
                      @Comment,
                      @ct_id,
                      GETDATE(),
                      @ValidDate,
                      @e_id,
                      @PassWord,
                      /*cast(@PassWord AS VARBINARY(50)),*/
                      0,
                      @StopUse,
                      @y_id,
                      0                      
                      )         
                
   /*PRINT @Sign + cast (@BeginNum AS VARCHAR(20)) */
   SET @NewID = @NewID + 1
   set @begin = @begin + 1
  END
END
GO
