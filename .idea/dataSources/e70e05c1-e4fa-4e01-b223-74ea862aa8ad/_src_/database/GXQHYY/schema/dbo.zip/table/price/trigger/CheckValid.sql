



CREATE	TRIGGER [CheckValid] ON [dbo].[price]
FOR INSERT
AS
declare @nuid int,@npriceid int
select @nuid=u_id,@npriceid=price_id  from inserted
if @nuid=0 delete from price where price_id=@npriceid
GO
