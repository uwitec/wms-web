




CREATE	 TRIGGER [DeleteDraft] ON [dbo].[billdraftidx]
FOR DELETE
AS

declare @nBilltype int,@nBillid int,@billguid varchar(50)

declare deldraft cursor for
select billtype,billid,guid  from deleted

open deldraft

fetch next from deldraft into @nBilltype,@nBillid,@billguid

while @@fetch_status=0
begin
    if @nBilltype in (10,11,12,13,16,17,110,111,112,32,210,212,211,150,151,152,153)  /*销售*/
    begin
        delete from salemanagebilldrf where bill_id=@nBillid
        if @nbilltype in (12,13) delete from retailmerge where newbillguid=@billguid and draft=1
    end else
    
    if @nBilltype in (20,21,24,25,120,121,122,35,220,222,221,160,161,162,163)	/*-采购*/
    begin
        delete from buymanagebilldrf where bill_id=@nBillid
    end  else
    
    if @nBilltype in (30,31,33,34,40,41,42,43,44,45,46,47,48,49,51,141)  /*库存类单据*/
    begin
        delete from storemanagebilldrf where bill_id=@nBillid
    end  else
    
    if @nBilltype in (50,58)  /*库存盘点单*/
    begin  
        delete from GoodsCheckbilldrf where bill_id=@nBillid
    end  else
    
    if @nBilltype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,87,88,155,165,170)	/*钱流单据*/
    begin
        delete from financebilldrf where bill_id=@nBillid
        if @nBilltype in (15,23,155,165,170)
        begin
          Delete jsbdetail where skd_bid=@nBillid and flag=1
          Delete jspdetail where skd_bid=@nBillid and flag=1
        end
    end  else
    
    if @nBilltype in (53,54,55,56)	/*配送单据*/
    begin
        delete from TranManagebilldrf where bill_id=@nBillid
    end else
    
    if @nBilltype in (184, 185)	/*返利 获利*/
    begin
        delete from Returnbilldrf where bill_id=@nBillid
    end
    if @nBilltype in (44)
		delete from msgcenter where msgtype=1 and billid=@nbillid
	if @nBilltype in (149)	/* 积分兑换单*/
	begin
		delete from ExIntegRalManagebilldrf where billid = @nbillid
	end
  fetch next from deldraft into @nBilltype,@nBillid,@billguid
end

close deldraft
deallocate deldraft
GO
