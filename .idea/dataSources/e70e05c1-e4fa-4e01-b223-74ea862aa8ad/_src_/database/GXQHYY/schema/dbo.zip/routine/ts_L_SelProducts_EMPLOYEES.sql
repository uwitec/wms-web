
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_EMPLOYEES
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

	/*
	--2011-12-22 by zhangke 修正职员大类隶属机构与职员隶属机构不一致导致的大类记录不显示问题，及之后的不包括职员隶属机构的大类记录显示问题
	SELECT a.* 
	FROM   (   SELECT DISTINCT ve.*
	           FROM   vw_Employee ve
	                  INNER JOIN (SELECT * FROM AuthorizeEmployees(@E_id) WHERE Child_Number = 0) u ON LEFT (u.class_id, LEN(ve.class_id)) = ve.class_id
	           WHERE  ve.parent_id = @parent_id
	                  AND (@nShowStatus = 0 OR (@nShowStatus = 1 AND DELETED = 0))
	                  AND (child_count <> 0 OR CAST(Y_ID AS VARCHAR(50)) LIKE(CASE WHEN (@nY_ID = 0) OR (@nFilterY = 0) THEN '%%' ELSE CAST(@nY_ID AS VARCHAR(50)) END))
	                  AND (CASE WHEN ((child_count <> 0) AND (@nFilterY = 1)) THEN 0 ELSE @nFilterY END = 0 OR Y_id = @nY_id)
	       ) a
	WHERE  (   SELECT CASE WHEN a.child_count <> 0 THEN COUNT(*) ELSE 1 END
	           FROM   employees e WHERE  e.parent_id = a.class_id AND e.Y_ID = @nY_id
	       ) > 0
	*/
	IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'BJDZ001' AND sysvalue = '1')
	BEGIN
		IF @nFilterY IN (100001, 100002, 100003, 100004, 100005, 100006, 100007, 100008)
		BEGIN
			/*此时为选择默认职员分类记录*/
			SET @Parent_id = CAST(@nFilterY AS VARCHAR)
		END	
	END
	if (@szWhere <> '') and (((CHARINDEX('and',@szWhere)) = 0) or ((CHARINDEX('and',@szWhere)) > 5))
	  set @szWhere = 'and ' + @szWhere
	
	if @szListFlag='A' /*add by luowei 职员信息全部列表*/
	begin
	 set @Sql = '  select * from vw_Employee ve where  emp_id in (SELECT emp_id FROM AuthorizeEmployees('+cast(@UserId as varchar(20))+') WHERE Child_Number = 0) and deleted <> 1   '+ @szwhere
	 exec(@sql)
	end
	else
	begin
		if (@szWhere <> '') and (@szListFlag = 'S')
		begin
		  /*set @sql = ' select * from vw_Employee where deleted = 0 and child_number = 0 '+ @szwhere*/
                  set @sql = ' select * from vw_Employee ve where  emp_id in (SELECT emp_id FROM AuthorizeEmployees('+cast(@UserId as varchar(20))+') WHERE Child_Number = 0) and deleted <> 1   '+ @szwhere
		end
		else		begin   
		  set @sql = '
					   SELECT DISTINCT ve.*
							FROM   vw_Employee ve
							INNER JOIN (SELECT * FROM AuthorizeEmployees('+cast(@UserId as varchar(20))+') WHERE Child_Number = 0) u ON LEFT (u.class_id, LEN(ve.class_id)) = ve.class_id
							WHERE  ve.parent_id = '''+@parent_id+'''
							AND ('+cast(@nShowStatus as varchar(10))+' = 0 OR ('+cast(@nShowStatus as varchar(10))+' = 1 AND DELETED = 0))
							AND (child_count <> 0 OR CAST(Y_ID AS VARCHAR(50)) LIKE(CASE WHEN ('+cast(@nY_ID as varchar(20))+' = 0) OR ('+cast(@nFilterY as varchar(20))+' = 0) THEN ''%%'' ELSE CAST('+cast(@nY_ID as varchar(20))+' AS VARCHAR(50)) END))
							AND (CASE WHEN ((child_count <> 0) AND ('+cast(@nFilterY as varchar(20))+' = 1)) THEN 0 ELSE '+cast(@nFilterY as varchar(20))+' END = 0 OR Y_id = '+cast(@nY_id as varchar(10))+')' + @szWhere		   
		end 
	/*	print @sql*/
		exec(@sql)      
	end
GO
