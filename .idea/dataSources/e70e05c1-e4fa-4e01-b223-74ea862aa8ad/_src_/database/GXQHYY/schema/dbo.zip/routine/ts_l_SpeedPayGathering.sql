

/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_l_SpeedPayGathering] 
( @nMode int,
  @Begindate datetime,
  @EndDate  datetime,
  @e_id int,
  @roadid int,
  @gatheringman int
)
AS
 
 IF @nMode=0 /*快速收款单*/
 begin
   select b.billdate,b.billnumber,b.auditdate,b.NOTE,b.BILLID,b.c_id,
           (case when b.billtype in (10,210) then b.YSMONEY else -b.ysmoney end)YSMONEY,
           (case when b.billtype in (10,210) then b.JSYE else -b.jsye end)jsye,
           billname=(case when b.billtype=10 then '销售出库单'
                          when b.billtype=210 then '销售单（财务收款）'
                          when b.billtype=11 then '销售出库退货单'
                          else '' end),
          IE.name as inputmanname,
          AE.name as auditmanname,
          e.name  as employeename,
		  gm.name as gatheringman,	         
          (case when b.billtype in (10,210) then b.jsye  else -b.jsye end)JSTOTAL,
          b.billtype as vchtype,
          C.name as Cname
     from billidx b
     LEFT JOIN employees AE  on b.auditman=AE.emp_id
     LEFT JOIN employees IE  on b.inputman=IE.emp_id
     LEFT JOIN employees  E  on b.e_id=e.emp_id
     left join employees gm  on b.GatheringMan=gm.emp_id
     LEFT JOIN Clients    C  on b.C_id=C.Client_id
     where b.billstates=0 and b.billtype in (10,11,210)
       and (b.billdate between @Begindate and @Enddate)
       and (@e_id=0 or b.e_id=@e_id) and (@roadid=0 or c.RoadID in (0,@roadid))
       and (@gatheringman=0 or b.GatheringMan=@gatheringman)
        
 end
GO
