
CREATE FUNCTION GetTcRate
(
	@dTotal     numeric(25,8) = 0,
	@f_ID       INT = 0	
)
RETURNS numeric(25,8)
AS
BEGIN
	DECLARE @TcType    INT
	DECLARE @TcRate    numeric(25,8)
	DECLARE @BeginNum  numeric(25,8)
	DECLARE @EndNum    numeric(25,8)
	DECLARE @Temp      numeric(25,8)
	DECLARE @Re        numeric(25,8)
	
	SET @Temp = 0
	SET @Re = 0
	
	SELECT @TcType = TcType
	FROM   TcFormuLa
	WHERE  Formula_ID = @f_id
	
	DECLARE ForTc      CURSOR  
	FOR
	    SELECT BeginNum,
	           EndNum,
	           tcRate  
	    FROM   TcFormulaMX
	    WHERE  F_id = @f_ID
	    ORDER BY
	           FormulaMX_id
	
	OPEN ForTc
	FETCH NEXT FROM ForTc INTO @BeginNum, @EndNum, @TcRate                                                                                                                                                                                                                                                                             
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    IF @TcType IN (0, 1, 3, 4)
	    BEGIN
	        IF @dTotal > 0
	        BEGIN
	            IF @dTotal >= @BeginNum
	            BEGIN
	                IF @dTotal >= @EndNum
	                BEGIN
	                    SET @Temp = @EndNum - @BeginNum + 1
	                END
	                ELSE
	                BEGIN
	                    SET @Temp = @dTotal - @BeginNum + 1
	                END
	                SET @Re = @Re + (@Temp / 100 * @TcRate)
	            END
	        END
	    END
	    
	    IF @TcType IN (2, 6, 7)
	    BEGIN
	        IF @dTotal > 0
	        BEGIN
	            IF @dTotal >= @BeginNum
	            BEGIN
	                IF @dTotal >= @EndNum
	                BEGIN
	                    SET @Temp = (@EndNum - @BeginNum) + 1
	                END
	                ELSE
	                BEGIN
	                    SET @Temp = (@dTotal - @BeginNum) + 1
	                END
	                SET @Re = @Re + (@Temp * @TcRate)
	            END
	        END
	    END
	    
	    IF @TcType = 5
	    BEGIN
	        IF @dTotal > 0
	        BEGIN
	            IF @dTotal >= @BeginNum
	            BEGIN
	                SET @Re = @Re + @TcRate
	            END
	        END
	    END
	    
	    FETCH NEXT FROM ForTc INTO @BeginNum, @EndNum, @TcRate
	END
	CLOSE ForTc
	DEALLOCATE ForTc
	
	
	RETURN(@Re)
END
GO
