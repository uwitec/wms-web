


CREATE  VIEW dbo.vw_c_ADetail
AS
SELECT dbo.accountdetail.*, isnull(dbo.clients.class_id,'') AS cclass_id, isnull(dbo.clients.serial_number,'') AS serial_number,
      dbo.account.class_id AS aclass_id, isnull(dbo.account.name,'') AS accountname, 
      isnull(dbo.clients.name,'') AS clientname
FROM dbo.account RIGHT OUTER JOIN
      dbo.accountdetail ON 
      dbo.account.account_id = dbo.accountdetail.a_id LEFT OUTER JOIN
      dbo.clients ON dbo.accountdetail.c_id = dbo.clients.client_id
GO
