
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2013-2-20*/
/* Description:	判断权限*/
/* =============================================*/
CREATE FUNCTION _GetSubLimit
(
	@Eid		int,	/*职员*/
	@Limit		int,	/*权限ID*/
	@SubLimit	int = -1	/* 子权限*/
)
RETURNS int
AS
BEGIN
	declare @Result int
	if @SubLimit = -1
	begin
		select @Result = CAST(SUBSTRING(lim, @Limit + 1, 1) AS int) from employees where emp_id = @Eid
	end
	else
		select @Result = CAST(SUBSTRING(lim, @Limit + 1, 1) AS int) & POWER(2, @SubLimit) from employees where emp_id = @Eid

	if @Result > 0
		set @Result = 1
	RETURN @Result
END
GO
