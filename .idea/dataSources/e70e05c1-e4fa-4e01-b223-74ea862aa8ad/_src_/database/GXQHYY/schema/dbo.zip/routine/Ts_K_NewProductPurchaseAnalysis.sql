

CREATE PROCEDURE Ts_K_NewProductPurchaseAnalysis(
	@Begin           DATETIME, 
	@End             DATETIME, 
	@YId             INT, 
	@SupplierId      INT, 
	@EId             INT, 
	@CgIds            VARCHAR(7000), 
	@szID            VARCHAR(3000))    /*这个字段暂时没用,客户端传过来也一直为空*/
AS
BEGIN
	SET @Begin = CAST(CONVERT(varchar(100), @Begin, 23) + ' 00:00:00' AS DATETIME)
	SET @End = CAST(CONVERT(varchar(100), @End, 23) + ' 23:59:59' AS DATETIME)
	
	/*DECLARE @ProductList TABLE (CgId INT, PId INT)*/
	CREATE TABLE #ProductList (CgId INT, PId INT)
	
	IF @CgIds = ''
	BEGIN
		INSERT INTO #ProductList(CgId, PId)
		SELECT 0, product_id FROM vw_Products	
	END
	ELSE
	BEGIN
	/*传过来的参数直接是选择的自定义类别的id，不需要转换*/
		/*DECLARE @ClassId VARCHAR(30)
		SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CgId   */
		
		INSERT INTO #ProductList(CgId, PId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE cg.id in (select TYPE from dbo.DecodeStr(@CgIds))AND cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (0, -1) AND 
			  cm.deleted=0
	END
	
	/*从入库类单据中获取时间段内入库的商品*/
	/*DECLARE @PurchasePId TABLE (PId INT) --存放时间段内采购入库过的商品*/
	CREATE TABLE #PurchasePId (PId INT)
	INSERT INTO #PurchasePId(PId)
	SELECT DISTINCT s.p_id
	  FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
	WHERE b.billstates = 0 AND b.billtype IN (20, 160, 162) AND b.Y_ID = @YId AND 
	      b.billdate BETWEEN @Begin AND @End
	
	DECLARE @NewPId TABLE (PId INT) /*存放时间段内第一次采购入库的商品*/
	INSERT INTO @NewPId(PId)
	SELECT DISTINCT a.PId 
		FROM #PurchasePId a LEFT JOIN (
								SELECT p_id FROM PerStockData WHERE y_id = @YId AND [datetime] < @End GROUP BY p_id
		) b ON a.PId = b.p_id
	WHERE b.p_id IS NULL
	
	DECLARE @PurchaseInfo TABLE (PId INT, PurchaseBillDate DATETIME, FristPurchaseQty numeric(25,8), StockQty numeric(25,8), StockTaxTotal numeric(25,8), 
	        StockTotal numeric(25,8), StockPrice numeric(25,8), StockTaxPrice numeric(25,8), YId INT)
	INSERT INTO @PurchaseInfo
	SELECT a.p_id, a.PurchaseBillDate, a.FristPurchaseQty, SUM(ISNULL(s.quantity, 0)) AS StockQty, SUM(ISNULL(s.costtaxtotal, 0)) AS StockTaxTotal,
	       SUM(ISNULL(s.costtotal, 0)) AS StockTotal, AVG(ISNULL(s.costprice, 0)) AS StockPrice, AVG(ISNULL(s.costtaxprice, 0)) AS StockTaxPrice, @YId 
		FROM ( 
			SELECT b.p_id, MIN(c.billdate) AS PurchaseBillDate, CAST(dbo.GetNewProductPurchaseInfo(0, b.p_id, @YId, @Begin, @End) AS numeric(25,8)) AS FristPurchaseQty 
				FROM @NewPId a INNER JOIN buymanagebill b ON a.PId = b.p_id 
						       INNER JOIN billidx c ON b.bill_id = c.billid
						       INNER JOIN #ProductList p ON b.p_id = p.PId 
			WHERE c.billstates = 0 AND c.billtype IN (20, 160, 162) AND c.Y_ID = @YId AND 
				  c.billdate BETWEEN @Begin AND @End GROUP BY b.p_id
		) a LEFT JOIN (SELECT p_id, SUM(quantity) AS quantity, SUM(costtaxtotal) AS costtaxtotal, SUM(costtotal) AS costtotal, 
		                      AVG(costprice) AS costprice, AVG(costtaxprice) AS costtaxprice 
						FROM storehouse 
		               WHERE Y_ID = @YId GROUP BY p_id
		) s ON a.p_id = s.p_id
	GROUP BY a.p_id, a.PurchaseBillDate, a.FristPurchaseQty
	
	SELECT w.PId, CASE WHEN ISNULL(w.PurchaseBillDate, 0) < 10 THEN '' ELSE CONVERT(varchar(100), w.PurchaseBillDate, 23) END AS PurchaseBillDate, 
	       w.FristPurchaseQty, w.StockQty, w.StockTaxTotal, w.StockTotal, w.StockPrice, w.StockTaxPrice,
	       CASE WHEN ISNULL(f.BillDate, 0) < 10 THEN '' ELSE CONVERT(varchar(100), f.BillDate, 23) END AS SaleBillDate, 
	       ISNULL(f.SaleQty, 0.00) AS SaleQty, ISNULL(f.SaleMoney, 0.00) AS SaleMoney,
	       ISNULL(f.MlTotal, 0.00) AS MlTotal, ISNULL(f.TaxTotal, 0) AS TaxTotal, ISNULL(f.SaleMlRate, 0.00) AS SaleMlRate,
	       ISNULL(f.SendQty, 0.00) AS SendQty, ISNULL(f.SendMoney, 0.00) AS SendMoney, ISNULL(f.SendMlTotal, 0.00) AS SendMlTotal,
	       ISNULL(f.SendMlRate, 0.00) AS SendMlRate, ISNULL(f.SaleFreq, 0.00) AS SaleFreq, 
	       ISNULL(f.AvgDaySale, 0.00) AS AvgDaySale,
	       ISNULL(f.CanSaleDay, 0.00) AS CanSaleDay, 
	       f.SaleCycle, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea, u.name AS UnitName, p.Factory, p.Inputdate,
	       ISNULL(e.name, '') AS EName, ISNULL(c.name, '') AS SupplierName,
	       CAST(ISNULL(o.name, '0.00') AS numeric(25,8)) AS TaxRate
	    FROM @PurchaseInfo w INNER JOIN products p ON w.PId = p.product_id
							 INNER JOIN #ProductList pp ON w.PId = pp.PId
						     INNER JOIN unit u ON p.unit1_id = u.unit_id
						     LEFT JOIN productbalance k ON p.product_id = k.p_id AND k.Y_id = w.YId
						     LEFT JOIN clients c ON k.Supplier_id = c.client_id
						     LEFT JOIN employees e ON k.Emp_id = e.emp_id
						     LEFT JOIN (
						     		SELECT a.p_id, a.BillDate, a.SaleQty, a.SaleMoney, 
						     		       ROUND(a.MlTotal, 4) AS MlTotal, a.TaxTotal, ROUND(a.MlTotal * 100 / NULLIF(a.TaxTotal, 0), 4) AS SaleMlRate, a.SendQty,
										   a.SendMoney, a.SendMlTotal, a.SaleFreq,
										   CASE WHEN a.SendTaxTotal = 0 THEN 0 ELSE ROUND(a.SendMlTotal * 100 / NULLIF(a.SendTaxTotal, 0), 4) END AS SendMlRate, 
										   CASE WHEN (a.SaleQty <> 0 AND a.DayCount <> 0) 
												THEN ROUND(dbo.FN_GetAvlqty_Y(a.p_id, @YId) / NULLIF(a.SaleQty, 0) / NULLIF(a.DayCount, 0), 0) 
												ELSE 0 END AS CanSaleDay, 
										   CAST(dbo.GetNewProductPurchaseInfo(2, a.p_id, @YId, @Begin, @End) AS numeric(25,8)) AS AvgDaySale, 
										   CAST(DATEDIFF(DAY, a.BillDate, GETDATE()) AS INT) AS SaleCycle  
									FROM (      
											SELECT b.p_id, MIN(c.BillDate) AS BillDate, 
											       CAST(dbo.GetNewProductPurchaseInfo(1, b.p_id, @YId, @Begin, @End) AS INT) AS SaleFreq,
											       CAST(dbo.GetNewProductPurchaseInfo(3, b.p_id, @YId, @Begin, @End) AS INT) AS DayCount,
												   SUM(CASE WHEN c.billtype IN (10, 12, 150, 152) THEN b.quantity ELSE -b.quantity END) AS SaleQty,
												   SUM(CASE WHEN c.billtype IN (10, 12, 150, 152) THEN b.taxtotal ELSE -b.taxtotal END) AS SaleMoney,
												   SUM(CASE WHEN c.billtype IN (10, 12, 150, 152) THEN (b.SendQTY * b.taxtotal / b.quantity - b.costtaxprice * b.SendQTY) 
																								  ELSE -(b.SendQTY * b.taxtotal / b.quantity - b.costtaxprice * b.SendQTY) END) AS MlTotal,
												   SUM(CASE WHEN c.billtype IN (10, 12, 150, 152) THEN b.taxtotal ELSE -b.taxtotal END) AS TaxTotal,
												   SUM(CASE WHEN c.billtype IN (10, 11, 12, 13) THEN 0 
															WHEN c.billtype IN (150, 152) THEN b.quantity 
															WHEN c.billtype IN (151, 153) THEN -b.quantity ELSE 0 END) AS SendQty,
												   SUM(CASE WHEN c.billtype IN (10, 11, 12, 13) THEN 0 
															WHEN c.billtype IN (150, 152) THEN b.taxtotal
															WHEN c.billtype IN (151, 153) THEN -b.taxtotal ELSE 0 END) AS SendMoney,    
												   SUM(CASE WHEN c.billtype IN (10, 11, 12, 13) THEN 0 
															WHEN c.billtype IN (150, 152) THEN (b.SendQTY * b.taxtotal / b.quantity - b.costtaxprice * b.SendQTY)
															WHEN c.billtype IN (151, 153) THEN -(b.SendQTY * b.taxtotal / b.quantity - b.costtaxprice * b.SendQTY) ELSE 0 END) AS SendMlTotal,  
												   SUM(CASE WHEN c.billtype IN (10, 11, 12, 13) THEN 0 
															WHEN c.billtype IN (150, 152) THEN b.taxtotal
															WHEN c.billtype IN (151, 153) THEN -b.taxtotal ELSE 0 END) AS SendTaxTotal,
												   SUM(ISNULL(s.quantity, 0)) AS StockQty       
												FROM @NewPId a INNER JOIN salemanagebill b ON a.PId = b.p_id 
													INNER JOIN billidx c ON b.bill_id = c.billid
													LEFT JOIN (SELECT p_id, SUM(quantity) AS quantity FROM storehouse WHERE Y_ID = @YId GROUP BY p_id) s ON b.p_id = s.p_id
											WHERE c.billstates = 0 AND c.billtype IN (10, 11, 12, 13, 150, 151, 152, 153) AND c.Y_ID = @YId AND 
												  c.billdate BETWEEN @Begin AND @End GROUP BY b.p_id
									) a	
						     	) f ON w.PId = f.p_id
						     	LEFT JOIN (
						     		SELECT c.name, c.id, cm.baseinfo_id 
						     			FROM customCategory c INNER JOIN customCategoryMapping cm ON c.id = cm.category_id 
						     		WHERE cm.BaseTypeid = 0 and cm.deleted=0
						     	) o ON p.product_id = o.baseinfo_id AND p.TaxRate = o.id
	WHERE (@SupplierId = 0 OR k.Supplier_id = @SupplierId) AND (@EId = 0 OR k.Emp_id = @EId)
	DROP TABLE #ProductList
	DROP TABLE #PurchasePId
END
GO
