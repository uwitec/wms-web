
CREATE TRIGGER [DeleteSaleRange] ON [dbo].[Salerange] 
	FOR delete
	AS
	/*if update(deleted)*/
	begin
		delete from SaleRangeCheck where Sr_id in (select [id] from deleted)/* where deleted=1)*/
	end
GO
