

CREATE	PROCEDURE [Ts_L_ClinicRangeMapping]
	(@Info_id 	[int],
	 /*@Cr_id	[int],*/
	 @Cr_class_id	varchar(1000),
	 @InfoTyp [int],
	 @IsCheck	[int]
	 )

AS

IF @Info_id < 0
BEGIN
	EXEC Ts_L_ClinicRangeMapping_His @Info_id, @Cr_class_id, @InfoTyp, @IsCheck
	RETURN 1
END
ELSE
BEGIN
	declare @Cr_id int
	SET @Cr_id = 0

	select @Cr_id =  cr_id from clinicRange where class_id = @Cr_class_id;  

	/*历史数据处理BUG 18004 如果不清除 clinicRangeMapping 表类型baseInfoType=2 诊疗范围根节点*/
	/*cr_class_id='000000'的数据，对往来单位进行诊疗范围修改后，页面始终未全选状态*/
	/*clinicRangeMapping只存往来单位诊疗范围的子节点 所以这里对baseInfoType=2 and cr_class_id='000000' 数据清理*/

	delete clinicRangeMapping where info_id=@Info_id and baseInfoType=2 and cr_class_id='000000'

	if (@IsCheck = 1)
	begin
		if  not exists (select cm_id from clinicRangeMapping where info_id=@Info_id and cr_id=@Cr_id AND cr_class_id = @Cr_class_id AND baseInfoType = @InfoTyp)
		begin
			INSERT INTO clinicRangeMapping (info_id, cr_id, cr_class_id, baseInfoType) 
			VALUES (@Info_id, @Cr_id, @Cr_class_id, @InfoTyp)
			if @@rowcount<>0 
				return @@IDENTITY
			else
				return 0
		end
	end else
	begin
		delete  clinicRangeMapping where info_id=@Info_id and cr_id=@Cr_id AND cr_class_id = @Cr_class_id AND baseInfoType = @InfoTyp
		return 1
	end
END
GO
