

/*基础资料选择*/
/*在微信商城中选对应公司公司对应仓库*/
CREATE PROCEDURE [dbo].[WebAPP_GetBaseInfo2wx]
(
    @datatype	varchar(20),
    @chvFilter	varchar(255),
    @RetMessage varchar(200) out
)

/*$Encode$--*/

AS
select @RetMessage='操作成功'

if @datatype='Company'
begin
	select company_id as id,name from company where deleted=0 and child_number=0 and child_count=0 and StartUse=1
end
else if @datatype='stock'
begin
	select storage_id as id,name from storages where deleted=0 and child_number=0 and child_count=0
end
GO
