
CREATE FUNCTION TrsCode( @billtype INT)
RETURNS char(3) AS  
BEGIN 
  declare @Ret char(3)
  SET @Ret =
  case @billtype
  when 10 then '01'
  when 11 then '02'
  when 20 then '03'
  end

  return @Ret
END
GO
