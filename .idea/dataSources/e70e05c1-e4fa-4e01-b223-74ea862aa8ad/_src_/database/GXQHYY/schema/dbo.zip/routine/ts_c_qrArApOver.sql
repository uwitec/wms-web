









/* 2011-4-18: 增加查询出机构Class_ID //Huang.Y*/

/*查询超期应收应付款*/
/*  @nMode	=0 应收
		@nMode		=1 应付
*/
CREATE	 PROCEDURE ts_c_qrArApOver 
( @tEndDate datetime,
  @szCClass_id  varchar(50),
  @szYClass_id  varchar(50), 
  @nMode	int,
  @OperatorID INT = 0
)
AS
/*Params Ini begin*/
if @OperatorID is null  SET @OperatorID = 0
/*Params Ini end*/

declare @ClientTable int, @Companytable int,@employeestable int 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*------------------------*/

if @nMode = 0	  /*超期应收款*/
begin
  select c.client_id,c.class_id,c.[name],e.[name] as ename,b.billid,b.billnumber,b.billdate,b.billtype,b.inputman,b.auditman,b.skdate,b.jsye,b.ysmoney,Y.Class_id as YClass_ID
  from clients c,employees e,Company Y,
       (select billid,billnumber,billdate,billtype,inputman,auditman,skdate,jsye,ysmoney,c_id,e_id,Y_id
        from billidx where billtype in (10,112) and skdate<@tEndDate and skdate>0 and jsye<>0 and billstates='0'  
       )b
  where b.Y_id=Y.Company_id and c.client_id=b.c_id and b.e_id=e.emp_id   
  and c.deleted = 0
  and (@szCClass_id='' or C.Class_id like @szCClass_id+'%')
  and (@szYClass_id='' or Y.Class_id like @szYClass_id+'%')
  AND ((@employeestable=0) OR (b.E_id in (select [id] from #employeestable)))
  AND ((@ClientTable=0) or (b.c_id in (select [id] from #Clienttable)))
  AND ((@Companytable=0)or (b.Y_id in (select [id] from #Companytable)))   
  order by b.billdate
end
else
begin		/*超期应付款*/
  select c.client_id,c.class_id,c.[name],e.[name] as ename,b.billid,b.billnumber,b.billdate,b.billtype,b.inputman,b.auditman,b.skdate,b.jsye,b.ysmoney,Y.Class_id as YClass_ID
  from clients c,employees e,Company Y,
       (select billid,billnumber,billdate,billtype,inputman,auditman,skdate,jsye,ysmoney,c_id,e_id,Y_id
        from billidx where billtype in (20,122) and skdate<@tEndDate and skdate>0 and jsye<>0 and billstates='0' 
       )b
  where b.Y_id=Y.Company_id and c.client_id=b.c_id and b.e_id=e.emp_id    
  and c.deleted = 0
  and (@szCClass_id='' or C.Class_id like @szCClass_id+'%')
  and (@szYClass_id='' or Y.Class_id like @szYClass_id+'%')
  AND ((@employeestable=0) OR (b.E_id in (select [id] from #employeestable)))
  AND ((@ClientTable=0) or (b.c_id in (select [id] from #Clienttable)))
  AND ((@Companytable=0)or (b.Y_id in (select [id] from #Companytable)))   
  order by b.billdate
end
GO
