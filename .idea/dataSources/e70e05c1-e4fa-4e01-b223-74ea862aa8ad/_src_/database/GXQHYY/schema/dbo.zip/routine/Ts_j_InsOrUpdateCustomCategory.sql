

Create  procedure Ts_j_InsOrUpdateCustomCategory
( @CG_id          [int],
  @Parent_id      [int], 
  @class_id       [varchar](8),
  @name           [varchar](80),
  @pinyin         [varchar](80),  
  @baseType       [int],
  @rowindex       [int]
)  
AS

declare  @tempId  varchar(30),
         @child_number  [int],
         @child_count [int],
         @newP_id  int,
         @szParent_id varchar(8),
         @lParentBasetype int,
         @typeid int



if @Parent_id > 1  
begin
  select @lParentBasetype = basetype from customCategory where id = @Parent_id
  if @lParentBasetype <>  @baseType 
  begin
    RAISERROR('子类所属类型必须和父类一致，才能保存，请修改[所属类型]！',16,1)
	return-1
  end	 
end

/*取得ID号*/
if @CG_id=0
begin
    if @Parent_id <= 1  
      select @szParent_id = class_id, @Parent_id = id from customCategory where class_id = '00'
    else
      select @szParent_id = class_id from customCategory where id = @Parent_id 
                  
	select @tempid=classid,@child_number=childnumber,@child_count=childCount 
	from Getid(@szParent_id,'customCategory')
	select @typeid=Typeid from customCategory where id=@Parent_id
	if @@rowcount=0
	begin
	 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
	 return-1
	end
	 insert into customCategory( 
				[class_id],                     
				[parent_id],									          				
				[name]  ,										
				[pinyin] ,										
				[rowindex],						
				[baseType],
				[Typeid]
			 )						
	Values(	@tempId,
	        @Parent_id ,     			
			@name,               
			@pinyin,          
			@child_count,          
			@baseType,
			@typeid   						    	    
		   )									

	if @@rowCount=0 
	begin
	 return -1
	end else 
	begin
	 update customCategory set child_number=@child_number,child_count=@child_count  where class_id =@szParent_id
	 select @newP_id= @@IDENTITY
	 return @newP_id 
    end
end else
begin
   UPDATE [customCategory]  
		SET  		
		[name]           = @name,
		[pinyin]	     = @pinyin,
	    [baseType]       = @baseType
  WHERE 
	( [id] = @CG_id)
   
  select @szParent_id = class_id+'%' from customCategory where id = @CG_id   
  update customCategory set baseType = @baseType where  class_id like @szParent_id	
  return @CG_id
end
GO
