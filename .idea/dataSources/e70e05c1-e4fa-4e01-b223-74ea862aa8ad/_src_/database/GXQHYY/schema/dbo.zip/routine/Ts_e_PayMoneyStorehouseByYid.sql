create procedure Ts_e_PayMoneyStorehouseByYid
  @strP_id varchar(8000)='',/*出入商品的ID的字符串*/
  @batchNO varchar(100)='',/*批号*/
  @makeddate  varchar(100)='',/*生产日期*/
  @validdate  varchar(100)='',/*有效期*/
  @FactoryId  int=0, /*生产厂家ID*/
  @Typeid     varchar(100)=''/*区分是查找商品批次库存，供应商库存; 商品批次库存:'A' 供应商库存'B'*/
as
begin
 if @Typeid='A' 
 begin
     SELECT  s.Y_ID, isnull(cp.name,'') as yname,isnull(s.batchno,'') as batchno,s.validdate,isnull(s.quantity,0) as quantity       
	 FROM storehouse S  left join company cp on s.Y_ID = cp.company_id	 			     
     where s.batchno=@batchNO 
           and s.makedate=@makeddate 
           and s.validdate=@validdate 
           and s.factoryid=@FactoryId
           and s.p_id in (select  szTYPE from  DecodeToStr(@strP_id))
 end
 else
 begin
     SELECT  s.Y_ID,isnull(cp.name,'') as yname,isnull(p.alias,'') as alias,isnull(p.name,'') as p_name,
            isnull(p.standard,'') as P_Standard,
            isnull(f.AccountComment,'') as Factory,
            isnull(p.permitcode,'') as permitcode,isnull(s.batchno,'') as batchno,isnull(s.quantity,0) as quantity,
            isnull(s.costtaxtotal,0) as costtaxtotal,s.makedate, s.validdate,isnull(s.costtaxprice,0) as costtaxprice,
            pr.retailprice,
            s.quantity*pr.retailprice-s.costtotal as MlToatl,
            case s.costtotal when 0 then 0 else ((s.quantity*pr.retailprice-s.costtotal)/s.costtotal)*100 end as MlRate    
	 FROM storehouse S left join  vw_b_Products p on s.p_id = p.p_id
	                   left join  company   cp on s.Y_ID=cp.company_id
	                   left join  price  pr on p.p_id=pr.p_id and p.Unit1_id=pr.u_id
	                   left join  basefactory f on s.factoryid=f.CommID		   			   
     where  s.p_id in (select distinct  szTYPE from  DecodeToStr(@strP_id))
 end
end
GO
