
CREATE	 PROCEDURE [Ts_L_SearchUserauthorize]
( @eid          int ,
  @isclient     int=0,        
  @useClient    varchar(50)='' output,/*往来授权*/
  @iscompany    int=0,
  @useCompany   varchar(50)='' output,/*分支机构授权*/
  @isemployees  int=0,
  @useemployees varchar(50)='' output,/*职员授权*/
  @isstores     int=0,
  @usestores    varchar(50)='' output,/*仓库授权*/
  @isRegion     int=0,
  @useRegion    varchar(50)='' output,/*片区授权*/
  @isDepart     int=0,
  @useDepart    varchar(50)='' output/*部门授权*/
) 
AS 
/*Params Ini begin*/
if @isclient is null  SET @isclient = 0
if @useClient is null  SET @useClient = '' 
if @iscompany is null  SET @iscompany = 0
if @useCompany is null  SET @useCompany = '' 
if @isemployees is null  SET @isemployees = 0
if @useemployees is null  SET @useemployees = '' 
if @isstores is null  SET @isstores = 0
if @usestores is null  SET @usestores = '' 
if @isRegion is null  SET @isRegion = 0
if @useRegion is null  SET @useRegion = '' 
if @isDepart is null  SET @isDepart = 0
if @useDepart is null  SET @useDepart = '' 
/*Params Ini end*/
  Declare  @Now  DATETIME
  Declare  @Tablename  VARCHAR(1000)
  Declare  @szsql  varchar(8000)

 SET  @Now=Getdate()

 SET  @TableName = '##' + CAST(DATEPART(minute,  @Now) AS VARCHAR(2)) +
                        + CAST(DATEPART(second,  @Now) AS VARCHAR(2)) +
                        + CAST(DATEPART(millisecond,  @Now) AS VARCHAR(3))

 if @isclient=1 
 begin
   set @useClient=@tablename+'Clinet'

   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@eid and u.Type='C' and u.psc_id='000000') 
   begin
     set @useClient=''
          
   end
   else
   begin 
     set @szsql='select C.* into '+@useClient+' from (select psc_id as CCID from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''C'')C'
     exec (@szsql)
   end
 end

 if @iscompany=1
 begin
   set @useCompany=@tablename+'CompanY' 
  
   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@eid and u.Type='Y' and u.psc_id='000000') 
   begin
      set @useCompany=''
   end
   else
   begin 
      set @szsql='select Y.* into '+@useCompany+' from (select psc_id as YCID from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''Y'')Y'
      exec(@szsql)
   end
  
 end

 if @isemployees=1
 begin
   set @useemployees=@tablename+'employees' 

   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@eid and u.Type='E' and u.psc_id='000000') 
   begin
     set @useemployees=''
          
   end
   else
   begin 
      set @szsql='select E.* into '+@useemployees+' from (select psc_id as ECID  from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''E'')E'
      exec(@szsql)
   end

 end
 
 if @isstores=1
 begin
   set @usestores=@tablename+'Storages'

   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@eid and u.Type='S' and u.psc_id='000000') 
   begin
     set @usestores=''
           
   end
   else
   begin 
      set @szsql='select S.* into '+@usestores+' from (select psc_id  as SCID from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''S'')S'
      exec (@szsql)
   end
 end


 if @isRegion=1 
 begin
   set @useRegion=@tablename+'Region'

   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='R') 
   begin
      set @useRegion=''
           
   end
   else
   begin 
      set @szsql='select R.* into '+@useRegion+' from (select psc_id as RID from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''R'')R'
      exec (@szsql)  
   end
 
 end
 
 if @isDepart=1
 begin
   set @useDepart=@tablename+'Depart'

   if not exists(select * from userauthorize u where u.e_id=@eid and u.Type='D') 
   begin
      set @useDepart=''
           
   end
   else
   begin 
      set @szsql='select D.* into '+@useDepart+' from (select psc_id as DID from userauthorize u where u.e_id='+cast(@eid as varchar(20))+' and u.Type=''D'')D'
      exec (@szsql) 
   end
  

 end
GO
