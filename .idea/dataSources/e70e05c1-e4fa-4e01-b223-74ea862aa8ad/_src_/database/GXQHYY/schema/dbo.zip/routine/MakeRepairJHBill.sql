
/*********生成补拣货单**********/
/******add by luowei 2013-07-31***/


create procedure MakeRepairJHBill
(
  @bill_id int /*-含有差额的拣货单id*/
)
as
begin
begin    
    /*1、实物库存不足状态，实物库存不足商品生成同价调拨单用于扣减账面库存*/
	/*-----判读是否更新实物库存不足的商品数量信息*/
	if exists(select 1 from sysconfigtmp where sysname = 'jhBillAudit' and sysvalue = '0')
	begin
		DECLARE @GetDate varchar(20)
		declare @szBillnumber varchar(30)
		declare @szJHBillnumber varchar(30)
		declare @nE_id int
		declare @nauditmain int
		declare @ninputmain int
		declare @nOutsid int
		declare @nInSid int
		declare @qty int
		declare @y_id int 
		declare @new_billid int 

		set @GetDate = ''
		set @szBillnumber = ''
		set @nE_id = 0
		set @nauditmain = 0
		set @ninputmain = 0
		set @y_id = 2
		set @new_billid = 0
		set @qty = 0
		select  @nInSid = region_id  from billdraftidx where billid = @bill_id



		/*-----------生成同价调拨单主表*/
		select @szJHBillnumber = billnumber,@nE_id = e_id,@nauditmain = auditman,@ninputmain = inputman,@nOutsid = sout_id, 
			   @y_id = y_id from billdraftidx where billid = @bill_id

		select @GetDate =(cast( YEAR (getdate()) as varchar(4))+'-'+cast( MONTH (getdate()) as varchar(4))
			+'-'+ cast( DAY (getdate()) as varchar(4)) ) 
			
		if exists(select 1 from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 7)
		begin	
			select @qty = isnull(SUM(isnull(quantity,0)-isnull(SendQTY,0)),0) from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 7
				
			exec TS_H_CreateBillSN 44, 0, null, @nE_id, 0, @szBillnumber output	
			    
			INSERT INTO BillDraftidx
			(
				billdate ,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
				ysmoney  ,ssmoney  ,araptotal,quantity , taxrate,period  ,billstates,order_id ,
				department_id,posid  ,region_id ,auditdate ,skdate  ,jsflag,note  ,summary ,
				jsye,invoice ,invoiceNO,invoiceTotal ,businesstype,GatheringMan,SendQTY,vipCardID,Y_id
			)
			VALUES
			(
				@GetDate,@szBillnumber,44,0,0,@nE_id,@nOutsid,@nInSid,@nauditmain,@ninputmain,
				0,0,0,@qty,0,0,3,0,
				0,0,0,0,0,0,'由拣货单【'+@szJHBillnumber+'】中无实物库存商品生成','',
				0,0 ,'',0, 0,0,@qty,0,@Y_id 
			)

			SET  @new_billid=@@IDENTITY

			/*--------------------生成同价调拨单明细*/
			if(@new_billid> 0)
			begin
				INSERT INTO storemanageBilldrf
				(
				 bill_id  ,p_id  ,batchno  ,quantity  ,costprice,costtotal  ,price ,totalmoney  ,retailprice  ,
				 retailmoney  ,makedate  ,validdate  ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,
				 commissionflag  ,comment  ,unitid ,location_id2, qualitystatus,iotag, total, invoiceTotal , 
				  OrgBillID,Aoid,SendQTY,SendCostTotal,Y_id, instoretime
				)
				select @new_billid,p_id,batchno,isnull((quantity-SendQTY),0),costprice,costprice*isnull((quantity-SendQTY),0),costprice,costprice*(isnull(quantity-SendQTY,0)),0,
				0,makedate,validdate,0,@nOutsid,@nInSid,location_id,supplier_id,
				commissionflag, dbo.GetProductComment(p_id, isnull((quantity-SendQTY),0)) ,unitid,location_id2,'合格',iotag,costprice*isnull(quantity-SendQTY,0),0,
				0,0,quantity,costprice*isnull(quantity-SendQTY,0),@Y_id, instoretime
				from salemanagebilldrf where bill_id = @bill_id and AOID = 7
				
				if @@IDENTITY <= 0 
				begin
				  raiserror('生成同价调拨单草稿明细错误！',16,1)
				  return -4
				end
				
				declare @nP_id int
				declare @nReturnNumber int
				exec ts_c_BillAudit @new_billid,@nP_id output,@nReturnNumber output,44
				if (@nReturnNumber <> 0)
				begin
				  EXEC Ts_b_DeleteBillDraft @nReturnNumber output, 2, @new_billid
				  raiserror('生成同价调拨单过账错误！',16,1)
				  return -5
				end 
			end
			else
			begin
			  raiserror('生成同价调拨单主表草稿错误！',16,1)
			  return -3
			end
		end

	end


	/*-----判读是否更新实物库存不足的商品数量信息*/
	if exists(select 1 from sysconfigtmp where sysname = 'jhBillAudit' and sysvalue = '0')
	begin
	  /*-----更新拣货单重实物库存不足的商品*/
	  update salemanagebilldrf set quantity = SendQTY,batchprice = quantity - SendQTY,comment = dbo.GetProductComment(p_id, SendQTY) where bill_id = @bill_id and SendQTY <> quantity and AOID = 7 
	  /*-----更新拣货单主表信息*/
	  update billdraftidx set quantity =  mx.qty from 
				(select bill_id,sum(SendQTY) as qty from salemanagebilldrf where bill_id = @bill_id group by bill_id) mx
				where billid = mx.bill_id
	  
	  /*-----更新原销售出库单实物品库存不足商品明细信息*/

	  update salemanagebilldrf  set quantity = RealQty,
	         /*totalmoney = discountprice * (quantity - jhmx.lostQty),taxtotal = taxprice*(quantity - jhmx.lostQty),*/
			 comment = dbo.GetProductComment(p_id, (RealQty)),
			 /*total = (quantity - jhmx.lostQty) * saleprice , */
			 thqty = RealQty,
			 SendQTY = RealQty
			 /*SendCostTotal = (quantity - jhmx.lostQty) * costprice*/
			  from (select CxGuid as mxguid, SendQTY as RealQty from salemanagebilldrf where bill_id = @bill_id  and AOID = 7) jhmx 
	  where RowGuid = jhmx.mxguid 
	  delete from salemanagebilldrf where quantity = 0 and p_id > 0 and bill_id = (select order_id from billdraftidx where billid = @bill_id and billtype = 254)
	  /*-delete from salemanagebilldrf where quantity <= 0 and p_id > 0 and bill_id = @bill_id*/
	  
	  
	    /*----获取商品整货单位换算表*/
  select * into #rate1 from 
  (
     select p.product_id,p.WholeUnit_id,p.rate2 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit2_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate3 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit3_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
							 
							 union all
							 
							  select p.product_id,p.WholeUnit_id,p.rate4 as rate from products p
							inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit4_id and p.product_id = t.product_id)
							 where p.WholeUnit_id <> 0 
  ) rate
    
     /*---------获取原销售出库单单据中对应商品中非基本单位非整货单位的换算率*/
  select * into #Oldotherrate1 from  (
  
	 select p_id,mx.unitid,t.rate2 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit2_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit2_id)
	 where bill_id in (select order_id from billdraftidx where billid = @bill_id)
	 union all
	  select p_id,mx.unitid,t.rate3 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit3_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit3_id)
	 where bill_id in (select order_id from billdraftidx where billid = @bill_id)
	 union all
	 select p_id,mx.unitid,t.rate4 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit4_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit4_id)
	 where bill_id in (select order_id from billdraftidx where billid = @bill_id)
  
  ) otherrate
  
	  
/*---------------获取原单明细并关联整货换算率*/

 select ISNULL(#rate1.rate,0) as rate,ISNULL(#Oldotherrate1.otherrate,1) as otherrate,sm.* into #oldsalemx1 from  salemanagebilldrf sm
             left join #rate1 on (sm.p_id = #rate1.product_id and sm.unitid = #rate1.WholeUnit_id)
             left join #Oldotherrate1 on (sm.p_id = #Oldotherrate1.p_id and sm.unitid = #Oldotherrate1.unitid)
             where bill_id in (select order_id from billdraftidx where billid = @bill_id)
	   
	 /*-----根据新的明细信息重算原销售出库单主表*/
  update billdraftidx set quantity = mx.quantity,SendQTY = mx.quantity,WholeQty = mx.WholeQty,PartQty = mx.PartQty
  from 
  (
    select bill_id,SUM(quantity) as quantity,SUM(SendQTY) as SendQTY,SUM(WholeQty) as WholeQty,SUM(PartQty) as PartQty 
    from (
             select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #oldsalemx1 where rate <> 0  /*-整货商品*/
             union all
             select 0 as WholeQty,quantity as PartQty,* from #oldsalemx1 where rate = 0   /*-零货商品*/
         ) sm 
     where bill_id in (select order_id from billdraftidx where billid = @bill_id) group by bill_id
  ) mx where billid = mx.bill_id



  /*---------更新原销售出库单明细的相关金额*/
  update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*WholeQty,taxtotal = salemanagebilldrf.taxprice*WholeQty,
  retailtotal = salemanagebilldrf.retailprice*WholeQty,total =salemanagebilldrf.saleprice*WholeQty,SendCostTotal =salemanagebilldrf.costprice*WholeQty
  from 
  (
    select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #oldsalemx1 where rate <> 0  /*-整货商品*/
  ) sm where sm.bill_id in (select order_id from billdraftidx where billid = @bill_id) and salemanagebilldrf.smb_id = sm.smb_id and salemanagebilldrf.p_id > 0
  
   update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*otherqty,taxtotal = salemanagebilldrf.taxprice*otherqty,
  retailtotal = salemanagebilldrf.retailprice*otherqty,total =salemanagebilldrf.saleprice*otherqty,SendCostTotal =salemanagebilldrf.costprice*otherqty
  from 
  (
    select 0 as WholeQty,quantity/otherrate as otherqty,* from #oldsalemx1 where rate = 0  /*-零货商品*/
  ) sm where sm.bill_id in (select order_id from billdraftidx where billid = @bill_id) and salemanagebilldrf.smb_id = sm.smb_id and salemanagebilldrf.p_id > 0
  
  /*-----------更新主表ysmoney      */
    update billdraftidx set ysmoney = mx.total,jsye = ISNULL(ssmoney,0) - isnull(mx.total,0) 
    from (
             select bill_id,SUM(taxtotal) as total from  salemanagebilldrf 
             where bill_id in (select order_id from billdraftidx where billid = @bill_id) and AOID = 0
              group by bill_id
          ) mx 
  where billid = bill_id and bill_id in (select order_id from billdraftidx where billid = @bill_id)
    
  drop table #rate1
  drop table #oldsalemx1
	  
	end
	else
	begin  
		/*
	  -------更新拣货单重实物库存不足的商品
	  update salemanagebilldrf set quantity = SendQTY where bill_id = @bill_id and SendQTY <> quantity and AOID = 7 
	  -------更新拣货单主表信息
	  update billdraftidx set quantity =  mx.qty from 
				(select bill_id,sum(quantity) as qty from salemanagebilldrf where bill_id = @bill_id group by bill_id) mx
				where billid = mx.bill_id
	  
	  -------更新原销售出库单实物品库存不足商品明细信息

	  update salemanagebilldrf  set quantity = jhmx.jhqty,totalmoney = discountprice*jhmx.jhqty,taxtotal = taxprice*jhmx.jhqty,
			 comment = CAST(jhmx.jhqty as varchar) + SUBSTRING(comment,CHARINDEX('(',comment,1),LEN(comment)-CHARINDEX('(',comment,1)+1),
			 total = jhmx.jhqty * saleprice , thqty = jhmx.jhqty,SendQTY = jhmx.jhqty,SendCostTotal = jhmx.jhqty * costprice
			  from (select CxGuid as mxguid,quantity as jhqty from salemanagebilldrf where bill_id = @bill_id  and AOID = 7) jhmx 
	  where RowGuid = jhmx.mxguid 
	   
	  -------根据新的明细信息重算原销售出库单主表
	  update billdraftidx set quantity = mx.qty,ysmoney =mx.total,jsye = mx.total,SendQTY = mx.qty,PartQty = mx.total  from 
		 (
			select bill_id,SUM(quantity) as qty,SUM(totalmoney) as total from salemanagebilldrf mx 
			where exists(select 1 from billdraftidx i where mx.bill_id = i.billid and i.billid in (select order_id from billdraftidx where billid = @bill_id))
			group by bill_id
		) mx where mx.bill_id = billid
	  */

	  /* 修改原销售出库单草稿为未审核*/
	  update billdraftidx set auditman = 0, billstates = 2 where billid = (select order_id from billdraftidx where billid = @bill_id and billtype = 254)
		  /*---将原销售出库单草稿的所有拣货单取消关联，并作废，重新生成新的拣货单*/
	  update billdraftidx set posid  =1,order_id = 0
	  where order_id in (select order_id from billdraftidx where billid = @bill_id) and billtype = 254
	  
	/*  
	  declare @salebillid  int
	  set @salebillid = 0
	  select @salebillid = order_id  from billdraftidx where billid = @bill_id 
	  -------重新生成新拣货单
	  exec TS_L_CreateJHBill @salebillid 
	  */ 
	  
	end
end




/*--启用将漏检货商品重新生成新的销售出库单草稿 add by luowei 2013-10-19*/
if exists(select 1 from sysconfigtmp where sysname = 'JHMakeNewSaleBill' and sysvalue = '1')
and exists(select 1 from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 6)
begin
  /*----生成销售出库单草稿主表 */
  declare @nxsbillid int /*-原销售单id*/
  declare @newxsbillid int  /*--新销售单id*/
  declare @newbilldate varchar(10)
  declare @SaleBillnumber varchar(50)
  declare @oldjhbillnumber varchar(50)
  declare @e_id int
  declare @s_id int
  set @nxsbillid = 0
  set @newxsbillid = 0
  set @newbilldate = '1990-01-01'
  set @SaleBillnumber = ''
  set @oldjhbillnumber = ''
  set @e_id = 0
  set @s_id = 0
  
  select @nxsbillid = billid,@e_id=e_id from billdraftidx where GUID in (select InvoiceNO from billdraftidx where billid = @bill_id)
  select @s_id = sout_id,@oldjhbillnumber = billnumber from billdraftidx where billid = @bill_id
  
  set @newbilldate = CONVERT(varchar(10),GETDATE(),121)
  exec TS_H_CreateBillSN 10, 0, null, @e_id, 0, @SaleBillnumber output	
   
  
  insert into billdraftidx 
  (
     billdate,billnumber,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,
     quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,jsye,
     note,GUID,ArAptotal,SendQTY,Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_id,WholeQty,PartQty
  )
  select @newbilldate,@SaleBillnumber,10,c_id,e_id,@s_id,@s_id,inputman,0,
         0,taxrate,period,2,order_id,department_id,posid,region_id,jsye,
         note + ' 由拣货单'+@oldjhbillnumber+'漏拣货商品生成 ',NEWID(),ArAptotal,0,Y_ID,B_CustomName1,B_CustomName2,B_CustomName3,sendC_id,0,0
  from billdraftidx where billid = @nxsbillid
  
  if @@IDENTITY <= 0 
	begin
	  raiserror('生成销售出库单草稿主表错误！',16,1)
	  return -10
	end
					
  set @newxsbillid = @@IDENTITY
  
  /*--------生成销售出库单草稿明细 */
  
  insert into salemanagebilldrf
  (
    bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,totalmoney,taxprice,taxtotal,retailprice,retailtotal,makedate,
    validdate,qualitystatus,price_id,ss_id,sd_id,location_id,supplier_id,commissionflag,unitid,taxrate,order_id,total,iotag,thqty,newprice,
    AOID,PriceType,SendQTY,SendCostTotal,RowGuid,RowE_id,YCostPrice,YGuid,Y_ID,instoretime,location_id2,comment2
  )
  select @newxsbillid,p_id,batchno,(quantity-jhqty),costprice,saleprice,discount,discountprice,0,taxprice,
  0,retailprice,0,makedate,validdate,qualitystatus,price_id,ss_id,sd_id,location_id,
  supplier_id,commissionflag,unitid,taxrate,order_id,0,iotag,(quantity-jhqty),newprice,
  AOID,PriceType,(quantity-jhqty),0,NEWID(),RowE_id,YCostPrice,YGuid,Y_ID,instoretime,location_id2,comment2
  from 
  (
    select isnull(jh.SendQTY,0) as jhqty,mx.* from salemanagebilldrf mx inner join 
    (
       select CxGuid,SendQTY from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 6
     ) jh on mx.RowGuid = jh.CxGuid
  ) tb /*where bill_id = tb.bill_id*/
  
  
  if @@IDENTITY <= 0 
	begin
	  delete from billdraftidx where billid = @newxsbillid  /*-删除主表*/
	  raiserror('生成销售出库单草稿明细错误！',16,1)
	  return -11
	end
  
  /*----------更新自动生成的销售出库单草稿相关信息-------------------------------------------begin--------------------------------*/
  
  
  /*----获取商品整货单位换算表*/
  select * into #rate from 
  (
            select p.product_id,p.WholeUnit_id,p.rate2 as rate from products p
			inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit2_id and p.product_id = t.product_id)
			 where p.WholeUnit_id <> 0 
			 
			 union all
			 
			  select p.product_id,p.WholeUnit_id,p.rate3 as rate from products p
			inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit3_id and p.product_id = t.product_id)
			 where p.WholeUnit_id <> 0 
			 
			 union all
			 
			  select p.product_id,p.WholeUnit_id,p.rate4 as rate from products p
			inner join (select * from products where WholeUnit_id <> 0 ) t on (p.WholeUnit_id = t.unit4_id and p.product_id = t.product_id)
			 where p.WholeUnit_id <> 0 
  ) rate
  
  
  /*---------获取单据中对应商品中非基本单位非整货单位的换算率*/
  select * into #otherrate from  (
  
	 select p_id,mx.unitid,t.rate2 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit2_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit2_id)
	 where bill_id = @newxsbillid
	 union all
	  select p_id,mx.unitid,t.rate3 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit3_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit3_id)
	 where bill_id = @newxsbillid
	 union all
	 select p_id,mx.unitid,t.rate4 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit4_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit4_id)
	 where bill_id = @newxsbillid
  
  ) otherrate
  
 /*---------------------处理整货与零货数量 */
 
 select ISNULL(#rate.rate,0) as rate,ISNULL(#otherrate.otherrate,1) as otherrate,sm.* into #salemx from  salemanagebilldrf sm
             left join #rate on (sm.p_id = #rate.product_id and sm.unitid = #rate.WholeUnit_id)
             left join #otherrate on (sm.p_id = #otherrate.p_id and sm.unitid = #otherrate.unitid)
             where bill_id = @newxsbillid 
                         
  
 /*---------更新新主表中相关的数量信息 */
  update billdraftidx set quantity = mx.quantity,SendQTY = mx.quantity,WholeQty = mx.WholeQty,PartQty = mx.PartQty
  from 
  (
    select bill_id,SUM(quantity) as quantity,SUM(SendQTY) as SendQTY,SUM(WholeQty) as WholeQty,SUM(PartQty) as PartQty 
    from (
             select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #salemx where rate <> 0  /*-整货商品*/
             union all
             select 0 as WholeQty,quantity as PartQty,* from #salemx where rate = 0   /*-零货商品*/
         ) sm 
     where bill_id = @newxsbillid group by bill_id
  ) mx where billid = mx.bill_id
  
 
 /*---------更新新销售出库单明细的相关金额*/
  update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*WholeQty,taxtotal = salemanagebilldrf.taxprice*WholeQty,
  retailtotal = salemanagebilldrf.retailprice*WholeQty,total =salemanagebilldrf.saleprice*WholeQty,SendCostTotal =salemanagebilldrf.costprice*WholeQty
  from 
  (
    select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #salemx where rate <> 0  /*-整货商品*/
  ) sm where sm.bill_id = @newxsbillid and salemanagebilldrf.smb_id = sm.smb_id
  
   update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*otherqty,taxtotal = salemanagebilldrf.taxprice*otherqty,
  retailtotal = salemanagebilldrf.retailprice*otherqty,total =salemanagebilldrf.saleprice*otherqty,SendCostTotal =salemanagebilldrf.costprice*otherqty
  from 
  (
    select 0 as WholeQty,quantity/otherrate as otherqty,* from #salemx where rate = 0  /*-零货商品*/
  ) sm where sm.bill_id = @newxsbillid and salemanagebilldrf.smb_id = sm.smb_id
  
 
   /*-----------更新新主表ysmoney*/
  update billdraftidx set ysmoney = mx.total,jsye = mx.total from (select bill_id,SUM(taxtotal) as total from  salemanagebilldrf where bill_id = @newxsbillid and AOID = 0 group by bill_id) mx 
  where bill_id = billid and billid = @newxsbillid
  
 /*----------更新自动生成的销售出库单草稿相关信息-------------------------------------------end--------------------------------*/
  
  
/*------------更新原销售出库单相关信息---------------------------------------begin-------------------------------  */
  
/*-----更新拣货单重实物库存不足的商品*/
	  update salemanagebilldrf set  quantity = SendQTY, batchprice = quantity - SendQTY, comment = dbo.GetProductComment(p_id, SendQTY) where bill_id = @bill_id and SendQTY <> quantity and AOID = 6 
	  /*-----更新拣货单主表信息*/
	  update billdraftidx set quantity =  mx.qty from 
				(select bill_id,sum(SendQTY) as qty from salemanagebilldrf where bill_id = @bill_id group by bill_id) mx
				where billid = mx.bill_id
	  
	  /*-----更新原销售出库单实物品库存不足商品数量明细信息*/

	  update salemanagebilldrf  set quantity = RealQty,
	  /*totalmoney = discountprice * (quantity - jhmx.lostQty),taxtotal = taxprice*(quantity - jhmx.lostQty),*/
			 comment = dbo.GetProductComment(p_id, RealQty),
			 /*total = (quantity - jhmx.lostQty) * saleprice , */
			 thqty = RealQty,SendQTY = RealQty
			 /*SendCostTotal = (quantity - jhmx.lostQty) * costprice*/
			  from (select CxGuid as mxguid, SendQTY as RealQty from salemanagebilldrf where bill_id = @bill_id  and AOID = 6) jhmx 
	  where RowGuid = jhmx.mxguid 
	  /*-----删除原单完全没有库存的明细*/
	  delete from salemanagebilldrf where quantity = 0 and p_id > 0 and bill_id = (select order_id from billdraftidx where billid = @bill_id and billtype = 254)
	  
	  /*----------删除拣货单*/
/*-	  delete from salemanagebilldrf where quantity <= 0 and p_id > 0 and bill_id = @bill_id*/
	  
 /*---------------------原销售单处理整货与零货数量 */
 
 
   /*---------获取原销售出库单单据中对应商品中非基本单位非整货单位的换算率*/
  select * into #Oldotherrate from  (
  
	 select p_id,mx.unitid,t.rate2 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit2_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit2_id)
	 where bill_id = @nxsbillid
	 union all
	  select p_id,mx.unitid,t.rate3 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit3_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit3_id)
	 where bill_id = @nxsbillid
	 union all
	 select p_id,mx.unitid,t.rate4 as otherrate from salemanagebilldrf mx 
	 inner join (select * from products where unit4_id <> 0) t on  (mx.p_id = t.product_id and mx.unitid = unit4_id)
	 where bill_id = @nxsbillid
  
  ) otherrate
 
 
 
 select ISNULL(#rate.rate,0) as rate,ISNULL(#Oldotherrate.otherrate,1) as otherrate,sm.* into #oldsalemx from  salemanagebilldrf sm
             left join #rate on (sm.p_id = #rate.product_id and sm.unitid = #rate.WholeUnit_id)
             left join #Oldotherrate on (sm.p_id = #Oldotherrate.p_id and sm.unitid = #Oldotherrate.unitid)
             where bill_id =@nxsbillid
	 
	 
	 
	   
	  /*-----根据新的明细信息重算原销售出库单主表*/
  update billdraftidx set quantity = mx.quantity,SendQTY = mx.quantity,WholeQty = mx.WholeQty,PartQty = mx.PartQty
  from 
  (
    select bill_id,SUM(quantity) as quantity,SUM(SendQTY) as SendQTY,SUM(WholeQty) as WholeQty,SUM(PartQty) as PartQty 
    from (
             select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #oldsalemx where rate <> 0  /*-整货商品*/
             union all
             select 0 as WholeQty,quantity as PartQty,* from #oldsalemx where rate = 0   /*-零货商品*/
         ) sm 
     where bill_id = @nxsbillid group by bill_id
  ) mx where billid = mx.bill_id
  
  /*---------更新原销售出库单明细的相关金额*/
  update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*WholeQty,taxtotal = salemanagebilldrf.taxprice*WholeQty,
  retailtotal = salemanagebilldrf.retailprice*WholeQty,total =salemanagebilldrf.saleprice*WholeQty,SendCostTotal =salemanagebilldrf.costprice*WholeQty
  from 
  (
    select isnull(quantity/rate,0) as WholeQty,0 as PartQty,* from #oldsalemx where rate <> 0  /*-整货商品*/
  ) sm where sm.bill_id = @nxsbillid and salemanagebilldrf.smb_id = sm.smb_id and salemanagebilldrf.p_id > 0
  
   update salemanagebilldrf set totalmoney = salemanagebilldrf.discountprice*otherqty,taxtotal = salemanagebilldrf.taxprice*otherqty,
  retailtotal = salemanagebilldrf.retailprice*otherqty,total =salemanagebilldrf.saleprice*otherqty,SendCostTotal =salemanagebilldrf.costprice*otherqty
  from 
  (
    select 0 as WholeQty,isnull(quantity/otherrate,0) as otherqty,* from #oldsalemx where rate = 0  /*-零货商品*/
  ) sm where sm.bill_id = @nxsbillid and salemanagebilldrf.smb_id = sm.smb_id and salemanagebilldrf.p_id > 0
  
  /*-----------更新主表ysmoney*/
  update billdraftidx set ysmoney = mx.total,jsye = ISNULL(ssmoney,0) - isnull(mx.total,0) from (select bill_id,SUM(taxtotal) as total from  salemanagebilldrf where bill_id = @nxsbillid and AOID = 0 group by bill_id) mx 
  where bill_id = billid and billid = @nxsbillid
  
  /*------------更新原销售出库单相关信息---------------------------------------begin-------------------------------*/
  drop table #rate
  drop table #salemx
  drop table #oldsalemx
  drop table #otherrate
  drop table #Oldotherrate
   
end




  /*2、判断拣货未拣够，生成补拣单后更新原拣货单数量*/
  
    if not exists(select 1 from billdraftidx where a_id = @bill_id and billtype = 254)
    begin
      if exists(select 1 from salemanagebilldrf where bill_id = @bill_id and AOID = 6 and quantity <> SendQTY) and 
         exists(select 1 from sysconfigtmp where sysname = 'JHMakeNewSaleBill' and sysvalue = '0')
		begin
			declare @qtytotal int
			select @qtytotal = isnull(SUM(isnull(quantity,0)-isnull(SendQTY,0)),0) from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 6
		    
			declare @nBillCount int   /*--当天捡货单数目，用于生成捡货单编号*/
			declare @JHbillnumber VARCHAR(50)   /*-捡货单编号 */
			declare @billdate datetime  /*-单据日期*/
			 set @nBillCount = 0
			 set @JHbillnumber = ''
			select @nBillCount = isnull(COUNT(billid),0) from billdraftidx where billtype = 254  /*获取捡货单单据数目*/
			select @billdate = billdate from billdraftidx where billid = @bill_id
			set @nBillCount=@nBillCount+1
			   set @JHbillnumber=''
			   set @JHbillnumber='JHD'+'-'+left(CONVERT(varchar,@billdate,21),10)+'-'+CAST(@nBillCount as varchar)
		       
			insert into billdraftidx
			(
			  billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,quantity,billstates,order_id,department_id,posid,
			  region_id,auditdate,note,invoice,transcount,GUID,InvoiceNO,GatheringMan,VIPCardID,Y_ID,integral
			)
			select billdate,@JHbillnumber,billtype,billid,c_id,e_id,sout_id,sin_id,auditman,inputman,@qtytotal,billstates,order_id,department_id,
			posid,region_id,auditdate,'由拣货单【'+billnumber+'】补拣货生成  '+note,invoice,transcount,GUID,InvoiceNO,GatheringMan,2,Y_ID,
			integral from billdraftidx where billid = @bill_id
		    
			if @@IDENTITY <= 0
			begin
			  raiserror('生成补拣货单主表错误！',16,1)
			  return -1
			end
			else
			begin
			  declare @newbill int 
			  set @newbill = @@IDENTITY
			  insert into salemanagebilldrf
			  (
				bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,totalmoney,taxprice,taxtotal,retailprice,
				retailtotal,makedate,validdate,qualitystatus,price_id,ss_id,sd_id,location_id,supplier_id,commissionflag,comment,
				unitid,taxrate,order_id,total,iotag,newprice,orgbillid,jsprice,AOID,invoice,PriceType,RowGuid,RowE_id,YGuid,Y_ID,
				transflag,instoretime,cxType,location_id2,comment2,BatchBarCode,scomment,batchprice,CxGuid
			  )
			  select @newbill,p_id,batchno,(quantity-SendQTY),costprice,saleprice,discount,discountprice,0,taxprice,0,retailprice,
			  0,makedate,validdate,qualitystatus,price_id,ss_id,sd_id,location_id,supplier_id,commissionflag,dbo.GetProductComment(p_id, (quantity-SendQTY)),
			  unitid,taxrate,smb_id,total,iotag,newprice,orgbillid,jsprice,0,invoice,PriceType,NEWID(),RowE_id,YGuid,Y_ID,
			  transflag,instoretime,cxType,location_id2,comment2,BatchBarCode,scomment,batchprice,CxGuid
			  
			   from salemanagebilldrf where bill_id = @bill_id and SendQTY <> quantity and AOID = 6
			   
			  if @@IDENTITY <= 0
			  begin
				raiserror('生成补拣货单明细错误！',16,1)
				return -2
			  end
			  else
			  begin
				/*------更新原拣货单数量为实际拣货数量*/
				update salemanagebilldrf set quantity = SendQTY, comment = dbo.GetProductComment(p_id, SendQTY) where bill_id = @bill_id and SendQTY <> quantity and AOID = 6
				/*------更新拣货单主表*/
				update billdraftidx set quantity =  mx.qty from 
				(select bill_id,sum(quantity) as qty from salemanagebilldrf where bill_id = @bill_id group by bill_id) mx
				where billid = mx.bill_id
				
				 /*-----------判断原单是否是全部无库存或漏拣货，是则删除原单据草稿防止原单打开报错 add by luowei 2013-11-21*/
				  if not exists(select 1 from billdraftidx where billtype = 254 and quantity > 0 and order_id in (select order_id from billdraftidx where billid = @bill_id))
				  begin
					declare @nbillid int 
					select @nbillid = order_id from billdraftidx where billid = @bill_id
				     
					delete from salemanagebilldrf where bill_id = @nbillid
					delete from billdraftidx where billid = @nbillid
				  end    
				
				return 1
			  end
			end
		end
    end
    
    
     /*-----------判断原单是否是全部无库存或漏拣货，是则删除原单据草稿防止原单打开报错 add by luowei 2013-11-21*/
  if not exists(select 1 from billdraftidx where billtype = 254 and quantity > 0 and order_id in (select order_id from billdraftidx where billid = @bill_id))
  begin
    declare @ibillid int 
    select @ibillid = order_id from billdraftidx where billid = @bill_id
     
    delete from salemanagebilldrf where bill_id = @ibillid
    delete from billdraftidx where billid = @ibillid
  end    
   
end
GO
