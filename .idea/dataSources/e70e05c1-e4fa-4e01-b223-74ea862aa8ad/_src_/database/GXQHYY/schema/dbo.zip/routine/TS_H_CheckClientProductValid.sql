
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014.6.12*/
/* Description:	检测往来单位（分支机构）和商品对应关系*/
/* =============================================*/
CREATE PROCEDURE TS_H_CheckClientProductValid 
	@nCid int = 0, /*往来单位id*/
	@nPid int = 0, /*商品id*/
	@nWtId int = 0, /*委托书id*/
	@nBillType int = 0, /*单据类型*/
	@CType int = 0, /* rangecheck表的ctype*/
	@GHSCid int = 0 /*商品的供货单位id*/
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nRet int
	DECLARE @nCType int
	DECLARE @nGHSCType int
	DECLARE @dtPReg datetime
	DECLARE @dtPPermit datetime
	DECLARE @dtPGMP datetime
	DECLARE @dtGHWTS datetime
	SET @nRet = 0
	
	/* 获取所属类型 1：生产企业 2：批发 3：医疗机构 4：连锁 */
	SELECT @nCType = ent_type FROM clients WHERE client_id = @nCid  
	if (@GHSCid <> 0) and (@nBillType in (14, 10, 210)) 
	/*销售订单判断勾选了’流通次数控制‘的商品销售的时候的单位匹配（进货单位是生成企业的可以销售给任何单位，批发、连锁、医疗只能销售给医疗机构）*/
	begin
		if Exists(select 1 from products where product_id = @nPid and LTTime = 1)/*检测商品是否为流通次数控制*/
		begin
			SELECT @nGHSCType = ent_type FROM clients WHERE client_id = @GHSCid
			if @nGHSCType in (2, 3, 4)	/*供应商不是生成企业*/
			begin
				if @nCid <> 3 /*销售往来单位不是医疗机构*/
				return -1  /*商品启用了<流通次数控制>，供应商为流通企业则只能销售给医疗机构*/
			end			
		end
		return 0
	end

    if (@nWtId <> 0) and (@nCType <> 3) 
    /*判断供货商委托书的有效期是否过期(要排除医疗机构，医疗机构不判断是否过期)*/
    begin
      IF @nBillType IN (22, 20, 220)
      begin
        select @dtGHWTS = validDate  from wtorder where WT_ID = @nWtId
        if @dtGHWTS > '1900-1-1' and @dtGHWTS < GETDATE()
           Return -2  /*供货商委托书有效期过期*/
      end
      return 0
    end

	/* 首先判断商品3个有效期，采购生效*/
	IF @nBillType IN (22, 20, 220) /*采购订单，采购入库单，采购单*/
	BEGIN
		SELECT @dtPReg = Registervalid, @dtPPermit = PerCodevalid, @dtPGMP = GMPvaliddate FROM products WHERE product_id = @nPid
		IF @dtPReg > '1900-1-1' AND @dtPReg < GETDATE()
			RETURN -3
		IF @dtPPermit > '1900-1-1' AND @dtPPermit < GETDATE()
			RETURN -4
		IF @dtPGMP > '1900-1-1' AND @dtPGMP < GETDATE()
			RETURN -5
	END

	IF @nBillType IN (22, 20, 220, 14, 10, 210) /* 往来单位 select Vch_ID from VchType*/
	BEGIN
		IF @nCType = 1 /* 生产企业判断剂型*/
		BEGIN
			IF NOT EXISTS(SELECT 1
				FROM dbo.GMPMedtype AS M INNER JOIN
				dbo.GMPIndex AS A ON M.ga_id = A.g_id INNER JOIN
				dbo.products AS P ON M.mt_id = P.medtype
				WHERE A.c_id = @nCid AND P.product_id = @nPid)
			RETURN -6	/*所选商品超出往来单位生产范围	*/
			if not exists(select 1 
			    from GMPIndex where c_id = @nCid and validdate >= GETDATE())
			return -7 /*GMP证书过期*/
		END
		if @CType=0
		begin
		   set @CType=1
		end
		if @CType=1
		begin
		   set @CType=2
		end
		else if @nCType in (2, 4) /*批发以及连锁类型*/
			 begin
			   IF EXISTS(SELECT 1 FROM customCategoryMapping WHERE  baseinfo_id = -1 and deleted=0)/*如果设置了本企业经营范围*/
			   begin
			      IF not EXISTS(SELECT r.category_id as r_id FROM customCategoryMapping r, products p,customCategory z WHERE r.baseinfo_id = p.product_id and r.category_id=z.id AND p.product_id = @nPid AND r.baseinfo_id = -1 and r.deleted=0)
			      return -8 /*所选商品超出本公司经营范围*/
			   end
			   else
			   begin
				   IF EXISTS (SELECT 1 FROM customCategoryMapping WHERE baseinfo_id = @nCid AND BaseTypeid = @CType and deleted=0) /*如果存在经营范围定义才检查*/
				   begin
					   if not EXISTS(SELECT 1 FROM customCategoryMapping r, products p,customCategory z WHERE r.baseinfo_id = p.product_id and r.category_id=z.id  AND p.product_id = @nPid AND r.baseinfo_id = @nCid AND r.BaseTypeid = @CType and r.deleted=0)
					   return -9 /*经营范围不匹配*/
				   end
			   end
			 end else if @nCType = 3  /*医疗机构判断商品的诊疗范围和单位的诊疗范围是否一致*/
					  begin
						IF NOT EXISTS(SELECT  1 
									FROM dbo.products AS P 
									INNER JOIN
										(SELECT   cm_id, baseInfoType, info_id, cr_id, cr_class_id
										 FROM      dbo.clinicRangeMapping
										 WHERE   (baseInfoType = 1)) AS PM ON P.product_id = PM.info_id 
									INNER JOIN
										(SELECT   cm_id, baseInfoType, info_id, cr_id, cr_class_id
										 FROM      dbo.clinicRangeMapping AS clinicRangeMapping_1
										 WHERE   (baseInfoType = 2)) AS CM 
										 INNER JOIN dbo.clients AS C ON CM.info_id = C.client_id 
									ON CM.cr_id = PM.cr_id
									WHERE C.client_id = @nCid AND P.product_id = @nPid)
						RETURN -10  /*所选商品超出往来单位诊疗范围*/
			          end
	END
	ELSE
	
	/* 分支机构(暂时不写)*/
	BEGIN
	  select 1
	END
    return 0 /*检测通过*/
END
GO
