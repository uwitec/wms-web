/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-10-23*/
/* Description:	单据提示相应操作*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_BillHintAct] 
	@Act		int, /* 操作 0：列出可用单据 1：设置下次提醒时间 2：检测是否有新单据*/
	@nBillId	int = 0, /* 单据ID*/
	@nBillType	int = 0, /* 单据类型*/
	@nEid		int = 0, /* 职员*/
	@nYid		int = 0, /* 机构*/
	@dtNextHint	datetime = 0 /* 下次提示时间*/
AS
BEGIN
	SET NOCOUNT ON;

	IF @nBillId IS NULL SET @nBillId = 0
	IF @nBillType IS NULL SET @nBillType = 0
	IF @nEid IS NULL SET @nEid = 0
	IF @nYid IS NULL SET @nYid = 0
	IF @dtNextHint IS NULL SET @dtNextHint = 0

	DECLARE @nStandardProcess int	/* 是否启用标准流程*/
	SET @nStandardProcess = 0
	SELECT @nStandardProcess = sysvalue FROM sysconfigtmp WHERE sysname = 'GspStandardProcess'

	IF @Act = 0
	BEGIN
		CREATE TABLE #tmpBill(billtype int, billid int, billnumber varchar(50), e_id int, billdate datetime)
		/* 总部提示单据*/
		IF @nYid = 2
		BEGIN
			IF dbo.A_GetSubLimit(@nEid, 62, -1) = 1	/* 机构请货单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM         dbo.TranIdx
				WHERE     (c_id > 2) AND (CenterAuditMan = 0)
					 AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 52 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)
			IF DBO.A_GetSubLimit(@nEid, 9507, -1) = 1 /* 机构退货验收单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, Gspbillid, billnumber, inputman, billdate
				FROM          dbo.GSPbillidx
				WHERE      (billtype = 524) AND (BillStates = 10) and (y_id = 0 or y_id =
				@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 524 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		   IF DBO.A_GetSubLimit(@nEid, 9, -1) = 1 /* 付款单*/
		        INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM          dbo.billidx 
				WHERE      (billtype = 23) and (y_id = 0 or y_id =
				@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 23 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)	
		END
		ELSE
		/* 分支机构提示单据*/
		BEGIN
			IF dbo.A_GetSubLimit(@nEid, 70, -1) = 1	/* 商品调价单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM         dbo.PriceIdx
				/*WHERE     (billstates = '3') AND (posid = @nYid OR posid = 0 AND region_id = (SELECT region_id FROM company WHERE company_id = @nYid))*/
				WHERE (billstates = '3') /*AND ((CharIndex(CAST(@nYid as varchar) + ',', posid + ',', 1) > 0) OR posid = '0' AND region_id = (SELECT region_id FROM company WHERE company_id = @nYid))*/
					 AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 140 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

			IF DBO.A_GetSubLimit(@nEid, 9506, -1) = 1 /* 机构入库验收单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, Gspbillid, billnumber, inputman, billdate
				FROM          dbo.GSPbillidx
				WHERE      (billtype = 523) AND (BillStates = 10) and (y_id = 0 or y_id =
				@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 523 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)
		END
		/* 所有机构都需要提示的单据*/
		IF DBO.A_GetSubLimit(@nEid, 9501, -1) = 1 /* 销售退回收货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 512) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 512 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9503, -1) = 1 /* 冷藏药品销售退回收货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 514) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 514 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9504, -1) = 1 /* 采购验收单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 521) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 521 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9505, -1) = 1 /* 销售退回验收单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 522) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 522 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9508, -1) = 1 /* 上架确认单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 531) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 531 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9509, -1) = 1 /* 拣货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 541) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 541 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9510, -1) = 1 /* 复核单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 551) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 551 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9511, -1) = 1 /* 采购退出申请单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 561) AND (BillStates IN (10, 12)) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 561 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9512, -1) = 1 /* 销售退回申请单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 562) AND (BillStates IN (10, 12)) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 562 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 0, -1) = 1) /* 销售出库单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 10) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 10 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 6, -1) = 1) /* 采购入库单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 20) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 20 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 1, -1) = 1) /* 销售出库退货单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 11) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 11 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 7, -1) = 1) /* 采购入库退货单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 21) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 21 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		SELECT     x.billtype, x.billid, x.billnumber, x.e_id, v.Comment, e.name
		FROM       #tmpBill
		AS x INNER JOIN
		dbo.employees AS e ON x.e_id = e.emp_id LEFT OUTER JOIN
		dbo.VchType AS v ON x.billtype = v.Vch_ID
		where x.billtype in (select Distinct Billtype from BillTypeHintSet where EID = @nEid)/*zjx--2017-01-19--tfs45069--以前注释不明原因，现在放开，解决受单据提醒设置不受控制的问题*/
		ORDER BY x.billdate
		DROP TABLE #tmpBill
	END
	ELSE
	IF @Act = 1
	BEGIN
		UPDATE BillHint SET States = 1, ShowTime = @dtNextHint WHERE billId = @nBillId AND billtype = @nBillType AND E_ID = @nEid AND Y_ID = @nYid
		IF @@ROWCOUNT = 0
			INSERT INTO BillHint(billId, BillType, E_ID, States, ShowTime, Y_ID) VALUES(@nBillId, @nBillType, @nEid, 1, @dtNextHint, @nYid)
	END
	ELSE
	IF @Act = 2
	BEGIN
		/*CREATE TABLE #tmpBill(billtype int, billid int, billnumber varchar(50), e_id int, billdate datetime)*/
		/* 总部提示单据*/
		IF @nYid = 2
		BEGIN
			IF dbo.A_GetSubLimit(@nEid, 62, -1) = 1	/* 机构请货单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM         dbo.TranIdx
				WHERE     (c_id > 2) AND (CenterAuditMan = 0)
					 AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 52 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)
			IF DBO.A_GetSubLimit(@nEid, 9507, -1) = 1 /* 机构退货验收单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, Gspbillid, billnumber, inputman, billdate
				FROM          dbo.GSPbillidx
				WHERE      (billtype = 524) AND (BillStates = 10) and (y_id = 0 or y_id =
				@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 524 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)
		    IF DBO.A_GetSubLimit(@nEid, 9, -1) = 1 /* 付款单*/
		        INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM          dbo.billidx 
				WHERE      (billtype = 23) and (y_id = 0 or y_id =
				@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 23 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)	
		
		END
		ELSE
		/* 分支机构提示单据*/
		BEGIN
			IF dbo.A_GetSubLimit(@nEid, 70, -1) = 1	/* 商品调价单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, billid, billnumber, e_id, billdate
				FROM         dbo.PriceIdx
				/*WHERE     (billstates = '3') AND (posid = @nYid OR posid = 0 AND region_id = (SELECT region_id FROM company WHERE company_id = @nYid))*/
				WHERE (billstates = '3') AND ((CharIndex(CAST(@nYid as varchar) + ',', posid + ',', 1) > 0) OR posid = '0' AND region_id = (SELECT region_id FROM company WHERE company_id = @nYid))
					 AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 140 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

			IF DBO.A_GetSubLimit(@nEid, 9506, -1) = 1 /* 机构入库验收单*/
				INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
				SELECT     billtype, Gspbillid, billnumber, inputman, billdate
				FROM          dbo.GSPbillidx
				WHERE      (billtype = 523) AND (BillStates = 10) and (y_id = 0 or y_id =
				@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 523 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)
		END
		/* 所有机构都需要提示的单据*/
		IF DBO.A_GetSubLimit(@nEid, 9501, -1) = 1 /* 销售退回收货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 512) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 512 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9503, -1) = 1 /* 冷藏药品销售退回收货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 514) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 514 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9504, -1) = 1 /* 采购验收单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 521) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 521 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9505, -1) = 1 /* 销售退回验收单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 522) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 522 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9508, -1) = 1 /* 上架确认单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 531) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 531 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9509, -1) = 1 /* 拣货单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 541) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 541 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9510, -1) = 1 /* 复核单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 551) AND (BillStates = 10) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 551 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9511, -1) = 1 /* 采购退出申请单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 561) AND (BillStates IN (10, 12)) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 561 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF DBO.A_GetSubLimit(@nEid, 9512, -1) = 1 /* 销售退回申请单*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, Gspbillid, billnumber, inputman, billdate
			FROM          dbo.GSPbillidx
			WHERE      (billtype = 562) AND (BillStates IN (10, 12)) and (y_id = 0 or y_id =
			@nYid) AND Gspbillid NOT IN(SELECT billid FROM BillHint WHERE billtype = 562 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 0, -1) = 1) /* 销售出库单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 10) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 10 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 6, -1) = 1) /* 采购入库单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 20) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 20 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 1, -1) = 1) /* 销售出库退货单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 11) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 11 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		IF (@nStandardProcess = 1) AND (DBO.A_GetSubLimit(@nEid, 7, -1) = 1) /* 采购入库退货单，启用标准流程才返回*/
			INSERT INTO #tmpBill(billtype, billid, billnumber, e_id, billdate)
			SELECT     billtype, billid, billnumber, inputman, billdate
			FROM          dbo.billdraftidx
			WHERE      (billtype = 21) AND (BillStates = 2) and (y_id = 0 or y_id =
			@nYid) AND billid NOT IN(SELECT billid FROM BillHint WHERE billtype = 21 AND States = 1 AND ShowTime > GETDATE() AND E_ID = @nEid AND Y_ID = @nYid)

		/*SELECT     x.billtype, x.billid, x.billnumber, x.e_id, v.Comment, e.name*/
		/*FROM       #tmpBill*/
		/*AS x INNER JOIN*/
		/*dbo.employees AS e ON x.e_id = e.emp_id LEFT OUTER JOIN*/
		/*dbo.VchType AS v ON x.billtype = v.Vch_ID*/
		/*ORDER BY x.billdate*/
		IF EXISTS(SELECT * FROM #tmpBill where billtype in (select Distinct Billtype from BillTypeHintSet where EID = @nEid))/*zjx--2017-01-19--tfs45069--以前注释不明原因，现在放开，解决受单据提醒设置不受控制的问题*/
			RETURN 1
		ELSE
			RETURN 0

		DROP TABLE #tmpBill
	END
END
GO
