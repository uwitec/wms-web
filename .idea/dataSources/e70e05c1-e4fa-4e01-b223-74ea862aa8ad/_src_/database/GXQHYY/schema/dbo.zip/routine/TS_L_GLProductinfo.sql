

CREATE procedure TS_L_GLProductinfo
(
  @GLName varchar(200),   /*--关联名称*/
  @GL_PidArr varchar(8000),  /*关联商品 p_id 数组*/
  @GL_Comment varchar(200),   /*关联说明*/
  @GL_index_idArr varchar(8000),  /*indx_id 数组 */
  @nTag int     /*----@ntag 0 :查询，1：添加，2 ：修改，3：删除 ，4：查询关联商品*/
)
as
begin
  if @nTag = 0    /*---查询*/
  begin
    select P.*,gl.*,isnull(fa.AccountComment,'') as 'factoryName' from vw_Products P
	inner join gl_products gl on product_id = p_id
	left join (select * from  basefactory) FA on factoryc_id = commID 
  end
  
  if @nTag = 1   /*----新增*/
  begin
	  declare @nbegin int
	  declare @nlen int
	  declare @p_id int
	  
	  set @nbegin = 1
	  set @nlen = 0
	  while(CHARINDEX(',',@GL_PidArr,@nbegin) > 0)
	  begin
		set @nlen = CHARINDEX(',',@GL_PidArr,@nbegin)
		set @p_id = SUBSTRING(@GL_PidArr,@nbegin,@nlen-@nbegin)
		set @nbegin = @nlen+1
		insert into GL_Products(GLName,P_id,GLComment)values (@GLName,@p_id,@GL_Comment)
	  end
  end
  
  if @nTag = 2 /*-修改*/
  begin
    delete GL_Products where idx_id =  @GL_index_idArr
    insert into GL_Products(GLName,P_id,GLComment)values (@GLName,@GL_PidArr,@GL_Comment)
  end
  
  if @nTag = 3 /*-删除*/
  begin
    declare @szsql varchar(8000)
    if @GL_PidArr <> ''
    begin
      if CHARINDEX(',',@GL_index_idArr,1) <1 
      begin
        delete GL_Products where idx_id =  @GL_index_idArr
      end
      else
      begin
       set @szsql =  'delete GL_Products where idx_id in ('+SUBSTRING(@GL_index_idArr,1,LEN(@GL_index_idArr)-1)+ ')'
       exec (@szsql)
      end       
    end
  end
  
  if @nTag = 4 
  begin
    select P.*,gl.*,isnull(fa.AccountComment,'') as 'factoryName' from vw_Products P
	inner join 
	      (
	         select * from gl_products 
	         where GLName in (select GLName FROM gl_products WHERE P_id = cast(@GL_PidArr as int))
	         AND P_id <> @GL_PidArr
	      ) gl on product_id = p_id
	left join (select * from  basefactory) FA on factoryc_id = commID
  end  
end
GO
