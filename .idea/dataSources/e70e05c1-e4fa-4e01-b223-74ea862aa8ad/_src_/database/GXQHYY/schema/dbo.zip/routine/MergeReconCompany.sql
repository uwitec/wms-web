
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-1-14*/
/* Description:	合并对账计划中的机构名称*/
/* =============================================*/
CREATE FUNCTION MergeReconCompany 
(
	@col int
)
RETURNS varchar(5000)
AS
BEGIN
	DECLARE @Result varchar(5000)

	SELECT @Result = ISNULL(@Result + ',', '') + name from company where company_id in (select y_id from reconciliationResult where plan_id = @col)

	RETURN @Result

END
GO
