



CREATE VIEW dbo.vw_z_EmployeeTC
AS
SELECT E.*, TP.Name AS TpName, TP.ProType, TP.f_id, TP.Comment AS TpComment, 
      TP.CreateMan, TP.CreateDate, F.Name AS FName, F.tcType
FROM dbo.TcFormula F INNER JOIN
      dbo.TcProject TP ON F.Formula_id = TP.f_id RIGHT OUTER JOIN
      dbo.employees E ON TP.TcProject_id = E.Tp_ID
WHERE (E.deleted <> 1)
GO
