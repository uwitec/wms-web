
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2016-3-1*/
/* Description:	查询及处理质量基础数据变动记录*/
/* =============================================*/
CREATE PROCEDURE TS_H_BaseInfoChangeLogAct 
	@Act int = 0,	/* 操作：0 查询列表；1 变动详情；2 审核通过/不通过*/
	@BeginDate datetime = '1900-1-1',
	@EndDate datetime = '2999-12-31',
	@BaseInfoType varchar(10) = '',
	@RequestMan int = 0,
	@AuditMan int = 0,
	@Status int = -1,
	@HisIDs varchar(8000) = '',
	@AuditOption varchar(500) = '',
	@HisID int = 0,
	@GroupGUID uniqueidentifier = 0x0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @nBaseInfoID int

	IF @Act = 0
	BEGIN
		SELECT ER.name AS RequestMan, RequestDate, CASE Status WHEN 0 THEN '待审核' WHEN 1 THEN '审核通过' WHEN 2 THEN '审核未通过' ELSE '' END AS AuditStatus,
			ISNULL(EA.name, '') AS AuditMan, NULLIF(AuditDate, '1900-1-1') AS AuditDate, bih.Comment as Comment,
			His_ID, BaseInfo_ID, BaseInfoType, Status AS StatusID, GroupGUID
		FROM BaseInfoHistory bih 
		INNER JOIN employees ER ON BIH.RequestMan = ER.emp_id
		LEFT JOIN employees EA ON bih.AuditMan = EA.emp_id
		WHERE RequestDate BETWEEN @BeginDate AND @EndDate AND (RequestMan = @RequestMan OR @RequestMan = 0)
			AND BaseInfoType = @BaseInfoType AND (Status = @Status OR @Status = -1)
	END
	ELSE
	IF @Act = 1
	BEGIN
		DECLARE @nXmlHandle int
		DECLARE @xml xml
		SELECT @xml = NewContent, @nBaseInfoID = BaseInfo_ID FROM BaseInfoHistory WHERE His_ID = @HisID
		EXEC sp_xml_preparedocument @nXmlHandle OUTPUT, @xml

		IF @BaseInfoType = 'P'
		BEGIN
			select @nBaseInfoID as product_id, * 
			INTO #TP
			from OPENXML(@nXmlHandle, 'root/products', 1)
			with products

			SELECT TOP 1 @xml = NewContent FROM BaseInfoHistory WHERE BaseInfo_ID = @nBaseInfoID AND BaseInfoType = 'PB' AND GroupGUID = @GroupGUID
			EXEC sp_xml_preparedocument @nXmlHandle OUTPUT, @xml

			select * 
			INTO #TPB
			from OPENXML(@nXmlHandle, 'root/Productbalance', 1)
			with Productbalance

			SELECT a.*, b.*, c.name as MedName, ISNULL(u1.name, '') as Unit1Name
			, ISNULL(uh.name, '') as WholeUnitName, ISNULL(u2.name, '') as Unit2Name, ISNULL(u3.name, '') as Unit3Name 
			, ISNULL(u4.name, '') as Unit4Name, d.*, e.TaxRate as TaxRateName, ISNULL(pc.pc_name, '') as PcName,
			ISNULL(se.name,'') as szEName,isnull(sp.name,'') as szCName,ISNULL(sg.loc_name,'') as locname
			,ISNULL(wl.loc_name,'') as WholeLocName,ISNULL(sl.loc_name,'') as SingleLocName
			FROM #TP a 
			inner JOIN customCategory c on a.medtype=c.id
			inner join productsExtend d on a.product_id = d.p_id
			inner join VW_TaxRate e on a.product_id = e.product_id
			LEFT JOIN #TPB b ON a.product_id = b.p_id
			left join unit uh on a.WholeUnit_id = uh.unit_id
			left join unit u1 on a.unit1_id = u1.unit_id
			left join unit u2 on a.unit2_id = u2.unit_id
			left join unit u3 on a.unit3_id = u3.unit_id
			left join unit u4 on a.unit4_id = u4.unit_id
			LEFT OUTER JOIN	dbo.PrintClass pc ON a.PrintClass = pc.pc_id
			left join clients sp on b.Supplier_id=sp.client_id
			left join employees se on b.emp_id=se.emp_id
			left join location sg  on b.locationid=sg.loc_id
			left join location wl  on b.WholeLoc=wl.loc_id
			left join location sl  on b.SingleLoc=sl.loc_id
			DROP TABLE #TP
			DROP TABLE #TPB
		END
		ELSE
		IF @BaseInfoType = 'C'
		BEGIN
			select @nBaseInfoID as client_id, * 
			INTO #TC
			from OPENXML(@nXmlHandle, 'root/clients', 1)
			with clients

			SELECT TOP 1 @xml = NewContent FROM BaseInfoHistory WHERE BaseInfo_ID = @nBaseInfoID AND BaseInfoType = 'CB' AND GroupGUID = @GroupGUID
			EXEC sp_xml_preparedocument @nXmlHandle OUTPUT, @xml

			select * 
			INTO #TCB
			from OPENXML(@nXmlHandle, 'root/Clientsbalance', 1)
			with Clientsbalance

			SELECT a.*,b.*,isnull(cty.name,'') as ctypename,isnull(rg.name,'') as rgname,isnull(ey.name,'') as Ename,
			       isnull(sr.RoadName,'') as RdName FROM #TC  a 
			                  LEFT JOIN #TCB b ON a.client_id = b.c_id
			                  left join clienttype cty on a.Clienttype_id=cty.Clienttype_id 
			                  left join region rg  on  a.region_id=rg.region_id
			                  left join employees ey on a.e_id=ey.emp_id
			                  left join SendRoad sr  on a.roadid=sr.RoadID

			DROP TABLE #TC
			DROP TABLE #TCB
		END
		ELSE
		IF @BaseInfoType = 'CR'
		BEGIN
			DECLARE @nEntType int
			SELECT @nBaseInfoID = BaseInfo_ID FROM BaseInfoHistory WHERE BaseInfoType = @BaseInfoType AND GroupGUID = @GroupGUID
			SELECT @nEntType = ent_type FROM clients 
			WHERE client_id = @nBaseInfoID
			SELECT @xml = (SELECT cast((select cast(NewContent as xml) FROM BaseInfoHistory WHERE BaseInfoType = 'cr' AND GroupGUID = @GroupGUID for xml path('')) as xml) for xml raw)
			EXEC sp_xml_preparedocument @nXmlHandle OUTPUT, @xml
			select *
			INTO #TCR
			from OPENXML(@nXmlHandle, 'row/root/ClientReport2', 1)
			with ClientReport2
			select distinct cl.repname, cr.repNo,cr.inputtime, isnull(cr.validtime,'1900-01-01') as valid, cr.Pathname as pathn,cl.cl_id as rpn_id
			from BindLicense bl inner join ClientLicense cl on bl.cl_id = cl.cl_id
			left join #TCR cr on cl.cl_id = cr.rpn_id and Ctype = 0 and c_id = @nBaseInfoID
			where ent_type = @nEntType order by cl.cl_id

			DROP TABLE #TCR
		END
		ELSE
		IF @BaseInfoType = 'CCMC'
		BEGIN
			SELECT @xml = (SELECT cast((select cast(NewContent as xml) FROM BaseInfoHistory WHERE BaseInfoType = 'CCMC' AND GroupGUID = @GroupGUID for xml path('')) as xml) for xml raw)
			EXEC sp_xml_preparedocument @nXmlHandle OUTPUT, @xml
			select *
			INTO #TCCMC
			from OPENXML(@nXmlHandle, 'row/root/customCategoryMapping', 1)
			with customCategoryMapping

			SELECT   rid, rname, deleted, modifyDate, CASE tsid WHEN 0 THEN 0 ELSE 1 END AS tsid
			FROM      (SELECT   ISNULL(a.id, 0) AS rid, a.name AS rname, 0 AS deleted, a.modifyDate, ISNULL(b.category_id, 0) AS tsid
				FROM      (SELECT   id, name, class_id, parent_id, baseType, rowIndex, modifyDate, deleted, pinyin, Child_Number, 
					Child_Count, Typeid
					FROM      dbo.customCategory
					WHERE   (baseType = -1) AND (Child_Number = 0)) AS a LEFT OUTER JOIN
					(SELECT * FROM #TCCMC) AS b ON a.id = b.category_id) AS c
			ORDER BY rname
			DROP TABLE #TCCMC
		END
		EXEC sp_xml_removedocument @nXmlHandle
	END
	ELSE
	IF @Act = 2
	BEGIN
		/* 审核成功*/
		/* 太复杂，客户端实现*/
		/*IF @Status = 1*/
		/*BEGIN*/
		/*	SELECT [TYPE] INTO #T*/
		/*	FROM dbo.DecodeStr(@HisIDs)*/

		/*	DELETE FROM #T*/
		/*	WHERE [TYPE] IN (SELECT His_ID FROM BaseInfoHistory WHERE Status <> 0)*/

		/*	WHILE EXISTS(SELECT * FROM #T)*/
		/*	BEGIN*/
		/*		DECLARE @nBaseInfoID int*/

		/*		SELECT TOP 1 @HisID = [TYPE] FROM #T*/

		/*		SELECT @nBaseInfoID = BaseInfo_ID, @BaseInfoType = BaseInfoType */
		/*		FROM BaseInfoHistory WHERE His_ID = @HisID*/


		/*		DELETE FROM #T WHERE [TYPE] = @HisID*/
		/*	END*/
		/*END*/

		UPDATE BaseInfoHistory SET [Status] = @Status, AuditMan = @AuditMan, AuditDate = GETDATE(), Comment = @AuditOption
		WHERE GroupGUID IN(SELECT GroupGUID FROM BaseInfoHistory WHERE His_ID IN(SELECT [TYPE] FROM dbo.DecodeStr(@HisIDs))) AND Status = 0
	END
END
GO
