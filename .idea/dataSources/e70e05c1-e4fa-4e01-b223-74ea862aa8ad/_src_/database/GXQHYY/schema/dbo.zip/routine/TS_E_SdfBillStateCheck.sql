create procedure TS_E_SdfBillStateCheck
 @StartData datetime,
 @EndDate   datetime,
 @B_id      int,
 @BillNumber varchar(100),
 @nMode int,
 @nY_ID int
as
begin
   declare @billid int 
  select @billid = MAX(billid) from sfda_billidx
  if @billid is null set @billid = 0
   
  insert into sfda_billidx(billid)
    select distinct pd.billid 
      from Sfda_Detail pd     
      inner join billidx bi on bi.billid = pd.billid
      where pd.billid > @billid and bi.billstates = 0 
            and bi.billtype in (10, 11, 12, 13, 20, 21, 41, 150, 152, 151, 153, 162, 160)  /*修改单据类型需要和保存单据一致 */
                         

	select a.billdate,isnull(a.billnumber,'') as billnumber,isnull(b.Comment,'') as bname,
	       CASE WHEN a.billtype IN (10, 11, 12, 13, 20, 21, 41) THEN isnull(c.name,'') 
	            WHEN a.billtype IN (150, 151, 152, 153) THEN ISNULL(c2.name, '') ELSE ''
	       END AS cname,
	       isnull(d.name,'') as ename,
		   isnull(inputman,'') as  inputman,isnull(e.name,'') as auditMan, a.billid, a.Y_ID, ISNULL(y.name, '') as YName, sf.sfda_transflag,
		   Case sfda_transflag when 0 then '否' when 1 then '是' when 2 then '强制完成' else '' end  as ifupload   
      from billidx a
		  inner join sfda_billidx sf on a.billid = sf.billid		   
		  LEFT JOIN VCHTYPE B ON A.BILLTYPE=B.VCH_ID
		  LEFT JOIN CLIENTS C ON A.C_ID=C.CLIENT_ID
		  LEFT JOIN EMPLOYEES D ON A.E_ID=D.EMP_ID
		  LEFT JOIN EMPLOYEES E ON A.AUDITMAN=E.EMP_ID
		  LEFT JOIN company  Y on a.Y_ID = Y.company_id
		  LEFT JOIN company c2 ON a.c_id = c2.company_id
		  WHERE a.billdate BETWEEN @STARTDATA AND @ENDDATE
		        AND (A.C_ID=@B_ID OR @B_ID=0) 
		        AND a.billnumber LIKE '%'+@BILLNUMBER+'%'
		        and (a.Y_ID = @nY_ID or @nY_ID = 0) 	
		        and ((@nMode = 0 and sf.sfda_transflag = 0) or @nMode = 2) 
		        and a.billstates = '0'
		        		        						  
end
GO
