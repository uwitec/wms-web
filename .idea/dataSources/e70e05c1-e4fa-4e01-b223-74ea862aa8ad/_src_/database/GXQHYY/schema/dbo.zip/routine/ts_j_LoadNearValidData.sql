
/*@nRet=0, 生成成功, -1 无数据返回*/

CREATE proc ts_j_LoadNearValidData

as	
	declare @curdate datetime
	set @CurDate = FLOOR(cast(GETDATE() as numeric(25,8)))
	
	
   SELECT p.code, p.Unit3Name, 
		  p.Unit2Name, p.Unit4Name, 
		  p.LatinName, p.ChemName, 
		  p.EngName, p.medtype, p.pinyin, 
		  p.makearea, p.trademark, 
		  p.permitcode, p.modal, p.standard, 
		  p.alias, p.name, p.serial_number, 
		  p.class_id, p.product_id, s.batchno, 
		  p.Posyhday, 
		  s.makedate, s.validdate,s.location_id,
		  SUM(s.costtotal) AS costtotal, SUM(s.costprice) AS costPrice, 
		  SUM(s.quantity) AS quantity, p.MedName, 
		  p.Unit1Name, s.s_id, ' ' as yhdate, 
		  s.instoretime, s.supplier_id, ISNULL(dbo.clients.name, '') 
		  AS CName, p.MaintainType, p.MaintainDay, 
		  p.validmonth, p.validday, p.gspflag, 
		  ISNULL(dbo.storages.name, '') AS sName,p.Factory, p.StorageCon,
		  p.PackStd
	FROM  vw_Products  p INNER JOIN
		  NearValidProducts s ON p.product_id = s.p_id LEFT OUTER JOIN
		  dbo.storages ON s.s_id = dbo.storages.storage_id LEFT OUTER JOIN
		  dbo.clients ON s.supplier_id = dbo.clients.client_id
	where s.CreateDate = @curdate	  
	GROUP BY p.code, p.Unit3Name, 
		  p.Unit2Name, p.Unit4Name, 
		  p.LatinName, p.ChemName, 
		  p.EngName, p.medtype, p.pinyin, 
		  p.makearea, p.trademark, 
		  p.permitcode, p.modal, p.standard, 
		  p.alias, p.name, p.serial_number, 
		  p.class_id, p.product_id, s.batchno, 
		  p.Posyhday, 
		  s.makedate, s.validdate, p.MedName, 
		  p.Unit1Name, s.s_id, 
		  s.instoretime, s.supplier_id, dbo.clients.name, 
		  p.MaintainType, p.MaintainDay, 
		  p.validmonth, p.validday, p.gspflag, 
		  dbo.storages.name,p.Factory,s.location_id, p.StorageCon,
		  p.PackStd
GO
