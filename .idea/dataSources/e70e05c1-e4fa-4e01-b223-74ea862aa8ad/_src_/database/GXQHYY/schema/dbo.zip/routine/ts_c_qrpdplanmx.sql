
create proc ts_c_qrpdplanmx
(
  @npdidx int
)
/*with encryption*/
as
set nocount on 
/*declare @sqlscript varchar(8000)*/
    select vs.*, isnull(pri.retailprice,0) as retailprice, isnull(pri.price1,0) as price1,
           isnull(pri.price2,0) as price2, isnull(pri.price3,0) as price3, isnull(pri.lowprice,0) as lowprice
    from (select dbo.products.name as pname, dbo.products.alias, dbo.products.standard, 
      m.name as medtype, dbo.products.makearea, dbo.products.serial_number as code, dbo.products.otcflag,
      pdplan.batchno, CAST(tx.name AS numeric(25,8)) as taxrate, pdplan.s_id, 
      dbo.products.validmonth, dbo.products.permitcode,dbo.products.comment,dbo.products.Factory, 
      dbo.products.Custompro1, dbo.products.Custompro2, dbo.products.Custompro3, dbo.products.Custompro4, dbo.products.Custompro5,       
      pdplan.quantity,pdplan.spquantity, PdPlan.pdflag, pdplan.PYquantity, pdplan.PKquantity,
      pdplan.costtotal, isnull(dbo.clients.name, '') as cname, 
      isnull(dbo.location.loc_name, '') as locname, dbo.storages.class_id as sclassid, 
      dbo.products.class_id as pclassid, isnull(dbo.clients.class_id, '') as cclassid, 
      pdplan.p_id, dbo.products.rate2, dbo.products.rate3, dbo.products.rate4, 
      isnull(dbo.unit.name, '') as name1, isnull(unit_1.name, '') as name2, 
      isnull(unit_2.name, '') as name3, isnull(unit_3.name, '') as name4, 
      dbo.storages.name as sname, pdplan.makedate, pdplan.validdate, 
      pdplan.costprice, pdplan.costtaxprice taxprice, pdplan.costtaxtotal taxtotal, pdplan.stopsaleflag, pdplan.supplier_id, 
      pdplan.location_id, pdplan.commissionflag, pdplan.instoretime,
      isnull(m.name, '') as medname,
      isnull(PrintClass.pc_Code,'') as PcCode,
      isnull(PrintClass.pc_Name,'') as PcName,
      ' ' as e_name, ' ' as c_name
       from dbo.unit right outer join
      dbo.unit unit_2 right outer join
      dbo.unit unit_3 right outer join
      
      dbo.products left outer join
	  (
			select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on products.product_id = m.baseinfo_id
	   left   join 
	  (
		select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=3 and b.deleted=0
	  )tx on products.product_id = tx.baseinfo_id
	  left outer join
      dbo.PrintClass on products.PrintClass=PrintClass.pc_id on 
      unit_3.unit_id = dbo.products.unit4_id left outer join
      dbo.unit unit_1 on dbo.products.unit2_id = unit_1.unit_id on 
      unit_2.unit_id = dbo.products.unit3_id on 
      dbo.unit.unit_id = dbo.products.unit1_id right outer join
      pdplan left outer join
      dbo.storages on pdplan.s_id = dbo.storages.storage_id left outer join
      dbo.location on pdplan.location_id = dbo.location.loc_id left outer join
      dbo.clients on pdplan.supplier_id = dbo.clients.client_id on 
      dbo.products.product_id = pdplan.p_id     
      where (dbo.products.deleted <> 1) and (dbo.storages.deleted = 0) and pdplan.pdidx=@npdidx
      ) vs 
      left join price pri on vs.p_id=pri.p_id and pri.unittype=1 order by vs.p_id, vs.batchno
GO
