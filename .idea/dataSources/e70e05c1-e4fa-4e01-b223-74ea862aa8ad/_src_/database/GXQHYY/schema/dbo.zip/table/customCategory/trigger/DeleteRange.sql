
CREATE TRIGGER [DeleteRange] ON [dbo].[customCategory] 
	FOR delete
	AS
	/*if update(deleted)*/
	begin
		delete from customCategoryMapping where category_id in (select id from deleted)/*where deleted=1)*/
	end
GO
