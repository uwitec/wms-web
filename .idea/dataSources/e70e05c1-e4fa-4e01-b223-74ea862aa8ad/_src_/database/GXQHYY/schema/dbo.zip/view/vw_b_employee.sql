















CREATE	VIEW dbo.vw_b_employee
AS
SELECT emp_id as e_id, name as e_name
FROM employees
/*不能加 deleted=0 否则当单据上的经手人停用后，单据打开会报错。*/
GO
