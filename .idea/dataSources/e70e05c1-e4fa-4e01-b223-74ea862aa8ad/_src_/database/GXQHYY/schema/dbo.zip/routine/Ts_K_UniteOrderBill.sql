
CREATE PROCEDURE Ts_K_UniteOrderBill
(
	@BillId   VARCHAR(5000) = '(0)',
    @nRet     INT OUTPUT
)
/*with encryption*/
AS
BEGIN
	DECLARE @BillResult TABLE (BillId INT)
	INSERT INTO @BillResult
	SELECT s.[str] FROM dbo.[Split](@BillId, ',') s
	
	DECLARE @MasterBillId INT
	SET @MasterBillId = 0
	SELECT @MasterBillId = a.BillId
	FROM   (
	           SELECT TOP 1 BillId FROM @BillResult ORDER BY BillId
	       ) a

	UPDATE a SET a.ysmoney = b.ysmoney, a.ssmoney = b.ssmoney, a.quantity = b.quantity, 
	             a.jsye = b.jsye, a.InvoiceTotal = b.InvoiceTotal FROM orderidx a, (
	             	SELECT SUM(o.ysmoney) AS ysmoney, SUM(o.ssmoney) AS ssmoney, SUM(o.quantity) AS quantity, 
						   SUM(o.jsye) AS jsye, SUM(o.InvoiceTotal) AS InvoiceTotal, @MasterBillId AS BillId
					  FROM orderidx o 
					WHERE o.billid IN (SELECT BillId FROM @BillResult) 
	             ) b 
	WHERE a.billid = b.BillId 
	
	UPDATE OrderBill SET bill_id = @MasterBillId WHERE bill_id IN (SELECT BillId FROM @BillResult)			
	
	DELETE FROM orderidx WHERE billid IN (SELECT BillId FROM @BillResult WHERE BillId <> @MasterBillId)
	
	SET @nRet = @MasterBillId
	
	RETURN @MasterBillId
END
GO
