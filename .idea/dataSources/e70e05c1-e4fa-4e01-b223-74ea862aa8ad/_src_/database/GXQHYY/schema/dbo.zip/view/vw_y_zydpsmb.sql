



CREATE VIEW dbo.vw_y_zydpsmb
AS
SELECT dbo.salemanagebill.*, ISNULL(storages_2.class_id, '') AS ssclass_id, 
      ISNULL(storages_1.class_id, '') AS sdclass_id, ISNULL(storages_2.name, '') 
      AS ssname, ISNULL(storages_1.name, '') AS sdname, ISNULL(u.name, '') 
      AS unitname, ISNULL(dbo.products.name, '') AS Pname, 
      ISNULL(dbo.products.class_id, '') AS PClass_ID,
      isnull(E.class_id,'') as REclass_ID,
      isnull(E.[name],'') as REname,
      sp.name as suppliername,
	  l1.loc_name as l1name,
	  l2.loc_name as l2name

FROM dbo.salemanagebill LEFT OUTER JOIN
      dbo.products ON 
      dbo.salemanagebill.p_id = dbo.products.product_id LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.salemanagebill.sd_id = storages_1.storage_id LEFT OUTER JOIN
      dbo.storages storages_2 ON 
      dbo.salemanagebill.ss_id = storages_2.storage_id LEFT OUTER JOIN
      dbo.unit u ON dbo.salemanagebill.unitid = u.unit_id  LEFT OUTER JOIN
      employees E ON salemanagebill.RowE_id=E.emp_id
      left outer join clients sp on salemanagebill.supplier_id=sp.client_id
      left outer join location l1 on salemanagebill.location_id=l1.loc_id
      left outer join location l2 on salemanagebill.location_id2=l2.loc_id
WHERE (dbo.salemanagebill.AOID = 0)
GO
