
create PROCEDURE Ts_T_QueryRetailGeneralReport
( 
  @BeginDate DateTime, /*开始时间*/
  @EndDate DateTime, /*结束时间*/
  @GroupType Int = -1, /*汇总条件 -1：无；0：机构YID， 1：收银员EID, 2：营业员INPUTMAN, 3:柜组：未知, 4:供应商：CID；*/
  @ProductChecked Int = 0, /*是否按商品，默认否0*/
  @ProductTypeChecked Int = 0, /*是否按商品类别，默认否0  */
  @PTypeID Int = 0, /*商品类别组ID，默认无0*/
  @PTypeRange Int = -1, /*商品类别层，大中小，默认无-1*/
  @TimeChecked Int = 0, /*是否时间段汇总，默认否0*/
  @TimeRange Int = -1, /*时间段范围，日月季度，默认无-1*/
  @YClass_id varchar(200) = '000000' /*分支机构*/
)      
 AS     
  IF @YClass_id is null set @YClass_id = ''
  /*EXEC语句  */
  DECLARE @TMPSQL VARCHAR(200)  /*临时使用*/
  DECLARE @INSSQL VARCHAR(8000) /*组合语句的INSERT部分*/
  DECLARE @SELSQL VARCHAR(8000) /*组合语句的SELECT部分*/
  DECLARE @GRPSQL VARCHAR(8000) /*组合语句的GROUP部分*/
  DECLARE @EXESQL VARCHAR(8000) /*组合后需执行SQL语句，由前三部分组装而成    */
    
  /*查询结果集临表*/
  Create Table #FinalData 
  (
    RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
    Y_ID INT NULL DEFAULT(0), /*零售单所属机构*/
    YClass_id VARCHAR(100) NULL DEFAULT(''), /*机构Class_id*/
    E_ID INT NULL DEFAULT(0), /*零售单营业员*/
    INPUTMAN INT NULL DEFAULT(0), /*零售单收银员*/
    TEAM INT NULL DEFAULT(0), /*柜组，意义未知，预留*/
    SUPPLIERID INT NULL DEFAULT(0), /*供应商           */
    PTypeID INT NULL DEFAULT(0), /*商品类别组ID*/
    PTypeRange VARCHAR(100) NULL DEFAULT(''), /*商品类别大中小*/
    DATERANGE VARCHAR(100) NULL DEFAULT(''), /*时间类别大中小*/
    PID INT NULL DEFAULT(0), /*商品ID*/
    AOID int null DEFAULT(0), /*商品状态,诊疗费用为8,需与Products区分 Add-Wsj-tfsbug44599-2016-12-30  */
    /*以下三个为计算辅助字段*/
    CBeginDate VARCHAR(20) Not Null Default(''), /*开始日期*/
    CEndDate VARCHAR(20) Not Null Default(''),  /*结束日期*/
    CTypeRange VARCHAR(20) Not Null Default(''), /*商品类别层*/
    /*以下五个字段根据实际需要在获取数据集后重新计算  */
    SumPGNumInstore INT NULL, /*库存品规数*/
    SumPGNumSaled INT NULL, /*动销品规数    */
    AveSaleMByday numeric(25,8) NULL, /*日均销售额     */
    SumNumInStore INT NULL, /*库存数量*/
    PGNumNewInstore INT NULL, /*新品品规数   */
    SaleNumByDay numeric(25,8) NULL, /*日均销量*/
    /*END*/
    SumRetailtotal numeric(25,8) NULL DEFAULT(0),  /*零售金额*/
    /*优惠金额算法未知*/
    SumPreMoney numeric(25,8) NULL DEFAULT(0), /*优惠金额*/
    
    SumTaxTotal numeric(25,8) NULL DEFAULT(0),  /*实收金额*/
    SumTotalMoney numeric(25,8) NULL DEFAULT(0),  /*无税实收*/
    SumCosttaxTotal numeric(25,8) NULL DEFAULT(0),  /*含税成本*/
    SumCostTotal numeric(25,8) NULL DEFAULT(0),  /*无税成本*/
    DISCOUNTRATE numeric(25,8) NULL DEFAULT(0),  /*折扣率*/
    SumML numeric(25,8) NULL DEFAULT(0),  /*毛利*/
    MLRATE numeric(25,8) NULL DEFAULT(0),  /*毛利率*/
    /*以下2个字段根据实际需要在获取数据集后重新计算  */
    MLPerscent numeric(25,8) NULL, /*毛利占比*/
    SaleMoneyPercent numeric(25,8) NULL, /*销售额占比*/
    /*END*/
    SumBillNumber numeric(25,8) NULL DEFAULT(0), /*客流量*/
    SumSaleTimes numeric(25,8) NULL DEFAULT(0), /*销售次数*/
    PricePerBill numeric(25,8) NULL DEFAULT(0), /*客单价*/
    AvePriceByPID numeric(25,8) NULL DEFAULT(0), /*平均品单价*/
    AveNumberByPerson numeric(25,8) NULL DEFAULT(0)/*平均客品次                  */
  )
     
  /*获取指定@PTypeID下属的所有ID*/
  CREATE TABLE #CTypeID (TypeID INT NOT NULL DEFAULT(0))
  IF @PTypeID > 0 
  BEGIN
    DECLARE @CLASSID VARCHAR(100)
    SELECT @CLASSID = class_id FROM customCategory WHERE ID = @PTypeID
    INSERT INTO #CTypeID SELECT ID FROM customCategory WHERE class_id LIKE @CLASSID + '%'       
  END
  /*把选定时间段内的单据数据写入临表*/
  IF @ProductTypeChecked > 0 /*按商品大类*/
    SELECT identity(int, 1, 1) as RecNo, 
         idx.Y_ID,c.class_id as YClass_id, sm.RowE_id as e_id, idx.inputman, 0 as Team, sm.supplier_id, /*idx.c_id, */
         /*有做关联的前提下，len(cg.class_id)只有4, 6, 8三种情况，2和大于8的时候自定义类别不允许关联；没做关联全部置空*/
         (case len(cg.class_id) when 4 then cg.class_id when 6 then Left(cg.class_id, 4) when 8 then Left(cg.class_id, 4) else ' ' end) BClass_ID, 
         (case len(cg.class_id) when 4 then ' ' when 6 then cg.class_id when 8 then Left(cg.class_id, 6) else ' ' end) MClass_ID, 
         (case len(cg.class_id) when 4 then ' ' when 6 then ' ' when 8 then cg.class_id else ' ' end) SClass_ID, 
         CONVERT(varchar(10), idx.billdate, 120) ACTIONDATE, 
         Cast(Year(idx.billdate) as VarChar) + '年' + Cast(Month(idx.billdate) as VarChar) + '月' as ACTIONMONTH, 
         Cast(Year(idx.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, idx.billdate) as VarChar) + '季度' as ACTIONSEASON, idx.billid, sm.smb_id, sm.p_id,sm.AOID, 
         (case idx.billtype when 12 then sm.quantity else (-1) * sm.quantity end) as quantity, 
         /*(case idx.billtype when 12 then (case AOID when 7 then 0 else sm.retailtotal end) else -(case AOID when 7 then 0 else sm.retailtotal end) end) as retailtotal,*/
         (case idx.billtype when 12 then sm.retailtotal else -sm.retailtotal end) as retailtotal,
         0 as PreMoney, 
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.taxtotal end) else -(case AOID when 7 then 0 else sm.taxtotal end) end) as taxtotal,
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.totalmoney End) else -(case AOID when 7 then 0 else sm.totalmoney end) end) as totalmoney,
         (case idx.billtype when 12 then sm.costtaxtotal else -sm.costtaxtotal  end) as costtaxtotal,
         (case idx.billtype when 12 then sm.costtaxtotal / (1 + sm.taxrate) else (-1) * sm.costtaxtotal / (1 + sm.taxrate) end) as CostTotal,
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.discount * sm.discountprice * sm.quantity end) else -(case AOID when 7 then 0 else sm.discount * sm.discountprice * sm.quantity end) end) as DiscountMoney,
         (case idx.billtype when 12 then sm.taxtotal - sm.costtaxtotal else -(sm.taxtotal - sm.costtaxtotal) end) as MLMoney 
    INTO #BaseGroup
    FROM billidx idx inner join salemanagebill sm on idx.billid = sm.bill_id AND IsNull(sm.p_id, 0) >= 0 
                                               and ((@PTypeID <= 0) OR (sm.p_id in (select distinct baseinfo_id from customCategoryMapping 
                                                                                      where deleted = 0 and BaseTypeid = 0 
                                                                                        and category_id in (select distinct TypeID from #CTypeID)
                                                                                    )
                                                                        )
                                                   )
                     left join customCategoryMapping cgm on sm.p_id = cgm.baseinfo_id 
                           and cgm.deleted = 0 and cgm.BaseTypeid = 0 and ((@PTypeID <= 0) or (cgm.category_id in (select distinct TypeID from #CTypeID)))
                     left join customCategory cg on cgm.category_id = cg.id and cg.deleted = 0 and ((@PTypeID <= 0) or (cg.id in (select distinct TypeID from #CTypeID)))
                     left join company c on c.company_id = idx.Y_ID                     
    WHERE 1=1  
      AND (idx.billtype = 12 or idx.billtype = 13)
      AND idx.billstates = 0 
      AND idx.billdate >= @BeginDate AND idx.billdate < @EndDate
      
  ELSE /*未选商品类别*/
  
    SELECT identity(int, 1, 1) as RecNo, 
         idx.Y_ID,c.class_id as YClass_id, sm.RowE_id as e_id, idx.inputman, 0 as Team, sm.supplier_id, /*idx.c_id, */
         /*未选商品类别，不关联商品类别表 */
         ' ' BClass_ID, ' ' MClass_ID, ' ' SClass_ID, 
         CONVERT(varchar(10), idx.billdate, 120) ACTIONDATE, 
         Cast(Year(idx.billdate) as VarChar) + '年' + Cast(Month(idx.billdate) as VarChar) + '月' as ACTIONMONTH, 
         Cast(Year(idx.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, idx.billdate) as VarChar) + '季度' as ACTIONSEASON, idx.billid, sm.smb_id, sm.p_id,sm.AOID, 
         (case idx.billtype when 12 then sm.quantity else (-1) * sm.quantity end) as quantity, 
         /*(case idx.billtype when 12 then (case AOID when 7 then 0 else sm.retailtotal end) else -(case AOID when 7 then 0 else sm.retailtotal end) end) as retailtotal,*/
         (case idx.billtype when 12 then sm.retailtotal else -sm.retailtotal end) as retailtotal,
         0 as PreMoney, 
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.taxtotal end) else -(case AOID when 7 then 0 else sm.taxtotal end) end) as taxtotal,
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.totalmoney end) else -(case AOID when 7 then 0 else sm.totalmoney end) end) as totalmoney,
         (case idx.billtype when 12 then sm.costtaxtotal else -sm.costtaxtotal end) as costtaxtotal,
         (case idx.billtype when 12 then sm.costtaxtotal / (1 + sm.taxrate) else (-1) * sm.costtaxtotal / (1 + sm.taxrate) end) as CostTotal,
         (case idx.billtype when 12 then (case AOID when 7 then 0 else sm.discount * sm.discountprice * sm.quantity end) else -(case AOID when 7 then 0 else sm.discount * sm.discountprice * sm.quantity end)end) as DiscountMoney,
         (case idx.billtype when 12 then sm.taxtotal - sm.costtaxtotal else -(sm.taxtotal - sm.costtaxtotal) end) as MLMoney 
    INTO #BaseGroup1
    FROM billidx idx inner join salemanagebill sm on idx.billid = sm.bill_id AND IsNull(sm.p_id, 0) >= 0
         left join company c on c.company_id = idx.Y_ID                                                                  
    WHERE 1=1  
      AND (idx.billtype = 12 or idx.billtype = 13)
      AND idx.billstates = 0 
      AND idx.billdate >= @BeginDate AND idx.billdate < @EndDate             
           
  /*生成汇总SQL  */
  SET @INSSQL = ISNULL(@INSSQL, '')
  SET @SELSQL = ISNULL(@SELSQL, '')
  SET @GRPSQL = ISNULL(@GRPSQL, '') 
  /*选中按商品，则把所有条件归类汇总，如果有的话。优先级最高 */
  IF @ProductChecked = 1 
  BEGIN
    /*@ProductChecked Int = 0, --是否按商品，默认否0*/
    IF @ProductChecked <> 1 
      RETURN 0
      
    /*商品*/
    IF @ProductChecked = 1 
    BEGIN
      SET @TMPSQL = 'p_id,AOID'
      SET @INSSQL = @INSSQL + 'PID,AOID, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END      
    /*机构*/
    IF @GroupType = 0 
    BEGIN
      SET @TMPSQL = 'Y_ID,YClass_id'
      SET @INSSQL = @INSSQL + 'Y_ID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END
    /*收银员*/
    IF @GroupType = 1 
    BEGIN
      SET @TMPSQL = 'INPUTMAN,YClass_id'
      SET @INSSQL = @INSSQL + 'INPUTMAN,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END  
    /*营业员*/
    IF @GroupType = 2 
    BEGIN
      SET @TMPSQL = 'E_ID,YClass_id'
      SET @INSSQL = @INSSQL + 'E_ID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END   
    /*柜组*/
    /*IF @GroupType = 3 */
    /*BEGIN      */
      /*SET @GRPSQL = ''  */
    /*END  */
    /*供应商 */
    IF @GroupType = 4 
    BEGIN
      SET @TMPSQL = 'supplier_id,YClass_id'
      SET @INSSQL = @INSSQL + 'SUPPLIERID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END          
    /*类别大中小*/
    IF @PTypeRange >=0 
    BEGIN
      IF @PTypeRange = 0 SET @TMPSQL = 'BClass_ID'  /*大*/
      IF @PTypeRange = 1 SET @TMPSQL = 'MClass_ID' /*中*/
      IF @PTypeRange = 2 SET @TMPSQL = 'SClass_ID' /*小*/
      SET @INSSQL = @INSSQL + 'PTypeRange, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END
    /*时间大中小*/
    IF @TimeRange >= 0
    BEGIN
      IF @TimeRange = 0 SET @TMPSQL = 'ACTIONDATE' /*大*/
      IF @TimeRange = 1 SET @TMPSQL = 'ACTIONMONTH' /*中*/
      IF @TimeRange = 2 SET @TMPSQL = 'ACTIONSEASON' /*小*/
      SET @INSSQL = @INSSQL + 'DATERANGE, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END      
  END 
  /*未选中按商品，选中按汇总条件，则把除按商品外的所有条件汇总，优先级次之*/
  ELSE IF @GroupType > -1    
  BEGIN
    /*@GroupType Int = -1, --汇总条件 -1：无；0：机构YID， 1：收银员EID, 2：营业员INPUTMAN, 3:柜组：未知, 4:供应商：CID；*/
    IF @GroupType < 0 
      RETURN 0
    /*机构*/
    IF @GroupType = 0 
    BEGIN
      SET @TMPSQL = 'Y_ID,YClass_id'
      SET @INSSQL = @INSSQL + 'Y_ID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END
    /*收银员*/
    IF @GroupType = 1 
    BEGIN
      SET @TMPSQL = 'INPUTMAN,YClass_id'
      SET @INSSQL = @INSSQL + 'INPUTMAN,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END  
    /*营业员*/
    IF @GroupType = 2 
    BEGIN
      SET @TMPSQL = 'E_ID,YClass_id'
      SET @INSSQL = @INSSQL + 'E_ID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END   
    /*柜组*/
    /*IF @GroupType = 3 */
    /*BEGIN*/
      /*SET @GRPSQL = ''  */
    /*END    */
    /*供应商 */
    IF @GroupType = 4 
    BEGIN
      SET @TMPSQL = 'supplier_id,YClass_id'
      SET @INSSQL = @INSSQL + 'SUPPLIERID,YClass_id, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '  
    END          
    /*类别大中小*/
    IF @PTypeRange >=0 
    BEGIN
      IF @PTypeRange = 0 SET @TMPSQL = 'BClass_ID'  /*大*/
      IF @PTypeRange = 1 SET @TMPSQL = 'MClass_ID' /*中*/
      IF @PTypeRange = 2 SET @TMPSQL = 'SClass_ID' /*小*/
      SET @INSSQL = @INSSQL + 'PTypeRange, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END
    /*时间大中小*/
    IF @TimeRange >= 0
    BEGIN
      IF @TimeRange = 0 SET @TMPSQL = 'ACTIONDATE' /*大*/
      IF @TimeRange = 1 SET @TMPSQL = 'ACTIONMONTH' /*中*/
      IF @TimeRange = 2 SET @TMPSQL = 'ACTIONSEASON' /*小*/
      SET @INSSQL = @INSSQL + 'DATERANGE, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END    
  END
  /*选中按商品类别组，则按商品类别组和时间段汇总，如果有的话。优先级次之*/
  ELSE IF @ProductTypeChecked = 1
  BEGIN
    IF @PTypeRange < 0 
      RETURN 0
    /*类别大中小*/
    IF @PTypeRange >= 0 
    BEGIN
      IF @PTypeRange = 0 SET @TMPSQL = 'BClass_ID'  /*大*/
      IF @PTypeRange = 1 SET @TMPSQL = 'MClass_ID' /*中*/
      IF @PTypeRange = 2 SET @TMPSQL = 'SClass_ID' /*小*/
      SET @INSSQL = @INSSQL + 'PTypeRange, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END
    /*时间大中小*/
    IF @TimeRange >= 0
    BEGIN
      IF @TimeRange = 0 SET @TMPSQL = 'ACTIONDATE' /*大*/
      IF @TimeRange = 1 SET @TMPSQL = 'ACTIONMONTH' /*中*/
      IF @TimeRange = 2 SET @TMPSQL = 'ACTIONSEASON' /*小*/
      SET @INSSQL = @INSSQL + 'DATERANGE, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END
  END
  /*选中按时间段，则只汇总时间段*/
  ELSE IF @TimeChecked = 1 
  BEGIN
    IF @TimeRange < 0  /*没有选大中小*/
      RETURN 0
    IF @TimeRange >= 0 
    BEGIN    
      IF @TimeRange = 0 SET @TMPSQL = 'ACTIONDATE' /*大*/
      IF @TimeRange = 1 SET @TMPSQL = 'ACTIONMONTH' /*中*/
      IF @TimeRange = 2 SET @TMPSQL = 'ACTIONSEASON' /*小*/
      SET @INSSQL = @INSSQL + 'DATERANGE, '
      SET @SELSQL = @SELSQL + @TMPSQL + ', '
      SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
    END
  END
  /*没有选任何条件*/
  ELSE
    RETURN 0
    
  /*语句提到最后暂时屏蔽柜组    */
  SET @INSSQL = ' INSERT INTO #FinalData (' + @INSSQL  
  SET @SELSQL = ' SELECT ' + @SELSQL
  IF @GRPSQL <> ''  /*柜组处理*/
    SET @GRPSQL = ' GROUP BY ' + @GRPSQL
  
  IF @INSSQL <> ''
  BEGIN    
    SET @INSSQL = @INSSQL 
                + 'SumRetailtotal, SumPreMoney, SumTaxTotal, SumTotalMoney, SumCosttaxTotal, SumCostTotal, DISCOUNTRATE, '
                + 'SumML, MLRATE, SumBillNumber, SumSaleTimes, PricePerBill, AvePriceByPID, AveNumberByPerson) '           
  END
  IF @SELSQL <> ''
  BEGIN
    SET @SELSQL = @SELSQL 
                + 'SUM(RetailTotal) SumRetailtotal, NULL, SUM(TaxTotal) SumTaxTotal, SUM(TotalMoney) SumTotalMoney, '
                + 'SUM(CosttaxTotal) SumCosttaxTotal, SUM(CostTotal) SumCostTotal, '
                + '(CASE SUM(RetailTotal) WHEN 0 THEN 100 ELSE SUM(DiscountMoney)*100/SUM(RetailTotal) END) AS DISCOUNTRATE, '
                + 'SUM(MLMoney) SumML, '
                + '(CASE SUM(taxtotal) WHEN 0 THEN 100 ELSE SUM(MLMoney)*100/SUM(taxtotal) END) AS MLRATE, COUNT(DISTINCT billid) SumBillNumber, '                
                + 'COUNT(DISTINCT billid) SumSaleTimes, '
                + '(CASE COUNT(DISTINCT billid) WHEN 0 THEN SUM(TaxTotal) ELSE SUM(TaxTotal)/COUNT(DISTINCT billid) END) PricePerBill, '                      
                + '(CASE SUM(QUANTITY) WHEN 0 THEN SUM(taxtotal) ELSE SUM(taxtotal)/SUM(QUANTITY) END) AvePriceByPID, COUNT(DISTINCT SMB_ID) AveNumberByPerson '
    IF @ProductTypeChecked > 0                
      SET @SELSQL = @SELSQL + 'FROM #BaseGroup '
    ELSE
      SET @SELSQL = @SELSQL + 'FROM #BaseGroup1 '
  END               
  IF @GRPSQL <> ''
  BEGIN
    IF RIGHT(RTRIM(@GRPSQL), 1) = ','
      SET @GRPSQL = LEFT(RTRIM(@GRPSQL), LEN(RTRIM(@GRPSQL))-1)          
  END
  
  /*执行SQL，获取数据集*/
  SET @EXESQL = @INSSQL + @SELSQL + @GRPSQL
  
  IF @EXESQL <> ''
    EXEC(@EXESQL) 
   /* print @EXESQL*/
  /*空值处理*/
  DELETE #FinalData WHERE ISNULL(SumRetailtotal, 0) = 0 AND ISNULL(SumPreMoney, 0) = 0 AND ISNULL(SumTaxTotal, 0) = 0
                      AND ISNULL(SumTotalMoney, 0) = 0 AND ISNULL(SumCosttaxTotal, 0) = 0 AND ISNULL(SumCostTotal, 0) = 0
                      AND ISNULL(PID, 0) = 0     

  /*select * from #FinalData                                                              */
    
  /*以下开始获取计算字段 */
  
  /*毛利占比、销售额占比    */
  DECLARE @WHOLEML numeric(25,8) /*毛利总数*/
  DECLARE @WHOLESALEMONEY numeric(25,8) /*销售总额     */
  SELECT @WHOLEML = SUM(ISNULL(SUMML, 0)), @WHOLESALEMONEY = SUM(ISNULL(SumTaxTotal, 0)) FROM #FinalData        
  Update #FinalData set MLPerscent = (case @WHOLEML when 0 then 100 else CONVERT(DECIMAL(18, 4), SumML*100/@WHOLEML) end), 
                        SaleMoneyPercent = (case @WHOLESALEMONEY when 0 then 100 else CONVERT(DECIMAL(18, 4), SumTaxTotal*100/@WHOLESALEMONEY) end)
  
  /*日均销量                           */
  IF @ProductTypeChecked > 0           
    Update #FinalData 
      set SaleNumByDay = CONVERT(DECIMAL(18, 4), (case PID when 0 then (SELECT SUM(quantity) FROM #BaseGroup)/datediff(DD, @BeginDate, @EndDate)
                                                                  else (SELECT SUM(quantity) FROM #BaseGroup where p_id = PID and #BaseGroup.YClass_id = #FinalData.YClass_id)/datediff(DD, @BeginDate, @EndDate)
                                                  end))
  ELSE
    Update #FinalData 
      set SaleNumByDay = CONVERT(DECIMAL(18, 4), (case PID when 0 then (SELECT SUM(quantity) FROM #BaseGroup1 )/datediff(DD, @BeginDate, @EndDate)
                                                                  else (SELECT SUM(quantity) FROM #BaseGroup1 where P_ID = PID and #BaseGroup1.YClass_id = #FinalData.YClass_id)/datediff(DD, @BeginDate, @EndDate)
                                                  end))
  /*库存数量                                                                                                        */
  Update #FinalData set SumNumInStore = tmp.qty /*机构+商品*/
    from (SELECT Y_id, p_id, SUM(quantity) qty FROM StoreHouse Group by Y_ID, p_id) tmp
      where #FinalData.Y_ID > 0 and #FinalData.PID > 0 
        and #FinalData.Y_ID = tmp.Y_ID and #FinalData.PID = tmp.p_id
        and #FinalData.AOID<>8
  Update #FinalData set SumNumInStore = tmp.qty /*只商品*/
    from (SELECT p_id,Y_ID, SUM(quantity) qty FROM StoreHouse Group by p_id,Y_ID) tmp
    left join company c on tmp.Y_ID = c.company_id
      where #FinalData.Y_ID <= 0 and #FinalData.PID > 0 
        and #FinalData.PID = tmp.p_id and c.class_id = #FinalData.YClass_id  
        and #FinalData.AOID<>8                                                                                                                                                                                                                                                      
  Update #FinalData set SumNumInStore = tmp.qty /*只机构 */
    from (SELECT Y_id, SUM(quantity) qty FROM StoreHouse Group by Y_id) tmp
      where #FinalData.Y_ID > 0 and #FinalData.PID <= 0 
        and #FinalData.Y_id = tmp.Y_id  
        and #FinalData.AOID<>8                                                                                                                                                                                                                                                       
  Update #FinalData set SumNumInStore = tmp.qty /*无机构+无商品*/
    from (SELECT SUM(quantity) qty FROM StoreHouse) tmp
      where #FinalData.Y_ID <= 0 and #FinalData.PID <= 0 
      and #FinalData.AOID<>8        
  /*-------------------------------------------      */
  /*取开始结束日期*/
  /*无日期*/
  Update #FinalData set CBeginDate = CAST(@BeginDate as Varchar), CEndDate = CAST(@EndDate - 1 as Varchar), 
     CTypeRange = (case when RTRIM(LTRIM(ISNULL(PTypeRange, ''))) <> '' then RTRIM(LTRIM(ISNULL(PTypeRange, ''))) + '%' else RTRIM(LTRIM(ISNULL(PTypeRange, ''))) end)
   where ISNULL(DateRange, '') = ''
  /*按月统计   */
  Update #FinalData set CBeginDate = dateadd(mm, datediff(mm, 0, CAST(REPLACE(REPLACE(DateRange, '年', '-'), '月', '-') + '01' as DateTime)), 0), /*当月第一天*/
     CEndDate = dateadd(ms, -3, dateadd(mm, datediff(m, 0, CAST(REPLACE(REPLACE(DateRange, '年', '-'), '月', '-') + '01' as DateTime)) + 1, 0)), /*当月最后一天*/
     CTypeRange = (case when RTRIM(LTRIM(ISNULL(PTypeRange, ''))) <> '' then RTRIM(LTRIM(ISNULL(PTypeRange, ''))) + '%' else RTRIM(LTRIM(ISNULL(PTypeRange, ''))) end)
   where CHARINDEX('月', DateRange) > 0
  /*按季度统计*/
  Update #FinalData set 
     CBeginDate = SUBSTRING(DateRange, 1, 4) + (CASE SUBSTRING(DateRange, CHARINDEX('季度', DateRange) - 1, 1) when '1' then '-01-01' when '2' then '-04-01' when '3' then '-07-01' when '4' then '-10-01' end), 
     CEndDate = SUBSTRING(DateRange, 1, 4) + (CASE SUBSTRING(DateRange, CHARINDEX('季度', DateRange) - 1, 1) when '1' then '-03-31' when '2' then '-06-30' when '3' then '-09-30' when '4' then '-12-31' end), 
     CTypeRange = (case when RTRIM(LTRIM(ISNULL(PTypeRange, ''))) <> '' then RTRIM(LTRIM(ISNULL(PTypeRange, ''))) + '%' else RTRIM(LTRIM(ISNULL(PTypeRange, ''))) end)
   where CHARINDEX('季度', DateRange) > 0
  /*按天统计 */
  Update #FinalData set CBeginDate = CONVERT(varchar(10), DateRange, 120) + ' 00:00:00', 
     CEndDate = CONVERT(varchar(10), DateRange, 120) + ' 23:59:59',
     CTypeRange = (case when RTRIM(LTRIM(ISNULL(PTypeRange, ''))) <> '' then RTRIM(LTRIM(ISNULL(PTypeRange, ''))) + '%' else RTRIM(LTRIM(ISNULL(PTypeRange, ''))) end)
   where (ISNULL(DateRange, '') <> '') and (CHARINDEX('月', DateRange) <= 0) and (CHARINDEX('季度', DateRange) <= 0)
   
  /*日均销售额     */
  Update #FinalData set AveSaleMByday = CONVERT(DECIMAL(18, 4), SumTaxTotal) where DATEDIFF(DD, CBeginDate, CEndDate) = 0 /*只有一天*/
  Update #FinalData set AveSaleMByday = CONVERT(DECIMAL(18, 4), SumTaxTotal/(DATEDIFF(DD, CAST(CBeginDate AS DATETIME), CAST(CEndDate AS DATETIME)) + 1)) 
    where DATEDIFF(DD, CBeginDate, CEndDate) <> 0 /*不止一天*/
    
  /*新品品规数*/
  Update #FinalData set PGNumNewInstore = CONVERT(DECIMAL(18, 4), (SELECT COUNT(DISTINCT(tmp.p_id)) FROM  /*没有按商品类别或者类别为空，则直接统计全部*/
                                                                    (SELECT bm.p_id, MIN(idx.billdate) mindate
                                                                       FROM billidx idx inner join buymanagebill bm on idx.billid = bm.bill_id
                                                                         WHERE billtype = 20 /*采购入库单 */
                                                                          AND idx.Y_ID = 2 /*总公司               */
                                                                       Group by bm.p_id
                                                                     ) tmp
                                                                     WHERE tmp.mindate BETWEEN CAST(CBeginDate AS datetime) and DATEADD(DD, 1, CAST(CEndDate AS datetime))  
                                                                   )  
                                                  )
    where @PTypeID <= 0 OR CTypeRange = ''                                                  
  
  Update #FinalData set PGNumNewInstore = CONVERT(DECIMAL(18, 4), (SELECT COUNT(DISTINCT(tmp.p_id)) FROM  /*按商品类别，则需要按类别统计*/
                                                                    (SELECT bm.p_id, MIN(idx.billdate) mindate
                                                                       FROM billidx idx inner join buymanagebill bm on idx.billid = bm.bill_id
                                                                         WHERE billtype = 20 /*采购入库单 */
                                                                           AND idx.Y_ID = 2 /*总公司  */
                                                                           AND bm.p_id in (select distinct baseinfo_id 
                                                                                             from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                                               where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                                                 and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                                                           )             
                                                                      Group by bm.p_id
                                                                     ) tmp
                                                                     WHERE tmp.mindate BETWEEN CAST(CBeginDate AS datetime) and DATEADD(DD, 1, CAST(CEndDate AS datetime)) 
                                                                   ) 
                                                 )
    where @PTypeID > 0 and CTypeRange <> ''  
    
  /*平均客品次  */
  Update #FinalData set AveNumberByPerson = AveNumberByPerson/SumBillNumber  
  
  /*动销品规数*/
  Update #FinalData set SumPGNumSaled = (SELECT COUNT(DISTINCT P_ID) /*没有按商品类别或者类别为空，则直接统计全部*/
                                           FROM PerDayData 
                                             WHERE BillType in (10, 11, 12, 13, 92, 93, 110, 111, 120, 121)
                                               AND [DATETIME] BETWEEN  CAST(CBeginDate AS datetime) AND DATEADD(DD, 1, CAST(CEndDate AS datetime))
                                               AND (#FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID) 
                                         )
    where @PTypeID <= 0 OR CTypeRange = ''  
    
  Update #FinalData set SumPGNumSaled = (SELECT COUNT(DISTINCT P_ID) /*按商品类别，则需要按类别统计*/
                                           FROM PerDayData 
                                             WHERE BillType in (10, 11, 12, 13, 92, 93, 110, 111, 120, 121)
                                               AND [DATETIME] BETWEEN  CAST(CBeginDate AS datetime) AND DATEADD(DD, 1, CAST(CEndDate AS datetime))
                                               AND (#FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID) 
                                               AND p_id in (select distinct baseinfo_id 
                                                              from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                  and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                            )
                                         )
    where @PTypeID > 0 and CTypeRange <> ''                                                                                                                                                                               
  /*                           
  --动销品规数
  Update #FinalData set SumPGNumSaled = CONVERT(DECIMAL(18, 4), (SELECT COUNT(DISTINCT dtl.p_id)  --没有按商品类别或者类别为空，则直接统计全部
                                                                   FROM billidx idx inner join productdetail dtl on idx.billid = dtl.billid
                                                                     WHERE idx.billdate >= CBeginDate and idx.billdate <= CEndDate 
                                                                       and (#FinalData.Y_ID = 0 OR dtl.Y_ID = #FinalData.Y_ID)
                                                                       and (#FinalData.PID = 0 OR dtl.p_id = #FinalData.PID)
                                                                 )
                                               )
    where @PTypeID <= 0 OR CTypeRange = ''   
                                            
  Update #FinalData set SumPGNumSaled = CONVERT(DECIMAL(18, 4), (SELECT COUNT(DISTINCT dtl.p_id) --按商品类别，则需要按类别统计
                                                                   FROM billidx idx inner join productdetail dtl on idx.billid = dtl.billid
                                                                     WHERE idx.billdate >= CBeginDate and idx.billdate <= CEndDate 
                                                                       and (#FinalData.Y_ID = 0 OR dtl.Y_ID = #FinalData.Y_ID)
                                                                       and (#FinalData.PID = 0 OR dtl.p_id = #FinalData.PID)
                                                                       and dtl.p_id in (select distinct baseinfo_id 
                                                                                          from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                                            where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                                              and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                                                        )
                                                                 )
                                                )
    where @PTypeID > 0 and CTypeRange <> '' 
*/

  
  Update #FinalData set SumPGNumInstore = tmp.cnt /*没有按商品类别或者类别为空，则直接统计全部*/
    from (select y_id, [datetime], COUNT(distinct p_id) cnt from PerStockData Group by y_id, [datetime]) tmp
     where (#FinalData.Y_ID = 0 OR #FinalData.Y_ID = tmp.y_id) 
        and SUBSTRING(convert(varchar, Cast(#FinalData.CEndDate as DateTime), 120), 1, 10) = SUBSTRING(convert(varchar, tmp.[datetime], 120), 1, 10)        
        and (@PTypeID <= 0 OR CTypeRange = '')
    
  Update #FinalData set SumPGNumInstore = tmp.cnt  /*按商品类别，则需要按类别统计*/
    from (
           select y_id, [datetime], PTypeRange, COUNT(distinct p_id) cnt 
             from 
             (
               select pd.*, 
                 (Case @PTypeRange 
                    when 0 then 
                      (case len(cg.class_id) when 4 then cg.class_id when 6 then Left(cg.class_id, 4) when 8 then Left(cg.class_id, 4) else ' ' end)
                    when 1 then 
                      (case len(cg.class_id) when 4 then ' ' when 6 then cg.class_id when 8 then Left(cg.class_id, 6) else ' ' end) 
                    when 2 then                 
                      (case len(cg.class_id) when 4 then ' ' when 6 then ' ' when 8 then cg.class_id else ' ' end)
                    else 
                      ' '
                  end) as PTypeRange                                
               from PerStockData pd left join customCategoryMapping cm on pd.p_id = cm.baseinfo_id and cm.deleted = 0 and cm.BaseTypeid = 0
                                             left join customCategory cg on cg.id = cm.category_id and cg.deleted = 0 
             ) psd
             where psd.PTypeRange in (select distinct PTypeRange from #FinalData)
             Group by y_id, [datetime], PTypeRange
         ) tmp
      where (#FinalData.Y_ID = 0 OR #FinalData.Y_ID = tmp.y_id) 
        and #FinalData.PTypeRange = tmp.PTypeRange
        and SUBSTRING(convert(varchar, Cast(#FinalData.CEndDate as DateTime), 120), 1, 10)  = SUBSTRING(convert(varchar, tmp.[datetime], 120), 1, 10)                                
        and (@PTypeID > 0 and CTypeRange <> '')  

  /*
  --库存品规数
  Update #FinalData set SumPGNumInstore = (SELECT COUNT(DISTINCT p_id)   --没有按商品类别或者类别为空，则直接统计全部
                                             FROM PerStockData 
                                               WHERE DATEDIFF(DD, [datetime], CAST(CEndDate AS datetime)) = 0 
                                                 AND (#FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID) 
                                           ) 
    where @PTypeID <= 0 OR CTypeRange = ''
    
  Update #FinalData set SumPGNumInstore = (SELECT COUNT(DISTINCT p_id)   --按商品类别，则需要按类别统计
                                             FROM PerStockData 
                                               WHERE DATEDIFF(DD, [datetime], CAST(CEndDate AS datetime)) = 0 
                                                 AND (#FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID) 
                                                 AND p_id in (select distinct baseinfo_id 
                                                                from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                  where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                    and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                              )
                                           ) 
    where @PTypeID > 0 OR CTypeRange <> ''       
                                                  

  --库存品规数
  Update #FinalData set SumPGNumInstore = (SELECT COUNT(DISTINCT c.P_ID) FROM  --没有按商品类别或者类别为空，则直接统计全部
                                            (SELECT a.p_id, (Sum(a.xqty) - Sum(a.lqty)) as qty from --结束日期当天PID及数量
                                              (select dtl.p_id, sum(dtl.quantity) lqty,0 as xqty  
                                                 from billidx idx, productdetail dtl 
                                                   where idx.billid = dtl.billid and idx.billdate > CEndDate AND (#FinalData.Y_ID = 0 OR dtl.Y_ID = #FinalData.Y_ID)
                                                 Group by dtl.p_id --结束日期到现在所有交易PID及数量
                                               union all
                                               --现有PID及数量
                                               select p_id ,0 as lqty, Sum(quantity) xqty from StoreHouse where #FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID Group by p_id
                                              ) a
                                            Group by a.p_id
                                           ) c
                                           WHERE c.qty > 0
                                          )
    where @PTypeID <= 0 OR CTypeRange = '' 
    
  Update #FinalData set SumPGNumInstore = (SELECT COUNT(DISTINCT c.P_ID) FROM  --按商品类别，则需要按类别统计
                                            (SELECT a.p_id, (Sum(a.xqty) - Sum(a.lqty)) as qty from --结束日期当天PID及数量
                                              (select dtl.p_id, sum(dtl.quantity) lqty,0 as xqty  
                                                 from billidx idx, productdetail dtl 
                                                   where idx.billid = dtl.billid and idx.billdate > CEndDate AND (#FinalData.Y_ID = 0 OR dtl.Y_ID = #FinalData.Y_ID)
                                                    AND dtl.p_id in (select distinct baseinfo_id 
                                                                      from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                        where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                          and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                                     )
                                               Group by dtl.p_id --结束日期到现在所有交易PID及数量
                                               union all
                                               --现有PID及数量
                                               select p_id ,0 as lqty, Sum(quantity) xqty from StoreHouse 
                                                 where (#FinalData.Y_ID = 0 OR Y_ID = #FinalData.Y_ID)
                                                   AND p_id in (select distinct baseinfo_id 
                                                                  from customCategoryMapping cmp inner join customCategory ccg on cmp.category_id = ccg.id 
                                                                    where cmp.deleted = 0 and ccg.deleted = 0 and ccg.class_id like CTypeRange 
                                                                      and cmp.BaseTypeid = 0 and cmp.category_id in (select distinct TypeID from #CTypeID)
                                                                )
                                              Group by p_id
                                             ) a
                                           Group by a.p_id
                                          ) c
                                          WHERE c.qty > 0 
                                         )  
    where @PTypeID > 0 OR CTypeRange <> ''                                                                                        
  */
  
  /*显示商品类别组*/
  IF @PTypeID > 0 
    UPDATE #FinalData SET PTypeID = @PTypeID               
  /*计算字段END  */
  
  /*返回数据集    */
  SELECT tmp.*, emp1.name as EName, emp2.name as IName, cmy.name as YName, cts.name as CName,
         case when tmp.AOID = 8 then sp.alias else pts.alias end as alias,
         case when tmp.AOID = 8 then sp.name  else pts.name  end as pname,
         case when tmp.AOID = 8 then '' else pts.[standard] end as PStandard,
         case when tmp.AOID = 8 then sp.Code else pts.serial_number end as serial_number,
         case when tmp.AOID = 8 then '' else pts.makearea end as makearea,
         case when tmp.AOID = 8 then sp.comment else pts.comment end as comments,
         case when tmp.AOID = 8 then '' else cgy.name end as PTypeName,   
         case when tmp.AOID = 8 then sp.UnitName else u.name end as UName,  
         case when tmp.AOID = 8 then '' else cgy1.name end as PType,
         tmp.YClass_id,
         factory = case when tmp.AOID = 8 then '' else (case pts.IfZYCheck when 0 then bf.AccountComment else '' end) end
    FROM #FinalData tmp left join employees emp1 on tmp.E_ID = emp1.emp_id
                        left join employees emp2 on tmp.INPUTMAN = emp2.emp_id
                        left join company cmy on tmp.Y_ID = cmy.company_id
                        left join clients cts on tmp.SUPPLIERID = cts.client_id
                        left join products pts on tmp.PID = pts.product_id
                        left join VW_H_SpecialProducts sp on tmp.PID =sp.product_id
                        left join unit u on pts.unit1_id = u.unit_id 
                        left join customCategory cgy on tmp.PTypeRange = cgy.class_id
                        left join customCategory cgy1 on tmp.PTypeID = cgy1.id                        
                        left join basefactory bf on pts.factoryc_id = bf.CommID
                        where (@YClass_id in('','%%') or tmp.YClass_id = @YClass_id)
    ORDER By YName, EName, IName, TEAM, CName, pts.alias, PTypeRange, PTypeName, DATERANGE                                             
  
  /*删除临时表*/
  IF object_id(N'#CTypeID', N'U') is not null  
    DROP TABLE #CTypeID
  IF object_id(N'#BaseGroup', N'U') is not null
    Drop Table #BaseGroup  
  IF object_id(N'#BaseGroup1', N'U') is not null
    Drop Table #BaseGroup1 
  IF object_id(N'#FinalData', N'U') is not null
    Drop Table #FinalData
GO
