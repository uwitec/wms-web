

CREATE VIEW dbo.vw_Clients
AS
SELECT c.client_id,c.class_id,c.parent_id,c.child_number,c.child_count,c.serial_number,c.[name],
       c.alias,c.region_id,c.phone_number,c.address,c.zipcode,c.contact_personal,c.tax_number,
       c.acount_number,c.pinyin,c.pricemode,c.firstcheck,c.comment,c.csflag,c.deleted,c.ProtocolDate,
       c.GMPNo,c.GSPNo,c.Cetype,c.ModifyDate,c.RowIndex,c.IncRate,c.licence_no,c.ent_type,c.city_id,
       c.city_name,c.boro_id,c.boro_name,c.e_id,c.consignBook_no,c.organCard_no,c.BusinessLicence_no,c.MassConfer_no,
       c.Cer_CustomNO1,c.Cer_CustomNO2,c.Cer_CustomNO3,c.Cer_CustomNO4,c.Cer_CustomNO5,
       isnull(CB.credit_total,0)credit_total,  isnull(CB.APcredit_total,0)Apcredit_total,
       isnull(CB.sklimit,0)sklimit,isnull(CB.artotal,0)artotal,
       isnull(CB.artotal_ini,0)artotal_ini,  isnull(CB.aptotal,0)aptotal,isnull(CB.aptotal_ini,0)aptotal_ini,
       isnull(CB.pre_artotal,0)pre_artotal,  isnull(CB.pre_artotal_ini,0)pre_artotal_ini,
       isnull(CB.pre_aptotal,0)pre_aptotal,  isnull(CB.pre_aptotal_ini,0)pre_aptotal_ini,

      ISNULL(r.name, '') AS RegionName,isnull(e.name,'') as ename,
      cename = CASE c.csflag WHEN '0' THEN '客户' WHEN '1' THEN '供应商' WHEN '2' THEN
       '两者皆是' END
      ,CN_PriceMode=case c.PriceMode 
			when 0 then'[无]'
			when 1 then'预设售价1'
			when 2 then'预设售价2'
			when 3 then'预设售价3'
			when 4 then'会员价'
			when 5 then'国批价'
			when 6 then'国零价'
			when 7 then'特价'
			when 8 then'最近进价'
			when 9 then'零售价'
		end,
      StatusName=case c.deleted
      when 0 then '正常'  when 1 then '删除' when 4 then '停用'
      end,
      isnull(r1.validTime, '1900-01-01') as d1, 		
      isnull(r4.validTime, '1900-01-01') as d2, 
   	  isnull(r5.validTime, '1900-01-01') as d8, 
      isnull(r3.validTime, '1900-01-01') as d9, 	
      isnull(r2.validTime, '1900-01-01') as d10,       
      isnull(r6.validTime, '1900-01-01') as d12, 
      isnull(r7.validTime, '1900-01-01') as d13,
      isnull(r8.validTime, '1900-01-01') as d14,
      isnull(r9.validTime, '1900-01-01') as d15,
      isnull(r10.validTime, '1900-01-01') as d16,
      c.CreateDate,c.C_Customname1,c.C_Customname2,c.C_Customname3,c.C_Customname4,c.C_Customname5,
      c.clienttype_id,isnull(ct.name,'') as clienttypename,isnull(v.name,'') as cardname,c.card_id,c.discount,c.AddressZC,c.jsdw_id
FROM dbo.clients c LEFT OUTER JOIN     dbo.Region r ON c.region_id = r.region_id
                   LEFT OUTER JOIN     dbo.clienttype ct ON c.clienttype_id = ct.clienttype_id    
                   left OUTER join     vipcard v on c.card_id=v.vipcardid

LEFT JOIN
      employees e on e.emp_id=c.e_id
    /*left join */
    /*  gspalert g on c.Client_id = g.c_id and g.mt_id=0 and g.ctype = 0*/
	left join ClientReport2 r1 on c.client_id = r1.c_id and r1.CType = 0 and r1.rpn_id = 1  /*许可证*/
                         left join ClientReport2 r2 on c.client_id = r2.c_id and r2.CType = 0 and r2.rpn_id = 2  /*GSP证书*/
                         left join ClientReport2 r3 on c.client_id = r3.c_id and r3.CType = 0 and r3.rpn_id = 3  /*组织机构代码*/
                         left join ClientReport2 r4 on c.client_id = r4.c_id and r4.CType = 0 and r4.rpn_id = 4  /*营业执照*/
                         left join ClientReport2 r5 on c.client_id = r5.c_id and r5.CType = 0 and r5.rpn_id = 5  /*质量保证*/
                         left join ClientReport2 r6 on c.client_id = r6.c_id and r6.CType = 0 and r6.rpn_id = 6  /*自定义1*/
                         left join ClientReport2 r7 on c.client_id = r7.c_id and r7.CType = 0 and r7.rpn_id = 7  /*自定义2*/
                         left join ClientReport2 r8 on c.client_id = r8.c_id and r8.CType = 0 and r8.rpn_id = 8  /*自定义3*/
                         left join ClientReport2 r9 on c.client_id = r9.c_id and r9.CType = 0 and r9.rpn_id = 9  /*自定义4*/
                         left join ClientReport2 r10 on c.client_id = r10.c_id and r10.CType = 0 and r10.rpn_id = 10  /*自定义5*/
    Left join    (   SELECT   MAX(Id) AS Id, c_id, MAX(d1) AS d1, MAX(d2) AS d2, MAX(d3) AS d3, MAX(d4) AS d4, MAX(d6) AS d6, 
											MAX(d7) AS d7, MAX(d8) AS d8, MAX(d9) AS d9, MAX(GspId) AS GspId, MAX(D10) AS D10, MAX(mt_id) 
											AS mt_id, MAX(d12) AS d12, MAX(d13) AS d13, MAX(d14) AS d14, MAX(d15) AS d15, MAX(d16) 
											AS d16, CType, MAX(d17) AS d17, MAX(d18) AS d18, MAX(d19) AS d19, MAX(d20) AS d20, MAX(d21) AS d21
										FROM      dbo.gspalert AS g
										GROUP BY c_id, CType
                                       ) g on c.Client_id = g.c_id and g.mt_id=0 and g.ctype = 0              
    Left Join 
      (select C_id,MAX(credit_total)credit_total,MAX(APcredit_total) APcredit_total, MAX(sklimit)sklimit,sum(artotal)artotal,sum(artotal_ini)artotal_ini,
                   sum(aptotal)aptotal          ,sum(aptotal_ini)aptotal_ini            ,sum(pre_artotal)pre_artotal
                  ,sum(pre_artotal_ini)pre_artotal_ini,sum(pre_aptotal)pre_aptotal,sum(pre_aptotal_ini)pre_aptotal_ini
             from Clientsbalance where Y_id in (select sysvalue from sysconfig where [sysname]='Y_id') Group by C_id )CB on CB.c_id=C.client_id 
WHERE (c.deleted in (0, 4))
GO
