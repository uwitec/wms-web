/************************************************************

--功能：GMP证书查询   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE ts_j_InsUpdateGmp
	(
      @C_ID int = 0,
      @szmt_id varchar(500)='',
      @Gmpdate datetime =0,
      @GMPNO varchar(100),
      @nID int  /*0添加，>0 修改*/
     )
AS
begin
	/*Params Ini begin*/
	if @C_ID is null  SET @C_ID = 0
	if @szmt_id is null  SET @szmt_id = ''
	if @Gmpdate is null  SET @Gmpdate = 0
	/*Params Ini end*/
	declare @nRet int, @ga_id int
	set @nRet = -1
	if @nID = 0
	begin
		if exists(select * from GMPIndex where c_id = @C_ID and gmp_no = @GMPNO)
			return @nRet
		else
		begin
			insert into GMPIndex(c_id, GMP_NO, validdate) values(@C_ID, @GMPNO, @Gmpdate)
			set @nID = @@IDENTITY
		end
	end
	else
	begin
		update GMPIndex set GMP_NO = @GMPNO, validdate = @Gmpdate where g_id = @nID
		if @@ROWCOUNT = 0
			return -1
	end
	delete from GMPMedtype where ga_id = @nID
	set @nRet = @nID
	return @nRet
end
GO
