
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_PRODUCTS
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/
declare @nTmpParent_id varchar(36)

select @nTmpParent_id = '}'+@Parent_id
/*----*/
 declare @nTmpYID int
 set @nTmpYID=@nY_id
 if (@E_id=-100) 
   set @nTmpYID=@E_id
/*---*/
/*Wsj-2017-03-15优化函数FilterProduct引起查询商品效率慢问题先转换为临时表*/
/*yypeng-2017-04-17 把所有函数全部存入临时表加快开单速度，望以后开发看到这段代码随时警醒，慎用表值函数，很影响速度*/
 select * into #FilterProduct from dbo.FilterProduct(@nY_id)
 select * into #FnPDraftQty  from FnPDraftQty(@nTmpYID)
 select * into #FN_GetAvlqty from FN_GetAvlqty(0,0,@nTmpParent_id,0)
 
 
 
 if @szListFlag=''  goto ListLeavel  /*分级显示*/
 if @szListFlag='A' goto ListAll     /*全部列表*/
 if @szListFlag='P' goto ListPart    /*部分列表*/
 if @szListFlag='S' goto SearchAll    /*搜索*/
 if @szListFlag='C' goto ListCustomerSale	/*区域客户授权商品*/
 return 0                 
 ListCustomerSale:
	SELECT     T.*, T.Qty1 - T.DraftQty AS saleQty
	FROM         (SELECT     *,
													  (SELECT     ISNULL(SUM(quantity), 0) AS Expr1
														FROM          dbo.storehouse AS s
														WHERE      (FP.product_id = p_id)) AS qty,
													  (SELECT     ISNULL(SUM(DraftQty), 0) AS Expr1
														FROM          dbo.FnPDraftQty(0) AS pd
														WHERE      (FP.product_id = p_id)) AS DraftQty,
													  (SELECT     ISNULL(SUM(quantity), 0) AS Expr1
														FROM          dbo.storehouse AS s
														WHERE      (FP.product_id = p_id) AND (Y_ID = 0)) AS Qty1
						   FROM          dbo.FilterProduct(0) AS FP
						   ) AS T INNER JOIN
						  dbo.ProductCustomRight AS r ON T.product_id = r.p_id
	WHERE     (r.c_id = @E_id) 
 return 0
 SearchAll:
  set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
  set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s where '
  IF @nY_id <> 2
     SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND '     
  set @sql=@sql + ' FP.Product_id=s.p_id ) qty,'
  /*if @e_id<>0  set @Sql=@sql+' and s.s_id='+cast(@E_id as varchar(20)) + ') qty, '*/
  set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty ' 
  set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
  set @sql=@sql + 'from #FilterProduct FP Where Child_Number=0 and '+@szWhere + ') T '
  /*print @sql*/
  exec (@sql)
  return 0

 ListAll:
  if @e_id=0  /*全部仓库*/
  BEGIN
    set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
    set @sql= @sql +  'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s where '
   IF @nY_id <> 2
     SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND ' 
   set @sql=@sql + '  FP.Product_id=s.p_id ) qty, ' 
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql +  'from #FilterProduct FP  where Child_Number=0 ' +@szWhere + ') T '  
   /*wsk add @szWhere  2  2009-02-23 zjl增加可开数量*/
    /*print @sql*/
    exec(@sql)
  END  /* 全部仓库   OVER*/
  else
   if @e_id=-100 /*只统计配送中心仓库*/
   BEGIN
    set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
    set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s ,storages st
      where  s.s_id=st.storage_id and st.flag=0 and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from #FilterProduct FP
   where Child_Number=0 ' +@szWhere + ') T  '                      /*wsk add @szWhere*/
   exec(@sql)
   END            /*只统计配送中心仓库 OVER*/
   else
   BEGIN         /*当前仓库*/
   if UPPER(@TableName) = 'XJPRODUCTS' /*-*/
   begin
	 set @nTmpYID=@nY_id
	 if (@E_id=-100) 
	 set @nTmpYID=@E_id
   end
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s 
      where s.s_id='+ cast(@E_id as varchar) + ' and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from #FilterProduct FP where Child_Number=0 '+@szWhere + ') T '                      /*wsk add @szWhere*/
   /*print @sql*/
   exec(@sql)
   END          /*当前仓库   OVER  */

  return 0   /* ListAll 结束*/
 
 listPart:
  if @e_id=0  /*全部仓库*/
  BEGIN
   set @parent_id=@parent_id+'%'
   
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s where '
   IF @nY_id <> 2
     SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND '    
   set @sql=@sql + ' FP.Product_id=s.p_id) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from #FilterProduct FP
   where Parent_id like '+char(39)+ @parent_id+char(39)  + ' and Child_Number=0 '+@szWhere + ') T '                      /*wsk add @szWhere*/
   exec(@sql)
  END          /*全部仓库 OVER*/
  else
   if @e_id=-100     /*只统计配送中心仓库*/
  BEGIN  
   set @parent_id=@parent_id+'%'
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s ,storages st
      where  s.s_id=st.storage_id and st.flag=0 and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from #FilterProduct FP
   where Parent_id like '+char(39)+ @parent_id+char(39)  + ' and Child_Number=0 '+@szWhere + ') T '
   exec(@sql)
  END               /*只统计配送中心仓库  OVER */
   else         
  BEGIN             /*当前仓库*/
   set @parent_id=@parent_id+'%'
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s where s.s_id='+ cast(@E_id as varchar)+ ' and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50))  + ' ) qty, ' 
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from #FilterProduct FP
   where Parent_id like '+char(39)+ @parent_id+char(39)  + ' and Child_Number=0 '+@szWhere + ') T ' 
   exec(@sql)
  END                /*当前仓库 OVER */

  return 0            /*LISTPART OVER*/
 
 ListLeavel:
  if @e_id=0  /*全部仓库*/
  BEGIN
  if  @nFilterY=999
  begin
       set @sql='select *, (isnull(quantity2,0)) as saleQty  from ('
	   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0)   from storehouse s   where '
	   IF @nY_id <> 2
		 SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND '   
	   set @sql=@sql +  ' FP.Product_id=s.p_id) qty, '
	   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
	   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
	   set @sql=@sql + ' from FilterProductCL('+cast(@nY_ID as varchar(10))+') FP     
	   where  cldw<>0 and Parent_id='+char(39)+@parent_id+char(39)+' '+@szWhere + ') T ' 
	   + 'left join (select isnull(p_id,'''') as p_id,sum(isnull(quantity,0)) as quantity2 from #FN_GetAvlqty where storeQty>0 '
	   IF @nY_id <> 2
		 set @sql=@sql + ' and Y_ID=' + cast(@nY_id as varchar(20)) 
	   set @sql=@sql +' group by p_id) s on t.product_id = s.p_id'
	   set @sql=@sql +' order by Rowindex '
	   /*print @sql */
		exec(@sql) 
  end
  else
  begin
	   set @sql='select *, (isnull(quantity2,0)) as saleQty  from ('
	   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0)   from storehouse s   where '
	   IF @nY_id <> 2
		 SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND '   
	   set @sql=@sql +  ' FP.Product_id=s.p_id) qty, '
	   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
	   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
	   set @sql=@sql + ' from #FilterProduct FP     
	   where Parent_id='+char(39)+@parent_id+char(39)+' '+@szWhere + ') T ' 
	   + 'left join (select isnull(p_id,'''') as p_id,sum(isnull(quantity,0)) as quantity2 from #FN_GetAvlqty where storeQty>0 '
	   IF @nY_id <> 2
		 set @sql=@sql + ' and Y_ID=' + cast(@nY_id as varchar(20)) 
	   set @sql=@sql +' group by p_id) s on t.product_id = s.p_id'
	   set @sql=@sql +' order by Rowindex '
	   /*print @sql */
		exec(@sql) 
   end 
  END     /*全部仓库 OVER*/
  else
   if @e_id=-100 /*只统计配送中心仓库*/
  BEGIN
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0)  from storehouse s ,storages st
      where  s.s_id=st.storage_id and st.flag=0 and FP.Product_id=s.p_id 
          and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql= @sql + 'from #FilterProduct FP
   where Parent_id='+char(39)+@parent_id+char(39)+' '+@szWhere +') T order by Rowindex '
   /*print @sql*/
   exec(@sql)
  END             /*只统计配送中心仓库 OVER*/
   else
  BEGIN            /*当前仓库*/
  if  @nFilterY=999
  begin
	   set @sql='select *, (Qty1 - DraftQty) as saleQty,cldw as unit1_id  from ('
	   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0) 
		  from storehouse s 
		  where s.s_id='+cast(@E_id as varchar) +' and FP.Product_id=s.p_id 
			and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
	   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty ' 
	   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
	   set @sql=@sql + 'from FilterProductCL('+cast(@nY_ID as varchar(10))+') FP
	   where   cldw<>0  and  Parent_id='+char(39)+@parent_id+char(39)+' '+@szWhere + ') T order by Rowindex '
	   print @sql 
	   exec(@sql) 
   end
   else
   begin
      set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
	   set @sql= @sql + 'select *,(select isnull(sum(s.quantity),0) 
		  from storehouse s 
		  where s.s_id='+cast(@E_id as varchar) +' and FP.Product_id=s.p_id 
			and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
	   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from #fnPDraftQty pd where  FP.Product_id=pd.p_id) DraftQty ' 
	   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
	   set @sql=@sql + 'from #FilterProduct FP
	   where Parent_id='+char(39)+@parent_id+char(39)+' '+@szWhere + ') T order by Rowindex '

	   /*print @sql */
	   exec(@sql)
   end
  END              /*当前仓库 OVER */
  return 0           /*LISTLEAVEL OVER*/
GO
