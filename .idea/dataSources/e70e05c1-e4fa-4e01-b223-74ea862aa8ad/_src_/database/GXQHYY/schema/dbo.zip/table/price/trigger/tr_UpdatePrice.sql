


CREATE TRIGGER tr_UpdatePrice ON [dbo].[price] 
FOR  UPDATE
AS
declare @p_id int
declare	@recPrice numeric(18,4)
declare	@unittype int
if update(recPrice)
begin
	select @p_id=p_id,@recPrice=recPrice,@unitType=UnitType from inserted 
	update posPrice set recprice=@recprice where p_id=@P_id and UnitType=@UnitType
end
GO
