


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/****************************************

配送成本表

****************************************/
CREATE PROCEDURE TS_C_QrDbCost
(	@begindate 	DATETIME,
	@EndDate 	  DATETIME,
	@nZd_id		  INT=0,
	@nJs_id		  INT=0,
	@nSh_id		  INT=0,
	@nOutS_id	  INT=0,
	@nInS_id	  INT=0,
	@nBilltype	INT=0,
        @YClass_id      varchar(50)
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nZd_id is null  SET @nZd_id = 0
if @nJs_id is null  SET @nJs_id = 0
if @nSh_id is null  SET @nSh_id = 0
if @nOutS_id is null  SET @nOutS_id = 0
if @nInS_id is null  SET @nInS_id = 0
if @nBilltype is null  SET @nBilltype = 0
/*Params Ini end*/
  SET NOCOUNT ON 

  DECLARE @szBilltype VARCHAR(30), @SQLScript VARCHAR(8000), @TableName VARCHAR(30),
    @szSSClass_id VARCHAR(30),@szSdClass_id VARCHAR(30),@szZdClass_id VARCHAR(30),
	  @szJsClass_id VARCHAR(30),@szShClass_id VARCHAR(30)

  IF @nOutS_id<>0 SELECT @szSsClass_id=[class_id]+'%' FROM storages WHERE [storage_id]=@nOutS_id
  IF @nInS_id<>0  SELECT @szSdClass_id=[class_id]+'%' FROM storages WHERE [storage_id]=@nInS_id
  IF @nZd_id<>0	  SELECT @szZdClass_id=[class_id]+'%' FROM employees WHERE [emp_id]=@nZd_id
  IF @nJs_id<>0	  SELECT @szJsClass_id=[class_id]+'%' FROM employees WHERE [emp_id]=@nJs_id
  IF @nSh_id<>0	  SELECT @szShClass_id=[class_id]+'%' FROM employees WHERE [emp_id]=@nSh_id

  IF @nBillType=0 SET @szBilltype=' IN (44,45)'
  IF @nBillType=1 SET @szBilltype=' IN (44)'
  IF @nBillType=2 SET @szBilltype=' IN (45)'
  IF @nBillType=3 SET @szBilltype=' IN (53)'

IF @nBillType IN (0, 1, 2)
BEGIN
  SET @SQLScript=
	'SELECT CASE WHEN (GROUPING(vs.bill_id) = 1) THEN 0 ELSE ISNULL(vs.bill_id, ''unknow'') END AS billid,
		CASE WHEN (GROUPING(vs.smb_id) = 1) THEN 0 ELSE ISNULL(vs.smb_id, ''unknow'') END AS smb_id,
		MAX(vb.billtype) AS billtype,
    MAX(vb.billdate) AS billdate,
    MAX(vb.billnumber) AS billnumber,
		MAX(vs.p_id) AS p_id,
    MAX(vp.code) AS code,
    MAX(vp.[name]) pname,
    MAX(vp.standard) standard,
    MAX(vp.makearea) makearea,
    MAX(vp.medtype) medtype,
    MAX(vp.unitname1) unitname1,
		MAX(vs.batchno) AS batchno,
    MAX(vs.validdate) AS validdate,
		MAX(vs.ssname) ssname,
    MAX(vs.sdname) sdname,
    MAX(vb.inputman) AS inputman,
    MAX(vb.auditman) AS auditman,
    MAX(vb.ename) ename,
    MAX(vb.inputmanname) inputmanname,
    MAX(vb.auditmanname) auditmanname,
		MAX(vs.unitname) unitname,
    SUM(vs.quantity) AS quantity,
    SUM(vs.totalmoney) AS totalmoney,
    CAST(0 AS numeric(25,8)) AS taxtotal,
    CAST(0 AS numeric(25,8)) AS taxprice,
    CAST(SUM(vs.costtotal) as numeric(25,8)) costtotal,
    SUM(vs.retailmoney) AS retailmoney
		FROM VW_C_Storemb vs 
		LEFT JOIN VW_C_Billidx vb ON vb.billid=vs.bill_id
		LEFT JOIN VW_C_Products vp ON vs.p_id=vp.product_id
		WHERE (vb.billdate BETWEEN '+CHAR(39)+CAST(@begindate AS VARCHAR)+CHAR(39)+' AND '+CHAR(39)
      +CAST(@EndDate AS VARCHAR)+CHAR(39)+') AND vb.billstates=''0'''

END
ELSE BEGIN
  SET @SQLScript=
	'SELECT CASE WHEN (GROUPING(vs.bill_id) = 1) THEN 0 ELSE ISNULL(vs.bill_id, ''unknow'') END AS billid,
		CASE WHEN (GROUPING(vs.smb_id) = 1) THEN 0 ELSE ISNULL(vs.smb_id, ''unknow'') END AS smb_id,
		MAX(vb.billtype) AS billtype,
    MAX(vb.billdate) AS billdate,
    MAX(vb.billnumber) AS billnumber,
		MAX(vs.p_id) AS p_id,
    MAX(vp.code) AS code,
    MAX(vp.[name]) pname,
    MAX(vp.standard) standard,
    MAX(vp.makearea) makearea,
    MAX(vp.medtype) medtype,
    MAX(vp.unitname1) unitname1,
		MAX(vs.batchno) AS batchno,
    MAX(vs.validdate) AS validdate,
		MAX(vs.ssname) ssname,
    MAX(vs.sdname) sdname,
    MAX(vb.inputman) AS inputman,
    MAX(vb.auditman) AS auditman,
    MAX(vb.ename) ename,
    MAX(vb.inputmanname) inputmanname,
    MAX(vb.auditmanname) auditmanname,
		MAX(vs.unitname) unitname,
    SUM(vs.quantity) AS quantity,
    SUM(vs.totalmoney) AS totalmoney,
    SUM(vs.taxtotal) AS taxtotal,
    SUM(vs.taxPrice) AS taxprice,
    CAST(SUM(vs.costtotal) as numeric(25,8)) costtotal,
    SUM(vs.retailmoney) AS retailmoney
		FROM VW_F_Storemb vs 
		LEFT JOIN VW_C_Billidx vb ON vb.billid=vs.bill_id
		LEFT JOIN VW_C_Products vp ON vs.p_id=vp.product_id
		WHERE (vb.billdate BETWEEN '+CHAR(39)+CAST(@begindate AS VARCHAR)+CHAR(39)+' AND '+CHAR(39)
      +CAST(@EndDate AS VARCHAR)+CHAR(39)+') AND vb.billstates=''0'''
END

  IF @nOutS_id<>0 
  	SET @SQLScript=@SQLScript+' AND vs.ssclass_id LIKE '+CHAR(39)+@szSsClass_id+CHAR(39)
  IF @nInS_id<>0 
  	SET @SQLScript=@SQLScript+' AND vs.sdclass_id LIKE '+CHAR(39)+@szSdClass_id+CHAR(39)
  IF @nZd_id<>0 
  	SET @SQLScript=@SQLScript+' AND vb.inputmanclass_id LIKE '+CHAR(39)+@szZdClass_id+CHAR(39)
  IF @nJs_id<>0 
  	SET @SQLScript=@SQLScript+' AND vb.eclass_id LIKE '+CHAR(39)+@szJsClass_id+CHAR(39)
  IF @nSh_id<>0 
  	SET @SQLScript=@SQLScript+' AND vb.auditmanclass_id LIKE '+CHAR(39)+@szShClass_id+CHAR(39)

  IF @YClass_id<>''
        SET @SQLScript=@SQLScript+' AND vb.YClass_id LIKE '''+@YClass_id+'%'''
  SET @SQLScript=@SQLScript+' AND vb.billtype '+@szBilltype
  SET @SQLScript=@SQLScript+' GROUP BY vs.bill_id,vs.smb_id WITH ROLLUP'

  EXEC(@SQLScript)
  GOTO Succee 

Succee:
  RETURN 0
GO
