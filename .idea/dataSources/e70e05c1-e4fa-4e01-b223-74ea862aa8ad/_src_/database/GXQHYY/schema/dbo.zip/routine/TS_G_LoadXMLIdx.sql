/*exec TS_G_LoadXMLIdx  13,516,0x*/
CREATE PROCEDURE [dbo].[TS_G_LoadXMLIdx]
  @nHisId int = 0,
  @billtype INT,
  @guid UNIQUEIDENTIFIER = 0x
AS
BEGIN
	DECLARE @nxmlHandle int
	DECLARE @xml xml
	SELECT @xml = IdxContent FROM BillHistory WHERE type = 0 AND (id = @nHisId OR guid = @guid)
	EXEC sp_xml_preparedocument @nxmlHandle OUTPUT, @xml
	
	/*GSP单据*/
	IF @BillType BETWEEN 501 AND 599
	BEGIN
		SELECT  i.Gspbillid, i.billtype, i.billnumber, i.Y_id, i.c_id, i.billdate, i.inputman, i.auditman1, i.audittime1, i.auditman2, i.audittime2, 
                i.upauditman1, i.upauditman2, i.traffictype, i.traffictools, i.traffictime, i.tempcontrol, i.spectrafficprove, i.sendaddress, i.sendtime, 
                i.trafficCompany, i.tempcontrolmode, i.WholeQty, i.PartQty, i.discountTotal, i.taxTotal, i.Ybillid, i.Ybilltype, i.Yguid, 
                i.b_CustomName1, i.b_CustomName2, i.b_CustomName3, i.b_CustomName4, i.b_CustomName5, i.billstates, i.s_id, y.name Y_NAME, 
                ISNULL(CASE WHEN i.Ybilltype in (52, 152, 150, 161, 163) THEN cy.name ELSE cc.name end, '') C_NAME, 
                ipt.name AS INPUTER, ISNULL(a1.name, '') 
                AS AUDITER1, ISNULL(a2.name, '') AS AUDITER2, ISNULL(u1.name, '') AS UPAUDITER1, ISNULL(u2.name, '') 
                AS UPAUDITER2, ISNULL(s.name, '') AS S_NAME, i.Note, 
				ISNULL(CASE WHEN i.Ybilltype in (22, 14) THEN oi.taxrate ELSE bi.taxrate end, 0) AS TaxRate, 
				ISNULL(CASE WHEN i.Ybilltype in (22, 14) THEN oi.ename ELSE bi.ename end, '') AS YE_NAME,
				ISNULL(CASE WHEN i.Ybilltype in (22, 14) THEN oi.e_id ELSE bi.e_id end, 0) AS YE_ID,
				ISNULL(CASE WHEN i.Ybilltype in (22, 14) THEN oi.billnumber ELSE bi.billnumber end, '') AS YBILLNUMBER,
				CASE ISNULL(CASE WHEN i.Ybilltype in (22, 14) THEN oi.invoice ELSE bi.invoice end, 0) WHEN 0 THEN '无' WHEN 1 THEN '收据' WHEN 2 THEN '普票' WHEN 3 THEN '增值税票' ELSE '其它' END AS InvoiceType,
				financeAudit,financeAuditDate,ISNULL(e5.name, '') 
                AS FinanceAuditer, dbo.FN_GetVchStatesText(i.billstates, i.billtype) as billstateText,
				i.FollowNumber, i.TicketDate, i.BalanceMode, isnull(i.InBags,0) as InBags,
				isnull(i.sendc_id,0) as sendc_id,ISNULL(I.sendcname,'') as sendcname,i.InputMan
		FROM    OPENXML(@nxmlHandle, 'root/GSPbillidx', 1)
		WITH 
		(
				[Gspbillid] [int] ,
				[BillType] [int] ,
				[BillNumber] [varchar](30) ,
				[Y_id] [int] ,
				[C_id] [int] ,
				[S_id] [int] ,
				[BillDate] [datetime] ,
				[InputMan] [int] ,
				[AuditMan1] [int] ,
				[AuditTime1] [datetime] ,
				[AuditMan2] [int] ,
				[AuditTime2] [datetime] ,
				[UpauditMan1] [int] ,
				[UpauditMan2] [int] ,
				[TrafficType] [varchar](60) ,
				[TrafficTools] [varchar](100) ,
				[TrafficTime] [numeric](8, 1) ,
				[TempControl] [varchar](50) ,
				[SpecTrafficProve] [varchar](100) ,
				[SendAddress] [varchar](100) ,
				[SendTime] [datetime] ,
				[TrafficCompany] [varchar](100) ,
				[TempControlMode] [varchar](50) ,
				[WholeQty] [int] ,
				[PartQty] [int] ,
				[DiscountTotal] numeric(25,8) ,
				[TaxTotal] numeric(25,8) ,
				[Ybillid] [int] ,
				[Ybilltype] [int] ,
				[Yguid] [uniqueidentifier] ,
				[GUID] [uniqueidentifier] ,
				[BillStates] [smallint] ,
				[B_CustomName1] [varchar](100) ,
				[B_CustomName2] [varchar](100) ,
				[B_CustomName3] [varchar](100) ,
				[B_CustomName4] [varchar](100) ,
				[B_CustomName5] [varchar](100) ,
				[Note] [varchar](256),
				FollowNumber	varchar(100),
				TicketDate	varchar(100),
				transflag	int,
				Sendid	int,
				BalanceMode	int,
				financeAudit	int,
				financeAuditDate	datetime,
				InBags int,
				sendc_id int,
				sendcname varchar(100)
		) i
                inner JOIN
                dbo.company AS y ON i.Y_id = y.company_id left JOIN
                dbo.employees AS ipt ON i.inputman = ipt.emp_id LEFT OUTER JOIN
                dbo.employees AS a1 ON i.auditman1 = a1.emp_id LEFT OUTER JOIN
                dbo.employees AS a2 ON i.auditman2 = a2.emp_id LEFT OUTER JOIN
                dbo.employees AS u1 ON i.upauditman1 = u1.emp_id LEFT OUTER JOIN
                dbo.storages AS s ON i.s_id = s.storage_id LEFT OUTER JOIN
                dbo.employees AS u2 ON i.upauditman2 = u2.emp_id LEFT OUTER JOIN
                dbo.employees AS e5 ON i.financeAudit = e5.emp_id LEFT OUTER JOIN
				dbo.clients AS cc ON i.C_id = cc.client_id LEFT OUTER JOIN
				dbo.company AS cy ON i.C_id = cy.company_id LEFT OUTER JOIN
				dbo.vw_c_orderidx oi ON i.Ybillid = oi.billid AND i.Ybilltype IN(22, 14) LEFT JOIN
				dbo.vw_c_billidx bi ON i.Ybillid = bi.billid 		
		
	END
	
   /*订单*/
    ELSE IF @BillType IN (14, 22)
	BEGIN
		SELECT	b.*,0 as araptotal,
		  isnull(a.a_name,'') AS a_name,
		  isnull(c.c_name,'') AS c_name,
		  isnull(sc.c_name,'') AS sendc_name,
		  isnull(e.e_name,'') AS inputer,
		  isnull(s.s_name,'') AS s_name,
		  isnull(d.d_name,'') AS d_name,
		  isnull(s2.s_name,'') AS s_name2,
		  isnull(e1.e_name,'') AS e_name,
		  isnull(e2.e_name,'') AS auditer,
		  '' as Z_NAME,
		  isnull(pos.posname,'')  as POS_NAME,
		  0 as GatheringMan,0 as SendQTY,
		  0 as vipcardid,
		  isnull(Y.Name,'') as Y_NAME  ,
		  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
			  CURY_ID=b.Y_ID,B_CustomName1='',B_CustomName2='',B_CustomName3='',0 as WholeQty,0 as PartQty,
			  '' as GATHERINGName,
		  ISNULL(wt.saleEName , '') AS WT_EName,  b.TrafficCompany as CYDW, b.TrafficType as CYFS, SendTime as QYTime,
		  0 as QualityAudit,  '1900-01-01' as QualityAuditDate , '' as QualityAuditer,'' as FinanceAuditer, 0 as FinanceAudit,
		  '1900-1-1' as dpdate,'' as FollowNumber,'1900-01-01' as TicketDate, '1900-1-1' as FinanceAuditDate,
		  B_CustomName1,B_CustomName2,B_CustomName3,b.balancemode	
		 FROM OPENXML(@nxmlHandle, 'root/orderidx', 1)
		 WITH
		 (
			[billid] [int] ,
			[billdate] [datetime] ,
			[billnumber] [varchar](30) ,
			[billtype] [smallint] ,
			[a_id] [int] ,
			[c_id] [int] ,
			[e_id] [int] ,
			[sout_id] [int] ,
			[sin_id] [int] ,
			[auditman] [int] ,
			[inputman] [int] ,
			[ysmoney] numeric(25,8) ,
			[ssmoney] numeric(25,8) ,
			[quantity] numeric(25,8) ,
			[taxrate] [numeric](5, 2) ,
			[period] [smallint] ,
			[billstates] [char](1) ,
			[order_id] [int] ,
			[department_id] [int] ,
			[posid] [int] ,
			[region_id] [int] ,
			[auditdate] [datetime] ,
			[skdate] [datetime] ,
			[jsye] numeric(25,8) ,
			[jsflag] [char](1) ,
			[note] [varchar](256) ,
			[summary] [varchar](256) ,
			[invoice] [int] ,
			[InvoiceTotal] numeric(25,8) ,
			[InvoiceNO] [varchar](50) ,
			[BusinessType] [tinyint] ,
			[Guid] [uniqueidentifier] ,
			[Y_ID] [int] ,
			[WT_ID] [int] ,
			[OrderValidDate] [datetime] ,
			[GatheringMan] [int] ,
			[TrafficCompany] [varchar](100) ,
			[TrafficType] [varchar](60) ,
			[SendTime] [datetime] ,
			[SendC_ID] [int],
			B_CustomName1	varchar(100),
			B_CustomName2	varchar(100),
			B_CustomName3	varchar(100),
			yfye	int,
			yfdate	datetime,
			yfflag	int,
			BalanceMode	int
		 ) b
		/*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, */
		/*vw_b_dept d,vw_b_employee e1,vw_b_employee e2 ,vw_b_pos pos --, vw_b_region z*/
		/*     ,Company Y*/
		 inner join vw_b_employee e  on  b.inputman = e.e_id
		 left  join vw_b_employee e1 on b.e_id = e1.e_id
		 left  join vw_b_employee e2 on b.auditman = e2.e_id
		 left  join vw_b_account a   on b.a_id = a.a_id
		 left  join vw_b_client  c   on b.c_id = c.c_id
		 left  join vw_b_client  sc   on b.SendC_ID = sc.c_id
		 left  join vw_b_storage s   on b.sout_id = s.s_id
		 left  join vw_b_storage s2  on b.sin_id = s2.s_id
		 left  join vw_b_dept d      on b.department_id = d.d_id
		 left  join vw_b_pos pos     on b.PosID = pos.PosID
		 left  join Company Y        on b.Y_ID = Y.Company_ID
		 left  join wtorder wt       on b.WT_ID = wt.WT_ID	
		
	END	

	/*GSPTable的数据*/
	ELSE IF @billtype BETWEEN 2000 AND 3000
	BEGIN
			SELECT GspID, GspType, BillCode, BillE, BillDate, comment, CheckState, batchno, Sign, GSPVer, guid, szid, Y_ID, IFUpLoad, checkFlag, P_ID, szid2, BillId, BillType,
			       convert(varchar(8000),dbo.f_base64_decode(GspText)) GspText  
			FROM    OPENXML(@nxmlHandle, 'root/GspTable', 1)
					with(
							[GspID] [numeric](18, 0) ,
							[GspType] [smallint] ,
							[BillCode] [varchar](60) ,
							[BillE] [varchar](20) ,
							[BillDate] [datetime] ,
							[GspText] [varchar](8000) ,
							[comment] [varchar](60) ,
							[CheckState] [tinyint] ,
							[batchno] [text] ,
							[Sign] [tinyint] ,
							[GSPVer] [tinyint] ,
							[guid] [uniqueidentifier] ,
							[szid] [varchar](800) ,
							[Y_ID] [int] ,
							[IFUpLoad] [tinyint] ,
							[checkFlag] [int] ,
							[P_ID] [int] ,
							[szid2] [varchar](100) ,
							[BillId] [int] ,
							[BillType] [int]
						)
			ORDER BY GspID		
		
	END
	
    /*业务单据*/
    ELSE
	begin
		SELECT	b.*,
		  isnull(a.a_name,'') AS a_name,
		  isnull(c.c_name,'') AS c_name,
		  isnull(e.e_name,'') AS inputer,
		  isnull(s.s_name,'') AS s_name,
		  isnull(d.d_name,'') AS d_name,
		  isnull(s2.s_name,'') AS s_name2,
		  isnull(e1.e_name,'') AS e_name,
		  isnull(e2.e_name,'') AS auditer,
		  ISNULL(e3.e_name,'') AS GatheringName,
		  '' as Z_NAME,
		  isnull(pos.posname,'')  as POS_NAME,
		  isnull(Y.Name,'') as Y_NAME ,
			  getdate() AS BEGINDATE, getdate() as ENDDATE,getdate() as BEGINTIME,getdate() as  ENDTIME, '' as XQ,
		  CURY_ID=b.Y_ID,isnull(sc.c_name,'') AS sendc_name,B.WholeQty,B.PartQty, 
		  0 as WT_ID, '' AS WT_EName,  '' AS WT_EName, '' as CYDW, '' as CYFS, '1900-01-01' as QYTime, '1900-01-01' as OrderValiddate,
		  ISNULL(e4.e_name,'') AS QualityAuditer, ISNULL(e5.e_name,'') AS financeAuditer,
		  QualityAudit as QualityAudit,  QualityAuditDate as QualityAuditDate , financeAudit as financeAudit,  financeAuditDate as financeAuditDate,
		  FollowNumber,TicketDate, DPdate
		FROM OPENXML(@nxmlHandle, 'root/billdraftidx', 1)
		WITH 
		(
			[billid] [int] ,
			[billdate] [datetime] ,
			[billnumber] [varchar](30) ,
			[billtype] [smallint] ,
			[a_id] [int] ,
			[c_id] [int] ,
			[e_id] [int] ,
			[sout_id] [int] ,
			[sin_id] [int] ,
			[auditman] [int] ,
			[inputman] [int] ,
			[ysmoney] numeric(25,8) ,
			[ssmoney] numeric(25,8) ,
			[quantity] numeric(25,8) ,
			[taxrate] [numeric](5, 2) ,
			[period] [smallint] ,
			[billstates] [char](1) ,
			[order_id] [int] ,
			[department_id] [int] ,
			[posid] [int] ,
			[region_id] [int] ,
			[auditdate] [datetime] ,
			[skdate] [datetime] ,
			[jsye] numeric(25,8) ,
			[jsflag] [char](1) ,
			[note] [varchar](256) ,
			[summary] [varchar](256) ,
			[invoice] [int] ,
			[transcount] [tinyint] ,
			[lasttranstime] [datetime] ,
			[GUID] [uniqueidentifier]  ,
			[InvoiceTotal] numeric(25,8) ,
			[InvoiceNO] [varchar](50) ,
			[BusinessType] [tinyint] ,
			[ArAptotal] numeric(25,8) ,
			[SendQTY] numeric(25,8) ,
			[GatheringMan] [int] ,
			[VIPCardID] [int] ,
			[jsInvoiceTotal] [numeric](18, 8) ,
			[Y_ID] [int] ,
			[transflag] [int] ,
			[begindate] [datetime] ,
			[Enddate] [datetime] ,
			[integral] [int] ,
			[integralYE] numeric(25,8) ,
			[B_CustomName1] [varchar](100) ,
			[B_CustomName2] [varchar](100) ,
			[B_CustomName3] [varchar](100) ,
			[RetailDate] [datetime] ,
			[sendC_id] [int] ,
			[WholeQty] [int] ,
			[PartQty] [int] ,
			[WMSFlag] [int] ,
			[Thfs] [int] ,
			[DeliveryTime] [datetime] ,
			[QualityAudit] [int] ,
			[QualityAuditDate] [datetime] ,
			[YGuid] [uniqueidentifier],
			FollowNumber	varchar(100),
			TicketDate	varchar(100),
			BalanceMode	int,
			financeAudit	int,
			financeAuditDate	datetime,
			DPdate datetime
		) b
		/*, vw_b_account a, vw_b_client  c, vw_b_employee e, vw_b_storage s, vw_b_storage s2, vw_b_dept d*/
		/*     ,vw_b_employee e1,vw_b_employee e2,vw_b_employee e3 ,vw_b_pos pos,Company Y --, vw_b_region z*/
		/*     ,vw_b_client sc*/
		inner join vw_b_employee e on b.inputman = e.e_id
		inner join vw_b_employee e1 on b.e_id = e1.e_id
		left  join vw_b_employee e2 on b.auditman = e2.e_id
		left  join vw_b_employee e3 on b.gatheringMan =e3.e_id
		left  join vw_b_employee e4 on b.qualityaudit =e4.e_id
		left  join vw_b_employee e5 on b.financeAudit =e5.e_id
		left  join vw_b_account a   on b.a_id = a.a_id
		left  join vw_b_client  c   on	b.c_id = c.c_id 
		left  join vw_b_storage s   on b.sout_id = s.s_id
		left  join vw_b_storage s2  on b.sin_id = s2.s_id
		left  join vw_b_dept d      on b.department_id = d.d_id
		left  join vw_b_pos pos     on b.PosID = pos.PosID
		left  join Company Y        on b.Y_ID = Y.Company_ID
		left  join vw_b_client sc   on b.sendc_ID = sc.c_ID
	END 
	
	EXEC sp_xml_removedocument @nxmlHandle
END
GO
