
/*缺货分析　按客户汇总，表格2*/

CREATE	       PROCEDURE Ts_j_QrOOSCatalogC02
(
	@C_ID   int = 0,	  /*商品id*/
	@nflag   INT = 0,	  /*0[全部]  1未处理  2已处理 3已终止	*/
	@BeginDate  DATETIME,  
	@EndDate    DATETIME
)
/*with encryption*/
AS

	SELECT
	       p.serial_number, p.name AS PName, p.alias, p.[standard], p.Unit1Name,  
		   p.MedName, p.makearea, p.permitcode, p.unit1_id as unitid,o.ProductId, 
		   v.ModifyDate as buydate, v.BuyPrice, ISNULL(sp.name, '') as spName,  	
		   p.class_id,  e.name AS EName, i.name AS Inputman, 
           o.OOSId, o.ProductId, o.CompanyId, o.ClientId, o.EId, o.OOSQty, o.PlanQty,
           o.SaleQty, o.InputDate, o.InputManId, o.[Deleted], o.ModifyDate, o.CreateDate, 
           o.inflag, o.indisposeflag, o.inquantity, o.instoredate, o.indisposeMan, o.IndisposeDate,
           isnull(v.buyPrice, 0) as buyprice, o.buyOrderMxid, o.outquantity, o.outDisposeMan, o.OutDisposeDate,
           o.outdisposeflag, o.salebilltype,  isnull(inpute.name, '') as inputEname,  isnull(sp.name, '') as SupplierName,  
           isnull(oute.name, '') as OutEname,  case o.inflag when 0 then '未处理' when 1 then '已处理' else  '已终止' end as inflagName,
           case o.indisposeflag when 0 then '未处理' when 1 then '已采购' when 2 then '暂无货' else '' end as indisPoseflagName,  
           case o.outdisposeflag when 0 then '未处理' when 1 then '已部分开票' when 2 then '已全部开票' end as outDisposeflagName, 
           y.name AS YName, c.name AS CName,p.unit1_id as unitid, 
           ISNULL(dbo.GetOOSCatalogStorehouse(o.ProductId), 0) AS Qty,
           CASE WHEN (o.OOSQty < o.PlanQty) THEN 0 ELSE (o.OOSQty - o.PlanQty) END AS fQty,
           ISNULL(v.c_id, 0) AS SupplierId, o.Remark, P.TaxRate, p.factoryc_id factory_id 
    FROM OOSCatalog o INNER JOIN vw_products p ON o.ProductId = p.product_id
                      LEFT JOIN company y ON o.CompanyId = y.company_id
                      LEFT JOIN clients c ON o.ClientId = c.client_id
                      LEFT JOIN employees e ON o.EId = e.emp_id
                      LEFT JOIN employees i ON o.InputManId = i.emp_id
                      left join employees inputE on o.indisposeMan = inpute.emp_id
                      left join employees OutE on o.outdisposeMan = Oute.emp_id                                                                                                                               
                      LEFT JOIN (SELECT DISTINCT a.p_id, a.c_id, a.BuyPrice, a.ModifyDate 
									FROM buypricehis a INNER JOIN (SELECT p_id, MAX(ModifyDate) AS ModifyDate 
									                               FROM buypricehis WHERE Y_ID = 2 GROUP BY p_id) AS b 
									                   ON  a.p_id = b.p_id AND a.ModifyDate = b.ModifyDate) v ON o.ProductId = v.p_id
                      left join Clients sp on v.c_id = sp.client_id									                   
    WHERE o.[Deleted] = 0 AND p.[deleted] = 0 AND o.ClientId = @C_ID and 
          o.InputDate BETWEEN @BeginDate AND @EndDate and 
		 ((@nflag = 0) or (@nflag = 1 and o.Inflag =0) or (@nflag = 2 and o.Inflag =1) or (@nflag = 3 and o.Inflag =2))
GO
