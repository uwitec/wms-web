/************************************************************
--过程名称：门店类别配送表
--功能：查询门店按商品类别2进行查询
--创建人：LUO XIAOTIAN 
--创建时间：2010-11-10  
--最后修改:


参数说明：@begindate  --开始时间
          @enddate   --结束时间
          @szYClassid  --门店
          @nPSR2id --商品分类2

备注：
**************************************************************/
Create procedure [dbo].[ts_t_SendTable]
( 
  @begindate  datetime,
  @enddate    datetime,
  @szYClassid  Varchar(30),/*门店*/
  @nPSR2id  int /*商品分类2*/
)
AS
if OBJECT_ID('tempdb..#stock') is not null
   drop table #stock
create table #stock
( Y_id  int,
  stockQty  int,
  stockMoney  numeric(25,8))
if OBJECT_ID('tempdb..#untread') is not null
   drop table #untread
create table #untread
( Y_id  int,
  untreadQty int,
  untreadMoney numeric(25,8))
if OBJECT_ID('tempdb..#In') is not null
   drop table #In
 Create table #In
 ( Y_id  int,
   InQty       int,
   InMoney     numeric(25,8))
if OBJECT_ID('tempdb..#out') is not null
   drop table #out
 Create table #out
 ( Y_id  int, 
   outQty      int,
   outMoney    numeric(25,8))  

/*declare @sql varchar(3000)*/

insert #stock(Y_id,stockQty,stockMoney)
select bd.c_id ,ABS(sum(isnull(pd.quantity,0))),ABS(sum(isnull(pd.costtotal,0))) from 
       ( select pd.billid,pd.quantity,pd.costtotal from productdetail pd 
                  left join products p on pd.p_id=p.product_id
                   where p.SR2_id=@nPSR2id and pd.smb_id<0)pd
      left join billidx bd  on bd.billid=pd.billid 
where  billstates=0 and billtype=152 and billdate between @begindate and @enddate 
group by bd.c_id  order by bd.c_id
 
insert #untread(Y_id,untreadQty,untreadMoney)
select bd.c_id ,sum(isnull(pd.quantity,0)),sum(isnull(pd.costtotal,0)) from 
      ( select pd.billid,pd.quantity,pd.costtotal from productdetail pd 
                    left join products p on pd.p_id=p.product_id
           where p.SR2_id=@nPSR2id)pd  
           left join billidx bd on bd.billid=pd.billid        
where  billstates=0 and billtype=153 and billdate between @begindate and @enddate
group by bd.c_id  order by bd.c_id 

insert #In(Y_id,InQty,InMoney)
select pd.Y_ID ,sum(isnull(pd.quantity,0)),sum(isnull(pd.costtotal,0)) from
       ( select pd.billid,pd.Y_id,pd.quantity,pd.costtotal from productdetail pd 
                              left join products p on pd.p_id=p.product_id
                   where p.SR2_id=@nPSR2id )pd  
      left join billidx bd   on bd.billid=pd.billid          
where  billstates=0 and billtype=160 and billdate between @begindate and @enddate
group by pd.Y_ID  order by pd.Y_ID 

insert #out(Y_id,outQty,outMoney)
select pd.Y_ID ,sum(isnull(pd.quantity,0)),sum(isnull(pd.costtotal,0)) from 
      ( select pd.billid,pd.Y_id,pd.quantity,pd.costtotal from productdetail pd 
                              left join products p on pd.p_id=p.product_id
                   where p.SR2_id=@nPSR2id)pd
      left join  billidx bd   on bd.billid=pd.billid  
   /*   left join  storages s  on bd.Sin_id=s.storage_id             */
where  billstates=0 and billtype=150 and billdate between @begindate and @enddate
group by pd.Y_ID  order by pd.Y_ID 

select y.Company_id,y.name,isnull(s.stockQty,0)stockQty,isnull(s.stockMoney,0)stockMoney,
       isnull(u.untreadQty,0)untreadQty,isnull(u.untreadMoney,0)untreadMoney,
       isnull(I.InQty,0)InQty,isnull(I.InMoney,0)InMoney,-isnull(O.outQty,0)outQty,
       -isnull(O.outMoney,0)outMoney
       from company y 
               left join #stock s   on y.company_id=s.y_id
               left join #untread u on y.company_id=u.y_id  
               left join #In   I    on y.company_id=I.y_id
               left join #out  O    on y.company_id=O.y_id
where (@szYClassid='' or y.class_id like @szYClassid)  and y.deleted=0
       and y.class_id<>'000000' and y.class_id<>'000001'
GO
