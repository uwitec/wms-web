
CREATE       PROCEDURE [Ts_X_InsGiftQtySet]
 ( 
	@p_id [int] ,   /*商品id*/
	@AOID [int] ,  /*赠品类型*/
	@QTY [int] ,  /*数量*/
	@inputMan [int]   /*录入职员*/
  )

AS
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/

if @p_id = null set @p_id = 0
if @AOID = null set @AOID = 0
if @QTY = null set @QTY = 0
if @inputMan = null set @inputMan = 0


if @AOID > 0 and @p_id > 0
begin
	if exists(select 1 from giftProducts where p_id=@p_id and AOID=@AOID and insertTime = GETDATE())
	begin
	 /*RAISERROR('该商品重复添加！',16,1)*/
	 return -2
	end
	
  INSERT INTO [giftProducts] 
	  (
	[p_id] ,			
	[AOID],		
	[QTY] ,		
	[inputMan] ,
	[insertTime] 
	  )
	 
  VALUES 
	 (
	@p_id ,				/* 职员id*/
	@AOID ,				/* 赠品类型*/
	@QTY,			/* 数量*/
	@inputMan ,
	GETDATE() 
	  )
	/*if @@rowCount=0 */
  return @@identity	
end
GO
