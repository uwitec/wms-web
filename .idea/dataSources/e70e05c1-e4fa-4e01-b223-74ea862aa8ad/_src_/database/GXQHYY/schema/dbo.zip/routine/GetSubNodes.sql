
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2011-11-3*/
/* Description:	返回当前节点的子节点*/
/* =============================================*/
CREATE FUNCTION [dbo].[GetSubNodes] 
(
	@szClassID varchar(30), 
	@szListFlag char(1),
	@szTableFlag char(1),
	@nYid int = 0
)
RETURNS 
@tSubIDs TABLE 
(
	id int,
	class_id varchar(30)
)
AS
BEGIN
	if @szClassID in ('', '%', '%%', '%%%')
		set @szClassId = '000000'
		
	IF @szTableFlag = 'E'
	begin
		if @szListFlag = 'L'
			insert into @tSubIDs select emp_id, class_id from employees where parent_id = @szClassID and deleted <> 1 and (@nYid = 0 or y_id = @nYid)
		else if @szListFlag = 'P'
			insert into @tSubIDs select emp_id, class_id from employees where (@szClassId = '000000' or class_id like @szClassID + '%') and deleted <> 1 and (@nYid = 0 or y_id = @nYid) and child_number = 0
	end
	else
	if @szTableFlag = 'P'
	begin
		if @szListFlag = 'L'
			insert into @tSubIDs select product_id, class_id from products where parent_id = @szClassID and deleted <> 1
		else if @szListFlag = 'P'
			insert into @tSubIDs select product_id, class_id from products where (@szClassId = '000000' or class_id like @szClassID + '%') and deleted <> 1 and child_number = 0
	end
	else
	if @szTableFlag = 'S'
	begin
		if @szListFlag = 'L'
			insert into @tSubIDs select storage_id, class_id from storages where parent_id = @szClassID and deleted <>1  and (@nYid = 0 or y_id = @nYid)
		else if @szListFlag = 'P'
			insert into @tSubIDs select storage_id, class_id from storages where (@szClassId = '000000' or class_id like @szClassID + '%') and deleted <> 1 and (@nYid = 0 or y_id = @nYid) and child_number = 0
	end
	else
	if @szTableFlag = 'Y'
	begin
		if @szListFlag = 'L'
			insert into @tSubIDs select company_id, class_id from company where parent_id = @szClassID and deleted <> 1
		else if @szListFlag = 'P'
			insert into @tSubIDs select company_id, class_id from company where (@szClassId = '000000' or class_id like @szClassID + '%') and deleted <> 1 and child_number = 0
	end
	
	RETURN
END
GO
