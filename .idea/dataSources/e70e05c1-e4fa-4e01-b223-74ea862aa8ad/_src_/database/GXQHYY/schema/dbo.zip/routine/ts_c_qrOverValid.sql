

CREATE proc ts_c_qrOverValid
(  
  @nY_id  int
)
as
set nocount on 
select s.*,isnull(mt.mt_name,'') mt_name,s.code as barcode  
from vw_c_storehouse s 
left join (
		    select distinct a.baseinfo_id,b.mt_name from 
			(
			select  category_id,baseinfo_id  from customCategoryMapping where BaseTypeid=0 and deleted=0
			) a inner join 
			(
				SELECT id as mt_id ,name as  mt_name 
				FROM customCategory
				WHERE deleted = 0 and Typeid=2
			) b on a.category_id=b.mt_id
          ) mt on s.p_id=mt.baseinfo_id 
where s.Y_id=@nY_id and s.validdate<getdate() and s.validdate>0
GO
