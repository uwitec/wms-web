/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-9-17*/
/* Description:	生成商品批次条码*/
/* =============================================*/
CREATE FUNCTION MakeBatchBarcode 
(
	@nPid int,
	@szBatchNo varchar(20),
	@dtValidDate datetime,
	@nRnd int
)
RETURNS varchar(20)
AS
BEGIN
	DECLARE @Result varchar(20)
	DECLARE @position int
	DECLARE @nChar int
	DECLARE @szBatchTmp varchar(6)
	DECLARE @nDays int

	SET @Result = dbo.PadLeft(@nPid, 6, '0')
	SET @szBatchTmp = ''

	SET @position = 1
	SELECT @szBatchNo = RIGHT(@szBatchNo, 6)
	WHILE @position <= DATALENGTH(@szBatchNo)
	BEGIN
	SELECT @nChar = ASCII(SUBSTRING(@szBatchNo, @position, 1))
	IF @nChar >= 48 AND @nChar <= 57
		SET @szBatchTmp = @szBatchTmp + SUBSTRING(@szBatchNo, @position, 1)
	SET @position = @position + 1
	END
	SET @szBatchTmp = dbo.PadLeft(@szBatchTmp, 6, '0')

	SET @Result = @Result + @szBatchTmp

	SET @nDays = DATEDIFF(d, '2000-1-1', @dtValidDate)
	SET @Result = @Result + dbo.PadLeft(@nDays, 4, '0')
	SET @Result = @Result + dbo.PadLeft(@nRnd, 4, '0')

	RETURN @Result

END
GO
