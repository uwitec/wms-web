CREATE PROCEDURE Ts_K_SetSFDACodeOfBarCode(@PId INT, @UnitId INT, @Code VARCHAR(50))
AS
BEGIN
    /*设置电子监管码与商品的关联*/
	DELETE FROM barcode WHERE barcode = @Code
	INSERT INTO barcode(p_id, barcode, AutoCode, unitid, BarcodeType, codetype) 
	SELECT @PId, @Code, 0, @UnitId, 0, 0 
END
GO
