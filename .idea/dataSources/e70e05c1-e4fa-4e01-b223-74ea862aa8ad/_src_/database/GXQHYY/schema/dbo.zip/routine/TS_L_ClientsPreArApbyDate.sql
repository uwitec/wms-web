
/* 往来单位预收预付分布
  add by luowei 2012-067-01
*/

create procedure TS_L_ClientsPreArApbyDate
(
  @szbegindate varchar(20),  
  @szenddate varchar(20),
  @CClass_id  varchar(30)='',  /*单位class_id*/
  @YClass_id  varchar(60)='',  /*机构class_id*/
  @Eclass_id varchar(30) = '', /*职员class_id*/
  @OperatorID int              /*操作员id*/
)
as
begin
/*----------授权控制----------------------*/
declare @ClientTable int, @Companytable int,@employeestable int 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*----------授权控制结束-------------------*/

declare @c_id int
declare @e_id int
declare @y_id int

if @CClass_id = ''
  set @c_id = 0
else
  select @c_id = client_id from clients where class_id = @CClass_id
  
if @YClass_id = ''
  set @y_id = 0
else
  select @y_id = company_id from company where class_id = @YClass_id
  
if @Eclass_id = '' 
  set @e_id = 0 
else
  select @e_id = emp_id from employees where class_id = @Eclass_id     
  
 /*-XXX.2017-01-19 直接用id好来匹配预收，预付账款科目是不科学的，应该用 class_id*/
  declare @ar_id int    /*预收账款*/
  declare @ap_id int    /*预付账款*/
  
  select @ap_id = account_id from account where class_id = '000002000005'
  select @ar_id = account_id from account where class_id = '000001000009'

  /*---------------创建临时表用于存储需要的结构---------------*/
  create table #tmp
               (
                 c_id int,
                 class_id varchar(60),
                 [单位编号] varchar(100),
                 [往来单位] varchar(100),
                 [联系电话] varchar(100),
                 [联系人]   varchar(50),
                 [上期|预收] numeric(25,8),
                 [上期|预付] numeric(25,8)             
               )
   declare @vardatedeff int  /*时间差变量*/
   declare @monthvalue varchar(20)
   declare @month varchar(50)  /*月份列名称*/
   declare @sql varchar(500)
   
   set @vardatedeff = 0
   set @monthvalue = 0
   set @monthvalue = @szbegindate
   set @sql = ''
   set @month = ''
   set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差*/
       
   while(@vardatedeff>0)
   begin
     set @month = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月' /*得到月份列*/
     set @sql =' ALTER TABLE #tmp Add ['+@month+'|预收'+'] numeric(25,8) not NULL default(0) 
			     ALTER TABLE #tmp Add ['+@month+'|预付'+'] numeric(25,8) not NULL default(0)'
     exec (@sql)
     /*print @sql*/
     set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20)  
     set @vardatedeff = @vardatedeff -1
   end
   
   /*---------插入本期预收预付合计和当前预收预付列*/
   set @sql =	' ALTER TABLE #tmp Add [本期合计|预收合计] numeric(25,8) not NULL default(0) '+
   	        ' ALTER TABLE #tmp Add [本期合计|预付合计] numeric(25,8) not NULL default(0) '+
   	
   	        ' ALTER TABLE #tmp Add [期末|预收] numeric(25,8) not NULL default(0) '+
   	        ' ALTER TABLE #tmp Add [期末|预付] numeric(25,8) not NULL default(0) '+
   	
   	        ' ALTER TABLE #tmp Add [当前|预收] numeric(25,8) not NULL default(0) '+
   	        ' ALTER TABLE #tmp Add [当前|预付] numeric(25,8) not NULL default(0) '
   exec(@sql)
   	
   /*----------创建临时表 end-----------------*/
   
   /*-将往来单位全部类别插入临时表中*/
   insert #tmp(c_id,class_id,[单位编号],[往来单位],[联系电话],[联系人],[上期|预付],[上期|预收]) 
   select client_id,class_id,serial_number,name,phone_number,contact_personal,0,0 from clients c 
   where c.child_number = 0 and deleted = 0 and(@c_id = 0 or c.client_id= @c_id) order by class_id
   
   /*----------获取选择时间段内的单位预收预付-----------------*/
   	select c_id,billdate,sum(ysmoney) as ysmoney,SUM(yfmoney) as yfmoney into #t from 
	(
	select c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7) as billdate ,
		   (case a_id when @ap_id then SUM(jdmoney) else 0 end) as ysmoney,
		   (Case a_id when @ar_id then SUM(jdmoney) else 0 end) as yfmoney from 
	(
	select a.*,i.billdate from accountdetail a, billidx i
	where a.billid = i.billid and i.billstates = 0 and a.a_id in (@ar_id,@ap_id)
	      and i.billdate between @szbegindate and @szenddate
	      and (@c_id= 0 or a.c_id = @c_id)
	      and (@y_id= 0 or a.Y_ID = @y_id)
	      and (@e_id= 0 or i.e_id = @e_id)
	      AND ((@employeestable=0) OR (i.E_id in (select [id] from #employeestable)))
          AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
          AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))    
	) t group by c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7),a_id

	) tt group by c_id,billdate 
	/*----------------获取选择时间段内的单位预收预付 end----------------------		  */
	
	declare @upmonth varchar(20)
	declare @monthcolys varchar(50)
	declare @monthcolyf varchar(50)
	declare @upsql varchar(500)
	
	set @monthvalue = @szbegindate
	set @vardatedeff = DATEDIFF(M,@szbegindate,@szenddate) + 1  /*返回时间差            */
	while(@vardatedeff>0)
	begin
	  if LEN(convert(varchar(10),DATEPART(MM,@monthvalue))) =1 
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+'0'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	  else
	    set @upmonth = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'-'+convert(varchar(10),DATEPART(MM,@monthvalue)) /*得到月份列*/
	      
	  set @monthcolys = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|预收'  /*得到月份列*/
	  set @monthcolyf = convert(varchar(10),DATEPART(YYYY,@monthvalue))+'年'+convert(varchar(10),DATEPART(MM,@monthvalue)) +'月'+'|预付' /*得到月份列*/
	  set @upsql = 'update #tmp set ['+@monthcolys+'] = #t.ysmoney,['+@monthcolyf+'] = #t.yfmoney from #t where #t.c_id = #tmp.c_id and #t.billdate ='+CHAR(39)+@upmonth+CHAR(39)
	  /*print @upsql*/
	  exec(@upsql)
	  set @monthvalue = convert(varchar(10),DATEADD(M,1,@monthvalue),20) 
	  set @vardatedeff = @vardatedeff -1
	end  
	
	/*-------插入此前预收预付（上期 = 开始时间之前 + 期初）*/
    update #tmp set [上期|预收] = initable.ysmoney,[上期|预付] = initable.yfmoney
    from 
    ( select c_id,billdate,sum(ysmoney) as ysmoney,SUM(yfmoney) as yfmoney  from 
	  ( 
	    select c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7) as billdate ,
		   (case a_id when @ap_id then SUM(jdmoney) else 0 end) as ysmoney,
		   (Case a_id when @ar_id then SUM(jdmoney) else 0 end) as yfmoney from 
	    (
			select a.*,i.billdate from accountdetail a, billidx i
			where a.billid = i.billid and i.billstates = 0 and a.a_id in (@ar_id,@ap_id)
				  and i.billdate <@szbegindate
				  and (@c_id= 0 or a.c_id = @c_id)
	              and (@y_id= 0 or a.Y_ID = @y_id)
	              and (@e_id= 0 or i.e_id = @e_id)
				  AND ((@employeestable=0) OR (i.E_id in (select [id] from #employeestable)))
                  AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                  AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
	    ) t 
	    group by c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7),a_id
	) tt group by c_id,billdate
		  ) initable where initable.c_id = #tmp.c_id

/*------插入本期预收预付合计（即所选时间段内单位的预收预付合计）*/
    update  #tmp set [本期合计|预收合计] = hj.ysmoney,[本期合计|预付合计] = hj.yfmoney  from
    (    
	  select c_id,SUM(ysmoney) as ysmoney,SUM(yfmoney) as yfmoney 
	  from #t group by c_id
    ) hj where #tmp.c_id = hj.c_id

/*------插入当前预收预付和将上期加上期初*/
   update #tmp set [当前|预收] =dq.pre_artotal,[当前|预付] = dq.pre_aptotal,
   [上期|预收] = [上期|预收] + dq.pre_artotal_ini,[上期|预付] = [上期|预付] + dq.pre_aptotal_ini
   from
   (
     select c_id ,SUM(pre_artotal_ini) as pre_artotal_ini,SUM(pre_artotal) as pre_artotal,
             SUM(pre_aptotal) as pre_aptotal,SUM(pre_aptotal_ini) as pre_aptotal_ini
     from Clientsbalance where (@c_id = 0 or c_id = @c_id) and (@y_id = 0 or Y_id = @y_id)
     group by C_ID
   ) dq  where #tmp.c_id = dq.c_id 	
   
/*-----插入期末预收预付*/

/*update #tmp set [期末|预收] = lasttable.ysmoney,[期末|预付] = lasttable.yfmoney
    from 
    ( select c_id,billdate,sum(ysmoney) as ysmoney,SUM(yfmoney) as yfmoney  from 
	  ( 
	    select c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7) as billdate ,
		   (case a_id when 67 then SUM(jdmoney) else 0 end) as ysmoney,
		   (Case a_id when 66 then SUM(jdmoney) else 0 end) as yfmoney from 
	    (
			select a.*,i.billdate from accountdetail a, billidx i
			where a.billid = i.billid and i.billstates = 0 and a.a_id in (67,66)
				  and i.billdate >@szenddate
				  and (@c_id= 0 or a.c_id = @c_id)
	              and (@y_id= 0 or a.Y_ID = @y_id)
	              and (@e_id= 0 or i.e_id = @e_id)
				  AND ((@employeestable=0) OR (i.E_id in (select [id] from #employeestable)))
                  AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                  AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
	    ) t 
	    group by c_id,SUBSTRING(convert(varchar(20),billdate,20),1,7),a_id
	) tt group by c_id,billdate
		  ) lasttable where lasttable.c_id = #tmp.c_id */
		  
	/*-期末 = 本期合计 + 上期 modify by luowei 2012-11-05	  */
	 update #tmp set [期末|预收] = [本期合计|预收合计] + [上期|预收],[期末|预付] = [本期合计|预付合计] + [上期|预付] 
	
	/*ALTER TABLE #tmp DROP column c_id  --删除c_id字段 */
	
	SELECT * FROM #tmp
    drop table #tmp
    drop table #t            
end
GO
