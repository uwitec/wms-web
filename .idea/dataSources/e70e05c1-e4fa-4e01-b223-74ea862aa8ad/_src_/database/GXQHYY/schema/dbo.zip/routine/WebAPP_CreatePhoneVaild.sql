




/*保存会员卡和微信号绑定*/
/*调整了，不再在后台生成发送文件，直接在云平台上发送验证码这儿是作判断用*/
CREATE PROCEDURE [WebAPP_CreatePhoneVaild]
(
    @tel	varchar(30),
    @weixinno	varchar(50),
    @validcode	varchar(20),
    @newFlag	int,
    @chvErrMsg		varchar(100) out
)

/*$Encode$--*/

AS
 if(@weixinno='')
 begin
	select @chvErrMsg='微信号不能为空'
	select @chvErrMsg as outMsg,-1 as reCode
	return -1
end
if (@tel ='')
begin
	select @chvErrMsg='卡号和电话号码不能同时为空'
	select @chvErrMsg as outMsg,-1 as reCode
	return -1
end
if @newFlag=0
begin
	if not exists(select 1 from vipcard where Tel=@tel and Deleted=0 and isLock=0)
	begin
		select @chvErrMsg='没有相应的会员信息'
		select @chvErrMsg as outMsg,-1 as reCode
		return -1
	end

	if exists(select count(1) from vipcard where Tel=@tel and Deleted=0 and isLock=0  having count(*)>1)
	begin
		select @chvErrMsg='电话号码在会员号中的信息不唯一'
		select @chvErrMsg as outMsg,-1 as reCode
		return -1
	end
end
else if @newFlag=1
begin
	if exists(select 1 from vipcard where tel=@tel or cardno=@tel)
	begin
		select @chvErrMsg='该电话号码已被注册'
		select @chvErrMsg as outMsg,-1 as reCode
		return -1
	end
end
else if @newFlag=3/*往来单位*/
begin
	declare @phone_number varchar(200)	
	select @phone_number=phone_number from clients where serial_number=@tel
	if isnull(@phone_number,'')<>''
	begin
		update clients set wxbindpass=@validcode where serial_number=@tel
		select @tel=@phone_number
	end
	else
	begin
		select '单位编号不正确，或对应的手机号不正确' as outMsg,-1 as reCode
		return -1
	end
end

if @newFlag<>3
	select @chvErrMsg=@validcode
else
	select @chvErrMsg=@validcode

/*--===现改成直接在微信后台发送短信
--向短信内容表插入一条新的短信，字段SendFlag等于2代表为发送，为了方便这里把IP默认为127.0.0.1
--insert into PhoneSendDetails(loginIP,LoginID,LoginName,ReceiveID,ReceiveTel,ReceiveName,SendTime,SendContent,SendFlag) 
--values('127.0.0.1',1,'系统管理员',0,@tel,'短信验证码',getdate(),@chvErrMsg,2)
*/

select @chvErrMsg=@tel
/*需要返回电话号码*/
select @chvErrMsg as outMsg,0 as reCode
return 0
GO
