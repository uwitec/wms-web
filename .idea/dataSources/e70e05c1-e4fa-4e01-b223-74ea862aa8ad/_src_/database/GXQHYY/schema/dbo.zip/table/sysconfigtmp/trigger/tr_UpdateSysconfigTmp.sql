
CREATE TRIGGER dbo.tr_UpdateSysconfigTmp 
   ON  dbo.sysconfigtmp 
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @ID INT
	DECLARE @v1 VARCHAR(30)
	DECLARE @v2 VARCHAR(30)
	DECLARE @n VARCHAR(30)
	SELECT @ID = systmp_id FROM inserted
	SELECT @n = sysname FROM inserted
	SELECT @v1 = sysvalue FROM deleted
	SELECT @v2 = sysvalue FROM inserted
	IF @v1 <> @v2
		INSERT INTO SystemLog(EID, ActionTag, VchID, ActionType, Computer, ActionDate, Comment)
		VALUES(-2, -2, @ID, 'sysconfigtmp', 'SYS', GETDATE(), @n + '：' +  @v1 + ' -> ' + @v2)
END
GO
