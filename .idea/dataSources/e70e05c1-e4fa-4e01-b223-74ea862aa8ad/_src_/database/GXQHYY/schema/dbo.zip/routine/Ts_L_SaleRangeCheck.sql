

CREATE	PROCEDURE [Ts_L_SaleRangeCheck]
	(@C_id 	[int],
	 @sr_id	[int],
	 @IfSelect [int])

AS
IF @C_id < 0
BEGIN
	EXEC Ts_L_SaleRangeCheck_His @C_id, @sr_id, @IfSelect
	RETURN 1
END
ELSE
if (@IfSelect=1)
begin
	if  not exists (select c_id from SaleRangeCheck where c_id=@c_id and [sr_id]=@sr_id)
	begin
		INSERT INTO [SaleRangeCheck] ( [c_id],[sr_id]) 
		VALUES (@c_id,@sr_id)
		if @@rowcount<>0 
			return @@IDENTITY
		else
			return 0
	end
end else
begin
	delete  SaleRangeCheck where c_id=@c_id and [sr_id]=@sr_id
	return 1
end
GO
