



CREATE  VIEW DBO.[VW_X_UnionClient]
AS
SELECT U.[ID], U.[C_ID], U.[S_ID], 
  CAST(U.[PassWord] AS VARCHAR) AS [PASSWORD],
  U.[Comment],
  ISNULL(D.[Serial_Number], '') AS [DCode],
  ISNULL(S.[Serial_Number], '') AS [SCode],
  ISNULL(D.[Name], '') AS [DName],
  ISNULL(S.[Name], '') AS [SName]
FROM DBO.UnionClient U
  LEFT JOIN DBO.DepartMent D ON U.[C_ID]=D.[DepartmentID]
  LEFT JOIN DBO.Storages   S ON U.[S_ID]=S.[Storage_ID]
GO
