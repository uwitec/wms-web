
create proc ts_c_qrMultSaletrace
(
  @begindate		datetime,
  @enddate			datetime,
  @szEClass_id		varchar(30),
  @Supplierid		int,
  @nYClassid		varchar(100)='',
  @nloginEID		int=0,
  @isaddDate		int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
  @InputmanID		varchar(50),
  @sPids1			varchar(8000),
  @sPids2			varchar(8000),
  @sPids3			varchar(8000),
  @sPids4			varchar(8000),
  @sPids5			varchar(8000),
  @sBillType		varchar(8000)
)
/*with encryption*/
as
/*Params Ini begin*/
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
set nocount on 
if @szEClass_id='' select @szEClass_id='%%' else select @szEClass_id=@szEClass_id+'%'
if @InputmanID=''  select @InputmanID='%%'  else select @InputmanID=@InputmanID+'%'
if @nYClassid=''   select @nYClassid='%%'   else select @nYClassid=@nYClassid+'%'

/* 商品临时表*/
CREATE TABLE #tmpP (ID int)
INSERT INTO #tmpP SELECT * FROM DecodeStr(@sPids1)
INSERT INTO #tmpP SELECT * FROM DecodeStr(@sPids2)
INSERT INTO #tmpP SELECT * FROM DecodeStr(@sPids3)
INSERT INTO #tmpP SELECT * FROM DecodeStr(@sPids4)
INSERT INTO #tmpP SELECT * FROM DecodeStr(@sPids5)

/* 单据类型临时表*/
CREATE TABLE #tmpB (ID int)
INSERT INTO #tmpB SELECT * FROM DecodeStr(@sBillType)

  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
/*----------------获取Y_ID */
select company_id into #y_id from company where class_id like @nYClassid

/*---本期库存*/
select p_id,SUM(qty) as qty into #CurrentStore from 
(
	select p_id,SUM(-quantity) as qty from productdetail pd 
	where storetype = 0 and Y_ID in (select * from #y_id) and
	exists(select 1 from billidx idx where idx.billid = pd.billid and idx.billstates = 0 and idx.billdate > @enddate)
	group by p_id
	union all
	select p_id,SUM(quantity) as qty from storehouse where Y_ID in (select * from #y_id) group by p_id
) a group by a.p_id  order by p_id

/*----上期库存*/

select p_id,SUM(qty) as qty into #preStore from 
(
	select p_id,SUM(quantity) as qty from productdetail pd 
	where storetype = 0 and Y_ID in (select * from #y_id) and 
	exists(select 1 from billidx idx where idx.billid = pd.billid and idx.billstates = 0 and idx.billdate < @begindate)
	group by p_id
	union all
	select p_id,SUM(quantity) as qty from storehouseini where Y_ID in (select * from #y_id) group by p_id
) a group by a.p_id  order by p_id



/*销售流向查询*/
select   a. p_id ,a. billid  ,a. batchno , a.costprice, a. vbbilltype, a.  pcode ,
         a.billdate , a.inputman,a. ename, a. e_id,a.billnumber, a.billtype,a.cname,
	     a.pname,a.factory,a.standard,a.makearea,a.permitcode,a.e_name,a.C_Name,a.trademark, a.unitname1,
	     a.comment, a.medtype,a.taxprice,a.suppliername, a.sname,
	      a.quantity,a.taxtotal,a.costtotal,
	    a. prestoreqty,
	    a. currentstoreqty,
	    a.billstates 
	    ,a.inputname  INTO #tempA     from (
	select 
	case when (grouping(vs.p_id) = 1) then -1
			            else isnull(vs.p_id, '总计')
			       end as p_id,
	/*		vs.p_id,*/
	case when (grouping(vs.billid) = 1) then -2
			            else isnull(vs.billid,0)
			       end as billid,
	cast(case when (grouping(vs.batchno) = '1') then '-1111'
			            else isnull(vs.batchno, '-111')
			       END AS varchar) as batchno,
	case when (grouping(vs.costprice) = 1) then -1111
			            else isnull(vs.costprice, 0)
			       end as costprice,
        case when (grouping(vs.billtype) = 1) then -1111
			            else isnull(vs.billtype, 0)
			       end as vbbilltype,
	
	/*    max(vs.batchno)    as  batchno              ,*/
	/*    max(vs.costprice)  as  costprice        ,*/
	    max(vs.code)       as  pcode                ,
	    max(vs.billdate)   as  billdate             ,
	    max(vs.inputman)   as  inputman             ,
	    max(vs.Rename)     as  ename                ,
	    max(vs.Rowe_id)    as  e_id                 ,
	    max(vs.billnumber) as  billnumber           ,
	    max(vs.billtype)   as  billtype             ,
	    cname=case when max(vs.billtype) in (44,45) then max(vs.sdname) else max(isnull(vs.cname,'')) end,
	    max(vs.[name])     as  pname                ,
	    max(vs.Factory)    as  Factory              ,
	    max(vs.standard)   as  standard             ,
	    max(vs.makearea)   as  makearea             ,
	    max(vs.permitcode) as  permitcode           ,
	    MAX(vs.e_name)     as  e_name               ,
	    MAX(vs.C_Name)     as  C_Name               ,
	    max(vs.trademark)  as  trademark            ,
	    max(isnull(U1.[name],'')) as  unitname1     ,
	    max(vs.comment)    as  comment              ,
	    max(ISNULL(M.[MT_Name],'')) as  medtype     ,
	    max(vs.taxprice)   as  taxprice             ,
        max(vs.supname)    as suppliername  	,
	    sname=case when max(vs.billtype) in (44,45) then max(vs.sdname) else max(vs.sname) end,
	    quantity=sum(case when (vs.billtype in (44,45)) then abs(vs.quantity)/1 else vs.quantity end),  
	    sum(vs.taxtotal)  as taxtotal,  
	    sum(vs.costtotal) as costtotal,
	    isnull(max(#preStore.qty),0) as prestoreqty,
	    isnull(max(#CurrentStore.qty),0) as currentstoreqty,
	    0 AS billstates 
            ,max(vs.inputname) as inputname
	from
        (  select YPSM.*,p.serial_number as code,p.[name],p.standard,p.makearea,p.factory, p.permitcode,p.trademark,p.comment,p.medtype
                     ,p.Unit1_ID,isnull(VP.e_name,'') as e_name,isnull(VP.C_Name,'') as C_Name
                     ,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(RE.[name],'')REname
                     ,isnull(C.Class_id,'')CClass_id,
                      case when YPSM.billtype in(150,151,152,153,160,161) then CY.[name] else c.[name] end as Cname
                     ,isnull(Sup.Class_id,'')SupClass_id,isnull(Sup.[name],'')Supname
                     ,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id
                     ,isnull(Sd.[name],'')Sdname,isnull(s.[name],'')sname,e.name as inputname
           from  
             (SELECT vb.billid,vb.billdate,vb.billnumber,vs.p_id,vs.batchno,vs.costprice,vs.supplier_id,vb.billtype,
                     vs.aoid,vs.RowE_ID,vb.Inputman,vb.Y_id,vb.sin_id,vb.c_id,vs.taxprice,Vs.s_id,                             
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -vs.quantity else vs.quantity end)quantity,
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -vs.taxtotal else vs.taxtotal end)taxtotal,
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -(vs.quantity*vs.costprice) else (vs.quantity*vs.costprice) end)costtotal
              FROM
                (select bill_id,p_id,quantity,batchno,costprice,supplier_id,taxprice,taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                UNION all
                Select bill_id,p_id,quantity,batchno,costprice,supplier_id,taxprice,taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id from buymanagebill
                UNION all
                Select bill_id,p_id,quantity,batchno,costprice,supplier_id,0 as taxprice,0 as taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id from storemanagebill 
                ) vs
                INNER JOIN 
                (select billid ,billdate,billnumber,billtype,Inputman,Y_id,sin_id,c_id 
                 from billidx where billtype in (select distinct ID from #tmpB) and billstates='0' 
                   and billdate between @begindate and @enddate
                ) VB on vb.billid=vs.bill_id 
              WHERE vs.p_id in (select ID from #tmpP) and vs.aoid in(0,5)
             )YPSM
           LEFT JOIN Products  p   on p.product_id=YPSM.p_id
           LEFT JOIN employees RE  on re.emp_id=YPSM.RowE_id
           LEFT JOIN Clients   Sup on YPSM.supplier_id=sup.client_id
           LEFT JOIN employees E   on YPSM.inputman=E.emp_id 
           LEFT JOIN Company   Y   on Y.Company_id=YPSM.y_id
           LEFT JOIN storages  Sd  on Sd.storage_id=YPSM.sin_id
           LEFT JOIN storages  S   on S.storage_id=YPSM.s_id
           LEFT JOIN Clients   C   on C.Client_id=YPSM.c_id
	       LEFT JOIN Company   CY  on CY.company_id=YPSM.c_id
	       LEFT JOIN vw_productbalance VP ON p.product_id = VP.p_id and VP.Y_id=YPSM.Y_ID 
        )VS 
        LEFT JOIN Unit U1    ON vs.[Unit1_ID]=U1.[Unit_ID]
        LEFT JOIN (select baseinfo_id,name as MT_Name from customCategoryMapping cu 
					left join customCategory c on cu.category_id = c.id 
					where BaseTypeid = 0 and c.Typeid = 2 and cu.deleted = 0) M  ON vs.[p_id]=M.[baseinfo_id]
        left join #preStore  on #preStore.p_id = vs.p_id
        left join #CurrentStore on #CurrentStore.p_id = vs.p_id 
        where (@Companytable=0 or (vs.Y_id in (select [id] from #Companytable)))
          AND vs.YClass_id like @nYClassid
          and(@ClientTable=0 or (vs.c_id in (select [id] from #Clienttable)))
          AND (@employeestable=0 OR (vs.RowE_id in (select [id] from #Employeestable)))
          AND vs.reclass_id like @szEClass_id 
          AND vs.Inputmanclass_id like @InputmanID
          and (@supplierid =0 or vs.supplier_id=@supplierid) 
          AND (@ClientTable=0 or (vs.supplier_id in (select [id] from #Clienttable)))
          
	group by vs.p_id,vs.billid,vs.batchno,vs.costprice,vs.billtype with rollup
	
	UNION ALL
	/*@isaddDate = 1时显示红字反冲单据*/
	select 
	case when (vs.p_id = 1) then -1
			            else isnull(vs.p_id, '总计')
			       end as p_id,
	/*		vs.p_id,*/
	case when (vs.billid = 1) then -2
			            else isnull(vs.billid,0)
			       end as billid,
	cast(case when (vs.batchno = '1') then '-1111'
			            else isnull(vs.batchno, '-111')
			       END AS varchar) as batchno,
	case when (vs.costprice = 1) then -1111
			            else isnull(vs.costprice, 0)
			       end as costprice,
        case when (vs.billtype = 1) then -1111
			            else isnull(vs.billtype, 0)
			       end as vbbilltype,
	
	/*    max(vs.batchno)    as  batchno              ,*/
	/*    max(vs.costprice)  as  costprice        ,*/
	    max(vs.code)       as  pcode                ,
	    max(vs.billdate)   as  billdate             ,
	    max(vs.inputman)   as  inputman             ,
	    max(vs.Rename)     as  ename                ,
	    max(vs.Rowe_id)    as  e_id                 ,
	    max(vs.billnumber) as  billnumber           ,
	    max(vs.billtype)   as  billtype             ,
	    cname=case when max(vs.billtype) in (44,45) then max(vs.sdname) else max(isnull(vs.cname,'')) end,
	    max(vs.[name])     as  pname                ,
	    max(vs.Factory)    as  Factory              ,
	    max(vs.standard)   as  standard             ,
	    max(vs.makearea)   as  makearea             ,
	    max(vs.permitcode) as  permitcode           ,
	    MAX(vs.e_name)     as  e_name               ,
	    MAX(vs.C_Name)     as  C_Name               ,
	    max(vs.trademark)  as  trademark            ,
	    max(isnull(U1.[name],'')) as  unitname1     ,
	    max(vs.comment)    as  comment              ,
	    max(ISNULL(M.[MT_Name],'')) as  medtype     ,
	    max(vs.taxprice)   as  taxprice             ,
        max(vs.supname)    as suppliername  	,
	    sname=case when max(vs.billtype) in (44,45) then max(vs.sdname) else max(vs.sname) end,
	    quantity=sum(case when (vs.billtype in (44,45)) then abs(vs.quantity)/1 else vs.quantity end),  
	    sum(vs.taxtotal)  as taxtotal,  
	    sum(vs.costtotal) as costtotal,
	    isnull(max(#preStore.qty),0) as prestoreqty,
	    isnull(max(#CurrentStore.qty),0) as currentstoreqty,
	    1 AS billstates
	    ,'' as inputname   
	from
        (  select YPSM.*,p.serial_number as code,p.[name],p.standard,p.makearea,p.factory,p.permitcode,p.trademark,p.comment,p.medtype
                     ,p.Unit1_ID,isnull(VP.e_name,'') as e_name,isnull(VP.C_Name,'') as C_Name
                     ,isnull(P.Class_id,'')PClass_id,isnull(RE.Class_id,'')REClass_id,isnull(RE.[name],'')REname
                     ,isnull(C.Class_id,'')CClass_id,
                      case when YPSM.billtype in(150,151,152,153,160,161) then CY.[name] else c.[name] end as Cname
                     ,isnull(Sup.Class_id,'')SupClass_id,isnull(Sup.[name],'')Supname
                     ,isnull(E.Class_id,'')InputmanClass_id,isnull(Y.Class_id,'')YClass_id
                     ,isnull(Sd.[name],'')Sdname,isnull(s.[name],'')sname
           from  
             (SELECT vb.billid,vb.billdate,vb.billnumber,vs.p_id,vs.batchno,vs.costprice,vs.supplier_id,vb.billtype,
                     vs.aoid,vs.RowE_ID,vb.Inputman,vb.Y_id,vb.sin_id,vb.c_id,vs.taxprice,Vs.s_id,                             
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -vs.quantity else vs.quantity end)quantity,
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -vs.taxtotal else vs.taxtotal end)taxtotal,
                     (case when vb.billtype in (21,221,10,12,210,212,41,49,150,152,161,163) then -(vs.quantity*vs.costprice) else (vs.quantity*vs.costprice) end)costtotal
              FROM
                (select bill_id,p_id,quantity,batchno,costprice,supplier_id,taxprice,taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                UNION all
                Select bill_id,p_id,quantity,batchno,costprice,supplier_id,taxprice,taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id from buymanagebill
                UNION all
                Select bill_id,p_id,quantity,batchno,costprice,supplier_id,0 as taxprice,0 as taxtotal,(quantity*costprice)costtotal,aoid,RowE_id,ss_id as s_id from storemanagebill 
                ) vs
                INNER JOIN 
                (select billid ,billdate,billnumber,billtype,Inputman,Y_id,sin_id,c_id 
                 from billidx where @isaddDate = 1 and billtype in (select distinct ID from #tmpB) and billstates='1' 
                   and billdate between @begindate and @enddate
                ) VB on vb.billid=vs.bill_id 
              WHERE vs.p_id in (select ID from #tmpP) and vs.aoid in(0,5)
             )YPSM
           LEFT JOIN Products  p   on p.product_id=YPSM.p_id
           LEFT JOIN employees RE  on re.emp_id=YPSM.RowE_id
           LEFT JOIN Clients   Sup on YPSM.supplier_id=sup.client_id
           LEFT JOIN employees E   on YPSM.inputman=E.emp_id 
           LEFT JOIN Company   Y   on Y.Company_id=YPSM.y_id
           LEFT JOIN storages  Sd  on Sd.storage_id=YPSM.sin_id
           LEFT JOIN storages  S   on S.storage_id=YPSM.s_id
           LEFT JOIN Clients   C   on C.Client_id=YPSM.c_id
	       LEFT JOIN Company   CY  on CY.company_id=YPSM.c_id
	       LEFT JOIN vw_productbalance VP ON p.product_id = VP.p_id and VP.Y_id=YPSM.Y_ID 
        )VS 
        LEFT JOIN Unit U1    ON vs.[Unit1_ID]=U1.[Unit_ID]
        LEFT JOIN Medtype M  ON vs.[Medtype]=M.[MT_ID]
        left join #preStore  on #preStore.p_id = vs.p_id
        left join #CurrentStore on #CurrentStore.p_id = vs.p_id 
        where (@Companytable=0 or (vs.Y_id in (select [id] from #Companytable)))
          AND vs.YClass_id like @nYClassid
          and(@ClientTable=0 or (vs.c_id in (select [id] from #Clienttable)))
          AND (@employeestable=0 OR (vs.RowE_id in (select [id] from #Employeestable)))
          AND vs.reclass_id like @szEClass_id 
          AND vs.Inputmanclass_id like @InputmanID
          and (@supplierid =0 or vs.supplier_id=@supplierid) 
          AND (@ClientTable=0 or (vs.supplier_id in (select [id] from #Clienttable)))
          
	group by vs.p_id,vs.billid,vs.batchno,vs.costprice,vs.billtype /*with rollup*/
	/*@isaddDate = 1时显示红字反冲单据*/
	union all
	select 
	    vp.product_id     as  p_id                 ,
	    /*9999             as  billid               ,*/
	    99999999             as  billid               ,
	    ''                as  batchno              ,
	    0                 as  costprice            ,
            ''                as  vbbilltype           ,
	    vp.Serial_Number  as  pcode                ,
	    0                 as  billdate             ,
	    ''                as  inputman             ,
	    ''                as  ename                ,
	    0                 as  e_id                 ,
	    ''                as  billnumber           ,
	    0                 as  billtype             ,
	    ''                as  cname                ,
	    vp.[name]         as  pname                ,
	    vp.factory        as  factory              ,
	    vp.standard       as  standard             ,
	    vp.makearea       as  makearea             ,
	    vp.permitcode     as  permitcode           ,
	   isnull(vpb.e_name,'')        as e_name                ,
	   isnull(vpb.C_Name,'')        as C_Name                ,
	    vp.trademark      as  trademark            ,
       isnull(u1.[name],'')    as  unitname1            ,
	    vp.comment        as  comment              ,
       ISNULL(M.[MT_Name],'')  as  medtype              ,
	    0                 as  taxprice             ,
      ''								as  suppliername				 ,
	    ''                as  sname                ,
	    0                 as  quantity             ,  
	    0                 as  taxtotal             ,
	    0                 as  costtotal            ,
	    isnull(#preStore.qty,0)     as  prestoreqty          ,
	    isnull(#CurrentStore.qty,0) as  currentstoreqty,
	    0 AS billstates 
	    ,'' as inputname             
	from products vp left join Unit U1 ON vp.[Unit1_ID]=U1.[Unit_ID]
                     LEFT JOIN Medtype M  ON vp.[Medtype]=M.[MT_ID]  
                     LEFt JOin 
                     (select * from vw_productbalance where Y_ID in (select * from #y_id)) vpb on vpb.p_id= vp.product_id
                     left join #CurrentStore on #CurrentStore.p_id = vp.product_id
                     left join #preStore on #preStore.p_id = vp.product_id
                         
	where  vp.product_id in (select ID from #tmpP)
	
	) as a 
	/*order by a.p_id desc,a.billdate,a.ename*/
	SELECT * FROM  #tempA WHERE p_id IN(SELECT  p_id FROM #tempA GROUP BY p_id HAVING COUNT(p_id)>1 OR p_id=-1 )
	order by p_id DESC,billid desc,billdate ,ename /*quantity asc*/
	drop table #CurrentStore
	drop table #preStore
	DROP TABLE #tmpP
	DROP TABLE #tmpB
	DROP TABLE #tempA
GO
