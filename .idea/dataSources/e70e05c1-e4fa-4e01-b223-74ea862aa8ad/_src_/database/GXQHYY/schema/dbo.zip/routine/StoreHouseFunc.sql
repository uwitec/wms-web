






CREATE FUNCTION StoreHouseFunc(@nS_id int)  
RETURNS table 
 AS  
	return	(SELECT a.class_id, b.s_id, ISNULL(SUM(b.quantity), 0) AS quantity, 
	      ISNULL(SUM(b.costtotal), 0) AS costtotal
		FROM dbo.products a INNER JOIN
		      dbo.storehouse b ON a.product_id = b.p_id
		WHERE (a.deleted <> 1 and b.S_id=@nS_id)
		GROUP BY a.class_id, b.s_id
	)
GO
