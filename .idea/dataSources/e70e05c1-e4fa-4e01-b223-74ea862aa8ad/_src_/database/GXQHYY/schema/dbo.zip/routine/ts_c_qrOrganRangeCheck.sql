

create proc ts_c_qrOrganRangeCheck
(
	@nC_id int,/*机构ID*/
	@nP_id int
)
/*with encryption*/
as
set nocount on 
declare @iReturn int

select @iReturn=-1

if not exists(select top 1 * from OrganRangeCheck)
  select @iReturn=0
else
if exists(select 1 from products where product_id=@nP_id and sr_id=0) 
  select @iReturn=0
else 
if exists(select sr.sr_id from OrganRangeCheck sr,products p where sr.sr_id=p.sr_id and p.product_id=@nP_id and sr.c_id=@nC_id) 
  select @iReturn=0

select @iReturn as nRet
GO
