

/*====================================*/
/*卡卷设置*/
/*select * from wx_vip_ticket*/
/*====================================*/
CREATE PROCEDURE WebAPP_GetVipticketList
(
@keywords		varchar(100),
@pageszie	int,
@page		int
)
/*$Encode$--*/
AS
declare @sindex int,@eindex int
select @keywords = '%'+ISNULL(@keywords,'')+'%'
select @sindex = @pageszie*(@page - 1) + 1
select @eindex = @pageszie * @page

declare @recordCount int
/*得到总行数*/
select @recordCount=COUNT(*) from wx_vip_ticket where name like @keywords or content like @keywords and deleted=0
select @recordCount=ISNULL(@recordCount,0)

SELECT tt.Row,tt.name,tt.total,
case when tt.endday>0 then '领取之后【'+CAST(endday as varchar)+'】天有效' else CONVERT(varchar(10),tt.begindate,20)+'至'+ CONVERT(varchar(10),tt.enddate,20) end as validate,
tt.id,tt.createdate,isnull(tt.givetotal,0) as givetotal,'' as reurl ,deleted
FROM (
	SELECT ROW_NUMBER() OVER (
		order by w.createdate desc
	)AS Row, w.*,t.givetotal
	from wx_vip_ticket w 
	left join
	(
		select t_id,count(*) as givetotal from wx_vip_getticket group by t_id
	) t on w.id=t.t_id
	where (w.name like @keywords or w.content like @keywords) and w.deleted=0
) TT 
 WHERE TT.Row between @sindex and @eindex
 
select @recordCount as [rowCount], 0 as reCode
return 0
GO
