
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-3-21*/
/* Description:	处理GSP流程单据到货/退货数量*/
/* =============================================*/
CREATE PROCEDURE TS_H_GspQtyAct 
	@nBillType int,
	@nBillId int,
	@nAct int /* 1：增加 -1：扣除*/
AS
BEGIN
	SET NOCOUNT ON;

	/* 采购收货、冷藏采购收货*/
	IF @nBillType IN(511, 513)
	BEGIN
		IF NOT EXISTS(SELECT * FROM GSPbillidx WHERE BillType = @nBillType AND GSPbillid = @nBillId)
			RETURN 0
		UPDATE OrderBill SET ComeQty = ComeQty + X.InceptQty * @nAct, ComeDate = X.BillDate
		FROM
		(SELECT OrgBillid, SUM(InceptQty) AS InceptQty, BillDate FROM GSPbilldetail B INNER JOIN GSPbillidx I 
			ON B.Gspbill_id = I.Gspbillid WHERE Gspbill_id = @nBillId GROUP BY B.OrgBillid, I.BillDate) X
		WHERE OrderBill.smb_id = X.OrgBillid
	END
	
	/* 销售退回申请生成收货单*/
	IF @nBillType IN(512)
	BEGIN
		IF NOT EXISTS(SELECT * FROM GSPbillidx WHERE BillType = @nBillType AND GSPbillid = @nBillId)
			RETURN 0
		UPDATE salemanagebill SET thqty = thqty + X.InceptQty * @nAct
		FROM
		(SELECT OrgBillid, SUM(InceptQty) AS InceptQty, BillDate FROM GSPbilldetail B INNER JOIN GSPbillidx I 
			ON B.Gspbill_id = I.Gspbillid WHERE Gspbill_id = @nBillId GROUP BY B.OrgBillid, I.BillDate) X
		WHERE salemanagebill.smb_id = X.OrgBillid
	END
	
	/* 直调采购单*/
	IF @nBillType = 515
	BEGIN
		IF NOT EXISTS(SELECT * FROM GSPbillidx WHERE BillType = @nBillType AND GSPbillid = @nBillId)
			RETURN 0
		UPDATE OrderBill SET ComeQty = ComeQty + X.InceptQty * @nAct, ComeDate = X.BillDate
		FROM
		(SELECT OrgBillid, SUM(InceptQty) AS InceptQty, BillDate FROM GSPbilldetail B INNER JOIN GSPbillidx I 
			ON B.Gspbill_id = I.Gspbillid WHERE Gspbill_id = @nBillId GROUP BY B.OrgBillid, I.BillDate) X
		WHERE OrderBill.smb_id = X.OrgBillid
	END
END
GO
