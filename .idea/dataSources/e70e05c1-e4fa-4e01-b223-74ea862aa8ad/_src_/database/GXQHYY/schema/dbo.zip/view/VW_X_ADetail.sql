
CREATE  VIEW [VW_X_ADetail]
AS
SELECT AD.*, 
  ISNULL(C.[Class_ID] ,'') AS [CClass_ID], 
  ISNULL(A.[Class_ID] ,'') AS [AClass_ID], 
  ISNULL(A.[Name]     ,'') AS [AccountName], 
  ISNULL(C.[Name]     ,'') AS [ClientName]
FROM AccountDetail AD
  LEFT JOIN Account A ON A.[Account_ID]=AD.[A_ID] 
  LEFT JOIN Clients C ON C.[Client_ID]=AD.[C_ID]
GO
