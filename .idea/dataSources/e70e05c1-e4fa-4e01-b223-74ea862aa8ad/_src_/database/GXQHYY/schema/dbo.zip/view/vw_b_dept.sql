















CREATE	VIEW dbo.vw_b_dept
AS
SELECT departmentid as d_id, name as d_name
FROM department
WHERE deleted = 0
GO
