

CREATE VIEW [VW_C_Invoice]
AS
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],       BI.[Billtype],  ' ' as [Note],
  BI.[Inputmanname],     BI.[Auditmanname], BI.[Billstates],  	   BI.[CName],     BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID], (0)  AS [InvoiceID],
  BI.[Invoice],          BI.[Invoiceno],    BI.[Invoicetotal],
  BI.[Note] AS [BillComment], 
  BI.[Billdate]     AS [Invoicedate],
  BI.[Inputmanname] AS [Invoiceinputname],
  BI.[Auditmanname] AS [Invoiceauditname],
  BI.[E_ID]         AS [Invoiceinput],
  BI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN BI.[billtype] in (11,21,24,25,54,56) THEN -BI.[Ysmoney] ELSE BI.[Ysmoney]  END AS [Taxtotal],
  (0)               AS [Smb_ID],
  (0)               AS [P_ID],
  (0)		            AS [AOID],
  (0)               AS [Taxprice],
  (0)               AS [Quantity],
  (5)	              AS [FlagIdx]
FROM VW_X_BillIDX BI
WHERE BI.[Billstates]='0' AND BI.[Billtype] IN (10,11,112,20,21,122,15,23,16,17,24,25,32,35,18,28,53,54,55,56)
UNION ALL
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],       BI.[Billtype],  ' ' as [Note],
  BI.[Inputmanname],     BI.[Auditmanname], BI.[Billstates],       BI.[CName],   BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID], (0)  AS [InvoiceID], 
  SM.[Invoice],          SM.[Invoiceno],    SM.[Invoicetotal],
  BI.[Note] AS [BillComment], 
  BI.[Billdate]     AS [Invoicedate],
  BI.[Inputmanname] AS [Invoiceinputname],
  BI.[Auditmanname] AS [Invoiceauditname],
  BI.[E_ID]         AS [Invoiceinput],
  BI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN (BI.[Billtype] IN (11,17) OR (BI.[Billtype] IN (18) AND SM.[IOTag]=0)) THEN -SM.[Taxtotal]  ELSE SM.[Taxtotal] END AS [Taxtotal],
  SM.[Smb_ID]       AS [Smb_ID],
  SM.[P_ID]         AS [P_ID],
  SM.[AOID]	        AS [AOID], 
  SM.[Taxprice]     AS [Taxprice],
  SM.[Quantity]     AS [Quantity],
  (3)               AS FlagIdx
FROM VW_X_BillIDX BI, VW_c_SaleMB SM
WHERE BI.[BillID]=SM.[Bill_ID] AND BI.[Billstates]='0' AND BI.[Billtype] IN (10,11,112,16,17,18,32)
UNION ALL
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],       BI.[Billtype],  ' ' as [Note],
  BI.[Inputmanname],     BI.[Auditmanname], BI.[Billstates],       BI.[CName],      BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID], (0)  AS [InvoiceID],
  BM.[Invoice],          BM.[Invoiceno],    BM.[Invoicetotal],
  BI.[Note] AS [BillComment],
  BI.[Billdate]     AS [Invoicedate],
  BI.[Inputmanname] AS [Invoiceinputname],
  BI.[Auditmanname] AS [Invoiceauditname],
  BI.[E_ID]         AS [Invoiceinput],
  BI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN (BI.[Billtype] in (21,25) OR (BI.[Billtype] IN (28) AND BM.[IOTag]=0)) THEN -BM.[Taxtotal]  ELSE  BM.[Taxtotal]  END   AS [Taxtotal],
  BM.[Smb_ID]       AS [Smb_ID],
  BM.[P_ID]         AS [P_ID],
  BM.[AOID]	        AS [AOID],
  BM.[Taxprice]     AS [Taxprice],
  BM.[Quantity]     AS [Quantity],
  (2)               AS FlagIdx
FROM VW_X_BillIDX BI, VW_c_BuyMB BM
WHERE BI.[BillID]=BM.[Bill_ID] AND BI.[Billstates]='0' AND BI.[Billtype] IN (20,21,122,24,25,28,35) 
UNION ALL
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],             BI.[Billtype],  VI.[Comment] AS [Note],
  BI.[Inputmanname],     BI.[Auditmanname], VI.[States] AS [Billstates], BI.[CName], BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID],       VI.[ID] AS [InvoiceID],	
  VI.[Invoice],          VI.[Invoiceno],    VI.[Invoicetotal],
  BI.[Note] AS [BillComment],
  VI.[Invoicedate]  AS [Invoicedate],
  E1.[Name]         AS [Invoiceinputname],
  E2.[Name]         AS [Invoiceauditname],
  VI.[Inputman]     AS [Invoiceinput],
  VI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN BI.[billtype] in (11,21,24,25) THEN -BI.[Ysmoney] ELSE BI.[Ysmoney]  END AS [Taxtotal],
  V.[Smb_ID]        AS [Smb_ID],
  (0)               AS [P_ID],
  (0)		            AS [AOID],
  (0)               AS [Taxprice],
  (0)               AS [Quantity],
  (4)               AS FlagIdx
FROM Invoice V 
LEFT JOIN InvoiceIDX VI      ON V.[InvoiceID]=VI.[ID]
LEFT JOIN Employees E1      ON VI.[Inputman]=E1.[Emp_ID]
LEFT JOIN Employees E2      ON VI.[Auditman]=E2.[Emp_ID]
LEFT JOIN VW_X_BillIDX BI ON BI.[BillID]=V.[BillID]
WHERE V.[Smb_ID]=0
UNION ALL
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],             BI.[Billtype],  VI.[Comment] AS [Note],
  BI.[Inputmanname],     BI.[Auditmanname], VI.[States] AS [Billstates], BI.[CName], BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID],       VI.[ID] AS [InvoiceID], 
  VI.[Invoice],          VI.[Invoiceno],    VI.[Invoicetotal],
  BI.[Note] AS [BillComment],
  VI.[Invoicedate]  AS [Invoicedate],
  E1.[Name]         AS [Invoiceinputname],
  E2.[Name]         AS [Invoiceauditname],
  VI.[Inputman]     AS [Invoiceinput],
  VI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN (BI.[Billtype] IN (11,17) OR (BI.[Billtype] IN (18) AND SM.[IOTag]=0)) THEN -SM.[Taxtotal]  ELSE SM.[Taxtotal] END    AS [Taxtotal],
  V.[Smb_ID]        AS [Smb_ID],
  SM.[P_ID]         AS [P_ID],
  SM.[AOID]	        AS [AOID],
  SM.[Taxprice]     AS [Taxprice],
  SM.[Quantity]     AS [Quantity],
  (1)               AS FlagIdx
FROM VW_X_BillIDX BI, Invoice V, InvoiceIDX VI, Employees E1, Employees E2, VW_c_SaleMB SM
WHERE BI.[Billtype] IN (10,11,112,16,17,18,32) AND BI.[Billstates]='0' AND BI.[BillID]=V.[BillID] 
  AND V.[InvoiceID]=VI.[ID] AND VI.[Inputman]=E1.[Emp_ID] AND VI.[Auditman]=E2.[Emp_ID] AND V.[Smb_ID]<>0 
  AND V.[Smb_ID]=SM.[Smb_ID] AND V.[BillID]=SM.[Bill_ID]
UNION ALL
SELECT
  BI.[BillID],           BI.[Billdate],     BI.[Billnumber],             BI.[Billtype],  VI.[Comment] AS [Note],
  BI.[Inputmanname],     BI.[Auditmanname], VI.[States] AS [Billstates], BI.[CName], BI.[Cclass_ID], BI.[Eclass_ID],
  BI.[InputmanClass_ID], BI.[InputMan],     BI.[AuditmanClass_ID],	 VI.[ID] AS [InvoiceID],
  VI.[Invoice],          VI.[Invoiceno],    VI.[Invoicetotal],
  BI.[Note] AS [BillComment],
  VI.[Invoicedate]  AS [Invoicedate],
  E1.[Name]         AS [Invoiceinputname],
  E2.[Name]         AS [Invoiceauditname],
  VI.[Inputman]     AS [Invoiceinput],
  VI.[Auditman]     AS [Invoiceaudit],
  CASE WHEN (BI.[Billtype] in (21,25) OR (BI.[Billtype] IN (28) AND BM.[IOTag]=0)) THEN -BM.[Taxtotal]  ELSE  BM.[Taxtotal]  END  AS [Taxtotal],
  V.[Smb_ID]        AS [Smb_ID],
  BM.[P_ID]         AS [P_ID],
  BM.[AOID]	        AS [AOID],
  BM.[Taxprice]     AS [Taxprice],
  BM.[Quantity]     AS [Quantity],
  (0)               AS FlagIdx
FROM VW_X_BillIDX BI, Invoice V, InvoiceIDX VI, Employees E1, Employees E2, VW_c_BuyMB BM
WHERE BI.[Billtype] IN (20,21,122,24,25,28,35) AND BI.[Billstates]='0' AND BI.[BillID]=V.[BillID] 
  AND V.[InvoiceID]=VI.[ID] AND VI.[Inputman]=E1.[Emp_ID] AND VI.[Auditman]=E2.[Emp_ID] AND V.[Smb_ID]<>0 
  AND V.[Smb_ID]=BM.[Smb_ID] AND V.[BillID]=BM.[Bill_ID]
GO
