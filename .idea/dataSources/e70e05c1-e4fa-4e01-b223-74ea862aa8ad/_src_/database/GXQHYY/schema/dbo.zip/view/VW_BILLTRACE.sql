
CREATE	   VIEW dbo.VW_BILLTRACE
AS

SELECT     idx.BillNumber, idx.billId, idx.billType, idx.BillTypeName, idx.inputman, idx.billdate, idx.isDraft, e.name AS ename, 
                      dbo.FN_GetVchStatesText(idx.BILLSTATES, idx.billType) AS states, idx.BILLSTATES, idx.id, idx.lastId, 
                      idx.traceGuid, idx.tableTag, dbo.FN_GetVchAuditMan(idx.billid, idx.billtype, idx.isDraft) AS auditername
FROM         (SELECT     CASE T .ISDRAFT WHEN 0 THEN I.BILLNUMBER ELSE CASE WHEN T .BILLTYPE IN (14, 22, 26, 108, 154) THEN O.BILLNUMBER WHEN T .BILLTYPE BETWEEN 
                                              501 AND 599 THEN G.BILLNUMBER ELSE D .BILLNUMBER END END AS BillNumber, T.billId, T.billType, ISNULL(V.Comment, '') AS BillTypeName, 
                                              CASE T .ISDRAFT WHEN 0 THEN I.INPUTMAN ELSE CASE WHEN T .BILLTYPE IN (14, 22, 26, 108, 154) THEN O.inputman WHEN T .BILLTYPE BETWEEN 501 AND 
                                              599 THEN G.inputman ELSE D .inputman END END AS inputman, CASE T .ISDRAFT WHEN 0 THEN I.billdate ELSE CASE WHEN T .BILLTYPE IN (14, 22, 26, 108, 154) 
                                              THEN O.billdate WHEN T .BILLTYPE BETWEEN 501 AND 599 THEN G.billdate ELSE D .billdate END END AS billdate, T.isDraft, 
                                              CASE T .ISDRAFT WHEN 0 THEN I.BILLSTATES ELSE CASE WHEN T .BILLTYPE IN (14, 22, 26, 108, 154) THEN O.BILLSTATES WHEN T .BILLTYPE BETWEEN 
                                              501 AND 599 THEN G.BILLSTATES ELSE D .BILLSTATES END END AS BILLSTATES, T.id, T.lastId, T.traceGuid, CASE WHEN T .BILLTYPE IN (14, 22, 26, 108, 154) 
                                              THEN 'O' WHEN T .BILLTYPE BETWEEN 501 AND 599 THEN 'G' WHEN T .BILLTYPE IN (150, 152, 10, 11, 151, 153, 106) THEN 'S' WHEN T .BILLTYPE IN (20, 
                                              21, 160, 162, 163, 161, 104) THEN 'B' ELSE '-' END AS tableTag
                       FROM          dbo.billTrace AS T LEFT OUTER JOIN
                                              dbo.VchType AS V ON T.billType = V.Vch_ID LEFT OUTER JOIN
                                              dbo.billidx AS I ON T.billId = I.billid LEFT OUTER JOIN
                                              dbo.billdraftidx AS D ON T.billId = D.billid LEFT OUTER JOIN
                                              dbo.GSPbillidx AS G ON T.billId = G.Gspbillid LEFT OUTER JOIN
                                              dbo.orderidx AS O ON T.billId = O.billid) AS idx INNER JOIN
                      dbo.employees AS e ON idx.inputman = e.emp_id
GO
