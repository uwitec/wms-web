




CREATE FUNCTION GetPTcMoney(
 @Pro_id     int =0,   /* 提成方案ID*/
 @p_id      INT = 0,
 @mSLTotal  numeric(25,8),/*数量*/
 @mJeTotal  numeric(25,8),/*金额*/
 @mMLTotal  numeric(25,8))/*毛利  */
RETURNS numeric(25,8)
AS 
BEGIN
  declare @Fid   Int
  declare @TcType int
  declare @dTotal  numeric(25,8)
  declare @TcMoney numeric(25,8)

  select @Fid=0
  select @TcType=0
  select @dTotal=0
  select @TcMoney=0

  select @Fid=isnull(TPO.f_id,0),@TcType=TcType from TcProjectOther TPO,TcFormula F 
       where Tpo.f_id=F.Formula_ID and Tpo.Tp_id=@Pro_id and Tpo.p_id=@p_id          

  if @Fid=0  /*没有特殊提成公式*/
    select @Fid=TP.F_id,@TcType=TcType from TcProject TP ,TcFormula F 
       where Tp.f_id=F.Formula_ID and TP.TcProject_ID=@Pro_ID

  select @dTotal=case @TcType when 2 then @mSLTotal/*按数量提成*/
                              when 3 then @mJETotal/*按金额提成*/
                              when 4 then @mMLTotal/*毛利*/
                              /*when 5 then @mJeTotal--zh20110428固定提成(取消商品固定处理到职员上)*/
                 end

  if @TcType=2  /*数量提成不是百分比*/
    select @TcMoney=@dTotal*dbo.GetTcRate(@dTotal,@Fid)
 /* if @TcType=5 --固定金额提成也不是百分比 zh20110428
   begin
    if @dTotal<>0
     select @TcMoney=dbo.GetTcRate(@dTotal,@Fid)
    if @dTotal=0
     select @TcMoney=@dTotal*dbo.GetTcRate(@dTotal,@Fid)--dbo.GetTcRate(@dTotal,@Fid)
    --select @TcMoney=(select TcRate from TcFormuLaMX where (@dTotal between BeginNum and EndNum) and F_ID=@FID )
   end */
  /*if @TcType not in (2,5)*/
  else
    select @TcMoney=@dTotal/100*dbo.GetTcRate(@dTotal,@Fid)   
 
  RETURN(@TcMoney)
END
GO
