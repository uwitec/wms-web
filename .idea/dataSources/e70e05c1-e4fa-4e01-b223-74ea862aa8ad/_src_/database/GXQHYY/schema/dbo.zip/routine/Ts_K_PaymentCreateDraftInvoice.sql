
CREATE PROCEDURE Ts_K_PaymentCreateDraftInvoice(
	@nRet          INT OUTPUT, 
	@EId           INT,           /*审核人ID*/
	@Billid        INT            /*付款申请单Id*/
)
AS
BEGIN
	BEGIN TRAN CreatePaymentBill
begin
	/*付款申请单生成付款单草稿*/
	DECLARE @szError VARCHAR(800)
	SET @nRet = 0
	
	
	/*检查申请单状态是否处于草稿和已结算状态*/
	IF EXISTS(SELECT 1 FROM PaymentIdx a WHERE a.BillId = @Billid AND a.BillStates in (1,2) )
	BEGIN
		SET @nRet = -1
		RAISERROR('此单据已生成草稿单或已完成结算，不允许重复操作！', 16, 1)
		RETURN -1
	END	
	IF EXISTS(SELECT 1 FROM PaymentIdx a WHERE a.BillId = @Billid AND a.BillStates not in (0,1,2) )
	BEGIN
		SET @nRet = -99
		RAISERROR('单据状态错误！', 16, 1)
		RETURN -99
	END	
	
	DECLARE @States INT
		
	IF EXISTS(SELECT 1 FROM PaymentIdx a WHERE a.BillId = @Billid  AND a.BillStates = 0 )
	BEGIN
	
		UPDATE PaymentIdx SET BillStates = 1 WHERE BillId = @Billid
		
		DECLARE @szBillNumber VARCHAR(200), @szRequestNumber VARCHAR(200)
		DECLARE @YId INT, @PayBillId INT
		DECLARE @GUID UNIQUEIDENTIFIER
		
		SET @GUID = NEWID()
		SELECT @szRequestNumber = BillNumber, @YId = Y_id
		  FROM PaymentIdx WHERE BillId = @Billid
		EXEC TS_H_CreateBillSN;1 23, 1, NULL, 0, 0, @szBillNumber OUTPUT, @YId		
		
		INSERT INTO billdraftidx
		(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, 
		 quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag,
		 note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan,
		 VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate,
		 sendC_id, WholeQty, PartQty, DPdate, QualityAudit, QualityAuditDate, YGuid, financeAudit, financeAuditDate, FollowNumber, TicketDate, BalanceMode)
		SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, 23, 0, C_Id, @EId, 0, 0, 0, @EId, PayMoney, PayMoney,
		       0, 0, 0, 2, 0, 0, 0, 0, '1900-01-01', '1900-01-01', 0, 'P',
		       '付款申请单【' + @szRequestNumber + '】生成', '付款申请单【' + @szRequestNumber + '】生成', 0, 0, '1900-01-01', @GUID, 0, '', 0, 0, 0, @EId,
		       0, 0, @YId, 0, '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 
		       0, 0, 0, '1900-01-01', 0, '1900-01-01', 0x0, 0, '1900-01-01', '', '1900-01-01', -1
			FROM PaymentIdx 
		WHERE BillId = @Billid 	
		
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -2
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单主表出错！', 16, 1)
			RETURN -2
		END
		SET @PayBillId = @@identity 
		
		INSERT INTO financebilldrf
		(bill_id, a_id, c_id, jftotal, dftotal, comment1, comment2, comment3, 
		 InvoiceTotal, RowGuid, Y_Id, Conclusion, factoryid, costtaxprice, costtaxrate, costtaxtotal)
		SELECT @PayBillId, 6, C_Id, PayMoney, 0, '', '', '', 
		       0, NEWID(), @YId, '', 0, 0, 0, 0
		  FROM PaymentIdx 
		WHERE BillId = @Billid
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -3
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单明细表出错！', 16, 1)
			RETURN -3
		END
		
		INSERT INTO jspdetail
		(c_id, skd_bid, xsd_bid, billtype, quantity, jstotal, detail_id, yj_quantity,
		 flag, billguid, Y_Id, skdGuid, xsdGuid, DetailGuid, RowGuid, transflag)
		SELECT b.c_id, @PayBillId, b.billid, b.billtype,s.quantity,
		case when billtype in(24,25) then a.taxtotal else s.taxtotal end, s.smb_id, 0,
		       1, b.GUID, @YId, @GUID, b.GUID, s.RowGuid, NEWID(), 0    
			FROM PaymentBill p 
				INNER JOIN billidx b ON p.BuyBill_id = b.billid 
				INNER JOIN buymanagebill s ON s.smb_id = p.BuyDetai_ID
				LEFT JOIN (
				 SELECT distinct a.smb_id,a.quantity,isnull(a.taxprice-b.taxprice,0) AS taxprice,isnull(a.taxtotal+b.taxtotal,0) AS taxtotal FROM
                       (SELECT smb_id,orgbillid,a.quantity,taxprice,taxtotal FROM buymanagebill a 
                       LEFT JOIN billidx b ON a.bill_id = b.billid 
                       WHERE b.billtype IN (24,25) AND a.iotag = 0 and b.billstates = 0) a
                       LEFT JOIN 
                       (SELECT smb_id,orgbillid,taxprice,taxtotal FROM buymanagebill a 
                       LEFT JOIN billidx b ON a.bill_id = b.billid 
                       WHERE b.billtype IN (24,25) AND a.iotag = 1 and b.billstates = 0) b
                       ON a.orgbillid = b.orgbillid
				) a ON s.smb_id = a.smb_id
		WHERE p.Bill_Id = @Billid
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -4
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成付款单按行结算明细表出错！', 16, 1)
			RETURN -4
		END
		UPDATE PaymentIdx 
			SET PaymentBillId = @PayBillId 
		WHERE BillId = @Billid 	
	END	
end	
begin
	/*生成发票单草稿主表*/
	DECLARE   @nIVID int,
              @dInvoicedate     datetime, 
              @szInvoiceno       varchar(50),
              @dInvoicetotal    numeric(25,8),
              @nC_id	    int,
              @nY_ID		int,
              @nbillNumber  varchar(50)
              set @nC_id = 0
              set @nY_ID = 0
              
    EXEC TS_H_CreateBillSN;1 200, 1, NULL, 0, 0, @nbillNumber OUTPUT, @YId        	
    select @dInvoicedate = CONVERT(VARCHAR(100), GETDATE(), 23),@szInvoiceno = InvoiceNumber,
           @dInvoicetotal = sum(case when b.billtype = 21 then -c.taxtotal else c.taxtotal end),
           @nC_id = a.C_Id, @nY_ID = a.Y_id
    from PaymentIdx a
         left join PaymentBill p on p.Bill_Id = a.BillId
         left join billidx b on b.billid = p.BuyBill_id
         left join buymanagebill c on c.smb_id = p.BuyDetai_ID          
         where a.BillId = @Billid and b.billtype in (20,21)
         group by InvoiceNumber , a.C_Id, a.Y_id
    if @@ROWCOUNT = 0
    begin
    	 SET @nRet = -8
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('结算调价单不能按行开票，不能生成发票单！', 16, 1)
		 RETURN @nRet  
    end else
    begin        
    insert invoiceidx
           (Invoicedate,Invoiceno,Invoicetotal,Invoice,C_id,Departmentid,Inputman,
			Auditman,Invoicetype,Jsflag,InvoiceBillType,Summary,Comment,OrderID,Y_ID,billnumber)
			values(
			@dInvoicedate,@szInvoiceno,@dInvoicetotal,4,@nC_id,0,@EId,
			0,1,2,0,'付款申请单【' + @szRequestNumber + '】生成','',0,@nY_ID,@nbillNumber
			) 
		IF @@ERROR <> 0
		BEGIN
			SET @nRet = -5
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成发票单主表出错！', 16, 1)
			RETURN -5
		END 
	    set @nIVID = @@identity
	 /*生成发票单草稿明细*/
	 INSERT INTO invoice ( 
                   invoiceid, billid, smb_id, billguid, rowguid, 
                   p_id, quantity,total,YKQuantity, YKTotal, CurrQuantity, CurrTotal 
                   )select 
                   @nIVID,a.BuyBill_Id,BuyDetai_ID,b.GUID,'00000000-0000-0000-0000-000000000000',
                   a.P_id,
                   case when b.billtype = 21 then -c.quantity else c.quantity end,
                   case when b.billtype = 21 then -c.taxtotal else c.taxtotal end,0,0,
                   case when b.billtype = 21 then -c.quantity else c.quantity end,
                   case when b.billtype = 21 then -c.taxtotal else c.taxtotal end
                    from PaymentBill a
                    left join billidx b on a.BuyBill_id = b.billid
                    left join buymanagebill c on a.BuyDetai_ID = c.smb_id  
                    where a.Bill_Id = @Billid 
                    and c.smb_id not in(select i.smb_id from invoice i left join PaymentBill p on i.billid = p.BuyBill_id)
                    and b.billtype in (20,21) 
	  IF @@ROWCOUNT = 0
	  BEGIN
	     	SET @nRet = -6
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('该付款单已经开票完成，不能生成发票单！', 16, 1)
			RETURN -6  
	  END	  
	  IF @@ERROR <> 0
      BEGIN
			SET @nRet = -7
			ROLLBACK TRAN CreatePaymentBill
			RAISERROR('生成发票单明细出错！', 16, 1)
			RETURN -7
	  END	  
	end    	                 
end	
	COMMIT TRAN CreatePaymentBill
	SET @nRet = 1
END
GO
