/************************************************************
--过程名称：Ts_T_SendmangeShow
--功能：按物流单id串查询物流单明细
--创建人：XXX
--创建时间：2015-01-07 
**************************************************************/
create proc [dbo].[Ts_T_SendmangeShow]
(/* @BeginDate  [datetime], */
 /* @EndDate    [datetime],*/
  @szbillid   VARCHAR(30) = '' /*条件(物流单的id串)*/
)
as
	SELECT   ISNULL(Sm.Sendid,0) AS Sendid,g.Gspbillid AS billId, g.BillType, g.BillNumber, g.Y_id, g.C_id, g.BillDate, g.INPUTER AS inputmanname, g.AuditMan1, 
					g.AUDITER1 AS auditmanN1name, 
					/*g.AuditTime1, */
					(Case when g.AuditTime1 < '1900-01-01' then '1900-01-01' else g.AuditTime1 end) AuditTime1, 
					g.AuditMan2, g.AUDITER2 AS auditmanN2name, 
					/*g.AuditTime2, */
					(Case when g.AuditTime2 < '1900-01-01' then '1900-01-01' else g.AuditTime2 end) AuditTime2, 
					 g.TrafficTools, g.TrafficTime, g.TempControl, g.SpecTrafficProve, g.SendAddress, g.SendTime, 
					 g.TempControlMode, g.WholeQty, g.PartQty, g.DiscountTotal, g.TaxTotal, g.BillStates, 
					g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, g.Note, g.Ybillid, 
					g.Ybilltype, g.S_id, g.InputMan, g.C_NAME AS CName, billstateText AS billStatesN, g.YBillTypeName AS ywtype, 
					g.YBILLNUMBER, g.S_NAME AS sname, ISNULL(P.printcount, 0) AS printCount,g.FollowNumber,g.TicketDate,isnull(o.TrafficType,'') as TrafficType,isnull(o.TrafficCompany,'') as TrafficCompany
	FROM      dbo.VW_GSPBILLIDX AS g
				LEFT JOIN dbo.vw_c_printcountYH p ON g.Gspbillid = P.Rep_ID AND P.nflag = 2
				LEFT JOIN orderidx O ON g.Yguid = o.Guid
                left join Sendmangebill Sm on G.Gspbillid =Sm.billid 
    			/*left join SendRoad sr on g.roadid=sr.RoadID				*/
	WHERE g.BillType = 551 
		AND Sm.sendid in (select CAST(szTYPE as int) as Sendid from dbo.DecodeToStr(@szBillid))             
    order by Sm.Sendid
GO
