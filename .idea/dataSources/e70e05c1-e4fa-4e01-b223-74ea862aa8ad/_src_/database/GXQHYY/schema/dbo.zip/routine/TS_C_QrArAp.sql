



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
应收账款、应付账款
********************************************/
CREATE PROCEDURE TS_C_QrArAp
( @szParid   	VARCHAR(30)='000000',
  @szPeriod   CHAR(2)='',
  @szListFlag CHAR(1)='L',
  @BeginDate  DATETIME=0,
  @EndData    DATETIME=0,
  @EClass_id  varchar(30)='',
  @YClass_id  varchar(60)='',
  @nloginEID  int=0,
  @nFindOtherY  int=0,        /*是否查询其他分支机构 :0不查询 1 要查询*/
  @nDetachArap  int=0         /*应收应付是否分开查询 :0不查询 1 要查询 2010-04-14*/

)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParid is null  SET @szParid = '000000'
if @szPeriod is null  SET @szPeriod = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @BeginDate is null  SET @BeginDate = 0
if @EndData is null  SET @EndData = 0
if @EClass_id is null  SET @EClass_id = ''
if @YClass_id is null  SET @YClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @nFindOtherY is null  SET @nFindOtherY = 0
if @nDetachArap is null  SET @nDetachArap = 0         /*应收应付是否分开查询 :0不查询 1 要查询 2010-04-14*/
/*Params Ini end*/
SET NOCOUNT ON

DECLARE
  @SQLScript VARCHAR(7000),@SQLFilterY VARCHAR(200),
  @SQLTemp   VARCHAR(200), @SQLYClassId VARCHAR(200),
  @AR_ID     VARCHAR(30),
  @AP_ID     VARCHAR(30),
  @szTable   VARCHAR(10),
  @SONNUM    INT,
  @CTable varchar(100),		/*往来单位授权*/
  @Companytable varchar(100),		/*分支机构授权*/
  @szY_ID		varchar(100),
  @len int
  
  if @szListFlag='L'
  begin
	if @szParid='000000'  set @len=6 else set @len=LEN(@szParid)+6
  end else set @len=30
  
  SET @SQLFilterY='' SET @SQLYClassId='' /*SET @SQLFilterE='' */


  if @EClass_id='' set @EClass_id='%%' else set @EClass_id=@EClass_id+'%'  /*增加经手人查询*/

  IF @YClass_id not in ('','000000','%%')    /*增加分支机构查询 */
  BEGIN
     /*SET @SQLYClassId = ' and YClass_ID like '''+@YClass_id+'%'''*/
     SELECT @szY_ID =cast(company_id as varchar(100)) from company where Class_id=@YClass_id
     SET @SQLYClassId = ' and (Y_id='+@szY_ID+' or (superior_id='+@szY_ID+' and yType=1) )'
  END
  ELSE SET @SQLYClassId = ' ' 

/*---------增加授权控制---------------------*/
  create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      SET @SQLFilterY = ' and (Y_id in (select [id] from #Companytable))'
   end
/*---分支机构授权*/
/*---------增加授权控制  完成---------------------*/

  IF NOT (EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c') 
     OR EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c' and u.psc_id='000000') )
    SET @szTable='Clients'
  ELSE BEGIN
    SELECT * INTO ##Client FROM
    (SELECT  [client_id], [class_id], [parent_id], [child_number], [child_count], [serial_number], [name], [alias], 
             [region_id], [phone_number], [address], [zipcode], [contact_personal], [tax_number], [acount_number],
             [credit_total], [pinyin], [pricemode], [sklimit], [artotal], [artotal_ini], [aptotal], [aptotal_ini],
             [pre_artotal], [pre_artotal_ini], [pre_aptotal], [pre_aptotal_ini], [firstcheck], [comment], [csflag], 
             [deleted], [ProtocolDate], [GMPNo], [GSPNo], [Cetype], [ModifyDate], [RowIndex], [IncRate], [licence_no], 
             [ent_type], [city_id], [city_name], [boro_id], [boro_name],U.* FROM Clients C
		INNER JOIN Userauthorize U ON C.[Class_ID] LIKE (U.[Psc_ID]+'%')
		WHERE U.[Type]='c' AND U.[E_ID]=@nloginEID) C
    SET @szTable='##Client'
  END

  SELECT @AR_ID='000001000005', @AP_ID='000002000001'
  SELECT @SONNUM=[Child_Number] FROM Clients WHERE [Class_ID]=@szParid

  IF @SONNUM>0
  BEGIN
    IF @szListFlag='L'  SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Parent_ID]='+CHAR(39)+@szParID+CHAR(39)
    IF @szListFlag='A' 	SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Child_number]=0'
    IF @szListFlag='P' 	SELECT @SQLTemp='a.[Deleted]<>1 AND a.[Child_number]=0 AND LEFT(a.[Class_ID], LEN('+CHAR(39)+@szParID+CHAR(39)+'))='+CHAR(39)+@szParID+CHAR(39)  
  END
  ELSE
  BEGIN
    SELECT @SQLTemp='a.[Class_ID]='+CHAR(39)+@szParID+CHAR(39)
  END

  IF @szPeriod=''
  BEGIN

    SET @SQLScript = 'SELECT YD.*,isnull(E.Class_id,'''')EClass_id,isnull(Y.Class_id,'''')YClass_id,
              isnull(A.Class_id,'''')AClass_id,isnull(C.Class_id,'''')CClass_id,Y.superior_id,Y.YType
  FROM
   (SELECT ad.c_id,b.e_id, ad.a_id,ad.Y_id,b.billdate,sum(ad.[JdMoney]) jdmoney
    FROM AccountDetail ad 
         LEFT JOIN billidx B ON B.billid=ad.billid
    where billtype not in (150,151,155,160,161,165) and B.billstates=0
    group by ad.c_id,b.e_id, ad.a_id,ad.Y_id,b.billdate
   )YD
   LEFT JOIN employees E ON YD.e_id=E.emp_id
   LEFT JOIN Company   Y ON YD.Y_id=Y.company_id
   LEFT JOIN Clients   C ON YD.C_ID=C.client_id
   LEFT JOIN Account   A ON YD.a_id=A.account_id
  )AD
  WHERE [AClass_ID] IN ('''+@AR_ID+''', '''+@AP_ID+''')
    and AD.eclass_id like '''+@EClass_id+''''


    SELECT @SQLScript='(SELECT CClass_id as [Class_ID], Y_id,
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate]<'''
        +CONVERT(VARCHAR(10),@BeginDate,20)+''' THEN [JdMoney] END), 0) AS [BeginArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate]<'''
        ++CONVERT(VARCHAR(10),@BeginDate,20)+''' THEN [JdMoney] END), 0) AS [BeginApTotal],

      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [NowArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate] BETWEEN '''+CONVERT(VARCHAR(10),@BeginDate,20)
        +''' AND '''+CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [NowApTotal], 

      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AR_ID+''' AND [BillDate]<='''
        +CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [EndArTotal], 
      ISNULL(SUM(CASE WHEN [AClass_ID]='''+@AP_ID+''' AND [BillDate]<='''
        ++CONVERT(VARCHAR(10),@EndData,20)+''' THEN [JdMoney] END), 0) AS [EndApTotal]

      FROM (' + @SQLScript +  @SQLFilterY +  @SQLYClassId + 
      ' GROUP BY [CClass_ID], Y_id)'
  END
  ELSE 
    SELECT @SQLScript='(SELECT C.[Class_ID], y.Class_id as [YClass_ID],
      (0) AS [BeginArTotal], (0) AS [BeginApTotal],
      sum(CB.[ArTotal_Ini]) AS [NowArTotal], sum(CB.[ApTotal_Ini]) AS [NowApTotal],
      (0) AS [EndArTotal], (0) AS [EndApTotal] FROM ClientsBalance CB 
      left join clients c on cb.[C_ID]=c.[CLIENT_ID]
      left join company Y ON Y.[Company_id]=CB.[Y_ID] '
      /*+ (case when @YClass_id not in ('','000000','%%') then ' Where Y.Class_ID like '''+@YClass_id+'%''' else ''end )*/
      + (case when @YClass_id not in ('','000000','%%') then ' Where (Y.company_id= '+@szY_ID+' or y.superior_id='+@szY_ID+' and yType=1) )' else ''end )
      + ' group by c.[Class_ID],y.Class_id ) '

  if @nDetachArap=0
  begin  
	  SELECT @SQLScript='SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],
	    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
	    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal]
	    FROM '+@szTable+' a 
	    LEFT JOIN (
	    SELECT a.[Class_ID],
	    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])>0 THEN SUM(a.[Artotal]-a.[Aptotal]) ELSE 0 END, 0) AS [Artotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal]-a.[Aptotal])<0 THEN -(SUM(a.[Artotal]-a.[Aptotal])) ELSE 0 END, 0) AS [Aptotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[BeginArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[BeginApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
	    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])>0 THEN SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowArTotal], 
	    ISNULL(CASE WHEN SUM(b.[NowArTotal]-b.[NowApTotal])<0 THEN -SUM(b.[NowArTotal]-b.[NowApTotal]) ELSE 0 END, 0) AS [NowApTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))>0 THEN SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
	    ISNULL(CASE WHEN SUM(a.[Artotal_Ini]+ISNULL(b.[EndArTotal], 0)-a.[Aptotal_Ini]-ISNULL(b.[EndApTotal], 0))<0 THEN -SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)-a.[aptotal_ini]-ISNULL(b.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal]
	    FROM (select * from ( select c.class_id,y.class_id as YClass_id,
				  c.Child_Number,c.Deleted,cb.* ,Y.superior_id,Y.YType
			          FROM ClientsBalance cb 
				  left join clients c on cb.c_id = c.client_id
				  left join company y on y.company_id = cb.y_id 
				) aa
	          WHERE [Child_Number]=0 AND [Deleted]<>1 ' + @SQLFilterY + @SQLYClassId +
	    ' ) a LEFT JOIN'
	    +@SQLScript+' b
	    ON a.[Class_ID]=b.[Class_ID] and b.Y_id=a.Y_id '+ (case when (@nFindOtherY<>0) then ' and a.YClass_id=b.YClass_id ' else ''end) 
	    +' GROUP BY a.[Class_ID]) b
	    ON LEFT(b.[Class_ID], LEN(a.[Class_ID]))=a.[Class_ID]
	    WHERE '+@SQLTemp+' 
	    GROUP BY a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name], a.[Alias], 
	    a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal] 
	    order by a.client_id'
  end
  else 
	  SELECT @SQLScript='SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],
	    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
	    ISNULL(SUM(b.[Artotal]), 0) AS [Artotal], 
	    ISNULL(SUM(b.[Aptotal]), 0) AS [Aptotal],
	    ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
	    ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0)-ISNULL(SUM(b.[BeginArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0)-ISNULL(SUM(b.[BeginApTotal]), 0) AS [NowApTotal],
	    ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
	    ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal]
	    FROM '+@szTable+' a 
	    LEFT JOIN (
	    SELECT a.[Class_ID],
	    ISNULL(sum(a.[Artotal]), 0) AS [Artotal], 
	    ISNULL(sum(a.[Aptotal]), 0) AS [Aptotal], 
	    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[BeginArTotal], 0)), 0) AS [BeginArTotal], 
	    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[BeginApTotal], 0)), 0) AS [BeginApTotal], 
	    ISNULL(SUM(b.[NowArTotal]), 0) AS [NowArTotal], 
	    ISNULL(SUM(b.[NowApTotal]), 0) AS [NowApTotal], 
	    ISNULL(SUM(a.[artotal_ini]+ISNULL(b.[EndArTotal], 0)), 0) AS [EndArTotal], 
	    ISNULL(SUM(a.[aptotal_ini]+ISNULL(b.[EndApTotal], 0)), 0) AS [EndApTotal]
	    FROM (select * from ( select c.class_id,y.class_id as YClass_id,
				  c.Child_Number,c.Deleted,cb.* ,y.superior_id,Y.YType
			          FROM ClientsBalance cb 
				  left join clients c on cb.c_id = c.client_id
				  left join employees e on cb.e_id=e.emp_id  
				  left join company y on y.company_id = cb.y_id 
				) aa
	          WHERE [Child_Number]=0 AND [Deleted]<>1 ' + /*@SQLFilterY + @SQLYClassId +*/
	    ' ) a LEFT JOIN'
	    +@SQLScript+' b
	    ON a.[Class_ID]=b.[Class_ID] and b.Y_id=a.Y_id '+ /*(case when (@nFindOtherY<>0) then ' and a.YClass_id=b.YClass_id ' else ''end) */
	    +' GROUP BY a.[Class_ID]) b
	    ON LEFT(b.[Class_ID], LEN(a.[Class_ID]))=a.[Class_ID]
	    WHERE '+@SQLTemp+' 
	    GROUP BY a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name], a.[Alias], 
	    a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal] 
	    order by a.client_id'

/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO SUCCEE


SUCCEE:
  IF EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c') 
	   OR EXISTS(SELECT * FROM userauthorize u WHERE u.e_id=@nloginEID and u.type='c' and u.psc_id='000000')
     DROP TABLE [dbo].[##Client]

  RETURN 0
GO
