
/*******************************************
客户业绩分析
*********************************************/
CREATE PROCEDURE TS_C_QrClientAnalyse
(	@BeginDate 	  DATETIME,/*开始时间*/
	@EndDate	 	  DATETIME,/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szParent_ID	VARCHAR(30)='',/*产品父类ID*/
	@szListFlag		VARCHAR(1)='L',/*分级显示*/
    @nloginEID               int=0,   
    @nFindSaleTotal  int =0,/*查询销售额*/
    @dBeginSaleTotal numeric(25,8) =0,
    @dEndSaleTotal numeric(25,8) =0,
    @nFindMlrate  int =0,/*查询毛利率*/
    @dBeginMlrate numeric(25,8) =0,
    @dEndMlrate numeric(25,8) =0
)
AS
/*Params Ini begin*/
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szParent_ID is null  SET @szParent_ID = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @nloginEID is null  SET @nloginEID = 0
if @nFindSaleTotal is null  SET @nFindSaleTotal = 0
if @dBeginSaleTotal is null  SET @dBeginSaleTotal = 0
if @dEndSaleTotal is null  SET @dEndSaleTotal = 0
if @nFindMlrate is null  SET @nFindMlrate = 0
if @dBeginMlrate is null  SET @dBeginMlrate = 0
if @dEndMlrate is null  SET @dEndMlrate = 0
/*Params Ini end*/
  /*SET NOCOUNT ON */
  DECLARE @SQLScript VARCHAR(8000), @SQLChildTemp VARCHAR(200)
  Declare @ClientTable INTEGER
  create table #Clienttable([id] int) 
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

declare @dMlTotal			numeric(25,8)

 if @szCClass_ID='' set @szCClass_ID='%%'

 SELECT @dMlTotal=ISNULL(SUM(P.[Total]),0) 
    FROM
      (SELECT b.c_id,b.Inputman,sm.p_id,sm.RowE_id,sm.ss_id,B.Y_id,
             (case when B.billtype IN (10,12,32,112,53,16,210) then sm.totalmoney else -sm.totalmoney end)total
           /*  (case when billtype IN (10,12,32,112,53,16,210) then sm.costtotal  else -sm.costtotal end)Costtotal*/
         FROM       
            (SELECT bill_id,p_id,totalmoney,RowE_id,ss_id       /*,(costprice*quantity)as costtotal*/
               FROM salemanagebill  where p_id>0 and aoid in (0,5)
            )sm
         LEFT JOIN Billidx   B  ON SM.bill_id=B.billid
         LEFT JOIN Clients   C  ON B.c_id=C.Client_id
         Where  B.[BillDate] BETWEEN @BeginDate AND @EndDate and
                B.[Billtype] IN (10,11,12,13,112,16,17,32,53,54,212) AND
                B.[Billstates]='0' and 
                C.[Class_ID] LIKE @szCClass_ID /*and */

)P   
	
/*客户销售排行*/

   SELECT P.[Class_ID] as PClass_id,
		  ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],  ISNULL(SUM(SM.[TaxTotal]), 0) AS [TaxTotal],
		  ISNULL(SUM(SM.[SaleTotal]), 0) AS [SaleTotal],ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],
		  ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
		  ISNULL(cast(SUM(SM.[SendTotal]) as numeric(25,8)),0) AS [SendTotal],
		  ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],

		  /*abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,*/
		  ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[SaleTotal]), 0) as setotal,
		  ISNULL(SUM(SM.[SendTotal]) ,0)-ISNULL(SUM(SM.[SendCostTotal]),0) as MlTotal,
	    
	   	  (case when @dMlTotal<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/@dMlTotal else 0 end) as ratio,
		  (case when ISNULL(SUM(SM.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SM.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SM.[SendCostTotal]),0))*100/ISNULL(SUM(SM.[SendTotal]),0) else 0 end) as Mlrate

     INTO #TempCSalePH
     FROM  
       (select * from Clients where  deleted<>1
        AND ((@ClientTable=0) or (Client_id in (select [id] from #Clienttable)))
       )P
     LEFT JOIN
       (SELECT YPD.[C_ID],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[Quantity] else -YPD.[Quantity] end),0) AS [Quantity],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[TaxTotal] else -YPD.[TaxTotal] end),0) AS [TaxTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210) THEN YPD.[Totalmoney] else -YPD.[Totalmoney] end), 0) AS [SaleTotal],
	  		   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[SendQTY]  ELSE -YPD.[SendQTY] end), 0) AS [SendQTY],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[SendCostTotal] else -YPD.[SendCostTotal] end),0) AS [SendCostTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] else -YPD.[totalmoney]/YPD.[quantity]*YPD.[SendQTY] end),0) AS [SendTotal],
			   ISNULL(SUM(case when YPD.Billtype IN (10,12,32,112,53,16,210)  THEN YPD.[quantity]*YPD.[costprice]  else -YPD.[quantity]*YPD.[costprice] end), 0) AS [CostTotal]
          FROM 
            (SELECT b.c_id,sm.quantity,costprice,sm.totalmoney,sm.taxtotal,
                    sm.SendQTY,sm.SendCostTotal,B.billtype
               FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数                 */
               LEFT JOIN billidx   b  ON b.billid=sm.bill_id
               LEFT JOIN Clients   C  on b.c_id=c.client_id             
              WHERE ([Billdate] BETWEEN   @BeginDate AND  @EndDate) and
                    [Billtype] IN (10,11,12,13,112,16,17,32,53,54,210,211) and [Billstates]='0'
                    AND aoid in (0,5) and p_id>0 and
                    ((@szCClass_ID IN ('', '%%', '000000')) or (c.class_id LIKE @szCClass_ID))  AND
                    ((@ClientTable=0) or (B.c_id in (select [id] from #Clienttable)))          
            )YPD
        GROUP BY YPD.[C_ID]
       ) SM ON P.[Client_ID]=sm.[C_ID]
    where ((@nFindSaleTotal=0) or (SM.SaleTotal between @dBeginSaleTotal and @dEndSaleTotal))
    GROUP BY P.[Class_ID]
        
 IF @szListFlag='L'
  BEGIN
	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
			 ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],  ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal],
			 ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],
			 ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			  ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			  ISNULL(SUM(SH.ratio),0) as ratio,
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From clients P
		Left join #TempCSalePH SH on LEFT(SH.[PClass_ID],LEN(p.[Class_ID]))=p.[Class_ID]
		where  p.parent_id=@szParent_id and p.deleted<>1
		      and ((@nFindMlrate=0) or (SH.Mlrate between @dBeginMlrate and @dEndMlrate))
		      and ((@nFindSaleTotal=0) or (SH.SaleTotal between @dBeginSaleTotal and @dEndSaleTotal))
                      and p.class_id like @szCClass_ID /*zh100928*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
                  P.[Name], P.[Contact_personal], P.[Address],
                  p.[Parent_ID],P.C_Customname1,p.C_Customname2,
                  p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_id
  END
  
  IF @szListFlag='P'
  BEGIN
	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
	         ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 ISNULL(SUM(SH.ratio),0) as ratio,
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From Clients P
		Left join #TempCSalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where  LEFT(p.[Class_ID], LEN(@szParent_id))=@szParent_id and p.deleted<>1 and p.[Child_Number]=0
		      and ((@nFindMlrate=0) or (SH.Mlrate between @dBeginMlrate and @dEndMlrate))
		      and ((@nFindSaleTotal=0) or (SH.SaleTotal between @dBeginSaleTotal and @dEndSaleTotal))
                      and p.class_id like @szCClass_ID /*zh100928*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_ID    
  END
  
  IF @szListFlag='A'
  BEGIN
	  Select P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],
             p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted],
             ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[SaleTotal]), 0) AS [SaleTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0) AS [SendTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal,
			 ISNULL(SUM(SH.MlTotal),0) as MlTotal,
			 ISNULL(SUM(SH.ratio),0) as ratio,
              (case when ISNULL(SUM(Sh.[SendTotal]),0)<>0 then (ISNULL(cast(SUM(SH.[SendTotal]) as numeric(25,8)),0)-ISNULL(SUM(SH.[SendCostTotal]),0))*100/abs(ISNULL(SUM(SH.[SendTotal]),0)) else 0 end) as Mlrate
		From clients P
		Left join #TempCSalePH SH on SH.[PClass_ID]=p.[Class_ID]
		where p.[DELETEd]<>1 and p.[Child_Number]=0 and p.[Client_ID]<>1
		      and ((@nFindMlrate=0) or (Mlrate between @dBeginMlrate and @dEndMlrate))
		      and ((@nFindSaleTotal=0) or (SH.SaleTotal between @dBeginSaleTotal and @dEndSaleTotal))
                      and p.class_id like @szCClass_ID /*zh100928*/
		Group by  P.[Class_ID],P.[Client_ID],  P.[Child_Number], P.[Serial_Number], 
             P.[Name], P.[Contact_personal], P.[Address],p.[Parent_ID],P.C_Customname1,p.C_Customname2,
             p.C_Customname3,P.C_Customname4,P.C_Customname5,p.[Deleted]
		Order by p.Client_ID  
  END
GO
