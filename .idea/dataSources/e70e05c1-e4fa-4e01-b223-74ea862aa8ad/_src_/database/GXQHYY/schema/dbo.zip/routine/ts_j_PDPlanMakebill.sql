/************************************************************

--功能：不管批次直接盘点时，由盘点划生成草稿单据
--创建人：Zhou JiLin 
--创建时间：2010-11-03  
--最后修改:2011-04-15
--修改说明：带批次盘点存在错误

参数说明：   
    @nPdidx: 盘点计划ID, 
    @nMode: 0 未盘点商品生成报损单
			1 已盘点商品生成报溢单
			2 已盘点商品生成报损单
			3 全部的单据,含上面三种单据




--新增功能: 按批次生成报损 报溢单   else 以后的代码 WSJING

**************************************************************/

CREATE	 PROCEDURE [ts_j_PDPlanMakebill]
  (
    @nPdidx int,
    @nMode int = 0,
    @nEID int
  )
AS 
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
/*Params Ini end*/


declare @billid int, @s_id int, @y_id int, @NoBatch int

select @s_id = k_id, @Y_Id = Y_Id, @NoBatch = NoBatch from pdplanidx where pdidx = @nPdidx

if @NoBatch = 1 
begin 
	begin tran makePDbill
	   if @nMode in (0, 3)
	   begin
		  set @billid = 0      
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,41,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-未盘点商品盘亏') 
		  set @billid = @@IDENTITY
		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id)
			 select @billid, p_id,'',quantity, s_id, y_id 
			   from PdPlan pd
			   where pdidx = @nPdidx and pyQuantity=0 and pkQuantity=0 and pdflag=0 and quantity<>0
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                    delete billdraftidx where billid = @billid  
	   end
	   if @nMode in (2, 3)
	   begin
		  set @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,41,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘亏') 
		  set @billid = @@IDENTITY
		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id)
			 select @billid, p_id,'',pkquantity, s_id, y_id 
			   from PdPlan   
			   where pdidx = @nPdidx and pyQuantity=0 and pkQuantity>0 and pdflag=1
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end                
	   
	   if @nMode in (1, 3)
	   begin
		  set @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,42,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘盈(盘点前库存为0)') 
		  set @billid = @@IDENTITY
		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id)
			 select @billid, p_id,'',pyquantity, s_id, y_id 
			   from PdPlan
			   where pdidx = @nPdidx and pyQuantity>0 and pkQuantity=0 and pdflag=1 and quantity =0
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end
	   
	   if @nMode in (1, 3)
	   begin
		  set @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,42,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘盈(盘点前库存不为0)') 
		  set @billid = @@IDENTITY
		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id)
			 select @billid, p_id,'',pyquantity, s_id, y_id 
			   from PdPlan
			   where pdidx = @nPdidx and pyQuantity>0 and pkQuantity=0 and pdflag=1 and quantity <>0
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end
	                     
	commit tran makePDbill
end
else begin

	begin tran makePDbill
	   if @nMode in (0, 3)
	   begin
		  set @billid = 0      
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,41,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-未盘点商品盘亏') 
		  Select @billid = @@IDENTITY


/*select * from storemanagebilldrf*/
/*select * from pdplan*/

		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, price, totalmoney, costtotal, total)
			 select @billid, p_id,batchno,quantity, s_id, y_id,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, costprice, quantity*costprice, quantity*costprice, quantity*costprice
			   from PdPlan  
			   where pdidx = @nPdidx 
			     and pyQuantity=0 
			     and pkQuantity=0 
			     and pdflag=0 
			     and quantity<>0 
			     group by p_id,batchno,quantity,y_id,
			      makedate, validdate, batchno, commissionflag, s_id, supplier_id, location_id, costprice
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid   		
			     
	   end
	   if @nMode in (2, 3)
	   begin
		  Select @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,41,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘亏') 
		  Select @billid = @@IDENTITY

		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, price, totalmoney, costtotal, total)
			 select @billid, p_id,batchno,pkquantity, s_id, y_id  ,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, costprice, pkquantity*costprice, pkquantity*costprice, pkquantity*costprice
			   from PdPlan   
			   where pdidx = @nPdidx and pyQuantity=0 and pkQuantity>0 and pdflag=1
			   group by  p_id,batchno,quantity, s_id,y_id, makedate, pkquantity,
					validdate, batchno, commissionflag, supplier_id, location_id, costprice
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end                
	   
	   if @nMode in (1, 3)
	   begin
		  Select @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,42,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘盈(盘点前库存为0)') 
		  Select @billid = @@IDENTITY

		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, price, totalmoney, costtotal, total)
			 select @billid, p_id,batchno,pyquantity, s_id, y_id  ,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, costprice, pyquantity*costprice, pyquantity*costprice, pyquantity*costprice

			   from PdPlan
			   where pdidx = @nPdidx and pyQuantity>0 and pkQuantity=0 and pdflag=1 and quantity =0
			   group by  p_id,batchno,quantity, s_id,y_id, makedate, pyquantity,
					validdate, batchno, commissionflag, supplier_id, location_id, costprice
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end
	   
	   if @nMode in (1, 3)
	   begin
		  Select @billid = 0  
		  insert into billdraftidx(billdate,billtype,c_id,e_id,sout_id,sin_id,inputman,ysmoney,billstates,y_id,note)
			 values(cast(CAST(GETDATE() as varchar(10)) as datetime) ,42,0,@nEID,@s_id,@s_id,@nEID,0,2,@y_id,'由盘点系统生成-已盘点商品盘盈(盘点前库存不为0)') 
		  Select @billid = @@IDENTITY
		  insert into storemanagebilldrf(bill_id,p_id,batchno,quantity,ss_id,y_id,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, price, totalmoney, costtotal, total)
			 select @billid, p_id,batchno,pyquantity, s_id, y_id  ,
				costprice, makedate, validdate, commissionflag, supplier_id, location_id, costprice, pyquantity*costprice, pyquantity*costprice, pyquantity*costprice
			   from PdPlan
			   where pdidx = @nPdidx and pyQuantity>0 and pkQuantity=0 and pdflag=1 and quantity <>0
			   group by  p_id,batchno,quantity, s_id,y_id,  makedate, pyquantity,
					validdate, batchno, commissionflag, supplier_id, location_id, costprice
                  if not exists(select 1 from storemanagebilldrf where bill_id = @billid)
                     delete billdraftidx where billid = @billid  
	   end
	                     
	commit tran makePDbill

end
GO
