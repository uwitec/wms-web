


CREATE	TRIGGER IntergralChange ON [dbo].[membercard]
FOR  UPDATE
AS
if update(Integral)
begin
   declare @dBaseTotal numeric(18,4), @t varchar(18)

  	exec ts_GetSysValue 'VIPIntegral', @T out
  	if @T='' set @dBaseTotal=0 else set @dBaseTotal= @T

    if @dBaseTotal<>0
  	begin
		  update membercard set intergraltotal=b.integral*@dBaseTotal
      from membercard a,(	select cardid,sum(integral) integral from inserted group by cardid) b
      where a.cardid=b.cardid
  	end
end
GO
