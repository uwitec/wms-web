create procedure ts_e_SelectPriceTag
(
    @szPriceTag varchar(8000)/*商品ID字符串*/
)
as
begin
  select a.product_id AS pid,isnull(alias,'') as pname,isnull(standard,'') as standard,isnull(factory,'') as factory,
          isnull(makearea,'') as makearea,isnull(b.name ,'')  as uname,isnull(a.serial_number,'') as  serial_number,
          isnull(c.retailprice,0) as retailprice,isnull(c.price4,0) as vipprice,isnull(c.gpprice,0) as gpprice,isnull(c.glprice,0) as glprice,isnull(c.specialprice,0) as specialprice,
          isnull(c.price1,0) as price1,isnull(c.price2,0) as price2,isnull(c.price3,0) as price3,isnull(recprice,0) as recprice,
          isnull(lowprice,0) as lowprice,isnull(barcode,'') as  barcode
          from products a
               left join unit b on a.unit1_id=b.unit_id
               left join price c on a.product_id=c.p_id and a.unit1_id=c.u_id
               left join 
               (
                 select * from barcode where codetype=1
                ) d on a.product_id=d.p_id and a.unit1_id=d.unitid
               where product_id in  (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szPriceTag))
end
GO
