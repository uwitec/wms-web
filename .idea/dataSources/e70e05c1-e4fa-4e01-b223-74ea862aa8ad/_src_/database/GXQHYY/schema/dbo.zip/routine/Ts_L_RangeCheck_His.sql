

CREATE	PROCEDURE [Ts_L_RangeCheck_His]
	(@C_id 	[int],
	 @r_id	[int],
	 @CType [int])

AS
set @C_id = ABS(@C_id)
begin
	SELECT TOP 0 * 
	INTO #T
	FROM [customCategoryMapping]

	INSERT INTO #T 
		 ( category_id,baseinfo_id,deleted,BaseTypeid
		  ) 
	 
	VALUES 
		( @r_id,@C_id,0,@CType)

	INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
	SELECT @C_id, 'CCMC', (SELECT * FROM #T AS [customCategoryMapping] FOR XML AUTO, TYPE, ROOT), 1
	DROP TABLE #T
end
GO
