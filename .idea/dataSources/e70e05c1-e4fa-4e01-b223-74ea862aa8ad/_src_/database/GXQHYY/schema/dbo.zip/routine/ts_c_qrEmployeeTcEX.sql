


/*
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
*/

CREATE PROC ts_c_qrEmployeeTcEX(
                                   @Parent_id VARCHAR(36),
                                   /*  @szWhere        varchar(500),*/
                                   @begindate VARCHAR(50),
                                   @enddate VARCHAR(50),
                                   @Employee VARCHAR(100) = '',
                                   @nloginEID INT = 0,
                                   @YClass_id VARCHAR(100) = ''
                               )
/*with encryption*/
AS
/*Params Ini begin*/
if @Employee is null  SET @Employee = ''
if @nloginEID is null  SET @nloginEID = 0
if @YClass_id is null  SET @YClass_id = ''
/*Params Ini end*/
SET NOCOUNT ON

DECLARE @LenClass        INT

DECLARE @Companytable    INTEGER,
        @employeestable  integer     

CREATE TABLE #Companytable
(
	[id] INT
)
CREATE TABLE #employeestable
(
	[id] INT
)
/*---分支机构授权*/
IF NOT EXISTS(
       SELECT *
       FROM   userauthorize u
       WHERE  u.e_id = @nloginEID
              AND u.Type = 'Y'
   )
   OR EXISTS(
          SELECT *
          FROM   userauthorize u
          WHERE  u.e_id = @nloginEID
                 AND u.Type = 'Y'
                 AND u.psc_id = '000000'
      )
BEGIN
    SET @Companytable = 0
END
ELSE
BEGIN
    SET @Companytable = 1
    INSERT #Companytable
      (
        [id]
      )
    SELECT Company_id
    FROM   Company C
    WHERE  EXISTS(
               SELECT u.psc_id
               FROM   userauthorize u
               WHERE  u.e_id = @nloginEID
                      AND u.Type = 'Y'
                      AND C.class_id LIKE u.psc_id + '%'
           )
END
/*---分支机构授权*/
/*---职员授权*/
IF NOT EXISTS(
       SELECT *
       FROM   userauthorize u
       WHERE  u.e_id = @nloginEID
              AND u.Type = 'E'
   )
   OR EXISTS(
          SELECT *
          FROM   userauthorize u
          WHERE  u.e_id = @nloginEID
                 AND u.Type = 'E'
                 AND u.psc_id = '000000'
      )
BEGIN
    SET @employeestable = 0
END
ELSE
BEGIN
    SET @employeestable = 1
    INSERT #employeestable
      (
        [id]
      )
    SELECT emp_id
    FROM   employees C
    WHERE  EXISTS(
               SELECT u.psc_id
               FROM   userauthorize u
               WHERE  u.e_id = @nloginEID
                      AND u.Type = 'E'
                      AND C.class_id LIKE u.psc_id + '%'
           )
END   

/*---职员授权*/

IF @Parent_id = '000000'
    SET @LenClass = 6
ELSE
    SET @LenClass = LEN(@Parent_id) + 6

SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id,
       ve.parent_id, ve.child_Number, ve.Child_Count, '制单人单据明细数量' AS mType, ISNULL(bi.mTotal, 0) AS mTotal,
       ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> '' AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
                  AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 7
       )VE
       LEFT JOIN (
                SELECT a.inputman AS e_id, COUNT(*) AS mTotal
                FROM   (   SELECT b.inputman FROM billidx b, buymanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND b.order_id = 0 AND
                                 b.billdate BETWEEN @BeginDate AND @EndDate AND
                                 b.Billtype IN (10, 11, 12, 13, 122, 210, 211, 20, 21, 220, 221)
                           UNION ALL
                           SELECT b.inputman FROM billidx b, salemanagebill bi 
                           WHERE b.billid = bi.bill_id AND b.billstates = 0 AND b.order_id = 0 AND
                                 b.billdate BETWEEN @BeginDate AND @EndDate AND
                                 b.Billtype IN (10, 11, 12, 13, 122, 210, 211, 20, 21, 220, 221)       
                       )a
                GROUP BY inputman
            ) AS bi
            ON  bi.e_id = ve.emp_id
UNION ALL
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id,
       ve.parent_id, ve.child_Number, ve.Child_Count, '制单人单据数量' AS mType, ISNULL(bi.mTotal, 0) AS mTotal,
       ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> '' AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
                  AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 6
       )VE
       LEFT JOIN (
                SELECT a.inputman AS e_id, COUNT(*) AS mTotal
                FROM   (   SELECT inputman
                           FROM   BillIdx
                           WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0 AND order_id =0 
                                  AND [Billtype] IN (10, 11, 12, 13, 122, 210, 211, 20, 21, 220, 221)
                       )a
                GROUP BY inputman
            ) AS bi
            ON  bi.e_id = ve.emp_id
UNION ALL
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id,
       ve.parent_id, ve.child_Number, ve.Child_Count, '职员销售总金额' AS mType, ISNULL(bi.mTotal, 0) AS mTotal,
       ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> '' AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
                  AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 0
       )VE
       LEFT JOIN (
                SELECT a.e_id, SUM(CASE WHEN (BillType IN (11, 13, 17, 54, 211)) THEN -a.YsMoney ELSE a.YsMoney END) AS mTotal
                FROM   (   SELECT e_id, billtype, ysmoney
                           FROM   BillIdx
                           WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0 
                                  AND [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)
                       )a
                GROUP BY e_id
            ) AS bi
            ON  bi.e_id = ve.emp_id 
UNION ALL
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id, ve.parent_id, ve.child_Number,
       ve.Child_Count, '' AS mType,
       (CASE WHEN  TcType = 2 THEN bi.SLTotal when TcType = 3 THEN bi.JETotal when TcType = 4 THEN bi.MLTotal ELSE 0 END) AS mTotal,            
       ISNULL(dbo.GetTcRateParent(ve.class_id, @begindate, @enddate, @Employee, @nloginEID, @YClass_id), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND VE.Deleted = 0 AND ve.Child_Number > 0  
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) 
                       OR (@Employee <> '' AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
       )VE
       LEFT JOIN (
                SELECT LEFT(class_id, @LenClass) AS ss,
                       SUM(CASE WHEN (BillType IN (11, 13, 17, 54, 211)) THEN -YsMoney ELSE YsMoney END) AS JETotal,
                       sum(case when (BillType in (11, 13, 17, 54, 211)) then -a.quantity else a.quantity end) as SlTotal,
                       SUM(CASE WHEN (BillType IN (11, 13, 17, 54, 211)) THEN -(a.TaxTotal -(a.costPrice * a.Quantity)) ELSE (a.TaxTotal -(a.costPrice * a.Quantity)) END) AS MLTotal
                FROM   (   SELECT e_id, p_id, billtype, ysmoney,s.quantity,s.taxtotal,s.costprice
                           FROM   BillIdx b left join salemanagebill s on s.bill_id = b.billid 
                           WHERE  [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)
                                  AND BillDate BETWEEN @begindate AND @enddate AND BillStates = 0
                       )a,
                       employees
                WHERE  emp_id = a.e_id AND employees.Tp_ID > 0
                GROUP BY LEFT(class_id, @LenClass)
            ) AS bi
            ON  bi.ss = ve.class_id  
UNION ALL 
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id, ve.parent_id,
       ve.child_Number, ve.Child_Count, '商品销售固定提成金额' AS mType, ISNULL(bi.mTotal, 0) AS mTotal,
       ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> ''
                                 AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
                  AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 5
       )VE
       LEFT JOIN (
                SELECT a.e_id, SUM(CASE WHEN (BillType IN (11, 13, 17, 54, 211)) THEN -a.YsMoney ELSE a.YsMoney END) AS mTotal
                FROM   (   SELECT e_id, billtype, ysmoney
                           FROM   BillIdx
                           WHERE  BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0
                                  AND [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211)
                       )a
                GROUP BY e_id
            ) AS bi
            ON  bi.e_id = ve.emp_id  
UNION ALL 
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id, ve.parent_id,
       ve.child_Number, ve.Child_Count, '职员回款总金额' AS mType, ISNULL(bi.mTotal, 0) AS mTotal,
       ISNULL(dbo.GetTcRate(ISNULL(bi.mTotal, 0), VE.F_ID), 0) AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND VE.Deleted = 0 AND ve.Child_Number = 0 AND TcType = 1
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) 
                       OR (@Employee <> '' AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
       )VE
       LEFT JOIN (
                /*
                SELECT b.e_id, ISNULL(SUM(a.jdmoney), 0) AS mTotal
                FROM   accountdetail a
                       INNER JOIN billidx b ON  a.billid = b.billid
                WHERE  a.jdmoney > 0
                       AND a.a_id IN (SELECT account_id FROM account WHERE parent_id LIKE '000001000004%' OR account_id = 6)
                       AND b.BillDate BETWEEN @BeginDate AND @EndDate AND b.billstates = 0
                GROUP BY b.e_id
                */
                SELECT a.e_id, SUM(a.jstotal) AS mTotal 
				FROM ( 
					SELECT bb.e_id, 
					       CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 ELSE j.jstotal END) 
					       ELSE j.jstotal END AS jstotal 
					FROM jsbdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND 
					      b.billtype = 10 AND bb.BillDate BETWEEN @BeginDate AND @EndDate
					UNION ALL
                    SELECT bb.e_id, 
					       CASE WHEN c.sklimit > 0 THEN (CASE WHEN DATEDIFF([d], b.billdate, bb.billdate) > c.sklimit THEN 0 ELSE j.jstotal END) 
					       ELSE j.jstotal END AS jstotal
					FROM jspdetail j INNER JOIN billidx b ON j.xsd_bid = b.billid 
					                 INNER JOIN billidx bb ON j.skd_bid = bb.billid
					                 INNER JOIN clients c ON b.c_id = c.client_id
					WHERE b.billstates = 0 AND bb.billstates = 0 AND bb.billtype = 15 AND 
						  b.billtype = 10 AND bb.BillDate BETWEEN @BeginDate AND @EndDate
				) a GROUP BY a.e_id
            ) BI
            ON  bi.e_id = ve.emp_id
UNION ALL 
SELECT sp.emp_id, sp.serial_Number, sp.name, sp.dep_id, sp.tp_id, sp.tpName, sp.fName, sp.tcType, sp.class_id, sp.parent_id,
       sp.child_Number, sp.Child_Count, '商品销售提成' AS mType, SUM(sp.mTotal) AS mTotal, 
       SUM(dbo.GetTcRate(sp.mTotal, sp.f_id)) AS TcTotal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType, ve.class_id,
                  ve.parent_id, ve.child_Number, ve.Child_Count, '商品销售提成' AS mType,
                  CASE WHEN ISNULL(tpo.FtcType, TcType) = 2 THEN sbbi.mSLTotal
                       ELSE (   CASE WHEN ISNULL(tpo.FtcType, TcType) = 3 THEN sbbi.mJETotal
                                     ELSE (CASE WHEN ISNULL(tpo.FtcType, TcType) = 4 THEN sbbi.mMLTotal ELSE 0 END)
                                END
                            )
                  END AS mTotal, ISNULL(tpo.F_id, ve.f_id) AS f_id
           FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                             ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
                      FROM   Employees VE
                             LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                             LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                             LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
                      WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable))) AND 
                             VE.Deleted = 0 AND VE.Child_Number = 0 AND TcType IN (2, 3, 4)
                             AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> '' AND VE.[name] = @Employee))
                             AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                             AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
                  )VE
                  LEFT JOIN (
                           SELECT a.e_id, a.p_id,
                                  SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -a.Quantity ELSE a.Quantity END) AS mSLTotal,
                                  SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -a.TaxTotal ELSE a.TaxTotal END) AS mJETotal,
                                  SUM(CASE WHEN (a.BillType IN (11, 13, 17, 54, 211)) THEN -(a.TaxTotal -(a.costPrice * a.Quantity)) ELSE (a.TaxTotal -(a.costPrice * a.Quantity)) END) AS mMLTotal
                           FROM   (   SELECT bi.billtype, sb.rowe_id as e_id, sb.p_id, sb.quantity, sb.taxtotal, sb.costPrice
                                      FROM   saleManageBill sb, BillIdx bi
                                      WHERE  [Billtype] IN (10, 11, 12, 13, 112, 16, 17, 32, 53, 54, 210, 211) AND sb.AOID IN (0, 5)
                                             AND BillDate BETWEEN @BeginDate AND @EndDate AND BillStates = 0 AND sb.Bill_id = bi.BillID
                                  )a
                           GROUP BY a.p_id, a.e_id
                       ) AS SBBI ON  sbbi.e_id = ve.emp_id
                  LEFT JOIN (SELECT b.*, a.tcType AS FtcType FROM TcFormula a, TcProjectOther b 
                             WHERE  a.Formula_id = b.F_id) tpo ON  ve.tp_id = tpo.Tp_id AND sbbi.p_id = tpo.p_id
       ) Sp
GROUP BY sp.emp_id, sp.serial_Number, sp.name, sp.dep_id, sp.tp_id, sp.tpName, sp.fName, 
         sp.tcType, sp.class_id, sp.parent_id, sp.child_Number, sp.Child_Count  
UNION ALL 
SELECT VE.emp_id, ve.serial_Number, ve.name, ve.dep_id, ve.tp_id, ve.tpName, ve.fName, ve.tcType,
       ve.class_id, ve.parent_id, ve.child_Number, ve.Child_Count, '' AS mType, 0 AS mTotal, 0 AS TcToTal
FROM   (   SELECT VE.emp_id, ve.serial_Number, ve.[name], ve.dep_id, ve.tp_id, ve.class_id, ve.parent_id, ve.child_Number,
                  ve.Child_Count, TP.F_ID, ISNULL(TP.[Name], '')tpName, ISNULL(F.[Name], '')fName, ISNULL(f.tcType, -1)tcType
           FROM   Employees VE
                  LEFT JOIN TcProject TP ON  TP.TcProject_id = VE.Tp_ID
                  LEFT JOIN TcFormula F ON  F.Formula_id = TP.f_id
                  LEFT JOIN Company Y ON  VE.Y_id = Y.Company_id
           WHERE  ((@Companytable = 0) OR (VE.Y_id IN (SELECT [id] FROM #Companytable)))
                  AND VE.Deleted = 0 AND Tp_id = 0 AND VE.child_number = 0
                  AND ((@Employee = '' AND VE.Parent_id = @Parent_ID) OR (@Employee <> ''
                                 AND VE.[name] = @Employee))
                  AND (@YClass_id = '' OR Y.Class_id LIKE @YClass_id + '%')
                  AND ((@employeestable = 0) OR (VE.Emp_id IN (SELECT [id] FROM #employeestable)))
       )VE 
         
IF @@error = 0
    RETURN 0
ELSE
    RETURN -1
GO
