


CREATE TRIGGER DeletePFlag ON dbo.jspdetail
FOR delete
AS
declare @xsdbid numeric(10,0),@ncount int,@skd_bid numeric(10,0)
select @xsdbid=xsd_bid ,@skd_bid=skd_bid from deleted
select @ncount=isnull(count(*),0)  from jspdetail where xsd_bid=@xsdbid and skd_bid=@skd_bid
if @ncount=0 update billidx set jsflag='0'  where billid=@xsdbid
GO
