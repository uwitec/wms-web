










CREATE	PROCEDURE [Ts_L_UpdateAccount]
	(@account_id	[int],
	 @name	[varchar](80),
	 @alias 		[varchar](30),
	 @serial_number 	[varchar](26),
	 @Comment	[varchar](256),
	 @ini_total	numeric(25,8),
	 @PinYin	[varchar](80),
         @szY_id         int,
     @szYB     int    
         
)

AS 


if exists(select * from Account where serial_number=@serial_number and Account_id<>@Account_id and deleted =0)
begin
	RAISERROR('编号重复！不能添加！！',16,1)
	return -2
end
/*--------只有一个科目为医保科目*/
if @szYB=1 
begin
  UPDATE [account] set [YBaccount] =0
end


UPDATE [account] 

SET  [name]	 = @name,
	 [alias]	 = @alias,
	 [serial_number]	 = @serial_number,
	 [Comment]	 = @Comment,
	 [ini_total]	 = @ini_total,
	 [PinYin]	 = @PinYin, 
     [YBaccount] = @szYB

WHERE 
	( [account_id]	 = @account_id)


IF exists(select * from accountbalance where y_id=@szY_id and a_id=@account_id)
BEGIN
  
	UPDATE [accountbalance] 
	
	SET      [ini_total]	 = @ini_total
	WHERE 
		( [a_id]	 = @account_id AND 
                  Y_id           = @szY_id)

END
ELSE
BEGIN
    INSERT  [accountbalance](Y_id,a_id,cur_total,ini_total,total_01,total_02,total_03,total_04,
                            total_05,total_06,total_07,total_08,total_09,total_10,total_11,total_12,
                            bqtotal,sumtotal)
      VALUES(@szY_id,@account_id,0,@ini_total,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
END
GO
