
CREATE PROC ts_c_qrOverCredit(@nArApType INT = 1, @nY_Id INT = 2)
AS
/*Params Ini begin*/
if @nArApType is null  SET @nArApType = 1
if @nY_Id is null  SET @nY_Id = 2
/*Params Ini end*/
SET NOCOUNT ON 
SELECT a.client_id,
       a.serial_number,
       a.[name],
       a.alias,
       a.phone_number,
       a.ADDRESS,
       a.contact_personal,
       CASE WHEN @nArApType = 1 THEN b.credit_total ELSE b.APCredit_total END AS credit_total,
       b.artotal,
       b.aptotal
FROM   clients a LEFT JOIN clientsbalance b ON a.client_id = b.C_ID 
WHERE  b.Y_id = @nY_Id 
       AND (CASE WHEN @nArApType = 1 THEN b.artotal ELSE b.aptotal END) 
          >= (CASE WHEN @nArApType = 1 THEN b.credit_total ELSE b.APCredit_total END) 
       AND a.DELETED = 0
       AND a.child_number = 0
       AND (CASE WHEN @nArApType = 1 THEN b.credit_total ELSE b.Apcredit_total END) <> 0
GO
