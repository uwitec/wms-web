

/*====================================*/
/*获取微会员得到的优惠券*/
/*select * from wx_vip_getticket*/
/*exec abcdef..sys_getvipticketbyid @dhvopenid='abcdef',@chvisuse=0*/
/*exec dbo.WebAPP_GetVipTicketListByErp @chvopenid='abcdef',@chvisuse=-1*/
/*====================================*/
CREATE PROCEDURE [dbo].WebAPP_GetVipTicketListByErp
(
@chvopenid		varchar(200),
@chvisuse		int
)
/*$Encode$--*/
 AS

declare @dhvcardid int
if @chvisuse<>-4
	select @dhvcardid=VIPCardID from VIPCardBind where WeiXinNo=@chvopenid

if @chvisuse=0
begin
	select g.id,g.cardid,g.t_id,g.t_name,g.total,g.usecontent,g.remark,g.begindate,g.enddate,g.usedate,g.number,
	g.t_name as name,
	case when DATEDIFF(dd,g.enddate,GETDATE())>=-3 then '即将过期' else '还有'+cast(-DATEDIFF(dd,g.enddate,GETDATE()) as varchar)+'天' end as outmsg
	from wx_vip_getticket g 
	where g.cardid=@dhvcardid and g.isuse=0 and (DATEDIFF(dd , g.enddate , GETDATE())<=0)
end
else if @chvisuse=1
begin
	select g.id,g.cardid,g.t_id,g.t_name,g.total,g.usecontent,g.remark,g.begindate,g.enddate,g.usedate,g.number,
	g.t_name as name,
	'已使用' as outmsg
	from wx_vip_getticket g 
	where g.cardid=@dhvcardid and g.isuse=1
end
else if @chvisuse=2
begin
	select g.id,g.cardid,g.t_id,g.t_name,g.total,g.usecontent,g.remark,g.begindate,g.enddate,g.usedate,g.number,
	g.t_name as name,
	'已过期' as outmsg
	from wx_vip_getticket g 
	where g.cardid=@dhvcardid and g.isuse=0 and DATEDIFF(dd , g.enddate , GETDATE())>0
	
end
else if @chvisuse=-1
begin
	/*select * from wx_vip_ticket*/
	select t.id,t.total,t.endday,t.name as t_name,
	CONVERT(varchar(10),case when t.endday>0 then GETDATE() else t.begindate end,20) as begindate,
	CONVERT(varchar(10),case when t.endday>0 then DATEADD(dd,t.endday - 1,GETDATE()) else t.enddate end,20) as enddate,
	t.content as remark,
	case when t.useflag>0 then '单笔消费【'+CAST(t.useflag as varchar)+'】' else '不限制' end usecontent,
	0 as islose
	from wx_vip_ticket t
	where not exists(select 1 from wx_vip_getticket g where t.id=g.t_id and g.cardid=@dhvcardid)
	and (t.endday>0 or (DATEDIFF(dd , t.enddate , GETDATE())<=0)) and t.deleted=0
end
else if @chvisuse=-2
begin
	select *,0 as islose from wx_vip_ticket where id=@chvopenid and deleted=0
end
else if @chvisuse=-3
begin
	select id,cardid,t_id,t_name,t_name as name,total,usecontent,remark,begindate,enddate,isuse,usedate,number,
	DATEDIFF(dd ,enddate,GETDATE()) as endday,
	DATEDIFF(dd ,enddate,GETDATE()) as islose 
	from wx_vip_getticket where id=@chvopenid
end
else if @chvisuse=-4
begin
	create table #tickId (id int)
	insert into #tickId(id) select s from dbo.getstr(@chvopenid)
	
	update wx_vip_ticket set deleted=1 where id in (select id from #tickId) 
	select '操作成功' as outmsg,0 as reCode
end

return 0
GO
