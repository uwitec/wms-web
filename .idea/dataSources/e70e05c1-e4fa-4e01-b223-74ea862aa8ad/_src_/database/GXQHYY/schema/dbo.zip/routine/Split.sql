
CREATE  FUNCTION [Split](@Expression VARCHAR(8000), @Delimiter VARCHAR(10) = ',')
RETURNS
	@Array TABLE ([str] VARCHAR(8000))
AS
BEGIN
	DECLARE @nPos INT, @szTemp VARCHAR(8000)
	SET @Expression = LTRIM(RTRIM(@Expression))
	WHILE @Expression <> ''
	BEGIN
		SELECT @nPos = PATINDEX('%' + @Delimiter + '%', @Expression)
		IF @nPos = 0
		BEGIN
			INSERT INTO @Array([str])
			VALUES(@Expression)
			BREAK
		END
		ELSE
		BEGIN
			SELECT @szTemp = SUBSTRING(@Expression, 1, @nPos - 1)
			INSERT INTO @Array([str])
			VALUES(@szTemp)
			SELECT @Expression = SUBSTRING(@Expression, @nPos + 1, LEN(@Expression) - @nPos)
		END
	END
	RETURN
END
GO
