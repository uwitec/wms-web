
CREATE   PROCEDURE [dbo].[TS_ExportData] 
  @QuerySql varchar(2000),
  @FileName varchar(1000),
  @UserName VARCHAR(200),
  @Password VARCHAR(200)
AS
begin
  declare @bcp varchar(3000)  
  DECLARE @TmpTable VARCHAR(50)
  SET @TmpTable= '[##' + CAST(NEWID() AS VARCHAR(50)) + ']'
  DECLARE @sql VARCHAR(5000)
  SET @sql = ''
  IF LEN(@QuerySql) > 1000
    BEGIN
      /*PRINT LEN(@QuerySql)*/
     set @sql = 'SELECT * into ' + @TmpTable + ' FROM (' + @QuerySql + ') t '
      set @QuerySql = 'select * from ' +  @TmpTable  
      set @bcp = ' exec master..xp_cmdshell' + ' ''bcp "' + @QuerySql + '" ' + ' queryout "' + @FileName + '" -c -S"' + convert(varchar(100),ServerProperty('ServerName')) + '" '
               + ' -U"' + @UserName + '" ' + '-P"' + @Password + '"' + ' '' '
      set @sql = @sql + @bcp + ' DROP TABLE ' +  @TmpTable
      print @sql
      EXEC(@sql)
    END 
  ELSE
    begin
      set @bcp = ' bcp "' + @QuerySql + '" ' + ' queryout "' + @FileName + '" -c -S"' + convert(varchar(100),ServerProperty('ServerName')) + '" '
               + ' -U"' + @UserName + '" ' + '-P"' + @Password + '"'
      print @bcp
      EXEC master..xp_cmdshell @bcp
    end  
END
GO
