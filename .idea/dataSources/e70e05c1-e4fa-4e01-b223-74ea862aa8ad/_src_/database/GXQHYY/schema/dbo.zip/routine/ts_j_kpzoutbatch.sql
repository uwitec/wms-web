

CREATE proc ts_j_kpzoutbatch
(
	@begindate datetime,
	@enddate   datetime,
    @nbilltype int,
    @nIgnore int,
    @nMerge int,
    @nMode int    /*0从历史单据选择导入 1 从其他菜单批量导出                 */
)
/*with encryption*/
as
set nocount on

/*初始化查询条件*/
declare @a int, @b int, @nReturnNumber int
declare @nBilltypeTmp int, @nBillIDTmp int,  @nOutPzid int

declare @OutGuid varchar(100)

truncate table Kpzout

if @nMode = 0
begin
  if @nMerge = 1 
    goto MergePZ
  else
    goto OutPZ    
end



if @nMode = 1
begin
  if @nbilltype=0 
  begin
	select @a=min(billtype),@b=max(billtype) from billidx
  end
  else begin
   set @a=@nbilltype
   set @b=@nbilltype
  end
  /*写入需要导入的单据到临时表*/
  if @nIgnore = 0   
    delete pzOutBill 
     where billid in      
          (select billid from billidx 
           where (billdate between @BeginDate and @EndDate) and billstates='0' and (billtype between @a and @b))
              
  insert into pzOutBill(BillID, BillType, OutCount, OutDate, OutStates, OutGUID) 
     select billid, billtype, 0, GETDATE(), 0 ,NEWID() from billidx 
           where (billdate between @BeginDate and @EndDate) and billstates='0' and (billtype between @a and @b)
                  and billid not in (select billid from pzOutBill)    
  
  if @nMerge = 1 
    goto MergePZ
  else
    goto OutPZ     
end


MergePZ:    
   begin tran            
	 declare pzoutMerge cursor for
	 select distinct billtype from pzOutBill where OutStates = 0 
	 open pzoutMerge
	   fetch next from pzoutMerge into @nBilltypetmp
	   while @@fetch_status=0
	   begin
	     update billidx set note ='【已导出】' + note where billid in (select billid from pzOutBill where billtype = @nBilltypeTmp and OutStates = 0)
		 exec @nReturnNumber=ts_j_KPzMergeOut @nBilltypetmp
		 if @nReturnNumber=-1 goto error		 
		 fetch next from pzoutMerge into @nBilltypetmp
	   end
	 close pzoutMerge
	 deallocate pzoutMerge
   commit tran
   
   return 0 
   
 
OutPZ:
   begin tran            
	 declare pzoutbatch cursor for
	 select Billid from pzOutBill where OutStates = 0 
	 open pzoutbatch
	   fetch next from pzoutbatch into @nBillIdtmp
	   while @@fetch_status=0
	   begin
		 exec @nReturnNumber= ts_q_kpzout @nBillIdtmp
		 if @nReturnNumber=-1 goto error
		 update billidx set note ='【已导出】' + note where billid = @nBillIdtmp		 
		 fetch next from pzoutbatch into @nBillIdtmp
	   end

	 close pzoutbatch
	 deallocate pzoutbatch
   commit tran   
   return 0


Error:
return -1
GO
