
/* =============================================*/

/* 用法:	通过id合并一个字段*/
/* =============================================*/
CREATE FUNCTION MergeStr
(
	@id int
)
RETURNS varchar(5000)
AS
BEGIN
	DECLARE @Result varchar(5000)

	SELECT @Result = ISNULL(@Result + ',', '') + comment from VW_C_WLMX where billid = @id

	RETURN @Result

END
GO
