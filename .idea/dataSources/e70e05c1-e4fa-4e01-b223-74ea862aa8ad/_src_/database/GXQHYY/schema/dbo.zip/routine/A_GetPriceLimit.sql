
/* =============================================*/
/* Author:		张科*/
/* Create date: 2013-4-27*/
/* Description:	获取职员价格权限*/
/* =============================================*/
CREATE FUNCTION A_GetPriceLimit
(
	@Eid		int,	/*职员ID*/
	@PriceType  int	    /*价格类型 0、零售价；1、预设售价1；2、预设售价2；3、预设售价3；4、会员价；5、国批价；6、国零价；7、特价；8、最近进价；9、最低售价*/
)
RETURNS int
AS
BEGIN
	DECLARE @Result INT
	IF @Eid = 1 
	BEGIN
		/*管理员全部价格权限*/
		SET @Result = 1
	END
	ELSE
	BEGIN
		DECLARE @Lim CHAR(1)
		SET @Lim = '0'
		SELECT @Lim = SUBSTRING(ISNULL(e.PriceInfor, '0000000000'), @PriceType + 1, 1) FROM EmplimitEx e WHERE e.e_id = @Eid
		IF @Lim = '1'
			SET @Result = 1
		ELSE
			SET @Result = 0
	END
	RETURN @Result
END
GO
