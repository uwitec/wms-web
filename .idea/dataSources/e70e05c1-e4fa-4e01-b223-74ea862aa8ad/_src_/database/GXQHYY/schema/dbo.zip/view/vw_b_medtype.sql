
CREATE	  VIEW dbo.vw_b_medtype
AS
SELECT id as mt_id ,name as  mt_name 
FROM customCategory
WHERE deleted = 0
GO
