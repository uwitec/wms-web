

CREATE	   VIEW dbo.vw_b_account
AS
SELECT account_id as a_id,serial_number as code , name as a_name, class_id as a_classid
FROM account
WHERE deleted = 0
GO
