
CREATE	PROCEDURE [Ts_j_InsPDAMac]
	(@nEditMode int=0,   /*0 添加， 1 修改*/
	 @nMid int=0,
	 @szPDANO [varchar] (100),
	 @szdemo [varchar] (100),
	 @szpassword [varchar] (20),
	 @szRegCode [varchar](50)
	)
AS
/*Params Ini begin*/
if @nEditMode is null  SET @nEditMode = 0
if @nMid is null  SET @nMid = 0
/*Params Ini end*/


if @nEditMode = 0
begin
   if exists(select * from pda_machine where [PDANO]=@szPDANO)
   begin
   	RAISERROR('PDA设备编号重复，请检查',16,1) 
	return 0
   end 
   
	INSERT INTO [pda_machine]
		 ( 
		 [PDANO],
		 [demo],
		 [password],
		 [PDAGUID]
		 )	 
	VALUES 
		(@szPDANO,
		 @szdemo,
		 cast(@szpassword as BINARY(20)),
		 @szRegCode
		 )
		 		 
	if @@rowcount <>0 
		return @@IDENTITY
	else return 0
END 

if @nEditMode = 1
begin
   if exists(select * from pda_machine where [PDANO]=@szPDANO and mid <> @nMid)
   begin
   	RAISERROR('PDA设备编号重复，请检查',16,1) 
	return 0
   end 
   
	update [pda_machine]
	  set  PDANO =  @szPDANO,
		   [demo] = @szdemo,	  
		   [password] = cast(@szPassWord as BINARY(20)),
		   [pdaguid] = @szRegCode
     where  mid = @nMid 
      		 		 
	if @@rowcount <>0 
		return @nMid
	else return 0
end
GO
