
CREATE TRIGGER [tranflag_check] ON [dbo].[tasklist] 
FOR UPDATE
AS

declare @tranflag tinyint,@billtype int,@tsid int
if update(tranflag)
begin
  select @tsid=tsid,@billtype=billtype,@tranflag=tranflag from inserted
  if @tranflag=2
  begin
    if @billtype=140
    begin
      update tasklist set tranflag=1 where tsid=@tsid
    end
  end
end
GO
