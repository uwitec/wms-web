












CREATE  VIEW dbo.vw_c_orderidx AS 
SELECT 
      dbo.orderidx.billid, dbo.orderidx.billdate, dbo.orderidx.billnumber, dbo.orderidx.billtype, dbo.orderidx.a_id, dbo.orderidx.c_id, dbo.orderidx.e_id,
      dbo.orderidx.sout_id, dbo.orderidx.sin_id, dbo.orderidx.auditman, dbo.orderidx.inputman, dbo.orderidx.ysmoney, dbo.orderidx.ssmoney,
      dbo.orderidx.quantity, dbo.orderidx.taxrate, dbo.orderidx.period, dbo.orderidx.billstates, dbo.orderidx.order_id, dbo.orderidx.department_id,
      dbo.orderidx.posid, dbo.orderidx.region_id, dbo.orderidx.skdate, dbo.orderidx.auditdate, dbo.orderidx.jsye, dbo.orderidx.jsflag, dbo.orderidx.note,
      dbo.orderidx.summary, dbo.orderidx.invoice, dbo.orderidx.InvoiceTotal, dbo.orderidx.InvoiceNO, dbo.orderidx.BusinessType, dbo.orderidx.Guid,
      dbo.orderidx.Y_ID, dbo.orderidx.WT_ID, dbo.orderidx.OrderValidDate, dbo.orderidx.GatheringMan, dbo.orderidx.TrafficCompany,
      dbo.orderidx.TrafficType, dbo.orderidx.SendTime, dbo.orderidx.SendC_ID, dbo.orderidx.B_CustomName1, dbo.orderidx.B_CustomName2,
      dbo.orderidx.B_CustomName3, dbo.orderidx.yfdate, dbo.orderidx.yfflag, dbo.orderidx.yfye, dbo.orderidx.BalanceMode,
      isnull(dbo.clients.name, '') as cname, isnull(dbo.account.name, '') 
      as aname, isnull(dbo.employees.name, '') as ename, isnull(dbo.account.class_id, 
      '') as aclass_id, isnull(dbo.clients.class_id, '') as cclass_id, 
      isnull(dbo.employees.class_id, '') as eclass_id,isnull(emp.class_id, '') as inputmanclass_id,
      isnull(emp.[name],'') as inputmanname,
      isnull(empa.[name],'') as auditmanname,
      isnull(empa.class_id,'') as auditmanclass_id,
      isnull(dep.[name],'') as departmentname,
      isnull(reg.[name],'') as regionname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      isnull(Y.class_id,'') as YClass_id,
      isnull(Y.[name],'') as Yname,
      isnull(com.[name],'') as comname,
      ISNULL(sds.name,'') as sendcname
from dbo.orderidx left outer join
      dbo.account on dbo.orderidx.a_id = dbo.account.account_id left outer join
      dbo.clients on dbo.orderidx.c_id = dbo.clients.client_id left outer join
      dbo.employees on dbo.orderidx.e_id = dbo.employees.emp_id
      left outer join employees emp on dbo.orderidx.inputman=emp.emp_id
      left outer join employees empa on dbo.orderidx.auditman=empa.emp_id
      left outer join department dep on dbo.orderidx.department_id=dep.departmentid
      left outer join region reg on dbo.orderidx.region_id=reg.region_id
      left outer join storages ss on dbo.orderidx.sout_id=ss.storage_id
      left outer join storages sd on dbo.orderidx.sin_id=sd.storage_id
      left outer join COMPANY  Y  on Y.Company_id=dbo.orderidx.Y_id
      left outer join COMPANY  com on dbo.orderidx.c_id = com.company_id
      left outer join clients sds  on  dbo.orderidx.SendC_ID=sds.client_id
GO
