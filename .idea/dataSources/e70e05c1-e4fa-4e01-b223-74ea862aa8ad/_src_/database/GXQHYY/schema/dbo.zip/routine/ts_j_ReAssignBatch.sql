/************************************************************

--功能：对不能正常日结的零售单重新分配批次   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改: 2010-07-14

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_ReAssignBatch]

/*with encryption */

AS 


declare @nP_id  		int  					  /*商品id*/
declare @nS_id  		int  					  /*仓库id*/
declare @nY_ID		 int
declare @nL_idIn	int  					  /*货位id*/
declare @szBatchNoIn 	varchar(20)  	  /*批号*/
declare @dQtyIn numeric(25,8), @dQty numeric(25,8)	/*数量*/
declare @dCostPriceIn	numeric(25,8)	/*传入成本单价*/
declare @MakeDateIn    		  datetime  /*生产日期*/
declare @ValidDateIn	  datetime  /*效期*/
declare @nSupplier_idIn     int     /*供应商id*/
declare @nCommissionflagIn  int	    /*代销商品标记*/
declare @nSmb_ID int, @nBill_ID	int    
declare @tInstoretimeIn     datetime  /*入库时间*/
declare @nRet int, @i int, @j int

if object_id('tempdb..#storeAll') is not null  /*取全部的库存，避免重复分配*/
    drop table #storeAll
    
select s.* into #StoreAll from storehouse s
  inner join (select distinct p_id, ss_id, y_id from Ysalemanagebilldrf where p_id > 0) mx
  on s.p_id = mx.p_id and s.s_id = mx.ss_id and s.Y_ID = mx.Y_ID 
    

if object_id('tempdb..#tstorehouse') is not null 
    drop table #tstorehouse
select top 0  IDENTITY(int, 1, 1) as t_id, cast(storehouse_id as int) as storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
             validdate, commissionflag,Instoretime  
      into #tstorehouse from storehouse


begin tran ReAssignBatch
	declare curP cursor scroll for 
	        select sm.smb_id,bi.billid,sm.p_id, bi.y_id, sm.ss_id, sm.location_id,sm.supplier_id,sm.quantity,sm.costprice,
		       sm.batchno,sm.makedate, sm.validdate,sm.commissionflag,sm.Instoretime 
                  from Ysalemanagebilldrf  sm inner join ybilldraftidx bi on sm.bill_id=bi.billid 
   		  where bi.transflag < 0 and sm.p_id > 0 and sm.aoid in (0,5) and bi.billtype = 12
                  
	 open curP
	      fetch next from curP into @nSmb_ID,@nBill_ID,@nP_id,@nY_ID,@nS_id, @nL_idIn,@nSupplier_idIn,@dQtyIn,@dCostPriceIn,
					@szBatchNoIn, @MakeDateIn, @ValidDateIn, @nCommissionflagIn,@tInstoretimeIn
	      WHILE @@FETCH_STATUS = 0
	      begin
                  set @nRet = -1
		  truncate table #tstorehouse
		  /*完全相同，可能storehouse 有两条记录	*/
                  insert into #tstorehouse(storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		         validdate, commissionflag,Instoretime) 
		  select storehouse_id,p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		         validdate, commissionflag,Instoretime   
		    from #StoreAll 
                    where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and location_id = @nL_idIn and 
			  supplier_id = @nSupplier_idIn and costprice = @dCostPriceIn and batchno = @szBatchNoIn and makedate = @MakeDateIn and 
                          validdate=@ValidDateIn and commissionflag=@nCommissionflagIn and Instoretime = @tInstoretimeIn

	          select  @dQty = sum(quantity) from #tstorehouse
                  
		  if @dQty is null set @dQty = 0      
                  
                  if @dQty >= @dQtyIn
                  begin
		    /*注意这里批次正确过了账，应检查他原因	*/
		    if exists(select 1 from #StoreAll having count(1) =1)
                    begin
                      fetch next from curP into @nSmb_ID,@nBill_ID,@nP_id,@nY_ID,@nS_id, @nL_idIn,@nSupplier_idIn,@dQtyIn,@dCostPriceIn,
					     @szBatchNoIn, @MakeDateIn, @ValidDateIn, @nCommissionflagIn,@tInstoretimeIn
                      continue
                    end
                    set @nRet = 0  
                  end

		  /*不同成本价	*/
		  if @nRet <> 0
                  begin
		    insert into #tstorehouse(storehouse_id,p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		                             validdate, commissionflag,Instoretime) 
		       select storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		              validdate, commissionflag,Instoretime   
		         from #StoreAll 
                         where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and location_id = @nL_idIn and 
			  	supplier_id = @nSupplier_idIn and batchno = @szBatchNoIn and makedate = @MakeDateIn and 
                         	 validdate=@ValidDateIn and commissionflag=@nCommissionflagIn and 
                                 storehouse_id not in (select storehouse_id from #tstorehouse)
			 order by instoretime

		    select  @dQty = sum(quantity) from #tstorehouse	
	            if @dQty is null set @dQty = 0

		    if @dQty >= @dQtyIn
                       set @nRet = 0
                  end
			
		  /*不同货位	*/
		  if @nRet <> 0
                  begin
		    insert into #tstorehouse(storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		                             validdate, commissionflag,Instoretime) 
		       select storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		              validdate, commissionflag,Instoretime   
		         from #StoreAll 
                         where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and 
			  	supplier_id = @nSupplier_idIn and batchno = @szBatchNoIn and makedate = @MakeDateIn and 
                         	 validdate=@ValidDateIn and commissionflag=@nCommissionflagIn and 
                                 storehouse_id not in (select storehouse_id from #tstorehouse)
			 order by instoretime
		    select  @dQty = sum(quantity) from #tstorehouse	
	            if @dQty is null set @dQty = 0

		    if @dQty >= @dQtyIn
                       set @nRet = 0
                  end
		  
 	          /*近效期先出,匹配代销，供应商	*/
		  if @nRet <> 0
                  begin
		    insert into #tstorehouse(storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		                             validdate, commissionflag,Instoretime) 
		       select storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		              validdate, commissionflag,Instoretime   
		         from #StoreAll 
                         where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and 
			  	supplier_id = @nSupplier_idIn  and commissionflag=@nCommissionflagIn and 
                                 storehouse_id not in (select storehouse_id from #tstorehouse)
			 order by validdate

		    select  @dQty = sum(quantity) from #tstorehouse	
	            if @dQty is null set @dQty = 0

		    if @dQty >= @dQtyIn
                       set @nRet = 0
                  end  
		 
                  /*近效期先出,匹配供应商	*/
		  if @nRet <> 0
                  begin
		    insert into #tstorehouse(storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		                             validdate, commissionflag,Instoretime) 
		       select storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		              validdate, commissionflag,Instoretime   
		         from #StoreAll 
                         where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and 
			  	supplier_id = @nSupplier_idIn and 
                                 storehouse_id not in (select storehouse_id from #tstorehouse)
			 order by validdate
	
		    select  @dQty = sum(quantity) from #tstorehouse	
	            if @dQty is null set @dQty = 0

		    if @dQty >= @dQtyIn
                       set @nRet = 0
                  end	
                  
                  		 
                  /*近效期先出*/
		  if @nRet <> 0
                  begin
		    insert into #tstorehouse(storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		                             validdate, commissionflag,Instoretime) 
		       select storehouse_id, p_id, y_id, s_id, location_id,supplier_id,quantity, costprice, batchno, makedate, 
		              validdate, commissionflag,Instoretime   
		         from #StoreAll 
                         where p_id=@nP_id and y_id=@nY_ID and s_id = @nS_id and 
                               storehouse_id not in (select storehouse_id from #tstorehouse)
			 order by validdate

		    select  @dQty = sum(quantity) from #tstorehouse	
	            if @dQty is null set @dQty = 0

		    if @dQty >= @dQtyIn
                       set @nRet = 0
                  end	
                  
	 	  /*更新批次 		  */
                  if @nRet = 0
		  begin
		    set @i = 1
                    select @j = max(t_id) from #tstorehouse
		    set @dQty = @dQtyIn
                    while @i <= @j
                    begin
                      if exists (select 1 from #tstorehouse where t_id = @i and quantity > @dQty)
		      begin
			update #tstorehouse set quantity = @dQty where t_id = @i
 			delete #tstorehouse where t_id > @i or quantity = 0  
			break
                      end
 
                      select @dQty = @dQty - quantity from #tstorehouse where t_id = @i 
                      set @i = @i + 1
		    end

		    
		    insert into ysalemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
                                        totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,aoid,thqty,SendQty,SendCostTotal,PriceType,RowE_ID,
					YGUID,Y_ID,InStoreTime,cxType, RowGuid,ycostprice, transflag)

                    select sm.bill_id, sm.p_id, s.batchno, s.quantity, s.costprice, sm.saleprice, sm.discount, sm.discountprice, 
                                        sm.discountprice*s.quantity, sm.taxprice, sm.taxprice*s.quantity, sm.discountprice*s.quantity*sm.taxrate, 
  					sm.retailprice, sm.retailprice*s.quantity, s.makedate, s.validdate, 
					sm.qualitystatus, sm.price_id, sm.ss_id, sm.sd_id, s.location_id, s.supplier_id, s.commissionflag, 
					sm.comment,sm.unitid,sm.taxrate,sm.order_id,sm.saleprice * s.quantity, sm.aoid, s.quantity, s.quantity,
					s.quantity*s.costprice, sm.PriceType, sm.RowE_ID,sm.YGUID,sm.Y_ID,s.InStoreTime,
					sm.cxType, newid(), sm.ycostprice, sm.transflag

		    from #tstorehouse s 
                    left join ysalemanagebilldrf sm on  s.p_id = sm.p_id
		    where sm.smb_id = @nsmb_id 

                    delete ysalemanagebilldrf where smb_id = @nsmb_id
                    
            update #StoreAll set quantity = s1.quantity-t.quantity from #StoreAll s1, #tstorehouse t             
              where  s1.p_id=t.p_id and s1.y_id=t.Y_ID and s1.s_id = t.S_id and s1.location_id =t.location_id and 
			  s1.supplier_id = t.supplier_id and s1.costprice = t.costprice and s1.batchno = t.batchno and s1.makedate = t.MakeDate and 
                         s1.validdate=t.ValidDate and s1.commissionflag=t.Commissionflag and s1.Instoretime = t.Instoretime
	          delete #Storeall where quantity  = 0                          
                                          
		    update ybilldraftidx set transflag = 0 where billid = @nBill_ID
		  end
	          fetch next from curP into @nSmb_ID,@nBill_ID,@nP_id,@nY_ID,@nS_id, @nL_idIn,@nSupplier_idIn,@dQtyIn,@dCostPriceIn,
					     @szBatchNoIn, @MakeDateIn, @ValidDateIn, @nCommissionflagIn,@tInstoretimeIn
	      end
	       close curp
	 deallocate curP

commit tran ReAssignBatch

return 0
GO
