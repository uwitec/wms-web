


CREATE	TRIGGER cgGspBillstates ON [dbo].[gspbillidx]
FOR  UPDATE
AS
if update(billstates)
begin
  if exists(select 1 from inserted where billtype in (561) and billstates=15)
  begin
	 delete from gspdraft  where bill_id in (select GSPbillid from inserted where billtype in (561) and billstates=15)
  end
  else if exists(select 1 from inserted where billtype in (561) and billstates<>15)
  begin
    update gspdraft set billstates=b.billstates from gspdraft a,inserted b where a.bill_id=b.Gspbillid and b.BillType in (561) and b.BillStates<>15
  end
  
  if exists(select 1 from inserted where billtype in (516) and billstates not in (10,12))
  begin
  	 delete from  gspdraft where bill_id in (select GSPbillid from inserted where billtype in (516) and billstates not in (10,12))
  end 
  else if exists(select 1 from inserted where billtype in (516) and billstates  in (10,12))
  begin
    update gspdraft set billstates=b.billstates from gspdraft a,inserted b where a.bill_id=b.Gspbillid and b.BillType in (516) and b.BillStates  in (10,12)
  end
  
end
GO
