


CREATE	 TRIGGER CheckTran ON [dbo].[TranBill]
FOR  UPDATE
AS
declare @nbillid numeric(10,0)
if update(comeqty)
begin
	select @nbillid=bill_id from deleted
	if exists(select * from tranbill where quantity>comeqty and bill_id=@nbillid)
		update tranidx set billstates='3' where billid=@nbillid
	else
		update tranidx set billstates='0' where billid=@nbillid
end
GO
