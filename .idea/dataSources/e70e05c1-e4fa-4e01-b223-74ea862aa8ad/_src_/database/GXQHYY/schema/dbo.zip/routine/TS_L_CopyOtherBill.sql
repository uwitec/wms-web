/*************复制其他单据************/
/******add by luowei 2012-09-28*****/
/*说明：目前只对促销单进行复制，可以通过判断单据类型进行扩展*/

CREATE PROCEDURE TS_L_CopyOtherBill
(
  @nBillNo int, 
  @billType int = 0 
)
as
  
  declare @nNewbillid int 
  declare @npriority int
  
  select @npriority = MAX(priority) from CxBillIdx

  insert into CxBillIdx(billnumber,e_id,c_id,Y_ID,auditman,inputman,billstate,billdate,auditdate,cp_id,begindate,enddate,
  begintime,endtime,billtype,cardtype,weekday,priority,totalmoney,comment,guid,cpname,clientArea,CompanyArea,totalmoneyMax)
  
  select   billnumber,e_id,c_id,Y_ID,0,inputman,2,GETDATE(),auditdate,cp_id,begindate,enddate,
  begintime,endtime,billtype,cardtype,weekday,@npriority+1,totalmoney,comment + '(由促销单【'+billnumber+'】复制生成)',newid(),cpname,clientArea,CompanyArea,totalmoneyMax
  from CxBillIdx where billid  = @nBillNo
  
  Set @nNewbillid=@@identity
  
  insert into CxBillNew(billid,p_id,unit_id,price,discount,lownum,billlimit,totallimit,total,grouptotal,presenttype,
            groupnum,comment,sale,guid,daylimit,cardlimit)
  select   @nNewbillid,p_id,unit_id,price,discount,lownum,billlimit,totallimit,total,grouptotal,presenttype,
         groupnum,comment,sale,NEWID(),daylimit,cardlimit from CxBillNew where billid = @nBillNo order by smb_id
         
 if @@rowcount=0 goto error
 
 return 0        

error: 
   return -1
GO
