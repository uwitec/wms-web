

CREATE PROCEDURE Ts_K_SendGoodsBillSetSomething(@BillId INT, @BillType INT)
AS
BEGIN
	IF @BillType in (150, 152) 
	BEGIN
		SELECT c.opaddress AS [ADDRESS], c.manager AS EName, c.tel 
			FROM billidx b INNER JOIN company c ON b.c_id = c.company_id 
		WHERE b.billid = @BillId 
	END
	ELSE
	IF @BillType in (10, 11, 212, 21) 
    BEGIN
		SELECT c.[address], c.contact_personal AS EName, c.phone_number AS Tel 
			FROM billidx b INNER JOIN clients c ON b.c_id = c.client_id 
		WHERE b.billid = @BillId 	
    END	
END
GO
