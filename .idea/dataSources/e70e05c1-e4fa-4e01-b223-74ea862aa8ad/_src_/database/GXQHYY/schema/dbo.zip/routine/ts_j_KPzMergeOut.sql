
create  proc ts_j_KPzMergeOut
(
	@nBilltype int
)
/*with encryption*/
as
set nocount on
    declare @nReturnNumber int, @nBillidTmp int
	declare @outGUID varchar(120) 
	declare @FDate datetime, @FYear decimal(28, 10), @FPeriod decimal(28, 10),
	        @FGroupID varchar(80), @FNumber decimal(28, 10), @FCurrencyNum varchar(10),
			@FCurrencyName varchar(40), @FPreparerID varchar(255), @FCheckerID varchar(255),
			@FApproveID varchar(255),  @FCashierID varchar(255), @FHandler varchar(50),
			@FSettleTypeID varchar(80), @FSettleNo varchar(255), @FExplanation varchar(255),
			@FQuantity varchar(10), @FMeasureUnitID varchar(255), @FUnitPrice varchar(10),
			@FReference varchar(255), @FTransDate datetime, @FTransNo varchar(40),
			@FAttachments decimal(28, 10), @FSerialNum decimal(28, 10), @FObjectName varchar(100),
			@FParameter varchar(100), @FExchangeRate varchar(10), @FEntryID decimal(28, 10),
			@FPosted decimal(28, 10), @FInternalInd varchar(10), @FCashFlow varchar(255)                              	

   begin tran            	  
	 select @outGUID = NEWID()
	 update  pzOutBill set OutGUID = @outGUID where OutStates = 0 and billtype = @nBilltype
   
	 declare pzoutbatch cursor for
	 select Billid from pzOutBill where OutStates = 0 and billtype = @nBilltype
	 open pzoutbatch
	   fetch next from pzoutbatch into @nBillIdtmp
	   while @@fetch_status=0
	   begin
		 exec @nReturnNumber= ts_q_kpzout @nBillIdtmp
		 if @nReturnNumber=-1 goto error
		 fetch next from pzoutbatch into @nBillIdtmp
	   end
	 close pzoutbatch
	 deallocate pzoutbatch
	 
	 /*FEntryID 需要更新*/
		 
		 
	 select top 1 
	        @FDate = FDate, @FYear= FYear, @FPeriod =FPeriod, @FGroupID= FGroupID, @FNumber= FNumber, 
	        @FCurrencyNum= FCurrencyNum, @FCurrencyName= FCurrencyName, @FPreparerID =FPreparerID, 
	        @FCheckerID= FCheckerID, @FApproveID= FApproveID, @FCashierID= FCashierID, @FHandler= FHandler, 
	        @FSettleTypeID= FSettleTypeID, @FSettleNo= FSettleNo,@FExplanation= FExplanation,
	        @FQuantity= FQuantity,@FMeasureUnitID= FMeasureUnitID,@FUnitPrice= FUnitPrice,
	        @FReference= FReference, @FTransDate= FTransDate, @FTransNo= FTransNo, 
	        @FAttachments =FAttachments, @FSerialNum =FSerialNum,@FObjectName= FObjectName, 
	        @FParameter= FParameter, @FExchangeRate= FExchangeRate, @FEntryID= FEntryID,
	        @FPosted= FPosted,@FInternalInd= FInternalInd,@FCashFlow= FCashFlow 	            
	   from Kpzout	 
	 
	if OBJECT_ID('tempdb..#kptmp') is not null
	   drop table #kptmp
 	  	 
	select FAccountNum, FAccountName, fItem, SUM(FAmountFor) as FAmountFor, 
	       SUM(FDebit) as Fdebit, SUM(Fcredit) as Fcredit, FEntryID2 = IDENTITY(int, 1, 1)
	   into #kptmp     
	  from  Kpzout  
  group by FAccountNum, FAccountName, fItem
	 

  truncate table kpzout
  
  insert into Kpzout(	FAccountNum, FAccountName, fItem, FAmountFor, 
						Fdebit, Fcredit,
						FDate, FYear, FPeriod, FGroupID, FNumber, 
						FCurrencyNum, FCurrencyName, FPreparerID, 
						FCheckerID, FApproveID, FCashierID, FHandler, 
						FSettleTypeID, FSettleNo, FExplanation,
						FQuantity,FMeasureUnitID,FUnitPrice,
						FReference, FTransDate, FTransNo, 
						FAttachments, FSerialNum,FObjectName, 
						FParameter, FExchangeRate, FEntryID,
						FPosted,FInternalInd,FCashFlow
	                  
	                    
  )	 	 	 
      
       select   FAccountNum, FAccountName, fItem, FAmountFor, 
	            Fdebit, Fcredit,
	            @FDate, @FYear, @FPeriod, @FGroupID, @FNumber, 
				@FCurrencyNum, @FCurrencyName, @FPreparerID, 
				@FCheckerID, @FApproveID, @FCashierID, @FHandler, 
				@FSettleTypeID, @FSettleNo,@FExplanation,
				@FQuantity,@FMeasureUnitID,@FUnitPrice,
				@FReference, @FTransDate, @FTransNo, 
				@FAttachments, @FSerialNum,@FObjectName, 
				@FParameter, @FExchangeRate, FEntryID2-1,
				@FPosted,@FInternalInd,@FCashFlow			
	     from	#kptmp  
	 	 
   commit tran   
   
   return 0
   
 Error:
   return -1
GO
