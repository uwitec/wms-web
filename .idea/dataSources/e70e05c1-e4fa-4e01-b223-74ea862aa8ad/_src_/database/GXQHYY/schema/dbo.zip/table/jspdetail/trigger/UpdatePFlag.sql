


CREATE TRIGGER UpdatePFlag ON dbo.jspdetail
FOR INSERT
AS
declare @xsdbid numeric(10,0)
select @xsdbid=xsd_bid from inserted
update billidx set jsflag='P'  where billid=@xsdbid
GO
