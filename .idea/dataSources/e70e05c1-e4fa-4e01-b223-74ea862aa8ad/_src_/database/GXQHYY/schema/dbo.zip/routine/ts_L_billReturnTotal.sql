

CREATE proc ts_L_billReturnTotal
(@billid int
)
as
 if object_id('tempdb..#RetStd') is not null
 drop table #RetStd
 
 if object_id('tempdb..#Returnstd') is not null
 Drop Table #Returnstd
 
select c_id,P_id,Begindate,EndDate,y_id,max(returnID)Rid into #RetStd from returnstd
Group by c_id,P_id,Begindate,EndDate,y_id

select * into #Returnstd 
from returnstd where returnID in (select rid from #RetStd)

select R.billid,R.billdate,(sum(RtQTY)+SUm(RtMoney))RtTotal
From
   (select b.billid,billtype,b.billdate,bm.quantity,bm.taxtotal,r.ReturnPrice,r.ReturnRate,(bm.quantity*r.ReturnPrice)RtQty,
           (bm.taxtotal*r.ReturnRate)RtMoney
      from billidx b,productDetail bm,#Returnstd r
     where b.billid=bm.billid and bm.p_id=r.p_id and r.c_id=bm.supplier_id
           and b.billstates=0 and billtype in (20,220) and b.billid=@billid
           and r.tag=1 and b.billdate between r.begindate and r.enddate
   )R
Group by R.billid,R.billdate

 if object_id('tempdb..#RetStd') is not null
 drop table #RetStd
 
 if object_id('tempdb..#Returnstd') is not null
 Drop Table #Returnstd
GO
