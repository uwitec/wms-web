
create PROCEDURE Ts_T_QryRetailBackMx
( 
  @BeginDate DateTime, /*开始时间*/
  @EndDate DateTime, /*结束时间*/
  @YID Int = 0, /*机构ID*/
  @YYID Int = 0, /*营业员  */
  @PTypeRange VarChar(1000) = '', /*商品类别*/
  @nloginEID int = 0     /*登陆职员*/
)      
 AS    
 
  Declare @Companytable INTEGER
  create table #Companytable([id] int)

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权 */
 
 
 
  /*根据传入的商品类别获取对应的PID，允许商品类别为空*/
  SELECT ISNULL(baseinfo_id, 0) pid INTO #TmpP FROM customCategoryMapping 
    WHERE deleted = 0 and BaseTypeid = 0 
      and category_id in (select type  from DecodeStr(@PTypeRange)) 
 
  SELECT identity(int, 1, 1) as RecNo, c.alias,c.makearea,c.name as pname,c.comment as comments, c.[standard], bf.AccountComment factory, d.name PUnit, cpy.name YName, 
         f.billdate as SaleDate, a.billdate, emp.name RMan, emp1.name SMan,  
         datediff(DD, f.billdate, a.billdate) as OutStoreDays, a.note as THReason, b.batchno, b.validdate, g.quantity as SaleQty, 
         g.taxtotal as SaleMoney, b.quantity, b.taxtotal retailtotal, b.costtaxtotal / (1 + b.taxrate) costtotal,  b.costtaxtotal, /*b.costtaxprice * b.quantity costtaxtotal, */
         (b.costtaxtotal - b.taxtotal) as MLLost, 
         (case IsNull(b.taxtotal, 0) when 0 then 0 else (b.costtaxtotal - b.taxtotal) * 100/ b.taxtotal end) as MLRate, 
         (case IsNull(g.quantity, 0) when 0 then 100 else (b.quantity * 100/ g.quantity) end) as THRate,                  
         e.name CName, Null as BuyerName,isnull(c.serial_number,'') as pcode
    INTO #QryResult
  /*FROM RetailBillidx a inner join retailbill b on a.billid = b.bill_id*/
  FROM billidx a inner join salemanagebill b on a.billid = b.bill_id
                       left join products c on b.p_id = c.product_id 
                       left join unit d on c.unit1_id = d.unit_id
                       left join clients e on b.supplier_id = e.client_id                       
                       left join salemanagebill g on g.smb_id = b.orgbillid /*原零售单明细*/
                       left join billidx f on g.bill_id = f.billid /*原零售单主表 */
                       left join employees emp on a.inputman = emp.emp_id 
                       left join employees emp1 on b.RowE_id = emp1.emp_id                       
                       left join basefactory bf on b.factoryid = bf.CommID  
                       left join company cpy on a.Y_ID = cpy.company_id                                      
  WHERE a.billtype = 13 
    AND a.billstates = 0 
    and b.p_id > 0
    AND a.billdate >= @BeginDate AND a.billdate < @EndDate
    and (@YID = 0 or a.Y_ID = @YID) and (@YYID = 0 or b.RowE_id = @YYID)   
    and ((@PTypeRange = '') or (b.p_id in (select pid from #TmpP))) 
    and ((@Companytable=0)or (b.Y_ID in (select [id] from #Companytable)))    
  
  IF object_id(N'#TmpP', N'U') is not null  
    DROP TABLE #TmpP

  SELECT * FROM #QryResult

  IF object_id(N'#QryResult', N'U') is not null  
    DROP TABLE #QryResult
GO
