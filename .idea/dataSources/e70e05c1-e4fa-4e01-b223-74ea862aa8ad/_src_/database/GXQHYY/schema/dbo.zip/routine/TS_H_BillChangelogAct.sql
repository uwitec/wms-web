
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-03-25*/
/* Description:	单据修改的申请、审核、查询操作*/
/* =============================================*/
CREATE PROCEDURE TS_H_BillChangelogAct 
	@Act		int = 0,	/* 0: 申请修改；1：审核；2；拒绝；3：待审核列表；4：检测是否可修改；5：直接反审核*/
	@BillID		int = 0,    /* BillID < 0 的为历史单据，用于处理红冲；其余为反审核*/
	@BillType	int = 0,
	@Eid		int = 0,
	@Reason		varchar(500) = '',
	@Ret		int = 0 OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	IF @Act IS NULL SET @Act = 0
	IF @BillID IS NULL SET @BillID = 0
	IF @BillType IS NULL SET @BillType = 0
	IF @Eid IS NULL SET @Eid = 0
	IF @Reason IS NULL SET @Reason = ''
	
	SET @Ret = -1
	IF @Act = 0
	BEGIN
		IF EXISTS(SELECT * FROM billChangelog WHERE billId = @BillID AND billType = @BillType AND status = 2)
			SET @Ret = -1
		ELSE
		BEGIN
			INSERT INTO billChangelog(billId, billType, requestMan, requestDate, modifyReason, status)
			VALUES(@BillID, @BillType, @Eid, GETDATE(), @Reason, 2)
			SET @Ret = 0
		END
	END
	ELSE
	IF @Act = 1
	BEGIN
		IF NOT EXISTS(SELECT * FROM billChangelog WHERE billId = @BillID AND billType = @BillType AND status = 2)
			SET @Ret = -1
		ELSE
		BEGIN
			SET @Ret = 0
			IF (@BillType IN (14, 22)) OR (@BillType BETWEEN 501 AND 599)
			BEGIN
				EXEC @Ret = TS_H_GspBillAct 2, @BillID, @BillType, @Eid, 1
			END
			else if @BillID < 0
			begin
				set @BillID = ABS(@BillID)
				exec ts_c_redword @BillID, @Ret output
				set @BillID = -@BillID
			end
			ELSE
				UPDATE billdraftidx SET auditdate = '1900-1-1', auditman = 0 WHERE billid = @BillID
			IF @Ret >= 0
			BEGIN
				UPDATE billChangelog SET replyMan = @Eid, replyDate = GETDATE(), status = 3
				WHERE billId = @BillID AND billType = @BillType AND status = 2
				SET @Ret = 0
			END
		END
	END
	ELSE
	IF @Act = 2
	BEGIN
		IF NOT EXISTS(SELECT * FROM billChangelog WHERE billId = @BillID AND billType = @BillType AND status = 2)
			SET @Ret = -1
		ELSE
		BEGIN
			UPDATE billChangelog SET replyMan = @Eid, replyDate = GETDATE(), status = 1
			WHERE billId = @BillID AND billType = @BillType AND status = 2
			SET @Ret = 0
		END
	END
	ELSE
	IF @Act = 3
	BEGIN
		SELECT     l.billId, l.billType, l.requestMan AS e_id, l.requestDate, l.modifyReason, e.name, 
					ISNULL(CASE WHEN l.billId < 0 THEN bi.billnumber
						WHEN l.billtype IN (22, 14) THEN o.billnumber 
						WHEN l.billtype BETWEEN 501 AND 599 THEN g.billnumber 
						ELSE i.billnumber END, '') AS billnumber, 
					ISNULL(v.Comment, '') AS Comment,
					ISNULL(CASE WHEN l.billId < 0 THEN bi.inputman
						WHEN l.billtype IN (22,26, 14) THEN o.inputman 
						WHEN l.billtype BETWEEN 501 AND 599 THEN g.InputMan 
						when l.billType = 52 then t.inputman 
						ELSE i.inputman END, '') AS inputman
		FROM         dbo.billChangelog AS l INNER JOIN
                      dbo.employees AS e ON l.requestMan = e.emp_id LEFT OUTER JOIN
                      dbo.VchType AS v ON l.billType = v.Vch_ID LEFT OUTER JOIN
                      dbo.GSPbillidx AS g ON l.billId = g.Gspbillid LEFT OUTER JOIN
                      dbo.orderidx AS o ON l.billId = o.billid LEFT OUTER JOIN
                      dbo.billdraftidx AS i ON l.billId = i.billid LEFT OUTER JOIN 
                      dbo.billidx AS bi ON l.billId = bi.billid LEFT OUTER JOIN 
					  tranidx as t on l.billId = t.billid
		WHERE L.status = 2
	END
	ELSE
	IF @Act = 4
	BEGIN
		IF EXISTS(SELECT * FROM billChangelog WHERE billId = @BillID AND billType = @BillType AND status = 2)
			SET @Ret = -1
		ELSE
			SET @Ret = 0
	END
	ELSE
	IF @Act = 5
	BEGIN
		IF EXISTS(SELECT * FROM billChangelog WHERE billId = @BillID AND billType = @BillType AND status = 2)
			SET @Ret = -1
		ELSE
		BEGIN
			INSERT INTO billChangelog(billId, billType, requestMan, requestDate, modifyReason, status, replyMan, replyDate)
			VALUES(@BillID, @BillType, @Eid, GETDATE(), @Reason, 3, @Eid, GETDATE())
			SET @Ret = @@IDENTITY
		END
	END
END
GO
