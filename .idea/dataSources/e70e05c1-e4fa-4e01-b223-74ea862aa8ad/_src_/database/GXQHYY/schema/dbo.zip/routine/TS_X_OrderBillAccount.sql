
/*查看采购单据的开票情况  
  xxx 2015-01-30
*/

create procedure TS_X_OrderBillAccount
( @nmode int = 0,  /*0表示单据，1表示明细*/
  @szbegindate varchar(20),  /*开始，结束时间*/
  @szenddate varchar(20),
  @Cclass_id varchar(30) = '', /*往来单位*/
  @jsflag varchar(30) = '',/*结算方式*/
  @OperatorID int              /*操作员id*/
)

as
begin
/*----------授权控制----------------------*/
declare @ClientTable int, @Companytable int,@employeestable int 
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/
/*----------授权控制结束-------------------*/

declare @c_id int
 
if @Cclass_id = '' 
  set @c_id = 0 
else
  select @c_id = client_id from clients where class_id = @Cclass_id      

if @nmode = 0
begin
	SELECT vw.eName as employeename,vw.*,isnull(iv.Total, 0) as OverTotal,(select Comment from VchType where Vch_ID = vw.billtype) as sbilltype,
	isnull(case when vw.[BILLTYPE] IN (11,13,21,24,25,211,221) THEN -vw.[YSMONEY] else vw.ysmoney end - isnull(iv.total, 0),0) as NoOverTotal,
	case iv.jsflag when 1 then '按单开票'  when 2 then '按行开票' else '未开票' end  as JsType 
	FROM vw_c_billidx as vw left join 
	(select sum(Case when 0 = inv.invoicebilltype then CurrTotal else -CurrTotal end) as Total, billid,max(inv.jsFlag) as jsflag 
	from invoice i LEFT JOIN invoiceidx inv ON inv.[id]=i.invoiceid where inv.states = 2 group by billid)
	 iv on vw.billid= iv.billid  
	 /*left join (select * from BillStates where SeachType = 'B') bs on vw.billid = bs.Bill_id*/
	 WHERE vw.billtype in (20,220,24,21,221,25,122,80,55,56,184,104) AND vw.billstates= 0 and 
		 (vw.billdate>= @szbegindate) and (vw.billdate<=@szenddate)  and (vw.c_id = @c_id or @c_id = 0) and 
		 (vw.jsflag='0' OR vw.jsflag= @jsflag or @jsflag = '') and /*vw.jsye<>0 and*/ (vw.eName like '%%') and vw.Y_id=2 
		 and vw.billid not in (select Bill_id from BillStates where SeachType = 'B' and [delete] = 0)
	 ORDER BY vw.billdate
end
else
begin
	SELECT * FROM 
	(
	SELECT P.NAME,P.STANDARD,P.MODAL ,P.MEDTYPE, p.medtype_id, P.MAKEAREA,p.Permitcode,p.trademark,
	  b.VALIDDate, b.quantity, b.taxprice, b.taxtotal, b.smb_id ,b.bill_id,  /*-as Detail_id*/
	  ISNULL((SELECT SUM(quantity) FROM jspdetail j WHERE j.billtype= idx.billtype and j.Flag =0 AND b.smb_ID = j.detail_id) ,0) AS CheckedQty,
	  b.unitid,
	  CASE b.unitid
	  WHEN p.unit1_id THEN 1
	  WHEN p.unit2_id THEN p.unitrate2
	  WHEN p.unit3_id THEN p.unitrate3
	  WHEN p.unit4_id THEN p.unitrate4
	  END AS unitrate,
	  CASE b.unitid
	  WHEN p.unit1_id THEN p.unit1
	  WHEN p.unit2_id THEN p.unit2
	  WHEN p.unit3_id THEN p.unit3
	  WHEN p.unit4_id THEN p.unit4
	  END AS unit,
	  e.Name as EmployeeName
	FROM vw_b_products p, BuyManageBill b , billidx idx , employees e
	WHERE  b.p_id = p.p_id AND idx.billid = b.bill_id /*-and b.aoid=0  */
	and e.emp_id=idx.e_id
	) AS DETAIL 
	WHERE abs(quantity)>=CheckedQty
	ORDER BY smb_id
end
       
end
GO
