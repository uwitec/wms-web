

/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-5-6*/
/* Description:	由智能配送生成相关单据*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_MakeBillByInteSend]
	@Act			int,				/* 操作 1. 生成采购计划 2. 生成配送单  3. 明细添加到缺货清单  4. 生成拣货单 5. 生成机构配送订单*/
	@TranIds		varchar(8000),		/* TranBill ID 列表  商品id的集合*/
	@TranIds2		varchar(8000),		/* TranBill ID 列表2*/
	@TranIds3		varchar(8000),		/* TranBill ID 列表3*/
	@TranIds4		varchar(8000),		/* TranBill ID 列表4*/
	@TranIds5		varchar(8000),		/* TranBill ID 列表5*/
	@TranIds6		varchar(8000),		/* TranBill ID 列表6*/
	@TranIds7		varchar(8000),		/* TranBill ID 列表7*/
	@TranIds8		varchar(8000),		/* TranBill ID 列表8*/
	@TranIds9		varchar(8000),		/* TranBill ID 列表9*/
	@TranIds10		varchar(8000),		/* TranBill ID 列表10*/
	@BillType		int = 0,			/* 单据类型，对应 Vch 中定义*/
	@Rule			int = 0,			/* 生成规则 1. 顺序分配 2. 平均分配 3. 按比例分配*/
	@SendBillSN		varchar(80) = '',	/* 配送单编号（已废弃）*/
	@TransferSN		varchar(80) = '',	/* 调拨单编号（已废弃）*/
	@EId			int = 0,			/* 操作员*/
	@Supplier		int = 0				/* 供应商*/
AS
BEGIN
/*Params Ini begin*/
if @BillType is null  SET @BillType = 0
if @Rule is null  SET @Rule = 0
if @SendBillSN is null  SET @SendBillSN = ''
if @TransferSN is null  SET @TransferSN = ''
if @EId is null  SET @EId = 0
if @Supplier is null  SET @Supplier = 0
/*Params Ini end*/
	SET NOCOUNT ON;
	
	/* 取系统设置中的机构配送价格方式*/
	declare @CostRate numeric(25,8)
	declare @nSendTaxPrice numeric(25,8)  /*含税单价*/
	declare @nSendTaxTotal numeric(25,8)	/*含税金额*/
	declare @nSendTaxMoney numeric(25,8)	/*税额*/
	 
	declare @CostType int, @nIncMode int
	select @CostType = sysvalue from sysconfig where sysname = 'CompanySendCostprice'
	if @CostType = 1
		set @CostRate = 1
	else
		set @CostRate = 0
	
	DECLARE @Ret int					/* 返回值*/
	DECLARE @WholeStorage varchar(10)	/* 整零库控制*/
	DECLARE @VchCode int				/* 单据 ID*/
	DECLARE @OrderVchCode int			/* 订单单据 ID*/
	DECLARE @Today varchar(10)			/* 当前日期*/
	DECLARE @WStorage int				/* 整货仓库*/
	DECLARE @SStorage int				/* 零货仓库*/
	DECLARE @ZBStorage  int				/* 总部仓库*/
	DECLARE @TaxRate numeric(25,8)		/* 税率*/
	DECLARE @TaxPercent numeric(3, 2)	/* 税率小数*/
	
	declare @iFor int
	declare @iDetailCount int
	
	/* 批次要素*/
	declare @iSid int
	declare @iSupplier int
	declare @nCost numeric(25,8)
	declare @sBatch varchar(80)
	declare @dtMake datetime
	declare @dtInstore datetime
	declare @dtValid datetime
	declare @iCommi int
	declare @iLoc int
	declare @iUnit int
	declare @iPYid int
	declare @sBatchCode varchar(30)
	declare @sScomment varchar(80)
	declare @nBatchPrice numeric(25,8)
	declare @nFactoryId int
	
	declare @nCostTaxPrice numeric(25,8)
	declare @nCostTaxRate numeric(25,8)
	declare @nCostTaxTotal numeric(25,8)
	
	declare @iAvlQty numeric(25,8)
	declare @sUnit varchar(50)
	declare @nPrice numeric(25,8)
	
	declare @iQty numeric(25,8)
	declare @iPid int
	declare @iSmb int
	declare @iGuid uniqueidentifier
	declare @sComment varchar(50)
			
	declare @nTotalMoney numeric(25,8)
	declare @nTaxPrice numeric(25,8)
	declare @nTaxTotal numeric(25,8)
	declare @nTaxMoney numeric(25,8)
	
	declare @nBillTotal numeric(25,8)
	declare @nBillQty numeric(25,8)
			
	declare @iYid int
	declare @iMDSid int
	declare @iLineCount int
	declare @iBillCount int
	declare @nSend_taxPrice numeric(25,8)
	declare @nSend_taxTotal numeric(25,8)
	declare @nSendPrice numeric(25,8)
	declare @nSendTotal numeric(25,8)
	
	declare @nRetailPrice numeric(25,8)
	declare @nRetailTotal numeric(25,8)
	declare @rp numeric(25,8) /*零售价*/
	declare @rt numeric(25,8) /*零售金额*/
	declare @ProductValidDay int /*商品近效期	*/
	declare @YID int /*机构ID*/
	declare @bUseSameTaxRate bit    /*是否启用统一税率*/
		
	select @WholeStorage = sysvalue from sysconfig where [sysname] = 'WholeStorage' and Y_ID = 2
	SET @Today = convert(varchar(10), getdate(), 120)	
	
	set @YID=2
	select @YID=sysvalue from sysconfig where sysname='Y_ID'
	if @YID=0 
		set @YID=2
	
	select @ZBStorage = sysvalue from sysconfig where sysname = 'CenterSID' and y_id =@YID    /*总部默认仓库取系统默认*/
	
	if @ZBStorage is null	
		select top 1 @ZBStorage = storage_id from storages where y_id = @YID and child_count = 0 and qualityFlag=0
	
	set @TaxRate = 0
	set @bUseSameTaxRate = 0
	set @TaxPercent = 0
	if exists (select 1 from sysconfig where sysname ='UseSameTaxRate' and sysvalue = '1') /*取统一税率*/
	begin
	    set @bUseSameTaxRate = 1
		select @TaxRate = sysvalue from sysconfig where [sysname] = 'TaxRate' and Y_ID = 0
		set @TaxPercent = @TaxRate / 100
	end
	if @Act in (1, 2, 4, 5)
	begin
		set @ZBStorage = ISNULL(@ZBStorage, -1)
		if @ZBStorage <= 0
		begin
			raiserror ('总部未设置仓库！', 16, 1)
			return -1
		end
	end
	
	/* 创建编号临时表*/
	declare @TempSQL varchar(8000)
	declare @iCharPos int
	create table #tmpId([id] int IDENTITY(1,1) NOT NULL, smb int)
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 2*/
	set @TranIds = @TranIds2
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 3*/
	set @TranIds = @TranIds3
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 4*/
	set @TranIds = @TranIds4
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 5*/
	set @TranIds = @TranIds5
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 6*/
	set @TranIds = @TranIds6
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 7*/
	set @TranIds = @TranIds7
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 8*/
	set @TranIds = @TranIds8
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 9*/
	set @TranIds = @TranIds9
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	/* 10*/
	set @TranIds = @TranIds10
	while Len(@TranIds) > 0
	begin
		set @TempSQL = SUBSTRING(@TranIds, 1, 500)
		set @TranIds = SUBSTRING(@TranIds, 501, 8000)
		set @iCharPos = CHARINDEX(',', @TranIds, 1)
		if @iCharPos <= 0
		begin
			set @TempSQL = @TempSQL + @TranIds
			set @TranIds = ''
		end
		else
		begin
			set @TempSQL = @TempSQL + SUBSTRING(@TranIds, 1, @iCharPos)
			set @TranIds = SUBSTRING(@Tranids, @iCharPos + 1, 8000)
			Set @TempSQL = SUBSTRING(@TempSQL, 1, LEN(@TempSQL) - 1)
		end
		set @TempSQL = replace(@TempSQL, ',', ' union all select ')
		exec ('insert into #tmpId(smb) select ' + @TempSQL)
	end
	
	/*获取机构商品近效期拦截天数*/
	 set @ProductValidDay=0
	 select @ProductValidDay=sysvalue from sysconfig where sysname ='ProductValidDay' and Y_ID=2
 	
	/* 将可开数量写入临时表*/
	SELECT * INTO #TMPAVLQTY FROM DBO.FN_GetAvlqty(0, 0, '', 0) 
		WHERE s_id IN (SELECT s_id FROM vw_avlSid) 
		and (validdate<10 or validdate>GETDATE()) AND storeQty > 0 		
		and DATEDIFF ( d , GETDATE(),case when validdate='1900-01-01 00:00:00.000' then '9999-01-01 00:00:00.000' else validdate end)>@ProductValidDay
		order by validdate asc
	
	if @Act in (1, 2, 3, 4, 5)  /*生成采购计划的时候不需要判断配送订单是否完成*/
	begin
		/*首先判断机构配送订单是否都已经完成，如果未完成不能再次生成 --生成采购计划不需要判断配送订单是否完成*/
		if @Act in (2, 3, 4, 5)  
			IF EXISTS(
				SELECT 0 FROM OrderBill B 
					INNER JOIN orderidx I ON B.bill_id = I.billid WHERE I.BillType = 154
					and orgbillid<>0 and I.billstates <> 0 and (orgbillid in (select smb from #tmpId)) 
					group by OrgBillid
					having SUM(b.quantity)-SUM(b.ComeQty)>0 ) 
			begin
				raiserror('机构配送订单还未完成，不能再次配货!', 16, 1)
				return -100
			end
		  
		/* 创建请货临时表*/
		SELECT     b.smb_id, b.p_id, b.quantity - ISNULL(PK.ComeQty, 0) AS qty, i.c_id,i.e_id,b.RowGuid, CAST(0 AS numeric(25,8)) AS total, CAST(0 AS numeric(25,8)) AS scale, MIN(s.storage_id) 
							  AS s_id, CAST(0 AS numeric(25,8)) AS sendQty
		INTO  #tmpList
		FROM         dbo.TranBill AS b INNER JOIN
							  dbo.TranIdx AS i ON b.bill_id = i.billid left JOIN
							  dbo.storages AS s ON i.c_id = s.Y_ID LEFT JOIN
							  (SELECT OrgBillid, SUM(b.quantity) AS Yqty,SUM(b.ComeQty) AS ComeQty FROM OrderBill B INNER JOIN orderidx I ON B.bill_id = I.billid WHERE I.BillType = 154
								AND I.billstates <> '2'
								GROUP BY OrgBillid) PK
							  ON B.smb_id = PK.OrgBillid
		WHERE     (isnull(s.child_number,0) = 0) AND (isnull(s.deleted,0) = 0) AND (s.WholeFlag <> 3) AND
		          (b.smb_id in (select smb from #tmpId)) AND (b.quantity - ISNULL(PK.ComeQty, 0) > 0 )
		GROUP BY b.smb_id, b.p_id, b.quantity - ISNULL(PK.ComeQty, 0), i.c_id, i.e_id, b.RowGuid, PK.OrgBillid, PK.Yqty

		if @Act in (2, 4, 5)
		/* 配送处理*/
		begin
			if @Rule = 1		/* 顺序配送，配送比例为 1*/
				update #tmpList set scale = 1
			else
			if @Rule = 2		/* 平均分配，按请货门店数分配*/
			begin
				update #tmpList set total = (select count(0) from #tmpList a where a.p_id = #tmpList.p_id)
				update #tmpList set scale = cast(1 as numeric(25,8)) / total
			end
			else
			if @Rule = 3		/* 比例分配，按商品请货数量分配*/
			begin
				update #tmpList set total = (select sum(qty) from #tmpList a where a.p_id = #tmpList.p_id)
				update #tmpList set scale = cast(qty as numeric(25,8)) / total
			end
			
			/* 去掉无库存商品*/
			delete from #tmpList where total is null
			
			/* 创建请货门店列表*/
			SELECT c_id, s_id INTO #tmpCompany FROM #tmpList group by c_id, s_id

			/* 判断数据有效性*/
			IF NOT EXISTS(SELECT * FROM #tmpList)
				RETURN -5
			IF NOT EXISTS(SELECT * FROM #tmpCompany)
				RETURN -3
			IF EXISTS(SELECT * FROM #tmpCompany WHERE s_id IS NULL)
				RETURN -3
			IF EXISTS(SELECT * FROM company WHERE company_id IN(SELECT c_id FROM #tmpCompany) AND sendBillType = -1)
				RETURN -4
		end
		
		/* 取得可开数量*/
		if  @Act in (2, 3, 4, 5)
		begin
			update #tmpList set total = X.QTY
			FROM
			(SELECT SUM(quantity) AS QTY, p_id FROM #TMPAVLQTY WHERE Y_ID = 2 AND s_id IN(SELECT storage_id FROM storages WHERE flag = 0)
				GROUP BY p_id) X
			WHERE X.p_id = #tmpList.p_id
		end
		else if @Act in (1)  /*在生成采购计划的时候取库存数量*/
		begin
			update #tmpList set total = X.QTY
			FROM
			(SELECT SUM(quantity) AS QTY, p_id FROM storehouse WHERE Y_ID = 2 AND s_id IN(SELECT storage_id FROM storages WHERE flag = 0)
				GROUP BY p_id) X
			WHERE X.p_id = #tmpList.p_id		  
		end

		/*SELECT * FROM #tmpList*/
		
		if @Act in (2, 4, 5)
		begin
			/* 更新实际可配送数量*/
			IF @Rule > 1
				update #tmpList set sendQty = FLOOR(scale * total)
			ELSE
				UPDATE #tmpList SET sendQty = scale * total
			/* 判断数据有效性*/
			IF NOT EXISTS(SELECT * FROM #tmpList WHERE sendQty > 0)
				RETURN -5
			
			/* 整零库控制*/
			if @WholeStorage = '1'
			begin
				/* 整货仓库*/
				SELECT     storage_id
				INTO      #tmpWStore
				FROM         dbo.storages
				WHERE     (deleted = 0) AND (flag = 0) AND (Y_ID = 2) AND (WholeFlag = 1) AND (child_number = 0)

				select top 1 @WStorage = storage_id from #tmpWStore

				/* 零货仓库*/
				SELECT     storage_id
				INTO      #tmpSStore
				FROM         dbo.storages
				WHERE     (deleted = 0) AND (flag = 0) AND (Y_ID = 2) AND (WholeFlag <> 1) AND (child_number = 0)
				
				select top 1 @SStorage = storage_id from #tmpSStore
				
				/* 统计可请货数量*/
				select p_id, sum(qty) as qty, cast(0 as numeric(25,8)) as splitQty, cast(0 as numeric(25,8)) as wholeQty
				into #tmpStore
				from #tmpList
				group by p_id
				
				/* 取得需拆零数量*/
				update #tmpStore set splitQty = qty - (select sum(quantity) from #TMPAVLQTY where s_id in
				(select storage_id from #tmpSStore) and #TMPAVLQTY.p_id = #tmpStore.p_id),
				#tmpStore.wholeqty = (select CASE WHEN wholeunit_id > 0 AND wholeunit_id = unit2_id THEN rate2 WHEN wholeunit_id > 0 AND 
				wholeunit_id = unit3_id THEN rate3 WHEN wholeunit_id > 0 AND wholeunit_id = unit4_id THEN rate4 ELSE 1 END
				FROM #TMPAVLQTY INNER JOIN
				dbo.products ON dbo.#tmpStore.p_id = dbo.products.product_id
				where #tmpStore.p_id = products.product_id
				group by product_id, rate2, wholeunit_id, rate3, rate4, unit2_id, unit3_id, unit4_id)
				
				update #tmpStore set splitQty = qty where splitQty is null
				
				update #tmpStore set splitqty = ceiling(splitqty / wholeqty) * wholeqty
				
				/* 取得可拆零数量*/
				/* 这一段貌似有问题，后面来改*/
				update #tmpStore set wholeQty = (select quantity from #TMPAVLQTY where s_id in
				(select storage_id from #tmpWStore) and #TMPAVLQTY.p_id = #tmpStore.p_id)
				
				/* 去掉无效数据*/
				delete from #tmpStore where wholeQty is null
				
				update #tmpStore set qty = case when splitqty < wholeqty then splitqty else wholeqty end
				
				delete from #tmpStore where qty <= 0
				
				/* 生成同价调拨单*/
				if exists(select 0 from #tmpStore where qty > 0)
				begin
					exec TS_H_CreateBillSN 44, 1, null, @EId, @EId, @TransferSN output, 2
					
					exec ts_b_insertbillindexdraft @VchCode output, 0, 2, 0, @Today, @TransferSN, 44, 0, 0,
						@EId, @Wstorage, @SStorage, @Eid, @Eid, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, ' ',
						'【由智能配货生成】', '', 0, '', 0, 0, 0, 0, 0, default, default, default, default, default,
						default, 2
						
					declare curSplit scroll cursor for
					select p_id, qty from #tmpStore
					open curSplit
					
					set @iLineCount = 0
					set @iFor = 0
					while @iFor < @@cursor_rows
					begin
						fetch next from curSplit into @iPid, @iQty
						while @iQty > 0
						begin
							set @iAvlQty = -1
						
							SELECT     @nCost = a.costprice, @dtMake = a.makedate, @dtValid = a.validdate, 
								@iLoc = a.location_id, @iSupplier = a.supplier_id, @iCommi = a.commissionflag, 
								@dtInstore = a.instoretime, @iSid = a.s_id, @sBatch = a.batchno, @iAvlQty = a.quantity - ISNULL(b_1.qty, 0),
								@iUnit = unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
								@nBatchPrice = a.batchprice, @nFactoryId = a.factoryid, @nCostTaxPrice = a.costtaxprice, 
								@nCostTaxRate = a.costtaxrate, @nCostTaxTotal = a.costtaxtotal 
							FROM         #TMPAVLQTY AS a INNER JOIN
												  dbo.products AS p ON a.p_id = p.product_id LEFT OUTER JOIN
													  (SELECT     b.p_id, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, b.commissionflag, b.instoretime, b.ss_id, b.batchno, 
																			   SUM(b.quantity) AS qty
														FROM          dbo.billdraftidx AS i INNER JOIN
																			   dbo.storemanagebilldrf AS b ON i.billid = b.bill_id
														WHERE      (i.billtype = 44)
														GROUP BY b.p_id, b.costprice, b.makedate, b.validdate, b.location_id, b.supplier_id, b.commissionflag, b.instoretime, b.ss_id, b.batchno) AS b_1 ON
												   a.batchno = b_1.batchno AND a.s_id = b_1.ss_id AND a.instoretime = b_1.instoretime AND a.commissionflag = b_1.commissionflag AND 
												  a.supplier_id = b_1.supplier_id AND a.location_id = b_1.location_id AND a.validdate = b_1.validdate AND a.makedate = b_1.makedate AND 
												  a.costprice = b_1.costprice AND a.p_id = b_1.p_id
							WHERE a.s_id in (select storage_id from #tmpWStore) and a.p_id = @iPid 
								and a.quantity - ISNULL(b_1.qty, 0) > 0
							ORDER BY a.validdate
							
							if @iAvlQty > 0
							begin
								if @iQty < @iAvlQty
									set @iAvlQty = @iQty
								set @iQty = @iQty - @iAvlQty
								if @iAvlQty > 0
								begin
									set @nTotalMoney = @iAvlQty * @nCost
									set @nTaxMoney = @nCost * @TaxRate / 100
									set @nTaxPrice = @nCost + @nTaxMoney
									set @nTaxTotal = @nTaxPrice * @iAvlQty
									SET @nCostTaxTotal = @nCostTaxRate * @iAvlQty
									set @iGuid = newid()
									set @sComment = dbo.GetProductComment(@iPid, @iAvlQty)
									exec ts_b_insertbilldetaildraft @Ret output, 2, 0, @VchCode, 0, @iPid, @sBatch, @iAvlQty,
										@nCost, @nCost, @nTotalMoney, 1, @nCost, @nTotalMoney, @nTaxPrice, @nTaxTotal,
										@nTaxMoney, 0, 0, @dtMake, @dtValid, '合格', 2, @iSid, @SStorage, 0, @iLoc, @iSupplier,
										@iCommi, @sComment, @iUnit, 0, 0, 0, 0, 0, 0, default, default, default, default, default, default,
										@iGuid, default, '0', @iPYid, @dtInstore, 0, '', @sScomment, @nBatchPrice, @sBatchCode, @iGuid, '', '', @nFactoryId,
										@nCostTaxRate, @nCostTaxPrice, @nCostTaxTotal
									set @iLineCount = @iLineCount + 1
								end
							end
							else
								set @iQty = 0
						end
						set @iFor = @iFor + 1
					end
					DEALLOCATE curSplit
					if @iLineCount > 0
					begin
						exec TS_c_BillAudit @VchCode, @iPid output, @Ret output, 44
						if @Ret <> 0
						begin
							select @VchCode, @iPid, @Ret
							raiserror('商品拆零失败！', 16, 1)
							return -2
						end
						/*update BillSNStyle set SNCount = SNCount + 1 where billtype = 44 and Y_ID=0*/
					end
					else
						delete from billdraftidx where billid = @vchCode
				end
			end
		end
		else
		if @Act = 1
			/* 更新采购数量*/
			update #tmpList set sendQty = qty - isnull(total, 0)
		
		if @Act = 3  /*-插入缺货明细 add by luowei 2012-08-17*/
		BEGIN
		  insert into OOSCatalog(ProductId,CompanyId,ClientId,EId,OOSQty,PlanQty,Deleted,InputManId,GUID)
		  select  p_id,c_id,c_id,e_id,QTY,0,0,@EId,RowGuid 
		  from
		      (
		        select t.p_id,t.c_id,t.e_id,(isnull(t.qty,0)  - isnull(md.qty,0)) as Qty,t.RowGuid from #tmpList t
		        left outer join
				  (SELECT     SUM(h.quantity) AS qty, h.p_id
								FROM          dbo.FN_GetAvlqty(0, 0, '', 0) AS h INNER JOIN
													   dbo.storages AS r ON h.s_id = r.storage_id
								WHERE      (r.flag = 0) AND (r.Y_ID = 2) and h.storeQty > 0 and r.WholeFlag<>3/*zjx--tfs45072--2017-01-18--缺货登记剔除拆零商品*/
								GROUP BY h.p_id
				  ) AS md on t.p_id = md.p_id
				where (isnull(t.qty,0) -isnull(md.qty,0)) > 0
				  
		      ) tt
		  IF @@ROWCOUNT=0/*zjx--tfs44827--2017-01-09--处理如果当请货数量小于可开数量的时候不会写入登记表，所以不应该提示登记成功*/
		     return  0
		  else
		     return  @billtype
		    
		END 	
	end
	
	IF @Act = 1
	/* 生成采购计划*/
	BEGIN
		exec TS_H_CreateBillSN 26, 1, null, @EId, @EId, @SendBillSN output, 2
		
		exec ts_b_insertbillindexdraft @VchCode output, 0, 4, 0, @Today, @SendBillSN, 26, 0, @Supplier,
			@EId, 0, 0, 0, @Eid, 0, 0, 0, @TaxRate, 0, 2, 0, 0, 2, 0, 0, 0, 0, ' ',
			'【由智能配货生成】', '', 0, '', 0, 0, 0, 0, 0, default, default, default, default, default,
			default, 2
			
		/*select * from #tmpList*/
		select a.c_id,a.p_id,a.unit_id,a.buyprice,a.ModifyDate,a.quantity,a.billtype,a.Y_ID,a.E_id,a.discount,a.discountprice,a.taxrate,a.taxprice
		into #buypricehistmp  
		from buypricehis a inner join products b on a.p_id=b.product_id and a.unit_id=b.unit1_id
	    	where a.p_id in(select p_id from #tmpList) and a.Y_ID = 2
		declare curBuyPlan scroll cursor for
		SELECT     l.p_id, SUM(l.sendQty) AS sendQty, p.unit1_id, cast(isnull(h.BuyPrice, 0) as numeric(25,8)), u.name
		FROM         #tmpList AS l INNER JOIN
                      dbo.products AS p ON l.p_id = p.product_id INNER JOIN
                      dbo.unit AS u ON p.unit1_id = u.unit_id LEFT OUTER JOIN
					(select p_id, unit_id, min(BuyPrice) as BuyPrice from #buypricehistmp 
						group by p_id, unit_id) h ON p.unit1_id = h.unit_id AND p.product_id = h.p_id
		where    l.sendQty >= 0
		GROUP BY l.p_id, p.unit1_id, cast(isnull(h.BuyPrice, 0) as numeric(25,8)), u.name
   		open curBuyPlan

		set @iFor = 0
		
		if @@cursor_rows <= 0 
		begin
		  DEALLOCATE curBuyPlan
		  return -999      /*表示可生成采购计划的数量为0*/
		end  
		
		while @iFor < @@cursor_rows
		begin
			fetch next from curBuyPlan into @iPid, @iQty, @iUnit, @nPrice, @sUnit
			set @nTotalMoney = @iQty * @nPrice
			set @nTaxMoney = @nPrice * @TaxRate / 100
			set @nTaxPrice = @nPrice + @nTaxMoney
			set @nTaxTotal = @nTaxPrice * @iQty
			
			set @iGuid = newid()
			set @sComment = dbo.GetProductComment(@iPid, @iQty)
			
			/*把零售价和零售金额传入，存入orderbill表中*/
		    select @rp = retailprice,@nFactoryId = p.factoryc_id,    /*读取生产厂家*/
				 @TaxPercent =(case when @bUseSameTaxRate = 1 then @TaxRate/ 100 else convert(numeric(25,8), r.name)/ 100 end)  /*读取税率*/
		     from products p left join price pr on p.product_id=pr.p_id 
		           left join  CustomCategory r on p.TaxRate=r.id
			  where p.product_id = @iPid
			  
			 if @rp is null set @rp = 0   /*剔除有可能在price表中没数据的情况*/
			select @rt = @rp * @iQty  
			
			exec ts_b_insertbilldetaildraft @Ret output, 4, 0, @VchCode, 0, @iPid, '', @iQty,
				@nPrice, @nPrice, @nTotalMoney, 1, @nPrice, @nTotalMoney, @nTaxPrice, @nTaxTotal,
				@nTaxMoney, @rp, @rt, 0, 0, '合格', 0, 0, 0, 0, 0, @Supplier,
				0, @sComment, @iUnit, @TaxPercent, 0, 0, 0, 0, 0, default, default, default, default, default, default,			
				@iGuid, default, '0', 2, default, default, default, default, default, default,default,default,default,
				@nFactoryId,@TaxPercent,@nTaxPrice,@nTaxTotal
			set @iFor = @iFor + 1
		end
		DEALLOCATE curBuyPlan
		
		if @iFor = 0
		  return 0
		else
		 return @VchCode
	END
	ELSE
	IF @Act = 2
	BEGIN
		set @iBillCount = 0
		while 1 > 0
		begin
			set @iYid = -1
			select top 1 @iYid = c_id, @iMDSid = s_id from #tmpCompany
			if @iYid < 0
				return @iBillCount
			
			if @CostType = 2
			begin
				select @CostRate = case IncRate when 0 then 1 else IncRate end from company where company_id = @iYid
			end
			
			exec TS_H_CreateBillSN @BillType, 1, null, @EId, @EId, @SendBillSN output, 2
			
			exec ts_b_insertbillindexdraft @VchCode output, 0, 1, 0, @Today, @SendBillSN, @BillType, 0, @iYid,
				@EId, @ZBStorage, @iMDSid, 0, @Eid, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, ' ',
				'【由智能配货生成】', '', 0, '', 0, 0, 0, 0, 0, default, default, default, default, default,
				default, 2
			if @VchCode = -1
			begin
				raiserror('保存草稿出错！', 16, 1)
				return -100
			end
			
			declare curSend scroll cursor for
			select p_id, case when qty < sendQty then qty else sendQty end, smb_id from #tmpList where c_id = @iYid
			open curSend
			
			set @nBillTotal = 0
			set @nBillQty = 0
			set @iFor = 0
			set @iLineCount = 0
			
			while @iFor < @@cursor_rows
			begin
				fetch next from curSend into @iPid, @iQty, @iSmb
				
				while @iQty > 0
				begin
					set @iAvlQty = -1
					if @WholeStorage = '1'
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0)
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 AND a.s_id IN (select storage_id from #tmpSStore)
						ORDER BY a.validdate, a.instoretime
					end
					else
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0)
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 
							AND (a.s_id IN (select storage_id from storages where y_id = 2 and flag = 0))
						ORDER BY a.validdate, a.instoretime
					end

					if @iAvlQty > 0
					begin
						if @iQty < @iAvlQty
							set @iAvlQty = @iQty
						set @iQty = @iQty - @iAvlQty
						if @iAvlQty > 0
						begin
							UPDATE #TMPAVLQTY SET quantity = quantity - @iAvlQty
							WHERE p_id = @iPid AND s_id = @iSid AND location_id = @iLoc AND supplier_id = @iSupplier
								AND costprice = @nCost AND batchno = @sBatch AND makedate = @dtMake AND instoretime = @dtInstore
								AND validdate = @dtValid AND commissionflag = @iCommi AND Y_ID = @iPYid
						   /*取初装货位*/
						    declare @nLoc2ID int, @nInSid int
						    set @nLoc2ID = 0
						    set @nInSid = @iMDSid
						    if exists(select 1 from sysconfig where [sysname] = 'InStorageTra' and sysvalue = 1) and (@BillType =150 or @BillType =152) 
						    begin						      
						       select top 1 @nLoc2ID=l_id from LocationTrace where p_id = @iPid and s_id = @iMDSid and Y_ID = @iYid order by rectime desc						    
						       set @nLoc2ID = ISNULL(@nLoc2ID, 0)
						       set @nInSid = @iMDSid
						    end
						    						    
							/*set @iAvlQty = CEILING(@iAvlQty)*/
							set @iGuid = newid()
							set @sComment = dbo.GetProductComment(@iPid, @iAvlQty)
							/*读取商品加价率*/
							if @CostType = 3
							begin
							  select @nIncMode = incRateMode from company where company_id=@iYid
							  select @CostRate = Case @nIncMode when 1 then incRate when 2 then incRate2
													 when 3 then incRate3  else 1 end    
							   from products where product_id = @iPid 
							  if @CostRate = 0 set @CostRate = 1							  							   				              				              
							end													
							set @nSendPrice = @nCost * @CostRate
							set @nSendTotal = @nSendPrice * @iAvlQty
							set @nRetailTotal = @nRetailPrice * @iAvlQty
							exec ts_b_insertbilldetaildraft @Ret output, 1, 0, @VchCode, 0, @iPid, @sBatch, @iAvlQty,
								@nCost, @nSendPrice, @nSendTotal, 1, @nSendPrice, @nSendTotal, @nSendPrice, @nSendTotal,
								0, @nRetailPrice, @nRetailTotal, @dtMake, @dtValid, '', 0, @iSid, @nInSid, @iSmb, @iLoc, @iSupplier,
								@iCommi, @sComment, @iUnit, 0, @nLoc2ID, 0, 0, @iSmb, 0, default, default, default, default, default, default,
								@iGuid, default, '0', @iPYid, @dtInstore, 0, '', @sScomment, @nBatchPrice, @sBatchCode
							set @iLineCount = @iLineCount + 1
							set @nBillTotal = @nBillTotal + @nSendTotal
							set @nBillQty = @nBillQty + @iAvlQty
						end
					end
					else
						set @iQty = 0
				end
				set @iFor = @iFor + 1
			end
			DEALLOCATE curSend
			update billdraftidx set ysmoney = @nBillTotal, quantity = @nBillQty where billid = @vchCode
			if @iLineCount = 0
				delete from billdraftidx where billid = @vchCode
			else
				set @iBillCount = @iBillCount + 1
			delete from #tmpCompany where c_id = @iYid
		end
		return @iBillCount
	END
	ELSE
	IF @Act IN (4, 5)
	/* 生成拣货单、机构配送订单（生成拣货单同时生成订单）*/
	BEGIN
		DECLARE @nSendBillType int
		set @iBillCount = 0
		set @iGuid = newid()
		while 1 > 0
		begin
			set @iYid = -1
			select top 1 @iYid = c_id, @iMDSid = s_id from #tmpCompany
			if @iYid < 0
				return @iBillCount
			
			if @CostType = 2
			begin
				select @CostRate = case IncRate when 0 then 1 else IncRate end from company where company_id = @iYid
			end

			SELECT @nSendBillType = sendBillType FROM company WHERE company_id = @iYid

			/*取本机构的公司名称*/
			declare @TrafficCompany varchar(200) 
			declare @L int
			SET @TrafficCompany = ''
			SELECT @TrafficCompany = comment FROM SysConfig WHERE SysName='CompanyName'
			set @L = CHARINDEX('公司全名',@TrafficCompany)
			set @TrafficCompany = SUBSTRING(@TrafficCompany,@L + LEN('公司全名'),LEN(@TrafficCompany))
			set @TrafficCompany = SUBSTRING(@TrafficCompany,1,CHARINDEX('',@TrafficCompany)-1)

			/* 首先生成机构配送订单*/
			exec TS_H_CreateBillSN 154, 1, null, @EId, @EId, @SendBillSN output, 2

			INSERT INTO orderidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
                taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
                invoice, InvoiceTotal, InvoiceNO, BusinessType, Guid, Y_ID, WT_ID, OrderValidDate, GatheringMan, TrafficCompany, 
                TrafficType, SendTime, SendC_ID)
			VALUES(CONVERT(VARCHAR(10), GETDATE(), 120), @SendBillSN, 154, 0, @iYid, @EId, @ZBStorage, @iMDSid, 0, @EId, 0, 0, 0,
				0, 0, 2, 0, 0, 0, 0, '1900-1-1', '1900-1-1', 0, ' ', '【由智能配货生成】', '',
				0, 0, '', @nSendBillType, @iGuid, 2, 0, '1900-1-1', 0, @TrafficCompany,
				'企业配送', '1900-1-1', 0)
			/*exec Ts_b_InsertBillIndexDraft @OrderVchCode output, 0, 1, 0, @Today, @SendBillSN, 154, 0, @iYid,*/
			/*	@EId, @ZBStorage, @iMDSid, 0, @Eid, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, ' ',*/
			/*	'【由智能配货生成】', '', 0, '', 0, 0, 0, 0, 0, default, default, default, default, default,*/
			/*	default, 2*/
			SET @OrderVchCode = @@IDENTITY
			IF @OrderVchCode = -1
			begin
				raiserror('保存草稿出错！', 16, 1)
				return -100
			end

			/* 生成拣货单*/
			IF @Act = 4
			BEGIN
				exec TS_H_CreateBillSN 541, 1, null, @EId, @EId, @SendBillSN output, 2

				INSERT INTO GSPbillidx(BillType, BillNumber, Y_id, C_id, S_id, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, 
					UpauditMan1, UpauditMan2, WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
					GUID, BillStates, B_CustomName1, B_CustomName2, B_CustomName3, B_CustomName4, B_CustomName5, 
					Note,TrafficType,TrafficCompany,YE_Id)
				VALUES(541, @SendBillSN, 2, @iYid, @ZBStorage, GETDATE(), @EId, 0, '1900-1-1', 0, '1900-1-1',
					@EId, 0, 0, 0, 0, 0, @OrderVchCode, CASE @nSendBillType WHEN 1 THEN 150 ELSE 152 END, @iGuid,
					NEWID(), 10, '', '', '', '', '', '【由智能配货生成】','企业配送',@TrafficCompany,@EId)

				set @VchCode = @@IDENTITY
			
				if @VchCode = -1
				begin
					DELETE FROM orderidx WHERE billid = @OrderVchCode
					raiserror('保存单据出错！', 16, 1)
					return -100
				end
			END

			declare @uGuid uniqueidentifier
			declare @iTranQty numeric(25,8)
			
			declare curSend scroll cursor for
			select p_id, isnull(case when qty < sendQty then qty else sendQty END, 0) AS iqty, smb_id, RowGuid, qty from #tmpList where c_id = @iYid
			open curSend
			
			set @nBillTotal = 0
			set @nBillQty = 0
			set @iFor = 0
			set @iLineCount = 0
			
			while @iFor < @@cursor_rows
			begin
				fetch next from curSend into @iPid, @iQty, @iSmb, @uGuid, @iTranQty
				
				while @iQty > 0
				begin
					set @iAvlQty = -1
					if @WholeStorage = '1'
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0),
							@TaxPercent =( case when @bUseSameTaxRate = 1 then @TaxRate/ 100 else convert(numeric(25,8), r.name)/ 100 end),@nFactoryId=a.factoryid,@nCostTaxPrice=a.costtaxprice,
							@nCostTaxRate=a.costtaxrate,@nCostTaxTotal=a.costtaxtotal
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
					    left join  CustomCategory r on p.TaxRate=r.id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 AND a.s_id IN (select storage_id from #tmpSStore)
						ORDER BY a.validdate, a.instoretime
					end
					else
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0),
							@TaxPercent =( case when @bUseSameTaxRate = 1 then @TaxRate/ 100 else convert(numeric(25,8), r.name)/ 100 end),@nFactoryId=a.factoryid,@nCostTaxPrice=a.costtaxprice,
							@nCostTaxRate=a.costtaxrate,@nCostTaxTotal=a.costtaxtotal
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
						left join  customCategory r on p.TaxRate=r.id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 
							AND (a.s_id IN (select storage_id from storages where y_id = 2 and flag = 0))
						ORDER BY a.validdate, a.instoretime
					end

					if @iAvlQty > 0
					begin
						if @iQty < @iAvlQty
							set @iAvlQty = @iQty
						set @iQty = @iQty - @iAvlQty
						if @iAvlQty > 0
						begin
							UPDATE #TMPAVLQTY SET quantity = quantity - @iAvlQty
							WHERE p_id = @iPid AND s_id = @iSid AND location_id = @iLoc AND supplier_id = @iSupplier
								AND costprice = @nCost AND batchno = @sBatch AND makedate = @dtMake AND instoretime = @dtInstore
								AND validdate = @dtValid AND commissionflag = @iCommi AND Y_ID = @iPYid and factoryid=@nFactoryId
								and costtaxprice=@nCostTaxPrice and costtaxrate=@nCostTaxRate and costtaxtotal=@nCostTaxTotal
							/*set @iAvlQty = CEILING(@iAvlQty)*/
							set @iGuid = newid()
							set @sComment = dbo.GetProductComment(@iPid, @iAvlQty)
							/*读取商品加价率*/
							if @CostType = 3
							begin
								select @nIncMode = incRateMode from company where company_id=@iYid
								select @CostRate = Case @nIncMode when 1 then incRate when 2 then incRate2
														when 3 then incRate3  else 1 end    
								from products where product_id = @iPid 
								if @CostRate = 0 
									set @CostRate = 1							  							   				              				              
							end		
							/*录单时选择*/
							if @CostType = 0
							begin
							    DECLARE @SendPriceType INT
							    SELECT @SendPriceType = SendPriceType FROM company WHERE company_id = @iYid
							    select @nSendPrice = (Case @SendPriceType WHEN 0 THEN 0 WHEN 1 THEN PRICE1 WHEN 2 THEN PRICE2 WHEN 3 THEN PRICE3 WHEN 4 THEN PRICE4 
							                                            WHEN 5 THEN gpprice WHEN 6 THEN glprice WHEN 7 THEN specialprice WHEN 8 THEN lastprice 
							                                            WHEN 9 THEN retailprice WHEN 10 THEN @nCost 
							                         END) 
							    FROM PRICE WHERE p_id = @iPid
							    
							    set @nSendTotal = @nSendPrice * @iAvlQty
								set @nRetailTotal = @nRetailPrice * @iAvlQty
								set @TaxPercent =ISNULL(@TaxPercent,0)
							    set	@nSendTaxPrice = convert(numeric(18,4 ),@nSendPrice *(1 +@TaxPercent))
						        set @nSendTaxTotal = convert(numeric(18,4 ),@nSendTotal*(1+ @TaxPercent))
							    set @nSendTaxMoney = convert( numeric(18,4 ),@nSendTotal * @TaxPercent)
							    set @nCostTaxTotal =@iAvlQty*@nCostTaxPrice
							end
							else	
							/*ZJX--TFS42388---2016-11-02--处理小数位数不用算直接取*/
							begin	
							    set @nSendPrice = @nCost * @CostRate
							    set @nSendTotal =     @nSendPrice * @iAvlQty																										
							    set @nSend_taxPrice = @nCostTaxPrice * @CostRate
							    set @nSend_taxTotal = @nSend_taxPrice * @iAvlQty
								set @nRetailTotal = @nRetailPrice * @iAvlQty
								set @TaxPercent =ISNULL(@TaxPercent,0)
							   	set @nSendTaxPrice = convert(numeric(18,4 ),@nSend_taxPrice)
						    	set @nSendTaxTotal = convert(numeric(18,4 ),@nSend_taxTotal)
							    set @nSendTaxMoney = convert( numeric(18,4 ),@nSendTotal * @TaxPercent)
							    set @nCostTaxTotal =@iAvlQty*@nCostTaxPrice
							end
							
							declare @bCold bit
							declare @bSpecial bit
							select @bCold = Iscold, @bSpecial = Isspec from vw_Products where product_id = @iPid


							/* 取初装货位*/
						    set @nLoc2ID = 0
						    set @nInSid = @iMDSid
						    if exists(select 1 from sysconfig where [sysname] = 'InStorageTra' and sysvalue = 1) and (@BillType =150 or @BillType =152) 
						    begin						      
						       select top 1 @nLoc2ID=l_id from LocationTrace where p_id = @iPid and s_id = @iMDSid and Y_ID = @iYid order by rectime desc						    
						       set @nLoc2ID = ISNULL(@nLoc2ID, 0)
						       set @nInSid = @iMDSid
						    end

							/* 写入订单明细*/
							exec ts_b_insertbilldetaildraft @Ret output, 4, 0, @OrderVchCode, 0, @iPid, @sBatch, @iAvlQty,
								@nCost, @nSendPrice, @nSendTotal, 1, @nSendPrice, @nSendTotal, @nSendTaxPrice ,@nSendTaxTotal,
								@nSendTaxMoney, @nRetailPrice, @nRetailTotal, @dtMake, @dtValid, '', 0, @iSid, @nInSid, @iSmb, @iLoc, @iSupplier,
								@iCommi, @sComment, @iUnit, @TaxPercent, @nLoc2ID, 0, 0, @iSmb, 0, default, default, default, default, default, default,
								@iGuid, default, '0', @iPYid, @dtInstore, 0, '', @sScomment, @nBatchPrice, @sBatchCode,@iGuid,'','',@nFactoryId,@nCostTaxRate,@nCostTaxPrice,@nCostTaxTotal
                            if @@IDENTITY>0 /*zjx--2016-12-06--（科开问题）订单明细没有商品，但拣货单明细有商品，导致拣货单保存拣货数量不能大于订单数量错误*/
                            begin 
								/* 写入拣货单明细 */
								IF @Act = 4
								BEGIN
								   /*由于触发器insOrderdrf 导致@@IDENTITY的取值不是想要的值，所以这儿重新去取*/
								   declare @smb_id int
								   set @smb_id = 0
								   SELECT TOP 1 @smb_id = smb_id FROM OrderBill WHERE bill_id = @OrderVchCode ORDER BY smb_id DESC
									
									INSERT INTO GSPbilldetail(Gspbill_id, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, 
										RefuseQty, PickQty, CheckQty, SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, 
										Pricediscrepancy, Total, Discount, DiscountTotal, TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, 
										RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept, CheckReport, ReturnReason, CheckState, 
										CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode, Batchcomment, BatchPrice, 
										Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2, 
										Comment3,factoryid,costtaxprice,costtaxrate,costtaxtotal
										)
									VALUES(@VchCode, @iPid, @dtMake, @dtValid, @sBatch, @iUnit, @iAvlQty, @iTranQty, 0, @iAvlQty,
										0, @iAvlQty, 0, 0, 0, 0, @nSendPrice, @nSendPrice, @nSendPrice, @nSendTaxPrice,
										0, @nSendTotal, 1, @nSendTotal, @TaxPercent, @nSendTaxMoney, @nSendTaxTotal, @nCost, @nCost * @iAvlQty, '',
										'', '', '', '', '', '', 0,
										'', @iSid, @iLoc, @iSupplier, @dtInstore, @iAvlQty, @sBatchCode, @sScomment, @nBatchPrice,
										@bCold, @bSpecial, @iPYid, 0, 0, @smb_id, @uGuid, @iCommi, NEWID(), @sComment, '', '',
										@nFactoryId,@nCostTaxPrice,@nCostTaxRate,@nCostTaxTotal
									)
								END
								set @iLineCount = @iLineCount + 1
								set @nBillTotal = @nBillTotal + @nSendTaxTotal
								set @nBillQty = @nBillQty + @iAvlQty
						   end
						end
					end
					else
						set @iQty = 0
				end
				set @iFor = @iFor + 1
			end
			DEALLOCATE curSend
			update orderidx set ysmoney = @nBillTotal, quantity = @nBillQty, jsye = @nBillTotal where billid = @OrderVchCode
			if @Act = 4 
			begin
			  update tranbill  set ComeQty = ComeQty + B.quantity from (select orgbillid,sum(quantity) as quantity from  OrderBill where bill_id= @OrderVchCode group by orgbillid ) B  where tranbill.smb_id = B.orgbillid
			  /*再更新请货单的状态*/
			  update tranidx set billstates = 0 where billid not in (select bill_id from tranbill where ComeQty < quantity group by bill_id)				
			end
			if @iLineCount = 0
			begin
				delete from orderidx where billid = @OrderVchCode
				if @Act = 4
					delete from GSPbillidx where Gspbillid = @vchCode
			end			
			else
			begin
				set @iBillCount = @iBillCount + 1
			/* 写入单据追踪*/
			EXEC TS_H_BillTraceAct 0, @OrderVchCode, 154
			IF @Act = 4
			BEGIN
				UPDATE orderidx SET auditman = @EId, auditdate = GETDATE(), billstates = 3 WHERE billid = @OrderVchCode
				update GSPbillidx set TaxTotal = @nBillTotal, DiscountTotal = @nBillTotal where Gspbillid = @vchCode
				
				UPDATE GSPbillidx SET S_id = (SELECT MIN(S_id) FROM GSPbilldetail WHERE Gspbill_id = @VchCode) WHERE Gspbillid = @VchCode
				
				EXEC @Ret = TS_H_SplitGspBillByS @vchCode
					IF @Ret = 0
						EXEC TS_H_BillTraceAct 0, @vchCode, 541, @OrderVchCode, 154
				
					/*set @iBillCount = @iBillCount + 1*/
				END
			END
			delete from #tmpCompany where c_id = @iYid
		end
		return @iBillCount
	END
	ELSE
	IF @Act = -5
	BEGIN
		set @iBillCount = 0
		set @iGuid = newid()
		while 1 > 0
		begin
			set @iYid = -1
			select top 1 @iYid = c_id, @iMDSid = s_id from #tmpCompany
			if @iYid < 0
				return @iBillCount
			
			if @CostType = 2
			begin
				select @CostRate = case IncRate when 0 then 1 else IncRate end from company where company_id = @iYid
			end
			
			exec TS_H_CreateBillSN @BillType, 1, null, @EId, @EId, @SendBillSN output, 2

			exec Ts_b_InsertBillIndexDraft @VchCode output, 0, 1, 0, @Today, @SendBillSN, @BillType, 0, @iYid,
				@EId, @ZBStorage, @iMDSid, 0, @Eid, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, ' ',
				'【由智能配货生成】', '', 0, '', 0, 0, 0, 0, 0, default, default, default, default, default,
				default, 2
			if @VchCode = -1
			begin
				raiserror('保存草稿出错！', 16, 1)
				return -100
			end
			
			declare curSend scroll cursor for
			select p_id, case when qty < sendQty then qty else sendQty end, smb_id from #tmpList where c_id = @iYid
			open curSend
			
			set @nBillTotal = 0
			set @nBillQty = 0
			set @iFor = 0
			set @iLineCount = 0
			
			while @iFor < @@cursor_rows
			begin
				fetch next from curSend into @iPid, @iQty, @iSmb
				
				while @iQty > 0
				begin
					set @iAvlQty = -1
					if @WholeStorage = '1'
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0)
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 AND a.s_id IN (select storage_id from #tmpSStore)
						ORDER BY a.validdate, a.instoretime
					end
					else
					begin
						SELECT  top 1 @iSid = a.s_id, @iSupplier = a.supplier_id, @nCost = a.costprice, @sBatch = a.batchno, 
									@dtMake = a.makedate, @dtInstore = a.instoretime, @dtValid = a.validdate, @iCommi = a.commissionflag, 
									@iLoc = a.location_id, @iAvlQty = a.quantity, @iUnit = p.unit1_id, @iPYid = a.Y_ID, @sBatchCode = a.batchbarcode, @sScomment = a.scomment, 
							@nBatchPrice = a.batchprice, @nRetailPrice = ISNULL(c.RetailPrice, 0)
						FROM #TMPAVLQTY as a
						INNER JOIN products as p
						ON a.p_id = p.product_id
						LEFT JOIN price c
						ON a.p_id = c.p_id AND p.unit1_id = c.u_id
						WHERE a.p_id = @iPid AND a.quantity > 0 
							AND (a.s_id IN (select storage_id from storages where y_id = 2 and flag = 0))
						ORDER BY a.validdate, a.instoretime
					end

					if @iAvlQty > 0
					begin
						if @iQty < @iAvlQty
							set @iAvlQty = @iQty
						set @iQty = @iQty - @iAvlQty
						if @iAvlQty > 0
						begin
							UPDATE #TMPAVLQTY SET quantity = quantity - @iAvlQty
							WHERE p_id = @iPid AND s_id = @iSid AND location_id = @iLoc AND supplier_id = @iSupplier
								AND costprice = @nCost AND batchno = @sBatch AND makedate = @dtMake AND instoretime = @dtInstore
								AND validdate = @dtValid AND commissionflag = @iCommi AND Y_ID = @iPYid
						   /*取初装货位*/

						    set @nLoc2ID = 0
						    set @nInSid = @iMDSid
						    if exists(select 1 from sysconfig where [sysname] = 'InStorageTra' and sysvalue = 1) and (@BillType =150 or @BillType =152) 
						    begin						      
						       select top 1 @nLoc2ID=l_id from LocationTrace where p_id = @iPid and s_id = @iMDSid and Y_ID = @iYid order by rectime desc						    
						       set @nLoc2ID = ISNULL(@nLoc2ID, 0)
						       set @nInSid = @iMDSid
						    end
						    						    
							/*set @iAvlQty = CEILING(@iAvlQty)*/
							set @iGuid = newid()
							set @sComment = dbo.GetProductComment(@iPid, @iAvlQty)
							/*读取商品加价率*/
							if @CostType = 3
							begin
							  select @nIncMode = incRateMode from company where company_id=@iYid
							  select @CostRate = Case @nIncMode when 1 then incRate when 2 then incRate2
													 when 3 then incRate3  else 1 end    
							   from products where product_id = @iPid 
							  if @CostRate = 0 set @CostRate = 1							  							   				              				              
							end													
							set @nSendPrice = @nCost * @CostRate
							set @nSendTotal = @nSendPrice * @iAvlQty
							set @nRetailTotal = @nRetailPrice * @iAvlQty
							exec ts_b_insertbilldetaildraft @Ret output, 4, 0, @VchCode, 0, @iPid, @sBatch, @iAvlQty,
								@nCost, @nSendPrice, @nSendTotal, 1, @nSendPrice, @nSendTotal, @nSendPrice, @nSendTotal,
								0, @nRetailPrice, @nRetailTotal, @dtMake, @dtValid, '', 0, @iSid, @nInSid, @iSmb, @iLoc, @iSupplier,
								@iCommi, @sComment, @iUnit, 0, @nLoc2ID, 0, 0, @iSmb, 0, default, default, default, default, default, default,
								@iGuid, default, '0', @iPYid, @dtInstore, 0, '', @sScomment, @nBatchPrice, @sBatchCode
							set @iLineCount = @iLineCount + 1
							set @nBillTotal = @nBillTotal + @nSendTotal
							set @nBillQty = @nBillQty + @iAvlQty
						end
					end
					else
						set @iQty = 0
				end
				set @iFor = @iFor + 1
			end
			DEALLOCATE curSend
			update billdraftidx set ysmoney = @nBillTotal, quantity = @nBillQty where billid = @vchCode
			if @iLineCount = 0
				delete from billdraftidx where billid = @vchCode
			else
				set @iBillCount = @iBillCount + 1
			delete from #tmpCompany where c_id = @iYid
		end
		return @iBillCount
	END
END
GO
