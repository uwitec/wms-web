



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*************************************************

全能进销存变动表,赠品

*************************************************/
CREATE PROCEDURE [ts_c_qrjxczero]
(	@BeginDate 	  DATETIME=0,
	@EndDate		  DATETIME=0,
	@szSClass_ID	VARCHAR(30)='%%',
	@szParent_id	VARCHAR(30)='000000',
	@szListFlag   VARCHAR(1)='L',
    @nYClassid                 varchar(100)='',
    @nloginEID               int=0,
    @isaddDate              int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szSClass_ID is null  SET @szSClass_ID = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
	SET NOCOUNT ON
  IF @szSClass_ID='' SELECT @szSClass_ID='%%'
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)


/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   
/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

	IF @szListFlag='L' GOTO leveallist
	IF @szListFlag='P' GOTO partlist
	IF @szListFlag='A' GOTO alllist

leveallist:
		SELECT a.Class_ID,a.product_id,a.child_number,a.[name],a.alias,a.[code],a.standard,a.makearea,a.medtype, a.[trademark], a.[permitcode],
        a.[unitname1], a.[rate2], a.[rate3], a.[rate4], a.[unitname2], a.[unitname3],  a.[unitname4],
        a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
        a.[pinyin], a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.Factory,a.rname,a.Comment,
        cast('' as varchar(10)) as e_name,cast('' as varchar(10)) as c_name,
        ISNULL(pr.[retailprice], 0) AS [retailprice],
		ISNULL(a.salequantity,0) AS salequantity,ISNULL(a.saletotal,0) AS saletotal,ISNULL(a.salewtquantity,0) AS salewtquantity,ISNULL(a.salewttotal,0) AS salewttotal,
		ISNULL(a.saletaxtotal,0) AS saletaxtotal,ISNULL(a.salegaintotal,0) AS salegaintotal,
		ISNULL(a.wtfhquantity,0) AS wtfhquantity,ISNULL(a.wtfhtotal,0) AS wtfhtotal,ISNULL(a.wtthquantity,0) AS wtthquantity,ISNULL(a.wtthtotal,0) AS wtthtotal,
		ISNULL(a.salelendquantity,0) AS salelendquantity,ISNULL(a.salelendtotal,0) AS salelendtotal,
		ISNULL(a.lendquantity,0) AS lendquantity,ISNULL(a.lendtotal,0) AS lendtotal,ISNULL(a.lendthquantity,0) AS lendthquantity,ISNULL(a.lendthtotal,0) AS lendthtotal,
		ISNULL(a.buyborrowquantity,0) AS buyborrowquantity,ISNULL(a.buyborrowtotal,0) AS buyborrowtotal,
		ISNULL(a.borrowquantity,0) AS borrowquantity,ISNULL(a.borrowtotal,0) AS borrowtotal,ISNULL(a.borrowthquantity,0) AS borrowthquantity,ISNULL(a.borrowthtotal,0) AS borrowthtotal,
		ISNULL(a.buyquantity,0) AS buyquantity,ISNULL(a.buytotal,0) AS buytotal,ISNULL(a.buybackquantity,0) AS buybackquantity,ISNULL(a.buybacktotal,0) AS buybacktotal,ISNULL(a.salebackquantity,0) AS salebackquantity,
		ISNULL(a.buystquantity,0) AS buystquantity,ISNULL(a.buysttotal,0) AS buysttotal,ISNULL(a.stshquantity,0) AS stshquantity,ISNULL(a.stshtotal,0) AS stshtotal,ISNULL(a.stthquantity,0) AS stthquantity,
		ISNULL(a.stthtotal,0) AS stthtotal, ISNULL(a.buytaxtotal,0) AS buytaxtotal,
		ISNULL(a.salebacktotal,0) AS salebacktotal,ISNULL(a.salebacktaxcost,0) AS salebacktaxcost,
		ISNULL(a.losequantity,0) AS losequantity,ISNULL(a.loseTotal,0) AS loseTotal,ISNULL(a.overflowquantity,0) AS overflowquantity,
		ISNULL(a.overflowtotal,0) AS overflowtotal,ISNULL(a.tjdbrktotal,0) AS tjdbrktotal,ISNULL(a.tjdbcktotal,0) AS tjdbcktotal,ISNULL(a.bjdbrkquantity,0) AS bjdbrkquantity,
		ISNULL(a.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(a.tjdbckquantity,0) AS tjdbckquantity,ISNULL(a.bjdbckquantity,0) AS bjdbckquantity,ISNULL(a.bjdbrktotal,0) AS bjdbrktotal,
		ISNULL(a.bjdbcktotal,0) AS bjdbcktotal,ISNULL(a.qtrkquantity,0) AS qtrkquantity,ISNULL(a.qtckquantity,0) AS qtckquantity,ISNULL(a.qtrktotal,0) AS qtrktotal,
		ISNULL(a.givequantity,0) AS givequantity,ISNULL(a.givetotal,0) AS givetotal,ISNULL(a.gainquantity,0) AS gainquantity,ISNULL(a.gaintotal,0) AS gaintotal,
		ISNULL(a.qtcktotal,0) AS qtcktotal,ISNULL(a.bqckquantity,0) AS bqckquantity,ISNULL(a.bqcktotal,0) AS bqcktotal,ISNULL(a.bqrkquantity,0) AS bqrkquantity,ISNULL(a.bqrktotal,0) AS bqrktotal,
		cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) as numeric(25,8)) AS sqcQuantity,
		cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) as numeric(25,8)) AS bqcQuantity ,
		cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) as numeric(25,8)) AS sqcCostTotal,
		cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) as numeric(25,8)) AS bqcTotal,
	    cast(0 as numeric(25,8)) AS ComRecquantity, cast(0 as numeric(25,8)) AS ComRecTotal,
        cast(0 as numeric(25,8)) AS ComRecBackquantity, cast(0 as numeric(25,8)) AS ComRecBackTotal,
        cast(0 as numeric(25,8)) AS ComSendquantity, cast(0 as numeric(25,8)) AS ComSendTotal,
        cast(0 as numeric(25,8)) AS ComSendBackquantity, cast(0 as numeric(25,8)) AS ComSendBackTotal,
        0.0 as kcqty,0.0as kctotal,0.0as taxcosttotal,0.00  as ztquantity,0.00 as zttaxtotal
        /*xzdong-2016-12-14-TFS44112*/
        ,0.00 as ztcosttaxtotal,0.00 as bqccosttaxtotal,0.00 as bqckcosttaxtotal,0.00 as comsendtaxtotal
	    ,0.00 as comrecbacktaxtotal,0.00 as qtcktaxtotal,0.00 as bjdbcktaxtotal,0.00 as tjdbcktaxtotal
	    ,0.00 as stthtaxtotal,0.00 as salewttaxtotal,0.00 as wtfhtaxtotal,0.00 as buybacktaxtotal
	    ,0.00 as bqrkcosttaxtotal,0.00 as comsendbackcosttaxtotal,0.00 as comreccosttaxtotal
	    ,0.00 as qtrkcosttaxtotal,0.00 as bjdbrkcosttaxtotal,0.00 as tjdbrktaxtotal,0.00 as wtthtaxtotal
	    ,0.00 as buysttaxtotal,0.00 as sqccosttaxtotal,0.00 as stshtaxtotal         
      
		FROM (SELECT p.Class_ID,max(p.product_id) AS product_id,max(p.child_number) AS child_number,max(p.[name]) AS [name],max(p.[alias]) AS [alias],max(p.[code]) AS code,
			max(p.standard) AS standard,max(p.makearea) makearea,max(p.medname) AS medtype, max(p.[trademark]) as [trademark], max(p.[permitcode]) as [permitcode],
      max(p.[unit1name]) as [unitname1], max(p.[rate2]) AS [rate2], max(p.[rate3]) AS [rate3], max(p.[rate4]) AS [rate4],  max(p.[unit2name]) AS [unitname2], max(p.[unit3name]) AS [unitname3],  max(p.[unit4name]) AS [unitname4],
      max(p.Inputman)Inputman,max(p.InputDate)InputDate,max(p.Custompro1)Custompro1,max(p.Custompro2)Custompro2,max(p.Custompro3)Custompro3,max(p.Custompro4)Custompro4,max(p.Custompro5)Custompro5,
      max(p.pinyin) as pinyin,max(p.EngName) as EngName,max(p.ChemName) as ChemName,max(p.LatinName) as LatinName,max(p.PackStd) as PackStd,max(p.StorageCon) as StorageCon,
      max(p.RegisterNo) as RegisterNo,max(p.BulidNo) as BulidNo,max(p.Factory) as Factory,max(p.rname) as rname,max(p.Comment) as Comment,
/* a.[pinyin], a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.Factory,a.rname,a.Comment,*/
      ISNULL(SUM(b.salequantity),0) AS salequantity,ISNULL(SUM(b.saletotal),0) AS saletotal,ISNULL(SUM(b.salewtquantity),0) AS salewtquantity,ISNULL(SUM(b.salewttotal),0) AS salewttotal,
      ISNULL(SUM(b.saletaxtotal),0) AS saletaxtotal,ISNULL(SUM(b.salegaintotal),0) AS salegaintotal,
			ISNULL(SUM(b.wtfhquantity),0) AS wtfhquantity,ISNULL(SUM(b.wtfhtotal),0) AS wtfhtotal,ISNULL(SUM(b.wtthquantity),0) AS wtthquantity,ISNULL(SUM(b.wtthtotal),0) AS wtthtotal,
            ISNULL(SUM(b.salelendquantity),0) AS salelendquantity,ISNULL(SUM(b.salelendtotal),0) AS salelendtotal,
			ISNULL(SUM(b.lendquantity),0) AS lendquantity,ISNULL(SUM(b.lendtotal),0) AS lendtotal,ISNULL(SUM(b.lendthquantity),0) AS lendthquantity,ISNULL(SUM(b.lendthtotal),0) AS lendthtotal,
            ISNULL(SUM(b.buyborrowquantity),0) AS buyborrowquantity,ISNULL(SUM(b.buyborrowtotal),0) AS buyborrowtotal,
			ISNULL(SUM(b.borrowquantity),0) AS borrowquantity,ISNULL(SUM(b.borrowtotal),0) AS borrowtotal,ISNULL(SUM(b.borrowthquantity),0) AS borrowthquantity,ISNULL(SUM(b.borrowthtotal),0) AS borrowthtotal,
			ISNULL(SUM(b.buyquantity),0) AS buyquantity,ISNULL(SUM(b.buytotal),0) AS buytotal,ISNULL(SUM(b.buystquantity),0) AS buystquantity,ISNULL(SUM(b.buysttotal),0) AS buysttotal,
			ISNULL(SUM(b.buytaxtotal),0) AS buytaxtotal,
			ISNULL(SUM(b.stshquantity),0) AS stshquantity,ISNULL(SUM(b.stshtotal),0) AS stshtotal,ISNULL(SUM(b.stthquantity),0) AS stthquantity,ISNULL(SUM(b.stthtotal),0) AS stthtotal,
			ISNULL(SUM(b.buybackquantity),0) AS buybackquantity,ISNULL(SUM(b.buybacktotal),0) AS buybacktotal,ISNULL(SUM(b.salebackquantity),0) AS salebackquantity,
			ISNULL(SUM(b.salebacktotal),0) AS salebacktotal,ISNULL(SUM(b.salebacktaxcost),0) AS salebacktaxcost,
			ISNULL(SUM(b.losequantity),0) AS losequantity,ISNULL(SUM(b.loseTotal),0) AS loseTotal,ISNULL(SUM(b.overflowquantity),0) AS overflowquantity,
			ISNULL(SUM(b.overflowtotal),0) AS overflowtotal,ISNULL(SUM(b.tjdbrktotal),0) AS tjdbrktotal,ISNULL(SUM(b.tjdbcktotal),0) AS tjdbcktotal,ISNULL(SUM(b.bjdbrkquantity),0) AS bjdbrkquantity,
			ISNULL(SUM(b.tjdbrkquantity),0) AS tjdbrkquantity,ISNULL(SUM(b.tjdbckquantity),0) AS tjdbckquantity,ISNULL(SUM(b.bjdbckquantity),0) AS bjdbckquantity,ISNULL(SUM(b.bjdbrktotal),0) AS bjdbrktotal,
			ISNULL(SUM(b.bjdbcktotal),0) AS bjdbcktotal,ISNULL(SUM(b.qtrkquantity),0) AS qtrkquantity,ISNULL(SUM(b.qtckquantity),0) AS qtckquantity,ISNULL(SUM(b.qtrktotal),0) AS qtrktotal,
			ISNULL(SUM(b.givequantity),0) AS givequantity,ISNULL(SUM(b.givetotal),0) AS givetotal,ISNULL(SUM(b.gainquantity),0) AS gainquantity,ISNULL(SUM(b.gaintotal),0) AS gaintotal,
			ISNULL(SUM(b.qtcktotal),0) AS qtcktotal,ISNULL(SUM(b.bqckquantity),0) AS bqckquantity,ISNULL(SUM(b.bqcktotal),0) AS bqcktotal,ISNULL(SUM(b.bqrkquantity),0) AS bqrkquantity,ISNULL(SUM(b.bqrktotal),0) AS bqrktotal
			FROM vw_products p LEFT JOIN
			   (SELECT pd.PClass_ID,
			   SUM(CASE	WHEN 	PD.billtype IN(10,12) and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salequantity],
			   cast(0 as numeric(25,8))  [saletotal],
			   cast(0 as numeric(25,8))  [saletaxtotal],
			   cast(0 as numeric(25,8))  [salegaintotal],
			   cast(0 as numeric(25,8))  [salewtquantity],
			   cast(0 as numeric(25,8))  [salewttotal],
			   cast(0 as numeric(25,8))  [wtfhquantity],
			   cast(0 as numeric(25,8))  [wtfhtotal],
			   cast(0 as numeric(25,8))  [wtthquantity],
			   cast(0 as numeric(25,8))  [wtthtotal],
			   cast(0 as numeric(25,8))  [salelendquantity],
			   cast(0 as numeric(25,8))  [salelendtotal],
			   cast(0 as numeric(25,8))  [lendquantity],
			   cast(0 as numeric(25,8))  [lendtotal],
			   cast(0 as numeric(25,8))  [lendthquantity],
			   cast(0 as numeric(25,8))  [lendthtotal],
			   SUM(CASE WHEN 	PD.billtype =20  and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buyquantity],
			   cast(0 as numeric(25,8))  [buytotal],
			   cast(0 as numeric(25,8))  [buytaxtotal],
			   cast(0 as numeric(25,8))  [buystquantity],
			   cast(0 as numeric(25,8))  [buysttotal],
			   cast(0 as numeric(25,8))  [stshquantity],
			   cast(0 as numeric(25,8))  [stshtotal],
			   cast(0 as numeric(25,8))  [stthquantity],
			   cast(0 as numeric(25,8))  [stthtotal],
			   cast(0 as numeric(25,8))  [buyborrowquantity],
			   cast(0 as numeric(25,8))  [buyborrowtotal],
			   cast(0 as numeric(25,8))  [borrowquantity],
			   cast(0 as numeric(25,8))  [borrowtotal],
			   cast(0 as numeric(25,8))  [borrowthquantity],
			   cast(0 as numeric(25,8))  [borrowthtotal],
			   SUM(CASE WHEN 	PD.billtype =21 and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buybackquantity],
			   cast(0 as numeric(25,8))  [buybacktotal],
			   SUM(CASE WHEN 	PD.billtype IN(11,13)  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salebackquantity],
			   cast(0 as numeric(25,8))  [salebacktotal],
			   
			   cast(0 as numeric(25,8))  [salebacktaxcost],
			   
			   SUM(CASE WHEN 	PD.billtype =41  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [losequantity],
			   cast(0 as numeric(25,8))  [loseTotal],
			   SUM(CASE WHEN 	PD.billtype =42	 and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [overflowquantity],
			   cast(0 as numeric(25,8))  [overflowtotal],
			   SUM(CASE WHEN 	PD.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbrkquantity],
			   SUM(CASE WHEN 	PD.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbckquantity],
			   cast(0 as numeric(25,8))  [tjdbrktotal],
			   cast(0 as numeric(25,8))  [tjdbcktotal],
			   SUM(CASE WHEN 	PD.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbrkquantity],
			   SUM(CASE WHEN 	PD.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbckquantity],
			   cast(0 as numeric(25,8))  [bjdbrktotal],
			   cast(0 as numeric(25,8))  [bjdbcktotal],
			   cast(0 as numeric(25,8))  [givequantity],
			   cast(0 as numeric(25,8))  [givetotal],
			   cast(0 as numeric(25,8))  [gainquantity],
			   cast(0 as numeric(25,8))  [gaintotal],
			   cast(0 as numeric(25,8))  [qtrkquantity],
			   cast(0 as numeric(25,8))  [qtrktotal],
			   cast(0 as numeric(25,8))  [qtckquantity],
			   cast(0 as numeric(25,8))  [qtcktotal],
			   SUM(CASE WHEN  pd.quantity<0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
			   cast(0 as numeric(25,8))  [bqcktotal],
			   SUM(CASE WHEN  pd.quantity>0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
			   cast(0 as numeric(25,8))  [bqrktotal]
			   FROM  
                 (
			    select PClass_ID=p.class_id,bi.billtype,pd.aoid,pd.quantity ,pd.storetype, pd.p_id, pd.s_id
			    from ProductDetail PD 
			    inner join BillIDX bi on pd.billid=bi.billid
			    left join Products p on pd.p_id=p.product_id
			    left join storages S on pd.s_id=S.storage_id
			    left join Company  Y on Y.company_id = PD.Y_ID
			    where bi.billdate between @BeginDate AND @EndDate and PD.aoid in (5,6)
                            and S.Class_ID like @szSClass_ID+'%' AND billstates='0'
	                    AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
			    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
		            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
		            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
		            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
                            )PD   
				 GROUP BY PD.PClass_ID
				) AS b
		 	on	LEFT(b.pClass_ID,LEN(p.Class_ID))=p.Class_ID
			WHERE p.parent_id=@szParent_id AND p.deleted<>1 AND p.product_id<>1
			GROUP BY p.Class_ID) AS a 
			INNER JOIN
			(	SELECT p.Class_ID,ISNULL(SUM(st.iniquantity),0) AS iniquantity,ISNULL(SUM(st.inicosttotal),0) AS inicosttotal 
				FROM products p 
				LEFT JOIN 
					(	
						SELECT si.Class_ID,ISNULL(SUM(si.quantity),0) AS iniquantity,ISNULL(SUM(si.costtotal),0) AS inicosttotal 
						FROM  vw_c_OtherStorehouseini si
						WHERE si.sClass_ID like @szSClass_ID+'%'
				                AND (@nYClassID='' or si.YClass_id like @nYClassID+'%')					       
   					        AND ((@Storetable=0) or (si.s_id in (select [id] from #storagestable)))
						AND ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))
						GROUP BY si.Class_ID
					 ) st
				ON LEFT(st.Class_ID,LEN(p.Class_ID))=p.Class_ID
				WHERE p.parent_id=@szParent_id AND p.deleted<>1
				GROUP BY p.Class_ID
			) AS b
			ON a.Class_ID=b.Class_ID
			INNER JOIN
			(	SELECT p.Class_ID,ISNULL(SUM(st.prequantity),0) AS prequantity,ISNULL(SUM(st.precosttotal),0) AS precosttotal 
				FROM products p 
				LEFT JOIN 
					(
					 select PClass_ID=p.Class_ID,ISNULL(SUM(pd.quantity),0) AS prequantity,ISNULL(SUM(pd.costtotal),0) AS precosttotal 
				         from ProductDetail PD 
					 inner join BillIDX bi on pd.billid=bi.billid
					 inner join Products p on pd.p_id=p.product_id
					 left join storages S on pd.s_id=S.storage_id
					 left join Company  Y on Y.company_id = PD.Y_ID
					 WHERE bi.billdate<@BeginDate AND bi.billstates='0' AND pd.storetype=3 AND S.Class_ID like @szSClass_ID+'%' 
					    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
				            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
				            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
				            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
					 GROUP BY P.Class_ID
					 ) st
				ON LEFT(st.pClass_ID,LEN(p.Class_ID))=p.Class_ID
				WHERE p.parent_id=@szParent_id AND p.deleted<>1
				GROUP BY p.Class_ID
			) AS c
			ON a.Class_ID=c.Class_ID
        LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr
        ON a.[product_id]=pr.[P_ID]

      GOTO SUCCEE

partlist:
		SELECT a.Class_ID,a.product_id,a.child_number,a.[name],a.[code],a.standard,a.makearea,a.medtype,a.[trademark], a.[permitcode],
      a.[unitname1], a.[rate2], a.[rate3], a.[rate4], a.[unitname2], a.[unitname3],  a.[unitname4],
      a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,
      a.[pinyin], a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.Factory,a.rname,a.Comment,a.alias,
      cast('' as varchar(10)) as e_name,cast('' as varchar(10)) as c_name,
      ISNULL(pr.[retailprice], 0) AS [retailprice],
			ISNULL(a.salequantity,0) AS salequantity,ISNULL(a.saletotal,0) AS saletotal,ISNULL(a.salewtquantity,0) AS salewtquantity,ISNULL(a.salewttotal,0) AS salewttotal,
      ISNULL(a.saletaxtotal,0) AS saletaxtotal,ISNULL(a.salegaintotal,0) AS salegaintotal,
			ISNULL(a.wtfhquantity,0) AS wtfhquantity,ISNULL(a.wtfhtotal,0) AS wtfhtotal,ISNULL(a.wtthquantity,0) AS wtthquantity,ISNULL(a.wtthtotal,0) AS wtthtotal,
      ISNULL(a.salelendquantity,0) AS salelendquantity,ISNULL(a.salelendtotal,0) AS salelendtotal,
			ISNULL(a.lendquantity,0) AS lendquantity,ISNULL(a.lendtotal,0) AS lendtotal,ISNULL(a.lendthquantity,0) AS lendthquantity,ISNULL(a.lendthtotal,0) AS lendthtotal,
      ISNULL(a.buyborrowquantity,0) AS buyborrowquantity,ISNULL(a.buyborrowtotal,0) AS buyborrowtotal,
			ISNULL(a.borrowquantity,0) AS borrowquantity,ISNULL(a.borrowtotal,0) AS borrowtotal,ISNULL(a.borrowthquantity,0) AS borrowthquantity,ISNULL(a.borrowthtotal,0) AS borrowthtotal,
			ISNULL(a.buyquantity,0) AS buyquantity,ISNULL(a.buytotal,0) AS buytotal,ISNULL(a.buybackquantity,0) AS buybackquantity,ISNULL(a.buybacktotal,0) AS buybacktotal,ISNULL(a.salebackquantity,0) AS salebackquantity,
			ISNULL(a.buystquantity,0) AS buystquantity,ISNULL(a.buysttotal,0) AS buysttotal,ISNULL(a.stshquantity,0) AS stshquantity,ISNULL(a.stshtotal,0) AS stshtotal,ISNULL(a.stthquantity,0) AS stthquantity,
			ISNULL(a.stthtotal,0) AS stthtotal, ISNULL(a.buytaxtotal,0) AS buytaxtotal,
			ISNULL(a.salebacktotal,0) AS salebacktotal,ISNULL(a.salebacktaxcost,0) AS salebacktaxcost,
			ISNULL(a.losequantity,0) AS losequantity,ISNULL(a.loseTotal,0) AS loseTotal,ISNULL(a.overflowquantity,0) AS overflowquantity,
			ISNULL(a.overflowtotal,0) AS overflowtotal,ISNULL(a.tjdbrktotal,0) AS tjdbrktotal,ISNULL(a.tjdbcktotal,0) AS tjdbcktotal,ISNULL(a.bjdbrkquantity,0) AS bjdbrkquantity,
			ISNULL(a.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(a.tjdbckquantity,0) AS tjdbckquantity,ISNULL(a.bjdbckquantity,0) AS bjdbckquantity,ISNULL(a.bjdbrktotal,0) AS bjdbrktotal,
			ISNULL(a.bjdbcktotal,0) AS bjdbcktotal,ISNULL(a.qtrkquantity,0) AS qtrkquantity,ISNULL(a.qtckquantity,0) AS qtckquantity,ISNULL(a.qtrktotal,0) AS qtrktotal,
			ISNULL(a.givequantity,0) AS givequantity,ISNULL(a.givetotal,0) AS givetotal,ISNULL(a.gainquantity,0) AS gainquantity,ISNULL(a.gaintotal,0) AS gaintotal,
			ISNULL(a.qtcktotal,0) AS qtcktotal,ISNULL(a.bqckquantity,0) AS bqckquantity,ISNULL(a.bqcktotal,0) AS bqcktotal,
      ISNULL(a.bqrkquantity,0) AS bqrkquantity,
      ISNULL(a.bqrktotal,0) AS bqrktotal,
			cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) as numeric(25,8)) AS sqcQuantity,
      cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) as numeric(25,8)) AS bqcQuantity ,
      cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) as numeric(25,8)) AS sqcCostTotal,
      cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) as numeric(25,8)) AS bqcTotal,
/*		ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) AS sqcQuantity,ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) AS bqcQuantity ,
      ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTotal,ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) AS bqcTotal
      */
      cast(0 as numeric(25,8)) AS ComRecquantity, cast(0 as numeric(25,8)) AS ComRecTotal,
	        cast(0 as numeric(25,8)) AS ComRecBackquantity, cast(0 as numeric(25,8)) AS ComRecBackTotal,
	        cast(0 as numeric(25,8)) AS ComSendquantity, cast(0 as numeric(25,8)) AS ComSendTotal,
	        cast(0 as numeric(25,8)) AS ComSendBackquantity, cast(0 as numeric(25,8)) AS ComSendBackTotal,
        0.0 as kcqty,0.0as kctotal,0.0as taxcosttotal,0.00  as ztquantity,0.00 as zttaxtotal
        /*xzdong-2016-12-14-TFS44112*/
        ,0.00 as ztcosttaxtotal,0.00 as bqccosttaxtotal,0.00 as bqckcosttaxtotal,0.00 as comsendtaxtotal
	    ,0.00 as comrecbacktaxtotal,0.00 as qtcktaxtotal,0.00 as bjdbcktaxtotal,0.00 as tjdbcktaxtotal
	    ,0.00 as stthtaxtotal,0.00 as salewttaxtotal,0.00 as wtfhtaxtotal,0.00 as buybacktaxtotal
	    ,0.00 as bqrkcosttaxtotal,0.00 as comsendbackcosttaxtotal,0.00 as comreccosttaxtotal
	    ,0.00 as qtrkcosttaxtotal,0.00 as bjdbrkcosttaxtotal,0.00 as tjdbrktaxtotal,0.00 as wtthtaxtotal
	    ,0.00 as buysttaxtotal,0.00 as sqccosttaxtotal,0.00 as stshtaxtotal        

		FROM 
			(		SELECT p.Class_ID,p.product_id,p.child_number,p.[name] AS [name],p.[code],p.standard,p.makearea,(p.medname) AS [medtype], p.[trademark], p.[permitcode],
          p.[unit1name] AS [Unitname1], p.[rate2], p.[rate3], p.[rate4], p.[unit2name] AS [unitname2], p.[unit3name] AS [unitname3],  p.[unit4name] AS [unitname4],
      p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.alias,
       p.[pinyin], p.EngName,p.ChemName,p.LatinName,p.PackStd,p.StorageCon,p.RegisterNo,p.BulidNo,p.Factory,p.rname,p.Comment,
					ISNULL(b.salequantity,0) AS salequantity,ISNULL(b.saletotal,0) AS saletotal,ISNULL(b.salewtquantity,0) AS salewtquantity,ISNULL(b.salewttotal,0) AS salewttotal,
          ISNULL(b.saletaxtotal,0) AS saletaxtotal,ISNULL(b.salegaintotal,0) AS salegaintotal,
					ISNULL(b.wtfhquantity,0) AS wtfhquantity,ISNULL(b.wtfhtotal,0) AS wtfhtotal,ISNULL(b.wtthquantity,0) AS wtthquantity,ISNULL(b.wtthtotal,0) AS wtthtotal,
          ISNULL(b.salelendquantity,0) AS salelendquantity,ISNULL(b.salelendtotal,0) AS salelendtotal,
    			ISNULL(b.lendquantity,0) AS lendquantity,ISNULL(b.lendtotal,0) AS lendtotal,ISNULL(b.lendthquantity,0) AS lendthquantity,ISNULL(b.lendthtotal,0) AS lendthtotal,
          ISNULL(b.buyborrowquantity,0) AS buyborrowquantity,ISNULL(b.buyborrowtotal,0) AS buyborrowtotal,
    			ISNULL(b.borrowquantity,0) AS borrowquantity,ISNULL(b.borrowtotal,0) AS borrowtotal,ISNULL(b.borrowthquantity,0) AS borrowthquantity,ISNULL(b.borrowthtotal,0) AS borrowthtotal,
					ISNULL(b.buyquantity,0) AS buyquantity,ISNULL(b.buytotal,0) AS buytotal,ISNULL(b.buystquantity,0) AS buystquantity,ISNULL(b.buysttotal,0) AS buysttotal,
    			ISNULL(b.buytaxtotal,0) AS buytaxtotal,
					ISNULL(b.stshquantity,0) AS stshquantity,ISNULL(b.stshtotal,0) AS stshtotal,ISNULL(b.stthquantity,0) AS stthquantity,ISNULL(b.stthtotal,0) AS stthtotal,
					ISNULL(b.buybackquantity,0) AS buybackquantity,ISNULL(b.buybacktotal,0) AS buybacktotal,ISNULL(b.salebackquantity,0) AS salebackquantity,
					ISNULL(b.salebacktotal,0) AS salebacktotal,ISNULL(b.salebacktaxcost,0) AS salebacktaxcost,
					ISNULL(b.losequantity,0) AS losequantity,ISNULL(b.loseTotal,0) AS loseTotal,ISNULL(b.overflowquantity,0) AS overflowquantity,
					ISNULL(b.overflowtotal,0) AS overflowtotal,ISNULL(b.tjdbrktotal,0) AS tjdbrktotal,ISNULL(b.tjdbcktotal,0) AS tjdbcktotal,ISNULL(b.bjdbrkquantity,0) AS bjdbrkquantity,
					ISNULL(b.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(b.tjdbckquantity,0) AS tjdbckquantity,ISNULL(b.bjdbckquantity,0) AS bjdbckquantity,ISNULL(b.bjdbrktotal,0) AS bjdbrktotal,
					ISNULL(b.bjdbcktotal,0) AS bjdbcktotal,ISNULL(b.qtrkquantity,0) AS qtrkquantity,ISNULL(b.qtckquantity,0) AS qtckquantity,ISNULL(b.qtrktotal,0) AS qtrktotal,
    			ISNULL(b.givequantity,0) AS givequantity,ISNULL(b.givetotal,0) AS givetotal,ISNULL(b.gainquantity,0) AS gainquantity,ISNULL(b.gaintotal,0) AS gaintotal,
					ISNULL(b.qtcktotal,0) AS qtcktotal,ISNULL(b.bqckquantity,0) AS bqckquantity,ISNULL(b.bqcktotal,0) AS bqcktotal,ISNULL(b.bqrkquantity,0) AS bqrkquantity,ISNULL(b.bqrktotal,0) AS bqrktotal
					FROM vw_products p LEFT JOIN
			   (SELECT pd.p_id,
			   SUM(CASE	WHEN 	pd.billtype IN(10,12) and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salequantity],
			   cast(0 as numeric(25,8))  [saletotal],
			   cast(0 as numeric(25,8))  [saletaxtotal],
			   cast(0 as numeric(25,8))  [salegaintotal],
			   cast(0 as numeric(25,8))  [salewtquantity],
			   cast(0 as numeric(25,8))  [salewttotal],
			   cast(0 as numeric(25,8))  [wtfhquantity],
			   cast(0 as numeric(25,8))  [wtfhtotal],
			   cast(0 as numeric(25,8))  [wtthquantity],
			   cast(0 as numeric(25,8))  [wtthtotal],
			   cast(0 as numeric(25,8))  [salelendquantity],
			   cast(0 as numeric(25,8))  [salelendtotal],
			   cast(0 as numeric(25,8))  [lendquantity],
			   cast(0 as numeric(25,8))  [lendtotal],
			   cast(0 as numeric(25,8))  [lendthquantity],
			   cast(0 as numeric(25,8))  [lendthtotal],
			   SUM(CASE WHEN 	pd.billtype =20  and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buyquantity],
			   cast(0 as numeric(25,8))  [buytotal],
			   cast(0 as numeric(25,8))  [buytaxtotal],
			   cast(0 as numeric(25,8))  [buystquantity],
			   cast(0 as numeric(25,8))  [buysttotal],
			   cast(0 as numeric(25,8))  [stshquantity],
			   cast(0 as numeric(25,8))  [stshtotal],
			   cast(0 as numeric(25,8))  [stthquantity],
			   cast(0 as numeric(25,8))  [stthtotal],
			   cast(0 as numeric(25,8))  [buyborrowquantity],
			   cast(0 as numeric(25,8))  [buyborrowtotal],
			   cast(0 as numeric(25,8))  [borrowquantity],
			   cast(0 as numeric(25,8))  [borrowtotal],
			   cast(0 as numeric(25,8))  [borrowthquantity],
			   cast(0 as numeric(25,8))  [borrowthtotal],
			   SUM(CASE WHEN 	pd.billtype =21 and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buybackquantity],
			   cast(0 as numeric(25,8))  [buybacktotal],
			   SUM(CASE WHEN 	pd.billtype IN(11,13)  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salebackquantity],
			   cast(0 as numeric(25,8))  [salebacktotal],
			   cast(0 as numeric(25,8))  [salebacktaxcost],
			   SUM(CASE WHEN 	pd.billtype =41  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [losequantity],
			   cast(0 as numeric(25,8))  [loseTotal],
			   SUM(CASE WHEN 	pd.billtype =42	 and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [overflowquantity],
			   cast(0 as numeric(25,8))  [overflowtotal],
			   SUM(CASE WHEN 	pd.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbrkquantity],
			   SUM(CASE WHEN 	pd.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbckquantity],
			   cast(0 as numeric(25,8))  [tjdbrktotal],
			   cast(0 as numeric(25,8))  [tjdbcktotal],
			   SUM(CASE WHEN 	pd.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbrkquantity],
			   SUM(CASE WHEN 	pd.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbckquantity],
			   cast(0 as numeric(25,8))  [bjdbrktotal],
			   cast(0 as numeric(25,8))  [bjdbcktotal],
			   cast(0 as numeric(25,8))  [givequantity],
			   cast(0 as numeric(25,8))  [givetotal],
			   cast(0 as numeric(25,8))  [gainquantity],
			   cast(0 as numeric(25,8))  [gaintotal],
			   cast(0 as numeric(25,8))  [qtrkquantity],
			   cast(0 as numeric(25,8))  [qtrktotal],
			   cast(0 as numeric(25,8))  [qtckquantity],
			   cast(0 as numeric(25,8))  [qtcktotal],
			   SUM(CASE WHEN  pd.quantity<0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
			   cast(0 as numeric(25,8))  [bqcktotal],
			   SUM(CASE WHEN  pd.quantity>0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
			   cast(0 as numeric(25,8))  [bqrktotal]
  		   FROM  (
			    select PClass_ID=p.class_id,bi.billtype,pd.aoid,pd.quantity ,pd.storetype, pd.p_id, pd.s_id
			    from ProductDetail PD 
			    inner join BillIDX bi on pd.billid=bi.billid
			    left join Products p on pd.p_id=p.product_id
			    left join storages S on pd.s_id=S.storage_id
			    left join Company  Y on Y.company_id = PD.Y_ID
			    where bi.billdate between @BeginDate AND @EndDate and PD.aoid in (5,6)
                            and S.Class_ID like @szSClass_ID+'%' AND billstates='0'
	                    AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
			    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
		            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
		            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
		            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
                          )pd
                          LEFT JOIN Storages s ON s.storage_id=pd.s_id
   				 	 GROUP BY pd.p_id
					) AS b
				 	on	b.p_id=p.product_id
					WHERE LEFT(p.Class_ID,LEN(@szParent_id))=@szParent_id AND p.child_number=0 AND p.deleted<>1 AND p.product_id<>1
			) AS a 
			INNER JOIN
			(	SELECT p.product_id,ISNULL(SUM(st.iniquantity),0) AS iniquantity,ISNULL(SUM(st.inicosttotal),0) AS inicosttotal 
				FROM products p 
				LEFT JOIN 
					(	
						SELECT si.p_id,ISNULL(SUM(si.quantity),0) AS iniquantity,ISNULL(SUM(si.costtotal),0) AS inicosttotal 
						FROM vw_c_OtherStorehouseini si
						WHERE si.sClass_ID like @szSClass_ID
			                        AND (@nYClassID='' or si.YClass_id like @nYClassID+'%')
						AND ((@Storetable=0) or (si.s_id in (select [id] from #storagestable))) 
						AND ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))
						GROUP BY si.p_id
					 ) st
				ON st.p_id=p.product_id
				WHERE LEFT(p.Class_ID,LEN(@szParent_id))=@szParent_id AND p.child_number=0 AND p.deleted<>1
				GROUP BY p.product_id
			) AS b
			ON a.product_id=b.product_id
			INNER JOIN
			(	SELECT p.product_id,ISNULL(SUM(st.prequantity),0) AS prequantity,ISNULL(SUM(st.precosttotal),0) AS precosttotal 
				FROM products p 
				LEFT JOIN 
					(	
					 select PD.p_id,ISNULL(SUM(pd.quantity),0) AS prequantity,ISNULL(SUM(pd.costtotal),0) AS precosttotal 
				         from ProductDetail PD 
					 inner join BillIDX bi on pd.billid=bi.billid
					 inner join Products p on pd.p_id=p.product_id
					 left join storages S on pd.s_id=S.storage_id
					 left join Company  Y on Y.company_id = PD.Y_ID
					 WHERE bi.billdate<@BeginDate AND bi.billstates='0' AND pd.storetype=3 AND S.Class_ID like @szSClass_ID+'%' 
					    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
				            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
				            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
				            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
					 GROUP BY PD.p_id
					 ) st
				ON st.p_id=p.product_id
				WHERE LEFT(p.Class_ID,LEN(@szParent_id))=@szParent_id AND p.child_number=0 AND p.deleted<>1
				GROUP BY p.product_id
			) AS c
			ON a.product_id=c.product_id
        LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr
        ON a.[product_id]=pr.[P_ID]

      GOTO SUCCEE

alllist:
		SELECT a.Class_ID,a.product_id,a.child_number,a.[name],a.[code],a.standard,a.makearea,a.medtype,a.[trademark], a.[permitcode],
      a.[unitname1], a.[rate2], a.[rate3], a.[rate4], a.[unitname2], a.[unitname3],  a.[unitname4],
      a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.alias,
      a.[pinyin], a.EngName,a.ChemName,a.LatinName,a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.Factory,a.rname,a.Comment,
      cast('' as varchar(10)) as e_name,cast('' as varchar(10)) as c_name,
      ISNULL(pr.[retailprice], 0) AS [retailprice],
			ISNULL(a.salequantity,0) AS salequantity,ISNULL(a.saletotal,0) AS saletotal,ISNULL(a.salewtquantity,0) AS salewtquantity,ISNULL(a.salewttotal,0) AS salewttotal,
      ISNULL(a.saletaxtotal,0) AS saletaxtotal,ISNULL(a.salegaintotal,0) AS salegaintotal,
			ISNULL(a.wtfhquantity,0) AS wtfhquantity,ISNULL(a.wtfhtotal,0) AS wtfhtotal,ISNULL(a.wtthquantity,0) AS wtthquantity,ISNULL(a.wtthtotal,0) AS wtthtotal,
      ISNULL(a.salelendquantity,0) AS salelendquantity,ISNULL(a.salelendtotal,0) AS salelendtotal,
			ISNULL(a.lendquantity,0) AS lendquantity,ISNULL(a.lendtotal,0) AS lendtotal,ISNULL(a.lendthquantity,0) AS lendthquantity,ISNULL(a.lendthtotal,0) AS lendthtotal,
      ISNULL(a.buyborrowquantity,0) AS buyborrowquantity,ISNULL(a.buyborrowtotal,0) AS buyborrowtotal,
			ISNULL(a.borrowquantity,0) AS borrowquantity,ISNULL(a.borrowtotal,0) AS borrowtotal,ISNULL(a.borrowthquantity,0) AS borrowthquantity,ISNULL(a.borrowthtotal,0) AS borrowthtotal,
			ISNULL(a.buyquantity,0) AS buyquantity,ISNULL(a.buytotal,0) AS buytotal,ISNULL(a.buybackquantity,0) AS buybackquantity,ISNULL(a.buybacktotal,0) AS buybacktotal,ISNULL(a.salebackquantity,0) AS salebackquantity,
			ISNULL(a.buystquantity,0) AS buystquantity,ISNULL(a.buysttotal,0) AS buysttotal,ISNULL(a.stshquantity,0) AS stshquantity,ISNULL(a.stshtotal,0) AS stshtotal,ISNULL(a.stthquantity,0) AS stthquantity,
			ISNULL(a.stthtotal,0) AS stthtotal, ISNULL(a.buytaxtotal,0) AS buytaxtotal,
			ISNULL(a.salebacktotal,0) AS salebacktotal,ISNULL(a.salebacktaxcost,0) AS salebacktaxcost,
			ISNULL(a.losequantity,0) AS losequantity,ISNULL(a.loseTotal,0) AS loseTotal,ISNULL(a.overflowquantity,0) AS overflowquantity,
			ISNULL(a.overflowtotal,0) AS overflowtotal,ISNULL(a.tjdbrktotal,0) AS tjdbrktotal,ISNULL(a.tjdbcktotal,0) AS tjdbcktotal,ISNULL(a.bjdbrkquantity,0) AS bjdbrkquantity,
			ISNULL(a.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(a.tjdbckquantity,0) AS tjdbckquantity,ISNULL(a.bjdbckquantity,0) AS bjdbckquantity,ISNULL(a.bjdbrktotal,0) AS bjdbrktotal,
			ISNULL(a.bjdbcktotal,0) AS bjdbcktotal,ISNULL(a.qtrkquantity,0) AS qtrkquantity,ISNULL(a.qtckquantity,0) AS qtckquantity,ISNULL(a.qtrktotal,0) AS qtrktotal,
			ISNULL(a.givequantity,0) AS givequantity,ISNULL(a.givetotal,0) AS givetotal,ISNULL(a.gainquantity,0) AS gainquantity,ISNULL(a.gaintotal,0) AS gaintotal,
			ISNULL(a.qtcktotal,0) AS qtcktotal,ISNULL(a.bqckquantity,0) AS bqckquantity,ISNULL(a.bqcktotal,0) AS bqcktotal,ISNULL(a.bqrkquantity,0) AS bqrkquantity,ISNULL(a.bqrktotal,0) AS bqrktotal,

			cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) as numeric(25,8)) AS sqcQuantity,
      cast(ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) as numeric(25,8)) AS bqcQuantity ,
      cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) as numeric(25,8)) AS sqcCostTotal,
      cast(ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) as numeric(25,8)) AS bqcTotal,
        cast(0 as numeric(25,8)) AS ComRecquantity, cast(0 as numeric(25,8)) AS ComRecTotal,
	        cast(0 as numeric(25,8)) AS ComRecBackquantity, cast(0 as numeric(25,8)) AS ComRecBackTotal,
	        cast(0 as numeric(25,8)) AS ComSendquantity, cast(0 as numeric(25,8)) AS ComSendTotal,
	        cast(0 as numeric(25,8)) AS ComSendBackquantity, cast(0 as numeric(25,8)) AS ComSendBackTotal,
        0.0 as kcqty,0.0as kctotal,0.0as taxcosttotal,0.00 as ztquantity,0.00 as zttaxtotal
      /*xzdong-2016-12-14-TFS44112*/
      ,0.00 as ztcosttaxtotal,0.00 as bqccosttaxtotal,0.00 as bqckcosttaxtotal,0.00 as comsendtaxtotal
	  ,0.00 as comrecbacktaxtotal,0.00 as qtcktaxtotal,0.00 as bjdbcktaxtotal,0.00 as tjdbcktaxtotal
	  ,0.00 as stthtaxtotal,0.00 as salewttaxtotal,0.00 as wtfhtaxtotal,0.00 as buybacktaxtotal
	  ,0.00 as bqrkcosttaxtotal,0.00 as comsendbackcosttaxtotal,0.00 as comreccosttaxtotal
	  ,0.00 as qtrkcosttaxtotal,0.00 as bjdbrkcosttaxtotal,0.00 as tjdbrktaxtotal,0.00 as wtthtaxtotal
	  ,0.00 as buysttaxtotal,0.00 as sqccosttaxtotal,0.00 as stshtaxtotal         

/*			ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) AS sqcQuantity,ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) AS bqcQuantity ,*/
/*      ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTotal,ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) AS bqcTotal*/

		FROM 
			(		SELECT p.Class_ID,p.product_id,p.child_number,p.[name] AS [name],p.[code],p.standard,p.makearea,(p.medname) AS [medtype], p.[trademark], p.[permitcode],
          p.[unit1name] AS [Unitname1], p.[rate2], p.[rate3], p.[rate4], p.[unit2name] AS [unitname2], p.[unit3name] AS [unitname3],  p.[unit4name] AS [unitname4],
          p.Inputman,p.InputDate,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.alias,
          p.[pinyin], p.EngName,p.ChemName,p.LatinName,p.PackStd,p.StorageCon,p.RegisterNo,p.BulidNo,p.Factory,p.rname,p.Comment,
					ISNULL(b.salequantity,0) AS salequantity,ISNULL(b.saletotal,0) AS saletotal,ISNULL(b.salewtquantity,0) AS salewtquantity,ISNULL(b.salewttotal,0) AS salewttotal,
          ISNULL(b.saletaxtotal,0) AS saletaxtotal,ISNULL(b.salegaintotal,0) AS salegaintotal,
					ISNULL(b.wtfhquantity,0) AS wtfhquantity,ISNULL(b.wtfhtotal,0) AS wtfhtotal,ISNULL(b.wtthquantity,0) AS wtthquantity,ISNULL(b.wtthtotal,0) AS wtthtotal,
          ISNULL(b.salelendquantity,0) AS salelendquantity,ISNULL(b.salelendtotal,0) AS salelendtotal,
    			ISNULL(b.lendquantity,0) AS lendquantity,ISNULL(b.lendtotal,0) AS lendtotal,ISNULL(b.lendthquantity,0) AS lendthquantity,ISNULL(b.lendthtotal,0) AS lendthtotal,
          ISNULL(b.buyborrowquantity,0) AS buyborrowquantity,ISNULL(b.buyborrowtotal,0) AS buyborrowtotal,
    			ISNULL(b.borrowquantity,0) AS borrowquantity,ISNULL(b.borrowtotal,0) AS borrowtotal,ISNULL(b.borrowthquantity,0) AS borrowthquantity,ISNULL(b.borrowthtotal,0) AS borrowthtotal,
					ISNULL(b.buyquantity,0) AS buyquantity,ISNULL(b.buytotal,0) AS buytotal,ISNULL(b.buystquantity,0) AS buystquantity,ISNULL(b.buysttotal,0) AS buysttotal,
    			ISNULL(b.buytaxtotal,0) AS buytaxtotal,
					ISNULL(b.stshquantity,0) AS stshquantity,ISNULL(b.stshtotal,0) AS stshtotal,ISNULL(b.stthquantity,0) AS stthquantity,ISNULL(b.stthtotal,0) AS stthtotal,
					ISNULL(b.buybackquantity,0) AS buybackquantity,ISNULL(b.buybacktotal,0) AS buybacktotal,ISNULL(b.salebackquantity,0) AS salebackquantity,
					ISNULL(b.salebacktotal,0) AS salebacktotal,ISNULL(b.salebacktaxcost,0) AS salebacktaxcost,
					ISNULL(b.losequantity,0) AS losequantity,ISNULL(b.loseTotal,0) AS loseTotal,ISNULL(b.overflowquantity,0) AS overflowquantity,
					ISNULL(b.overflowtotal,0) AS overflowtotal,ISNULL(b.tjdbrktotal,0) AS tjdbrktotal,ISNULL(b.tjdbcktotal,0) AS tjdbcktotal,ISNULL(b.bjdbrkquantity,0) AS bjdbrkquantity,
					ISNULL(b.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(b.tjdbckquantity,0) AS tjdbckquantity,ISNULL(b.bjdbckquantity,0) AS bjdbckquantity,ISNULL(b.bjdbrktotal,0) AS bjdbrktotal,
					ISNULL(b.bjdbcktotal,0) AS bjdbcktotal,ISNULL(b.qtrkquantity,0) AS qtrkquantity,ISNULL(b.qtckquantity,0) AS qtckquantity,ISNULL(b.qtrktotal,0) AS qtrktotal,
    			ISNULL(b.givequantity,0) AS givequantity,ISNULL(b.givetotal,0) AS givetotal,ISNULL(b.gainquantity,0) AS gainquantity,ISNULL(b.gaintotal,0) AS gaintotal,
					ISNULL(b.qtcktotal,0) AS qtcktotal,ISNULL(b.bqckquantity,0) AS bqckquantity,ISNULL(b.bqcktotal,0) AS bqcktotal,ISNULL(b.bqrkquantity,0) AS bqrkquantity,ISNULL(b.bqrktotal,0) AS bqrktotal
					FROM vw_products p LEFT JOIN
			   (SELECT pd.p_id,
			   SUM(CASE	WHEN 	pd.billtype IN(10,12) and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salequantity],
			   cast(0 as numeric(25,8))  [saletotal],
			   cast(0 as numeric(25,8))  [saletaxtotal],
			   cast(0 as numeric(25,8))  [salegaintotal],
			   cast(0 as numeric(25,8))  [salewtquantity],
			   cast(0 as numeric(25,8))  [salewttotal],
			   cast(0 as numeric(25,8))  [wtfhquantity],
			   cast(0 as numeric(25,8))  [wtfhtotal],
			   cast(0 as numeric(25,8))  [wtthquantity],
			   cast(0 as numeric(25,8))  [wtthtotal],
			   cast(0 as numeric(25,8))  [salelendquantity],
			   cast(0 as numeric(25,8))  [salelendtotal],
			   cast(0 as numeric(25,8))  [lendquantity],
			   cast(0 as numeric(25,8))  [lendtotal],
			   cast(0 as numeric(25,8))  [lendthquantity],
			   cast(0 as numeric(25,8))  [lendthtotal],
			   SUM(CASE WHEN 	pd.billtype =20  and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buyquantity],
			   cast(0 as numeric(25,8))  [buytotal],
			   cast(0 as numeric(25,8))  [buytaxtotal],
			   cast(0 as numeric(25,8))  [buystquantity],
			   cast(0 as numeric(25,8))  [buysttotal],
			   cast(0 as numeric(25,8))  [stshquantity],
			   cast(0 as numeric(25,8))  [stshtotal],
			   cast(0 as numeric(25,8))  [stthquantity],
			   cast(0 as numeric(25,8))  [stthtotal],
			   cast(0 as numeric(25,8))  [buyborrowquantity],
			   cast(0 as numeric(25,8))  [buyborrowtotal],
			   cast(0 as numeric(25,8))  [borrowquantity],
			   cast(0 as numeric(25,8))  [borrowtotal],
			   cast(0 as numeric(25,8))  [borrowthquantity],
			   cast(0 as numeric(25,8))  [borrowthtotal],
			   SUM(CASE WHEN 	pd.billtype =21 and pd.aoid=3  THEN ABS(pd.quantity) ELSE 0 END) AS [buybackquantity],
			   cast(0 as numeric(25,8))  [buybacktotal],
			   SUM(CASE WHEN 	pd.billtype IN(11,13)  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [salebackquantity],
			   cast(0 as numeric(25,8))  [salebacktotal],
			   cast(0 as numeric(25,8))  [salebacktaxcost],
			   
			   
			   SUM(CASE WHEN 	pd.billtype =41  and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [losequantity],
			   cast(0 as numeric(25,8))  [loseTotal],
			   SUM(CASE WHEN 	pd.billtype =42	 and pd.aoid=3 THEN ABS(pd.quantity) ELSE 0 END) AS [overflowquantity],
			   cast(0 as numeric(25,8))  [overflowtotal],
			   SUM(CASE WHEN 	pd.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbrkquantity],
			   SUM(CASE WHEN 	pd.billtype =44	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [tjdbckquantity],
			   cast(0 as numeric(25,8))  [tjdbrktotal],
			   cast(0 as numeric(25,8))  [tjdbcktotal],
			   SUM(CASE WHEN 	pd.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbrkquantity],
			   SUM(CASE WHEN 	pd.billtype =45	 and pd.aoid=3 THEN (CASE WHEN pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) ELSE 0 END) AS [bjdbckquantity],
			   cast(0 as numeric(25,8))  [bjdbrktotal],
			   cast(0 as numeric(25,8))  [bjdbcktotal],
			   cast(0 as numeric(25,8))  [givequantity],
			   cast(0 as numeric(25,8))  [givetotal],
			   cast(0 as numeric(25,8))  [gainquantity],
			   cast(0 as numeric(25,8))  [gaintotal],
			   cast(0 as numeric(25,8))  [qtrkquantity],
			   cast(0 as numeric(25,8))  [qtrktotal],
			   cast(0 as numeric(25,8))  [qtckquantity],
			   cast(0 as numeric(25,8))  [qtcktotal],
			   SUM(CASE WHEN  pd.quantity<0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
			   cast(0 as numeric(25,8))  [bqcktotal],
			   SUM(CASE WHEN  pd.quantity>0 AND pd.storetype=3 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
			   cast(0 as numeric(25,8))  [bqrktotal]
  		   FROM  (
			    select PClass_ID=p.class_id,bi.billtype,pd.aoid,pd.quantity ,pd.storetype, pd.p_id, pd.s_id
			    from ProductDetail PD 
			    inner join BillIDX bi on pd.billid=bi.billid
			    left join Products p on pd.p_id=p.product_id
			    left join storages S on pd.s_id=S.storage_id
			    left join Company  Y on Y.company_id = PD.Y_ID
			    where bi.billdate between @BeginDate AND @EndDate and PD.aoid in (5,6)
                            and S.Class_ID like @szSClass_ID+'%' AND billstates='0'
	                    AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
			    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
		            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
		            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
		            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
                           ) pd
         
                 	  GROUP BY pd.p_id
					) AS b
				 	on	b.p_id=p.product_id
					WHERE p.child_number=0 AND p.deleted<>1 AND p.product_id<>1
			) AS a 
			INNER JOIN
			(	SELECT p.product_id,ISNULL(SUM(st.iniquantity),0) AS iniquantity,ISNULL(SUM(st.inicosttotal),0) AS inicosttotal 
				FROM products p 
				LEFT JOIN 
					(	
						SELECT si.p_id,ISNULL(SUM(si.quantity),0) AS iniquantity,ISNULL(SUM(si.costtotal),0) AS inicosttotal 
						FROM  vw_c_OtherStorehouseini si
						WHERE si.sClass_ID like @szSClass_ID+'%'
			                        AND (@nYClassID='' or si.YClass_id like @nYClassID+'%')
				               	AND ((@Storetable=0) or (si.s_id in (select [id] from #storagestable)))
						AND ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))
						GROUP BY si.p_id
					 ) st
				ON st.p_id=p.product_id
				WHERE p.child_number=0 AND p.deleted<>1 AND p.product_id<>1
				GROUP BY p.product_id
			) AS b
			ON a.product_id=b.product_id
			INNER JOIN
			(	SELECT p.product_id,ISNULL(SUM(st.prequantity),0) AS prequantity,ISNULL(SUM(st.precosttotal),0) AS precosttotal 
				FROM products p 
				LEFT JOIN 
					(
					 select pd.p_id,ISNULL(SUM(pd.quantity),0) AS prequantity,ISNULL(SUM(pd.costtotal),0) AS precosttotal 
				         from ProductDetail PD 
					 inner join BillIDX bi on pd.billid=bi.billid
					 inner join Products p on pd.p_id=p.product_id
					 left join storages S on pd.s_id=S.storage_id
					 left join Company  Y on Y.company_id = PD.Y_ID
					 WHERE bi.billdate<@BeginDate AND bi.billstates='0' AND pd.storetype=3 AND S.Class_ID like @szSClass_ID+'%' 
					    AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
				            AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
				            AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
				            AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
					 GROUP BY PD.p_id
					 ) st
				ON st.p_id=p.product_id
				WHERE p.child_number=0 AND p.deleted<>1 AND p.product_id<>1
				GROUP BY p.product_id
			) AS c
			ON a.product_id=c.product_id
        LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr
        ON a.[product_id]=pr.[P_ID]

      GOTO SUCCEE

SUCCEE:

  RETURN 0
GO
