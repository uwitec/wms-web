

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*************************************************

供货商进销存查询
查询某段时间从某一供货商所进商品的进出存情况

*************************************************/
/*zhh修改，察看全部仓库时，显示所有本供货商供应的货品*/

CREATE PROCEDURE TS_C_QrJxcByClient
(	@BeginDate    DATETIME=0,
	@EndDate	    DATETIME=0,
	@nSupplier_ID INT=0,	
        @nStorage_ID  INT=0,
        @nYClassid                 varchar(100)='',
        @nloginEID               int=0,
        @isaddDate              int=0 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nSupplier_ID is null  SET @nSupplier_ID = 0
if @nStorage_ID is null  SET @nStorage_ID = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
  /*SET NOCOUNT ON*/
 Declare @Companytable INTEGER,@employeestable integer,@Storetable integer

  create table #Companytable([id] int)
/*   create table #employeestable([id] int)*/
/*   create table #storagestable([id] int)*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*
-----职员授权
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

-----职员授权

-----仓库授权
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
-----仓库授权
*/

  	SELECT a.product_id,a.class_id,a.child_number,a.[name],a.Serial_Number as code,a.alias,a.Pinyin,a.EngName,
        a.ChemName,a.LatinName,a.standard,a.modal,isnull(f.AccountComment,'') as makearea,a.rate2,a.rate3,a.rate4,ISNULL(U1.[Name], '')unitname1,
        /*ISNULL(M.name,'') AS medtype,*/
        /*TQH,后边做连接速度太慢，提到本处，包括name和medtype*/
        medtype = (select top 1 y.name from customCategoryMapping x left join customCategory y on y.id=x.category_id where x.BaseTypeid=0 and y.Typeid=2 and x.deleted=0 and x.baseinfo_id = a.product_id), 
        a.PackStd,a.StorageCon,a.RegisterNo,a.BulidNo,a.TradeMark,a.Comment, 
        /*r.name as rname,*/
        name = (select top 1 y.name from customCategoryMapping x left join customCategory y on y.id=x.category_id where x.BaseTypeid=0 and y.Typeid=1 and x.deleted=0 and x.baseinfo_id = a.product_id),   
        a.Factory,        
        a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,cast(p.retailPrice as numeric(25,8))retailPrice,
    	ABS(b.salequantity) AS salequantity,ABS(b.saletotal) AS saletotal,isnull(ABS(b.saleTaxTotal),0) AS saleTaxTotal,
    	b.salebackquantity,b.salebacktotal,b.buyquantity,b.buytotal,ABS(b.buybackquantity) AS buybackquantity,ABS(b.buybacktotal) AS buybacktotal,
  	    ABS(b.bqckquantity) bqckquantity,ABS(b.bqcktotal) AS bqcktotal,b.bqrkquantity,b.bqrktotal,
  	    /*本期入库收货含税成本金额,本期入库销售退货含税成本金额,本期入库合计含税成本金额*/
  	    b.buycosttaxtotal,b.salebackcosttaxtotal,b.bqrkcosttaxtotal,
  	    /*本期出库发货含税成本金额,本期出库进货退货含税金额,本期出库合计含税成本金额*/
  	    ABS(b.salecosttaxtotal) As salecosttaxtotal,ABS(b.buybacktaxtotal) AS buybacktaxtotal,ABS(b.bqckcosttaxtotal) AS bqckcosttaxtotal,
    	ISNULL(d.prequantity,0)+ISNULL(c.iniquantity,0) AS sqcQuantity,
    	/*上期存金额,上期存含税成本金额*/
    	ISNULL(d.precosttotal,0)+ISNULL(c.inicosttotal,0) AS sqccosttotal,
    	ISNULL(d.precosttaxtotal,0)+ISNULL(c.inicosttaxtotal,0) AS sqccosttaxtotal,
    	ISNULL(d.prequantity,0)+ISNULL(c.iniquantity,0)+ISNULL(b.bqckquantity,0)+ISNULL(b.bqrkquantity,0) AS bqcQuantity ,
    	/*本期存金额,本期存含税成本金额*/
    	ISNULL(d.preCostTotal,0)+ISNULL(c.inicosttotal,0)+ISNULL(b.bqckTotal,0)+ISNULL(b.bqrkTotal,0) AS bqcTotal,
    	ISNULL(d.preCosttaxTotal,0)+ISNULL(c.inicosttaxtotal,0)+ISNULL(b.bqckcosttaxTotal,0)+ISNULL(b.bqrkTotal,0) AS bqccosttaxTotal,
    	ISNULL(sqt.sqty,0) as sqty, /*zfl增加库存数量*/
    	ISNULL(sqt.stotal,0) as stotal /*zfl库存金额*/
  	FROM 
         ( select * from products 
           where product_id in(select distinct p_id from storehouseini  where (@nSupplier_ID=0 or supplier_id=@nSupplier_ID)
                                    union 
                                   select distinct p_id from productdetail  where (@nSupplier_ID=0 or supplier_id=@nSupplier_ID)
                                   )/*修改，考虑没有业务，但有期初*/
                ) a 
        left join (select p_id,SUM(quantity) as sqty,SUM(costtotal) as stotal from storehouse group by p_id ) sqt on a.product_id = sqt.p_id
        LEFT JOIN Unit U1       ON a.[Unit1_ID]=U1.[Unit_ID]
        /*
        LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
		 )r ON a.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON a.product_id=r.baseinfo_id
		 */
        left join (select * from price where unittype = 1) p on a.product_id = p.p_id
	LEFT JOIN
  		(	SELECT pd.p_id,
    			SUM(CASE	WHEN  pd.billtype in(10,12,112,53,212) and pd.aoid=0  THEN pd.quantity ELSE 0 END) AS salequantity,
    			SUM(CASE 	WHEN  pd.billtype in(10,12,112,53,212) and pd.aoid=0  THEN pd.costtotal ELSE 0 END) AS saletotal,
    			SUM(CASE 	WHEN  pd.billtype in(10,12,112,53,212) and pd.aoid=0  THEN pd.costtaxtotal ELSE 0 END) AS salecosttaxtotal,
			    SUM(CASE 	WHEN  pd.billtype in(10,12,112,53,212) and pd.aoid=0  THEN pd.taxtotal ELSE 0 END) AS saleTaxTotal,
  		  	    SUM(CASE 	WHEN  pd.billtype in(11,13,54) and pd.aoid=0  THEN pd.quantity ELSE 0 END) AS salebackquantity,
  		  	    SUM(CASE 	WHEN  pd.billtype in(11,13,54) and pd.aoid=0  THEN pd.costtotal ELSE 0 END) AS salebacktotal,
  		  	    SUM(CASE 	WHEN  pd.billtype in(11,13,54) and pd.aoid=0  THEN pd.costtaxtotal ELSE 0 END) AS salebackcosttaxtotal,
        	    SUM(CASE 	WHEN  pd.billtype in(20,122,222) and pd.aoid=0  THEN pd.quantity ELSE 0 END) AS buyquantity,
  		  	    SUM(CASE	WHEN  pd.billtype in(20,122,222) and pd.aoid=0  THEN pd.costtotal ELSE 0 END) AS buytotal,
  		  	    SUM(CASE	WHEN  pd.billtype in(20,122,222) and pd.aoid=0  THEN pd.costtaxtotal ELSE 0 END) AS buycosttaxtotal,
        	    SUM(CASE 	WHEN  pd.billtype =21 and pd.aoid=0  THEN pd.quantity ELSE 0 END) AS buybackquantity,
  		  	    SUM(CASE 	WHEN  pd.billtype =21 and pd.aoid=0  THEN pd.costtotal ELSE 0 END) AS buybacktotal,
  		  	    SUM(CASE 	WHEN  pd.billtype =21 and pd.aoid=0  THEN pd.taxtotal ELSE 0 END) AS buybacktaxtotal,
	        	SUM(CASE 	WHEN  pd.quantity<0 THEN pd.quantity ELSE 0 END) AS bqckquantity,
	  	    	SUM(CASE 	WHEN  pd.quantity<0 THEN pd.costtotal ELSE 0 END) AS bqcktotal,
	  	    	SUM(CASE 	WHEN  pd.quantity<0 THEN pd.costtaxtotal ELSE 0 END) AS bqckcosttaxtotal,
	  	    	SUM(CASE 	WHEN  pd.quantity>0 THEN pd.quantity ELSE 0 END) AS bqrkquantity,
	  	    	SUM(CASE 	WHEN  pd.quantity>0 THEN pd.costtotal ELSE 0 END) AS bqrktotal,
	  	    	SUM(CASE 	WHEN  pd.quantity>0 THEN pd.costtaxtotal ELSE 0 END) AS bqrkcosttaxtotal
  			FROM 
                        (SELECT p.billid,p.p_id,p.aoid, p.quantity,p.costtotal,p.taxtotal,p.costtaxtotal,p.supplier_id,p.storetype,p.s_id,p.RowE_id,p.Y_id,b.billtype
                           from FilterProductdetail(@nloginEID) p  
                           INNER JOIN billidx b on b.billid=p.billid 
                           WHERE  (b.billdate BETWEEN @BeginDate AND @EndDate)
                                and  p.aoid in (0,7) /*and b.billtype not in (150,151,155,160,161,165)*/
                                and b.billstates='0'
                                AND p.storetype=0 
                         )pd
         
                        LEFT JOIN  Company Y  ON pd.y_id=Y.Company_id 
  			WHERE        (@nSupplier_id=0 or pd.supplier_id=@nSupplier_id) 
                         AND (@nStorage_ID=0 or pd.[S_ID]=@nStorage_ID)
                         AND (@nYClassid='' or Y.Class_id like @nYClassid+'%')
/*                          AND ((@employeestable=0) OR (PD.RowE_id in (select [id] from #employeestable)))*/
/* 		         AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) */
		         AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))                           
 			GROUP BY pd.p_id
  		) AS b
  	ON a.product_id=b.p_id
  	LEFT JOIN 
  	( SELECT st.p_id,ISNULL(SUM(st.quantity),0) AS iniquantity,ISNULL(SUM(st.costtotal),0) AS inicosttotal,ISNULL(SUM(st.costtaxtotal),0) AS inicosttaxtotal  
  		FROM 
                (select * from storehouseini st
                 LEFT JOIN  Company Y  on st.Y_id=Y.Company_id
                where (@nSupplier_id=0 or supplier_id=@nSupplier_id) AND (@nStorage_ID=0 or [S_ID]=@nStorage_ID)
                AND (@nYClassid='' or Y.Class_id like @nYClassid+'%')
/*	        AND ((@Storetable=0) OR (s_id in (select [id] from #storagestable))) */
                AND ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))                           

                )st,products p
  		WHERE st.p_id=p.product_id AND p.deleted<>1 
                
  		GROUP BY st.p_id
  	) AS c
  	ON a.product_id=c.p_id
  	LEFT JOIN
  	(
  		SELECT pd.p_id,SUM(pd.quantity) AS prequantity,SUM(pd.costtotal) AS precosttotal,SUM(pd.costtaxtotal) AS precosttaxtotal
  		FROM 
                (SELECT p.billid,p.p_id,p.aoid, p.quantity,p.costtotal,p.taxtotal,p.costtaxtotal,p.supplier_id,p.storetype,p.s_id,p.RowE_id,p.Y_id,b.billtype
                   from FilterProductdetail(@nloginEID) p 
                   Inner JOIN billidx b ON b.billid=p.billid 
                   where b.billdate < @BeginDate AND p.aoid in (0,7) and b.billstates='0'/* and b.billtype not in (150,151,155,160,161,165)*/
                         AND storetype=0 
                )pd left join Company Y ON pd.Y_id=Y.company_id 
                
                where (@nSupplier_id=0 or pd.supplier_id=@nSupplier_id)
                AND (@nYClassid='' or Y.Class_id like @nYClassid+'%') 
                AND (@nStorage_ID=0 or pd.[S_ID]=@nStorage_ID)
/*                 AND ((@employeestable=0) OR (PD.RowE_id in (select [id] from #employeestable)))*/
/* 		AND ((@Storetable=0) OR (PD.s_id in (select [id] from #storagestable))) */
		AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
  		
                      
  		GROUP BY pd.p_id
  	) AS d
  	ON d.p_id=a.product_id
  	LEFT JOIN BaseFactory f on a.factoryc_id = f.CommID
  	WHERE a.product_id<>1 AND a.deleted<>1  and a.[child_number]=0


  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
