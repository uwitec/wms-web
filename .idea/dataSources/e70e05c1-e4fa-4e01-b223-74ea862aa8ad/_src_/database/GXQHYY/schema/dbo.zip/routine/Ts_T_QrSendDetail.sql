/************************************************************
--过程名称：Ts_T_QrSendDetail
--功能：查询物流配送单明细报表
--创建人：LUO XIAOTIAN 
--创建时间：2010-12-14 
--最后修改:


参数说明：
		   
                 
备注：
**************************************************************/
create proc [dbo].[Ts_T_QrSendDetail]
( @Sendid int, /*物流配送单主表id*/
  @begindate datetime,/*查询物流配送单开始时间*/
  @enddate   datetime,/*查询物流配送单结束时间*/
  @P_id   int , /*商品id*/
  @nDriver  int,
  @nstevedore int,
  @ncheckman int,
  @locedit  int,
  @custemer int
)
As
if @Sendid<>0 
begin
  select Sd.serial_number as number,sd.billDate ,sd.consign_dep,e1.name AS Driver,e2.name  AS stevedore,e3.name as checkman,sd.wholeNumber,sd.lhqty,sd.remnantNumber,
         bd.billdate as Dates,bd.billnumber,c.name as cname,p.serial_number,p.name,p.standard,lt.loc_name,p.permitcode,p.makearea,sm.quantity,sm.totalmoney 
         from salemanagebill sm
              left join billidx bd on Sm.bill_id=bd.billid
              left join clients c on bd.c_id = c.client_id
              left join Sendmangebill S  on sm.bill_id=S.billid 
              left join Sendidx sd on sd.Send_id=s.sendid 
              left join products p  on p.product_id=sm.p_id 
              left join employees e1 on e1.emp_id=sd.Driver 
              left join employees e2 on e2.emp_id=sd.stevedore 
              left join employees e3 on e3.emp_id=sd.checkman 
              left join location lt  on lt.loc_id = sm.location_id 
         where sd.Send_id=@Sendid and sd.billstates=0 and bd.billstates=0

end
else
begin
  select   Sd.serial_number as number,sd.billDate ,sd.consign_dep,e1.name AS Driver,e2.name  AS stevedore,e3.name as checkman,sd.wholeNumber,sd.lhqty,sd.remnantNumber,
         bd.billdate as Dates,bd.billnumber,c.name as cname,p.serial_number,p.name,p.standard,lt.loc_name,p.permitcode,p.makearea,sm.quantity,sm.totalmoney 
         from salemanagebill sm
              left join billidx bd on Sm.bill_id=bd.billid
              left join clients c on bd.c_id = c.client_id
              left join Sendmangebill S  on sm.bill_id=S.billid 
              left join Sendidx sd on sd.Send_id=s.sendid 
              left join products p  on p.product_id=sm.p_id 
              left join employees e1 on e1.emp_id=sd.Driver 
              left join employees e2 on e2.emp_id=sd.stevedore 
              left join employees e3 on e3.emp_id=sd.checkman 
              left join location lt  on lt.loc_id = sm.location_id 
         where bd.billtype in (10, 11, 212, 150, 152) 
               and sd.billDate between cast(@begindate as varchar(10)) and cast(@enddate as varchar(10)) and (@P_id=0 or sm.p_id = @P_id ) 
               and (@custemer=0 or bd.c_id=@custemer)
               and (@nDriver=0 or sd.Driver=@nDriver) and (@nstevedore=0 or sd.stevedore=@nstevedore)
               and (@ncheckman=0 or sd.checkman=@ncheckman) and (@locedit=0 or sm.location_id=@locedit)
               and sd.billstates=0 and bd.billstates=0
   UNION ALL
   select   Sd.serial_number as number,sd.billDate ,sd.consign_dep,e1.name AS Driver,e2.name  AS stevedore,e3.name as checkman,sd.wholeNumber,sd.lhqty,sd.remnantNumber,
         bd.billdate as Dates,bd.billnumber,c.name as cname,p.serial_number,p.name,p.standard,lt.loc_name,p.permitcode,p.makearea,sm.quantity,sm.totalmoney 
         from buymanagebill sm
              left join billidx bd on Sm.bill_id=bd.billid
              left join clients c on bd.c_id = c.client_id
              left join Sendmangebill S  on sm.bill_id=S.billid 
              left join Sendidx sd on sd.Send_id=s.sendid 
              left join products p  on p.product_id=sm.p_id 
              left join employees e1 on e1.emp_id=sd.Driver 
              left join employees e2 on e2.emp_id=sd.stevedore 
              left join employees e3 on e3.emp_id=sd.checkman 
              left join location lt  on lt.loc_id = sm.location_id 
         where bd.billtype = 21 
               and sd.billDate between cast(@begindate as varchar(10)) and cast(@enddate as varchar(10)) and (@P_id=0 or sm.p_id = @P_id ) 
               and (@custemer=0 or bd.c_id=@custemer)
               and (@nDriver=0 or sd.Driver=@nDriver) and (@nstevedore=0 or sd.stevedore=@nstevedore)
               and (@ncheckman=0 or sd.checkman=@ncheckman) and (@locedit=0 or sm.location_id=@locedit)
               and sd.billstates=0 and bd.billstates=0            
end
GO
