
create PROCEDURE Ts_T_QryRetailBillMx
( 
  @BeginDate DateTime, /*开始日期*/
  @EndDate DateTime, /*结束日期*/
  @BeginTime DateTime, /*开始时间*/
  @EndTime DateTime, /*结束时间*/
  @YID Int = 0, /*机构ID*/
  /*@CID Int = 0, --供应商ID*/
  @CID VarChar(8000) = '', /*供应商ID字串*/
  /*@PID Int = 0, --商品ID  */
  @PID VarChar(8000) = '', /*商品ID  */
  @SYID Int = 0, /*收银员*/
  @SaleID Int = 0, /*销售员*/
  /*@FactoryID Int = 0, --生产厂家，来自basefactory*/
  @FactoryID VarChar(8000) = '', /*生产厂家ID字串，来自basefactory*/
  @PTypeRange VarChar(8000) = '', /*商品类别*/
  @IncBack Int = 1, /*是否包含退货，0--不包含，1--包含，默认1*/
  @GroupText  varchar(8000) = '',		/*多时间段同比环比时汇总分组的条件*/
  @nloginEID int = 0     /*登陆职员  */
)      
 AS      
  /*根据传入的商品类别获取对应的PID，允许商品类别为空*/
  SELECT ISNULL(baseinfo_id, 0) pid INTO #TmpP FROM customCategoryMapping 
    WHERE deleted = 0 and BaseTypeid = 0 
      and category_id in (select type  from DecodeStr(@PTypeRange)) 
      
	set @BeginDate = FLOOR(CAST(@BeginDate as numeric(25,8)))
	set @EndDate = CEILING(CAST(@EndDate + 1 as numeric(25,8)))

	set @BeginTime = @BeginTime - FLOOR(CAST(@BeginTime as numeric(25,8)))
	set @EndTime = @EndTime - FLOOR(CAST(@EndTime as numeric(25,8)))

	Declare @Companytable INTEGER
	create table #Companytable([id] int)


/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

  IF @GroupText = '' 
  BEGIN             
    IF @IncBack = 1  /*包含退货*/
    BEGIN
      SELECT convert(varchar(100),a.RetailDate, 20) as billdate, a.billnumber, emp.name RMan, emp1.name SMan,
             case when b.AOID = 8 then sp.serial_number else c.serial_number end as code,  
             case when b.AOID = 8 then sp.alias else c.alias end as alias,
             case when b.AOID = 8 then sp.name else c.name end as Pname, cpy.name YName, 
             case when b.AOID = 8 then '' else c.[standard] end as  standard, 
             case when b.AOID = 8 then '' else f.AccountComment end  as factory, 
             case when b.AOID = 8 then '' else c.makearea end as makearea,
             case when b.AOID = 8 then sp.comment else c.comment end as comments, 
             case when b.AOID = 8 then sp.UnitName else d.name end as PUnit, b.batchno, b.validdate, 
             quantity = (case a.billtype when 12 then b.quantity else (-1)*b.quantity end), 
             b.retailprice, 
             billType = (Case a.billtype when 12 then '零售' else '零退' end),
             retailtotal = (case a.billtype when 12 then b.retailtotal else (-1)*b.retailtotal end),           
             PreMoney = (Case a.billtype when 12 then (b.retailtotal - b.taxtotal) else (-1) * (b.retailtotal - b.taxtotal) end), 
             b.taxprice, 
             taxtotal = (case a.billtype when 12 then (case AOID when 7 then 0 else b.taxtotal end) else -(case AOID when 7 then 0 else b.taxtotal end) end),
             b.taxrate * 100 taxrate, b.discountprice, 
             discounttotal = (case a.billtype when 12 then (case AOID when 7 then 0 else b.taxtotal end) / (1 + b.taxrate) else -(case AOID when 7 then 0 else b.taxtotal end) / (1 + b.taxrate) end), /*b.discountprice * b.quantity discounttotal, */
             MLMoney = (case a.billtype when 12 then (b.taxtotal - b.costtaxtotal) else (-1)*(b.taxtotal - b.costtaxtotal) end),         
             costtotal = (case a.billtype when 12 then b.costtaxtotal / (1 + b.taxrate) else (-1) * b.costtaxtotal / (1 + b.taxrate) end), 
             costtaxtotal = (case a.billtype when 12 then b.costtaxtotal else (-1)*b.costtaxtotal end), /*b.costtaxprice * b.quantity costtaxtotal, */
             MLRate = (case a.billtype when 12 then (case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end) 
                                       else (-1)*(case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end)
                       end),          
             case when b.AOID = 8 then '' else ISNULL(e.name, '') end as CName, ' ' as BuyerName, b.p_id as KeyId
      FROM billidx a inner join salemanagebill b on a.billid = b.bill_id
                      left join products c on b.p_id = c.product_id
                      left join VW_H_SpecialProducts sp on sp.product_id = b.p_id 
                      left join unit d on c.unit1_id = d.unit_id                      
                      left join clients e on b.supplier_id = e.client_id
                      left join employees emp on a.inputman = emp.emp_id 
                      left join employees emp1 on b.RowE_id = emp1.emp_id                       
                      left join basefactory f on b.factoryid = f.CommID
                      left join company cpy on a.Y_ID = cpy.company_id
      WHERE a.billtype in (12, 13)
        AND a.billstates = 0 
        and b.p_id > 0 
        AND RetailDate BETWEEN @BeginDate AND @EndDate
        /*AND CONVERT(varchar(100), RetailDate, 23) <= @EndDate   */
		AND RetailDate - floor(cast(RetailDate as numeric(25,8))) BETWEEN @BeginTime AND @EndTime
        /*AND CONVERT(varchar(100), RetailDate, 24) >= @BeginTime --HH:MM:SS*/
        /*AND CONVERT(varchar(100), RetailDate, 24) <= @EndTime*/
        and (@YID = 0 or a.Y_ID = @YID) 
        /*and (@CID = 0 or b.supplier_id = @CID)*/
        and ((@CID = '') or (@CID = '0') or (b.supplier_id in (select type from DecodeStr(@CID)))) /*支持模糊查询*/
        /*and (@PID = 0 or b.p_id = @PID)       */
        and ((@PID = '') or (@PID = '0') or (b.p_id in (select type from DecodeStr(@PID)))) /*支持模糊查询*/
        and (@SYID = 0 or a.inputman = @SYID)  /*收银员即制单人，inputman          */
        and (@SaleID = 0 or b.RowE_id = @SaleID) /*营业员（销售员）即经手人, e_id*/
        /*and (@FactoryID = 0 or f.CommID = @FactoryID) */
        and ((@FactoryID = '') or (@FactoryID = '0') or (f.CommID in (select type from DecodeStr(@FactoryID)))) /*支持模糊查询*/
        and ((@PTypeRange = '') or (b.p_id in (select pid from #TmpP))) 
        and ((@Companytable=0)or (b.Y_ID in (select [id] from #Companytable)))   
    END 
    ELSE IF @IncBack = 0 /*不含退货*/
    BEGIN
      SELECT convert(varchar(100),a.RetailDate, 20) as billdate, a.billnumber, emp.name RMan, emp1.name SMan,
             case when b.AOID = 8 then sp.serial_number else c.serial_number end as code,  
             case when b.AOID = 8 then sp.alias else c.alias end as alias,
             case when b.AOID = 8 then sp.name else c.name end as Pname, cpy.name YName,
             billType = (Case a.billtype when 12 then '零售' else '零退' end),
             case when b.AOID = 8 then '' else c.[standard] end as  standard, 
             case when b.AOID = 8 then '' else f.AccountComment end  as factory, 
             case when b.AOID = 8 then '' else c.makearea end as makearea,
             case when b.AOID = 8 then sp.comment else c.comment end as comments,  
             case when b.AOID = 8 then sp.UnitName else d.name end as PUnit, b.batchno, b.validdate, b.quantity, b.retailprice, b.retailtotal, 
             (b.retailtotal - b.taxtotal) as PreMoney, 
             b.taxprice, (case AOID when 7 then 0 else b.taxtotal end) as taxtotal, b.taxrate * 100 taxrate, b.discountprice, 
             (case AOID when 7 then 0 else b.taxtotal end) / (1 + b.taxrate) discounttotal, /*b.discountprice * b.quantity discounttotal, */
             (b.taxtotal - b.costtaxtotal) as MLMoney, b.costtaxtotal / (1 + b.taxrate) costtotal, b.costtaxtotal, /*b.costtaxprice * b.quantity costtaxtotal, */
             (case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end) as MLRate, 
             case when b.AOID = 8 then '' else ISNULL(e.name, '') end as CName, ' ' as BuyerName, b.p_id as KeyId   
       FROM billidx a inner join salemanagebill b on a.billid = b.bill_id
                       left join products c on b.p_id = c.product_id
                       left join VW_H_SpecialProducts sp on sp.product_id = b.p_id 
                       left join unit d on c.unit1_id = d.unit_id                      
                       left join clients e on b.supplier_id = e.client_id
                       left join employees emp on a.inputman = emp.emp_id 
                       left join employees emp1 on b.RowE_id = emp1.emp_id                       
                       left join basefactory f on b.factoryid = f.CommID
                       left join company cpy on a.Y_ID = cpy.company_id
      WHERE a.billtype = 12 
        AND a.billstates = 0 
        and b.p_id > 0
        AND RetailDate BETWEEN @BeginDate AND @EndDate
		AND RetailDate - floor(cast(RetailDate as numeric(25,8))) BETWEEN @BeginTime AND @EndTime
        and (@YID = 0 or a.Y_ID = @YID) 
        /*and (@CID = 0 or b.supplier_id = @CID)*/
        and ((@CID = '') or (@CID = '0') or (b.supplier_id in (select type  from DecodeStr(@CID)))) /*支持模糊查询*/
        /*and (@PID = 0 or b.p_id = @PID) */
        and ((@PID = '') or (@PID = '0') or (b.p_id in (select type from DecodeStr(@PID)))) /*支持模糊查询*/
        and (@SYID = 0 or a.inputman = @SYID)  /*收银员即制单人，inputman          */
        and (@SaleID = 0 or b.RowE_id = @SaleID) /*营业员（销售员）即经手人, e_id*/
        /*and (@FactoryID = 0 or f.CommID = @FactoryID) */
        and ((@FactoryID = '') or (@FactoryID = '0') or (f.CommID in (select type  from DecodeStr(@FactoryID)))) /*支持模糊查询*/
        and ((@PTypeRange = '') or (b.p_id in (select pid from #TmpP))) 
        and ((@Companytable=0)or (b.Y_ID in (select [id] from #Companytable)))    
    END
  END
  ELSE
  BEGIN
    IF @IncBack = 1  /*包含退货*/
    BEGIN
      SELECT convert(varchar(100),a.RetailDate, 20) as billdate, a.billnumber, emp.name RMan, emp1.name SMan,
             case when b.AOID = 8 then sp.serial_number else c.serial_number end as code,  
             case when b.AOID = 8 then sp.alias else c.alias end as alias,
             case when b.AOID = 8 then sp.name else c.name end as Pname, cpy.name YName, 
             case when b.AOID = 8 then '' else c.[standard] end as  standard, 
             case when b.AOID = 8 then '' else f.AccountComment end  as factory, 
             case when b.AOID = 8 then '' else c.makearea end as makearea,
             case when b.AOID = 8 then sp.comment else c.comment end as comments, 
             case when b.AOID = 8 then sp.UnitName else d.name end as PUnit, b.batchno, b.validdate, 
             quantity = (case a.billtype when 12 then b.quantity else (-1)*b.quantity end), 
             b.retailprice, 
             billType = (Case a.billtype when 12 then '零售' else '零退' end),
             retailtotal = (case a.billtype when 12 then b.retailtotal else (-1)*b.retailtotal end),           
             PreMoney = (Case a.billtype when 12 then (b.retailtotal - b.taxtotal) else (-1) * (b.retailtotal - b.taxtotal) end), 
             b.taxprice, 
             taxtotal = (case a.billtype when 12 then b.taxtotal else (-1)*b.taxtotal end),
             b.taxrate * 100 taxrate, b.discountprice, 
             discounttotal = (case a.billtype when 12 then b.taxtotal / (1 + b.taxrate) else (-1)*b.taxtotal / (1 + b.taxrate) end), /*b.discountprice * b.quantity discounttotal, */
             MLMoney = (case a.billtype when 12 then (b.taxtotal - b.costtaxtotal) else (-1)*(b.taxtotal - b.costtaxtotal) end),         
             costtotal = (case a.billtype when 12 then b.costtaxtotal / (1 + b.taxrate) else (-1) * b.costtaxtotal / (1 + b.taxrate) end), 
             costtaxtotal = (case a.billtype when 12 then b.costtaxtotal else (-1)*b.costtaxtotal end), /*b.costtaxprice * b.quantity costtaxtotal, */
             MLRate = (case a.billtype when 12 then (case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end) 
                                       else (-1)*(case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end)
                       end),          
             case when b.AOID = 8 then '' else ISNULL(e.name, '') end as CName, ' ' as BuyerName, ' ' as KeyId
      into #tmp
      FROM billidx a inner join salemanagebill b on a.billid = b.bill_id
                      left join products c on b.p_id = c.product_id
                      left join VW_H_SpecialProducts sp on sp.product_id = b.p_id  
                      left join unit d on c.unit1_id = d.unit_id                      
                      left join clients e on b.supplier_id = e.client_id
                      left join employees emp on a.inputman = emp.emp_id 
                      left join employees emp1 on b.RowE_id = emp1.emp_id                       
                      left join basefactory f on b.factoryid = f.CommID
                      left join company cpy on a.Y_ID = cpy.company_id
      WHERE a.billtype in (12, 13)
        AND a.billstates = 0 
        and b.p_id > 0 
        AND RetailDate BETWEEN @BeginDate AND @EndDate
		AND RetailDate - floor(cast(RetailDate as numeric(25,8))) BETWEEN @BeginTime AND @EndTime
        and (@YID = 0 or a.Y_ID = @YID) 
        /*and (@CID = 0 or b.supplier_id = @CID)*/
        and ((@CID = '') or (@CID = '0') or (b.supplier_id in (select type from DecodeStr(@CID)))) /*支持模糊查询*/
        /*and (@PID = 0 or b.p_id = @PID)       */
        and ((@PID = '') or (@PID = '0') or (b.p_id in (select type from DecodeStr(@PID)))) /*支持模糊查询*/
        and (@SYID = 0 or a.inputman = @SYID)  /*收银员即制单人，inputman          */
        and (@SaleID = 0 or b.RowE_id = @SaleID) /*营业员（销售员）即经手人, e_id*/
        /*and (@FactoryID = 0 or f.CommID = @FactoryID) */
        and ((@FactoryID = '') or (@FactoryID = '0') or (f.CommID in (select type from DecodeStr(@FactoryID)))) /*支持模糊查询*/
        and ((@PTypeRange = '') or (b.p_id in (select pid from #TmpP)))    
    END 
    ELSE IF @IncBack = 0 /*不含退货*/
    BEGIN
      SELECT convert(varchar(100),a.RetailDate, 20) as billdate, a.billnumber, emp.name RMan, emp1.name SMan,
             case when b.AOID = 8 then sp.serial_number else c.serial_number end as code,  
             case when b.AOID = 8 then sp.alias else c.alias end as alias,
             case when b.AOID = 8 then sp.name else c.name end as Pname, cpy.name YName, 
             billType = (Case a.billtype when 12 then '零售' else '零退' end),
             case when b.AOID = 8 then '' else c.[standard] end as  standard, 
             case when b.AOID = 8 then '' else f.AccountComment end  as factory, 
             case when b.AOID = 8 then '' else c.makearea end as makearea,
             case when b.AOID = 8 then sp.comment else c.comment end as comments,
             case when b.AOID = 8 then sp.UnitName else d.name end as PUnit, b.batchno, b.validdate, b.quantity, b.retailprice, b.retailtotal, 
             (b.retailtotal - b.taxtotal) as PreMoney, 
             b.taxprice, b.taxtotal, b.taxrate * 100 taxrate, b.discountprice, b.taxtotal / (1 + b.taxrate) discounttotal, /*b.discountprice * b.quantity discounttotal, */
             (b.taxtotal - b.costtaxtotal) as MLMoney, b.costtaxtotal / (1 + b.taxrate) costtotal, b.costtaxtotal, /*b.costtaxprice * b.quantity costtaxtotal, */
             (case IsNull(b.taxtotal, 0) when 0 then 0 else (b.taxtotal - b.costtaxtotal) * 100/ b.taxtotal end) as MLRate, 
             case when b.AOID = 8 then '' else ISNULL(e.name, '') end as CName, ' ' as BuyerName, ' ' as KeyId  
       into #tmp1
       FROM billidx a inner join salemanagebill b on a.billid = b.bill_id
                       left join products c on b.p_id = c.product_id
                       left join VW_H_SpecialProducts sp on sp.product_id = b.p_id  
                       left join unit d on c.unit1_id = d.unit_id                      
                       left join clients e on b.supplier_id = e.client_id
                       left join employees emp on a.inputman = emp.emp_id 
                       left join employees emp1 on b.RowE_id = emp1.emp_id                       
                       left join basefactory f on b.factoryid = f.CommID
                       left join company cpy on a.Y_ID = cpy.company_id
      WHERE a.billtype = 12 
        AND a.billstates = 0 
        and b.p_id > 0
        AND RetailDate BETWEEN @BeginDate AND @EndDate
		AND RetailDate - floor(cast(RetailDate as numeric(25,8))) BETWEEN @BeginTime AND @EndTime
        and (@YID = 0 or a.Y_ID = @YID) 
        /*and (@CID = 0 or b.supplier_id = @CID)*/
        and ((@CID = '') or (@CID = '0') or (b.supplier_id in (select type  from DecodeStr(@CID)))) /*支持模糊查询*/
        /*and (@PID = 0 or b.p_id = @PID) */
        and ((@PID = '') or (@PID = '0') or (b.p_id in (select type from DecodeStr(@PID)))) /*支持模糊查询*/
        and (@SYID = 0 or a.inputman = @SYID)  /*收银员即制单人，inputman          */
        and (@SaleID = 0 or b.RowE_id = @SaleID) /*营业员（销售员）即经手人, e_id*/
        /*and (@FactoryID = 0 or f.CommID = @FactoryID) */
        and ((@FactoryID = '') or (@FactoryID = '0') or (f.CommID in (select type  from DecodeStr(@FactoryID)))) /*支持模糊查询*/
        and ((@PTypeRange = '') or (b.p_id in (select pid from #TmpP)))     
    END  
    
    /*select + cast ( RMan  as varchar(200))+ cast ( SMan  as varchar(200))+ cast ( code  as varchar(200))+ cast ( alias  as varchar(200)) */
    /*       + cast ( YName  as varchar(200))+ cast ( standard  as varchar(200))+ cast ( retailprice  as varchar(200))+ cast ( billType  as varchar(200))  */
    /*       + cast ( taxprice  as varchar(200))+ cast ( taxrate  as varchar(200))+ cast ( discountprice  as varchar(200))+ cast ( MLMoney  as varchar(200)) */
    /*       + cast ( MLRate  as varchar(200)) + cast ( CName  as varchar(200)) as keyid */
           /*+ cast ( BuyerName  as varchar(200))  as keyid             */
    /*from #tmp */
    /*select * from #tmp*/
    /*return*/
    
    DECLARE @TMPTBLNAME VARCHAR(20)
    IF @IncBack = 1  /*包含退货*/
      SET @TMPTBLNAME = 'tempdb..#tmp'
    ELSE IF @IncBack = 0 /*不含退货*/
      SET @TMPTBLNAME = 'tempdb..#tmp1'
      
    DECLARE @i INT, @count INT, @colname VARCHAR(100), @colname2 VARCHAR(100), @Keyid VARCHAR(1000), @select VARCHAR(1000), @sql VARCHAR(8000)   
    SET @count = 0
    SET @colname = ''
    SET @colname2 = ''
    SET @select = ''
    SET @Keyid = ''
    SET @i= 1
    
    SELECT @count = COUNT(column_id) FROM tempdb.sys.columns WHERE object_id = object_id(@TMPTBLNAME);
    WHILE @i < @count + 1
    BEGIN
      SELECT @colname = name FROM tempdb.sys.columns WHERE object_id = object_id(@TMPTBLNAME) and column_id = @i 
      IF @colname is null 
        SET @colname2 = ''
      ELSE
        SET @colname2 = '%' + @colname + ',%'
      IF PATINDEX(@colname2, @GroupText) > 0   /*该列在分组中*/
      BEGIN
        IF @select = ''
        BEGIN
	      SET @select = @colname
		  SET @Keyid = 'cast(' + @colname + ' as varchar(100))'
	    END
	    ELSE 
	    BEGIN
	      SET @select = @select + ',' + @colname
	      SET @Keyid =  @Keyid + '+ cast(' + @colname + ' as varchar(100))' 
	    END          
      END      
      ELSE  /*不在分组中的*/
      BEGIN
        IF PATINDEX('%quantity%', @colname) > 0 or PATINDEX('%total%', @colname) > 0 or PATINDEX('%money%', @colname) > 0
        BEGIN
          IF @select = ''
			SET @select = 'sum(' + @colname + ') as ' + @colname 
		  ELSE
		    SET @select = @select + ', sum(' + @colname + ') as ' + @colname  
	    END
	    ELSE IF PATINDEX('%price%', @colname) > 0 OR PATINDEX('%MLRate%', @colname) > 0 
	    BEGIN
	      IF @select = ''
			SET @select = 'AVG(' + @colname + ') as ' + @colname 
		  ELSE
		    SET @select = @select + ', AVG(' + @colname + ') as ' + @colname   
	    END
	    ELSE
	    BEGIN 
          IF @select = ''
			SET @select = 'max(' + @colname + ') as ' + @colname 
		  ELSE	   
	        SET @select = @select + ',max(' + @colname + ') as ' + @colname
	    END
      END
     
      SET @i = @i + 1
    END
   
    IF @Keyid = ''
      SET @Keyid = ' p.name as keyid,'
    ELSE
      SET @Keyid = @Keyid +  '  as keyid, '
   
	SELECT @sql = 'select ' + @Keyid + @select + ' from ' + @TMPTBLNAME + ' group by '+ left(@GroupText, LEN(@GroupText) -1) /*这儿要去掉最后一个,号，之前用来匹配使用*/
		
	/*PRINT @sql*/
	EXEC(@sql) 
	
	IF object_id(N'#tmp', N'U') is not null  
	  DROP table #tmp
    IF object_id(N'#tmp1', N'U') is not null  
	  DROP table #tmp  	   
  END
  
  IF object_id(N'#TmpP', N'U') is not null  
    DROP TABLE #TmpP
GO
