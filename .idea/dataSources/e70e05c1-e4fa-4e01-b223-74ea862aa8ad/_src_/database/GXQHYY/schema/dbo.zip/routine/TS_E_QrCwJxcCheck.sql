create procedure TS_E_QrCwJxcCheck
(
    @BeginDate    DATETIME=0,
    @EndDate      DATETIME=0,
    @nPid          int=0,
    @nYClassid    varchar(1000)='',
    @szParent_id VARCHAR(30)='000000',
    @szListFlag   VARCHAR(1)='L',
    @nloginEID    int=0,
    @nYid         int=0,
    @isaddDate    int=0, 
    @szSClass_ID VARCHAR(30)='%%'
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @nPid is null  SET @nPid = 0
if @nYid is null  SET @nYid = 0
if @EndDate is null  SET @EndDate = 0
if @szSClass_ID is null  SET @szSClass_ID = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
/*SET NOCOUNT ON*/
  IF @szSClass_ID='' SELECT @szSClass_ID='%%' else select @szSClass_ID=@szSClass_ID+'%'
declare @lenth tinyint 
 	if @szParent_id ='000000' set @lenth = 6 else set @lenth = len(@szParent_id)+6
declare @likeParentclassid varchar(30)
select @likeParentclassid = case @szParent_id when '000000' then '%' else @szParent_id+'%' end

  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
 
  create table #Companytable([id] int)
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权   */
/*----------不选择机构*/

  if @nYid=0 
  begin
				SELECT  vp.Class_ID as PClass_id,
					ISNULL(a.salequantity,0) AS salequantity,/*销售数量*/
					ISNULL(a.saletotal,0) AS saletotal,/*销售金额*/
					ISNULL(a.buyquantity,0) AS buyquantity,/*采购数量*/
					ISNULL(a.buytotal,0) AS buytotal,/*采购金额*/
					ISNULL(a.losequantity,0) AS losequantity,/*报损数量*/
					ISNULL(a.loseTotal,0) AS loseTotal,/*报损金额*/
					ISNULL(a.overflowquantity,0) AS overflowquantity,/*报溢数量*/
					ISNULL(a.overflowtotal,0) AS overflowtotal,/*报溢金额*/
					ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) AS sqcQuantity,/*上期数量*/
					ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTotal,/*上期金额*/
				    ISNULL(a.ComRecquantity,0) AS ComRecquantity,/*机构收货数量*/
					ISNULL(a.ComRecTotal,0) AS ComRecTotal,/*机构收货金额*/
					ISNULL(a.ComSendquantity,0.0) AS ComSendquantity,/*机构发货数量*/
					ISNULL(a.ComSendTotal,0.0) AS ComSendTotal,/*机构发货金额*/
					isnull(kc.kcqty,0.0) as kcqty/*库存数量*/
					,ISNULL(kc.kctotal,0.0)as kctotal/*库存金额 */
					,ISNULL(a.costtaxtotal,0.0)as taxcosttotal/*销售成本金额*/
					,ISNULL(cj.buytjtotal,0.0) as buytjtotal/*采购调价金额*/
					,ISNULL(a.SaleStoreTotal,0.0) as SaleStoreTotal/*出库单金额*/
					,ISNULL(a.CbTjTotal,0.0) as CbTjTotal/*成本调价金额*/
					,ISNULL(a.cbtjqty,0.0) as cbtjqty/*成本调价数量*/
			        ,ISNULL(a.SaleStoreqty,0.0) as SaleStoreqty/*出库单数量*/
			        ,ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) AS bqcTotal/*本期金额*/
			        ,ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) AS bqcQuantity /*本期数量*/
					
				INTO #jxctable
				FROM (select * from Products where deleted <> 1 and IsSplit=0) vp
				LEFT JOIN
					 (
					   SELECT	PClass_id,
						SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.quantity ) ELSE -(k.quantity ) END) ELSE 0 END) AS [salequantity],/*销售数量*/
						SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.taxtotal)  ELSE -(k.taxtotal ) END) ELSE 0 END) AS [saletotal],/*销售金额*/
						SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.costtaxtotal)  ELSE -(k.costtaxtotal ) END) ELSE 0 END) AS [costtaxtotal],/*销售成本金额*/
						sum(CASE WHEN  k.billtype in (20,21)        THEN k.quantity ELSE 0 END) AS [buyquantity],/*采购数量*/
						sum(CASE WHEN  k.billtype in (20,21)        THEN k.taxtotal ELSE 0 END) AS [buytotal],/*采购金额*/
					    sum( Case when  k.billtype in (152,153)  then (case when k.quantity<0 then abs(k.taxtotal) else -(k.taxtotal) end) ELSE 0 END)   AS [ComSendTotal],/*机构发货金额*/
			   			sum( Case when  k.billtype in (152,153)  then (case when k.quantity<0 then abs(k.quantity) else -(k.quantity) end) ELSE 0 END) AS [ComSendquantity],/*机构发货数量*/
			   			sum( Case when  k.billtype in (162,163)  then   k.taxtotal  else 0 end )  AS [ComRecTotal],/*机构收货金额*/
			   			sum( Case when  k.billtype in (162,163)  then   k.quantity  else 0 end )  AS [ComRecquantity],/*机构收货数量*/
						SUM(CASE WHEN  k.billtype =41  and k.aoid in(0,7)    THEN ABS(k.quantity) ELSE 0 END) AS [losequantity],/*报损数量*/
						ABS(SUM(CASE WHEN  k.billtype =41  and k.aoid in(0,7)    THEN k.costtaxtotal ELSE 0 END)) AS [loseTotal],/*报损金额*/
						SUM(CASE WHEN  k.billtype =42  and k.aoid in(0,7)   THEN ABS(k.quantity) ELSE 0 END) AS [overflowquantity],/*报溢数量*/
						ABS(SUM(CASE WHEN  k.billtype =42  and k.aoid in(0,7)    THEN k.costtotal ELSE 0 END)) AS [overflowtotal],/*报溢金额 */
						ABS(SUM(CASE WHEN  k.billtype IN(10) and k.aoid in(0,7)   THEN k.quantity  ELSE 0 END)) AS [SaleStoreqty],/*-出库单数量*/
			            ABS(SUM(CASE WHEN  k.billtype IN(10) and k.aoid in(0,7)   THEN k.taxtotal ELSE 0 END)) AS [SaleStoreTotal],/*-出库单金额*/
		                SUM(CASE when k.billtype  in (43)    THEN (case when k.quantity<0 then abs(k.costtaxtotal) else -(k.costtaxtotal) end) ELSE 0 END) AS [CbTjTotal],/*成本调价金额*/
		                SUM(CASE WHEN k.billtype  IN(43)     THEN (case when k.quantity<0 then abs(k.quantity) else -(k.quantity) end) ELSE 0 END) AS [cbtjqty],/*成本调价数量*/
					    ABS(SUM(CASE WHEN  k.quantity<0     THEN k.costtaxtotal ELSE 0 END)) AS [bqcktotal],
					    ABS(SUM(CASE WHEN  k.quantity>0     THEN k.costtaxtotal ELSE 0 END)) AS [bqrktotal],
					    SUM(CASE WHEN  k.quantity<0     THEN ABS(k.quantity) ELSE 0 END) AS [bqckquantity],
					    SUM(CASE WHEN  k.quantity>0     THEN ABS(k.quantity) ELSE 0 END) AS [bqrkquantity]
					   FROM 
						  (
							 select pd.*,isnull(p.class_id,'') as PClass_id
							 from   
								  (select p_id,pd.quantity,costtotal,taxtotal,costtaxtotal,billdate,storetype,aoid,
								    commissionflag,s_id,RowE_id,billtype,bi.Y_id,bi.c_id 
									 from ProductDetail PD
									 inner join billidx bi on pd.billid=bi.billid
									 where (billdate between @begindate and @EndDate) and
									  billstates='0' and pd.storetype=0 and p_id>0
								   )pd                             
								   left JOIN  products  p on p_id=p.product_id  
								   left JOIN  Company   Y on pd.Y_id=Y.company_id
								where  p.class_id like @likeParentclassid
								   and ((pd.p_id=@nPid) or (@nPid=0))
								   AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
						  ) k 
 						   GROUP BY PClass_id
					 )a ON Vp.class_id=a.pclass_id 
				left JOIN
					 ( SELECT p.Class_ID as PClass_id, ISNULL(SUM(pd.quantity),0) AS prequantity,ISNULL(SUM(pd.costtaxtotal),0) AS precosttotal 
						 FROM
						  (select pd.p_id,pd.quantity,pd.costtotal,pd.costtaxtotal,b.billdate,b.billstates,pd.storetype,pd.s_id,b.Y_id,b.c_id,pd.RowE_id
						   from Productdetail pd
							 INNER JOIN  billidx B ON pd.billid=b.billid
						   where  billdate<@BeginDate and b.billstates='0'  AND pd.storetype=0 and p_id>0
						   )pd 
						INNER JOIN products P ON pd.p_id=P.product_id 
    					INNER JOIN Company  Y on pd.Y_id=Y.Company_id 
						WHERE P.class_id like @likeParentclassid+'%' 
						  and  ((pd.p_id=@nPid) or (@nPid=0))
						  and ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
						GROUP BY p.Class_ID
					  )c ON vp.class_id=c.pclass_id
				LEFT JOIN
					(SELECT     P.Class_ID as PClass_id,ISNULL(SUM(si.quantity),0) AS iniquantity,ISNULL(SUM(si.costtaxtotal),0) AS inicosttotal 
					   FROM  storehouseini  si
					  INNER JOIN Products P on P.product_id=si.p_id
					  INNER JOIN Company  Y on si.Y_id=Y.Company_id
					  WHERE si.p_id>0
						and  ((si.p_id=@nPid) or (@nPid=0))
						and p.class_id like @likeParentclassid 
						and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
					  GROUP BY p.Class_ID
					)b ON Vp.class_id=b.PClass_id
				left join 
				   (
					select P.Class_ID as PClass_id,ISNULL(SUM(si.quantity),0.0) as kcqty,ISNULL(SUM(costtotal),0.0)as kctotal,ISNULL(SUM(costtaxtotal),0.0)as costtaxtotal
					from storehouse si
					inner join products p on p.product_id=si.p_id
					INNER JOIN Company  Y on si.Y_id=Y.Company_id
					  WHERE si.p_id>0
						and  ((si.p_id=@nPid) or (@nPid=0))
						and p.class_id like @likeParentclassid
						and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
					  GROUP BY p.Class_ID
					 )kc on Vp.Class_ID=kc.PClass_id
			    left join 
			       (
			         select a.pclass_id,(sum(isnull(a.taxtotal,0))-sum(isnull(b.taxtotal,0))) as buytjtotal   from 
			            (
			               select c.class_id as pclass_id,sum(a.taxtotal) as taxtotal from buymanagebill a inner join billidx b on a.bill_id=b.billid 
			                             left join products c on a.p_id=c.product_id
			                        where b.billdate between @BeginDate and @EndDate
			                        and p_id>0 and billtype in (24)and b.billstates=0
			                         and  ((a.p_id=@nPid) or (@nPid=0))
			                         and c.class_id like @likeParentclassid
			                         and ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))  
			                         group by   c.class_id
			            ) a left join 
			            (
			              select c.class_id as pclass_id,sum(a.taxtotal) as taxtotal from buymanagebill a inner join billidx b on a.bill_id=b.billid 
			                             left join products c on a.p_id=c.product_id
			                        where b.billdate between @BeginDate and @EndDate
			                        and p_id>0 and billtype in (25)and b.billstates=0
			                         and  ((a.p_id=@nPid) or (@nPid=0))
			                         and c.class_id like @likeParentclassid
			                         and ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))  
			                         group by   c.class_id
			            )  b on a.pclass_id=b.pclass_id
			            group by a.pclass_id
			       )cj on vp.class_id=cj.pclass_id
				  order by vp.class_id
  end
  else
  begin
		SELECT  vp.Class_ID as PClass_id,py.company_id as  Y_ID,
			ISNULL(a.salequantity,0) AS salequantity,/*销售数量（零售单，零售退货单）*/
			ISNULL(a.saletotal,0) AS saletotal,/*销售金额*/
			ISNULL(a.buyquantity,0) AS buyquantity,/*采购数量（采购入库单，采购入库退货单）*/
			ISNULL(a.buytotal,0) AS buytotal,/*采购金额*/
			ISNULL(a.losequantity,0) AS losequantity,/*报损数量*/
			ISNULL(a.loseTotal,0) AS loseTotal,/*报损金额*/
			ISNULL(a.overflowquantity,0) AS overflowquantity,/*报溢数量*/
			ISNULL(a.overflowtotal,0) AS overflowtotal,/*报溢金额*/
			ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) AS sqcQuantity,/*上期数量*/
			ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTotal,/*上期金额*/
			ISNULL(a.ComRecquantity,0) AS ComRecquantity,/*机构收货数量*/
			ISNULL(a.ComRecTotal,0) AS ComRecTotal,/*机构收货金额*/
			ISNULL(a.ComSendquantity,0.0) AS ComSendquantity,/*机构发货数量*/
			ISNULL(a.ComSendTotal,0.0) AS ComSendTotal/*机构发货金额*/
			,isnull(kc.kcqty,0.0) as kcqty/*库存数量*/
			,ISNULL(kc.kctotal,0.0)as kctotal /*库存金额*/
			,ISNULL(a.costtaxtotal,0.0)as taxcosttotal/*销售成本金额*/
			,ISNULL(cj.buytjtotal,0.0) as buytjtotal/*采购调价金额*/
		    ,ISNULL(a.SaleStoreTotal,0.0) as SaleStoreTotal/*出库单金额*/
			,ISNULL(a.CbTjTotal,0.0) as CbTjTotal/*成本调价金额*/
			,ISNULL(a.cbtjqty,0.0) as cbtjqty/*成本调价数量*/
			,ISNULL(a.SaleStoreqty,0.0) as SaleStoreqty/*出库单数量*/
			,ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) AS bqcTotal/*本期金额*/
		    , ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) AS bqcQuantity /*本期数量*/
		INTO #jxctableOne
		FROM (select * from Products where deleted <> 1 and IsSplit=0) vp
		left join (select product_id,company_id from products cross join company where ((company_id=@nYid) or (@nYid=0))) py on vp.product_id=py.product_id 
		LEFT JOIN
			 (
			   SELECT	PClass_id,k.Y_ID,
				  SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.quantity ) ELSE -(k.quantity ) END) ELSE 0 END) AS [salequantity],/*销售数量*/
						SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.taxtotal)  ELSE -(k.taxtotal ) END) ELSE 0 END) AS [saletotal],/*销售金额*/
						SUM(CASE WHEN  k.billtype IN(12,13)    THEN (CASE WHEN k.quantity<0 THEN ABS(k.costtaxtotal)  ELSE -(k.costtaxtotal ) END) ELSE 0 END) AS [costtaxtotal],/*销售成本金额*/
						sum(CASE WHEN  k.billtype in (20,21)        THEN k.quantity ELSE 0 END) AS [buyquantity],/*采购数量*/
						sum(CASE WHEN  k.billtype in (20,21)        THEN k.taxtotal ELSE 0 END) AS [buytotal],/*采购金额*/
					    sum( Case when  k.billtype in (152,153)  then (case when k.quantity<0 then abs(k.taxtotal) else -(k.taxtotal) end) ELSE 0 END)   AS [ComSendTotal],/*机构发货金额*/
			   			sum( Case when  k.billtype in (152,153)  then (case when k.quantity<0 then abs(k.quantity) else -(k.quantity) end) ELSE 0 END) AS [ComSendquantity],/*机构发货数量*/
			   			sum( Case when  k.billtype in (162,163)  then   k.taxtotal  else 0 end )  AS [ComRecTotal],/*机构收货金额*/
			   			sum( Case when  k.billtype in (162,163)  then   k.quantity  else 0 end )  AS [ComRecquantity],/*机构收货数量*/
						SUM(CASE WHEN  k.billtype =41  and k.aoid in(0,7)    THEN ABS(k.quantity) ELSE 0 END) AS [losequantity],/*报损数量*/
						ABS(SUM(CASE WHEN  k.billtype =41  and k.aoid in(0,7)    THEN k.costtaxtotal ELSE 0 END)) AS [loseTotal],/*报损金额*/
						SUM(CASE WHEN  k.billtype =42  and k.aoid in(0,7)   THEN ABS(k.quantity) ELSE 0 END) AS [overflowquantity],/*报溢数量*/
						ABS(SUM(CASE WHEN  k.billtype =42  and k.aoid in(0,7)    THEN k.costtotal ELSE 0 END)) AS [overflowtotal],/*报溢金额 */
						ABS(SUM(CASE WHEN  k.billtype IN(10) and k.aoid in(0,7)   THEN abs(k.quantity)  ELSE 0 END)) AS [SaleStoreqty],/*-出库单数量*/
			            ABS(SUM(CASE WHEN  k.billtype IN(10) and k.aoid in(0,7)   THEN abs(k.taxtotal) ELSE 0 END)) AS [SaleStoreTotal],/*-出库单金额*/
		                SUM(CASE when k.billtype  in (43)    THEN (case when k.quantity<0 then abs(k.costtaxtotal) else -(k.costtaxtotal) end) ELSE 0 END) AS [CbTjTotal],/*成本调价金额*/
		                SUM(CASE WHEN k.billtype  IN(43)     THEN (case when k.quantity<0 then abs(k.quantity) else -(k.quantity) end) ELSE 0 END) AS [cbtjqty],/*成本调价数量*/
		                ABS(SUM(CASE WHEN  k.quantity<0     THEN k.costtaxtotal ELSE 0 END)) AS [bqcktotal],
					    ABS(SUM(CASE WHEN  k.quantity>0     THEN k.costtaxtotal ELSE 0 END)) AS [bqrktotal],
					    SUM(CASE WHEN  k.quantity<0     THEN ABS(k.quantity) ELSE 0 END) AS [bqckquantity],
					    SUM(CASE WHEN  k.quantity>0     THEN ABS(k.quantity) ELSE 0 END) AS [bqrkquantity]
			   FROM 
				  (
					 select pd.*,isnull(p.class_id,'') as PClass_id
					 from   
						  (select p_id,pd.quantity,costtotal,taxtotal,costtaxtotal,billdate,storetype,aoid,
						     commissionflag,s_id,RowE_id,billtype,bi.Y_id,bi.c_id 
							 from ProductDetail PD
							 inner join billidx bi on pd.billid=bi.billid
							 where (billdate between @begindate and @EndDate) and
							  billstates='0' and pd.storetype=0 and p_id>0
						   )pd                             
						   left JOIN  products  p on p_id=p.product_id  
						   left JOIN  Company   Y on pd.Y_id=Y.company_id
						where  p.class_id like @likeParentclassid
						   AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
				  ) k 
 				   GROUP BY PClass_id,Y_ID
			 )a ON Vp.class_id=a.pclass_id  and py.company_id=a.Y_ID
		left JOIN
			 ( SELECT p.Class_ID as PClass_id, y_id, ISNULL(SUM(pd.quantity),0) AS prequantity,ISNULL(SUM(pd.costtaxtotal),0) AS precosttotal 
				 FROM
				  (select pd.p_id,pd.quantity,pd.costtotal,pd.costtaxtotal,b.billdate,b.billstates,pd.storetype,pd.s_id,b.Y_id,b.c_id,pd.RowE_id
				   from Productdetail pd
					 INNER JOIN  billidx B ON pd.billid=b.billid
				   where  billdate<@BeginDate and b.billstates='0'  AND pd.storetype=0 and p_id>0
				   )pd 
				INNER JOIN products P ON pd.p_id=P.product_id 
    			INNER JOIN Company  Y on pd.Y_id=Y.Company_id 
				WHERE P.class_id like @likeParentclassid+'%' 
				  and ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
				GROUP BY p.Class_ID,Y_ID
			  )c ON vp.class_id=c.pclass_id and  py.company_id=c.Y_ID
		LEFT JOIN
			(SELECT     P.Class_ID as PClass_id, y_id, ISNULL(SUM(si.quantity),0) AS iniquantity,ISNULL(SUM(si.costtaxtotal),0) AS inicosttotal 
			   FROM  storehouseini  si
			  INNER JOIN Products P on P.product_id=si.p_id
			  INNER JOIN Company  Y on si.Y_id=Y.Company_id
			  WHERE si.p_id>0
				and p.class_id like @likeParentclassid
				and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
			  GROUP BY p.Class_ID,Y_ID
			)b ON Vp.class_id=b.PClass_id and  py.company_id=b.Y_ID
		left join 
		   (
			select P.Class_ID as PClass_id,y_id, ISNULL(SUM(si.quantity),0.0) as kcqty,ISNULL(SUM(costtotal),0.0)as kctotal,ISNULL(SUM(costtaxtotal),0.0)as costtaxtotal
			from storehouse si
			inner join products p on p.product_id=si.p_id
			INNER JOIN Company  Y on si.Y_id=Y.Company_id
			  WHERE si.p_id>0
				and p.class_id like @likeParentclassid 
				and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
			  GROUP BY p.Class_ID,Y_ID
			 )kc on Vp.Class_ID=kc.PClass_id and  py.company_id=kc.Y_ID 
		 left join 
			       (
			         select a.pclass_id,a.Y_ID,(sum(isnull(a.taxtotal,0))-sum(isnull(b.taxtotal,0))) as buytjtotal   from 
			            (
			               select c.class_id as pclass_id,b.y_id, sum(a.taxtotal) as taxtotal from buymanagebill a inner join billidx b on a.bill_id=b.billid 
			                             left join products c on a.p_id=c.product_id
			                        where b.billdate between @BeginDate and @EndDate
			                        and p_id>0 and billtype in (24)and b.billstates=0
			                         and c.class_id like @likeParentclassid
			                         and ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))  
			                         group by   c.class_id,b.y_id
			            ) a left join 
			            (
			              select c.class_id as pclass_id,b.y_id,sum(a.taxtotal) as taxtotal from buymanagebill a inner join billidx b on a.bill_id=b.billid 
			                             left join products c on a.p_id=c.product_id
			                        where b.billdate between @BeginDate and @EndDate
			                        and p_id>0 and billtype in (25)and b.billstates=0
			                        and c.class_id like @likeParentclassid
			                        and ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))  
			                        group by   c.class_id,b.y_id
			            )  b on a.pclass_id=b.pclass_id
			            group by a.pclass_id ,a.Y_ID
			       )cj on vp.class_id=cj.pclass_id and py.company_id=cj.Y_ID
		    order by vp.class_id
  end

 IF @szListFlag='L' 
 begin
  if @nYid=0 
  begin
   SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
    vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
    vp.Factory,
	ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
	ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
	ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
	ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
	ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
	ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
	ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
	ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
	ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
	ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
	ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
    ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
	ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
	ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
	ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
	ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
	isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
	isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
	isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
	,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
	,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
	,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
	, '所有机构' as yname/*机构名称*/
	,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
	,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
     FROM (select * from Products where deleted <> 1 and IsSplit=0 and   ((product_id=@nPid) or (@nPid=0))) vp
     LEFT JOIN (select distinct * from #jxctable) a   ON LEFT(a.[PClass_ID],LEN(vp.[Class_ID]))=vp.[Class_ID]
     LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
     LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
     LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
     LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
     LEFT JOIN
     ( 
         select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1  and b.deleted=0
     )r ON vp.product_id=r.baseinfo_id
      LEFT JOIN
     ( 
         select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
     )m ON vp.product_id=m.baseinfo_id
     LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID]
     LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
    WHERE  vp.parent_id=@szParent_id and vp.deleted<>1 
    Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
        M.name , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory
   order by vp.class_id
  end
  else
  begin
    SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
    vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
    vp.Factory,
	ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
	ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
	ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
	ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
	ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
	ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
	ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
	ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
	ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
	ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
	ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
    ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
	ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
	ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
	ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
	ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
	isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
	isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
	isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
	,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
	,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
	,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
	,isnull(y.name,'') as yname/*机构名称*/
	,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
	,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
		 FROM (select * from Products where deleted <> 1 and IsSplit=0 and   ((product_id=@nPid) or (@nPid=0))) vp
		 inner JOIN (select distinct * from #jxctableOne where ((Y_ID=@nYid) or (@nYid=0))) a   ON LEFT(a.[PClass_ID],LEN(vp.[Class_ID]))=vp.[Class_ID]
		 left  join company y on a.Y_ID=y.company_id
		 LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
		 LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
		 LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
		 LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
		 LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1  and b.deleted=0
		 )r ON vp.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON vp.product_id=m.baseinfo_id
		 LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID]
		 LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
		WHERE  vp.parent_id=@szParent_id and vp.deleted<>1 
		Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
			M.name , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
		U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
			vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory,y.name
	   order by vp.class_id
  end
 end

 IF @szListFlag='P' 
 begin 
   if  @nYid=0 
   begin
		SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
			vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
			vp.Factory,
			ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
			ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
			ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
			ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
			ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
			ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
			ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
			ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
			ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
			ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
			ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
			ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
			ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
			ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
			ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
			ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
			isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
			isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
			isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
			,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
			,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
			,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
			,'所有机构' as yname/*机构名称*/
			,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
			,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
		 FROM (select * from Products where deleted <> 1  and IsSplit=0 and   ((product_id=@nPid) or (@nPid=0))) vp
		 LEFT JOIN #jxctable a   ON a.[PClass_ID]=vp.[Class_ID]
		 LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
		 LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
		 LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
		 LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
		 LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
		 )r ON vp.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON vp.product_id=m.baseinfo_id
		 LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
		 LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
		WHERE LEFT(vp.[Class_ID], LEN(@szParent_id))=@szParent_id and vp.deleted<>1 and vp.[Child_Number]=0
		Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
			M.[name] , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
		U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
			vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory
	   order by vp.class_id
   end
   else
   begin
		SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
				vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
				vp.Factory,
				ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
				ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
				ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
				ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
				ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
				ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
				ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
				ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
				ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
				ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
				ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
				ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
				ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
				ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
				ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
				ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
				isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
				isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
				isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
				,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
				,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
				,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
				,isnull(y.name,'') as yname/*机构名称*/
				,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
				,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
		 FROM (select * from Products where deleted <> 1 and IsSplit=0  and   ((product_id=@nPid) or (@nPid=0))) vp
		 inner JOIN (select distinct * from #jxctableOne where ((Y_ID=@nYid) or (@nYid=0))) a  ON a.[PClass_ID]=vp.[Class_ID]
		 left  join company y on a.Y_ID=y.company_id
		 LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
		 LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
		 LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
		 LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
		 LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
		 )r ON vp.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON vp.product_id=m.baseinfo_id
		 LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
		 LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
		WHERE LEFT(vp.[Class_ID], LEN(@szParent_id))=@szParent_id and vp.deleted<>1 and vp.[Child_Number]=0
		Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
			M.[name] , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
		U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
			vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory,y.name
	   order by vp.class_id
   end
  end

 IF @szListFlag='A' 
 begin
    if @nYid=0 
    begin
		SELECT  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
				vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
				vp.Factory,
				ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
				ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
				ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
				ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
				ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
				ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
				ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
				ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
				ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
				ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
				ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
				ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
				ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
				ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
				ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
				ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
				isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
				isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
				isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
				,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
				,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
				,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
				,'所有机构' as yname/*机构名称*/
				,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
				,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
		 FROM (select * from Products where deleted <> 1 and IsSplit=0 and   ((product_id=@nPid) or (@nPid=0))) vp
		 LEFT JOIN #jxctable a   ON a.[PClass_ID]=vp.[Class_ID]
		 LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
		 LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
		 LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
		 LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
		 LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
		 )r ON vp.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON vp.product_id=m.baseinfo_id
		 LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
		 LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
		WHERE vp.[DELETEd]<>1 and vp.[Child_Number]=0 and vp.[Product_ID]<>1
		Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
			M.name , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
			U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
			vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory
	   order by vp.class_id
	 end
	 else
	 begin
	    SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,
				vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
				vp.Factory,
				ISNULL(sum(a.salequantity),0) AS salequantity,/*销售数量*/
				ISNULL(sum(a.saletotal),0) AS saletotal,/*销售金额*/
				ISNULL(sum(a.buyquantity),0) AS buyquantity,/*采购数量*/
				ISNULL(sum(a.buytotal),0) AS buytotal,/*采购金额*/
				ISNULL(sum(a.losequantity),0) AS losequantity,/*报损数量*/
				ISNULL(sum(a.loseTotal),0) AS loseTotal,/*报损金额*/
				ISNULL(sum(a.overflowquantity),0) AS overflowquantity,/*报溢数量*/
				ISNULL(sum(a.overflowtotal),0) AS overflowtotal,/*报溢金额*/
				ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,/*上期数量*/
				ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,/*上期金额*/
				ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,/*本期数量*/
				ISNULL(sum(a.bqcTotal),0) AS bqcTotal,/*本期金额*/
				ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,/*机构收货数额*/
				ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,/*机构收货金额*/
				ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,/*机构发货数量*/
				ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,/*机构发货金额*/
				isnull(sum(a.kcqty),0.0) as kcqty,/*库存数量*/
				isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,/*销售成本金额*/
				isnull(sum(a.kctotal),0.0) as kctotal/*库存金额*/
				,ISNULL(SUM(a.buytjtotal),0) as buytjtotal/*采购调价金额*/
				,ISNULL(SUM(a.SaleStoreTotal),0) as SaleStoreTotal/*出库单金额*/
				,ISNULL(SUM(a.CbTjTotal),0)  as CbTjTotal/*成本调价金额*/
				,isnull(y.name,'') as yname/*机构名称*/
				,ISNULL(SUM(a.cbtjqty),0)  as cbtjqty/*成本调价数量*/
				,ISNULL(SUM(a.SaleStoreqty),0)  as SaleStoreqty/*出库单数量*/
		 FROM (select * from Products where deleted <> 1 and IsSplit=0 and    ((product_id=@nPid) or (@nPid=0))) vp
		 inner JOIN (select distinct * from #jxctableOne where ((Y_ID=@nYid) or (@nYid=0))) a   ON a.[PClass_ID]=vp.[Class_ID]
		 left join company y   on a.Y_ID=y.company_id
		 LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
		 LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
		 LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
		 LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
		 LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=1 and b.deleted=0
		 )r ON vp.product_id=r.baseinfo_id
		  LEFT JOIN
		 ( 
			 select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
		 )m ON vp.product_id=m.baseinfo_id
		 LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
		 LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
		WHERE vp.[DELETEd]<>1 and vp.[Child_Number]=0 and vp.[Product_ID]<>1
		Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
			M.name , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
			U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
			vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
			vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.name,vp.Factory,y.name
	   order by vp.class_id
	 end
  end

 if OBJECT_ID('tempdb..#jxctableOne') is not null
 drop table #jxctableOne
 if OBJECT_ID('tempdb..#jxctable') is not null
 drop table #jxctable
GO
