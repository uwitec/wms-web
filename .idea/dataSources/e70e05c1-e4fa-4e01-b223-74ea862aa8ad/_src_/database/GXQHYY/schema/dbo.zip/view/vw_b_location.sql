

CREATE	 VIEW dbo.vw_b_location
AS
SELECT loc_id as l_id, loc_name as l_name,Shelfid as slid
FROM location
WHERE deleted = 0
GO
