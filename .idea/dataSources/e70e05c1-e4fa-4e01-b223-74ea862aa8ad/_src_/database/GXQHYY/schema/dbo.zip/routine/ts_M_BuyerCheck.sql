

CREATE proc ts_M_BuyerCheck
(
  @szEClass_ID 		varchar(100)='000000',
  @szListFlag		VARCHAR(1)='L',		  /*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
  @nY_ID			int = '0'
)
as
/*Params Ini begin*/
if @szEClass_ID is null  SET @szEClass_ID = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nY_ID is null  SET @nY_ID = '0'
/*Params Ini end*/

/*TS_C_QrStoreHouse	*/

IF @szListFlag='L'      GOTO ListLeavel
IF @szListFlag='A' 	GOTO ListAll

/*-------------------------------------------*/
/*当前库存，分级列表*/
/*-------------------------------------------*/
ListLeavel:
begin
  if @szEClass_ID in ('') set @szEClass_ID = '000000'

  select
  E.[emp_id], E.[class_id], E.[parent_id], E.[child_number], E.[child_count],
  E.[name], E.[alias], E.[serial_number], E.[phone], E.[address],

  PCount = ISNULL(P1.PCount,0), /*负责品种总数*/
  NQCount = ISNULL(P2.NQCount,0),/*断货品种数*/
  NQRate = (case when (ISNULL(P1.PCount,0) <> 0) then (cast(ISNULL(P2.NQCount,0) as numeric(8,4))/cast(ISNULL(P1.PCount,0) AS numeric(8,4))) 
                 else 0 end),
  /*断货率=断货品种数/该采购员负责品种总数*/
  ULCount = ISNULL(P3.ULCount,0),/*上限品种数*/
  ULRate = (case when (ISNULL(P1.PCount,0) <> 0) then (cast(ISNULL(P3.ULCount,0) as numeric(8,4))/ cast(ISNULL(P1.PCount,0)as numeric(8,4)))  
                 else 0 end),
  /*上限率=上限品种数/该采购员负责品种总数*/
  /*下限*/
  LLCount = ISNULL(P4.LLCount,0),/*上限品种数*/
  LLRate = (case when (ISNULL(P1.PCount,0) <> 0) then (cast(ISNULL(P4.LLCount,0) AS numeric(8,4))/cast(ISNULL(P1.PCount,0) AS numeric(8,4))) 
                 else 0 end)
  from employees E 
  /*负责品种总数: 以每个品种资料中主采购员为准，品种总数即为该采购员所负责的所有品种数*/
  left join 
   (  select Emp_ID,PCount=count(Emp_ID) from Products P 
        inner join (select * from productbalance where Y_id = @nY_ID) pb on p.product_id = pb.p_id
      where Pb.Emp_ID<>0 and P.child_number=0 and P.deleted=0
      group by Pb.Emp_ID 
    )P1 on E.Emp_Id = P1.Emp_Id
  /*断货品种数: 商品资料里增加断货数量字段，所有库存余量低于设定的值的品种数*/
  left join 
   (  select Emp_ID,NQCount=count(Emp_ID) from 
      (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
      left join (select p1.product_id, pb.Emp_id,p1.NoneQuantity from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where  pb.Y_id = @nY_ID and Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0 
      ) P on P.Product_ID = SH.P_ID 
      where  SH.quantity < P.NoneQuantity
      group by P.Emp_ID
    )P2 on E.Emp_Id = P2.Emp_Id
  /*上限品种数：所有库存余量超过所有仓库的库存上限报警设定的值的品种数*/
  left join 
   (  select Emp_ID,ULCount=count(Emp_ID) from 
      (select P_ID,UpperLimit=sum(UpperLimit) from StoreLimit  group by P_ID) SL
      left join (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
         on SH.P_ID = SL.P_ID 
      left join (select p1.product_id, pb.Emp_id from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where pb.Y_id =@nY_ID and  Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0       
      ) P on P.Product_ID = SL.P_ID 
      where SH.quantity > SL.UpperLimit
      group by P.Emp_ID
    )P3 on E.Emp_Id = P3.Emp_Id
  /*下限品种数*/
  left join 
   (  select Emp_ID,LLCount=count(Emp_ID) from 
      (select P_ID,LowLimit=sum(LowLimit) from StoreLimit  group by P_ID) SL
      left join (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
         on SH.P_ID = SL.P_ID 
      left join (select p1.product_id, pb.Emp_id from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where pb.Y_id = @nY_ID and Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0 
                )P on P.Product_ID = SL.P_ID 
      where 
           SH.quantity < SL.LowLimit
      group by P.Emp_ID
    )P4 on E.Emp_Id = P4.Emp_Id
  
  Where  E.deleted=0 and E.[Parent_ID]=@szEClass_ID and e.y_id=@ny_id /*zh100914*/

  RETURN 0
end

/*-------------------------------------------*/
/*当前库存，全部列表*/
/*-------------------------------------------*/
ListAll:
begin

  set @szEClass_ID = @szEClass_ID + '%'
  
  select
  E.[emp_id], E.[class_id], E.[parent_id], E.[child_number], E.[child_count],
  E.[name], E.[alias], E.[serial_number], E.[phone], E.[address],

  PCount = ISNULL(P1.PCount,0), /*负责品种总数*/
  NQCount = ISNULL(P2.NQCount,0),/*断货品种数*/
  NQRate = (case when (ISNULL(P1.PCount,0) <> 0) then ((cast(ISNULL(P2.NQCount,0) as numeric(8,4))/ cast(ISNULL(P1.PCount,0) as numeric(8,4)))*100) 
                 else 0 end),
  /*断货率=断货品种数/该采购员负责品种总数*/
  ULCount = ISNULL(P3.ULCount,0),/*上限品种数*/
  ULRate = (case when (ISNULL(P1.PCount,0) <> 0) then ((cast(ISNULL(P3.ULCount,0) as numeric(8,4))/ cast(ISNULL(P1.PCount,0) as numeric(8,4)))*100) 
                 else 0 end),
  /*上限率=上限品种数/该采购员负责品种总数*/
  /*下限*/
  LLCount = ISNULL(P4.LLCount,0),/*上限品种数*/
  LLRate = (case when (ISNULL(P1.PCount,0) <> 0) then ((cast(ISNULL(P4.LLCount,0) as numeric(8,4))/ cast(ISNULL(P1.PCount,0) AS numeric(8,4)))*100) 
                 else 0 end)
  from employees E 
  /*负责品种总数: 以每个品种资料中主采购员为准，品种总数即为该采购员所负责的所有品种数*/
  left join 
   (  select pb.Emp_ID,PCount=count(pb.Emp_ID) from Products P 
      inner join productbalance pb on p.product_id = pb.p_id
      where pb.y_id = @nY_ID and  Pb.Emp_ID<>0 and P.child_number=0 and P.deleted=0
      group by Pb.Emp_ID 
    )P1 on E.Emp_Id = P1.Emp_Id
  /*断货品种数: 商品资料里增加断货数量字段，所有库存余量低于设定的值的品种数*/
  left join 
   (  select Emp_ID,NQCount=count(Emp_ID) from 
      (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
      left join (select p1.product_id, pb.Emp_id, p1.NoneQuantity from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where pb.Y_id = @nY_ID and Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0 
        ) P on P.Product_ID = SH.P_ID 
      where 
            SH.quantity < P.NoneQuantity
      group by P.Emp_ID
    )P2 on E.Emp_Id = P2.Emp_Id
  /*上限品种数：所有库存余量超过所有仓库的库存上限报警设定的值的品种数*/
  left join 
   (  select Emp_ID,ULCount=count(Emp_ID) from 
      (select P_ID,UpperLimit=sum(UpperLimit) from StoreLimit  group by P_ID) SL
      left join (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
         on SH.P_ID = SL.P_ID 
      left join (select p1.product_id, pb.Emp_id from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where pb.Y_id = @nY_ID and Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0 
                 ) P on P.Product_ID = SL.P_ID 
      where 
             SH.quantity > SL.UpperLimit
      group by P.Emp_ID
    )P3 on E.Emp_Id = P3.Emp_Id
  /*下限品种数*/
  left join 
   (  select Emp_ID,LLCount=count(Emp_ID) from 
      (select P_ID,LowLimit=sum(LowLimit) from StoreLimit  group by P_ID) SL
      left join (select P_ID,quantity=sum(quantity) from storehouse  group by P_ID) SH
         on SH.P_ID = SL.P_ID 
      left join (select p1.product_id, pb.Emp_id from Products p1 inner join productbalance pb on p1.product_id = pb.p_id
                 where pb.Y_id = @nY_ID and Pb.Emp_ID <> 0 and P1.child_number = 0 and P1.deleted=0 
      ) P on P.Product_ID = SL.P_ID 
      where 
            SH.quantity < SL.LowLimit
      group by P.Emp_ID
    )P4 on E.Emp_Id = P4.Emp_Id
  
  Where  E.deleted=0 and E.child_number = 0  and E.[Class_ID] like @szEClass_ID  and e.y_id=@ny_id /*zh100914*/

  RETURN 0
end
GO
