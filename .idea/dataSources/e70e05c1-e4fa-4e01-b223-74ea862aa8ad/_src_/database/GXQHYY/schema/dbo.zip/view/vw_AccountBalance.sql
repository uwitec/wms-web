

CREATE VIEW dbo.vw_AccountBalance
AS

SELECT 
	AB.*,
	A.ACCOUNT_ID,A.CLASS_ID, A.PARENT_ID, A.CHILD_NUMBER,A.CHILD_COUNT,A.[NAME],A.ALIAS,
	A.SERIAL_NUMBER, A.COMMENT,A.SYSFLAG,          
	A.SYSROW,   A.DELETED,
	A.PINYIN, 
	A.CASHAUDIT,   A.DIRECTION, A.RowIndex,
	(CASE A.UseForPos WHEN 0 THEN '否' else '是' end) as ifUseForPos,A.YBaccount
FROM 		dbo.accountBalance 	AB 
INNER JOIN 	dbo.account 	  	A	ON  A.Account_id=AB.a_id
WHERE (A.deleted = 0)

/*
select rowindex,* from dbo.account
select * from dbo.accountBalance
*/
GO
