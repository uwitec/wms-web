



CREATE	    VIEW dbo.vw_b_Products
AS
SELECT p.product_id as p_id, p.class_id as pclass_id,p.name,p.standard,p.modal,p.makearea,f.AccountComment as Factory,p.BulidNo,p.RegisterNo,p.comment, p.permitcode, p.trademark, p.costmethod,p.rate2 as UNITRATE2,
p.rate3 as UNITRATE3,p.rate4 as UNITRATE4, p.ValidMonth, p.validday,  p.child_number,  p.otcflag, p.alias, p.GspFlag, p.PackStd , p.StorageCon, p.OTCType, p.r_id,
isnull(pc.Pc_Name,'') as PcName,
isnull(pc.Pc_Code,'') as pcCode,
ISNULL(m.mt_name,'') as medtype,  p.medtype as medtype_id,
ISNULL(u1.U_name,'') as unit1, 
ISNULL(u2.U_name,'') as unit2, 
ISNULL(u3.U_name,'') as unit3, 
ISNULL(u4.U_name,'') as unit4,
ISNULL(u5.U_name,'') as unitcl,
p.cldw,Unit1_id, Unit2_id, Unit3_id, Unit4_id,p.sfcl,p.hsbl,
Serial_Number as Code,IsSplit
/*ISNULL((select top 1 barcode as code from barcode where  p.product_id = p_id order by barcode_id),'') AS Code*/
,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,p.Inputdate,p.Inputman,p.pinyin,p.IfZYCheck,
(case when p.WholeUnit_id=p.unit2_id then p.rate2 
      when p.wholeunit_id=p.unit3_id then p.rate3 
      when p.wholeunit_id=p.unit4_id then p.rate4 else 1 end)as Wholerate ,
      factoryc_id
FROM products p
left join basefactory f  on p.factoryc_id=f.CommID
left join vw_b_medtype m on p.medtype = m.mt_id
left join vw_b_unit u1   on p.Unit1_id = u1.U_id
left join vw_b_unit u2   on p.Unit2_id = u2.U_id
left join vw_b_unit u3   on p.Unit3_id = u3.U_id 
left join vw_b_unit u4   on p.Unit4_id = u4.U_id 
left join PrintClass pc  on p.PrintClass = pc.Pc_ID
left join vw_b_unit u5   on p.cldw = u5.U_id
WHERE p.deleted <> 1 and p.IsSplit  = 0
GO
