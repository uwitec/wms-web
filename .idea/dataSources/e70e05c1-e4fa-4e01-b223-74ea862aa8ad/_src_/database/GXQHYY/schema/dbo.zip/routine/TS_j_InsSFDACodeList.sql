create procedure TS_j_InsSFDACodeList
  @piatsCode varchar(100),
  @parentCode varchar(20),
  @codeLevel varchar(10),
  @code varchar(20)
as

begin   
   declare @smb_id int 
     select top 1  @smb_id = smb_id from SFDA_SingleCodeRelation where piatsCode = @piatsCode
   if @smb_id is null set @smb_id =0
   
   insert into [SFDA_SCRCodeInfoList](smb_id, parentCode, codeLevel, code)
    values(@smb_id, @parentCode, @codeLevel, @code)
    /* 写入 sfdalist*/
    
    declare @p_id int /*, @batchNo varchar(30), @validdate datetime, @makedate datetime, @s_id int, @y_id int*/
    select top 1  @p_id = product_id from  products where  commodityCode =  LEFT(@piatsCode, 7)  and child_number = 0 and deleted = 0
    if @p_id is null set @p_id = 0
    if @p_id > 0 
      update SFDA_SingleCodeRelation set product_id = @p_id where piatsCode = @piatsCode              
end
GO
