
CREATE	PROCEDURE [ts_L_SelGSPBill] 
(@lBilltype int, 
 @dBeginDate	Datetime,
 @dEndDate	datetime,
 @nDraft	tinyint,
 @nC_id 	int=0,
 @InputmanID    int=0,
 @nY_ID         int=0
)
AS
/*Params Ini begin*/
if @nC_id is null  SET @nC_id = 0
if @InputmanID is null  SET @InputmanID = 0
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/
/*
2201; //【GSP】本企业经营进口品种一览表
2204; //【GSP】药品采购进货计划表
2205; //【GSP】药品购进记录
2206; //【GSP】药品进货情况质量评审表

2220; //【GSP】药品到货请验单
2221; //【GSP】药品验收抽样记录
2222; // 【GSP】购进药品验收记录
2403: //【GSP】生物制剂验收记录
2223; // 【GSP】退回药品验收记录
2224; //【GSP】药品验收抽（送）验单
2228; //【GSP】化验原始记录
2229;  //【GSP】计量器具管理台帐
2230; //【GSP】药品收货记录
2235; //【GSP】强制检定工作计量器具定期检定记录卡
2236; //【GSP】非强制检定计量器具检定记录卡
2237;  //【GSP】精密仪器使用记录
2238; //【GSP】滴定液配制及标化记录
2239;  //【GSP】滴定液标签
2240; //【GSP】上年度药品进货批次汇总表
2241;  //【GSP】年度药品抽验批次汇总表
2242; //【GSP】年度药品抽验质量汇总表
2243; //【GSP】验收入库通知单
2244; //【GSP】药品到货拒收报告单
2245; //【GSP】药品入库记录
2230; //【GSP】药品收货记录 
2246; //【GSP】购进药品退出记录
2247; //【GSP】不合格药品报废销毁审批表
2248; //【GSP】不合格药品报表
2249; //【GSP】不合格药品报损审批表
2250; //【GSP】不合格药品报废销毁记录
2251; //【GSP】不合格药品台帐
2252; //【GSP】注射剂澄明度检查记录

2255; //【GSP】中药饮片装斗复核记录

2260; //【GSP】顾客资格审核表
2261;  //【GSP】定单确认表
2262; //【GSP】药品销售记录
2263; //【GSP】药品直调记录表
2264; //【GSP】销出药品追回记录
2265; //【GSP】药品不良反应报告表

2271; //【GSP】近效期药品标志牌
2272; //【GSP】已销出药品退(换)货审批表
2273; //【GSP】已销药品退货通知单
2274; //【GSP】销出药品退回记录
2275; //【GSP】中药材/饮片在库养护记录表
2276; //【GSP】库存药品养护检查记录
2277; //【GSP】药品停售通知单
2278; //【GSP】药品质量复检通知单
2279;  //【GSP】药品养护质量报表
2280; //【GSP】药品养护档案卡
2281;  //【GSP】解除停售通知单
2282;  //【GSP】近效期药品催销月报表
2283;  //【GSP】养护设备使用记录

2285; //【GSP】药品出库复核记录
2402; //【GSP】药品运输记录

2408; // 【GSP】生物制品出库复核记录
2410; // 【GSP】生物制品运输记录
2409; // 【GSP】生物制品销售记录
2403; // 【GSP】生物制剂验收记录
2404; // 【GSP】生物药品入库验收记录
2405; // 【GSP】生物制品购进记录
2406; // 【GSP】生物制品购进验收记录
2407; // 【GSP】生物制品入库记录

2414;  // 【GSP】疫苗接收记录台帐
2415;  // 【GSP】疫苗验收记录台帐
2416;  // 【GSP】疫苗购进记录台帐
2417;  // 【GSP】疫苗出库复核记录台帐
2418;  // 【GSP】疫苗药品销售记录台帐
2419;  // 【GSP】疫苗退货记录台帐
2608;  // 【GSP】冷藏药品运输记录
2609;  // 【GSP】冷藏药品验收记录   
2610;  // 【GSP】采购委托书
*/

IF @lBilltype in (-1021,2451) 
BEGIN
	/*检验报告调用 【GSP】药品销售记录(零售)*/
	SELECT *
	FROM   vw_l_BillIdx g
	WHERE  (g.billDate >= @dBeginDate AND G.BillDate <= @dEndDate)
	       AND g.billtype IN (10, 11, 12, 13, 20, 110, 44, 45, 48, 49, 53, 56, 55, 56, 120, 212, 222)
	       AND (@InputmanID = 0 OR (g.inputman = @InputmanID))
	       AND g.y_id = @nY_ID
END

if @lBilltype in (2205,2221,2222,2220,2252,2243,2204,2245,2253,2256,2257,2289,2268,2403,2404,2405,2406,2407,2414,2415,2416,2422,
                  2423,2424,2425,2426,2427,2432,2433,2434,2431,2435,2436,2450,2230,2609,2619)	 
/*【GSP】药品购进记录【GSP】购进药品验收记录【GSP】药品到货请验单*/
begin
	if @nDraft =0 
	begin
		if @nC_id=0  
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.billtype in (48,20,120,55,56,11,222,160, 162) 
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) 
                       AND g.y_id = @nY_ID /*OR (g.billtype=152 and g.c_id=@nY_ID)) */


		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.billtype in (48,20,120,55,56,11,222,160,162) and g.C_id=@nC_id and (@InputmanID=0 or (g.inputman=@InputmanID)) and 
                       g.y_id = @nY_ID /*OR (g.billtype=152 and g.c_id=@nY_ID)) */

	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.billtype in (48,20,120,55,56,11,222,160,162)
                        and (@InputmanID=0 or (g.inputman=@InputmanID)) and 
                        g.y_id = @nY_ID /*OR (g.billtype=152 and g.c_id=@nY_ID)) */
		else
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.billtype in (48,20,120,55,56,11,222,160,162) and g.C_id=@nC_id
                        and (@InputmanID=0 or (g.inputman=@InputmanID)) and 
                        g.y_id = @nY_ID /*OR (g.billtype=152 and g.c_id=@nY_ID)) */


	end

end

if @lBilltype in (2246,2419,2421)	 /*【GSP】购进药品退出记录*/
begin
	if @nDraft=0 
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (49,21,121,54, 161, 163,20)
                        and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (49,21,121,54, 161, 163,20) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (49,21,121,54, 161, 163,20)
                       and (@InputmanID=0 or (g.inputman=@InputmanID))  and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (49,21,121,54, 161, 163,20) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID

	end
end

if @lBilltype in (2613,2285,2262,2263,2204,2401,2408,2410,2409,2417,2418,2428,2429,2430,2437,2438,2439,2440,2441,2442,2443,2620)  /*【GSP】药品出库复核记录 --【GSP】药品销售记录--【GSP】药品直调记录表	*/
begin
	if @nDraft=0 
	begin
		if @nC_id=0
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,49,110,12,13,53,56,44,45,212,150, 161, 163)
                      and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,49,110,12,13,53,56,44,45,212,150, 161, 163) and g.C_id=@nC_id
                      and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,49,110,12,13,53,56,44,45,212,150, 161, 163)
                      and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,49,110,12,13,53,56,44,45,212,150, 161, 163) and g.c_id=@nC_id
                      and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end
end

if @lBilltype in (2223,2274,2420)	 /*【GSP】购进药品退出记录*/
begin
	if @nDraft=0
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (11,13,111,54,56,151,161,163,10) and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (11,13,111,54,56,151,161,163,10) and g.C_id=@nC_id and (@InputmanID=0 or (g.inputman=@InputmanID)) and 
			g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (11,13,111,54,56,161,163,10) and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillDraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (11,13,111,54,56,161,163,10) and g.c_id=@nC_id and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end

end

/*if @lBilltype=2220  --【GSP】药品到货请验单
begin
	select * 
	from vw_GSPIndex g 
	Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
		and g.Checkstate='2' and GSPType in (2205)
end*/


if @lBilltype in (2255)	 /*【GSP】中药饮片装斗复核记录*/
begin
	if @nDraft=0 
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,20,44,45) and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,20,44,45) and g.c_id=@nC_id and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,20,44,45) and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,20,44,45) and g.c_id=@nC_id and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID

	end
END
if @lBilltype in (2251)	 /*【GSP】不合格药品台账*/
begin
	if @nDraft=0 
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (48,20,120,55,56,11,222,160, 162,10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210)
                        and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (48,20,120,55,56,11,222,160, 162,10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163, 210) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (48,20,120,55,56,11,222,160, 162,10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210)
                       and (@InputmanID=0 or (g.inputman=@InputmanID))  and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (48,20,120,55,56,11,222,160, 162,10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID

	end
end
if @lBilltype in (2402,2264,2444,2608)	 /*【GSP】药品运输记录,销出药品追回记录*/
begin
	if @nDraft=0 
	begin
		if @nC_id=0 
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210)
                        and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BillIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163, 210) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID
	end else
	begin
		if @nC_id=0 
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210)
                       and (@InputmanID=0 or (g.inputman=@InputmanID))  and g.y_id = @nY_ID
		else
		select * 
		from vw_l_BilldraftIdx g 
		Where (g.billDate>=@dBeginDate and G.BillDate<=@dEndDate) 
			and G.Billtype in (10,11,21,41,44,45,49,53,54,56,110,111,121,151,212,161,163,210) and g.c_id=@nC_id
                       and (@InputmanID=0 or (g.inputman=@InputmanID)) and g.y_id = @nY_ID

	end
end
GO
