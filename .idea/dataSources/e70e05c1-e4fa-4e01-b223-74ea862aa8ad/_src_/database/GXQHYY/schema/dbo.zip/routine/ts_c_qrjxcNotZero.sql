
/*************************************************

全能进销存变动表,有成本赠品
zhh 2007.10.18
*************************************************/
CREATE PROCEDURE [ts_c_qrjxcNotZero]
(	@BeginDate 	  DATETIME=0,
	@EndDate		  DATETIME=0,
	@szSClass_ID	VARCHAR(30)='%%',
        @szEClass_id    varchar(50)='%%',
	@szParent_id	VARCHAR(30)='000000',
	@szListFlag   VARCHAR(1)='L',
        @nYClassid                 varchar(100)='',
        @nloginEID               int=0,
        @isaddDate              int=0 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szSClass_ID is null  SET @szSClass_ID = '%%'
if @szEClass_id is null  SET @szEClass_id = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
	SET NOCOUNT ON
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)


/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

  IF @szSClass_ID='' SELECT @szSClass_ID='%%'
  IF @szEClass_id='' Select @szEclass_id='%%'

	IF @szListFlag='L' GOTO leveallist
	IF @szListFlag='P' GOTO partlist
	IF @szListFlag='A' GOTO alllist
leveallist:
		SELECT p.Class_ID,p.product_id AS product_id,p.child_number AS child_number,p.[name] AS [name],p.[code] AS code,
			p.standard AS standard,p.makearea as makearea,p.medname AS medtype, p.[trademark] as [trademark], p.[permitcode] as [permitcode],
                        p.[unit1name] as [unitname1], p.[rate2] AS [rate2], p.[rate3] AS [rate3], p.[rate4] AS [rate4],  p.[unit2name] AS [unitname2], p.[unit3name] AS [unitname3],  p.[unit4name] AS [unitname4],
                        P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
                        ISNULL(SUM(b.bqckquantity),0) as bqckquantity,
						ISNULL(SUM(b.bqrkquantity),0) as bqrkquantity,
						isnull(SUM(b.bqrkquantity-b.bqckquantity),0) as totalQuantity,
						cast(ISNULL(SUM(b.bqckJe),0) as numeric(25,8)) as bqckJe,
						cast(ISNULL(SUM(b.bqrkJe),0) as numeric(25,8)) as bqrkJe,
					    cast(ISNULL(SUM(b.bqckcct),0) as numeric(25,8)) as bqckcct,
		                cast(ISNULL(SUM(b.bqrkcct),0) as numeric(25,8)) as bqrkcct,
		                cast(ISNULL(SUM(b.bqcktt),0) as numeric(25,8)) as bqcktt,
		                cast(ISNULL(SUM(b.bqrktt),0) as numeric(25,8)) as bqrktt,
						cast(isnull(SUM(b.bqrkJe-b.bqckJe),0) as numeric(25,8)) as totalJe,
						cast(isnull(SUM(b.bqrktt-b.bqcktt),0) as numeric(25,8)) as totalttJe,
						isnull(SUM(b.bqckSendQTY),0) as bqckSendQTY,
						isnull(SUM(b.bqrkSendQTY),0) as bqrkSendQTY,
						CAST(isnull(SUM(b.bqckSendJe),0) as numeric(25,8)) as bqckSendJe,
						CAST(isnull(SUM(b.bqrkSendJe),0) as numeric(25,8)) as bqrkSendJe 
		FROM vw_products p LEFT JOIN
                       (SELECT PD.PClass_ID,
					   (CASE WHEN  pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
					   (CASE WHEN  pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
					   (CASE WHEN  pd.quantity<0 THEN ABS(pd.costtotal) ELSE 0 END) AS [bqckJe],
					   (CASE WHEN  pd.quantity>0 THEN ABS(pd.costtotal) ELSE 0 END) AS [bqrkJe],
					   (CASE WHEN  pd.quantity<0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqckcct],
			           (CASE WHEN  pd.quantity>0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqrkcct],
			           (CASE WHEN  pd.quantity<0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqcktt],
			           (CASE WHEN  pd.quantity>0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqrktt],
					   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqckSendQTY],
					   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqrkSendQTY],
					   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY*pd.costtotal/pd.quantity) ELSE 0 END) AS [bqckSendJe],
					   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY*pd.costtotal/pd.quantity) ELSE 0 END) AS [bqrkSendJe]
			   FROM 
                ( select PClass_ID=p.class_id, pd.quantity, pd.SendQTY, pd.s_id, pd.costtotal,pd.costtaxtotal,pd.taxtotal
				   from ProductDetail PD 
				   inner join BillIDX bi on pd.billid=bi.billid
				   left join Products p on pd.p_id=p.product_id
				   left join storages S on pd.s_id=S.storage_id
				   left join Company  Y on Y.company_id = PD.Y_ID
				   left join employees  E on PD.RowE_id=E.emp_id			 
				   where    bi.billtype in (10,11,12,13,20,21,53,54,55,56,210,211,220,221,150,151,160,161)
                           and bi.billdate between  @BeginDate and @EndDate    
		                   and PD.p_ID>0 AND PD.aoid=7 and pd.storetype=0             
                           and bi.billstates='0'
                           and S.class_id like @szSClass_ID+'%'
                           and E.class_id like @szEClass_id+'%'
                       and S.Class_ID like @szSClass_ID+'%' AND billstates='0'
				   AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
				   AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
			           AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
			           AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
			           AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
                                 )PD
                                  LEFT JOIN Storages s ON s.storage_id=pd.s_id
			    ) AS b
		 	on	LEFT(b.PClass_ID,LEN(P.Class_ID))=p.Class_ID
			WHERE p.parent_id=@szParent_id AND p.deleted<>1 AND p.product_id<>1
			GROUP BY  p.Class_ID,p.product_id ,p.child_number ,p.[name] ,p.[code] ,
			p.standard ,p.makearea ,p.medname , p.[trademark] , p.[permitcode],
            p.[unit1name] , p.[rate2] , p.[rate3] , p.[rate4],p.[unit2name] ,p.[unit3name],p.[unit4name],
            P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5
  GOTO SUCCEE

partlist:
		SELECT p.Class_ID,p.product_id AS product_id,p.child_number AS child_number,p.[name] AS [name],p.[code] AS code,
			p.standard AS standard,p.makearea as makearea,p.medname AS medtype, p.[trademark] as [trademark], p.[permitcode] as [permitcode],
            p.[unit1name] as [unitname1], p.[rate2] AS [rate2], p.[rate3] AS [rate3], p.[rate4] AS [rate4],  p.[unit2name] AS [unitname2], p.[unit3name] AS [unitname3],  p.[unit4name] AS [unitname4],
            P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
            ISNULL(SUM(b.bqckquantity),0) as bqckquantity,
			ISNULL(SUM(b.bqrkquantity),0) as bqrkquantity,
			isnull(SUM(b.bqrkquantity-b.bqckquantity),0) as totalQuantity,
			cast(ISNULL(SUM(b.bqckJe),0) as numeric(25,8)) as bqckJe,
			cast(ISNULL(SUM(b.bqrkJe),0) as numeric(25,8)) as bqrkJe,
			cast(ISNULL(SUM(b.bqckcct),0) as numeric(25,8)) as bqckcct,
		    cast(ISNULL(SUM(b.bqrkcct),0) as numeric(25,8)) as bqrkcct,
		    cast(ISNULL(SUM(b.bqcktt),0) as numeric(25,8)) as bqcktt,
		    cast(ISNULL(SUM(b.bqrktt),0) as numeric(25,8)) as bqrktt,
			cast(isnull(SUM(b.bqrkJe-b.bqckJe),0) as numeric(25,8)) as totalJe,
			cast(isnull(SUM(b.bqrktt-b.bqcktt),0) as numeric(25,8)) as totalttJe,
			isnull(SUM(b.bqckSendQTY),0) as bqckSendQTY,
			isnull(SUM(b.bqrkSendQTY),0) as bqrkSendQTY,
			CAST(isnull(SUM(b.bqckSendJe),0) as numeric(25,8)) as bqckSendJe,
			CAST(isnull(SUM(b.bqrkSendJe),0) as numeric(25,8)) as bqrkSendJe 
		FROM vw_products p LEFT JOIN
			(SELECT PD.PClass_ID,
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.total) ELSE 0 END) AS [bqckJe],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.total) ELSE 0 END) AS [bqrkJe],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqckcct],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqrkcct],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqcktt],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqrktt],
			   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqckSendQTY],
			   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqrkSendQTY],
			   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY*pd.total/pd.quantity) ELSE 0 END) AS [bqckSendJe],
			   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY*pd.total/pd.quantity) ELSE 0 END) AS [bqrkSendJe]
			   FROM 
                  (  
				   select PClass_ID=p.class_id, pd.quantity, pd.SendQTY, pd.costtotal as total,pd.costtaxtotal,pd.taxtotal, 
				    pd.s_id
				   from ProductDetail PD 
				   inner join BillIDX bi on pd.billid=bi.billid
				   left join Products p on pd.p_id=p.product_id
				   left join storages S on pd.s_id=S.storage_id
				   left join Company  Y on Y.company_id = PD.Y_ID
				   left join employees  E on PD.RowE_id=E.emp_id			 
				   where   bi.billtype in (10,11,12,13,20,21,53,54,55,56,210,211,220,221,150,151,160,161)
                           and bi.billdate between  @BeginDate and @EndDate
						   and PD.p_ID>0 AND PD.aoid=7 and pd.storetype=0 
                           and bi.billstates='0'
                           and S.class_id like @szSClass_ID+'%'
                           and E.class_id like @szEClass_id+'%'
                           AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
                           AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
					       AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
					       AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
					       AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
                         )PD
                          LEFT JOIN Storages s ON s.storage_id=pd.s_id
			    ) AS b
		 	on	LEFT(b.PClass_ID,LEN(p.Class_ID))=p.Class_ID
			WHERE p.parent_id like @szParent_id+'%' and  p.Child_Number=0 AND p.deleted<>1 AND p.product_id<>1
            GROUP BY  p.Class_ID,p.product_id ,p.child_number ,p.[name] ,p.[code],
			p.standard ,p.makearea ,p.medname , p.[trademark] , p.[permitcode],
            p.[unit1name] , p.[rate2] , p.[rate3] , p.[rate4] ,  p.[unit2name] , p.[unit3name] ,  p.[unit4name],
            P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5
    GOTO SUCCEE

alllist:
		SELECT p.Class_ID,p.product_id AS product_id,p.child_number AS child_number,p.[name] AS [name],p.[code] AS code,
			p.standard AS standard,p.makearea as makearea,p.medname AS medtype, p.[trademark] as [trademark], p.[permitcode] as [permitcode],
            p.[unit1name] as [unitname1], p.[rate2] AS [rate2], p.[rate3] AS [rate3], p.[rate4] AS [rate4],  p.[unit2name] AS [unitname2], p.[unit3name] AS [unitname3],  p.[unit4name] AS [unitname4],
            P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
            ISNULL(SUM(b.bqckquantity),0) as bqckquantity,
			ISNULL(SUM(b.bqrkquantity),0) as bqrkquantity,
			isnull(SUM(b.bqrkquantity-b.bqckquantity),0) as totalQuantity,
			cast(ISNULL(SUM(b.bqckJe),0) as numeric(25,8)) as bqckJe,
			cast(ISNULL(SUM(b.bqrkJe),0) as numeric(25,8)) as bqrkJe,
			cast(ISNULL(SUM(b.bqckcct),0) as numeric(25,8)) as bqckcct,
		    cast(ISNULL(SUM(b.bqrkcct),0) as numeric(25,8)) as bqrkcct,
		    cast(ISNULL(SUM(b.bqcktt),0) as numeric(25,8)) as bqcktt,
		    cast(ISNULL(SUM(b.bqrktt),0) as numeric(25,8)) as bqrktt,
			cast(isnull(SUM(b.bqrkJe-b.bqckJe),0) as numeric(25,8)) as totalJe,
			cast(isnull(SUM(b.bqrktt-b.bqcktt),0) as numeric(25,8)) as totalttJe,
			isnull(SUM(b.bqckSendQTY),0) as bqckSendQTY,
			isnull(SUM(b.bqrkSendQTY),0) as bqrkSendQTY,
			CAST(isnull(SUM(b.bqckSendJe),0) as numeric(25,8)) as bqckSendJe,
			CAST(isnull(SUM(b.bqrkSendJe),0) as numeric(25,8)) as bqrkSendJe 
		FROM vw_products p LEFT JOIN
			(SELECT PD.PClass_ID,
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqckquantity],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.quantity) ELSE 0 END) AS [bqrkquantity],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.total) ELSE 0 END) AS [bqckJe],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.total) ELSE 0 END) AS [bqrkJe],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqckcct],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.costtaxtotal) ELSE 0 END) AS [bqrkcct],
			   (CASE WHEN  pd.quantity<0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqcktt],
			   (CASE WHEN  pd.quantity>0 THEN ABS(pd.taxtotal) ELSE 0 END) AS [bqrktt],
			   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqckSendQTY],
			   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY) ELSE 0 END) AS [bqrkSendQTY],
			   (CASE WHEN  pd.SendQTY<0 THEN ABS(pd.SendQTY*pd.total/pd.quantity) ELSE 0 END) AS [bqckSendJe],
			   (CASE WHEN  pd.SendQTY>0 THEN ABS(pd.SendQTY*pd.total/pd.quantity) ELSE 0 END) AS [bqrkSendJe]
			   FROM 
                (  
  				   select p.class_id as PClass_ID, pd.quantity,pd.costtaxtotal,  pd.SendQTY, pd.costtotal as total,pd.taxtotal,
  				         pd.s_id 
				   from Productdetail PD 
   				   inner join BillIDX bi on pd.billid=bi.billid
				   left join Products p on pd.p_id=p.product_id
				   left join storages S on pd.s_id=S.storage_id
				   left join Company  Y on Y.company_id = PD.Y_ID
				   left join employees  E on PD.RowE_id=E.emp_id	
	       where	 bi.billtype in (10,11,12,13,20,21,53,54,55,56,210,211,220,221,150,151,160,161,150,151,160,161)
                       and bi.billdate between  @BeginDate and @EndDate
					   and PD.p_ID>0 AND PD.aoid=7 and pd.storetype=0                                    
                       and bi.billstates='0'
                       and S.class_id like @szSClass_ID+'%'
                       and E.class_id like @szEClass_id+'%'
                       AND (@nYClassID='' or Y.Class_id like @nYClassID+'%')
                       AND ((@employeestable=0) or (PD.RowE_id in (select [id] from #employeestable)))
			           AND ((@Storetable=0) or (PD.s_id in (select [id] from #storagestable))) 
			           AND ((@ClientTable=0) or (bi.c_id in (select [id] from #Clienttable)))
			           AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))    
                                 )PD
                                  LEFT JOIN Storages s ON s.storage_id=pd.s_id
			    ) AS b
		 	on	LEFT(b.PClass_ID,LEN(p.Class_ID))=p.Class_ID
			WHERE p.Child_Number=0 AND p.deleted<>1 AND p.product_id<>1
		    GROUP BY  p.Class_ID,p.product_id ,p.child_number ,p.[name] ,p.[code] ,
			p.standard ,p.makearea ,p.medname , p.[trademark] , p.[permitcode],
            p.[unit1name] , p.[rate2] , p.[rate3] , p.[rate4] ,  p.[unit2name] , p.[unit3name] ,  p.[unit4name],
            P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5
    GOTO SUCCEE

SUCCEE:

  RETURN 0
GO
