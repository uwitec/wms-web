


CREATE TRIGGER DeleteFlag ON [dbo].[jsbdetail]
FOR delete
AS
declare @xsdbid numeric(10,0)
select @xsdbid=xsd_bid from deleted
if not exists(select * from jsbdetail where xsd_bid=@xsdbid)	update billidx set jsflag='0'  where billid=@xsdbid
GO
