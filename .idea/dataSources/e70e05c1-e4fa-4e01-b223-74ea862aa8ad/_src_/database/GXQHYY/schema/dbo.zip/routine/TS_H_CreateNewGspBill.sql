
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-7*/
/* Description:	将现有GSP单据生成另一单据类型的新单*/
/* =============================================*/
CREATE PROCEDURE TS_H_CreateNewGspBill 
	@OldBillID int = 0,		/* 现有单据ID*/
	@OldBillType int = 0,	/* 现有单据类型*/
	@NewBillType int = 0,	/* 新单类型*/
	@nRet int output		/* 返回值，成功返回新单ID，失败返回-1，错误返回-2*/
AS
BEGIN
	SET NOCOUNT ON;
	
	/*当启用外部wms接口时，不再生成流程内单据*/
	if exists(select 1 from sysconfigtmp where [sysname] = 'otherwms' and sysvalue = '1') and (@OldBillType not in(512,562))
	begin
	  if @OldBillType in (511, 512, 513,514)  EXEC TS_H_GspQtyAct @OldBillType, @OldBillID, 1
	  set @nRet = 999999999
	  return 0
	end		
	DECLARE @nSmbId INT
	DECLARE @cUseSalePriceTrace INT /*售价跟踪*/
	DECLARE @nNewBillID int 
	DECLARE @yGuid uniqueidentifier
	DECLARE @szBillNumber varchar(200)
	DECLARE @nOrderBillId INT		/* 源头单据ID*/
	DECLARE @nOrderBillType int		/* 源头单据类型*/
	DECLARE @nOrderGuid uniqueidentifier	/* 源头单据GUID*/
	DECLARE @nGuid uniqueidentifier	    /* 单据GUID*/
	DECLARE @nEid int
	DECLARE @bstates int 
	DECLARE @BillQty NUMERIC(25,8)
	DECLARE @billtotal NUMERIC(25,8)
	DECLARE @dtBillDate datetime	/* 单据日期*/
	DECLARE @nPickSID int, @nPickSAID int /*拣货仓库id, 拣货库区id 根据销售订单仓库、库区生成多张拣货单*/
	DECLARE @nSID int /*入库订单分冷库后使用回写表头S_ID*/
	DECLARE @nOrderYid int	/* 源头单据机构*/
	DECLARE @bNestedFlag bit
	DECLARE @nYNDZ001 int  /*云南定制版本*/
	DECLARE @nCheckOutMan int, @szCheckOutMan varchar(120)   /*复核人*/
	DECLARE @nUseOrderBillNum int	/* 使用订单编号作为业务单据编号*/
	DECLARE @FResultId_BillAudit INT, @FVchCode_BillAudit INT /*草稿自动过账使用*/
	DECLARE @nYId INT, @nTmpBillId INT
	
	select top 1 @nYNDZ001=CAST(sysvalue as Int) from sysconfigtmp where [sysname] = 'yndz001'
	if 	@nYNDZ001 is null set @nYNDZ001 = 0	

	SET @nRet = -2
	
	IF @@TRANCOUNT > 0
	BEGIN
		SET @bNestedFlag = 1
		SAVE TRAN CREATEBILL
	END
	ELSE
	BEGIN
		SET @bNestedFlag = 0
		BEGIN TRAN CREATEBILL
	END

	/* 根据新单据类型生成不同的单据日期*/
	IF @NewBillType < 500
		SET @dtBillDate = CONVERT(VARCHAR(10), GETDATE(), 120)
	ELSE
		SET @dtBillDate = GETDATE()

	IF @OldBillID <= 0 OR @NewBillType <= 0
		RETURN -1

	SET @nRet = -1

	set @bstates =(SELECT BillStates FROM GSPbillidx WHERE Gspbillid = @OldBillID)

	SET @nUseOrderBillNum = 0
	SELECT @nUseOrderBillNum = sysvalue FROM sysconfigtmp WHERE sysname = 'UseOrderBillNumber'

	SET @cUseSalePriceTrace = 0
	exec ts_getsysvalue 'UseSaleTrace', @cUseSalePriceTrace OUT	
	/* 判断原单状态*/
	IF @NewBillType NOT IN (516, 517, 150, 152)/*机构/自营店发货单生成机构收货单时跳过检查，复核生成自营店/机构发货单也跳过检查*/
	begin
		if @OldBillType BETWEEN 501 AND 599
		begin
			IF NOT EXISTS(SELECT 0 FROM GSPbillidx WHERE Gspbillid = @OldBillID AND billstates = 13)
				GOTO ERROR
		end
	    
		if @OldBillType = 14
		begin
			IF NOT EXISTS(SELECT 0 FROM orderidx WHERE billid = @OldBillID AND billstates = 3)
				GOTO ERROR
		end 
	end
	/*---单据GUID*/
     if @NewBillType  in(10,21,150,152)
	   select @nGuid=guid  from GSPbillidx WHERE Gspbillid = @OldBillID
      
	SET @nOrderYid = 0
	IF @OldBillType BETWEEN 501 AND 599
		SELECT @nOrderYid = Y_ID FROM GSPbillidx WHERE Gspbillid = @OldBillID
	ELSE
	IF @OldBillType IN (14, 22)
		SELECT @nOrderYid = Y_ID FROM orderidx WHERE billid = @OldBillID
	ELSE
	IF @OldBillType IN (161, 163)
		SELECT @nOrderYid = c_id, @nOrderGuid = Guid FROM billidx_dts WHERE billid = @OldBillID
	ELSE
	IF @OldBillType IN (-161, -163)
		SELECT @nOrderYid = c_id, @nOrderGuid = Guid FROM billidx WHERE billid = @OldBillID
	ELSE
	IF @OldBillType IN (150, 152) AND @NewBillType = 516
		SELECT @nOrderYid = c_id, @nOrderGuid = YGuid FROM billidx_dts WHERE billid = @OldBillID
	ELSE  
	/* 单据类型使用负数表示实时连接*/
	IF @OldBillType IN (-150, -152)
		SELECT @nOrderYid = c_id, @nOrderGuid = YGuid FROM billidx WHERE billid = @OldBillID
      
    
	/* 生成单据编号, 销售订单生成拣货单不在此处生成单据编号*/
	if not ((@OldBillType in (14, 561)) and (@NewBillType = 541))
		EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid

	/* 新单据类型为GSP单据*/
	IF (@NewBillType BETWEEN 501 AND 599)
	BEGIN
		/* 取源头GUID*/
		IF @nOrderBillType BETWEEN 501 AND 599
			SELECT @nOrderGuid = Yguid FROM GSPbillidx WHERE Gspbillid = @OldBillID
		ELSE
		IF @nOrderBillType IN(14, 22)
			SELECT @nOrderGuid = GUID FROM orderidx WHERE billid = @OldBillID

		/*销售订单生成拣货单begin*/
		if (@OldBillType = 14) and (@NewBillType = 541)
		begin
			/*更新没有仓库id的明细行*/
											
			update OrderBill set ss_id = bi.sout_id 
				from OrderBill mx, orderidx bi 
				where mx.bill_id= bi.billid and bi.billid = @OldBillID and mx.ss_id =0 and bi.sout_id <> 0

			DELETE FROM GSPBILLDETAIL WHERE GSPBILL_ID IN (SELECT Gspbillid FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @OldBillID AND Ybilltype = @OldBillType AND BillStates = 10)
			DELETE FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @OldBillID AND Ybilltype = @OldBillType AND BillStates = 10
			IF EXISTS(SELECT * FROM GSPbillidx WHERE billtype = 541 AND Ybillid = @OldBillID AND Ybilltype = @OldBillType)
				GOTO ERROR
				
			/*云南定制，当启用后按库区生拣货单	*/
			if exists (select 1 from sysconfigtmp where sysvalue = '1' and [sysname] = 'yndz001')			
			begin  /*按库区*/
				declare CreatePickBilCurl cursor for
					select distinct mx.ss_id, isnull(l.sa_id, 0) as pickSaid 
					  from orderbill mx 
					       left join location l on mx.location_id = l.loc_id					       					       					       
					 where mx.bill_id = @OldBillID							   			   
				open CreatePickBilCurl
				
				fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			      
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
									upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
									GUID, Note, BalanceMode,YE_ID,SendC_Id)									     
							SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
									auditman, 0, traffictype, '', '', 0, '', sendtime, 
									trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, billtype, [guid], 
									b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, @nPickSID, 0, 
									[Guid], Note, BalanceMode,e_id,SendC_ID/*NEWID()*/
						FROM      dbo.orderidx
						WHERE billid = @OldBillID					   
						SELECT @nNewBillID = @@IDENTITY
						IF @nNewBillID > 0
						BEGIN
							INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxrate,costtaxprice,costtaxtotal,oldorderqty,oldorderunit,
									OldOrderUnitid,OldOrderUnitrate)
							SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
										o.quantity, 0, 0, 0, o.quantity, o.taxprice as Ytaxprice, o.saleprice as saleprice, o.discountprice as DiscountPrice, 
										o.taxprice as taxprice, 0, o.total, 
										o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
										'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
										o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID, '', o.smb_id, 
										o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),factoryid,costtaxrate,costtaxprice,o.quantity*costtaxprice,
									   case  when o.unitid= p.unit2_id then  o.quantity/p.rate2
										      when o.unitid= p.unit3_id  then  o.quantity/p.rate3
										      when o.unitid= p.unit4_id  then  o.quantity/p.rate4
										      else  o.quantity  end as oldorderqty,u.name,
								       o.unitid,case  when o.unitid= p.unit2_id then p.rate2
										      when o.unitid= p.unit3_id  then p.rate3
										      when o.unitid= p.unit4_id  then p.rate4
										      else  0    end as unitrate
							FROM      
							      ( select mx.*, ISNULL(l.sa_id, 0) as pickSaID from dbo.OrderBill mx 
							         left join location l on mx.location_id = l.loc_id
							         where mx.bill_id = @OldBillID and mx.ss_id = @nPickSID ) o
							left join unit u on o.unitid=u.unit_id
							inner join vw_Products p on o.p_id = p.product_id							
							WHERE o.pickSaID = @nPickSAID
							order by o.smb_id
							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						END
						ELSE
							GOTO ERROR						
						fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID 
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
			end /*按库区*/
			/*陈志良定制，当启用后按仓库简名生成拣货单	*/
			else
			IF EXISTS (SELECT 1 FROM sysconfigtmp WHERE sysvalue = '1' and [sysname] = 'SplitSaleBillByStorage')	
			BEGIN
				/* 按简名拆分订单开始*/
				DECLARE @nStorageCount INT
				DECLARE @nBillCount int
				SET @nBillCount = 0
				DECLARE @uBillGuid uniqueidentifier
				DECLARE @szStorageGroup varchar(80)
				DECLARE @nCurBillId int

				SELECT @nStorageCount = COUNT(alias) FROM 
					(SELECT   s.alias
					FROM      dbo.OrderBill AS sb INNER JOIN
									dbo.storages AS s ON sb.ss_id = s.storage_id
					WHERE   (sb.bill_id = @OldBillID) AND (sb.p_id > 0) AND (sb.ss_id > 0)
					GROUP BY s.alias) a

				DECLARE curSplit CURSOR FOR
				SELECT alias, MIN(sb.ss_id) AS s_id FROM OrderBill sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @OldBillID AND p_id > 0 GROUP BY alias
				OPEN curSplit
				FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @nBillCount = @nBillCount + 1
					SET @uBillGuid = NEWID()
					INSERT INTO orderidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, InvoiceTotal, InvoiceNO, BusinessType, Guid, Y_ID, WT_ID, OrderValidDate, GatheringMan, TrafficCompany, 
						TrafficType, SendTime, SendC_ID)
					SELECT billdate, billnumber + '-' + dbo.PadLeft(CAST(@nBillCount AS VARCHAR(2)), 2, '0'), billtype, a_id, c_id, e_id, @nSid, @nSid, auditman, inputman, ysmoney, 0, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, InvoiceTotal, InvoiceNO, BusinessType, @uBillGuid, Y_ID, WT_ID, OrderValidDate, GatheringMan, TrafficCompany, 
						TrafficType, SendTime, SendC_ID

					FROM orderidx WHERE billid = @OldBillID
            
					/*-------判断主表 add by luowei 2014-01-17*/
					if @@ROWCOUNT <= 0 
					goto error
            
					SET @nCurBillId = @@IDENTITY

					INSERT INTO OrderBill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, ComeDate, ComeQty, total, RowGuid, RowE_id, Y_ID, comment2, Conclusion, 
						Instoretime, BatchBarCode, scomment, batchprice, AOID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nCurBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, sb.comment, unitid, taxrate, ComeDate, ComeQty, total, NEWID(), RowE_id, sb.Y_ID, comment2, Conclusion, 
						Instoretime, BatchBarCode, scomment, batchprice, AOID,factoryid,costtaxprice,costtaxrate,costtaxprice*quantity
					FROM OrderBill sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @OldBillID AND s.alias = @szStorageGroup
            
					/*-------判断明细 add by luowei 2014-01-17*/
					if @@ROWCOUNT <= 0 
					goto error
                    /*-------更新主表的ysmoney，赠品金额不合计，非赠品合计*/
					UPDATE orderidx SET ysmoney = X.TOTAL, quantity = X.QTY, jsye = X.TOTAL, sout_id = x.s_id, sin_id = x.s_id
					FROM(
					     select isnull(SUM(TOTAL),0) as total,isnull(SUM(QTY),0)  as qty,MIN(s_id) AS s_id from 
					     (
					      SELECT SUM(taxtotal) AS TOTAL, SUM(quantity) AS QTY, MIN(ss_id) AS s_id FROM OrderBill WHERE bill_id = @nCurBillId AND p_id > 0  and AOID in (0,5)
					      union all
					      SELECT 0 AS TOTAL, SUM(quantity) AS QTY, MIN(ss_id) AS s_id FROM OrderBill WHERE bill_id = @nCurBillId AND p_id > 0  and AOID  not in (0,5)
					     ) r
					   ) X
					WHERE orderidx.billid = @nCurBillId
                   
					/* 生成拣货单*/
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			      
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
								GUID,note, BalanceMode,YE_ID,SendC_Id)
						SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
								auditman, 0, traffictype, '', '', 0, '', sendtime, 
								trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, billtype, [guid], 
								B_CustomName1,B_CustomName2,B_CustomName3, '', '', 10, sout_id, 0, 
								NEWID(),note, BalanceMode,e_id,SendC_ID
					FROM      dbo.orderidx
					WHERE billid = @nCurBillId					   
					SELECT @nNewBillID = @@IDENTITY
					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,FactoryId,costtaxprice,costtaxrate,costtaxtotal,oldorderqty,oldorderunit,
								OldOrderUnitid,OldOrderUnitrate )
						SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
									o.quantity, 0, 0, 0, o.quantity, o.taxprice as Ytaxprice, o.saleprice as saleprice, o.discountprice as DiscountPrice, 
									o.taxprice as taxprice, 0, o.total, 
									o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
									'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
									o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID, '', o.smb_id, 
									o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),o.FactoryId,o.costtaxprice,o.costtaxrate,o.costtaxtotal,
									case  when o.unitid= p.unit2_id then  o.quantity/p.rate2
										      when o.unitid= p.unit3_id  then  o.quantity/p.rate3
										      when o.unitid= p.unit4_id  then  o.quantity/p.rate4
										      else  o.quantity  end as oldorderqty,u.name,
								   o.unitid,case  when o.unitid= p.unit2_id then p.rate2
										      when o.unitid= p.unit3_id  then p.rate3
										      when o.unitid= p.unit4_id  then p.rate4
										      else  0    end as unitrate
						FROM  OrderBill o /*INNER JOIN storages s ON o.ss_id = s.storage_id  */
						 left join unit u on o.unitid=u.unit_id
			             INNER JOIN vw_Products p on o.p_id = p.product_id							
						WHERE o.bill_id = @nCurBillId
						ORDER BY o.smb_id	
						if @@ROWCOUNT <= 0 GOTO ERROR
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @nCurBillId, @OldBillType, 1, 0
					END
					ELSE
						GOTO ERROR						

					FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
				END
				CLOSE curSplit
				deallocate curSplit
				EXEC Ts_b_DeleteBillDraft @nNewBillId, 4, @OldBillID

				/* 按简名拆分订单结束*/
			END
			
			
			
			/*yypeng-tfsbug-2016-08-23 16:20:51-贵州安锡金定制--生成拣货单时一张订单生成一张拣货单，不按仓库区分，客户的三个仓库都在大仓库里*/
			ELSE IF EXISTS (SELECT 1 FROM sysconfigtmp WHERE sysvalue = '1' and [sysname] = 'NotSplitBill')	 
			begin
			        set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			      
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
									upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
									GUID, Note, BalanceMode,YE_ID,SendC_Id)
							SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
									auditman, 0, traffictype, '', '', 0, '', sendtime, 
									trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, billtype, [guid], 
									b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, sout_id, 0, 
									[Guid], Note, BalanceMode,e_id,SendC_ID/*NEWID()*/
						FROM      dbo.orderidx
						WHERE billid = @OldBillID					   
						SELECT @nNewBillID = @@IDENTITY
						IF @nNewBillID > 0
						BEGIN
							INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,FactoryId,costtaxprice,costtaxrate,costtaxtotal,OldOrderQty,OldOrderUnit,
									OldOrderUnitid,OldOrderUnitrate)
							SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
										o.quantity, 0, 0, 0, o.quantity, o.taxprice as Ytaxprice, o.saleprice as saleprice, o.discountprice as DiscountPrice, 
										o.taxprice as taxprice, 0, o.total, 
										o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
										'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
										o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID, '', o.smb_id, 
										o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),o.FactoryId,o.costtaxprice,o.costtaxrate,o.costtaxtotal,
							            case  when o.unitid= p.unit2_id then  o.quantity/p.rate2
										      when o.unitid= p.unit3_id  then  o.quantity/p.rate3
										      when o.unitid= p.unit4_id  then  o.quantity/p.rate4
										      else  o.quantity  end as oldorderqty,u.name,
										o.unitid,case  when o.unitid= p.unit2_id then p.rate2
										      when o.unitid= p.unit3_id  then p.rate3
										      when o.unitid= p.unit4_id  then p.rate4
										      else  0    end as unitrate
							FROM      dbo.OrderBill o
							left join unit  u on o.unitid=u.unit_id
							inner join vw_Products p on o.p_id = p.product_id
							WHERE o.bill_id = @OldBillID
							ORDER BY o.smb_id
							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						END
			end
			else 
			begin	/*按仓库 																				    */
				declare CreatePickBilCurl cursor for
					select distinct ss_id  from orderbill where bill_id = @OldBillID							   			   
				open CreatePickBilCurl
				
				fetch next from CreatePickBilCurl into @nPickSID
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			        INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
										upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
										trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
										b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
										GUID, Note, BalanceMode,YE_ID,SendC_Id)
								SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
										auditman, 0, traffictype, '', '', 0, '', sendtime, 
										trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, billtype, [guid], 
										b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, @nPickSID, 0, 
										[Guid], Note, BalanceMode,e_id,SendC_ID/*NEWID()*/
							FROM      dbo.orderidx
							WHERE billid = @OldBillID
									   
						SELECT @nNewBillID = @@IDENTITY
						IF @nNewBillID > 0
						BEGIN
							INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,FactoryId,costtaxprice,costtaxrate,costtaxtotal,oldorderqty,oldorderunit,
									OldOrderUnitid,OldOrderUnitrate)
							SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
										o.quantity, 0, 0, 0, o.quantity, o.taxprice as Ytaxprice, o.saleprice as saleprice, o.discountprice as DiscountPrice, 
										o.taxprice as taxprice, 0, o.total, 
										o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
										'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
										o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID, '', o.smb_id, 
										o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),o.FactoryId,o.costtaxprice,o.costtaxrate,o.costtaxtotal,
										case  when o.unitid= p.unit2_id then  o.quantity/p.rate2
										      when o.unitid= p.unit3_id  then  o.quantity/p.rate3
										      when o.unitid= p.unit4_id  then  o.quantity/p.rate4
										      else  o.quantity  end as oldorderqty,u.name,
										o.unitid,case  when o.unitid= p.unit2_id then p.rate2
										      when o.unitid= p.unit3_id  then p.rate3
										      when o.unitid= p.unit4_id  then p.rate4
										      else  0    end as unitrate
							FROM      dbo.OrderBill o
							left join unit u on o.unitid=u.unit_id
							inner join vw_Products p on o.p_id = p.product_id
							WHERE o.bill_id = @OldBillID and o.ss_id = @nPickSID
							ORDER BY o.smb_id
							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						END
						ELSE
							GOTO ERRORA						
						fetch next from CreatePickBilCurl into @nPickSID
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
			end	/*按仓库			 									*/
		end  
		/*销售订单生成拣货单end*/
		else
		/* 机构配送订单生成拣货单*/
		if @OldBillType = 154 and @NewBillType = 541
		begin
			/*-- 删除已生成的拣货单*/
			/*delete from GSPbillidx where Ybillid = @OldBillID and BillType = 541 and Yguid = (select GUID from orderidx where billid = @OldBillID)*/
			/*云南定制，当启用后按库区生拣货单*/
			declare @nSendBillType int
			select  @nSendBillType = SendBillType From company c left join orderidx o on c.company_id = o.c_id where billid = @OldBillID			
			if exists (select 1 from sysconfigtmp where sysvalue = '1' and [sysname] = 'yndz001')			
			begin  /*按库区*/
				declare CreatePickBilCurl cursor for
					select distinct mx.ss_id, isnull(l.sa_id, 0) as pickSaid 
					  from orderbill mx 
					       left join location l on mx.location_id = l.loc_id					       					       					       
					 where mx.bill_id = @OldBillID							   			   
				open CreatePickBilCurl
				
				fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			      
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
									upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
									GUID, Note, BalanceMode,YE_ID)
							SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
									auditman, 0, traffictype, '', '', 0, '', sendtime, 
									trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, case @nSendBillType when 1 then 150 else 152 end, [guid], 
									b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, @nPickSID, 0, 
									[Guid], note, BalanceMode,e_id
						FROM      dbo.orderidx
						WHERE billid = @OldBillID
						SELECT @nNewBillID = @@IDENTITY
						IF @nNewBillID > 0
						BEGIN
							INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
										o.quantity, 0, 0, 0, o.quantity, o.taxprice  as Ytaxprice, o.saleprice as saleprice, o.DiscountPrice as DiscountPrice, 
										o.taxprice as taxprice, 0, o.total, 
										o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
										'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
										o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID , '', o.smb_id, 
										o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),o.factoryid,o.costtaxprice,o.costtaxrate,o.costtaxtotal
							FROM    
							      ( select mx.*, ISNULL(l.sa_id, 0) as pickSaID from dbo.OrderBill mx 
							         left join location l on mx.location_id = l.loc_id
							         where mx.bill_id = @OldBillID and mx.ss_id = @nPickSID ) o
							inner join vw_Products p on o.p_id = p.product_id							
							WHERE o.pickSaID = @nPickSAID and o.p_id > 0
							ORDER BY o.smb_id
							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
							IF @cUseSalePriceTrace = 1
							BEGIN
								/*售价跟踪打开，机构配送订单刷新售价跟踪表数据*/
								DECLARE WritePriceTraceCur CURSOR FOR
										SELECT   o.smb_id
									FROM  (  select mx.*, ISNULL(l.sa_id, 0) as pickSaID from dbo.OrderBill mx 
											 left join location l on mx.location_id = l.loc_id
											 where mx.bill_id = @OldBillID and mx.ss_id = @nPickSID ) o
									inner join vw_Products p on o.p_id = p.product_id							
									WHERE o.pickSaID = @nPickSAID
								OPEN WritePriceTraceCur
				                		FETCH NEXT FROM WritePriceTraceCur INTO @nSmbId
								WHILE @@FETCH_STATUS=0
								BEGIN	
								  EXEC ts_c_SaleBuyPriceTrace;1 'S', @nSmbId, @OldBillType
								  FETCH NEXT FROM WritePriceTraceCur INTO @nSmbId
								END
								CLOSE WritePriceTraceCur
						        	DEALLOCATE WritePriceTraceCur   	
							END
						END
						ELSE
							GOTO ERROR						
						fetch next from CreatePickBilCurl into @nPickSID, @nPickSaID 
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
			end /*按库区*/
			else begin	/*按仓库 																				    */
				declare CreatePickBilCurl cursor for
					select distinct ss_id  from orderbill where bill_id = @OldBillID and p_id > 0							   			   
				open CreatePickBilCurl
				
				fetch next from CreatePickBilCurl into @nPickSID
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			      
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
									upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
									GUID, Note, BalanceMode,YE_ID)
							SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
									auditman, 0, traffictype, '', '', 0, '', sendtime, 
									trafficCompany, 0, 0, 0, ysmoney, ysmoney, billid, case @nSendBillType when 1 then 150 else 152 end, [guid], 
									b_CustomName1, b_CustomName2, b_CustomName3, '', '', 10, @nPickSID, 0, 
									[Guid], Note, BalanceMode,e_id
						FROM      dbo.orderidx
						WHERE billid = @OldBillID					   
						SELECT @nNewBillID = @@IDENTITY
						IF @nNewBillID > 0
						BEGIN
							INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT   @nNewBillID, o.p_id, o.makedate, o.validdate, o.batchno, o.unitid, o.quantity, o.quantity, 0, 0, 0, 
										o.quantity, 0, 0, 0, o.quantity, (o.taxtotal/o.quantity)  as Ytaxprice, (o.total/o.quantity) as saleprice, (o.totalmoney/o.quantity) as DiscountPrice, 
										(o.taxtotal/o.quantity) as taxprice, o.taxprice-o.discountprice, o.total, 
										o.discount, o.totalmoney, o.TaxRate, o.taxmoney, o.TaxTotal, 0, '', '', '', 
										'', '', '', '', '', o.ss_id, o.location_id, o.supplier_id, o.instoretime, o.quantity, 
										o.BatchBarCode, o.scomment, o.batchprice, p.Iscold, p.Isspec, o.comment, o.comment2, o.y_id, o.AOID , '', o.smb_id, 
										o.rowguid, o.commissionflag, o.CostPrice, o.costprice*o.quantity, NEWID(),o.factoryid,o.costtaxprice,o.costtaxrate,o.costtaxtotal
							FROM      dbo.OrderBill o
							inner join vw_Products p on o.p_id = p.product_id
							WHERE o.bill_id = @OldBillID and o.ss_id = @nPickSID and o.p_id > 0
							ORDER BY o.smb_id	
							if @@ROWCOUNT <= 0
								GOTO ERROR
							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
							IF @cUseSalePriceTrace = 1
							BEGIN
								/*售价跟踪打开，机构配送订单刷新售价跟踪表数据*/
								DECLARE WritePriceTraceCur CURSOR FOR
										SELECT o.smb_id FROM dbo.OrderBill o WHERE o.bill_id = @OldBillID and o.ss_id = @nPickSID		
								OPEN WritePriceTraceCur
				                		FETCH NEXT FROM WritePriceTraceCur INTO @nSmbId
								WHILE @@FETCH_STATUS=0
								BEGIN	
								  EXEC ts_c_SaleBuyPriceTrace;1 'S', @nSmbId, @OldBillType
								  FETCH NEXT FROM WritePriceTraceCur INTO @nSmbId
								END
								CLOSE WritePriceTraceCur
						        	DEALLOCATE WritePriceTraceCur   	
							END
						END
						ELSE
							GOTO ERROR						
						fetch next from CreatePickBilCurl into @nPickSID
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
			end	/*按仓库*/
		  /*机构配送订单审核后更新请货单的完成数量*/
		  update tranbill  set ComeQty = ComeQty + B.quantity from (select orgbillid,sum(quantity) as quantity from  OrderBill where bill_id= @OldBillID group by orgbillid ) B  where tranbill.smb_id = B.orgbillid
		  /*再更新请货单的状态*/
		  update tranidx set billstates = 0 where billid not in (select bill_id from tranbill where ComeQty < quantity group by bill_id)			 									
		end
		/*采购退出申请单生成拣货单begin*/
		else
		if (@OldBillType = 561) and (@NewBillType = 541)
		begin
		
		  /*云南定制，当启用后按库区生拣货单	*/
			if exists (select 1 from sysconfigtmp where sysvalue = '1' and [sysname] = 'yndz001')			
			begin  /*按库区 		      */
				declare CreatePickBilCurl cursor for
					select distinct mx.s_id, isnull(l.sa_id, 0) as picksaid  
					  from gspbilldetail mx left join location l on mx.location_id = l.loc_id					  					 
					  where gspbill_id = @OldBillID							   			   
				open CreatePickBilCurl
								
				fetch next from CreatePickBilCurl into @nPickSID, @npickSaid
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			            /*b_CustomName1, b_CustomName2在采退申请单上用作供应商代表，不往后流转 任务ID：32827*/
			            /* 
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode)
						SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, @nPickSID, TrafficTime, 
								[GUID],FollowNumber,TicketDate, BalanceMode
					    */
					    INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode,YE_ID)
						SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName3, b_CustomName4, b_CustomName5, Note,10, @nPickSID, TrafficTime, 
								[GUID],FollowNumber,TicketDate, BalanceMode,YE_ID
					FROM      dbo.GSPbillidx
					WHERE Gspbillid = @OldBillID

					SELECT @nNewBillID = @@IDENTITY
					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, applicantqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
									applicantqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, mx.S_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail mx
						         left join location l on mx.Location_id = l.loc_id						       
						WHERE Gspbill_id = @OldBillID and mx.S_id = @nPickSID and
						      (@nPickSaid = 0 and (l.sa_id = 0 or l.sa_id is null)) or (@nPickSaid  <> 0 and l.sa_id = @nPickSAID) 
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					END
					ELSE
						GOTO ERROR
				    	
					fetch next from CreatePickBilCurl into @nPickSID, @nPickSaid
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
		    end	/*按库区		*/
		    else begin					    
				declare CreatePickBilCurl cursor for
					select distinct s_id  from gspbilldetail where gspbill_id = @OldBillID and P_id > 0							   			   
				open CreatePickBilCurl
				
				fetch next from CreatePickBilCurl into @nPickSID
				while @@FETCH_STATUS=0
				begin	
					set @nNewBillID = 0
					EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
			            /*b_CustomName1, b_CustomName2在采退申请单上用作供应商代表，不往后流转 任务ID：32827*/
			            /*
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode)
						SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, @nPickSID, TrafficTime, 
								[GUID],FollowNumber,TicketDate, BalanceMode
						*/
						INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode,YE_ID)
						SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName3, b_CustomName4, b_CustomName5, Note,10, @nPickSID, TrafficTime, 
								[GUID],FollowNumber,TicketDate, BalanceMode,YE_ID
					FROM      dbo.GSPbillidx
					WHERE Gspbillid = @OldBillID

					SELECT @nNewBillID = @@IDENTITY
					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, applicantqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
									applicantqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID and S_id = @nPickSID and P_id > 0
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					END
					ELSE
						GOTO ERROR
				    	
					fetch next from CreatePickBilCurl into @nPickSID
				end	
				close CreatePickBilCurl
				deallocate CreatePickBilCurl
		  end	 				 									
		end  
		/*采购退出申请单生成拣货单end			*/
		ELSE
		IF (@OldBillType = 161) AND (@NewBillType = 524)/*机构收货退单生成机构退货验收单*/
		BEGIN
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, Yguid,
					b.B_CustomName1, b.B_CustomName2, b.B_CustomName3, '', '', 10, b.sin_id, 0,
					GUID, '退货单编号：' + billnumber + b.note
				FROM BillIdx_dts b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, 0, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM BuyManageBill_dts s 
				INNER JOIN vw_Products v ON s.p_id = v.product_id 
				INNER JOIN billidx_dts b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID

				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
	
			END
		ELSE
		/* 实时连接*/
		IF (@OldBillType = -161) AND (@NewBillType = 524)/*机构收货退单生成机构退货验收单*/
		BEGIN
			SET @OldBillType = ABS(@OldBillType)
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, GUID,
					b.B_CustomName1, b.B_CustomName2, b.B_CustomName3, '', '', 10, b.sin_id, 0,
					NEWID(), '退货单编号：' + billnumber + b.note, balancemode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, 0, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM BuyManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id
				INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID

				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
		END
		ELSE
		IF (@OldBillType IN (161, 163)) AND (@NewBillType = 517)/*自营店收货退单生成机构退货收货单*/
		BEGIN
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, Yguid,
					'', '', b.B_CustomName3, '', '', 10, b.sin_id, 0,
					GUID, '退货单编号：' + billnumber+ b.note, balancemode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
	        			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, 0, 0, s.quantity, 0, 
						0, 0, 0, s.quantity, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, location_id, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid, costtaxprice,costtaxrate,costtaxtotal
				FROM BuyManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id 
				INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID
				IF @@ROWCOUNT <= 0 
					GOTO ERROR													
				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
		END				
		ELSE
		IF (@OldBillType = 163) AND (@NewBillType = 524)/*自营店收货退单生成机构退货验收单*/
		BEGIN
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, Yguid,
					b.B_CustomName1, b.B_CustomName2, b.B_CustomName3, '', '', 10, b.sin_id, 0,
					GUID, '退货单编号：' + billnumber+ b.note, BalanceMode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, 0, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid, costtaxprice,costtaxrate,costtaxtotal
				FROM BuyManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id 
				INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID

				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
		END
		ELSE
		/* 实时连接*/
		IF (@OldBillType IN (-161,-163)) AND (@NewBillType = 517)/*自营店收货退单生成机构退货验收单*/
		BEGIN
			SET @OldBillType = ABS(@OldBillType)
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, guid,
					'', '', b.B_CustomName3, '', '', 10, b.sin_id, 0,
					NEWID(), '退货单编号：' + billnumber+ b.note, BalanceMode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, 0, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid, costtaxprice ,costtaxrate,costtaxtotal
				FROM BuyManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id 
											INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID

				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
		END
		else
		IF (@OldBillType = -163) AND (@NewBillType = 524)/*自营店收货退单生成机构退货验收单*/
		BEGIN
			SET @OldBillType = ABS(@OldBillType)
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, b.inputman, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, B.billid, b.billtype, guid,
					b.B_CustomName1, b.B_CustomName2, b.B_CustomName3, '', '', 10, b.sin_id, 0,
					NEWID(), '退货单编号：' + billnumber+ b.note, BalanceMode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.buyprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', 0, 0, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, s.smb_id, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid, costtaxprice ,costtaxrate,costtaxtotal
				FROM BuyManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id 
											INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID

				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
			END
			ELSE
				GOTO ERROR
		END
		ELSE
		IF (@OldBillType IN (150, 152)) AND (@NewBillType = 516)/*机构/自营店发货单生成机构收货单*/
		BEGIN
			/* 取默认制单人*/
			DECLARE @nDefaultInput int
			SELECT @nDefaultInput = sysvalue FROM sysconfig WHERE sysname = 'localinputman' AND Y_ID = (SELECT c_id FROM billidx_dts WHERE billid = @OldBillID)
			IF @nDefaultInput IS NULL
				SET @nDefaultInput = 0

			SELECT @nGuid = [GUID] FROM billidx_dts WHERE billid = @OldBillID
			/*取默认经手人 add by zfl 2015-01-20*/
			DECLARE @upauditman1 int
			SELECT @upauditman1 = sysvalue FROM sysconfig WHERE sysname = 'localeid' AND Y_ID = (SELECT c_id FROM billidx_dts WHERE billid = @OldBillID)
			IF @upauditman1 IS NULL
				SET @upauditman1 = 0			
			
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note,FollowNumber,TicketDate)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, CASE @nDefaultInput WHEN 0 THEN b.inputman ELSE @nDefaultInput END, 0, '1900-01-01', 0, '1900-01-01',
					@upauditman1, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, 0, b.billtype, @nOrderGuid,
					'', '', b.B_CustomName3, '', '', 10, b.sin_id, 0,/*自营店发货单生成机构收货单时B_CustomName1，B_CustomName2传空值过去 tfs-bug-40154-zl0928*/
					GUID, '发货单编号：' + billnumber+ b.note,FollowNumber,TicketDate
				FROM BillIdx_Dts b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, 
						/*用20%的差别来判断是否是大单位*/
						case when abs(s.taxprice - s.taxtotal /nullif(s.quantity,0) )/nullif(s.taxprice,0) < 0.2 then s.taxprice else s.taxtotal / s.quantity end,/*s.taxprice, */
						case when abs(s.taxprice - s.taxtotal /nullif(s.quantity,0) )/nullif(s.taxprice,0) < 0.2 then s.saleprice else s.total / s.quantity end,
						case when abs(s.taxprice - s.taxtotal /nullif(s.quantity,0) )/nullif(s.taxprice,0) < 0.2 then s.discountprice else s.totalmoney/ s.quantity end,
						case when abs(s.taxprice - s.taxtotal /nullif(s.quantity,0) )/nullif(s.taxprice,0) < 0.2 then s.taxprice else s.taxtotal / s.quantity end,
						 0, s.total, 
						s.discount, s.totalmoney, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', s.sd_id, s.location_id2, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, 0,/*orgbillid, */
						s.RowGuid, s.commissionflag, s.discountprice, s.totalmoney, NEWID(),s.factoryid,s.taxprice,s.costtaxrate,s.taxtotal
				FROM SaleManageBill_Dts s INNER JOIN vw_Products v ON s.p_id = v.product_id 
				INNER JOIN BillIdx_Dts b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID
				UPDATE a SET a.InceptQty = b.EligibleQty  
					FROM gspbilldetail a, (SELECT OrgBillid, SUM(EligibleQty) AS EligibleQty 
					                       FROM GSPbilldetail WHERE Gspbill_id = @nNewBillID AND OrgBillid > 0 GROUP BY OrgBillid) b 
                WHERE a.OrgBillid = b.OrgBillid
                
			/*机构货位跟踪 IsFollowProductLoc*/
				if not exists(select 1 from sysconfig where sysvalue='1' and sysname='IsFollowProductLoc') /*如果按指定货位入库就不处理货位跟踪*/
					if exists(select 1 from sysconfig where sysvalue='1' and sysname='InStorageTra')
					begin
					  update GSPbilldetail set Location_id=isnull(b.l_id,0),S_id=isnull(b.s_id ,0)
					  from GSPbilldetail a,
					  (
							select * from
							(
								select a.* from LocationTrace a,
								(
									select distinct p_id,billtype,max(ModifyDate) ModifyDate from LocationTrace where billtype in (160,162)
									group by p_id,billtype
								) b
								where a.p_id=b.p_id and a.billtype=b.billtype and a.ModifyDate=b.ModifyDate
							) c
					  ) b
					  where a.Gspbill_id=@nNewBillID and a.P_id=b.p_id and a.Y_id=b.Y_ID
					end  
					/*更新表头仓库*/
			      update GSPbillidx set S_id=gd.S_id from 
					(SELECT  top 1 s_id from GSPbilldetail where Gspbill_id=@nNewBillID) gd 
					where  Gspbillid = @nNewBillID		
				              
                
				
				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 1
				/*处理标准流程中总部下传的电子监管码*/
				INSERT INTO RetailBillidx_Sfda(bill_id, Product_Id, sfda_code, BillType, IsDraft, BatchNo, ValidDate, MakeDate)
				SELECT @nNewBillID AS BillId, a.p_id, s.sfda_code, @NewBillType AS BillType, 1 AS IsDraft, 
				       '' AS BatchNo, '1900-01-01' AS ValidDate, '1900-01-01' AS MakeDate 
				FROM Sfda_Detail s INNER JOIN 
				    (SELECT GUID AS GUID, MAX(g.P_id) AS p_id FROM GSPbillidx b INNER JOIN GSPbilldetail g ON b.Gspbillid = g.Gspbill_id 
				     WHERE g.Gspbill_id = @nNewBillID GROUP BY b.GUID) a ON s.guid = a.guid
				DELETE FROM Sfda_Detail WHERE guid = @nGuid      
				
			END	
			ELSE
				GOTO ERROR
		END
		ELSE
		/* 实时连接*/
		IF (@OldBillType IN (-150, -152)) AND (@NewBillType = 516)/*机构/自营店发货单生成机构验收单*/
		BEGIN
			SET @OldBillType = ABS(@OldBillType)
			SELECT @nDefaultInput = sysvalue FROM sysconfig WHERE sysname = 'localinputman' AND Y_ID = (SELECT c_id FROM billidx WHERE billid = @OldBillID)
			IF @nDefaultInput IS NULL
				SET @nDefaultInput = 0
			SELECT @nGuid = [GUID] FROM billidx WHERE billid = @OldBillID
			
			INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
						upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
						trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
						b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
						GUID, Note, BalanceMode)
			SELECT @NewBillType, @szBillNumber, b.c_id, b.Y_ID, @dtBillDate, CASE @nDefaultInput WHEN 0 THEN b.inputman ELSE @nDefaultInput END, 0, '1900-01-01', 0, '1900-01-01',
					b.auditman, 0, '', '', '', '', '', '1900-01-01',
					'', '', b.WholeQty, b.PartQty, b.ysmoney, b.ysmoney, CASE @OldBillType WHEN 152 THEN @OldBillID ELSE 0 END, b.billtype, @nOrderGuid,
					'', '', b.B_CustomName3, '', '', 10, b.sin_id, 0,/*自营店发货单生成机构收货单时B_CustomName1，B_CustomName2的值传空值过去 tfs-bug-40154-zl0928*/
					NEWID(), '发货单编号：' + billnumber+ b.note, BalanceMode
				FROM BillIdx b WHERE b.billid = @OldBillID
			  
			SELECT @nNewBillID = @@IDENTITY
			
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, s.p_id, s.makedate, s.validdate, s.batchno, s.unitid, s.quantity, s.quantity, 0, s.quantity, 0, 
						0, 0, 0, 0, 0, s.taxprice, s.saleprice, s.discountprice, s.taxprice, 0, s.totalmoney, 
						s.discount, s.discountprice * s.quantity, s.taxrate, s.taxmoney, s.taxtotal, 0, '', '', '', 
						'', '', '', 0, '', s.sd_id, s.location_id2, s.supplier_id, s.instoretime, 0, 
						s.BatchBarCode, s.scomment, s.batchprice, v.Iscold, v.Isspec, s.comment, s.comment2, b.c_id, s.aoid, 0, orgbillid, 
						s.RowGuid, s.commissionflag, s.CostPrice, s.costprice * s.quantity, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM SaleManageBill s INNER JOIN vw_Products v ON s.p_id = v.product_id 
				INNER JOIN BillIdx b ON s.bill_id = b.billid 
				WHERE s.bill_id = @OldBillID
				
				UPDATE a SET a.InceptQty = b.EligibleQty  
					FROM gspbilldetail a, (SELECT OrgBillid, SUM(EligibleQty) AS EligibleQty 
					                       FROM GSPbilldetail WHERE Gspbill_id = @nNewBillID AND OrgBillid > 0 GROUP BY OrgBillid) b 
                WHERE a.OrgBillid = b.OrgBillid
				
				SET @nRet = @nNewBillID
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
				
				
			END	
			ELSE
				GOTO ERROR
		END
		ELSE		/* 其他*/
		BEGIN
			/*生成销售退回收货单时需要根据商品过滤生成冷藏药品销售退回收货单*/
			if @NewBillType = 512
			begin
				/*存在冷藏药品时生成冷藏药品销售退回收货单*/
				DECLARE @SumDetailDiscountTotal NUMERIC(25,8), @SumDetailTaxTotal NUMERIC(25,8)
				SET @SumDetailDiscountTotal = 0 
				SET @SumDetailTaxTotal = 0
				if exists (select 1 from GSPbilldetail where Gspbill_id = @OldBillID and Iscold = 1)
				begin
				INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
							upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
							GUID,Note, BalanceMode,YE_Id,SendC_Id)
					SELECT   514, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
							auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							'', '', '', '', '', 10, s_id, TrafficTime, 
							NEWID(),Note, BalanceMode,YE_Id,SendC_Id
				FROM      dbo.GSPbillidx
				WHERE Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
					INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
								pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, 0, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM      dbo.GSPbilldetail
					WHERE Gspbill_id = @OldBillID and Iscold = 1

					SET @nRet = @nNewBillID
					/*更新新单主表金额合计值*/
					SELECT @SumDetailDiscountTotal = ISNULL(SUM(g.DiscountTotal), 0), @SumDetailTaxTotal = ISNULL(SUM(g.TaxTotal), 0) 
						FROM GSPbilldetail g WHERE g.Gspbill_id = @nNewBillID
					UPDATE GSPbillidx SET DiscountTotal = @SumDetailDiscountTotal, TaxTotal = @SumDetailTaxTotal 
					WHERE Gspbillid = @nNewBillID
					EXEC TS_H_BillTraceAct 0, @nNewBillID, 514, @OldBillID, @OldBillType, 1, 0
				END
				ELSE
					GOTO ERROR
				end
		     
				/*存在普通药品时生成销售退回收货单 */
				if exists (select 1 from GSPbilldetail where Gspbill_id = @OldBillID and Iscold = 0)
				begin
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
							upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, billstates, s_id, TrafficTime, 
							GUID,Note, BalanceMode,YE_Id,SendC_Id)
					SELECT   512, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
							auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							'', '', '', '', '', 10, s_id, TrafficTime, 
							NEWID(),Note, BalanceMode,YE_Id,SendC_Id
				FROM      dbo.GSPbillidx
				WHERE Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
					INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   				pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
							discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
							checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
							BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
							Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
								pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, 0, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM      dbo.GSPbilldetail
					WHERE Gspbill_id = @OldBillID and Iscold = 0

					SET @nRet = @nNewBillID
					/*更新新单主表金额合计值*/
					SELECT @SumDetailDiscountTotal = ISNULL(SUM(g.DiscountTotal), 0), @SumDetailTaxTotal = ISNULL(SUM(g.TaxTotal), 0) 
						FROM GSPbilldetail g WHERE g.Gspbill_id = @nNewBillID
					UPDATE GSPbillidx SET DiscountTotal = @SumDetailDiscountTotal, TaxTotal = @SumDetailTaxTotal 
					WHERE Gspbillid = @nNewBillID
					EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
				END
				ELSE
					GOTO ERROR      		      
				end		      		      		    		    
			end
			ELSE
			IF @OldBillType IN (511, 512, 513, 514, 517)
			BEGIN
				/*收货单生成验收单(收货数量大于零的收货记录才生成验收记录)*/
				IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.InceptQty > 0)
				BEGIN
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
							upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
							GUID,FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id)
					SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
							auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, s_id, TrafficTime, 
							NEWID(),FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id
			    	FROM      dbo.GSPbillidx
			    	WHERE Gspbillid = @OldBillID
			    	SELECT @nNewBillID = @@IDENTITY
			    	/**/
			    	IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, Yqty, InceptQty, uneligibleqty, inceptqty, refuseqty, 
						  			pickqty, checkqty, 0, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy,  total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason , '', 
									checkaccept, checkreport, returnreason, checkstate, checkreason, isnull(s_id, 0), ISNULL(location_id,0), supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, Gspsmb_id, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID AND InceptQty > 0
						ORDER BY Gspsmb_id
						
						UPDATE a 
							SET a.CheckQty = b.InceptQty FROM GSPbilldetail a, (SELECT SUM(g.InceptQty) AS InceptQty, g.OrgBillid
						FROM GSPbilldetail g WHERE g.Gspbill_id = @nNewBillID AND g.OrgBillid > 0 GROUP BY g.OrgBillid) b 
						WHERE a.OrgBillid = b.OrgBillid AND a.Gspbill_id = @nNewBillID	
						UPDATE GSPbilldetail SET CheckQty = InceptQty WHERE Gspbill_id = @nNewBillID AND OrgBillid = 0
						
						IF @OldBillType =512
							EXEC TS_H_GspQtyAct @OldBillType, @OldBillID, -1	
						else
							EXEC TS_H_GspQtyAct @OldBillType, @OldBillID, 1
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					    /*处理收货单新生成的验收单的电子监管码*/
						INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
						SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
							FROM RetailBillidx_Sfda 
						WHERE BillType IN (511, 512, 513, 514) AND Bill_Id = @OldBillID
					END
					ELSE
						GOTO ERROR
				END
				ELSE
				BEGIN
					SET @nRet = 1
				END	
			END	
			ELSE
			IF @OldBillType = 515
			BEGIN
				/*直调采购单生成直掉验收单(采购数量大于零的直调采购单才生成直调验收单)*/
				IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.InceptQty > 0)
				BEGIN
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
							upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
							GUID, BalanceMode,YE_Id)
					SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, inputman, 0, '1900-1-1', 0, '1900-1-1', 
							auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, s_id, TrafficTime, 
							NEWID(), BalanceMode,YE_Id
			    	FROM      dbo.GSPbillidx
			    	WHERE Gspbillid = @OldBillID
			    	SELECT @nNewBillID = @@IDENTITY
			    	/**/
			    	IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
						  			pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy,  total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID AND InceptQty > 0
						ORDER BY Gspsmb_id

						EXEC TS_H_GspQtyAct @OldBillType, @OldBillID, 1
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					END
					ELSE
						GOTO ERROR	
				END
				ELSE
				BEGIN
					SET @nRet = 1
				END
			END
			ELSE
			IF @OldBillType IN (521, 522, 524)	
			BEGIN
			    /*上架确认单“验收合格数量”，取验收单中的“合格数量”*/
				/*采购验收单、销售退回验收单、机构退货验收单生成上架确认单(合格数量大于零的验收记录才生成上架确认单)	*/
				DECLARE @nCreateEligibleQty INT
				SET @nCreateEligibleQty = 0
				IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.EligibleQty > 0)
				BEGIN
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
							upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
							GUID,FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id)
					SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
							auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
							trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, CASE @OldBillType WHEN 524 THEN GUID ELSE Yguid END, 
							b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, s_id, TrafficTime, 
							NEWID(),FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id
			    	FROM      dbo.GSPbillidx
			    	WHERE Gspbillid = @OldBillID
			    	SELECT @nNewBillID = @@IDENTITY
			    	/**/
			    	IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, EligibleQty, eligibleqty, 0, inceptqty, refuseqty, 
						  			pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy,  total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, '', '', 
									'合格', checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, dbo.GetProductComment(P_id, EligibleQty), comment2, y_id, aoid, sfdacounts, Gspsmb_id, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID AND EligibleQty > 0
						ORDER BY Gspsmb_id
						
						/*货位跟踪 IsFollowProductLoc*/
						if not exists(select 1 from sysconfig where sysvalue='1' and sysname='IsFollowProductLoc') /*如果按指定货位入库就不处理货位跟踪*/
							if exists(select 1 from sysconfig where sysvalue='1' and sysname='InStorageTra')
							begin
							  update GSPbilldetail set Location_id=isnull(b.l_id,0),S_id=isnull(b.s_id ,0)
							  from GSPbilldetail a,
							  (
									select * from
									(
										select a.* from LocationTrace a,
										(
											select distinct p_id,billtype,max(ModifyDate) ModifyDate from LocationTrace where billtype=20
											group by p_id,billtype
										) b
										where a.p_id=b.p_id and a.billtype=b.billtype and a.ModifyDate=b.ModifyDate
									) c
							  ) b
							  where a.Gspbill_id=@nNewBillID and a.P_id=b.p_id and a.Y_id=b.Y_ID
							end

						SET @nRet = @nNewBillID
						SET @nCreateEligibleQty = 1
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						
						/*处理验收单新生成的上架确认单的电子监管码*/
						INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
						SELECT @nNewBillID, a.Product_Id, a.Sfda_Code, 1, a.BatchNo, a.ValidDate, a.MakeDate, @NewBillType
							FROM RetailBillidx_Sfda a, GSPbilldetail b 
						WHERE a.Bill_Id = b.Gspbill_id AND a.Product_Id = b.P_id AND a.BillType IN (521, 522, 524) AND 
						      a.Bill_Id = @OldBillID AND b.EligibleQty > 0
						GROUP BY a.Product_Id, a.Sfda_Code, a.BatchNo, a.ValidDate, a.MakeDate
						
						/*---入库验收单  机构货位跟踪,修改分单后的表头仓库 */
					IF @OldBillType=521
					begin
						  /*-----机构货位跟踪*/
					if not exists(select 1 from sysconfig where sysvalue='1' and sysname='IsFollowProductLoc') /*如果按指定货位入库就不处理货位跟踪*/
						if exists(select 1 from sysconfig where sysvalue='1' and sysname='InStorageTra')
						  begin							  
						  DECLARE @vJgid int
						  set @vJgid=(select distinct Y_id from  GSPbillidx where Gspbillid = @OldBillID)
				        	update  GSPbilldetail set Location_id=w.loc_id,S_id=w.s_id
				        	from GSPbilldetail a,
				        	(
					          SELECT L1.s_id, L1.loc_id, L2.p_id, L2.Y_ID FROM location L1
					          INNER JOIN
					            (SELECT L.p_id, MIN(L.l_id) AS L_ID, L.Y_ID FROM LocationTrace L 
					          INNER JOIN
					          (SELECT p_id, MAX(rectime) AS REC, Y_ID FROM LocationTrace
							  where s_id in (select s_id from vw_avlSid)
						       GROUP BY p_id, Y_ID) X
					          ON L.p_id = X.p_id AND L.rectime = X.REC AND L.Y_ID = X.Y_ID
					          GROUP BY L.p_id, L.Y_ID) L2
					          ON L1.loc_id = L2.L_ID
					          where L2.y_ID=@vJgid
					         ) w
					        where a.Gspbill_id=@nNewBillID and a.P_id=w.p_id						  
						  /*----修改表头仓库 */
						  SET @nSID =(SELECT  top 1 s_id from GSPbilldetail where Gspbill_id=@nNewBillID)
					      update GSPbillidx set S_id=@nSID  where  Gspbillid = @nNewBillID
						end	
					end				    
					END
					ELSE
						GOTO ERROR
				END
				
				/* 不合格商品也生成上架确认单*/
				/* 不再判断此开关*/
				/*IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'PutonbillDealUneligible' AND sysvalue = '1')*/
				BEGIN
					IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.UneligibleQty > 0 AND CHARINDEX('拒收', g.UneligibleTranSactor, 1) = 0)
					BEGIN
						/* 取不合格品库*/
						DECLARE @nUeStoreCold int		/* 冷库*/
						DECLARE @nUeStoreOther int		/* 其他*/
						DECLARE @Iscold int		/* 判断冷链还是常温*/
						SET @nUeStoreCold = 0
						SET @nUeStoreOther = 0
						SET @Iscold = 0
						select top 1 @Iscold = Iscold from dbo.GSPbilldetail where Gspbill_id = @OldBillID AND unEligibleQty > 0 AND CHARINDEX('拒收', UneligibleTranSactor, 1) = 0
						if @Iscold = 1 /*表示冷链*/
						begin
							SELECT @nUeStoreCold = storage_id FROM storages WHERE qualityFlag = 1 and storeCondition = 2 AND Y_ID = (SELECT Y_ID FROM GSPbillidx WHERE Gspbillid = @OldBillID) and child_number = 0 and deleted = 0
						end
						else
							SELECT @nUeStoreOther = storage_id FROM storages WHERE qualityFlag = 1 and storeCondition <> 2 AND Y_ID = (SELECT Y_ID FROM GSPbillidx WHERE Gspbillid = @OldBillID) and child_number = 0 and deleted = 0
						IF (@nUeStoreCold > 0) OR (@nUeStoreOther > 0)
						BEGIN
							IF @nCreateEligibleQty = 1
							BEGIN
							  /*SET @szBillNumber = ''*/
							  EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
							END
							INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
									upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
									GUID,FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id)
							SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
									auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
									trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, CASE @OldBillType WHEN 524 THEN GUID ELSE Yguid END, 
									b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, @nUeStoreOther, TrafficTime, 
									NEWID(),FollowNumber,TicketDate, BalanceMode,YE_Id,SendC_Id
			    			FROM      dbo.GSPbillidx
			    			WHERE Gspbillid = @OldBillID
			    			SELECT @nNewBillID = @@IDENTITY
			    		
			    			IF @nNewBillID > 0
							BEGIN
								INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   								pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
											discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
											checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
											BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
											Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
								SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, uneligibleqty, uneligibleqty, 0, inceptqty, refuseqty, 
						  					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, uneligibleqty*price, 
											discount, DiscountPrice*uneligibleqty, TaxRate, (TaxPrice*uneligibleqty)-(DiscountPrice*uneligibleqty), TaxPrice*uneligibleqty, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
											checkaccept, checkreport, returnreason, checkstate, checkreason, CASE Iscold WHEN 1 THEN @nUeStoreCold ELSE @nUeStoreOther END, 0, supplier_id, instoretime, cansaleqty, 
											BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, dbo.GetProductComment(P_id, UneligibleQty), comment2, y_id, aoid, sfdacounts, Gspsmb_id, 
											Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
								FROM      dbo.GSPbilldetail
								WHERE Gspbill_id = @OldBillID AND unEligibleQty > 0 AND CHARINDEX('拒收', UneligibleTranSactor, 1) = 0
								ORDER BY Gspsmb_id
								IF @@ROWCOUNT <= 0
									GOTO ERROR
									
								/* 更新表头仓库*/
								if EXISTS (SELECT TOP 1 S_id FROM GSPbilldetail WHERE Gspbill_id = @nNewBillID AND S_id > 0)
								begin
							    	UPDATE GSPbillidx SET S_id = isnull((SELECT TOP 1 S_id FROM GSPbilldetail WHERE Gspbill_id = @nNewBillID AND S_id > 0),0) WHERE Gspbillid = @nNewBillID
							    end
								SET @nRet = @nNewBillID
								EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
							     
							    /*处理验收单新生成的上架确认单的电子监管码*/
								INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
								SELECT @nNewBillID, a.Product_Id, a.Sfda_Code, 1, a.BatchNo, a.ValidDate, a.MakeDate, @NewBillType
									FROM RetailBillidx_Sfda a, GSPbilldetail b 
								WHERE a.Bill_Id = b.Gspbill_id AND a.Product_Id = b.P_id AND a.BillType IN (521, 522, 524) AND 
									  a.Bill_Id = @OldBillID AND b.UneligibleQty > 0
								GROUP BY a.Product_Id, a.Sfda_Code, a.BatchNo, a.ValidDate, a.MakeDate
							
							END
							ELSE
								GOTO ERROR
						END
					END
				END
			END
			/* 其余所有 Gsp单据到gsp单据*/
			else
			begin 
				if ((@OldBillType > 500) and (@NewBillType > 500)) AND ((@OldBillType <> 561) and (@NewBillType <> 541))
				begin
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode,YE_ID,SendC_Id)
					SELECT   @NewBillType, @szBillNumber, Y_id, c_id, @dtBillDate, CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, Note,10, s_id, TrafficTime, 
								NEWID(),FollowNumber,TicketDate, BalanceMode,YE_ID,SendC_Id
			    	FROM      dbo.GSPbillidx
			     	WHERE Gspbillid = @OldBillID
				  
					SELECT @nNewBillID = @@IDENTITY
					
					/*当启用YNDZ001时，自动将拣货单的复核人填写到复核单*/
					if (@nYNDZ001 = 1) and (@NewBillType=551)
					begin
					  select @szCheckOutMan ='复核人：' + isnull(e.name, '') 
					    from GSPbillidx bi left join 
					         employees e on bi.AuditMan2 = e.emp_id
					   where bi.Gspbillid = @OldBillID     					  
                      update GSPbillidx set Note =@szCheckOutMan + ' '+ Note  where GSPbillid = @nNewBillID 					  					
					end	
														

					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
			   					pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
								discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
								checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
								BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
								Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal,OldOrderQty,OldOrderUnit,
								OldOrderUnitId,OldOrderUnitRate)
						SELECT   @nNewBillID, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
									pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy,  total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, '', checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal,OldOrderQty,OldOrderUnit,
								    OldOrderUnitId,OldOrderUnitRate
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID
						order by Gspsmb_id

						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						/*-控制状态15 不能在生成单据*/
						update GSPbillidx set BillStates = 15 where Gspbillid = @OldBillID AND BillType IN (541, 551)  AND Yguid <> 0x0
						IF @OldBillType=541 AND @NewBillType=551 /*-写入检验报告*/
						begin
							exec  TS_Y_InsertCheckReport @nNewBillID
						end
					END
					ELSE
						GOTO ERROR
				end
				
			END     /*-else end*/
		END
	END
	IF (@OldBillType = 564) AND (@NewBillType IN (161))
	BEGIN
		/*实时在线机构退回通知单生成机构收货退货单、自营店收货退货单在此处理*/
		IF EXISTS(SELECT 1 FROM company c WHERE c.[deleted] = 0 AND c.posdatamode = 0 AND c.child_count = 0 AND c.company_id <> 2)
		BEGIN
			DECLARE gvtYBackInformCreatevtYReceiveBack CURSOR  
			FOR
				SELECT c.company_id, CASE WHEN sendBillType = 1 THEN 161 ELSE 163 END AS billtype  
					FROM company c 
				WHERE c.[deleted] = 0 AND c.posdatamode = 0 AND c.child_count = 0 AND c.company_id <> 2	
			OPEN gvtYBackInformCreatevtYReceiveBack
			FETCH NEXT FROM gvtYBackInformCreatevtYReceiveBack INTO @nYId, @NewBillType                                                                                                     
			WHILE @@FETCH_STATUS = 0
			BEGIN
				/*为分支机构生成各自的机构退回通知单*/
				SET @nRet = -1
				EXEC TS_H_CreateBillSN @OldBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nYId
				
				INSERT INTO GSPbillidx
				(BillType, BillNumber, Y_id, C_id, S_id, BillDate, InputMan, AuditMan1, AuditTime1, AuditMan2, AuditTime2, UpauditMan1, UpauditMan2,
				 TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, SendTime, TrafficCompany, TempControlMode,
				 WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, GUID, BillStates, Note, B_CustomName1, B_CustomName2,
				 B_CustomName3, B_CustomName4, B_CustomName5, financeAudit, financeAuditDate, FollowNumber, TicketDate, transflag, Sendid, BalanceMode)
				SELECT @OldBillType, @szBillNumber, @nYid, Y_id, S_id, GETDATE(), InputMan, InputMan, GETDATE(), AuditMan2, AuditTime2, UpauditMan1, UpauditMan2,
					   TrafficType, TrafficTools, TrafficTime, TempControl, SpecTrafficProve, SendAddress, SendTime, TrafficCompany, TempControlMode,
					   WholeQty, PartQty, DiscountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, GUID, 13, Note, B_CustomName1, B_CustomName2,
					   B_CustomName3, B_CustomName4, B_CustomName5, financeAudit, financeAuditDate, FollowNumber, TicketDate, transflag, Sendid, BalanceMode 
					FROM GSPbillidx
				WHERE Gspbillid = @OldBillID
				
				SET @nTmpBillId = @@IDENTITY
			    
				INSERT INTO GSPbilldetail
				(Gspbill_id, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, RefuseQty, PickQty, CheckQty,
				 SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, Pricediscrepancy, Total, Discount, DiscountTotal,
				 TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept,
				 CheckReport, ReturnReason, CheckState, CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode,
				 Batchcomment, BatchPrice, Iscold, Isspec, Y_id, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2,
				 Comment3, factoryid, costtaxprice, costtaxrate, costtaxtotal)
				SELECT @nTmpBillId, P_id, MakeDate, Validdate, Batchno, Unit_id, Yqty, EligibleQty, UneligibleQty, InceptQty, RefuseQty, PickQty, CheckQty,
					   SampleQty, ApplicantQty, ThQty, YtaxPrice, Price, DiscountPrice, TaxPrice, Pricediscrepancy, Total, Discount, DiscountTotal,
					   TaxRate, TaxMoney, TaxTotal, CostPrice, CostTotal, InceptState, RefuseReason, UneligibleReason, UneligibleTranSactor, CheckAccept,
					   CheckReport, ReturnReason, CheckState, CheckReason, S_id, Location_id, Supplier_id, InstoreTime, CanSaleQty, BatchBarCode,
					   Batchcomment, BatchPrice, Iscold, Isspec, @nYid, Aoid, SfdAcounts, OrgBillid, YrowGuid, CommisionFlag, RowGUID, Comment, Comment2,
					   Comment3, factoryid, costtaxprice, costtaxrate, costtaxtotal
					FROM GSPbilldetail
				WHERE Gspbill_id = @OldBillID
		        
				/*生成机构类收货退货单据*/
				EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nYId				
				INSERT INTO billdraftidx
				(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate,
				 period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount,
				 lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID,
				 transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty,
				 PartQty, DPdate, financeAudit, financeAuditDate, FollowNumber, QualityAudit, QualityAuditDate, TicketDate, YGuid, BalanceMode)
				SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, @NewBillType, 0, @nOrderYid, InputMan, S_id, 0, 0, InputMan, 0, 0, 0, 0,
					   1, 2, 0, 0, 0, 0, '1900-01-01', '1900-01-01', 0, 0, '原单编号【' + billnumber + '】', '', 0, 0, 
					   '1900-01-01', NEWID(), 0, '', 0, 0, 0, 0, 0, 0, @nYid, 
					   0, '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 0, 0,
					   0, '1900-01-01', 0, '1900-01-01', '', 0, '1900-01-01', '1900-01-01', GUID, -1
					FROM GSPbillidx 
				WHERE Gspbillid = @nTmpBillId
				
				SELECT @nNewBillID = @@IDENTITY
				
				INSERT INTO buymanagebilldrf
				(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, taxmoney,
				 retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag,
				 comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno,
				 PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode,
				 scomment, batchprice, Conclusion, costtaxprice, costtaxrate, costtaxtotal, factoryid)
				SELECT @nNewBillID, a.P_id, a.Batchno, a.ApplicantQty, 0, 0, 1, 0, 0, 0, 0, 0,
				0, 0, a.MakeDate, a.Validdate, '合格', 0, a.S_id, 0, 0, 0, 0,
				'', a.Unit_id, 0, 0, 0, 0, 0, a.ApplicantQty, 0, 0, 0, 0, 0, '',
				-1, a.ApplicantQty, 0, NEWID(), b.InputMan, 0, b.Yguid, @nYid, 0, '1900-01-01', '', '',
				'', 0, '', 0, 0, 0, 0  
					FROM GSPbilldetail a, GSPbillidx b
				WHERE a.Gspbill_id = b.Gspbillid AND Gspbill_id = @nTmpBillId
				
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @nTmpBillId, @OldBillType, 1, 0
				SET @nRet = @nNewBillID
				FETCH NEXT FROM gvtYBackInformCreatevtYReceiveBack INTO @nYId, @NewBillType
			END
			CLOSE gvtYBackInformCreatevtYReceiveBack
			DEALLOCATE gvtYBackInformCreatevtYReceiveBack	
			
		END
		ELSE
			SET @nRet = 1	
	END
		
	IF (@OldBillType = 525) AND ((@NewBillType = 104) OR (@NewBillType = 106))	
	BEGIN
		IF @NewBillType = 106
			SET @nRet = 9999
		ELSE
		IF @NewBillType = 104
		BEGIN
			/*直调验收单生成直调药品采购单（中间商）、直调药品销售单（中间商）；不合格的生成上架确认单入不合格品库*/
			/*-行仓库带入主表仓库*/
			DECLARE @DirectSId INT
			SET @DirectSId = (SELECT TOP 1 g.S_id FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID)
			UPDATE GSPbillidx SET S_id = @DirectSId WHERE Gspbillid = @OldBillID 
			
			IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.EligibleQty > 0)
			BEGIN
				DECLARE @IdxQty NUMERIC(25,8)
				SET @IdxQty = 0
				SELECT @IdxQty = SUM(g.EligibleQty) FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID
				
				/*生成直调药品采购单（中间商）草稿*/
				INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
										 ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
										 auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
										 InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
										 begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, 
										 PartQty, YGuid)
				SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @szBillNumber, 104, 0, g.C_id, g.AuditMan1, g.S_id, g.S_id, g.AuditMan1, g.AuditMan1,
					   g.TaxTotal, 0, @IdxQty, 0, 0, 3, 0, 0, 0, 0,
						CONVERT(VARCHAR(100), GETDATE(), 23), '1900-01-01', g.TaxTotal, 0, '直调验收单' + g.billnumber, '', 0, 0, '1900-01-01', NEWID(),
						0, '', 0, 0, @IdxQty, 0, 0, 0, g.Y_id, 0,
						'1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', o.c_id, g.WholeQty, 
						g.PartQty, g.Yguid 
				FROM GSPbillidx g INNER JOIN orderidx o ON g.Ybillid = o.billid
				WHERE g.Gspbillid = @OldBillID	
				
				SELECT @nNewBillID = @@IDENTITY
				
				IF @nNewBillID > 0
				BEGIN
					INSERT INTO buymanagebilldrf
							(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, 
							 taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, 
							 location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, 
							 thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, 
							 RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, 
							 batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @nNewBillID, b.p_id, batchno, eligibleqty, price, price, discount, DiscountPrice, discounttotal, taxprice, 
						   TaxTotal, taxmoney, 0, 0, makedate, validdate, '合格', 0, s_id, 0, 
						   location_id, supplier_id, commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, 
						   eligibleqty, TaxPrice, orgbillid, aoid, 0, 0, '', -1, eligibleqty, CostTotal, 
						   NEWID(), 0, 0, Yrowguid, y_id, 0, instoretime, comment2, BatchBarCode, Batchcomment, 
						   batchprice, '',factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM dbo.GSPbilldetail b		
					WHERE Gspbill_id = @OldBillID
					
					IF @@ROWCOUNT <= 0
						GOTO ERROR	
					EXEC TS_H_BillTraceAct 0, @nNewBillID, 104, @OldBillID, @OldBillType, 1, 0	
				END
				ELSE
					GOTO ERROR
					
				/*生成直调药品销售单（中间商）草稿*/
				DECLARE @vtSaleDirectMidBillId INT
				SET @szBillNumber = ''
				EXEC TS_H_CreateBillSN 106, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
				INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
										 ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
										 auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
										 InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
										 begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, 
										 PartQty, YGuid)
				SELECT billdate, @szBillNumber, 106, a_id, sendC_id, e_id, sout_id, sin_id, auditman, inputman, 
					  ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
					  auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
					  InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
					  begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, c_id, WholeQty, 
					  PartQty, YGuid
				FROM billdraftidx WHERE billid = @nNewBillID  
				SELECT @vtSaleDirectMidBillId = @@IDENTITY
				
				IF @vtSaleDirectMidBillId > 0
				BEGIN
					INSERT INTO Salemanagebilldrf
							(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, 
							 taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, 
							 location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, 
							 thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, 
							 RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, 
							 batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT @vtSaleDirectMidBillId, b.p_id, b.batchno, b.eligibleqty, b.price, b.YtaxPrice, b.discount, 
						   /*b.YtaxPrice * b.Discount, (b.YtaxPrice * b.Discount) * b.eligibleqty, b.YtaxPrice * (1 + o.taxrate), */
						   o.discountprice, o.discountprice * b.eligibleqty, b.YtaxPrice * (1 + o.taxrate), 
						   b.YtaxPrice * (1 + o.taxrate) * b.EligibleQty, b.YtaxPrice * (o.taxrate) * b.EligibleQty, 
						   0, 0, b.makedate, b.validdate, '合格', 0, s_id, 0, 
						   b.location_id, b.supplier_id, commisionflag, b.comment, unit_id, o.TaxRate, b.orgbillid, o.total, 0, 0, 
						   b.eligibleqty, b.YtaxPrice * (1 + o.taxrate), b.orgbillid, b.aoid, 0, 0, '', -1, b.eligibleqty, b.price * b.eligibleqty, 
						   NEWID(), 0, 0, b.Yrowguid, b.y_id, 0, b.instoretime, b.comment2, b.BatchBarCode, b.Batchcomment, 
						   b.batchprice, '',b.factoryid,b.costtaxprice,b.costtaxrate,b.costtaxtotal
					FROM dbo.GSPbilldetail b INNER JOIN OrderBill o ON b.OrgBillid = o.smb_id		
					WHERE Gspbill_id = @OldBillID
					
					IF @@ROWCOUNT <= 0
						GOTO ERROR	
					    UPDATE billdraftidx 
						SET ysmoney = 
						(
						  select sum(taxtotal) as taxtotal from 
						  (
							   SELECT SUM(taxtotal) taxtotal FROM Salemanagebilldrf WHERE bill_id = @vtSaleDirectMidBillId  and AOID in (0,5)
							   union all
							   SELECT 0 as taxtotal FROM Salemanagebilldrf WHERE bill_id = @vtSaleDirectMidBillId  and AOID not in (0,5)
						   )r
						) 
					   WHERE billid = @vtSaleDirectMidBillId
					
					EXEC TS_H_BillTraceAct 0, @vtSaleDirectMidBillId, 106, @OldBillID, @OldBillType, 1, 0		
				END
				ELSE
					GOTO ERROR
					
				SET @nRet = @nNewBillID
				
				/*
				DECLARE @ResultId INT, @FVchCode INT
				SET @ResultId = 0
				SET @FVchCode = 0
				EXEC ts_c_BillAudit;1 @nNewBillID, @ResultId, @FVchCode, 104
				IF @ResultId > 0 SET @nRet = @ResultId
				
				IF @FVchCode = 0
				BEGIN
					SET @ResultId = 0
					SET @FVchCode = 0
					EXEC ts_c_BillAudit;1 @vtSaleDirectMidBillId, @ResultId, @FVchCode, 106
					IF @FVchCode < 0
						GOTO ERROR	
				END
				ELSE
					GOTO ERROR	
				*/			
			END
			/*不合格数量生成上架确认单，仓库为不合格品库*/
			IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.UneligibleQty > 0)
			BEGIN
				DECLARE @UneSId INT
				SET @UneSId = 0
				SELECT @UneSId = storage_id FROM storages 
				WHERE qualityFlag = 1 AND deleted = 0 AND y_id = (SELECT DISTINCT Y_ID FROM GSPbillidx WHERE Gspbillid = @OldBillID)
				/*获取不合格品库ID*/
				IF @UneSId > 0
				BEGIN
					SET @szBillNumber = ''
					EXEC TS_H_CreateBillSN 531, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
					INSERT INTO GSPbillidx(billtype, billnumber, Y_id, c_id, billdate, inputman, auditman1, audittime1, auditman2, audittime2, 
								upauditman1, upauditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, Yguid, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5,Note, billstates, s_id, TrafficTime, 
								GUID,FollowNumber,TicketDate, BalanceMode,YE_Id)
						SELECT  531, @szBillNumber, Y_id, c_id, GETDATE(), CASE WHEN auditman2 > 0 THEN auditman2 WHEN auditman1 > 0 THEN auditman1 ELSE 0 END, 0, '1900-1-1', 0, '1900-1-1', 
								auditman1, auditman2, traffictype, traffictools, tempcontrol, spectrafficprove, sendaddress, sendtime, 
								trafficCompany, tempcontrolmode, WholeQty, PartQty, discountTotal, TaxTotal, Ybillid, Ybilltype, CASE @OldBillType WHEN 524 THEN GUID ELSE Yguid END, 
								b_CustomName1, b_CustomName2, b_CustomName3, b_CustomName4, b_CustomName5, '直调验收不合格品退库，直调验收单号：' + billnumber, 10, @UneSId, TrafficTime, 
								NEWID(),FollowNumber,TicketDate, BalanceMode,YE_Id
	    				FROM      dbo.GSPbillidx
	    				WHERE Gspbillid = @OldBillID
	    			SELECT @nNewBillID = @@IDENTITY
					
					IF @nNewBillID > 0
					BEGIN
						INSERT INTO GSPbilldetail(Gspbill_id, p_id, makedate, validdate, batchno, unit_id, Yqty, eligibleqty, uneligibleqty, inceptqty, refuseqty, 
   									pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy, total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, s_id, location_id, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, comment, comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, RowGUID,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT      @nNewBillID, p_id, makedate, validdate, batchno, unit_id, uneligibleqty, uneligibleqty, 0, inceptqty, refuseqty, 
			  						pickqty, checkqty, sampleqty, applicantqty, thqty, Ytaxprice, price, DiscountPrice, taxprice, pricediscrepancy,  total, 
									discount, discounttotal, TaxRate, taxmoney, TaxTotal, inceptstate, refusereason, uneligiblereason, uneligibletransactor, 
									checkaccept, checkreport, returnreason, checkstate, checkreason, @UneSId, 0, supplier_id, instoretime, cansaleqty, 
									BatchBarCode, Batchcomment, batchprice, Iscold, Isspec, dbo.GetProductComment(P_id, UneligibleQty), comment2, y_id, aoid, sfdacounts, orgbillid, 
									Yrowguid, commisionflag, CostPrice, CostTotal, NEWID(),factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail
						WHERE Gspbill_id = @OldBillID AND unEligibleQty > 0
						ORDER BY Gspsmb_id
						IF @@ROWCOUNT <= 0
							GOTO ERROR
						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, 531, @OldBillID, @OldBillType, 1, 0
					END
					ELSE
						GOTO ERROR
				END
			END	
		END	
	END	
	
	/*机构验收单生成自营店收货单草稿*/
	IF (@OldBillType = 523) AND (@NewBillType IN (160, 162))
	BEGIN
		/* 不是自营店发货单生成的验收单才生成收货单*/
		IF EXISTS(SELECT * FROM GSPbillidx WHERE Ybillid = 0 AND Gspbillid = @OldBillID)
		BEGIN
			SET @nCreateEligibleQty = 0
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
									ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
									auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
									InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
									begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, 
									PartQty, YGuid,FollowNumber,TicketDate, BalanceMode)
			SELECT @dtBillDate, @szBillNumber, @NewBillType, 0, i.c_id, i.inputman, i.s_id, i.s_id, 0, i.inputman, 
				i.TaxTotal, 0, 0, 0, 0, 2, i.Ybillid, 0, 0, 0, 
				'1900-1-1', '1900-01-01', i.TaxTotal, 0, '机构验收单编号：' + i.billnumber, '', 0, 0, '1900-1-1', GUID, 
				0, '', 0, 0, 0, 0, 0, 0, i.y_id, 0, 
				'1900-1-1', '1900-1-1', 0, 0, '', '', '', CONVERT(varchar(100), i.billdate, 23), 0, i.WholeQty, 
				i.PartQty, i.Yguid,i.FollowNumber,i.TicketDate, BalanceMode
			FROM dbo.GSPbillidx i
			WHERE i.Gspbillid = @OldBillID
			SELECT @nNewBillID = @@IDENTITY
		
			IF @nNewBillID > 0
			BEGIN
				INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, 
											 taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, 
											 location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, 
											 thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, SendCostTotal, 
											 RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, scomment, 
											 batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT @nNewBillID, b.p_id, batchno, Yqty, costprice, price, discount, DiscountPrice, Yqty * DiscountPrice, taxprice, 
						Yqty * TaxPrice, Yqty * TaxPrice - Yqty * DiscountPrice, ISNULL(c.retailprice, 0) AS retailprice, ISNULL(c.retailprice, 0) * Yqty, makedate, validdate, '合格', 0, s_id, s_id, 
						location_id, supplier_id, commisionflag, dbo.GetProductComment(b.p_id, Yqty), unit_id, TaxRate, 0, Yqty * price, 0, 0, 
						Yqty, TaxPrice, orgbillid, aoid, 0, 0, '', 0, Yqty, Yqty * costprice, 
						NEWID(), 0, CostPrice, Yrowguid, y_id, 0, instoretime, comment2, BatchBarCode, Batchcomment, 
						batchprice, '',factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM dbo.GSPbilldetail b LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id
				WHERE Gspbill_id = @OldBillID AND Yqty > 0

				SET @nRet = @nNewBillID
				SET @nCreateEligibleQty = 1
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
				EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
				INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
				SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
					FROM RetailBillidx_Sfda 
				WHERE BillType = 523 AND Bill_Id = @OldBillID
					/*-------------判断赠品商品没有ysmoney*/
				UPDATE billdraftidx SET ysmoney = X.TOTAL, quantity = X.QTY
								FROM (
									   select SUM(TOTAL) as total,sum(QTY) as qty,bill_id from 
									   (
										 SELECT bill_id, SUM(taxtotal) AS TOTAL, SUM(quantity) AS QTY FROM buymanagebilldrf WHERE bill_id = @nNewBillID AND p_id > 0 and AOID in (0,5) GROUP BY bill_id 
										 union all
										 SELECT bill_id, 0 AS TOTAL, SUM(quantity) AS QTY FROM buymanagebilldrf WHERE bill_id = @nNewBillID AND p_id > 0 and AOID not in (0,5) GROUP BY bill_id
									   )r group by bill_id
									 ) X
								WHERE billdraftidx.billid = X.bill_id
				/*--------------判断赠品商品没有ysmoney*/
			END 
			ELSE
				GOTO ERROR

			/*验收后把可退数量写回验收单*/
			UPDATE GSPbilldetail set ThQty = Yqty  WHERE Gspbill_id = @OldBillID			
		END
		ELSE
		BEGIN	
			/* 不合格商品生成同价调拨单*/
			/* 不再判断此开关*/
			/*IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'PutonbillDealUneligible' AND sysvalue = '1')*/
			BEGIN
				/* 设置单据类型为同价调拨单*/
				SET @NewBillType = 44
				SET @dtBillDate = CONVERT(VARCHAR(10), GETDATE(), 120)
				IF EXISTS(SELECT 1 FROM GSPbilldetail g WHERE g.Gspbill_id = @OldBillID AND g.UneligibleQty > 0)
				BEGIN
					SELECT @nOrderYid = Y_ID, @nEid = InputMan FROM GSPbillidx WHERE Gspbillid = @OldBillID
					/* 取不合格品库*/
					SET @nUeStoreOther = 0
					SELECT @nUeStoreOther = storage_id FROM storages WHERE qualityFlag = 1 AND Y_ID = @nOrderYid
					IF @nUeStoreOther > 0
					BEGIN
						EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid
						INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
													ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, posid, region_id, 
													auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, 
													InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, 
													begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, 
													PartQty, YGuid, BalanceMode)
						SELECT @dtBillDate, @szBillNumber, @NewBillType, 0, 0, i.InputMan, i.S_id, @nUeStoreOther, i.auditMan1, i.inputman, 
								i.TaxTotal, 0, 0, 0, 0, 3, 0, 0, 0, 0, 
								GETDATE(), '1900-01-01', i.TaxTotal, 0, '机构验收单编号：' + i.billnumber, '', 0, 0, '1900-1-1', NEWID(), 
								0, '', 0, 0, 0, 0, 0, 0, i.y_id, 0, 
								'1900-1-1', '1900-1-1', 0, 0, '', '', '', CONVERT(varchar(100), i.billdate, 23), 0, i.WholeQty, 
								i.PartQty, i.Yguid, i.BalanceMode
						FROM dbo.GSPbillidx i
						WHERE i.Gspbillid = @OldBillID
			    		SELECT @nNewBillID = @@IDENTITY
			    		
			    		IF @nNewBillID > 0
						BEGIN
							INSERT INTO storemanagebilldrf
									(bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate, qualitystatus, price_id, 
									ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, location_id2, iotag, total, InvoiceTotal, thqty, newprice, orgbillid, AOID, 
									SendQTY, SendCostTotal, RowGuid, RowE_id, Y_ID, instoretime, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT @nNewBillID, b.p_id, b.batchno, b.UneligibleQty, b.price, b.CostPrice * b.UneligibleQty, b.CostPrice, b.CostPrice * b.UneligibleQty, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * UneligibleQty, b.MakeDate, b.Validdate, '合格', 0,
									b.S_id, @nUeStoreOther, b.Location_id, b.Supplier_id, b.CommisionFlag, b.Comment, b.Unit_id, 0, 0, b.CostPrice * b.UneligibleQty, 0, b.UneligibleQty, b.CostPrice, 0, b.Aoid,
									b.UneligibleQty, b.CostPrice * b.UneligibleQty, NEWID(), @nEid, b.Y_id, b.InstoreTime, b.BatchBarCode, b.Batchcomment, b.BatchPrice, '',b.factoryid,costtaxprice,costtaxrate,costtaxtotal

							FROM dbo.GSPbilldetail b LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id
							WHERE Gspbill_id = @OldBillID AND UneligibleQty > 0

							UPDATE billdraftidx SET ysmoney = X.TOTAL, quantity = X.QTY
							FROM (
										SELECT bill_id, SUM(total) AS TOTAL, SUM(quantity) AS QTY FROM storemanagebilldrf WHERE bill_id = @nNewBillID AND p_id > 0 GROUP BY bill_id 
									) X
							WHERE billdraftidx.billid = X.bill_id

							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
							/*EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID*/
						END
						ELSE
							GOTO ERROR
					END
					ELSE
						GOTO ERROR
				END
				ELSE
					SET @nRet = 999999999
			END
		END
	END
	
	/*上架确认单生成采购单*/
	if (@OldBillType = 531) and (@NewBillType = 20)
	begin
	    /*-行仓库带入主表仓库*/
	    DECLARE @billsid int ,@vbillsid int
	    set  @billsid=(select top 1 S_id from GSPbilldetail where Gspbill_id=@OldBillID)   
	    set  @vbillsid=(select top 1 S_id from GSPbillidx where Gspbillid=@OldBillID)
	    if @vbillsid =0 
	    begin
	      update GSPbillidx set s_id=@billsid where Gspbillid=@OldBillID
	    end
	    /*--end*/
	   IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'BuyBillStoragesSplit' AND sysvalue = '1') 
	   begin
			/*创建拣货单明细仓库临时表  zjx*/
			IF object_id(N'#SID531_4', N'U') is not null  
			  DROP TABLE #SID531_4   
			select Distinct s_id into #SID531_4 from GSPbilldetail where Gspbill_id = @OldBillID
			/*上架确认单生成采购单按仓库分单生成 zjx*/
			DECLARE @SID531_4 int
			DECLARE SID4_cursor CURSOR FOR SELECT s_id FROM #SID531_4
			OPEN SID4_cursor
			FETCH NEXT FROM SID4_cursor INTO @SID531_4
			WHILE @@FETCH_STATUS = 0
			BEGIN	
			           /*先获取单号*/
                        EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid  /*zjx*/
						INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
								taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
								invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
								VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
								B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,FollowNumber,TicketDate, BalanceMode)
						SELECT   @dtBillDate, CASE @nUseOrderBillNum WHEN 1 THEN O.billnumber ELSE @szBillNumber END, @NewBillType, 0, O.c_id, i.YE_ID, @SID531_4, @SID531_4, /*zjx--I.s_id,I.s_id替换@SID531, @SID531 */
								/* (case when I.s_id=0 then  @billsid else I.s_id end)as s_id, */
								 0, I.inputman, 0, 0, 0,
								O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + isnull(o.billnumber,'')+'  '+isnull(i.note,''), '',
								o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
								0, 0, O.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
								'', I.billdate, 0, I.WholeQty, I.PartQty, I.Yguid,I.FollowNumber,I.TicketDate, o.BalanceMode
						FROM      dbo.GSPbillidx AS I INNER JOIN
								dbo.orderidx AS O ON I.Ybillid = O.billid
						WHERE Gspbillid = @OldBillID

						SELECT @nNewBillID = @@IDENTITY

						IF @nNewBillID > 0
						BEGIN
							SELECT @nOrderBillId = isnull(Ybillid,0) FROM GSPbillidx WHERE Gspbillid = @OldBillID
							SELECT @nEid = isnull(E_ID,0) FROM orderidx WHERE billid = @nOrderBillId

							INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
								taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
								commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
								invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
								instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
								taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice*b.InceptQty, 0), makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
								commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
								0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
								instoretime, comment2, BatchBarCode, Batchcomment, batchprice, '',b.factoryid,costtaxprice,costtaxrate,costtaxtotal
							FROM      dbo.GSPbilldetail b
							 LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id 		
							WHERE Gspbill_id = @OldBillID
							      AND b.s_id = @SID531_4  /*zjx*/
						    
							if @@ROWCOUNT >0
							begin
								update buymanagebilldrf set totalmoney = quantity*discountprice, total=buyprice*quantity 
															/*taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity  */
													where bill_id = @nNewBillID
							   select @BillQty= SUM(quantity) ,@billtotal=sum(taxtotal)  from 
							   (
		       					select SUM(quantity) as quantity, SUM(taxtotal) as taxtotal from buymanagebilldrf where bill_id  =@nNewBillID and AOID in (0,5)
		       					union all
		       					select SUM(quantity) as quantity, 0 as taxtotal  from buymanagebilldrf where bill_id  =@nNewBillID and AOID not in (0,5)
							   ) a
								update billdraftidx set quantity = @BillQty, SendQTY = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID	    
							
								EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
								EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
								/*处理上架确认单生成采购入库单草稿的电子监管码*/
								INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
								SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
									FROM RetailBillidx_Sfda 
								WHERE BillType = 531 AND Bill_Id = @OldBillID	
								      AND Product_Id in (select distinct P_id from GSPbilldetail where Gspbill_id = @OldBillID AND s_id = @SID531_4)  /*zjx*/
								/*采购入库单收款日期等于采购订单收款日期-采购订单单据日期+采购入库单单据日期*/
								DECLARE @dSkDate_4 DATETIME, @dBillDate_4 DATETIME
								SELECT @dBillDate_4 = o.billdate, @dSkDate_4 = o.skdate FROM orderidx o WHERE o.billid = @nOrderBillId
								IF @dSkDate_4 > 10
								BEGIN
									UPDATE billdraftidx SET skdate = CAST(@dSkDate_4 AS INT) - CAST(@dBillDate_4 AS INT) + @dtBillDate 
									WHERE billid = @nNewBillID	
								END					
								IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditInStore' AND sysvalue = '1')
								BEGIN
									/*采购入库单草稿审核人和制单人取采购订单上的审核人和制单人*/
									UPDATE a SET a.inputman = b.inputman, a.auditman = b.auditman, a.auditdate = GETDATE() 
										FROM billdraftidx a, (SELECT @nNewBillID AS billid, o.inputman, o.auditman 
																FROM Gspbillidx g INNER JOIN Orderidx o ON g.ybillid = o.billid 
															  WHERE o.billtype = 22 AND g.Gspbillid = @OldBillID) b 
									WHERE a.billid = b.billid 
									
									SET @FResultId_BillAudit = -1
									SET @FVchCode_BillAudit = -1
									EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 20
									IF @FResultId_BillAudit > 0 
									BEGIN
										SET @nRet = @FResultId_BillAudit
										/*EXEC TS_H_BillTraceAct 0, @FResultId_BillAudit, @NewBillType, @OldBillID, @OldBillType, 0, 0*/
									END
									ELSE
										GOTO ERROR		
								END
							end
							ELSE
								GOTO ERROR
							/*删除拣货单明细仓库临时表  zjx*/
							IF object_id(N'#SID531_4', N'U') is not null  
							DROP TABLE #SID531_4 
							SET @nRet = @nNewBillID
						END 
						ELSE
							GOTO ERROR
					 FETCH NEXT FROM SID4_cursor INTO @SID531_4
				 END
					CLOSE SID4_cursor
					DEALLOCATE SID4_cursor
		end
		else
		begin
				INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
						VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
						B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid,FollowNumber,TicketDate, BalanceMode)
				SELECT   @dtBillDate, CASE @nUseOrderBillNum WHEN 1 THEN O.billnumber ELSE @szBillNumber END, @NewBillType, 0, O.c_id, i.YE_ID, I.s_id,I.s_id, 
						/* (case when I.s_id=0 then  @billsid else I.s_id end)as s_id, */
						 0, I.inputman, 0, 0, 0,
						O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + isnull(o.billnumber,'')+'  '+isnull(i.Note,''), '',
						o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
						0, 0, O.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
						'', I.billdate, 0, I.WholeQty, I.PartQty, I.Yguid,I.FollowNumber,I.TicketDate, o.BalanceMode
				FROM      dbo.GSPbillidx AS I INNER JOIN
						dbo.orderidx AS O ON I.Ybillid = O.billid
				WHERE Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
							SELECT @nOrderBillId = isnull(Ybillid,0) FROM GSPbillidx WHERE Gspbillid = @OldBillID
							SELECT @nEid = isnull(E_ID,0) FROM orderidx WHERE billid = @nOrderBillId

							INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
								taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
								commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
								invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
								instoretime, comment2, BatchBarCode, scomment, batchprice, Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
								taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice*b.InceptQty, 0), makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
								commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
								0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
								instoretime, comment2, BatchBarCode, Batchcomment, batchprice, '',b.factoryid,costtaxprice,costtaxrate,costtaxtotal
							FROM      dbo.GSPbilldetail b
							 LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id 		
							WHERE Gspbill_id = @OldBillID
						    
							if @@ROWCOUNT >0
							begin
								update buymanagebilldrf set totalmoney = quantity*discountprice, total=buyprice*quantity 
															/*taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity  */
													where bill_id = @nNewBillID
							   select @BillQty= SUM(quantity) ,@billtotal=sum(taxtotal)  from 
							   (
		       					select SUM(quantity) as quantity, SUM(taxtotal) as taxtotal from buymanagebilldrf where bill_id  =@nNewBillID and AOID in (0,5)
		       					union all
		       					select SUM(quantity) as quantity, 0 as taxtotal  from buymanagebilldrf where bill_id  =@nNewBillID and AOID not in (0,5)
							   ) a
								update billdraftidx set quantity = @BillQty, SendQTY = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID	    
							
								EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
								EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
								/*处理上架确认单生成采购入库单草稿的电子监管码*/
								INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
								SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
									FROM RetailBillidx_Sfda 
								WHERE BillType = 531 AND Bill_Id = @OldBillID	
								
								/*采购入库单收款日期等于采购订单收款日期-采购订单单据日期+采购入库单单据日期*/
								DECLARE @dSkDate DATETIME, @dBillDate DATETIME
								SELECT @dBillDate = o.billdate, @dSkDate = o.skdate FROM orderidx o WHERE o.billid = @nOrderBillId
								IF @dSkDate > 10
								BEGIN
									UPDATE billdraftidx SET skdate = CAST(@dSkDate AS INT) - CAST(@dBillDate AS INT) + @dtBillDate 
									WHERE billid = @nNewBillID	
								END					
								IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditInStore' AND sysvalue = '1')
								BEGIN
									/*采购入库单草稿审核人和制单人取采购订单上的审核人和制单人*/
									UPDATE a SET a.inputman = b.inputman, a.auditman = b.auditman, a.auditdate = GETDATE() 
										FROM billdraftidx a, (SELECT @nNewBillID AS billid, o.inputman, o.auditman 
																FROM Gspbillidx g INNER JOIN Orderidx o ON g.ybillid = o.billid 
															  WHERE o.billtype = 22 AND g.Gspbillid = @OldBillID) b 
									WHERE a.billid = b.billid 
									
									SET @FResultId_BillAudit = -1
									SET @FVchCode_BillAudit = -1
									EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 20
									IF @FResultId_BillAudit > 0 
									BEGIN
										SET @nRet = @FResultId_BillAudit
										/*EXEC TS_H_BillTraceAct 0, @FResultId_BillAudit, @NewBillType, @OldBillID, @OldBillType, 0, 0*/
									END
									ELSE
										GOTO ERROR		
								END
							end
							ELSE
								GOTO ERROR

							SET @nRet = @nNewBillID
						END 
						ELSE
							GOTO ERROR    
		end	
	end
	
	/*上架确认单生成销售出库退货单*/
	if (@OldBillType = 531) and (@NewBillType = 11)
	begin  
	  /*-zjx--2016-12-16---tfs44034销售出库退货单按仓库分单begin*/
	  IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'SaleBackBillStoragesSplit' AND sysvalue = '1') 
	  begin
			IF @nUseOrderBillNum = 1
			   SELECT @szBillNumber = BillNumber FROM GSPbillidx WHERE Gspbillid = (select billid from billTrace where traceGuid = (select traceGuid from billTrace where billId = @OldBillID AND billType = @OldBillType) and billType = 562)
              /*创建上架单明细仓库临时表  zjx*/
			IF OBJECT_ID(N'#SID531_3', N'U') IS NOT NULL  
			DROP TABLE #SID531_3   
			SELECT DISTINCT S_ID INTO #SID531_3 FROM GSPBILLDETAIL WHERE GSPBILL_ID = @OLDBILLID
			/*上架确认单生成销售出库货退货单按仓库分单生成 ZJX*/
			DECLARE @SID531_3 INT
			DECLARE SID3_CURSOR CURSOR FOR SELECT S_ID FROM #SID531_3
			OPEN SID3_CURSOR
			FETCH NEXT FROM SID3_CURSOR INTO @SID531_3
			WHILE @@FETCH_STATUS = 0
			BEGIN	
			     EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid /*zjx-先获取单号*/
				 INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
						VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
						B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
				 SELECT  TOP 1 @dtBillDate, @szBillNumber, @NewBillType, 0, ISNULL(O.c_id, I.C_id), ISNULL(i.YE_ID,0),@SID531_3,@SID531_3, 0, I.inputman, 0, 0, 0,/*zjx--I.s_id替换成@SID531_3*/
						ISNULL(O.taxrate, 0), ISNULL(O.period, 1), 2, ISNULL(O.billid, 0), ISNULL(O.department_id, 0), ISNULL(O.posid, 0), ISNULL(O.region_id, 0), '1900-1-1', 
						ISNULL(O.skdate, '1900-01-01'), ISNULL(O.jsye, 0), ISNULL(O.jsflag, 0), 
						CASE WHEN o.billnumber IS NULL THEN '' ELSE '订单编号：' + o.billnumber END + I.note, '',
						ISNULL(o.invoice, 0), 0, '1900-1-1', NEWID(), ISNULL(O.InvoiceTotal, 0), ISNULL(O.InvoiceNO, ''), ISNULL(O.BusinessType, 0), 0, 0, ISNULL(O.GatheringMan, 0),
						0, 0, ISNULL(O.Y_ID, i.Y_id), 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
						'', I.billdate, ISNULL(i.SendC_ID, 0), I.WholeQty, I.PartQty, I.Yguid, i.BalanceMode
				FROM      dbo.GSPbillidx AS I LEFT JOIN
						dbo.billidx AS O ON I.Ybillid = O.billid
				WHERE I.Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
						SELECT @nEid = E_ID FROM billidx WHERE billid IN (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)
						IF @nEid IS NULL 
							SET @nEid = 0
						IF @nOrderBillId IS NULL
							SET @nOrderBillId = 0
							
						INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
							taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
							commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
							invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
							instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
							taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
							commisionflag, comment, unit_id, TaxRate, @nOrderBillId, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
							0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
							instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail b			
						LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
						WHERE Gspbill_id = @OldBillID
						      AND b.s_id = @SID531_3  /*zjx*/
					    
						if @@ROWCOUNT >0
						begin
							update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
								taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity  
							where bill_id = @nNewBillID AND p_id > 0
						end
						ELSE
							GOTO ERROR

						/* 写入帐户信息*/
						INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
							taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
							commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
							invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
							instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
							taxmoney, 0, 0, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
							commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
							0, '', 0, eligibleqty, CostTotal, NEWID(), 0, 0, Yrowguid, y_id, 0,
							instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail b		
						WHERE Gspbill_id = (SELECT BILLID FROM billTrace WHERE traceGuid = (SELECT traceGuid FROM billTrace WHERE billId = @OldBillID AND billType = @OldBillType) AND billType = 562)
						AND P_id < 0
						AND b.s_id = @SID531_3/*zjx*/

						DECLARE @ssMoneyOne NUMERIC(25,8)
						select @BillQty=SUM(quantity),@billtotal=SUM(billtotal),@ssMoneyOne=SUM(ssmoney) from 
						(
						select  SUM(quantity) as quantity,SUM(taxtotal - (CASE p_id WHEN -59 THEN total ELSE 0 END)) as billtotal,  SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) as ssmoney from salemanagebilldrf  where bill_id = @nNewBillID and AOID in (0,5)
						union all
						select SUM(quantity) as quantity ,  0 as billtotal, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) as ssmoney from salemanagebilldrf  where bill_id = @nNewBillID and AOID not in (0,5)
						) a
						update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, ssmoney = @ssMoneyOne, jsye = @billtotal - @ssMoneyOne where billid = @nNewBillID
						IF EXISTS(SELECT * FROM salemanagebilldrf WHERE bill_id = @nNewBillID AND p_id < 0)
							UPDATE billdraftidx SET a_id = -100 WHERE billid = @nNewBillID
						
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						/*处理上架确认单生成销售出库退货单草稿的电子监管码*/
						INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
						SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
							FROM RetailBillidx_Sfda
						WHERE BillType = 531 AND Bill_Id = @OldBillID
						      AND Product_Id in (select distinct P_id from GSPbilldetail where Gspbill_id = @OldBillID AND s_id = @SID531_3)  /*zjx*/
						
						IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditInStore' AND sysvalue = '1')
						BEGIN
							/*销售出库退货单草稿审核人和制单人取销售退回申请单上的审核人和制单人*/
							UPDATE a SET a.inputman = b.InputMan, a.auditman = b.AuditMan1, a.auditdate = GETDATE() 
								FROM billdraftidx a, (SELECT TOP 1 @nNewBillID AS billid, InputMan, AuditMan1 
														FROM GSPbillidx 
													  WHERE Gspbillid IN (SELECT billid FROM billtrace 
																		  WHERE billtype = 562 AND 
																				traceguid IN (SELECT traceguid FROM billtrace 
																							  WHERE billid = @OldBillID and 
																									billtype = 531))
													  ) b 
							WHERE a.billid = b.billid
							
							SET @FResultId_BillAudit = -1
							SET @FVchCode_BillAudit = -1
							EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 11
							IF @FResultId_BillAudit > 0 
							BEGIN
								SET @nRet = @FResultId_BillAudit
								/*EXEC TS_H_BillTraceAct 0, @FResultId_BillAudit, @NewBillType, @OldBillID, @OldBillType, 0, 0*/
							END
							ELSE
								GOTO ERROR		
						END
						/*删除拣货单明细仓库临时表  zjx*/
		                IF object_id(N'#SID531_3', N'U') is not null  
                        DROP TABLE #SID531_3 		    
						SET @nRet = @nNewBillID
				END
				ELSE
					GOTO ERROR
			  FETCH NEXT FROM SID3_cursor INTO @SID531_3
			  END
			 CLOSE SID3_cursor
			 DEALLOCATE SID3_cursor
	  end
	   /*-zjx--2016-12-16---tfs44034销售出库退货单按仓库分单end*/
	  else
	  begin
			IF @nUseOrderBillNum = 1
				SELECT @szBillNumber = BillNumber FROM GSPbillidx WHERE Gspbillid = (select billid from billTrace where traceGuid = (select traceGuid from billTrace where billId = @OldBillID AND billType = @OldBillType) and billType = 562)

			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
					taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
					invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
					VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
					B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
			SELECT  TOP 1 @dtBillDate, @szBillNumber, @NewBillType, 0, ISNULL(O.c_id, I.C_id), ISNULL(i.YE_ID,0), I.s_id, I.s_id, 0, I.inputman, 0, 0, 0,
					ISNULL(O.taxrate, 0), ISNULL(O.period, 1), 2, ISNULL(O.billid, 0), ISNULL(O.department_id, 0), ISNULL(O.posid, 0), ISNULL(O.region_id, 0), '1900-1-1', 
					ISNULL(O.skdate, '1900-01-01'), ISNULL(O.jsye, 0), ISNULL(O.jsflag, 0), 
					CASE WHEN o.billnumber IS NULL THEN '' ELSE '订单编号：' + o.billnumber END + I.note, '',
					ISNULL(o.invoice, 0), 0, '1900-1-1', NEWID(), ISNULL(O.InvoiceTotal, 0), ISNULL(O.InvoiceNO, ''), ISNULL(O.BusinessType, 0), 0, 0, ISNULL(O.GatheringMan, 0),
					0, 0, ISNULL(O.Y_ID, i.Y_id), 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
					'', I.billdate, ISNULL(i.SendC_ID, 0), I.WholeQty, I.PartQty, I.Yguid, i.BalanceMode
			FROM      dbo.GSPbillidx AS I LEFT JOIN
					dbo.billidx AS O ON I.Ybillid = O.billid
			WHERE I.Gspbillid = @OldBillID

			SELECT @nNewBillID = @@IDENTITY

			IF @nNewBillID > 0
			BEGIN
				SELECT @nEid = E_ID FROM billidx WHERE billid IN (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)
				IF @nEid IS NULL 
					SET @nEid = 0
				IF @nOrderBillId IS NULL
					SET @nOrderBillId = 0
					
				INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
					taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
					commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
					invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
					instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
					taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
					commisionflag, comment, unit_id, TaxRate, @nOrderBillId, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
					0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
					instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM      dbo.GSPbilldetail b			
				LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
				WHERE Gspbill_id = @OldBillID
			    
				if @@ROWCOUNT >0
				begin
					update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
						taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity  
					where bill_id = @nNewBillID AND p_id > 0
				end
				ELSE
					GOTO ERROR

				/* 写入帐户信息*/
				INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
					taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
					commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
					invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
					instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
				SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
					taxmoney, 0, 0, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
					commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, orgbillid, aoid, 0,
					0, '', 0, eligibleqty, CostTotal, NEWID(), 0, 0, Yrowguid, y_id, 0,
					instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
				FROM      dbo.GSPbilldetail b		
				WHERE Gspbill_id = (SELECT BILLID FROM billTrace WHERE traceGuid = (SELECT traceGuid FROM billTrace WHERE billId = @OldBillID AND billType = @OldBillType) AND billType = 562)
				AND P_id < 0

				DECLARE @ssMoney NUMERIC(25,8)
				select @BillQty=SUM(quantity),@billtotal=SUM(billtotal),@ssMoney=SUM(ssmoney) from 
				(
				select  SUM(quantity) as quantity,SUM(taxtotal - (CASE p_id WHEN -59 THEN total ELSE 0 END)) as billtotal,  SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) as ssmoney from salemanagebilldrf  where bill_id = @nNewBillID and AOID in (0,5)
				union all
				select SUM(quantity) as quantity ,  0 as billtotal, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) as ssmoney from salemanagebilldrf  where bill_id = @nNewBillID and AOID not in (0,5)
				) a
				update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, ssmoney = @ssMoney, jsye = @billtotal - @ssMoney where billid = @nNewBillID
				IF EXISTS(SELECT * FROM salemanagebilldrf WHERE bill_id = @nNewBillID AND p_id < 0)
					UPDATE billdraftidx SET a_id = -100 WHERE billid = @nNewBillID
				
				EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
				/*处理上架确认单生成销售出库退货单草稿的电子监管码*/
				INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
				SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
					FROM RetailBillidx_Sfda
				WHERE BillType = 531 AND Bill_Id = @OldBillID
				
				IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditInStore' AND sysvalue = '1')
				BEGIN
					/*销售出库退货单草稿审核人和制单人取销售退回申请单上的审核人和制单人*/
					UPDATE a SET a.inputman = b.InputMan, a.auditman = b.AuditMan1, a.auditdate = GETDATE() 
						FROM billdraftidx a, (SELECT TOP 1 @nNewBillID AS billid, InputMan, AuditMan1 
												FROM GSPbillidx 
											  WHERE Gspbillid IN (SELECT billid FROM billtrace 
																  WHERE billtype = 562 AND 
																		traceguid IN (SELECT traceguid FROM billtrace 
																					  WHERE billid = @OldBillID and 
																							billtype = 531))
											  ) b 
					WHERE a.billid = b.billid
					
					SET @FResultId_BillAudit = -1
					SET @FVchCode_BillAudit = -1
					EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 11
					IF @FResultId_BillAudit > 0 
					BEGIN
						SET @nRet = @FResultId_BillAudit
						/*EXEC TS_H_BillTraceAct 0, @FResultId_BillAudit, @NewBillType, @OldBillID, @OldBillType, 0, 0*/
					END
					ELSE
						GOTO ERROR		
				END
						    
				SET @nRet = @nNewBillID
			END
			ELSE
				GOTO ERROR
	  end
	end
	/*上架确认单生成自营店/机构发货退货单begin*/
	if (@OldBillType = 531) and (@NewBillType IN(151, 153))
	begin
	        /*-zjx--2016-12-16---tfs44035机构发货退货单按仓库分单begin*/
	        IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'YSendBackBillStoragesSplit' AND sysvalue = '1') 
	        begin
			    if (@OldBillType = 531) and (@NewBillType IN(151))
			    begin
						/*创建上架单明细仓库临时表  zjx*/
						IF object_id(N'#SID531_1', N'U') is not null  
						DROP TABLE #SID531_1   
						select Distinct s_id into #SID531_1 from GSPbilldetail where Gspbill_id = @OldBillID
						/*上架确认单生成机构发货退货单按仓库分单生成 zjx*/
						DECLARE @SID531_1 int
						DECLARE SID1_cursor CURSOR FOR SELECT s_id FROM #SID531_1
						OPEN SID1_cursor
						FETCH NEXT FROM SID1_cursor INTO @SID531_1
						WHILE @@FETCH_STATUS = 0
						BEGIN	 	
							EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid /*zjx-先获取单号*/
							INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
									taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
									invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
									VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
									B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
							SELECT  @dtBillDate, @szBillNumber, @NewBillType, 0, I.c_id, O.e_id, @SID531_1, @SID531_1, 0, I.inputman, 0, 0, 0,/*I.s_id--替换成--@SID531_1--zjx*/
									O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber + I.note, '',
									o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
									0, 0, I.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
									'', I.billdate, 0, I.WholeQty, I.PartQty, i.Yguid, i.BalanceMode
							FROM      dbo.GSPbillidx AS I INNER JOIN
									dbo.billidx AS O ON I.Ybillid = O.billid
							WHERE Gspbillid = @OldBillID
							
							SELECT @nNewBillID = @@IDENTITY

							IF @nNewBillID > 0
							BEGIN
								SELECT @nEid = E_ID FROM billidx WHERE billid = (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)

								INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
									taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
									commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
									invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
									instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
								SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
									taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
									commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, B.OrgBillid, aoid, 0,
									0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
									instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
								FROM      dbo.GSPbilldetail b			
								LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
								WHERE Gspbill_id = @OldBillID  
									  AND b.s_id = @SID531_1  /*zjx*/
							    
								if @@ROWCOUNT >0
								begin
								/*取原发货单更新为原单批次								*/
								   UPDATE salemanagebilldrf SET
									p_id = x.p_id,
									batchno = x.batchno,
									costprice = x.costprice,
									saleprice = x.saleprice,
									discount = x.discount,
									discountprice = x.discountprice,
									costtaxprice = x.costtaxprice,
									totalmoney =
									case when salemanagebilldrf.quantity = x.quantity then x.totalmoney
									else x.discountprice * salemanagebilldrf.quantity end,
									taxprice = x.taxprice,
									taxtotal = 
									case when salemanagebilldrf.quantity = x.quantity then x.taxtotal
									else x.taxprice * salemanagebilldrf.quantity end,
									taxmoney = case when salemanagebilldrf.quantity = x.quantity then x.taxmoney
									else x.taxprice * salemanagebilldrf.quantity - x.saleprice * salemanagebilldrf.quantity end,
									retailprice = x.retailprice, 
									retailtotal = case when salemanagebilldrf.quantity = x.quantity then x.retailtotal
									else x.retailprice * salemanagebilldrf.quantity end, 
									makedate = x.makedate, 
									validdate = x.validdate,
									price_id = x.price_id,
									supplier_id = x.supplier_id,
									commissionflag = x.commissionflag,
									unitid = x.unitid,
									taxrate = x.taxrate,
									total = case when salemanagebilldrf.quantity = x.quantity then x.total
									else x.saleprice * salemanagebilldrf.quantity end,
									Y_ID = x.Y_ID,
									instoretime = x.instoretime,
									batchprice = x.batchprice,
									BatchBarCode = x.BatchBarCode,
									scomment = x.scomment,
									PriceType = x.PriceType,
									SendCostTotal = case when salemanagebilldrf.quantity = x.quantity then x.SendCostTotal
									else x.costprice * salemanagebilldrf.quantity end,
									RowE_id = x.RowE_id,
									YCostPrice = x.YCostPrice			
									FROM
									(select * from salemanagebill sm inner join (
										select bm.YGuid bYGuid,drf.YGuid sYGuid from
										(SELECT YGuid FROM salemanagebilldrf where bill_id = @nNewBillID) drf left join buymanagebill bm on drf.YGuid = bm.RowGuid
										) t on sm.RowGuid = t.bYGuid
									) X
									WHERE salemanagebilldrf.YGuid = x.sYGuid AND salemanagebilldrf.bill_id = @nNewBillID
									
									update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
																taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity ,
																costtaxtotal=costtaxprice*quantity
														where bill_id = @nNewBillID
									select @BillQty=SUM(quantity), @billtotal =SUM(taxtotal) from 
									( 
										select  SUM(quantity) as quantity,  SUM(taxtotal) as taxtotal from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID in (0,5)	
			     						union all
			     						select  SUM(quantity) as quantity,  0 as taxtotal             from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID not in (0,5)					
									) a
									update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID		    
								end
								ELSE
									GOTO ERROR
                                
                                /*删除拣货单明细仓库临时表  zjx*/
								IF object_id(N'#SID531_1', N'U') is not null  
								DROP TABLE #SID531_1
								SET @nRet = @nNewBillID
								EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
								EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
							END
							ELSE
								GOTO ERROR
							FETCH NEXT FROM SID1_cursor INTO @SID531_1
					   END
					   CLOSE SID1_cursor
					   DEALLOCATE SID1_cursor
			    end
	        end
	        /*-zjx--2016-12-16---tfs44035机构发货退货单按仓库分单end*/
	        else
	        begin
	             if (@OldBillType = 531) and (@NewBillType IN(151))
			     begin
					  INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
					  taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
					  invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
					  VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
					  B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
						SELECT  @dtBillDate, @szBillNumber, @NewBillType, 0, I.c_id, O.e_id, I.s_id, I.s_id, 0, I.inputman, 0, 0, 0,
								O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber + I.note, '',
								o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
								0, 0, I.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
								'', I.billdate, 0, I.WholeQty, I.PartQty, i.Yguid, i.BalanceMode
						FROM      dbo.GSPbillidx AS I INNER JOIN
								dbo.billidx AS O ON I.Ybillid = O.billid
						WHERE Gspbillid = @OldBillID

						SELECT @nNewBillID = @@IDENTITY

						IF @nNewBillID > 0
						BEGIN
							SELECT @nEid = E_ID FROM billidx WHERE billid = (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)

							INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
								taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
								commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
								invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
								instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
							SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
								taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
								commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, B.OrgBillid, aoid, 0,
								0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
								instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
							FROM      dbo.GSPbilldetail b			
							LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
							WHERE Gspbill_id = @OldBillID
						    
							if @@ROWCOUNT >0
							begin
							/*取原发货单更新为原单批次								*/
							   UPDATE salemanagebilldrf SET
								p_id = x.p_id,
								batchno = x.batchno,
								costprice = x.costprice,
								saleprice = x.saleprice,
								discount = x.discount,
								discountprice = x.discountprice,
								costtaxprice = x.costtaxprice,
								totalmoney =
								case when salemanagebilldrf.quantity = x.quantity then x.totalmoney
								else x.discountprice * salemanagebilldrf.quantity end,
								taxprice = x.taxprice,
								taxtotal = 
								case when salemanagebilldrf.quantity = x.quantity then x.taxtotal
								else x.taxprice * salemanagebilldrf.quantity end,
								taxmoney = case when salemanagebilldrf.quantity = x.quantity then x.taxmoney
								else x.taxprice * salemanagebilldrf.quantity - x.saleprice * salemanagebilldrf.quantity end,
								retailprice = x.retailprice, 
								retailtotal = case when salemanagebilldrf.quantity = x.quantity then x.retailtotal
								else x.retailprice * salemanagebilldrf.quantity end, 
								makedate = x.makedate, 
								validdate = x.validdate,
								price_id = x.price_id,
					/*			ss_id = x.ss_id,*/
					/*			sd_id = x.sd_id,*/
					/*			location_id = x.location_id,*/
								supplier_id = x.supplier_id,
								commissionflag = x.commissionflag,
								unitid = x.unitid,
								taxrate = x.taxrate,
								total = case when salemanagebilldrf.quantity = x.quantity then x.total
								else x.saleprice * salemanagebilldrf.quantity end,
								Y_ID = x.Y_ID,
								instoretime = x.instoretime,
								batchprice = x.batchprice,
								BatchBarCode = x.BatchBarCode,
								scomment = x.scomment,
								PriceType = x.PriceType,
								SendCostTotal = case when salemanagebilldrf.quantity = x.quantity then x.SendCostTotal
								else x.costprice * salemanagebilldrf.quantity end,
								RowE_id = x.RowE_id,
								YCostPrice = x.YCostPrice			
								FROM
								(select * from salemanagebill sm inner join (
									select bm.YGuid bYGuid,drf.YGuid sYGuid from
									(SELECT YGuid FROM salemanagebilldrf where bill_id = @nNewBillID) drf left join buymanagebill bm on drf.YGuid = bm.RowGuid
									) t on sm.RowGuid = t.bYGuid
								) X
								WHERE salemanagebilldrf.YGuid = x.sYGuid AND salemanagebilldrf.bill_id = @nNewBillID
								
								update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
															taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity ,
															costtaxtotal=costtaxprice*quantity
													where bill_id = @nNewBillID
								select @BillQty=SUM(quantity), @billtotal =SUM(taxtotal) from 
								( 
									select  SUM(quantity) as quantity,  SUM(taxtotal) as taxtotal from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID in (0,5)	
			     					union all
			     					select  SUM(quantity) as quantity,  0 as taxtotal             from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID not in (0,5)					
								) a
								update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID		    
							end
							ELSE
								GOTO ERROR

							SET @nRet = @nNewBillID
							EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
							EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
						  END
						  ELSE
							GOTO ERROR
	             end
	        end
	        /*-zjx--2016-12-16---tfs44035自营店发货退货单按仓库分单begin*/
	        IF EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'SelfSendBackBillStoragesSplit' AND sysvalue = '1') 
	        begin
			   if (@OldBillType = 531) and (@NewBillType IN(153))
			   begin
						/*创建上架单明细仓库临时表  zjx*/
						IF object_id(N'#SID531_2', N'U') is not null  
						DROP TABLE #SID531_2   
						select Distinct s_id into #SID531_2 from GSPbilldetail where Gspbill_id = @OldBillID
						/*上架确认单生成自营店发货退货单按仓库分单生成 zjx*/
						DECLARE @SID531_2 int
						DECLARE SID2_cursor CURSOR FOR SELECT s_id FROM #SID531_2
						OPEN SID2_cursor
						FETCH NEXT FROM SID2_cursor INTO @SID531_2
						WHILE @@FETCH_STATUS = 0
						BEGIN	 	
							EXEC TS_H_CreateBillSN @NewBillType, 1, NULL, 0, 0, @szBillNumber OUTPUT, @nOrderYid /*zjx-先获取单号*/
							INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
									taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
									invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
									VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
									B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
							SELECT  @dtBillDate, @szBillNumber, @NewBillType, 0, I.c_id, O.e_id, @SID531_2, @SID531_2, 0, I.inputman, 0, 0, 0,/*I.s_id--替换成--@SID531_2--zjx*/
									O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber + I.note, '',
									o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
									0, 0, I.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
									'', I.billdate, 0, I.WholeQty, I.PartQty, i.Yguid, i.BalanceMode
							FROM      dbo.GSPbillidx AS I INNER JOIN
									dbo.billidx AS O ON I.Ybillid = O.billid
							WHERE Gspbillid = @OldBillID
							
							SELECT @nNewBillID = @@IDENTITY

							IF @nNewBillID > 0
							BEGIN
								SELECT @nEid = E_ID FROM billidx WHERE billid = (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)

								INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
									taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
									commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
									invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
									instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
								SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
									taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
									commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, B.OrgBillid, aoid, 0,
									0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
									instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
								FROM      dbo.GSPbilldetail b			
								LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
								WHERE Gspbill_id = @OldBillID  
									  AND b.s_id = @SID531_2  /*zjx*/
							    
								if @@ROWCOUNT >0
								begin
								/*取原发货单更新为原单批次								*/
								   UPDATE salemanagebilldrf SET
									p_id = x.p_id,
									batchno = x.batchno,
									costprice = x.costprice,
									saleprice = x.saleprice,
									discount = x.discount,
									discountprice = x.discountprice,
									costtaxprice = x.costtaxprice,
									totalmoney =
									case when salemanagebilldrf.quantity = x.quantity then x.totalmoney
									else x.discountprice * salemanagebilldrf.quantity end,
									taxprice = x.taxprice,
									taxtotal = 
									case when salemanagebilldrf.quantity = x.quantity then x.taxtotal
									else x.taxprice * salemanagebilldrf.quantity end,
									taxmoney = case when salemanagebilldrf.quantity = x.quantity then x.taxmoney
									else x.taxprice * salemanagebilldrf.quantity - x.saleprice * salemanagebilldrf.quantity end,
									retailprice = x.retailprice, 
									retailtotal = case when salemanagebilldrf.quantity = x.quantity then x.retailtotal
									else x.retailprice * salemanagebilldrf.quantity end, 
									makedate = x.makedate, 
									validdate = x.validdate,
									price_id = x.price_id,
									supplier_id = x.supplier_id,
									commissionflag = x.commissionflag,
									unitid = x.unitid,
									taxrate = x.taxrate,
									total = case when salemanagebilldrf.quantity = x.quantity then x.total
									else x.saleprice * salemanagebilldrf.quantity end,
									Y_ID = x.Y_ID,
									instoretime = x.instoretime,
									batchprice = x.batchprice,
									BatchBarCode = x.BatchBarCode,
									scomment = x.scomment,
									PriceType = x.PriceType,
									SendCostTotal = case when salemanagebilldrf.quantity = x.quantity then x.SendCostTotal
									else x.costprice * salemanagebilldrf.quantity end,
									RowE_id = x.RowE_id,
									YCostPrice = x.YCostPrice			
									FROM
									(select * from salemanagebill sm inner join (
										select bm.YGuid bYGuid,drf.YGuid sYGuid from
										(SELECT YGuid FROM salemanagebilldrf where bill_id = @nNewBillID) drf left join buymanagebill bm on drf.YGuid = bm.RowGuid
										) t on sm.RowGuid = t.bYGuid
									) X
									WHERE salemanagebilldrf.YGuid = x.sYGuid AND salemanagebilldrf.bill_id = @nNewBillID
									
									update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
																taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity ,
																costtaxtotal=costtaxprice*quantity
														where bill_id = @nNewBillID
									select @BillQty=SUM(quantity), @billtotal =SUM(taxtotal) from 
									( 
										select  SUM(quantity) as quantity,  SUM(taxtotal) as taxtotal from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID in (0,5)	
			     						union all
			     						select  SUM(quantity) as quantity,  0 as taxtotal             from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID not in (0,5)					
									) a
									update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID		    
								end
								ELSE
									GOTO ERROR
                                /*删除拣货单明细仓库临时表  zjx*/
		                        IF object_id(N'#SID531_2', N'U') is not null  
                                DROP TABLE #SID531_2 
								SET @nRet = @nNewBillID
								EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
								EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
							END
							ELSE
								GOTO ERROR
							FETCH NEXT FROM SID2_cursor INTO @SID531_2
					   END
					   CLOSE SID2_cursor
					   DEALLOCATE SID2_cursor
			    end
	        end
	        /*-zjx--2016-12-16---tfs44035自营店发货退货单按仓库分单end*/
	        else
	        begin
	           if (@OldBillType = 531) and (@NewBillType IN(153))
		       begin
	              INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
				  taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
				  invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
				  VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
				  B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
					SELECT  @dtBillDate, @szBillNumber, @NewBillType, 0, I.c_id, O.e_id, I.s_id, I.s_id, 0, I.inputman, 0, 0, 0,
							O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber + I.note, '',
							o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
							0, 0, I.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
							'', I.billdate, 0, I.WholeQty, I.PartQty, i.Yguid, i.BalanceMode
					FROM      dbo.GSPbillidx AS I INNER JOIN
							dbo.billidx AS O ON I.Ybillid = O.billid
					WHERE Gspbillid = @OldBillID

					SELECT @nNewBillID = @@IDENTITY

					IF @nNewBillID > 0
					BEGIN
						SELECT @nEid = E_ID FROM billidx WHERE billid = (SELECT Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID)

						INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
							taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
							commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
							invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
							instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
						SELECT   @nNewBillID, b.p_id, batchno, eligibleqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
							taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * eligibleqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
							commisionflag, comment, unit_id, TaxRate, 0, total, 0, 0, eligibleqty, TaxPrice, B.OrgBillid, aoid, 0,
							0, '', 0, eligibleqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
							instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
						FROM      dbo.GSPbilldetail b			
						LEFT JOIN price c ON B.p_id = c.p_id AND b.Unit_id = c.u_id	
						WHERE Gspbill_id = @OldBillID
					    
						if @@ROWCOUNT >0
						begin
						/*取原发货单更新为原单批次								*/
						   UPDATE salemanagebilldrf SET
							p_id = x.p_id,
							batchno = x.batchno,
							costprice = x.costprice,
							saleprice = x.saleprice,
							discount = x.discount,
							discountprice = x.discountprice,
							costtaxprice = x.costtaxprice,
							totalmoney =
							case when salemanagebilldrf.quantity = x.quantity then x.totalmoney
							else x.discountprice * salemanagebilldrf.quantity end,
							taxprice = x.taxprice,
							taxtotal = 
							case when salemanagebilldrf.quantity = x.quantity then x.taxtotal
							else x.taxprice * salemanagebilldrf.quantity end,
							taxmoney = case when salemanagebilldrf.quantity = x.quantity then x.taxmoney
							else x.taxprice * salemanagebilldrf.quantity - x.saleprice * salemanagebilldrf.quantity end,
							retailprice = x.retailprice, 
							retailtotal = case when salemanagebilldrf.quantity = x.quantity then x.retailtotal
							else x.retailprice * salemanagebilldrf.quantity end, 
							makedate = x.makedate, 
							validdate = x.validdate,
							price_id = x.price_id,
				/*			ss_id = x.ss_id,*/
				/*			sd_id = x.sd_id,*/
				/*			location_id = x.location_id,*/
							supplier_id = x.supplier_id,
							commissionflag = x.commissionflag,
							unitid = x.unitid,
							taxrate = x.taxrate,
							total = case when salemanagebilldrf.quantity = x.quantity then x.total
							else x.saleprice * salemanagebilldrf.quantity end,
							Y_ID = x.Y_ID,
							instoretime = x.instoretime,
							batchprice = x.batchprice,
							BatchBarCode = x.BatchBarCode,
							scomment = x.scomment,
							PriceType = x.PriceType,
							SendCostTotal = case when salemanagebilldrf.quantity = x.quantity then x.SendCostTotal
							else x.costprice * salemanagebilldrf.quantity end,
							RowE_id = x.RowE_id,
							YCostPrice = x.YCostPrice			
							FROM
							(select * from salemanagebill sm inner join (
								select bm.YGuid bYGuid,drf.YGuid sYGuid from
								(SELECT YGuid FROM salemanagebilldrf where bill_id = @nNewBillID) drf left join buymanagebill bm on drf.YGuid = bm.RowGuid
								) t on sm.RowGuid = t.bYGuid
							) X
							WHERE salemanagebilldrf.YGuid = x.sYGuid AND salemanagebilldrf.bill_id = @nNewBillID
							
							update salemanagebilldrf set totalmoney = quantity*discountprice, total=saleprice*quantity, 
														taxtotal = taxprice*quantity, taxmoney = (taxprice - discountprice) *quantity ,
														costtaxtotal=costtaxprice*quantity
												where bill_id = @nNewBillID
							select @BillQty=SUM(quantity), @billtotal =SUM(taxtotal) from 
							( 
								select  SUM(quantity) as quantity,  SUM(taxtotal) as taxtotal from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID in (0,5)	
			     				union all
			     				select  SUM(quantity) as quantity,  0 as taxtotal             from salemanagebilldrf where bill_id  =@nNewBillID	 and AOID not in (0,5)					
							) a
							update billdraftidx set quantity = @BillQty, ysmoney = @billtotal, jsye = @billtotal where billid  = @nNewBillID		    
						end
						ELSE
							GOTO ERROR

						SET @nRet = @nNewBillID
						EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
						EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
					  END
					  ELSE
						GOTO ERROR
	         end
	        end
	end
	/*上架确认单生成自营店/机构发货退货单end*/
	
	IF @OldBillType = 551	/* 复核单生成 销售出库单、采购入库退货单、自营店/机构发货单*/
	BEGIN
		IF @bstates = 13	/* 全部复核之后才生成*/
		BEGIN
			SELECT @nOrderBillId = Ybillid FROM GSPbillidx WHERE Gspbillid = @OldBillID
			SELECT @nOrderGuid = guid FROM GSPbillidx WHERE Gspbillid = @OldBillID
			SELECT @nEid = inputman FROM GSPbillidx WHERE Gspbillid = @OldBillID

			/* 从billtrace表取拣货单和复核单数量*/
			IF EXISTS(SELECT * FROM VW_BILLTRACE WHERE traceGuid = (SELECT TOP 1 traceGuid FROM billTrace WHERE billType = @OldBillType AND billId = @OldBillID ORDER BY ID DESC)
				AND billtype IN (541, 551) AND BILLSTATES NOT IN (13, 15))
			BEGIN
				SET @nRet = 999999
				GOTO ERROR
			END

			/* 用临时表保存同一拨次的复核单*/
			SELECT billId INTO #TMPCHECK FROM billTrace WHERE billType = @OldBillType
				AND traceGuid = (SELECT TOP 1 traceGuid FROM billTrace WHERE billType = @OldBillType AND billId = @OldBillID ORDER BY ID DESC)

			/* 删除已存在草稿*/
			IF @NewBillType <> 21  /*BUG27632*/
			  DELETE FROM billdraftidx WHERE YGuid = (SELECT Yguid FROM GSPbillidx WHERE Gspbillid = @OldBillID) AND billstates = 2
			    	AND YGuid <> 0x0 and sin_id=(select s_id from   dbo.GSPbillidx 
				     WHERE Gspbillid = @OldBillID)

			IF @NewBillType IN (150, 152)	/* 自营店/机构发货单*/
			BEGIN
				/* 获取机构默认仓库*/
				DECLARE @iMDSid int
				DECLARE @Jgid int
				SET @iMDSid = 0
				SELECT @iMDSid = MIN(storage_id) FROM storages WHERE Y_ID = (SELECT C_id FROM GSPbillidx WHERE Gspbillid = @OldBillID)
					AND deleted = 0 AND child_number = 0 AND WholeFlag <> 3 AND qualityFlag = 0
				set @Jgid = (select distinct c_id from  GSPbillidx where Gspbillid = @OldBillID)
				/* 未取到机构货位*/
				IF @iMDSid <= 0
					GOTO ERROR

				INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
						VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
						B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
				SELECT  @dtBillDate, @szBillNumber, @NewBillType, 0, ISNULL(o.c_id, i.c_id), ISNULL(i.YE_ID,0), ISNULL(O.sout_id, s_id), ISNULL(O.SIN_ID, @iMDSid), 0, ISNULL(O.INPUTMAN, I.inputman), TaxTotal, 0, 0,
						0, 0, 2, 0, 0, 0,0, '1900-1-1', '1900-1-1', 0, 0, isnull(o.note,'')+'  '+ISNULL(i.Note,''), '',
						0, 0, '1900-1-1', NEWID(), TaxTotal, '', 0, 0, 0, isnull(o.GatheringMan,0),
						0, 0, ISNULL(O.Y_ID, I.Y_ID), 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
						'', GETDATE(), 0, WholeQty, PartQty, YGuid, i.BalanceMode
				FROM      dbo.GSPbillidx i
					LEFT JOIN orderidx o on i.Ybillid = o.billid
				WHERE Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
					INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
						invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
						instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT   @nNewBillID, b.p_id, batchno, checkqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
						taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * checkqty, makedate, validdate, '合格', 0, B.S_ID, ISNULL(LT.sd_id, @iMDSid), b.Location_id, supplier_id,
						commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, checkqty, TaxPrice, orgbillid, b.Aoid, 0,
						0, '', 0, checkqty, CostTotal, NEWID(), 0, 0, Yrowguid, b.Y_id, 0,
						instoretime, 0, ISNULL(LT.location_id2, 0), comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM      dbo.GSPbilldetail b
					LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id
					LEFT JOIN (SELECT smb_id, sd_id, location_id2 FROM OrderBill WHERE bill_id = @nOrderBillId) LT
					ON B.OrgBillid = LT.smb_id   /*AND B.Y_id = LT.Y_ID*/
					WHERE Gspbill_id IN (SELECT billId FROM #TMPCHECK)	/* 智能采购生成的拣货单无ybillid，通过yguid关联*/
					AND CheckQty > 0

					IF @@ROWCOUNT <= 0
						GOTO ERROR

					/* 更新表头金额、数量*/
					UPDATE billdraftidx SET ysmoney = X.TOTAL, jsye = X.TOTAL, quantity = X.QTY, SendQTY = X.QTY
					FROM
					(
					  select SUM(TOTAL) as total,SUM(QTY) as qty from 
					  (
					     SELECT SUM(taxtotal) AS TOTAL, SUM(quantity) AS QTY FROM salemanagebilldrf WHERE bill_id = @nNewBillID and AOID in (0,5)
					     union all
					     SELECT 0 AS TOTAL,             SUM(quantity) AS QTY FROM salemanagebilldrf WHERE bill_id = @nNewBillID and AOID not in (0,5)
					  ) r
					) X
					WHERE billdraftidx.billid = @nNewBillID

					SET @nRet = @nNewBillID
					/*UPDATE GSPbillidx SET BillStates = 15 WHERE Yguid = @nOrderGuid*/
					EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					/*-计算装箱件数*/
				    exec ts_Y_GspjhprintNo @nGuid
				    EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
				    
				    /*处理新生成草稿单据的电子监管码*/
					INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
					SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
						FROM RetailBillidx_Sfda 
					WHERE BillType = 551 AND Bill_Id = @OldBillID
				END
				ELSE
					GOTO ERROR
			END

			IF @NewBillType = 10	/*---生成销售出库单 草稿*/
			BEGIN
				/*存在同一订单生成多张复核单时 合并备注*/
			    DECLARE @nnote varchar(100)/*备注*/
		            DECLARE @Ybillid int       /*原单id*/
		            set @nnote=''
		            select @Ybillid=Ybillid from GSPbillidx where  Gspbillid = @OldBillID
		            select @nnote=@nnote+'  '+Note from GSPbillidx where  Ybillid = @Ybillid and billtype = @OldBillType
		        IF EXISTS (SELECT 1 FROM sysconfigtmp WHERE sysvalue = '1' and [sysname] = 'GzTzDataALL') /*-贵州天柱定制销售出库单与销售订单日期一致	*/
		        begin
		             INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
							taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
							invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
							VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
							B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
					SELECT  O.billdate, CASE @nUseOrderBillNum WHEN 1 THEN O.billnumber ELSE @szBillNumber END, @NewBillType, o.a_id, O.c_id, i.YE_ID, I.s_id, I.s_id, 0, O.inputman, 0, 0, 0,
							O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber +@nnote, '',
							o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
							0, 0, O.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, O.B_CustomName1, O.B_CustomName2,
							O.B_CustomName3, I.billdate, o.SendC_ID, I.WholeQty, I.PartQty, I.Yguid, i.BalanceMode
					FROM      dbo.gspbillidx AS I INNER JOIN
							dbo.orderidx AS O ON I.Ybillid = O.billid
					WHERE Gspbillid = @OldBillID
		        end
		        else
		        begin
					INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
							taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
							invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
							VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
							B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
					SELECT  @dtBillDate, CASE @nUseOrderBillNum WHEN 1 THEN O.billnumber ELSE @szBillNumber END, @NewBillType, o.a_id, O.c_id, O.e_id, I.s_id, I.s_id, 0, O.inputman, 0, 0, 0,
							O.taxrate, O.period, 2, O.billid, O.department_id, O.posid, O.region_id, '1900-1-1', O.skdate, O.jsye, O.jsflag, '订单编号：' + o.billnumber +@nnote, '',
							o.invoice, 0, '1900-1-1', NEWID(), O.InvoiceTotal, O.InvoiceNO, O.BusinessType, 0, 0, O.GatheringMan,
							0, 0, O.Y_ID, 0, '1900-1-1', '1900-1-1', 0, 0, O.B_CustomName1, O.B_CustomName2,
							O.B_CustomName3, I.billdate, o.SendC_ID, I.WholeQty, I.PartQty, I.Yguid, i.BalanceMode
					FROM      dbo.gspbillidx AS I INNER JOIN
							dbo.orderidx AS O ON I.Ybillid = O.billid
					WHERE Gspbillid = @OldBillID
                end
				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
					SELECT @nEid = isnull(E_ID,0) FROM orderidx WHERE billid = @nOrderBillId

					INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
						invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
						instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT   @nNewBillID, b.p_id, batchno, checkqty, CostPrice, price, discount, DiscountPrice, DiscountPrice * checkqty, taxprice, taxprice * checkqty,
						taxprice * checkqty - DiscountPrice * checkqty, ISNULL(c.retailprice, 0) , ISNULL(c.retailprice, 0) * checkqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
						commisionflag, comment, unit_id, TaxRate, orgbillid, price * checkqty, 0, 0, checkqty, taxPrice, orgbillid, b.Aoid, 0,
						0, '', 0, checkqty, CostPrice * checkqty, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
						instoretime, 0, 0, comment2, BatchBarCode, Batchcomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM      dbo.GSPbilldetail  b
					LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id
					WHERE Gspbill_id IN (SELECT billId FROM #TMPCHECK)
					AND CheckQty > 0

					IF @@ROWCOUNT <= 0
						GOTO ERROR
					
					/* 写入帐户信息*/
					INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
						invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
						instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid,factoryid,costtaxprice,costtaxrate,costtaxtotal)
					SELECT   @nNewBillID, b.p_id, batchno, 0, CostPrice, 0, discount, DiscountPrice, 0, taxprice, TaxTotal,
						taxmoney, 0, 0, makedate, validdate, '合格', 0, 0, 0, location_id, supplier_id,
						0, comment, 0, TaxRate, 0, total, 0, 0, 0, 0, 0, b.Aoid, 0,
						0, '', 0, 0, 0, NEWID(), 0, 0, NEWID(), y_id, 0,
						instoretime, 0, 0, comment2, BatchBarCode, scomment, batchprice, 0x0, '', 0,b.factoryid,costtaxprice,costtaxrate,costtaxtotal
					FROM      dbo.OrderBill b
					WHERE B.bill_id = @nOrderBillId AND B.p_id < 0

					/* 更新表头金额、数量*/
					UPDATE billdraftidx SET ysmoney = X.TOTAL, quantity = X.QTY, SendQTY = X.QTY, ssmoney = x.ssmoney, jsye = x.TOTAL - x.ssmoney
					FROM
					(
					  select SUM(TOTAL) as total,SUM(QTY) as qty,SUM(ssmoney) as ssmoney from 
					  (
					    SELECT SUM(taxtotal - (CASE p_id WHEN -59 THEN total ELSE 0 END)) AS TOTAL, SUM(quantity) AS QTY, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) AS ssmoney FROM salemanagebilldrf WHERE bill_id = @nNewBillID and AOID in (0,5)
					    union all
					    SELECT 0 AS TOTAL, SUM(quantity) AS QTY, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) AS ssmoney FROM salemanagebilldrf WHERE bill_id = @nNewBillID and AOID not in (0,5)
					  )a
					) X
					WHERE billdraftidx.billid = @nNewBillID
					
					/*更新复核人到单据备注中*/
					if @nYNDZ001 = 1
					begin						  
					   set @szCheckOutMan = '复核人:'													
						declare ReadCheckOutCur cursor for
							SELECT distinct AuditMan1 FROM GSPbillidx WHERE Ybillid = @nOrderBillId AND BillType = @OldBillType
						open ReadCheckOutCur				
						fetch next from ReadCheckOutCur into @nCheckOutMan
						while @@FETCH_STATUS=0	
						begin
						  select @szCheckOutMan = @szCheckOutMan+ name+ ' ' from employees where emp_id = @nCheckOutMan											
						  fetch next from ReadCheckOutCur into @nCheckOutMan
						end	
					  close ReadCheckOutCur
					  deallocate ReadCheckOutCur					
					  UPDATE billdraftidx SET note =  @szCheckOutMan+ note where billid = @nNewBillID					
					end
					
					EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					
					EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
					/*处理新生成草稿单据的电子监管码*/
					INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
					SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
						FROM RetailBillidx_Sfda 
					WHERE BillType = 551 AND Bill_Id IN (SELECT billId FROM #TMPCHECK)
					
					IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditOutStore' AND sysvalue = '1')
					BEGIN
						/*销售出库单草稿审核人和制单人取销售订单上的审核人和制单人*/
						UPDATE a SET a.inputman = b.inputman, a.auditman = b.auditman, a.auditdate = GETDATE() 
							FROM billdraftidx a, (SELECT @nNewBillID AS billid, o.inputman, o.auditman 
													FROM Gspbillidx g INNER JOIN Orderidx o ON g.ybillid = o.billid 
												  WHERE o.billtype = 14 AND g.Gspbillid = @OldBillID) b 
						WHERE a.billid = b.billid 
						
						SET @FResultId_BillAudit = -1
						SET @FVchCode_BillAudit = -1
						EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 10
						IF @FResultId_BillAudit > 0 
						BEGIN
							SET @nRet = @FResultId_BillAudit
							/*EXEC TS_H_BillTraceAct 0, @FResultId_BillAudit, @NewBillType, @OldBillID, @OldBillType, 0, 0*/
						END
						ELSE
							GOTO ERROR		
					END
					
					SET @nRet = @nNewBillID
                    UPDATE GSPbillidx SET BillStates = 15 WHERE Yguid = @nOrderGuid AND Yguid <> 0x0
					/*-计算装箱件数*/
				    exec ts_Y_GspjhprintNo @nGuid
				END
				ELSE
					GOTO ERROR
			END

			IF @NewBillType = 21 /*-生成 采购入库退货单 草稿*/
			BEGIN
				IF @nUseOrderBillNum = 1
					SELECT @szBillNumber = BillNumber FROM GSPbillidx WHERE Gspbillid = (select billid from billTrace where traceGuid = (select traceGuid from billTrace where billId = @OldBillID AND billType = @OldBillType) and billType = 561)

				INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
						taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
						invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
						VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
						B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, YGuid, BalanceMode)
				SELECT  TOP 1 @dtBillDate, @szBillNumber, @NewBillType, 0, ISNULL(O.c_id, I.C_id), ISNULL(i.YE_ID,0), I.s_id, I.s_id, 0, I.inputman, 0, 0, 0,
					    ISNULL(O.taxrate, 0), ISNULL(O.period, 0), 2, ISNULL(O.billid, 0), ISNULL(O.department_id, 0), ISNULL(O.posid, 0), ISNULL(O.region_id, 0), 
					    '1900-1-1', ISNULL(O.skdate, '1900-01-01'), ISNULL(O.jsye, I.[DiscountTotal]), ISNULL(O.jsflag, 0), CASE WHEN o.billnumber IS NULL THEN '' ELSE '订单编号：' + o.billnumber END + i.note, '',
						ISNULL(o.invoice, 0), 0, '1900-1-1', NEWID(), ISNULL(O.InvoiceTotal, 0), ISNULL(O.InvoiceNO, ''), ISNULL(O.BusinessType, 0), 0, 0, ISNULL(O.GatheringMan, 0),
						0, 0, ISNULL(O.Y_ID, I.Y_id), 0, '1900-1-1', '1900-1-1', 0, 0, '', '',
						'', I.billdate, 0, I.WholeQty, I.PartQty, i.Yguid, i.BalanceMode
				FROM      dbo.gspbillidx AS I LEFT JOIN
						dbo.billidx AS O ON I.Ybillid = O.billid
				WHERE I.Gspbillid = @OldBillID

				SELECT @nNewBillID = @@IDENTITY

				IF @nNewBillID > 0
				BEGIN
					SELECT @nEid = E_ID FROM billdraftidx WHERE billid = @nOrderBillId

					INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
						invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
						instoretime, /*cxType, location_id2, */
						comment2, BatchBarCode, scomment, batchprice,/* CxGuid, */
						Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal/*, OOSid*/
						)
					SELECT   @nNewBillID, b.p_id, batchno, checkqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
						taxmoney, ISNULL(c.retailprice, 0), ISNULL(c.retailprice, 0) * checkqty, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
						commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, checkqty, TaxPrice, orgbillid, b.Aoid, 0,
						0, '', 0, checkqty, CostTotal, NEWID(), @nEid, 0, Yrowguid, y_id, 0,
						instoretime, /*0, 0, */
						comment2, BatchBarCode, Batchcomment, batchprice,'',b.factoryid,costtaxprice,costtaxrate,costtaxtotal/*, 0x0, '', 0*/
					FROM      dbo.GSPbilldetail  b
					LEFT JOIN price c ON B.p_id = c.p_id AND b.unit_id = c.u_id
					WHERE Gspbill_id IN (SELECT billId FROM #TMPCHECK)
					AND CheckQty > 0

					IF @@ROWCOUNT <= 0
						GOTO ERROR

					/* 写入帐户信息*/
					INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
						taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
						commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
						invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
						instoretime, /*cxType, location_id2, */
						comment2, BatchBarCode, scomment, batchprice,/* CxGuid, */
						Conclusion,factoryid,costtaxprice,costtaxrate,costtaxtotal/*, OOSid*/
						)
					SELECT   @nNewBillID, b.p_id, batchno, checkqty, CostPrice, price, discount, DiscountPrice, discounttotal, taxprice, TaxTotal,
						taxmoney, 0, 0, makedate, validdate, '合格', 0, s_id, 0, location_id, supplier_id,
						commisionflag, comment, unit_id, TaxRate, orgbillid, total, 0, 0, checkqty, price, orgbillid, b.Aoid, 0,
						0, '', 0, checkqty, CostTotal, NEWID(), 0, 0, Yrowguid, y_id, 0,
						instoretime, /*0, 0, */
						comment2, BatchBarCode, Batchcomment, batchprice,'',b.factoryid,costtaxprice,costtaxrate,costtaxtotal/*, 0x0, '', 0*/
					FROM      dbo.GSPbilldetail  b
					WHERE Gspbill_id IN (SELECT billId FROM #TMPCHECK)
					AND P_id < 0

					/* 更新表头金额、数量 //aoid (0,5) 非赠品 （6,7）赠品*/
					UPDATE billdraftidx SET ysmoney = X.TOTAL, quantity = X.QTY, SendQTY = X.QTY, ssmoney = x.ssmoney, jsye = x.TOTAL - x.ssmoney
					FROM
					(
					  select SUM(TOTAL) as total,SUM(QTY) as qty,SUM(ssmoney) as ssmoney from 
					  (
					     SELECT SUM(taxtotal - (CASE p_id WHEN -59 THEN total ELSE 0 END)) AS TOTAL, SUM(quantity) AS QTY, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) AS ssmoney FROM buymanagebilldrf WHERE bill_id = @nNewBillID and AOID in (0,5)
					     union all
					     SELECT 0 AS TOTAL, SUM(quantity) AS QTY, SUM(CASE WHEN p_id < 0 AND p_id <> -59 THEN total ELSE 0 END) AS ssmoney FROM buymanagebilldrf WHERE bill_id = @nNewBillID and AOID not in (0,5)
					  ) a
					) X
					WHERE billdraftidx.billid = @nNewBillID

					IF EXISTS(SELECT * FROM buymanagebilldrf WHERE bill_id = @nNewBillID AND p_id < 0)
						UPDATE billdraftidx SET a_id = -100 WHERE billid = @nNewBillID

					EXEC TS_H_BillTraceAct 0, @nNewBillID, @NewBillType, @OldBillID, @OldBillType, 1, 0
					EXEC Ts_K_MarkAllENameOnBill;1 @nNewBillID
					/*处理新生成草稿单据的电子监管码*/
					INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, IsDraft, BatchNo, ValidDate, MakeDate, BillType)
					SELECT @nNewBillID, Product_Id, Sfda_Code, 1, BatchNo, ValidDate, MakeDate, @NewBillType
						FROM RetailBillidx_Sfda 
					WHERE BillType = 551 AND Bill_Id = @OldBillID
					
					IF EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'ExecBillAuditInStore' AND sysvalue = '1')
					BEGIN
						/*采购入库退货单草稿审核人和制单人取采购退出申请单上的审核人和制单人*/
						UPDATE a SET a.inputman = b.InputMan, a.auditman = b.AuditMan1, a.auditdate = GETDATE() 
							FROM billdraftidx a, (SELECT TOP 1 @nNewBillID AS billid, InputMan, AuditMan1 
													FROM GSPbillidx 
												  WHERE Gspbillid IN (SELECT billid FROM billtrace 
																	  WHERE billtype = 561 AND 
																			traceguid IN (SELECT traceguid FROM billtrace 
																						  WHERE billid = @OldBillID and 
																								billtype = 551))
												  ) b 
						WHERE a.billid = b.billid
						
						SET @FResultId_BillAudit = -1
						SET @FVchCode_BillAudit = -1
						EXEC ts_c_BillAudit @nNewBillID, @FResultId_BillAudit OUTPUT, @FVchCode_BillAudit OUTPUT, 21
						IF @FResultId_BillAudit > 0 
							SET @nRet = @FResultId_BillAudit
						ELSE
							GOTO ERROR		
					END
					
					SET @nRet = @nNewBillID
					UPDATE GSPbillidx SET BillStates = 15 WHERE guid = @nOrderGuid AND Yguid <> 0x0
					
					/*-计算装箱件数*/
				    exec ts_Y_GspjhprintNo @nGuid
				END
			END
			
			SELECT @YGuid = YGuid FROM GSPbillidx WHERE [GUID] = @nOrderGuid
			IF EXISTS(SELECT 1 FROM GSPbillidx 
			          WHERE YGUID = @YGuid AND BillType = @OldBillType AND Gspbillid <> @OldBillID)  
			BEGIN
				/*存在相同原单的复核单*/
				IF EXISTS(SELECT 1 FROM GSPbillidx 
							  WHERE YGuid = @YGuid AND BillType = @OldBillType AND 
									Gspbillid <> @OldBillID AND BillStates IN (10))/*, 12*/
				BEGIN
					/*还存在相同原单未审核的单据*/
					UPDATE GSPbillidx SET BillStates = 12 WHERE YGuid = @YGuid AND BillType = @OldBillType AND Gspbillid = @OldBillID	
				END
				else
				begin
				  UPDATE GSPbillidx SET BillStates = 15 WHERE YGuid = @YGuid  AND Yguid <> 0x0
				end		
			END
			ELSE
			BEGIN
				/*不存在相同原单的复核单时直接完成*/
				UPDATE GSPbillidx SET BillStates = 15 WHERE Gspbillid = @OldBillID AND BillType = @OldBillType AND Yguid <> 0x0
			END
		END
		ELSE
			GOTO ERROR
	END
	
	/*XXX.2017-05-15 begin店间调拨单生成收货退货单 */
	if (@OldBillType = 157) and (@NewBillType = 163)
	begin 
	    select @nGuid=guid,@bstates = BillStates  from billdraftidx WHERE billid = @OldBillID 
	    
		IF  @bstates IN (3)
		BEGIN
			declare @QualityAudit INT
			SELECT @QualityAudit = QualityAudit FROM billdraftidx WHERE billid= @OldBillID AND BillType = @OldBillType 
			
			DECLARE @BillSN VARCHAR(200) SET @BillSN = ''
			EXEC TS_H_CreateBillSN 163,1,NULL,0,0,@BillSN OUTPUT,0 
			/*PRINT @BillSN*/
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period, billstates,
				order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime, GUID, InvoiceTotal, 
				InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty, QualityAudit, QualityAuditDate, YGuid)
			SELECT CONVERT(VARCHAR(10),convert(datetime,GETDATE(),10)),
				@BillSN,163,0,2,e_id, sout_id, 0, auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period,3,
				0,0,0,0,0,0,ysmoney,0,'由店间调拨单生成,原单编号:' + billnumber,'',0,0,0,NewID(),0,
				'',0,0,quantity,0,0,0, Y_ID, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, Guid
           
			FROM billdraftidx
			WHERE billid= @OldBillID AND BillType = @OldBillType
   
			SET @nNewBillId = @@IDENTITY
   
			INSERT INTO buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
				price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
				iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
				SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, 
				scomment, batchprice, Conclusion, costtaxprice, factoryid, costtaxrate, costtaxtotal)
			SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, 
				price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id, total, 
				iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, invoice, invoiceno, PriceType, SendQTY, 
				SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, instoretime, comment2, BatchBarCode, 
				scomment, batchprice, Conclusion, costtaxprice, factoryid, costtaxrate, costtaxtotal
			FROM salemanagebilldrf
			WHERE bill_id = @OldBillID    

			/*自动过账*/
			EXEC ts_c_BillAudit @nNewBillId, @FResultId_BillAudit output, @FVchCode_BillAudit output, @NewBillType
			IF @FVchCode_BillAudit <> 0
			BEGIN
				UPDATE BillLog SET ErrFlag = @FVchCode_BillAudit, ErrCount = ErrCount + 1, p_id = @FResultId_BillAudit WHERE BillGuid = @nGuid
				DELETE FROM billdraftidx WHERE billid = @nNewBillId
			END
			ELSE
			BEGIN
				DECLARE @nNBILLID INT, @nYBILLID INT
			    SELECT @nYBILLID = billid FROM billdraftidx WHERE GUID  = @nGuid AND billtype = @OldBillType
			    SELECT @nNBILLID = billid FROM billidx      WHERE YGuid = @nGuid AND billtype = 163
			    EXEC TS_H_BillTraceAct 0, @nNBILLID, 163, @nYBILLID, @OldBillType, 0, 1 /*店间调拨单单据跟踪*/
			    
				UPDATE BillLog SET Status = 0, InDateTime = GetDate(), ErrFlag = 0 WHERE BillGuid = @nGuid
				UPDATE billdraftidx SET billstates = 0, transflag = 0 WHERE GUID = @nGuid
			    
			    SET @bstates = 0
				SET @nRet = @nNewBillID

			END     
		END 
		 
		IF @OldBillType IN (157) AND @bstates IN (0)
		BEGIN 
			UPDATE billdraftidx SET QualityAudit=@QualityAudit WHERE GUID = @nGuid
		END 	  
	
	END
	/*XXX.2017-05-15 begin店间调拨单生成收货退货单 END */

	IF @bNestedFlag = 0
	BEGIN
		COMMIT TRAN CREATEBILL
	END
	RETURN 0

ERROR:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	RETURN -1

	
/*yypeng-订单审核后不生成拣货单，这里做个日志检测*/
ERRORA:
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN CREATEBILL
	insert into LostGVTPICKLog( BillID,BillGuid, BillType, y_id, AuditTime, BillNumber, BillDate, ErrMsg)
    			select @OldBillID,GUID,billtype,Y_ID,GETDATE(),billnumber,billdate,'这张订单没有生成GSPBILLIDX的主表，插入有报错'  FROM orderidx  WHERE billid = @OldBillID 
	RETURN -1
END
GO
