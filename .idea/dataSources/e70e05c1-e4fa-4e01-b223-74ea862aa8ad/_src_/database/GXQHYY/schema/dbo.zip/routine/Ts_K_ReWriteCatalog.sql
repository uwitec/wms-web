
CREATE	       PROCEDURE Ts_K_ReWriteCatalog
(
	@OOSId      INT,  
	@BillType   INT,
	@Qty        numeric(25,8)	
)
/*with encryption*/
AS
	DECLARE @Bill VARCHAR(50)
	SET @Bill = ''
	IF @BillType = 20 
	    SET @Bill = '已生成过采购入库单草稿；'
	IF @BillType = 26
		SET @Bill = '已生成过采购计划；'  
	IF @BillType = 22
		SET @Bill = '已生成过采购合同；' 
	IF @BillType = 10
		SET @Bill = '已生成过销售出库单草稿；'  
	IF @BillType = 152
		SET @Bill = '已生成过自营店发货单草稿；'  
	IF @BillType = 150
		SET @Bill = '已生成过机构发货单草稿；'  	
				 	
	DECLARE @Remark VARCHAR(300)
	SELECT @Remark = ISNULL(o.Remark, '') FROM OOSCatalog o WHERE o.OOSId = @OOSId
	
	SET @Remark = REPLACE(@Remark, @Bill, '')
	SET @Remark = @Remark + @Bill
	
	IF @BillType IN (20, 22, 26)
		UPDATE OOSCatalog SET PlanQty = @Qty + PlanQty, Remark = @Remark WHERE OOSId = @OOSId
	IF @BillType IN (10, 150, 152)
		UPDATE OOSCatalog SET SaleQty = @Qty + SaleQty, Remark = @Remark WHERE OOSId = @OOSId
GO
