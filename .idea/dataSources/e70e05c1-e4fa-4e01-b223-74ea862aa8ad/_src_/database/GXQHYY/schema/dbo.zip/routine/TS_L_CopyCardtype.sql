

CREATE PROCEDURE TS_L_CopyCardtype
  @CT_ID        int,
  @typename     varchar(50)
/*with encryption*/
AS
declare @newid int

begin tran

Insert VIPCardType  (Code,          [Name],       ct_Type,            isBank,           isIntegral,
                 PriceMode,     Discount,     IntegralMoney,      isYeIntegral,     isSpecialPriceIntegral,
                 isPromotionIntegral,         isMoneyUp,          UpMoney,          MoneyUpCT_id,
                 isIntegralUp,                UpIntegral,         IntegeralUpCT_id, UpDecIntegral,
                 Comment,       Deleted,      SaveDate,           IsPDiscount,      IsPIntegRal,
                 IsAutoDisCount, isDiscount , isCxIntegral,       ValidDate)
select           '',          @typename,      ct_Type,            isBank,           isIntegral,
                 PriceMode,     Discount,     IntegralMoney,      isYeIntegral,     isSpecialPriceIntegral,
                 isPromotionIntegral,         isMoneyUp,          UpMoney,          MoneyUpCT_id,
                 isIntegralUp,                UpIntegral,         IntegeralUpCT_id, UpDecIntegral,
                 Comment,       Deleted,      SaveDate,           IsPDiscount,      IsPIntegRal,
                 IsAutoDisCount, isDiscount,  isCxIntegral,       ValidDate
from  VIPCardType   where ct_id=@CT_ID
  
select @newid=@@IDENTITY

Insert CTDiscountOther(ct_id,p_id,Discount,Comment)
select @newid,p_id,Discount,Comment from CTDiscountOther  where ct_id=@CT_ID

Insert CTExchangeIntegral(ct_id,p_id,ExchangeIntegral,Comment)
select @newid,p_id,ExchangeIntegral,Comment from dbo.CTExchangeIntegral  where ct_id=@CT_ID

Insert dbo.CTIntegralOther(ct_id,p_id,IntegralMoney,Comment)
select @newid,p_id,IntegralMoney,Comment from dbo.CTIntegralOther  where ct_id=@CT_ID

if @@Error=0
    COMMIT TRAN
else
    ROLLBACK TRAN
GO
