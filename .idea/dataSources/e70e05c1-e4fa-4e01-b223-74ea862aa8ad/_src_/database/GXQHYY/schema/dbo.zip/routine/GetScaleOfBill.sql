
CREATE  FUNCTION GetScaleOfBill(
	@Type			INT,			 /*0数量；1金额*/
	@SmbId          INT,
	@YId			INT,
	@PId            INT,
	@SupplierId     INT    
)  
RETURNS numeric(25,8) 
AS  
BEGIN 
	/*计算销售数量或金额完成比例，在付款计划列表里使用*/
	DECLARE @Result numeric(25,8)
	
	/*储存购进数据的结构*/
	DECLARE @BuyTable TABLE (PId INT, Qty numeric(25,8), Total numeric(25,8))
	/*储存销售数据的结构*/
	DECLARE @SaleTable TABLE (PId INT, Qty numeric(25,8), Total numeric(25,8))
	
	INSERT INTO @BuyTable(PId, Qty, Total)
	SELECT d.p_id, ISNULL(e.Qty, 0) AS Qty, ISNULL(e.Total, 0) AS Total
	FROM   (
	           SELECT DISTINCT s.p_id FROM buymanagebill s WHERE s.smb_id = @SmbId AND s.p_id = @PId AND s.supplier_id = @SupplierId
	       ) d
	       LEFT JOIN (
	                SELECT c.p_id,
	                       SUM(CASE WHEN b.billtype IN (21) THEN -c.quantity ELSE c.quantity END) AS Qty,
	                       SUM(CASE WHEN b.billtype IN (21) THEN -c.taxtotal ELSE c.taxtotal END) AS Total
	                FROM   billidx b INNER JOIN buymanagebill c ON b.billid = c.bill_id
	                WHERE  b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (20, 21) AND c.supplier_id = @SupplierId
	                GROUP BY c.p_id
	            ) e
	            ON  d.p_id = e.p_id
	
	INSERT INTO @SaleTable(PId, Qty, Total)
	SELECT d.p_id, ISNULL(e.Qty, 0) AS Qty, ISNULL(e.Total, 0) AS Total
	FROM   (
	           SELECT DISTINCT s.p_id FROM buymanagebill s WHERE s.smb_id = @SmbId AND s.p_id = @PId AND s.supplier_id = @SupplierId
	       ) d
	       LEFT JOIN (
	                SELECT c.p_id,
	                       SUM(CASE WHEN b.billtype IN (11) THEN -c.quantity ELSE c.quantity END) AS Qty,
	                       SUM(CASE WHEN b.billtype IN (11) THEN -c.taxtotal ELSE c.taxtotal END) AS Total
	                FROM   billidx b INNER JOIN salemanagebill c ON b.billid = c.bill_id
	                WHERE  b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (10, 11) AND c.supplier_id = @SupplierId
	                GROUP BY c.p_id
	            ) e
	            ON  d.p_id = e.p_id
	
	IF @Type = 0
	BEGIN
		/*计算数量类型*/
		SELECT @Result = ((Case a.Total when 0 then 0 else  b.Total / a.Total end) / 100) FROM @BuyTable a INNER JOIN @SaleTable b ON a.PId = b.PId
	END
	ELSE
	BEGIN
		/*计算金额类型*/
		SELECT @Result = ((Case a.Total when 0 then 0 else  b.Total / a.Total end ) / 100) FROM @BuyTable a INNER JOIN @SaleTable b ON a.PId = b.PId
	END
	
	IF @Result IS NULL
		SET @Result = 0.00
	
	RETURN @Result
END
GO
