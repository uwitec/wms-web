

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*************************************************

供货商进销存查询
查询某段时间给某一经销商的代销商品的进出存情况

*************************************************/
CREATE PROCEDURE TS_C_QrJxcDxByClient
(	@BeginDate        DATETIME=0,
	@EndDate	  DATETIME=0,
	@nSupplier_ID     INT=0,
        @nStorage_ID      INT=0,	
	@nCommissionFlag  INT=1,/*代销类型 =1 委托代销 ＝2 受托代销*/
        @nYClassID        varchar(50)='',
        @nloginEID        int=0,
        @isaddDate        int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nSupplier_ID is null  SET @nSupplier_ID = 0
if @nStorage_ID is null  SET @nStorage_ID = 0
if @nCommissionFlag is null  SET @nCommissionFlag = 1
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
SET NOCOUNT ON
DECLARE
  @szSClassID VARCHAR(30)
Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
Declare @isfinally int

  IF @nStorage_ID IN (0, 1)
    SELECT @szSClassID='%%'
  ELSE
    SELECT @szSClassID=ISNULL([Class_ID], '000000') FROM Storages WHERE [Storage_ID]=@nStorage_ID
  
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
   end
/*---仓库授权*/


/*委托代销*/
IF @nCommissionFlag=1
BEGIN
  IF @isaddDate=1
  BEGIN/*从YProductDetail中统计*/
    SELECT
    A.[Product_ID], A.[Class_ID], A.[Child_number], A.[Name],      A.[Code],
    A.[Alias],      A.[Standard], A.[Modal],        A.[Makearea],  A.[Medtype] AS [MedName],
    A.[Rate2],      A.[Rate3],    A.[Rate4],        A.[Unitname1], a.Inputman, a.InputDate,
    a.Custompro1,  a.Custompro2,  a.Custompro3,     a.Custompro4,  a.Custompro5,
 	  B.[Wtquantity],
    B.[Wttotal],
    B.[Wtbackquantity],
    B.[Wtbacktotal],
    B.[Wtjsquantity],
    B.[Wtjstotal],
 	  ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0) AS [SqcQuantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0) AS [Sqccosttotal],
  	ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0)+ISNULL(B.[Wtquantity],0)+ISNULL(B.[Wtbackquantity],0)+ISNULL(B.[Wtjsquantity],0) AS [BqcQuantity],
   	ISNULL(D.[PreCostTotal],0)+ISNULL(C.[Inicosttotal],0)+ISNULL(B.[WtTotal]   ,0)+ISNULL(B.[WtbackTotal]   ,0)+ISNULL(B.[Wtjstotal]   ,0) AS [BqcTotal]
  FROM VW_C_Products A
  INNER JOIN
  (SELECT PD.P_ID,
    SUM(CASE WHEN PD.[Billtype] =110 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [Wtquantity],
  	SUM(CASE WHEN PD.[Billtype] =110 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [Wttotal],
    SUM(CASE WHEN PD.[Billtype] =111 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [Wtbackquantity],
  	SUM(CASE WHEN PD.[Billtype] =111 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [Wtbacktotal],
    SUM(CASE WHEN PD.[Billtype] =112 AND PD.[Storetype]=1 THEN PD.[Quantity]  ELSE 0 END) AS [Wtjsquantity],
  	SUM(CASE WHEN PD.[Billtype] =112 AND PD.[Storetype]=1 THEN PD.[Costtotal] ELSE 0 END) AS [Wtjstotal]
	FROM dbo.vw_L_YProductdetail PD
	WHERE (PD.[Billdate] BETWEEN @BeginDate AND @EndDate) 
  AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
  AND PD.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
  AND PD.AOID in(0,5,7) AND PD.billtype not in (150,151,155,160,161,165)
  AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
  AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
  AND (@CompanyTable=0 or ((PD.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and PD.Yclass_id like u.psc_id+'%'))))
  AND (@ClientTable=0 or ((PD.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and PD.cclass_id like u.psc_id+'%'))))
  AND (@nYClassid='' or PD.YClass_id like @nYClassid+'%')  
 
  GROUP BY PD.[P_ID]
  ) AS B
 	ON A.[Product_ID]=B.[P_ID]
 	LEFT JOIN 
  (SELECT ST.[P_ID],
     ISNULL(SUM(ST.[Quantity]), 0) AS [Iniquantity],
     ISNULL(SUM(ST.[Costtotal]),0) AS [Inicosttotal]
   FROM vw_c_storedxini ST
   WHERE  ST.[Supplier_ID]=@nSupplier_ID
   AND ST.[Commissionflag]=@nCommissionFlag
   AND (@ClientTable=0 or ((st.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and st.cclass_id like u.psc_id+'%'))))
   AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
   AND (@nYClassid='' or ST.YClass_id like @nYClassid+'%') 


   GROUP BY ST.[P_ID]
  	) AS C
   ON B.[P_ID]=C.[P_ID]
 	 LEFT JOIN
   (SELECT PD.[P_ID], 
      SUM(PD.[Quantity])  AS [Prequantity],
      SUM(PD.[Costtotal]) AS [Precosttotal]
  	FROM dbo.vw_L_YProductdetail PD
 		WHERE PD.[Billdate]<@BeginDate
    AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
    AND PD.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
    AND PD.AOID in(0,5,7) AND PD.billtype not in (150,151,155,160,161,165)
    AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
    AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
    AND (@CompanyTable=0 or ((PD.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and PD.Yclass_id like u.psc_id+'%'))))
    AND (@ClientTable=0 or ((PD.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and PD.cclass_id like u.psc_id+'%'))))
    AND (@nYClassid='' or PD.YClass_id like @nYClassid+'%')  
 
 		GROUP BY PD.[P_ID]
  	) AS D
  	ON D.[P_ID]=B.[P_ID]
 	WHERE A.[Product_ID]<>1 AND A.[Deleted]<>1
  END
  ELSE/*从单据中进行查找*/
  BEGIN
  SELECT
    A.[Product_ID], A.[Class_ID], A.[Child_number], A.[Name],      A.[Code],
    A.[Alias],      A.[Standard], A.[Modal],        A.[Makearea],  A.[Medtype] AS [MedName],
    A.[Rate2],      A.[Rate3],    A.[Rate4],        A.[Unitname1], a.Inputman, a.InputDate,
    a.Custompro1,  a.Custompro2,  a.Custompro3,     a.Custompro4,  a.Custompro5,
 	  B.[Wtquantity],
    B.[Wttotal],
    B.[Wtbackquantity],
    B.[Wtbacktotal],
    B.[Wtjsquantity],
    B.[Wtjstotal],
 	  ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0) AS [SqcQuantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0) AS [Sqccosttotal],
  	ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0)+ISNULL(B.[Wtquantity],0)+ISNULL(B.[Wtbackquantity],0)+ISNULL(B.[Wtjsquantity],0) AS [BqcQuantity],
   	ISNULL(D.[PreCostTotal],0)+ISNULL(C.[Inicosttotal],0)+ISNULL(B.[WtTotal]   ,0)+ISNULL(B.[WtbackTotal]   ,0)+ISNULL(B.[Wtjstotal]   ,0) AS [BqcTotal]
  FROM VW_C_Products A
  INNER JOIN
  (SELECT PD.P_ID,
    SUM(CASE WHEN B.[Billtype] =110 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [Wtquantity],
  	SUM(CASE WHEN B.[Billtype] =110 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [Wttotal],
    SUM(CASE WHEN B.[Billtype] =111 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [Wtbackquantity],
  	SUM(CASE WHEN B.[Billtype] =111 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [Wtbacktotal],
    SUM(CASE WHEN B.[Billtype] =112 AND PD.[Storetype]=1 THEN PD.[Quantity]  ELSE 0 END) AS [Wtjsquantity],
  	SUM(CASE WHEN B.[Billtype] =112 AND PD.[Storetype]=1 THEN PD.[Costtotal] ELSE 0 END) AS [Wtjstotal]
	FROM VW_C_PDetail PD, VW_C_BillIDX B
	WHERE B.[BillID]=PD.[BillID] AND (B.[Billdate] BETWEEN @BeginDate AND @EndDate) 
  AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
  AND B.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
  AND B.billtype not in (150,151,155,160,161,165)
  AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E'and PD.Reclass_id like u.psc_id+'%'))))
  AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id  like u.psc_id+'%'))))
  AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id   like u.psc_id+'%'))))
 
 
  GROUP BY PD.[P_ID]
  ) AS B
 	ON A.[Product_ID]=B.[P_ID]
 	LEFT JOIN 
  (SELECT ST.[P_ID],
     ISNULL(SUM(ST.[Quantity]), 0) AS [Iniquantity],
     ISNULL(SUM(ST.[Costtotal]),0) AS [Inicosttotal]
   FROM vw_c_storedxini ST
   WHERE  ST.[Supplier_ID]=@nSupplier_ID
   AND ST.[Commissionflag]=@nCommissionFlag
   AND (@ClientTable=0 or ((st.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and st.cclass_id like u.psc_id+'%'))))
   AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
   AND (@nYClassid='' or ST.YClass_id like @nYClassid+'%') 


   GROUP BY ST.[P_ID]
  	) AS C
   ON B.[P_ID]=C.[P_ID]
 	 LEFT JOIN
   (SELECT PD.[P_ID], 
      SUM(PD.[Quantity])  AS [Prequantity],
      SUM(PD.[Costtotal]) AS [Precosttotal]
  	FROM VW_C_PDetail PD, VW_C_BillIDX B
 		WHERE B.[BillID]=PD.[BillID] AND B.[Billdate]<@BeginDate
    AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
    AND B.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
    AND B.billtype not in (150,151,155,160,161,165)
    AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id  like u.psc_id+'%'))))
    AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
    AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%'))))
 
 		GROUP BY PD.[P_ID]
  	) AS D
  	ON D.[P_ID]=B.[P_ID]
 	WHERE A.[Product_ID]<>1 AND A.[Deleted]<>1
  END
  GOTO SUCCEE
END

IF @nCommissionFlag=2
BEGIN
  IF @isaddDate=1
  BEGIN
    SELECT
    A.[Product_ID], A.[Class_ID], A.[Child_number], A.[Name],      A.[Code],
    A.[Alias],      A.[Standard], A.[Modal],        A.[Makearea],  A.[Medtype] AS [MedName],
    A.[Rate2],      A.[Rate3],    A.[Rate4],        A.[Unitname1],  a.Inputman, a.InputDate,
    a.Custompro1,   a.Custompro2, a.Custompro3,     a.Custompro4,   a.Custompro5,
    B.[Stquantity],
    B.[Sttotal],
    -B.[Stbackquantity] AS [Stbackquantity],
    -B.[Stbacktotal]    AS [Stbacktotal],
    -B.[Stjsquantity]   AS [Stjsquantity],
    -B.[Stjstotal]      AS [Stjstotal],
    -B.[Salequantity]   AS [Salequantity],
    -B.[Saletotal]      AS [Saletotal],
    B.[Salebackquantity],
    B.[Salebacktotal],
    ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0) AS [Sqcquantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0) AS [Sqccosttotal],
    ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0)+ISNULL(B.[Stquantity],0)+ISNULL(B.[Stbackquantity],0)+ISNULL([Stjsquantity],0) AS [Bqcquantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0)+ISNULL(B.[Sttotal]   ,0)+ISNULL(B.[Stbacktotal]   ,0)+ISNULL([Stjstotal]   ,0) AS [Bqctotal],
    ISNULL(E.[Quantity]  ,0) AS [Quantity],
    ISNULL(E.[Costtotal] ,0) AS [Costtotal]
  FROM VW_C_Products A
  INNER JOIN
  (SELECT B.p_id,SUM(B.stquantity) AS stquantity,SUM(B.sttotal) AS sttotal,
       SUM(B.stbackquantity) AS stbackquantity,SUM(B.stbacktotal) AS stbacktotal,
       SUM(B.stjsquantity) AS stjsquantity,SUM(B.stjstotal) AS stjstotal,
       SUM(B.Salequantity) AS Salequantity,SUM(B.Saletotal) AS Saletotal,
       SUM(B.Salebackquantity) AS Salebackquantity,SUM(B.Salebacktotal) AS Salebacktotal
   FROM
  (SELECT PD.P_ID,
    CASE WHEN PD.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [stquantity],
    CASE WHEN PD.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [sttotal],
    CASE WHEN PD.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [stbackquantity],
    CASE WHEN PD.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [stbacktotal],
    CASE WHEN PD.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Quantity]  ELSE 0 END  AS [stjsquantity],
    CASE WHEN PD.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Costtotal] ELSE 0 END  AS [stjstotal],
    CASE WHEN PD.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [Salequantity],
    CASE WHEN PD.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [Saletotal],
    CASE WHEN PD.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Quantity]  ELSE 0 END  AS [Salebackquantity],
    CASE WHEN PD.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Costtotal] ELSE 0 END  AS [Salebacktotal]
   FROM  vw_L_YProductdetail PD
   WHERE (PD.[Billdate] BETWEEN @BeginDate AND @EndDate) 
          AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
	  AND PD.[Billstates]='0'AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
	  AND PD.AOID in(0,5,7)  AND PD.billtype not in (150,151,155,160,161,165)
	  AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
	  AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
	  AND (@CompanyTable=0 or ((PD.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and PD.Yclass_id like u.psc_id+'%'))))
	  AND (@ClientTable=0 or ((PD.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and PD.cclass_id like u.psc_id+'%'))))
	  AND (@nYClassid='' or PD.YClass_id like @nYClassid+'%')  

   Union All
   SELECT PD.P_ID,
    CASE WHEN B.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [stquantity],
    CASE WHEN B.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [sttotal],
    CASE WHEN B.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [stbackquantity],
    CASE WHEN B.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [stbacktotal],
    CASE WHEN B.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Quantity]  ELSE 0 END  AS [stjsquantity],
    CASE WHEN B.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Costtotal] ELSE 0 END  AS [stjstotal],
    CASE WHEN B.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END  AS [Salequantity],
    CASE WHEN B.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END  AS [Saletotal],
    CASE WHEN B.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Quantity]  ELSE 0 END  AS [Salebackquantity],
    CASE WHEN B.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Costtotal] ELSE 0 END  AS [Salebacktotal]
   FROM VW_C_PDetail PD, VW_C_BillIDX B
   WHERE B.[BillID]=PD.[BillID] AND (B.[Billdate] BETWEEN @BeginDate AND @EndDate) 
	AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
	AND B.[Billstates]='0'AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
	AND B.billtype not in (150,151,155,160,161,165)
	AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
	AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
	AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((b.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and b.Yclass_id like u.psc_id+'%'))))
        AND (@nYClassid='' or b.YClass_id like @nYClassid+'%')  
   )B
   GROUP BY B.p_id
  ) AS B ON A.[Product_ID]=B.[P_ID]
  LEFT JOIN 
  (SELECT ST.[P_ID],
        ISNULL(SUM(ST.[Quantity]), 0) AS [Iniquantity],
        ISNULL(SUM(ST.[Costtotal]),0) AS [Inicosttotal]
   FROM vw_c_storedxini ST, VW_C_Products P
   WHERE ST.P_ID=P.[Product_ID] AND P.[Deleted]<>1 AND ST.[Supplier_ID]=@nSupplier_ID
   AND ST.[Commissionflag]=@nCommissionFlag
   AND (@ClientTable=0 or ((st.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and st.cclass_id like u.psc_id+'%'))))
   AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
   AND (@nYClassid='' or ST.YClass_id like @nYClassid+'%') 

   GROUP BY ST.[P_ID]) AS C ON B.[P_ID]=C.[P_ID]
  LEFT JOIN
  (SELECT D.P_ID, SUM(D.[Prequantity])  AS [Prequantity],SUM(D.[Precosttotal]) AS [Precosttotal]
   FROM (SELECT PD.[P_ID], 
                SUM(PD.[Quantity])  AS [Prequantity],
                SUM(PD.[Costtotal]) AS [Precosttotal]
         FROM vw_L_YProductdetail PD
         WHERE  PD.[Billdate]<@BeginDate
	         AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
	         AND PD.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
	         AND PD.AOID in(0,5,7)  AND PD.billtype not in (150,151,155,160,161,165)
	         AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
	         AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
	         AND (@CompanyTable=0 or ((PD.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and PD.Yclass_id like u.psc_id+'%'))))
	         AND (@ClientTable=0 or ((PD.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and PD.cclass_id like u.psc_id+'%'))))
	         AND (@nYClassid='' or PD.YClass_id like @nYClassid+'%') 
         GROUP BY PD.[P_ID]

         UNION ALL
         SELECT PD.[P_ID], 
                SUM(PD.[Quantity])  AS [Prequantity],
                SUM(PD.[Costtotal]) AS [Precosttotal]
         FROM VW_C_PDetail PD, VW_C_BillIDX B
         WHERE B.[BillID]=PD.[BillID] AND B.[Billdate]<@BeginDate
		    AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
		    AND B.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
		    AND B.billtype not in (150,151,155,160,161,165)
		    AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
		    AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
		    AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%'))))
         GROUP BY PD.[P_ID]
    ) D  GROUP BY D.P_ID
  ) AS D ON D.[P_ID]=B.[P_ID]
  LEFT JOIN 
  	(SELECT ST.[P_ID],
               ISNULL(SUM(ST.[Quantity]) ,0) AS [Quantity],
               ISNULL(SUM(ST.[Costtotal]),0) AS [Costtotal]
  	 FROM VW_C_Storehouse ST, VW_C_Products P
         WHERE ST.P_ID=P.[Product_ID] AND P.[Deleted]<>1 AND ST.[Supplier_ID]=@nSupplier_ID
         AND ST.[Commissionflag]=@nCommissionFlag AND LEFT(ST.[SClassID], LEN(@szSClassID)) LIKE @szSClassID
         AND (@Storetable=0 OR ((st.sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and st.sclassid like u.psc_id+'%'))))
         AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
         AND (@nYClassid='' or St.YClass_id like @nYClassid+'%') 

 	 GROUP BY ST.[P_ID]
  	) AS E  ON B.[P_ID]=E.[P_ID]
  WHERE A.[Product_ID]<>1 AND A.[Deleted]<>1
  END
  ELSE
  BEGIN
    SELECT
    A.[Product_ID], A.[Class_ID], A.[Child_number], A.[Name],      A.[Code],
    A.[Alias],      A.[Standard], A.[Modal],        A.[Makearea],  A.[Medtype] AS [MedName],
    A.[Rate2],      A.[Rate3],    A.[Rate4],        A.[Unitname1],  a.Inputman, a.InputDate,
    a.Custompro1,   a.Custompro2, a.Custompro3,     a.Custompro4,   a.Custompro5,
    B.[Stquantity],
    B.[Sttotal],
    -B.[Stbackquantity] AS [Stbackquantity],
    -B.[Stbacktotal]    AS [Stbacktotal],
    -B.[Stjsquantity]   AS [Stjsquantity],
    -B.[Stjstotal]      AS [Stjstotal],
    -B.[Salequantity]   AS [Salequantity],
    -B.[Saletotal]      AS [Saletotal],
    B.[Salebackquantity],
    B.[Salebacktotal],
    ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0) AS [Sqcquantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0) AS [Sqccosttotal],
    ISNULL(D.[Prequantity] ,0)+ISNULL(C.[Iniquantity] ,0)+ISNULL(B.[Stquantity],0)+ISNULL(B.[Stbackquantity],0)+ISNULL([Stjsquantity],0) AS [Bqcquantity],
    ISNULL(D.[Precosttotal],0)+ISNULL(C.[Inicosttotal],0)+ISNULL(B.[Sttotal]   ,0)+ISNULL(B.[Stbacktotal]   ,0)+ISNULL([Stjstotal]   ,0) AS [Bqctotal],
    ISNULL(E.[Quantity]  ,0) AS [Quantity],
    ISNULL(E.[Costtotal] ,0) AS [Costtotal]
  FROM VW_C_Products A
  INNER JOIN
  (SELECT PD.P_ID,
    SUM(CASE WHEN B.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [stquantity],
    SUM(CASE WHEN B.[Billtype] =120 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [sttotal],
    SUM(CASE WHEN B.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [stbackquantity],
    SUM(CASE WHEN B.[Billtype] =121 AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [stbacktotal],
    SUM(CASE WHEN B.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Quantity]  ELSE 0 END) AS [stjsquantity],
    SUM(CASE WHEN B.[Billtype] =122 AND PD.[Storetype]=1 THEN PD.[Costtotal] ELSE 0 END) AS [stjstotal],
    SUM(CASE WHEN B.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Quantity]  ELSE 0 END) AS [Salequantity],
    SUM(CASE WHEN B.[Billtype] IN (10,12,112,53,212) AND PD.[Storetype]=0 THEN PD.[Costtotal] ELSE 0 END) AS [Saletotal],
    SUM(CASE WHEN B.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Quantity]  ELSE 0 END) AS [Salebackquantity],
    SUM(CASE WHEN B.[Billtype] IN (11,13,54) AND PD.[Storetype]=0 		THEN PD.[Costtotal] ELSE 0 END) AS [Salebacktotal]
   FROM VW_C_PDetail PD, VW_C_BillIDX B
   WHERE B.[BillID]=PD.[BillID] AND (B.[Billdate] BETWEEN @BeginDate AND @EndDate) 
    AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
    AND B.[Billstates]='0'AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
    AND B.billtype not in (150,151,155,160,161,165)
    AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
    AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
    AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%'))))
    AND (@CompanyTable=0 or ((b.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and b.Yclass_id like u.psc_id+'%'))))
    AND (@nYClassid='' or b.YClass_id like @nYClassid+'%')  
  GROUP BY PD.[P_ID]
  ) AS B
 	ON A.[Product_ID]=B.[P_ID]
 	LEFT JOIN 
  (SELECT ST.[P_ID],
     ISNULL(SUM(ST.[Quantity]), 0) AS [Iniquantity],
     ISNULL(SUM(ST.[Costtotal]),0) AS [Inicosttotal]
   FROM vw_c_storedxini ST, VW_C_Products P
   WHERE ST.P_ID=P.[Product_ID] AND P.[Deleted]<>1 AND ST.[Supplier_ID]=@nSupplier_ID
   AND ST.[Commissionflag]=@nCommissionFlag
   AND (@ClientTable=0 or ((st.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and st.cclass_id like u.psc_id+'%'))))
   AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
   AND (@nYClassid='' or ST.YClass_id like @nYClassid+'%') 

   GROUP BY ST.[P_ID]
  	) AS C
   ON B.[P_ID]=C.[P_ID]
 	 LEFT JOIN
   (SELECT PD.[P_ID], 
      SUM(PD.[Quantity])  AS [Prequantity],
      SUM(PD.[Costtotal]) AS [Precosttotal]
  	FROM VW_C_PDetail PD, VW_C_BillIDX B
 		WHERE B.[BillID]=PD.[BillID] AND B.[Billdate]<@BeginDate
    AND PD.[Supplier_ID]=@nSupplier_ID AND PD.[Commissionflag]=@nCommissionFlag
    AND B.[Billstates]='0' AND LEFT(PD.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID
    AND B.billtype not in (150,151,155,160,161,165)
    AND (@employeestable=0 OR ((PD.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and PD.Reclass_id like u.psc_id+'%'))))
    AND (@Storetable=0 OR ((PD.sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and PD.sclass_id like u.psc_id+'%'))))
    AND (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%'))))
 		GROUP BY PD.[P_ID]
  	) AS D
  	ON D.[P_ID]=B.[P_ID]
  	LEFT JOIN 
  	(SELECT ST.[P_ID],
      ISNULL(SUM(ST.[Quantity]) ,0) AS [Quantity],
      ISNULL(SUM(ST.[Costtotal]),0) AS [Costtotal]
  	FROM VW_C_Storehouse ST, VW_C_Products P
   WHERE ST.P_ID=P.[Product_ID] AND P.[Deleted]<>1 AND ST.[Supplier_ID]=@nSupplier_ID
   AND ST.[Commissionflag]=@nCommissionFlag AND LEFT(ST.[SClassID], LEN(@szSClassID)) LIKE @szSClassID
   AND (@Storetable=0 OR ((st.sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and st.sclassid like u.psc_id+'%'))))
   AND (@CompanyTable=0 or ((st.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and st.Yclass_id like u.psc_id+'%'))))
   AND (@nYClassid='' or St.YClass_id like @nYClassid+'%') 

 		GROUP BY ST.[P_ID]
  	) AS E
  	ON B.[P_ID]=E.[P_ID]
 	WHERE A.[Product_ID]<>1 AND A.[Deleted]<>1
  END
  GOTO SUCCEE 
END

SUCCEE:
  RETURN 0
GO
