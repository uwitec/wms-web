


CREATE	TRIGGER cgBillstates ON [dbo].[orderidx]
FOR  UPDATE
AS
if update(billstates)
begin
  if exists(select 1 from inserted where billtype in (14,154) and billstates=0)
  begin
	 delete from orderdraft  where bill_id in (select billid from inserted where billtype in (14,154) and billstates=0)
  end
  if exists(select 1 from inserted where billtype in (14,154) and billstates in (2,3))
  begin
  	 update orderdraft set billstates=b.billstates from orderdraft a,inserted b where a.bill_id=b.billid and b.billtype in (14,154) and b.billstates in (2,3)
  end 
  if exists(select 1 from inserted a,deleted b where a.billid=b.billid and a.billstates=3 and b.billstates=0 and a.billtype in (14,154)) /*生成的单据被红冲*/
  begin
    delete from orderdraft where bill_id in (select a.billid from inserted a,deleted b where a.billid=b.billid and a.billstates=3 and b.billstates=0 and a.billtype in (14,154)) 
    
    insert orderdraft (orgsmb_id,bill_id,b.billstates,p_id,batchno,quantity,costprice,makedate,validdate,ss_id,location_id,supplier_id,commissionflag,comeqty,y_id,a.instoretime,aoid, factoryid, costtaxprice, costtaxrate)
	select smb_id,bill_id,billstates,p_id,batchno,a.quantity,costprice,makedate,validdate,ss_id,location_id,supplier_id,commissionflag,comeqty,a.Y_ID,instoretime,aoid, factoryid, costtaxprice, costtaxrate
	from OrderBill a,(select a.billid,a.billstates from inserted a,deleted b where a.billid=b.billid and a.billstates=3 and b.billstates=0 and a.billtype in (14,154)) b
	where a.bill_id=b.billid and a.AOID in (0,7)
  end
end
GO
