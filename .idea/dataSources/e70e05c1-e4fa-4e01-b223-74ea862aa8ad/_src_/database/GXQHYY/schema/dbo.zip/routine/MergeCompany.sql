
/* =============================================*/
/* Description:	合并机构名称*/
/* =============================================*/
CREATE FUNCTION MergeCompany 
(
    @nmode int,  /*0表示传入的是机构id串，1表示传入自定义类别class_id, 2表示传入机构id是否在这个类别内*/
	@strid varchar(5000),
	@c_id int 
)
RETURNS varchar(5000)
AS
BEGIN
	DECLARE @Result varchar(5000)
	
	set @Result = ''

if @nmode = 0
begin
	SELECT @Result = ISNULL(@Result + ',', '') + name from company where company_id in (select szTYPE from DecodeToStr(@strid))
			and deleted = 0 and child_number = 0
	if @Result <> ''
	begin
	  set @Result = Substring(@Result,2,LEN(@Result)-1)   
	end
end
else if @nmode = 1
begin
   SELECT @Result = ISNULL(@Result + ',', '') + name from company where company_id in (
		select distinct baseinfo_id from customCategoryMapping cp 
		left join customCategory c on cp.category_id = c.id  where cp.BaseTypeid = 2 and patindex(@strid + '%',c.class_id) > 0   
   )
	if @Result <> ''
	begin
	  set @Result = Substring(@Result,2,LEN(@Result)-1)  
	end   
   
end
else if @nmode = 2
begin
 if exists(
   SELECT name  from company where company_id in (
		select distinct baseinfo_id from customCategoryMapping cp 
		left join customCategory c on cp.category_id = c.id  where cp.BaseTypeid = 2 and patindex(@strid + '%',c.class_id) > 0   
   )
   and company_id = @c_id)
   set @Result = '1'
 else
  set @Result = '0'
end

RETURN @Result

END
GO
