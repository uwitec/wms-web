
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_STORAGES
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

	/* 全部列表*/
	if @szListFlag = 'A'
	begin
		IF @nFilterY = 1/*过滤掉拆零库*/
		BEGIN
		    select *,0 as qty
		    from vw_Storage where WholeFlag <> 3 and child_number = 0 and deleted = 0
			and storage_id in (select storage_id from AuthorizeStorage(@E_id))
		END
		ELSE
		IF @nFilterY = 4/*只显示拆零库	*/
		BEGIN
			select *,0 as qty
		    from vw_Storage where WholeFlag = 3 and child_number = 0 and deleted = 0
			and storage_id in (select storage_id from AuthorizeStorage(@E_id))
		END
		ELSE
		BEGIN
			select *,0 as qty
		    from vw_Storage where child_number = 0 and deleted = 0
			and storage_id in (select storage_id from AuthorizeStorage(@E_id))
		END	
	end
	/* 其他*/
	else
	begin
	  if @nFilterY =-100
	  begin
		select *,0 as qty
		from vw_Storage
		where Parent_id=@parent_id and deleted=0 
	  end ELSE
	  IF @nFilterY = 2
	  BEGIN
	  	SELECT vs.* ,0 as qty
			FROM (
				select distinct s.* from vw_Storage s 
				inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u 
				  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id AND 
				     (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0)) AND (s.Y_ID = @nY_id OR s.Y_ID = 0) 
			 ) vs
			WHERE Parent_id=@parent_id 	
	  END else	
	  IF @nFilterY IN (-999, 1)/*过滤掉拆零库*/
	  BEGIN
	    if @szWhere=''
		begin 
			SELECT vs.* ,0 as qty
			FROM (
				select distinct s.* from vw_Storage s 
				inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
			 ) vs
			WHERE Parent_id=@parent_id AND vs.WholeFlag <> 3 			
		end else
		begin
		  if CHARINDEX('Like',@szWhere) > 0 
		  begin
			set @Sql = '  select *,0 as qty  from (
							  select distinct s.* from vw_Storage s 
								inner JOIN (
									   select * from AuthorizeStorage('+cast(@E_id as varchar(20))+') where Child_Number=0
									 ) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id 
										) t where Parent_id='''+@parent_id+''' and t.WholeFlag <> 3 and ' + @szwhere
			/*print(@sql) */
			exec(@sql)                      
		  end
		  else
		  begin
	          if exists(SELECT 1 FROM sysconfig WHERE sysname = 'CtrlStoreCondition' AND sysvalue = 1)
		    begin
			  /*如果打开了严格控制温度开关，返回与传入的产品ID温度条件一致的仓库*/
			SELECT vs.* ,isnull(sq.qty,0)as qty
			FROM (
					select distinct s.* from vw_Storage s 
					inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
				 ) vs
			  left join (select s_id,sum(quantity) as qty from storehouse where p_id=cast(@szWhere as integer) group by s_id) sq on vs.storage_id=sq.s_id
			  WHERE (Parent_id=@parent_id AND WholeFlag <> 3) AND 
			         vs.storeCondition IN (SELECT StoreCondition FROM products WHERE product_id = cast(@szWhere as integer))
			end
			else
			begin  
			  SELECT vs.* ,isnull(sq.qty,0)as qty
  			  FROM (
					  select distinct s.* from vw_Storage s 
					  inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
				   ) vs
			    left join (select s_id,sum(quantity) as qty from storehouse where p_id=cast(@szWhere as integer) group by s_id) sq on vs.storage_id=sq.s_id
			  
			WHERE (Parent_id=@parent_id AND WholeFlag <> 3)
		    end	  
		  end
		end
	  END ELSE
	  IF @nFilterY IN (-1000, 4)/*只显示拆零库*/
	  BEGIN
		if @szWhere=''
		begin 
			SELECT vs.* ,0 as qty
			FROM (
				select distinct s.* from vw_Storage s 
				inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
			 ) vs
			WHERE Parent_id=@parent_id AND vs.WholeFlag = 3 			
		end else
		begin
		  if CHARINDEX('Like',@szWhere) > 0 
		  begin
			set @Sql = '  select *,0 as qty from (
							  select distinct s.* from vw_Storage s 
								inner JOIN (
									   select * from AuthorizeStorage('+cast(@E_id as varchar(20))+') where Child_Number=0
									 ) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id 
										) t where Parent_id='''+@parent_id+''' AND t.WholeFlag = 3 and ' + @szwhere
			/*print(@sql) */
			exec(@sql)                      
		  end
		  else
			SELECT vs.* ,isnull(sq.qty,0)as qty
			FROM (
					select distinct s.* from vw_Storage s 
					inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
				 ) vs
			  left join (select s_id,sum(quantity) as qty from storehouse where p_id=cast(@szWhere as integer) group by s_id) sq on vs.storage_id=sq.s_id
			WHERE (Parent_id=@parent_id AND WholeFlag = 3)
		end	
	  END ELSE
	  begin
	    if @szWhere=''
		begin 
			SELECT vs.* ,0 as qty
			FROM (
				select distinct s.* from vw_Storage s 
				inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
			 ) vs
			WHERE Parent_id=@parent_id		
		end else
		begin
		  if CHARINDEX('Like',@szWhere) > 0 
		  begin
			set @Sql = '  select *,0 as qty from (
							  select distinct s.* from vw_Storage s 
								inner JOIN (
									   select * from AuthorizeStorage('+cast(@E_id as varchar(20))+') where Child_Number=0
									 ) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id 
										) t where ' + @szwhere
			/*print(@sql) */
			exec(@sql)                      
		  end
		  else
			SELECT vs.* ,isnull(sq.qty,0)as qty
			FROM (
					select distinct s.* from vw_Storage s 
					inner JOIN (select * from AuthorizeStorage(@E_id) where Child_Number=0) u  ON LEFT (u.class_id, LEN(s.class_id))=s.class_id
				 ) vs
			  left join (select s_id,sum(quantity) as qty from storehouse where p_id=cast(@szWhere as integer) group by s_id) sq on vs.storage_id=sq.s_id
			WHERE (Parent_id=@parent_id)
		end
	  end
	end
GO
