
CREATE PROCEDURE Ts_K_SaveDeductFormulaDetail(
    @FId            INT = 0,            
    @CategoryId     INT = 0,            
    @BatchNo        VARCHAR(200) = '',
    @BeginNum1      numeric(25,8) = 0,
    @EndNum1        numeric(25,8) = 0,
    @Rate1          numeric(25,8) = 0,
    @BeginNum2      numeric(25,8) = 0,
    @EndNum2        numeric(25,8) = 0,
    @Rate2          numeric(25,8) = 0,
    @BeginNum3      numeric(25,8) = 0,
    @EndNum3        numeric(25,8) = 0,
    @Rate3          numeric(25,8) = 0,
    @BeginNum4      numeric(25,8) = 0,
    @EndNum4        numeric(25,8) = 0,
    @Rate4          numeric(25,8) = 0 
)
AS
BEGIN
	
	INSERT INTO Deduct_FormulaDetail
	(FId, CategoryId, BatchNo, BeginNum1, EndNum1, Rate1, BeginNum2, EndNum2, Rate2, BeginNum3, EndNum3, Rate3, BeginNum4, EndNum4, Rate4)
	VALUES(@FId, @CategoryId, @BatchNo, @BeginNum1, @EndNum1, @Rate1, @BeginNum2, @EndNum2, @Rate2, @BeginNum3, @EndNum3, @Rate3, @BeginNum4, @EndNum4, @Rate4)
		
END
GO
