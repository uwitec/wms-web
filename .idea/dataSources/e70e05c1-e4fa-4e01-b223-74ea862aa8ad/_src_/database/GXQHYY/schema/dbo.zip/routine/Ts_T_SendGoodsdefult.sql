CREATE PROCEDURE [dbo].[Ts_T_SendGoodsdefult]
(	
	@C_id           int
)
AS

  select Cer_CustomNO1 as name,Cer_CustomNO2 as phone_number,(Case when Cer_CustomNO1='' then 1 else 0 end)showflag from clients 
  where client_id=@C_id
GO
