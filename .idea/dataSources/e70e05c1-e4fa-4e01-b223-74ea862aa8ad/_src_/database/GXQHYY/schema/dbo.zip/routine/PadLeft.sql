
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date, ,>*/
/* Description:	<Description, ,>*/
/* =============================================*/
CREATE FUNCTION PadLeft 
(
	/* Add the parameters for the function here*/
	@str		varchar(8000),
	@len		int,
	@char		char(1) = ' '
)
RETURNS varchar(8000)
AS
BEGIN
	/* Declare the return variable here*/
	declare @iFor int
	
	set @iFor = len(@str)
	
	while @iFor < @len
	begin
		set @str = @char + @str
		set @iFor = @iFor + 1
	end

	RETURN @str

END
GO
