/*exec ts_c_qrSaleBuyBatchMx '2015-02-01 00:00:00','2015-02-05 00:00:00','','','','',0,1,'000001',2,0,0*/
/*0 采购批次汇总表*/
/*1 销售批次汇总表*/
create proc ts_c_qrSaleBuyBatchMx
(           
	@BeginDate 		      datetime,
	@EndDate	 	      datetime,
	@szCClass_id		  varchar(30),
	@szEClass_id		  varchar(30),
	@szSClass_id		  varchar(30),
	@szInputClass_id	  varchar(30),
	@nLocationId          int,
	@nSortType            int=0,
	@nYClassID            varchar(50)='',
	@nloginEID               int=0,
	@isaddDate              int=0 ,/*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
	@ProductRange         int=0, /*药品类别*/
	@strBusinessType      varchar(50)= '0',
	@isBuyBack  int =0
)
/*with encryption*/
as
/*Params Ini begin*/
if @nSortType is null  SET @nSortType = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
set nocount on
declare @szLocid varchar(20)
Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int
declare @SQLScript varchar(8000)
DECLARE @nYId INT
DECLARE @billtype varchar(200)

if @isBuyBack = 0 
begin
   set @billtype = '20,24,35,220'
end else set  @billtype ='20,21,24,25,35,220,221' 

if @nLocationId=0 set @szLocid='%%' else
set @szLocid=cast(@nLocationId as varchar(20))

if @szCClass_id='' select @szCClass_id='%%' else select @szCClass_id=@szCClass_id+'%'
if @szEClass_id='' select @szEClass_id='%%' else select @szEClass_id=@szEClass_id+'%'
/*Wsj-tfsbug44003-2016-12-15 选择全部仓库无数据。*/
if @szSClass_id='' or @szSClass_id = '000000' select @szSClass_id='%%' else select @szSClass_id=@szSClass_id+'%'
if @szInputClass_id='' select @szInputClass_id='%%' else select @szInputClass_id=@szInputClass_id+'%'

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


if @nSortType=0 goto pBuyMx	/*采购批次汇总*/
else 
if @nSortType=1 goto pSaleMx 	/*销售批次汇总*/
else 
if @nSortType=2 goto pYReceiveMx 		/*机构收货批次汇总表*/
else 
if @nSortType=3 goto pYsendMx 		/*机构发货批次汇总表*/
goto succee


pBuyMx:
begin
   select a.* into #pBuyMx  from 
      (select isnull(vp.code,'') as code,isnull(vp.[name],'') as [name],isnull(vp.alias,'') as alias,
	isnull(vp.standard,'') as standard,isnull(vp.makearea,'') as makearea,isnull(vp.medtype,'') as medtype,
    isnull(vp.Inputman,'')Inputman,isnull(vp.InputDate,'')InputDate,isnull(vp.Custompro1,'')Custompro1,isnull(vp.Custompro2,'')Custompro2
    ,isnull(vp.Custompro3,'')Custompro3,isnull(vp.Custompro4,'')Custompro4,isnull(vp.Custompro5,'')Custompro5,
	isnull(t.batchno,'') as batchno,t.validdate,
	t.quantity,t.costtotal,t.taxtotal,t.saletotal,t.p_id ,(t.saletotal-t.costtotal) as mltotal,
	costprice=case when t.quantity=0 then 0 else t.costtotal/t.quantity end,
	taxmoney=t.taxtotal-t.saletotal,isnull(vp.unitname1,'') as unitname1,t.RowE_id,t.c_id,t.Y_id,t.ss_id,vp.rangename,
	isnull(t.factory,'') as factory, costtaxprice=case when t.quantity=0 then 0 else t.costtaxtotal/t.quantity end,t.costtaxtotal
	from (	select 
         pd.p_id,pd.batchno,
		max(pd.validdate) as validdate,
		isnull(sum(case when vb.billtype in (20,24,35,220) then pd.quantity else -pd.quantity end),0) as quantity,
		isnull(sum(case when vb.billtype in (20,24,35,220) then pd.costtaxtotal else -pd.costtaxtotal end),0) as costtotal,
		isnull(sum(case when vb.billtype in (20,24,35,220) then pd.taxtotal else -pd.taxtotal end),0) as taxtotal,
		isnull(sum(case when vb.billtype in (20,24,35,220) then pd.total else -pd.total end),0) as saletotal,
        isnull(Re.emp_id,'') as RowE_id,vb.c_id,vb.Y_id,pd.ss_id,
        isnull(f.AccountComment,'') as factory,
        isnull(sum(case when vb.billtype in (20,24,35,220) then pd.costtaxtotal else -pd.costtaxtotal end),0) as costtaxtotal
		from buymanagebill pd left join vw_c_products p
		on pd.p_id=p.product_id
		left join vw_c_billidx vb
		on pd.bill_id=vb.billid
                left join employees Re on RE.emp_id=pd.RowE_id
                left join storages Se on Se.storage_id = pd.ss_id
                left join basefactory f on f.CommID = pd.factoryid 
        where vb.billtype in (select szTYPE from DecodeToStr(@billtype)) and (vb.billdate between @BeginDate and @EndDate) and vb.billstates='0' and p.deleted<>1 
        and pd.aoid in(select szTYPE from DecodeToStr(@strBusinessType))
 		and (@szCClass_id in ('','%%') or vb.cclass_id like @szCClass_id )
		and (@szEClass_id in ('','%%') or Re.class_id like @szEClass_id )
 		and (@szSClass_id in ('','%%') or (Se.class_id like @szSClass_id+'%'))
 		and (@szInputClass_id in('','%%') or vb.inputmanclass_id like @szInputClass_id)
        and (@szLocid in ('','%%') or pd.location_id like @szLocid)
        and (@nYClassID='' or vb.YClass_id like @nYClassID+'%')
		group by pd.p_id,pd.batchno,Re.emp_id,vb.c_id,vb.Y_id,pd.ss_id,f.AccountComment
	    ) t left join vw_c_products vp
	on t.p_id=vp.product_id
	where (@ProductRange=0 or vp.SR2_id=@ProductRange)
   )a           where    ((@Companytable=0)   or (a.Y_id    in (select [id] from #Companytable)))   
                     AND ((@ClientTable=0)    or (a.c_id    in (select [id] from #Clienttable)))
                     AND ((@employeestable=0) or (a.RowE_id in (select [id] from #employeestable)))
                     AND ((@Storetable=0)     or (a.ss_id    in (select [id] from #storagestable))) 

     
       select distinct		      
             case when (grouping(p_id) = 1) then '-2'     else isnull(p_id, '总计')     end as p_id,
             /*case when (grouping(batchno) = 1) then '-1'  else isnull(batchno, '总计')  end as batchno,*/
             case when (grouping(batchno) = 1) then 'zzzzzzzzzzzzzzzzzz'  else isnull(batchno, '总计')  end as batchno, /*BUG31065*/
             MAX([code])       as  code,
             MAX([name])       as  name,
             MAX([alias])      as  alias,
             MAX([standard])   AS standard,
             MAX([makearea])   AS makearea,
             MAX([medtype])    AS medtype,
			 MAX([Inputman])   AS Inputman,
			 MAX([InputDate])  AS InputDate,
			 MAX([Custompro1]) AS Custompro1,
			 MAX([Custompro2]) AS Custompro2,
			 MAX([Custompro3]) AS Custompro3,
			 MAX([Custompro4]) AS Custompro4,
			 MAX([Custompro5]) AS Custompro5,
             MAX([batchno])    AS batchno2,
             MAX([validdate])  AS validdate,
             SUM([quantity])   AS quantity,
             SUM([costtotal])  AS costtotal,
             SUM([taxtotal])   AS taxtotal,
             SUM([saletotal])  AS saletotal,
             SUM([mltotal])    AS mltotal,
             MAX([factory])    AS factory,
             SUM([taxtotal]) as costtaxtotal,
             cast((case when sum(quantity)=0 then 0 else sum(costtaxtotal)/sum(quantity) end) as numeric(25,8)) AS costtaxprice,
             cast((case when sum(quantity)=0 then 0 else sum(costtotal)/sum(quantity) end) as numeric(25,8)) AS costprice,
             SUM([taxmoney])   AS taxmoney,
             case when (grouping(batchno) = 1) then '' when batchno=null then '' else  MAX([unitname1])end  AS unitname1,
             0.00 AS OtherQuantity,
             0.00 AS OtherCost ,
            case when (grouping(batchno) = 1) then '' when batchno=null then '' else  MAX( rangename)end as rangename 
       FROM  #pBuyMx where (quantity<>0 or costtotal<>0 or taxtotal<>0 or saletotal<>0 or mltotal<>0 or taxmoney<>0)
       group by p_id,batchno,rangename with rollup
       order by p_id desc, batchno 
       

   GOTO Succee
end

pSaleMx:
begin
   select a.* into #pSaleMx  from 
      (select isnull(vp.code,'') as code,isnull(vp.[name],'') as [name],isnull(vp.alias,'') as alias,
	isnull(vp.standard,'') as standard,isnull(vp.makearea,'') as makearea,isnull(vp.medtype,'') as medtype,
        isnull(vp.Inputman,'')Inputman,isnull(vp.InputDate,'')InputDate,isnull(vp.Custompro1,'')Custompro1,isnull(vp.Custompro2,'')Custompro2
        ,isnull(vp.Custompro3,'')Custompro3,isnull(vp.Custompro4,'')Custompro4,isnull(vp.Custompro5,'')Custompro5,
	isnull(t.batchno,'') as batchno,t.validdate,
	t.quantity,t.costtotal,t.taxtotal,t.saletotal,t.p_id ,(t.saletotal-t.costtotal) as mltotal,
	costprice=case when t.quantity=0 then 0 else t.costtotal/t.quantity end,
	taxmoney=t.taxtotal-t.saletotal,isnull(vp.unitname1,'') as unitname1,t.RowE_id,t.c_id,t.Y_id,t.s_id, 
	t.OtherQuantity, t.OtherCost,t.factory as factory,t.costtaxtotal,
	costtaxprice=case when t.quantity=0 then 0 else t.costtaxtotal/t.quantity end
	from (	
	       select pd.p_id,pd.batchno,
	       max(pd.validdate) as validdate,
		   isnull(sum(CASE WHEN pd.aoid <> 7 THEN -pd.quantity ELSE 0 END),0) as quantity,
		   isnull(sum(CASE WHEN pd.aoid <> 7 THEN -pd.costtotal ELSE 0 END),0) as costtotal,
		   isnull(sum(CASE WHEN pd.aoid <> 7 THEN -pd.taxtotal ELSE 0 END),0) as taxtotal,
		   isnull(sum(CASE WHEN pd.aoid <> 7 THEN -pd.total ELSE 0 END),0) as saletotal,
		   ISNULL(SUM(CASE WHEN pd.AOID = 7 THEN -pd.quantity ELSE 0 END), 0) AS OtherQuantity,
		   ISNULL(SUM(CASE WHEN pd.AOID = 7 THEN -pd.costtotal ELSE 0 END), 0) AS OtherCost,
           isnull(Re.emp_id,'') as RowE_id,vb.c_id,vb.Y_id,pd.s_id,isnull(pd.factory,'') as factory,
           isnull(sum(CASE WHEN pd.aoid <> 7 THEN -pd.costtaxtotal ELSE 0 END),0) as costtaxtotal
		from /*vw_c_pdetailJS pd */
		     (
		     	SELECT pd.y_id AS pdY_id, pd_id, billid, p_id, pd.s_id, quantity, price, total, costprice, costtotal, taxprice, taxtotal,
		     	       batchno, makedate, validdate, commissionflag, pd.supplier_id, location_id, storetype, price_id, order_id, unitid,
		     	       smb_id, pd.comment, jsprice, AOID, ISNULL(dbo.products.class_id, '') AS class_id, ISNULL(dbo.storages.class_id, '') AS sclass_id,
		     	       ISNULL(dbo.storages.[name], '') AS sname, ISNULL(dbo.products.[name], '') AS pname, products.makearea, products.standard,
		     	       ISNULL(l.loc_name, '') AS locname, ISNULL(cl.[name], '') AS suppliername, ISNULL(e.class_id, '') AS Reclass_id,
		     	       ISNULL(e.[name], '') AS Rename,pd.factory,isnull(pd.costtaxprice,0) as costtaxprice,isnull(pd.costtaxtotal,0) as costtaxtotal
		     	FROM FilterProductdetail(@nloginEID) pd LEFT OUTER JOIN storages ON pd.s_id = storages.storage_id 
		     	LEFT OUTER JOIN products ON pd.p_id = products.product_id
		     	LEFT OUTER JOIN location l ON pd.location_id = l.loc_id
		     	LEFT OUTER JOIN clients cl ON pd.supplier_id = cl.client_id
		     	LEFT OUTER JOIN employees e ON pd.RowE_id = e.emp_id
		     	WHERE pd.aoid 	IN (0, 5, 7)
		     	UNION ALL 
		     	SELECT pdY_id, pd_id, billid, p_id, sm.s_id, CASE WHEN billtype IN (16, 25) THEN -quantity ELSE quantity END, price,
		     	       CASE WHEN billtype IN (16, 25) THEN -total ELSE total END, CAST(costprice AS numeric(25,8)) AS costprice,
		     	       CASE WHEN billtype IN (16, 25) THEN -costtotal ELSE costtotal END, CAST(taxprice AS NUMERIC(20, 8)) AS taxprice,
		     	       CASE WHEN billtype IN (16, 25) THEN -taxtotal ELSE taxTotal END,
		     	       batchno, makedate, validdate, commissionflag, sm.supplier_id, location_id, storetype, price_id, order_id, unitid, smb_id,
		     	       sm.comment, jsprice, AOID, ISNULL(dbo.products.class_id, '') AS class_id, ISNULL(dbo.storages.class_id, '') AS sclass_id,
		     	       ISNULL(dbo.storages.[name], '') AS sname, ISNULL(dbo.products.[name], '') AS pname, products.makearea, products.standard,
		     	       ISNULL(l.loc_name, '') AS locname, ISNULL(cl.[name], '') AS suppliername, ISNULL(e.class_id, '') AS Reclass_id,
		     	       ISNULL(e.[name], '') AS Rename,isnull(sm.factory,'') as factory,CAST(costtaxprice AS NUMERIC(20, 8)) AS costtaxprice,
		     	       CASE WHEN billtype IN (16, 25) THEN -sm.costtaxtotal ELSE sm.costtaxtotal END
		     	FROM (
		     			     	         
		                  SELECT sm.y_id AS pdY_id, sm.smb_id AS pd_id, Sm.p_id, sm.ss_id AS s_id, sm.quantity,
		     			     	                CAST(sm.SalePrice AS NUMERIC(20, 8)) AS price, sm.total, sm.costprice, sm.taxprice,
		     			     	                sm.taxtotal, sm.batchno, sm.makedate, sm.validdate, sm.commissionflag, sm.supplier_id,
		     			     	                sm.location_id, sm.price_id, sm.order_id, sm.unitid, sm.smb_id, sm.comment, sm.jsprice,
		     			     	                sm.AOID, sm.RowE_id, bi.billType, bi.BillID, CAST((costPrice * Sm.Quantity) AS numeric(25,8)) AS 
		     			     	                costTotal, 0 AS storeType,isnull(sm.factory,'') factory,
		     			     	                sm.costtaxprice,costtaxtotal
		     			     	         FROM   FilterSalemanagebill(@nloginEID) sm, BillIdx bi
		     			     	         WHERE  sm.Bill_id = bi.BillID AND billType IN (16, 17)
		     			  UNION ALL
		     			     	         
		     			     	         SELECT bm.y_id AS pdY_id, bm.smb_id AS pd_id, bm.p_id, bm.ss_id AS s_id, bm.quantity,
		     			     	                CAST(bm.buyPrice AS NUMERIC(20, 8)) AS price, bm.total, bm.costprice, bm.taxprice,
		     			     	                bm.taxtotal, bm.batchno, bm.makedate, bm.validdate, bm.commissionflag, bm.supplier_id,
		     			     	                bm.location_id, bm.price_id, bm.order_id, bm.unitid, bm.smb_id, bm.comment, bm.jsprice,
		     			     	                bm.AOID, bm.RowE_id, bi.billType, bi.BillID,
		     			     	                CAST((costPrice * bm.Quantity) AS numeric(25,8)) AS costTotal, 0 AS storeType,bm.factory,
		     			     	                bm.costtaxprice,bm.costtaxtotal
		     			     	         FROM   (select a.*,isnull(f.AccountComment,'') as factory from BuyManageBill a left join AccountComment f on a.FactoryId=f.CommID) bm, BillIdx bi
		     			     	         WHERE  Bm.Bill_id = bi.BillID AND billType IN (24, 25)
		     			     	     ) sm 
		     	LEFT OUTER JOIN storages ON sm.s_id = storages.storage_id 
		     	LEFT OUTER JOIN products ON sm.p_id = products.product_id
		     	LEFT OUTER JOIN location l ON sm.location_id = l.loc_id
		     	LEFT OUTER JOIN clients cl ON sm.supplier_id = cl.client_id
		     	LEFT OUTER JOIN employees e ON sm.RowE_id = e.emp_id
		     	WHERE sm.aoid IN (0, 5)
		     ) pd
		     left join vw_c_products p on pd.p_id=p.product_id
		     left join vw_c_billidx vb on pd.billid=vb.billid
             left join employees Re on RE.class_id=pd.Reclass_id
 		where vb.billtype in (10,11,12,13,112,53,54,16,17,212) and (vb.billdate between @BeginDate and @EndDate)  and vb.billstates='0' and p.deleted<>1 and pd.aoid in(0, 5, 7)
 		and (@szCClass_id in ('','%%') or vb.cclass_id like @szCClass_id) 
		and (@szEClass_id in ('','%%') or pd.Reclass_id like @szEClass_id) 
 		and (@szSClass_id in ('','%%') or (pd.sclass_id like @szSClass_id+'%' and vb.billtype <>112)) 
 		and (@szInputClass_id in('','%%') or vb.inputmanclass_id like @szInputClass_id)
        and (@szLocid in('','%%') or pd.location_id like @szLocid)
        and (@nYClassID in('','%%') or vb.YClass_id like @nYClassID+'%')
		group by pd.p_id,pd.batchno,Re.emp_id,vb.c_id,vb.Y_id,pd.s_id,pd.factory  
	    ) t left join vw_c_products vp
	on t.p_id=vp.product_id
   )a       

     
       select distinct		      
             case when (grouping(p_id) = 1) then '-2'     else isnull(p_id, '总计')     end as p_id,
             /*case when (grouping(batchno) = 1) then '-1'  else isnull(batchno, '总计')  end as batchno,*/
             case when (grouping(batchno) = 1) then 'zzzzzzzzzzzzzzzzzz'  else isnull(batchno, '总计')  end as batchno, /*BUG31065*/
             MAX([code])       as  code,
             MAX([name])       as  name,
             MAX([alias])      as  alias,
             MAX([standard])   AS standard,
             MAX([makearea])   AS makearea,
             MAX([medtype])    AS medtype,
			 MAX([Inputman])   AS Inputman,
			 MAX([InputDate])  AS InputDate,
			 MAX([Custompro1]) AS Custompro1,
			 MAX([Custompro2]) AS Custompro2,
			 MAX([Custompro3]) AS Custompro3,
			 MAX([Custompro4]) AS Custompro4,
			 MAX([Custompro5]) AS Custompro5,
             MAX([batchno])    AS batchno2,
             MAX([validdate])  AS validdate,
             SUM([quantity])   AS quantity,
             SUM([costtotal])  AS costtotal,
             SUM([taxtotal])   AS taxtotal,
             SUM([saletotal])  AS saletotal,
             SUM([mltotal])    AS mltotal,             
             cast((case when sum(quantity)=0 then 0 else sum(costtotal)/sum(quantity) end) as numeric(25,8)) AS costprice,
             SUM([taxmoney])   AS taxmoney,
             MAX([unitname1])  AS unitname1,
             SUM([OtherQuantity]) AS OtherQuantity,
             SUM([OtherCost]) AS OtherCost 
             ,'' as rangename,
             max(factory) as factory,
             SUM(costtaxtotal) as costtaxtotal,
             cast((case when sum(quantity)=0 then 0 else sum(costtaxtotal)/sum(quantity) end) as numeric(25,8)) AS costtaxprice
       FROM  #pSaleMx /*where (quantity<>0 or costtotal<>0 or taxtotal<>0 or saletotal<>0 or mltotal<>0 or taxmoney<>0)*/
       group by p_id,batchno,factory with rollup
       order by p_id desc, batchno 

   GOTO Succee
end

pYsendMx:
BEGIN
	IF (@nYClassID = '') OR (@nYClassID = '%%')
	  SET @nYId = 0
	ELSE
	  SELECT @nYId = ISNULL(company_id, 0) FROM company c WHERE c.class_id = @nYClassID  
      select a.* into #YsendMx  from 
      (	select isnull(vp.code,'') as code,isnull(vp.[name],'') as [name],isnull(vp.alias,'') as alias,
    	isnull(vp.standard,'') as standard,isnull(vp.makearea,'') as makearea,isnull(vp.medtype,'') as medtype,
        isnull(vp.Inputman,'')Inputman,isnull(vp.InputDate,'')InputDate,isnull(vp.Custompro1,'')Custompro1,isnull(vp.Custompro2,'')Custompro2
        ,isnull(vp.Custompro3,'')Custompro3,isnull(vp.Custompro4,'')Custompro4,isnull(vp.Custompro5,'')Custompro5,
	isnull(t.batchno,'') as batchno,t.validdate,
	t.quantity,t.costtotal,t.taxtotal,t.saletotal,t.p_id ,(t.saletotal-t.costtotal) as mltotal,
	costprice=case when t.quantity=0 then 0 else t.costtotal/t.quantity end,
	taxmoney=case when isnull(t.taxtotal,0)=0 then 0 else t.taxtotal-t.saletotal end,
        isnull(vp.unitname1,'') as unitname1,t.RowE_id,t.c_id,t.Y_id,t.s_id,isnull(t.factory,'') as factory,
        ISNULL(t.costtaxtotal,0) as costtaxtotal
	from (	
	    select  pd.p_id,pd.batchno,
		max(pd.validdate) as validdate,
		isnull(sum(-pd.quantity),0) as quantity,
		isnull(sum(-pd.costtotal),0) as costtotal,
		isnull(sum(-pd.taxtotal),0) as taxtotal,
		isnull(sum(-pd.total),0) as saletotal,
        isnull(Re.emp_id,'') as RowE_id,vb.c_id,vb.Y_id,pd.s_id,isnull(pd.factory,'') as factory,
        ISNULL(sum(-pd.costtaxtotal),0) as costtaxtotal
		from Filtervw_c_pdetailJS(@nloginEID) pd left join vw_c_products p
		on pd.p_id=p.product_id
		left join vw_c_billidx vb
		on pd.billid=vb.billid
                left join employees Re on RE.class_id=pd.Reclass_id
 		where  (@nYId = 0 OR pd.pdY_id=@nYId) and vb.billtype in (150,151,152,153) and (vb.billdate between @BeginDate and @EndDate) and vb.billstates='0' and p.deleted<>1 and pd.aoid in(0,5)
				and (@szCClass_id in('','%%') or vb.cclass_id like @szCClass_id) 
				and (@szEClass_id in('','%%') or pd.Reclass_id like @szEClass_id) 
				and (@szSClass_id in('','%%') or pd.sclass_id like @szSClass_id+'%' )
				and (@szInputClass_id in('','%%') or vb.inputmanclass_id like @szInputClass_id)
                and (@szLocid in('','%%') or pd.location_id like @szLocid)
                and (@nYClassID in('','%%') or vb.YClass_id like @nYClassID+'%')
		group by pd.p_id,pd.batchno,Re.emp_id,vb.c_id,vb.Y_id,pd.s_id ,pd.factory 
	    ) t left join vw_c_products vp
	on t.p_id=vp.product_id
   )a       

     
       select 		      
             case when (grouping(p_id) = 1) then '-2'     else isnull(p_id, '总计')     end as p_id,
             /*case when (grouping(batchno) = 1) then '-1'  else isnull(batchno, '总计')  end as batchno,*/
             case when (grouping(batchno) = 1) then 'zzzzzzzzzzzzzzzzzz'  else isnull(batchno, '总计')  end as batchno, /*BUG31065*/
             MAX([code])       as  code,
             MAX([name])       as  name,
             MAX([alias])      as  alias,
             MAX([standard])   AS standard,
             MAX([makearea])   AS makearea,
             MAX([medtype])    AS medtype,
			 MAX([Inputman])   AS Inputman,
			 MAX([InputDate])  AS InputDate,
			 MAX([Custompro1]) AS Custompro1,
			 MAX([Custompro2]) AS Custompro2,
			 MAX([Custompro3]) AS Custompro3,
			 MAX([Custompro4]) AS Custompro4,
			 MAX([Custompro5]) AS Custompro5,
             MAX([batchno])    AS batchno2,
             MAX([validdate])  AS validdate,
             SUM([quantity])   AS quantity,
             SUM([costtotal])  AS costtotal,
             SUM([taxtotal])   AS taxtotal,
             SUM([saletotal])  AS saletotal,
             SUM([mltotal])    AS mltotal,           
             cast((case when sum(quantity)=0 then 0 else sum(costtotal)/sum(quantity) end) as numeric(25,8)) AS costprice,
             SUM([taxmoney])   AS taxmoney,
             MAX([unitname1])  AS unitname1,
             0.00 AS OtherQuantity,
             0.00 AS OtherCost
             ,'' as rangename,  
             max(factory) as factory,
             cast((case when sum(quantity)=0 then 0 else sum(costtaxtotal)/sum(quantity) end) as numeric(25,8)) AS costtaxprice,
             SUM(costtaxtotal) as costtaxtotal
       FROM  #YsendMx where (quantity<>0 or costtotal<>0 or taxtotal<>0 or saletotal<>0 or mltotal<>0 or taxmoney<>0)  
       group by p_id,batchno with rollup
   GOTO Succee
end



pYReceiveMx:
begin
      select a.* into #YReceiveMx  from 
      (	select isnull(vp.code,'') as code,isnull(vp.[name],'') as [name],isnull(vp.alias,'') as alias,
		isnull(vp.standard,'') as standard,isnull(vp.makearea,'') as makearea,isnull(vp.medtype,'') as medtype,
		isnull(vp.Inputman,'')Inputman,isnull(vp.InputDate,'')InputDate,isnull(vp.Custompro1,'')Custompro1,isnull(vp.Custompro2,'')Custompro2
		,isnull(vp.Custompro3,'')Custompro3,isnull(vp.Custompro4,'')Custompro4,isnull(vp.Custompro5,'')Custompro5,
	isnull(t.batchno,'') as batchno,t.validdate,
	t.quantity,t.costtotal,t.taxtotal,t.saletotal,t.p_id ,(t.saletotal-t.costtotal) as mltotal,
	costprice=case when t.quantity=0 then 0 else t.costtotal/t.quantity end,
	taxmoney=case when isnull(t.taxtotal,0)=0 then 0 else t.taxtotal-t.saletotal end,isnull(vp.unitname1,'') as unitname1,
	t.RowE_id,t.c_id,t.Y_id,t.s_id,isnull(t.factory,'') as factory,
	t.costtaxtotal,costtaxprice=case when t.quantity=0 then 0 else t.costtaxtotal/t.quantity end
	from (	select 
                pd.p_id,pd.batchno,
		max(pd.validdate) as validdate,
		isnull(sum(case when vb.billtype in (160,161,152,162,163) then pd.quantity else -pd.quantity end),0) as quantity,
		isnull(sum(case when vb.billtype in (160,161,152,162,163) then pd.costtotal else -pd.costtotal end),0) as costtotal,
		isnull(sum(case when vb.billtype in (160,161,152,162,163) then pd.taxtotal else -pd.taxtotal end),0) as taxtotal,
		isnull(sum(case when vb.billtype in (160,161,152,162,163) then pd.total else -pd.total end),0) as saletotal,
	    isnull(Re.emp_id,'') as RowE_id,vb.c_id,vb.Y_id,pd.s_id,isnull(pd.factory,'') as factory,
	    isnull(sum(case when vb.billtype in (160,161,152,162,163) then pd.costtaxtotal else -pd.costtaxtotal end),0) as costtaxtotal
		from Filtervw_c_pdetailJS(@nloginEID) pd left join vw_c_products p
		on pd.p_id=p.product_id
		left join vw_c_billidx vb
		on pd.billid=vb.billid
                left join employees Re on RE.class_id=pd.Reclass_id
 		where pd.pdY_id<>2 and vb.billtype in (160,161,152,162,163) and (vb.billdate between @BeginDate and @EndDate)and vb.billstates='0' and p.deleted<>1 and pd.aoid in(0,5)
 		and (@szCClass_id in('','%%') or case when billtype=152 then vb.YClass_id else vb.cclass_id end like @szCClass_id) 
		and (@szEClass_id in('','%%') or pd.Reclass_id like @szEClass_id)
 		and (@szSClass_id in('','%%') or pd.sclass_id like @szSClass_id +'%')
 		and (@szInputClass_id in('','%%') or vb.inputmanclass_id like @szInputClass_id)
		and (@szLocid in('','%%') or pd.location_id like @szLocid)
		and (@nYClassID in('','%%') or case when billtype=152 then  vb.cclass_id else vb.YClass_id end like @nYClassID+'%')
		group by pd.p_id,pd.batchno,Re.emp_id,vb.c_id,vb.Y_id,pd.s_id,pd.factory 
	    ) t left join vw_c_products vp
	on t.p_id=vp.product_id
   )a       
       select 		      
             case when (grouping(p_id) = 1) then '-2'     else isnull(p_id, '总计')     end as p_id,
             /*case when (grouping(batchno) = 1) then '-1'  else isnull(batchno, '总计')  end as batchno,*/
             case when (grouping(batchno) = 1) then 'zzzzzzzzzzzzzzzzzz'  else isnull(batchno, '总计')  end as batchno, /*BUG31065*/
             MAX([code])       as  code,
             MAX([name])       as  name,
             MAX([alias])      as  alias,
             MAX([standard])   AS standard,
             MAX([makearea])   AS makearea,
             MAX([medtype])    AS medtype,
			 MAX([Inputman])   AS Inputman,
			 MAX([InputDate])  AS InputDate,
			 MAX([Custompro1]) AS Custompro1,
			 MAX([Custompro2]) AS Custompro2,
			 MAX([Custompro3]) AS Custompro3,
			 MAX([Custompro4]) AS Custompro4,
	         MAX([Custompro5]) AS Custompro5,
             MAX([batchno])    AS batchno2,
             MAX([validdate])  AS validdate,
             SUM([quantity])   AS quantity,
             SUM([costtotal])  AS costtotal,
             SUM([taxtotal])   AS taxtotal,
             SUM([saletotal])  AS saletotal,
             SUM([mltotal])    AS mltotal,             
             cast((case when sum(quantity)=0 then 0 else sum(costtotal)/sum(quantity) end) as numeric(25,8)) AS costprice,
             SUM([taxmoney])   AS taxmoney,
             MAX([unitname1])  AS unitname1,
             0.00 AS OtherQuantity,
             0.00 AS OtherCost 
             ,'' as rangename, 
             max(factory) as factory,
             cast((case when sum(quantity)=0 then 0 else sum(costtaxtotal)/sum(quantity) end) as numeric(25,8)) AS costtaxprice,
             SUM(costtaxtotal) as costtaxtotal
       FROM  #YReceiveMx where (quantity<>0 or costtotal<>0 or taxtotal<>0 or saletotal<>0 or mltotal<>0 or taxmoney<>0)
       group by p_id,batchno with rollup

   GOTO Succee   
end

Succee:
     return 0
GO
