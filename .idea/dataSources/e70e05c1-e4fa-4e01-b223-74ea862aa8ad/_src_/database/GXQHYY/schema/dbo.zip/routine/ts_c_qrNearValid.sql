



create proc ts_c_qrNearValid
(
	@nDay   int,
        @nY_id  int
)
as
set nocount on 
if @nDay>=0 
begin
	select s.*,isnull(mt.mt_name,'') mt_name,s.code as barcode 
	from vw_c_storehouse s 
        left join medtype mt on s.medtype=mt.mt_id 
	where s.Y_id=@nY_id and s.validdate<convert(varchar(10),dateadd(day,@nDay,getdate()),20) and s.validdate>convert(varchar(10),getdate(),20) 
	order by s.pname,s.sname,s.locname
	
	return 0
end
if @nDay=-1
begin
	select s.*,isnull(mt.mt_name,'') mt_name,s.code as barcode 
	from vw_c_storehouse s 
	left join vw_c_Alert va on s.p_id=va.p_id
	left join medtype mt on s.medtype=mt.mt_id 
	where s.Y_id=@nY_id and s.validdate<convert(varchar(10),dateadd(day,va.alertday,getdate()),20) and s.validdate>convert(varchar(10),getdate(),20) 
	order by s.pname,s.sname,s.locname
end
GO
