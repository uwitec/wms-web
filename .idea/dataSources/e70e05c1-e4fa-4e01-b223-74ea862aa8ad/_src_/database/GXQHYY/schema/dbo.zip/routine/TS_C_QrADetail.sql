

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

科目明细帐
最后的修改日期 2003-12-26

********************************************/
CREATE PROCEDURE TS_C_QrADetail
( @BeginDate 	  DATETIME=0,
	@EndDate 		  DATETIME=0,
	@szAClass_ID	VARCHAR(30)='',
	@szCClass_ID	VARCHAR(30)='',
  @szEClass_ID  VARCHAR(30)='',
  @szIClass_ID  VARCHAR(30)='',
  @nBillType    INT=0,
  @nOrderType   INT=0,
  @iniTotal     numeric(25,8)=0 OUTPUT,
  @nYClassid    varchar(100)='',
  @nloginEID    int=0,
  @isaddDate    int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
  @szSummary    VARCHAR(30)=''
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szAClass_ID is null  SET @szAClass_ID = ''
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szIClass_ID is null  SET @szIClass_ID = ''
if @nBillType is null  SET @nBillType = 0
if @nOrderType is null  SET @nOrderType = 0
if @iniTotal is null  SET @iniTotal = 0 
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @szSummary is null  SET @szSummary = ''
/*Params Ini end*/
  SET NOCOUNT ON
  /*------Some account id*/
	DECLARE 
		@SQLScript  VARCHAR(8000),
		@ArTotal_Id VARCHAR(30),  /*9	『应收款合计』*/
		@ApTotal_Id VARCHAR(30),	/*15『应付帐款合计』*/
	  @dTempTotal numeric(25,8)


 /* SET NOCOUNT ON*/

  Declare @ClientTable int,@Companytable int,@employeestable int
  Declare @YId int 
  set @YId=0
  SELECT @YId =cast(company_id as varchar(100)) from company where Class_id=@nYClassid

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


	SELECT	@ArTotal_Id		='000001000005'	/*9	『应收款合计』*/
	SELECT	@ApTotal_Id		='000002000001'	/*15『应付帐款合计』*/

IF @szAClass_ID= @ArTotal_Id
BEGIN
  /*取起始时间段内的变化量*/
    SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ArTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0)
      FROM
        (SELECT YA.*,isnull(a.Class_id,'')AClass_id,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id,
           y.superior_id,y.Ytype
           FROM 
             (select a.a_id,a.jdmoney,b.e_id,a.c_id,a.Y_id    
                from (
						select billid, a_id ,c_id,y_id,sum(jdmoney) as jdmoney 
						from accountdetail 
						where a_id in (9,CASE @isaddDate WHEN 0 THEN 15 ELSE 0 END) 
						group by billid, a_id,c_id,y_id
					) a 
					left join billidx b on b.billid=a.billid
					where b.billdate<@BeginDate  and b.billstates='0' and a.Y_ID = @YId 
             )YA
           LEFT JOIN Account A on A.account_id=YA.a_id
           LEFT JOIN Clients C on C.Client_id=YA.C_id
           LEFT JOIN Company Y on Y.Company_id=YA.Y_id
         )a
      WHERE ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable))) 
        and ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
        and ((@employeestable=0) OR (a.E_id in (select [id] from #employeestable)))
        and  a.AClass_ID IN (@ArTotal_Id, CASE @isaddDate WHEN 0 THEN @APTotal_Id ELSE '' END)
        /*and (@nYClassid='' or a.YClass_id like @nYClassid+'%') */
        and (@YID=0 or (a.Y_ID=@YID or (a.superior_id=@YID and a.yType=1)) )
        and (@szCClass_ID='' or a.cClass_ID like @szCClass_ID+'%')
    IF @szCClass_ID<>'' 
    BEGIN 
    /*从往来单位取期初余额*/
      SELECT @iniTotal=ISNULL(SUM(cb.artotal_ini)-SUM(cb.aptotal_ini),0)
        FROM 
            (select cb.artotal_ini,cb.aptotal_ini,cb.c_id,cb.Y_id,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id ,
               y.superior_id,y.Ytype
               from Clientsbalance cb
               left join Clients C on cb.c_id=C.Client_id
               left join Company Y on cb.Y_id=Y.Company_id
             )cb   
      WHERE ((@Companytable=0)or (cb.Y_id in (select [id] from #Companytable))) 
        and ((@ClientTable=0) or (cb.c_id in (select [id] from #Clienttable)))
        and LEFT(cb.CClass_ID,LEN(@szCClass_ID))=@szCClass_ID
        /*and (@nYClassID='' OR cb.Yclass_id like @nYClassID+'%') */
        and (@YID=0 or (cb.Y_ID=@YID or (cb.superior_id=@YID and cb.yType=1)) )   
    END ELSE
    BEGIN
    /*从往来明细帐中取期初余额*/
      SELECT @iniTotal=ISNULL(SUM(ab.ini_total),0)
        FROM (select AB.ini_total,AB.Y_id,isnull(A.Class_id,'')AClass_id,isnull(Y.Class_id,'')YClass_id ,
				y.superior_id,y.Ytype
                from accountbalance AB
                LEFT JOIN  account  A  ON AB.a_id=a.account_id
                LEFT JOIN  Company  Y  ON AB.Y_id=Y.company_id
              )AB
       WHERE ((@Companytable=0)or (ab.Y_id in (select [id] from #Companytable))) 
        /*AND (@nYClassID='' OR ab.Yclass_id like @nYClassID+'%')*/
        and (@YID=0 or (ab.Y_ID=@YID or (ab.superior_id=@YID and ab.yType=1)) )
        and AB.AClass_ID=@szAClass_ID
    END

    SELECT @iniTotal=@iniTotal+@dTempTotal

END
ELSE
IF @szAClass_ID= @ApTotal_Id
BEGIN
    /*取起始时间段内的变化量*/
    SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ApTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0)
      FROM
        (SELECT YA.*,isnull(a.Class_id,'')AClass_id,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id,
           y.superior_id,y.Ytype
           FROM 
             (select a.a_id,a.jdmoney,b.e_id,a.c_id,a.Y_id    
                from (
						select billid, a_id ,c_id,y_id,sum(jdmoney) as jdmoney 
						from accountdetail 
						where a_id in (CASE @isaddDate WHEN 0 THEN 9 ELSE 0 END,15) 
						group by billid, a_id,c_id,y_id
					) a 
					left join billidx b on b.billid=a.billid
					where b.billdate<@BeginDate  and b.billstates='0' and a.Y_ID = @YId  
             )YA
           LEFT JOIN Account A on A.account_id=YA.a_id
           LEFT JOIN Clients C on C.Client_id=YA.C_id
           LEFT JOIN Company Y on Y.Company_id=YA.Y_id
         )a
      WHERE a.AClass_ID IN (CASE @isaddDate WHEN 0 THEN @ArTotal_Id ELSE '' END, @APTotal_Id)
        /*and (@nYClassid='' or a.YClass_id like @nYClassid+'%') */
        and (@YID=0 or (a.Y_ID=@YID or  (a.superior_id=@YID and a.yType=1)) )
        and (@szCClass_ID='' or a.cClass_ID like @szCClass_ID+'%')
        and ((@employeestable=0) OR (a.E_id in (select [id] from #employeestable)))
        and ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
        and ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))   
			

    IF @szCClass_ID<>'' 
    BEGIN 
    /*从往来单位取期初余额*/
      SELECT @iniTotal=ISNULL(SUM(cb.aptotal_ini)-SUM(cb.artotal_ini),0)
        FROM 
            (select cb.artotal_ini,cb.aptotal_ini,cb.c_id,cb.Y_id,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id,
               Y.superior_id,y.yType
               from Clientsbalance cb
               left join Clients C on cb.c_id=C.Client_id
               left join Company Y on cb.Y_id=Y.Company_id
             )cb   
      WHERE ((@Companytable=0)or (cb.Y_id in (select [id] from #Companytable))) 
        and ((@ClientTable=0) or (cb.c_id in (select [id] from #Clienttable)))
        and  LEFT(cb.CClass_ID,LEN(@szCClass_ID))=@szCClass_ID
        /*and (@nYClassID='' OR cb.Yclass_id like @nYClassID+'%')*/
        and (@YID=0 or (cb.Y_ID=@YID or (cb.superior_id=@YID and cb.yType=1)) )               
        
    END ELSE
    BEGIN
    /*从往来明细帐中取期初余额*/
      SELECT @iniTotal=ISNULL(SUM(ab.ini_total),0)
        FROM (select AB.ini_total,AB.Y_id,isnull(A.Class_id,'')AClass_id,isnull(Y.Class_id,'')YClass_id ,
                Y.superior_id,y.yType
                from accountbalance AB
                LEFT JOIN  account  A  ON AB.a_id=a.account_id
                LEFT JOIN  Company  Y  ON AB.Y_id=Y.company_id
              )AB
       WHERE ((@Companytable=0)or (ab.Y_id in (select [id] from #Companytable)))
        /*AND (@nYClassID='' OR ab.Yclass_id like @nYClassID+'%')*/
        and (@YID=0 or (ab.Y_ID=@YID or (ab.superior_id=@YID and ab.yType=1)) )
        and  AB.AClass_ID=@szAClass_ID
    END

    SELECT @iniTotal=@iniTotal+@dTempTotal


END ELSE
BEGIN
    /*取起始时间段内的变化量*/
    SELECT @dTempTotal=ISNULL(SUM(a.jdmoney),0)
      FROM
        (SELECT YA.*,isnull(a.Class_id,'')AClass_id,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id,
           Y.superior_id,y.yType
           FROM 
             (select a.a_id,a.jdmoney,b.e_id,b.c_id,b.Y_id    
                from (select billid, a_id, sum(jdmoney) as jdmoney from accountdetail group by billid, a_id) a 
                left join billidx b on b.billid=a.billid
               where b.billdate<@BeginDate  and b.billstates='0' and b.Y_ID = @YId
             )YA
           LEFT JOIN Account A on A.account_id=YA.a_id
           LEFT JOIN Clients C on C.Client_id=YA.C_id
           LEFT JOIN Company Y on Y.Company_id=YA.Y_id
         )a
      WHERE ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
        and ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
        and  LEFT(a.aClass_ID,LEN(@szAClass_ID))=@szAClass_ID
        /*and (@nYClassid='' or a.YClass_id like @nYClassid+'%') */
        and (@YID=0 or (a.Y_ID=@YID or (a.superior_id=@YID and a.yType=1)) )
        and (@szCClass_ID='' or a.cClass_ID like @szCClass_ID+'%')
        and ((@employeestable=0) OR (a.E_id in (select [id] from #employeestable)))
       
           

    /*取期初余额*/
    SELECT @iniTotal=ISNULL(SUM(ab.ini_total),0)
      FROM (select AB.ini_total,AB.Y_id,isnull(A.Class_id,'')AClass_id,isnull(Y.Class_id,'')YClass_id ,
                Y.superior_id,y.yType
                from accountbalance AB
                LEFT JOIN  account  A  ON AB.a_id=a.account_id
                LEFT JOIN  Company  Y  ON AB.Y_id=Y.company_id
            )AB
     WHERE AB.AClass_ID=@szAClass_ID
       and ((@Companytable=0)or (ab.Y_id in (select [id] from #Companytable)))
       /*AND (@nYClassID='' or ab.Yclass_id like @nYClassID+'%')*/
       and (@YID=0 or (ab.Y_ID=@YID or (ab.superior_id=@YID and ab.yType=1)) )

    SELECT @iniTotal=@iniTotal+@dTempTotal
END 


SET @SQLScript='SELECT p.billid,p.billtype,p.billdate,p.billnumber,p.inputman,p.auditman,
                       case when  p.billtype = 90 then p.note+''摘要:''+f.comment1 else p.note end as note,
                       p.SUMmary,p.billstates, p.IEname as inputmanname, p.AEname as auditmanname,
                       invoicetype=(case p.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end),'

IF @szAClass_ID= @ArTotal_Id
BEGIN
  SET @SQLScript=@SQLScript+'
			jdmoney=CASE p.aClass_ID 
			WHEN '+CHAR(39)+@ArTotal_id+CHAR(39)+' THEN p.jdmoney 
			WHEN '+CHAR(39)+@ApTotal_id+CHAR(39)+' THEN -p.jdmoney 
			ELSE p.jdmoney 
			END,'

END ELSE IF @szAClass_ID= @ApTotal_Id
BEGIN
  SET @SQLScript=@SQLScript+'
		        jdmoney=CASE p.aClass_ID 
			WHEN '+CHAR(39)+@ApTotal_id+CHAR(39)+' THEN p.jdmoney 
			WHEN '+CHAR(39)+@ArTotal_id+CHAR(39)+' THEN -p.jdmoney 
			ELSE p.jdmoney 
			END,'
END ELSE
  SET @SQLScript=@SQLScript+'p.jdmoney, '

/*zh100928*/
SET @SQLScript=@SQLScript+
'               ISNULL(p.Ename,'''') AS employeename,
		ISNULL(p.accountname,'''') AS accountname,
		ISNULL(cserial_number,'''') AS [serial_nubmer],
		ISNULL(p.cname,'''') AS clientname
    FROM
      (SELECT YA.*,isnull(a.class_id,'''')AClass_id,isnull(a.[name],'''')accountname,
                   isnull(Y.Class_id,'''')YClass_id,
                   isnull((case when billtype in (150,151,155,160,161,165,171,172,173,174) then (select Class_id from Company where Company_id=YA.c_id)
                                            else (select Class_id from Clients where Client_id=YA.C_id)  end),'''')CClass_id,
                   isnull((case when billtype in (150,151,155,160,161,165,171,172,173,174) then (select [name] from Company where Company_id=YA.c_id)
                                            else (select [name] from Clients where Client_id=YA.C_id) end),'''')Cname,
                   isnull((case when billtype in (150,151,155,160,161,165,171,172,173,174) then (select serial_number from Company where Company_id=YA.c_id)
                                            else (select serial_number from Clients where Client_id=YA.C_id) end),'''')cserial_number,
                   isnull(E.[name],'''')Ename,      isnull(E.Class_id,'''')EClass_id,
                   isnull(IE.[name],'''')IEname,    isnull(IE.Class_id,'''')InputmanClass_ID,
                   isnull(AE.[name],'''')AEname,    isnull(AE.Class_id,'''')AEClass_id,
                   y.Ytype,y.superior_id,y.class_id
         FROM 
            (select b.billid,b.billtype,b.billdate,b.billnumber,b.inputman,b.auditman,b.note,b.summary,b.billstates,B.invoice
                    ,p.jdmoney,p.a_id,b.Y_id,b.e_id,p.C_id
               from (select billid, a_id, c_id, sum(jdmoney) jdmoney from Accountdetail group by a_id, c_id, billid) p  
               left join billidx b  ON p.billid=b.billid
              where b.billstates in (0) and b.billdate BETWEEN '+CHAR(39)+convert(VARCHAR(10),@BeginDate,20)
                                      +CHAR(39)+' and '+CHAR(39)+convert(VARCHAR(10),@EndDate,20)+CHAR(39)+
            ' )YA 
         LEFT JOIN Account A ON YA.a_id=A.account_id
         LEFT JOIN Company Y ON YA.Y_id=Y.company_id
         LEFT JOIN Clients C ON YA.C_ID=C.Client_id
         LEFT JOIN employees E  ON YA.e_id=E.emp_Id
         LEFT JOIN employees IE ON YA.inputman=IE.emp_id
         LEFT JOIN employees AE ON YA.auditman=AE.emp_id  
      )P
   left join (select a_id,bill_id,max(comment1) as comment1  from Financebill Group by a_id,bill_id)f on p.a_id=f.a_id and p.billid=f.bill_id 
    
      WHERE ('+cast(@Yid as varchar(100))+'=0 or (p.Y_id='+cast(@Yid as varchar(100))+' or (p.superior_id='+cast(@Yid as varchar(100))+' and p.yType=1)) )'

/*    WHERE  ('''+@nYClassid+'''='''' or p.YClass_id like '''+@nYClassid+'%'')*/
/*'*/
               
		
/*加入科目的条件  */
  IF @szAClass_ID = @ArTotal_Id or @szAClass_ID=@ApTotal_Id
  begin
	if @isaddDate = 0
	  SET @SQLScript=@SQLScript+' and p.aClass_ID IN ('
		+CHAR(39)+@ApTotal_Id+CHAR(39)+','+CHAR(39)+@ArTotal_Id+CHAR(39)+')'
	else
	  SET @SQLScript=@SQLScript+' and p.aClass_ID = '
		+CHAR(39)+@szAClass_ID+CHAR(39)
  end
  ELSE
	  SET @SQLScript=@SQLScript+' and LEFT(p.aClass_ID,LEN('+CHAR(39)+@szAClass_ID+CHAR(39)+'))='+CHAR(39)
    +@szAClass_ID+CHAR(39)

/*加入单位的条件  */
  IF @szCClass_ID<>''
	  SET @SQLScript=@SQLScript+' and LEFT(p.cClass_ID,LEN('+CHAR(39)+@szCClass_ID+CHAR(39)+'))='+CHAR(39)
    +@szCClass_ID+CHAR(39)

/*加入经手人的条件  */
  IF @szEClass_ID<>''
	  SET @SQLScript=@SQLScript+' and LEFT(p.[EClass_ID], LEN('+CHAR(39)+@szEClass_ID+CHAR(39)+'))='+CHAR(39)+@szEClass_ID+CHAR(39)

/*加入制单人的条件  */
  IF @szIClass_ID<>''
	  SET @SQLScript=@SQLScript+' and LEFT(p.[InputmanClass_ID], LEN('+CHAR(39)+@szIClass_ID+CHAR(39)+'))='+CHAR(39)+@szIClass_ID+CHAR(39)

/*加入摘要说明条件*/
  if @szSummary<>'' 
          SET @SQLScript=@SQLScript+' AND ((p.billtype<>90 and p.[note]  like '''+@szSummary +'%'') or (p.billtype=90 and f.comment1 like '''+@szSummary +'%''))' 

/*加入单据类型的条件  */
  IF @nBillType<>0 SELECT @SQLScript=@SQLScript+'AND p.[billtype]='+CAST(@nBillType AS VARCHAR)

/*加入分支机构 zh100928*/
  if @nYClassid<>0 select @SQLScript=@SQLScript+'and p.class_id='+@nYClassid

  IF @employeestable<>0 
  SELECT @SQLScript=@SQLScript+' and p.E_id in (select [id] from #employeestable)'
  
  IF @ClientTable<>0  
  SELECT @SQLScript=@SQLScript+' AND P.c_id in (select [id] from #Clienttable)'
  
  IF @Companytable<>0 
  SELECT @SQLScript=@SQLScript+' AND P.Y_id in (select [id] from #Companytable)'   

/*加入排序的条件*/
  IF @nOrderType=0 SELECT @SQLScript=@SQLScript+' ORDER BY p.[billdate]'
  ELSE SELECT @SQLScript=@SQLScript+' ORDER BY p.[auditdate]'


  /*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO Succee

Succee:
  RETURN 0
GO
