create procedure TS_E_SdfBaseInfoCheck
  @pname varchar(100),
  @p_id   int =0,
  @BatchNo varchar(100)
as
begin
     set @pname = '%'+ @pname+ '%'
	 if @BatchNo=''
     begin
		select * from SFDA_SingleCodeRelation  where product_id=@p_id or physicName like @pname
     end
     else
     begin
	    select * from SFDA_SingleCodeRelation  where (product_id=@p_id or physicName like @pname) and (produceBatchNo=@BatchNo)
     end
end
GO
