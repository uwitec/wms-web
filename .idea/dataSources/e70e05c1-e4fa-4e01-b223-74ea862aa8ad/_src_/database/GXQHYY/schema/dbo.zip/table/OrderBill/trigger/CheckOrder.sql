


CREATE	TRIGGER CheckOrder ON [dbo].[OrderBill]
FOR  UPDATE
AS
declare @nbillid numeric(10,0)
if update(comeqty)
begin
 select @nbillid=bill_id from deleted
 if exists(select * from orderbill where quantity>comeqty and bill_id=@nbillid)
 begin
   update orderidx set billstates='3' where billid=@nbillid
   update orderdraft set comeqty=b.ComeQty from orderdraft a,inserted b where a.orgsmb_id=b.smb_id
 end else
 begin
   update orderidx set billstates='0' where billid=@nbillid
   delete from orderdraft where bill_id=@nbillid
 end
  
  
end
GO
