

CREATE PROCEDURE Ts_K_PurchaseBackAnalysis(
	@Begin               DATETIME, 
	@End                 DATETIME, 
	@YId                 INT, 
	@PId                 INT, 
	@SupplierId          INT, 
	@Factory             VARCHAR(100), 
	@EId                 INT, 
	@CgId                INT, 
	@szID                VARCHAR(7000),     /*选择的商品类别id串*/
    @CCgId               INT, 
	@szCID               VARCHAR(7000),      /*选择的机构类别id串*/
	@strBusinessType     varchar(50)
)
AS
BEGIN
	DECLARE @ProductList TABLE (CgId INT, PId INT)
	DECLARE @SupplierList TABLE (CgId INT, CId INT)
	DECLARE @BaseType INT
	DECLARE @ClassId VARCHAR(30)
	set @strBusinessType = @strBusinessType+',5'
	
	IF @szID = ''
	BEGIN
		INSERT INTO @ProductList(CgId, PId)
		SELECT 0, product_id FROM vw_Products	
	END
	ELSE
	BEGIN
	/*都知道具体的id了，没得必要再用class_id 去关联了*/
		/*SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CgId*/
		
		INSERT INTO @ProductList(CgId, PId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (0, -1) AND  cm.BaseTypeid = 0 AND
			  (@szID = '' OR cg.id IN (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szID)))	 and cm.deleted=0
	END
	
	IF @szCID = ''
	BEGIN
		INSERT INTO @SupplierList(CgId, CId)
		SELECT 0, client_id FROM vw_Clients	
	END
	ELSE
	BEGIN
		/*SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CCgId*/
		
		INSERT INTO @SupplierList(CgId, CId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE  cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (1, -1) AND cm.BaseTypeid = 1 AND 
			  (@szCID = '' OR cg.id IN (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szCID)))	 and cm.deleted=0
	END
	
	SELECT s.p_id AS PId, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea, u.name AS UnitName, p.Factory, 
	       b.billnumber, s.instoretime, b.billdate, s.taxmoney,
	       CAST(DATEDIFF(DAY, s.instoretime, GETDATE()) AS INT) AS StockCycle, ISNULL(bb.quantity, 0.00) AS PurchaseQty,
	       CASE WHEN s.makedate < 10 THEN '' ELSE CONVERT(varchar(100), s.makedate, 23) END AS MakeDate, s.batchno, 
	       CASE WHEN s.validdate < 10 THEN '' ELSE CONVERT(varchar(100), s.validdate, 23) END AS ValidDate,
	       s.quantity, s.buyprice, s.total, s.taxrate * 100 AS taxrate, s.taxprice, s.taxtotal, 
	       CASE WHEN ISNULL(bb.quantity, 0.00) <> 0 THEN ROUND(s.quantity * 100 / ISNULL(bb.quantity, 0.00), 2) ELSE 0 END AS BackRate,  
	       e.name AS EName, CASE WHEN b.billtype IN (21) THEN c.name ELSE y.name END AS SupplierName,
	       ISNULL(g.ReturnReason, s.comment) AS BackReason, s.supplier_id
	INTO #TMP
		FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		               INNER JOIN products p ON s.p_id = p.product_id
		               INNER JOIN unit u ON p.unit1_id = u.unit_id
		               INNER JOIN employees e ON b.e_id = e.emp_id
		               LEFT JOIN clients c ON s.supplier_id = c.client_id
		               LEFT JOIN company y ON b.c_id = y.company_id
		               INNER JOIN @ProductList pp ON s.p_id = pp.PId
		               /*INNER JOIN @SupplierList cc ON s.supplier_id = cc.CId*/
		               LEFT JOIN buymanagebill bb ON s.orgbillid = bb.smb_id
		               LEFT JOIN (SELECT b.YrowGuid, b.ReturnReason
		                            FROM gspbillidx a INNER JOIN gspbilldetail b ON a.Gspbillid = b.Gspbill_id 
		                          WHERE a.BillType = 561 and b.YrowGuid <> '00000000-0000-0000-0000-000000000000' GROUP BY b.YrowGuid, b.ReturnReason) g ON s.YGuid = g.YrowGuid
	WHERE b.billtype IN (21, 221) AND b.billstates = 0 AND b.billdate BETWEEN @Begin AND @End AND
	      b.Y_ID = @YId AND (@EId = 0 OR @EId = b.e_id) AND (@SupplierId = 0 OR @SupplierId = s.supplier_id) AND
	      (@PId = 0 OR @PId = s.p_id) AND (@Factory = '' OR p.Factory LIKE '%' + @Factory + '%')
	      and ((bb.AOID is null) or (bb.AOID in(select szTYPE from DecodeToStr(@strBusinessType)))) /*不调原单时bb.AOID is null*/
	    
	      
	    SELECT * FROM #TMP WHERE supplier_id in (select distinct cid from @SupplierList) or supplier_id = 0
END
GO
