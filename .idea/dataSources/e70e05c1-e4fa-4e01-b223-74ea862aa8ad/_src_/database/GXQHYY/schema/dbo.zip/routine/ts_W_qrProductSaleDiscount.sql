
create proc ts_W_qrProductSaleDiscount
(
        @szPclass_id              varchar(30)='',
	@szCClass_id		  varchar(30)='',
        @szSClass_id		  varchar(30)='',	
        @szEClass_id		  varchar(30)='',
	@szInputClass_id	  varchar(30)='',
        @nYClassID                varchar(50)='',
	@szParid   	          VARCHAR(30)='000000',
	@szListFlag               CHAR(1)='L',
        @nloginEID                int=0,
	@BeginDate 		  datetime,
	@EndDate	 	  datetime
        /* @nMode                    int=0  0:商品销售折扣统计,1:客户销售折扣统计,2:职员销售折扣统计  */
)
/*with encryption*/
as 
/*Params Ini begin*/
if @szPclass_id is null  SET @szPclass_id = ''
if @szCClass_id is null  SET @szCClass_id = ''
if @szSClass_id is null  SET @szSClass_id = ''
if @szEClass_id is null  SET @szEClass_id = ''
if @szInputClass_id is null  SET @szInputClass_id = ''
if @nYClassID is null  SET @nYClassID = ''
if @szParid is null  SET @szParid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
set nocount on
Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int

if @szPclass_id=''     select @szPclass_id='%%' else select @szPclass_id=@szPclass_id+'%'
if @szCClass_id=''     select @szCClass_id='%%' else select @szCClass_id=@szCClass_id+'%'
if @szEClass_id=''     select @szEClass_id='%%' else select @szEClass_id=@szEClass_id+'%'
if @szSClass_id=''     select @szSClass_id='%%' else select @szSClass_id=@szSClass_id+'%'
if @szInputClass_id='' select @szInputClass_id='%%' else select @szInputClass_id=@szInputClass_id+'%'
if @nYClassID=''       select @nYClassID='%%' else select @nYClassID=@nYClassID+'%'

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

/*单据统计：零售单，零售退货单，销售出库单，销售退货单，委托代销结算单，销售结算调价单，销售退货结算调价单*/

  select a.* into #psalediscount from  
   (select p.product_id,p.class_id,p.Parent_ID,p.child_number,p.serial_number,p.name,p.alias,p.standard,p.permitcode,p.trademark,p.makearea,p.comment,p.inputdate,p.inputman,
          p.deleted,p.custompro1,p.custompro2,p.custompro3,p.custompro4,p.custompro5,
          sum(isnull(t.quantity,0)) as quantity,
          sum(isnull(t.costtotal,0)) as costtotal,
          sum(isnull(t.totalmoney,0)) as totalmoney,
          sum(isnull(t.discountprice,0)) as discountprice,
          sum(isnull(t.discountmoney,0)) as discountmoney,
          sum(isnull(t.taxtotal,0)) as taxtotal,
          sum(isnull(t.retailtotal,0)) as retailtotal,
          case sum(isnull(t.costtotal,1)) when 0 then 0 else  sum(isnull(t.discountmoney,0))/sum(isnull(t.costtotal,1))*100 end as discountrate/*zjx--20170314--tfs46292--处理遇到零除错误*/
          /*isnull(t.discountrate,0)discountrate */
    from (select * from products where class_id like @szPclass_id and deleted=0 and IsSplit=0 ) p /*zjx-20170301--tfs45920--处理不统计拆零商品*/
    left join 
	  (select 
	  sm.Pclass_id,
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.quantity else -sm.quantity end),0) as quantity,
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.quantity*sm.costprice else -sm.quantity*sm.costprice end),0) as costtotal,  /*销售成本*/
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.total else -sm.total end),0) as totalmoney, /*销售总金额*/
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.totalmoney else -sm.totalmoney end),0) as discountprice,/*销售折后总金额*/
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.total-(sm.total * discount) else (sm.total * discount)-sm.total  end),0) as discountmoney,/*销售折扣总金额*/
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.taxtotal else -sm.taxtotal end),0) as taxtotal,/*销售含税总金额*/
	  isnull(sum(case when b.billtype in (10,12,16,112) then sm.retailtotal else -sm.retailtotal end),0) as retailtotal/*销售零售总金额*/
         /* case when (sum(case when b.billtype in (10,12,16,112) then sm.quantity*sm.saleprice else -sm.quantity*sm.saleprice end))<>0 
               then  (isnull(sum(case when b.billtype in (10,12,16,112) then sm.quantity*(sm.saleprice-sm.discountprice) 
                     else sm.quantity*(sm.discountprice-sm.saleprice) end),0)/
          sum(case when b.billtype in (10,12,16,112) then sm.quantity*sm.saleprice else -sm.quantity*sm.saleprice end)*100) else 0 end  as discountrate */ 
          from 
             (select sm.*,isnull(P.class_id,0) as Pclass_id,isnull(Re.class_id,'') as ReClass_id,isnull(Y.class_id,'') as Yclass_id,
                     isnull(s.class_id,'') as Sclass_id  FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
	             inner join products   p  on sm.p_id=p.product_id
                     left  join employees  Re on sm.RowE_id=Re.emp_id
                     left  join company    Y  on sm.Y_id   =Y.company_id
                     left  join storages   s  on sm.ss_id   =s.storage_id
              where Y.class_id like @nYClassID
                    and s.class_id like @szSClass_id
                    and Re.class_id like @szEClass_id
                    and p.class_id like @szPclass_id
                    and sm.p_id>0 and sm.aoid in (0,5)
                    and s.WholeFlag<>3/*zjx-20170301--tfs45920--处理不统计拆零商品*/
                    and ((@Companytable=0)   or (sm.Y_id    in (select [id] from #Companytable)))
                    and ((@Storetable=0)     or (sm.ss_id    in (select [id] from #storagestable)))
                    and ((@employeestable=0) or (sm.RowE_id in (select [id] from #employeestable)))                     
             )  sm            
          inner join (select b.*,isnull(c.class_id,'') as Cclass_id,isnull(Ie.class_id,'') as InputmanClass_id,isnull(Y.class_id,'') as Yclass_id
                      from billidx b      
                      left join clients    c  on b.c_id    =c.client_id
                      left join employees  Ie on b.inputman=Ie.emp_id
                      left join company    Y  on b.Y_id    =Y.company_id
                      where Y.class_id like @nYClassID
                            and b.billtype in (12,13,10,11,112,16,17)
                            and b.billdate between @BeginDate and @EndDate
                            and b.billstates=0
                            and c.class_id like @szCClass_id
                            AND ((@ClientTable=0) or (b.c_id in (select [id] from #Clienttable)))
                            and Ie.class_id like @szInputClass_id
                     )b 
          on sm.bill_id=b.billid         
          group by sm.Pclass_id
          ) t 
   ON LEFT(T.[PClass_ID], LEN(P.[Class_ID]))=P.[Class_ID]
   group by 
    p.product_id,p.class_id,p.Parent_ID,p.child_number,p.serial_number,p.name,p.alias,p.standard,p.permitcode,p.trademark,p.makearea,p.comment,p.inputdate,p.inputman,
    p.deleted,p.custompro1,p.custompro2,p.custompro3,p.custompro4,p.custompro5
   )a

IF @szListFlag='L'
    select * from  #psalediscount p WHERE  p.[Parent_ID] = @szParid  order by p.product_id
    
IF @szListFlag='A'
    select * from  #psalediscount p WHERE P.[Child_Number]=0  order by p.product_id

IF @szListFlag='P'
    select * from  #psalediscount p WHERE LEFT(P.[Class_ID], LEN(@szParid))=@szParid AND P.[Deleted]=0 AND P.[Child_Number]=0 order by p.product_id
GO
