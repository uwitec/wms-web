
CREATE  PROCEDURE  TS_L_CTIntegralchange
(   @CTid  int,
    @tabletype  int=1,   /*1 查询商品兑换积分；*/
    @pclassid  varchar(50),
    @IntegralMoney  numeric(25,8)    output
)
AS
   declare @szsql varchar(8000)
   declare @Pcid varchar(100)
   declare @money numeric(25,8)
   declare @Iid  int
   declare @nPid int
    /*今日农历天*/
   DECLARE @LunarDay VARCHAR(10) 
   SELECT @LunarDay = SUBSTRING(LunarDate, CharIndex('月', LunarDate) + 1, 2) FROM TBLunarData WHERE SolarDate = Convert(VARCHAR(100), GETDATE(), 23)
   
   /*当前机构*/
   DECLARE @YID INT
   select @YID = sysvalue from sysconfig where sysname = 'Y_ID'
   /*传入商品*/
   select @nPid = product_id from products where class_id = @pclassid
   
   select @money=isnull(ExchangeIntegral,-1) from CTExchangeIntegral 
     where ct_id = @CTid and p_id = @nPid
       and ((ISNULL(YIDS, '') = '') OR (',' + YIDS + ',' like '%,' + CAST(@YID AS VARCHAR) + ',%')) /*指定分支机构*/
       and ((Ytype <= 0) OR EXISTS(select baseinfo_id from customCategoryMapping where category_id in /*机构类别，改为自定义类别*/
                                       (
                                         select cc2.id from customCategory cc1 left join customCategory cc2 on cc2.class_id like cc1.class_id + '%' where cc1.id = CTExchangeIntegral.YType
                                       ) 
                                       and baseinfo_id = @YID
                                   )
            )  /*指定机构类别*/
       and deleted = 0 /*未删除*/
       and ((BeginDate = 0) or (GetDate() >= BeginDate)) /*开始日期*/
       and ((EndDate = 0) or (GetDate() < EndDate + 1))  /*结束日期*/
       and AuditMan > 0 /*已审核*/
       and ISNULL([Status], 0) = 0 /*未停用       */
       and ((DateLimite = 0) /*无日期限定*/
             or
            ((DateLimite = 1) and (DateType = 1) and  (CharIndex(',' + CAST(DATEPART(DD, GETDATE()) AS VARCHAR) + ',', ',' + DateStr + ',') > 0)) /*公历*/
             or 
            ((DateLimite = 1) and (DateType = 2) and  (CharIndex(',' + @LunarDay + ',', ',' + DateStr + ',') > 0)) /*农历*/
             or
            ((DateLimite = 1) and (DateType = 3) and  (CharIndex(',' + CAST(DATEPART(DW, GETDATE())-1 AS VARCHAR) + ',', ',' + DateStr + ',') > 0)) /*星期几*/
           ) 
                                
   
/*   
   set @Iid=(select MAX(I_id) from INTEGRALCONTACT where ctype=2 and c_id=@CTid and I_id in(select I_id from CTExchangeIntegral where p_id = @nPid))

if @tabletype=1

select @money=isnull(a.ExchangeIntegral,-1)  
        from (
             select distinct  a.ExchangeIntegral,a.p_id,b.class_id--,c.c_id--,d.y_id
             from  CTExchangeIntegral a
             inner join Products b         on a.p_id=b.product_id
             inner join Integralcontact c  on a.I_id=c.I_id
             inner join vw_Integralcontact d on d.ct_id=c.c_id
             where c.c_id=@CTid and b.class_id=@pclassid and b.deleted=0 and a.I_id=@Iid
             )a  
*/             
       
   if isnull(@money,-1)<=0
   begin
      select @Pcid=left(@Pclassid,len(@Pclassid)-6)
      
      if isnull(@Pcid, '')<>''
        exec TS_L_CTIntegralANDDiscountOther @CTid , @tabletype , @pcid , @Integralmoney out
      else 
        select @Integralmoney=-1 
   end
   else
   begin
    select @IntegralMoney=@money     
   end
GO
