
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-10*/
/* Description:	写入巡店日志*/
/* =============================================*/
CREATE PROCEDURE TS_H_GoRoundIns 
	@Act			int,
	@R_ID			int,
	@BeginTime		datetime,
	@EndTime		datetime,
	@E_ID			int,
	@C_ID			int,
	@Comment		varchar(500) = ''
AS
BEGIN
/*Params Ini begin*/
if @Comment is null  SET @Comment = ''
/*Params Ini end*/
	SET NOCOUNT ON;

	if @E_ID = 0
	begin
		raiserror('未选择职员！', 16, 1)
		return 0
	end
	if @C_ID = 0
	begin
		raiserror('未选择门店！', 16, 1)
		return 0
	end
	if @Act = 0
	begin
		insert into empgoround(
			emp_id,
			c_id,
			Begintime,
			endtime,
			comment
		) values(
			@E_ID,
			@C_ID,
			@BeginTime,
			@EndTime,
			@Comment
		)
		return @@identity
	end
	else
	if @Act = 1
	begin
		update empgoround set
			emp_id = @E_ID,
			c_id = @C_ID,
			Begintime = @BeginTime,
			endtime = @EndTime,
			comment = @Comment
		where r_id = @R_ID
		return @@rowcount
	end
END
GO
