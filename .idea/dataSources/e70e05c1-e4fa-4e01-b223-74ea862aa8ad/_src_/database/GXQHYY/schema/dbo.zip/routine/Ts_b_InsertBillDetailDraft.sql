
CREATE		  proc Ts_b_InsertBillDetailDraft
(
@nRET	INT OUTPUT,
@nTableTAG INT,
@nID  INT,
@bill_id  INT,
@a_id  INT,
@p_id  INT,
@batchno  VARCHAR(20),
@quantity  numeric(25,8),
@costprice  numeric(25,8),
@price	numeric(25,8),
@total	numeric(25,8),
@discount  numeric(25,8),
@discountprice	numeric(25,8),
@totalmoney  numeric(25,8),
@taxprice  numeric(25,8),
@taxtotal  numeric(25,8),
@taxmoney  numeric(25,8),
@retailprice  numeric(25,8),
@retailtotal  numeric(25,8),
@makedate  DATETIME,
@validdate  DATETIME,
@qualitystatus	VARCHAR(20),
@price_id  INT,
@ss_id	INT,
@sd_id	INT,
@order_id INT,
@location_id  INT,
@b_id  INT,
@commissionflag  TINYINT,
@comment  VARCHAR(255),
@unitid  INT,
@taxrate  numeric(25,8),
@location_id2 INT,
@iotag INT,
@invoiceTotal numeric(25,8),
@OrgBillID INT,
@jsPrice numeric(25,8),
@nCheckQty int=1,
@AOID INT=0,
@SendQTY numeric(25,8)=0,
@SendCostTotal numeric(25,8)=0,
@PriceType INT=0,
@RowE_ID int = 0,
@YGUID   uniqueidentifier=null,
@YCostPrice varchar(50)='0',
@INVOICENO varchar(50)='',/*该字段标识:机构单据是手工录入的还是其他机构传输的*/
@Y_ID INT = 0,
@InStoreTime DateTime =0,
@CXTYPE int = 0,
@comment2 varchar(200)='', /*备注二*/
@scomment varchar(80) = '',		/* 批次备注*/
@batchprice numeric(25,8) = 0,			/* 批次限价*/
@batchbarcode varchar(80) = '',	/* 批次条码*/
@cxGuid uniqueidentifier = 0x0,
@Conclusion VARCHAR(200) = '', /*质量结论*/
@IdNo varchar(20)='',/*身份证号码*/
@FactoryId int =0,    /*生产厂家id*/
@costtaxrate numeric(25,8) = 0 ,   /*成本税率*/
@costtaxprice numeric(25,8) = 0,  /*成本单价*/
@costtaxtotal numeric(25,8) = 0   /*成本金额*/
)

/*with encryption*/
AS
/*Params Ini begin*/
if @nCheckQty is null  SET @nCheckQty = 1
if @AOID is null  SET @AOID = 0
if @SendQTY is null  SET @SendQTY = 0
if @SendCostTotal is null  SET @SendCostTotal = 0
if @PriceType is null  SET @PriceType = 0
if @RowE_ID is null  SET @RowE_ID = 0
if @YGUID is null  SET @YGUID = null
if @YCostPrice is null  SET @YCostPrice = '0'
if @INVOICENO is null  SET @INVOICENO = ''
if @Y_ID is null  SET @Y_ID = 0
if @InStoreTime is null  SET @InStoreTime = 0
if @CXTYPE is null  SET @CXTYPE = 0
if @comment2 is null  SET @comment2 = ''
if @scomment is null  SET @scomment = ''
if @batchprice is null  SET @batchprice = 0
if @batchbarcode is null  SET @batchbarcode = ''
if @cxGuid is null  SET @cxGuid = 0x0
IF @Conclusion IS NULL SET @Conclusion = ''
if @FactoryId is null  SET @FactoryId = 0
if @costtaxrate is null  SET @costtaxrate = 0
if @costtaxprice is null  SET @costtaxprice = 0
if @costtaxtotal is null  SET @costtaxtotal = 0
/*Params Ini end*/
SET NOCOUNT ON


if @makedate<10 set @makedate=0
if @validdate<10 set @validdate=0

SET @nRET = -1
/*批次:入库时间只精确到天*/
set @InStoreTime = (DATENAME(Year, @InStoreTime) + '-' + DATENAME(Month, @InStoreTime) + '-' + DATENAME(Day, @InStoreTime))
/*mixb修改*/
declare @billtype int, @nE_ID int, @nSin_id int, @c_id int,@Newbilltype int
declare @RowGUID uniqueidentifier, @szError varchar(200), @szErrQty varchar(100)/*处理出错提示*/
DECLARE @dtBillDate datetime
set @nE_ID=0
set @billtype = 0
/*mxb:如果单据是销售定单,采购计划,采购定单,则明细单据经手人不能从billdraftidx取.*/
    IF @nTableTag = 4
    BEGIN
		select @dtBillDate = billdate, @c_id = c_id, @billtype=isnull(billType,0), @nE_ID = isnull(E_ID, 0), @nSin_id = sin_id from orderidx where billid=@bill_id
    END
    ELSE
    IF @nTableTAG IN (5, 25, 40)
    BEGIN
    	select @dtBillDate = billdate, @c_id = c_id, @billtype=isnull(billType,0), @nE_ID = isnull(E_ID, 0), @nSin_id = sin_id from retailbillidx where billid=@bill_id
    END
    ELSE
    BEGIN	
    	select @dtBillDate = billdate, @c_id = c_id, @billtype=isnull(billType,0), @nE_ID = isnull(E_ID, 0), @nSin_id = sin_id from billdraftidx where billid=@bill_id
    END
   
if @RowE_ID = 0 set @RowE_ID = @nE_ID  /*默认为表关经手人*/
if @billtype in (152,157)
begin
  if @sd_id =0 set @sd_id = @nSin_id
end

declare @nLocalYid int
select @nLocalYid = sysvalue from sysconfig where sysname = 'y_id'

declare @DBqty numeric(25,8)    /*调拨入库数量，用于启用仓库管理控制时回写调拨入库数量，增加可开数量 add by luowei 2012-12-12 */
set @DBqty = 0

/* 启用标准GSP流程*/
DECLARE @nStandardGSP VARCHAR(2), @nGspOrderProcess int
SELECT @nStandardGSP = sysvalue FROM sysconfigtmp WHERE sysname = 'GspStandardProcess'
SELECT top 1 @nGspOrderProcess = cast(sysvalue as int) FROM sysconfigtmp WHERE sysname = 'GspOrderProcess'
if @nGspOrderProcess is null set @nGspOrderProcess = 0


IF @nStandardGSP = '1'
BEGIN
	IF @billtype IN(161, 163) and @nLocalYid <> 2
	BEGIN
		 set @order_id = (SELECT orgbillid FROM buymanagebill WHERE smb_id = @OrgBillID)
		 set @OrgBillID = 0
	END
END
ELSE
BEGIN
	if @billtype = 163 and @nLocalYid <> 2	/* 自营店收货退货单门店不保存原单信息，否则不能过账*/
	begin
		 set @order_id = 0
		 set @OrgBillID = 0
	end
END

/* 根据仓库重写YID*/
IF @billtype IN (20, 11, 13, 26, 48, 150, 151, 152, 153)
BEGIN
	IF @ss_id > 0
		SELECT @Y_ID = CASE Y_ID WHEN 0 THEN @Y_ID ELSE Y_ID END FROM storages WHERE storage_id = @ss_id
END

declare @validpname varchar(200)
IF @billtype IN (20,220) and (@makedate <> 0)
begin
  if exists(select 1 from products where product_id = @p_id and (@makedate > Registervalid or @makedate > PerCodevalid) and Registervalid > 0 and PerCodevalid > 0)
  begin
    select @validpname = name from products where product_id = @p_id
    set @szError = '商品【'+@validpname+'】生产日期超出【注册证号有效期】或【批准文号有效期】'
    RAISERROR(@szError, 16, 1)
    return -100 
  end
end

IF EXISTS(SELECT 1 FROM sysconfig WHERE sysname = 'CtrlStoreCondition' AND sysvalue = '1')
BEGIN
	/*严格控制温度条件开关打开后，采购入库单控制仓库与商品温度条件一致*/
	IF (@ss_id > 0) AND (@BillType IN (20))
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM (SELECT p.StoreCondition FROM Products p WHERE p.product_id = @p_id) a 
										INNER JOIN (SELECT s.storeCondition FROM storages s WHERE s.storage_id = @ss_id) b 
												ON a.StoreCondition = b.storeCondition)
		BEGIN
			SELECT @validpname = name FROM products WHERE product_id = @p_id
			SET @szError = '第 ' + CAST(@nID AS VARCHAR(10)) + ' 行商品【' + @validpname + '】温度条件与仓库温度条件不一致！'
			RAISERROR(@szError, 16, 1)		
		END		
	END
END
  
IF @billtype IN (14)/*销售订单不能选择不合格品库中的商品库存*/
BEGIN
	IF EXISTS(SELECT 1 FROM storages s WHERE s.storage_id = @ss_id AND s.qualityFlag = 1)
	BEGIN
		DECLARE @SSName VARCHAR(100)
		SELECT @SSName = s.name FROM storages s WHERE s.storage_id = @ss_id
		SET @szError = '仓库“' + @SSName + '”的仓库类型是不合格品库，不允许销售！'
		RAISERROR(@szError, 16, 1)
        RETURN -100 	
	END
end

if @billtype in (20,22) /*--------检查商品GMP剂型有效期 add by luowei 2013-08-11*/
begin
  declare @mt_id int
  declare @mtname varchar(20)
  select @mt_id = medtype from vw_Products where product_id = @p_id
  select @mtname = name from customCategory where id = @mt_id and Typeid=2
  
  if exists(select 1 from gspalert where mt_id > 0 and CType = 0 
			and CAST(SUBSTRING(CONVERT(VARCHAR,GETDATE(),121),1,10) AS DATETIME) > D10 
			and mt_id =@mt_id  and c_id = @c_id ) 
  begin
    set @szError = '商品剂型: 【'+@mtname+'】GMP证书效期过期，不能选择该剂型的商品!'
     RAISERROR(@szError, 16, 1)
    return -100
  end			
end


if  @nTableTAG=4  /*-订单*/
begin
 select @billtype = billtype from orderidx where billid =@bill_id
end 

declare @IdentityCardBuyLimit int /*身份证限量开关标记 zfl*/
select @IdentityCardBuyLimit = sysvalue from sysconfigtmp where SYSNAME = 'IdentityCardBuyLimit'
if (@IdentityCardBuyLimit = 1) and (@billtype IN (12))  /*以身份证为条件来限量 zfl,开关开启且仅控制零售单*/
BEGIN
    declare @ctype_id int
    select @ctype_id = isnull(clienttype_id,0) from clients where client_id = @c_id
	DECLARE @QtyLimit numeric(25,8), @QtyAll numeric(25,8)
	DECLARE @nMonthCount int
	DECLARE @nMonthQty numeric(25,8)
	DECLARE @nMonthCountHis int
	DECLARE @nMonthQtyHis numeric(25,8)
    SELECT TOP 1 @QtyLimit = ISNULL(b.Qty, 9999999), @nMonthCount = ISNULL(b.MonthCount, 0), @nMonthQty = ISNULL(b.MonthQty, 0)
	FROM BillProductLimit b, products p  
	WHERE b.PId = p.product_id AND p.cldw <> @unitid AND b.PId = @p_id AND b.[Deleted] = 0 AND b.BillType = 12 AND 
		  b.YId = @Y_ID AND b.BeginTime <= GETDATE() AND b.EndTime >= GETDATE() AND 
		  (b.ctype_id = @ctype_id or b.ctype_id = 0) order by b.ctype_id desc	

	SELECT @QtyAll = ISNULL(SUM(r.quantity), 0) FROM RetailBill r WHERE r.bill_id = @bill_id AND r.p_id = @p_id	
		
	SET @QtyAll = @QtyAll + @quantity
	
	IF @QtyAll > @QtyLimit 
	BEGIN
		SET @nRet = - @p_id
		DECLARE @ZK_PName VARCHAR(100)
		SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
		SET @szError = '商品【' + @ZK_PName + '】的开票数量大于身份证每单限量 '+ CAST(@QtyLimit AS VARCHAR(24))+'(基本数量)。' 
		RAISERROR(@szError, 16, 1) 
		RETURN -100	
	END
	ELSE
	/* 每月限量*/
	BEGIN
		DECLARE @dtBegin datetime
		DECLARE @dtEnd datetime
		SET @dtBegin = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-01' AS datetime)
		SET @dtEnd = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-' + CAST(DBO.DaysThisMonth(@dtBillDate) AS VARCHAR(2)) AS datetime)
		/* 设置每月限次后才读取当月次数*/
		IF @nMonthCount > 0
		BEGIN
			SELECT @nMonthCountHis =  count(distinct Gspbill_id)  from GSPCompy com inner join billidx idx on com.Gspbill_id = idx.billid 
				 where IDNumber=@IdNo 
				and idx.billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND com.Gspbill_Type = 12
				AND billid IN (SELECT s.bill_id FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id) /*AND c_id = @c_id*/
			IF @nMonthCountHis >= @nMonthCount
			BEGIN
				SET @nRet = - @p_id
				SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
				SET @szError = '商品【' + @ZK_PName + '】的开票次数大于身份证每月限次 '+ CAST(@nMonthCount AS VARCHAR(24))+'。' 
				SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthCountHis AS VARCHAR(24)) + ' 次'
				RAISERROR(@szError, 16, 1) 
				RETURN -100	
			END
		END

		/* 设置每月限量后才读取当月销量*/
		IF @nMonthQty > 0
		BEGIN
			SELECT @nMonthQtyHis = ISNULL(SUM(s.quantity), 0) FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id AND s.bill_id IN
				(SELECT BILLID FROM billidx idx inner join GSPCompy com on idx.billid=com.Gspbill_id WHERE IDNumber=@IdNo and billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND billtype = 12) /*AND c_id = @c_id)*/
			IF @nMonthQtyHis + @quantity > @nMonthQty 
			BEGIN
				SET @nRet = - @p_id
				SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
				SET @szError = '商品【' + @ZK_PName + '】的开票数量大于身份证每月限量 '+ CAST(@nMonthQty AS VARCHAR(24))+'。'
				SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthQtyHis AS VARCHAR(24))
				RAISERROR(@szError, 16, 1) 
				RETURN -100	
			END
		END
	END 
end
else /*按照原来的特殊商品每单限量*/
begin
    IF @billtype IN (10,12,14)  /*特殊商品每单限量(add by luowei 2013-08-12 增加往来单位类型判断,有单位类型的商品优先于没有单位的商品)*/
	BEGIN
		select @ctype_id = isnull(clienttype_id,0) from clients where client_id = @c_id
		SELECT TOP 1 @QtyLimit = ISNULL(b.Qty, 9999999), @nMonthCount = ISNULL(b.MonthCount, 0), @nMonthQty = ISNULL(b.MonthQty, 0)
		FROM BillProductLimit b, products p  
		WHERE b.PId = p.product_id AND p.cldw <> @unitid AND b.PId = @p_id AND b.[Deleted] = 0 AND b.BillType = @billtype AND 
			  b.YId = @Y_ID AND b.BeginTime <= GETDATE() AND b.EndTime >= GETDATE() AND 
			  (b.ctype_id = @ctype_id or b.ctype_id = 0) order by b.ctype_id desc	
		
		IF @billtype IN (12)
		BEGIN
			SELECT @QtyAll = ISNULL(SUM(r.quantity), 0) FROM RetailBill r WHERE r.bill_id = @bill_id AND r.p_id = @p_id	
			
			SET @QtyAll = @QtyAll + @quantity
		END
		ELSE
		IF @billtype IN(14)
		BEGIN
			SELECT @QtyAll = @quantity + ISNULL(SUM(r.quantity), 0) FROM OrderBill r WHERE r.bill_id = @bill_id AND r.p_id = @p_id	
		END	
		ELSE
		IF @billtype IN(10)
		BEGIN
			SELECT @QtyAll = @quantity + ISNULL(SUM(r.quantity), 0) FROM salemanagebilldrf r WHERE r.bill_id = @bill_id AND r.p_id = @p_id	
		END	
		
		IF @QtyAll > @QtyLimit
		BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			
			SET @szError = '商品【' + @ZK_PName + '】的开票数量大于特殊商品每单限量 '+ CAST(@QtyLimit AS VARCHAR(24))+'(基本数量)。' 
			
			SELECT @ZK_PName = ISNULL(g.GSPPropert, '') FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID 
			WHERE p.product_id = @p_id
			
			IF CHARINDEX('麻黄碱', @ZK_PName) > 0
				SET @szError = '含麻黄碱' + @szError
			
			RAISERROR(@szError, 16, 1) 
			RETURN -100	
		END

		/* 每月限量*/
		SET @dtBegin = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-01' AS datetime)
		SET @dtEnd = CAST(CONVERT(varchar(7), @dtBillDate, 120) + '-' + CAST(DBO.DaysThisMonth(@dtBillDate) AS VARCHAR(2)) AS datetime)
		IF @nMonthCount > 0
		BEGIN
		IF @billtype = 14
		BEGIN
			SELECT @nMonthCountHis = COUNT(1) FROM orderidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('3', '0') AND billtype = @billtype
				AND billid IN (SELECT bill_id FROM OrderBill WHERE p_id = @p_id) AND c_id = @c_id
		END
		ELSE
		BEGIN
			SELECT @nMonthCountHis = COUNT(1) FROM billidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND billtype = @billtype
				AND billid IN (SELECT s.bill_id FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id) AND c_id = @c_id
	        END
		IF @nMonthCountHis >= @nMonthCount 
		BEGIN
			SET @nRet = - @p_id
			SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
			SET @szError = '商品【' + @ZK_PName + '】的开票次数大于特殊商品每月限次 '+ CAST(@nMonthCount AS VARCHAR(24))+'。' 
			SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthCountHis AS VARCHAR(24)) + ' 次'
			RAISERROR(@szError, 16, 1) 
			RETURN -100	
		END
		END
		IF @nMonthQty > 0
		BEGIN
			IF @billtype = 14
				SELECT @nMonthQtyHis = ISNULL(SUM(quantity), 0) FROM OrderBill WHERE p_id = @p_id AND bill_id IN
					(SELECT BILLID FROM orderidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('3', '0') AND billtype = @billtype AND c_id = @c_id)
			
		ELSE
			SELECT @nMonthQtyHis = ISNULL(SUM(s.quantity), 0) FROM salemanagebill s, products p WHERE s.p_id = p.product_id AND p.cldw <> @unitid AND s.p_id = @p_id AND s.bill_id IN
					(SELECT BILLID FROM billidx WHERE billdate BETWEEN @dtBegin AND @dtEnd AND billstates IN ('0') AND billtype = @billtype AND c_id = @c_id)
		
			IF @nMonthQtyHis + @quantity > @nMonthQty
			BEGIN
				SET @nRet = - @p_id
				SELECT @ZK_PName = p.name FROM products p WHERE p.product_id = @p_id
				SET @szError = '商品【' + @ZK_PName + '】的开票数量大于特殊商品每月限量 '+ CAST(@nMonthQty AS VARCHAR(24))+'。'
				SET @szError = @szError + CHAR(13) + CHAR(10) + '当月已开 ' +  CAST(@nMonthQtyHis AS VARCHAR(24))
				RAISERROR(@szError, 16, 1) 
				RETURN -100	
			END
		END
	END                    
end 

if @billtype in (10,20,11,21, 210, 220)
begin
  declare @szGspAlert varchar(300),@szCheckValid varchar(10)

  set @szCheckValid='0'

	exec ts_getsysvalue 'GspFlowControl',@szCheckValid output 

  if @szCheckValid='1'
  begin
    exec ts_j_qrgspcheck @c_id, @p_id, @batchno, @billtype, @szGspAlert output
    if @szGspAlert<>'' 
    begin
      raiserror(@szGspAlert,16,1)
      return -100
    end
  end
end

set @RowGUID=NEWID()
	IF NOT EXISTS(SELECT 1 FROM sysconfigtmp WHERE [sysname] = 'GspStandardProcess' AND sysvalue = '1')
	BEGIN
		IF  (@billtype not in(150, 151,152, 153,160,161,162,163)) 
			SET @YGUID=@RowGUID
	END		
/*if (@billtype in(150,151,160,161, 152, 153, 162, 163)) and (@INVOICENO='1')  --这行代码会导致自营店收货退货单等单据的ycostprice不正确，导致总部退回的成本价格不对*/
if (@billtype in(150,152)) and (@INVOICENO='1')  /*收货，退货类单据不能修改ycostprice zc 2012-03-09修改*/
   SET @YCostPrice=@CostPrice
   
/*近效期商品禁止销售*/
/*-----------取零售单,合同的单据类型*/
if @nTableTag in(5,25,40) select @billtype=isnull(billType,0)from retailbillidx where billid=@bill_id
IF @nTableTag in(4) select @billtype=isnull(billType,0) from orderidx where billid=@bill_id
declare @P1 int, @PName varchar(100)
set @P1=0 set @PName=''
exec ts_M_qrStopSaleDay;1 @P1 output,@BillType,@validdate 
if (@P1=-1) 
begin
    set @nRet=-@p_id
    select @PName=[name] from products where product_id=@p_id
	set @szError = '商品【'+@PName+'】，近效期禁止商品' 
	raiserror(@szError,16,1) 
	return -100
end 

 
/*if (@InStoreTime < 1) set @InStoreTime = (DATENAME(Year, getdate()) + '-' + DATENAME(Month, getdate()) + '-' + DATENAME(Day, getdate()))*/
 

/*采购,销售单及退货单据都不写 SendQty*/
/*    210;           //  销售单*/
/*    211;           //  销售退货单*/
/*    220;           //  采购单*/
/*    221;           //  采购退货单*/
/*    11;            //  销售出库退货单*/
/*    13;            //  零售退货单*/
/*    21;            //  采购入库退货单*/
/*    111;           //  委托代销退货单*/
/*    121;           //  受托代销退货单*/
/*    54;            //  配送出库退货单*/
/*    56;            //  配送入库退货单 */
if @billtype in (220,221,210,211)
begin
  set @SendQTY=0
  set @SendCostTotal=0
end else
begin
  set @SendQty=@quantity 
  set @SendCostTotal=@costprice*@quantity
end

declare @nSaleQuantity NUMERIC(18,8),@szPname varchar(255)
declare @cUseSameCostMethod char(1),@nCostMethod char(1),@CheckSaleQty char(1), @GspStandardProcess char(1)
declare @isPAllQty int  /*是否根据批次计算可开数量，0按批次计算可开数量，　1按全部商品合计计算可开数量　zjl140105*/

	set @CheckSaleQty='0'
	exec ts_getsysvalue 'CheckSaleQty',@CheckSaleQty out/*存草稿是否检测可开数量*/
		
	exec ts_GetSystmpValue 'GspStandardProcess',0,@GspStandardProcess out, 0 
 
 /*非标准流程下，给机构发货检查赠品数量*/
 declare @giftQty numeric(25,8)  /*赠品总数*/
 declare @sendgiftQty numeric(25,8)  /*已经配送的赠品数量*/
 set @giftQty = 0
 set @sendgiftQty = 0
 if @nStandardGSP = '0' and @billtype in (150,152) and @AOID in (6,7)
 begin
    select @giftQty =isnull(SUM(QTY),0) from giftProducts 
		  where p_id =@p_id and AOID =@AOID

  		SELECT @sendgiftQty = ISNULL(SUM(CASE WHEN YPD.BILLTYPE IN (53,150,152)  THEN YPD.[SENDQTY]  ELSE - YPD.[SENDQTY]  END), 0)
		   FROM  
			 (SELECT b.billid,sm.p_id,sm.quantity,costprice,totalmoney,taxtotal,
					 sm.SendQTY,sm.SendCostTotal,B.billtype,AOID  
				FROM salemanagebill sm                  
				LEFT JOIN billidx   b  on sm.bill_id=b.billid
				LEFT JOIN Products  p  on p.product_id=SM.p_id           
				WHERE B.[billtype] IN (53,54,150,151,152,153) and
					  [Billstates]=0 AND aoid = @AOID/*aoid in (6,7) */
					  and p_id>0 and ( p_id= @p_id)
			 )YPD 
	  SET @nSaleQuantity = 	@giftQty - @sendgiftQty	 
		if @nSaleQuantity<@quantity
		  begin
		    set @nRet=-@p_id
		    select @szPname=[name] from products where product_id=@p_id
		    if @AOID = 6
			  set @szError = '第【'+cast(@nID as varchar)+'】行,商品【'+@szPname+'】的开票零成本赠品数量大于可开零成本赠品数量'+cast(@nSaleQuantity as varchar(24))+'，可能出现负库存。' 
			else
			  set @szError = '第【'+cast(@nID as varchar)+'】行,商品【'+@szPname+'】的开票有成本赠品数量大于可开有成本赠品数量'+cast(@nSaleQuantity as varchar(24))+'，可能出现负库存。' 
			raiserror(@szError,16,1) 
			return -100
		end 		 
 end     
 /* END************非标准流程下，给机构发货检查赠品数量*/
 
 
 /* XXX.2017-05-04 开启开关后，零售单检测可开数量*/

if @billtype = 12 
begin
	DECLARE @RetailCheckQty  int
	SELECT @RetailCheckQty = sysvalue FROM sysconfigtmp WHERE sysname = 'RetailCheckQty' 
	if @RetailCheckQty is null set @RetailCheckQty = 0
	if @RetailCheckQty = 1
	begin
		exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
		if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
			exec ts_getsysvalue 'CostMethod',@nCostMethod out
		else select @nCostMethod=isnull(costmethod,'0') from products where product_id=@p_id

		if @nCostMethod in ('1','2','3') and @nCheckQty=1
		begin
			select @szPname=[name] from products where product_id=@p_id
			
			set @nSaleQuantity=0

			if @costprice > 0
			begin
				select @nSaleQuantity = isnull(quantity, 0) from dbo.FN_GetAvlqty(@p_id, @ss_id, '', 157) where p_id = @p_id and s_id = @ss_id
						and costprice = @costprice and batchno = @batchno and makedate = @makedate and validdate = @validdate
						and instoretime = @InStoreTime and commissionflag = @commissionflag and Y_ID = @Y_ID and supplier_id = @b_id
						and location_id = @location_id

				if @nSaleQuantity<@quantity
				begin
					set @nRet=-@p_id
					set @szError = '第【'+cast(@nID as varchar)+'】行,商品【'+@szPname+'】的开票数量大于可开数量'+cast(@nSaleQuantity as varchar(24))+'(基本数量)，可能出现负库存。' 
					raiserror(@szError,16,1) 
					return -100
				end 
			end
		end
	end
end
    
if (@CheckSaleQty<>'0') and (@AOID not in (5,6))
begin
	/* 启用标准流程后销售出库单、自营店发货单、机构发货单、采购入库退货单不检测可开数量*/
	IF NOT ((@nStandardGSP = '1') AND @billtype IN(10, 150, 152, 21))
	BEGIN
		exec ts_getsysvalue 'UseSameCostMethod',@cUseSameCostMethod out /*是否使用同一成本核算法*/
		if @cUseSameCostMethod='1' /*系统使用统一成本核算*/
			exec ts_getsysvalue 'CostMethod',@nCostMethod out
		else select @nCostMethod=isnull(costmethod,'0') from products where product_id=@p_id
   
		if @nCostMethod in ('1','2','3') and @nCheckQty=1
		begin
			if @nTableTag in (0,1,35,2,8,4)
			begin
				select @szPname=[name] from products where product_id=@p_id
		
				set @nSaleQuantity=0

				if @costprice > 0
				begin
					if @billtype in (10,14,21,30,34,38,41,43,44,45,46,49,51,53,56,150,152,161,163,210,212, 154,157) and @iotag = 0
					begin
					  if @billtype=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
					  begin
					    select @nSaleQuantity = isnull(quantity, 0) from dbo.FN_GetAvlqty(@p_id, @ss_id, '', 41) where p_id = @p_id and s_id = @ss_id
							and costprice = @costprice and batchno = @batchno and makedate = @makedate and validdate = @validdate
							and instoretime = @InStoreTime and commissionflag = @commissionflag and Y_ID = @Y_ID and supplier_id = @b_id
							and location_id = @location_id
					  end
					  else if @billtype=157
					  begin
					    select @nSaleQuantity = isnull(quantity, 0) from dbo.FN_GetAvlqty(@p_id, @ss_id, '', 157) where p_id = @p_id and s_id = @ss_id
							and costprice = @costprice and batchno = @batchno and makedate = @makedate and validdate = @validdate
							and instoretime = @InStoreTime and commissionflag = @commissionflag and Y_ID = @Y_ID and supplier_id = @b_id
							and location_id = @location_id
					  end
					  else 
					  begin
						select @nSaleQuantity = isnull(quantity, 0) from dbo.FN_GetAvlqty(@p_id, @ss_id, '', 0) where p_id = @p_id and s_id = @ss_id
							and costprice = @costprice and batchno = @batchno and makedate = @makedate and validdate = @validdate
							and instoretime = @InStoreTime and commissionflag = @commissionflag and Y_ID = @Y_ID and supplier_id = @b_id
							and location_id = @location_id
					  end
					end
					else
						set @nSaleQuantity = @quantity
					set @DBqty = 0
					if (exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue  ='1')) and (@billtype in (10, 14))/*销售出库单草稿启用仓库管理流程时检测调拨单草稿中的可开数量 add by luowei 2012-12-14*/
					begin   
					  select @DBqty = TJDB.qty from
					  (
						  select p_id,sd_id,batchno,supplier_id,location_id2,validdate,commissionflag,costprice,instoretime,sum(quantity) as qty
						  from storemanagebilldrf mx where exists(select 1 from billdraftidx idx where idx.billid = mx.bill_id and billtype = 44)
						  and aoid in (0,7)
						  group by p_id,sd_id,batchno,supplier_id,location_id2,validdate,commissionflag,costprice,instoretime
					  ) TJDB 
					  where TJDB.p_id =@p_id  AND TJDB.sd_id = @ss_id AND TJDB.batchno = @batchno AND TJDB.supplier_id = @b_id
					AND TJDB.location_id2 = @location_id
					AND TJDB.validdate = @validdate
							  AND TJDB.commissionflag = @commissionflag AND TJDB.costprice = @costprice AND TJDB.instoretime = @InStoreTime
					end
					set @nSaleQuantity=@nSaleQuantity+@DBqty
					if @nSaleQuantity<@quantity
					begin
						set @nRet=-@p_id
						set @szError = '第【'+cast(@nID as varchar)+'】行,商品【'+@szPname+'】的开票数量大于可开数量'+cast(@nSaleQuantity as varchar(24))+'(基本数量)，可能出现负库存。' 
						raiserror(@szError,16,1) 
						return -100
					end 
				end
			end
		end
	END
end




IF @order_id IS NULL
	SET @order_id = 0

IF @nTableTag =0 
INSERT INTO buymanageBilldrf
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,buyprice  ,discount	,discountprice	,totalmoney  ,taxprice	,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total, iotag, invoiceTotal , OrgBillID,AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID, INVOICENO, Y_ID, InStoreTime, comment2, scomment, batchprice, BatchBarCode, Conclusion,FactoryId,costtaxrate,costtaxprice,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  , @order_id ,@location_id  ,@b_id  ,@commissionflag  ,@comment  ,@unitid  ,@taxrate, @qualitystatus, @total,@iotag, @invoiceTotal, @OrgBillID,@AOID,@SendQTY,@SendCostTotal,@PriceType,@RowE_id ,@YCostPrice, @RowGUID, @YGUID, @INVOICENO, @Y_ID, @InStoreTime, @comment2, @scomment, @batchprice, @batchbarcode, @Conclusion,@FactoryId,@costtaxrate,@costtaxprice,@costtaxtotal
)
ELSE IF @nTableTag  in (1,35)
begin
   if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and
      exists(select 1 from billdraftidx where billtype = 10 and billid = @bill_id)
   begin
       if (@order_id = 0) or (@order_id = 1)  /*-启用仓库流程管理 只插入新的明细和需要重新修改的明细 --add by luowei 2012-12-14   */
	   INSERT INTO salemanageBilldrf
		(
		 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,location_id  ,location_id2, supplier_id  ,commissionflag  ,comment  ,unitid	,taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID, jsprice,AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID, INVOICENO, Y_ID, InStoreTime, cxType, comment2, scomment, batchprice, BatchBarCode, CxGuid, Conclusion,Factoryid,costtaxrate,costtaxprice,costtaxtotal
		)
		VALUES
		(
		 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  , 0 ,@location_id  , @location_id2, @b_id  ,@commissionflag  ,@comment  ,@unitid  ,@taxrate, @qualitystatus, @total, @iotag, @invoiceTotal , @OrgBillID, @JsPrice,@AOID,@SendQTY,@SendCostTotal,@PriceType, @RowE_id ,@YCostPrice, @RowGUID, @YGUID, @INVOICENO, @Y_ID, @InStoreTime, @CXTYPE, @comment2, @scomment, @batchprice, @batchbarcode, @cxGuid, @Conclusion,@FactoryId,@costtaxrate,@costtaxprice,@costtaxtotal
		)
		else
		INSERT INTO salemanageBilldrf
		(
		 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,location_id  ,location_id2, supplier_id  ,commissionflag  ,comment  ,unitid	,taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID, jsprice,AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID, INVOICENO, Y_ID, InStoreTime, cxType, comment2, scomment, batchprice, BatchBarCode, CxGuid, Conclusion,Factoryid,costtaxrate,costtaxprice,costtaxtotal
		)
		VALUES
		(
		 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  , @order_id ,@location_id  , @location_id2, @b_id  ,@commissionflag  ,@comment  ,@unitid  ,@taxrate, @qualitystatus, @total, @iotag, @invoiceTotal , @OrgBillID, @JsPrice,@AOID,@SendQTY,@SendCostTotal,@PriceType, @RowE_id ,@YCostPrice, @RowGUID, @YGUID, @INVOICENO, @Y_ID, @InStoreTime, @CXTYPE, @comment2, @scomment, @batchprice, @batchbarcode, @cxGuid, @Conclusion,@FactoryId,@costtaxrate,@costtaxprice,@costtaxtotal
		)
    end		
	else
		INSERT INTO salemanageBilldrf
		(
		 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,location_id  ,location_id2, supplier_id  ,commissionflag  ,comment  ,unitid	,taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID, jsprice,AOID,SendQTY,SendCostTotal,PriceType, RowE_id, YCostPrice, RowGUID, YGUID, INVOICENO, Y_ID, InStoreTime, cxType, comment2, scomment, batchprice, BatchBarCode, CxGuid, Conclusion,Factoryid,costtaxrate,costtaxprice,costtaxtotal
		)
		VALUES
		(
		 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  , @order_id ,@location_id  , @location_id2, @b_id  ,@commissionflag  ,@comment  ,@unitid  ,@taxrate, @qualitystatus, @total, @iotag, @invoiceTotal , @OrgBillID, @JsPrice,@AOID,@SendQTY,@SendCostTotal,@PriceType, @RowE_id ,@YCostPrice, @RowGUID, @YGUID, @INVOICENO, @Y_ID, @InStoreTime, @CXTYPE, @comment2, @scomment, @batchprice, @batchbarcode, @cxGuid, @Conclusion,@FactoryId,@costtaxrate,@costtaxprice,@costtaxtotal
		)
end
ELSE IF @nTableTag =2
INSERT INTO storemanageBilldrf
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,price ,totalmoney  ,retailprice  ,retailmoney  ,makedate  ,validdate  ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid	,location_id2, qualitystatus,iotag, total, invoiceTotal , OrgBillID,Aoid,SendQTY,SendCostTotal,RowE_id,RowGUID, Y_ID, InStoreTime, scomment, batchprice, BatchBarCode,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price ,@totalmoney  ,@retailprice  ,@retailtotal , @makedate  ,@validdate  ,@price_id	,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@location_id2, @qualitystatus,@iotag, @total, @invoiceTotal ,@OrgBillID,@AOID,@SendQTY,@SendCostTotal,@RowE_id,@RowGUID, @Y_ID, @InStoreTime, @scomment, @batchprice, @batchbarcode,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag =3
INSERT INTO financebilldrf
(
 bill_id  ,a_id  ,jftotal, dftotal ,c_id ,comment1, invoiceTotal ,RowGUID, Y_ID,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@a_id  ,@total  ,@totalmoney ,@b_id  ,@comment  , @invoiceTotal ,@RowGUID, @Y_ID,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag =4
begin
	INSERT INTO ORDERBILL
	(
	 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total, RowE_id,RowGUID, Y_ID, comment2, batchbarcode, scomment, batchprice, Instoretime, location_id2, orgbillid,AOID,FactoryId,costtaxrate,costtaxprice,costtaxtotal
	)
	VALUES
	(
	 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@taxrate, @qualitystatus, @total, @RowE_id, @RowGUID, @Y_ID, @comment2, @batchbarcode, @scomment, @batchprice, @InStoreTime, @location_id2, @OrgBillID,@AOID,@FactoryId,@costtaxrate,@costtaxprice,@costtaxtotal
	)
end
ELSE IF @nTableTag in(5,25,40)
INSERT INTO RETAILBILL
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total, OrgBillID,aoid,PriceType, RowE_id, RowGUID, Y_ID, InStoreTime, cxType, scomment, batchprice, BatchBarCode, CxGuid,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@taxrate, @qualitystatus, @total, @OrgBillID,@AOID,@PriceType, @RowE_id ,@RowGUID, @Y_ID, @InStoreTime, @CXTYPE, @scomment, @batchprice, @batchbarcode, @cxGuid,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag in(37)	/*诊治费用单*/
INSERT INTO RETAILCLINICBILLDRF
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total, OrgBillID,aoid,PriceType, RowE_id, RowGUID, Y_ID, InStoreTime, cxType
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@taxrate, @qualitystatus, @total, @OrgBillID,@AOID,@PriceType, @RowE_id ,@RowGUID, @Y_ID, @InStoreTime, @CXTYPE
)
ELSE IF @nTableTag in(38)	/*挂号单*/
INSERT INTO REGISTERBILLDRF
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total, OrgBillID,aoid,PriceType, RowE_id, RowGUID, Y_ID, InStoreTime, cxType
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@taxrate, @qualitystatus, @total, @OrgBillID,@AOID,@PriceType, @RowE_id ,@RowGUID, @Y_ID, @InStoreTime, @CXTYPE
)
ELSE IF @nTableTag in(39)
begin	/*商品缺货单*/
    if @p_id = 999999999
    begin
      set @nRET =1
      return 0
    end    
	INSERT INTO ZeroStockBill
	(
	 bill_id  ,p_id ,quantity  ,unitid , aoid, comment, comment2, Y_ID,factoryid,costtaxprice,costtaxrate,costtaxtotal
	)
	VALUES
	(
	 @bill_id  ,@p_id  , @quantity  ,@unitid  ,0, @comment, @comment2, @Y_ID,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
	)
end
ELSE IF @nTableTag =6
INSERT INTO GoodsCheckBillDrf
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,buyprice  ,discount	,discountprice	,totalmoney  ,taxprice	,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  ,location_id  ,supplier_id	,commissionflag  ,comment  ,unitid  ,taxrate, qualitystatus, total,aoid, RowGUID, Y_ID, InStoreTime, scomment, batchprice, BatchBarCode,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  ,@location_id  ,@b_id  ,@commissionflag  ,@comment	,@unitid  ,@taxrate, @qualitystatus, @total,@AOID, @RowGUID ,@Y_ID, @InStoreTime, @scomment, @batchprice, @BatchBarCode,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag =7
INSERT INTO TRANBILL
(
 bill_id  ,p_id  ,quantity  ,retailprice  ,retailMoney  ,comment  ,unitid ,RowGUID , Y_ID,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@quantity  ,@retailprice  ,@retailtotal  ,@comment	,@unitid , @RowGUID, @Y_ID,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag  =8
INSERT INTO TranManageBilldrf
(
 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,saleprice  ,discount  ,discountprice  ,totalmoney  ,taxprice  ,taxtotal  ,taxmoney  ,retailprice  ,retailtotal  ,makedate  ,validdate  ,price_id  ,ss_id  ,sd_id  , order_id ,location_id  ,supplier_id  ,commissionflag  ,comment  ,unitid	,taxrate, qualitystatus, total, iotag, invoiceTotal ,OrgBillID,aoid,SendQTY,SendCostTotal,thqty, PriceType, RowE_id, RowGUID, Y_ID, InStoreTime, scomment, batchprice, BatchBarCode,factoryid,costtaxprice,costtaxrate,costtaxtotal
)
VALUES
(
 @bill_id  ,@p_id  ,@batchno  ,@quantity  ,@costprice  ,@price	,@discount  ,@discountprice  ,@totalmoney  ,@taxprice  ,@taxtotal  ,@taxmoney  ,@retailprice  ,@retailtotal  ,@makedate  ,@validdate  ,@price_id  ,@ss_id  ,@sd_id  , @order_id ,@location_id  ,@b_id  ,@commissionflag  ,@comment  ,@unitid  ,@taxrate, @qualitystatus, @total, @iotag, @invoiceTotal , @OrgBillID,@AOID,@SendQTY,@SendCostTotal,@quantity,@PriceType, @RowE_id, @RowGUID, @Y_ID, @InStoreTime, @scomment, @batchprice, @BatchBarCode,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal
)
ELSE IF @nTableTag  =9
INSERT INTO PriceBill
(
bill_id  ,p_id  ,price_id  ,comment  ,unitid	,RetailPrice	,price1	,price2	,price3	,price4	,gpprice	,glprice	,specialprice	,recprice, lowprice, Y_ID ,oldretailprice, profit, profitPercent
)
VALUES
(
 @bill_id  ,@p_id  ,@price_id  ,@comment  ,@unitid , @price, @total, @discountprice, @totalmoney ,@taxmoney, @taxprice, @taxtotal ,@retailprice, @retailtotal,@invoiceTotal, @Y_ID,@jsPrice,@costtaxtotal,@costtaxrate
)
ELSE IF @nTableTag  =20
begin
INSERT INTO PriceInquireBill
(
  bill_id, p_id, comment, unitid, price, Y_ID
)
VALUES
(
 @bill_id  ,@p_id,@comment  ,@unitid , @price, @Y_ID
)
end
else if @nTableTag = 22 /*积分兑换单*/
begin
  insert into ExIntegRalManagebilldrf
          (billid,         P_id,       u_id,            s_id,       
           quantity,   Costprice,       CostTotal,     IntegralMoney,
           IntegRalTotal,  status,     comment,	   batchno,	makedate,	validdate,	location_id,
           supplier_id,		commissionflag,		aoid,	SendQTY ,	SendCostTotal,  RowGUID, Y_ID, InStoreTime,factoryid,costtaxprice,costtaxrate,costtaxtotal)
  values
          (@bill_id,       @P_id,      @unitid,         @ss_id,
           @quantity,  @costprice,      @costprice*@quantity,    @price,
           @total,         0 ,   @comment,	@batchno,	@makedate,	@validdate,	@location_id,
           @b_id,		@commissionflag,	@aoid,	@quantity ,	@costprice*@quantity, @RowGUID, @Y_ID, @InStoreTime,@FactoryId,@costtaxprice,@costtaxrate,@costtaxtotal)
end
else if @nTableTAG =33 /*促销单据*/
begin
  insert into CxBill
  (Bill_ID,P_ID,Price_ID,UnitID,HighQty,LowQty,Discount,CxPrice,Comment)
  values
  (@bill_id,@p_id,@price_id,@unitid,@Quantity,@total,@discount,@price,@comment)
end
else if @ntabletag=34 /*返利获利*/
begin
  insert into returnbilldrf
  (Bill_ID,ret_id,p_id,saleQty,SaleTotal,RetTotal,Total,comment)
  values
  (@bill_id,@order_id,@p_id,@Quantity,@price,@total,@total,@comment)
end
ELSE RETURN -100
      
  SET @nRET = @@ROWCOUNT
/*----------启用仓库管理流程时处理正常明细，防止回滚单据   add by luowei 2012-12-18*/
if exists(select 1 from sysconfigtmp where sysname = 'storagesmanage' and sysvalue = '1') and
      exists(select 1 from billdraftidx where billtype = 10 and billid = @bill_id) and (@order_id <> 1)
  set @nRET = 1  
  
RETURN 0
GO
