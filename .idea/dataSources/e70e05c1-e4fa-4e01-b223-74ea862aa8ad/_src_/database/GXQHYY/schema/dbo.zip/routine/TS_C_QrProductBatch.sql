
/******************************************
批次选择
nMode			=0 当前库存
			=1 委托代销库存
			=2 受托代销库存
			=3 借出库存
			=4 借进库存
			=5 单品库存查询
      		=6 动态盘点选择批次 
			=7 禁止销售批次信息
********************************************/
CREATE  PROCEDURE  TS_C_QrProductBatch
( @nP_id      	INT,
  @nS_id      	INT,
  @PeriodFlag   VARCHAR(2)='',
  @nMode		INT=0,
  @nYClassid    varchar(100)='',
  @nloginEID    int=0,
  @nFilterY     int=0,  		/*1:业务单据选择批次,只能选择本机构的批次//放到客户端处理*/
  @SfdaCode     VARCHAR(20) = '',/*零售单输入的电子监管码*/
  @nVchtype     int=0/*单据类型*/
)   
/*with encryptiON      */
AS
/*Params Ini begin*/
if @PeriodFlag is null  SET @PeriodFlag = ''
if @nMode is null  SET @nMode = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @nFilterY is null  SET @nFilterY = 0
IF @SfdaCode IS NULL SET @SfdaCode = ''
/*Params Ini end*/

SET NOCOUNT ON


  Declare @Companytable int,@Storetable int,@ClientTable INTEGER
  Declare @isfinally int
  declare @multselectS int
  
  declare @wholeflag int
  if @nVchtype=0 /*-不合格报损审批表和不合格报溢审批表单据类型为0则设置一个单据类型*/
  begin
     set @nVchtype=41
  end
  set @multselectS=0
  select @multselectS=ISNULL(sysvalue,0) from sysconfigtmp where sysname='MultBatchSelect'/*零售单多仓库发货*/
  
  if @multselectS = 1 and @nMode <> 6 
  begin
    select @wholeflag=WholeFlag from storages where storage_id=@nS_id
    if @wholeflag=3 
    begin
      set @nS_id=@nS_id
    end
    else
    begin
      set @wholeflag=2
      set @nS_id=0 
    end
  end
 /* declare @szY_ID varchar(60)
  declare @nY_ID int

  exec ts_GetSysValue 'Y_ID',  @szY_ID output
  if (@szY_ID = 0) or (@szY_ID = '')
  begin
    RAISERROR ('没有设置当前机构!', 16, 1)
    return -22 
  end
  set @nY_ID = cast(@szY_ID as int)
*/
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
IF @nMode=0 
BEGIN
	IF @PeriodFlag='00'
	begin
	  if @multselectS=1
	  begin
	     if @WholeFlag=2
	     begin
	        if  @nVchtype in (41,42,50) /*处理报损报溢盘点单和不合格报损报溢审批表选择不合格品库，选择商品可以选择不合格商品批次*/
		    begin
		       SELECT s.storehouseini_id as batchid,s.quantity,0 as salequantity,s.costtotal,s.costprice,s.batchno,s.makedate,
					s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
					ISNULL(c.[name],'') as suppliername,
					ISNULL(l.loc_name,'') as locname,
					CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
					isnull(cu.name,0) as taxrate,s.s_id as s_id,p.Factory,p.comment
					,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
					, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode, dbo.Decimalbits(4,s.costtaxprice)as costtaxprice, s.costtaxtotal, 
					s.factoryid, s.taxrate as costtaxrate,ss.name as sname
					FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from StoreHouseIni  s
											LEFT JOIN Company Y ON S.Y_id=Y.Company_id 
						  )s 
					LEFT JOIN 	clients c     ON s.supplier_id=c.client_id
					LEFT JOIN      locatiON l     ON s.location_id=l.loc_id
					LEFT JOIN      products p     ON s.P_ID=p.product_ID
					LEFT JOIN  ForbiddenBatch FB  ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
					left JOin  storages ss ON s.s_id=ss.storage_id
					left JOin  customCategory cu ON p.TaxRate = cu.id
					WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0) 
						 and s.YClass_id like @nYClassid+'%'
						 and ss.WholeFlag<>3
					   /*  and ss.Y_ID=@nY_ID*/
						 and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						 AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))
					ORDER BY s.validdate
		    end
		    else
		    begin
  				   SELECT s.storehouseini_id as batchid,s.quantity,0 as salequantity,s.costtotal,s.costprice,s.batchno,s.makedate,
					s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
					ISNULL(c.[name],'') as suppliername,
					ISNULL(l.loc_name,'') as locname,
					CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
					isnull(cu.name,0) as taxrate,s.s_id as s_id,p.Factory,p.comment
					,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
					, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode, dbo.Decimalbits(4,s.costtaxprice)as costtaxprice, s.costtaxtotal, 
					s.factoryid, s.taxrate as costtaxrate,ss.name as sname
					FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from StoreHouseIni  s
											LEFT JOIN Company Y ON S.Y_id=Y.Company_id 
						  )s 
					LEFT JOIN 	clients c     ON s.supplier_id=c.client_id
					LEFT JOIN      locatiON l     ON s.location_id=l.loc_id
					LEFT JOIN      products p     ON s.P_ID=p.product_ID
					LEFT JOIN  ForbiddenBatch FB  ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
					left JOin  storages ss ON s.s_id=ss.storage_id
					left JOin  customCategory cu ON p.TaxRate = cu.id
					WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0) and (ss.qualityFlag=0)
						 and s.YClass_id like @nYClassid+'%'
						 and ss.WholeFlag<>3
					   /*  and ss.Y_ID=@nY_ID*/
						 and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						 AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))
					ORDER BY s.validdate
			 end
		   end
		   else
		   begin
		        SELECT s.storehouseini_id as batchid,s.quantity,0 as salequantity,s.costtotal,s.costprice,s.batchno,s.makedate,
					s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
					ISNULL(c.[name],'') as suppliername,
					ISNULL(l.loc_name,'') as locname,
					CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
					isnull(cu.name,0) as taxrate,s.s_id as s_id,p.Factory,p.comment
					,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
					, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode, dbo.Decimalbits(4,s.costtaxprice)as costtaxprice, s.costtaxtotal, 
					s.factoryid, s.taxrate as costtaxrate,ss.name as sname
					FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from StoreHouseIni  s
											LEFT JOIN Company Y ON S.Y_id=Y.Company_id 
						  )s 
					LEFT JOIN 	clients c     ON s.supplier_id=c.client_id
					LEFT JOIN      locatiON l     ON s.location_id=l.loc_id
					LEFT JOIN      products p     ON s.P_ID=p.product_ID
					LEFT JOIN  ForbiddenBatch FB  ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
					left JOin  storages ss ON s.s_id=ss.storage_id
					left JOin  customCategory cu ON p.TaxRate = cu.id
					WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0) and (ss.qualityFlag=0)
						 and s.YClass_id like @nYClassid+'%'
						 and ss.WholeFlag=3
					    /* and ss.Y_ID=@nY_ID*/
						 and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						 AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))
					ORDER BY s.validdate
		   end
	  end
	  else
	  begin
	    SELECT s.storehouseini_id as batchid,s.quantity,0 as salequantity,s.costtotal,s.costprice,s.batchno,s.makedate,
			s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
			ISNULL(c.[name],'') as suppliername,
			ISNULL(l.loc_name,'') as locname,
			CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
			isnull(cu.name,0) as taxrate,s.s_id as s_id,p.Factory,p.comment
			,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
			, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode, dbo.Decimalbits(4,s.costtaxprice)as costtaxprice, s.costtaxtotal, 
			s.factoryid, s.taxrate as costtaxrate,ss.name as sname
			FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from StoreHouseIni  s
									LEFT JOIN Company Y ON S.Y_id=Y.Company_id 
				  )s 
			LEFT JOIN 	clients c     ON s.supplier_id=c.client_id
			LEFT JOIN      locatiON l     ON s.location_id=l.loc_id
			LEFT JOIN      products p     ON s.P_ID=p.product_ID
			LEFT JOIN  ForbiddenBatch FB  ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
			left JOin  storages ss ON s.s_id=ss.storage_id
			left JOin  customCategory cu ON p.TaxRate = cu.id
			WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)
				 and s.YClass_id like @nYClassid+'%'
				 and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
				 AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))
			ORDER BY s.validdate
	  end
	 end
	ELSE 
	BEGIN
		IF EXISTS(SELECT * FROM sysconfigtmp s WHERE s.[sysname] = 'ScanSFDACode' AND s.sysvalue = '1')
		BEGIN
			IF (LEN(@SfdaCode) = 20) AND (SUBSTRING(@SfdaCode, 1, 1) = '8')
				SET @SfdaCode = SUBSTRING(@SfdaCode, 1, 7)
		END
		IF LEN(@SfdaCode) <> 20 
		 if @multselectS=1
	     begin 
	      if @WholeFlag=2
	      begin
	        if  @nVchtype in (41,42,50) /*处理报损报溢盘点单和不合格报损报溢审批表选择不合格品库，选择商品可以选择不合格商品批次 */
		    begin
		       SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
				s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
				ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
				CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
				isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
				,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
				, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
				isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
				isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
				FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
								LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
								left join basefactory r on s.Factoryid=r.CommID      
					)s 
				LEFT JOIN  clients c ON s.supplier_id=c.client_id
				LEFT JOIN locatiON l ON s.location_id=l.loc_id
				LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
				ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
				AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
				AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
				and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
				LEFT JOIN  products p ON s.P_ID=p.product_ID
				LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				LEFT JOIN storages ss on s.s_id=ss.storage_id
				left JOin  customCategory cu ON p.TaxRate = cu.id
				WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)  
						and ss.WholeFlag<>3
						and s.YClass_id like @nYClassid+'%'
						/*and ss.Y_ID=@nY_ID*/
						and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
				ORDER BY s.validdate 
		    end
		    else  if @nVchtype in (12,157)  /*XXX.零售单检测可开数量和店间调拨单一致*/
		    begin
		       SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
				s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
				ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
				CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
				isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
				,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
				, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
				isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
				isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
				FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
								LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
								left join basefactory r on s.Factoryid=r.CommID      
					)s 
				LEFT JOIN  clients c ON s.supplier_id=c.client_id
				LEFT JOIN locatiON l ON s.location_id=l.loc_id
				LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',157) where p_id = @nP_id) o 
				ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
				AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
				AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
				and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
				LEFT JOIN  products p ON s.P_ID=p.product_ID
				LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				LEFT JOIN storages ss on s.s_id=ss.storage_id
				left JOin  customCategory cu ON p.TaxRate = cu.id
				WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)  and (ss.qualityFlag=0)
						and ss.WholeFlag<>3
						and s.YClass_id like @nYClassid+'%'
						/*and ss.Y_ID=@nY_ID*/
						and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
				ORDER BY s.validdate 
		    end
		    else
		    begin
				SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
				s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
				ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
				CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
				isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
				,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
				, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
				isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
				isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
				FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
								LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
								left join basefactory r on s.Factoryid=r.CommID      
					)s 
				LEFT JOIN  clients c ON s.supplier_id=c.client_id
				LEFT JOIN locatiON l ON s.location_id=l.loc_id
				LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
				ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
				AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
				AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
				and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
				LEFT JOIN  products p ON s.P_ID=p.product_ID
				LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				LEFT JOIN storages ss on s.s_id=ss.storage_id
				left JOin  customCategory cu ON p.TaxRate = cu.id
				WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)  and (ss.qualityFlag=0)
						and ss.WholeFlag<>3
						and s.YClass_id like @nYClassid+'%'
						/*and ss.Y_ID=@nY_ID*/
						and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
				ORDER BY s.validdate 
		     end
	      end
	      else
	      begin
				SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
				s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
				ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
				CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
				isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
				,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
				, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
				isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
				isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
				FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
								LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
								left join basefactory r on s.Factoryid=r.CommID      
					)s 
				LEFT JOIN  clients c ON s.supplier_id=c.client_id
				LEFT JOIN locatiON l ON s.location_id=l.loc_id
				LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
				ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
				AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
				AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
				and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
				LEFT JOIN  products p ON s.P_ID=p.product_ID
				LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				LEFT JOIN storages ss on s.s_id=ss.storage_id
				left JOin  customCategory cu ON p.TaxRate = cu.id
				WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)  and (ss.qualityFlag=0)
						and s.YClass_id like @nYClassid+'%'
						/*and ss.Y_ID=@nY_ID*/
						and ss.WholeFlag=3
						and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
						AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
				ORDER BY s.validdate
		    end
		  end
		  else
		  begin
		  if @nVchtype in (12,157)  /*XXX.零售单检测可开数量和店间调拨单一致*/
		  begin
				   SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
					s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
					ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
					CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
					isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
					,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
					, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
					isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
					isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
					FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
									LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
									left join basefactory r on s.Factoryid=r.CommID      
						)s 
					LEFT JOIN  clients c ON s.supplier_id=c.client_id
					LEFT JOIN locatiON l ON s.location_id=l.loc_id
					LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',157) where p_id = @nP_id) o 
					ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
					AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
					AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
					and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
					LEFT JOIN  products p ON s.P_ID=p.product_ID
					LEFT JOIN ForbiddenBatch FB 
					ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
					LEFT JOIN storages ss on s.s_id=ss.storage_id
					left JOin  customCategory cu ON p.TaxRate = cu.id
					WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)
							/*and s.YClass_id like @nYClassid+'%'*/
							and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
							AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
					ORDER BY s.validdate
			end
			else
			begin
			       SELECT s.storehouse_id AS batchid,s.quantity, isnull(o.quantity,0) as salequantity,s.costtotal,
					s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
					ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
					CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
					isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
					,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
					, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
					isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
					isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
					FROM ( select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
									LEFT JOIN Company Y ON S.Y_id=Y.Company_id    
									left join basefactory r on s.Factoryid=r.CommID      
						)s 
					LEFT JOIN  clients c ON s.supplier_id=c.client_id
					LEFT JOIN locatiON l ON s.location_id=l.loc_id
					LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
					ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
					AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
					AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
					and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
					LEFT JOIN  products p ON s.P_ID=p.product_ID
					LEFT JOIN ForbiddenBatch FB 
					ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
					LEFT JOIN storages ss on s.s_id=ss.storage_id
					left JOin  customCategory cu ON p.TaxRate = cu.id
					WHERE s.p_id=@nP_id AND (s.s_id=@nS_id or @nS_id = 0)
							/*and s.YClass_id like @nYClassid+'%'*/
							and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
							AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
					ORDER BY s.validdate
			end
		  end
		ELSE
			SELECT s.storehouse_id AS batchid,s.quantity, ISNULL(o.quantity,0) as salequantity,s.costtotal,
			s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
			ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
			CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
			isnull(cu.name,0) as taxrate,s.s_id as s_id,isnull(s.factory,'') as Factory,p.comment
			,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,ss.WholeFlag
			, s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,isnull(s.Factoryid,0) as Factoryid,
			isnull(dbo.Decimalbits(4,s.costtaxprice),0) as costtaxprice,isnull(s.costtaxtotal,0) as costtaxtotal,
			isnull(s.taxrate,1)*100 as costtaxrate,ss.name as sname
			FROM ( SELECT c.* 
			       FROM (SELECT a.P_Id, a.BatchNo, a.MakeDate, a.ValidDate
					     FROM Sfda_List a 
			             WHERE a.Sfda_Code = @SfdaCode AND a.S_Id = @nS_id AND a.[Deleted] = 0) b 
			         INNER JOIN (				  
				           select s.*,ISNULL(Y.Class_id,'')YClass_id ,y.name,r.AccountComment as factory from StoreHouse  s
							        INNER JOIN Company Y ON S.Y_id=Y.Company_id 
							        left join  basefactory r on s.Factoryid=r.CommID
			               WHERE y.class_id = @nYClassid  AND s.p_id = @nP_id AND s.s_id = @nS_id) c 
			         ON b.P_Id = c.p_id AND b.BatchNo = c.batchno AND b.ValidDate = c.validdate AND b.MakeDate = c.makedate   
				)s 
			LEFT JOIN  clients c ON s.supplier_id=c.client_id
			LEFT JOIN locatiON l ON s.location_id=l.loc_id
			LEFT JOIN (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o 
			ON o.p_id=s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND o.location_id=s.location_id and o.validdate=s.validdate and o.makedate=s.makedate
			AND o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime AND O.s_id = S.s_id
			and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
			and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
            LEFT JOIN  products p ON s.P_ID=p.product_ID
			LEFT JOIN ForbiddenBatch FB 
			ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
			LEFT JOIN storages ss on s.s_id=ss.storage_id
			left JOin  customCategory cu ON p.TaxRate = cu.id
			WHERE ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
					AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
			ORDER BY s.validdate	
	END
	RETURN 0
END

IF @nMode IN (1,2)
BEGIN
	IF @PeriodFlag='00'
  	   SELECT s.storedxini_id  as batchid,s.quantity,s.quantity as salequantity,s.costtotal,s.costprice,s.batchno,
      s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
      ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
      CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
      isnull(cu.name,0) as taxrate,s.c_id as s_id,p.Factory,p.comment
      ,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,0 as WholeFlag
      , 0 as batchprice, ' ' as scomment, ' ' as batchbarcode,isnull(s.factoryid,0) as factoryid,isnull(s.factory,'') as factory,
       dbo.Decimalbits(4,s.costtaxprice) as costtaxprice,s.taxrate as costtaxrate,
       s.costtaxtotal as costtaxtotal,cl.name as sname
           FROM  (select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name,f.AccountComment as factory from Storedxini s
                                left join Company Y ON Y.Company_id=s.Y_id
                                left join basefactory f on s.factoryid=f.CommID
                 )s
                 left JOIN clients  c ON s.supplier_id=c.client_id
		 LEFT JOIN locatiON l ON s.location_id=l.loc_id
                 LEFT JOIN products p ON s.P_ID=p.product_ID
                 LEFT JOIN ForbiddenBatch FB 
  			ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
  			left JOin  customCategory cu ON p.TaxRate = cu.id
  		 left join clients cl on cl.client_id=s.c_id
  			
           WHERE s.p_id=@nP_id AND s.c_id=@nS_id AND commissionflag=@nMode
             and s.YClass_id like @nYClassid+'%'
             AND ((@ClientTable=0) or (s.c_id in (select [id] from #Clienttable)))
             AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
    	   ORDER BY s.validdate
	ELSE 
  	   SELECT s.storedx_id  as batchid,s.quantity,s.quantity as salequantity,s.costtotal,s.costprice,s.batchno,
        s.makedate,s.validdate,s.commissionflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
        CAST(s.stopsaleflag AS INT) AS stopsaleflag,ISNULL(c.[name],'') as suppliername,
        ISNULL(l.loc_name,'') as locname,
        CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
        isnull(cu.name,0) as taxrate,s.c_id as s_id,p.Factory,p.comment
        ,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,0 as WholeFlag
      , 0 as batchprice, ' ' as scomment, ' ' as batchbarcode,isnull(s.factoryid,0) as factoryid,isnull(s.factory,'') as factory,
        dbo.Decimalbits(4,s.costtaxprice) as costtaxprice,s.taxrate as costtaxrate,s.costtaxtotal as costtaxtotal,cl.name as sname
	   FROM (select S.*,ISNULL(Y.Class_id,'')YClass_id,y.name,f.AccountComment as factory FROM Storedx s
                                left join Company Y ON Y.Company_id=s.Y_id
                                left join basefactory f on s.factoryid=f.CommID
                )s
                LEFT JOIN  clients c ON s.supplier_id=c.client_id
		LEFT JOIN locatiON l ON s.location_id=l.loc_id
                LEFT JOIN products p ON s.P_ID=p.product_ID
                LEFT JOIN ForbiddenBatch FB 
		       ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
		       left JOin  customCategory cu ON p.TaxRate = cu.id
		       left join clients cl on cl.client_id=s.c_id
	   WHERE s.p_id=@nP_id AND s.c_id=@nS_id AND commissionflag=@nMode
             and s.YClass_id like @nYClassid+'%'
             AND ((@ClientTable=0) or (s.c_id in (select [id] from #Clienttable))) 
             AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
                ORDER BY s.validdate
	RETURN 0
END

IF @nMode IN (3,4)
BEGIN
	IF @PeriodFlag='00'
  	   SELECT s.storebrrowini_id  as batchid,s.quantity,s.quantity as salequantity,s.costtotal,s.costprice,s.batchno,
        s.makedate,s.validdate,s.commissionflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
        CAST(s.stopsaleflag AS INT) AS stopsaleflag,ISNULL(c.[name],'') as suppliername,
        ISNULL(l.loc_name,'') as locname,
        CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
        isnull(cu.name,0) as taxrate,s.c_id as s_id,p.Factory,p.comment
	,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,0 as wholeflag
      , 0 as batchprice, ' ' as scomment, ' ' as batchbarcode,0 as factoryid,0 as costtaxprice,0 as costtaxrate,
      0 as costtaxtotal,cl.name as sname
	   FROM (select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from Storebrrowini s 
                                left join Company Y ON Y.Company_id=s.Y_id
                )s
                LEFT JOIN clients c  ON s.supplier_id=c.client_id
		LEFT JOIN locatiON l ON s.location_id=l.loc_id
                LEFT JOIN products p ON s.P_ID=p.product_ID
                LEFT JOIN ForbiddenBatch FB 
		       ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
		       left JOin  customCategory cu ON p.TaxRate = cu.id
		       left join clients cl on cl.client_id=s.c_id
	   WHERE s.p_id=@nP_id AND s.c_id=@nS_id AND commissionflag=@nMode
             and s.YClass_id like @nYClassid+'%'
             AND ((@ClientTable=0) or (s.c_id in (select [id] from #Clienttable))) 
             AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
	   ORDER BY s.validdate
	ELSE 
  	   SELECT s.storebrrow_id  as batchid,s.quantity,s.quantity as salequantity,s.costtotal,s.costprice,s.batchno,
       s.makedate,s.validdate,s.commissionflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
       CAST(s.stopsaleflag AS INT) AS stopsaleflag,ISNULL(c.[name],'') as suppliername,
       ISNULL(l.loc_name,'') as locname,
       CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
       isnull(cu.name,0) as taxrate,s.c_id as s_id,p.Factory,p.comment
	,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,0 as wholeflag
      , 0 as batchprice, ' ' as scomment, ' ' as batchbarcode,0 as factoryid,0 as costtaxprice,0 as costtaxrate,
      0 as costtaxtotal,cl.name as sname
	   FROM (select s.*,ISNULL(Y.Class_id,'')YClass_id,y.name from Storebrrow s 
                                left join Company Y ON Y.Company_id=s.Y_id
                )s 
                LEFT JOIN clients c  ON s.supplier_id=c.client_id
		LEFT JOIN locatiON l ON s.location_id=l.loc_id
                LEFT JOIN products p ON s.P_ID=p.product_ID
                LEFT JOIN ForbiddenBatch FB 
		       ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
		       left JOin  customCategory cu ON p.TaxRate = cu.id
		       left join clients cl on cl.client_id=s.c_id
	   WHERE s.p_id=@nP_id AND s.c_id=@nS_id AND commissionflag=@nMode
             and s.YClass_id like @nYClassid+'%'
             AND ((@ClientTable=0) or (s.c_id in (select [id] from #Clienttable))) 
             AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable))) 
           ORDER BY s.validdate
	RETURN 0
END


if @nmode=6
begin
  declare @npdplanid  int
  set @npdplanid=@ns_id
  set @ns_id=0
  select @ns_id=k_id from pdplanidx where pdidx=@npdplanid
  if @ns_id=0 
  begin
    raiserror('没有选择仓库！',16,1)
    return 0
  end 

   select s.pdplan_id as batchid,s.quantity,isnull(o.quantity,0) as salequantity,s.costtotal,s.Y_ID,
   s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,y.name as yname,
   isnull(c.[name],'') as suppliername,isnull(l.loc_name,'') as locname,
   CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
   isnull(cu.name,0) as taxrate,s.s_id ,p.Factory,p.comment
   ,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,sh.WholeFlag
    , s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,s.factoryid as factoryid,
    dbo.Decimalbits(4,s.costtaxprice) as costtaxprice,s.costtaxrate*100 as costtaxrate,
    s.costtaxtotal as costtaxtotal,sh.name as sname
   from pdplan s 
              INNER JOIN
                (select storage_id,WholeFlag,name from Storages s                                 
                )sh  on sh.storage_id=s.s_id
               
		left join 
		clients c on s.supplier_id=c.client_id
		left join location l 
		on s.location_id=l.loc_id
		left join (select * from dbo.fn_getavlqty(@nP_id, @nS_id, '',1) where p_id = @nP_id) o
		on o.p_id=s.p_id and o.batchno=s.batchno and o.supplier_id=s.supplier_id and o.location_id=s.location_id 
     and o.commissionflag=s.commissionflag and o.costprice=s.costprice and o.instoretime=s.instoretime
	AND O.s_id = S.s_id and o.costtaxprice=s.costtaxprice and o.factoryid = s.factoryid /*原来没加factoryid*/
	and o.makedate = s.makedate and o.validdate = s.validdate and o.Y_ID = s.Y_ID    /*XXX.2017-02-16 把批次条件加完，不然会初选重复*/
    left join 
    products p on s.p_id=p.product_id
    LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
    LEFT JOIN Company Y ON Y.company_id=s.Y_id
    left JOin  customCategory cu ON p.TaxRate = cu.id
		where s.pdidx=@npdplanid and s.p_id=@np_id and s.s_id=@ns_id
              and Y.Class_id like @nYClassid+'%'
             and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
             AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))  
		order by s.validdate
	return 0
end


IF @nMode=7
BEGIN
  	SELECT s.storehouse_id AS batchid,s.quantity,s.quantity as salequantity,s.costtotal,
        s.costprice,s.batchno,s.makedate,s.validdate,s.commissionflag,CAST(s.stopsaleflag AS INT) AS stopsaleflag,s.supplier_id,s.location_id,s.name as yname,s.Y_ID,
        ISNULL(c.[name],'') as suppliername,ISNULL(l.loc_name,'') as locname,
        CAST(CONVERT(varchar(100), s.instoretime, 23) AS DATETIME) AS instoretime,
        isnull(cu.name,0) as taxrate,s.s_id as s_id,p.Factory,p.comment
	,(CASE WHEN  not (FB.BatchNo is null) THEN '禁销' ELSE '' END) FBTag,ISNULL(FB.fbType ,-1)fbType,SS.WholeFlag
    , s.batchprice, s.scomment, isnull(s.batchbarcode,'') as batchbarcode,0 as factoryid,0 as costtaxprice,
    0 as costtaxrate,0 as costtaxtotal,ss.name as sname
			 FROM (
                                select S.*,isnull(Y.Class_id,'')YClass_id,y.name from StoreHouse  s  
                                              LEFT JOIN Company Y on Y.Company_id=s.Y_id
                                )s 
				LEFT JOIN 
				clients c ON s.supplier_id=c.client_id
				LEFT JOIN locatiON l 
				ON s.location_id=l.loc_id
			        LEFT JOIN products p
       				ON s.P_ID=p.product_ID
				LEFT JOIN ForbiddenBatch FB 
				ON FB.PermitCode=P.PermitCode and FB.BatchNo=s.BatchNo and FB.fbType=1
				LEFT JOIN storages SS ON S.s_id=SS.storage_id
				left JOin  customCategory cu ON p.TaxRate = cu.id
			WHERE s.p_id=@nP_id 
                          and s.YClass_id like @nYClassid+'%'
                          and ((@Storetable=0) OR (s.s_id in (select [id] from #storagestable))) 
                          AND ((@Companytable=0)or (s.Y_id in (select [id] from #Companytable)))  
				ORDER BY s.validdate
	RETURN 0
END
GO
