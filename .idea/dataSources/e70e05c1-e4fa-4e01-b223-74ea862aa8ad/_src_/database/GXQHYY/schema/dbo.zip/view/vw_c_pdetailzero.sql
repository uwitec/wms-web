


CREATE  view dbo.vw_c_pdetailzero
as
select  dbo.productdetail.*, 
isnull(dbo.products.class_id,'') as class_id, 
isnull(dbo.storages.class_id,'') as sclass_id, 
isnull(dbo.storages.[name],'') as sname, 
isnull(dbo.products.[name],'') as pname,
isnull(products.makearea,'') as makearea,
isnull(products.standard,'') as standard,
isnull(products.serial_number,'') as serial_number,
isnull(products.comment,'') as pcomment,
isnull(products.alias,'') as alias,
isnull(l.loc_name,'') as locname,
isnull(cl.[name],'') as suppliername,
isnull(e.class_id,'') as Reclass_id,
isnull(e.[name],'') as Rename,
isnull(f.AccountComment,'') as factory
from dbo.productdetail 
 left outer join
       dbo.storages on dbo.productdetail.s_id = dbo.storages.storage_id 
 left outer join
       dbo.products on dbo.productdetail.p_id = dbo.products.product_id
 left outer join
       dbo.location l on dbo.productdetail.location_id = l.loc_id
 left outer join
       dbo.clients cl on dbo.productdetail.supplier_id = cl.client_id
 left outer join
       dbo.employees e on dbo.productdetail.RowE_id = e.emp_id
 left outer join 
       dbo.basefactory f on dbo.products.factoryc_id=f.CommID

where dbo.productdetail.aoid in(5,6)
GO
