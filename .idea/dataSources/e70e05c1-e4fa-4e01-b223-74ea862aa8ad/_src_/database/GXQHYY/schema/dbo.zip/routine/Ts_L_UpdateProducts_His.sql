
CREATE	  PROCEDURE [Ts_L_UpdateProducts_His]
		(@product_id	[int] OUTPUT,
		@serial_number 	[varchar](26),
		@name	[varchar](80),
		@alias 	[varchar](80),
		@standard	[varchar](100),
		@modal 	[varchar](20),
		@permitcode	[varchar](50),
		@trademark	[varchar](50),
		@makearea	[varchar](60),
		@unit1_id	[smallint],
		@unit2_id	[smallint],
		@unit3_id	[smallint],
		@unit4_id	[smallint],
		@rate2 	numeric(25,8),
		@rate3 	numeric(25,8),
		@rate4 	numeric(25,8),
		@validmonth	[smallint],
		@validday	[smallint],
		@comment	[varchar](250),
		@pinyin	[varchar](80),
		@firstcheck	[bit],
		@otcflag	[char](1),
		@gspflag	[char](2),
		@medtype	int,
		@costmethod	[char](1),
		@engName	[varchar](50),
		@chemName	[varChar](50),
		@latinName	[varChar](50),
		@deduct	numeric(25,8),
		@OtcType	[tinyint],
		@gmp		[bit],
		@gross		numeric(25,8),
		@MaintainType	[tinyint],
		@maintainDay	[int],
		@range		[int],
		@packStd	[varchar](60),
		@storageCon	[varchar](60),
		@taxrate	numeric(25,8),
		@supplier_id	[int],
		@Emp_id	[int],
		@PosYhDay	[int],
		@ifIntegral [bit],
		@integral   [int],
		@Factory    varchar(80),
		@tc1   numeric(25,8),
		@tc2   numeric(25,8),
		@tcmoney numeric(25,8),
		@TcCost numeric(25,8),
		@BulidNo	[varchar](500),
		@RegisterNo	[varchar](500),
		@PrintClass int,
		@WholeUnit_id int,
		@deleted  int,
		@Inputdate varchar(50),
		@Inputman  varchar(50),
		@Custompro1 Varchar(100),
		@Custompro2 varchar(100),
		@Custompro3 varchar(100),
		@Custompro4 varchar(100),
		@Custompro5 varchar(100),
		@Locid      int,
		@NoneQuantity numeric(25,8),/*断货数量参数*/
		@FactoryC_ID int,
		@SR_id       int,
		@nY_id       int,  
		@drate       numeric(25,8),
		@basicMedication numeric(25,8), /*基本药物  */
		@SR2_id      int,
        @Wholeloc    int,
        @SingleLoc   int,
        @protectprice int,
        @RegistervalidDate datetime,  /*--注册证号有效期 add by luowei 2013-03-26*/
        @PerCodevalidDate datetime, /*--批准文号有效期 add by luowei 2013-03-26*/
        @TransToYJ    [char](1),
		@ControlYard  [char](1),
		@ifdiscount  char(1),
		@pack varchar(100),
		@isCheckReport bit,
        @GMPNo varchar(120),
        @GMPValiddate  datetime,
	    @Kcl INT,
	    @Kcldw INT,
	    @Khsbl numeric(25,8),
	    @Kcljg numeric(25,8),
	    @incRate2 numeric(25,8),
	    @incRate3 numeric(25,8),
	    @isCheckLT BIT,
	    @StoreCondition INT,
	    @IsValidP int, /*zfl贵细药品*/
	    @IfZYCheck int,/*中药*/
	    @IsClientdiscount int, /*折扣 往来单位*/
	    @commodityCode varchar(100),
	    @fztaxrate     numeric(25,8),/*辅助税率*/
        @taxrateflcode varchar(100), /*税务类型编号*/
        @Z_ZNumber     varchar(100),  /*证照编号*/
        @Z_ZBillDate   datetime /*证照期限*/
		)
		AS
		
		declare  @serial_numberOld 	[varchar](26),@nameOld	[varchar](80),
		@aliasOld 	[varchar](80),
		@standardOld	[varchar](100),
		@modalOld 	[varchar](20),
		@permitcodeOld	[varchar](50),
		@trademarkOld	[varchar](50),
		@makeareaOld	[varchar](60),
		@unit1_idOld	[smallint],
		@unit2_idOld	[smallint],
		@unit3_idOld	[smallint],
		@unit4_idOld	[smallint],
		@rate2Old 	numeric(25,8),
		@rate3Old 	numeric(25,8),
		@rate4Old 	numeric(25,8),
		@validmonthOld	[smallint],
		@validdayOld	[smallint],
		@commentOld	[varchar](250),
		@pinyinOld	[varchar](80),
		@firstcheckOld	[bit],
		@otcflagOld	[char](1),
		@gspflagOld	[char](2),
		@medtypeOld	int,
		@costmethodOld	[char](1),
		@engNameOld	[varchar](50),
		@chemNameOld	[varChar](50),
		@latinNameOld	[varChar](50),
		@deductOld	numeric(25,8),
		@OtcTypeOld	[tinyint],
		@gmpOld		[bit],
		@grossOld		numeric(25,8),
		@MaintainTypeOld	[tinyint],
		@maintainDayOld	[int],
		@rangeOld		[int],
		@packStdOld	[varchar](60),
		@storageConOld	[varchar](60),
		@taxrateOld	numeric(25,8),
		@supplier_idOld	[int],
		@Emp_idOld	[int],
		@PosYhDayOld	[int],
		@ifIntegralOld [bit],
		@integralOld   [int],
		@FactoryOld    varchar(80),
		@tc1Old   numeric(25,8),
		@tc2Old   numeric(25,8),
		@tcmoneyOld numeric(25,8),
		@TcCostOld numeric(25,8),
		@BulidNoOld	[varchar](500),
		@RegisterNoOld	[varchar](500),
		@PrintClassOld int,
		@WholeUnit_idOld int,
		@deletedOld  int,
		@InputdateOld varchar(50),
		@InputmanOld  varchar(50),
		@Custompro1Old Varchar(100),
		@Custompro2Old varchar(100),
		@Custompro3Old varchar(100),
		@Custompro4Old varchar(100),
		@Custompro5Old varchar(100),
		@LocidOld      int,
		@NoneQuantityOld numeric(25,8),/*断货数量参数*/
		@FactoryC_IDOld int,
		@SR_idOld       int,
		@nY_idOld       int,  
		@drateOld       numeric(25,8),
		@basicMedicationOld numeric(25,8), /*基本药物  */
		@SR2_idOld      int,
        @WholelocOld    int,
        @SingleLocOld   int,
        @protectpriceOld int,
        @RegistervalidDateOld datetime,  /*--注册证号有效期 add by luowei 2013-03-26*/
        @PerCodevalidDateOld datetime, /*--批准文号有效期 add by luowei 2013-03-26*/
        @TransToYJOld    [char](1),
		@ControlYardOld  [char](1),
		@ifdiscountOld  char(1),
		@packOld varchar(100),
		@isCheckReportOld bit,
        @GMPNoOld varchar(120),
        @GMPValiddateOld  datetime,
	    @KclOld INT,
	    @KcldwOld INT,
	    @KhsblOld numeric(25,8),
	    @KcljgOld numeric(25,8),
	    @incRate2Old numeric(25,8),
	    @incRate3Old numeric(25,8),
	    @isCheckLTOld BIT,
	    @StoreConditionOld INT,
	    @IsValidPOld int, /*zfl贵细药品*/
	    @IfZYCheckOld int,/*中药*/
	    @IsClientdiscountOld int, /*折扣 往来单位*/
	    @commodityCodeOld varchar(100),
	    @fztaxrateOld     numeric(25,8),/*辅助税率*/
        @taxrateflcodeOld varchar(100), /*税务类型编号*/
        @Z_ZNumberOld     varchar(100),  /*证照编号*/
        @Z_ZBillDateOld   datetime /*证照期限*/

		SET @product_id = ABS(@product_id)

		/* 判断是否存在未处理申请修改*/
		IF EXISTS(SELECT * FROM BaseInfoHistory WHERE BaseInfoType = 'P' AND BaseInfo_ID = @product_id AND Status = 0)
		BEGIN
			RAISERROR ('本商品已提交过修改申请，请等待处理后再次提交！', 16, 1)
			set @product_id = -@product_id
			RETURN -50
		END

		SELECT * 
		INTO #TP
		FROM products
		WHERE product_id = @product_id
		
		SELECT * 
		INTO #TPOld
		FROM products
		WHERE product_id = @product_id

		UPDATE #TP 
		SET  
		[serial_number]	 = @serial_number,
		[name]  = @name,
		[alias]	 = @alias,
		[standard]	 = @standard,
		[modal]	 = @modal,
		[permitcode]	 = @permitcode,
		[trademark]	 = @trademark,
		[makearea]	 = @makearea,
		[unit1_id]	 = @unit1_id,
		[unit2_id]	 = @unit2_id,
		[unit3_id]	 = @unit3_id,
		[unit4_id]	 = @unit4_id,
		[rate2]	 = @rate2,
		[rate3]	 = @rate3,
		[rate4]	 = @rate4,
		[validmonth]	 = @validmonth,
		[validday]	 = @validday,
		[comment]	 = @comment,
		[pinyin]	 = @pinyin,
		[firstcheck]	 = @firstcheck,
		[otcflag]	 = @otcflag,
		[gspflag]	 = @gspflag,
		[medtype]	 = @medtype,
		[costmethod]	 = @costmethod ,
		[engName]	 =@engName,
		[chemName]	 =@chemName,
		[LatinName]	 =@latinName,
		[deduct]	 =@deduct,
		[otcType]	 =@otcType,
		[Gmp]		 =@gmp,
		[Gross]	 =@gross,
		[maintainType]  = @MaintainType,
		[MaintainDay]	 = @maintainDay,
		[r_id]		 = @range,
		packStd	 =@packStd,
		storagecon	 =@storageCon,	
		taxrate		=@taxrate,
		PosYhDay	=@posYhDay,
		ifIntegral=@ifIntegral,
		Integral  =@Integral,
		factory  =@Factory,
		tc1		= @tc1,
		tc2   = @tc2,
		tcmoney=@tcmoney,
		TcCost=@TcCost,
		BulidNo=@BulidNo,
		LastUpDate=@Inputdate,
		LastUpdateman=@Inputman,
		RegisterNo=@RegisterNo,
		PrintClass=@PrintClass,
		WholeUnit_id=@WholeUnit_id,
		Custompro1=@Custompro1, 
		Custompro2=@Custompro2,
		Custompro3=@Custompro3, 
		Custompro4=@Custompro4, 
		Custompro5=@Custompro5,
		NoneQuantity=@NoneQuantity, /*断货数量参数*/
		FactoryC_ID = @FactoryC_ID,
		SR_ID    =@SR_id,
		SR2_ID   =@SR2_id,
		Incrate =@drate,
		basicMedication=@basicMedication,
		protectprice = @protectprice,
		Registervalid = @RegistervalidDate,
		PerCodevalid  = @PerCodevalidDate,
		TransToYJ=@TransToYJ,
		ControlYard=@ControlYard,
		ifdiscount=@ifdiscount,
		pack=@pack,
		[isCheckReport] = @isCheckReport,
		GMPNo=@GMPNo,
		GMPvaliddate=@GMPvaliddate,
		sfcl = @Kcl,
		cldw = @Kcldw,
		hsbl = @Khsbl,
		cljg = @Kcljg,
		incRate2 = @incRate2,
		incRate3 = @incRate3,
		LTTime = @isCheckLT,
		StoreCondition = @StoreCondition,
		IsValuedProduct = @IsValidP,	 
		IfZYCheck=@IfZYCheck,
		IsClientdiscount=@IsClientdiscount,
		commodityCode=@commodityCode,
        fztaxrate =@fztaxrate,    
        taxrateflcode=@taxrateflcode,
        Z_ZNumber=@Z_ZNumber,
        Z_ZBillDate=@Z_ZBillDate
		WHERE 
		( [product_id]	 = @product_id)
		
		select @serial_numberOld=a.serial_number,@nameOld=a.name,
		@aliasOld=a.alias,
		@standardOld=standard,
		@modalOld=modal,
		@permitcodeOld=permitcode,
		@trademarkOld=trademark,
		@makeareaOld=makearea,
		@unit1_idOld=unit1_id,
		@unit2_idOld=unit2_id,
		@unit3_idOld=unit3_id,
		@unit4_idOld=unit4_id,
		@rate2Old   =rate2,
		@rate3Old   =rate3,
		@rate4Old   =rate4,
		@validmonthOld=validmonth,
		@validdayOld=validday,
		@commentOld=a.comment,
		@pinyinOld =a.pinyin,
		@firstcheckOld=a.firstcheck,
		@otcflagOld=otcflag,
		@gspflagOld=gspflag,
		@medtypeOld=medtype,
		@costmethodOld=costmethod,
		@engNameOld=engName,
		@chemNameOld=chemName,
		@latinNameOld=latinName,
		@deductOld=a.deduct,
		@OtcTypeOld=OtcType,
		@gmpOld=gmp,
		@grossOld=gross,
		@MaintainTypeOld=MaintainType,
		@maintainDayOld=maintainDay,
		@rangeOld=r_id,
		@packStdOld=packStd,
		@storageConOld=storageCon,
		@taxrateOld=taxrate,
		@PosYhDayOld=PosYhDay,
		@ifIntegralOld=ifIntegral,
		@integralOld=integral,
		@FactoryOld=Factory,
		@tc1Old=tc1,
		@tc2Old=tc2,
		@tcmoneyOld=tcmoney,
		@TcCostOld=TcCost,
		@BulidNoOld=BulidNo,
		@RegisterNoOld=RegisterNo,
		@PrintClassOld=PrintClass,
		@WholeUnit_idOld=WholeUnit_id,
		@deletedOld=a.deleted,
		@InputdateOld=Inputdate,
		@InputmanOld=Inputman,
		@Custompro1Old=Custompro1,
		@Custompro2Old=Custompro2,
		@Custompro3Old=Custompro3,
		@Custompro4Old=Custompro4,
		@Custompro5Old=Custompro5,
		@NoneQuantityOld=NoneQuantity,/*断货数量参数*/
		@FactoryC_IDOld=FactoryC_ID,
		@SR_idOld=SR_id,
		@drateOld=a.Incrate,
		@basicMedicationOld=basicMedication, /*基本药物  */
		@SR2_idOld=SR2_id,
        @protectpriceOld=protectprice,
        @RegistervalidDateOld=Registervalid,  /*--注册证号有效期 add by luowei 2013-03-26*/
        @PerCodevalidDateOld=PerCodevalid, /*--批准文号有效期 add by luowei 2013-03-26*/
        @TransToYJOld=TransToYJ,
		@ControlYardOld=ControlYard,
		@ifdiscountOld=ifdiscount,
		@packOld=pack,
		@isCheckReportOld=isCheckReport,
        @GMPNoOld=a.GMPNo,
        @GMPValiddateOld=GMPValiddate,
	    @KclOld=sfcl,
	    @KcldwOld=cldw,
	    @KhsblOld=hsbl,
	    @KcljgOld=cljg,
	    @incRate2Old=incRate2,
	    @incRate3Old=incRate3,
	    @isCheckLTOld=LTTime,
	    @StoreConditionOld=StoreCondition,
	    @IsValidPOld=IsValuedProduct, /*zfl贵细药品*/
	    @IfZYCheckOld=IfZYCheck,/*中药*/
	    @IsClientdiscountOld=IsClientdiscount, /*折扣 往来单位*/
	    @commodityCodeOld=commodityCode,
	    @fztaxrateOld=fztaxrate,/*辅助税率*/
        @taxrateflcodeOld=taxrateflcode, /*税务类型编号*/
        @Z_ZNumberOld=Z_ZNumber,  /*证照编号*/
        @Z_ZBillDateOld=Z_ZBillDate,
        @SingleLocOld=isnull(SingleLoc,0),
		@nY_idOld=b.Y_id,
		@LocidOld=isnull(locationid,0),
		@WholeUnit_idOld=WholeUnit_id,
		@WholelocOld=WholeLoc,
		@supplier_idOld=Supplier_id,
		@Emp_idOld=b.Emp_id
        from  products a left join  
         (select  * from productbalance where Y_id=2) b on a.product_id=b.p_id
		WHERE product_id = @product_id 
		
		
		UPDATE #TPOld 
		SET  
		[serial_number]	 = @serial_numberOld,
		[name]  = @nameOld,
		[alias]	 = @aliasOld,
		[standard]	 = @standardOld,
		[modal]	 = @modalOld,
		[permitcode]	 = @permitcodeOld,
		[trademark]	 = @trademarkOld,
		[makearea]	 = @makeareaOld,
		[unit1_id]	 = @unit1_idOld,
		[unit2_id]	 = @unit2_idOld,
		[unit3_id]	 = @unit3_idOld,
		[unit4_id]	 = @unit4_idOld,
		[rate2]	 = @rate2Old,
		[rate3]	 = @rate3Old,
		[rate4]	 = @rate4Old,
		[validmonth]	 = @validmonthOld,
		[validday]	 = @validdayOld,
		[comment]	 = @commentOld,
		[pinyin]	 = @pinyinOld,
		[firstcheck]	 = @firstcheckOld,
		[otcflag]	 = @otcflagOld,
		[gspflag]	 = @gspflagOld,
		[medtype]	 = @medtypeOld,
		[costmethod]	 = @costmethodOld ,
		[engName]	 =@engNameOld,
		[chemName]	 =@chemNameOld,
		[LatinName]	 =@latinNameOld,
		[deduct]	 =@deductOld,
		[otcType]	 =@otcTypeOld,
		[Gmp]		 =@gmpOld,
		[Gross]	 =@grossOld,
		[maintainType]  = @MaintainTypeOld,
		[MaintainDay]	 = @maintainDayOld,
		[r_id]		 = @rangeOld,
		packStd	 =@packStdOld,
		storagecon	 =@storageConOld,	
		taxrate		=@taxrateOld,
		PosYhDay	=@posYhDayOld,
		ifIntegral=@ifIntegralOld,
		Integral  =@IntegralOld,
		factory  =@FactoryOld,
		tc1		= @tc1Old,
		tc2   = @tc2Old,
		tcmoney=@tcmoneyOld,
		TcCost=@TcCostOld,
		BulidNo=@BulidNoOld,
		LastUpDate=@InputdateOld,
		LastUpdateman=@InputmanOld,
		RegisterNo=@RegisterNoOld,
		PrintClass=@PrintClassOld,
		WholeUnit_id=@WholeUnit_idOld,
		Custompro1=@Custompro1Old, 
		Custompro2=@Custompro2Old,
		Custompro3=@Custompro3Old, 
		Custompro4=@Custompro4Old, 
		Custompro5=@Custompro5Old,
		NoneQuantity=@NoneQuantityOld, /*断货数量参数*/
		FactoryC_ID = @FactoryC_IDOld,
		SR_ID    =@SR_idOld,
		SR2_ID   =@SR2_idOld,
		Incrate =@drateOld,
		basicMedication=@basicMedicationOld,
		protectprice = @protectpriceOld,
		Registervalid = @RegistervalidDateOld,
		PerCodevalid  = @PerCodevalidDateOld,
		TransToYJ=@TransToYJOld,
		ControlYard=@ControlYardOld,
		ifdiscount=@ifdiscountOld,
		pack=@packOld,
		[isCheckReport] = @isCheckReportOld,
		GMPNo=@GMPNoOld,
		GMPvaliddate=@GMPvaliddateOld,
		sfcl = @KclOld,
		cldw = @KcldwOld,
		hsbl = @KhsblOld,
		cljg = @KcljgOld,
		incRate2 = @incRate2Old,
		incRate3 = @incRate3Old,
		LTTime = @isCheckLTOld,
		StoreCondition = @StoreConditionOld,
		IsValuedProduct = @IsValidPOld,	 
		IfZYCheck=@IfZYCheckOld,
		IsClientdiscount=@IsClientdiscountOld,
		commodityCode=@commodityCodeOld,
        fztaxrate =@fztaxrateOld,    
        taxrateflcode=@taxrateflcodeOld,
        Z_ZNumber=@Z_ZNumberOld,
        Z_ZBillDate=@Z_ZBillDateOld
		WHERE 
		( [product_id]	 = @product_id)
	
		if @@ERROR <> 0
		begin
			set @product_id = -@product_id
			return -1
		end

		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,oldContent)
		SELECT @product_id, 'P', (SELECT * FROM #TP AS products FOR XML AUTO, TYPE, ROOT), 0,(SELECT * FROM #TPOld AS products FOR XML AUTO, TYPE, ROOT)

		DROP TABLE #TP
		DROP TABLE #TPOld


		SELECT TOP 0 * 
		INTO #TCCM
		FROM customCategoryMapping

		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@taxrate,@product_id,0,0)
		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@medtype,@product_id,0,0)
		INSERT INTO #TCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@range,@product_id,0,0)
		
		SELECT TOP 0 * 
		INTO #OldTCCM
		FROM customCategoryMapping
		
	    INSERT INTO #OldTCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@taxrateOld,@product_id,0,0)
		INSERT INTO #OldTCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@medtypeOld,@product_id,0,0)
		INSERT INTO #OldTCCM(category_id,baseinfo_id,deleted,BaseTypeid)
		values(@rangeOld,@product_id,0,0)
		
		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,OldContent)
		SELECT @product_id, 'CCMP', (SELECT * FROM #TCCM AS customCategoryMapping FOR XML AUTO, TYPE, ROOT), 0, (SELECT * FROM #OldTCCM AS customCategoryMapping FOR XML AUTO, TYPE, ROOT)
		DROP TABLE #TCCM
		DROP TABLE #OldTCCM

 		SELECT TOP 0 * 
		INTO #TPB
		FROM Productbalance
		
		INSERT INTO #TPB(Y_id,P_ID,Locationid,Wholeloc,Singleloc,Supplier_id,Emp_id)
		VALUES(@nY_id,@product_id,@Locid,@Wholeloc,@SingleLoc,@supplier_id,@emp_id)
		
		SELECT TOP 0 * 
		INTO #OldTPB
		FROM Productbalance
		
		INSERT INTO #OldTPB(Y_id,P_ID,Locationid,Wholeloc,Singleloc,Supplier_id,Emp_id)
		VALUES(isnull(@nY_idOld,0),@product_id,isnull(@LocidOld,0),isnull(@WholelocOld,0),isnull(@SingleLocOld,0),isnull(@supplier_idOld,0),isnull(@Emp_idOld,0))

		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,OldContent)
		SELECT @product_id, 'PB', (SELECT * FROM #TPB AS Productbalance FOR XML AUTO, TYPE, ROOT), 0, (SELECT * FROM #OldTPB AS Productbalance FOR XML AUTO, TYPE, ROOT)
		DROP TABLE #TPB
		DROP TABLE #OldTPB

return @product_Id
GO
