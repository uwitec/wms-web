
CREATE VIEW dbo.vw_avlSid
AS
SELECT     storage_id as s_id
FROM         dbo.storages
WHERE     (qualityFlag = 0) AND (wholeflag <> 3)
GO
