

CREATE proc ts_c_qrClientYw
(
	@BeginDate 	datetime,
	@EndDate	datetime,	
	@szCClass_id 	varchar(30)='%%',
	@szEClass_id 	varchar(30)='%%',
	@szParent_id	varchar(30)='000000',
	@szListflag	varchar(30)='L',
	@nMode		int=0,/*	=0:	往来单位业务分析 =1：内部职员业务分析*/
    @nYClassid      varchar(100)='',
    @nloginEID      int=0,
    @isaddDate      int=0, /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
    @nRegion_id     INT=0  /*片区ID*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @szCClass_id is null  SET @szCClass_id = '%%'
if @szEClass_id is null  SET @szEClass_id = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szListflag is null  SET @szListflag = 'L'
if @nMode is null  SET @nMode = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @nRegion_id is null  SET @nRegion_id = 0
/*Params Ini end*/

set nocount on
declare @szsql varchar(8000),@szsql2 varchar(8000)
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/


  Declare  @AR_ID   VARCHAR(30), @AP_ID   VARCHAR(30)
  SELECT @AR_ID='000001000005', @AP_ID='000002000001'

  if @nMode=0
  begin

		select c.cclass_id as class_id,
		isnull(sum(c.artotal),0) as artotal,
		isnull(sum(c.aptotal),0) as aptotal,
                ISNULL(CASE WHEN SUM(c.[Artotal_Ini]+ISNULL(c.[BeginArTotal], 0)-c.[Aptotal_Ini]-ISNULL(c.[BeginApTotal], 0))>0 THEN SUM(c.[artotal_ini]+ISNULL(c.[BeginArTotal], 0)-c.[aptotal_ini]-ISNULL(c.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginArTotal], 
                ISNULL(CASE WHEN SUM(c.[Artotal_Ini]+ISNULL(c.[BeginArTotal], 0)-c.[Aptotal_Ini]-ISNULL(c.[BeginApTotal], 0))<0 THEN -SUM(c.[artotal_ini]+ISNULL(c.[BeginArTotal], 0)-c.[aptotal_ini]-ISNULL(c.[BeginApTotal], 0)) ELSE 0 END, 0) AS [BeginApTotal], 
                ISNULL(CASE WHEN SUM(ISNULL(c.[EndArTotal], 0)-ISNULL(c.[EndApTotal], 0)-ISNULL(c.[BeginArTotal], 0)+ISNULL(c.[BeginApTotal], 0))>0 THEN SUM(ISNULL(c.[EndArTotal], 0)-ISNULL(c.[EndApTotal], 0)-ISNULL(c.[BeginArTotal], 0)+ISNULL(c.[BeginApTotal], 0)) ELSE 0 END, 0) AS [NowArTotal],  
                ISNULL(CASE WHEN SUM(ISNULL(c.[EndArTotal], 0)-ISNULL(c.[EndApTotal], 0)-ISNULL(c.[BeginArTotal], 0)+ISNULL(c.[BeginApTotal], 0))<0 THEN -SUM(ISNULL(c.[EndArTotal], 0)-ISNULL(c.[EndApTotal], 0)-ISNULL(c.[BeginArTotal], 0)+ISNULL(c.[BeginApTotal], 0)) ELSE 0 END, 0) AS [NowApTotal],  
                ISNULL(CASE WHEN SUM(c.[Artotal_Ini]+ISNULL(c.[EndArTotal], 0)-c.[Aptotal_Ini]-ISNULL(c.[EndApTotal], 0))>0 THEN SUM(c.[artotal_ini]+ISNULL(c.[EndArTotal], 0)-c.[aptotal_ini]-ISNULL(c.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndArTotal], 
                ISNULL(CASE WHEN SUM(c.[Artotal_Ini]+ISNULL(c.[EndArTotal], 0)-c.[Aptotal_Ini]-ISNULL(c.[EndApTotal], 0))<0 THEN -SUM(c.[artotal_ini]+ISNULL(c.[EndArTotal], 0)-c.[aptotal_ini]-ISNULL(c.[EndApTotal], 0)) ELSE 0 END, 0) AS [EndApTotal]
		into #b
		from ( SELECT CB.c_id ,cb.artotal,cb.aptotal,cb.Artotal_Ini,cb.Aptotal_Ini,
                              cb.Y_id,ISNULL(Y.class_id,'')YClass_ID,isnull(C.Class_id,'')CClass_id,
                              ad.[BeginArTotal],ad.[BeginApTotal],ad.[EndArTotal],ad.[EndApTotal] 
                       FROM  Clientsbalance CB
                       LEFT JOIN  Clients  C  ON C.Client_id=cb.c_id
                       LEFT JOIN  Company  Y  ON CB.Y_id=Y.Company_id
                       LEFT JOIN 
                       (select b.c_id,b.Y_id,
                        ISNULL(SUM(CASE WHEN a.[Class_ID]=@AR_ID AND b.[BillDate]<@BeginDate THEN b.[JdMoney] END), 0) AS [BeginArTotal], 
                        ISNULL(SUM(CASE WHEN a.[Class_ID]=@AP_ID AND b.[BillDate]<@BeginDate THEN b.[JdMoney] END), 0) AS [BeginApTotal],

                        ISNULL(SUM(CASE WHEN a.[Class_ID]=@AR_ID AND b.[BillDate]<=@EndDate THEN b.[JdMoney] END), 0) AS [EndArTotal], 
                        ISNULL(SUM(CASE WHEN a.[Class_ID]=@AP_ID AND b.[BillDate]<=@EndDate THEN b.[JdMoney] END), 0) AS [EndApTotal]
                        from (select ad.a_id, b.billdate,ad.jdmoney,ad.c_id,b.Y_id from accountdetail ad,billidx b
                               where b.billid=ad.billid and b.billstates=0 and  b.billtype not in (150,151,152,153,155,160,161,162,163,165) and (@szEClass_id='' or b.e_id=@szEClass_id)
                             )b
                        ,account a where b.a_id=a.account_id  Group by b.c_id,b.Y_id)ad
                       ON  ad.c_id=cb.c_id and cb.Y_id=ad.Y_id

                       where c.deleted <> 1)c
                where
                     (@nYClassid='' or C.Yclass_id LIKE @nYClassid+'%')
                 AND ((@ClientTable=0) or (c.c_id in (select [id] from #Clienttable)))
                 AND ((@Companytable=0)or (c.Y_id in (select [id] from #Companytable))) 
		group by c.cclass_id

		select ad.cclass_id as class_id,
		isnull(sum(ad.jdmoney),0) as saletotal
		into #c
		from (select ad.jdmoney,ad.c_id,ad.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(C.Class_id,'')CClass_id,
                      isnull(a.Class_id,'')AClass_id
                      from (select ad.c_id,b.Y_id,ad.a_id,ad.jdmoney from accountdetail ad,billidx B
                             where ad.billid=B.Billid and b.billdate between @BeginDate and @EndDate and 
                                   b.billstates='0' and b.billtype not in (150,151,152,153,155,160,161,162,163,165) and (@szEClass_id='' or b.e_id=@szEClass_id)
                           )ad
                        LEFT JOIN Company  Y ON ad.Y_id=Y.Company_id
                        LEFT JOIN Clients  C ON ad.C_id=C.Client_id
                        LEFT JOIN account  A ON a.account_id=ad.a_id
                      where left(a.class_id,12)='000003000001'
                            and (@nYClassid='' or Y.class_id LIKE @nYClassid+'%')
                      )ad
		where  
                     ((@ClientTable=0) or (ad.c_id in (select [id] from #Clienttable)))
                 AND ((@Companytable=0)or (ad.Y_id in (select [id] from #Companytable)))  
		group by ad.cclass_id
		
		/*select b.cclass_id as class_id,
		isnull(sum(jdmoney),0) as costtotal
		into #d
		from vw_c_adetail ad,vw_c_billidx b
		where (b.billdate between @BeginDate and @EndDate) and b.billid=ad.billid 
		and b.billstates='0' and  left(ad.aclass_id,12)='000004000001'
		group by b.cclass_id*/
             
        select b.cclass_id as class_id,
		ISNULL(SUM(case when b.billtype in (10,12,16,112,53,212) then b.totalmoney else -b.totalmoney end),0) as totalmoney,
		ISNULL(SUM(case when b.billtype in (10,12,16,112,53,212) then b.taxmoney else -b.taxmoney end),0) as taxmoney,
		ISNULL(SUM(case when b.billtype in (10,12,16,112,53,212) then b.quantity else -b.quantity end),0) as SendQTY,
        ISNULL(SUM(case when b.billtype in (10,12,16,112,53,212) then cast(b.totalmoney/b.quantity*b.SendQTY as numeric(25,8)) else -cast(b.totalmoney/b.quantity*b.SendQTY as numeric(25,8)) end),0) as SendTotal,
        ISNULL(SUM(case when b.billtype in (10,12,16,112,53,212) then b.SendCosttotal else -b.SendCosttotal end),0) as costtotal
		into #d
		from 
                  (SELECT YPSM.*,isnull(C.Class_id,'')CClass_id,isnull(Y.Class_id,'')YClass_id
                   FROM  
                      (select sm.quantity,sm.totalmoney,sm.taxmoney,sm.SendQTY,sm.SendCosttotal,b.c_id,b.Y_id,b.billtype
                       FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数  */
                       Inner JOIN billidx b ON b.billid=sm.bill_id
                       where b.billdate between @BeginDate and @EndDate and (@szEClass_id='' or sm.RowE_id=@szEClass_id) and 
                       b.billtype in (10,11,12,13,15,16,17,32,112,53,54,212) and billstates='0' and sm.aoid in (0,5) and sm.p_id>0
                      )YPSM
                      LEFT JOIN Clients C on C.client_id=YPSM.c_id
                      LEFT JOIN Company Y ON Y.Company_id=YPSM.Y_id
                   )b
                  where (@nYClassid='' or b.Yclass_id LIKE @nYClassid+'%')
                 AND ((@ClientTable=0) or (b.c_id in (select [id] from #Clienttable)))
                 AND ((@Companytable=0)or (b.Y_id in (select [id] from #Companytable))) 
		group by b.cclass_id

		select ad.cclass_id as class_id,
		isnull(sum(jdmoney),0) as feetotal
		into #e
		from  (select ad.jdmoney,ad.c_id,ad.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(C.Class_id,'')CClass_id,
                      isnull(a.Class_id,'')AClass_id
                         from (select ad.c_id,ad.Y_id,ad.jdmoney,ad.a_id from accountdetail ad,billidx B 
                                where ad.billid=B.Billid and  b.billdate between @BeginDate and @EndDate and 
                                      b.billstates='0' and b.billtype not in (150,151,152,153,155,160,161,162,163,165) and (@szEClass_id='' or b.e_id=@szEClass_id)
                              )ad
                        LEFT JOIN Company  Y ON ad.Y_id=Y.Company_id
                        LEFT JOIN Clients  C ON ad.C_id=C.Client_id
                        LEFT JOIN account  A ON a.account_id=ad.a_id
                       where left(a.class_id,12)='000004000003'
                       AND (@nYClassid='' or Y.class_id LIKE @nYClassid+'%')   
                      )ad
		where  
                     ((@ClientTable=0) or (ad.c_id in (select [id] from #Clienttable)))
                 AND ((@Companytable=0)or (ad.Y_id in (select [id] from #Companytable)))  
		group by ad.cclass_id

                	
		select ad.cclass_id as class_id,
		isnull(sum(jdmoney),0) as othertotal
		into #f
		from  (select ad.jdmoney,ad.c_id,ad.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(C.Class_id,'')CClass_id,
                      isnull(a.Class_id,'')AClass_id
                         from (select ad.c_id,ad.Y_id,ad.jdmoney,ad.a_id from accountdetail ad,billidx B 
                                where ad.billid=B.Billid and  b.billdate between @BeginDate and @EndDate and 
                                      b.billstates='0' and b.billtype not in (150,151,152,153,155,160,161,162,163,165) and (@szEClass_id='' or b.e_id=@szEClass_id)
                              )ad
                        LEFT JOIN Company  Y ON ad.Y_id=Y.Company_id
                        LEFT JOIN Clients  C ON ad.C_id=C.Client_id
                        LEFT JOIN account  A ON a.account_id=ad.a_id
                       where left(a.class_id,12)='000003000003'
                       AND (@nYClassid='' or Y.class_id LIKE @nYClassid+'%')   
                      )ad
		where  
                     ((@ClientTable=0) or (ad.c_id in (select [id] from #Clienttable)))
                 AND ((@Companytable=0)or (ad.Y_id in (select [id] from #Companytable)))  
		group by ad.cclass_id
		
		select ad.cclass_id as class_id,
		isnull(sum(jdmoney),0) as hktotal
		into #g
		from  (select ad.jdmoney,ad.c_id,ad.Y_id,isnull(Y.Class_id,'')YClass_id,isnull(C.Class_id,'')CClass_id,
                      isnull(a.Class_id,'')AClass_id
                         from (select ad.c_id,ad.Y_id,ad.jdmoney,ad.a_id from accountdetail ad,billidx B 
                                where ad.billid=B.Billid and  b.billdate between @BeginDate and @EndDate and 
                                      b.billstates='0' and b.billtype not in (150,151,152,153,155,160,161,162,163,165) and (@szEClass_id='' or b.e_id=@szEClass_id)
                              )ad
                        LEFT JOIN Company  Y ON ad.Y_id=Y.Company_id
                        LEFT JOIN Clients  C ON ad.C_id=C.Client_id
                        LEFT JOIN account  A ON a.account_id=ad.a_id
                       where left(a.class_id,12) in ('000001000003','000001000004')
                       AND (@nYClassid='' or Y.class_id LIKE @nYClassid+'%')   
                      )ad
		where ((@ClientTable=0) or (ad.c_id in (select [id] from #Clienttable)))
                  AND ((@Companytable=0)or (ad.Y_id in (select [id] from #Companytable)))  
		group by ad.cclass_id


		if @szListFlag='L'  
		begin
			set @szsql='select distinct  * into ##a
				from clients c 
				where c.parent_id='+char(39)+@szParent_id+char(39)+' and deleted <> 1 
                AND ('+cast(@ClientTable as varchar(50))+'=0 or
                exists( select 1 from 
                            ( 
                             select class_id from clients 
                             where exists(select 1 from #Clienttable where id = client_id)
                             ) c1 where left(c1.class_id,len(c.class_id)) = c.class_id 
                       )
                     ) '
		end
		if @szListFlag='A' 
		begin
			set @szsql='select  * into ##a 
			from clients  
			where deleted<>1 and child_number=0
                        AND ('+cast(@ClientTable as varchar(50))+'=0 or (Client_id in (select [id] from #Clienttable)))
                        '
		end
		if @szListFlag='P' 	
		begin
			set @szsql='select  * into ##a
			from clients  
			where left(class_id,len('+char(39)+@szParent_id+char(39)+'))='+char(39)+@szParent_id+char(39)+' and deleted<>1 and child_number=0
                         AND ('+cast(@ClientTable as varchar(50))+'=0 or (Client_id in (select [id] from #Clienttable)))
                         '
		end
		exec (@szsql)	
	  /*  print (@szsql)*/
		
		select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.contact_personal,
		      a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,
		        0.0000 as arlimit, 0.0000 as aplimit,
                isnull(E.[name],'')Ename,
                cename = CASE a.csflag WHEN '0' THEN '客户' WHEN '1' THEN '供应商' WHEN '2' THEN '两者皆是' END,
                ISNULL(r.[name], '') AS RegionName,
                isnull(ct.name,'') as clienttypename,
		ISNULL(SUM(a.[BeginArTotal]), 0) AS [BeginArTotal], 
		ISNULL(SUM(a.[BeginApTotal]), 0) AS [BeginApTotal],
		ISNULL(SUM(a.[NowArTotal]),0) as  [NowArTotal],
		ISNULL(SUM(a.[NowApTotal]), 0) AS [NowApTotal],
		ISNULL(SUM(a.[EndArTotal]), 0) AS [EndArTotal], 
		ISNULL(SUM(a.[EndApTotal]), 0) AS [EndApTotal],
		sum(a.artotal) artotal,
		sum(a.aptotal) aptotal,
		sum(a.saletotal) saletotal,
                sum(a.totalmoney)totalmoney,
                sum(a.taxmoney)taxmoney,
                sum(a.SendQTY) SendQTY,
                sum(a.SendTotal) SendTotal,
		sum(a.costtotal) costtotal,
		sum(a.feetotal) feetotal,
		sum(a.othertotal) othertotal,
		sum(a.hktotal) hktotal
		from 
		(	select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                                a.clienttype_id,
                                a.csflag, 
                                a.contact_personal,
            a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,
				cast(sum(isnull(b.artotal,0)) as numeric(25,8)) as ArTotal,
				cast(sum(isnull(b.aptotal,0)) as numeric(25,8)) as ApTotal,
				ISNULL(SUM(b.[BeginArTotal]), 0) AS [BeginArTotal], 
				ISNULL(SUM(b.[BeginApTotal]), 0) AS [BeginApTotal],
				ISNULL(SUM(b.[NowArTotal]), 0) AS [NowArTotal], 
				ISNULL(SUM(b.[NowApTotal]), 0) AS [NowApTotal],
				ISNULL(SUM(b.[EndArTotal]), 0) AS [EndArTotal], 
				ISNULL(SUM(b.[EndApTotal]), 0) AS [EndApTotal],                               
				0 as SaleTotal,
                                0 as totalmoney,
                                0 as taxmoney,
                                0 as SendQTY,
                                0 as SendTotal,
				0 as CostTotal,
				0 as feetotal,
				0 as othertotal,
				0 as hktotal
	
				from  ##a  as a
				left join #b as b
				on left(b.class_id,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                     a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5          
			union all
			select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                                a.clienttype_id,
                                a.csflag, 
                                a.contact_personal,
                  a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,              	
				0 as ArTotal,
				0 as ApTotal,
				0 AS [BeginArTotal], 
				0 AS [BeginApTotal],
				0 AS [NowArTotal], 
				0 AS [NowApTotal],
				0 AS [EndArTotal], 
				0 AS [EndApTotal],  
				cast(sum(isnull(c.saletotal,0)) as numeric(25,8)) as SaleTotal,
                                0 as totalmoney,
                                0 as taxmoney,
                                0 as SendQTY,
                                0 as SendTotal,
				0 as CostTotal,
				0 as feetotal,
				0 as othertotal,
				0 as hktotal
				from  ##a  as a
				left join  #c as c
				on left(c.class_id ,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                    a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5           
			union all 
				select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
						a.clienttype_id,
						csflag, 
						contact_personal,
				a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,			
				0 as ArTotal,
				0 as ApTotal,
                  		0 AS [BeginArTotal], 
				0 AS [BeginApTotal],
				0 AS [NowArTotal], 
				0 AS [NowApTotal],
				0 AS [EndArTotal], 
				0 AS [EndApTotal],  
				0 as SaleTotal,
                                isnull(sum(d.totalmoney),0) as totalmoney,
                                isnull(sum(d.taxmoney),0) as taxmoney,
                                cast(isnull(sum(d.SendQTY) ,0)  as numeric(25,8)) as SendQTY,
                                cast(isnull(sum(d.SendTotal),0) as numeric(25,8)) as SendTotal,
				cast(sum(isnull(d.costtotal,0)) as numeric(25,8)) as CostTotal,
				0 as feetotal,
				0 as othertotal,
				0 as hktotal
				from  ##a  as a
				left join  #d as d
				on left(d.class_id ,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                    a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5           
			union all
			select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                                a.clienttype_id,
                                a.csflag, 
                                a.contact_personal,
                  a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,              	
				0 as ArTotal,
				0 as ApTotal,
			        0 AS [BeginArTotal], 
				0 AS [BeginApTotal],
				0 AS [NowArTotal], 
				0 AS [NowApTotal],
				0 AS [EndArTotal], 
				0 AS [EndApTotal],  
				0 as SaleTotal,
                                0 as totalmoney,
                                0 as taxmoney,
                                0 as SendQTY,
				0 as SendTotal,
				0 as CostTotal,
				cast(sum(isnull(e.feetotal,0)) as numeric(25,8)) as feetotal,
				0 as othertotal,
				0 as hktotal
				from  ##a  as a
				left join #e as e
				on left(e.class_id,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                     a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5          
			union all 
                        select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                                a.clienttype_id,
                                a.csflag, 
                                a.contact_personal,
                       a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,         	
				0 as ArTotal,
				0 as ApTotal,
                		0 AS [BeginArTotal], 
				0 AS [BeginApTotal],
				0 AS [NowArTotal], 
				0 AS [NowApTotal],
				0 AS [EndArTotal], 
				0 AS [EndApTotal],  
				0 as SaleTotal,
                                0 as totalmoney,
                                0 as taxmoney,
                                0 as SendQTY,
				0 as SendTotal,
				0 as CostTotal,
				0 as feetotal,
				cast(sum(isnull(f.othertotal,0)) as numeric(25,8)) as othertotal,
				0 as hktotal
				from  ##a  as a
				left join #f as f
				on left(f.class_id,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                     a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5          
			union all 
                        select a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                                a.clienttype_id,
                                a.csflag, 
                                a.contact_personal,
                         a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,       	
				0 as ArTotal,
				0 as ApTotal,
        			0 AS [BeginArTotal], 
				0 AS [BeginApTotal],
				0 AS [NowArTotal], 
				0 AS [NowApTotal],
				0 AS [EndArTotal], 
				0 AS [EndApTotal],  
				0 as SaleTotal,
                                0 as totalmoney,
                                0 as taxmoney,
                                0 as SendQTY,
				0 as SendTotal,
				0 as CostTotal,
				0 as feetotal,
				0 as othertotal,
				cast(sum(isnull(g.hktotal,0)) as numeric(25,8)) as hktotal
				from  ##a  as a
				left join #g as g
				on left(g.class_id,len(a.class_id))=a.class_id
			group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,a.e_id,a.region_id,
                               a. clienttype_id,a.csflag, a.contact_personal,
                     a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5          
		) a 
                Left join Employees  E  ON a.e_id=E.emp_id
                LEFT JOIN Region     r  ON a.region_id = r.region_id
                LEFT JOIN clienttype ct ON a.clienttype_id = ct.clienttype_id                    
               where (@szCClass_id in ('%%','') or a.client_id=@szCClass_id)
                group by a.client_id,a.class_id,a.child_number,a.[name],a.alias,a.serial_number,contact_personal,
                a.address,a.phone_number,a.discount,a.acount_number,a.C_Customname1,a.C_Customname2,a.C_Customname3,a.C_Customname4,a.C_Customname5,
                              e.name,ct.name,a.csflag,r.name
	drop table ##a
	return 0
  end

  if @nMode=1
  begin
		declare @nCid int
		declare @nClassLen int
		if @szListflag = 'P'
			set @nClassLen = 30
		else
		if @szListflag = 'L'
		begin
			if @szParent_id in ('', '000000')
				set @nClassLen = 6
			else
				set @nClassLen = LEN(@szParent_id) + 6
		end
		
		select @nCid = client_id from clients where class_id = @szCClass_id
		select company_id into #tmpYid from company where deleted <> 1 and class_id like @nYClassid + '%' and (@Companytable = 0 OR company_id in (select ID from #Companytable))
		
		if @szListflag = 'A'
		begin
SELECT     e.class_id, e.emp_id AS client_id, e.name, CASE WHEN ISNULL(ini.jd, 0) > 0 THEN ini.jd ELSE 0 END AS beginArTotal, 
                      CASE WHEN ISNULL(ini.jd, 0) < 0 THEN - ini.jd ELSE 0 END AS beginApTotal, CASE WHEN ISNULL(ed.jd, 0) > 0 THEN ed.jd ELSE 0 END AS endArTotal, 
                      CASE WHEN ISNULL(ed.jd, 0) < 0 THEN - ed.jd ELSE 0 END AS endApTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) > 0 THEN ISNULL(ed.jd, 0) 
                      - ISNULL(ini.jd, 0) ELSE 0 END AS nowArTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) < 0 THEN ISNULL(ini.jd, 0) - ISNULL(ed.jd, 0) 
                      ELSE 0 END AS nowApTotal, ISNULL(sl.sale, 0) AS saleTotal, ISNULL(sd.totalmoney, 0) AS totalmoney, ISNULL(sd.taxmoney, 0) AS taxmoney, 
                      CAST(ISNULL(sd.SendTotal, 0) AS numeric(25,8)) AS SendTotal, ISNULL(sd.SendCostTotal, 0) AS costtotal, ISNULL(hk.jdmoney, 0) AS hkTotal, e.artotal, 
                      e.aptotal, e.arlimit, e.aplimit, ' ' AS contact_personal, ' ' AS ename, e.serial_number, e.child_number, ' ' AS cename, ' ' AS regionname, 
                      ' ' AS clienttypename, e.alias, ISNULL(fe.fee, 0) AS feeTotal, ISNULL(ot.other, 0) AS otherTotal
FROM         dbo.employees AS e LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, i.e_id
                            FROM          dbo.billidx AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   dbo.employees AS e ON i.e_id = e.emp_id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate < @BeginDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY i.e_id) AS ini ON e.emp_id = ini.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, i.e_id
                            FROM          dbo.billidx AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   dbo.employees AS e ON i.e_id = e.emp_id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate <= @EndDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY i.e_id) AS ed ON e.emp_id = ed.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS sale, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND 
                                                   (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (ad.a_id = 20) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY i.e_id) AS sl ON e.emp_id = sl.e_id LEFT OUTER JOIN
                          (SELECT     e_id, SUM(totalmoney * dir) AS totalmoney, SUM(taxmoney * dir) AS taxmoney, SUM(SendQTY * dir) AS SendQTY, SUM(SendTotal * dir) 
                                                   AS SendTotal, SUM(SendCostTotal * dir) AS SendCostTotal
                            FROM          (SELECT     i.e_id, sb.totalmoney, sb.taxmoney, sb.SendQTY, sb.totalmoney / sb.quantity * sb.SendQTY AS SendTotal, sb.SendCostTotal, 
                                                                           CASE WHEN i.billtype IN (10, 12, 16, 112, 53, 212) THEN 1 ELSE - 1 END AS dir
                                                    FROM          dbo.billidx AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id*/
                                                                           salemanagebill AS sb ON i.billid = sb.bill_id      /*XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
                                                    WHERE      (i.billtype IN (10, 11, 12, 13, 15, 16, 17, 32, 112, 53, 54, 212)) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND (sb.p_id > 0) AND 
                                                                           (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))) AS snd
                            GROUP BY e_id) AS sd ON e.emp_id = sd.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS jdmoney, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid
                            WHERE      (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account
                                                         WHERE      (account_id = 6) OR
                                                                                (class_id LIKE '000001000004%'))) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND 
                                                   (i.billdate BETWEEN @BeginDate AND @EndDate) AND 
                                                   (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id)
                            GROUP BY i.e_id) AS hk ON e.emp_id = hk.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS fee, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_2
                                                         WHERE      (class_id LIKE '000004000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid))
                            GROUP BY i.e_id) AS fe ON e.emp_id = fe.e_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS other, i.e_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_1
                                                         WHERE      (class_id LIKE '000003000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid))
                            GROUP BY i.e_id) AS ot ON e.emp_id = ot.e_id
WHERE     (e.emp_id > 1) AND (e.deleted <> 1) AND (e.child_number = 0)
order by e.emp_id
		end
		else
		begin
			select * into #tmpEidL from getsubnodes(@szParent_id, 'L', 'E', 0)
			select * into #tmpEidP from getsubnodes(@szParent_id, 'P', 'E', 0)
			
			select top 0 0 as emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted into #tmpE from employees
			if @szListflag = 'L'
				insert into #tmpE select emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted from employees where emp_id in (select id from #tmpEidL)
			else
			if @szListflag = 'P'
				insert into #tmpE select emp_id, class_id, child_number, artotal, aptotal, arlimit, aplimit, name, serial_number, alias, deleted from employees where emp_id in (select id from #tmpEidP)
				
	
	SELECT     e.class_id, e.emp_id AS client_id, e.name, CASE WHEN ISNULL(ini.jd, 0) > 0 THEN ini.jd ELSE 0 END AS beginArTotal,
	            '' as address,'' as phone_number,0.0 as discount,'' as acount_number,'' as  C_Customname1,'' as  C_Customname2,'' as C_Customname3,'' as C_Customname4,'' as C_Customname5,
						  CASE WHEN ISNULL(ini.jd, 0) < 0 THEN - ini.jd ELSE 0 END AS beginApTotal, CASE WHEN ISNULL(ed.jd, 0) > 0 THEN ed.jd ELSE 0 END AS endArTotal, 
						  CASE WHEN ISNULL(ed.jd, 0) < 0 THEN - ed.jd ELSE 0 END AS endApTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) > 0 THEN ISNULL(ed.jd, 0) 
						  - ISNULL(ini.jd, 0) ELSE 0 END AS nowArTotal, CASE WHEN ISNULL(ed.jd, 0) - ISNULL(ini.jd, 0) < 0 THEN ISNULL(ini.jd, 0) - ISNULL(ed.jd, 0) 
						  ELSE 0 END AS nowApTotal, ISNULL(sl.sale, 0) AS saleTotal, ISNULL(sd.totalmoney, 0) AS totalmoney, ISNULL(sd.taxmoney, 0) AS taxmoney, 
						  CAST(ISNULL(sd.SendTotal, 0) AS numeric(25,8)) AS SendTotal, ISNULL(sd.SendCostTotal, 0) AS costtotal, ISNULL(hk.jdmoney, 0) AS hkTotal, rp.artotal, 
						  rp.aptotal, e.arlimit, e.aplimit, ' ' AS contact_personal, ' ' AS ename, e.serial_number, e.child_number, ' ' AS cename, ' ' AS regionname, 
						  ' ' AS clienttypename, e.alias, ISNULL(fe.fee, 0) AS feeTotal, ISNULL(ot.other, 0) AS otherTotal
	FROM         (select * from #tmpE) AS e LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.billidx AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate < @BeginDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY Left(e.class_id, @nClassLen)) AS ini ON e.class_id = ini.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney * (- ((ad.a_id - 9) / 3) + 1)) AS jd, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.billidx AS i INNER JOIN
                                                   dbo.accountdetail AS ad ON i.billid = ad.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (ad.a_id IN (9, 15)) AND (i.billdate <= @EndDate) AND 
                                                   (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND 
                                                   (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
                            GROUP BY Left(e.class_id, @nClassLen)) AS ed ON e.class_id = ed.class_id LEFT OUTER JOIN
                          (
                             select SUM(a.totalmoney*a.dir) as sale,a.class_id from
							   (
								select   case  when  i.billtype in (10, 12, 16, 112, 53, 212) then 1 else -1  end as dir,
								smb.totalmoney as totalmoney,
								Left(e.class_id, @nClassLen) as class_id 
								from billidx i inner join salemanagebill smb on i.billid = smb.bill_id
								inner join #tmpEidP AS e ON smb.RowE_id = e.id
								WHERE      (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND 
										   (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))
								) a group by a.class_id
                            ) AS sl ON e.class_id = sl.class_id LEFT OUTER JOIN
                          (SELECT     class_id, SUM(totalmoney * dir) AS totalmoney, SUM(taxmoney * dir) AS taxmoney, SUM(SendQTY * dir) AS SendQTY, SUM(SendTotal * dir) 
                                                   AS SendTotal, SUM(SendCostTotal * dir) AS SendCostTotal
                            FROM          (SELECT     Left(e.class_id, @nClassLen) as class_id, sb.totalmoney, sb.taxmoney, sb.SendQTY, sb.totalmoney / sb.quantity * sb.SendQTY AS SendTotal, sb.SendCostTotal, 
                                                                           CASE WHEN i.billtype IN (10, 12, 16, 112, 53, 212) THEN 1 ELSE - 1 END AS dir
                                                    FROM          dbo.billidx AS i INNER JOIN
                                                                           /*dbo.FilterSalemanagebill(@nloginEID) AS sb ON i.billid = sb.bill_id INNER JOIN*/
                                                                           salemanagebill AS sb ON i.billid = sb.bill_id INNER JOIN      /*XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
																		   #tmpEidP AS e ON i.e_id = e.id
                                                    WHERE      (i.billtype IN (10, 11, 12, 13, 15, 16, 17, 32, 112, 53, 54, 212)) AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND (sb.p_id > 0) AND
                                                                           (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable)))) AS snd
                            GROUP BY class_id) AS sd ON e.class_id = sd.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS jdmoney, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account
                                                         WHERE      (account_id = 6) OR
                                                                                (class_id LIKE '000001000004%'))) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND 
                                                   (i.billdate BETWEEN @BeginDate AND @EndDate) AND 
                                                   (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id)
                            GROUP BY Left(e.class_id, @nClassLen)) AS hk ON e.class_id = hk.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS fee, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_2
                                                         WHERE      (class_id LIKE '000004000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND
                                                         (i.billdate BETWEEN @BeginDate AND @EndDate)
                            GROUP BY Left(e.class_id, @nClassLen)) AS fe ON e.class_id = fe.class_id LEFT OUTER JOIN
                          (SELECT     SUM(ad.jdmoney) AS other, Left(e.class_id, @nClassLen) as class_id
                            FROM          dbo.accountdetail AS ad INNER JOIN
                                                   dbo.billidx AS i ON ad.billid = i.billid INNER JOIN
                                                   #tmpEidP AS e ON i.e_id = e.id
                            WHERE      (@szCClass_id IN ('%%','') or i.c_id = @nCid) AND (NOT (i.billtype IN (150, 151, 152, 153, 155, 160, 161, 162, 163, 165))) AND (i.billstates = '0') AND ((@employeestable = 0) OR (i.e_id in (select [id] from #employeestable))) AND (ad.a_id IN
                                                       (SELECT     account_id
                                                         FROM          dbo.account AS account_1
                                                         WHERE      (class_id LIKE '000003000003%'))) AND (@nRegion_id = 0 OR i.region_id = @nRegion_id) AND (i.Y_ID IN (select company_id FROM #tmpYid)) AND
                                                         (i.billdate BETWEEN @BeginDate AND @EndDate)
                            GROUP BY Left(e.class_id, @nClassLen)) AS ot ON e.class_id = ot.class_id LEFT OUTER JOIN
                           (SELECT     Left(e.class_id, @nClassLen) as class_id, CASE WHEN SUM(aptotal) - SUM(artotal) > 0 THEN SUM(aptotal) - SUM(artotal) ELSE 0 END AS aptotal, CASE WHEN SUM(aptotal) - SUM(artotal) < 0 THEN SUM(artotal) - SUM(aptotal) ELSE 0 END AS artotal
							FROM         dbo.employees i INNER JOIN #tmpEidP AS e ON i.emp_id = e.id
							GROUP BY Left(e.class_id, @nClassLen)) AS rp ON e.class_id = rp.class_id
	WHERE     (e.emp_id > 1) AND (e.deleted <> 1)
	order by e.emp_id
	return 0
  end
  end
GO
