




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

采购销售明细帐本

********************************************/
CREATE PROCEDURE TS_C_QrSaleBuyDetail
(	@BeginDate 		DATETIME,
	@EndDate 		DATETIME,
	@szPClass_Id 	        VARCHAR(30),
	@szSClass_Id 	        VARCHAR(30),
	@szCClass_id	        VARCHAR(30),
	@szEClass_id	        VARCHAR(30),
	@nStoreType 	        INT=0,
	@nFlag			INT=0,/*=0 buy;=1 sale;*/
        @nYClassid              Varchar(50)='',
        @nloginEID              int=0,
        @isaddDate              int=0 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nStoreType is null  SET @nStoreType = 0
if @nFlag is null  SET @nFlag = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/
  /*SET NOCOUNT ON*/
 
  Declare @ClientTable int,@Companytable int,@employeestable int,@Storetable int

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


  if  @szPClass_Id in ('','%%','000000') set @szPClass_Id='%%' else set @szPClass_Id=@szPClass_Id+'%' 
  if  @szSClass_Id in ('','%%','000000') set @szSClass_Id='%%' else set @szSClass_Id=@szSClass_Id+'%'
  if  @szCClass_id in ('','%%','000000') set @szCClass_id='%%' else set @szCClass_id=@szCClass_id+'%'
  if  @szEClass_id in ('','%%','000000') set @szEClass_id='%%' else set @szEClass_id=@szEClass_id+'%'
  if  @nYClassid   in ('','%%','000000') set @nYClassid='%%'   else set @nYClassid=@nYClassid+'%' 

if @nFlag=0
begin
SELECT BMD.* FROM 
  (SELECT   billid,billtype,billdate,billnumber,p.inputman,p.auditman,p.c_id,p.RowE_id,p.y_ID,p.S_ID,
	    note,summary,billstates,batchno,price,taxprice,validdate,makedate, p.[comment],
                (case when billtype in (20,35,122,24,220) then p.quantity else -p.quantity end) as quantity,
            cast((case when billtype in (20,35,122,24,220) then p.costtotal else -p.costtotal end) as numeric(25,8)) as costtotal,
                (case when billtype in (20,35,122,24,220) then p.taxtotal  else -p.taxtotal end) as taxtotal,
		cast(p.costprice as numeric(25,8))costprice,
                (case when billtype in (20,35,122,24,220) then p.totalMoney else -p.totalMoney end) as total,
                (case when billtype in (20,35,122,24,220) then p.sendQTY else -p.SendQTY end)SendQTY,
                (case when billtype in (20,35,122,24,220) then p.Sendcosttotal else -p.Sendcosttotal end)Sendcosttotal,
                (case when billtype in (20,35,122,24,220) then (p.SendQTY*p.totalmoney/p.quantity) else (-p.SendQTY*p.totalmoney/p.quantity) end)SendTotal,
                /*(-p.SendQTY*p.totalmoney/p.quantity)+p.Sendcosttotal as mltotal,*/
                cast(0 as numeric(18,6)) as mltotal,
	    invoicetype=(
             case invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
		billname=CASE billtype 
		  WHEN 10 THEN '销售出库单'
		  WHEN 11 THEN '销售出库退货单'
		  WHEN 16 THEN '销售结算调价'
		  WHEN 17 THEN '销售退货结算调价'
		  WHEN 53 THEN '配送出库单'
		  WHEN 54 THEN '配送出库退货单'
		  WHEN 12 THEN '零售单'
		  WHEN 13 THEN '零售退货单'
		  WHEN 20 THEN '采购入库单'
		  WHEN 21 THEN '采购入库退货单'
                  WHEN 24 THEN '采购结算调价'
                  WHEN 25 THEN '采购退货结算调价'
		  WHEN 112 THEN '委托代销结算单'
		  WHEN 122 THEN '受托代销结算单'
                  WHEN 210 THEN '销售单'
                  WHEN 211 THEN '销售退货单'     
                  WHEN 220 THEN '采购单'
                  WHEN 221 THEN '采购退货单'
		END,
		ISNULL(vp.[name],'') AS productname,
		ISNULL(s.[name],'') AS storagename,
		ISNULL(e.[name],'') AS employeename,		
		ISNULL(IE.[name],'') AS Inputmanname,
		ISNULL(AE.[name],'') AS Auditmanname,
		ISNULL(a.[name],'') AS accountname,
                ISNULL(C.[name],'')Cname,
                ISNULL(vp.[standard], '') AS [standard], 
                ISNULL(vp.[permitcode], '') AS [permitcode], 
                ISNULL(M.name,'')  AS [medtype], 
                ISNULL(vp.[makearea], '') AS [makearea], 
                ISNULL(vp.[Serial_Number], '') AS [code],
                isnull(f.AccountComment,'') as factory,
                isnull(vp.alias,'') as alias,
                isnull(vp.comment,'') as pcomment,
                ISNULL(U1.[Name], '')unitname1,
		ISNULL(L.loc_name,'') AS locationname,
		ISNULL(SP.[name],'') AS suppliername,
	 inouttype=case p.commissionflag
		WHEN 0 THEN '一般'
		WHEN 1 THEN '委托代销'
		WHEN 2 THEN '受托代销'
		WHEN 3 THEN '借出'
		WHEN 4 THEN '借进'
		end,
           isnull(C.Class_id,'')CClass_id,isnull(S.Class_id,'')SClass_id,isnull(E.Class_id,'')EClass_id,
           isnull(VP.Class_id,'')PClass_id,isnull(Y.Class_id,'')YClass_id
   FROM 
     (SELECT   b.billid,b.billtype,b.billdate,b.billnumber,b.inputman,b.auditman,b.invoice,b.c_id,b.Y_id,a_id,sm.p_id,
               b.note,b.summary,b.billstates,sm.batchno,cast((sm.total/sm.quantity) as numeric(25,8))price,
               cast((sm.taxtotal/sm.quantity) as numeric(25,8))taxprice,sm.validdate,sm.commissionflag,sm.ss_id as s_id,
               sm.RowE_id,sm.makedate,sm.[comment],sm.Location_id,sm.supplier_id,sm.quantity,(sm.quantity*sm.Costprice)Costtotal,
               sm.taxtotal,sm.costprice,sm.totalmoney,sm.SendQTY,sm.SendCosttotal
        from buymanagebill sm  
          LEFT  JOIN Billidx b ON B.billid=sm.bill_id 
       where b.billtype in (20,21,35,122,24,25,220,221) and b.billdate BETWEEN @BeginDate AND @Enddate  and 
         /*b.billstates=0 and */
         sm.p_id>0 
        
     )P  

      LEFT JOIN Products  vp  ON p.p_id=vp.product_id
      left join basefactory f on vp.factoryc_id=f.CommID
      LEFT JOIN Unit      U1  ON vP.[Unit1_ID]=U1.[Unit_ID]  
      left   join 
	  (
			select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on vp.product_id = m.baseinfo_id
      LEFT JOIN Clients   C   ON C.Client_id=p.c_id
      LEFT JOIN storages  S   ON S.storage_id=P.s_id
      LEFT JOIN Employees E   ON E.emp_id=p.RowE_ID
      LEFT JOIN employees AE  ON AE.emp_id=p.auditman
      LEFT JOIN employees IE  ON IE.emp_id=p.inputman
      LEFT JOIN Account   A   ON A.account_id=p.a_id
      LEFT JOIN location  L   ON L.loc_id=p.location_id
      LEFT JOIN Clients   SP  ON SP.Client_id=p.supplier_id
      LEFT JOIN Company   Y   ON Y.Company_id=P.Y_id
 )BMD
 WHERE ((@Companytable=0)or (BMD.Y_id in (select [id] from #Companytable)))  
   AND ((@ClientTable=0) or (BMD.c_id in (select [id] from #Clienttable)))
   AND ((@Storetable=0) OR (BMD.s_id in (select [id] from #storagestable))) 
   AND ((@employeestable=0) OR (BMD.RowE_id in (select [id] from #employeestable)))
   and BMD.YClass_id like @nYClassid
   and BMD.PClass_id like @szPClass_Id
   and BMD.SClass_id like @szSClass_Id
   and BMD.CClass_id like @szCClass_Id
   and BMD.EClass_id like @szEClass_Id
 ORDER BY billdate ,billid
end
else
begin
SELECT SMD.* FROM 
  (SELECT   billid,billtype,billdate,billnumber,p.inputman,p.auditman,p.c_id,p.RowE_id,p.y_ID,p.S_ID,
	    note,summary,billstates,batchno,price,taxprice,validdate,makedate, p.[comment],
                (case when billtype in (10,12,32,112,53,16,210) then p.quantity else -p.quantity end) as quantity,
            cast((case when billtype in (10,12,32,112,53,16,210) then p.costtotal else -p.costtotal end) as numeric(25,8)) as costtotal,
                (case when billtype in (10,12,32,112,53,16,210) then p.taxtotal  else -p.taxtotal end) as taxtotal,
		cast(p.costprice as numeric(25,8))costprice,
                (case when billtype in (10,12,32,112,53,16,210) then p.totalMoney else -p.totalMoney end) as total,
                (case when billtype in (10,12,32,112,53,16,210) then p.sendQTY else -p.SendQTY end)SendQTY,
                (case when billtype in (10,12,32,112,53,16,210) then p.Sendcosttotal else -p.Sendcosttotal end)Sendcosttotal,
                (case when billtype in (10,12,32,112,53,16,210) then (p.SendQTY*p.totalmoney/p.quantity) else (-p.SendQTY*p.totalmoney/p.quantity) end)SendTotal,
                (case when billtype in (10,12,32,112,53,16,210) then cast(((p.SendQTY*p.totalmoney/p.quantity)-p.Sendcosttotal) as numeric(18,6))
                 else cast((-(p.SendQTY*p.totalmoney/p.quantity)+p.Sendcosttotal) as numeric(18,6)) end)mltotal,
	    invoicetype=(
             case invoice when 0 then '无' when 1 then '收据' when 2 then '普票' when 3 then '增值税票' else '其他' end),
		billname=CASE billtype 
		  WHEN 10 THEN '销售出库单'
		  WHEN 11 THEN '销售出库退货单'
		  WHEN 16 THEN '销售结算调价'
		  WHEN 17 THEN '销售退货结算调价'
		  WHEN 53 THEN '配送出库单'
		  WHEN 54 THEN '配送出库退货单'
		  WHEN 12 THEN '零售单'
		  WHEN 13 THEN '零售退货单'
		  WHEN 20 THEN '采购入库单'
		  WHEN 21 THEN '采购出库退货单'
                  WHEN 24 THEN '采购结算调价'
                  WHEN 25 THEN '采购退货结算调价'
		  WHEN 112 THEN '委托代销结算单'
		  WHEN 122 THEN '受托代销结算单'
                  WHEN 210 THEN '销售单'
                  WHEN 211 THEN '销售退货单'     
                  WHEN 220 THEN '采购单'
                  WHEN 221 THEN '采购退货单'
		END,
		ISNULL(vp.[name],'') AS productname,
		ISNULL(s.[name],'') AS storagename,
		ISNULL(e.[name],'') AS employeename,
		ISNULL(IE.[name],'') AS Inputmanname,
		ISNULL(AE.[name],'') AS Auditmanname,
		ISNULL(a.[name],'') AS accountname,
                ISNULL(C.[name],'')Cname,
                ISNULL(vp.[standard], '') AS [standard], 
                ISNULL(vp.[permitcode], '') AS [permitcode], 
                ISNULL(M.name,'')  AS [medtype], 
                ISNULL(vp.[makearea], '') AS [makearea], 
                ISNULL(vp.[Serial_Number], '') AS [code],
                isnull(f.AccountComment,'') as factory,
                isnull(vp.alias,'') as alias,
                isnull(vp.comment,'') as pcomment,
                ISNULL(U1.[Name], '')unitname1,
		ISNULL(L.loc_name,'') AS locationname,
		ISNULL(SP.[name],'') AS suppliername,
	 inouttype=case p.commissionflag
		WHEN 0 THEN '一般'
		WHEN 1 THEN '委托代销'
		WHEN 2 THEN '受托代销'
		WHEN 3 THEN '借出'
		WHEN 4 THEN '借进'
		end,
           isnull(C.Class_id,'')CClass_id,isnull(S.Class_id,'')SClass_id,isnull(E.Class_id,'')EClass_id,
           isnull(VP.Class_id,'')PClass_id,isnull(Y.Class_id,'')YClass_id
   FROM 
     (SELECT   b.billid,b.billtype,b.billdate,b.billnumber,b.inputman,b.auditman,b.invoice,b.c_id,b.Y_id,a_id,sm.p_id,
               b.note,b.summary,b.billstates,sm.batchno,cast((sm.total/sm.quantity) as numeric(25,8))price,
               cast((sm.taxtotal/sm.quantity)as numeric(25,8))taxprice,sm.validdate,sm.commissionflag,sm.ss_id as s_id,
               sm.RowE_id,sm.makedate,sm.[comment],sm.Location_id,sm.supplier_id,sm.quantity,(sm.quantity*sm.Costprice)Costtotal,
               sm.taxtotal,sm.costprice,sm.totalmoney,sm.SendQTY,sm.SendCosttotal
        FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID) sm   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数    */
          LEFT  JOIN Billidx b ON B.billid=sm.bill_id 
       where b.billtype in (10,11,12,13,112,53,54,16,17,210,211) and b.billdate BETWEEN @BeginDate AND @Enddate 
         /*and b.billstates=0 */
         and sm.p_id>0
         
     )P  

      LEFT JOIN Products  vp  ON p.p_id=vp.product_id
      left join basefactory f on vp.factoryc_id=f.CommID
      LEFT JOIN Unit      U1  ON vP.[Unit1_ID]=U1.[Unit_ID]  
      left   join 
	  (
			select name,baseinfo_id from customCategory a inner join customCategoryMapping b on a.id=b.category_id where b.BaseTypeid=0 and a.Typeid=2 and b.deleted=0
	  )m on vp.product_id = m.baseinfo_id
      LEFT JOIN Clients   C   ON C.Client_id=p.c_id
      LEFT JOIN storages  S   ON S.storage_id=P.s_id
      LEFT JOIN employees AE  ON AE.emp_id=p.auditman
      LEFT JOIN employees IE  ON IE.emp_id=p.inputman
      LEFT JOIN Employees E   ON E.emp_id=p.RowE_ID
      LEFT JOIN Account   A   ON A.account_id=p.a_id
      LEFT JOIN location  L   ON L.loc_id=p.location_id
      LEFT JOIN Clients   SP  ON SP.Client_id=p.supplier_id
      LEFT JOIN Company   Y   ON Y.Company_id=P.Y_id
 )SMD
 WHERE ((@Companytable=0)or (SMD.Y_id in (select [id] from #Companytable)))  
   AND ((@ClientTable=0) or (SMD.c_id in (select [id] from #Clienttable)))
   AND ((@Storetable=0) OR (SMD.s_id in (select [id] from #storagestable)))
   AND ((@employeestable=0) OR (SMD.RowE_id in (select [id] from #employeestable)))
   and SMD.YClass_id like @nYClassid
   and SMD.PClass_id like @szPClass_Id
   and SMD.SClass_id like @szSClass_Id
   and SMD.CClass_id like @szCClass_Id
   and SMD.EClass_id like @szEClass_Id
 ORDER BY billdate ,billid 
END
  GOTO SUCCEE

SUCCEE:
  RETURN 0
GO
