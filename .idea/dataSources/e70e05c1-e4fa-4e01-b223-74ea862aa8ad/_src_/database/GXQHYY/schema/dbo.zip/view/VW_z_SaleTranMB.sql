

CREATE VIEW dbo.VW_z_SaleTranMB
AS
SELECT smb_id, bill_id, p_id,pclass_id, batchno, quantity, costprice, saleprice, discount, 
      discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
      makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
      commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, 
      newprice, orgbillid, AOID, invoice, invoiceno, ssclass_id, sdclass_id, ssname, 
      sdname, unitname,SendQTY,SendCostTotal,suppliername,locname,RowE_id,REclass_ID,REname,
      YCostPrice
FROM dbo.vw_c_salemb
UNION ALL
SELECT smb_id, bill_id, p_id,PClass_id, batchno, quantity, costprice, saleprice, discount, 
      discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, 
      makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
      commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, 
      newprice, orgbillid, AOID, invoice, invoiceno, ssclass_id, sdclass_id, ssname, 
      sdname, unitname,SendQTY,SendCostTotal,suppliername,locname,RowE_id,REclass_ID,REname,
      '0' as YCostPrice
FROM dbo.vw_c_Tranmb
GO
