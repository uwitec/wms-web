


CREATE VIEW dbo.vw_z_TCManageBill
AS
SELECT smb_id, bill_id, p_id, batchno, quantity, costprice, saleprice, discount, 
      discountprice, totalmoney, taxprice, taxmoney, taxtotal, retailprice, retailtotal, 
      makedate, validdate, qualitystatus, price_id, sd_id, ss_id, location_id, supplier_id, 
      commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, 
      newprice, orgbillid, AOID, invoice, invoiceno
FROM dbo.salemanagebill
UNION ALL
SELECT smb_id, bill_id, p_id, batchno, quantity, costprice, saleprice, discount, 
      discountprice, totalmoney, taxprice, taxmoney, taxtotal, retailprice, retailtotal, 
      makedate, validdate, qualitystatus, price_id, sd_id, ss_id, location_id, supplier_id, 
      commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, 
      newprice, orgbillid, AOID, invoice, invoiceno
FROM dbo.TranManagebill
GO
