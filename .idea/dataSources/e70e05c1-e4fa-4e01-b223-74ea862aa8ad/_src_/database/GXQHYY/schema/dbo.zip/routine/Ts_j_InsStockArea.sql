
CREATE PROCEDURE [Ts_j_InsStockArea]
	(@s_id		[int],
	 @szCode	[varchar](30),
	 @szName	[varchar](30),
	 @szComment	[varchar](20),
     @sa_id    int     
)

AS 
if @sa_id = 0 
begin
   select * from stockArea
	INSERT INTO [stockarea] 
		 ( [s_id],
		 [serial_number],
		 [name],
		 [comment])		 
	VALUES 
		( @s_id,
		 @szCode,
		 @szName,
		 @szComment
		)
	if @@rowCount=0 
		return -1
	else 
		return @@IDENTITY

end
else begin
  update stockArea
     set [s_id] = @s_id,
		 [serial_number] = @szCode,		 
		 [name] = @szName,
		 [comment] = @szComment	             
   where  sa_id = @sa_id 
      
    if @@ERROR <> 0 
		return -1
	else 
		return @@IDENTITY  

end
GO
