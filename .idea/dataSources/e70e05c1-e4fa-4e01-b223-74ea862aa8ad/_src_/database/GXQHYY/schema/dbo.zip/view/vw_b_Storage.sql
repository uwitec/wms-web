

CREATE	VIEW dbo.vw_b_Storage
AS
SELECT storage_id as s_id, name as s_name,WholeFlag
FROM storages 
WHERE deleted = 0
GO
