


CREATE	VIEW dbo.vw_b_client
AS
SELECT client_id as c_id, name as c_name, Serial_Number as c_code
FROM clients
WHERE deleted <> 1
GO
