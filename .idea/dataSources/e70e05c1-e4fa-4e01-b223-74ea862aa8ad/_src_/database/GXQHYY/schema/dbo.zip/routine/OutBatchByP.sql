




CREATE  FUNCTION [OutBatchByP] (@nP_id int)  
returns @retSaleQty table 
  (p_id int,
   s_id int,
   batchno varchar(50),
   supplier_id int,
   location_id int,
   commissionflag int,
   costprice numeric(25,8),
   validdate datetime,
   quantity numeric(25,8),
   instoretime datetime
  )
AS  
begin
  declare @CheckSaleQty char(1)
	declare @nCalcOrder int
	set @nCalcOrder = 0
	set @CheckSaleQty='0'
	select @CheckSaleQty=sysvalue from sysconfig where [sysname]='CheckSaleQty'/*存草稿是是否检测可开数量*/
	if exists(select * from sysconfigtmp where sysname = 'GspStandardProcess' and sysvalue = '1')
		set @nCalcOrder = 1

  if @CheckSaleQty='0' or @CheckSaleQty='1'
  begin
    insert @retSaleQty  
    select k.p_id,k.ss_id as s_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate,isnull(sum(quantity),0) as quantity, k.instoretime
    from (
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
    	from salemanagebilldrf sb,billdraftidx b 
    	where (@nCalcOrder = 0) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and sb.aoid in (0,7)
        group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all 
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (21,121,221) then -sb.quantity else sb.quantity end) as quantity
    	from buymanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (21,121,221) and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (40,41,44,45,47,49) then -sb.quantity else sb.quantity end) as quantity
    	from storemanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (40,41,44,45,49) and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all  /*-包含库存批次调整单 add by luowei 2013-12-11*/
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (51) then -sb.quantity else sb.quantity end) as quantity
    	from storemanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and iotag = 0 and p_id=@nP_id and b.billtype in (51) and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (53,56) then -sb.quantity else sb.quantity end) as quantity
    	from tranmanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (53,56) and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (14) then -sb.quantity else sb.quantity end) as quantity
    	from OrderBill sb,orderidx b 
    	where (@nCalcOrder = 1) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (14) and b.billstates <> 0
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    ) k
    group by k.p_id,k.ss_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate, k.instoretime
    
  end else if @CheckSaleQty='2'
  begin
    insert @retSaleQty  
    select k.p_id,k.ss_id as s_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate,isnull(sum(quantity),0) as quantity, k.instoretime
    from (
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (10,110,210,152)  then -sb.quantity else sb.quantity end) as quantity
    	from salemanagebilldrf sb,billdraftidx b 
    	where (@nCalcOrder = 0) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (10,110,210,152) and b.billstates in ('3','7','8') and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all 
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (21,121,221) then -sb.quantity else sb.quantity end) as quantity
    	from buymanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (21,121,221) and b.billstates in ('3','7','8') and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (40,41,44,45,47,49) then -sb.quantity else sb.quantity end) as quantity
    	from storemanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and p_id=@nP_id and b.billtype in (40,41,44,45,49) and b.billstates='3' and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all /*增加库存批次调整单 add by luowei 2013-12-11*/
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (51) then -sb.quantity else sb.quantity end) as quantity
    	from storemanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid and p_id=@nP_id and iotag = 0 and b.billtype in (51) and b.billstates='3' and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (53,56) then -sb.quantity else sb.quantity end) as quantity
    	from tranmanagebilldrf sb,billdraftidx b 
    	where sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (53,56) and b.billstates='3' and sb.aoid in (0,7)
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    	union all
    	select sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime,
    	sum(case when b.billtype in (14) then -sb.quantity else sb.quantity end) as quantity
    	from OrderBill sb,orderidx b 
    	where (@nCalcOrder = 1) and sb.bill_id=b.billid  and p_id=@nP_id and b.billtype in (14) and b.billstates in ('3')
    	group by sb.p_id,sb.ss_id,sb.batchno,sb.supplier_id,sb.location_id,sb.commissionflag,sb.costprice,sb.validdate, sb.instoretime
    ) k
    group by k.p_id,k.ss_id,k.batchno,k.supplier_id,k.location_id,k.commissionflag,k.costprice,k.validdate, k.instoretime
  end
  return
end
GO
