
CREATE	  PROCEDURE [Ts_L_InorupExchangeItg]
   (@product_id	int,
    @ExchItg   int,
	@Comment   varchar(100),
	@I_id  int
	)
as  
/*
 declare @cts int
 set @cts=(select count(id) from CTExchangeIntegral where p_id=@product_id and I_id=@I_id)	
 if  @cts<=0 
 begin
    insert into CTExchangeIntegral(ct_id,p_id,ExchangeIntegral,Comment,I_id)
	 VALUES
	(
	0,
    @product_id,
    @ExchItg,
	@Comment,
	@I_id
	)  
 end
 else
 begin
   update CTExchangeIntegral set ExchangeIntegral=@ExchItg, Comment=@Comment where p_id=@product_id and I_id=@I_id
 end	            
  */
    insert into CTExchangeIntegral(ct_id,p_id,ExchangeIntegral,Comment,I_id)
	 VALUES
	(
	0,
    @product_id,
    @ExchItg,
	@Comment,
	@I_id
	)
GO
