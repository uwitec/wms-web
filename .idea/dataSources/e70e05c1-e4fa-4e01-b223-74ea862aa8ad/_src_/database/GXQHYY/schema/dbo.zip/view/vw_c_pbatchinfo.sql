


CREATE  VIEW dbo.vw_c_pbatchinfo
AS
SELECT   sh.storehouse_id, sh.location_id, sh.s_id, sh.p_id, sh.supplier_id, sh.quantity, sh.costprice, sh.costtotal, sh.batchno, 
                sh.makedate, sh.instoretime, sh.validdate, sh.commissionflag, sh.stopsaleflag, sh.inorder, sh.yhdate, sh.ModifyDate, 
                sh.Y_ID, sh.SendFlag, sh.BatchBarCode, sh.scomment, sh.batchprice, sh.costtaxprice, sh.costtaxtotal, sh.factoryid, 
                sh.taxrate * 100 AS CostTaxRate, p.name AS pname, p.alias, p.standard, p.medtype, p.Integral AS INTEGRAL, 
                p.Factory AS factory, p.makearea, p.validmonth, p.PackStd, p.StorageCon, ISNULL(tr.TaxRate, 0) AS TaxRate, 
                p.permitcode, p.comment, ISNULL(t.name, '') AS cname, ISNULL(l.loc_name, '') AS locname, p.class_id AS pclassid, 
                p.ifdiscount, ISNULL(t.class_id, '') AS cclassid, ISNULL(s.name, '') AS sname, ISNULL(s.flag, 0) AS sflag, 
                ISNULL(s.WholeFlag, 0) AS SWholeFlag, ISNULL(mt.medtype, '') AS mt_name, c.retailprice, sh.costprice AS recprice, 
                c.price1, c.price2, c.price3, c.lowprice, p.trademark, p.modal, p.serial_number AS code, p.unit1_id, p.unit2_id, p.unit3_id, 
                p.unit4_id, p.rate2, p.rate3, p.rate4, p.validday, p.otcflag, p.costmethod, p.BulidNo AS bulidNo, p.RegisterNo, 
                p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, p.Custompro5, ISNULL(dbo.PrintClass.pc_name, '') 
                AS PcName, ISNULL(dbo.unit.name, '') AS unitname, ISNULL(unit_1.name, '') AS unitname2, ISNULL(u2.name, '') 
                AS unitname3, ISNULL(unit_3.name, '') AS unitname4, p.SR_id
FROM      dbo.unit AS u2 RIGHT OUTER JOIN
                dbo.unit AS unit_3 RIGHT OUTER JOIN
                dbo.products AS p ON unit_3.unit_id = p.unit4_id ON u2.unit_id = p.unit3_id LEFT OUTER JOIN
                dbo.unit AS unit_1 ON p.unit2_id = unit_1.unit_id LEFT OUTER JOIN
                dbo.price AS c ON p.product_id = c.p_id LEFT OUTER JOIN
                dbo.PrintClass ON p.PrintClass = dbo.PrintClass.pc_id LEFT OUTER JOIN
                dbo.unit ON p.unit1_id = dbo.unit.unit_id RIGHT OUTER JOIN
                dbo.storehouse AS sh ON p.product_id = sh.p_id LEFT OUTER JOIN
                dbo.storages AS s ON sh.s_id = s.storage_id LEFT OUTER JOIN
                dbo.location AS l ON sh.location_id = l.loc_id LEFT OUTER JOIN
                dbo.clients AS t ON sh.supplier_id = t.client_id LEFT OUTER JOIN
                dbo.VW_TaxRate AS tr ON p.product_id = tr.product_id LEFT OUTER JOIN
                dbo.vw_medtype AS mt ON p.product_id = mt.product_id
WHERE   (p.deleted NOT IN (1, 3)) AND (s.deleted = 0) AND (c.unittype = 1)
GO
