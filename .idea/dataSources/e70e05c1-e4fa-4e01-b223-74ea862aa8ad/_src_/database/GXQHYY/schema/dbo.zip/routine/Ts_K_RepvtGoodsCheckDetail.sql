

CREATE PROCEDURE Ts_K_RepvtGoodsCheckDetail(
	@Begin                DATETIME, 
	@End                  DATETIME, 
	@YId                  INT, 
	@PId                  INT
)
AS
BEGIN
	SELECT b.billid, CONVERT(varchar(100), b.billdate, 23) AS billdate, b.billnumber, b.e_id, e.name AS EName, b.Y_ID, y.name AS YName, 
	       g.ss_id AS s_id, s.name AS SName, g.location_id AS l_id, ISNULL(l.loc_name, '') AS LName, g.p_id AS PId, p.name AS Name, 
	       p.alias, p.[standard], p.permitcode, p.MedName, p.Factory, p.Unit1Name AS UnitName, p.makearea, p.serial_number, p.BulidNo, 
	       p.RegisterNo, p.StorageCon, g.batchno, g.smb_id, g.quantity, g.costprice, g.costtaxprice, g.costtaxprice, 
	       CASE WHEN g.makedate < 10 THEN '' ELSE CONVERT(varchar(100), g.makedate, 23) END AS MakeDate,
	       CASE WHEN g.validdate < 10 THEN '' ELSE CONVERT(varchar(100), g.validdate, 23) END AS ValidDate,
	       ISNULL(i.retailprice, 0.00) AS retailprice, -(g.taxprice - g.quantity) AS YKQty, g.taxprice AS SQuantity,
	       -((g.taxprice - g.quantity) * g.costtaxprice) AS YKTaxTotal,
	       -((g.taxprice - g.quantity) * g.costprice) AS YKTotal, -((g.taxprice - g.quantity) * ISNULL(i.retailprice, 0.00)) AS YKRetailTotal,
	       g.instoretime, g.supplier_id, ISNULL(c.name, '') AS SupplierName 
		FROM billidx b INNER JOIN GoodsCheckBill g ON b.billid = g.bill_id
		               INNER JOIN company y ON b.Y_ID = y.company_id
		               INNER JOIN employees e ON b.e_id = e.emp_id
		               INNER JOIN storages s ON g.ss_id = s.storage_id
		               LEFT JOIN location l ON g.location_id = l.loc_id
		               INNER JOIN vw_Products p ON g.p_id = p.product_id
		               LEFT JOIN clients c ON g.supplier_id = c.client_id
		               LEFT JOIN price i ON p.product_id = i.p_id AND p.unit1_id = i.u_id AND i.unittype = 1
	WHERE b.billtype = 50 AND b.billstates = 0 AND b.Y_ID = @YId AND
		  b.billdate BETWEEN @Begin AND @End AND (@PId = 0 OR g.p_id = @PId) 
	ORDER BY b.billid, b.billdate DESC
END
GO
