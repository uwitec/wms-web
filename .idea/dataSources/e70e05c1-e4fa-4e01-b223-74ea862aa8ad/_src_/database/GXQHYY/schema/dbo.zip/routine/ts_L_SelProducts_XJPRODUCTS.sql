
/*增加对商品不同状态的查询支持   wsk 2007-06-05*/
create   PROCEDURE ts_L_SelProducts_XJPRODUCTS
(	@TableName	varchar(30),   /*表名*/
	@Parent_id	varchar(36),    /*相近商品、关联商品使用@Parent_id原商品的class_id add by luowei 2013-05-22*/
	@szWhere	varchar(500),
	@E_id		int =0,
	@szListFlag char(1)='', /*在商品中作仓库用，*/
	@nShowStatus	int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
	@nFilterY		int=0, 	/* 1: 只选择本机构的数据  0:选择本机构和共享机构     选择所有机构数据 2:只选择是独立帐套的分支机构*/
	@nY_id			int=0,
        @UserId         int=0     /*当前操作员id*/
)
AS
/*Params Ini begin*/
if @E_id is null  SET @E_id = 0
if @szListFlag is null  SET @szListFlag = ''
if @nShowStatus is null  SET @nShowStatus = 0
if @nFilterY is null  SET @nFilterY = 0
if @nY_id is null  SET @nY_id = 0
/*Params Ini end*/

set nocount on
declare @Sql varchar(8000)
declare @ClientFlags varchar(10)   /*--往来单位类型判断 add by luowei 2013-08-16*/
declare @userP_id    varchar(100)  /*--授权商品*/

 declare @nTmpYID int

/*------获取原商品对应相近商品的p_id */
  declare @filter varchar(8000)
  declare @p_id int
  set @filter = ''
  declare pid_cursor cursor  for 
  select R_pid from productsRelating where p_id in (select product_id from products where class_id = @Parent_id)
  open pid_cursor
  fetch next from pid_cursor into @p_id
  
  WHILE @@FETCH_STATUS = 0
  begin
    if @filter = '' 
    set @filter = CAST(@p_id as varchar)
    else 
    set @filter = @filter + ',' + CAST(@p_id as varchar)
    fetch next from pid_cursor into @p_id
  end
  CLOSE pid_cursor
  DEALLOCATE pid_cursor
  
  set @filter = '  and product_id in ('+@filter+')'
  
  set @szWhere = @szWhere + @filter
  GOTO ListAll

ListAll:
  if @e_id=0  /*全部仓库*/
  BEGIN
    set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
    set @sql= @sql +  'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s where '
   IF @nY_id <> 2
     SET @Sql = @Sql + ' Y_id = '+cast(@nY_ID as varchar(10))+' AND ' 
   set @sql=@sql + '  FP.Product_id=s.p_id ) qty, ' 
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  FP.Product_id=pd.p_id) DraftQty '
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql +  'from FilterProduct('+cast(@nY_ID as varchar(10))+') FP  where Child_Number=0 ' +@szWhere + ') T '  
   /*wsk add @szWhere  2  2009-02-23 zjl增加可开数量*/
    /*print @sql*/
    exec(@sql)
  END  /* 全部仓库   OVER*/
  else
   if @e_id=-100 /*只统计配送中心仓库*/
   BEGIN
    set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
    set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s ,storages st
      where  s.s_id=st.storage_id and st.flag=0 and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  FP.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from FilterProduct('+cast(@nY_ID as varchar(10))+') FP
   where Child_Number=0 ' +@szWhere + ') T  '                      /*wsk add @szWhere*/
   exec(@sql)
   END            /*只统计配送中心仓库 OVER*/
   else
   BEGIN         /*当前仓库*/
   if UPPER(@TableName) = 'XJPRODUCTS' /*-*/
   begin
	 set @nTmpYID=@nY_id
	 if (@E_id=-100) 
	 set @nTmpYID=@E_id
   end
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql=@sql + 'select *,(select isnull(sum(s.quantity),0) 
      from storehouse s 
      where s.s_id='+ cast(@E_id as varchar) + ' and FP.Product_id=s.p_id 
        and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  FP.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  FP.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql + 'from FilterProduct('+cast(@nY_ID as varchar(10))+') FP where Child_Number=0 '+@szWhere + ') T '                      /*wsk add @szWhere*/
   /*print @sql*/
   exec(@sql)
   END          /*当前仓库   OVER  */

  return 0   /* ListAll 结束*/
GO
