


CREATE	TRIGGER delGspdrfdetail ON [dbo].gspbilldetail
FOR  delete
AS
 delete from GspDraft where orgsmb_id in (select Gspsmb_id from deleted)
GO
