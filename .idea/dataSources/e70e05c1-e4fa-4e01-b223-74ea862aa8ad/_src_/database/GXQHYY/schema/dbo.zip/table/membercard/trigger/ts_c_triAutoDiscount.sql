

CREATE  TRIGGER ts_c_triAutoDiscount ON [dbo].[membercard] 
FOR UPDATE
AS
if update(buytotal)
begin
 declare @cardid int,@dTotal numeric(18,4),@begintotal numeric(18,4),@endtotal numeric(18,4),@autodiscount bit,@discount float

 declare curdiscount cursor for
 select a.cardid,a.buytotal,b.autodiscount
 from inserted a,cardtype b where a.discounttype=b.ctypeid

 open curdiscount
 fetch next from curdiscount into  @cardid,@dTotal,@autodiscount
 
 while @@fetch_status=0
 begin
   set @discount=100
   if @autodiscount=1
   begin
    if exists(select top 1discount from carddiscount where @dTotal>=begintotal and @dTotal<=endtotal)
    begin  
       select top 1 @discount=isnull(discount,100) from carddiscount where @dTotal>=begintotal and @dTotal<=endtotal
       update membercard set discount=@discount where cardid=@cardid
    end 
   end
   fetch next from curdiscount into  @cardid,@dTotal,@autodiscount
 end
 close curdiscount
 deallocate curdiscount
end
GO
