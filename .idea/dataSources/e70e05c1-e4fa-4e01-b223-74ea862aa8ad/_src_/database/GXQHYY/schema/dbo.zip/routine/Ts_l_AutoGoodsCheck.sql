


CREATE PROCEDURE Ts_l_AutoGoodsCheck  
(	@nSid int,
	@nLid int
)
AS

/*declare @Where varchar(500),@SQl varchar(8000)

if @npid<>0 then set @Where='sh.P_id='+cast(@npid as varchar(50))+' and '
if @nsid<>0 then set @Where=@Where+'sh.s_id='+cast(@nsid as varchar(50))+' and '
if @nLid<>0 then set @Where=@Where+'sh.location_id='+cast(@nLid as varchar(50))+' and '

set @Where=substring(@Where,1,len(@Where)-4)
set @sql='Select * from auto where '+@where
exec (@sql)
if @@rowcount <>0 then*/

if exists(select * from autoGoodscheck where ss_id=@nsid)  return 0 

if @nlid=0 
begin
	insert into AutoGoodsCheck 
	
	SELECT 0 AS bill_id,
		 sh.p_id, 
		p.code AS pCode, 
		p.name AS pname, 
		p.standard, 
	                p.MedName AS medType,
		 p.makearea, 
		p.permitcode, 
  		p.Unit1Name as unitName,
		sh.batchno, 
		sh.quantity, 
	      	sh.costprice,
		sh.quantity AS DiscountPrice, 
		sh.costtotal AS totalmoney, 
		sh.makedate, 
	      sh.validdate, '合格' AS qualitystatus, sh.s_id AS ss_id, ISNULL(s.name, '') AS sname,
	      sh.location_id, ISNULL(l.loc_name, '') AS lname, sh.supplier_id, ISNULL(c.name, '') 
	      AS cname, sh.commissionflag, '' AS comment, p.pinyin,sh.Y_ID,sh.InStoreTime
	FROM dbo.storehouse sh INNER JOIN
	      dbo.vw_Products p ON sh.p_id = p.product_id LEFT OUTER JOIN
	      dbo.storages s ON sh.s_id = s.storage_id LEFT OUTER JOIN
	      dbo.location l ON sh.location_id = l.loc_id LEFT OUTER JOIN
	      dbo.clients c ON sh.supplier_id = c.client_id
	where sh.s_id=@nsid
end else
begin
	insert into AutoGoodsCheck 
	
	SELECT 0 AS bill_id,
		 sh.p_id, 
		p.code AS pCode, 
		p.name AS pname, 
		p.standard, 
	                p.MedName AS medType,
		 p.makearea, 
		p.permitcode, 
  		p.Unit1Name as unitName,
		sh.batchno, 
		sh.quantity, 
	      	sh.costprice,
		sh.quantity AS DiscountPrice, 
		sh.costtotal AS totalmoney, 
		sh.makedate, 
	      sh.validdate, '合格' AS qualitystatus, sh.s_id AS ss_id, ISNULL(s.name, '') AS sname,
	      sh.location_id, ISNULL(l.loc_name, '') AS lname, sh.supplier_id, ISNULL(c.name, '') 
	      AS cname, sh.commissionflag, '' AS comment, p.pinyin,sh.Y_ID,sh.InStoreTime
	FROM dbo.storehouse sh INNER JOIN
	      dbo.vw_Products p ON sh.p_id = p.product_id LEFT OUTER JOIN
	      dbo.storages s ON sh.s_id = s.storage_id LEFT OUTER JOIN
	      dbo.location l ON sh.location_id = l.loc_id LEFT OUTER JOIN
	      dbo.clients c ON sh.supplier_id = c.client_id
	where sh.s_id=@nsid and sh.location_id=@nLid

end
GO
