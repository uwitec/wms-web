














CREATE VIEW dbo.vw_Account
AS
SELECT A.*
FROM dbo.account A
WHERE (deleted = 0)
GO
