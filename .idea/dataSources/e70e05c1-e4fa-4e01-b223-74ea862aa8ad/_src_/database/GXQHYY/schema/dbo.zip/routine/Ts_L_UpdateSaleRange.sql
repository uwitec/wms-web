

CREATE PROCEDURE  [Ts_L_UpdateSaleRange]
(	    @nid       int,
        @szName    varchar(30),
        @szCode    varchar(30),
        @szPinyin  varchar(30),
        @szMode      int
 )
AS
if @szMode=1 
begin
 if exists(select * from SaleRange where ([Name]=@szName or code=@szCode) and deleted=0 and [id] <> @nid)
 begin
 	RAISERROR('已经存在，请重新输入其它名称！',16,1) 
 	return 0 
 end

   update SaleRange set [Name]=@szName,pinyin=@szPinyin,code=@szCode where [id]=@nid
end
else
if @szMode=2
begin
   if exists(select * from SaleRange2 where ([Name]=@szName or code=@szCode) and deleted=0 and [id] <> @nid)
 begin
 	RAISERROR('已经存在，请重新输入其它名称！',16,1) 
 	return 0 
 end

   update SaleRange2 set [Name]=@szName,pinyin=@szPinyin,code=@szCode where [id]=@nid
end
if @@rowcount=0 
begin
	RAISERROR('数据库写入数据失败!',16,1) 
	return 0 
end else
return @@identity
GO
