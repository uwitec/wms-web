
CREATE FUNCTION GetSaleBreakOffAnalysisInfo
(
	@Type           INT = 0, /*0获取最后一次供应商;1首次采购日期；2最近采购日期；3销售频次；4日均销量；*/
	@YId			INT = 2,
	@PId			INT = 0,
	@Begin			DATETIME,
	@End			DATETIME,
	@BreakOffCount  INT
)
RETURNS VARCHAR(2000)
AS
BEGIN
	DECLARE @Qty       numeric(25,8)
	DECLARE @Re        VARCHAR(2000)
	SET @Re = ''
	
	IF @Type = 0
	BEGIN
		SELECT TOP 1 @Re = c.name 
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
						   INNER JOIN clients c ON s.supplier_id = c.client_id 
		WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (20, 160, 162)
		ORDER BY b.billdate DESC
		IF @Re IS NULL
			SET @Re = ''
	END
	ELSE
	IF @Type = 1
	BEGIN
		SELECT TOP 1 @Re = CONVERT(VARCHAR(100), b.billdate, 23)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (20, 160, 162) AND s.p_id = @PId
		ORDER BY b.billdate
		IF @Re IS NULL
			SET @Re = ''	
	END
	ELSE
	IF @Type = 2
	BEGIN
		SELECT TOP 1 @Re = CONVERT(VARCHAR(100), b.billdate, 23) 
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (20, 160, 162) AND s.p_id = @PId
		ORDER BY b.billdate DESC
		IF @Re IS NULL
			SET @Re = ''	
	END
	ELSE
	IF @Type = 3
	BEGIN
		SELECT TOP 1 @Re = CAST(COUNT(*) AS VARCHAR)
			FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id
		WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (10, 12, 150, 152) AND 
		      s.p_id = @PId AND b.billdate BETWEEN @Begin AND @End	
	END
	ELSE
	IF @Type = 4
	BEGIN
		SELECT @Qty = SUM(s.quantity)
			FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id
		WHERE b.Y_ID = @YId AND b.billstates = 0 AND b.billtype IN (10, 12, 150, 152) AND 
		      s.p_id = @PId AND b.billdate BETWEEN @Begin AND @End	
		IF @Qty IS NULL
			SET @Qty = 0
		SET @Re = CAST(ROUND(@Qty / @BreakOffCount, 2) AS VARCHAR)	
	END
		
	RETURN(@Re)
END
GO
