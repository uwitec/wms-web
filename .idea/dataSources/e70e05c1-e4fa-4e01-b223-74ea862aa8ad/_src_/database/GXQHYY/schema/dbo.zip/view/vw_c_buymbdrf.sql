



CREATE	VIEW dbo.vw_c_buymbdrf
AS
SELECT dbo.buymanagebilldrf.*, 
ISNULL(P.[Name]  ,'') AS [PName],         
ISNULL(P.[Class_ID]  ,'') AS [PClass_ID],
isnull(storages_2.class_id,'') AS ssclass_id, 
isnull(storages_1.class_id,'') AS sdclass_id, 
isnull(storages_2.name,'') AS ssname, 
isnull(storages_1.name,'') AS sdname,
isnull(u.name,'') as unitname,
isnull(l.loc_name,'') as locname,
isnull(c.[name],'') as suppliername,
isnull(E.class_id,'') as REclass_ID,
isnull(E.[name],'') as REname
FROM dbo.buymanagebilldrf 
      LEFT JOIN Products P  ON buymanagebilldrf.[P_ID]=P.[Product_ID] 
      LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      dbo.buymanagebilldrf.sd_id = storages_1.storage_id LEFT OUTER JOIN
      dbo.storages storages_2 ON dbo.buymanagebilldrf.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON dbo.buymanagebilldrf.unitid = u.unit_id
      LEFT OUTER JOIN
      location l on dbo.buymanagebilldrf.location_id=l.loc_id
      LEFT OUTER JOIN
      clients c on dbo.buymanagebilldrf.supplier_id=c.client_id
      LEFT OUTER JOIN
      employees E ON buymanagebilldrf.RowE_id=E.emp_id
WHERE  dbo.buymanagebilldrf.AOID=0
GO
