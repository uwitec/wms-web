

CREATE  view dbo.vw_c_pdetail
as
select  productdetail.[pd_id],productdetail.[billid],productdetail.[p_id],productdetail.[s_id]
,productdetail.[quantity],productdetail.[price],productdetail.[total],productdetail.[costprice]
,productdetail.[costtotal],productdetail.[taxprice],productdetail.[taxtotal],productdetail.[batchno]
,productdetail.[makedate],productdetail.[validdate],productdetail.[commissionflag],productdetail.[supplier_id]
,productdetail.[location_id],productdetail.[storetype],productdetail.[price_id],productdetail.[order_id]
,productdetail.[unitid],productdetail.[smb_id],productdetail.[comment],productdetail.[oldcommissionflag]
,productdetail.[AOID],productdetail.[jsprice],productdetail.[rowguid],productdetail.[ROWE_id]
,productdetail.[SendQTY],productdetail.[SendCostTotal],productdetail.[retailtotal],productdetail.[Y_ID]
,productdetail.[transflag],productdetail.[instoretime],productdetail.[cxType],productdetail.[retailprice]
,productdetail.[thqty],productdetail.[FlowFlag],productdetail.[BatchBarCode],productdetail.[scomment]
,productdetail.[batchprice],productdetail.[costtaxprice],productdetail.[costtaxrate],productdetail.[costtaxtotal]
,productdetail.[factoryid],productdetail.[taxrate],productdetail.[md_SMID],
isnull(dbo.products.class_id,'') as class_id, 
isnull(dbo.storages.class_id,'') as sclass_id, 
isnull(dbo.storages.[name],'') as sname,
isnull(dbo.products.[serial_number],'') as serial_number, 
isnull(dbo.products.[name],'') as pname,products.alias,products.makearea,products.standard,products.comment as pcomment,
case products.StoreCondition when 1 then '阴凉' when 2 then '冷藏' else '常温' end SCName, 
isnull(l.loc_name,'') as locname,
isnull(cl.[name],'') as suppliername,
isnull(e.class_id,'') as Reclass_id,
isnull(e.[name],'') as Rename,
ISNULL(f.AccountComment,'') as factory
from dbo.productdetail 
 left outer join
       dbo.storages on dbo.productdetail.s_id = dbo.storages.storage_id 
 left outer join
       dbo.products on dbo.productdetail.p_id = dbo.products.product_id
 left outer join
       dbo.location l on dbo.productdetail.location_id = l.loc_id
 left outer join
       dbo.clients cl on dbo.productdetail.supplier_id = cl.client_id
 left outer join 
       dbo.employees e on dbo.productdetail.RowE_id=e.emp_id
 left outer join 
       dbo.basefactory f on productdetail.Factoryid=f.CommID


where dbo.productdetail.aoid in (0,5,7)
GO
