

CREATE      procedure TS_L_ExchangeVIPCard
  @OldCardNo varchar(50),
  @NewCardNo varchar(50),
  @Comment varchar(200),
  @e_id int
as /*select * from ExchangeVIPCard*/
begin
  declare @OldCardID int,
          @NewCardID int,
          @Msg varchar(50)
  if exists(select * from VIPCard where CardNo=@NewCardNo and Deleted=0) 
  begin
    set @Msg = '已经存在这个会员卡号【'+@NewCardNo+'】'
    raiserror(@Msg,16,1)
    return -1
  end
   
  select @OldCardID=VIPCardID from VIPCard where CardNo=@OldCardNo
  begin tran
  Declare @NewID int
  select @NewID=Max(VIPCardID)+1 from VIPCard
  insert into VIPCard(  VIPCardID,
                        CardNo,    
                        Name,
                        PinYin,
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
                        IniMoney,
                        TotalBuyMoney,
                        SaveMoney,
                        IntergralYE,
                        IniIntergral,
                        Integral,
                        SwapIntegral,
                        BuyCount,
			Deleted,
			Lose,
			StopUse,
			RemainderMoney,
                        LoginPass)
                select  @NewID,
                        @NewCardNo,
                        Name,
                        PinYin,
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
                        IniMoney,
                        TotalBuyMoney,
                        SaveMoney,
                        IntergralYE,
                        IniIntergral,
                        Integral,
                        SwapIntegral,
                        BuyCount,
			Deleted,
			Lose,
			StopUse,
			RemainderMoney,
                        LoginPass
                   from VIPCard  
                  where VIPCardID=@OldCardID
                    and Deleted=0
  set @NewCardID = @NewID
  insert into ExchangeVIPCard(OldVIPCardID,NewVIPCardID,Comment,ExchangeDate,e_id)
              values(@OldCardID,@NewCardID,@Comment,GetDate(),@e_id)
  update VIPCard 
     set StopUse=1,
         IniMoney=0,TotalBuyMoney=0,SaveMoney=0,IntergralYE=0,IniIntergral=0,
         Integral=0,SwapIntegral=0,BuyCount=0,RemainderMoney=0 
   where VIPCardID=@OldCardID 

  if @@error=0
    commit tran
  else
    rollback tran
  return @NewCardID
end
GO
