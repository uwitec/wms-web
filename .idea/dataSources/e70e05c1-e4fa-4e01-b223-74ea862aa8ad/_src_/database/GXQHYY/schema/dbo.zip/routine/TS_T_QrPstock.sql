
CREATE PROCEDURE TS_T_QrPstock
(	@BeginDate 	  DATETIME,/*开始时间*/
	@EndDate	 	  DATETIME,/*结束时间*/
	@szCClass_ID	VARCHAR(30)='',/*客户ID*/
	@szEClass_ID	VARCHAR(30)='',/*经手人ID*/
	@szSClass_ID	VARCHAR(30)='',/*库房ID*/
	@szPClass_ID	VARCHAR(30)='',/*产品ID*/
	@szParent_ID	VARCHAR(30)='',/*产品父类ID*/
	@szListFlag		VARCHAR(1)='L',/*分级显示*/

	@dMlTotal			numeric(25,8) OUTPUT,/*总采购金额*/
	@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
	@nLocation_Id   INT=0,        /*货位ID*/
        @nYClassid          varchar(100)='',
        @nloginEID           int=0,
        @szRClass_id   varchar(50) = '' /*片区       */
)
AS
/*Params Ini begin*/
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szSClass_ID is null  SET @szSClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szParent_ID is null  SET @szParent_ID = ''
if @szListFlag is null  SET @szListFlag = 'L'
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @nLocation_Id is null  SET @nLocation_Id = 0
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @szRClass_id is null  SET @szRClass_id = ''
/*Params Ini end*/
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  Declare @isfinally int
  Declare @tablename varchar(8000)
  
  /*if @szRClass_id = '' or @szRClass_id = '000000' set @szRClass_id = '0'*/
  /*else set @szRClass_id = @szRClass_id + '%'*/

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/
       SELECT P.Class_id as Pclass_ID,SH.Y_ID,
              ISNULL(SUM(SH.SHQTY),0) AS SHQTY,           ISNULL(SUM(SM.[Quantity]), 0) AS [Quantity],
              ISNULL(SUM(SM.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SM.[BuyTotal]), 0) AS [BuyTotal],
              ISNULL(SUM(SM.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SM.[SendCostTotal]),0) AS [SendCostTotal],
              ISNULL(SUM(SM.[CostTotal]), 0) AS [CostTotal],
              abs(case when ISNULL(SUM(SM.SendQTY),0)<>0 then ISNULL(SUM(SM.[SendCostTotal]),0)/ISNULL(SUM(SM.SendQTY),0) else 0 end) as  CostPrice,
              ISNULL(SUM(SM.[TaxTotal]), 0)-ISNULL(SUM(SM.[BuyTotal]), 0) as setotal
         into #TempPBuyPH
         FROM (select * from Products
                       where deleted=0 and
                            ((@szPClass_ID IN ('', '%%', '000000')) or (class_id LIKE @szPClass_ID+'%')) 
              )P
         LEFT JOIN
           (SELECT isnull(sum(sh.Quantity),0)SHQTY, sh.P_id,sh.Y_ID
              FROM storehouse  sh
              LEFT JOIN storages s on s.storage_id=sh.s_id
              LEFT JOIN Company  Y on Y.Company_id=sh.Y_id
             WHERE ((@szSClass_ID IN ('', '%%', '000000')) or (S.Class_id like @szSClass_id+'%')) 
               AND ((@nLocation_Id=0) or (sh.location_id=@nLocation_Id)) 
               AND ((@nYClassID='') or (Y.class_id like @nYClassID+'%'))
               AND ((@Storetable=0) OR (sh.s_id in (select [id] from #storagestable)))
               AND ((@Companytable=0) or (sh.Y_id in (select [id] from #Companytable)))
            Group by sh.P_id,sh.Y_ID
           )SH on P.product_id=sh.p_id
         
         LEFT JOIN 
         (SELECT YPD.[p_id],YPD.Y_ID,
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[quantity]   else -YPD.[quantity] end),0) AS [Quantity],
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[TaxTotal]   else -YPD.[TaxTotal] end),0) AS [TaxTotal],
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[TotalMoney] else -YPD.[TotalMoney] end),0) AS [BuyTotal],
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[SendQTY] else -YPD.[SendQTY] end),0) AS [SendQTY],
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[quantity]*YPD.[costprice]   else -YPD.[quantity]*YPD.[costprice] end),0) AS [CostTotal],
                 ISNULL(SUM(case when YPD.billtype IN (20,222,24,220,22)  THEN YPD.[SendCostTotal]  else -YPD.[SendCostTotal] end),0) AS [SendCostTotal]
            FROM
                   (SELECT bmb.p_id,bmb.quantity,bmb.costprice,bmb.totalmoney,bmb.taxtotal,
                           bmb.SendQTY,bmb.SendCostTotal,B.billtype,b.Y_ID
                      FROM  buymanagebill bmb
                      INNER JOIN Billidx     B  ON B.billid=bmb.bill_id
					  LEFT JOIN employees   RE on re.emp_id=bmb.RowE_id
					  LEFT JOIN storages    S  on S.storage_id=bmb.ss_id
					  LEFT JOIN Clients     C  on B.c_id=c.client_id
					  LEFT JOIN employees   E  on B.inputman=E.emp_id 
					  LEFT JOIN Company     Y  on Y.Company_id=B.y_id
					  Left JOIN Region      R  ON b.region_id=r.region_id              
                     WHERE  ([Billdate] BETWEEN   @BeginDate AND  @EndDate) and 
                             B.[billtype] IN (20,21,24,25,220,221,222) and
                            [Billstates]=0 AND aoid in (0,5) and p_id>0 and 
                            ((@szRClass_id IN ('', '%%', '000000')) or (R.class_id like @szRClass_id+'%')) AND
                            ((@szEClass_ID IN ('', '%%', '000000')) or (Re.class_id like @szEClass_ID+'%'))AND
                            ((@szSClass_ID IN ('', '%%', '000000')) OR (S.Class_id like @szSClass_id+'%')) AND 
                            ((@nLocation_Id=0)  OR (bmb.Location_Id=@nLocation_Id)) AND
                            ((@szCClass_ID IN ('', '%%', '000000')) OR (C.Class_ID LIKE @szCClass_id+'%')) AND
                            ((@szInputClass_ID IN ('', '%%', '000000')) OR (E.Class_ID LIKE @szInputClass_id+'%')) AND
                            ((@nYClassID='') or (Y.Class_id like @nYClassID+'%')) AND
                            ((@employeestable=0) OR (bmb.RowE_id in (select [id] from #employeestable))) AND
                            ((@Storetable=0) OR (bmb.ss_id in (select [id] from #storagestable))) AND
                            ((@ClientTable=0) or (B.c_id in (select [id] from #Clienttable)))AND
                            ((@Companytable=0)or (B.Y_id in (select [id] from #Companytable)))  
                   )YPD
          GROUP BY YPD.[P_id],ypd.Y_ID)SM
         
      ON SM.p_ID=sh.p_id and sm.Y_ID = sh.Y_ID
     GROUP BY P.class_id,SH.Y_ID


IF @szListFlag='L'
  BEGIN
	  Select P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], isnull(f.AccountComment,'') as Makearea, u.[name] as [UnitName1],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5,IsNULL(MAX(vp.e_name),'')e_name,IsNULL(MAX(vp.C_Name),'')C_Name,/*p.[Parent_ID],p.[Deleted],*/
			 ISNULL(SUM(SH.SHQTY),0) AS SHQTY,           ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[BuyTotal]), 0) AS [BuyTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],	
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal
			        
		From products P
		Left join unit u          on p.unit1_id=u.unit_id
		Left join #TempPBuyPH SH on LEFT(SH.[PClass_ID],LEN(p.[Class_ID]))=p.[Class_ID]
		Left join vw_productbalance vp on vp.p_id= p.product_id and SH.Y_id= vp.Y_id
		Left join BaseFactory f on f.CommID = p.factoryc_id  
		where  p.parent_id=@szParent_id and p.deleted<>1
		Group by  P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], f.AccountComment, u.[name],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5/*,p.[Parent_ID],p.[Deleted]*/
		Order by p.product_id
  END
  
  IF @szListFlag='P'
  BEGIN
	  Select P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], isnull(f.AccountComment,'') as Makearea, u.[name] as [UnitName1],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5,IsNULL(MAX(vp.e_name),'')e_name,IsNULL(MAX(vp.C_Name),'')C_Name,/*p.[Parent_ID],p.[Deleted],*/
			 ISNULL(SUM(SH.SHQTY),0) AS SHQTY,           ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[BuyTotal]), 0) AS [BuyTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal
			       
		From products P
		Left join unit u          on p.unit1_id=u.unit_id
		Left join #TempPBuyPH SH on SH.[PClass_ID]=p.[Class_ID]
		Left join vw_productbalance vp on vp.p_id= p.product_id and Sh.Y_id= vp.Y_id
		Left join BaseFactory f on f.CommID = p.factoryc_id   
		where  LEFT(p.[Class_ID], LEN(@szParent_id))=@szParent_id and p.deleted<>1 and p.[Child_Number]=0
		Group by  P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], f.AccountComment, u.[name],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5/*,p.[Parent_ID],p.[Deleted]*/
		Order by p.product_id    
  END
  
  IF @szListFlag='A'
  BEGIN
	  Select P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], isnull(f.AccountComment,'') as Makearea, u.[name] as [UnitName1],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5,IsNULL(MAX(vp.e_name),'')e_name,IsNULL(MAX(vp.C_Name),'')C_Name,/*p.[Parent_ID],p.[Deleted],*/
			 ISNULL(SUM(SH.SHQTY),0) AS SHQTY,           ISNULL(SUM(SH.[Quantity]), 0) AS [Quantity],
			 ISNULL(SUM(SH.[TaxTotal]),0) AS [TaxTotal], ISNULL(SUM(SH.[BuyTotal]), 0) AS [BuyTotal],
			 ISNULL(SUM(SH.[SendQTY]), 0) AS [SendQTY],  ISNULL(SUM(SH.[SendCostTotal]),0) AS [SendCostTotal],
			 ISNULL(SUM(SH.[CostTotal]), 0) AS [CostTotal],
			 abs(case when ISNULL(SUM(SH.SendQTY),0)<>0 then ISNULL(SUM(SH.[SendCostTotal]),0)/ISNULL(SUM(SH.SendQTY),0) else 0 end) as  CostPrice,
			 ISNULL(SUM(SH.setotal),0) as setotal		
			       
		From products P
		Left join unit u          on p.unit1_id=u.unit_id
		Left join #TempPBuyPH SH on SH.[PClass_ID]=p.[Class_ID]
		Left join vw_productbalance vp on vp.p_id= p.product_id and Sh.Y_id= vp.Y_id
		Left join BaseFactory f on f.CommID = p.factoryc_id  
		where p.[DELETEd]<>1 and p.[Child_Number]=0 and p.[Product_ID]<>1
		Group by  P.[Product_ID], P.[Class_ID], P.[Child_Number], (P.Serial_Number) , 
			 P.[Name], P.[Alias], P.[Standard], f.AccountComment, u.[name],
			 p.[Deduct],p.tc1,p.tc2,p.tcmoney,P.Inputman,p.InputDate,p.Custompro1,p.Custompro2,
			 p.Custompro3,p.Custompro4,p.Custompro5       /*,p.[Parent_ID],p.[Deleted]*/
		Order by p.product_id  
  END
GO
