/************************************************************

--功能：pos前台数据合并为后台零售单   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：
 @nRet 返回值说明　
	0:执行成功
       -1:执行失败，发生异常
**************************************************************/

CREATE	 PROCEDURE [TS_C_QrArApdz]
	(
         @CClassid varchar(36) = '000000',
         @begindate datetime = 0,
         @enddate datetime = 0,                   
         @InpputMan int = 0,
         @EClassID varchar(30) = '000000',
         @YClassID Varchar(30) ='000000',
         @QrMode int = 0,
         @szListFlag varchar(50)='L'
        )
AS 
/*Params Ini begin*/
if @CClassid is null  SET @CClassid = '000000'
if @begindate is null  SET @begindate = 0
if @enddate is null  SET @enddate = 0
if @InpputMan is null  SET @InpputMan = 0
if @EClassID is null  SET @EClassID = '000000'
if @YClassID is null  SET @YClassID = '000000'
if @QrMode is null  SET @QrMode = 0
if @szListFlag is null  SET @szListFlag = 'L'
/*Params Ini end*/

declare @tablename varchar(1000),@SQLChildTemp VARCHAR(8000)
declare @cclass_id varchar(50)

if @CClassid = '' or  @CClassid  = '000000'
  set @cclass_id ='%%'
else 
  set @cclass_id = @CClassid +'%' 



if @EClassid = '' or  @EClassid  = '000000'
  set @EClassid ='%%'
else 
  set @EClassid = @EClassid +'%' 

if @YClassID = '' or  @YClassID  = '000000'
  set @YClassID ='%%'
else 
  set @YClassID = @YClassID +'%' 

if @QrMode = 0
begin
   SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],a.[Parent_ID],a.[Deleted],
    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
    a.artotal  As [Artotal], 
    cast(0 as numeric(25,8)) AS [Aptotal],
    isnull((a.artotal_ini + bt.BeginArTotal),0) as [BeginArTotal], 
    cast(0 as numeric(25,8)) AS [BeginApTotal],
    ISNULL(bt.NowArTotal,0)  AS [NowArTotal], 
    isnull(bt.NowApTotal,0) AS [NowApTotal],
    isnull((a.artotal_ini + bt.BeginArTotal+ bt.NowArTotal - bt.NowApTotal),0) AS [EndArTotal], 
    cast(0 as numeric(25,8)) AS [EndApTotal]
    into #arclient
    FROM Clients a left join Clientsbalance b on a.client_id=b.C_ID
         left join 
         (  select 
			ad.c_id, 
            sum(case when b.billdate < @begindate then isnull(jdmoney, 0)  else  0 end)  as BeginArTotal,
	 		sum(case when b.billdate BETWEEN @begindate and  @enddate and  billtype not in (15, 23) then isnull(jdmoney, 0)  else  0 end)  as NowArTotal,
            sum(case when b.billdate BETWEEN @begindate and  @enddate and  billtype in (15, 23) then isnull(-jdmoney, 0)  else  0 end)  as NowApTotal
            from VW_C_ADetail ad, VW_C_BILLIDX b 
            where ad.billid = b.billid and ad.[AClass_ID]='000001000005' and  b.[BillStates]='0' and b.eclass_id like @EClassID and b.YClass_ID LIKE @YClassID
			group by ad.c_id
          ) bt on a.client_id = bt.c_id 
    where a.class_id like @cclass_id and a.class_id in (select class_id from AuthorizeClients(@InpputMan))
    order by a.class_id

end

if @QrMode = 1
begin
  SELECT a.[Client_ID], a.[Class_ID], a.[Child_number], a.[Name],a.[Parent_ID],a.[Deleted],
    a.[Alias], a.[Serial_number], a.[phone_number], a.[address], a.[contact_personal],
    cast(0 as numeric(25,8)) As [Artotal], 
    a.Aptotal AS [Aptotal],
    isnull((a.aptotal_ini + bt.BeginApTotal),0) as [BeginApTotal], 
    cast(0 as numeric(25,8)) AS [BeginArTotal],
    isnull(bt.NowApTotal,0)  AS [NowApTotal], 
    isnull(bt.NowArTotal,0) AS [NowArTotal],
    isnull((a.aptotal_ini + bt.BeginApTotal+ bt.NowApTotal - bt.NowArTotal),0) AS [EndApTotal], 
    cast(0 as numeric(25,8)) AS [EndArTotal]
    into #apclient
    FROM Clients a left join Clientsbalance b on a.client_id=b.C_ID 
         left join 
         (				 select 
                         ad.c_id, 
                         sum(case when b.billdate < @begindate then isnull(jdmoney,  0)  else  0 end)  as BeginApTotal,
	 					 sum(case when b.billdate BETWEEN @begindate and  @enddate and  billtype not in (15, 23) then isnull(jdmoney, 0)  else  0 end)  as NowApTotal,
                         sum(case when b.billdate BETWEEN @begindate and  @enddate and  billtype in (15, 23) then isnull(-jdmoney, 0)  else  0 end)  as NowArTotal 
                         from VW_C_ADetail ad, VW_C_BILLIDX b 
                         where ad.billid = b.billid and ad.[AClass_ID]='000002000001' and  b.[BillStates]='0' and b.eclass_id like @EClassID and b.YClass_ID LIKE @YClassID
 						 group by ad.c_id
          ) bt on a.client_id = bt.c_id 
    where a.class_id like @cclass_id and a.class_id in (select class_id from AuthorizeClients(@InpputMan))
end

if @QrMode=0 
  select  @tablename='#arclient c'
else
  select  @tablename='#apclient c'

    IF @szListFlag='L'
      SELECT @SQLChildTemp='select 
    c1.[Client_ID], c1.[Class_ID], c1.[Child_number], c1.[Name],c1.[Parent_ID],c1.[Deleted],
    c1.[Alias], c1.[Serial_number], c1.[phone_number], c1.[address], c1.[contact_personal],    
    sum(c.artotal)  As [Artotal], 
    sum(c.[Aptotal])  as [Aptotal],
    sum(c.[BeginArTotal]) as [BeginArTotal], 
    sum(c.[BeginApTotal]) as [BeginApTotal],
    sum(c.[NowArTotal]) AS [NowArTotal], 
    sum(c.[NowApTotal]) as  [NowApTotal],
    sum(c.[EndArTotal]) as [EndArTotal], 
    sum(c.[EndApTotal]) AS [EndApTotal]
 from clients c1 join '+@tablename+' on
   c1.class_id = left(c.class_id, len(c1.class_id)) 
   WHERE C1.[Parent_ID]='+CHAR(39)+@CClassid+CHAR(39) + 
   ' group by c1.[Client_ID], c1.[Class_ID], c1.[Child_number], c1.[Name],c1.[Parent_ID],c1.[Deleted],
    c1.[Alias], c1.[Serial_number], c1.[phone_number], c1.[address], c1.[contact_personal]'

    
    IF @szListFlag='A'
      SELECT @SQLChildTemp='select * from '+@tablename+'  WHERE C.[Child_Number]=0 '

    IF @szListFlag='P'
      SELECT @SQLChildTemp='select * from '+@tablename+'  WHERE LEFT(C.[Class_ID], LEN('+CHAR(39)+@CClassid+CHAR(39)+'))='+CHAR(39)+@CClassid+CHAR(39)
      +' AND C.[Deleted]=0 AND C.[Child_Number]=0'
     /*print(@SQLChildTemp)*/
     exec (@SQLChildTemp)

   return 0
GO
