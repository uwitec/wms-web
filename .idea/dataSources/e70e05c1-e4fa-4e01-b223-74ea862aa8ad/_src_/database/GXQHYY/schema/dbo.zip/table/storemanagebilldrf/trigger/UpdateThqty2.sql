
create  TRIGGER  UpdateThqty2 ON [dbo].[storemanagebilldrf] 
FOR INSERT
AS

declare @smb_id int

select @smb_id=smb_id from inserted
update storemanagebilldrf set thqty=quantity,newprice=price where smb_id=@smb_id
GO
