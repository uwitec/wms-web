

CREATE PROCEDURE Ts_K_PurchaseDetailAnalysis(
	@Begin                DATETIME, 
	@End                  DATETIME, 
	@YId                  INT, 
	@PId                  INT, 
	@SupplierId           INT, 
	@Factory              VARCHAR(100), 
	@EId                  INT, 
	@CgId                 INT, 
	@szID                 VARCHAR(3000),
    @CCgId                 INT, 
	@szCID                 VARCHAR(3000),
	@nloginEID int = 0,     /*当前登陆职员*/
	@strBusinessType varchar(50) = '0'
)
AS
BEGIN
	DECLARE @ProductList TABLE (CgId INT, PId INT)
	DECLARE @SupplierList TABLE (CgId INT, CId INT)
	DECLARE @BaseType INT
	DECLARE @ClassId VARCHAR(30)
	Declare @Companytable INTEGER
	
	set @strBusinessType = @strBusinessType+',5'
	create table #Companytable([id] int)
	

/*----分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

	
	IF @szID = ''
	BEGIN
		INSERT INTO @ProductList(CgId, PId)
		SELECT 0, product_id FROM vw_Products	
	END
	ELSE
	BEGIN
		SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CgId
		
		INSERT INTO @ProductList(CgId, PId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE cg.class_id LIKE @ClassId AND cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (0, -1) AND cm.BaseTypeid = 0 AND 
			  (@szID = '' OR cg.id IN (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szID)))	 and cm.deleted=0
	END
	
	IF @szCID = ''
	BEGIN
		INSERT INTO @SupplierList(CgId, CId)
		SELECT 0, client_id FROM vw_Clients	
	END
	ELSE
	BEGIN
		SELECT @ClassId = class_id + '%' FROM customCategory WHERE id = @CCgId
		
		INSERT INTO @SupplierList(CgId, CId) 
		SELECT category_id, baseinfo_id    
			FROM customCategoryMapping cm INNER JOIN customCategory cg ON cm.category_id = cg.id
		WHERE cg.class_id LIKE @ClassId AND cg.Child_Number = 0 and cg.deleted = 0 AND cg.baseType IN (1, -1) AND cm.BaseTypeid = 1 AND
			  (@szCID = '' OR cg.id IN (SELECT CAST(sztype AS INT) FROM dbo.DecodeToStr(@szCID))) and cm.deleted=0	
	END
	
	SELECT s.smb_id AS KeyId, s.p_id AS PId, p.serial_number, p.name, p.alias, p.[standard], p.permitcode, p.makearea,p.comment, u.name AS UnitName, ISNULL(f.AccountComment, '') AS Factory, 
	       b.billnumber, s.instoretime,
	       CASE WHEN s.makedate < 10 THEN '' ELSE CONVERT(varchar(100), s.makedate, 23) END AS MakeDate, s.batchno, 
	       CASE WHEN s.validdate < 10 THEN '' ELSE CONVERT(varchar(100), s.validdate, 23) END AS ValidDate,
	       s.quantity,s.buyprice, s.total, s.taxrate * 100 AS taxrate, s.taxprice, s.taxtotal,  
	       e.name AS EName, CASE WHEN b.billtype IN (20) THEN c.name ELSE y.name END AS SupplierName 
		FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id
		               INNER JOIN products p ON s.p_id = p.product_id
		               INNER JOIN unit u ON p.unit1_id = u.unit_id
		               INNER JOIN employees e ON b.e_id = e.emp_id
		               LEFT JOIN clients c ON s.supplier_id = c.client_id
		               LEFT JOIN company y ON b.c_id = y.company_id
		               INNER JOIN @ProductList pp ON s.p_id = pp.PId
		               INNER JOIN @SupplierList cc ON s.supplier_id = cc.CId
		               LEFT JOIN BaseFactory f ON s.factoryid = f.CommID
	WHERE b.billtype IN (20,35,220) AND b.billstates = 0 
	      AND s.AOID in(select szTYPE from DecodeToStr(@strBusinessType))
	      AND b.billdate BETWEEN @Begin AND @End AND
	      b.Y_ID = @YId AND (@EId = 0 OR @EId = b.e_id) AND (@SupplierId = 0 OR @SupplierId = s.supplier_id) AND
	      (@PId = 0 OR @PId = s.p_id) AND (@Factory = '' OR p.Factory LIKE '%' + @Factory + '%')
	      and ((@Companytable=0)or (s.Y_ID in (select [id] from #Companytable)))
END
GO
