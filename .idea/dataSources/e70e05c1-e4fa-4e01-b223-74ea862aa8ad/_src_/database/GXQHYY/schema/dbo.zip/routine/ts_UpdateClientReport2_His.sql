/************************************************************

--功能：更新往来单位证照   
--创建人：zfl

**************************************************************/

CREATE	 PROCEDURE [ts_UpdateClientReport2_His]
	(     
	      @flag int, /*标示是新增还是修改*/
          @C_ID int =0,
          @rpn_id int,
          @repNo varchar(100),
          @validtime datetime,
          @inputTime datetime,
          @pathname varchar(120),
          @ctype int
        )
AS 
   /* if @repNo = ''*/
    
	set @C_ID = Abs(@C_ID)

	select top 0 *
	into #tc
	from ClientReport2

	insert into #tc(repNo, c_id, inputTime, validTime, rpn_id, Pathname, ctype)
	values(@repNo,@C_ID,@inputTime,@validtime,@rpn_id,@pathname, @ctype)

	INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag)
	SELECT @C_ID, 'CR', (SELECT * FROM #tc AS ClientReport2 FOR XML AUTO, TYPE, ROOT), 1
	DROP TABLE #tc
GO
