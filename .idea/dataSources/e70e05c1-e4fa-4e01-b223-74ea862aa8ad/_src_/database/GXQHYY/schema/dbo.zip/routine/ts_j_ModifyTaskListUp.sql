/************************************************************

--功能: 
--创建人：
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_ModifyTaskListUp]

AS 
  
begin tran  

  Update TaskListUp set TranFlag = 2 from TaskListUp t1, TaskListUpdtsIN t2 where t1.trantype =0 and 
  	 t1.Tranflag = 1 and t1.billGuid = t2.billguid and t1.rowguid =t2.rowguid and t1.tabletype =t2.tabletype 
         and t1.Opertype = t2.opertype
						   
  truncate table TaskListUpDtsIN

commit tran
GO
