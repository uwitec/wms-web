
CREATE PROCEDURE Ts_K_SaveDeductFormula(
    @TId            INT = 0,            
    @Type           INT = 0,            
    @Name           VARCHAR(100) = '',
    @BeginDate      DATETIME = '1900-01-01',
    @EndDate        DATETIME = '1900-01-01',
    @NotCX          BIT = 0,                  /*促销商品不参与提成*/
    @Comment        VARCHAR(200) = '',
    @nRet           INT = 0 OUTPUT 
)
AS
BEGIN
	
	INSERT INTO Deduct_Formula(TId, [Type], Name, BeginDate, EndDate, NotCX, Comment)
	VALUES(@TId, @Type, @Name, @BeginDate, @EndDate, @NotCX, @Comment)
	
	SET @nRet = @@identity
	
END
GO
