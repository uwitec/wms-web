
/* =============================================*/
/* Author:		ZK*/
/* Create date: 2015-06-05*/
/* Description:	采购汇总综合查询使用*/
/* =============================================*/
CREATE FUNCTION GetPurchaseCollectAnalysisInfo 
(
	/*0采购品规数（时间段）；1退货品规数；2新增品规数；3不动销品规数；4品规数；5有效品规数；6历史供应品规数；7采购品规数（汇总）；*/
	/*8新增品规数（汇总）；9退货品规数（汇总）；10不动销品规数（汇总）；11负责品规数（采购员）；12采购品规数（采购员）；*/
	/*13采购退货品规数（采购员）；16库存余量（商品）；17品规数（类别）；18有效品规数（类别）；19采购品规数（类别）；*/
	/*20新增品规数（类别）；21不动销品规数（类别）；23历史供应品规数（汇总类别时间段）；24负责品规数（汇总类别时间段）；*/
	/*25采购品规数（汇总类别时间段）；26采购品规数（汇总类别时间段）；27退货品规数（汇总类别时间段）; 28库存上限（仅商品）;*/
	/*29库存下限（仅商品）;*/
	@Type              INT,             
	@Begin             VARCHAR(100),
	@End               VARCHAR(100),
	@YId               INT,
	@TimeType          INT,             /*时间段类型0日；1月；2季度*/
	@CollectType       INT,             /*汇总类型0供应商；1采购员；2商品*/
    @CollectItemIndex  INT,             /*供应商Id或采购员Id或商品Id*/
	@IsTime            INT,             /*是否选择时间段 0否；1是*/
	@CgId              INT              /*自定义类别Id*/
)
RETURNS VARCHAR(200)
AS
BEGIN
	DECLARE @NumericTmp numeric(25,8)
	DECLARE @IntTmp     INT
	DECLARE @Result VARCHAR(50), @ClassId VARCHAR(100)
	SET @Result = '0'
	
	IF @IsTime = 1
	BEGIN
		IF @TimeType = 1
		BEGIN
			/*月最后一天*/
			SET @Begin = @Begin + '-01'
			SET @End = @End + '-01'
			SET @End = CONVERT(VARCHAR(100), DATEADD(D, -DAY(CAST(@End AS DATETIME)), DATEADD(M, 1, CAST(@End AS DATETIME))), 23)
		END
		ELSE
		IF @TimeType = 2
		BEGIN
			/*季度第一天*/
			SET @IntTmp = CAST(SUBSTRING(@Begin, 5, 5) AS INT)	
			IF @IntTmp = 1
				SET @Begin = SUBSTRING(@Begin, 1, 4) + '-01-01'
			ELSE
			IF @IntTmp = 2
				SET @Begin = SUBSTRING(@Begin, 1, 4) + '-03-01'	
			ELSE
			IF @IntTmp = 3
				SET @Begin = SUBSTRING(@Begin, 1, 4) + '-06-01'	
			ELSE
				SET @Begin = SUBSTRING(@Begin, 1, 4) + '-09-01'
			
			/*季度最后一天*/
			SET @IntTmp = CAST(SUBSTRING(@End, 5, 5) AS INT)	
			IF @IntTmp = 1
				SET @End = SUBSTRING(@End, 1, 4) + '-03-31'
			ELSE
			IF @IntTmp = 2
				SET @End = SUBSTRING(@End, 1, 4) + '-06-30'	
			ELSE
			IF @IntTmp = 3
				SET @End = SUBSTRING(@End, 1, 4) + '-09-30'	
			ELSE
				SET @End = SUBSTRING(@End, 1, 4) + '-12-31'
			
			SET @Result = '0'
		END	
	END
	
	SET @IntTmp = 0
	
	IF @Type = 0
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT s.p_id
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0
				GROUP BY s.p_id
			) a
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 1
	BEGIN
		SELECT @IntTmp = COUNT(s.p_id)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (21, 161, 163) AND b.billstates = 0
		GROUP BY s.p_id
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 2
	BEGIN
		SELECT @IntTmp = COUNT(*) FROM products 
		WHERE Inputdate BETWEEN @Begin AND @End AND [deleted] = 0 AND child_number = 0
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 3
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT p_id FROM PerStockData 
					WHERE y_id = @YId AND [datetime] BETWEEN @Begin AND @End 
				GROUP BY p_id HAVING(SUM(qty)) > 0
			) a LEFT JOIN (
				SELECT s.p_id
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
					  b.billtype IN (10, 12, 150, 152) AND b.billstates = 0
				GROUP BY s.p_id	
			) b ON a.p_id = b.p_id 
		WHERE b.p_id IS NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 4
	BEGIN
		SELECT @IntTmp = COUNT(*) FROM products p 
		WHERE p.[deleted] = 0 AND p.child_number = 0 AND p.Inputdate <= @End
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 5
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT p_id FROM PerStockData 
					WHERE y_id = @YId AND [datetime] = CONVERT(VARCHAR(10), @End, 120)   
				GROUP BY p_id HAVING(SUM(qty)) > 0
			) a INNER JOIN (
				SELECT product_id FROM products 
				WHERE [deleted] = 0 AND child_number = 0 AND products.Inputdate <= @End GROUP BY product_id
			) b ON a.p_id = b.product_id 
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 6
	BEGIN
		SELECT @IntTmp = COUNT(p_id) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate < @Begin AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
				GROUP BY s.p_id
			) a	
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 7
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
				GROUP BY s.p_id
			) a	
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 8
	BEGIN
		SELECT @IntTmp = COUNT(a.p_id) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
				GROUP BY s.p_id
			) a LEFT JOIN (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate < @Begin AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
				GROUP BY s.p_id		
			) b ON a.p_id = b.p_id
		WHERE b.p_id IS NULL
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 9
	BEGIN
		SELECT @IntTmp = COUNT(s.p_id)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (21, 161, 163) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
		GROUP BY s.p_id
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))		
	END	
	ELSE
	IF @Type = 10
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT DISTINCT p_id FROM storehouse
					WHERE y_id = @YId AND supplier_id = @CollectItemIndex
				GROUP BY p_id
			) a LEFT JOIN (
				SELECT s.p_id
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
					  b.billtype IN (10, 12, 150, 152) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex
				GROUP BY s.p_id	
			) b ON a.p_id = b.p_id 
		WHERE b.p_id IS NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 11
	BEGIN
		SELECT @IntTmp = COUNT(p_id) 
			FROM productbalance 
		WHERE Y_id = @YId AND Emp_id = @CollectItemIndex 
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 12
	BEGIN
		SELECT @IntTmp = COUNT(p_id) 
			FROM (
				SELECT s.p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND b.e_id = @CollectItemIndex
				GROUP BY s.p_id
			) a	 
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 13
	BEGIN
		SELECT @IntTmp = COUNT(s.p_id)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (21, 161, 163) AND b.billstates = 0 AND b.e_id = @CollectItemIndex
		GROUP BY s.p_id
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))		
	END
	ELSE
	IF @Type = 14
	BEGIN
		SELECT @IntTmp = COUNT(a.p_id) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND b.e_id = @CollectItemIndex
				GROUP BY s.p_id
			) a LEFT JOIN (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate < @Begin AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND b.e_id = @CollectItemIndex
				GROUP BY s.p_id		
			) b ON a.p_id = b.p_id
		WHERE b.p_id IS NULL
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END	
	ELSE
	IF @Type = 15
	BEGIN
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT p_id FROM storehouse
					WHERE y_id = @YId
				GROUP BY p_id
			) a LEFT JOIN (
				SELECT s.p_id
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
					  b.billtype IN (10, 12, 150, 152) AND b.billstates = 0 AND b.e_id = @CollectItemIndex
				GROUP BY s.p_id	
			) b ON a.p_id = b.p_id 
		WHERE b.p_id IS NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 16
	BEGIN
		SELECT @NumericTmp = SUM(qty) FROM PerStockData 
		WHERE y_id = @YId AND p_id = @CollectItemIndex AND [datetime] = CONVERT(VARCHAR(10), @End, 120)  
		
		IF @NumericTmp IS NULL
			SET @NumericTmp = 0.00
		SET @Result = CAST(@NumericTmp AS VARCHAR(200))	
	END	
	ELSE
	IF @Type = 17
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		
		SELECT @IntTmp = COUNT(*) 
			FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
			                      INNER JOIN products p ON m.baseinfo_id = p.product_id 
		WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0  
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 18
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		
		SELECT @IntTmp = COUNT(*) 
			FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
			                      INNER JOIN products p ON m.baseinfo_id = p.product_id 
			                      LEFT JOIN (SELECT DISTINCT p_id FROM storehouse WHERE Y_ID = @YId) s ON m.baseinfo_id = s.p_id  
		WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0 AND s.p_id IS NOT NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END	
	ELSE
	IF @Type = 19
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		
		SELECT @IntTmp = COUNT(p_id) 
			FROM (
				SELECT s.p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0  and m.deleted=0)
				GROUP BY s.p_id
			) a	 
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 20
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		
		SELECT @IntTmp = COUNT(a.p_id) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0  AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id
			) a LEFT JOIN (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate < @Begin AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0  AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id		
			) b ON a.p_id = b.p_id
		WHERE b.p_id IS NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 21
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT DISTINCT m.baseinfo_id AS p_id
				   FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
									     INNER JOIN products p ON m.baseinfo_id = p.product_id 
			    WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0
			) a LEFT JOIN (
				SELECT s.p_id
					FROM billidx b INNER JOIN salemanagebill s ON b.billid = s.bill_id	
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND s.p_id > 0 AND 
					  b.billtype IN (10, 12, 150, 152) AND b.billstates = 0 AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id	
			) b ON a.p_id = b.p_id 
		WHERE b.p_id IS NULL
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 22
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CollectItemIndex
		SELECT @IntTmp = COUNT(s.p_id)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND b.billtype IN (21, 161, 163) AND b.billstates = 0 AND 
			  s.p_id IN (SELECT m.baseinfo_id 
							FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
												  INNER JOIN products p ON m.baseinfo_id = p.product_id 
						 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
		GROUP BY s.p_id
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))		
	END
	ELSE
	IF @Type = 23
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CgId
		
		SELECT @IntTmp = COUNT(p_id) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate < @Begin AND 
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id
			) a	
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 24
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CgId
		
		SELECT @IntTmp = COUNT(p_id) 
			FROM productbalance 
		WHERE Y_id = @YId AND Emp_id = @CollectItemIndex AND 
			  p_id IN (SELECT m.baseinfo_id 
							FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
												  INNER JOIN products p ON m.baseinfo_id = p.product_id 
						 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)  
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 25
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CgId
		
		SELECT @IntTmp = COUNT(*) 
			FROM (
				SELECT p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id
			) a	
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))
	END
	ELSE
	IF @Type = 26
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CgId
		
		SELECT @IntTmp = COUNT(p_id) 
			FROM (
				SELECT s.p_id 
					FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id 
				WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND
					  b.billtype IN (20, 160, 162) AND b.billstates = 0 AND b.e_id = @CollectItemIndex AND 
					  s.p_id IN (SELECT m.baseinfo_id 
									FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
														  INNER JOIN products p ON m.baseinfo_id = p.product_id 
								 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
				GROUP BY s.p_id
			) a	 
		
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 27
	BEGIN
		SELECT @ClassId = c.class_id + '%' FROM customCategory c WHERE c.id = @CgId
		
		SELECT @IntTmp = COUNT(s.p_id)
			FROM billidx b INNER JOIN buymanagebill s ON b.billid = s.bill_id	
		WHERE b.Y_ID = @YId AND b.billdate BETWEEN @Begin AND @End AND 
			  b.billtype IN (21, 161, 163) AND b.billstates = 0 AND s.supplier_id = @CollectItemIndex AND 
			  s.p_id IN (SELECT m.baseinfo_id 
							FROM customCategory c INNER JOIN customCategoryMapping m ON c.id = m.category_id
												  INNER JOIN products p ON m.baseinfo_id = p.product_id 
						 WHERE c.class_id LIKE @ClassId AND m.[deleted] = 0 AND m.BaseTypeid = 0)
		GROUP BY s.p_id
		IF @IntTmp IS NULL
			SET @IntTmp = 0
		SET @Result = CAST(@IntTmp AS VARCHAR(200))		
	END	
	ELSE
	IF @Type = 28
	BEGIN
		SELECT @NumericTmp = SUM(UpperLimit) FROM StoreLimitComp 
		WHERE y_id = @YId AND p_id = @CollectItemIndex
		
		IF @NumericTmp IS NULL
			SET @NumericTmp = 0.00
		SET @Result = CAST(@NumericTmp AS VARCHAR(200))	
	END
	ELSE
	IF @Type = 29
	BEGIN
		SELECT @NumericTmp = SUM(LowLimit) FROM StoreLimitComp 
		WHERE y_id = @YId AND p_id = @CollectItemIndex
		
		IF @NumericTmp IS NULL
			SET @NumericTmp = 0.00
		SET @Result = CAST(@NumericTmp AS VARCHAR(200))	
	END
	
	RETURN @Result	
END
GO
