


CREATE	TRIGGER delOrderdrf ON [dbo].[orderidx]
FOR  delete
AS
 if exists(select 1 from deleted where billtype in (14,154))
  begin
	  delete from orderdraft where bill_id in (select billid from deleted where  billtype in (14,154))
	  delete from OrderBill where bill_id in (select billid from deleted where  billtype in (14,154))
  end
GO
