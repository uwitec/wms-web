

CREATE PROC [dbo].[GetDTSSql]
  @Table VARCHAR(50),
  @EndName varchar(50) = '_dts'
AS  
begin 
	IF @EndName IS NULL 
	  SET @EndName = '_dts'
	DECLARE @SQL VARCHAR(8000) SET @SQL = ''

	DECLARE @name VARCHAR(50) SET @name = ''
	DECLARE @xtype VARCHAR(50) SET @xtype = ''
	DECLARE @length INT SET @length = 0
	DECLARE @xprec INT SET @xprec= 0
	DECLARE @xscale INT SET @xscale = 0
	/*DECLARE @isnullable INT SET @isnullable = 0*/

	DECLARE Mycur SCROLL CURSOR FOR 
	select name,TYPE_NAME(xtype),length,xprec,xscale from dbo.syscolumns 
	 where id = object_id(@Table) 
	   AND xTYPE NOT IN (189) 
	OPEN Mycur   

    SET @SQL = 'if exists (select * from dbo.sysobjects where id = object_id(N''' + @Table + @EndName 
             + ''') and OBJECTPROPERTY(id, N''IsUserTable'') = 1) drop table ' + @Table + @EndName
             + ' CREATE TABLE ' + @Table + @EndName + '('
	DECLARE @count INT SET @count = @@CURSOR_ROWS
	DECLARE @i INT SET @i = 0
	WHILE @i < @count
	BEGIN
	  FETCH NEXT FROM MyCur INTO @name, @xtype,	@length, @xprec, @xscale
	  /*IF @xtype IN ('int','bigint','smallint','bit','numeric(25,8)','tinyint','DATETIME') */
	  /*    SET @SQL = @SQL + @name + ' ' + @xtype */
	  IF @xtype IN ('varchar','nvarchar','char','nchar','VarBinary','Binary')
	    SET @SQL = @SQL + @name + ' ' + @xtype + '(' + CAST(@length AS VARCHAR(50)) + ')'
	  ELSE IF @xtype IN ('numeric')  
	    SET @SQL = @SQL + @name + ' ' + @xtype + '(' + CAST(@xprec AS VARCHAR(50)) + ',' + CAST(@xscale AS VARCHAR(50)) + ')'
	  ELSE SET @SQL = @SQL + @name + ' ' + @xtype   
	    
	  IF @i + 1 = @count 
	    SET @SQL = @SQL + ')'
	  ELSE
	    SET @SQL = @SQL + ','	
	       
	  /*     */
	  SET @i = @i + 1
	END
   
	CLOSE Mycur
	DEALLOCATE Mycur 
	
	PRINT @SQL
	SELECT @SQL
	/*PRINT len(@SQL)*/
	/*EXEC(@SQL)*/

END
GO
