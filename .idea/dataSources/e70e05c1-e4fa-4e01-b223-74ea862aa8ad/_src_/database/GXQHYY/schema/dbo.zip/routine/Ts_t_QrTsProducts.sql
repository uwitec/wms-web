create procedure Ts_t_QrTsProducts
(@TcProjectID int)
AS
select  p.serial_number,p.name as Pname,t.Name as Tname,t.Comment,p.alias,p.standard,p.permitcode,p.makearea,
 p.MedName,p.Unit1Name,p.comment as Pcomment,t.id 
from (select Tpo.id, Tpo.p_id,Tpo.Tp_id,Tp.Name,TP.Comment 
             from TcProjectOther Tpo left join TcFormula TP on Tpo.F_id  = Tp.Formula_id)t 
left join vw_Products p on t.p_id=p.product_id 
where t.Tp_id = @TcProjectID
GO
