

CREATE  procedure TS_L_VIPCardLevelUp 
  @type int,
  @CardID int
as
begin  /*select * from vipcardtype  update vipcard set totalbuymoney=1000 where vipcardid=67*/
  declare   @oldCT_ID int,
            @NewCT_ID int,
            @IsMoneyUp int,
            @UpMoney numeric(25,8),          
            @TotalBuyMoney numeric(25,8),
            @IsIntegralUp int,   /*是否启用积分升级*/
            @Upintegral int,     /*多少分升级*/
            @UpDecIntegral int,  /*升级后扣除多少积分*/
            @Integral int,       /*积分总额*/
            @isStoragUp int,      /*储值升级*/
            @UpStorag numeric(25,8),	  /*升级需要达到的储值金额*/
            @SaveMoney numeric(25,8),     /*储值的金额*/
            @IsBank int,
            @IsIntegral int,
            @CardNo varchar(50),
            @Msg varchar(80)
  if @type=1
  begin
    select @IsBank=IsBank,@IsIntegral=IsIntegral,@CardNo=CardNo,@Integral=Integral,
           @TotalBuyMoney=TotalBuyMoney,@oldCT_ID=Card.CT_ID,@NewCT_ID=MoneyUpCT_ID,@IsMoneyUp=IsMoneyUp,@UpMoney=UpMoney
      from VIPCard card left join VIPCardType type on card.ct_id=type.ct_id
     where card.VIPCardID=@CardID
    if (@IsMoneyUp=1) and (@TotalBuyMoney>=@UpMoney) 
    begin
      if @IsBank=1
        if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsBank=1)
        begin
          select @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有储值功能,不能进行升级!'
          raiserror(@Msg,16,1)
          return -1
        end
      if @IsIntegral=1
        if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsIntegral=1 and @Integral>0)
        begin
          select @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有积分功能,不能进行升级!'
          raiserror(@Msg,16,1)
          return -1
        end      
     update VIPcard set ct_id=@NewCT_ID  where VIPCardID=@CardID
    end
  end
  else if @type=2
    begin
      select @IsBank=IsBank,@IsIntegral=IsIntegral,@CardNO=CardNo,
             @oldCT_ID=Card.CT_ID,@NewCT_ID=IntegeralUpCT_ID,
             @Integral=Integral,@IsIntegralUp=IsIntegralUp,@Upintegral=Upintegral,@UpDecIntegral=UpDecIntegral
        from VIPCard card left join VIPCardType type on card.ct_id=type.ct_id
       where card.VIPCardID=@CardID
      if (@IsIntegralUp=1) and (@Integral>=@Upintegral) 
      begin
        if @IsBank=1
          if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsBank=1)
          begin
            set @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有储值功能,不能进行升级!'
            raiserror(@Msg,16,1)
            return -1
          end
        if @IsIntegral=1
          if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsIntegral=1 and @Integral>0)
          begin
            set @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有积分功能,不能进行升级!'
            raiserror(@Msg,16,1)
            return -1
          end       
      end
      update VIPCard set Integral=Integral-@UpDecIntegral where VIPCardID=@CardID
      update VIPcard set ct_id=@NewCT_ID where VIPCardID=@CardID      
    end 
 else if @type=3   /*储值升级*/
    begin
      select @IsBank=IsBank,@IsIntegral=IsIntegral,@CardNO=CardNo,@Integral=Integral,
             @oldCT_ID=Card.CT_ID,@NewCT_ID=lStoragUpCT_id,
             @SaveMoney=SaveMoney,@isStoragUp=isStoragUp,@UpStorag=UpStorag
        from VIPCard card left join VIPCardType type on card.ct_id=type.ct_id
			left join VipCardTypeExtend ve on type.ct_id = ve.bill_id
       where card.VIPCardID=@CardID
      if (@isStoragUp=1) and (@SaveMoney>=@UpStorag) 
      begin
        if @IsBank=1
          if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsBank=1)
          begin
            set @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有储值功能,不能进行升级!'
            raiserror(@Msg,16,1)
            return -1
          end
        if @IsIntegral=1
          if not exists(select * from VIPCardType where ct_id=@NewCT_ID and IsIntegral=1 and @Integral>0)
          begin
            set @Msg='【'+@CardNo+'】'+'升级后的卡类型不具有积分功能,不能进行升级!'
            raiserror(@Msg,16,1)
            return -1
          end       
      end
      update VIPcard set ct_id=@NewCT_ID where VIPCardID=@CardID      
    end    
    
end
GO
