

CREATE VIEW dbo.vw_c_billdraftidx
AS
SELECT 
      dbo.billdraftidx.billid, dbo.billdraftidx.billdate, dbo.billdraftidx.billnumber, dbo.billdraftidx.billtype, 
      dbo.billdraftidx.a_id, dbo.billdraftidx.c_id, dbo.billdraftidx.e_id, 
      sout_id =case  when dbo.billdraftidx.billtype in (122,112) then 0 else  dbo.billdraftidx.sout_id end,
      sin_id= case when dbo.billdraftidx.billtype in (122,112) then 0 else dbo.billdraftidx.sin_id end,
      dbo.billdraftidx.auditman, dbo.billdraftidx.inputman, dbo.billdraftidx.ysmoney, dbo.billdraftidx.ssmoney, dbo.billdraftidx.quantity, dbo.billdraftidx.taxrate, dbo.billdraftidx.period,
      dbo.billdraftidx.billstates, dbo.billdraftidx.order_id, dbo.billdraftidx.department_id, dbo.billdraftidx.posid, dbo.billdraftidx.region_id, dbo.billdraftidx.auditdate,
      dbo.billdraftidx.skdate, dbo.billdraftidx.jsye, dbo.billdraftidx.jsflag, dbo.billdraftidx.note, dbo.billdraftidx.summary, dbo.billdraftidx.invoice, dbo.billdraftidx.transcount,
      dbo.billdraftidx.lasttranstime, dbo.billdraftidx.GUID, dbo.billdraftidx.InvoiceTotal, dbo.billdraftidx.InvoiceNO, dbo.billdraftidx.BusinessType, dbo.billdraftidx.jsInvoiceTotal,
      dbo.billdraftidx.SendQTY, dbo.billdraftidx.GatheringMan, dbo.billdraftidx.Y_ID, dbo.billdraftidx.transflag, dbo.billdraftidx.begindate, dbo.billdraftidx.Enddate, dbo.billdraftidx.integral, 
      dbo.billdraftidx.integralYE, dbo.billdraftidx.B_CustomName1, dbo.billdraftidx.B_CustomName2, dbo.billdraftidx.B_CustomName3, dbo.billdraftidx.RetailDate,
      dbo.billdraftidx.sendC_id, dbo.billdraftidx.WholeQty, dbo.billdraftidx.PartQty, dbo.billdraftidx.VIPCardID, dbo.billdraftidx.ArAptotal,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.[name] else CY.[name] END), '') as cname,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.address else CY.opaddress end),'') as cAddress,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.contact_personal else CY.manager end), '') as cContact_personal,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.phone_Number else CY.tel end), '') as cPhone_Number,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.class_id else CY.class_id end), '')cclass_id,
      isnull((case when dbo.billdraftidx.billtype not in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then clients.serial_number else CY.serial_number end), '')Cnumber, 
      ISNULL(dbo.account.name, '') AS aname, ISNULL(dbo.employees.name, '') AS ename, 
      ISNULL(dbo.account.class_id, '') AS aclass_id,  ISNULL(dbo.employees.class_id, '') AS eclass_id, 
      ISNULL(emp.class_id, '') AS inputmanclass_id, ISNULL(emp.name, '') 
      AS inputmanname, ISNULL(empa.name, '') AS auditmanname, ISNULL(empa.class_id, 
      '') AS auditmanclass_id, ISNULL(dep.name, '') AS departmentname, ISNULL(reg.name, 
      '') AS regionname, ISNULL(ss.name, '') AS ssname, ISNULL(sd.name, '') 
      AS sdname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      ISNULL(empg.name, '') AS GatheringManName, ISNULL(empg.class_id, '') AS GatheringManclass_id,
      ISNULL(Y.Class_ID,'') as YClass_ID,ISNULL(Y.[name],'') as Yname,
      isnull((case when billdraftidx.billtype in (150,151,152,153,155,160,161,162,163,165, 166, 157, 158, 159) then CY.Class_ID else '' end),'') as CYClass_ID,
       billdraftidx.QualityAudit, billdraftidx.QualityAuditDate, isnull(eQuality.[name],'') as QualityAuditer, ISNULL(wt.saleEName, '') as wtEName,
       FollowNumber,TicketDate,ISNULL(sds.name, '') AS sendcname 
FROM dbo.billdraftidx LEFT OUTER JOIN
      dbo.account ON dbo.billdraftidx.a_id = dbo.account.account_id LEFT OUTER JOIN
      dbo.clients ON dbo.billdraftidx.c_id = dbo.clients.client_id LEFT OUTER JOIN
      dbo.employees ON dbo.billdraftidx.e_id = dbo.employees.emp_id LEFT OUTER JOIN
      dbo.employees emp ON dbo.billdraftidx.inputman = emp.emp_id LEFT OUTER JOIN
      dbo.employees empa ON 
      dbo.billdraftidx.auditman = empa.emp_id LEFT OUTER JOIN
      dbo.employees empg ON dbo.billdraftidx.GatheringMan = empg.emp_id LEFT OUTER JOIN     
      dbo.department dep ON dbo.billdraftidx.department_id = dep.departmentId 
      left outer join employees eQuality on dbo.billdraftidx .QualityAudit=eQuality.emp_id
      LEFT OUTER JOIN
      dbo.Region reg ON dbo.billdraftidx.region_id = reg.region_id LEFT OUTER JOIN
      dbo.storages ss ON dbo.billdraftidx.sout_id = ss.storage_id LEFT OUTER JOIN
      dbo.storages sd ON dbo.billdraftidx.sin_id = sd.storage_id LEFT OUTER JOIN
      dbo.Company  Y  on dbo.billdraftidx.Y_id = Y.company_id   LEFT OUTER JOIN 
      dbo.Company  CY  on billdraftidx.C_id=CY.company_id LEFT OUTER JOIN 
      dbo.orderidx  oidx  on dbo.billdraftidx.order_id = oidx.billid LEFT OUTER JOIN 
      dbo.wtorder   wt  on oidx.WT_ID= wt.WT_ID LEFT OUTER JOIN 
      dbo.clients   sds on dbo.billdraftidx.sendC_id=sds.client_id
GO
