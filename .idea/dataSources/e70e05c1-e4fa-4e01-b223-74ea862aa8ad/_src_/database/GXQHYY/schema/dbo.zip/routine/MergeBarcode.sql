
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2012-9-26*/
/* Description:	合并同一商品多个条码*/
/* =============================================*/
CREATE FUNCTION MergeBarcode 
(
	@col int
)
RETURNS varchar(500)
AS
BEGIN
	DECLARE @Result varchar(500)

	SELECT @Result = ISNULL(@Result + ',', '') + barcode from barcode where p_id = @col

	RETURN @Result

END
GO
