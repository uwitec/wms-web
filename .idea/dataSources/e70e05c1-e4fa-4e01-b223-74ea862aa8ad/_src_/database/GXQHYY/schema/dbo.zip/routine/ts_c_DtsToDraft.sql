
/*DTS库到草稿*/
create  procedure ts_c_DtsToDraft
/*with encryption*/
as
set nocount on

/*变量定义*/
declare @nBillType smallint /*单据类型*/
declare @nBillid int,@nnewbillid int/*单据id,*/
declare @PosGuid varchar(50),@nPosid int,@nret int
declare @nGuid uniqueidentifier
declare @RetailMerge int /*零售单合并选项*/
declare @begindate varchar(10),@enddate varchar(10)
declare @nReturn int
set @nReturn = -1

/*变量定义end*/

set @RetailMerge=0
select @RetailMerge=sysvalue from sysconfig where [sysname]='RetailMerge'



set @begindate='1900-01-01'
set @enddate  ='2900-01-01'

set @nPosid=0

begin tran 

  select @begindate=convert(varchar(10),min(billdate),21),@enddate=convert(varchar(10),max(billdate),21)
  from billdtsidxIN 

  select a.* into #guidtemp
  from (select guid from retailmerge where billdate between @begindate and @enddate
         union select guid from billidx where billdate between @begindate and @enddate and billstates='0' 
         union select guid from billdraftidx )  a
  
  /*清除已经上传过的单据。*/
    delete salemanagebilldtsin from billdtsidxIN b ,salemanagebilldtsin s 
    where b.billid=s.bill_id  and b.guid in (select guid from #guidtemp)
  
    delete buymanagebilldtsin from billdtsidxIN b ,buymanagebilldtsin s 
    where b.billid=s.bill_id  and b.guid in (select guid from #guidtemp)

    delete storemanagebilldtsin from billdtsidxIN b ,storemanagebilldtsin s 
    where b.billid=s.bill_id and  b.guid in (select guid from #guidtemp)

    delete GoodsCheckbilldtsin from billdtsidxIN b ,GoodsCheckbilldtsin s 
    where b.billid=s.bill_id and  b.guid in (select guid from #guidtemp)

    delete financebilldtsin from billdtsidxIN b ,financebilldtsin s 
    where b.billid=s.bill_id and  b.guid in (select guid from #guidtemp)

    delete tranmanagebilldts from billdtsidxIN b ,tranmanagebilldts s 
    where b.billid=s.bill_id and  b.guid in (select guid from #guidtemp)

    delete ExIntegRalManagebilldtsin from billdtsidxIN b ,ExIntegRalManagebilldtsin s 
    where b.billid=s.billid and  b.guid in (select guid from #guidtemp)

    delete billdtsidxIN where guid in (select guid from #guidtemp)
	
  
  /*清除已经上传过的单据。*/

  /*合并零售单据*/
  if @RetailMerge<>0 and exists(select * from billdtsidxIN where billtype in (12,13)) 
    exec ts_c_merageRetailbillEx @RetailMerge,@nret output
  if @nret<>0 
  begin
    rollback tran
    return 0
  end

	declare billdraftidxcur cursor for
	select billid,billtype,posguid from billdtsidxIN
	open billdraftidxcur
	
	fetch next from billdraftidxcur into @nBillid,@nBillType,@PosGuid
	while @@FETCH_STATUS=0	
	begin
		select @nPosid=posid from ReplicationAuthorize where guid=@PosGuid
	
		/*销售出库单据,销售出库退货单,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,,销售单,销售退货单,发货单, 机构发货退货、自营店发货退货*/
		if @nBilltype in (10,11,12,13,16,17,110,111,112,32,210,212,211,150,151,152,153) 
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty,
			QualityAudit,QualityAuditDate,YGuid) 

			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,wholeqty,partqty,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN where billid=@nbillid
			
			select @nnewbillid=@@identity
			/*select * from salemanagebilldtsIN*/
			insert into salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
			RowGuid, RowE_id, YCostPrice, Y_ID, instoretime, cxType, location_id2, comment2,batchbarcode,scomment,batchprice,
			CxGuid,Conclusion,OOSid,factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select @nnewbillid, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
			totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
			qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
			comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,0,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
			RowGuid, RowE_id, YCostPrice, Y_ID, instoretime, cxType, location_id2, comment2,batchbarcode,scomment,batchprice,
			CxGuid,Conclusion,OOSid,factoryid, costtaxprice, costtaxrate, costtaxtotal
			from salemanagebilldtsIN
			where bill_id=@nbillid	
			order by smb_id
						
			update billdraftidx set ArAptotal = 1 where billid = @nnewbillid and billtype in (12, 13) and ArAptotal = 2			
		    
		end else
		/*采购入库单,采购入库退货单,受托代销收货,受托代销退货,受托代销结算,采购单,采购退货单,收货单*/
		if @nBilltype in (20,21,24,25,120,121,122,35,220,222,221, 163) 
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid) 
			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN where billid=@nbillid
		
			select @nnewbillid=@@identity
		    /*select * from buymanagebilldtsIN*/
			insert into buymanagebilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
		      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime,comment2,batchbarcode,scomment,batchprice,
		      Conclusion,factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select @nnewbillid, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,0,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
		      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, comment2,batchbarcode,scomment,batchprice,
		      Conclusion,factoryid, costtaxprice, costtaxrate, costtaxtotal
			from buymanagebilldtsin where bill_id=@nbillid	
			order by smb_id
		end else
		/*库存类单据  SELECT * from storemanagebilldts*/
		if @nBilltype in (30,31,33,34,40,41,42,43,44,45,46,47,48,49,51,141)
		/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty,
			QualityAudit,QualityAuditDate,YGuid) 
			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,wholeqty,partqty,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN 
			where billid=@nbillid
		
			select @nnewbillid=@@identity
			
			insert into storemanagebilldrf(bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
		     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,thqty,newprice,orgbillid,aoid,SendQty,SendCostTotal,
		     RowGuid, RowE_id, Y_ID, instoretime,batchbarcode,scomment,batchprice,
		     Conclusion,factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select @nnewbillid, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
		     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,InvoiceTotal,thqty,newprice,0,aoid,SendQty,SendCostTotal,
		     RowGuid, RowE_id, Y_ID, instoretime,batchbarcode,scomment,batchprice,
		     Conclusion,factoryid, costtaxprice, costtaxrate, costtaxtotal
			from storemanagebilldtsin
			where bill_id=@nbillid	
			order by smb_id
		end else
		if @nBilltype=50
		/*库存盘点单*/
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid)
			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN where billid=@nbillid
		
			select @nnewbillid=@@identity
			/*select * from GoodsCheckbill*/
			insert into GoodsCheckbilldrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,aoid,RowGuid, Y_ID, instoretime,batchbarcode,scomment,batchprice,Conclusion,
			  factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select @nnewbillid, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
		      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
		      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
		      comment,unitid,taxrate,order_id,total,aoid, RowGuid, Y_ID, instoretime,batchbarcode,scomment,batchprice,Conclusion,
			  factoryid, costtaxprice, costtaxrate, costtaxtotal
			from GoodsCheckbilldtsin where bill_id=@nbillid	
			order by smb_id
		end else
		/*库存盘点单*/

		/*钱流单据*/
		if @nbilltype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,148)
		/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买,储值单*/
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid)
			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN where billid=@nbillid
		
			select @nnewbillid=@@identity
			
			insert into financebilldrf(bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal, RowGuid, Y_Id, Conclusion)
			select @nnewbillid,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,InvoiceTotal, RowGuid, Y_Id, Conclusion
			from financebilldtsin 
			where bill_id=@nbillid	
			order by smb_id
		end else
		if @nBilltype in (149) 
		/*积分兑换单*/
		begin
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid)
			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
		      	@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,
			QualityAudit,QualityAuditDate,YGuid
			from billdtsidxIN where billid=@nbillid

                        select @nnewbillid=@@identity
     
                         insert into ExIntegralmanagebilldrf(
                                 billid,
                                 p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid,
				 batchno,makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal, rowguid, Y_Id, instoretime
                                )
                         select @nnewbillid,
                                 p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid,
				 batchno,makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal, rowguid, Y_Id, instoretime
                         from ExIntegralmanagebilldtsin
                         where billid=@nbillid
                         order by smb_id
	  	end 
		/*不再处理配送单据*/
		/*if @nBilltype in (53,54,55,56) */
		/*begin*/
			/*insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, */
			/*ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, */
			/*posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,*/
			/*SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID) */

			/*select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, */
			/*ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, */
			/*@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,*/
			/*SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID*/
			/*from billdtsidx where billid=@nbillid*/

			/*select @nnewbillid=@@identity*/
			
			/*insert into tranmanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, */
			/*totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, */
			/*qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, */
			/*comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal)*/
			/*select @nnewbillid, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, */
			/*totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, */
			/*qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, */
			/*comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,0,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal*/
			/*from tranmanagebilldts*/
			/*where bill_id=@nbillid	*/
			/*order by smb_id*/
		/*end*/
		fetch next from billdraftidxcur into @nBillid,@nBillType,@PosGuid
	end	
	close billdraftidxcur
	deallocate billdraftidxcur



/*调价单据*/
 
  
  /*清除已经上传过的单据。*/
    delete pricebilldtsin from priceidxdtsin b ,pricebilldtsin s 
    where b.billid=s.bill_id  and b.guid in (select guid from priceidx)
    delete priceidxdtsin where guid in (select guid from priceidx)


  	declare pricedraftidxcur cursor for
	  select billid,billtype from priceidxdtsin
	  open pricedraftidxcur
	
	  fetch next from pricedraftidxcur into @nBillid,@nBillType
	  while @@FETCH_STATUS=0	
	  begin
  		insert into priceidx(billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid, Y_ID)
	  	select billdate, billnumber, billtype, e_id, 0, inputman, 
			period, 2, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid, Y_ID
 			from priceidxdtsin where billid=@nbillid

			select @nnewbillid=@@identity

		  /*调价单*/
		  insert into pricebill(bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment, Y_Id, oldretailprice)
		  select @nnewbillid, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment, Y_Id, oldretailprice
		  from pricebilldtsin where bill_id=@nbillid
		  order by [id]
		  fetch next from pricedraftidxcur into @nBillid,@nBillType
	  end	
	  close pricedraftidxcur
	  deallocate pricedraftidxcur
      set @nReturn = 0
/*调价单据*/
commit tran 

truncate table billdtsidxIN
truncate table financebilldtsIN
truncate table buymanagebilldtsIN
truncate table salemanagebilldtsIN
truncate table storemanagebilldtsIN
truncate table goodscheckbilldtsIN
truncate table tranmanagebilldts
truncate table priceidxdtsIN
truncate table pricebilldtsIN
truncate table ExIntegRalManagebillDTSIN


return @nReturn
GO
