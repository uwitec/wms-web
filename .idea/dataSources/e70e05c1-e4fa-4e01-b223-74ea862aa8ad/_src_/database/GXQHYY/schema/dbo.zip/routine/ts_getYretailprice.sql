

/*
最分支机构零售价，可自行修改取价格的数值
*/

CREATE proc ts_getYretailprice
(
	@nY_ID int,
	@nP_id int

)
as

set nocount on
declare @dRetailPrice numeric(25,8), @nSwarajPrice int
 set @dRetailPrice =0
 select @nSwarajPrice = SwarajPrice from company where company_id = @nY_ID
 if @nSwarajPrice = 1 
   select @dRetailPrice = retailprice  from PosPrice where unittype =1 and Y_ID = @nY_ID and p_id = @nP_id
 if @dRetailPrice =0 or (@dRetailPrice is null)
   select @dRetailPrice = retailprice  from price where unittype =1 and p_id = @nP_id
 if @dRetailPrice is null
   set @dRetailPrice =0
 select  @dRetailPrice as retailprice
GO
