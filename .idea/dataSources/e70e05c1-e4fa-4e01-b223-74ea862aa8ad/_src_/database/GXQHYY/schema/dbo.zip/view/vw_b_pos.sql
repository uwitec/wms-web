

CREATE VIEW vw_b_pos
AS
SELECT PosID, PosName
FROM dbo.Shop
WHERE (deleted = 0)
GO
