
CREATE  FUNCTION [GetWhereStr](@szStr VARCHAR(4000))  
RETURNS 
  nvarchar(2000)
AS
BEGIN
	declare @Result nvarchar(2000)
	declare @name varchar(30)
	declare @minValue numeric(8, 2)
	declare @maxValue numeric(8, 2)
	declare @cur_Room cursor 
	
	set @Result = ''
	set @cur_Room = cursor for
	select name,minValue,maxValue from mlRataRoom where ml_id in (select TYPE as ml_id from DecodeStr(@szStr))  /*传入的id字符串*/

	open @cur_Room
	fetch next from @cur_Room into @name,@minValue,@maxValue

	while (@@FETCH_STATUS = 0)
	  begin
		if @Result = ''
		  select  @Result = ' (mlRate > ' + str(@minValue,8) + ' and  mlRate < ' + str(@maxValue,8) + ')' 	
		else
		  set  @Result = @Result + ' or (mlRate > ' + str(@minValue,8) + ' and  mlRate < ' + str(@maxValue,8) + ')' 
		fetch next from @cur_Room into @name,@minValue,@maxValue
	  end
	/*print(@where2)*/
	close @cur_Room
	deallocate @cur_Room
  RETURN @Result
END
GO
