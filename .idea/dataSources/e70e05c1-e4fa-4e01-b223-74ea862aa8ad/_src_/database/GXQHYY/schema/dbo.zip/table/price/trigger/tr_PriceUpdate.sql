
Create	TRIGGER tr_PriceUpdate ON [dbo].[Price]
FOR INSERT,UPDATE,Delete
AS
begin	
	DECLARE @y_id INT SET @y_id = 0
	DECLARE @count INT SET @count = 0
	SELECT @y_id = IsNull(sysvalue,0) FROM sysconfig WHERE SYSNAME = 'y_id'
	SELECT @count = ISNULL(COUNT(*),0) FROM company c WHERE DELETED = 0 AND child_count = 0
	
	/*总部修改价格后更新这个商品的时间戳 @count=1可能是分公司*/
	IF @y_id = 2 AND @count > 1
	begin
        UPDATE Price SET u_id = u_id 
         WHERE p_id in ( (select p_id from DELETED) UNION ALL (select p_id from inserted) )
    end     
end
GO
