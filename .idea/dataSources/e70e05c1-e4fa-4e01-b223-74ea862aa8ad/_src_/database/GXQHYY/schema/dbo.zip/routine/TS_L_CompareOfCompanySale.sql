
CREATE PROCEDURE TS_L_CompareOfCompanySale(@y_id INT, @nplan_id INT = 0)
AS
BEGIN
	/*-总部机构生成明细和总数据*/
	IF EXISTS(SELECT 1 FROM sysconfig WHERE  SYSNAME = 'Y_ID' AND sysvalue = '2')
	BEGIN
	    CREATE TABLE #tmp
	    (
	    	plan_id   INT,
	    	y_id      INT,
	    	billdate  DATETIME
	    )
	    
	    DECLARE @plan_id    INT
	    DECLARE @ny_id      INT
	    DECLARE @begindate  DATETIME
	    DECLARE @enddate    DATETIME
	    DECLARE @billdate   DATETIME
	    /*-----------------------重置对账明细后，门店上传后更新总部数据---------begin---------------*/
	    IF (@y_id <> 2) AND (@nplan_id = 0)
	    BEGIN
	        /*------删除上传机构的总部明细（包含：重置,和为上传完成的计划）---------------*/
	        DELETE FROM reconciliationDetail
	        WHERE y_id = @y_id AND isRemote = 0 AND EXISTS(SELECT 1 FROM   reconciliationPlan rp WHERE  rp.plan_id = reconciliationDetail.plan_id AND (rp.TransFlag = 3 OR rp.TransFlag = 0))
	        /*------重置上传机构计划*/
	        UPDATE reconciliationResult SET TransFlag = 0
	        WHERE isRemote = 0 AND y_id = @y_id AND EXISTS(SELECT 1 FROM   reconciliationPlan rp WHERE  rp.plan_id = reconciliationResult.plan_id AND (rp.TransFlag = 3 OR rp.TransFlag = 0))
	    END
	    /*-----------------------重置对账明细后，门店上传后更新总部数据---------end---------------*/
	    
	    
	    /*-------------------创建对账计划，生成总部数据--------begin------------------- */
	    DECLARE mxcur CURSOR  
	    FOR
	        SELECT re.plan_id, y_id, begindate, enddate  
	        FROM   reconciliationResult re
	               LEFT JOIN reconciliationPlan rp ON  re.plan_id = rp.plan_id
	        WHERE  re.TransFlag = 0 AND re.isRemote = 0 AND (re.plan_id = @nplan_id OR @nplan_id = 0)
	    
	    OPEN mxcur
	    
	    FETCH NEXT FROM mxcur INTO @plan_id,@ny_id,@begindate,@enddate                            
	    
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        SET @billdate = @begindate
	        WHILE (@billdate <= @enddate)
	        BEGIN
	            /*----初始化中间表，将日期段转换为每一天*/
	            INSERT INTO #tmp(plan_id, y_id, billdate)
	            VALUES(@plan_id, @ny_id, @billdate)
	            SET @billdate = DATEADD(D, 1, @billdate)
	        END 
	        FETCH NEXT FROM mxcur INTO @plan_id,@ny_id,@begindate,@enddate
	    END
	    
	    CLOSE mxcur
	    DEALLOCATE mxcur
	    
	    IF NOT EXISTS(SELECT * FROM #tmp)
	        RETURN 0
	    /*    else*/
	    /*      update reconciliationResult set TransFlag = 1 where*/
	    /*      exists(select 1 from #tmp where reconciliationResult.y_id = #tmp.y_id and reconciliationResult.plan_id = #tmp.plan_id) */
	    
	    SELECT plan_id,  #tmp.y_id, #tmp.billdate, ISNULL(mx.retailqty, 0) AS retailqty, ISNULL(mx.retailtotal, 0) AS retailtotal,
	           ISNULL(mx.retailBackQty, 0) AS retailBackQty, ISNULL(mx.retailbacktotal, 0) AS retailbacktotal, ISNULL(mx.cash, 0) AS cash,
	           ISNULL(mx.noncash, 0) AS noncash, 0 AS isRemote, 0 AS TransFlag 
		INTO #instt
	    FROM   #tmp
	           LEFT JOIN (
	                    SELECT i.billdate, i.Y_ID,
	                           SUM(CASE i.billtype WHEN 12 THEN b.quantity END) AS retailQty,
	                           SUM(CASE billtype WHEN 12 THEN ISNULL(b.taxtotal, 0) END) AS retailTotal,
	                           SUM(CASE billtype WHEN 13 THEN ISNULL(b.quantity, 0) END) AS retailBackQty,
	                           SUM(CASE billtype WHEN 13 THEN ISNULL(b.taxtotal, 0) END) AS retailBackTotal,
	                           SUM(CASE WHEN b.p_id = - 6 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id = - 6 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS cash,
	                           SUM(CASE WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS nonCash
	                    FROM   (
	                               SELECT billdate, Y_ID, billtype, billid
	                               FROM   dbo.billidx
	                               WHERE  (billstates = '0') AND (billtype IN (12, 13))
	                           ) AS i
	                           INNER JOIN salemanagebill AS b ON  i.billid = b.bill_id
	                    WHERE  (b.AOID IN (0, 5))
	                    GROUP BY i.billdate, i.Y_ID
	                ) MX ON  MX.Y_ID = #tmp.y_id AND mx.billdate = #tmp.billdate
	    
	    IF (@y_id <> 2)
	       AND (@nplan_id = 0) /*------总部重算时只更新对应机构的，否则会提示插入重复键*/
	    BEGIN
	        /*---插入明细*/
	        INSERT INTO reconciliationDetail
	          (plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag)
	        SELECT plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag
	        FROM   #instt
	        WHERE  #instt.y_id = @y_id
	        
	        
	        /*-----插入合计*/
	        
	        UPDATE reconciliationResult
	        SET    retailQty = t.retailqty, retailTotal = t.retailtotal, retailBackQty = t.retailBackQty, 
	               retailBackTotal = t.retailbacktotal, cash = t.cash, nonCash = t.noncash
	        FROM   (
	                   SELECT plan_id, y_id, SUM(retailqty) AS retailqty, SUM(retailtotal) AS retailtotal, SUM(retailBackQty) AS retailBackQty,
	                          SUM(retailbacktotal) AS retailbacktotal, SUM(cash) AS cash, SUM(noncash) AS noncash
	                   FROM   #instt
	                   GROUP BY plan_id, y_id
	               ) t
	        WHERE  reconciliationResult.plan_id = t.plan_id AND reconciliationResult.y_id = t.y_id AND t.y_id = @y_id AND isRemote = 0
	    END
	    ELSE
	    BEGIN
	        /*---插入明细*/
	        INSERT INTO reconciliationDetail
	          (plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag)
	        SELECT plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag
	        FROM   #instt
	        
	        
	        /*-----插入合计*/
	        
	        UPDATE reconciliationResult
	        SET    retailQty = t.retailqty, retailTotal = t.retailtotal, retailBackQty = t.retailBackQty,
	               retailBackTotal = t.retailbacktotal, cash = t.cash, nonCash = t.noncash
	        FROM   (
	                   SELECT plan_id, y_id, SUM(retailqty) AS retailqty, SUM(retailtotal) AS retailtotal, SUM(retailBackQty) AS retailBackQty,
	                          SUM(retailbacktotal) AS retailbacktotal, SUM(cash) AS cash, SUM(noncash) AS noncash
	                   FROM   #instt
	                   GROUP BY plan_id, y_id
	               ) t
	        WHERE  reconciliationResult.plan_id = t.plan_id AND reconciliationResult.y_id = t.y_id AND isRemote = 0
	    END
	    
	    IF (@y_id <> 2) AND (@nplan_id = 0) /*--机构上传数据后更新上传标志*/
	    BEGIN
	    	UPDATE reconciliationResult
	        SET    TransFlag = 1
	        WHERE  y_id = @y_id AND isRemote = 0
	               AND EXISTS(SELECT 1 FROM reconciliationPlan rp WHERE rp.plan_id = reconciliationResult.plan_id AND (rp.TransFlag = 3 OR rp.TransFlag = 0))
	        
	        UPDATE reconciliationDetail
	        SET    TransFlag = 1
	        WHERE  y_id = @y_id AND isRemote = 0
	               AND EXISTS(SELECT 1 FROM reconciliationPlan rp WHERE rp.plan_id = reconciliationDetail.plan_id AND (rp.TransFlag = 3 OR rp.TransFlag = 0))
	    END
	    
	    DROP TABLE #tmp
	    DROP TABLE #instt 
	    
	    /*-------------------创建对账计划，生成总部数据--------end-------------------*/
	END
	ELSE
	BEGIN
	    /*---------------重置对账明细-----begin------------------   */
	    IF EXISTS(SELECT 1 FROM reconciliationDetail WHERE isRemote = 0 AND TransFlag = 3 AND EXISTS(SELECT 1 FROM reconciliationPlan rp WHERE  rp.plan_id = reconciliationDetail.plan_id AND rp.TransFlag = 3))
	    BEGIN
	        /*----重置传输*/
	        UPDATE billidx
	        SET    transflag = 0
	        WHERE  EXISTS(SELECT 1 FROM reconciliationDetail rd
	                      WHERE rd.billdate = billidx.billdate AND rd.y_id = billidx.Y_ID AND billidx.transflag = 1
	                            AND billidx.billstates IN (1, 0) AND billidx.billtype IN (12, 13)
	                            AND isRemote = 0 AND rd.TransFlag = 3)
	        
	        /*-----重新统计明细*/
	        
	        SELECT plan_id, rd.y_id, rd.billdate,
	               ISNULL(mx.retailqty, 0) AS retailqty, ISNULL(mx.retailtotal, 0) AS retailtotal, ISNULL(mx.retailBackQty, 0) AS retailBackQty,
	               ISNULL(MX.retailbacktotal, 0) AS retailbacktotal, ISNULL(MX.cash, 0) AS cash, ISNULL(MX.noncash, 0) AS noncash,
	               ISNULL(jk.jkmoney, 0) AS payin, 1 AS isRemote, 0 AS TransFlag 
			INTO #instt1
	        FROM   reconciliationDetail rd
	               LEFT JOIN (
	                        SELECT i.billdate, i.Y_ID,
	                               SUM(CASE i.billtype WHEN 12 THEN b.quantity END) AS retailQty,
	                               SUM(CASE billtype WHEN 12 THEN ISNULL(b.taxtotal, 0) END) AS retailTotal,
	                               SUM(CASE billtype WHEN 13 THEN ISNULL(b.quantity, 0) END) AS retailBackQty,
	                               SUM(CASE billtype WHEN 13 THEN ISNULL(b.taxtotal, 0) END) AS retailBackTotal,
	                               SUM(CASE WHEN b.p_id = - 6 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id = - 6 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS cash,
	                               SUM(CASE WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS nonCash
	                        FROM   (
	                                   SELECT billdate, Y_ID, billtype, billid FROM dbo.billidx
	                                   WHERE  (billstates = '0') AND (billtype IN (12, 13))
	                               ) AS i
	                               INNER JOIN salemanagebill AS b
	                                    ON  i.billid = b.bill_id
	                        WHERE  (b.AOID IN (0, 5))
	                        GROUP BY i.billdate, i.Y_ID
	                    ) MX ON  MX.Y_ID = rd.y_id AND mx.billdate = rd.billdate
	               LEFT JOIN (
	                        /*------门店缴款金额*/
	                        SELECT Y_Id, jkdate, SUM(jkmoney) AS jkmoney
	                        FROM   jkdetail
	                        GROUP BY Y_Id, jkdate
	                    ) jk
	                    ON  jk.Y_Id = rd.y_id AND jk.jkdate = rd.billdate
	        WHERE  rd.isRemote = 0 AND rd.transflag = 3
	        
	        /*---插入明细*/
	        INSERT INTO reconciliationDetail
	          (plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal,
	           cash, nonCash, isRemote, TransFlag)
	        SELECT plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal,
	               cash, nonCash, 1, 0
	        FROM   #instt1 
	        /*-----插入合计*/
	        INSERT INTO reconciliationResult
	          (plan_id, y_id, retailQty, retailTotal, retailBackQty, retailBackTotal,
	           cash, nonCash, isRemote, payIn, transflag)
	        SELECT plan_id, y_id, SUM(retailqty) AS retailqty, SUM(retailtotal) AS retailtotal,
	               SUM(retailBackQty) AS retailBackQty, SUM(retailbacktotal) AS retailbacktotal, SUM(cash) AS cash,
	               SUM(noncash) AS noncash, 1 AS isRemote, SUM(payin) AS payIn, 0 AS transflag
	        FROM   #instt1
	        GROUP BY plan_id, y_id 
	        
	        DROP TABLE #instt1 
	        
	        /*-更新transflag ,防止重复插入   */
	        UPDATE reconciliationDetail
	        SET    TransFlag = 1
	        WHERE  isRemote = 0 AND transflag = 3
	               AND EXISTS(SELECT 1 FROM reconciliationPlan rp WHERE  rp.plan_id = reconciliationDetail.plan_id AND rp.TransFlag = 3)
	        
	        UPDATE reconciliationResult
	        SET    TransFlag = 1
	        WHERE  isRemote = 0 AND transflag = 3
	               AND EXISTS(SELECT 1 FROM reconciliationPlan rp WHERE rp.plan_id = reconciliationResult.plan_id AND rp.TransFlag = 3)
	        
	        UPDATE reconciliationPlan SET TransFlag = 1 WHERE TransFlag = 3
	    END
	    /*---------------重置对账明细-----end------------------ */
	    
	    /*---------------新生成门店明细----------begin------------  */
	    IF NOT EXISTS(SELECT 1 FROM reconciliationDetail WHERE isRemote = 0 AND TransFlag = 0)
	        RETURN 0
	    /*--------如果下传的计划存在已生成的门店明细则删除明细重新生成*/
	    DELETE reconciliationDetail
	    WHERE  EXISTS(SELECT 1 FROM reconciliationResult rr WHERE  reconciliationDetail.plan_id = rr.plan_id AND rr.isRemote = 0 AND rr.TransFlag = 0) AND isRemote = 1 
	    
	    /*------如果下传的计划存在已生成的门店合计则删除合计重新生成*/
	    DELETE reconciliationResult
	    WHERE  plan_id IN (SELECT plan_id FROM   reconciliationResult WHERE isRemote = 0 AND TransFlag = 0) AND isRemote = 1
	    
	    SELECT plan_id, rd.y_id, rd.billdate, ISNULL(MX.retailqty, 0) AS retailqty,
	           ISNULL(MX.retailtotal, 0) AS retailtotal, ISNULL(MX.retailBackQty, 0) AS retailBackQty, ISNULL(MX.retailbacktotal, 0) AS retailbacktotal,
	           ISNULL(MX.cash, 0) AS cash, ISNULL(MX.noncash, 0) AS noncash, ISNULL(jk.jkmoney, 0) AS payin, 1 AS isRemote, 0 AS TransFlag 
		INTO #instt2
	    FROM   reconciliationDetail rd
	           LEFT JOIN (
	                    SELECT i.billdate, i.Y_ID,
	                           SUM(CASE i.billtype WHEN 12 THEN b.quantity END) AS retailQty,
	                           SUM(CASE billtype WHEN 12 THEN ISNULL(b.taxtotal, 0) END) AS retailTotal,
	                           SUM(CASE billtype WHEN 13 THEN ISNULL(b.quantity, 0) END) AS retailBackQty,
	                           SUM(CASE billtype WHEN 13 THEN ISNULL(b.taxtotal, 0) END) AS retailBackTotal,
	                           SUM(CASE WHEN b.p_id = - 6 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id = - 6 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS cash,
	                           SUM(CASE WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 12 THEN ISNULL(b.total, 0) WHEN b.p_id <> - 6 AND b.p_id < 0 AND i.billtype = 13 THEN ISNULL(-b.total, 0) END) AS nonCash
	                    FROM   (
	                               SELECT billdate, Y_ID, billtype, billid FROM dbo.billidx WHERE  (billstates = '0') AND (billtype IN (12, 13))
	                           ) AS i
	                           INNER JOIN salemanagebill AS b ON  i.billid = b.bill_id
	                    WHERE  (b.AOID IN (0, 5))
	                    GROUP BY i.billdate, i.Y_ID
	                ) MX
	                ON  MX.Y_ID = rd.y_id AND mx.billdate = rd.billdate
	           LEFT JOIN (
	                    /*------门店缴款金额*/
	                    SELECT Y_Id, jkdate, SUM(jkmoney) AS jkmoney FROM jkdetail GROUP BY Y_Id, jkdate
	                ) jk
	                ON  jk.Y_Id = rd.y_id AND jk.jkdate = rd.billdate
	    WHERE  rd.isRemote = 0 AND rd.transflag = 0
	    
	    /*---插入明细*/
	    INSERT INTO reconciliationDetail
	      (plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, TransFlag)
	    SELECT plan_id, y_id, billDate, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, 1, 0
	    FROM   #instt2
	    /*-更新transflag ,防止重复插入*/
	    UPDATE reconciliationResult SET TransFlag = 1
	    WHERE  isRemote = 0
	           AND TransFlag = 0
	    
	    UPDATE reconciliationDetail SET TransFlag = 1 WHERE isRemote = 0 AND transflag = 0 
	    
	    
	    /*-----插入合计*/
	    INSERT INTO reconciliationResult
	      (plan_id, y_id, retailQty, retailTotal, retailBackQty, retailBackTotal, cash, nonCash, isRemote, payIn, transflag)
	    SELECT plan_id, y_id, SUM(retailqty) AS retailqty, SUM(retailtotal) AS retailtotal, SUM(retailBackQty) AS retailBackQty,
	           SUM(retailbacktotal) AS retailbacktotal, SUM(cash) AS cash, SUM(noncash) AS noncash, 1 AS isRemote, SUM(payin) AS payIn, 0 AS transflag
	    FROM   #instt2
	    GROUP BY plan_id, y_id
	    
	    DROP TABLE #instt2
	END
	/*---------------新生成门店明细----------end------------*/
END
GO
