

/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_l_repRetrun] 
	/* Add the parameters for the stored procedure here*/
	@c_id int, 
	@p_id int,
    @e_id int,
    @begindate datetime,
    @enddate DateTime,
    @RetMode int,
    @y_id    int
AS
BEGIN
declare @PClassID varchar(40), @CClassID varchar(40),@EClassID varchar(40)

if @C_id<>0 
   Select @CClassid=Class_id+'%' from clients where client_id=@C_id
else set @CClassid='%'

if @p_id<>0 
   Select @PClassid=class_id+'%' from products where product_id=@p_id
else set @PClassid='%'

if @E_id<>0 
   Select @EClassid=class_id+'%' from employees where emp_id=@e_id
else set @Eclassid='%'

if @RetMode=0 
	select r.*,p.name as pname,c.name as cname,isnull(d.saleqty,0) as AsaleQty,isnull(d.saletotal,0) saletotal,
           isnull(d.saleqty,0)*r.returnPrice+isnull(d.saletotal,0)*r.returnRate as fTotal,
           isnull(rt.rettotal,0) rettotal,
           (isnull(d.saleqty,0)*r.returnPrice+isnull(d.saletotal,0)*r.returnRate)-isnull(rt.rettotal,0) wftotal
	from returnstd r 
	     Left JOIN products p on r.p_id =p.product_id 
	     Left JOIN clients c on c.client_id=r.C_id
 	     left join (select abs(sum(pb.quantity)) Saleqty,abs(sum(total)) Saletotal,b.c_id
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        left join clients c1 on c1.client_id=b.c_id
                        left join Products P1 on P1.Product_id=pb.P_id
                        inner join employees e1 on b.e_id=e1.emp_id 
                        where (b.billdate between @begindate and @endDate)
                               and c1.Class_id like @CClassid and p1.Class_id like @PClassid
                               and b.billtype in (11,10) and pb.y_id=@y_id  
                        group by b.c_id) d on r.c_id=d.c_id
 	     left join (select sum(rb.rettotal) rettotal,b.c_id,b.y_id
                        from  returnbill rb 
                        inner join Billidx b on  rb.bill_id=b.billid
                        inner join clients c2 on c2.client_id=b.c_id
                        inner join employees e2 on b.e_id=e2.emp_id 
                        inner join (select r1.returnid,p3.Class_id,p3.Product_id 
                                    from returnstd r1 
                                    inner join products p3  on p3.product_id=r1.p_id ) p2  on p2.returnid=rb.Ret_id 
                       where (b.billdate between @begindate and @endDate)  and c2.Class_id like @CClassID 
                             and P2.Class_id like @PClassid and e2.Class_id like @eClassid and b.y_id=@y_id
                       group by b.c_id,b.y_id) rt on r.c_id=rt.c_id 
    where c.Class_id like @cClassid and p.Class_id like @pClassid and r.tag=@RetMode and r.y_id=@y_id
else
	select r.*,p.name as pname,c.name as cname,isnull(d.saleqty,0) as AsaleQty,isnull(d.saletotal,0) as saletotal,
           isnull(d.saleqty,0)*r.returnPrice+isnull(d.saletotal,0)*r.returnRate as fTotal,
           isnull(rt.rettotal,0) rettotal,
           (isnull(d.saleqty,0)*r.returnPrice+isnull(d.saletotal,0)*r.returnRate)-isnull(rt.rettotal,0) wftotal
	from returnstd r 
	     Left JOIN products p on r.p_id =p.product_id 
	     left JOIN clients c on c.client_id=r.C_id 
 	     left join (select abs(sum(pb.quantity)) Saleqty,abs(sum(total)) Saletotal,b.c_id
                        from  productdetail pb 
                        inner join Billidx b on  pb.billid=b.billid
                        inner join clients c1 on c1.client_id=b.c_id
                        inner join Products P1 on P1.Product_id=pb.P_id
                        inner join employees e1 on b.e_id=e1.emp_id 
                        where (b.billdate between @begindate and @endDate)
                               and c1.Class_id like @CClassid and p1.Class_id like @PClassid
                               and b.billtype in (20,21) and pb.y_id=@y_id 
                        group by b.c_id) d on r.c_id=d.c_id
 	     left join (select sum(rb.rettotal) rettotal,b.c_id,b.y_id
                        from  returnbill rb 
                        inner join Billidx b on  rb.bill_id=b.billid
                        inner join clients c2 on c2.client_id=b.c_id
                        inner join employees e2 on b.e_id=e2.emp_id 
                        inner join (select r1.returnid,p3.Class_id,p3.Product_id 
                                    from returnstd r1 
                                    inner join products p3  on p3.product_id=r1.p_id ) p2  on p2.returnid=rb.Ret_id 
                       where (b.billdate between @begindate and @endDate)  and c2.Class_id like @CClassID 
                             and P2.Class_id like @PClassid and e2.Class_id like @eClassid and b.y_id=@y_id
                       group by b.c_id,b.y_id) rt on r.c_id=rt.c_id
    where c.Class_id like @cClassid and p.Class_id like @pClassid and r.tag=@RetMode and r.y_id=@y_id
 
END
GO
