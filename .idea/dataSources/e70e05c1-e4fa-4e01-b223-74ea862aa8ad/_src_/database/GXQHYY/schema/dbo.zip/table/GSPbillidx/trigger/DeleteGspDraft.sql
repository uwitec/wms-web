




CREATE	 TRIGGER [DeleteGspDraft] ON [dbo].[Gspbillidx]
FOR DELETE
AS


  delete  GSPbilldetail from  GSPbilldetail a,deleted b where a.Gspbill_id = b.gspbillid
  
  delete billTrace from billTrace a,deleted b where a.billId = b.Gspbillid and a.billType =b.BillType
  
  delete GspTable from GspTable a,deleted b where a.BillId = b.Gspbillid and a.BillType=b.BillType
  
  delete gspdraft from gspdraft a,deleted b where a.bill_id=b.Gspbillid
GO
