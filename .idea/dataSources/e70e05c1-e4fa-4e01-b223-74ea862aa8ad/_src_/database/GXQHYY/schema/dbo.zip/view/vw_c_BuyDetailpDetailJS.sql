

CREATE  view dbo.vw_c_BuyDetailpDetailJS
as

SELECT pd.y_id as pdY_id,pd_id, billid, p_id, pd.s_id, quantity, price, total, costprice, quantity*costprice as costtotal, taxprice, taxtotal, 
      batchno, makedate, validdate, commissionflag, pd.supplier_id, location_id, storetype, 
      price_id, order_id, unitid, smb_id, pd.comment, jsprice, AOID,
	isnull(dbo.products.class_id,'') as class_id, 
	isnull(dbo.storages.class_id,'') as sclass_id, 
	isnull(dbo.storages.[name],'') as sname, 
	isnull(dbo.products.[name],'') as pname,products.makearea,products.standard,
	isnull(l.loc_name,'') as locname,
	isnull(cl.[name],'') as suppliername,
        isnull(e.class_id,'') as Reclass_id,
        isnull(e.[name],'') as Rename,
        ISNULL(f.AccountComment,'') as factory,
        isnull(pd.costtaxprice,0) as costtaxprice,isnull(pd.costtaxrate,0) as costtaxrate,isnull(pd.costtaxtotal,0) as costtaxtotal
from productdetail pd 
 left outer join
       storages on pd.s_id = storages.storage_id 
 left outer join
       products on pd.p_id = products.product_id
 left outer join
       location l on pd.location_id = l.loc_id
 left outer join
       clients cl on pd.supplier_id = cl.client_id
 left outer join
       employees e on pd.RowE_id=e.emp_id
 left outer join 
       basefactory f on pd.Factoryid=f.CommID
where pd.aoid in(0,5)

	
/*结算调价金额统计 2007-12-25*/
/* 16:销售结算调价; 17:  销售退货结算调价;*/
/* 24: 采购结算调价;  25:采购退货结算调价;*/
/* 43: 成本调价单*/
/* 103:发货调价单*/
/* 113:委托代销调价;*/
/* 123:受托代销调价; */
union all 

SELECT pdY_id,pd_id, billid, p_id, sm.s_id,
       case when billtype in (16,25)then -quantity else quantity end, 
      price, case when billtype in (16,25)then -total else total end,
      cast(costprice as numeric(25,8))as costprice, case when billtype in (16,25)then -costtotal else costtotal end,
      cast(taxprice as numeric(25,8))as taxprice, case when billtype in (16,25)then -taxtotal else taxTotal end, 
      batchno, makedate, validdate,commissionflag, sm.supplier_id, location_id, storetype, 
      price_id, order_id, unitid, smb_id, sm.comment, jsprice, AOID,
	isnull(dbo.products.class_id,'') as class_id, 
	isnull(dbo.storages.class_id,'') as sclass_id, 
	isnull(dbo.storages.[name],'') as sname, 
	isnull(dbo.products.[name],'') as pname,products.makearea,products.standard,
	isnull(l.loc_name,'') as locname,
	isnull(cl.[name],'') as suppliername,
        isnull(e.class_id,'') as Reclass_id,
        isnull(e.[name],'') as Rename,
        ISNULL(f.AccountComment,'') as factory,
        isnull(sm.costtaxprice,0) as costtaxprice,isnull(sm.costtaxrate,0) as costtaxrate,case when billtype in (16,25)then -costtaxtotal else costtaxtotal end
from (
         select sm.y_id as pdY_id,sm.smb_id as pd_id,Sm.p_id,sm.ss_id as s_id,sm.quantity,cast(sm.SalePrice as numeric(25,8)) as price,
             sm.total,sm.costprice,sm.taxprice,sm.taxtotal,sm.batchno,sm.makedate,sm.validdate,
             sm.commissionflag, sm.supplier_id, sm.location_id, sm.price_id, sm.order_id, sm.unitid, sm.smb_id,
             sm.comment, sm.jsprice, sm.AOID,sm.RowE_id,
             bi.billType,bi.BillID,sm.factoryid,
             CAST((costPrice*Sm.Quantity) as numeric(25,8)) as costTotal,  0 as storeType,
             sm.costtaxprice,sm.costtaxrate,sm.costtaxtotal
      from SaleManageBill sm,BillIdx bi 
      where sm.Bill_id=bi.BillID and billType in(16,17)
      union all
      select bm.y_id as pdY_id,bm.smb_id as pd_id,bm.p_id,bm.ss_id as s_id,bm.quantity,cast(bm.buyPrice as numeric(25,8)) as price,
             bm.total,bm.costprice,bm.taxprice,bm.taxtotal,bm.batchno,bm.makedate,bm.validdate,
             bm.commissionflag, bm.supplier_id, bm.location_id, bm.price_id, bm.order_id, bm.unitid, bm.smb_id,
             bm.comment, bm.jsprice, bm.AOID,bm.RowE_id,
             bi.billType,bi.BillID,bm.factoryid,
             CAST((costPrice*bm.Quantity) as numeric(25,8)) as costTotal,  0 as storeType,
             bm.costtaxprice,bm.costtaxrate,bm.costtaxtotal
      from BuyManageBill bm,BillIdx bi 
      where Bm.Bill_id=bi.BillID and billType in(24,25)
      ) sm 
 left outer join
       storages on sm.s_id = storages.storage_id 
 left outer join
       products on sm.p_id = products.product_id
 left outer join
       location l on sm.location_id = l.loc_id
 left outer join
       clients cl on sm.supplier_id = cl.client_id
 left outer join
       employees e on sm.RowE_id=e.emp_id
 left outer join 
       basefactory f on sm.factoryid=f.CommID

where sm.aoid in(0,5)
GO
