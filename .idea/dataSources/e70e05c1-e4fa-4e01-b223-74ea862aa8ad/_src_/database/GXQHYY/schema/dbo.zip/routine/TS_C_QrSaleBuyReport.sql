

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/

/******************************************
进货日报、月报、任意时间段报表	nMode=0
销售日报、月报、任意时间段报表	nMode=1
配送日报、月报、任意时间段报表	nMode=2
往来单位进货日报、月报、任意时间段报表	nMode=3
往来单位销售日报、月报、任意时间段报表	nMode=4
往来单位进货退货日报、月报、任意时间段报表	nMode=5
往来单位销售退货日报、月报、任意时间段报表	nMode=6
机构发货任意时间段报表            nMode=7
机构收货任意时间段报表            nMode=8

修改：2010-11-13 
     向销售报表增加零售价字段
     lxt
********************************************/

CREATE  PROCEDURE TS_C_QrSaleBuyReport
(	@BeginDate    DATETIME=0,
	@EndDate		  DATETIME=0,
	@nMode  		  INT=0,
	@szCClass_ID	VARCHAR(30)='000000',
	@szEClass_ID	VARCHAR(30)='000000',
	@szSClass_ID	VARCHAR(30)='000000',
	@szParid   		VARCHAR(30)='000000',
	@szListFlag 	VARCHAR(1)='L',
	@szZdClass_ID	VARCHAR(30)='000000',
    @nYClassid      varchar(100)='',
    @nloginEID      int=0,
    @isaddDate      int=0,
    @strBusinessType varchar(50) = '0', 
    @isBuyBack      int = 0,
    @nbilltype      varchar(200)
)

/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @nMode is null  SET @nMode = 0
if @szCClass_ID is null  SET @szCClass_ID = '000000'
if @szEClass_ID is null  SET @szEClass_ID = '000000'
if @szSClass_ID is null  SET @szSClass_ID = '000000'
if @szParid is null  SET @szParid = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @szZdClass_ID is null  SET @szZdClass_ID = '000000'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
if @strBusinessType is null set @strBusinessType ='0'
if @isBuyBack is null set @isBuyBack=0
/*Params Ini end*/
 /* SET NOCOUNT ON*/
  DECLARE @SQLScript VARCHAR(8000), @TableName VARCHAR(300),@szY_id int
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  
  declare @billtype varchar(8000)   
  set @strBusinessType = @strBusinessType+',5'
  if @nMode in(0,3)
  begin
    if @isBuyBack = 0 
    begin
      set @billtype = '20,24,35,220'
    end else set  @billtype ='20,21,24,25,35,220,221'   
  end
  
  IF @szCClass_ID='' SET @szCClass_ID='%%'

  IF @szEClass_ID='' SET @szEClass_ID='%%'

  IF @szZdClass_ID='' SET @szZdClass_ID='%%'
   
  IF @szSClass_ID='' SET @szSClass_ID='%%'
 
  IF @nYClassid =''
  begin
    SET @nYClassid='%%'
    Set @szY_id=2 
  end
  ELSE
  begin
    select @szY_id=company_id from company  where class_id= @nYClassid 
    SET @nYClassid=@nYClassid+'%'
  end
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

  IF @nMode=1 
/*销售出库单,销售出库退货,零售,零售退货,委托代销结算，借转销售,销售单,销售退货*/
  BEGIN
	SELECT a.class_id,a.quantity,a.taxtotal,a.retailtotal,a.Saletotal,a.Costtotal,a.costtaxprice,
		   a.costtaxtotal,a.Sendtotal,a.SendQTY,a.SendCostTotal,
		   a.RowE_id,a.c_id,a.Y_id,a.s_id as s_id into #TempProductSale from
		   (
				SELECT a.[class_id] as class_id,
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.totalmoney   else -a.totalmoney end), 0) AS [Saletotal],
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN (a.[quantity]*a.[costprice])   else -(a.[quantity]*a.[costprice]) end), 0) AS [Costtotal],		
				(ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.costtaxtotal  else -a.costtaxtotal end), 0))/nullif(ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210) THEN a.[quantity]  else -a.[quantity] end), 0),0) as costtaxprice,	      
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.costtaxtotal  else -a.costtaxtotal end), 0) AS costtaxtotal,
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN (a.totalmoney/a.quantity*a.[SendQTY]) else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0)  AS [Sendtotal],
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.[SendQTY]  else -a.SendQTY end), 0) AS [SendQTY],
				ISNULL(SUM(CASE WHEN a.[billtype] IN (10,12,32,112,53,16,210,150,152) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
				a.RowE_id,a.c_id,a.Y_id,a.ss_id as s_id
			   FROM 
				   (
					  select sm.[quantity],sm.[taxtotal],sm.[retailtotal],sm.[totalmoney],sm.costtaxprice,sm.costtaxtotal,
							 sm.[costprice],sm.[smb_id],sm.[SendQTY],sm.[sendCostTotal],sm.[RowE_id],sm.[ss_id],sm.[bill_id],
							 sm.[p_id],b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],b.inputman,isnull(p.class_id,'') as class_id 
					  FROM salemanagebill sm  inner join  billidx b   on sm.bill_id=b.billid
						 Left join products p   on sm.p_id      =p.product_id
						 left join clients   c  on c.client_id  =b.c_id
						 left join employees RE on RE.emp_id    =sm.RowE_id
						 left join employees IE on IE.emp_id    =b.inputman 
						 left join company   Y  on Y.company_id =b.Y_id  
						 LEFT JOIN STORAGES  S  ON S.STORAGE_ID =sm.ss_id    
					  Where b.[billdate] between @BeginDate AND @EndDate 
					       AND sm.p_id >0 and b.billtype in (select szTYPE from DecodeToStr(@nbilltype))   
						   and sm.AOID in (select szTYPE from DecodeToStr(@strBusinessType))  
						   AND b.[billstates]='0' 
  						   AND c.class_id  LIKE @szCClass_ID
  						   AND isnull(re.class_id,'') LIKE @szEClass_ID
  						   AND ie.class_id LIKE @szZdClass_ID
 						   AND s.class_id  like @szSClass_ID
						   AND y.class_id  like @nYClassID   
					) a 
				GROUP BY a.[class_id],a.RowE_id,a.c_id,a.Y_id,a.ss_id
	      )a 
		  where  ((@Companytable=0) or (a.Y_id in (select [id] from #Companytable)))
				 AND ((@ClientTable=0) or (a.c_id in (select [id]  from #Clienttable)))
				 AND ((@Storetable=0) or  (a.s_id in (select [id]  from #storagestable)))
				 AND ((@employeestable=0) OR (a.RowE_id in (select [id]  from #employeestable))) 
  END 
  ELSE IF @nMode=0
  BEGIN
/*采购,采购入库退货，采购结算调价，采购退货结算调价，借转采购，采购单，采购退货*/
 SELECT a.*  into #TempProductBuy from

       (SELECT p.[class_id] as class_id,
	           ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.totalmoney  else -a.totalmoney end), 0) AS [Saletotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[costprice]*a.[quantity]  else -(a.[costprice]*a.[quantity]) end), 0) AS [costtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.costtaxtotal else -a.costtaxtotal end), 0) AS [costtaxtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.totalmoney/a.quantity*a.[SendQTY] else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
  	           ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
	           ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[SendQTY] else -a.[SendQTY] end), 0) AS [SendQTY],
               a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select bm.[quantity],bm.[taxtotal],bm.[retailtotal],bm.[totalmoney],bm.[costprice],bm.[SendQTY],bm.[SendCostTotal],bm.costtaxtotal,
                    bm.[RowE_id],bm.[ss_id],bm.[p_id],bm.[bill_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID  FROM buymanagebill bm 
			 left join employees RE on RE.emp_id=bm.RowE_id
			 LEFT JOIN STORAGES  S  ON S.STORAGE_ID=bM.SS_ID
             Where bm.p_id >0 and AOID in (select szTYPE from DecodeToStr(@strBusinessType))             
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
             from billidx b    
             left join company   Y  on Y.company_id =b.Y_id         
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             /*Wsj-2016-11-11-tfs42602 BB.规范采购报表字段*/
             where b.[billtype] IN (select szTYPE from DecodeToStr(@billtype)) AND b.[billstates]='0' 
             /*xzdong-2016-11-10-TFS42599-采购报表（选定时间段）字段调整*/
             /*where b.[billtype] IN (20,35,122,24,220) AND b.[billstates]='0' */
            )b 
             ON b.[billid]=a.[bill_id]
	     Left join products p on a.p_id=p.product_id
             WHERE a.[P_id]>0  AND b.[billdate] between @BeginDate AND @EndDate
				  
  	        AND b.[cclass_id] LIKE @szCClass_ID
  	        AND a.[Reclass_id] LIKE @szEClass_ID
  	        AND b.[IEclass_id] LIKE @szZdClass_ID
 	        AND a.[ssclass_id] like @szSClass_ID
            AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY p.[class_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
                where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
                   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))
                   AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
END 
  ELSE IF @nMode=2
  BEGIN
/*配送出库,配送退货*/
    SELECT * INTO #TempProductTran FROM
      (SELECT a.[Pclass_id] as Class_id,
		    ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[quantity] else -a.[quantity] end), 0) AS [quantity], 
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[costprice]*a.[quantity] else -(a.[costprice]*a.[quantity]) end), 0) AS [costtotal],
	        0.0 AS [costtaxtotal],		
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[taxtotal] else -a.taxtotal end), 0) AS [taxtotal],
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[retailtotal] else -a.retailtotal end), 0) AS [retailtotal],
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.totalmoney else -a.totalmoney end), 0) AS [Saletotal],
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.totalmoney/a.quantity*a.[SendQTY] else -a.totalmoney/a.quantity*a.[SendQTY] end), 0) AS [Sendtotal],
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[SendQTY] else -a.SendQTY end), 0) AS [SendQTY],
			ISNULL(SUM(CASE WHEN b.[billtype] IN (53) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal]

       FROM VW_C_TranMB a 
       INNER JOIN (select b.[billtype],b.[billdate],b.[billstates],b.[cclass_id],b.[inputmanclass_id],b.[billid] from VW_C_BillIDX b where (@ClientTable=0 or ((b.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and b.cclass_id like u.psc_id+'%')))))b ON b.[billid]=a.[bill_id]
			WHERE a.[p_id]>1 AND b.[billdate] between @BeginDate AND @EndDate
			    AND b.[billtype] IN (53,54) AND b.[billstates]='0'
				AND b.[cclass_id] LIKE @szCClass_ID
				AND a.[Reclass_id] LIKE @szEClass_ID
				AND a.[ssclass_id] LIKE @szSClass_ID
				AND b.[inputmanclass_id] LIKE @szZdClass_ID
				AND (@employeestable=0 OR ((a.Reclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and a.Reclass_id like  u.psc_id+'%'))))
				AND (@Storetable=0 OR ((a.ssclass_id='') or (exists (select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S'and a.ssclass_id like u.psc_id+'%'))))

      GROUP BY a.[Pclass_id]) T
  END 
  IF @nMode=4
/*往来单位销售出库单,销售出库退货,零售,零售退货,委托代销结算,销售单，销售退货单*/
  BEGIN
  SELECT a.*  into #TempClientSale from
       (SELECT b.[cclass_id] as class_id,
        ISNULL(COUNT(DISTINCT b.[billid]), 0) AS [VchCount],      
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
		ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
        (ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.costtaxtotal  else -a.costtaxtotal end), 0))/nullif(ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[quantity]  else -a.[quantity] end), 0),0) as costtaxprice,	      
		ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.costtaxtotal  else -a.costtaxtotal end), 0) AS costtaxtotal,
	    /*0.0 AS [costtaxtotal],	*/
		ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
		ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.totalmoney   else -a.totalmoney end), 0) AS [Saletotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN (a.[quantity]*a.[costprice])   else -(a.[quantity]*a.[costprice]) end), 0) AS [Costtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN (a.totalmoney/a.quantity*a.[SendQTY])  else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[SendQTY]  else -a.SendQTY end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,32,112,53,16,210) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select sm.[quantity],sm.[taxtotal],sm.[retailtotal],sm.[totalmoney],sm.costtaxtotal,sm.[costprice],sm.[smb_id],sm.[SendQTY],sm.[sendCostTotal],
                    sm.[RowE_id],sm.[ss_id],sm.[bill_id],sm.[p_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM FilterSalemanagebill(@nloginEID) sm 
             left join employees RE on RE.emp_id   =sm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=SM.SS_ID
             LEFT join Products  P  on P.product_id=SM.p_id
             Where sm.p_id >0 and sm.aoid in (select szTYPE from DecodeToStr(@strBusinessType)) and p.[class_id] LIKE @szCClass_ID            
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b  
             left join company   Y  on Y.company_id =b.Y_id           
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             where  /*b.[billtype] IN (10,11,12,13,32,112,53,54,16,17,210,211) */
             b.billtype in (select szTYPE from DecodeToStr(@nbilltype))
             and b.[billdate] between @BeginDate AND @EndDate and b.c_id>1  AND b.[billstates]='0' 
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				AND b.[cclass_id] LIKE @szCClass_ID
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY b.[cclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
                where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
                   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))
                   AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  END 
  ELSE IF @nMode=3
  BEGIN
/*往来单位进货入库，进货入库退货，收货单，退货单*/
   SELECT a.*  into #TempClientBuy from

       (SELECT b.[cclass_id] as class_id,
        ISNULL(COUNT(DISTINCT b.[billid]), 0) AS [VchCount],      
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
	    ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
    	ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
    	ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,220)    THEN a.taxtotal  WHEN b.[billtype] IN (21,221) THEN -a.taxtotal else 0 end), 0) AS [Saletotal],    /*采购金额(统计退货但不统计结算调价)*/
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN (a.[quantity]*a.[costprice])   else -(a.[quantity]*a.[costprice]) end), 0) AS [Costtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.taxtotal  else -a.taxtotal end), 0) AS costtaxtotal, /*成本含税金额(包含退货和结算调价)*/
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN (a.totalmoney/a.quantity*a.[SendQTY])  else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[SendQTY]  else -a.SendQTY end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,24,220) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id
                     
       FROM 
            (select bm.[quantity],bm.costtaxtotal,bm.[taxtotal],bm.[retailtotal],bm.[totalmoney],bm.[costprice],bm.[SendQTY],bm.[SendCostTotal],
                    bm.[RowE_id],bm.[ss_id],bm.[p_id],bm.[bill_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM buymanagebill bm 
             left join employees RE on RE.emp_id   =bm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=bM.SS_ID
             LEFT join Products  P  on P.product_id=bM.p_id
             Where bm.p_id >0 /*and bm.aoid in (0,5)  modify by luowei 2011-12-08 : 往来单位进货查询统计赠品数量*/
             and AOID in (select szTYPE from DecodeToStr(@strBusinessType)) /*Wsj-2016-11-14 tfs 增加查询条件是否包含赠品数量  */
             and p.[class_id] LIKE @szCClass_ID            
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b      
             left join company   Y  on Y.company_id =b.Y_id       
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             where b.[billtype] IN (select szTYPE from DecodeToStr(@billtype)) and  b.[billdate] between @BeginDate AND @EndDate and b.c_id>1  AND b.[billstates]='0'  
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				/*AND b.[cclass_id] LIKE @szCClass_ID   modify by luowei 2011-12-08 : 往来单位查询中不可选择往来单位，且@szCClass_ID 为商品CLASS_id*/
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY b.[cclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
			where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
			   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
			   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))
			   AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  END 
  IF @nMode=6
/*往来单位销售出库退货,零售退货，销售退货*/
  BEGIN
   SELECT a.*  into #TempClientSaleBack from

       (SELECT b.[cclass_id] as class_id,
        ISNULL(COUNT(DISTINCT b.[billid]), 0) AS [VchCount],      
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[quantity] else a.[quantity] end), 0) AS [quantity], 
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[costprice]*a.[quantity] else (a.[costprice]*a.[quantity]) end), 0) AS [costtotal],
        0.0 AS [costtaxtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[taxtotal] else a.taxtotal end), 0) AS [taxtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.totalmoney else a.totalmoney end), 0) AS [saletotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[retailtotal] else a.retailtotal end), 0) AS [retailtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[SendQTY] else a.SendQTY end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.totalmoney/a.quantity*a.[SendQTY] else  a.totalmoney/a.quantity*a.[SendQTY] end), 0) AS [SendTotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (10,12,112,53,16) THEN -a.[SendCostTotal] else a.SendCostTotal end), 0) AS [SendCostTotal],

        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select sm.[quantity],sm.[taxtotal],sm.[retailtotal],sm.[totalmoney],sm.[costprice],sm.[smb_id],sm.[SendQTY],sm.[sendCostTotal],
                    sm.[RowE_id],sm.[ss_id],sm.[bill_id],sm.[p_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM FilterSalemanagebill(@nloginEID) sm 
             left join employees RE on RE.emp_id   =sm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=SM.SS_ID
             LEFT join Products  P  on P.product_id=SM.p_id
             Where sm.p_id >0 and sm.aoid in (0,5) and p.[class_id] LIKE @szCClass_ID            
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b             
             left join company   Y  on Y.company_id =b.Y_id
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman 
             where   b.[billtype] IN (11,13,54,17,211) and b.[billdate] between @BeginDate AND @EndDate
               and b.c_id>1
               AND b.[billstates]='0'
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				AND b.[cclass_id] LIKE @szCClass_ID
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY b.[cclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
        where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
           AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
           AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))
           AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  END 
  ELSE IF @nMode=5
  BEGIN
/*往来单位进货入库退货,采购退货*/
      SELECT a.*  into #TempClientBuyBack  from

       (SELECT b.[cclass_id] as class_id,
        ISNULL(COUNT(DISTINCT b.[billid]), 0) AS [VchCount],   
        ISNULL(SUM(a.[quantity]), 0) AS [quantity], 
		ISNULL(sum(a.[costprice]*a.[quantity]), 0) AS [costtotal],
		0.0 AS [costtaxtotal],
		ISNULL(SUM(a.taxtotal), 0) AS [taxtotal],
		ISNULL(SUM(a.retailtotal), 0) AS [retailtotal],
		ISNULL(SUM(a.totalmoney), 0) AS [saletotal],
		ISNULL(SUM(a.totalmoney/a.quantity*a.[SendQTY]), 0) AS [Sendtotal],
        ISNULL(SUM(a.[SendQTY]), 0) AS [SendQTY],
        ISNULL(SUM(a.[SendCostTotal]), 0) AS [SendCostTotal],

        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select bm.[quantity],bm.[taxtotal],bm.[retailtotal],bm.[totalmoney],bm.[costprice],bm.[SendQTY],bm.[SendCostTotal],
                    bm.[RowE_id],bm.[ss_id],bm.[p_id],bm.[bill_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM buymanagebill bm 
             left join employees RE on RE.emp_id   =bm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=bm.SS_ID
             LEFT join Products  P  on P.product_id=bm.p_id
             Where bm.p_id >0 and bm.aoid in (select szTYPE from DecodeToStr(@strBusinessType)) and p.[class_id] LIKE @szCClass_ID            
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b      
             left join company   Y  on Y.company_id =b.Y_id       
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             where b.[billtype] IN (21,25,221) and b.[billdate] between @BeginDate 
              AND @EndDate and b.c_id>1  AND b.[billstates]='0' 
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				AND b.[cclass_id] LIKE @szCClass_ID
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY b.[cclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
        where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
           AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
           AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))
           AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  END IF @nMode=7
  BEGIN/*机构发货统计报表（任意时间段）*/
     SELECT a.*  into #TempCompanySendAndDate from

       (SELECT a.[pclass_id] as class_id,
        ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
		ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
		ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
		ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.totalmoney   else -a.totalmoney end), 0) AS [Saletotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN (a.[quantity]*a.[costprice])   else -(a.[quantity]*a.[costprice]) end), 0) AS [Costtotal],
        0.0 AS [costtaxtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN (a.totalmoney/a.quantity*a.[SendQTY])  else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.[SendQTY]  else -a.SendQTY end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (150) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select sm.[quantity],sm.[taxtotal],sm.[retailtotal],sm.[totalmoney],sm.[costprice],sm.[smb_id],sm.[SendQTY],sm.[sendCostTotal],
                    sm.[RowE_id],sm.[ss_id],sm.[bill_id],sm.[p_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM FilterSalemanagebill(@nloginEID) sm 
             left join employees RE on RE.emp_id   =sm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=SM.SS_ID
             LEFT join Products  P  on P.product_id=SM.p_id
             Where sm.p_id >0 and sm.aoid in (0,5)             
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(y1.class_id,'') as Yclass_id,isnull(y.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b   
             left join company   Y  on Y.company_id =b.c_id
             left join company   y1 on y1.company_id = b.Y_ID          
             /*left join clients   c  on c.client_id  =b.c_id*/
             left join employees IE on IE.emp_id    =b.inputman             
             where  b.[billtype] IN (150,151)and b.[billdate] between @BeginDate AND @EndDate 
               and b.c_id>1 AND b.[billstates]='0' 
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				AND b.[cclass_id] LIKE @szCClass_ID
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY a.[pclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
                where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
                   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))    
                   AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
  END  IF @nMode=8
  BEGIN/*机构收货统计报表（任意时间段）*/
       SELECT a.*  into #TempCompanyReceiveAndDate from
       (SELECT a.[Pclass_id] as Class_id,
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.totalmoney  else -a.totalmoney end), 0) AS [Saletotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[costprice]*a.[quantity]  else -(a.[costprice]*a.[quantity]) end), 0) AS [costtotal],
       0.0 AS [costtaxtotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.totalmoney/a.quantity*a.[SendQTY] else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
       ISNULL(SUM(CASE WHEN b.[billtype] IN (160) THEN a.[SendQTY] else -a.[SendQTY] end), 0) AS [SendQTY],

               a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select bm.[quantity],bm.[taxtotal],bm.[retailtotal],bm.[totalmoney],bm.[costprice],bm.[SendQTY],bm.[SendCostTotal],
                    bm.[RowE_id],bm.[ss_id],bm.[p_id],bm.[bill_id],ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM buymanagebill bm 
             left join employees RE on RE.emp_id   =bm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=bM.SS_ID
             LEFT join Products  P  on P.product_id=bM.p_id
             Where bm.p_id >0 and bm.aoid in (0,5)             
            ) a 
	     Inner JOIN                                    
	     (select b.[billdate],b.[billtype],b.[billid],b.[c_id],b.[Y_ID],isnull(Y.class_id,'') as Yclass_id,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id
              from billidx b   
             left join company   Y  on Y.company_id =b.Y_id          
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman    
             where  b.[billtype] IN (160,161) and b.[billdate] between @BeginDate AND @EndDate  
             and b.c_id>1 AND b.[billstates]='0'
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  				AND b.[cclass_id] LIKE @szCClass_ID
  				AND a.[Reclass_id] LIKE @szEClass_ID
  				AND b.[IEclass_id] LIKE @szZdClass_ID
 				AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY a.[pclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
        where  (((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
           AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
           AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))  
           AND (@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))

   END IF @nMode=9
  BEGIN/*自营店发货统计报表（任意时间段）*/
     SELECT a.*  into #TempCompanySelfSendAndDate from

       (SELECT a.[pclass_id] as class_id,
       /*
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
	ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
	ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
	ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.totalmoney   else -a.totalmoney end), 0) AS [Saletotal],

        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN (a.[quantity]*a.[costprice])   else -(a.[quantity]*a.[costprice]) end), 0) AS [Costtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN (a.totalmoney/a.quantity*a.[SendQTY])  else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[SendQTY]  else -a.SendQTY end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
        */
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[quantity]  
                        WHEN b.[billtype] IN (153) THEN -a.[quantity]
                        else 0 end), 0) AS [quantity], 
	    ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[taxtotal]  
	                    when b.[billtype] IN (153) THEN -a.[taxtotal] 
	                    else 0 end), 0) AS [taxtotal],
	    ISNULL(SUM(CASE WHEN b.[billtype] IN (12) THEN a.totalmoney   
	                WHEN b.[billtype] IN (13) THEN -a.totalmoney  
	                else 0 end), 0) AS [retailtotal],	         
 	    ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.totalmoney   
	                    WHEN b.[billtype] IN (153) THEN -a.totalmoney  
	                    else 0 end), 0) AS [Saletotal],	 
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN (a.[quantity]*a.[costprice])   
                        WHEN b.[billtype] IN (153) THEN -(a.[quantity]*a.[costprice])
                        else 0 end), 0) AS [Costtotal],
                        0.0 AS [costtaxtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN (a.totalmoney/a.quantity*a.[SendQTY])  
                        WHEN b.[billtype] IN (152) THEN  -(a.totalmoney/a.quantity*a.[SendQTY])
                        else 0 end), 0) AS [Sendtotal],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[SendQTY]  
                        WHEN b.[billtype] IN (152) THEN -a.SendQTY
                        else 0 end), 0) AS [SendQTY],
        ISNULL(SUM(CASE WHEN b.[billtype] IN (152) THEN a.[SendCostTotal] 
                        WHEN b.[billtype] IN (152) THEN -a.[SendCostTotal]  
                        else 0 end), 0) AS [SendCostTotal],	                            
        a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select sm.*,ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM FilterSalemanagebill(@nloginEID) sm 
             left join employees RE on RE.emp_id   =sm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=SM.SS_ID
             LEFT join Products  P  on P.product_id=SM.p_id
             Where sm.p_id >0 and sm.aoid in (0,5)             
            ) a 
	     Inner JOIN                                    
	     (select b.*,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id,isnull(Y.class_id,'') as Yclass_id
              from billidx b             
             left join company   c  on c.company_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             left join company   Y  on Y.company_id =b.Y_id
             where b.c_id>1 and b.[billtype] IN (12,13,152,153) AND b.[billstates]='0' 
             and b.[billdate] between @BeginDate AND @EndDate
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  	        AND b.[cclass_id] LIKE @szCClass_ID
  	        AND a.[Reclass_id] LIKE @szEClass_ID
  	        AND b.[IEclass_id] LIKE @szZdClass_ID
 	        AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY a.[pclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
                where  ((@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
                   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                   AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
                   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))    
  END  IF @nMode=10
  BEGIN/*自营店收货统计报表（任意时间段）*/
         SELECT a.*  into #TempCompanySelfReceiveAndDate from
       (SELECT a.[Pclass_id] as Class_id,
	       ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[quantity]  else -a.[quantity] end), 0) AS [quantity], 
               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[taxtotal]  else -a.taxtotal end), 0) AS [taxtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[retailtotal]  else -a.retailtotal end), 0) AS [retailtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.totalmoney  else -a.totalmoney end), 0) AS [Saletotal],

               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[costprice]*a.[quantity]  else -(a.[costprice]*a.[quantity]) end), 0) AS [costtotal],
               0.0 AS [costtaxtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.totalmoney/a.quantity*a.[SendQTY] else -(a.totalmoney/a.quantity*a.[SendQTY]) end), 0) AS [Sendtotal],
               ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[SendCostTotal] else -a.SendCostTotal end), 0) AS [SendCostTotal],
	           ISNULL(SUM(CASE WHEN b.[billtype] IN (162) THEN a.[SendQTY] else -a.[SendQTY] end), 0) AS [SendQTY],

               a.RowE_id,b.c_id,b.Y_id,a.ss_id as s_id

       FROM 
            (select bm.*,ISNULL(RE.CLASS_ID,'') AS RECLASS_ID,ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.class_id,'') as PClass_id  FROM buymanagebill bm 
             left join employees RE on RE.emp_id   =bm.RowE_id
             LEFT JOIN STORAGES  S  ON S.STORAGE_ID=bM.SS_ID
             LEFT join Products  P  on P.product_id=bM.p_id
             Where bm.p_id >0 and bm.aoid in (0,5)             
            ) a 
	     Inner JOIN                                    
	     (select b.*,isnull(c.class_id,'') as cclass_id,isnull(IE.class_id,'') as IEclass_id,isnull(Y.class_id,'') as Yclass_id
              from billidx b             
             left join clients   c  on c.client_id  =b.c_id
             left join employees IE on IE.emp_id    =b.inputman
             left join company   Y  on Y.company_id =b.Y_id
             where b.c_id>1 and b.[billtype] IN (162,163) AND b.[billstates]='0' 
             and b.[billdate] between @BeginDate AND @EndDate
            )b                      
             ON b.[billid]=a.[bill_id]
             WHERE a.[P_id]>0 				  
  	        AND b.[cclass_id] LIKE @szCClass_ID
  	        AND a.[Reclass_id] LIKE @szEClass_ID
  	        AND b.[IEclass_id] LIKE @szZdClass_ID
 	        AND a.[ssclass_id] like @szSClass_ID
                AND b.[Yclass_ID]  like @nYClassID 
       GROUP BY a.[pclass_id],a.RowE_id,b.c_id,b.Y_id,a.ss_id
)a
                where  ((@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
                   AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                   AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
                   AND ((@Storetable=0) or (a.s_id in (select [id] from #storagestable)))  

  END

  IF @nMode=0 SET @TableName='#TempProductBuy b  '
  IF @nMode=1 SET @TableName='( select retailprice,p_id from price where unittype=1 )pr on a.product_id=pr.p_id  Left join #TempProductSale b  '
  IF @nMode=2 SET @TableName='#TempProductTran b  '
  IF @nMode=3 SET @TableName='#TempClientBuy b  '
  IF @nMode=4 SET @TableName='#TempClientSale b  ' 
  IF @nMode=5 SET @TableName='#TempClientBuyBack b  '
  IF @nMode=6 SET @TableName='#TempClientSaleBack b  '
  IF @nMode=7 SET @TableName='#TempCompanySendAndDate b  '
  IF @nMode=8 SET @TableName='#TempCompanyReceiveAndDate b  '
  IF @nMode=9 SET @TableName='#TempCompanySelfSendAndDate b  '
  IF @nMode=10 SET @TableName='#TempCompanySelfReceiveAndDate b  '


  IF @szListFlag='L'  SET @SQLScript=' ON LEFT(isnull(b.[class_id],''''), LEN(isnull(a.[class_id],'''')))=isnull(a.[class_id],'''')  
    WHERE a.[parent_id]='+CHAR(39)+@szParid+CHAR(39)+' AND a.[deleted]<>1 '
  IF @szListFlag='A' 	SET @SQLScript='ON b.[class_id]=a.[class_id]			
    WHERE  a.[child_number]=0 AND a.[deleted]<>1 AND a.[class_id]<>''000000'''
  IF @szListFlag='P' 	SET @SQLScript=' ON b.[class_id]=a.[class_id]
	WHERE LEFT(a.[class_id], LEN('+CHAR(39)+@szParid+CHAR(39)+'))='+CHAR(39)+@szParid+CHAR(39)
      +' AND a.[child_number]=0 AND a.[deleted]<>1'
  IF @nMode IN (0, 1, 2,7,8,9,10) GOTO GetProduct  
  ELSE GOTO GetClient 

GetProduct:
   SELECT @SQLScript='SELECT a.[product_id],a.[class_id],a.[child_number],a.[name],a.[code],a.[alias],
        a.[standard],a.[modal],a.[Factory] as makearea,a.[rate2],a.[rate3],a.[rate4],a.[unitname1],a.[medtype],
        a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.permitcode,
        Isnull(Max(vp.[e_name]),'''')e_name,Isnull(Max(vp.[C_Name]),'''')C_Name,
        '+ CASE @nMode when 1 then 'ISNULL(pr.retailprice,0)' else 'CAST(0 as numeric(25,8))' end
        +'		retailprice ,CAST(ISNULL(SUM(b.[quantity]),0)  AS numeric(25,8)) AS [quantity],
				CAST(ISNULL(SUM(b.[costtotal]),0) AS numeric(25,8)) AS [costtotal],
				CAST(ISNULL(SUM(b.[taxtotal]),0) AS numeric(25,8)) AS [taxtotal],
				CAST(ISNULL(SUM(b.[costtaxtotal]),0) AS numeric(25,8)) AS [costtaxtotal],
				CAST((ISNULL(SUM(b.[costtaxtotal]),0))/nullif(ISNULL(SUM(b.[quantity]),0),0) AS numeric(25,8)) as costtaxprice,
				CAST(ISNULL(SUM(b.[retailtotal]),0) AS numeric(25,8)) AS [retailtotal],
                CAST(ISNULL(SUM(b.[SaleTotal]),0) AS numeric(25,8)) AS [SaleTotal],
                CAST(ISNULL(SUM(b.[SendQTY]),0) AS numeric(25,8)) AS [SendQTY],
                CAST(ISNULL(SUM(b.[SendTotal]),0) AS numeric(25,8)) AS [SendTotal],
                CAST(ISNULL(SUM(b.[SendCostTotal]),0) AS numeric(25,8)) AS [SendCostTotal]
				FROM VW_C_Products a  
				LEFT JOIN (select C_Name,e_name,p_id from vw_productbalance where y_id='+Cast(@szY_id as varchar(10))+' ) vp ON a.product_id=vp.p_id
				                      LEFT JOIN '+@TableName+@SQLScript
		+' GROUP BY a.[product_id],a.[class_id],a.[child_number],a.[name],a.[code],a.[alias],
        a.[standard],a.[modal],a.[Factory],a.[rate2],a.[rate3],a.[rate4],a.[unitname1],a.[medtype],'+
        CASE @nMode WHEN 1 THEN 'pr.retailprice,' ELSE '' END
        +'a.Inputman,a.InputDate,a.Custompro1,a.Custompro2,a.Custompro3,a.Custompro4,a.Custompro5,a.permitcode
        ORDER BY a.[product_id]'
   EXEC(@SQLScript)
  GOTO Succee

GetClient:
   SELECT @SQLScript='SELECT a.[client_id],a.[class_id],a.[child_number],a.[name],a.[serial_number],
	      a.[phone_number],a.[address],a.[contact_personal],
				ISNULL(SUM(b.VCHcount),0) AS VCHcount,
				CAST(ISNULL(SUM(b.[quantity]),0)  AS numeric(25,8)) AS [quantity],
				CAST(ISNULL(SUM(b.[costtotal]),0) AS numeric(25,8)) AS [costtotal],
				CAST(ISNULL(SUM(b.[taxtotal]),0) AS numeric(25,8)) AS [taxtotal],
				CAST((ISNULL(SUM(b.[costtaxtotal]),0))/nullif(ISNULL(SUM(b.[quantity]),0),0) AS numeric(25,8)) as costtaxprice,
				CAST(ISNULL(SUM(b.[costtaxtotal]),0) AS numeric(25,8)) AS [costtaxtotal],
				CAST(ISNULL(SUM(b.[retailtotal]),0) AS numeric(25,8)) AS [retailtotal],
                CAST(ISNULL(SUM(b.[SaleTotal]),0) AS numeric(25,8)) AS [SaleTotal],
                CAST(ISNULL(SUM(b.[SendQTY]),0) AS numeric(25,8)) AS [SendQTY],
                CAST(ISNULL(SUM(b.[SendTotal]),0) AS numeric(25,8)) AS [SendTotal],
                CAST(ISNULL(SUM(b.[SendCostTotal]),0) AS numeric(25,8)) AS [SendCostTotal]
				FROM Clients a LEFT JOIN '+@TableName+@SQLScript+
                           ' AND ('+cast(@ClientTable as varchar(50))+'=0 or ((a.class_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''C'' and a.class_id  like u.psc_id+''%''))))'

        +'GROUP BY a.[client_id],a.[class_id],a.[child_number],a.[name],a.[serial_number],
	      a.[phone_number],a.[address],a.[contact_personal]
        ORDER BY a.[client_id]'


  /*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO Succee

Succee:
  RETURN 0
GO
