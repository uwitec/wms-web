
CREATE PROCEDURE [dbo].[Ts_K_ModifySfda]
(
    @BillType   INT,
    @BillId     INT,
    @SfdaCode   VARCHAR(20),
    @PId        INT,
    @BatchNo    VARCHAR(20),
    @ValidDate  DATETIME,
    @MakeDate   DATETIME,
    @Flag       INT         /*0 删除；1 新增*/
)
AS
BEGIN
	IF @Flag = 0
	BEGIN
		UPDATE Sfda_List SET [Deleted] = 1 WHERE Sfda_Code = @SfdaCode
		DELETE FROM RetailBillidx_Sfda 
		WHERE Sfda_Code = @SfdaCode AND Product_Id = @PId AND Bill_Id = @BillId AND BillType = @BillType AND 
		      IsDraft = 0 AND BatchNo = @BatchNo AND ValidDate = @ValidDate AND MakeDate = @MakeDate
		DELETE FROM Sfda_Detail WHERE billid = @BillId AND Sfda_Code = @SfdaCode       	
	END
	ELSE
	BEGIN
		DECLARE @bIsDraft INT
		IF @BillType IN (521)
			SET @bIsDraft = 1
		ELSE
			SET @bIsDraft = 0
		
		IF @BillType = 254
		  SELECT @BillId = b.billid, @BillType = b.billtype
		    FROM billidx b 
		  WHERE b.GUID IN (SELECT a.InvoiceNo FROM billdraftidx a WHERE a.billid = @BillId) 
		
		IF NOT EXISTS(SELECT 1 FROM Sfda_Detail WHERE billid = @BillId AND sfda_code = @SfdaCode)
		BEGIN
			INSERT INTO Sfda_Detail(billid, sfda_code, flag, guid)
			SELECT b.billid, @SfdaCode, V.StoreFlag, b.GUID
			  FROM billidx b INNER JOIN VchType v ON B.billtype = V.Vch_ID 
			WHERE b.billid = @BillId	
		END
		IF EXISTS(SELECT 1 FROM RetailBillidx_Sfda r 
		          WHERE r.Sfda_Code = @SfdaCode AND r.Bill_Id = @BillId AND 
		                r.IsDraft = 0 AND r.BillType = @BillType)
		BEGIN
			UPDATE RetailBillidx_Sfda SET Product_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate
			WHERE Sfda_Code = @SfdaCode AND Bill_Id = @BillId AND IsDraft = @bIsDraft AND BillType = @BillType
		END
		ELSE
		BEGIN
			INSERT INTO RetailBillidx_Sfda(Bill_Id, Product_Id, Sfda_Code, BillType, IsDraft, BatchNo, ValidDate, MakeDate)
			VALUES(@BillId, @PId, @SfdaCode, @BillType, @bIsDraft, @BatchNo, @ValidDate, @MakeDate)
		END
		
		DECLARE @YId INT, @SId INT, @CId INT
		IF @BillType > 500
		BEGIN
			SELECT @SId = b.S_id, @YId = b.Y_ID, @CId = b.c_id
			FROM GSPbillidx b WHERE b.Gspbillid = @BillId	
		END
		ELSE
		BEGIN
			SELECT @SId = b.sin_id, @YId = b.Y_ID, @CId = B.c_id
				FROM billidx b WHERE b.billid = @BillId
		END
		
		IF EXISTS(SELECT 1 FROM Sfda_List s WHERE s.Sfda_Code = @SfdaCode)
		BEGIN
			UPDATE Sfda_List
			SET P_Id = @PId, BatchNo = @BatchNo, ValidDate = @ValidDate, MakeDate = @MakeDate, S_Id = @SId,
			    Y_Id = CASE WHEN @BillType IN (150, 152) THEN @CId ELSE @YId END
			WHERE Sfda_Code = @SfdaCode		
		END
		ELSE
		BEGIN
			IF (@SId > 0) AND (@YId > 0) AND (@PId > 0)
			BEGIN
				INSERT INTO Sfda_List(Sfda_Code, P_Id, BatchNo, ValidDate, MakeDate, S_Id, Y_Id, [Deleted])
				VALUES(@SfdaCode, @PId, @BatchNo, @ValidDate, @MakeDate, @SId, CASE WHEN @BillType IN (150, 152) THEN @CId ELSE @YId END, 0)
			END
		END
	END
END
GO
