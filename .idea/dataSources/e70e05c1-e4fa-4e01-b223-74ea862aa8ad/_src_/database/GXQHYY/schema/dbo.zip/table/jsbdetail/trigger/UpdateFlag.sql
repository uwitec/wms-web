


CREATE TRIGGER UpdateFlag ON [dbo].[jsbdetail]
FOR insert
AS
declare @xsdbid numeric(10,0)
select @xsdbid=xsd_bid	from inserted
update billidx set jsflag='B'  where billid=@xsdbid
GO
