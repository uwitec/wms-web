
CREATE  FUNCTION GetStockOfPaymentPlanList(@BillId INT, @YId INT)  
RETURNS INT 
AS  
BEGIN 
	/*传入的单据明细商品中是否在待退厂库里有库存 0无库存，1有库存*/
	DECLARE @Result INT
	
	IF EXISTS(SELECT 1
			  FROM   (SELECT DISTINCT s.supplier_id, s.p_id FROM buymanagebill s WHERE s.bill_id = @BillId) a
			 		  INNER JOIN storehouse s ON  a.p_id = s.p_id AND a.supplier_id = s.supplier_id
					  INNER JOIN storages b ON s.s_id = b.storage_id
			  WHERE  s.Y_ID = @YId AND b.qualityFlag = 2)
	BEGIN
	    SET @Result = 1
	END
	ELSE
	BEGIN
	    SET @Result = 0
	END
	RETURN @Result
END
GO
