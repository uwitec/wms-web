




































CREATE proc ts_c_qrCashBank

(	
	@szParentid		varchar(30),
	@cSysFlag			char(2),
	@szPeriod			char(2)
)
as
set nocount on
if @szPeriod='' 
begin
	select a.account_id,a.class_id,a.serial_number,a.[name],a.parent_id,a.child_number,
		(select isnull(sum(b.cur_total),0) from account b 
		where left(b.class_id,len(a.class_id))=a.class_id and b.deleted=0) as 'total' 
	from account a 
	where a.parent_id=@szparentid and sysflag=@cSysFlag and a.deleted=0
end else
begin
	select a.account_id,a.class_id,a.serial_number,a.[name],a.parent_id,a.child_number,
		(select isnull(sum(b.ini_total),0) from account b 
		where left(b.class_id,len(a.class_id))=a.class_id and b.deleted=0) as 'total' 
	from account a 
	where a.parent_id=@szparentid and sysflag=@cSysFlag and a.deleted=0
end
GO
