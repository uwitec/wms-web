create procedure ts_e_RetailSaleZeroCheckMx
   @BeginDate DateTime ,   /*开始日期*/
   @EndDate   DateTime,    /*结束日期*/
   @BeginTime DateTime, /*开始时间*/
   @EndTime DateTime, /*结束时间*/
   @Y_id       int,             /*机构ID*/
   @SYY_ID     int,             /*收银员ID*/
   @SubStr     varchar(100)     /*赠品字符串 有成本赠品和零成本赠品*/
as 
    set @BeginDate = FLOOR(CAST(@BeginDate as numeric(25,8)))
	set @EndDate = CEILING(CAST(@EndDate + 1 as numeric(25,8)))

	set @BeginTime = @BeginTime - FLOOR(CAST(@BeginTime as numeric(25,8)))
	set @EndTime = @EndTime - FLOOR(CAST(@EndTime as numeric(25,8)))

begin
       select d.name as yname,a.billdate,a.auditdate as GzDate,billnumber,c.name as syname,
              e.serial_number as SerialNO,
              e.name as pname,e.alias as alias,e.[standard] as standard,f.AccountComment as factory,
              g.name as unitname,case billtype when 12 then  b.quantity else -b.quantity end as qty,
              costtaxprice,case billtype when 12 then costtaxtotal else -costtaxtotal end as costtaxtotal,
              case b.AOID when 7 then '有成本赠品' else '零成本赠品' end as AoidType,
              e.Custompro1,e.Custompro2,e.Custompro3,e.Custompro4,
              e.Custompro5,h.Comment as billVchtype,i.name as cname
              from billidx a inner join salemanagebill b on a.billid=b.bill_id
                               left  join employees c on a.inputman=c.emp_id
                               left  join company   d on a.Y_ID=d.company_id
                               left  join products  e on b.p_id=e.product_id
                               left  join basefactory F on e.factoryc_id=f.CommID
                               left join  unit g      on e.unit1_id=g.unit_id
                               left join  VchType  h  on a.billtype=h.Vch_ID
                               left join  storages i  on b.ss_id=i.storage_id
                      where  RetailDate between @BeginDate and @EndDate and
                             RetailDate - floor(cast(RetailDate as numeric(25,8))) BETWEEN @BeginTime AND @EndTime and 
                             a.billtype in (12,13) and a.billstates=0 and p_id>0 and  
                             AOID in(select  szTYPE from  DecodeToStr(@SubStr)) and 
                             (a.inputman=@SYY_ID or @SYY_ID=0) and
                             (a.Y_ID=@Y_id or @Y_id=0)
   
end
GO
