create procedure ts_e_RepRequestPayCheck
  @BeginDate  varchar(100) ,/*开始日期*/
  @EndDate varchar(100),/*结束日期*/
  @y_id  int=0,/*机构ID*/
  @y_class varchar(100),/*机构类ID*/
  @Yname varchar(100)/*机构名称*/

as
  IF @y_class IN ('','000000','%%')
    select @y_class='%%'
  ELSE 
    select @y_class=@y_class+'%'
begin
		 select  isnull(b.name,'') as yname,case b.Ytype  
				  when 0 then '分公司' when 1  then '自营店'
				  when 2 then '加盟店' when 3 then '内部机构' end as ytype,
				  isnull(a.billnumber,'') as billnumber,a.billdate as RequestDate,
				  isnull(c.RequestPGQty,0) as RequestPGQty,isnull(a.quantity,0) as RequesQty,
				  isnull(d.TurnoffPGQty,0) as TurnoffPGQty,isnull(h.SendQTY,0) as SendQTY,h.ComeDate as SendDate,
				  ISNULL(g.SendPGQty,0) as SendPGQty, /*isnull(i.OOSQty,0) as OOSQty,*/
				  isnull(a.quantity,0)-isnull(h.SendQTY,0) as OOSQty,
				  case isnull(c.RequestPGQty,0) when 0 then 0 else ((ISNULL(g.SendPGQty,0)*1.0)/(isnull(c.RequestPGQty,0)*1.0))*100 end as PgPsLv,
				  Case isnull(a.quantity,0) when 0 then 0  else  (isnull(h.SendQTY,0)/isnull(a.quantity,0))*100 end as QtyPsLV,
				  Case isnull(c.RequestPGQty,0) when 0 then 0 else  (isnull(d.TurnoffPGQty,0) /isnull(c.RequestPGQty,0))*100 end  as PGTurnoffLV,
				  case isnull(a.quantity,0) when 0 then 0 else  (isnull(a.quantity,0)-isnull(h.SendQTY,0))/isnull(a.quantity,0)*100 end as QtyOOSLv
                  from                                  
                   (
                       select * from company where class_id  like @y_class
                   ) b
                   left join 
                   (
                     select  sum(b.quantity) as  quantity,a.billdate,bill_id,c_id,a.billnumber  
                      from tranidx a inner join tranbill b on a.billid=b.bill_id
                      where  billtype=52 and a.billdate  between  @BeginDate and @EndDate
                      group by a.billdate,bill_id,c_id,a.billnumber  
                   ) a on a.c_id=b.company_id                                                         
                   left join 
                   (
                      select  COUNT(distinct p_id) as RequestPGQty,bill_id
                      from tranidx a inner join tranbill b on a.billid=b.bill_id
                      where  billtype=52 and billdate between  @BeginDate and @EndDate
                      group by bill_id
                   ) c on a.bill_id=c.bill_id
                   left join 
                   (
                     select COUNT(distinct p_id) as TurnoffPGQty,bill_id from tranbill a inner join tranidx b on a.bill_id=b.billid
                                                         where p_id not in(select p_id from storehouse where quantity<>0 and Y_ID=2) and a.p_id>0
                                                              and b.billdate between  @BeginDate and @EndDate
                                                         group by bill_id  
                   ) d on a.bill_id=d.bill_id
                   left join 
                          (
							 select  COUNT(distinct p_id) as SendPGQty,bill_id
							     from tranidx a inner join tranbill b on a.billid=b.bill_id
							     where  billtype=52  and billdate between  @BeginDate and @EndDate and ComeQty<>0
							    group by bill_id
                          )g on a.bill_id=g.bill_id   
                   left join 
					(                   
						  select  sum(ComeQty) as SendQTY,d.billdate as ComeDate,a.c_id,b.bill_id
						  from tranidx a inner join tranbill b on a.billid=b.bill_id
						                 left join salemanagebill c on b.RowGuid=c.YGuid
						                 left join billidx d on c.bill_id=d.billid
						  where  a.billtype=52 and a.billdate between  @BeginDate and @EndDate and ComeQty<>0
						  group by a.billdate,b.bill_id,a.c_id,d.billdate
                     ) h on a.bill_id=h.bill_id   
                     left join 
                     (
                      select sum(OOSQty) as OOSQty,CompanyId from OOSCatalog where InputDate  between  @BeginDate and @EndDate
                               group by CompanyId    
                     ) i  on a.c_id=i.CompanyId       
end
GO
