/* =============================================*/  
/* Author:  LuoLe*/  
/* Create date: 2016-02-22*/  
/* Description: 单会员数据分析*/  
/* =============================================*/  
Create Procedure TS_L_RepAnalysisFor1Member
       @VipCardID Int
      ,        /* vipID*/
       @QueryKind Int  /*查询种类*/
As
Begin
      If @QueryKind = 1  /*--会员档案*/
         Begin
               Select
                vc.VIPCardID 会员卡ID
               ,vc.CardNo 会员卡号
               ,vc.Name 姓名
               ,vc.sex 性别
               ,vc.Birthday 出生日月
               ,vc.Education 学历
               ,vc.BulidDate 发卡日期
               ,vc.Tel 电话
               ,vc.Address 地址
               ,vc.ValidityDate 有效日期
               ,DateDiff(Day,FirstLastBillDate.FirstBillDate,GetDate()) + 1 客龄
               , /*会受到年结存影响*/
                vc.ct_id 卡类型id
               ,vct.name 卡类型
               ,vc.Y_ID 发卡机构ID
               ,cpy.name 发卡机构
               ,FirstLastBillDate.Lastbilldate 最后消费日期
               ,/*会受到年结存影响*/
               Case When TotalBillInfo.TotalBuyCount <> 0 Then Round(( DateDiff(Day,FirstLastBillDate.FirstBillDate,FirstLastBillDate.LastBillDate) + 1 ) / TotalBillInfo.TotalBuyCount,0)
               Else 0
               End 消费周期
               , /*会受到年结存影响*/
                vc.e_id 建卡人ID
               ,IsNull(epy.name,'') 建卡人
               ,vc.SaveMoney 累计储值金额
               ,( vc.SaveMoney - vc.ReMainderMoney ) 储值消费
               ,vc.ReMainderMoney 储值余额
               ,IsNull(TotalBillInfo.TotalMoney,0) 累计消费金额
               ,IsNull(billdata.TotalFavoMoney,0) 累计优惠
               ,IsNull(CashCouponTotalBalance.CashCpnBalance,0) 代金券余额
               ,vc.Integral + vc.SwapIntegral 累计积分
               ,vc.invalidintegral 失效积分
               ,vc.Integral 可用积分
               ,IsNull(TotalBillInfo.TotalBuyCount,0) 累计消费次数
               ,Case When TotalBillInfo.TotalBuyCount <> 0 Then Round(TotalBillInfo.TotalMoney / TotalBillInfo.TotalBuyCount,2)
                Else 0
                End  客单价
               ,Case When TotalBillInfo.TotalBuyCount <> 0 Then PGSHZ.TotalPGS / TotalBillInfo.TotalBuyCount
               Else 0
               End 均品次
               ,  /* 均品次= (每单品规数之和) / 购买次数*/
                IsNull(billdata.TotalGrossProfit,0) 毛利贡献
               ,   /*--会受到年结存影响*/
                IsNull(billData.TotalGrossProfitRate,0) 毛利率   /*会受到年结存影响*/
               From
                vipcard As vc
                Left Outer Join VipCardType As vct
                    On vc.ct_id = vct.ct_id
                Left Outer Join company As cpy
                    On vc.y_id = cpy.company_id
                Left Outer Join employees As epy
                    On vc.e_id = epy.emp_id
                Left Outer Join ( Select
                                    Bidx.VipCardID
                                   ,-1 * Round(Sum(smbnew.TaxTotalNew - smbnew.retailTotalNew),2) TotalFavoMoney
                                   , /* 优惠累计*/
                                    Round(Sum(Case When SmbNew.aoid In ( 0,5 ) Then SmbNew.TaxTotalNew
                                                   Else 0
                                              End - SmbNew.CostTaxTotalNew),2) TotalGrossProfit
                                   ,  /*毛利润累计*/
                                    Case When Sum(Case When SmbNew.aoid In ( 0,5 ) Then smbNew.TaxTotalNew
                                                       Else 0
                                                  End) = 0 /*判断是否都是赠品记录，或者总价为0，避免除0错误*/
                                              Then 0
                                         Else Round(Sum(
                                                     case (Case When aoid In ( 0,5 ) Then smbNew.TaxTotalNew Else 0 End) when 0 then 0 else
                                                     (( Case When aoid In ( 0,5 ) Then SmbNEw.TaxTotalNew
                                                               Else 0 End - smbNew.CostTaxTotalNew ) * 100 /Case When aoid In ( 0,5 ) Then smbNew.TaxTotalNew Else 0
                                                                                                 End) end),2)
                                    End As TotalGrossProfitRate  /* 毛利率累计*/
                                  From
                                    ( Select
                                        Case When b.billtype = 12 Then a.retailTotal
                                             Else -a.retailTotal
                                        End retailTotalNew
                                       ,Case When b.billtype = 12 Then a.costtaxTotal
                                             Else -a.costtaxTotal
                                        End costtaxTotalNew
                                       ,Cast(( Case When b.billtype = 12 Then a.TaxTotal
                                                    Else -a.TaxTotal
                                               End ) As numeric(25,8)) TaxTotalNew
                                       ,a.Aoid
                                       ,a.Bill_id
                                      From
                                        saleManageBill a
                                        Left Outer Join billidx b
                                            On a.bill_id = b.billID
                                      Where
                                        ( a.p_id > 0 )
                                        And b.billtype In ( 12,13 )  /*零售单、零售退货单*/
                                        And b.billstates = 0
                                        And b.vipcardid = @VipCardID
                                    ) As SMBNew
                                    Left Outer Join Billidx bidx
                                        On SMBNEW.bill_id = bidx.billid
                                  Group By
                                    Bidx.VipCardID
                                ) As billdata
                    On billdata.vipCardId = vc.VipCardID
                Left Outer Join ( Select
                                    a.vipCardID
                                   ,Sum(b.total) CashCpnBalance
                                  From
                                    CashCoupon a
                                    Left Outer Join CashCouponType b
                                        On a.typeid = b.typeid
                                  Where
                                    a.flag = 0
                                    And a.vipcardID = @VipCardID
                                  Group By
                                    a.vipCardID
                                ) As CashCouponTotalBalance
                    On vc.VipCardID = CashCouponTotalBalance.VipCardID
                Left Outer Join ( Select
                                    Min(billdate) FirstBillDate
                                   ,Max(billdate) Lastbilldate
                                   ,VipCardID
                                  From
                                    billidx
                                  Where
                                    vipcardID = @VipCardID
                                  Group By
                                    VipCardID
                                ) FirstLastBillDate
                    On vc.VipCardID = FirstLastBillDate.vipCardID  /*首单末单时间*/
                Left Outer Join ( Select
                                    Sum(PGSMX.pgs) TotalPGS
                                   ,vipCardID
                                  From
                                    ( Select
                                        Count(Distinct ( a.p_id )) pgs
                                       ,a.bill_id
                                       ,b.VipCardID
                                      From
                                        salemanagebill a
                                        Left Outer Join billidx b
                                            On a.bill_id = b.billid
                                      Where
                                        b.billstates = 0
                                        And b.billtype In ( 12 )  /*品规不考虑退货*/
                                        And a.p_id > 0
                                        And b.Vipcardid = @VipCardID
                                      Group By
                                        a.bill_id
                                       ,b.VipCardID
                                    ) PGSMX   /* 品规数明细*/
                                  Group By
                                    vipcardid
                                ) PGSHZ
                    On vc.VipCardID = PGSHZ.vipCardID   /*品规数汇总*/
                Left Outer Join ( Select
                                    Sum(ysmoney) TotalMoney
                                   ,Count(billid) TotalBuyCount
                                   ,VipCardID
                                  From
                                    billidx
                                  Where
                                    billstates = 0
                                    And billtype In ( 12,13 )
                                    And VipCardID = @VipCardID
                                  Group By
                                    VipCardID
                                ) TotalBillInfo
                    On vc.VipCardID = TotalBillInfo.vipCardID
               Where
                vc.VipCardID = @VipCardID
         End
      If @QueryKind = 2  /*销售记录        */
         Begin
               Select
                日期
               ,单据编号
               ,单据类型
               ,通用名
               ,规格
               ,生产厂家
               ,单位
               ,数量
               ,批号
               ,有效期
               ,优惠后金额
               ,毛利
               ,Case When orgtab.billType = 12 Then MLL
                     Else -1 * MLL
                End 毛利率
               From
                ( Select
                    smbNEw.billDate 日期
                   ,smbNew.billnumber 单据编号
                   ,
                        /*bidx.billtype 单据类型ID ,*/
                    vtp.comment 单据类型
                   ,
                        /*smb.p_id 商品ID ,*/
                    pdt.alias 通用名
                   ,pdt.standard 规格
                   ,pdt.Factory 生产厂家
                   ,U.Name 单位
                   ,smbNew.quantity 数量
                   ,smbNew.batchno 批号
                   ,convert(char(7) ,smbNew.validdate , 120) 有效期
                   ,smbNew.RetailTotalNew 优惠后金额
                   ,smbNew.Billtype
                   ,Round(Case When smbNew.aoid In ( 0,5 ) Then smbNew.RetailTotalNew
                               Else 0
                          End - smbNew.CostTaxTotalNew,2) 毛利
                   ,( Case When ( Case When aoid In ( 0,5 ) Then smbNew.RetailTotalNew
                                       Else 0
                                  End ) <> 0 /*判断是否都是赠品记录，或者总价为0，避免除0错误*/
                                Then Round(( ( Case When aoid In ( 0,5 ) Then smbNew.RetailTotalNew
                                                    Else 0
                                               End ) - smbNew.CostTaxTotalNew ) * 100 / ( Case When aoid In ( 0,5 ) Then smbNew.RetailTotalNew
                                                                                               Else 0
                                                                                          End ),2)
                           Else 0
                      End ) As MLL
                  From
                    ( Select
                        Case When b.billtype = 12 Then RetailTotal
                             Else -RetailTotal
                        End RetailTotalNew
                       ,Case When b.billtype = 12 Then Costtaxtotal
                             Else -Costtaxtotal
                        End CosttaxtotalNew
                       ,Cast(( Case When b.billtype = 12 Then TaxTotal
                                    Else -TaxTotal
                               End ) As numeric(25,8)) TaxTotalNew
                       ,a.p_id
                       ,a.Aoid
                       ,a.Bill_id
                       ,a.Quantity
                       ,a.BatchNo
                       ,a.validdate
                       ,b.BillDate
                       ,b.billnumber
                       ,b.billtype
                       ,a.unitid
                      From
                        saleManageBill a
                        Left Outer Join billidx b
                            On a.bill_id = b.billID
                      Where
                        ( a.p_id > 0 )
                        And b.billtype In ( 12,13 )  /*零售单、零售退货单*/
                        And b.billstates = 0
                        And b.vipcardid = @VipCardID
                    ) As SMBNew
                    Left Outer Join vchtype vtp
                        On smbNew.billtype = vtp.vch_id
                    Left Outer Join products pdt
                        On smbNew.p_id = pdt.product_id
                    Left Outer Join Unit u
                        On smbNew.unitid = u.Unit_id
                ) As orgtab 
         End 
      If @QueryKind = 3       /*积分明细*/
         Begin
               Select
                BulidDate 日期
               ,'初始积分-增加积分' 事件
               ,IniIntergral 本次积分
               ,IniIntergral 可用积分余额
               ,'初始积分' 备注
               From
                vipcard
               Where
                VipCardID = @VipCardID
               Union All
               Select
                日期
               ,事件
               ,本次积分
               ,本次操作后的积分 可用积分余额
               ,备注
               From
                ( Select
                    BillDate 日期
                   ,'介绍人返积分-增加积分' 事件
                   ,totalItg 本次积分
                   ,ptotalItg 本次操作后的积分
                   ,'介绍人返积分' 备注
                  From
                    Integralidx
                  Where
                    remake = '介绍人返积分'
                    And VipCardID = @VipCardID
                  Union All
                  Select
                    ModifyDate 日期
                   ,Case When ModIntegral > 0 Then '积分修改' + '-增加积分'
                         Else '积分修改' + '-减少积分'
                    End 事件
                   ,ModIntegral 本次积分
                   ,NowIntegral + ModIntegral 本次操作后的积分
                   ,'积分修改' 备注
                  From
                    ModifyIntegral
                  Where
                    CardID = @VipCardID
                  Union All
                  Select
                    i.billDate 日期
                   ,'零售单积分-消费积分' 事件
                   ,totalItg 本次积分
                   ,PtotalItg 本次操作后的积分
                   ,'零售单积分' 备注
                  From
                    integralIdx i
                    Left Outer Join BillIdx b
                        On i.bill_id = b.billid
                  Where
                    i.VipCardID = @VipCardID
                    And b.billType In ( 12,13 )
                  Union All
                  Select
                    b.billdate 日期
                   ,'兑换积分-减少积分' 事件
                   ,-1 * Round(e.IntegralTotal,2) 本次积分
                   ,v.NowIntegral 本次操作后的积分
                   ,'积分兑换' 备注
                  From
                    billidx b
                    Left Outer Join ExIntegRalManagebill e
                        On b.billid = e.billid
                    Left Outer Join viplog v
                        On b.vipcardid = v.vipcardid
                  Where
                    billtype = 149
                    And b.vipcardid = @vipcardid
                    And v.actName = '积分兑换单'
                    And e.IntegralTotal = Substring(v.comment,CharIndex('兑换积分:',v.comment) + 5,CharIndex(';经手人',v.comment) - ( CharIndex('兑换积分:',v.comment) + 5 ))
                  Union All
                  Select
                    ActDate 日期
                   ,'积分清零-扣减积分' 事件
                   ,ModIntegral 本次积分
                   ,0 本次操作后的积分
                   ,'积分清零' 备注
                  From
                    viplog
                  Where
                    vipcardid = @vipcardid
                    And ActName = '积分清零'
                  Union All
                  Select
                    d.billdate 日期
                   ,'积分抵现-减少积分' 事件
                   ,d.totalItg 本次积分
                   ,d.PtotalItg 本次操作后的积分
                   ,'积分抵现' 备注
                  From
                    saleManageBill s
                    Left Outer Join Integraldetail i
                        On s.smb_id = i.smb_id
                    Left Outer Join integralIdx d
                        On i.billid = d.billid
                    Left Outer Join billidx b
                        On s.bill_id = b.billid
                  Where
                    s.p_id = -89
                    And b.vipcardid = @vipcardid
                  Union All
                  Select
                    Convert(Date,GetDate(),112) 日期
                   ,'积分失效-减少积分' 事件
                   ,invalidIntegral 本次积分
                   ,Integral 本次操作后的积分
                   ,'积分失效' 备注
                  From
                    vipcard
                  Where
                    VipcardID = @vipCardid
                ) As tb
               Order By
                日期              

         End
      If @QueryKind = 4 /*储值明细*/
         Begin
               Select
                Z.billid
               ,Z.smb_ID
               ,Z.日期
               ,Z.储值事件
               ,Z.金额
               ,Sum(F.金额) 储值余额
               From
                ( Select Top 5000
                    Row_Number() Over ( Order By billid + smb_id ) MyOrder
                   ,*
                  From
                    ( Select
                        b.billid
                       ,a.smb_id
                       ,b.billDate 日期
                       ,Case When a.a_id = 65 Then '储值赠送'
                             Else '储值充值'
                        End 储值事件
                       ,a.jftotal 金额
                      From
                        FinanceBill a
                        Left Outer Join BillIdx b
                            On a.bill_id = b.billid
                      Where
                        b.billtype = 148
                        And b.VipCardID = @VipCardID
                      Union All
                      Select
                        b.BillID
                       ,a.smb_id
                       ,b.billDate 日期
                       ,'储值消费' 储值事件
                       ,a.total 金额
                      From
                        salemanagebill a
                        Left Outer Join BillIdx b
                            On b.billid = a.bill_id
                      Where
                        b.billtype = 12
                        And a.p_id = -1 * ( Select account_id From account Where name = '储值帐款'
                                          )
                        And b.VipCardID = @VipCardID
                        Union All
                      Select
                        b.BillID
                       ,a.smb_id
                       ,b.billDate 日期
                       ,'零售退款' 储值事件
                       ,a.total 金额
                      From
                        salemanagebill a
                        Left Outer Join BillIdx b
                            On b.billid = a.bill_id
                      Where
                        b.billtype = 13
                        And a.p_id = -1 * ( Select account_id From account Where name = '储值帐款'
                                          )
                        And b.VipCardID = @VipCardID
                    ) As src
                  Order By
                    MyOrder
                ) Z
                Left Outer Join ( Select Top 5000
                                    Row_Number() Over ( Order By billid + smb_id ) MyOrder
                                   ,*
                                  From
                                    ( Select
                                        b.billid
                                       ,a.smb_id
                                       ,b.billDate 日期
                                       ,Case When a.a_id = 65 Then '储值赠送'
                                             Else '储值充值'
                                        End 储值事件
                                       ,a.jftotal 金额
                                      From
                                        FinanceBill a
                                        Left Outer Join BillIdx b
                                            On a.bill_id = b.billid
                                      Where
                                        b.billtype = 148
                                        And b.VipCardID = @VipCardID
                                      Union All
                                      Select
                                        b.BillID
                                       ,a.smb_id
                                       ,b.billDate 日期
                                       ,'储值消费' 储值事件
                                       ,-a.total 金额
                                      From
                                        salemanagebill a
                                        Left Outer Join BillIdx b
                                            On b.billid = a.bill_id
                                      Where
                                        b.billtype = 12
                                        And a.p_id = -1 * ( Select account_id From account Where name = '储值帐款'
                                                          )
                                        And b.VipCardID = @VipCardID
                                       Union All
                                      Select
                                        b.BillID
                                       ,a.smb_id
                                       ,b.billDate 日期
                                       ,'零售退款' 储值事件
                                       ,a.total 金额
                                      From
                                        salemanagebill a
                                        Left Outer Join BillIdx b
                                            On b.billid = a.bill_id
                                      Where
                                        b.billtype = 13
                                        And a.p_id = -1 * ( Select account_id From account Where name = '储值帐款'
                                                          )
                                        And b.VipCardID = @VipCardID
                                    ) As src
                                  Order By
                                    MyOrder
                                ) F
                    On Z.Myorder >= F.MyOrder
               Group By
                Z.billid
               ,Z.smb_id
               ,Z.日期
               ,Z.储值事件
               ,Z.金额
               Order By
                Z.billid
               ,Z.smb_ID
         End
      If @QueryKind = 5 /*代金券*/
         Begin
               Select
                a.CreateDate 发放日期
               ,b.validDate 有效期至
               ,a.CashNo 券号
               ,b.total 面值
               ,b.total 金额
               ,a.comment 备注
               From
                cashcoupon a
                Inner Join CashcouponType b
                    On a.typeid = b.typeid
               Where
                a.vipcardid = @VipCardID
                And deleted = 0
                And a.flag = 0 
         End
      If @QueryKind = 6 /*回访记录*/
         Begin
               Select
                CreateDate 发放日期
               ,b.validDate 有效期至
               ,a.CashNo 券号
               ,b.total 面值
               ,b.total 金额
               ,a.comment 备注
               From
                cashcoupon a
                Inner Join CashcouponType b
                    On a.typeid = b.typeid
               Where
                a.vipcardid = @VipCardID
                And deleted = 0
                And a.flag = 0                
         End            
End
GO
