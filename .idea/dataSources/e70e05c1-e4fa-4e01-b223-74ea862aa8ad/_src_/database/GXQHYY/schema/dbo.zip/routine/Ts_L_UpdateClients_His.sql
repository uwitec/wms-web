
CREATE	PROCEDURE [Ts_L_UpdateClients_His]
	(@client_id	[int] output,
	 @serial_number 	[varchar](26),
	 @name	[varchar](80),
	 @alias 	[varchar](30),
	 @region_id	[int],
	 @phone_number	[varchar](100),
	 @address	[varchar](80),
	 @zipcode	[varchar](10),
	 @contact_personal	[varchar](20),
	 @tax_number	[varchar](50),
	 @acount_number 	[varchar](2000),
	 @credit_total	[numeric],
         @APcredit_total [numeric],  
	 @pinyin	[varchar](80),
	 @pricemode	[smallint],
	 @sklimit	[smallint],
	 @artotal	numeric(25,8),
	 @artotal_ini	numeric(25,8),
	 @aptotal	numeric(25,8),
	 @aptotal_ini	numeric(25,8),
	 @pre_artotal	numeric(25,8),
	 @pre_artotal_ini	numeric(25,8),
	 @pre_aptotal	numeric(25,8),
	 @pre_aptotal_ini	numeric(25,8),
	 @firstcheck	[bit],
	 @comment	[varchar](256),
	 @csflag	[char](1),
	 @ceType	[Tinyint],
	 @GSPNO		[varchar](30),
	 @GMPNo		[varchar](30),
	 @incRate	numeric(25,8)=1,
	 @Licence_no [varchar](512),          	/*企业许可证*/
	 @Ent_type   int,          		/*所属类型*/
	 @City_id    [varchar](32),       	/*所属市区辖区编码*/
	 @City_name  [varchar](512),         	/*所属市区辖区*/
	 @boro_id    [varchar](32),         	/*所属县区辖区编码*/
	 @boro_name  [varchar](512),       	/*所属县区辖区*/
	 @e_id       int,
	 @createDate varchar(100),
	 @C_Customname1 varchar(100),           /*自定义属性1*/
	 @C_Customname2 varchar(100),           /*自定义属性2*/
	 @C_Customname3 varchar(100),           /*自定义属性3*/
	 @C_Customname4 varchar(100),           /*自定义属性4*/
	 @C_Customname5 varchar(100),            /*自定义属性5*/
     @clienttype_id  [int],                 /*客户类型ID*/
	 @cardID         [int],                 /*会员卡ID*/
	 @consignBook_no varchar (80),         /*委托书编号*/
	 @organCard_no   varchar (80),         /*组织机构证书编号*/
	 @BusinessLicence_no  varchar (80),    /*营业执照编号*/
	 @MassConfer_no   varchar (128),       /**/
	 @Cer_CustomNO1   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO2   varchar (128),
	 @Cer_CustomNO3   varchar (128),
	 @Cer_CustomNO4   varchar (128),
	 @Cer_CustomNO5   varchar (128),
	 @Y_id           [int],                /*分支机构ID*/
	 @ByWayDay       [int],
	 @Roadline       [int],               /*配送线路*/
	 @RoadOrder      varchar(5),           /*线路顺序号*/
	 @OrderCredit     [bit],                  /*是否允许下订单。0为允许下订单，1为不允许。*/
	 @discount       numeric(25,8),             /*单位折扣  2012-02-17*/
	 @ElecCode       [bit],	/* 电子监管码*/
	 @AddressZC		varchar (128),				/*注册地址*/
         @Quality_Personal VARCHAR(20),      /*质量负责人*/
         @Quality_Phone    VARCHAR(100),       /*质量负责人电话*/
         @QQ               VARCHAR(30),       /*QQ号*/
	 @ModifyEId      [INT],                /*录入人Id*/
	 @Cer_CustomNO6   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO7   varchar (128),
	 @Cer_CustomNO8   varchar (128),
	 @Cer_CustomNO9   varchar (128),
	 @Cer_CustomNO10   varchar (128),
	 @CreateMan varchar (50),
	 @zljgPeople  varchar(50),          /*质量机构负责人*/
	 @zljgphone  varchar(50),             
	 @cwPeople  varchar(50),            /*财务负责人*/
	 @cwphone  varchar(50), 
	 @zlglPeople  varchar(50),          /*质量管理员*/
	 @zlglphone  varchar(50), 
	 @storePeople  varchar(50),         /*仓库负责人*/
	 @storephone  varchar(50),
	 @BalanceMode  INT,                  /*结算方式 	*/
	 @refEntSeqNo varchar(100),           /*电子监管企业标识*/
	 @partnerSeqNo varchar(100),           /*电子监管网ID*/
	 @legalpeople varchar(50),          /*法人代表*/
     @legalphone varchar(50)            /*法人代表电话*/
	)
AS 
   declare @client_idOld	[int],
	 @serial_numberOld 	[varchar](26),
	 @nameOld	[varchar](80),
	 @aliasOld 	[varchar](30),
	 @region_idOld	[int],
	 @phone_numberOld	[varchar](100),
	 @addressOld	[varchar](80),
	 @zipcodeOld	[varchar](10),
	 @contact_personalOld	[varchar](20),
	 @tax_numberOld	[varchar](50),
	 @acount_numberOld 	[varchar](2000),
	 @credit_totalOld	[numeric],
         @APcredit_totalOld [numeric],  
	 @pinyinOld	[varchar](80),
	 @pricemodeOld	[smallint],
	 @sklimitOld	[smallint],
	 @artotalOld	numeric(25,8),
	 @artotal_iniOld	numeric(25,8),
	 @aptotalOld	numeric(25,8),
	 @aptotal_iniOld	numeric(25,8),
	 @pre_artotalOld	numeric(25,8),
	 @pre_artotal_iniOld	numeric(25,8),
	 @pre_aptotalOld	numeric(25,8),
	 @pre_aptotal_iniOld	numeric(25,8),
	 @firstcheckOld	[bit],
	 @commentOld	[varchar](256),
	 @csflagOld	[char](1),
	 @ceTypeOld	[Tinyint],
	 @GSPNOOld		[varchar](30),
	 @GMPNoOld		[varchar](30),
	 @incRateOld	numeric(25,8)=1,
	 @Licence_noOld [varchar](512),          	/*企业许可证*/
	 @Ent_typeOld   int,          		/*所属类型*/
	 @City_idOld    [varchar](32),       	/*所属市区辖区编码*/
	 @City_nameOld  [varchar](512),         	/*所属市区辖区*/
	 @boro_idOld    [varchar](32),         	/*所属县区辖区编码*/
	 @boro_nameOld  [varchar](512),       	/*所属县区辖区*/
	 @e_idOld       int,
	 @createDateOld varchar(100),
	 @C_Customname1Old varchar(100),           /*自定义属性1*/
	 @C_Customname2Old varchar(100),           /*自定义属性2*/
	 @C_Customname3Old varchar(100),           /*自定义属性3*/
	 @C_Customname4Old varchar(100),           /*自定义属性4*/
	 @C_Customname5Old varchar(100),            /*自定义属性5*/
     @clienttype_idOld  [int],                 /*客户类型ID*/
	 @cardIDOld         [int],                 /*会员卡ID*/
	 @consignBook_noOld varchar (80),         /*委托书编号*/
	 @organCard_noOld   varchar (80),         /*组织机构证书编号*/
	 @BusinessLicence_noOld  varchar (80),    /*营业执照编号*/
	 @MassConfer_noOld   varchar (128),       /**/
	 @Cer_CustomNO1Old   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO2Old   varchar (128),
	 @Cer_CustomNO3Old   varchar (128),
	 @Cer_CustomNO4Old   varchar (128),
	 @Cer_CustomNO5Old   varchar (128),
	 @Y_idOld           [int],                /*分支机构ID*/
	 @ByWayDayOld       [int],
	 @RoadlineOld       [int],               /*配送线路*/
	 @RoadOrderOld      varchar(5),           /*线路顺序号*/
	 @OrderCreditOld     [bit],                  /*是否允许下订单。0为允许下订单，1为不允许。*/
	 @discountOld       numeric(25,8),             /*单位折扣  2012-02-17*/
	 @ElecCodeOld       [bit],	/* 电子监管码*/
	 @AddressZCOld		varchar (128),				/*注册地址*/
     @Quality_PersonalOld VARCHAR(20),      /*质量负责人*/
     @Quality_PhoneOld    VARCHAR(100),       /*质量负责人电话*/
     @QQOld               VARCHAR(30),       /*QQ号*/
	 @ModifyEIdOld      [INT],                /*录入人Id*/
	 @Cer_CustomNO6Old   varchar (128),       /*自定义证照编号*/
	 @Cer_CustomNO7Old   varchar (128),
	 @Cer_CustomNO8Old   varchar (128),
	 @Cer_CustomNO9Old   varchar (128),
	 @Cer_CustomNO10Old   varchar (128),
	 @CreateManOld varchar (50),
	 @zljgPeopleOld  varchar(50),          /*质量机构负责人*/
	 @zljgphoneOld  varchar(50),             
	 @cwPeopleOld  varchar(50),            /*财务负责人*/
	 @cwphoneOld  varchar(50), 
	 @zlglPeopleOld  varchar(50),          /*质量管理员*/
	 @zlglphoneOld  varchar(50), 
	 @storePeopleOld  varchar(50),         /*仓库负责人*/
	 @storephoneOld  varchar(50),
	 @BalanceModeOld  INT,                  /*结算方式 	*/
	 @refEntSeqNoOld varchar(100),           /*电子监管企业标识*/
	 @partnerSeqNoOld varchar(100),           /*电子监管网ID*/
	 @legalpeopleOld varchar(50),          /*法人代表*/
     @legalphoneOld varchar(50)            /*法人代表电话*/
	/*Params Ini begin*/
	if @incRate is null  SET @incRate = 1
	/*Params Ini end*/
	/*declare @szY_ID varchar(50)*/
	declare @isopenDate int

	SET @client_id = ABS(@client_id)

	/* 判断是否存在未处理申请修改*/
	IF EXISTS(SELECT * FROM BaseInfoHistory WHERE BaseInfoType = 'C' AND BaseInfo_ID = @client_id AND Status = 0)
	BEGIN
		RAISERROR ('本往来单位已提交过修改申请，请等待处理后再次提交！', 16, 1)
		set @client_id = -@client_id
		RETURN -50
	END

	SELECT * 
	INTO #TC
	FROM clients
	WHERE client_id = @client_id
	
	SELECT * 
	INTO #TCOld
	FROM clients
	WHERE client_id = @client_id
	
select @serial_numberOld=[serial_number],
     @nameOld=[name],
	 @aliasOld=[alias],
	 @region_idOld=[region_id],
	 @phone_numberOld=[phone_number],
	 @addressOld=[address],
	 @zipcodeOld=[zipcode],
	 @contact_personalOld=contact_personal,
	 @tax_numberOld=[tax_number],
	 @acount_numberOld= [acount_number],
	 @credit_totalOld=[credit_total],
	 @pinyinOld=[pinyin],
	 @pricemodeOld=[pricemode],
	 @sklimitOld=[sklimit],
	 @artotal_iniOld=[artotal_ini],
	 @aptotal_iniOld=[aptotal_ini],
	 @pre_artotal_iniOld=[pre_artotal_ini],
	 @pre_aptotal_iniOld=[pre_aptotal_ini],
	 @firstcheckOld=[firstcheck],
	 @commentOld=[comment],
	 @csflagOld=[csflag] ,
	 @ceTypeOld=[ceType],
 	 @GSPNOOld=[GspNo],
	 @GMPNoOld=[gmpno],
	 @incRateOld=[incRate],
	 @Licence_noOld=[Licence_no],          	/*企业许可证*/
	 @Ent_typeOld=[Ent_type],          		/*所属类型*/
	 @City_idOld=[City_id],       		/*所属市区辖区编码*/
	 @City_nameOld=[City_name],         		/*所属市区辖区*/
	 @boro_idOld=[boro_id],         		/*所属县区辖区编码*/
	 @boro_nameOld=[boro_name],         		/*所属县区辖区*/
	 @e_idOld=[e_id],
	 @createDateOld=[createDate], 
	 @C_Customname1Old=[C_Customname1],                /*自定义属性1*/
	 @C_Customname2Old=[C_Customname2],                /*自定义属性2*/
	 @C_Customname3Old=[C_Customname3],               /*自定义属性3*/
   	 @C_Customname4Old=[C_Customname4],                /*自定义属性4*/
  	 @C_Customname5Old=[C_Customname5],                /*自定义属性5*/
 	 @clienttype_idOld=[clienttype_id],                /*客户类型ID*/
	 @cardIDOld=[card_ID],                        /*会员卡ID*/
	 @consignBook_noOld=[consignBook_no],             /*委托书编号*/
	 @organCard_noOld=[organCard_no],                /*组织机构证书编号*/
	 @BusinessLicence_noOld=[BusinessLicence_no],         /*营业执照编号  TT*/
	 @MassConfer_noOld=[MassConfer_no],
	 @Cer_CustomNO1Old=[Cer_CustomNO1],
	 @Cer_CustomNO2Old=[Cer_CustomNO2],
	 @Cer_CustomNO3Old=[Cer_CustomNO3],
	 @Cer_CustomNO4Old=[Cer_CustomNO4],
	 @Cer_CustomNO5Old=[Cer_CustomNO5],
	 @ByWayDayOld=[ByWayDay], 
	 @RoadlineOld=[RoadID],
	 @RoadOrderOld=[szOrdernum],  
	 @OrderCreditOld=[OrderCredit],
	 @discountOld=[discount],
	 @ElecCodeOld=ElecCode,
	 @AddressZCOld=AddressZC,
	 @Quality_PersonalOld=Quality_Personal,
	 @Quality_PhoneOld=Quality_Phone,
	 @QQOld=QQ,
	 @ModifyEIdOld=ModifyEId,
	 @Cer_CustomNO6Old=[Cer_CustomNO6],
	 @Cer_CustomNO7Old=[Cer_CustomNO7],
	 @Cer_CustomNO8Old=[Cer_CustomNO8],
	 @Cer_CustomNO9Old=[Cer_CustomNO9],
	 @Cer_CustomNO10Old=[Cer_CustomNO10],
	 @zljgPeopleOld=[zljgPeople],
	 @zljgphoneOld=[zljgphone],
	 @cwPeopleOld=[cwPeople],
	 @cwphoneOld=[cwphone],
	 @zlglPeopleOld=[zlglPeople],
	 @zlglphoneOld=[zlglphone],
	 @storePeopleOld=[storePeople],
	 @storephoneOld=[storephone],
	 @refEntSeqNoOld=[refEntSeqNo],
	 @partnerSeqNoOld=[partnerSeqNo],
	 @legalpeopleOld=[legalpeople],          /*法人代表*/
     @legalphoneOld=[legalphone]            /*法人代表电话*/
     from clients
     WHERE ( [client_id]		= @client_id)

UPDATE #TCOld 
SET	 [serial_number]	= @serial_numberOld,
	 [name] 		= @nameOld,
	 [alias]			= @aliasOld,
	 [region_id]		= @region_idOld,
	 [phone_number] = @phone_numberOld,
	 [address]		= @addressOld,
	 [zipcode]		= @zipcodeOld,
	 [contact_personal]	= @contact_personalOld,
	 [tax_number]		= @tax_numberOld,
	 [acount_number]	= @acount_numberOld,
	 [credit_total] 	= @credit_totalOld,
	 [pinyin]			= @pinyinOld,
	 [pricemode]		= @pricemodeOld,
	 [sklimit]			= @sklimitOld,
	 [artotal_ini]		= @artotal_iniOld,
	 [aptotal_ini]		= @aptotal_iniOld,
	 [pre_artotal_ini]	= @pre_artotal_iniOld,
	 [pre_aptotal_ini]	= @pre_aptotal_iniOld,
	 [firstcheck]		= @firstcheckOld,
	 [comment]		= @commentOld,
	 [csflag]		= @csflagOld ,
	 [ceType]		= @ceTypeOld,
 	 [GspNo]		= @GSPNOOld,
	 [gmpno]		= @GMPNoOld,
	 [incRate]		= @incRateOld,
	 [Licence_no]		= @Licence_noOld,          	/*企业许可证*/
	 [Ent_type]		= @Ent_typeOld,          		/*所属类型*/
	 [City_id]		= @City_idOld,       		/*所属市区辖区编码*/
	 [City_name]		= @City_nameOld,         		/*所属市区辖区*/
	 [boro_id]		= @boro_idOld,         		/*所属县区辖区编码*/
	 [boro_name]		= @boro_nameOld,         		/*所属县区辖区*/
	 [e_id]                 = @e_idOld,
	 [createDate]	        = @createDateOld, 
	 [C_Customname1]	= @C_Customname1Old,                /*自定义属性1*/
	 [C_Customname2]        = @C_Customname2Old,                /*自定义属性2*/
	 [C_Customname3]	= @C_Customname3Old,               /*自定义属性3*/
   	 [C_Customname4]	= @C_Customname4Old,                /*自定义属性4*/
  	 [C_Customname5]        = @C_Customname5Old,                /*自定义属性5*/
 	 [clienttype_id]        = @clienttype_idOld,                /*客户类型ID*/
	 [card_ID]              = @cardIDOld,                        /*会员卡ID*/
	 [consignBook_no]       = @consignBook_noOld,             /*委托书编号*/
	 [organCard_no]         = @organCard_noOld,                /*组织机构证书编号*/
	 [BusinessLicence_no]   = @BusinessLicence_noOld,         /*营业执照编号  TT*/
	 [MassConfer_no]        = @MassConfer_noOld,
	 [Cer_CustomNO1]        = @Cer_CustomNO1Old,
	 [Cer_CustomNO2]        = @Cer_CustomNO2Old,
	 [Cer_CustomNO3]        = @Cer_CustomNO3Old,
	 [Cer_CustomNO4]        = @Cer_CustomNO4Old,
	 [Cer_CustomNO5]        = @Cer_CustomNO5Old,
	 [ByWayDay]				= @ByWayDayOld, 
	 [RoadID]               = @RoadlineOld,
	 [szOrdernum]           = @RoadOrderOld,  
	 [OrderCredit]          = @OrderCreditOld,
	 [discount]             = @discountOld,
	 ElecCode               = @ElecCodeOld,
	 AddressZC              = @AddressZCOld,
	 Quality_Personal       = @Quality_PersonalOld,
	 Quality_Phone          = @Quality_PhoneOld,
	 QQ                     = @QQOld,
	 ModifyEId              = @ModifyEIdOld,
	 [Cer_CustomNO6]        = @Cer_CustomNO6Old,
	 [Cer_CustomNO7]        = @Cer_CustomNO7Old,
	 [Cer_CustomNO8]        = @Cer_CustomNO8Old,
	 [Cer_CustomNO9]        = @Cer_CustomNO9Old,
	 [Cer_CustomNO10]        = @Cer_CustomNO10Old,
	 [zljgPeople]=@zljgPeopleOld,
	 [zljgphone]=@zljgphoneOld,
	 [cwPeople]=@cwPeopleOld,
	 [cwphone]=@cwphoneOld,
	 [zlglPeople]=@zlglPeopleOld,
	 [zlglphone]=@zlglphoneOld,
	 [storePeople]=@storePeopleOld,
	 [storephone]=@storephoneOld,
	 [refEntSeqNo]	= @refEntSeqNoOld,
	 [partnerSeqNo] = @partnerSeqNoOld,
	 [legalpeople] = @legalpeopleOld,          /*法人代表*/
     [legalphone] = @legalphoneOld            /*法人代表电话*/

WHERE 
	( [client_id]		= @client_id)
	
UPDATE #TC 
SET	 [serial_number]	= @serial_number,
	 [name] 		= @name,
	 [alias]			= @alias,
	 [region_id]		= @region_id,
	 [phone_number] = @phone_number,
	 [address]		= @address,
	 [zipcode]		= @zipcode,
	 [contact_personal]	= @contact_personal,
	 [tax_number]		= @tax_number,
	 [acount_number]	= @acount_number,
	 [credit_total] 	= @credit_total,
	 [pinyin]			= @pinyin,
	 [pricemode]		= @pricemode,
	 [sklimit]			= @sklimit,
	 [artotal_ini]		= @artotal_ini,
	 [aptotal_ini]		= @aptotal_ini,
	 [pre_artotal_ini]	= @pre_artotal_ini,
	 [pre_aptotal_ini]	= @pre_aptotal_ini,
	 [firstcheck]		= @firstcheck,
	 [comment]		= @comment,
	 [csflag]		= @csflag ,
	 [ceType]		= @ceType,
 	 [GspNo]		= @GSPNO,
	 [gmpno]		= @GMPNo,
	 [incRate]		= @incRate,
	 [Licence_no]		= @Licence_no,          	/*企业许可证*/
	 [Ent_type]		= @Ent_type,          		/*所属类型*/
	 [City_id]		= @City_id,       		/*所属市区辖区编码*/
	 [City_name]		= @City_name,         		/*所属市区辖区*/
	 [boro_id]		= @boro_id,         		/*所属县区辖区编码*/
	 [boro_name]		= @boro_name,         		/*所属县区辖区*/
	 [e_id]                 = @e_id,
	 [createDate]	        = @createDate, 
	 [C_Customname1]	= @C_Customname1,                /*自定义属性1*/
	 [C_Customname2]        = @C_Customname2,                /*自定义属性2*/
	 [C_Customname3]	= @C_Customname3,               /*自定义属性3*/
   	 [C_Customname4]	= @C_Customname4,                /*自定义属性4*/
  	 [C_Customname5]        = @C_Customname5,                /*自定义属性5*/
 	 [clienttype_id]        = @clienttype_id,                /*客户类型ID*/
	 [card_ID]              = @cardID,                        /*会员卡ID*/
	 [consignBook_no]       = @consignBook_no,             /*委托书编号*/
	 [organCard_no]         = @organCard_no,                /*组织机构证书编号*/
	 [BusinessLicence_no]   = @BusinessLicence_no,         /*营业执照编号  TT*/
	 [MassConfer_no]        = @MassConfer_no,
	 [Cer_CustomNO1]        = @Cer_CustomNO1,
	 [Cer_CustomNO2]        = @Cer_CustomNO2,
	 [Cer_CustomNO3]        = @Cer_CustomNO3,
	 [Cer_CustomNO4]        = @Cer_CustomNO4,
	 [Cer_CustomNO5]        = @Cer_CustomNO5,
	 [ByWayDay]				= @ByWayDay, 
	 [RoadID]               = @Roadline,
	 [szOrdernum]           = @RoadOrder,  
	 [OrderCredit]          = @OrderCredit,
	 [discount]             = @discount,
	 ElecCode               = @ElecCode,
	 AddressZC = @AddressZC,
	 Quality_Personal       = @Quality_Personal,
	 Quality_Phone          = @Quality_Phone,
	 QQ                     = @QQ,
	 ModifyEId              = @ModifyEId,
	 [Cer_CustomNO6]        = @Cer_CustomNO6,
	 [Cer_CustomNO7]        = @Cer_CustomNO7,
	 [Cer_CustomNO8]        = @Cer_CustomNO8,
	 [Cer_CustomNO9]        = @Cer_CustomNO9,
	 [Cer_CustomNO10]        = @Cer_CustomNO10,
	 [zljgPeople]=@zljgPeople,
	 [zljgphone]=@zljgphone,
	 [cwPeople]=@cwPeople,
	 [cwphone]=@cwphone,
	 [zlglPeople]=@zlglPeople,
	 [zlglphone]=@zlglphone,
	 [storePeople]=@storePeople,
	 [storephone]=@storephone,
	 [refEntSeqNo]	= @refEntSeqNo,
	 [partnerSeqNo] = @partnerSeqNo,
	 [legalpeople] = @legalpeople,          /*法人代表*/
     [legalphone] = @legalphone            /*法人代表电话*/

WHERE 
	( [client_id]		= @client_id)

	if @@ERROR <> 0
	begin
		set @client_id = -@client_id
		return -1
	end

	INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,OldContent)
	SELECT @client_id, 'C', (SELECT * FROM #TC AS clients FOR XML AUTO, TYPE, ROOT), 1,(SELECT * FROM #TCOld AS clients FOR XML AUTO, TYPE, ROOT)

	DROP TABLE #TC
    DROP TABLE #TCOld
    
	SELECT TOP 0 * 
	INTO #TCB
	FROM Clientsbalance

	INSERT #TCB(Y_id,C_ID,credit_total,APcredit_total,sklimit,artotal,artotal_ini,aptotal,aptotal_ini,pre_artotal,
	                 pre_artotal_ini,pre_aptotal,pre_aptotal_ini,e_id, BalanceMode)
	  VALUES(@Y_id,@client_id,@credit_total,@APcredit_total,@sklimit,0,@artotal_ini,0,@aptotal_ini,0,
	                 @pre_artotal_ini,0,@pre_aptotal_ini,@e_id, @BalanceMode)
	                 
	SELECT TOP 0 * 
	INTO #TCBOld
	FROM Clientsbalance

	INSERT #TCBOld(Y_id,C_ID,credit_total,APcredit_total,sklimit,artotal,artotal_ini,aptotal,aptotal_ini,pre_artotal,
	                 pre_artotal_ini,pre_aptotal,pre_aptotal_ini,e_id, BalanceMode)
	  VALUES(@Y_idOld,@client_idOld,@credit_totalOld,@APcredit_totalOld,@sklimitOld,0,@artotal_iniOld,0,@aptotal_iniOld,0,
	                 @pre_artotal_iniOld,0,@pre_aptotal_iniOld,@e_idOld, @BalanceModeOld)
	
	INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,OldContent)
	SELECT @client_id, 'CB', (SELECT * FROM #TCB AS Clientsbalance FOR XML AUTO, TYPE, ROOT), 1, (SELECT * FROM #TCBOld AS Clientsbalance FOR XML AUTO, TYPE, ROOT)
	DROP TABLE #TCB
    DROP TABLE #TCBOld

    if @Ent_type=1 
    begin
 		SELECT TOP 0 * 
		INTO #TAC
		FROM accountcomment

		insert into #TAC(AccountComment,pinyin)
		values(@name,@pinyin)
        
        SELECT TOP 0 * 
		INTO #TACOld
		FROM accountcomment

		insert into #TACOld(AccountComment,pinyin)
		values(@nameOld,@pinyinOld)
		
		INSERT INTO BaseInfoHistory(BaseInfo_ID, BaseInfoType, NewContent, BaseInfoTag,OldContent)
		SELECT @client_id, 'AC', (SELECT * FROM #TAC AS accountcomment FOR XML AUTO, TYPE, ROOT), 1,(SELECT * FROM #TACOld AS accountcomment FOR XML AUTO)
		DROP TABLE #TAC
		DROP TABLE #TACOld
	end
GO
