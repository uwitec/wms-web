

CREATE TRIGGER TriggerInsAccount ON [dbo].[account]
FOR INSERT
AS
declare @Aid int,@szClassid varchar(36)
select @aid=Account_id,@szClassid=Parent_id from inserted
if left(@szClassid,12)='000001000004'
  Update Account set sysflag=1 where Account_id=@aid
GO
