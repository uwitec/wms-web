

CREATE	VIEW dbo.vw_c_buymb
AS
SELECT mx.smb_id,mx.bill_id,mx.p_id,mx.batchno,mx.quantity,mx.costprice,mx.buyprice,mx.discount,
mx.discountprice,mx.totalmoney,mx.taxprice,mx.taxtotal,mx.taxmoney,mx.retailprice,mx.retailtotal,
mx.makedate,mx.validdate,mx.qualitystatus,mx.price_id,mx.ss_id,mx.sd_id,mx.location_id,mx.supplier_id,
mx.commissionflag,mx.comment,mx.unitid,mx.taxrate,mx.order_id,mx.total,mx.iotag,mx.InvoiceTotal,
mx.thqty,mx.newprice,mx.orgbillid,mx.invoice,mx.invoiceno,mx.AOID,mx.jsprice,mx.PriceType,mx.SendQTY,
mx.SendCostTotal,mx.RowGuid,mx.RowE_id,mx.YCostPrice,mx.YGuid,mx.Y_ID,mx.transflag,mx.instoretime,mx.comment2,
mx.BatchBarCode,mx.scomment,mx.batchprice,mx.Conclusion,mx.factoryid,mx.costtaxrate,mx.costtaxprice,
mx.costtaxtotal,mx.bm_SMID,
ISNULL(P.[Name]  ,'') AS [PName],         
ISNULL(P.[Class_ID]  ,'') AS [PClass_ID],
isnull(storages_2.class_id,'') AS ssclass_id, 
isnull(storages_1.class_id,'') AS sdclass_id, 
isnull(storages_2.name,'') AS ssname, 
isnull(storages_1.name,'') AS sdname,
isnull(u.name,'') as unitname,
isnull(l.loc_name,'') as locname,
isnull(c.[name],'') as suppliername,
isnull(E.class_id,'') as REclass_ID,
isnull(E.[name],'') as REname
FROM dbo.buymanagebill mx
      LEFT JOIN Products P  ON mx.[P_ID]=P.[Product_ID] 
      LEFT OUTER JOIN
      dbo.storages storages_1 ON 
      mx.sd_id = storages_1.storage_id LEFT OUTER JOIN
      dbo.storages storages_2 ON mx.ss_id = storages_2.storage_id
      LEFT OUTER JOIN
      unit u ON mx.unitid = u.unit_id
      LEFT OUTER JOIN
      location l on mx.location_id=l.loc_id
      LEFT OUTER JOIN
      clients c on mx.supplier_id=c.client_id
      LEFT OUTER JOIN
      employees E ON mx.RowE_id=E.emp_id
WHERE  mx.AOID=0
GO
