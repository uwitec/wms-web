

/****** 对象:  用户定义的函数 dbo.getstr    脚本日期: 2010-06-11 10:09:22 ******/
/*===================================*/
/*还有一个小问题，如传进去是一个空值则查不出数据*/
/*==================================*/
create function getstr(@str varchar(1000)) 
returns @t table(s varchar(30)) 
as 
begin
declare @iDotPos int
set @iDotPos = CHARINDEX(',', @str)
if @iDotPos=0 
begin
	insert into @t(s) values(@str)
	return
end
insert @t select substring(@str, number, charindex(',', @str + ',', number) - number) from 
master..spt_values where type='p' and substring(',' + @str, number,1) = ',' 
return 
end
GO
