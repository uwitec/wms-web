

CREATE proc ts_m_MerageRetail
( @BeginDate varchar(100),
  @EndDate varchar(100),
  @nFlag int,   /*1.按经手人合并 2.按制单人合并  3.按经手人制单人合并*/
  @nRet  int output
)
as
set nocount on

begin tran 

declare @billdate datetime ,@e_id int ,@ss_id int ,@billtype int,@a_id int,@posid int,@c_id int,@inputman int
declare @nNewBillId numeric(10,0),@szBillCode varchar(30)
declare @nCount int,@dtotalmoney numeric(25,8),@dtotalqty numeric(25,8),@dSsMoney numeric(25,8)
declare @dTaxRate numeric(5,2)
declare @newbillguid varchar(50)
declare @nP_id int,@nReturnNumber int,@nVchtype int,@Y_ID int

set @nret=-1

select @dTaxRate=0
exec ts_getsysvalue 'TaxRate',@dTaxRate out

select @Y_ID=CAST(sysvalue as int) from sysconfig where sysname='Y_ID'

if @nFlag in (1,3)  
  if exists(select top 1 b.billnumber from salemanagebill s 
	left join billidx b on b.billid=s.bill_id 
	where b.billdate between @BeginDate and @EndDate
	and b.billtype in (12,13) and b.billstates='0'
	and s.RowE_id<>b.e_id and s.p_id>0)
begin
  RAISERROR('单据明细中有经手人不相同,请选择"制单人相同合并"!!',16,1)
  goto preerror
end

/*转入到临时表*/
select 
b.billdate,b.billtype,b.e_id,b.inputman,b.a_id,b.guid,b.c_id,b.posid,
s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,s.validdate,s.ss_id,isnull(p.unit1_id,0) unit1_id,s.taxrate,s.aoid,s.instoretime,
isnull(sum(s.quantity),0)		  as quantity,
isnull(sum(s.totalmoney),0)		as totalmoney,            /*折后税前金额*/
isnull(sum(s.retailtotal),0)	as retailtotal,
isnull(sum(s.taxmoney),0)		  as taxmoney,
isnull(sum(s.taxtotal),0)		  as taxtotal,
isnull(sum(s.total),0)			  as total                  /*折前金额*/
into #temptable1 from salemanagebill s  
left join billidx  b on b.billid=s.bill_id
left join products p on s.p_id=p.product_id
where b.billdate between @BeginDate and @EndDate
and  b.billtype in (12,13) and b.billstates='0'
group by 
b.billdate,b.billtype,b.e_id,b.inputman,b.a_id,b.guid,b.c_id,b.posid,
s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,s.makedate,s.validdate,s.ss_id,p.unit1_id,s.taxrate,s.aoid,s.instoretime

/*写入待删零售单*/
select billid into #DeleteBill from billidx b
where b.billdate between @BeginDate and @EndDate and b.billtype in (12,13) and b.billstates='0'

if not exists(select top 1 * from #temptable1)
begin
  RAISERROR('没有零售单可以合并.',16,1)
  goto preerror
end

if @nFlag=1/* by e_id*/
begin
  select @nCount=1

  declare mergebill cursor for
  select distinct billdate,e_id,ss_id,billtype,a_id,c_id,posid
  from #temptable1
  where p_id>0
  order by billdate,billtype,e_id
 
  open mergebill
  fetch next from mergebill into @billdate,@e_id,@ss_id,@billtype,@a_id,@c_id,@posid

  while @@fetch_status=0
  begin
    select 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime,
    isnull(sum(quantity),0)		  as quantity,
    isnull(sum(totalmoney),0)		as totalmoney,            /*折后税前金额*/
    isnull(sum(retailtotal),0)	as retailtotal,
    isnull(sum(taxmoney),0)		  as taxmoney,
    isnull(sum(taxtotal),0)		  as taxtotal,
    isnull(sum(total),0)			  as total                  /*折前金额*/
    into #temptable2 from #temptable1 
    where billdate=@billdate and e_id=@e_id and (ss_id=@ss_id or ss_id=0) and billtype=@billtype and a_id=@a_id and c_id=@c_id and posid=@posid
    group by 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime
    if @@rowcount=0 goto error

    if @billtype=12 set @szBillCode='LS' else set @szBillCode='LT'
	select @szBillCode=@szBillCode+'-'+convert(varchar(10),@billdate,21)+'-'+right(cast(10000+@nCount as varchar(5)),4)/*单据编号*/
    
    set @dtotalmoney=0
    set @dtotalqty=0
    set @dSsMoney=0 

	select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
	from #temptable2
	where p_id>0/*不计算多帐户收款*/
    and aoid=0

    select @dSsMoney=isnull(sum(total),0) /*统计多帐户收款金额*/
    from #temptable2
    where p_id<0
    
    set @dSsMoney=@dtotalmoney-@dSsmoney

	insert billidx (billdate,auditdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,jsflag,
		inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid,note,Y_ID)
		values(@billdate,@billdate,@szBillCode,@billtype,@a_id,@c_id,@e_id,@ss_id,@ss_id,'0',
		@e_id,@dtotalmoney,@dSsMoney,@dtotalqty,@dTaxRate,'0',@posid,'按经手人相同合并',@Y_ID)
    if @@rowcount=0 goto error

    set @nnewbillid=@@identity

	insert into salemanagebill
		(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
		 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
		 taxrate,total,unitid,aoid,Y_ID,YGuid,SendQTY,SendCostTotal,instoretime,RowE_id,thqty)
	select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity,case when aoid=0 then totalmoney/total else 0 end,totalmoney/quantity, 
		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
		validdate,'合格',0,ss_id,location_id,supplier_id,commissionflag,
    taxrate,total,unit1_id,aoid,@Y_ID,NEWID(),quantity,(quantity*costprice),instoretime,@e_id,quantity
		from #temptable2 where p_id>0
    if @@rowcount=0 goto error
    
	insert into salemanagebill
	(bill_id,p_id,total,batchno,quantity,Y_ID,YGuid)
	select @nnewbillid,p_id,total,'',0,@Y_ID,NEWID()
	from #temptable2 where p_id<0
 
	select @nCount=@nCount+1
    drop table #temptable2  
    
	insert into salemanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType)
    select bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType
	from salemanagebill where bill_id=@nNewBillId
    
	exec @nReturnNumber=ts_c_CreatePDetail @nnewbillid /*产生商品明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	update productdetail set costtotal=(costprice*quantity) where billid=@nnewbillid
		
	exec @nReturnNumber=ts_c_CreateADetail @nnewbillid /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error 
	
	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
         
    fetch next from mergebill  into @billdate,@e_id,@ss_id,@billtype,@a_id,@c_id,@posid
  end

  goto success
end

if @nFlag=2/* by inputman*/
begin
  select @nCount=1

  declare mergebill cursor for
  select distinct billdate,inputman,ss_id,billtype,a_id,c_id,posid
  from #temptable1 
  where p_id>0
  order by billdate,billtype,inputman
 
  open mergebill
  fetch next from mergebill  into @billdate,@inputman,@ss_id,@billtype,@a_id,@c_id,@posid

  while @@fetch_status=0
  begin
    select 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime,
    isnull(sum(quantity),0)		  as quantity,
    isnull(sum(totalmoney),0)		as totalmoney,            /*折后税前金额*/
    isnull(sum(retailtotal),0)	as retailtotal,
    isnull(sum(taxmoney),0)		  as taxmoney,
    isnull(sum(taxtotal),0)		  as taxtotal,
    isnull(sum(total),0)			  as total                  /*折前金额*/
    into #temptable3 from #temptable1 
    where billdate=@billdate and inputman=@inputman and (ss_id=@ss_id or ss_id=0) and billtype=@billtype and a_id=@a_id and c_id=@c_id and posid=@posid
    group by 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime
    if @@rowcount=0 goto error
    
    if @billtype=12 set @szBillCode='LS' else set @szBillCode='LT'
	select @szBillCode=@szBillCode+'-'+convert(varchar(10),@billdate,21)+'-'+right(cast(10000+@nCount as varchar(5)),4)/*单据编号*/
    

	select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
	from #temptable3
	where p_id>0/*不计算多帐户收款*/
    and aoid=0

    select @dSsMoney=isnull(sum(total),0) /*统计多帐户收款收款金额*/
    from #temptable3
    where p_id<0

    set @dSsMoney=@dtotalmoney-@dSsmoney

	insert billidx (billdate,auditdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,jsflag,
		inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid,note,Y_ID)
	values(@billdate,@billdate,@szBillCode,@billtype,@a_id,@c_id,@inputman,@ss_id,@ss_id,'0',
		@inputman,@dtotalmoney,@dSsMoney,@dtotalqty,@dTaxRate,'0',@posid,'按制单人相同合并',@Y_ID)
    if @@rowcount=0 goto error

    set @nnewbillid=@@identity

	insert into salemanagebill
		(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
		 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
		 taxrate,total,unitid,aoid,Y_ID,YGuid,SendQTY,SendCostTotal,instoretime,RowE_id,thqty)
	select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity,case when aoid=0 then totalmoney/total else 0 end,totalmoney/quantity, 
		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
		validdate,'合格',0,ss_id,location_id,supplier_id,commissionflag,
    taxrate,total,unit1_id,aoid,@Y_ID,NEWID(),quantity,(quantity*costprice),instoretime,@inputman,quantity
	from #temptable3 
    where p_id>0
    if @@rowcount=0 goto error

	insert into salemanagebill
	(bill_id,p_id,total,batchno,quantity,Y_ID,YGuid)
	select @nnewbillid,p_id,total,'',0,@Y_ID,NEWID()
	from #temptable3 
    where p_id<0
          
	select @nCount=@nCount+1
    drop table #temptable3   
    
	insert into salemanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType)
    select bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType
	from salemanagebill where bill_id=@nNewBillId
    
	exec @nReturnNumber=ts_c_CreatePDetail @nnewbillid /*产生商品明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	update productdetail set costtotal=(costprice*quantity) where billid=@nnewbillid

	exec @nReturnNumber=ts_c_CreateADetail @nnewbillid /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error 
	
	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
    fetch next from mergebill into @billdate,@inputman,@ss_id,@billtype,@a_id,@c_id,@posid
  end

  goto success
end

if @nFlag=3/* by e_id and inputman*/
begin
  select @nCount=1
  
  declare mergebill cursor for
  select distinct billdate,e_id,inputman,ss_id,billtype,a_id,c_id,posid
  from #temptable1
  where p_id>0
  order by billdate,billtype,e_id,inputman
 
  open mergebill
  fetch next from mergebill  into @billdate,@e_id,@inputman,@ss_id,@billtype,@a_id,@c_id,@posid

  while @@fetch_status=0
  begin
    select 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime,
    isnull(sum(quantity),0)		  as quantity,
    isnull(sum(totalmoney),0)		as totalmoney,            /*折后税前金额*/
    isnull(sum(retailtotal),0)	as retailtotal,
    isnull(sum(taxmoney),0)		  as taxmoney,
    isnull(sum(taxtotal),0)		  as taxtotal,
    isnull(sum(total),0)			  as total                  /*折前金额*/
    into #temptable4 from #temptable1 
    where billdate=@billdate and e_id=@e_id and inputman=@inputman and (ss_id=@ss_id or ss_id=0) and billtype=@billtype and a_id=@a_id and c_id=@c_id and posid=@posid
    group by 
    p_id,batchno,costprice,location_id,supplier_id,commissionflag,makedate,validdate,ss_id,unit1_id,taxrate,aoid,instoretime
    
    if @billtype=12 set @szBillCode='LS' else set @szBillCode='LT'
		select @szBillCode=@szBillCode+'-'+convert(varchar(10),@billdate,21)+'-'+right(cast(10000+@nCount as varchar(5)),4)/*单据编号*/
    

	select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
	from #temptable4
	where p_id>0/*不计算多帐户收款*/
    and aoid=0

    select @dSsMoney=isnull(sum(total),0) /*统计多帐户收款收款金额*/
    from #temptable4
    where p_id<0

    set @dSsMoney=@dtotalmoney-@dSsmoney

	insert billidx (billdate,auditdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,jsflag,
		inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid,note,Y_ID)
	values(@billdate,@billdate,@szBillCode,@billtype,@a_id,@c_id,@e_id,@ss_id,@ss_id,'0',
		@inputman,@dtotalmoney,@dSsMoney,@dtotalqty,@dTaxRate,'0',@posid,'按经手人制单人相同合并',@Y_ID)
    if @@rowcount=0 goto error

    set @nnewbillid=@@identity
    
	insert into salemanagebill
		(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
		 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
		 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
		 taxrate,total,unitid,aoid,Y_ID,YGuid,SendQTY,SendCostTotal,instoretime,RowE_id,thqty)
	select @nnewbillid,p_id,batchno,quantity,costprice,total/quantity,case when aoid=0 then totalmoney/total else 0 end,totalmoney/quantity, 
		totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
		validdate,'合格',0,ss_id,location_id,supplier_id,commissionflag,
    taxrate,total,unit1_id,aoid,@Y_ID,NEWID(),quantity,(quantity*costprice),instoretime,@e_id,quantity
	from #temptable4 
    where p_id>0
    if @@rowcount=0 goto error

	insert into salemanagebill
	(bill_id,p_id,total,batchno,quantity,Y_ID,YGuid)
	select @nnewbillid,p_id,total,'',0,@Y_ID,NEWID()
	from #temptable4 
    where p_id<0
          
	select @nCount=@nCount+1
    drop table #temptable4 
        
	insert into salemanagebilltmp(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType)
    select bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
	       totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
	       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
	       comment,unitid,taxrate,order_id,total,iotag,invoicetotal,thqty,newprice,orgbillid,jsprice,aoid,smb_id,
	       SendQTY,SendCostTotal,PriceType, RowGuid, RowE_id, YCostPrice, YGUID, Y_ID, InStoreTime, cxType
	from salemanagebill where bill_id=@nNewBillId
    
	exec @nReturnNumber=ts_c_CreatePDetail @nnewbillid /*产生商品明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	update productdetail set costtotal=(costprice*quantity) where billid=@nnewbillid

	exec @nReturnNumber=ts_c_CreateADetail @nnewbillid /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error 
	
	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
  
    fetch next from mergebill  into @billdate,@e_id,@inputman,@ss_id,@billtype,@a_id,@c_id,@posid
  end

  goto success
end


success:
  close mergebill
  deallocate mergebill
  
  /*写vipdetail*/
  INSERT INTO [VipDetail]
	   ([Billid],[BillDate],[CardID],[P_ID],[POS_ID],[Quantity],[Price],[Total],[Guid],[costtotal],
	   [discounttotal],[integral],[aoid],[Y_ID],[BillGuid],[billnumber],[billtype],[ysmoney],[e_id])
   SELECT b.billid,b.billdate,b.VIPCardID,s.p_id,b.posid,s.quantity,s.taxprice,s.taxtotal,b.GUID,(s.costprice*s.quantity),
	   (s.discountprice*s.quantity),b.integral,s.AOID,b.Y_ID,b.GUID,b.billnumber,b.billtype,b.ysmoney,s.RowE_id
   FROM salemanagebill s left join billidx b on s.bill_id=b.billid 
   WHERE b.billdate between @BeginDate and @EndDate and b.billtype in (12,13) 
   and b.VIPCardID<>0 and s.p_id>0 and b.billstates='0' 
      

  /*删除原零售单*/
  delete salemanagebill where bill_id in (select billid from #DeleteBill)
  delete billidx where billid in (select billid from #DeleteBill)
  delete AccountDetail where billid in (select billid from #DeleteBill)
  delete productdetail where billid in (select billid from #DeleteBill)  
  
  commit tran 
  
  set @nret=0
  return 0
  
error:
  close mergebill
  deallocate mergebill
  rollback tran
  set @nret=-1
  RAISERROR('单据合并失败.',16,1)
  return -1
  
preerror:
  set @nret=-1
  rollback tran
  RAISERROR('单据合并失败.',16,1)
  return -1
GO
