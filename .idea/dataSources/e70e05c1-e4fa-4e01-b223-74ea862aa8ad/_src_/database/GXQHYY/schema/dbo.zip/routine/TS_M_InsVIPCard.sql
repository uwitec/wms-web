
CREATE PROCEDURE TS_M_InsVIPCard
(
    @Tag	       int =0, 		/*0:新增 1:修改 2 :修改状态[删除,挂失,停用]  	*/
    @VIPCardID         int =0,	
    @Deleted	       int =0,		
    @Lose	       int =0,
    @StopUse	       int =0,
    @CardNo            varchar(60)='',
    @Name              varchar(20)='',
    @sex               varchar(10)='',
    @Tel               varchar(80)='',
    @Birthday          datetime=0,
    @Address           varchar(60)='',
    @Comment           varchar(300)='',
    @IDCard            varchar(20)='',
    @CT_ID             int=0,
    @BulidDate         datetime=0,
    @ValidityDate      datetime=0,
    @Y_Id             int=0,
    @E_id              int=0,
    @IniMoney          numeric(25,8)=0,
    @TotalBuyMoney     numeric(25,8)=0,
    @SaveMoney         numeric(25,8)=0,
    @IntergralYE       numeric(25,8)=0,
    @IniIntergral      numeric(25,8)=0,
    @Integral          int=0,
    @SwapIntegral      int=0,
    @BuyCount          int=0,
    @RemainderMoney    numeric(25,8)=0,
    @PinYin            varchar(20)='',
    @LoginPass         int=0,
    @islock            int=0,
    @Pos_Id            int=0,/*改为分公司后，门店ID默认为0。*/
	@code1				varchar(50) = '',  /*助记码1*/
	@code2				varchar(50) = '', /*助记码2*/
	@code3				varchar(50) = '', /*助记码3*/
	@birthDay2			varchar(20) = '', /*生日(农历)(自动计算)*/
	@height				numeric(25,8) = 0,    /*单位cm 身高*/
	@weight				numeric(25,8) = 0,    /*kg 体重*/
	@bloodtype			varchar(20) = '', /*血型*/
	@QQ					varchar(20) = '',    /*QQ号*/
	@Email				varchar(50) = '',  /*E_mail*/
	@Education			varchar(50) = '',  /*学历*/
	@SocialNO			varchar(60) = '',  /*社保号	*/
	@IntroducerID       int = 0, /*介绍人ID	*/
	@RetailHint         varchar(1000) = '' /*零售提示*/
)
AS
/*Params Ini begin*/
if @Tag is null  SET @Tag = 0
if @VIPCardID is null  SET @VIPCardID = 0
if @Deleted is null  SET @Deleted = 0
if @Lose is null  SET @Lose = 0
if @StopUse is null  SET @StopUse = 0
if @CardNo is null  SET @CardNo = ''
if @Name is null  SET @Name = ''
if @sex is null  SET @sex = ''
if @Tel is null  SET @Tel = ''
if @Birthday is null  SET @Birthday = 0
if @Address is null  SET @Address = ''
if @Comment is null  SET @Comment = ''
if @IDCard is null  SET @IDCard = ''
if @CT_ID is null  SET @CT_ID = 0
if @BulidDate is null  SET @BulidDate = 0
if @ValidityDate is null  SET @ValidityDate = 0
if @Y_Id is null  SET @Y_Id = 0
if @E_id is null  SET @E_id = 0
if @IniMoney is null  SET @IniMoney = 0
if @TotalBuyMoney is null  SET @TotalBuyMoney = 0
if @SaveMoney is null  SET @SaveMoney = 0
if @IntergralYE is null  SET @IntergralYE = 0
if @IniIntergral is null  SET @IniIntergral = 0
if @Integral is null  SET @Integral = 0
if @SwapIntegral is null  SET @SwapIntegral = 0
if @BuyCount is null  SET @BuyCount = 0
if @RemainderMoney is null  SET @RemainderMoney = 0
if @PinYin is null  SET @PinYin = ''
if @LoginPass is null  SET @LoginPass = 0
if @islock is null  SET @islock = 0
if @Pos_Id is null  SET @Pos_Id = 0
if @code1 is null  SET @code1 = ''
if @code2 is null  SET @code2 = ''
if @code3 is null  SET @code3 = ''
if @birthDay2 is null  SET @birthDay2 = ''
if @height is null  SET @height = 0
if @weight is null  SET @weight = 0
if @bloodtype is null  SET @bloodtype = ''
if @QQ is null  SET @QQ = ''
if @Email is null  SET @Email = ''
if @Education is null  SET @Education = ''
if @SocialNO is null  SET @SocialNO = ''
if @IntroducerID is null SET @IntroducerID = 0
if @RetailHint is null SET @RetailHint = ''

/*Params Ini end*/
/*0:新增 */


    /*--消除TAB键*/
    set @CardNo = REPLACE(@CardNo,CHAR(9),'')
    set @Name = REPLACE(@Name,CHAR(9),'')
    set @Tel = REPLACE(@Tel,CHAR(9),'')
    set @Address = REPLACE(@Address,CHAR(9),'')
    set @Comment = REPLACE(@Comment,CHAR(9),'')
    set @IDCard = REPLACE(@IDCard,CHAR(9),'')
    set @RetailHint = REPLACE(@RetailHint, CHAR(9), '')
    
    /*消除空格键*/
    set @Comment = REPLACE(@Comment,' ','')    
    set @Address = REPLACE(@Address,' ','')  
    set @RetailHint = REPLACE(@RetailHint, ' ', '')
    
    /*--判断非法字符*/
    if((CHARINDEX('*',@CardNo) > 0) or (CHARINDEX('/',@CardNo)>0) or (CHARINDEX('?',@CardNo)>0) 
    or (CHARINDEX('#',@CardNo)>0) or (CHARINDEX(' ',@CardNo)>0)) 
    begin
      Raiserror('会员卡编号不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end
    if((CHARINDEX('*',@Name) > 0) or (CHARINDEX('/',@Name)>0) or (CHARINDEX('?',@Name)>0) 
    or (CHARINDEX('#',@Name)>0) or (CHARINDEX(' ',@Name)>0)) 
    begin
      Raiserror('会员姓名不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end
    if((CHARINDEX('*',@Tel) > 0) or (CHARINDEX('/',@Tel)>0) or (CHARINDEX('?',@Tel)>0) 
    or (CHARINDEX('#',@Tel)>0) or (CHARINDEX(' ',@Tel)>0)) 
    begin
      Raiserror('联系电话不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end
    if((CHARINDEX('*',@Address) > 0) or (CHARINDEX('/',@Address)>0) or (CHARINDEX('?',@Address)>0) 
    or (CHARINDEX('#',@Address)>0) or (CHARINDEX(' ',@Address)>0)) 
    begin
      Raiserror('联系地址不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end
    if((CHARINDEX('*',@Comment) > 0) or (CHARINDEX('/',@Comment)>0) or (CHARINDEX('?',@Comment)>0) 
    or (CHARINDEX('#',@Comment)>0) or (CHARINDEX(' ',@Comment)>0)) 
    begin
      Raiserror('备注不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end
    if((CHARINDEX('*',@PinYin) > 0) or (CHARINDEX('/',@PinYin)>0) or (CHARINDEX('?',@PinYin)>0) 
    or (CHARINDEX('#',@PinYin)>0) or (CHARINDEX(' ',@PinYin)>0)) 
    begin
      Raiserror('拼音码不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end               
    if((CHARINDEX('*',@RetailHint) > 0) or (CHARINDEX('/',@RetailHint)>0) or (CHARINDEX('?',@RetailHint)>0) 
    or (CHARINDEX('#',@RetailHint)>0) or (CHARINDEX(' ',@RetailHint)>0)) 
    begin
      Raiserror('零售提示不允许存在以下字符：*,/,?,#,'' '' ',16,1)
        RETURN -1
    end   

IF @Tag=0 
BEGIN
    Declare @NewID int

    IF exists(select VIPcardid from Vipcard where VIPcardid=@VIPCardID)
    begin
       RETURN @VIPCardID
    end
            

    IF EXISTS (SELECT TOP 1 * FROM  VIPCard WHERE CardNo=@CardNo and deleted =0)
    BEGIN
	Raiserror('会员卡编号重复！',16,1)
        RETURN -1
    END
  
    
    IF  @VIPCardID<=0 
    select @NewID=IsNull(Max(VIPCardID),0)+1 from VIPCard
    else
    select @NewID=@VIPCardID
   


    INSERT INTO VIPCard(VIPCardID,
                        CardNo,
                        [Name],
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
                        IniMoney,
                        TotalBuyMoney,
                        SaveMoney,
                        IntergralYE,
                        IniIntergral,
                        Integral,
                        SwapIntegral,
                        BuyCount,
                        LoginPass,
			Deleted,
			Lose,
			StopUse,
			RemainderMoney,
                        PinYin,
                        islock,
                        Y_id,
						code1,		
						code2,		
						code3,		
						birthDay2,	
						height,		
						[weight],		
						bloodtype,	
						QQ,			
						Email,		
						Education,	
						SocialNO,						
						IntroducerID, 						
	                    RetailHint	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                        )

    VALUES(@NewID,
           @CardNo,
           @Name,
           @sex,
           @Tel,
           @Birthday,
           @Address,
           @Comment,
           @IDCard,
           @CT_ID,
           @BulidDate,
           @ValidityDate,
           @Pos_Id,
           @E_id,
           @IniMoney,
           @TotalBuyMoney,
           @SaveMoney,
           @IntergralYE,
           @IniIntergral,
           @Integral,
           @SwapIntegral,
           @BuyCount,
           @LoginPass,
	   @Deleted,		
       @Lose,
       @StopUse,	
	   @RemainderMoney,
           @PinYin,
           0,
           @Y_id,
			@code1,		
			@code2,		
			@code3,		
			@birthDay2,	
			@height,		
			@weight,		
			@bloodtype,	
			@QQ,			
			@Email,		
			@Education,	
			@SocialNO,			
			@IntroducerID,	       
	        @RetailHint	                                                                                                                                                                                                                            
           )
    IF (@@error!=0)
    BEGIN
        raiserror('新增会员卡资料失败!',16,1)
        /*RAISERROR(20000,'新增会员卡资料失败! ') */
	RETURN -1  
    END
    ELSE
    BEGIN 
    RETURN @NewID
    END
END
/*1:修改 */
IF @Tag=1
BEGIN

    UPDATE VIPCard SET  CardNo=@CardNo,
                        [Name]=@Name,
                        sex=@sex,
                        Tel=@Tel,
                        Birthday=@Birthday,
                        Address=@Address,
                        Comment=@Comment,
                        IDCard=@IDCard,
                        CT_ID=@CT_ID,
                        BulidDate=@BulidDate,
                        ValidityDate=@ValidityDate,
                        Pos_Id=@Pos_Id,
                        E_id=@E_id,
                        PinYin=@PinYin,
                        LoginPass=@LoginPass,
                        Y_id=@Y_id,
                        code1=	    @code1,		   	
						code2=		@code2,		
						code3=		@code3,		
						birthDay2=	@birthDay2,	
						height=		@height,	
						[weight]=	@weight,		
						bloodtype=	@bloodtype,	
						QQ=			@QQ,		
						Email=		@Email,		
						Education=	@Education,	
						SocialNO=	@SocialNO,
						StopUse=    @StopUse,
						IntroducerID=@IntroducerID, 						
	                    RetailHint=@RetailHint	        	                                                                                                                                                                                                                                                                                                                                                                                                                        
   WHERE VIPCardID=@VIPCardID


    IF (@@error!=0)
    BEGIN
        raiserror('修改会员卡资料失败!',16,1)
        /*RAISERROR  20000 '修改会员卡资料失败! ' */
	RETURN -1  
    END
    ELSE  RETURN @VIPCardID
END

if @Tag=2 /*update billidx set order_id=vipcardid where billtype in (12,13,148,149)*/
begin
  if exists(select * from billidx where VipCardID=@VIPCardID and billtype in (12,13,148,149)) or
     exists(select * from billdraftidx where VipCardID=@VIPCardID and billtype in (12,13,148,149)) or
     exists(select * from billdtsidx where VipCardID=@VIPCardID and billtype in (12,13,148,149)) or
     exists(select * from retailbillidx where VipCardID=@VIPCardID and billtype in (12,13,148,149))
  begin
    raiserror('单据中已经使用此会员卡,不能删除',16,1)
    return -1
  end
  UPDATE VIPCard SET Deleted=1 
   WHERE VIPCardID=@VIPCardID 
end
/*停用  select * from vipcard*/
if @Tag = 3
begin
  UPDATE VIPCard SET StopUse=1 
   WHERE VIPCardID=@VIPCardID    
end
/*启用*/
if @Tag = 4
begin
  UPDATE VIPCard SET StopUse=0 
   WHERE VIPCardID=@VIPCardID 
   and StopUse <> 2 /*换卡停用的不能再启用   */
end
/*挂失*/
if @Tag = 5
begin
  UPDATE VIPCard SET Lose=1
   WHERE VIPCardID=@VIPCardID    
end
/*解挂*/
if @Tag = 6
begin
  UPDATE VIPCard SET Lose=0 
   WHERE VIPCardID=@VIPCardID    
end
/*锁定*/
if @Tag = 7
begin
  UPDATE VIPCard SET IsLock=1 
   WHERE VIPCardID=@VIPCardID    
end
/*解锁*/
if @Tag = 8
begin
  if exists(select * from VIPErrorRec where VIPCardID=@VIPCardID)
  begin
    declare @aCardNo varchar(30),
            @Msg varchar(50)
    select @aCardNo=CardNo from VIPCard where VIPCardID=@VIPCardID and Deleted=0
    set @Msg='会员卡【'+@aCardNo+'】有未确认操作,不能解除锁定!'
    raiserror(@Msg,16,1)
    return -1
  end
  UPDATE VIPCard SET IsLock=0 
   WHERE VIPCardID=@VIPCardID    
end
/*积分清零*/
if @Tag = 9 
begin
  UPDATE VIPCard SET Integral=0,IntergralYE=0,IniIntergral=0,SwapIntegral=0 
   WHERE VIPCardID=@VIPCardID    
end
/*从远端更新数据*/
if @tag =10
begin

/*客户数据莫名丢失，记录传入的数据，     */
/*Insert membercard(CardNo,[Name],[Tel],Address,Comment,CardType,Discount,BulidDate,ValidityDate,Lose,*/
  /*                StopUse,BuyTotal,BuyTotalPerDay,AutoDiscount,IDCard,Integral,Brithday,DiscountType,SaveTotal,intergraltotal,sex)*/
/*values(@CardNo,@Name, @Tel, @Address, @Comment,@CT_ID,0,@BulidDate, @ValidityDate,@Lose,*/
  /*-     @StopUse, @TotalBuyMoney,@BuyCount,0,@IDCard,@Integral,@Birthday,0,@SaveMoney,@Integral,@sex*/

delete from VipCard where VipCardID=@VipCardid

    INSERT INTO VIPCard(VIPCardID,
                        CardNo,
                        [Name],
                        sex,
                        Tel,
                        Birthday,
                        Address,
                        Comment,
                        IDCard,
                        CT_ID,
                        BulidDate,
                        ValidityDate,
                        Pos_Id,
                        E_id,
                        IniMoney,
                        TotalBuyMoney,
                        SaveMoney,
                        IntergralYE,
                        IniIntergral,
                        Integral,
                        SwapIntegral,
                        BuyCount,
                        LoginPass,
			Deleted,
			Lose,
			StopUse,
			RemainderMoney,
                        PinYin,
                        islock,
                        Y_id,
                        code1,		
						code2,		
						code3,		
						birthDay2,	
						height,		
						[weight],		
						bloodtype,	
						QQ,			
						Email,		
						Education,	
						SocialNO,						
						IntroducerID, 						
	                    RetailHint                                                                                                                                                                                                                                                                                                                      
                        )
    VALUES(@VipCardid,
           @CardNo,
           @Name,
           @sex,
           @Tel,
           @Birthday,
           @Address,
           @Comment,
           @IDCard,
           @CT_ID,
           @BulidDate,
           @ValidityDate,
           @Pos_Id,
           @E_id,
           @IniMoney,
           @TotalBuyMoney,
           @SaveMoney,
           @IntergralYE,
           @IniIntergral,
           @Integral,
           @SwapIntegral,
           @BuyCount,
           @LoginPass,
	   @Deleted,		
           @Lose,
           @StopUse,	
	   @RemainderMoney,
           @PinYin,
           @islock,
           @Y_id,
           @code1,		
			@code2,		
			@code3,		
			@birthDay2,	
			@height,		
			@weight,		
			@bloodtype,	
			@QQ,			
			@Email,		
			@Education,	
			@SocialNO,			
			@IntroducerID,	       
	        @RetailHint           
           )


    IF (@@error!=0)
    BEGIN
        Raiserror('更新会员卡资料失败!',16,1)
        /*RAISERROR  20000 '更新会员卡资料失败! ' */
	RETURN -1  
    END
    ELSE
    BEGIN 
    RETURN @VipCardid
    END
    

end
GO
