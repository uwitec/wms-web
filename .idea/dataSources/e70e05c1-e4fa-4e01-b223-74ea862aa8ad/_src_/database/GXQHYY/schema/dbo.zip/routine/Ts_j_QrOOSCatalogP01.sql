
/*缺货分析　按商品汇总，表格1*/

CREATE	       PROCEDURE Ts_j_QrOOSCatalogP01
(
	@szfactory  varchar(100)= '%',  	
	@PClassID   VARCHAR(30) = '%',
	@CClassID   VARCHAR(30) = '%',
	@YClassID   VARCHAR(30) = '%',   /*暂不使用*/
	@BeginDate  DATETIME,  
	@EndDate    DATETIME,
	@nPFlag		int       /*处理的状态，0表示全部，1表示未处理，2表示处理中，3表示处理完成*/
)

/*with encryption*/

AS
      
   if @szfactory = ''  set @szfactory = '%%' else  set @szfactory = @szfactory +'%'
   if @PClassID = ''  set @PClassID = '%%'   else  set @PClassID = @PClassID +'%' 
   if @CClassID = ''  set @CClassID = '%%'	 else  set @CClassID = @CClassID +'%'
   if @YClassID = ''  set @YClassID = '%%'   else  set @YClassID = @YClassID +'%'
      
   select * from 
   (
	SELECT p.class_id, p.serial_number, p.name AS PName, p.alias, p.[standard], p.Unit1Name,  
		   p.MedName, p.makearea,isnull(f.AccountComment,'') as AccountComment, p.permitcode, p.unit1_id as unitid,o.ProductId, 
		   v.ModifyDate as buydate, v.BuyPrice, ISNULL(c.name, '') as spName, v.c_id  as supplierid,          
           ISNULL(dbo.GetOOSCatalogStorehouse(o.ProductId), 0) AS Qty,
           MAX(o.InStoreDate) AS InstoreDate,
           sum(o.OOSQty) as OOSQty,  sum(o.PlanQty) as PlanQty,		sum(o.SaleQty) as SaleQty,          
           sum(CASE WHEN (o.OOSQty < o.PlanQty) THEN 0 ELSE (o.OOSQty - o.PlanQty) END) AS fQty,
           COUNT(1) as OOSCount, /*缺货笔数*/
           COUNT(Case when Inflag = 1 then 1 end) as DisposeCount, /*处理笔数*/
           COUNT(Case when Inflag = 0 then 1 end) as NODisposecount,/*未处理笔数*/
           COUNT(Case when Inflag = 2 then 1 end) as StopDisposecount,/*终止笔数*/
           COUNT(Case when InDisposeflag = 1 then 1 end) as Buycount,/*计划购入笔数*/
           COUNT(Case when InDisposeflag = 2 then 1 end) as NoQtycount, /*暂无货笔数*/
           COUNT(Case when OutDisposeflag <> 0 then 1 end) as Salecount, /*已开票笔数*/
           isnull(p.factoryc_id,0) as FACTORY_ID, isnull(cs.name,'') as taxrate,p.retailprice
                                                              
    FROM OOSCatalog o INNER JOIN vw_products p ON o.ProductId = p.product_id                                                                                                                                                          
                      left join clients c1 on o.ClientId = c1.client_id
                      left join customCategory cs on p.taxrateid=cs.id
                      left join BaseFactory f on f.CommID=p.factoryc_id 
                      /*inner join company y on o.CompanyId = y.company_id */
                      LEFT JOIN (SELECT DISTINCT a.p_id, a.c_id, a.ModifyDate,a.BuyPrice 
									FROM buypricehis a INNER JOIN (SELECT p_id, MAX(ModifyDate) AS ModifyDate  
									                               FROM buypricehis WHERE Y_ID = 2 GROUP BY p_id) AS b 
									                   ON  a.p_id = b.p_id AND a.ModifyDate = b.ModifyDate) v 
									                   ON o.ProductId = v.p_id
					   left join clients c on v.c_id = c.client_id					   					   										                   									                   
    WHERE o.[Deleted] = 0 AND p.[deleted] = 0   AND p.factory like @szfactory and
          p.class_id LIKE @PClassID AND ISNULL(c1.class_id, '') LIKE @CClassID and /*AND ISNULL(y.class_id, '') LIKE @YClassID */
          o.InputDate BETWEEN @BeginDate AND @EndDate
                    
    group by  p.class_id, p.serial_number, p.name, p.alias, p.[standard], p.Unit1Name,  
			  p.MedName, p.makearea, p.permitcode, f.AccountComment, o.ProductId, p.unit1_id, v.ModifyDate, v.BuyPrice, c.name, v.c_id,
			  factoryc_id,cs.name,p.retailprice
    )a where (@nPFlag = 0 or 
				((@nPFlag = 1) and (DisposeCount = 0)) or
				((@nPFlag = 2) and (DisposeCount > 0) and (DisposeCount < OOSCount)) or 
				((@nPFlag = 3) and (DisposeCount = OOSCount)) )  
    
   /* a.OOSQty>Qty --不清楚原作者意图，前端无法显示，先注释*/
GO
