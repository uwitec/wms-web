



/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

库存商品统计
最后的修改日期 2003-12-17

与药易通的区别 ： 药易通显示为类型，精算显示为型号
(显示方式后面增加'-0'表示全部商品,'-1'表示正常商品,'-2'表示零货商品此判断目前只限于此存储过程 add by luowei 2013-08-30 )

********************************************/
CREATE PROCEDURE TS_C_QrOtherStoreHouse
(	@szParID 		VARCHAR(30)='000000',
	@nS_ID 			INT=0,					      /*仓库id号*/
	@szPeriod 		VARCHAR(1)='0',		    /*'0' 期初 ‘’当前*/
	@szListFlag		VARCHAR(3)='L',			  /*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
        @nUnitMode              int,
        @nYClassid              varchar(100)='',
        @nloginEID              int=0
)
/*with encryption*/
AS
/*Params Ini begin*/
if @szParID is null  SET @szParID = '000000'
if @nS_ID is null  SET @nS_ID = 0
if @szPeriod is null  SET @szPeriod = '0'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/


/*---处理是否显示零货商品 add by luowei 2013-08-30*/
declare @ProductType int 
declare @flags varchar(10)
if(CHARINDEX('-',@szListFlag,1)) > 0 
begin
  set @flags = SUBSTRING(@szListFlag,3,1)
  if @flags = '0'
  set @ProductType = -1
  if @flags = '1'
  set @ProductType = 0
  if @flags = '2'
  set @ProductType = 1         
end
else
set @ProductType = -1 /*-- -1 表示查询全部类型的商品*/

set @szListFlag = SUBSTRING(@szListFlag,1,1)

/*SET NOCOUNT ON*/
DECLARE @szSClassID VARCHAR(30)
  Declare @Companytable INTEGER,@Storetable integer, @nY_ID int
if @nYClassID = ''
  set @nY_ID = 2
else
  select @nY_ID = isnull(company_id, 2) from company where class_id = @nYClassId and child_number = 0    
if @nY_ID is null set @nY_ID = 2   

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
/*---分支机构授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
   end
/*---仓库授权*/


  IF @nS_ID IN (0, 1)
    SELECT @szSClassID='%%'
  ELSE
    SELECT @szSClassID=ISNULL([Class_ID], '000000') FROM Storages WHERE [Storage_ID]=@nS_ID

  SELECT * INTO #LastClient
  FROM
  (SELECT  P.[Product_ID], P.[Class_ID],
   C.[Name] AS [ClientName], C.[Phone_number]
   FROM VW_C_Products P,
	(SELECT A.* FROM Buypricehis A,
		(SELECT TOP 1 [P_ID], MAX([Modifydate]) AS [Modifydate], MAX([BuyPrice]) AS [BuyPrice]
   FROM Buypricehis GROUP BY [P_ID]) B
	 WHERE A.[P_ID]=B.[P_ID] AND A.[Modifydate]=B.[Modifydate] AND A.[BuyPrice]=B.[BuyPrice]
	 ) AS PD, Clients C
   WHERE P.[Child_Number]=0 AND P.[Deleted]<>1 AND PD.[C_ID]=C.[Client_ID] AND PD.[P_ID]=P.[Product_ID]) BM 

IF @szListFlag='L'  GOTO ListLeavel
IF @szListFlag='A' 	GOTO ListAll
IF @szListFlag='P' 	GOTO ListPart

GOTO SUCCEE

ListLeavel:
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
/*-------------------------------------------*/
/*当前库存，分级显示*/
/*-------------------------------------------*/
IF @szPeriod=''
BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(P.[E_Name], ' ') as ename, isnull(P.emp_id, 0) as emp_id, isnull(P.C_NAME, ' ') c_name,
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    '' AS [ClientName],
    '' AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal 
 		FROM
       (select P.*,isnull(pri.[unitname],'') as unitname,   pb.*
           from VW_C_Products P
           LEFT JOIN (select * from vw_productbalance where  Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]<>0
        AND (@ProductType = -1 OR IsSplit = @ProductType) 
        ) P 
    LEFT JOIN
    (SELECT SH.[PClassID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
     FROM 
     ( select * from   VW_C_OtherStorehouse where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclassid like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
     )SH

     WHERE LEFT(SH.[SClassID], LEN(@szSClassID)) LIKE @szSClassID  GROUP BY SH.[PClassID]
	  ) AS SH 
	ON LEFT(SH.[PClassID], LEN(P.[Class_ID]))=P.[Class_ID]
  
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],	     p.[PackStd],  P.[E_Name],P.emp_id,P.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
	UNION
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(P.[E_Name], ' ') as ename, isnull(P.emp_id, 0) as emp_id, isnull(P.C_NAME, ' ') c_name,
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal
 		FROM 
      (select P.*,isnull(pri.[unitname],'') as unitname,   pb.*
           from VW_C_Products P
           LEFT JOIN (select * from vw_productbalance where  Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
        AND (@ProductType = -1 OR IsSplit = @ProductType) 
        ) P  
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
     FROM 
     ( select * from   VW_C_OtherStorehouse where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclassid like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
     )SH
		   WHERE LEFT(SH.[SClassID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  P.[E_Name],P.emp_id,P.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END 
/*-------------------------------------------*/
/*期初库存，分级显示*/
/*-------------------------------------------*/
ELSE BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(Pb.[e_name], ' ') as ename, isnull(Pb.emp_id, 0), isnull(Pb.C_NAME, ' '),
    P.[Unitname1] as Unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    '' AS [ClientName],
    '' AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal 

 		FROM VW_C_Products P 
    LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
    (SELECT SH.[Class_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
     FROM
     ( select * from   VW_C_OtherStorehouseini where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclass_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
     )SH
		   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[Class_ID]
	  ) AS SH 
	ON LEFT(SH.[Class_ID], LEN(P.[Class_ID]))=P.[Class_ID]
  WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]<>0
  AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  Pb.[E_Name], Pb.emp_id, Pb.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
	UNION
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(Pb.[E_Name], ' ') as ename, isnull(Pb.emp_id, 0),isnull(Pb.C_NAME, ' '),
    P.[Unitname1] as Unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal
 		FROM VW_C_Products P 
    LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
     FROM 
     (select * from   VW_C_OtherStorehouseini where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclass_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
     )SH
		   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE P.[Parent_ID]=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
  AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  Pb.[E_Name],Pb.emp_id,Pb.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

ListAll:
/*-------------------------------------------*/
/*当前库存，全部列表*/
/*-------------------------------------------*/
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
IF @szPeriod=''
BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(P.[E_Name], ' ') as ename, isnull(P.emp_id, 0) as emp_id, isnull(P.C_NAME, ' ') c_name,
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal 
 		FROM 
       (select P.*,isnull(pri.[unitname],'') as unitname,   pb.*
           from VW_C_Products P
           LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
        AND (@ProductType = -1 OR IsSplit = @ProductType) 
        ) P  
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
	FROM 
     (select * from   VW_C_OtherStorehouse where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclassid like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
     )SH
		   WHERE LEFT(SH.[SClassID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]

  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],	     p.[PackStd],  P.[e_name], P.emp_id,P.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END

/*-------------------------------------------*/
/*期初库存，全部列表*/
/*-------------------------------------------*/
ELSE BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(Pb.[E_Name], ' ') as ename,isnull(Pb.emp_id, 0) as emp_id, isnull(Pb.C_NAME, '') as c_name,
    P.[Unitname1] as Unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit ,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal
 		FROM VW_C_Products P 
    LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
	FROM 
      (select * from   VW_C_OtherStorehouseini where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclass_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
      )SH
		   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
  AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  Pb.[E_Name],Pb.emp_id,Pb.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

ListPart:
SET TRANSACTION  ISOLATION  LEVEL READ UNCOMMITTED
/*-------------------------------------------*/
/*当前库存，部分列表*/
/*-------------------------------------------*/
IF @szPeriod=''
BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(P.[E_Name], ' ') as ename, isnull(P.emp_id, 0) as emp_id, isnull(P.C_NAME, ' ') c_name,
    (case when @nUnitMode=1 then MAX(P.[Unitname1]) else MAX(p.[unitname]) end)unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit ,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal
 		FROM 
       (select P.*,isnull(pri.[unitname],'') as unitname,   pb.*
           from VW_C_Products P
           LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
           LEFT JOIN 
            (select pri.*,isnull(u.[name],'')unitname from price pri left join unit u on pri.u_id=u.unit_id)pri 
           ON ( (@nUnitMode=1 and (pri.p_id=P.product_id and p.unit1_id=pri.u_id))
             or (@nUnitMode=2 and (pri.p_id=P.product_id and p.unit2_id=pri.u_id))
             or (@nUnitMode=3 and (pri.p_id=P.product_id and p.unit3_id=pri.u_id))     
             or (@nUnitMode=4 and (pri.p_id=P.product_id and p.unit4_id=pri.u_id))
               )
        WHERE LEFT(P.[Class_ID], LEN(@szParID))=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
        AND (@ProductType = -1 OR IsSplit = @ProductType) 
        ) P  
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
	FROM
      ( select * from   VW_C_OtherStorehouse where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclassid='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclassid like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
       )SH
		   WHERE LEFT(SH.[SClassID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  P.[E_Name],P.emp_id,P.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END
/*-------------------------------------------*/
/*期初库存，部分列表*/
/*-------------------------------------------*/
ELSE BEGIN
	SELECT
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  isnull(Pb.[E_Name], '') as ename, isnull(Pb.emp_id, '') as emp_id, isnull(Pb.C_NAME, '') c_name,
    P.[Unitname1] as Unitname,
    cast(0 as numeric(25,8)) as retailprice,cast(0 as numeric(25,8)) as recprice,cast(0 as numeric(25,8)) as price1,
    cast(0 as numeric(25,8)) as price2,     cast(0 as numeric(25,8)) as price3,  cast(0 as numeric(25,8)) as price4,
    cast(0 as numeric(25,8)) as gpprice,    cast(0 as numeric(25,8)) as glprice, cast(0 as numeric(25,8)) as specialprice,  
    P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
		cast(ISNULL(SUM(SH.[Quantity])  ,0) as numeric(25,8)) AS [Quantity],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [Costtotal],
		cast(ISNULL(SUM(SH.[Costtotal]) ,0) as numeric(25,8)) AS [taxtotal],
    ISNULL(MAX(BM.[ClientName])   ,'') AS [ClientName],
    ISNULL(MAX(BM.[Phone_number]) ,'') AS [Phone_number],
    0.0000 as nosendQTY,
    cast(0 as numeric(25,8)) as RetailTotal,'' as Factory,p.IsSplit ,0.0 as ZTQuantity,0.0 as ZTtaxtotal,
     0.0 as cljg,0.0 as clquantity,0.0 as cltotal
 		FROM VW_C_Products P
    LEFT JOIN (select * from vw_productbalance where Y_id = @nY_ID) pb on P.product_id = pb.p_id 
    LEFT JOIN
    (SELECT SH.[P_ID],
       ISNULL(SUM(SH.[Quantity])  ,0) AS [Quantity], 
       ISNULL(SUM(SH.[Costtotal]) ,0) AS [Costtotal]
	FROM
       ( select * from   VW_C_OtherStorehouseini where (@nYClassID='' or YClass_id like @nYClassID+'%') AND (@ProductType = -1 OR IsSplit = @ProductType) 
        AND (@Storetable=0 OR ((sclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and sclass_id like u.psc_id+'%'))))
        AND (@CompanyTable=0 or ((Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and Yclass_id like u.psc_id+'%'))))
       )SH
		   WHERE LEFT(SH.[SClass_ID], LEN(@szSClassID)) LIKE @szSClassID 
			 GROUP BY SH.[P_ID]
	  ) AS SH 
	ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN #LastClient BM ON P.[Product_ID]=BM.[Product_ID]
  WHERE LEFT(P.[Class_ID], LEN(@szParID))=@szParID AND P.[Deleted]<>1 AND P.[Product_ID]<>1 AND P.[Child_number]=0
  AND (@ProductType = -1 OR IsSplit = @ProductType) 
  GROUP BY
    P.[Product_ID], P.[Class_ID],  P.[Child_number], P.[Name],     P.[Code],
    P.[Alias],      P.[Standard],  P.[PermitCode],P.[Modal],        P.[Makearea], P.[Costmethod], P.Comment,
    P.[Rate2],      P.[Rate3],     P.[Rate4],        p.[PackStd],  Pb.[E_Name],Pb.emp_id,Pb.C_NAME,
    P.[Unitname1],  P.[Unitname2], P.[Unitname3],    P.[Unitname4],
    P.[Pinyin],     P.[Taxrate],   P.[Medtype],      P.[Otcflag],
    P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,p.IsSplit
END
SET TRANSACTION  ISOLATION  LEVEL READ COMMITTED
GOTO SUCCEE

SUCCEE:
  DROP TABLE #LastClient
  RETURN 0
GO
