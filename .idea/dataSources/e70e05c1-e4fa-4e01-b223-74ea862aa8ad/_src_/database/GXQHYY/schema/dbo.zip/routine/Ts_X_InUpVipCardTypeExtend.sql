
Create  procedure Ts_X_InUpVipCardTypeExtend
( 
    @I_id          [int],
    @jfRate1       [numeric](18, 2), /*多少元积一分 IntegralMoney*/
    @jfRate2       [numeric](18, 2), /*介绍消费多少元反一分    BackIntNeedMoney*/
    @jfValidDate   [numeric](18, 2),    /*积分有效期  validmonth*/
    @isdxIntegral  [bit],   /*抵现后是否整单积分  add*/
    @dxRate        [numeric](18, 2),   /*好多分抵现一元   add*/
    @islimitDate   [bit],  /*限制时间段      add*/
    @dxBegintime   [varchar](100),    /*抵现开始时间   add*/
    @dxEndtime     [varchar](100),    /*抵现结束时间   add*/
    @dxMode        [Int],      /*0表示按星期，1表示按日期  daymode*/
    @dxDateStr     [varchar](500),    /*抵现日期字段  dmstr*/

    @isSpecialIntegral  [bit],      /*特价商品积分  add*/
    @IntegralMode  [int],    /*积分累计模式    Integralmode*/
    @isMoneyUp     [bit],     /*ismoneyup*/
    @UpMoney      [numeric](18, 2),  /*moneyup*/
    @lMoneyUpCT_id [int],/* moneyupC_id*/
    @isMoneyAutoup [bit],     /*自动升级 isMoneyAutoup*/
    /*积分升级*/
    @isIntegralUp [bit],/* isIntegralup*/
    @UpIntegral   [numeric](18, 2),/*Integralup*/
    @lIntegralUpCT_id  [int],/* IntegralupC_id*/
    @UpDecIntegral    [numeric](18, 2),/*Integralupkc*/
    @isIntegralAutoup  [bit],  /*自动升级 isautoup*/
    /*储值升级*/
    @isStoragUp  [bit],/*  add*/
    @UpStorag    [numeric](18, 2),   /* add*/
    @lStoragUpCT_id   [int],/* add*/
    @isStoragAutoup   [bit],    /*自动升级add*/
    /*应用机构*/
    @isAllCompany    [bit],  /*全部机构   add*/
    @szCompanyStr     [varchar](1000),    /*选择的机构id串   cidstr*/
    @YCclassid  VARCHAR(1000)  /*选择的机构类别的class_id串  */
 )  
AS

/*取得ID号*/

DECLARE 
    @CardName      VARCHAR(500),   /*当前卡类型名称*/
    @moneyUPCName  VARCHAR(100),     /*moneyupC_name*/
    @integraUPCName   VARCHAR(100)    /*IntegralupC_name*/
    
  SELECT @CardName = Name FROM VIPCardType WHERE ct_id = @I_id
  IF @CardName IS NULL SET @CardName = ''
  SELECT @moneyUPCName = Name FROM VIPCardType WHERE ct_id = @lMoneyUpCT_id
  IF @moneyUPCName IS NULL SET @moneyUPCName = ''  
  SELECT @integraUPCName = Name FROM VIPCardType WHERE ct_id = @lIntegralUpCT_id
  IF @integraUPCName IS NULL SET @integraUPCName = ''  
  

if not exists(select 1 from VipCardTypeExtend where bill_id = @I_id)
begin     
   insert into VipCardTypeExtend
	( 
	bill_id,
	cardidstr,
	cardnamestr,
    IntegralMoney,
    BackIntNeedMoney,
    validmonth,
    isdxIntegral,
    dxRate,
    islimitDate,
    dxBegintime,
    dxEndtime,
    daymode,
    dmstr,
    isSpecialIntegral,
    Integralmode,
    ismoneyup,
    moneyup,
    moneyupC_id,
    moneyupC_name,
    isMoneyAutoup,
    /*积分升级*/
    isIntegralup,
    Integralup,
    IntegralupC_id,
    IntegralupC_name,
    Integralupkc,
    isautoup,
    /*储值升级*/
    isStoragUp,
    UpStorag,
    lStoragUpCT_id,
    isStoragAutoup,
    /*应用机构*/
    isAllCompany,
    cidstr,
    YC_classid
	)						
	Values(	
	@I_id,
	CAST(@I_id AS varchar(100)),
	@CardName,
    @jfRate1,
    @jfRate2,
    @jfValidDate,
    @isdxIntegral,
    @dxRate ,
    @islimitDate ,
    @dxBegintime  ,
    @dxEndtime   ,
    @dxMode    ,
    @dxDateStr   ,
    @isSpecialIntegral ,
    @IntegralMode ,
    @isMoneyUp ,
    @UpMoney ,
    @lMoneyUpCT_id ,
    @moneyUPCName,
    @isMoneyAutoup ,
    /*积分升级*/
    @isIntegralUp ,
    @UpIntegral ,
    @lIntegralUpCT_id ,
    @integraUPCName,
    @UpDecIntegral ,
    @isIntegralAutoup ,
    /*储值升级*/
    @isStoragUp ,
    @UpStorag ,
    @lStoragUpCT_id ,
    @isStoragAutoup,
    /*应用机构*/
    @isAllCompany,
    @szCompanyStr,
    @YCclassid  	    	    
		   )									
		   
	return @@IDENTITY 
end 
else
begin
   UPDATE VipCardTypeExtend
	SET 
	cardnamestr = @CardName, 		
    IntegralMoney = @jfRate1,
    BackIntNeedMoney = @jfRate2,
    validmonth = @jfValidDate,
    isdxIntegral  = @isdxIntegral,
    dxRate  = @dxRate,
    islimitDate  = @islimitDate,
    dxBegintime  =  @dxBegintime,
    dxEndtime    =  @dxEndtime,
    daymode = @dxMode,
    dmstr = @dxDateStr,

    isSpecialIntegral = @isSpecialIntegral,
    Integralmode = @IntegralMode,
    ismoneyup = @isMoneyUp,
    moneyup = @UpMoney,
    moneyupC_id = @lMoneyUpCT_id,
    moneyupC_name = @moneyUPCName,
    isMoneyAutoup = @isMoneyAutoup,
    /*积分升级*/
    isIntegralup = @isIntegralUp,
    Integralup = @UpIntegral,
    IntegralupC_id = @lIntegralUpCT_id,
    IntegralupC_name = @integraUPCName,
    Integralupkc = @UpDecIntegral,
    isautoup = @isIntegralAutoup,
    /*储值升级*/
    isStoragUp  = @isStoragUp,
    UpStorag   =  @UpStorag,
    lStoragUpCT_id =    @lStoragUpCT_id,
    isStoragAutoup =    @isStoragAutoup,
    /*应用机构*/
    isAllCompany =     @isAllCompany,
    cidstr =  @szCompanyStr,
    YC_classid = @YCclassid,
    cardidstr = CAST(@I_id AS varchar(100))
  WHERE bill_id =@I_id
  return @@rowcount 
end
GO
