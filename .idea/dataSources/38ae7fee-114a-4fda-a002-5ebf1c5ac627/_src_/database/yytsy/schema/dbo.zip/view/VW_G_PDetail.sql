




CREATE  VIEW [VW_G_PDetail]
AS
SELECT PD.pd_id,      PD.billid,    PD.p_id,  
       Case when bi.billtype in (112,122) then 1
                 else PD.S_ID 
       end as S_ID ,        
       PD.quantity,   PD.price,     PD.total,     PD.costprice, 
       PD.costtotal,  PD.taxprice,  PD.taxtotal,  PD.batchno,
       PD.makedate,   PD.validdate, PD.commissionflag,         PD.supplier_id, 
       PD.location_id,PD.storetype, PD.price_id,  PD.order_id, 
       PD.unitid,     PD.smb_id,    PD.comment,pd.aoid,  
       
  ISNULL(P.[Name]     ,'') AS [PName],        ISNULL(P.[Class_ID] ,'') AS [Class_ID], 
  ISNULL(S.[Name]     ,'') AS [SName],        ISNULL(S.[Class_ID] ,'') AS [SClass_ID], 
  ISNULL(P.[MakeArea] ,'') AS [MakeArea],     ISNULL(P.[Standard] ,'') AS [Standard],
  ISNULL(L.[Loc_Name] ,'') AS [LocName],      ISNULL(C.[Class_ID] ,'') AS [SupplierClass_id],
  ISNULL(C.[Name]     ,'') AS [SupplierName], ISNULL(E.[Class_ID] ,'') AS REClass_id,
  ISNULL(E.[Name]     ,'') AS [REname] 
FROM ProductDetail PD 
	LEFT JOIN	Storages S ON PD.[S_ID]=S.[Storage_ID] 
	LEFT JOIN	ProductS P ON PD.[P_ID]=P.[Product_ID]
	LEFT JOIN	Location L ON PD.[Location_ID]=L.[Loc_ID]
	LEFT JOIN	ClientS  C ON PD.[Supplier_ID]=C.[Client_ID]
        LEFT JOIN      employees e ON PD.ROWE_id=e.emp_id
  LEFT JOIN billidx bi on PD.billid  = bi.billid
where pd.aoid in (0,7)
GO
