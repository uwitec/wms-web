

/* =============================================*/
/* Author:		zjilin	*/
/* Create date: 2013-05-27*/
/* Description:	更新代金券指定字段的值*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_j_UpdateCashCoupon] 
	@ccid	int,		/*代金券ID*/
	@szFieldName  varchar(100),
	@szValue      varchar(200) = ''   
AS
   
  if @szFieldName is null return -1
  if @szValue is null  return -1
                      
  if upper(@szFieldName) = 'FLAG' 
  begin
    declare @nOldFlag int
    select @nOldFlag = flag from Cashcoupon where ccid = @ccid    
   /*已用代金券不允许删除*/
    if @nOldFlag = 5
    begin
      RAISERROR('已用代金券不允许修改状态或删除！',16,1)
	  return-1           
    end 
    if (@nOldFlag = 4) and (@szValue <> '1')
    begin
      RAISERROR('已作废代金券不允许修改状态！',16,1)
	  return-1           
    end 
           
    update Cashcoupon set flag= CAST(@szValue  as int ) where ccid = @ccid     
          
  end else if upper(@szFieldName) = 'COMMENT' 
  begin
     update Cashcoupon set comment  = @szValue where ccid = @ccid
  end
   
return 0
GO
