
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-5-8*/
/* Description:	将基本资料修改记录写入日志表*/
/* =============================================*/
CREATE PROCEDURE TS_H_InsBaseInfoLog
	@BaseInfoType	int,	/* 0: 商品 1: 往来单位 2: 机构*/
	@BaseInfoID		int,
	@Eid			int,
	@Content		VARCHAR(8000),
	@nReSetAudit    int =0,    /*是否重新审核 add by luowei 2013-08-08*/
	@nIsParent       int   /*是否是大类 1 是，0 不是*/
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @EName VARCHAR(80)
	SELECT @EName = NAME FROM employees WHERE emp_id = @Eid
	IF @EName IS NULL
		SET @EName = ''
		
	INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes)
	SELECT @BaseInfoID, @BaseInfoType, @Eid, GETDATE(), [str] FROM Split(@Content, '^')
	
	if @Content = '【审核】'
	begin
	  if @nIsParent = 0 
	  begin
		  if @BaseInfoType = 0 
			update products set AuditStates = 1 , AuditEName = @EName, AuditDate = GETDATE() where product_id = @BaseInfoID and AuditStates = 0
		  if @BaseInfoType = 1
		  begin
			update clients set AuditStates = 1 , AuditEName = @EName, AuditDate = GETDATE() where client_id = @BaseInfoID and AuditStates = 0
		    /*-配送单位*/
	        update clients set AuditStates = 1 , AuditEName = @EName, AuditDate = GETDATE() where jsdw_id = @BaseInfoID
		  end	
		  if  @BaseInfoType = 2 
			update company set AuditStates = 1 where company_id = @BaseInfoID and AuditStates = 0  
	  end
	  else
	  begin
	    declare @class_id varchar(100)
	    set @class_id = ''
	    if @BaseInfoType = 0
	    begin 
	        select @class_id = class_id from products where product_id = @BaseInfoID
			INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes)
			SELECT               product_id,0,@Eid,GETDATE(),'【审核】' 
			FROM products where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0   /*XXX.2017-01-19 虽然记录表会增大，但更新的每个商品都应该有日志记录*/
			update products set AuditStates = 1 , AuditEName = @EName, AuditDate = GETDATE()  where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0
	    end		
		if @BaseInfoType = 1
		begin
		    select @class_id = class_id from clients where client_id = @BaseInfoID
			INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes)
			SELECT               client_id,1,@Eid,GETDATE(),'【审核】' 
			FROM clients where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0
			update clients set AuditStates = 1 , AuditEName = @EName, AuditDate = GETDATE()  where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0
		end	
		if  @BaseInfoType = 2 
		begin
		    select @class_id = class_id from company where company_id = @BaseInfoID
			INSERT INTO sysTnotes(magbillid, billtype, updateman, updatedate, notes)
			SELECT               company_id,2,@Eid,GETDATE(),'【审核】' 
			FROM company where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0
			update company set AuditStates = 1 where (left(class_id,len(@class_id)) = @class_id or class_id = @class_id) and AuditStates = 0 
	    end		 
	  end  
	end
	else
	begin
	if @nReSetAudit = 1
	begin
	  if @BaseInfoType = 0 
	    update products set AuditStates = 0 , AuditEName = @EName, AuditDate = GETDATE()  where product_id = @BaseInfoID 
	  if @BaseInfoType = 1
	  begin
	    update clients set AuditStates = 0 , AuditEName = @EName, AuditDate = GETDATE()  where client_id = @BaseInfoID 
	    /*-配送单位*/
	    update clients set AuditStates = 0  , AuditEName = @EName, AuditDate = GETDATE()  where jsdw_id = @BaseInfoID
	  end    
	  if  @BaseInfoType = 2 
	    update company set AuditStates = 0 where company_id = @BaseInfoID 
	 end   
	end
END
GO
