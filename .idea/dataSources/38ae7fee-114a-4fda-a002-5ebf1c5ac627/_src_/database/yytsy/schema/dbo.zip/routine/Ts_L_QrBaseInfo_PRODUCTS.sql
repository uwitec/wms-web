
create PROCEDURE Ts_L_QrBaseInfo_PRODUCTS
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

declare @sql varchar(8000), @szPname varchar(8000)
declare @sql2 varchar(8000)

set @szPname = @szName

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

declare @nTmpYID int
set @nTmpYID=@nY_id
if (@E_id=-100) 
	set @nTmpYID=@E_id

  if @szWhere='2'
     set @szWhere=' '
  /**/
/*----*/
	/*declare @bExpense bit*/
    /*set @bExpense = @nFilterY / 10*/
/*---*/
  if @nFilterY in (4, 5)
  BEGIN
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 
   'SELECT p.*,
    (select isnull(sum(s.quantity),0) 
    from storehouse s 
    where p.Product_id=s.p_id  ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  p.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  p.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'   
   set @sql=@sql + 'FROM (select p1.*, isnull(pb.locationid, 0) as locationid, isnull(pb.wholeloc, 0) as wholeloc, isnull(pb.singleloc, 0) as singleloc, 
         isnull(pb.supplier_id, 0) as supplier_id, isnull(pb.emp_id, 0) as emp_id, isnull(pb.locname, '''') as locname, isnull(pb.Wlocname, '''') as Wlocname,
         isnull(pb.Slocname, '''') as Slocname, isnull(pb.c_name, '''') as c_name,  isnull(pb.E_name, '''') as E_name,                   
         ISNULL(pr.retailprice, 0) AS retailprice, 
         cast(ISNULL(pr.recprice, 0)as NUMERIC(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
         ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
         ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
         ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice                           
		from vw_Products2 p1
		left join (select * from dbo.getprice('+CAST(@nY_ID as varchar) +') where unittype = 1) pr  on p1.product_id = pr.p_id	
        left join (select * from vw_productbalance where Y_ID='+ cast(@nY_id as varchar(20))+') pb on p1.product_id = pb.p_id 
   where p1.product_id = '+@szPname+' and (p1.Child_Number=0) '+@szWhere + ')p ) T'
   /*print(@sql)*/
   exec(@sql)
  END else
  if @nFilterY=3 
  BEGIN
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 
   'SELECT p.*,
    (select isnull(sum(s.quantity),0) 
    from storehouse s 
    where p.Product_id=s.p_id  ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  p.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  p.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'   
   set @sql=@sql + 'FROM (select p1.*, isnull(pb.locationid, 0) as locationid, isnull(pb.wholeloc, 0) as wholeloc, isnull(pb.singleloc, 0) as singleloc, 
         isnull(pb.supplier_id, 0) as supplier_id, isnull(pb.emp_id, 0) as emp_id, isnull(pb.locname, '''') as locname, isnull(pb.Wlocname, '''') as Wlocname,
         isnull(pb.Slocname, '''') as Slocname, isnull(pb.c_name, '''') as c_name,  isnull(pb.E_name, '''') as E_name,
         ISNULL(pr.retailprice, 0) AS retailprice, 
         cast(ISNULL(pr.recprice, 0)as NUMERIC(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
         ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
         ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
         ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice           
		from vw_Products2 p1
		left join (select * from dbo.getprice('+CAST(@nY_ID as varchar) +') where unittype = 1) pr  on p1.product_id = pr.p_id			
        left join (select * from vw_productbalance where Y_ID='+ cast(@nY_id as varchar(20))+') pb on p1.product_id = pb.p_id 
   where p1.serial_number = '+char(39)+@szPname+char(39)+'  and (p1.Child_Number=0) '+@szWhere + ')p ) T'
   /*print(@sql)*/
   exec(@sql)
  END else
  if @E_id=0                  /*所有仓库*/
  BEGIN
   set @sql='select *, (Qty1 - DraftQty) as saleQty  from ('
   set @sql= @sql + 
   'SELECT p.*,
    (select isnull(sum(s.quantity),0) 
    from storehouse s,AuthorizeStorage('+cast(@nLoginid as varchar(20))+') ast 
    where p.Product_id=s.p_id and s.s_id=ast.storage_id) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  p.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  p.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'   
   set @sql=@sql + 'FROM (select p1.*, isnull(pb.locationid, 0) as locationid, isnull(pb.wholeloc, 0) as wholeloc, isnull(pb.singleloc, 0) as singleloc, 
         isnull(pb.supplier_id, 0) as supplier_id, isnull(pb.emp_id, 0) as emp_id, isnull(pb.locname, '''') as locname, isnull(pb.Wlocname, '''') as Wlocname,
         isnull(pb.Slocname, '''') as Slocname, isnull(pb.c_name, '''') as c_name,  isnull(pb.E_name, '''') as E_name
         ,isnull(SO.quantity,0) AS otherqty, 
         ISNULL(pr.retailprice, 0) AS retailprice, 
         cast(ISNULL(pr.recprice, 0)as NUMERIC(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
         ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
         ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
         ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice                             
		from vw_Products p1
		left join (select * from dbo.getprice('+CAST(@nY_ID as varchar) +') where unittype = 1) pr  on p1.product_id = pr.p_id					
        left join (select * from vw_productbalance where Y_ID = ' + cast(@nY_id as varchar(20))+') pb on p1.product_id = pb.p_id 
        left join (select * from OtherStorehouse   where Y_ID='+ cast(@nY_id as varchar(20))+') SO ON p1.product_id=SO.p_id 
   where pb.e_name like ''' + @szName + ''' or pb.e_pinyin like ''' + @szname + ''' or p1.product_id in 
   (select p_id from barcode where barcode like ' + char(39) + @szname+char(39)+' 
    union 
    select product_id as p_id from products 
    where ([Name] like ' + char(39) + @szname + char(39) + ' or serial_number like '+char(39)+@szname+char(39)+'  or pinyin like  '+char(39)+@szname+char(39)+' or makearea like ''' + @szName + ''') and (Child_Number=0) 
   ) and child_number=0 '+@szWhere + ')p ) T'
/*   print(@sql)*/
   exec(@sql)
  END                            /*所有仓库 OVER*/
  else
   if @e_id=-100                 /*配送中心*/
   BEGIN
    set @sql='select *, (Qty1 - DraftQty) as saleQty from ('
    set @sql= @sql + '
    SELECT p.*,
     (select isnull(sum(s.quantity),0) 
     from storehouse s ,storages st
     where s.s_id=st.storage_id and '
   IF @nY_ID = 2 
     SET @SQL = @SQL + ' st.flag=0 and ' 
   SET @sql = @SQL +  'p.Product_id=s.p_id 
       and s.Y_ID=' + cast(@nY_ID as varchar(50)) + ' ) qty, '
   set @sql=@sql + '(select isnull(sum(pd.DraftQty),0)   from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd where  p.Product_id=pd.p_id) DraftQty ' 
   set @sql=@sql + ',Qty1=(select isnull(sum(s.quantity),0)   from storehouse s where  p.Product_id=s.p_id and s.Y_ID='+ cast(@nY_id as varchar(20))+')'
   set @sql=@sql +  'FROM (select p1.*, isnull(pb.locationid, 0) as locationid, isnull(pb.wholeloc, 0) as wholeloc, isnull(pb.singleloc, 0) as singleloc, 
         isnull(pb.supplier_id, 0) as supplier_id, isnull(pb.emp_id, 0) as emp_id, isnull(pb.locname, '''') as locname, isnull(pb.Wlocname, '''') as Wlocname,
         isnull(pb.Slocname, '''') as Slocname, isnull(pb.c_name, '''') as c_name,  isnull(pb.E_name, '''') as E_name,
         ISNULL(pr.retailprice, 0) AS retailprice, 
		 cast(ISNULL(pr.recprice, 0)as NUMERIC(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
         ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
         ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
         ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 			                                            
         from vw_Products p1
         left join (select * from dbo.getprice('+CAST(@nY_ID as varchar) +') where unittype = 1) pr  on p1.product_id = pr.p_id		         
        left join (select * from vw_productbalance where Y_ID='+ cast(@nY_id as varchar(20))+') pb on p1.product_id = pb.p_id 
    where pb.e_name like ''' + @szName + ''' or pb.e_pinyin like ''' + @szname + ''' or p1.product_id in 
    (select p_id from barcode where barcode like  '+char(39)+@szname+char(39)+' 
     union 
     select product_id as p_id from products 
     where ([Name] like  '+char(39)+@szname+char(39)+' or serial_number like '+char(39)+@szname+char(39)+'  or pinyin like  '+char(39)+@szname+char(39)+' or makearea like ''' + @szName + ''') and (Child_Number=0) 
    ) and child_number=0 '+@szWhere + ')p ) T'
   /*print(@sql)	*/
   exec(@sql)
   END                          /*配送中心  OVER */
   else                        
   BEGIN
    set @sql='select p.*, isnull(q.qty,0) qty, isnull(q1.Qty1,0) - isnull(dq.DraftQty,0) as saleQty,ISNULL(so.quantity,0)  as otherqty
		      FROM ( '                        /*当前库房*/
    set @sql= @sql + '
			select p1.*, isnull(pb.locationid, 0) as locationid, isnull(pb.wholeloc, 0) as wholeloc, isnull(pb.singleloc, 0) as singleloc, 
			isnull(pb.supplier_id, 0) as supplier_id, isnull(pb.emp_id, 0) as emp_id, isnull(pb.locname, '''') as locname, isnull(pb.Wlocname, '''') as Wlocname,
			isnull(pb.Slocname, '''') as Slocname, isnull(pb.c_name, '''') as c_name,  isnull(pb.E_name, '''') as E_name,
			ISNULL(pr.retailprice, 0) AS retailprice, 
			cast(ISNULL(pr.recprice, 0)as NUMERIC(25,8)) AS recprice, ISNULL(pr.price1, 0) AS price1, 
            ISNULL(pr.price2, 0) AS price2, ISNULL(pr.price3, 0) AS price3, ISNULL(pr.price4, 0) AS price4, 
            ISNULL(pr.glprice, 0) AS glprice, ISNULL(pr.gpprice, 0) AS gpprice, 
            ISNULL(pr.specialprice, 0) AS Specialprice, ISNULL(pr.lowprice, 0) AS Lowprice 			
			from vw_Products p1
			left join (select * from dbo.getprice('+CAST(@nY_ID as varchar) +') where unittype = 1) pr  on p1.product_id = pr.p_id								
			join 
			(select distinct p_id from barcode where barcode like  '+char(39)+@szName+char(39)+' 
			 union 
			 select distinct product_id as p_id from products 
			 where ([Name] like  '+char(39)+@szName+char(39)+'  or serial_number like '+char(39)+@szName+char(39)+'  or pinyin like  '
			 +char(39)+@szName+char(39)+'  or makearea like '+char(39)+@szName+char(39)+') and (Child_Number=0) 
			 union 
			 select distinct p_id from productbalance a,(select emp_id from employees where name like '+char(39)+@szName+char(39)+' or pinyin like '
			 +char(39)+@szName+char(39)+')b 
			 where a.Emp_id=b.emp_id 
			) p on p.p_id=p1.product_id
			left join (select * from vw_productbalance where Y_ID='+cast(@nY_id as varchar(20))+') pb on p1.product_id = pb.p_id 
			where child_number=0  and deleted not in (3,4) 
		) p  '
        
        
	set @sql=@sql + 'left join 
	(
		select s.p_id, isnull(sum(s.quantity),0) as qty
		from storehouse s 
		where s.s_id='++ cast(@E_id as varchar) +'  
        and s.Y_ID in (select company_ID from AuthorizeCompany('+cast(@nLoginid as varchar(50))+'))  
        group by s.p_id
	) q  on  q.p_id=p.product_id '
	
   set @sql=@sql + 'left join
   (
		select pd.p_id,isnull(sum(pd.DraftQty),0) DraftQty   
		from fnPDraftQty('+ cast(@nTmpYID as varchar(20))+') pd 
		group by pd.p_id
	) dq on dq.p_id=p.product_id '
   set @sql=@sql +  'left join 
    (	
		select p_id,isnull(sum(s.quantity),0) qty1   
		from storehouse s 
		where  s.Y_ID='+ cast(@nTmpYID as varchar(20))+'
		group by p_id
	) q1  on q1.p_id=p.product_id '
	
   set @sql= @sql + 'left join 
	(
		select p_id,sum(quantity) as quantity from OtherStorehouse   
		where y_id='+ cast(@nY_id as varchar(20))+'
		group by p_id
	) SO ON p.product_id=SO.p_id 
	order by product_id '
  /*print (@sql)*/
  exec(@sql)
  END                           /*当前库房 OVER*/
GO
