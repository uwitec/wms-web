
create PROCEDURE Ts_L_QrBaseInfo_EMPLOYEES
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

 select distinct ve.* 
 from vw_Employee ve inner JOIN (select * from AuthorizeEmployees(@E_id) where Child_Number=0 ) u  
 ON LEFT (u.class_id, LEN(ve.class_id))=ve.class_id
 where  (ve.Child_Number=0) 
  and (ve.name like @szName or ve.serial_number like @szName or 
  PinYin like @szName)
  and CAST(Y_ID as varchar(50)) like (case when (@nY_ID=0) or (@nFilterY=0) then '%%' else  CAST(@nY_ID as varchar(50))end)
  and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0))
GO
