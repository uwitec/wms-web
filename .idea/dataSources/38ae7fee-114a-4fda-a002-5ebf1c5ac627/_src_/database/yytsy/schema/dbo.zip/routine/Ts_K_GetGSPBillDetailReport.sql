
CREATE PROCEDURE Ts_K_GetGSPBillDetailReport(@BillType INT, @ClientId INT, @CompanyId INT, @SId INT, @EId INT, @Begin VARCHAR(100), @End VARCHAR(100), @YId INT, @YBillType INT)
AS
BEGIN
	SELECT g.BillNumber, CONVERT(VARCHAR(100), g.BillDate, 120) AS BillDate, CASE WHEN g.Ybilltype > 100 THEN ISNULL(c2.name, '') ELSE ISNULL(c.name, '') END AS CName, 
	       ISNULL(s.name, '') AS SName, CASE g.BillType WHEN 541 THEN ISNULL(e1.name, '') WHEN 551 THEN ISNULL(e.name, '') END AS EName,
	       p.serial_number, p.name, p.alias, p.[standard], p.Unit1Name, p.permitcode, p.makearea, p.Factory, 
	       CASE WHEN b.MakeDate > 10 THEN CONVERT(VARCHAR(100), b.MakeDate, 23) ELSE '' END AS MakeDate, b.Batchno, 
	       CASE WHEN b.Validdate > 10 THEN CONVERT(VARCHAR(100), b.Validdate, 23) ELSE '' END AS Validdate, 
	       CASE g.billtype WHEN 541 THEN b.PickQty WHEN 551 THEN b.CheckQty ELSE 0 END AS Qty, b.P_id, b.Comment,
	       g.Y_id, g.Gspbillid, b.Gspsmb_id, g.BillType, g.C_id, g.S_id, g.InputMan, g.AuditMan1, g.AuditTime1, g.AuditMan2, g.AuditTime2, g.Ybillid, g.Ybilltype,
	       g.BillStates, g.Note, g.B_CustomName1, g.B_CustomName2, g.B_CustomName3, g.B_CustomName4, g.B_CustomName5, b.Price, b.TaxPrice, b.Total, b.TaxTotal,
	       b.DiscountPrice,'' as SerialNo, b.Discount, b.DiscountTotal, y.name AS YName,
	       p.retailprice,(CASE g.billtype WHEN 541 THEN b.PickQty WHEN 551 THEN b.CheckQty ELSE 0 END)*p.retailprice AS RetailTotal
	FROM   GSPbillidx g
		   INNER JOIN GSPbilldetail b ON g.Gspbillid = b.Gspbill_id
		   INNER JOIN vw_Products p ON b.P_id = p.product_id
		   LEFT JOIN vw_Storage s ON b.S_id = s.storage_id
		   LEFT JOIN clients c ON g.C_id = c.client_id
		   LEFT JOIN company c2 ON g.C_id = c2.company_id
		   LEFT JOIN employees e ON g.AuditMan1 = e.emp_id
		   INNER JOIN company y ON g.Y_id = y.company_id
		   LEFT JOIN employees e1 ON g.B_CustomName4 = CAST(e1.emp_id AS VARCHAR(8))
	WHERE  g.BillType = @BillType AND g.Y_id = @YId AND g.BillStates = 15 AND g.BillDate BETWEEN @Begin AND @End AND
	       (@SId = 0 OR g.S_id = @SId) AND 
	       (((@BillType = 541 AND @EId > 0 AND g.B_CustomName4 = CAST(@EId AS VARCHAR(8))) OR @EId = 0) OR
	       ((@BillType = 551 AND @EId > 0 AND g.AuditMan1 = @EId) OR @EId = 0)) AND
	       (((g.Ybilltype > 100 AND ISNULL(c2.company_id, 0) = @CompanyId) OR @CompanyId = 0) AND 
	       ((g.Ybilltype <= 100 AND ISNULL(c.client_id, 0) = @ClientId) OR @ClientId = 0))
	       AND (@YBillType = 0 or g.Ybilltype = @YBillType)
	ORDER BY g.Gspbillid DESC
END
GO
