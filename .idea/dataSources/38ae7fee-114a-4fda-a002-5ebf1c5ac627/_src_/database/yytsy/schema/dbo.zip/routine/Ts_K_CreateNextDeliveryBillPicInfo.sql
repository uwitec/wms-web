
CREATE PROCEDURE [dbo].[Ts_K_CreateNextDeliveryBillPicInfo]
(
    @Type       INT,                /*操作类型  0 删除本单据的关联记录；1 生成下一步单据的关联记录*/
    @BillId     INT,
    @BillType   INT
)
AS
BEGIN
	/*生成下一步单据的上游随货同行单记录*/
	DECLARE @NextBillId INT, @NextBillType INT, @IsDraft INT
	
	IF @Type = 0
	BEGIN
		PRINT 'DEL'
	END
	ELSE
	IF @Type = 1
	BEGIN
		SELECT TOP 1 @NextBillType = billType, @NextBillId = billId, @IsDraft = isDraft 
		  FROM VW_BILLTRACE 
		  WHERE billType IN (SELECT NextVch FROM VchFlow WHERE VchType = @BillType)
				AND traceGuid = (SELECT TOP 1 traceGuid FROM billTrace WHERE billType = @BillType AND billId = @BillId ORDER BY ID DESC)
		IF (@NextBillType > 0) AND (@NextBillId > 0)
		BEGIN
		    DELETE FROM DeliveryBillPicInfo WHERE BillID=@NextBillId AND BillType=@NextBillType
			INSERT INTO DeliveryBillPicInfo(BillID, BillType, IsDraft, DeliveryNo, SupplierId, PId, BatchNo, InstoreTime, PicPath, Y_Id, Comment)
			SELECT @NextBillId, @NextBillType, @IsDraft, DeliveryNo, SupplierId, PId, BatchNo, InstoreTime, PicPath, Y_Id, Comment 
				FROM DeliveryBillPicInfo 
			WHERE BillId = @BillId AND BillType = @BillType
		END
	END

END
GO
