/************************************************************
--过程名称：证书证明添加修改
--创建人：  YANRUI
--创建时间：2013-08-09 
--最后修改:


参数说明：
		  @Mrid  --0为添加，不为0是修改

备注：
**************************************************************/
create proc [dbo].[Ts_T_InsOrUpdataclientReport]
(   @Mrid      int,
    @repNo     varchar(100),
    @c_id      int,
    @rpn_id    int,
    @repname   varchar(120),
    @inputTime varchar(20),
    @path      varchar(120),
    @IndexID   int   
)
as

if @Mrid  = 0
begin
    if exists(select 1 from  ClientReport  where repNo = @repNo and ((c_id <> @c_id) or (rpn_id <> @rpn_id)) )
	begin
	  RAISERROR('证书编号,有重复！', 16, 1)
	  return-1
	end
	
	INSERT INTO [dbo].[ClientReport] 
	(
	 [repNo],
	 [c_id],
	 [rpn_id],
	 [repname],
	 [inputTime],
	 [pathName],
	 [IndexID]
	)
	Values
	(
	 @repNo ,   
	 @c_id ,
	 @rpn_id,    	 
	 @repname,
     @inputTime,
	 @path,
	 @IndexID 
	)
end else
begin
  if exists(select 1 from  ClientReport  where  repNo = @repNo and cr_id <> @Mrid and ((c_id <> @c_id) or (rpn_id <> @rpn_id))  )
begin
  RAISERROR('证书编号,有重复！',16,1)
  return-1
end
  update ClientReport 
  set [repNo]  = @repNo,
	  [c_id]   = @c_id,
	  [rpn_id] =@rpn_id,
	  [repname]=@repname,
	  [pathname] = @path,
	  [IndexID] = @IndexID
	 
  where cr_id =@Mrid 

end
GO
