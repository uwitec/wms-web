
/* =============================================*/
/* Author:  Huang.Y*/
/* Create date: 2011-4-14*/
/* Description: 由新品采购查询生成门店请货单*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_BuyCountMakeBill]
 @BeginDate  varchar(10) = '',
 @EndDate  varchar(10) = '',
 @Storage  int = 0,
 @Client   int = 0,
 @Company  int = 0,
 @Percent  NUMERIC(25,8) = 0,
 @eid   int = 0
AS
BEGIN
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @Storage is null  SET @Storage = 0
if @Client is null  SET @Client = 0
if @Company is null  SET @Company = 0
if @Percent is null  SET @Percent = 0
if @eid is null  SET @eid = 0
/*Params Ini end*/
 SET NOCOUNT ON;
 
 declare @nResult int
 declare @nBillId int
 declare @nRet int
 declare @nDtlRet int
 declare @yid int
 declare @today varchar(10)
 declare @szPeriod varchar(30)
 declare @nPeriod int
 declare @szBillSN varchar(200)
 
 select @yid = y_id from employees where emp_id = @eid
 set @today = convert(varchar(10), getdate(), 120)
 exec ts_GetSysValue 'AccountPeriod',@szPeriod output
 set @nPeriod = cast(@szPeriod as int)
 
 set @nResult = 0
 
exec TS_H_CreateBillSN 52, 1, null, @EId, @EId, @szBillSN output
			
exec ts_b_insertbillindexdraft @nRet output, 0, 7, 0, @today, @szBillSN, 52, 0, @company, @eid, 
  0, 0, 0, @eid, 0, 0, 0, 0, @nPeriod, '2', 0, 0, @yid, 0, 0, 0, 0, 
  '0', '【新品采购查询生成】','',0,'',0,0,0,0,0,0,0,0,0,0,'1111111',@yid
 if @nRet <> 0
 begin
  declare @pid int
  declare @qty int
  declare @unit int
  declare @guid uniqueidentifier
  declare curProducts cursor for
  SELECT     b.p_id, SUM(b.SendQTY * CASE WHEN i.billtype IN (21, 221) THEN - 1 ELSE 1 END) AS qty, p.unit1_id
  FROM         dbo.billidx AS i INNER JOIN
         dbo.buymanagebill AS b ON i.billid = b.bill_id INNER JOIN
         dbo.products AS p ON b.p_id = p.product_id
  WHERE     (p.buycount = 1) AND (i.billstates = '0') AND (i.C_ID = @Client OR @Client = 0) 
	AND (b.ss_id = @Storage OR @Storage = 0) AND (i.billdate BETWEEN @BeginDate AND @EndDate)
	AND (i.Billtype in (20, 21, 220, 221))
  GROUP BY b.p_id, p.unit1_id
  open curProducts
  fetch next from curProducts into @pid, @qty, @unit
  while @@fetch_status = 0
  begin
   set @qty = round(@qty * @percent / 100, 0)
   set @guid = newid()
   exec ts_b_insertbilldetaildraft @nDtlRet output, 7, 0, @nRet, 0, @pid, '', @qty, 
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '合格', 0, 0, 0, 0, 0, 0, 0, '', @unit,
    0, 0, 0, 0, 0, 0/*, 0, 0, 0, 0, 0, @eid, @guid, '', '', @yid, 0, 0, ''*/
   if @nDtlRet <> 1
   begin
	set @nResult = -1
    exec Ts_b_deletebilldraft @nDtlRet output, 7, @nRet
   end
   fetch next from curProducts into @pid, @qty, @unit
  end
  DEALLOCATE curProducts
 end
 return @nResult
END
GO
