
/* =============================================*/
/* Author:  黄耀*/
/* Create date: 2010-11-10*/
/* Description: 巡店日志查询*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_RepGoRound]
 @BeginDate	datetime,
 @EndDate	datetime,
 @E_ID		int = 0,
 @CName		varchar(100) = ''
AS
BEGIN
/*Params Ini begin*/
if @E_ID is null  SET @E_ID = 0
if @CName is null  SET @CName = ''
/*Params Ini end*/
 SET NOCOUNT ON;
 SELECT     r.r_id, e.name AS EmpName, e.emp_id, r.c_id, r.beginTime, r.endTime, r.comment, c.Name AS Company
FROM         dbo.EmpGoRound AS r INNER JOIN
                      dbo.employees AS e ON r.emp_id = e.emp_id INNER JOIN
                      dbo.dzClient AS c ON r.c_id = c.C_ID
 WHERE  r.beginTime >= @BeginDate AND r.beginTime <= @EndDate
    AND e.emp_id between case @e_id when 0 then 0 else @e_id end
     and case @e_id when 0 then 0x7fffffff else @e_id end
    AND c.Name like + '%' + @CName + '%'
 ORDER BY r.r_id DESC
END
GO
