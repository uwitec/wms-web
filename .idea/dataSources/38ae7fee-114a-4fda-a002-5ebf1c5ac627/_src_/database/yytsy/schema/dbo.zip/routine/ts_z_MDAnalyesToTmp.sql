

/******************************************

从门店请货分析写入BuyPlanTmp，用于生成采购计划

********************************************/
create  PROCEDURE [dbo].[ts_z_MDAnalyesToTmp]
(
  @BeginDate    varchar(100),
  @EndDate	varchar(100),
  @SelSQL       varchar(8000),
  @WhereSQL     varchar(8000),
  @szLoginY_id       int=0,
  @szYClass_id  varchar(50)
)

/*with encryption*/
AS
/*Params Ini begin*/
if @szLoginY_id is null  SET @szLoginY_id = 0
/*Params Ini end*/

	declare @SQLScript  VARCHAR(8000)
  if @szYClass_id in ('','%%','000000') set @szYClass_id='%%' else set @szYClass_id=@szYClass_id+'%'
  set @SQLScript = 'insert into BuyPlanTmp(inputman,pid,qty,unitid) (select '+@SelSQL+' from '+

  '(SELECT P.[Product_ID],p.[unit1_id], P.[Class_ID],
  ISNULL(SUM(B.[Quantity])    ,0)  AS [Quantity],
  ISNULL(SUM(B.[CostTotal])   ,0)  AS [CostTotal],
  ISNULL(SUM(B.[BuyComeQty])  ,0)  AS [BuyComeQty],
  ISNULL(SUM(B.[SaleComeQty]) ,0)  AS [SaleComeQty],
  ISNULL(SUM(B.[TranQty])     ,0)  AS [TranQty],
  ISNULL(SUM(B.[TranComeQty]) ,0)  AS [TranComeQty],
  ISNULL(MAX(B.[CostPrice])   ,0)  AS [CostPrice],
  ISNULL(MAX(B.[ClientName])  ,'''') AS [ClientName]
  FROM

  (SELECT [Product_ID], [Class_ID],[unit1_id]
   FROM products WHERE [Deleted]<>1 AND [Child_Number]=0) P
  LEFT JOIN

  (SELECT P.[Class_ID], 
  ISNULL(SH.[Quantity]    ,0) AS [Quantity],
  ISNULL(SH.[CostTotal]   ,0) AS [CostTotal],
  ISNULL(OB.[BuyComeQty]  ,0) AS [BuyComeQty],
  ISNULL(OB.[SaleComeQty] ,0) AS [SaleComeQty],
  ISNULL(TB.[Quantity]    ,0) AS [TranQty],
  ISNULL(TB.[TranComeQty] ,0) AS [TranComeQty],
  ISNULL(BM.[CostPrice]   ,0) AS [CostPrice],
  ISNULL(BM.[ClientName]  ,'''') AS [ClientName]
  FROM

  (SELECT [Product_ID], [Class_ID] FROM Products 
  WHERE [Deleted]<>1 AND [Child_Number]=0) P
  LEFT JOIN
  (SELECT [P_ID], SUM([Quantity]) AS [Quantity], SUM([CostTotal]) AS [CostTotal]
   FROM VW_C_StoreHouse where Y_id='+cast(@szLoginY_id as varchar(50))+' GROUP BY [P_ID]) SH
  ON P.[Product_ID]=SH.[P_ID]
  LEFT JOIN

  (SELECT ob.[P_ID], 
  ISNULL(SUM(CASE WHEN b.[billtype]=22 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [BuyComeQty], 
  ISNULL(SUM(CASE WHEN b.[billtype]=14 THEN ob.[Quantity]-ob.[ComeQty] END), 0) AS [SaleComeQty] 
  FROM VW_C_OrderIDX b, OrderBill ob
  WHERE b.[BillDate] BETWEEN '''+@BeginDate+''' AND '''+@EndDate+''' AND b.[BillID]=ob.[Bill_ID]
  AND b.[BillStates] IN (''3'') and b.YClass_id like '''+@szYClass_id+''' 
  GROUP BY ob.[P_ID]) OB
  ON P.[Product_ID]=OB.[P_ID]
  LEFT JOIN

  (SELECT tb.[P_ID], SUM(tb.[Quantity]) AS [Quantity], SUM(tb.[Quantity]-tb.[ComeQty]) AS [TranComeQty]
  FROM VW_C_Tranidx b, TranBill tb
  WHERE b.[BillDate] BETWEEN '''+@BeginDate+''' AND '''+@EndDate+''' AND b.[BillID]=tb.[Bill_ID]
  AND b.[BillStates] IN (''3'') and b.YClass_id like ''' +@szYClass_id+ ''' 
  GROUP BY tb.[P_ID]) TB
  ON P.[Product_ID]=TB.[P_ID]
  LEFT JOIN

  (SELECT  P.[Product_ID],
  ISNULL((SELECT TOP 1 PD.[CostPrice] FROM VW_C_PDetail PD, VW_C_BillIDX BI
  WHERE PD.[BillID]=BI.[BillID] AND BI.[Billtype]=20 AND BI.[BillStates]=''0''
  AND P.[Product_ID]=PD.[P_ID]
  ORDER BY BI.[BillDate] DESC, BI.[BillID] DESC), 0) AS [CostPrice],

  ISNULL((SELECT TOP 1 C.[Name] FROM VW_C_PDetail PD, VW_C_BillIDX BI, Clients C
  WHERE PD.[BillID]=BI.[BillID] AND BI.[Billtype]=20 AND BI.[BillStates]=''0''
  AND P.[Product_ID]=PD.[P_ID] AND BI.[C_ID]=C.[Client_ID]
  ORDER BY BI.[BillDate] DESC, BI.[BillID] DESC), '''') AS [ClientName]
  FROM Products P) BM 
  ON P.[Product_ID]=BM.[Product_ID]

  ) B
  ON  B.[Class_ID]=P.[Class_ID]
  GROUP BY P.[Product_ID], P.[Class_ID], p.[Unit1_id]) MDAnalyes

    where '+@WhereSQL+')'

/*PRINT @SQLScript*/
  EXEC(@SQLScript)

  GOTO SUCCEE

Succee:
  RETURN 0
GO
