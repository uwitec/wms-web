create procedure ts_e_StoreWMSInsBaseInfo
 @S_id  integer=0,
 @StoreKQSerial varchar(100)='',
 @StoreKQName varchar(100)='',
 @KQType     integer=0,
 @KQQuanFlag integer=0,
 @KQPickType integer=0,
 @KQPrintType integer=0,
 @RegionCode  varchar(400)='',
 @RegionComent varchar(400)='',
 @SType       varchar(10), /*'KQ' 表示库区，'QY' 表示区域，'HW'表示货位*/
 @nRet   INT OUTPUT
as
begin
 if @SType='KQ'
 begin
  insert into  stockArea(serial_number,name,s_id,comment)
  values(@StoreKQSerial,@StoreKQName,@S_id,'')
  insert into  WMSStockArea(Sa_ID, SAType,SAQuantityType,SAPickType,SAPrintType)
  values(@@IDENTITY,@KQType,@KQQuanFlag,@KQPickType,@KQPrintType)
 end
 if @SType='QY'
 begin
   insert into  WMSRegion(Store_KQ_ID,serial_number,Name,RegionCode,RegionComent)
   values(@S_id,@StoreKQSerial,@StoreKQName,@RegionCode,@RegionComent)
   select  @nRet= @@IDENTITY
   return  @nRet
 end
end
GO
