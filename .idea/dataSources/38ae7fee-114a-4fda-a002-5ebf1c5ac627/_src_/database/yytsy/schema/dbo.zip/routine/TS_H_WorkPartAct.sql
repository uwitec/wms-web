
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_WorkPartAct]
	/* Add the parameters for the stored procedure here*/
	@Act int,
	@Id	int,
	@Name varchar(50),
	@St datetime = 0,
	@Ed datetime = 0
AS
BEGIN
/*Params Ini begin*/
if @St is null  SET @St = 0
if @Ed is null  SET @Ed = 0
/*Params Ini end*/
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;

    /* Insert statements for procedure here*/
	if @Act = 0
	begin
		if Exists(select * from workpart where [name] = @name)
		begin
			Raiserror('名称不能重复！', 16, 1)
			return 0
		end
		insert into workpart(
			[name],
			[startTime],
			[endTime]
		) values(
			@name,
			@st,
			@ed
		)
		if @@rowcount > 0
			return @@identity
	end
	else
	if @Act = 1
	begin
		if Exists(select * from workpart where [name] = @name and part_id <> @Id)
		begin
			Raiserror('名称不能重复！', 16, 1)
			return 0
		end
		update workpart set
			[name] = @Name,
			[startTime] = @St,
			[endTime] = @Ed
		where [part_id] = @Id
		return @Id
	end
	if @Act = 2
	begin
		delete from workpart where [part_id] = @id
		return 1
	end
END
GO
