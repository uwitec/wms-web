


CREATE VIEW dbo.vw_L_Shop
AS
SELECT dbo.Shop.*, s.name AS S_Name, c.name AS c_Name,c.Rname ,
      Postypename = CASE shop.Postype WHEN 1 THEN '自营店' WHEN 0 THEN '加盟店' END
FROM dbo.Shop LEFT OUTER JOIN
      (select c.*,isnull(R.[name],'')as Rname from dbo.clients c left join Region R on c.region_id=R.region_id) c ON dbo.Shop.C_ID = c.client_id LEFT OUTER JOIN
      dbo.storages s ON dbo.Shop.S_ID = s.storage_id
WHERE (dbo.Shop.deleted = 0)
GO
