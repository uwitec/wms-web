
/* 功能：采购决策查询 类别级
  
*/

CREATE PROCEDURE TS_J_RepBuy02
( 
	@szbegindate varchar(12),   /*开始时间*/
	@szenddate   varchar(12),   /*结束时间*/
	@dateMode  int,		   /*1 月 2 季度 3 年		*/
	@CG_ID     int,         /*类别组id，必选项*/
	@szID      varchar(3000)= ''  /*选择的类别id*/
)

AS

/*处理查询日期*/
   declare @begindate datetime    /*开始时间*/
   declare @enddate   datetime    /*结束时间*/
   declare @Opendate   datetime   /*开账时间*/
             
   if @szbegindate <> ''
     set @begindate = CAST((@szbegindate+ '-01') as datetime)
     
   if @szenddate <> ''
     set @enddate = CAST((@szenddate+ '-01') as datetime)      
   set @enddate = dateadd(mm,1,@enddate) 
   set @enddate = @enddate -1 
   
   select @OpenDate = begindate from MonthSettleInfo where Y_ID =  2 and period = 1
   if @OpenDate is null set @OpenDate = @begindate
   if @begindate <  @OpenDate
     set @begindate = cast((cast(datepart(yyyy, @OpenDate) as varchar(4)) + '-' + cast(datepart(MM, @OpenDate) as varchar(2)) + '-' + '01') as datetime)

/*创建日期分段表，标识，时间跨度*/
/*创建需要查询的商品表，关联了类别组的商品*/
/*创建新品表*/
/*创建返回信息表*/
/*计算返回值*/


if OBJECT_ID('tempdb..#SplitDate' ) is not null 
  drop table #SplitDate
create table #splitDate
			 ( dateid int IDENTITY,   /*分隔日期后标识*/
			   FlagName varchar(50),  /*分隔后标识名称，例按年 2013 按月201306 按季度2013二季度*/
			   yyyy     varchar(10),  /*所属于年 */
			   qqq		varchar(10),  /*所属季度			   */
			   mm		varchar(10),  /*所属月			   			   	     */
			   begindate datetime,    /*本段分隔的开始时间*/
			   enddate   datetime,    /*本段分隔的结束时间*/
			   daycount  int		  /*本段分隔的天数统计	  */
			  )  
			  
if OBJECT_ID('tempdb..#QrProducts' ) is not null 
  drop table #QrProducts
create table #QrProducts
 			( p_id int,
 			  CG_id int
 			 )  
			  			  
			  
if OBJECT_ID('tempdb..#NewProducts' ) is not null 
  drop table #NewProducts
create table #NewProducts
			 ( dateid int,
			   p_id int,
			   cg_id int,			   
			   BuyDate datetime, 
			   preDate datetime,
			   DayCount int			   			  			   		  
			  )  			  
    
if OBJECT_ID('tempdb..#qrbuy01' ) is not null 
  drop table #qrbuy01
create table #qrbuy01
             ( dateid int,
               cg_id  int,           /*类别id                                   */
               buyQty NUMERIC(25,8),		 /*采购数量*/
               buytotal NUMERIC(25,8),		 /*采购金额	*/
               BackQty NUMERIC(25,8),        /*退货数量 not show*/
               BackTotal NUMERIC(25,8),      /*退货金额 not show */
               PlanRate NUMERIC(25,8),		 /*计划完成率*/
               orderRate NUMERIC(25,8),		 /*采购合同履约率*/
               backRate NUMERIC(25,8),		 /*退货发生率*/
               buyUpRate NUMERIC(25,8),		 /*采购增长率	*/
               newUpRate NUMERIC(25,8),		 /*新品增长率	*/
               newInRate NUMERIC(25,8),      /*新品引进率*/
               plancomeQty NUMERIC(25,8),    /*计划完成数量   */
               planQty     NUMERIC(25,8),    /*计划数量*/
               orderComeQty NUMERIC(25,8),   /*合同完成数量*/
               orderQty     NUMERIC(25,8),   /*合同数量*/
               newPQty    int,        /*新品数*/
               newPBuyQty NUMERIC(25,8),      /*新品采购数量                                                                                                        */
              )  


declare @nMinDateid int, @nMaxDateid int, @splitBegindate datetime,  @splitEnddate datetime, @nDateid int
declare @const_newDay int /*新品计算时间，定义为100天*/
DECLARE @info_ID INT 
DECLARE @ColName VARCHAR(100)
declare @PszSql varchar(8000)
set @const_newDay = 100
 if @szID<>'' 
 begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
            /*zjx.通过选择自定义类别id的字符串获取class_ID*/
			select   class_id into #Categoryclassid from customCategory where id in (select  szTYPE from  DecodeToStr(@szID))
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
 end
/*初始化#QrProducts*/
 if @CG_ID = 0 goto repend
 SET @PszSql = ' INSERT INTO #QrProducts(CG_id, p_id) '
                + ' select cc.id,p_id from products p ' 
                + ' left join ProductCategory pc on p.product_id = pc.P_id '
                + ' left join customCategory cc on pc.' + @ColName + ' = cc.class_id where ' + @ColName + ' in (select class_id from #Categoryclassid)'
 EXEC (@PszSql)    
if @dateMode = 1 goto repMonth    /*按月查询*/
if @dateMode = 2 goto repquarter  /*按季度查询*/
if @dateMode = 3 goto repYear     /*按年查询*/

repMonth:
/*取月begindate*/

set @begindate = DATEADD(MM, -1, @begindate)

insert into #SplitDate(begindate)
   select    
     dateadd(mm,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(mm,number,@begindate)<=@enddate
/*计算其他时间列     */
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+cast(DATEPART(MM, begindate) as varchar(2))+'月',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = DATEPART(MM, begindate)
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1
         
  goto  rep


repquarter:
/*取季度begindate*/
set @begindate = DATEADD(QQ, -1, @begindate) /*需要计算到选择时间段的上一期*/

insert into #SplitDate(begindate)
   select    
     dateadd(QQ,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(QQ,number,@begindate)<=@enddate
/*计算其他时间列*/
	update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年'+ cast(DATEPART(QQ, begindate) as varchar(2))+'季度',
						yyyy = DATEPART(YYYY, begindate), qqq = DATEPART(QQ, begindate),
						mm = 0	
	update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
	select @nMaxDateid = MAX(dateid) from #splitDate
    update #splitDate set enddate = @enddate where dateid = @nMaxDateid
    update #splitDate set daycount = cast((enddate - begindate) as Int)+1 	
                							
    goto rep
     

repYear:
  /*取年begindate*/

set @begindate = DATEADD(YYYY, -1, @begindate) /*需要计算到选择时间段的上一期*/
  
insert into #SplitDate(begindate)
   select    
     dateadd(YYYY,number,@begindate) 
   from 
     master..spt_values 
   where
     type='P' and  dateadd(YYYY,number,@begindate)<=@enddate
/*计算其他时间列*/
  update #splitDate set FlagName = cast(DATEPART(YYYY, begindate) as varchar(4)) +'年',
						yyyy = DATEPART(YYYY, begindate), qqq = 0, mm=0	
  update sp1 set enddate = sp2.begindate - 1 from #splitDate sp1, #splitDate sp2 where sp1.dateid = sp2.dateid -1
  select @nMaxDateid = MAX(dateid) from #splitDate
  update #splitDate set enddate = @enddate where dateid = @nMaxDateid
  update #splitDate set daycount = cast((enddate - begindate) as Int)+1										

  goto Rep
  
rep:
    /*初始化#qrbuy01表*/
  insert into #qrbuy01(dateid, cg_id)
     select sp.dateid, cg.cg_Id  
      from #splitDate sp
      cross join (select distinct cg_id as cg_Id from #QrProducts) cg
      order by sp.dateid, cg.cg_Id
                 
  /*采购数量	采购数量   --采购金额	采购金额   --退货总数量  --退货金额*/
          
  update b01 set b01.buyQty = t1.buyQty, b01.buytotal = t1.buytotal, 
				 b01.BackQty = t1.backQty, b01.BackTotal = t1.backTotal      
    from  #qrbuy01 b01,  
         (		           
		    select sp.dateid, p.CG_id,  
							 sum(case bi.billtype when 20 then mx.quantity else 0 end) as buyQty, 
							 sum(case bi.billtype when 20 then mx.taxtotal else 0  end) as buytotal,
							 sum(case bi.billtype when 21 then mx.quantity else 0 end) as backQty, 
							 sum(case bi.billtype when 21 then mx.taxtotal else 0  end) as backTotal                        
			   from billidx bi
			   inner join buymanagebill mx on bi.billid = mx.bill_id
			   inner join #QrProducts  p  on mx.p_id = p.p_id 
			   left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate
			   where bi.billtype in (20, 21) and bi.billstates = 0 and bi.billdate between @begindate and @enddate
					 and mx.p_id > 0 and mx.AOID = 0
			   group by sp.dateid, p.CG_id                
         ) t1
    where b01.dateid = t1.dateid and b01.cg_id = t1.CG_id  
    
       			 
/*采购计划完成率	采购合同数量/采购总数量  --采购合同履约率  	采购总数量/采购合同总数量*/
  update b01 set b01.plancomeQty = t1.plancomeqty, b01.planQty = t1.planQty, 
				 b01.orderComeQty = t1.orderComeQty, b01.orderQty = t1.orderQty      
    from  #qrbuy01 b01,  
         (
          select sp.dateid, p.CG_id,
				     sum(case bi.billtype when 26 then mx.ComeQty else 0 end) as plancomeqty, 
					 sum(case bi.billtype when 26 then mx.quantity else 0 end) as planQty,
					 sum(case bi.billtype when 22 then mx.ComeQty else 0 end) as orderComeQty, 
					 sum(case bi.billtype when 26 then mx.quantity else 0 end) as orderQty					                                                               
		   from #splitDate sp            
		   left join  Orderidx bi on bi.billdate between sp.begindate and sp.enddate
		   inner join orderbill mx  on mx.bill_id= bi.billid
		   inner join #qrproducts p on mx.p_id = p.p_id
		   where bi.billtype in (22, 26) and bi.billstates = 3 and bi.billdate between @begindate and @enddate 
		   group by sp.dateid, p.cg_Id          
         ) t1
    where b01.dateid = t1.dateid and b01.cg_id = t1.cg_id 
   
   /*清除null 避免计算出错*/
   update #qrbuy01 set planQty = 0			where planQty is null
   update #qrbuy01 set plancomeQty =  0		where plancomeQty is null
   update #qrbuy01 set orderComeQty = 0		where orderComeQty is null	
   update #qrbuy01 set orderQty =0			where orderQty is null
   update #qrbuy01 set buyQty = 0			where buyQty is null
   update #qrbuy01 set buytotal = 0			where buytotal is null
   update #qrbuy01 set BackQty = 0			where BackQty is null
   update #qrbuy01 set BackTotal = 0		where BackTotal is null
					   					          
   update #qrbuy01 set PlanRate = plancomeQty/planQty*100 where planQty <> 0
   update #qrbuy01 set orderRate = orderComeQty/orderQty*100 where orderQty <> 0
   
     
/*采购退货发生率	退货总数量/采购总数量 分母为0返回空     */
   update #qrbuy01 set backRate = BackQty/buyQty*100 where buyQty <> 0
/*采购增长率	(本期采购额-上期采购额)/上期采购额*/
   update q1 set buyUpRate = (q1.buytotal-q2.buytotal)/q2.buytotal*100 
     from #qrbuy01 q1, #qrbuy01 q2   
     where q1.dateid = q2.dateid + 1 and q2.buytotal <> 0 

/*计算新品*/
   
  insert into #NewProducts(dateid, p_id, cg_id, BuyDate)     
  select  sp.dateid, mx.p_Id, p.CG_id, MIN(cast(bi.billdate as NUMERIC(25,8))) as BuyDate
  from buymanagebill mx
       inner join #QrProducts p on mx.p_id = p.p_id
       inner join billidx bi on mx.bill_id= bi.billid
       left join #splitDate sp on bi.billdate between sp.begindate and sp.enddate
       where bi.billtype = 20 and billstates = 0
       group by sp.dateid, mx.p_id, p.CG_id
       
       /*前一次采购的最后时间*/
              
  update n1 set predate = t1.predate 
    from #NewProducts n1,                        
       (select np.dateid, np.cg_id, mx.p_id, MAX(cast(bi.billdate as NUMERIC(25,8))) as preDate   
         from billidx bi
         inner join buymanagebill mx on bi.billid = mx.bill_id
         inner join #newproducts  np on mx.p_id = np.p_id and bi.billdate < np.BuyDate
         where  bi.billtype = 20 and billstates = 0
         group by np.dateid, mx.p_id, np.cg_id) t1
       where n1.dateid = t1.dateid and n1.p_id = t1.p_id and n1.cg_id = t1.cg_id 
          
  update #NewProducts set BuyDate = 0 where buydate is null
  update #NewProducts set preDate = 0 where preDate is null
    
  update #NewProducts set DayCount = cast((BuyDate - preDate) as int)
  delete #NewProducts where DayCount < @const_newDay                         								                  
/*新品月增长率	新品默认为100天未采购；(本期采购新增品种数-上期采购新增品种数)/上期采购新增品种数 */
  update b1 set newPQty = t1.newPQty
    from #qrbuy01 b1,
         (select dateid, cg_id, COUNT(1) as newPQty from #NewProducts
            group by dateid, cg_id
         ) t1
    where b1.dateid = t1.dateid  and b1.cg_id = t1.cg_id         
  update #qrbuy01 set newPQty = 0 where newPQty is null
  update b1 set newUpRate = (b1.newPQty - b2.NewPQty)/b2.newPQty*100 
			from #qrbuy01 b1, #qrbuy01 b2
			where b1.dateid = b2.dateid + 1 and b1.cg_id = b2.cg_id and  b2.newPQty <> 0
			    
/*新品月引进率	新品默认为100天未采购；本期内新品种采购的数量/本期采购商品总数量(含退货)*/
  
  update b01 set b01.newPBuyQty = t1.newPBuyQty
    from  #qrbuy01 b01,  
         (select sp.dateid, np.cg_id, sum(case bi.billtype when 20 then mx.quantity else -mx.quantity end) as newPBuyQty                                             
       from billidx bi
       inner join  buymanagebill mx on bi.billid = mx.bill_id    
       left join #splitDate  sp on  bi.billdate between sp.begindate and sp.enddate 
       inner join  #NewProducts np on mx.p_id = np.p_id and sp.dateid = np.dateid
       where bi.billtype in (20, 21) and bi.billstates = 0 and bi.billdate between @begindate and @enddate 
			 and mx.p_id >0
       group by sp.dateid, np.cg_id) t1
    where b01.dateid = t1.dateid  and b01.cg_id = t1.cg_id
   
  update #qrbuy01 set newPBuyQty = 0 where newPBuyQty is null
  update #qrbuy01 set newInRate = newPBuyQty/(buyQty-BackQty)*100 where  (buyQty-BackQty) <> 0
      
  goto repend  
    
repend:
   declare @nSL int, @nDJ int, @nTotal int, @nTaxPrice int, @nOther int      
   select @nSL = sysValue from sysconfig where [sysname]='SLFMT'
   select @nDJ = sysValue from sysconfig where [sysname]='DJFMT'
   select @nTotal = sysValue from sysconfig where [sysname]='TOTALFMT'
   select @nTaxPrice = sysValue from sysconfig where [sysname]='TAXPRICEFMT'
   select @nOther = sysValue from sysconfig where [sysname]='NUMERIC(25,8)FMT' 


   select @nMinDateid = MIN(dateid)  from #SplitDate
   select 
		  /*b.dateid, */
		  dbo.DecimalQrValue(@nSL,b.buyQty) buyQty,
		  dbo.DecimalQrValue(@ntotal,b.buytotal) buytotal,
		  /*dbo.DecimalQrValue(@nSL,b.BackQty) BackQty,*/
		  /*dbo.DecimalQrValue(@ntotal,b.BackTotal) BackTotal,*/
		  dbo.DecimalQrValue(@nOther,b.PlanRate) PlanRate,
		  dbo.DecimalQrValue(@nOther,b.orderRate) orderRate,
		  dbo.DecimalQrValue(@nOther,b.backRate) backRate,
		  dbo.DecimalQrValue(@nOther,b.buyUpRate) buyUpRate,
		  dbo.DecimalQrValue(@nOther,b.newUpRate) newUpRate,
		  dbo.DecimalQrValue(@nOther,b.newInRate) newInRate,
		  /*dbo.DecimalQrValue(@nSL,b.plancomeQty) plancomeQty, */
		  /*dbo.DecimalQrValue(@nSL,b.planQty) planQty,     */
		  /*dbo.DecimalQrValue(@nSL,b.orderComeQty) orderComeQty,*/
		  /*dbo.DecimalQrValue(@nSL,b.orderQty) orderQty,    */
		  /*dbo.DecimalQrValue(@nSL,b.newPQty) newPQty,*/
		  /*dbo.DecimalQrValue(@nSL,b.newPBuyQty) newPBuyQty,                                                                                                                                                                                                                                      */
          sd.FlagName, /*sd.yyyy, sd.qqq, sd.mm, sd.begindate, sd.enddate, sd.daycount,*/
          isnull(c1.name, '') as c1name, isnull(c2.name, '') as c2name, isnull(c3.name, '') as c3name
          /*isnull(c1.id, 0) as c1id, isnull(c2.id, 0) as c2id, isnull(c3.id, 0) as c3id,*/
          /*isnull(c1.class_id, '') as c1class_Id, isnull(c2.class_id, '') as c2class_id, isnull(c3.class_id, '') as c3class_id                                   */
     from  #qrbuy01 b 
     left join #SplitDate sd on b.dateid = sd.dateid  
     left join customCategory cg on b.cg_id = cg.id
     left join customCategory c1 on LEFT(cg.class_id, 4) = c1.class_id and LEN(c1.class_id) =4
     left join customCategory c2 on LEFT(cg.class_id, 6) = c2.class_id and LEN(c2.class_id) =6 
     left join customCategory c3 on LEFT(cg.class_id, 8) = c3.class_id and LEN(c3.class_id) =8                     
     where sd.dateid >  @nMinDateid  
                
   return 0
GO
