-- =============================================
-- Create date: <2015-07-02>
-- Description:	<手机版-排行榜>
-- =============================================
CREATE PROCEDURE [dbo].[WebApp_QueryPhone_SaleBuyList] 
(
    @begindate datetime=0, -- 开始时间
	@EndDate datetime=0,   --结束时间
	@isClient tinyint=0,   
	@isSale tinyint=0,
	@Params VARCHAR(100)--预留接口进行后期特殊版本传值
)
AS
BEGIN
SET NOCOUNT ON;
declare @y_id int
select @y_id  = dbo.webapp_get_param(@Params, 'y_id', default, default)
SET @y_id=ISNULL(@y_id,0) 

--初始化时间
 set @begindate = CONVERT(varchar(10),@begindate,20)
 set @EndDate = CONVERT(varchar(10),@EndDate,20) +' 23:59:59'
--销售排行榜
if @isSale=1	
	begin
	   if @isClient=0  --按商品统计
	   begin
			SELECT  
			ISNULL(P.[name],'') AS name,
			ISNULL(SUM(SM.[Quantity]), 0) AS quantity,
			ISNULL(SUM(SM.[CostTotal]), 0) AS costtotal,
			ISNULL(SUM(SM.taxtotal), 0) AS total,
			(ISNULL(SUM(SM.taxtotal), 0)-ISNULL(SUM(SM.[CostTotal]), 0)) AS gain
			FROM Products P 
			LEFT JOIN
				(SELECT VP.p_id,
		   				ISNULL(SUM(-VP.[Quantity]), 0) AS [Quantity],
						ISNULL(SUM(CASE VP.AOID WHEN 0 THEN -VP.[CostTotal] ELSE 0 END), 0) AS [CostTotal],
						ISNULL(SUM(-VP.taxtotal), 0) AS taxtotal
				   FROM productdetail VP inner JOIN Billidx VB on  VP.[BillID]=VB.[BillID]
				  WHERE VB.[Billtype] IN (10,11,18,19,112,16,17,32,170) AND VB.[Billstates]='0' 
				   and vb.billdate between @begindate and @EndDate
				   and vp.p_id>0
				  GROUP BY VP.p_id) SM ON SM.p_id=P.product_id 
			where (p.deleted<>1 and p.child_number=0) 
			 and (sm.Quantity<>0 or sm.taxtotal<>0)  
			GROUP BY P.[name] order by quantity desc 
	   end 
	   if @isClient=1 --按客户统计
			begin
				SELECT  
				ISNULL(c.name,'') AS name,
				ISNULL(SUM(SM.[Quantity]), 0) AS quantity,
				ISNULL(SUM(SM.[CostTotal]), 0) AS costtotal,
				ISNULL(SUM(SM.taxtotal), 0) AS total,
				(ISNULL(SUM(SM.taxtotal), 0)-ISNULL(SUM(SM.[CostTotal]), 0)) AS gain
				FROM clients c 
				LEFT JOIN
				(SELECT VB.c_id,
				        ISNULL(SUM(-VP.[Quantity]), 0) AS [Quantity],
				        ISNULL(SUM(CASE VP.AOID WHEN 0 THEN -VP.[CostTotal] ELSE 0 END), 0) AS [CostTotal],
				        ISNULL(SUM(-VP.taxtotal), 0) AS taxtotal
			  	   FROM productdetail VP inner JOIN Billidx VB on  VP.[BillID]=VB.[BillID]
				   JOIN products p ON p.product_id=vp.p_id
				WHERE (p.deleted<>1 and p.child_number=0) and vp.p_id>0
				  and  VB.[Billtype] IN (10,11,18,19,112,16,17,32,170) AND VB.[Billstates]='0' 
				  AND vb.billdate between @begindate and @EndDate				  
				GROUP BY VB.c_id) SM ON SM.c_id=c.client_id 				
				where c.deleted<>1 and (sm.Quantity<>0 or sm.taxtotal<>0)  
				GROUP BY c.name order by quantity desc 
			end       
			if @isClient=2 --按职员统计
			begin
				SELECT  
				ISNULL(e.name,'') AS name,
				ISNULL(SUM(SM.[Quantity]), 0) AS quantity,
				ISNULL(SUM(SM.[CostTotal]), 0) AS costtotal,
				ISNULL(SUM(SM.taxtotal), 0) AS total,
				(ISNULL(SUM(SM.taxtotal), 0)-ISNULL(SUM(SM.[CostTotal]), 0)) AS gain
				FROM employees e 
				LEFT JOIN
				(SELECT VB.e_id,
				        ISNULL(SUM(-VP.[Quantity]), 0) AS [Quantity],
				        ISNULL(SUM(CASE VP.AOID WHEN 0 THEN -VP.[CostTotal] ELSE 0 END), 0) AS [CostTotal],
				        ISNULL(SUM(-VP.taxtotal), 0) AS taxtotal
				   FROM productdetail VP inner JOIN Billidx VB on  VP.[BillID]=VB.[BillID]
				   JOIN products p ON p.product_id=vp.p_id and vp.p_id>0
			  	  WHERE (p.deleted<>1 and p.child_number=0)
				    and VB.[Billtype] IN (10,11,18,19,112,16,17,32,170) AND VB.[Billstates]='0' 
				    AND VB.[Billdate] between @begindate and @EndDate								
				  GROUP BY VB.e_id) SM ON SM.e_id= e.emp_id				
				where e.deleted<>1 and(sm.Quantity<>0 or sm.taxtotal<>0)  
				GROUP BY e.name order by quantity desc 
			end       
	end 
	if @isSale=0  --采购排行榜
	begin      --这个需要各项目重写一下，改成采购排行。       
			if @isClient=0  --按商品统计
			begin
			  SELECT p.name AS name,
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.[quantity] else -a.[quantity] end), 0) AS quantity, 
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.[costprice]*a.[quantity] else -(a.[costprice]*a.[quantity]) end), 0) AS [CostTotal],
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.taxtotal else -a.taxtotal end), 0) AS total,
				0 AS gain
				FROM Billidx b
				 JOIN BuymanageBill a  ON b.[billid]=a.[bill_id]
				 JOIN products p ON a.p_id=p.product_id
				WHERE p.[deleted]<>1 and p.child_number=0 
				AND  b.[billdate] between @begindate and @EndDate
				AND b.[billtype] IN (20,21,35,122,175,24,25) AND b.[billstates]='0'
				GROUP BY p.name ORDER BY quantity desc
			end 
			if @isClient=1 --按客户统计
			begin
				SELECT p.name AS name,
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.[quantity] else -a.[quantity] end), 0) AS quantity, 
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.[costprice]*a.[quantity] else -(a.[costprice]*a.[quantity]) end), 0) AS [CostTotal],
				ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,24) or (b.[billtype]=175 and a.iotag=1) THEN a.taxtotal else -a.taxtotal end), 0) AS total,
				0 AS gain
				FROM Billidx b
				 JOIN BuymanageBill a  ON b.[billid]=a.[bill_id]
				 JOIN clients p ON b.c_id=p.client_id
				 JOIN products p1 ON a.p_id=p1.product_id
				WHERE  p.[deleted]=0 AND (p1.[deleted]<>1 and p1.child_number=0)
				AND  b.[billdate] between @begindate and @EndDate
				AND b.[billtype] IN (20,21,35,122,175,24,25) AND b.[billstates]='0'
				GROUP BY p.name ORDER BY quantity desc
			end
	END
IF @isSale=2
BEGIN
	SELECT  
	ISNULL(c.name,'') AS '单位名称',
	sum(ISNULL(SM.taxtotal, 0)) AS '金额'
	FROM clients c 
	LEFT JOIN
	(SELECT VB.c_id,
	        ISNULL(SUM(-VP.[Quantity]), 0) AS [Quantity],
	        ISNULL(SUM(CASE VP.AOID WHEN 0 THEN -VP.[CostTotal] ELSE 0 END), 0) AS [CostTotal],
	        ISNULL(SUM(-VP.taxtotal), 0) AS taxtotal
	   FROM productdetail VP inner JOIN Billidx VB on  VP.[BillID]=VB.[BillID]
	   JOIN products p ON p.product_id=vp.p_id 
	  WHERE (p.deleted<>1 and p.child_number=0)
		and VB.[Billtype] IN (10,11,18,19,112,16,17,32,170) AND VB.[Billstates]='0' 
	    AND VB.[Billdate] between @begindate and @EndDate		
	  GROUP BY VB.c_id) SM ON SM.c_id=c.client_id 
	where c.deleted<>1 and(sm.Quantity<>0 or sm.taxtotal<>0)  
	GROUP BY c.name order by '金额' desc 
END
IF @isClient=2
BEGIN
	SELECT p.name AS '单位名称',
	       ISNULL(SUM(CASE WHEN b.[billtype] IN (20,35,122,151,24) or (b.[billtype]=175 and a.iotag=1) THEN a.taxtotal else -a.taxtotal end), 0) AS '金额'
	  FROM BuymanageBill a 
	 JOIN Billidx b ON b.[billid]=a.[bill_id]
	 JOIN clients p ON b.c_id=p.client_id
	 JOIN products p1 ON a.p_id=p1.product_id
	WHERE  p.[deleted]<>1 and p.child_number=0
	 and  b.[billdate] between @begindate and @EndDate
	AND b.[billtype] IN (20,21,35,122,175,24,25) AND b.[billstates]='0'
	GROUP BY p.name ORDER BY '金额' desc
END
END
GO
