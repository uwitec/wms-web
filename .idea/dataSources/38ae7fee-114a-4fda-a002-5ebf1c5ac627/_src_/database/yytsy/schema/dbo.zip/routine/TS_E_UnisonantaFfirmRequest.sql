CREATE PROCEDURE TS_E_UnisonantaFfirmRequest
    @stardate DATETIME = 0
   ,/*开始时间*/
    @enddate DATETIME = 0
   ,/*结束时间*/
    @c_id INT = 0
   ,/*仓库*/
    @e_id INT = 0
   ,/*职员*/
    @b_id INT = 0
   ,/*单位*/
    @strAll INT = 0
   ,/*回执情况 0代表全部，1代表已确认 2代表未确认,如果@iutype=3的时候代表单位ID*/
    @iutype INT = 0
   ,/*0代表查询，1代表确认数据，*/
    @sbillid VARCHAR(100)
   ,/*返回选择单据的单据ID字符串*/
    @auditname VARCHAR(100)/*审核人名字*/
AS /*EXEC TS_E_UnisonantaFfirmRequest;1 '2014-01-01','2015-04-24',0,0,0,0*/
/*EXEC TS_E_UnisonantaFfirmRequest;1 '2015-04-01','2015-04-24',0,0,0,1*/
    BEGIN
        IF @iutype = 0
            BEGIN
                IF @strAll = 0
                    BEGIN
                        SELECT 
                            z.*
                        FROM
                            ( SELECT
                                a.billid,a.billdate,a.auditdate AS gzdate,
                                a.billnumber,b.Comment AS billtype,
                                c.name AS inputename,d.name AS jsrename,
                                e.name AS auditename,a.ysmoney AS total,
                                a.ssmoney AS sstotal,
                                ISNULL(h.kptotal,0) AS kptotal,
                                ISNULL(f.saleEName,'') AS ywdbEname,a.summary
                                ,CASE WHEN a.summary LIKE '%已确认%' THEN '是' ELSE '否' END AS ifqr
                                ,a.billtype AS billtypeid,a.Y_ID,
                                a.inputman,ISNULL(ct.name,'') AS ClientName
                              FROM
                                billidx a
                                LEFT JOIN VchType b ON a.billtype = b.Vch_ID
                                LEFT JOIN employees c ON a.inputman = c.emp_id
                                LEFT JOIN employees d ON a.e_id = d.emp_id
                                LEFT JOIN employees e ON a.auditman = e.emp_id
                                LEFT JOIN orderidx g ON a.order_id = g.billid
                                LEFT JOIN wtorder f ON g.WT_ID = f.WT_ID
                                LEFT JOIN ( SELECT
                                                SUM(TOTAL) AS kptotal,billid
                                            FROM
                                                invoice
                                            GROUP BY
                                                billid
                                          ) h ON g.billid = a.billid
                                LEFT JOIN Clients ct ON a.c_id = ct.client_id
                              WHERE
                                a.billtype = 10  
                                AND a.billdate BETWEEN @stardate AND @enddate
                                AND ( a.sout_id = @c_id  
                                      OR @c_id = 0 )
                                AND ( a.e_id = @e_id   
                                      OR @e_id = 0 )
                                AND ( a.c_id = @b_id    
                                      OR @b_id = 0 )
                                AND a.billstates=0      
                            ) z
                            INNER JOIN ( SELECT DISTINCT
                                            a.bill_id
                                         FROM
                                            salemanagebill a
                                            INNER JOIN ( SELECT
                                                            p.*
                                                         FROM
                                                            products p
                                                            LEFT JOIN gspPropert g ON p.gspFlag = g.gspId
                                                         WHERE
                                                            g.doubleCheck = 1
                                                       ) b ON a.p_id = b.product_id
                                       ) h ON z.billid = h.bill_id
                    END
                IF @strAll = 1
                    BEGIN
                        SELECT 
                            z.*
                        FROM
                            ( SELECT
                                a.billid,a.billdate,a.auditdate AS gzdate,
                                a.billnumber,b.Comment AS billtype,
                                c.name AS inputename,d.name AS jsrename,
                                e.name AS auditename,a.ysmoney AS total,
                                a.ssmoney AS sstotal,
                                ISNULL(h.kptotal,0) AS kptotal,
                                ISNULL(f.saleEName,'') AS ywdbEname,a.summary,
                                '是' AS ifqr,a.billtype AS billtypeid,a.Y_ID,
                                a.inputman,ISNULL(ct.name,'') AS ClientName
                              FROM
                                billidx a
                                LEFT JOIN VchType b ON a.billtype = b.Vch_ID
                                LEFT JOIN employees c ON a.inputman = c.emp_id
                                LEFT JOIN employees d ON a.e_id = d.emp_id				
                                LEFT JOIN employees e ON a.auditman = e.emp_id
                                LEFT JOIN orderidx g ON a.order_id = g.billid
                                LEFT JOIN wtorder f ON g.WT_ID = f.WT_ID
                                LEFT JOIN ( SELECT
                                                SUM(TOTAL) AS kptotal,billid
                                            FROM
                                                invoice
                                            GROUP BY
                                                billid
                                          ) h ON g.billid = a.billid
                                LEFT JOIN Clients ct ON a.c_id = ct.client_id
                              WHERE
                                a.billtype = 10
                                AND a.summary LIKE '%已确认%'
                                AND a.billdate BETWEEN @stardate AND @enddate
                                AND ( a.sout_id = @c_id
                                      OR @c_id = 0 )
                                AND ( a.e_id = @e_id
                                      OR @e_id = 0 )
                                AND ( a.c_id = @b_id
                                      OR @b_id = 0 )
                                AND a.billstates=0            
                            ) z
                            INNER JOIN ( SELECT DISTINCT
                                            bill_id
                                         FROM
                                            salemanagebill a
                                            INNER JOIN ( SELECT
                                                            p.*
                                                         FROM
                                                            products p
                                                            LEFT JOIN gspPropert g ON p.gspFlag = g.gspId
                                                         WHERE
                                                            g.doubleCheck = 1
                                                       ) b ON a.p_id = b.product_id
                                       ) h ON z.billid = h.bill_id
                    END
                IF @strAll = 2
                    BEGIN
                        SELECT 
                            z.*
                        FROM
                            ( SELECT
                                a.billid,a.billdate,a.auditdate AS gzdate,
                                a.billnumber,b.Comment AS billtype,
                                c.name AS inputename,d.name AS jsrename,
                                e.name AS auditename,a.ysmoney AS total,
                                a.ssmoney AS sstotal,
                                ISNULL(h.kptotal,0) AS kptotal,
                                ISNULL(f.saleEName,'') AS ywdbEname,a.summary,
                                '否' AS ifqr,a.billtype AS billtypeid,a.Y_ID,
                                a.inputman,ISNULL(ct.name,'') AS ClientName
                              FROM
                                billidx a
                                LEFT JOIN VchType b ON a.billtype = b.Vch_ID
                                LEFT JOIN employees c ON a.inputman = c.emp_id
                                LEFT JOIN employees d ON a.e_id = d.emp_id
                                LEFT JOIN employees e ON a.auditman = e.emp_id
                                LEFT JOIN orderidx g ON a.order_id = g.billid
                                LEFT JOIN wtorder f ON g.WT_ID = f.WT_ID
                                LEFT JOIN ( SELECT
                                                SUM(TOTAL) AS kptotal,billid
                                            FROM
                                                invoice
                                            GROUP BY
                                                billid
                                          ) h ON g.billid = a.billid
                                LEFT JOIN Clients ct ON a.c_id = ct.client_id
                              WHERE
                                a.billtype = 10
                                AND a.summary NOT LIKE '%已确认%'
                                AND a.billdate BETWEEN @stardate AND @enddate
                                AND ( a.sout_id = @c_id
                                      OR @c_id = 0 )
                                AND ( a.e_id = @e_id
                                      OR @e_id = 0 )
                                AND ( a.c_id = @b_id
                                      OR @b_id = 0 )
                                AND a.billstates=0 
                            ) z
                            INNER JOIN ( SELECT DISTINCT
                                            bill_id
                                         FROM
                                            salemanagebill a
                                            INNER JOIN ( SELECT
                                                            p.*
                                                         FROM
                                                            products p
                                                            LEFT JOIN gspPropert g ON p.gspFlag = g.gspId
                                                         WHERE
                                                            g.doubleCheck = 1
                                                       ) b ON a.p_id = b.product_id
                                       ) h ON z.billid = h.bill_id
                    END                                       
            END
        IF @iutype = 1
            BEGIN
                UPDATE
                    billidx
                SET summary = '已确认，' + '随货同行单确认审核人：' + @auditname
                WHERE
                    billid IN ( SELECT
                                    szTYPE
                                FROM
                                    DecodeToStr(@sbillid) )
            END
    END
GO
