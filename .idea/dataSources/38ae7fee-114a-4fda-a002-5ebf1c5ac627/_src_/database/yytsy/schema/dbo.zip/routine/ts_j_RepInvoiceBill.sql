

CREATE	 PROCEDURE [ts_j_RepInvoiceBill]
	(
	 @begindate 	datetime =0,  		/*开始时间*/
 	 @enddate	datetime =0,		/*结束时间*/
 	 @szInvoiceNO   varchar(60) ='',	/*发票号码*/
     @szSummary	varchar(120) ='',       /*发票摘要*/
     @nInvoice      int = -1,		/*发票类型*/
     @nInvoiceType  int = -1,		/*发票种类*/
 	 @nJsFlag	int = -1,		/*开票方式*/
     @nC_ID		int = 0,		/*往来单位*/
 	 @nDep_id	int = 0,		/*部门*/
  	 @nInputMan	int = 0,		/*开票人*/
	 @nAuditMan	int = 0,		/*审核人*/
  	 @nReAuditMan	int = 0,		/*复核人*/
     @szStates      varchar(30) ='',	/*发票状态 使用　11代替复核单据*/
	 @szIVBillType  varchar(30) ='',	/*发票单*/
	 @OperatorID    int = 0,
     @szYClass_id   varchar(50) ='',
     @szBillNumber  varchar(50) ='',     /*发票编号 --2016.10.25-Wsj-tfs:41954*/
     @SendC_id  int =0                  /*收货方*/
        )
AS 
/*Params Ini begin*/
if @begindate is null  SET @begindate = 0
if @enddate is null  SET @enddate = 0
if @szInvoiceNO is null  SET @szInvoiceNO = ''
if @szSummary is null  SET @szSummary = ''
if @nInvoice is null  SET @nInvoice = -1
if @nInvoiceType is null  SET @nInvoiceType = -1
if @nJsFlag is null  SET @nJsFlag = -1
if @nC_ID is null  SET @nC_ID = 0
if @nDep_id is null  SET @nDep_id = 0
if @nInputMan is null  SET @nInputMan = 0
if @nAuditMan is null  SET @nAuditMan = 0
if @nReAuditMan is null  SET @nReAuditMan = 0
if @szStates is null  SET @szStates = ''
if @szIVBillType is null  SET @szIVBillType = ''
if @OperatorID is null  SET @OperatorID = 0
if @szYClass_id is null  SET @szYClass_id = ''
if @szBillNumber is null  SET @szBillNumber = ''
if @SendC_id is null set @SendC_id = 0
/*Params Ini end*/



declare @nReAuditFlag int
Declare @ClientTable INTEGER,@Companytable INTEGER,@Storetable INTEGER

if @enddate <=1 		set @enddate = '2099-12-31'
if @szInvoiceNO <> ''  		set @szInvoiceNO = '%'+@szInvoiceNO+'%'
if @szSummary <> ''  		set @szSummary = '%'+@szSummary+'%'
if @szStates ='' 		set @szStates = '0,1,2,3,11' 
if @szIVBillType = '' 		set @szIVBillType = '0,1' 
if @szYClass_id=''  set @szYClass_id='%%' else set @szYClass_id=@szYClass_id+'%'
if @szBillNumber <> ''  	set @szBillNumber = '%'+@szBillNumber+'%'

if exists(select 1 from dbo.DecodeStr(@szStates) where type = 11)
  set @nReAuditFlag = 1
else
  set @nReAuditFlag = 0

  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*---仓库授权*/
  create table #storageslimt(id int)
   if not exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@OperatorID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
       insert into #storageslimt 
       select 0
   end
   else
   begin 
      set @Storetable=1
      /*找出有权限的仓库*/
      Insert #storagestable ([id]) 
      select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@OperatorID  and u.Type='S' and C.class_id like u.psc_id+'%')
     /*找出没有仓库权限的明细行的单子*/
      insert into #storageslimt
      select r.id from invoice a 
		   left join invoiceidx  r on a.invoiceid=r.id
           inner join billidx c  on a.billid=c.billid
           left join salemanagebill   b on a.billid=b.bill_id where c.billtype in (10,11,12,13,16,17,32,112,210,211)  and r.InvoiceDate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and c.billstates=0 and b.p_id>0
      union all
      select r.id from invoice a 
		   left join invoiceidx  r on a.invoiceid=r.id
           inner join billidx c  on a.billid=c.billid
           left join buymanagebill   b on a.billid=b.bill_id where c.billtype in (20,21,24,25,28,35,122,220,221)  and r.InvoiceDate between @begindate and @enddate
           and b.ss_id not in (select id from #storagestable) and c.billstates=0 and b.p_id>0
   end
/*---仓库授权*/

  select 
	 iv.[id] as invoiceid,		iv.invoicedate,			iv.InvoiceNO,  iv.billnumber,
	 case iv.InvoiceBillType when 1 then -iv.invoicetotal else iv.invoicetotal end as invoicetotal,		
	 iv.invoice,			iv.inputman,
 	 iv.auditman,			iv.states,			iv.comment,
	 iv.invoicetype,		iv.c_id,			iv.departmentid,
	 iv.Jsflag,			iv.InvoiceBillType,		iv.ReAuditFlag,
	 iv.ReAuditMan,			iv.OrderID,			iv.InvoiceGuid,
	 iv.Summary,			case when iv.states = 0 then '未审核'
					     when iv.states = 1 then '已审核'
					     when iv.states = 2 and iv.ReauditFlag =  0 then '已过账'
					     when iv.states = 3 then '已作废'
					     when iv.states = 2 and iv.ReauditFlag =  1 then '已复核'
					end as StatesName,
  	 case iv.InvoiceBillType when 0 then '发票单'
				 when 1 then '发票退回单'
	 end  as IVBillName,	 
         case iv.invoice when 0 then ' '
                      when 1 then '收据' 
 	 	      when 2 then '普票'
 	 	      when 3 then '增值税票'
		      when 4 then '其他'
	 end as invoiceName,
	 case iv.invoiceType when 0 then '销售发票'
                          when 1 then '采购发票' 
 	 	          when 2 then '财务发票'
	 end as invoiceTypeName,
	 case iv.jsflag when 0 then ' '
                     when 1 then '按单' 
 	 	     when 2 then '按行'
	 end as jsFlagName,

    isnull(c.[name],' ') as CName, 		isnull(e1.[name],' ') as InputmanName,		
    isnull(e2.[name],' ') as AuditmanName,      isnull(e3.[name],' ') as ReAuditmanName,
    case  when  ir.ir_id >0 then '发票已扫描' else ' ' end as isscan, 	
    isnull(d.[name], ' ') as depname,           iv.Y_id, isnull(c1.name,'') as SendCName
    from invoiceidx iv 
    left join Clients c on iv.c_id = c.Client_id
    left join Clients c1 on iv.SendC_id = c1.Client_id
    left join employees e1 on iv.inputman = e1.emp_id
    left join employees e2 on iv.auditman = e2.emp_id 
    left join employees e3 on iv.ReAuditman = e3.emp_id
    left join department d on iv.departmentid = d.departmentid
    left join Company    Y ON iv.Y_id=Y.Company_id
    left join invoiceReport ir on iv.invoiceno = ir.invoiceno
        where iv.InvoiceDate between CONVERT(VARCHAR(10),@BeginDate,20) and CONVERT(VARCHAR(10),@endDate,20) and
 	  (iv.InvoiceNO like @szInvoiceNo or @szInvoiceNo = '') and
 	  (iv.Invoice = @nInvoice or @nInvoice = -1) and
 	  (iv.InvoiceType = @nInvoiceType or @nInvoiceType = -1) and
	  (iv.JsFlag = @nJsFlag or @nJsFlag = -1) and
	  (iv.C_id = @nC_ID or @nC_ID = 0) and
	  (@SendC_id = 0 or iv.SendC_id = @SendC_id) and
 	  (iv.DepartmentID = @nDep_id or  @nDep_id = 0) and
 	  (iv.InputMan = @nInputMan or @nInputMan = 0) and
	  (iv.AuditMan = @nAuditMan or @nAuditMan = 0) and
 	  (iv.ReAuditMan = @nReAuditMan or @nReAuditMan = 0) and
 	  ((iv.States in (select type from dbo.DecodeStr(@szStates))) or (@nReAuditFlag = 1 and iv.ReAuditFlag = 1)) and
          iv.InvoiceBilltype in (select type from dbo.DecodeStr(@szIVBillType)) and
          (iv.Summary like @szSummary or @szSummary = '')
          and (iv.billnumber like @szBillNumber or @szBillNumber = '')
          and Y.Class_id like @szYClass_id
          AND ((@ClientTable=0) or (iv.c_id in (select [id] from #Clienttable)))
          AND ((@Companytable=0)or (iv.Y_id in (select [id] from #Companytable)))
          and id not in (select id from #storageslimt)
        
        
  order by iv.invoicedate,iv.[id] 	 
  drop table #storageslimt
GO
