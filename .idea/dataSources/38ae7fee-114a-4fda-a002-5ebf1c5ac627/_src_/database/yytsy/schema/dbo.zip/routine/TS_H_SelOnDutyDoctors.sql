
/* =============================================*/
/* Author:		<Author,,Name>*/
/* Create date: <Create Date,,>*/
/* Description:	<Description,,>*/
/* =============================================*/
CREATE PROCEDURE TS_H_SelOnDutyDoctors
	/* Add the parameters for the stored procedure here*/
	@DeptID		int,
	@WorkDay	datetime,
	@PartID		int
AS
BEGIN
	SET NOCOUNT ON;

	select * from VW_H_ExamDoctor
	where dep_id = @DeptID
	and workday = @WorkDay and WorkPart_ID = @PartID
END
GO
