






CREATE FUNCTION AuthorizeStorage(@OperatorID int)
RETURNS TABLE
AS
RETURN(
 SELECT distinct S.Storage_ID, S.Class_ID, S.Parent_ID, S.Child_Number, S.Serial_Number, S.[Name] FROM Storages S 
    INNER JOIN
     (SELECT * FROM userauthorize WHERE upper(type) = 'S' AND e_id = @OperatorID) AS UA
   ON     (LEFT(S.Class_id,LEN(UA.psc_id)) = UA.psc_id) OR (LEFT(UA.psc_id,LEN(S.class_id)) = S.class_id)
 UNION ALL
  SELECT distinct S.Storage_ID, S.Class_ID, S.Parent_ID, S.Child_Number, S.Serial_Number, S.[Name] FROM Storages S  
      WHERE (NOT EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'S' AND e_id = @OperatorID))
       OR (EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'S' AND e_id = @OperatorID AND psc_id = '000000'))
)
GO
