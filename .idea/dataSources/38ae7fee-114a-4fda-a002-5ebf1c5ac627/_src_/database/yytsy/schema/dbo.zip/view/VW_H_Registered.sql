
CREATE VIEW dbo.VW_H_Registered
AS
SELECT     TOP 100 PERCENT dbo.Patients.PatientID, dbo.Patients.Name, dbo.Patients.sex, dbo.Patients.Tel, dbo.Patients.Birthday, dbo.Patients.Job, 
                      dbo.Patients.Address, dbo.Patients.Comment, dbo.Patients.IDCard, dbo.Patients.BulidDate, dbo.Patients.Pos_Id, dbo.Patients.Deleted, 
                      dbo.Patients.PinYin, dbo.Patients.Guid, dbo.Patients.ModifyDate, dbo.Patients.isVIP, dbo.Patients.VIP_ID, ISNULL(Registered.count, 0) AS Count, 
                      dbo.employees.name AS PosName, dbo.GetAge(dbo.Patients.Birthday, GETDATE()) AS Age, Registered_2.Reg_ID, Registered_2.Doctor_ID, 
                      Registered_2.PresState, Registered_2.CaseState, Registered_2.RegDate, employees_1.name AS DoctorName, employees_2.name AS RegMame, 
                      dbo.department.departmentId, dbo.department.name AS DeptName, dbo.WorkPlan.WorkDay AS ExamDate
                       ,isnull(VIPCard.CardNo,'') as CardNo 
FROM         dbo.Patients INNER JOIN
                      dbo.employees ON dbo.Patients.Pos_Id = dbo.employees.emp_id INNER JOIN
                      dbo.Registered AS Registered_2 ON dbo.Patients.PatientID = Registered_2.Patient_ID INNER JOIN
                      dbo.employees AS employees_1 ON employees_1.emp_id = Registered_2.Doctor_ID INNER JOIN
                      dbo.employees AS employees_2 ON Registered_2.Emp_ID = employees_2.emp_id INNER JOIN
                      dbo.department ON employees_1.dep_id = dbo.department.departmentId INNER JOIN
                      dbo.WorkPlan ON Registered_2.RegWorkPlan = dbo.WorkPlan.Plan_ID RIGHT OUTER JOIN
                          (SELECT     Patient_ID, MAX(RegDate) AS regDate, COUNT(*) AS count
                            FROM          dbo.Registered AS Registered_1
                            GROUP BY Patient_ID) AS Registered ON dbo.Patients.PatientID = Registered.Patient_ID
                 LEFT JOIN  VIPCard on  VIPCard.VIPCardID=dbo.Patients.VIP_ID               
WHERE     (dbo.Patients.Deleted = 0)
ORDER BY Registered_2.RegDate DESC
GO
