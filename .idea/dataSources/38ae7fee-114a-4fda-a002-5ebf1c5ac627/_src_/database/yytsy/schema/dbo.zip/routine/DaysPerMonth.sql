
CREATE FUNCTION DaysPerMonth( @AYear  INT, @AMonth INT)
RETURNS INT AS  
BEGIN 
  declare @Ret INT

  SET @Ret =
  case @AMonth
  when 1 then 31
  when 2 then 28
  when 3 then 31
  when 4 then 30
  when 5 then 31
  when 6 then 30
  when 7 then 31
  when 8 then 31
  when 9 then 30
  when 10 then 31
  when 11 then 30
  else 31
  end
  
  IF (@AMonth = 2) and (dbo.IsLeapYear(@AYear) =1)
  SET @Ret= @Ret +1
  return @Ret
END
GO
