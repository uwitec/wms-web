
CREATE VIEW dbo.vw_L_Companybalance
AS
  SELECT YB.* ,ISNULL(C.class_id,'')CClass_ID,ISNULL(C.[name],'')Cname,
  ISNULL(Y.class_id,'')Yclass_ID, ISNULL(Y.[name],'')Yname
  FROM  Companybalance YB
  
   LEFT OUTER JOIN  Company    c  ON YB.c_id=c.Company_id
   LEFT OUTER JOIN  Company    Y  ON YB.Y_id=Y.company_id
where Yb.c_id  in (select Company_id from Company where deleted=0)
GO
