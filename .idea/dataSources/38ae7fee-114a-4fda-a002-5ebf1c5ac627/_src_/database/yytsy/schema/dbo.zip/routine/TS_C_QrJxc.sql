

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/*************************************************

全能进销存变动表

*************************************************/

Create  PROCEDURE [dbo].[TS_C_QrJxc]
( @BeginDate    DATETIME=0,
 @EndDate    DATETIME=0,
 @szSClass_ID VARCHAR(30)='%%',
 @szParent_id VARCHAR(30)='000000',
 @szListFlag   VARCHAR(1)='L',
 @nYClassid                 varchar(100)='',
 @nloginEID               int=0,
 @isaddDate              int=0 
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szSClass_ID is null  SET @szSClass_ID = '%%'
if @szParent_id is null  SET @szParent_id = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end    */

/*SET NOCOUNT ON*/
	DECLARE @Stores TABLE (S_Id[INT],WholeFlag[INT])
	IF (@szSClass_ID <> '' AND @szSClass_ID <> '%%')
	BEGIN
		INSERT INTO @Stores
		SELECT storage_id,WholeFlag FROM storages WHERE [deleted] = 0 AND child_number = 0 AND class_id LIKE @szSClass_ID + '%' 
	END
	ELSE
	BEGIN
		IF @nYClassid = '' 
		BEGIN
			INSERT INTO @Stores
			SELECT storage_id,WholeFlag FROM storages WHERE [deleted] = 0 AND child_number = 0
		END
		ELSE
		BEGIN
			INSERT INTO @Stores
			SELECT s.storage_id,s.WholeFlag
			FROM   storages s
			WHERE  s.Y_ID IN (SELECT c.company_id
							  FROM   company c
							  WHERE  c.class_id LIKE @nYClassid + '%')
		END 
	END

  IF @szSClass_ID='' SELECT @szSClass_ID='%%' else select @szSClass_ID=@szSClass_ID+'%'
declare @lenth tinyint 
 	if @szParent_id ='000000' set @lenth = 6 else set @lenth = len(@szParent_id)+6
declare @likeParentclassid varchar(30),@nyid int
 if @nYClassid=''
   set @nyid=2
 else
   select @nyid=company_id  from company where class_id= @nYClassid
select @likeParentclassid = case @szParent_id when '000000' then '%' else @szParent_id+'%' end

  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer

/*  create table #Clienttable([id] int) */
  create table #Companytable([id] int)
/*  create table #employeestable([id] int)*/
/*  create table #storagestable([id] int)*/
/*
-----往来单位授权
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
-----往来单位授权
*/
/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/
/*
-----职员授权
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

-----职员授权

-----仓库授权
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   --end
   else
   begin 
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
-----仓库授权
*/
/*-Wsj--2016.10.19 add 在途数量，在途金额*/
declare @ztSClass varchar(30), @ztYClass varchar(30)
if @szSClass_ID in('','%%','%%%') set @ztSClass = '%%' 
    else set @ztSClass = @szSClass_ID+'%'
if @nYClassid in('','%%','%%%') set @ztYClass = '%%' 
    else set @ztSClass = @nYClassid+'%'    
    /*XXX.优化速度*/

/*Wusj.2017-07-13优化    */
SELECT billid,YGuid INTO #TmpA FROM billidx a where billtype = 152 AND billstates = 0 
SELECT YGuid INTO #TmpB FROM billidx a where billtype = 162 AND billstates = 0
SELECT billid INTO #TmpC FROM #TmpA WHERE YGuid NOT IN (SELECT YGuid FROM #TmpB)    
    
select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,sum(costtaxtotal) as ZTcosttaxtotal,p.class_id as pclass_id into #ztTable from 
                    #TmpC a left join salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where st.class_id like @ztSClass and c.class_id like @ztYClass
                    group by p_id,p.class_id     
/*-Wsj--2016.10.19 add 在途数量，在途金额*/
/*xzdong-2016-12-13-TFS-43783-增加含税金额*/
/*print convert(varchar(23),getdate(),121)*/


/*-xxx.2017-01-17  优化全能进销存，根据实际业务情况和现有的脚本写法，主要对case when 的使用优化，根据业务和查询的字段的关系，建立多个临时表，从而减少不必要的case when  条件计算的开销*/
select pd.billtype,quantity,costtotal,taxtotal,commissionflag,costtaxtotal,pd.AOID,
isnull(p.class_id,'') as PClass_id,WholeFlag
into #mxtable
             from   
                  (select p_id,pd.quantity,costtotal,taxtotal,costtaxtotal,billdate,storetype,aoid,commissionflag,s_id,RowE_id,billtype,bi.Y_id,bi.c_id /*xddong-2016-10-09-TFS-41512-修改含税成本金额*/
                     from ProductDetail PD
                     inner join billidx bi on pd.billid=bi.billid
                     where (billdate between @begindate and @EndDate) and
                      billstates='0' and pd.storetype=0 and p_id>0 and billtype not in (51)/*yypeng-TFSBUG46217-2017-03-08--不统计批次调整单*/
                      /*and pd.aoid in (0,7)*/
                   )pd                             
                   INNER JOIN  products  p on p_id=p.product_id  
                   INNER JOIN  @Stores  s ON s.S_Id=pd.s_id
                   INNER JOIN  Company   Y on pd.Y_id=Y.company_id
                where  p.class_id like @likeParentclassid  
                   AND (@nYClassid='' or (Y.class_id like @nYClassid+'%'))
                   AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))

/*给临时表创建索引*/
create index  idx_TempTable on #mxtable(billtype)



/*print convert(varchar(23),getdate(),121)*/
/*4*/
/*-提出计算的部分作为临时表*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		SUM(Case when WholeFlag <> 3 then ABS(k.quantity) else 0 end) AS [salequantity],
        ABS(SUM(Case when WholeFlag <> 3 then k.costtotal else 0 end)) AS [saletotal],
		ABS(SUM(Case when WholeFlag <> 3 then k.taxtotal  else 0 end)) AS [saletaxtotal],
		/*本期出库销售利润金额*/
		SUM(Case WholeFlag when 0 then -(k.taxtotal-k.costtotal) else 0 end) AS [salegaintotal],
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],		
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]						
	into #xshztable
	FROM 
          #mxtable k where billtype in (10,12,212) and aoid in (0,7)
 	GROUP BY PClass_id
/*3*/
/*-提出计算的部分作为临时表*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		SUM(CASE WHEN  k.billtype in (20,222)     THEN ABS(k.quantity) ELSE 0 END) AS [buyquantity],
		ABS(SUM(CASE WHEN  k.billtype in (20,222)    THEN k.costtotal ELSE 0 END)) AS [buytotal],
		ABS(SUM(CASE WHEN  k.billtype in (20,222)     THEN k.taxtotal ELSE 0 END)) AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],        
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]			
	into #cghztable
	FROM 
          #mxtable k where  billtype in (20,222) and aoid in (0,7)
 	GROUP BY PClass_id
/*6*/
/*-提出计算的部分作为临时表*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],		
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		SUM(CASE WHEN  k.billtype IN(150, 152)  and k.quantity < 0  THEN ABS(k.quantity) ELSE 0 END) AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		ABS(SUM(CASE WHEN  k.billtype IN(150, 152)  and k.quantity < 0  THEN k.costtotal ELSE 0 END)) AS [ComSendTotal],
		ABS(SUM(CASE WHEN  k.billtype IN(150, 152)  and k.quantity < 0  THEN k.taxtotal ELSE 0 END)) AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		SUM(CASE WHEN  k.billtype IN(151,153)    THEN ABS(k.quantity) ELSE 0 END) AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		ABS(SUM(CASE WHEN  k.billtype IN(151,153)    THEN K.costtotal ELSE 0 END)) AS [ComSendBackTotal],
		ABS(SUM(CASE WHEN  k.billtype IN(151,153)    THEN K.costtaxtotal ELSE 0 END)) AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]		
	into #pshztable
	FROM 
          #mxtable k where billtype in (150, 152,151,153) and aoid in (0,7)
 	GROUP BY PClass_id
/*6*/
/*-提出计算的部分作为临时表*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],		
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		SUM(CASE WHEN  k.billtype IN(160, 162, 152)  and k.quantity > 0 THEN ABS(k.quantity) ELSE 0 END) AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		ABS(SUM(CASE WHEN  k.billtype IN(160, 162, 152) and k.quantity > 0 THEN k.costtotal ELSE 0 END)) AS [ComRecTotal],
		ABS(SUM(CASE WHEN  k.billtype IN(160, 162, 152)  and k.quantity > 0 THEN k.taxtotal ELSE 0 END)) AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		SUM(CASE WHEN  k.billtype IN(161,163)   THEN ABS(k.quantity) ELSE 0 END) AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		ABS(SUM(CASE WHEN  k.billtype IN(161,163)  THEN k.costtotal ELSE 0 END)) AS [ComRecBackTotal],
	    ABS(SUM(CASE WHEN  k.billtype IN(161,163)   THEN k.taxtotal ELSE 0 END)) AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]			
	into #psthztable
	FROM 
          #mxtable k where  billtype in (160, 162, 152,161,163) and aoid in (0,7)
 	GROUP BY PClass_id
/*26*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],		
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		SUM(CASE WHEN  k.billtype =21      THEN ABS(k.quantity) ELSE 0 END) AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		ABS(SUM(CASE WHEN  k.billtype =21     THEN k.costtotal ELSE 0 END)) AS [buybacktotal],
		ABS(SUM(CASE WHEN  k.billtype =21      THEN k.taxtotal ELSE 0 END)) AS [buybacktaxtotal],
		SUM(CASE WHEN  k.billtype IN(11,13) and WholeFlag <> 3  THEN ABS(k.quantity) ELSE 0 END) AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		ABS(SUM(CASE WHEN  k.billtype IN(11,13) and WholeFlag <> 3  THEN k.costtotal ELSE 0 END)) AS [salebacktotal],
		ABS(SUM(CASE WHEN  k.billtype IN(11,13) and WholeFlag <> 3  THEN k.taxtotal ELSE 0 END)) AS [salebacktaxcost],
		SUM(CASE WHEN  k.billtype =41     THEN ABS(k.quantity) ELSE 0 END) AS [losequantity],
		ABS(SUM(CASE WHEN  k.billtype =41      THEN k.costtotal ELSE 0 END)) AS [loseTotal],
		SUM(CASE WHEN  k.billtype =42    THEN ABS(k.quantity) ELSE 0 END) AS [overflowquantity],
		ABS(SUM(CASE WHEN  k.billtype =42      THEN k.costtotal ELSE 0 END)) AS [overflowtotal],
		SUM(CASE WHEN  k.billtype =44  and k.quantity>0 THEN ABS(k.quantity)  ELSE 0 END) AS [tjdbrkquantity],
		SUM(CASE WHEN  k.billtype =44  and k.quantity<0 THEN ABS(k.quantity)  ELSE 0 END) AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		ABS(SUM(CASE WHEN  k.billtype =44 and k.quantity>0 THEN k.costtotal  ELSE 0 END)) AS [tjdbrktotal],
	    ABS(SUM(CASE WHEN  k.billtype =44  and k.quantity>0 THEN k.taxtotal  ELSE 0 END)) AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		ABS(SUM(CASE WHEN  k.billtype =44  and k.quantity<0 THEN k.costtotal  ELSE 0 END)) AS [tjdbcktotal],
	    ABS(SUM(CASE WHEN  k.billtype =44  and k.quantity<0 THEN k.taxtotal  ELSE 0 END)) AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		SUM(CASE WHEN  k.billtype =45  and k.quantity>0 THEN ABS(k.quantity) ELSE 0 END) AS [bjdbrkquantity],  	
		SUM(CASE WHEN  k.billtype =45   and k.quantity<0 THEN ABS(k.quantity)  ELSE 0 END) AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		ABS(SUM(CASE WHEN  k.billtype =45  and k.quantity>0 THEN k.costtotal  ELSE 0 END)) AS [bjdbrktotal],
	    ABS(SUM(CASE WHEN  k.billtype =45  and k.quantity>0 THEN k.taxtotal  ELSE 0 END)) AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		ABS(SUM(CASE WHEN  k.billtype =45 and k.quantity<0 THEN k.costtotal  ELSE 0 END)) AS [bjdbcktotal],
	    ABS(SUM(CASE WHEN  k.billtype =45 and k.quantity<0 THEN k.taxtotal  ELSE 0 END)) AS [bjdbcktaxtotal],
		SUM(CASE WHEN  k.billtype =46     THEN ABS(k.quantity) ELSE 0 END) AS [givequantity],
		ABS(SUM(CASE WHEN  k.billtype =46     THEN k.costtotal ELSE 0 END)) AS [givetotal],
		SUM(CASE WHEN  k.billtype =47    THEN ABS(k.quantity) ELSE 0 END) AS [gainquantity],
		ABS(SUM(CASE WHEN  k.billtype =47      THEN k.costtotal ELSE 0 END)) AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		SUM(CASE WHEN k.billtype IN(11,13) and WholeFlag = 3  THEN ABS(k.quantity) ELSE 0 END) AS [ClkBqBackQuantity],
		ABS(SUM(CASE WHEN k.billtype IN(11,13) and WholeFlag = 3  THEN k.taxtotal ELSE 0 END)) AS [ClkBqBackTaxTotal],
		ABS(SUM(CASE WHEN k.billtype IN(11,13) and WholeFlag = 3  THEN k.costtaxtotal ELSE 0 END)) AS [ClkBqBackCostTaxTotal],			
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]			
	into #aptable
	FROM 
          #mxtable k where billtype in (21,11,13,41,42,44,45,46,47) and AOID in (0,7)
 	GROUP BY PClass_id

/*30*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],		
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		SUM(CASE WHEN  k.billtype =110  AND k.commissionflag=0   THEN ABS(k.quantity) ELSE 0 END) AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		ABS(SUM(CASE WHEN  k.billtype =110  AND k.commissionflag=0   THEN k.costtotal ELSE 0 END)) AS [wtfhtotal],
		ABS(SUM(CASE WHEN  k.billtype =110  AND k.commissionflag=0   THEN k.taxtotal ELSE 0 END)) AS [wtfhtaxtotal],
		SUM(CASE WHEN  k.billtype =111  AND k.commissionflag=0   THEN ABS(k.quantity) ELSE 0 END) AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		ABS(SUM(CASE WHEN  k.billtype =111  AND k.commissionflag=0   THEN k.costtotal ELSE 0 END)) AS [wtthtotal],
		ABS(SUM(CASE WHEN  k.billtype =111  AND k.commissionflag=0   THEN k.taxtotal ELSE 0 END)) AS [wtthtaxtotal],
		SUM(CASE WHEN  k.billtype =32  AND k.commissionflag=3   THEN ABS(k.quantity) ELSE 0 END) AS [salelendquantity],
		ABS(SUM(CASE WHEN  k.billtype =32  AND k.commissionflag=3   THEN k.costtotal ELSE 0 END)) AS [salelendtotal],
		SUM(CASE WHEN  k.billtype =30  AND k.commissionflag=3   THEN ABS(k.quantity) ELSE 0 END) AS [lendquantity],
		ABS(SUM(CASE WHEN  k.billtype =30  AND k.commissionflag=3   THEN k.costtotal ELSE 0 END)) AS [lendtotal],
		SUM(CASE WHEN  k.billtype =31  AND k.commissionflag=3   THEN ABS(k.quantity) ELSE 0 END) AS [lendthquantity],
		ABS(SUM(CASE WHEN  k.billtype =31  AND k.commissionflag=3   THEN k.costtotal ELSE 0 END)) AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		SUM(CASE WHEN  k.billtype =120  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		ABS(SUM(CASE WHEN  k.billtype =120  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [stshtotal],
		ABS(SUM(CASE WHEN  k.billtype =120  AND k.commissionflag=2    THEN k.taxtotal ELSE 0 END)) AS [stshtaxtotal],
		SUM(CASE WHEN  k.billtype =121  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		ABS(SUM(CASE WHEN  k.billtype =121  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [stthtotal],
		ABS(SUM(CASE WHEN  k.billtype =121  AND k.commissionflag=2    THEN k.taxtotal ELSE 0 END)) AS [stthtaxtotal],
		SUM(CASE WHEN  k.billtype =35  AND k.commissionflag=4    THEN ABS(k.quantity) ELSE 0 END) AS [buyborrowquantity],
		ABS(SUM(CASE WHEN  k.billtype =35  AND k.commissionflag=4    THEN k.costtotal ELSE 0 END)) AS [buyborrowtotal],
		SUM(CASE WHEN  k.billtype =33  AND k.commissionflag=4    THEN ABS(k.quantity) ELSE 0 END) AS [borrowquantity],
		ABS(SUM(CASE WHEN  k.billtype =33  AND k.commissionflag=4    THEN k.costtotal ELSE 0 END)) AS [borrowtotal],
		SUM(CASE WHEN  k.billtype =34  AND k.commissionflag=4    THEN ABS(k.quantity) ELSE 0 END) AS [borrowthquantity],
		ABS(SUM(CASE WHEN  k.billtype =34  AND k.commissionflag=4    THEN k.costtotal ELSE 0 END)) AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		SUM(CASE WHEN k.billtype IN(130,43,40,48,50,51,54,55)  and k.quantity>0 THEN k.quantity  ELSE 0 END) AS [qtrkquantity],	
		ABS(SUM(CASE WHEN  k.billtype IN(130,43,40,48,50,51,54,55) and k.quantity>0 THEN k.costtotal  ELSE 0 END)) AS [qtrktotal],
	    ABS(SUM(CASE WHEN  k.billtype IN(130,43,40,48,50,51,54,55) and k.quantity>0 THEN k.taxtotal ELSE 0 END)) AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		SUM(CASE WHEN  k.billtype IN(131,43,40,49,50,51,53,56) and k.quantity<0 THEN ABS(k.quantity) ELSE 0 END) AS [qtckquantity],	
		ABS(SUM(CASE WHEN  k.billtype IN(131,43,40,49,50,51,53,56) and k.quantity<0 THEN k.costtaxtotal  ELSE 0 END)) AS [qtcktotal],
	    ABS(SUM(CASE WHEN  k.billtype IN(131,43,40,49,50,51,53,56) and k.quantity<0 THEN k.costtaxtotal  ELSE 0 END)) AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]		
	into #dxtable
	FROM 
          #mxtable k where billtype in (110,111,32,30,31,120,121,35,33,34,130,43,40,48,50,51,54,55,49,131)
          /*(131,43,40,49,50,51,53,56) */
 	GROUP BY PClass_id

/*6*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],		
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		SUM(CASE WHEN  k.quantity<0     THEN ABS(k.quantity) ELSE 0 END) AS [bqckquantity],
		ABS(SUM(CASE WHEN  k.quantity<0     THEN k.costtotal ELSE 0 END)) AS [bqcktotal],
		ABS(SUM(CASE WHEN  k.quantity<0     THEN k.costtaxtotal ELSE 0 END)) AS [bqckcosttaxtotal],
		SUM(CASE WHEN  k.quantity>0     THEN k.quantity ELSE 0 END) AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		ABS(SUM(CASE WHEN  k.quantity>0     THEN k.costtotal ELSE 0 END)) AS [bqrktotal],
		ABS(SUM(CASE WHEN  k.quantity>0     THEN k.costtaxtotal ELSE 0 END)) AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		0 AS [ClkBqSaleQuantity],
        0 AS [ClkBqSaleTaxTotal],
        0 AS [ClkBqSaleCostTotal],
		0 AS [ClkBqSaleCostTaxTotal],
		0 AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		0 AS [ClkBqRkQuantity],
		0 AS [ClkBqRkTaxTotal],
		0 AS [ClkBqRkCostTotal],				
		0 AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		0 AS [CldCkQuantity],
		0 AS [CldCkTaxTotal],
		0 AS [CldCkCostTaxTotal]		
	into #sytable
	FROM 
          #mxtable k 
 	GROUP BY PClass_id

/*-提出计算的部分作为临时表*/
SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		0 AS [salequantity],
        0 AS [saletotal],
		0 AS [saletaxtotal],
		/*本期出库销售利润金额*/
		0 AS [salegaintotal],
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		0 AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		0 AS [wtfhtotal],
		0 AS [wtfhtaxtotal],
		0 AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		0 AS [wtthtotal],
		0 AS [wtthtaxtotal],
		0 AS [salelendquantity],
		0 AS [salelendtotal],
		0 AS [lendquantity],
		0 AS [lendtotal],
		0 AS [lendthquantity],
		0 AS [lendthtotal],
		0 AS [buyquantity],
		0 AS [buytotal],
		0 AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		0 AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		0 AS [stshtotal],
		0 AS [stshtaxtotal],
		0 AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		0 AS [stthtotal],
		0 AS [stthtaxtotal],
		0 AS [buyborrowquantity],
		0 AS [buyborrowtotal],
		0 AS [borrowquantity],
		0 AS [borrowtotal],
		0 AS [borrowthquantity],
		0 AS [borrowthtotal],
		0 AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		0 AS [buybacktotal],
		0 AS [buybacktaxtotal],
		0 AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		0 AS [salebacktotal],
		0 AS [salebacktaxcost],
		0 AS [losequantity],
		0 AS [loseTotal],
		0 AS [overflowquantity],
		0 AS [overflowtotal],
		0 AS [tjdbrkquantity],
		0 AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		0 AS [tjdbrktotal],
	    0 AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		0 AS [tjdbcktotal],
	    0 AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		0 AS [bjdbrkquantity],  	
		0 AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		0 AS [bjdbrktotal],
	    0 AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		0 AS [bjdbcktotal],
	    0 AS [bjdbcktaxtotal],
		0 AS [givequantity],
		0 AS [givetotal],
		0 AS [gainquantity],
		0 AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		0 AS [qtrkquantity],	
		0 AS [qtrktotal],
	    0 AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		0 AS [qtckquantity],	
		0 AS [qtcktotal],
	    0 AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		0 AS [bqckquantity],
		0 AS [bqcktotal],
		0 AS [bqckcosttaxtotal],
		0 AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		0 AS [bqrktotal],
		0 AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		0 AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		0 AS [ComRecTotal],
		0 AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		0 AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		0 AS [ComRecBackTotal],
	    0 AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		0 AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		0 AS [ComSendTotal],
		0 AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		0 AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		0 AS [ComSendBackTotal],
		0 AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		SUM(Case when WholeFlag = 3 and billtype = 12 then ABS(k.quantity) else 0 end) AS [ClkBqSaleQuantity],
        ABS(SUM(Case when WholeFlag = 3 and billtype = 12 then  k.taxtotal  else 0 end)) AS [ClkBqSaleTaxTotal],
        ABS(SUM(Case when WholeFlag = 3 and billtype = 12 then  k.costtotal  else 0 end)) AS [ClkBqSaleCostTotal],
		ABS(SUM(Case when WholeFlag = 3 and billtype = 12 then  k.costtaxtotal else 0 end)) AS [ClkBqSaleCostTaxTotal],
		SUM(Case when WholeFlag = 3 and billtype = 12 then -(k.taxtotal-k.costtaxtotal) else 0 end) AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量*/
		SUM(CASE WHEN WholeFlag = 3 and billtype = 39 THEN ABS(k.quantity) ELSE 0 END) AS [ClkBqRkQuantity],
		ABS(SUM(CASE WHEN WholeFlag = 3 and  billtype = 39 THEN k.costtotal ELSE 0 END)) AS [ClkBqRkTaxTotal], 
		ABS(SUM(CASE WHEN WholeFlag = 3 and  billtype = 39 THEN k.costtotal ELSE 0 END)) AS [ClkBqRkCostTotal],		
		ABS(SUM(CASE WHEN WholeFlag = 3 and  billtype = 39 THEN k.costtaxtotal ELSE 0 END)) AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		0 AS [ClkBqBackQuantity],
		0 AS [ClkBqBackTaxTotal],
		0 AS [ClkBqBackCostTaxTotal],				
		/*拆零单本期出库数量*/
		SUM(CASE WHEN WholeFlag <> 3 and billtype = 39  THEN ABS(k.quantity) ELSE 0 END) AS [CldCkQuantity],
		ABS(SUM(CASE WHEN WholeFlag <> 3 and  billtype = 39  THEN k.taxtotal ELSE 0 END)) AS [CldCkTaxTotal],
		ABS(SUM(CASE WHEN WholeFlag <> 3 and  billtype = 39  THEN k.costtaxtotal ELSE 0 END)) AS [CldCkCostTaxTotal]					
	into #cltable
	FROM 
          #mxtable k where billtype in (12,39)
 	GROUP BY PClass_id

SELECT	PClass_id,
        /*本期出库发货数量，本期出库发货金额，本期出库销售税后金额*/
		sum([salequantity]) [salequantity],
        SUM([saletotal]) AS [saletotal],
		SUM([saletaxtotal]) AS [saletaxtotal],
		/*本期出库销售利润金额*/
		SUM([salegaintotal]) AS [salegaintotal],
		/*SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],*/
		SUM([wtfhquantity]) AS [wtfhquantity],/*zhAND k.storetype=0 增加赠送数量*/
	    /*--本期出库委托代销发货金额,本期出库委托代销发货含税金额	*/
		SUM([wtfhtotal]) AS [wtfhtotal],
		SUM([wtfhtaxtotal]) AS [wtfhtaxtotal],
		SUM([wtthquantity]) AS [wtthquantity],
		/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
		SUM([wtthtotal]) AS [wtthtotal],
		SUM([wtthtaxtotal]) AS [wtthtaxtotal],
		SUM([salelendquantity]) AS [salelendquantity],
		SUM([salelendtotal]) AS [salelendtotal],
		SUM([lendquantity]) AS [lendquantity],
		SUM([lendtotal]) AS [lendtotal],
		SUM([lendthquantity]) AS [lendthquantity],
		SUM([lendthtotal]) AS [lendthtotal],
		sum([buyquantity]) AS [buyquantity],
		sum([buytotal]) AS [buytotal],
		sum([buytaxtotal]) AS [buytaxtotal],
		/*SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],*/
		/*ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal],*/
		SUM([stshquantity]) AS [stshquantity],
	    /*本期入库受托代销入库金额,本期入库受托代销入库含税金额	*/
		SUM([stshtotal]) AS [stshtotal],
		SUM([stshtaxtotal]) AS [stshtaxtotal],
		SUM([stthquantity]) AS [stthquantity],
	    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额	*/
		sum([stthtotal]) AS [stthtotal],
		SUM([stthtaxtotal]) AS [stthtaxtotal],
		SUM([buyborrowquantity]) AS [buyborrowquantity],
		SUM([buyborrowtotal]) AS [buyborrowtotal],
		SUM([borrowquantity]) AS [borrowquantity],
		SUM([borrowtotal]) AS [borrowtotal],
		SUM([borrowthquantity]) AS [borrowthquantity],
		SUM([borrowthtotal]) AS [borrowthtotal],
		SUM([buybackquantity]) AS [buybackquantity],
	    /*本期出库进货退货金额,本期出库进货退货含税金额	*/
		SUM([buybacktotal]) AS [buybacktotal],
		SUM([buybacktaxtotal]) AS [buybacktaxtotal],
		SUM([salebackquantity]) AS [salebackquantity],
		/*本期入库销售退货金额,本期入库销售退货含税金额*/
		SUM([salebacktotal]) AS [salebacktotal],
		SUM([salebacktaxcost]) AS [salebacktaxcost],
		SUM([losequantity]) AS [losequantity],
		SUM([loseTotal]) AS [loseTotal],
		SUM([overflowquantity]) AS [overflowquantity],
		SUM([overflowtotal]) AS [overflowtotal],
		SUM([tjdbrkquantity]) AS [tjdbrkquantity],
		SUM([tjdbckquantity]) AS [tjdbckquantity],
	    /*本期入库同价配送金额,本期入库同价配送含税金额*/
		SUM([tjdbrktotal]) AS [tjdbrktotal],
	    SUM([tjdbrktaxtotal]) AS [tjdbrktaxtotal],
	    /*本期出库同价配送金额,本期出库同价配送含税金额 	*/
		SUM([tjdbcktotal]) AS [tjdbcktotal],
	    SUM([tjdbcktaxtotal]) AS [tjdbcktaxtotal],
	    /*本期入库变价配送数量，本期出库变价配送数量 */
		SUM([bjdbrkquantity]) AS [bjdbrkquantity],  	
		SUM([bjdbckquantity]) AS [bjdbckquantity],
		/*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
		SUM([bjdbrktotal]) AS [bjdbrktotal],
	    SUM([bjdbrkcosttaxtotal]) AS [bjdbrkcosttaxtotal],
	    /*本期出库变价配送金额,本期出库变价配送含税金额*/
		SUM([bjdbcktotal]) AS [bjdbcktotal],
	    SUM([bjdbcktaxtotal]) AS [bjdbcktaxtotal],
		SUM([givequantity]) AS [givequantity],
		SUM([givetotal]) AS [givetotal],
		SUM([gainquantity]) AS [gainquantity],
		SUM([gaintotal]) AS [gaintotal],
		/*本期入库合计数量，本期入库合计金额,本期入库合计含税金额*/
		SUM([qtrkquantity]) AS [qtrkquantity],	
		SUM([qtrktotal]) AS [qtrktotal],
	    SUM([qtrkcosttaxtotal]) AS [qtrkcosttaxtotal],
	    /*本期出库其他出库数量，本期出库其他出库金额,本期出库其他出库含税金额 	*/
		SUM([qtckquantity]) AS [qtckquantity],	
		SUM([qtcktotal]) AS [qtcktotal],
	    SUM([qtcktaxtotal]) AS [qtcktaxtotal],	
	    /*本期出库合计数量，本期出库合计金额,本期出库合计含税成本金额 */
		SUM([bqckquantity]) AS [bqckquantity],
		SUM([bqcktotal]) AS [bqcktotal],
		SUM([bqckcosttaxtotal]) AS [bqckcosttaxtotal],
		SUM([bqrkquantity]) AS [bqrkquantity],
		/*本期入库合计金额,本期入库合计含税成本金额*/
		SUM([bqrktotal]) AS [bqrktotal],
		SUM([bqrkcosttaxtotal]) AS [bqrkcosttaxtotal],
		/*机构收货数量*/
		sum([ComRecquantity]) AS [ComRecquantity],
	    /*本期入库机构收货金额,本期入库机构收货含税成本金额*/
		sum([ComRecTotal]) AS [ComRecTotal],
		sum([ComReccosttaxTotal]) AS [ComReccosttaxTotal],
	    /*机构收货退货数量	*/
		sum([ComRecBackquantity]) AS [ComRecBackquantity],
	    /*--机构收货退货金额，机构收货退货含税金额*/
		sum([ComRecBackTotal]) AS [ComRecBackTotal],
	    sum([ComRecBacktaxTotal]) AS [ComRecBacktaxTotal],
	    /*机构发货数量*/
		sum([ComSendquantity]) AS [ComSendquantity],
	    /*本期出库机构发货金额,本期出库机构发货含税金额*/
		sum([ComSendTotal]) AS [ComSendTotal],
		sum([ComSendtaxTotal]) AS [ComSendtaxTotal],
	    /*机构发货退货数量	*/
		sum([ComSendBackquantity]) AS [ComSendBackquantity],
		/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
		sum([ComSendBackTotal]) AS [ComSendBackTotal],
		sum([ComSendBackcosttaxTotal]) AS [ComSendBackcosttaxTotal],
		/*拆零库本期出库数量*/
		SUM([ClkBqSaleQuantity]) AS [ClkBqSaleQuantity],
        SUM([ClkBqSaleTaxTotal]) AS [ClkBqSaleTaxTotal],
        SUM([ClkBqSaleCostTotal]) AS [ClkBqSaleCostTotal],
        SUM([ClkBqSaleCostTaxTotal]) AS [ClkBqSaleCostTaxTotal],
        SUM([ClkBqSaleGainTotal]) AS [ClkBqSaleGainTotal],
		/*拆零库本期入库数量    */
        SUM([ClkBqRkQuantity]) AS [ClkBqRkQuantity],
        SUM([ClkBqRkTaxTotal]) AS [ClkBqRkTaxTotal],
        SUM([ClkBqRkCostTotal]) AS [ClkBqRkCostTotal],
        SUM([ClkBqRkCostTaxTotal]) AS [ClkBqRkCostTaxTotal],
		/*拆零库本期退货数量*/
		SUM([ClkBqBackQuantity]) AS [ClkBqBackQuantity],
		SUM([ClkBqBackTaxTotal]) AS [ClkBqBackTaxTotal],
		SUM([ClkBqBackCostTaxTotal]) AS [ClkBqBackCostTaxTotal],                
		/*拆零单本期出库数量     */
        SUM([CldCkQuantity]) AS [CldCkQuantity],
        SUM([CldCkTaxTotal]) AS [CldCkTaxTotal],
        SUM([CldCkCostTaxTotal]) AS [CldCkCostTaxTotal]	        		
	into #hztable
	FROM 
         (
         select * from #xshztable
         union all
         select * from #cghztable
         union all
         select * from #pshztable
         union all
         select * from #aptable 
		 union all
         select * from #sytable      
         union all
         select * from #dxtable
         union all
         select * from #psthztable
         union all 
         select * from #cltable
         ) k
 	GROUP BY PClass_id


/*--本期受托\委托*/
SELECT	PClass_id,
        SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN ABS(k.quantity) ELSE 0 END) AS [buystquantity],
        /*本期入库受托代销结算金额,本期入库受托代销结算含税金额	*/
		ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.costtotal ELSE 0 END)) AS [buysttotal], 
		ABS(SUM(CASE WHEN  k.billtype =122  AND k.commissionflag=2    THEN k.taxtotal ELSE 0 END)) AS [buysttaxtotal], 
		SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN ABS(k.quantity) ELSE 0 END) AS [salewtquantity],
		/*本期出库委托代销结算金额,本期出库委托代销结算含税金额*/
		ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.costtotal ELSE 0 END)) AS [salewttotal],
		ABS(SUM(CASE WHEN  k.billtype =112 AND k.storetype=1 AND k.commissionflag=1   THEN k.taxtotal ELSE 0 END)) AS [salewttaxtotal]
	    into #bqwtTable FROM 
          (select pd.*,isnull(p.class_id,'') as PClass_id
             from   
                  (select p_id,pd.quantity,costtotal,taxtotal,billdate,storetype,aoid,commissionflag,s_id,RowE_id,billtype,bi.Y_id,bi.c_id
                     from ProductDetail PD
                     inner join billidx bi on pd.billid=bi.billid
                     where (billdate between @begindate and @EndDate) and
                      billstates='0' and pd.storetype=1 and bi.billtype IN (112, 122)
                   )pd                             
                   INNER JOIN  products  p on p_id=p.product_id  
                   INNER JOIN  Company   Y on pd.Y_id=Y.company_id
                   INNER JOIN  @Stores  s ON s.S_Id=pd.s_id
                where  p.class_id like @likeParentclassid
                   AND (@nYClassid='' or (Y.class_id like @nYClassid+'%'))
                   AND ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable))) 
          ) k 
 	  GROUP BY PClass_id
/*--上期数据*/
 SELECT p.Class_ID as PClass_id,
         ISNULL(SUM(pd.quantity),0) AS prequantity,
         ISNULL(SUM(pd.costtotal),0) AS precosttotal,
         ISNULL(SUM(pd.costtaxtotal),0) AS precosttaxtotal, /*xzdong-2016-12-14-TFS43783-进销存变动表优化*/
         /*拆零商品*/
         ISNULL(SUM(Case when WholeFlag = 3 then pd.quantity else 0 end),0) AS clkprequantity,
         ISNULL(SUM(Case when WholeFlag = 3 then pd.costtotal else 0 end),0) AS clkprecosttotal,
         ISNULL(SUM(Case when WholeFlag = 3 then pd.costtaxtotal else 0 end),0) AS clkprecosttaxtotal
         into #sqsjTable FROM Productdetail pd
	    INNER JOIN  billidx B ON pd.billid=b.billid
	    INNER JOIN @Stores s on pd.s_id = s.S_Id  
	    INNER JOIN products P ON pd.p_id=P.product_id 
    	INNER JOIN Company  Y on pd.Y_id=Y.Company_id 
        WHERE P.class_id like @likeParentclassid+'%' 
		  and (@nYClassID='' or Y.Class_id like @nYClassID+'%')
		  and ((@Companytable=0)or (PD.Y_id in (select [id] from #Companytable)))
		  and  billdate<@BeginDate and b.billstates='0'  AND pd.storetype=0 and p_id>0
        GROUP BY p.Class_ID
/*--期初库存*/
SELECT     P.Class_ID as PClass_id,
      ISNULL(SUM(si.quantity),0) AS iniquantity,
      ISNULL(SUM(si.costtotal),0) AS inicosttotal,
      ISNULL(SUM(si.costtaxtotal),0) AS inicosttaxtotal, /*xzdong-2016-12-14-TFS43783-进销存变动表优化*/
      /*拆零商品*/
      ISNULL(SUM(Case when WholeFlag = 3 then si.quantity else 0 end),0) AS clkiniquantity,
      ISNULL(SUM(Case when WholeFlag = 3 then si.costtotal else 0 end),0) AS clkinicosttotal,
      ISNULL(SUM(Case when WholeFlag = 3 then si.costtaxtotal else 0 end),0) AS clkinicosttaxtotal /*xzdong-2016-12-14-TFS43783-进销存变动表优化      */
      into #qckcTable FROM  storehouseini  si
      INNER JOIN @Stores s on si.s_id = s.S_Id 
      INNER JOIN Products P on P.product_id=si.p_id
      INNER JOIN Company  Y on si.Y_id=Y.Company_id
      WHERE si.p_id>0
        and p.class_id like @likeParentclassid
        and (@nYClassID='' or (Y.Class_id like @nYClassID+'%'))  
        and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
      GROUP BY p.Class_ID 
 /*--*/
 select P.Class_ID as PClass_id,
   ISNULL(SUM(si.quantity),0.0) as kcqty,
   ISNULL(SUM(costtotal),0.0)as kctotal,
   ISNULL(SUM(costtaxtotal),0.0)as costtaxtotal,
   /*拆零商品*/
   ISNULL(SUM(Case when WholeFlag = 3 then si.quantity else 0 end),0.0) as clkkcqty,
   ISNULL(SUM(Case when WholeFlag = 3 then costtotal else 0 end),0.0)as clkkctotal,
   ISNULL(SUM(Case when WholeFlag = 3 then costtaxtotal else 0 end),0.0)as clkcosttaxtotal  
   into #dqkcTable from storehouse si
    inner join @Stores s on si.s_id = s.S_Id 
    inner join products p on p.product_id=si.p_id
    INNER JOIN Company  Y on si.Y_id=Y.Company_id
      WHERE si.p_id>0
        and p.class_id like @likeParentclassid
        and (@nYClassID='' or (Y.Class_id like @nYClassID+'%'))  
        and ((@Companytable=0)or (si.Y_id in (select [id] from #Companytable)))   
      GROUP BY p.Class_ID
                  
/*print convert(varchar(23),getdate(),121)  + 'hz'*/
SELECT  vp.Class_ID as PClass_id,
	ISNULL(a.salequantity,0) AS salequantity,ISNULL(a.saletotal,0) AS saletotal,ISNULL(d.salewtquantity,0) AS salewtquantity,
	/*本期出库委托代销结算金额,本期出库委托代销结算含税金额	*/
	ISNULL(d.salewttotal,0) AS salewttotal,ISNULL(d.salewttaxtotal,0) AS salewttaxtotal,
	ISNULL(a.saletaxtotal,0) AS saletaxtotal,ISNULL(a.salegaintotal,0) AS salegaintotal,
    /*本期出库委托代销发货金额,本期出库委托代销发货含税金额*/
	ISNULL(a.wtfhquantity,0) AS wtfhquantity,ISNULL(a.wtfhtotal,0) AS wtfhtotal,ISNULL(a.wtfhtaxtotal,0) AS wtfhtaxtotal,
	/*本期入库委托代销退货金额,本期入库委托代销退货含税金额*/
	ISNULL(a.wtthquantity,0) AS wtthquantity,ISNULL(a.wtthtotal,0) AS wtthtotal,ISNULL(a.wtthtaxtotal,0) AS wtthtaxtotal,
	ISNULL(a.salelendquantity,0) AS salelendquantity,ISNULL(a.salelendtotal,0) AS salelendtotal,
	ISNULL(a.lendquantity,0) AS lendquantity,ISNULL(a.lendtotal,0) AS lendtotal,ISNULL(a.lendthquantity,0) AS lendthquantity,ISNULL(a.lendthtotal,0) AS lendthtotal,
	ISNULL(a.buyborrowquantity,0) AS buyborrowquantity,ISNULL(a.buyborrowtotal,0) AS buyborrowtotal,
	ISNULL(a.borrowquantity,0) AS borrowquantity,ISNULL(a.borrowtotal,0) AS borrowtotal,ISNULL(a.borrowthquantity,0) AS borrowthquantity,ISNULL(a.borrowthtotal,0) AS borrowthtotal,
	ISNULL(a.buyquantity,0) AS buyquantity,ISNULL(a.buytotal,0) AS buytotal,ISNULL(a.buybackquantity,0) AS buybackquantity,
	/*本期出库进货退货金额,本期出库进货退货含税金额*/
	ISNULL(a.buybacktotal,0) AS buybacktotal,ISNULL(a.buybacktaxtotal,0) AS buybacktaxtotal,
	ISNULL(a.salebackquantity,0) AS salebackquantity,
    /*本期入库受托代销结算金额,本期入库受托代销结算含税金额	*/
	ISNULL(d.buystquantity,0) AS buystquantity,ISNULL(d.buysttotal,0) AS buysttotal,ISNULL(d.buysttaxtotal,0) AS buysttaxtotal,
	/*本期入库受托代销入库金额,本期入库受托代销入库含税金额*/
	ISNULL(a.stshquantity,0) AS stshquantity,ISNULL(a.stshtotal,0) AS stshtotal,ISNULL(a.stshtaxtotal,0) AS stshtaxtotal,
    /*本期出库受托代销退货金额,	本期出库受托代销退货含税金额*/
	ISNULL(a.stthquantity,0) AS stthquantity,ISNULL(a.stthtotal,0) AS stthtotal,ISNULL(a.stthtaxtotal,0) AS stthtaxtotal, 
	ISNULL(a.buytaxtotal,0) AS buytaxtotal,
	/*本期入库销售退货金额,本期入库销售退货含税金额*/
	ISNULL(a.salebacktotal,0) AS salebacktotal,ISNULL(a.salebacktaxcost,0) AS salebacktaxcost,
	ISNULL(a.losequantity,0) AS losequantity,ISNULL(a.loseTotal,0) AS loseTotal,ISNULL(a.overflowquantity,0) AS overflowquantity,
	ISNULL(a.overflowtotal,0) AS overflowtotal,
	/*本期入库同价配送金额,本期入库同价配送含税金额*/
	ISNULL(a.tjdbrktotal,0) AS tjdbrktotal,ISNULL(a.tjdbrktaxtotal,0) AS tjdbrktaxtotal,
	/*本期出库同价配送金额,本期出库同价配送含税金额*/
	ISNULL(a.tjdbcktotal,0) AS tjdbcktotal,ISNULL(a.tjdbcktaxtotal,0) AS tjdbcktaxtotal,
	ISNULL(a.bjdbrkquantity,0) AS bjdbrkquantity,
	ISNULL(a.tjdbrkquantity,0) AS tjdbrkquantity,ISNULL(a.tjdbckquantity,0) AS tjdbckquantity,ISNULL(a.bjdbckquantity,0) AS bjdbckquantity,
    /*本期入库变价配送金额,本期入库变价配送含税成本金额	*/
	ISNULL(a.bjdbrktotal,0) AS bjdbrktotal,ISNULL(a.bjdbrkcosttaxtotal,0) AS bjdbrkcosttaxtotal,
	/*本期出库变价配送金额,本期出库变价配送含税金额*/
	ISNULL(a.bjdbcktotal,0) AS bjdbcktotal,ISNULL(a.bjdbcktaxtotal,0) AS bjdbcktaxtotal,	
	ISNULL(a.qtrkquantity,0) AS qtrkquantity,ISNULL(a.qtckquantity,0) AS qtckquantity,
	/*本期入库其他入库金额,本期入库其他入库含税成本金额*/
	ISNULL(a.qtrktotal,0) AS qtrktotal,ISNULL(a.qtrkcosttaxtotal,0) AS qtrkcosttaxtotal,
	ISNULL(a.givequantity,0) AS givequantity,ISNULL(a.givetotal,0) AS givetotal,ISNULL(a.gainquantity,0) AS gainquantity,ISNULL(a.gaintotal,0) AS gaintotal,
    /*本期出库其他出库金额,本期出库其他出库含税金额	*/
	ISNULL(a.qtcktotal,0) AS qtcktotal,ISNULL(a.qtcktaxtotal,0) AS qtcktaxtotal,
	/*本期出库合计金额,本期出库合计含税成本金额*/
	ISNULL(a.bqckquantity,0) AS bqckquantity,ISNULL(a.bqcktotal,0) AS bqcktotal,ISNULL(a.bqckcosttaxtotal,0) AS bqckcosttaxtotal,
	ISNULL(a.bqrkquantity,0) AS bqrkquantity,
	/*本期入库合计金额,本期入库合计含税金额*/
	ISNULL(a.bqrktotal,0) AS bqrktotal,ISNULL(a.bqrkcosttaxtotal,0) AS bqrkcosttaxtotal,
	ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0) AS sqcQuantity,
	ISNULL(c.prequantity,0)+ISNULL(b.iniquantity,0)-ISNULL(a.bqckquantity,0)+ISNULL(a.bqrkquantity,0) AS bqcQuantity ,
    /*上期存金额,本期存金额	*/
	ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTotal,
	ISNULL(c.preCostTotal,0)+ISNULL(b.iniCostTotal,0)-ISNULL(a.bqckTotal,0)+ISNULL(a.bqrkTotal,0) AS bqcTotal,
    /*上期存含税成本金额,本期存含税成本金额	*/
	ISNULL(c.precosttaxTotal,0)+ISNULL(b.iniCostTotal,0) AS sqcCostTaxTotal,
	ISNULL(c.preCosttaxTotal,0)+ISNULL(b.iniCosttaxTotal,0)-ISNULL(a.bqckcosttaxtotal,0)+ISNULL(a.bqrkcosttaxTotal,0) AS bqcCostTaxtotal,
	ISNULL(a.ComRecquantity,0) AS ComRecquantity,
	/*本期入库机构收货金额,本期入库机构收货含税成本金额*/
	ISNULL(a.ComRecTotal,0) AS ComRecTotal,ISNULL(a.ComReccosttaxtotal,0) AS ComReccosttaxtotal,
	ISNULL(a.ComRecBackquantity,0) AS ComRecBackquantity,
	/*本期出库机构收货退货金额,本期出库机构收货退货含税金额*/
	ISNULL(a.ComRecBackTotal,0) AS ComRecBackTotal,ISNULL(a.ComRecBacktaxTotal,0) AS ComRecBacktaxTotal,
	ISNULL(a.ComSendquantity,0) AS ComSendquantity,
	/*本期出库机构发货金额,本期出库机构发货含税金额*/
	ISNULL(a.ComSendTotal,0) AS ComSendTotal,ISNULL(a.ComSendTaxtotal,0) AS ComSendTaxtotal,
	ISNULL(a.ComSendBackquantity,0) AS ComSendBackquantity,
	/*本期入库机构发货退货金额,本期入库机构发货退货含税成本金额*/
	ISNULL(a.ComSendBackTotal,0) AS ComSendBackTotal,ISNULL(a.ComSendBackcosttaxtotal,0) AS ComSendBackcosttaxtotal,
	isnull(kc.kcqty,0.0) as kcqty
	,ISNULL(kc.kctotal,0.0)as kctotal 
	,ISNULL(kc.costtaxtotal,0.0)as taxcosttotal
	,ISNULL(z.ZTquantity,0) as ZTquantity
	/*在途金额,在途含税金额*/
	,ISNULL(z.ZTtaxtotal,0) as ZTtaxtotal,ISNULL(z.ZTcosttaxtotal,0) as ZTcosttaxtotal,
	/*上期存拆零商品数量、金额、含税成本金额*/
	ISNULL(c.clkprequantity,0)+ISNULL(b.clkiniquantity,0) AS ClkSqcQuantity,
	ISNULL(c.clkprecosttotal,0)+ISNULL(b.clkinicosttotal,0) AS clkSqcCosttotal,
	ISNULL(c.clkprecosttaxtotal,0)+ISNULL(b.clkinicosttaxtotal,0) AS clkSqcCosttaxtotal,
	/*本期存拆零商品数量、金额、含税成本金额*/
	ISNULL(c.clkprequantity,0)+ISNULL(b.clkiniquantity,0)-ISNULL(ClkBqSaleQuantity,0)+ISNULL(ClkBqRkQuantity,0) AS clkBqcQuantity,
	ISNULL(c.clkprecosttotal,0)+ISNULL(b.clkinicosttotal,0)-ISNULL(ClkBqSaleCostTotal,0)+ISNULL(ClkBqRkCostTotal,0) AS clkBqcCosttotal,
	ISNULL(c.clkprecosttaxtotal,0)+ISNULL(b.clkinicosttaxtotal,0)-ISNULL(ClkBqSaleCostTaxTotal,0)+ISNULL(ClkBqRkCostTaxTotal,0) AS clkBqcCosttaxtotal,
	/*本期出库拆零商品数量*/
	ISNULL(a.ClkBqSaleQuantity,0) AS ClkBqSaleQuantity,
	ISNULL(a.ClkBqSaleTaxTotal,0) AS ClkBqSaleTaxTotal,
	ISNULL(a.ClkBqSaleCostTaxTotal,0) AS ClkBqSaleCostTaxTotal,
	ISNULL(a.ClkBqSaleGainTotal,0) AS ClkBqSaleGainTotal,
	/*本期入库拆零商品数量    */
    ISNULL(ClkBqRkQuantity,0) AS ClkBqRkQuantity,
    ISNULL(ClkBqRkTaxTotal,0) AS ClkBqRkTaxTotal,
    ISNULL(ClkBqRkCostTaxTotal,0) AS ClkBqRkCostTaxTotal,
	/*本期入库拆零商品退货数量*/
	ISNULL(ClkBqBackQuantity,0) AS ClkBqBackQuantity,
	ISNULL(ClkBqBackTaxTotal,0) AS ClkBqBackTaxTotal,
	ISNULL(ClkBqBackCostTaxTotal,0) AS ClkBqBackCostTaxTotal,
	/*本期出库拆零单出库数量    	*/
    ISNULL(CldCkQuantity,0) AS CldCkQuantity,
    ISNULL(CldCkTaxTotal,0) AS CldCkTaxTotal,
    ISNULL(CldCkCostTaxTotal,0) AS CldCkCostTaxTotal    		
INTO #jxctable
FROM (select * from Products where deleted <> 1  and IsSplit=0) vp
LEFT JOIN
     #hztable
     a ON Vp.class_id=a.pclass_id
LEFT JOIN   /*本期委托、受托*/
     #bqwtTable d ON Vp.class_id=d.pclass_id
left JOIN   /*上期数据*/
     #sqsjTable c ON vp.class_id=c.pclass_id
LEFT JOIN   /*期初库存*/
     #qckcTable b ON Vp.class_id=b.PClass_id 
left join   /*当前库存*/
     #dqkcTable kc on Vp.Class_ID=kc.PClass_id 
left join   /*在途数量*/
     #ztTable z on vp.product_id = z.p_id  
order by vp.class_id

/*print convert(varchar(23),getdate(),121)  + 'all'*/


 IF @szListFlag='L' 
   SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
        ISNULL(M.medtype,'') AS medtype, vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	ISNULL(U1.[Name],'') as [unitname1], ISNULL(U2.[Name],'') as [unitname2],ISNULL(U3.[Name],'') as [unitname3], ISNULL(U4.[Name],'') as [unitname4],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName as rname,vp.Factory,
	ISNULL(max(pr.[retailprice]), 0) AS [retailprice],ISNULL(Max(vpb.e_name),'') as e_name,isNULL(Max(vpb.C_Name),'') as C_Name,
	ISNULL(sum(a.salequantity),0) AS salequantity,ISNULL(sum(a.saletotal),0) AS saletotal,ISNULL(sum(a.salewtquantity),0) AS salewtquantity,ISNULL(sum(a.salewttotal),0) AS salewttotal,
	ISNULL(sum(a.saletaxtotal),0) AS saletaxtotal,ISNULL(sum(a.salegaintotal),0) AS salegaintotal,
	ISNULL(sum(a.wtfhquantity),0) AS wtfhquantity,ISNULL(sum(a.wtfhtotal),0) AS wtfhtotal,ISNULL(sum(a.wtthquantity),0) AS wtthquantity,ISNULL(sum(a.wtthtotal),0) AS wtthtotal,
	ISNULL(sum(a.salelendquantity),0) AS salelendquantity,ISNULL(sum(a.salelendtotal),0) AS salelendtotal,
	ISNULL(sum(a.lendquantity),0) AS lendquantity,ISNULL(sum(a.lendtotal),0) AS lendtotal,ISNULL(sum(a.lendthquantity),0) AS lendthquantity,ISNULL(sum(a.lendthtotal),0) AS lendthtotal,
	ISNULL(sum(a.buyborrowquantity),0) AS buyborrowquantity,ISNULL(sum(a.buyborrowtotal),0) AS buyborrowtotal,
	ISNULL(sum(a.borrowquantity),0) AS borrowquantity,ISNULL(sum(a.borrowtotal),0) AS borrowtotal,ISNULL(sum(a.borrowthquantity),0) AS borrowthquantity,ISNULL(sum(a.borrowthtotal),0) AS borrowthtotal,
	ISNULL(sum(a.buyquantity),0) AS buyquantity,ISNULL(sum(a.buytotal),0) AS buytotal,ISNULL(sum(a.buybackquantity),0) AS buybackquantity,ISNULL(sum(a.buybacktotal),0) AS buybacktotal,ISNULL(sum(a.salebackquantity),0) AS salebackquantity,
	ISNULL(sum(a.buystquantity),0) AS buystquantity,ISNULL(sum(a.buysttotal),0) AS buysttotal,ISNULL(sum(a.stshquantity),0) AS stshquantity,ISNULL(sum(a.stshtotal),0) AS stshtotal,ISNULL(sum(a.stthquantity),0) AS stthquantity,
	ISNULL(sum(a.stthtotal),0) AS stthtotal, ISNULL(sum(a.buytaxtotal),0) AS buytaxtotal,
	ISNULL(sum(a.salebacktotal),0) AS salebacktotal,ISNULL(sum(a.losequantity),0) AS losequantity,ISNULL(sum(a.loseTotal),0) AS loseTotal,ISNULL(sum(a.overflowquantity),0) AS overflowquantity,
	ISNULL(sum(a.overflowtotal),0) AS overflowtotal,ISNULL(sum(a.tjdbrktotal),0) AS tjdbrktotal,ISNULL(sum(a.tjdbcktotal),0) AS tjdbcktotal,ISNULL(sum(a.bjdbrkquantity),0) AS bjdbrkquantity,
	ISNULL(sum(a.tjdbrkquantity),0) AS tjdbrkquantity,ISNULL(sum(a.tjdbckquantity),0) AS tjdbckquantity,ISNULL(sum(a.bjdbckquantity),0) AS bjdbckquantity,ISNULL(sum(a.bjdbrktotal),0) AS bjdbrktotal,
	ISNULL(sum(a.bjdbcktotal),0) AS bjdbcktotal,ISNULL(sum(a.qtrkquantity),0) AS qtrkquantity,ISNULL(sum(a.qtckquantity),0) AS qtckquantity,ISNULL(sum(a.qtrktotal),0) AS qtrktotal,
	ISNULL(sum(a.givequantity),0) AS givequantity,ISNULL(sum(a.givetotal),0) AS givetotal,ISNULL(sum(a.gainquantity),0) AS gainquantity,ISNULL(sum(a.gaintotal),0) AS gaintotal,
	ISNULL(sum(a.qtcktotal),0) AS qtcktotal,ISNULL(sum(a.bqckquantity),0) AS bqckquantity,ISNULL(sum(a.bqcktotal),0) AS bqcktotal,ISNULL(sum(a.bqrkquantity),0) AS bqrkquantity,ISNULL(sum(a.bqrktotal),0) AS bqrktotal,
	ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,
	ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,ISNULL(sum(a.bqcTotal),0) AS bqcTotal,
	ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,
	ISNULL(sum(a.ComRecBackQuantity),0) AS ComRecBackQuantity,ISNULL(sum(a.ComRecBacktotal),0) AS ComRecBacktotal,
	ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,
	ISNULL(sum(a.ComSendBackquantity),0) AS ComSendBackquantity,ISNULL(sum(a.ComSendBackTotal),0) AS ComSendBackTotal
	,isnull(sum(a.kcqty),0.0) as kcqty,isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,isnull(sum(a.kctotal),0.0) as kctotal
	,isnull(sum(a.salebacktaxcost),0.0) as salebacktaxcost
	,ISNULL(SUM(a.ZTquantity),0) as ZTquantity
	,ISNULL(SUM(a.ZTtaxtotal),0) as ZTtaxtotal
	/*xzdong-2016-12-14-TFS43783-进销存变动表优化*/
	,ISNULL(SUM(a.ZTcosttaxtotal),0) as ZTcosttaxtotal
	,ISNULL(SUM(a.bqccosttaxtotal),0) as bqccosttaxtotal
	,ISNULL(SUM(a.bqckcosttaxtotal),0) as bqckcosttaxtotal
	,ISNULL(SUM(a.comsendtaxtotal),0) as comsendtaxtotal
	,ISNULL(SUM(a.ComRecbacktaxtotal),0) as comrecbacktaxtotal
	,ISNULL(SUM(a.qtcktaxtotal),0) as qtcktaxtotal
	,ISNULL(SUM(a.bjdbcktaxtotal),0) as bjdbcktaxtotal
	,ISNULL(SUM(a.tjdbcktaxtotal),0) as tjdbcktaxtotal
	,ISNULL(SUM(a.stthtaxtotal),0) as stthtaxtotal
	,ISNULL(SUM(a.salewttaxtotal),0) as salewttaxtotal
	,ISNULL(SUM(a.wtfhtaxtotal),0) as wtfhtaxtotal
	,ISNULL(SUM(a.buybacktaxtotal),0) as buybacktaxtotal
	,ISNULL(SUM(a.bqrkcosttaxtotal),0) as bqrkcosttaxtotal
	,ISNULL(SUM(a.comsendbackcosttaxtotal),0) as comsendbackcosttaxtotal
	,ISNULL(SUM(a.comreccosttaxtotal),0) as comreccosttaxtotal
	,ISNULL(SUM(a.qtrkcosttaxtotal),0) as qtrkcosttaxtotal
	,ISNULL(SUM(a.bjdbrkcosttaxtotal),0) as bjdbrkcosttaxtotal
	,ISNULL(SUM(a.tjdbrktaxtotal),0) as tjdbrktaxtotal
	,ISNULL(SUM(a.wtthtaxtotal),0) as wtthtaxtotal
	,ISNULL(SUM(a.buysttaxtotal),0) as buysttaxtotal
	,ISNULL(SUM(a.sqccosttaxtotal),0) as sqccosttaxtotal
	,ISNULL(SUM(a.stshtaxtotal),0) as stshtaxtotal
	/*拆零商品*/
    ,ISNULL(SUM(a.ClkSqcQuantity),0) as ClkSqcQuantity
	,ISNULL(SUM(a.clkSqcCosttotal),0) as ClkSqcCosttotal
	,ISNULL(SUM(a.clkSqcCosttaxtotal),0) as ClkSqcCosttaxtotal	
	,ISNULL(SUM(a.clkBqcQuantity),0) as clkBqcQuantity
	,ISNULL(SUM(a.clkBqcCosttotal),0) as clkBqcCosttotal	
	,ISNULL(SUM(a.clkBqcCosttaxtotal),0) as clkBqcCosttaxtotal
	,ISNULL(SUM(a.ClkBqSaleQuantity),0) as ClkBqSaleQuantity
	,ISNULL(SUM(a.ClkBqSaleTaxTotal),0) as ClkBqSaleTaxTotal	
	,ISNULL(SUM(a.ClkBqSaleCostTaxTotal),0) as ClkBqSaleCostTaxTotal
	,ISNULL(SUM(a.ClkBqSaleGainTotal),0) as ClkBqSaleGainTotal
	,ISNULL(SUM(a.ClkBqRkQuantity),0) as ClkBqRkQuantity
	,ISNULL(SUM(a.ClkBqRkTaxTotal),0) as ClkBqRkTaxTotal	
	,ISNULL(SUM(a.ClkBqRkCostTaxTotal),0) as ClkBqRkCostTaxTotal
	,ISNULL(SUM(a.ClkBqBackQuantity),0) as ClkBqBackQuantity
	,ISNULL(SUM(a.ClkBqBackTaxTotal),0) as ClkBqBackTaxTotal	
	,ISNULL(SUM(a.ClkBqBackCostTaxTotal),0) as ClkBqBackCostTaxTotal	
	,ISNULL(SUM(a.CldCkQuantity),0) as CldCkQuantity
	,ISNULL(SUM(a.CldCkTaxTotal),0) as CldCkTaxTotal	
	,ISNULL(SUM(a.CldCkCostTaxTotal),0) as CldCkCostTaxTotal
			
     FROM Products vp
     LEFT JOIN #jxctable a   ON LEFT(a.[PClass_ID],LEN(vp.[Class_ID]))=vp.[Class_ID]
     LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
     LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
     LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
     LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
     LEFT JOIN VW_Range r    ON vp.product_id=r.product_id
     LEFT JOIN VW_MedType m  ON vp.product_id=m.product_id
     LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID]
     LEFT JOIN (select p_id,e_name,C_Name from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
    WHERE  vp.parent_id=@szParent_id and vp.deleted<>1 and IsSplit=0
    Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
        M.medtype , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName,vp.Factory
   order by vp.class_id

 IF @szListFlag='P' 
    SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
        ISNULL(M.medtype,'') AS medtype, vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	ISNULL(U1.[Name],'') as [unitname1], ISNULL(U2.[Name],'') as [unitname2],ISNULL(U3.[Name],'') as [unitname3], ISNULL(U4.[Name],'') as [unitname4],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName as rname,vp.Factory,
	ISNULL(max(pr.[retailprice]), 0) AS [retailprice],ISNULL(Max(vpb.e_name),'') as e_name,isNULL(Max(vpb.C_Name),'') as C_Name,
	ISNULL(sum(a.salequantity),0) AS salequantity,ISNULL(sum(a.saletotal),0) AS saletotal,ISNULL(sum(a.salewtquantity),0) AS salewtquantity,ISNULL(sum(a.salewttotal),0) AS salewttotal,
	ISNULL(sum(a.saletaxtotal),0) AS saletaxtotal,ISNULL(sum(a.salegaintotal),0) AS salegaintotal,
	ISNULL(sum(a.wtfhquantity),0) AS wtfhquantity,ISNULL(sum(a.wtfhtotal),0) AS wtfhtotal,ISNULL(sum(a.wtthquantity),0) AS wtthquantity,ISNULL(sum(a.wtthtotal),0) AS wtthtotal,
	ISNULL(sum(a.salelendquantity),0) AS salelendquantity,ISNULL(sum(a.salelendtotal),0) AS salelendtotal,
	ISNULL(sum(a.lendquantity),0) AS lendquantity,ISNULL(sum(a.lendtotal),0) AS lendtotal,ISNULL(sum(a.lendthquantity),0) AS lendthquantity,ISNULL(sum(a.lendthtotal),0) AS lendthtotal,
	ISNULL(sum(a.buyborrowquantity),0) AS buyborrowquantity,ISNULL(sum(a.buyborrowtotal),0) AS buyborrowtotal,
	ISNULL(sum(a.borrowquantity),0) AS borrowquantity,ISNULL(sum(a.borrowtotal),0) AS borrowtotal,ISNULL(sum(a.borrowthquantity),0) AS borrowthquantity,ISNULL(sum(a.borrowthtotal),0) AS borrowthtotal,
	ISNULL(sum(a.buyquantity),0) AS buyquantity,ISNULL(sum(a.buytotal),0) AS buytotal,ISNULL(sum(a.buybackquantity),0) AS buybackquantity,ISNULL(sum(a.buybacktotal),0) AS buybacktotal,ISNULL(sum(a.salebackquantity),0) AS salebackquantity,
	ISNULL(sum(a.buystquantity),0) AS buystquantity,ISNULL(sum(a.buysttotal),0) AS buysttotal,ISNULL(sum(a.stshquantity),0) AS stshquantity,ISNULL(sum(a.stshtotal),0) AS stshtotal,ISNULL(sum(a.stthquantity),0) AS stthquantity,
	ISNULL(sum(a.stthtotal),0) AS stthtotal, ISNULL(sum(a.buytaxtotal),0) AS buytaxtotal,
	ISNULL(sum(a.salebacktotal),0) AS salebacktotal,ISNULL(sum(a.losequantity),0) AS losequantity,ISNULL(sum(a.loseTotal),0) AS loseTotal,ISNULL(sum(a.overflowquantity),0) AS overflowquantity,
	ISNULL(sum(a.overflowtotal),0) AS overflowtotal,ISNULL(sum(a.tjdbrktotal),0) AS tjdbrktotal,ISNULL(sum(a.tjdbcktotal),0) AS tjdbcktotal,ISNULL(sum(a.bjdbrkquantity),0) AS bjdbrkquantity,
	ISNULL(sum(a.tjdbrkquantity),0) AS tjdbrkquantity,ISNULL(sum(a.tjdbckquantity),0) AS tjdbckquantity,ISNULL(sum(a.bjdbckquantity),0) AS bjdbckquantity,ISNULL(sum(a.bjdbrktotal),0) AS bjdbrktotal,
	ISNULL(sum(a.bjdbcktotal),0) AS bjdbcktotal,ISNULL(sum(a.qtrkquantity),0) AS qtrkquantity,ISNULL(sum(a.qtckquantity),0) AS qtckquantity,ISNULL(sum(a.qtrktotal),0) AS qtrktotal,
	ISNULL(sum(a.givequantity),0) AS givequantity,ISNULL(sum(a.givetotal),0) AS givetotal,ISNULL(sum(a.gainquantity),0) AS gainquantity,ISNULL(sum(a.gaintotal),0) AS gaintotal,
	ISNULL(sum(a.qtcktotal),0) AS qtcktotal,ISNULL(sum(a.bqckquantity),0) AS bqckquantity,ISNULL(sum(a.bqcktotal),0) AS bqcktotal,ISNULL(sum(a.bqrkquantity),0) AS bqrkquantity,ISNULL(sum(a.bqrktotal),0) AS bqrktotal,
	ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,
	ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,ISNULL(sum(a.bqcTotal),0) AS bqcTotal,
	ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,
	ISNULL(sum(a.ComRecBackQuantity),0) AS ComRecBackQuantity,ISNULL(sum(a.ComRecBacktotal),0) AS ComRecBacktotal,
	ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,
	ISNULL(sum(a.ComSendBackquantity),0) AS ComSendBackquantity,ISNULL(sum(a.ComSendBackTotal),0) AS ComSendBackTotal,
	isnull(sum(a.kcqty),0.0) as kcqty,isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,isnull(sum(a.kctotal),0.0) as kctotal
	,isnull(sum(a.salebacktaxcost),0.0) as salebacktaxcost
	,ISNULL(SUM(a.ZTquantity),0) as ZTquantity
	,ISNULL(SUM(a.ZTtaxtotal),0) as ZTtaxtotal
	/*xzdong-2016-12-14-TFS43783-进销存变动表优化*/
	,ISNULL(SUM(a.ZTcosttaxtotal),0) as ZTcosttaxtotal
	,ISNULL(SUM(a.bqccosttaxtotal),0) as bqccosttaxtotal
	,ISNULL(SUM(a.bqckcosttaxtotal),0) as bqckcosttaxtotal
	,ISNULL(SUM(a.comsendtaxtotal),0) as comsendtaxtotal
	,ISNULL(SUM(a.ComRecbacktaxtotal),0) as comrecbacktaxtotal
	,ISNULL(SUM(a.qtcktaxtotal),0) as qtcktaxtotal
	,ISNULL(SUM(a.bjdbcktaxtotal),0) as bjdbcktaxtotal
	,ISNULL(SUM(a.tjdbcktaxtotal),0) as tjdbcktaxtotal
	,ISNULL(SUM(a.stthtaxtotal),0) as stthtaxtotal
	,ISNULL(SUM(a.salewttaxtotal),0) as salewttaxtotal
	,ISNULL(SUM(a.wtfhtaxtotal),0) as wtfhtaxtotal
	,ISNULL(SUM(a.buybacktaxtotal),0) as buybacktaxtotal
	,ISNULL(SUM(a.bqrkcosttaxtotal),0) as bqrkcosttaxtotal
	,ISNULL(SUM(a.comsendbackcosttaxtotal),0) as comsendbackcosttaxtotal
	,ISNULL(SUM(a.comreccosttaxtotal),0) as comreccosttaxtotal
	,ISNULL(SUM(a.qtrkcosttaxtotal),0) as qtrkcosttaxtotal
	,ISNULL(SUM(a.bjdbrkcosttaxtotal),0) as bjdbrkcosttaxtotal
	,ISNULL(SUM(a.tjdbrktaxtotal),0) as tjdbrktaxtotal
	,ISNULL(SUM(a.wtthtaxtotal),0) as wtthtaxtotal
	,ISNULL(SUM(a.buysttaxtotal),0) as buysttaxtotal
	,ISNULL(SUM(a.sqccosttaxtotal),0) as sqccosttaxtotal
	,ISNULL(SUM(a.stshtaxtotal),0) as stshtaxtotal
	/*拆零商品*/
    ,ISNULL(SUM(a.ClkSqcQuantity),0) as ClkSqcQuantity
	,ISNULL(SUM(a.clkSqcCosttotal),0) as ClkSqcCosttotal
	,ISNULL(SUM(a.clkSqcCosttaxtotal),0) as ClkSqcCosttaxtotal	
	,ISNULL(SUM(a.clkBqcQuantity),0) as clkBqcQuantity
	,ISNULL(SUM(a.clkBqcCosttotal),0) as clkBqcCosttotal	
	,ISNULL(SUM(a.clkBqcCosttaxtotal),0) as clkBqcCosttaxtotal
	,ISNULL(SUM(a.ClkBqSaleQuantity),0) as ClkBqSaleQuantity
	,ISNULL(SUM(a.ClkBqSaleTaxTotal),0) as ClkBqSaleTaxTotal	
	,ISNULL(SUM(a.ClkBqSaleCostTaxTotal),0) as ClkBqSaleCostTaxTotal
	,ISNULL(SUM(a.ClkBqSaleGainTotal),0) as ClkBqSaleGainTotal
	,ISNULL(SUM(a.ClkBqRkQuantity),0) as ClkBqRkQuantity
	,ISNULL(SUM(a.ClkBqRkTaxTotal),0) as ClkBqRkTaxTotal	
	,ISNULL(SUM(a.ClkBqRkCostTaxTotal),0) as ClkBqRkCostTaxTotal
	,ISNULL(SUM(a.ClkBqBackQuantity),0) as ClkBqBackQuantity
	,ISNULL(SUM(a.ClkBqBackTaxTotal),0) as ClkBqBackTaxTotal	
	,ISNULL(SUM(a.ClkBqBackCostTaxTotal),0) as ClkBqBackCostTaxTotal	
	,ISNULL(SUM(a.CldCkQuantity),0) as CldCkQuantity
	,ISNULL(SUM(a.CldCkTaxTotal),0) as CldCkTaxTotal	
	,ISNULL(SUM(a.CldCkCostTaxTotal),0) as CldCkCostTaxTotal
		
     FROM  Products vp
     LEFT JOIN #jxctable a   ON a.[PClass_ID]=vp.[Class_ID]
     LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
     LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
     LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
     LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
     LEFT JOIN VW_Range r    ON vp.product_id=r.product_id
     LEFT JOIN VW_MedType m  ON vp.product_id=m.product_id
     LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
     LEFT JOIN (select p_id,e_name,C_Name from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
    WHERE LEFT(vp.[Class_ID], LEN(@szParent_id))=@szParent_id and vp.deleted<>1 and vp.[Child_Number]=0 and IsSplit=0
    Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
        M.medtype , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName,vp.Factory
   order by vp.class_id

 IF @szListFlag='A' 
    SELECT vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number]as code,vp.standard,vp.makearea,
    ISNULL(M.medtype,'') AS medtype, vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	ISNULL(U1.[Name],'') as [unitname1], ISNULL(U2.[Name],'') as [unitname2],ISNULL(U3.[Name],'') as [unitname3], ISNULL(U4.[Name],'') as [unitname4],
    vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
    vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName as rname,vp.Factory,
	ISNULL(max(pr.[retailprice]), 0) AS [retailprice],ISNULL(Max(vpb.e_name),'') as e_name,isNULL(Max(vpb.C_Name),'') as C_Name,
	ISNULL(sum(a.salequantity),0) AS salequantity,ISNULL(sum(a.saletotal),0) AS saletotal,ISNULL(sum(a.salewtquantity),0) AS salewtquantity,ISNULL(sum(a.salewttotal),0) AS salewttotal,
	ISNULL(sum(a.saletaxtotal),0) AS saletaxtotal,ISNULL(sum(a.salegaintotal),0) AS salegaintotal,
	ISNULL(sum(a.wtfhquantity),0) AS wtfhquantity,ISNULL(sum(a.wtfhtotal),0) AS wtfhtotal,ISNULL(sum(a.wtthquantity),0) AS wtthquantity,ISNULL(sum(a.wtthtotal),0) AS wtthtotal,
	ISNULL(sum(a.salelendquantity),0) AS salelendquantity,ISNULL(sum(a.salelendtotal),0) AS salelendtotal,
	ISNULL(sum(a.lendquantity),0) AS lendquantity,ISNULL(sum(a.lendtotal),0) AS lendtotal,ISNULL(sum(a.lendthquantity),0) AS lendthquantity,ISNULL(sum(a.lendthtotal),0) AS lendthtotal,
	ISNULL(sum(a.buyborrowquantity),0) AS buyborrowquantity,ISNULL(sum(a.buyborrowtotal),0) AS buyborrowtotal,
	ISNULL(sum(a.borrowquantity),0) AS borrowquantity,ISNULL(sum(a.borrowtotal),0) AS borrowtotal,ISNULL(sum(a.borrowthquantity),0) AS borrowthquantity,ISNULL(sum(a.borrowthtotal),0) AS borrowthtotal,
	ISNULL(sum(a.buyquantity),0) AS buyquantity,ISNULL(sum(a.buytotal),0) AS buytotal,ISNULL(sum(a.buybackquantity),0) AS buybackquantity,ISNULL(sum(a.buybacktotal),0) AS buybacktotal,ISNULL(sum(a.salebackquantity),0) AS salebackquantity,
	ISNULL(sum(a.buystquantity),0) AS buystquantity,ISNULL(sum(a.buysttotal),0) AS buysttotal,ISNULL(sum(a.stshquantity),0) AS stshquantity,ISNULL(sum(a.stshtotal),0) AS stshtotal,ISNULL(sum(a.stthquantity),0) AS stthquantity,
	ISNULL(sum(a.stthtotal),0) AS stthtotal, ISNULL(sum(a.buytaxtotal),0) AS buytaxtotal,
	ISNULL(sum(a.salebacktotal),0) AS salebacktotal,ISNULL(sum(a.losequantity),0) AS losequantity,ISNULL(sum(a.loseTotal),0) AS loseTotal,ISNULL(sum(a.overflowquantity),0) AS overflowquantity,
	ISNULL(sum(a.overflowtotal),0) AS overflowtotal,ISNULL(sum(a.tjdbrktotal),0) AS tjdbrktotal,ISNULL(sum(a.tjdbcktotal),0) AS tjdbcktotal,ISNULL(sum(a.bjdbrkquantity),0) AS bjdbrkquantity,
	ISNULL(sum(a.tjdbrkquantity),0) AS tjdbrkquantity,ISNULL(sum(a.tjdbckquantity),0) AS tjdbckquantity,ISNULL(sum(a.bjdbckquantity),0) AS bjdbckquantity,ISNULL(sum(a.bjdbrktotal),0) AS bjdbrktotal,
	ISNULL(sum(a.bjdbcktotal),0) AS bjdbcktotal,ISNULL(sum(a.qtrkquantity),0) AS qtrkquantity,ISNULL(sum(a.qtckquantity),0) AS qtckquantity,ISNULL(sum(a.qtrktotal),0) AS qtrktotal,
	ISNULL(sum(a.givequantity),0) AS givequantity,ISNULL(sum(a.givetotal),0) AS givetotal,ISNULL(sum(a.gainquantity),0) AS gainquantity,ISNULL(sum(a.gaintotal),0) AS gaintotal,
	ISNULL(sum(a.qtcktotal),0) AS qtcktotal,ISNULL(sum(a.bqckquantity),0) AS bqckquantity,ISNULL(sum(a.bqcktotal),0) AS bqcktotal,ISNULL(sum(a.bqrkquantity),0) AS bqrkquantity,ISNULL(sum(a.bqrktotal),0) AS bqrktotal,
	ISNULL(sum(a.sqcQuantity),0) as sqcQuantity,ISNULL(sum(a.bqcQuantity),0) AS bqcQuantity ,
	ISNULL(sum(a.sqcCostTotal),0) AS sqcCostTotal,ISNULL(sum(a.bqcTotal),0) AS bqcTotal,
	ISNULL(sum(a.ComRecQuantity),0) AS ComRecQuantity,ISNULL(sum(a.ComRecTotal),0) AS ComRecTotal,
	ISNULL(sum(a.ComRecBackQuantity),0) AS ComRecBackQuantity,ISNULL(sum(a.ComRecBacktotal),0) AS ComRecBacktotal,
	ISNULL(sum(a.ComSendQuantity),0) AS ComSendQuantity,ISNULL(sum(a.ComSendTotal),0) AS ComSendTotal,
	ISNULL(sum(a.ComSendBackquantity),0) AS ComSendBackquantity,ISNULL(sum(a.ComSendBackTotal),0) AS ComSendBackTotal,
	isnull(sum(a.kcqty),0.0) as kcqty,isnull(sum(a.taxcosttotal),0.0) as taxcosttotal,isnull(sum(a.kctotal),0.0) as kctotal
	,ISNULL(sum(a.salebacktaxcost),0.0) as salebacktaxcost
	,ISNULL(SUM(a.ZTquantity),0) as ZTquantity
	,ISNULL(SUM(a.ZTtaxtotal),0) as ZTtaxtotal
	/*xzdong-2016-12-14-TFS43783-进销存变动表优化*/
	,ISNULL(SUM(a.ZTcosttaxtotal),0) as ZTcosttaxtotal
	,ISNULL(SUM(a.bqccosttaxtotal),0) as bqccosttaxtotal
	,ISNULL(SUM(a.bqckcosttaxtotal),0) as bqckcosttaxtotal
	,ISNULL(SUM(a.comsendtaxtotal),0) as comsendtaxtotal
	,ISNULL(SUM(a.ComRecbacktaxtotal),0) as comrecbacktaxtotal
	,ISNULL(SUM(a.qtcktaxtotal),0) as qtcktaxtotal
	,ISNULL(SUM(a.bjdbcktaxtotal),0) as bjdbcktaxtotal
	,ISNULL(SUM(a.tjdbcktaxtotal),0) as tjdbcktaxtotal
	,ISNULL(SUM(a.stthtaxtotal),0) as stthtaxtotal
	,ISNULL(SUM(a.salewttaxtotal),0) as salewttaxtotal
	,ISNULL(SUM(a.wtfhtaxtotal),0) as wtfhtaxtotal
	,ISNULL(SUM(a.buybacktaxtotal),0) as buybacktaxtotal
	,ISNULL(SUM(a.bqrkcosttaxtotal),0) as bqrkcosttaxtotal
	,ISNULL(SUM(a.comsendbackcosttaxtotal),0) as comsendbackcosttaxtotal
	,ISNULL(SUM(a.comreccosttaxtotal),0) as comreccosttaxtotal
	,ISNULL(SUM(a.qtrkcosttaxtotal),0) as qtrkcosttaxtotal
	,ISNULL(SUM(a.bjdbrkcosttaxtotal),0) as bjdbrkcosttaxtotal
	,ISNULL(SUM(a.tjdbrktaxtotal),0) as tjdbrktaxtotal
	,ISNULL(SUM(a.wtthtaxtotal),0) as wtthtaxtotal
	,ISNULL(SUM(a.buysttaxtotal),0) as buysttaxtotal
	,ISNULL(SUM(a.sqccosttaxtotal),0) as sqccosttaxtotal
	,ISNULL(SUM(a.stshtaxtotal),0) as stshtaxtotal
	/*拆零商品*/
    ,ISNULL(SUM(a.ClkSqcQuantity),0) as ClkSqcQuantity
	,ISNULL(SUM(a.clkSqcCosttotal),0) as ClkSqcCosttotal
	,ISNULL(SUM(a.clkSqcCosttaxtotal),0) as ClkSqcCosttaxtotal	
	,ISNULL(SUM(a.clkBqcQuantity),0) as clkBqcQuantity
	,ISNULL(SUM(a.clkBqcCosttotal),0) as clkBqcCosttotal	
	,ISNULL(SUM(a.clkBqcCosttaxtotal),0) as clkBqcCosttaxtotal
	,ISNULL(SUM(a.ClkBqSaleQuantity),0) as ClkBqSaleQuantity
	,ISNULL(SUM(a.ClkBqSaleTaxTotal),0) as ClkBqSaleTaxTotal	
	,ISNULL(SUM(a.ClkBqSaleCostTaxTotal),0) as ClkBqSaleCostTaxTotal
	,ISNULL(SUM(a.ClkBqSaleGainTotal),0) as ClkBqSaleGainTotal
	,ISNULL(SUM(a.ClkBqRkQuantity),0) as ClkBqRkQuantity
	,ISNULL(SUM(a.ClkBqRkTaxTotal),0) as ClkBqRkTaxTotal	
	,ISNULL(SUM(a.ClkBqRkCostTaxTotal),0) as ClkBqRkCostTaxTotal
	,ISNULL(SUM(a.ClkBqBackQuantity),0) as ClkBqBackQuantity
	,ISNULL(SUM(a.ClkBqBackTaxTotal),0) as ClkBqBackTaxTotal	
	,ISNULL(SUM(a.ClkBqBackCostTaxTotal),0) as ClkBqBackCostTaxTotal	
	,ISNULL(SUM(a.CldCkQuantity),0) as CldCkQuantity
	,ISNULL(SUM(a.CldCkTaxTotal),0) as CldCkTaxTotal	
	,ISNULL(SUM(a.CldCkCostTaxTotal),0) as CldCkCostTaxTotal
		
     FROM Products vp
     LEFT JOIN #jxctable a   ON a.[PClass_ID]=vp.[Class_ID]
     LEFT JOIN Unit U1       ON vp.[Unit1_ID]=U1.[Unit_ID]
     LEFT JOIN Unit U2       ON vp.[Unit2_ID]=U2.[Unit_ID]
     LEFT JOIN Unit U3       ON vp.[Unit3_ID]=U3.[Unit_ID]
     LEFT JOIN Unit U4       ON vp.[Unit4_ID]=U4.[Unit_ID]
     LEFT JOIN VW_Range r    ON vp.product_id=r.product_id
     LEFT JOIN VW_MedType m  ON vp.product_id=m.product_id
     LEFT JOIN (SELECT * FROM Price WHERE [UnitType]=1) pr ON vp.[product_id]=pr.[P_ID] 
     LEFT JOIN (select * from vw_productbalance where Y_id = @nyid ) vpb ON vp.product_id= vpb.p_id  
    WHERE vp.[DELETEd]<>1 and vp.[Child_Number]=0 and vp.[Product_ID]<>1 and IsSplit=0
    Group by  vp.Class_ID,vp.parent_id,vp.product_id,vp.child_number,vp.deleted,vp.[name],vp.[alias],vp.[pinyin],vp.[Serial_Number],vp.standard,vp.makearea,
        M.medtype , vp.[trademark], vp.[permitcode],vp.[rate2], vp.[rate3], vp.[rate4],
	    U1.[Name] , U2.[Name] ,U3.[Name], U4.[Name],
        vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,
        vp.EngName,vp.ChemName,vp.LatinName,vp.PackStd,vp.StorageCon,vp.RegisterNo,vp.BulidNo,vp.Comment, r.RangeName,vp.Factory
   order by vp.class_id
   
   if OBJECT_ID('tempdb..#mxtable') is not null
		drop table #mxtable
		
   if OBJECT_ID('tempdb..#xshztable') is not null
		drop table #xshztable
		
   if OBJECT_ID('tempdb..#cghztable') is not null
		drop table #cghztable		
   if OBJECT_ID('tempdb..#pshztable') is not null
		drop table #pshztable
		
   if OBJECT_ID('tempdb..#aptable') is not null
		drop table #aptable		
		
   if OBJECT_ID('tempdb..#sytable') is not null
		drop table #sytable		
		
   if OBJECT_ID('tempdb..#dxtable') is not null
		drop table #dxtable		
		
   if OBJECT_ID('tempdb..#psthztable') is not null
		drop table #psthztable		 

/*print convert(varchar(23),getdate(),121)  + 'end'*/

 GOTO SUCCEE

SUCCEE:

  RETURN 0
GO
