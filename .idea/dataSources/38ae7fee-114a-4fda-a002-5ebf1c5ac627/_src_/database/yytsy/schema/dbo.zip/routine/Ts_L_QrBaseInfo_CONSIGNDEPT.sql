
create PROCEDURE Ts_L_QrBaseInfo_CONSIGNDEPT
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

	IF (@szName IS NULL) OR (@szName = '')
		SET @szName = '%%'
	ELSE
		SET @szName = '%' + @szName + '%'	
			
	SELECT l.Id, l.Name, l.Pinyin, l.[ADDRESS], l.Tel, l.LinkMan, l.Driver, l.DriverLicense, l.NumberPlate 
		FROM logisticsInfo l 
	WHERE l.ClassFlag = 'T'	AND (NAME LIKE @szName OR Pinyin LIKE @szName OR Tel LIKE @szName OR NumberPlate LIKE @szName)
GO
