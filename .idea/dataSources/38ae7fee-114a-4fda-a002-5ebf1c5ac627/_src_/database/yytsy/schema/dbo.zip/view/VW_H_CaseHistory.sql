
CREATE VIEW dbo.VW_H_CaseHistory
AS
SELECT     p.PatientID, p.Name, p.sex, p.Tel, p.Birthday, p.Job, p.Address, p.Comment, p.IDCard, p.BulidDate, p.Pos_Id, p.Deleted, p.PinYin, p.Guid, p.ModifyDate, p.isVIP, 
                      p.VIP_ID, ISNULL(r.regDate, '1900-1-1') AS regDate, ISNULL(r.count, 0) AS Count, e.name AS PosName, c.Case_ID, c.BillNo, c.Reg_ID, c.Patient_ID, c.Age, c.Doctor_ID, 
                      c.Doctor, c.CaseDate, c.SelfExp, c.Medical, c.BodyExam, c.AssisExam, c.Diagnose, c.Deal, c.Custom1, c.Custom2, c.Custom3, c.Custom4, ISNULL(v.CardNo, ' ') 
                      AS CardNo, c.Diseasetime, c.Allergies, c.Symptom, c.BloodSugar, c.BloodPressure, c.HeartFunction, c.LiverFunction, c.RenalFunction, c.FoodHabits, c.Medication, 
                      c.VipCardID
FROM         dbo.Patients AS p INNER JOIN
                      dbo.employees AS e ON p.Pos_Id = e.emp_id INNER JOIN
                      dbo.CaseHistory AS c ON p.PatientID = c.Patient_ID LEFT OUTER JOIN
                      dbo.VIPCard AS v ON p.VIP_ID = v.VIPCardID LEFT OUTER JOIN
                          (SELECT     Patient_ID, MAX(RegDate) AS regDate, COUNT(*) AS count
                            FROM          dbo.Registered AS Registered_1
                            GROUP BY Patient_ID) AS r ON p.PatientID = r.Patient_ID
WHERE     (p.Deleted = 0)
GO
