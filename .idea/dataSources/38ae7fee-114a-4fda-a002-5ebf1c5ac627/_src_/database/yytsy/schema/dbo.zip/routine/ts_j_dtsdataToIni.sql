
/*总部导入分支机构期初库存,过账*/
create proc ts_j_dtsdataToIni
/*with encryption*/
as
set nocount on

declare @nY_ID int, @nOpenAccount int
if OBJECT_ID('temp..#companyTmp') is not null
  drop table #companyTmp
select top 0 Y_id, Openaccount into #companyTmp from Companybalance where c_id = 0
insert into #companyTmp(y_id, openaccount) select company_id, 0 from company where Ifindependence = 1
delete #companyTmp  where Y_Id in (select Y_ID from Companybalance where c_id = 0 and OpenAccount = 1) 
if @@ERROR <> 0  goto Error
delete #companyTmp  where Y_Id in (select CAST(sysvalue as int) from sysconfig where UPPER([sysname])='Y_ID')
/*if @@ERROR <> 0 goto Error*/
/*delete #companyTmp  where Y_Id not in (select CAST(sysvalue as int) from sysconfig where UPPER([sysname])='Y_ID')*/
if @@ERROR <> 0 goto Error
delete #companyTmp  where Y_Id = (select ISNULL(COMPANY_ID, 0) from company where class_id='000001')
if @@ERROR <> 0 goto Error
     
begin tran ImportIniData
  declare CompanyCur cursor for
	select Y_id, Openaccount from #companyTmp
	open CompanyCur
	
	fetch next from CompanyCur into @nY_ID, @nOpenAccount
	while @@FETCH_STATUS=0	
	begin
	  if exists(select 1 from accountbalanceDtsIN where y_id = @nY_id)
	    delete accountbalance where y_id = @nY_id
	  if exists(select 1 from ClientsbalanceDtsIN where y_id = @nY_id)    
	    delete Clientsbalance where y_id = @nY_id
	  if exists(select 1 from CompanybalanceDtsIN where y_id = @nY_id)      
	    delete Companybalance where y_id = @nY_id
	  if exists(select 1 from OtherStorehouseinidtsIN where y_id = @nY_id)      
	    delete OtherStorehouseini where y_id = @nY_id
	  if exists(select 1 from storebrrowinidtsIN where y_id = @nY_id)      
	    delete storebrrowini where y_id = @nY_id
	  if exists(select 1 from storedxinidtsIN where y_id = @nY_id)      
	    delete storedxini where y_id = @nY_id
	  if exists(select 1 from storehouseinidtsIN where y_id = @nY_id)      
	    delete storehouseini where y_id = @nY_id
	  
	  insert into accountbalance(y_id, a_id, ini_total) select y_id, a_id, ini_total from accountbalanceDtsIN where y_id = @nY_id
	  
	  insert into Clientsbalance(Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id) 
		select Y_id, C_ID, credit_total, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini, e_id from ClientsbalanceDtsIN where y_id = @nY_id
	  
	  insert into Companybalance(y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini)
		select y_id, c_id, sklimit, artotal_ini, aptotal_ini, pre_artotal_ini, pre_aptotal_ini from CompanybalanceDtsIN where y_id = @nY_id
	   
	  insert into OtherStorehouseini(location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid)
		select location_id, s_id, p_id, supplier_id, batchno, commissionflag, costprice, quantity, makedate, instoretime, validdate, stopsaleflag,  inorder, yhdate, y_id, aoid from OtherStorehouseinidtsIN where y_id = @nY_id 
	  
	  insert into storebrrowini(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
		select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storebrrowinidtsIN where y_id = @nY_id
	  
	  insert into storedxini(location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id)
		select location_id, c_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, oldcommissionflag, y_id from storedxinidtsIN where y_id = @nY_id
	  
	  insert into storehouseini (location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID)
		select location_id, s_id, p_id, supplier_id, quantity, costprice, costtotal, batchno, makedate, instoretime, validdate, commissionflag, stopsaleflag, inorder, YhDate, Y_ID from storehouseinidtsIN where y_id = @nY_id  
	  
	 /* if @nOpenAccount = 1*/
	 /*   exec ts_c_OpenAccount @nY_ID*/
	  if @@ERROR <> 0 goto Error   		
	 fetch next from CompanyCur into @nY_ID, @nOpenAccount
	end	
	close CompanyCur
	deallocate CompanyCur
  
commit tran ImportIniData

truncate table accountbalanceDtsIN
truncate table ClientsbalanceDtsIN
truncate table CompanybalanceDtsIN
truncate table OtherStorehouseinidtsIN
truncate table storebrrowinidtsIN
truncate table storedxinidtsIN
truncate table storehouseinidtsIN

return 0 

Error: 
  close CompanyCur
  deallocate CompanyCur
  if OBJECT_ID('temp..#companyTmp') is not null
    drop table #companyTmp
  truncate table accountbalanceDtsIN
  truncate table ClientsbalanceDtsIN
  truncate table CompanybalanceDtsIN
  truncate table OtherStorehouseinidtsIN
  truncate table storebrrowinidtsIN
  truncate table storedxinidtsIN
  truncate table storehouseinidtsIN  
  Return -1
GO
