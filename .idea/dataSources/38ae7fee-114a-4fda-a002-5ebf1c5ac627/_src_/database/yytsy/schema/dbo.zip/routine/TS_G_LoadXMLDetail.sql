
CREATE PROCEDURE [dbo].[TS_G_LoadXMLDetail]
  @nHisId int = 0,
  @billtype INT,
  @guid UNIQUEIDENTIFIER = 0x
AS
BEGIN
	DECLARE @nxmlHandle int
	DECLARE @xml xml
	SELECT @xml = DetailContent FROM BillHistory WHERE type = 0 AND (id = @nHisId OR guid = @guid)
	EXEC sp_xml_preparedocument @nxmlHandle OUTPUT, @xml
	
	/*入库类*/
	IF @BillType IN (20, 21, 24, 25, 120, 121, 122, 123, 160, 161, 162, 163, 220, 221, 222)
	BEGIN 
		/*SELECT * FROM OPENXML(@nxmlHandle, 'root/buymanagebilldrf', 1) WITH buymanagebilldrf b*/
		          
		SELECT b.smb_id,b.bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.buyprice as price,b.discount,b.discountprice, b.totalmoney, b.total,
		  b.taxprice, b.taxtotal, b.taxmoney, b.retailprice, b.retailtotal,b.makedate,b.validdate,b.qualitystatus, b.order_id, B.orgbillid, b.JSPrice,b.aoid,
		  b.price_id,b.ss_id as s_id,b.sd_id as s_id2, b.location_id as l_id ,b.supplier_id as b_id,b.commissionflag,b.comment,b.unitid,b.taxrate,0 as l_id2,  iotag,
		  p.code,p.name,p.standard,p.modal,p.makearea,p.factory,p.BulidNo,p.RegisterNo,p.comment as Pcomment, p.permitcode, p.trademark,p.medtype,p.medtype_id,
		  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validmonth,p.validday, p.costmethod,
		  p.Unit1_id, p.Unit2_id, p.Unit3_id, p.Unit4_id, p.otcflag,p.alias, p.PackStd, p.StorageCon,p.PcName,p.PcCode,
		  ISNULL(l.l_name,'') as location,
		  '' as LOCATION2,
		  ISNULL(s.s_name,'') as STORAGE,
		  '' as STORAGE2,
		  INVOICETOTAL,
		  0 as COMEDATE,
		  0 as COMEQTY,
		  '' as SN,
		  '' as Vendor,
		  b.ThQTY,b.SendQTY,b.SendCostTotal
		  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5
		  ,b.PriceType,b.RowE_ID, ISNULL(e.[name],'') as RowEName, YGUID=isnull(b.YGUID,newid()), b.YCOSTPRICE, INVOICENO=(case when (b.INVOICENO='') then '0' else b.INVOICENO end)
		  ,b.Y_ID,b.InStoreTime, 0 as cxtype,
		  isnull(p.Wholerate,1)Wholerate,
		  isnull(s.wholeflag,0)wholeflag,
		  0 as wholeflag2, b.comment2,b.batchbarcode,b.scomment,b.batchprice,b.newprice, '' as cxGuid, b.Conclusion,b.FactoryId as FactoryId ,
		  b.costtaxprice,b.costtaxrate,b.costtaxtotal, p.IfZYCheck, 0 AS P_LCSL,0 as p_syts
		FROM OPENXML(@nxmlHandle, 'root/buymanagebilldrf', 1) 
		WITH 
		(
			[smb_id] [int] ,
			[bill_id] [int] ,
			[p_id] [int] ,
			[batchno] [varchar](20) ,
			[quantity] NUMERIC(25,8) ,
			[costprice] NUMERIC(25,8) ,
			[buyprice] NUMERIC(25,8) ,
			[discount] NUMERIC(25,8) ,
			[discountprice] NUMERIC(25,8) ,
			[totalmoney] NUMERIC(25,8) ,
			[taxprice] NUMERIC(25,8) ,
			[taxtotal] NUMERIC(25,8) ,
			[taxmoney] NUMERIC(25,8) ,
			[retailprice] NUMERIC(25,8) ,
			[retailtotal] NUMERIC(25,8) ,
			[makedate] [datetime] ,
			[validdate] [datetime] ,
			[qualitystatus] [varchar](20) ,
			[price_id] [int] ,
			[ss_id] [int] ,
			[sd_id] [int] ,
			[location_id] [int] ,
			[supplier_id] [int] ,
			[commissionflag] [tinyint] ,
			[comment] [varchar](255) ,
			[unitid] [int] ,
			[taxrate] NUMERIC(3,2) ,
			[order_id] [int] ,
			[total] NUMERIC(25,8) ,
			[iotag] [smallint] ,
			[InvoiceTotal] NUMERIC(25,8) ,
			[thqty] NUMERIC(25,8) ,
			[newprice] NUMERIC(25,8),
			[orgbillid] [int] ,
			[AOID] [int] ,
			[jsprice] NUMERIC(25,8) ,
			[invoice] [int] ,
			[invoiceno] [varchar](50) ,
			[PriceType] [int] ,
			[SendQTY] NUMERIC(25,8) ,
			[SendCostTotal] NUMERIC(25,8) ,
			[RowGuid] [uniqueidentifier] ,
			[RowE_id] [int] ,
			[YCostPrice] [varchar](50) ,
			[YGuid] [uniqueidentifier] ,
			[Y_ID] [int] ,
			[transflag] [int] ,
			[instoretime] [datetime] ,
			[comment2] [varchar](200) ,
			[BatchBarCode] [varchar](80) ,
			[scomment] [varchar](80) ,
			[batchprice] NUMERIC(25,8) ,
			[Conclusion] [varchar](200) ,
			[tuihlb] [int] ,
			[wmsQty] NUMERIC(25,8),
			factoryid	int,
			costtaxrate	numeric(25,8),
			costtaxprice	NUMERIC(25,8),
			costtaxtotal	numeric(25,8)
		) b
		inner join vw_b_Products p on b.p_id = p.p_id
		left join  vw_b_storage s  on b.ss_id =s.s_id
		left join  vw_b_location l on b.location_id =l.l_id
		left join employees e      on b.RowE_ID = e.emp_id
		/*ORDER BY b.smb_ID		*/
	END	
	
	/*出库类*/
	IF @BillType IN (10, 11, 16, 17, 110, 111, 112, 113, 210, 211, 212, 150, 151, 152, 153)
	BEGIN
		SELECT b.smb_ID,b.bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.saleprice as price,b.discount,b.discountprice,b.totalmoney, b.total,
		  b.taxprice,b.taxtotal,b.taxmoney,b.retailprice,b.retailtotal,b.makedate,b.validdate,b.qualitystatus, b.order_id, B.orgbillid, b.JSPrice,b.aoid,
		  b.price_id,b.ss_id as s_id,b.sd_id as s_id2, b.location_id as l_id ,b.supplier_id as b_id,b.commissionflag,b.comment,b.unitid,b.taxrate,b.location_id2 as l_id2,  iotag,
		  p.code,p.name,p.standard,p.modal,p.makearea,p.factory,p.BulidNo,p.RegisterNo,p.comment as Pcomment, p.permitcode, p.trademark,p.medtype,p.medtype_id,
		  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validmonth,p.validday, p.costmethod,
		  p.Unit1_id, p.Unit2_id, p.Unit3_id, p.Unit4_id, p.otcflag,p.alias, p.PackStd, p.StorageCon,p.PcName,p.PcCode,
		  ISNULL(l.l_name,'') as location,
		  ISNULL(l2.l_name,'') as LOCATION2,
		  ISNULL(s.s_name,'') as STORAGE,
		  ISNULL(s2.s_name,'') as STORAGE2,
		  INVOICETOTAL,
		  0 as COMEDATE,
		  0 as COMEQTY,
		  '' as SN,
		  isnull(c.[name],'') as Vendor,
		  b.ThQTY,b.SendQTY,b.SendCostTotal
		  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5
		  ,b.PriceType,b.RowE_ID, ISNULL(e.[name],'') as RowEName, YGUID=isnull(b.YGUID,NEWID()), b.YCOSTPRICE, INVOICENO=(case when (b.INVOICENO='') then '0' else b.INVOICENO end)
		  ,b.Y_ID,b.InStoreTime, b.cxType,
		  isnull(p.Wholerate,1)Wholerate,
		  isnull(s.wholeflag,0)wholeflag,
		  0 as wholeflag2, b.comment2,b.batchbarcode,b.scomment,b.batchprice,b.newprice, b.cxGuid, b.Conclusion,
			b.Factoryid,b.costtaxprice,costtaxrate,costtaxtotal, p.IfZYCheck, 0 AS P_LCSL,0 as p_syts
		FROM OPENXML(@nxmlHandle, 'root/salemanagebilldrf', 1)
		WITH 
		(
			[smb_id] [int] ,
			[bill_id] [int] ,
			[p_id] [int] ,
			[batchno] [varchar](20) ,
			[quantity] NUMERIC(25,8),
			[costprice] NUMERIC(25,8) ,
			[saleprice] NUMERIC(25,8) ,
			[discount] NUMERIC(25,8) ,
			[discountprice] NUMERIC(25,8) ,
			[totalmoney] NUMERIC(25,8) ,
			[taxprice] NUMERIC(25,8) ,
			[taxtotal] NUMERIC(25,8) ,
			[taxmoney] NUMERIC(25,8) ,
			[retailprice] NUMERIC(25,8) ,
			[retailtotal] NUMERIC(25,8) ,
			[makedate] [datetime] ,
			[validdate] [datetime] ,
			[qualitystatus] [varchar](20) ,
			[price_id] [int] ,
			[ss_id] [int] ,
			[sd_id] [int] ,
			[location_id] [int] ,
			[supplier_id] [int] ,
			[commissionflag] [tinyint] ,
			[comment] [varchar](255) ,
			[unitid] [int] ,
			[taxrate] NUMERIC(3,2) ,
			[order_id] [int] ,
			[total] NUMERIC(25,8) ,
			[iotag] [smallint] ,
			[InvoiceTotal] NUMERIC(25,8) ,
			[thqty] NUMERIC(25,8) ,
			[newprice] NUMERIC(25,8) ,
			[orgbillid] [int] ,
			[AOID] [int] ,
			[jsprice] NUMERIC(25,8) ,
			[invoice] [int] ,
			[invoiceno] [varchar](50) ,
			[PriceType] [int] ,
			[SendQTY] NUMERIC(25,8) ,
			[SendCostTotal] NUMERIC(25,8),
			[RowGuid] [uniqueidentifier] ,
			[RowE_id] [int] ,
			[YCostPrice] [varchar](50) ,
			[YGuid] [uniqueidentifier] ,
			[Y_ID] [int] ,
			[transflag] [int] ,
			[instoretime] [datetime] ,
			[cxType] [int] ,
			[location_id2] [int] ,
			[comment2] [varchar](200) ,
			[BatchBarCode] [varchar](80) ,
			[scomment] [varchar](80) ,
			[batchprice] NUMERIC(25,8) ,
			[CxGuid] [uniqueidentifier] ,
			[Conclusion] [varchar](200) ,
			[OOSid] [int] ,
			[wmsQty] NUMERIC(25,8),
			factoryid	int,
			costtaxrate	NUMERIC(25,8),
			costtaxprice	NUMERIC(25,8),
			costtaxtotal	NUMERIC(25,8)
		) b
		inner join vw_b_Products p on b.p_id = p.p_id
		left join  vw_b_storage s  on b.ss_id =s.s_id
		left join  vw_b_location l on b.location_id =l.l_id
		left join  vw_b_storage s2  on b.sd_id =s2.s_id
		left join  vw_b_location l2 on b.location_id2 =l2.l_id
		left join  clients c       on b.supplier_id=c.client_id
		left join  employees e     on b.RowE_ID = e.emp_id
		ORDER BY b.smb_ID		
		
	END
	
	/*库存类*/
	IF @BillType IN (30, 31, 33, 34, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 100, 101, 141)
	begin
		SELECT b.smb_ID,b.bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.price as price,0 as discount,0 as discountprice,b.totalmoney, b.total,
		  0 as taxprice,0 as taxtotal,0 as taxmoney,b.retailprice,b.retailmoney as retailtotal,b.makedate,b.validdate,b.qualitystatus, 0 as order_id, B.orgbillid, 0 as JSPrice,b.aoid,
		  b.price_id, b.ss_id as s_id, b.sd_id as s_id2, b.location_id as l_id , b.supplier_id as b_id, b.commissionflag, b.comment, b.unitid,0 as taxrate,b.location_id2 as l_id2, b.iotag,
		  p.code,p.name,p.standard,p.modal,p.makearea,p.factory,p.BulidNo,p.RegisterNo,p.comment as Pcomment, p.permitcode, p.trademark,p.medtype,p.medtype_id,
		  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validmonth,p.validday, p.costmethod,
		  p.Unit1_id, p.Unit2_id, p.Unit3_id, p.Unit4_id, p.otcflag,p.alias, p.PackStd, p.StorageCon,p.PcName,p.PcCode,
		  ISNULL(l.l_name,'') as location,
		  ISNULL(l2.l_name,'') as location2,
		  ISNULL(s.s_name,'') as STORAGE,
		  ISNULL(s2.s_name,'') as STORAGE2,
		  INVOICETOTAL,
		  0 as COMEDATE,
		  0 as COMEQTY,
		  '' as SN,
		  ISNULL(c.c_name,'') as Vendor,
		  b.ThQTY,b.SendQTY,b.SendCostTotal
		  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5
		  ,0 as PriceType,b.RowE_ID, ISNULL(e.[name],'') as RowEName,  NewID() as YGUID, '0' as YCOSTPRICE, '0' as INVOICENO
		  ,b.Y_ID,b.InStoreTime, 0 as cxtype,
		  isnull(p.Wholerate,1)Wholerate,
		  isnull(s.wholeflag,0)wholeflag,
		  isnull(s2.wholeflag,0) as wholeflag2, '' as comment2,b.batchbarcode,b.scomment,b.batchprice,
		  0 as newprice, '' as cxGuid,b.Conclusion,b.Factoryid,
		  b.costtaxprice,b.costtaxrate,b.costtaxtotal, p.IfZYCheck, 0 AS P_LCSL,0 as p_syts
		FROM OPENXML(@nxmlHandle, 'root/storemanagebilldrf', 1)
		WITH
		(
			[smb_id] [int] ,
			[bill_id] [int] ,
			[p_id] [int] ,
			[batchno] [varchar](20) ,
			[quantity] NUMERIC(25,8) ,
			[price] NUMERIC(25,8),
			[totalmoney] NUMERIC(25,8),
			[costprice] NUMERIC(25,8) ,
			[costtotal] NUMERIC(25,8) ,
			[retailprice] NUMERIC(25,8) ,
			[retailmoney] NUMERIC(25,8) ,
			[makedate] [datetime] ,
			[validdate] [datetime] ,
			[qualitystatus] [varchar](20) ,
			[price_id] [int] ,
			[ss_id] [int] ,
			[sd_id] [int] ,
			[location_id] [int] ,
			[supplier_id] [int] ,
			[commissionflag] [tinyint] ,
			[comment] [varchar](255) ,
			[unitid] [int] ,
			[location_id2] [int] ,
			[iotag] [smallint] ,
			[total] NUMERIC(25,8) ,
			[InvoiceTotal] NUMERIC(25,8) ,
			[thqty] NUMERIC(25,8) ,
			[newprice] NUMERIC(25,8) ,
			[orgbillid] [int] ,
			[AOID] [int] ,
			[SendQTY] NUMERIC(25,8) ,
			[SendCostTotal] NUMERIC(25,8) ,
			[RowGuid] [uniqueidentifier] ,
			[RowE_id] [int] ,
			[Y_ID] [int] ,
			[instoretime] [datetime] ,
			[BatchBarCode] [varchar](80) ,
			[scomment] [varchar](80) ,
			[batchprice] NUMERIC(25,8) ,
			[Conclusion] [varchar](200),
			factoryid	int,
			costtaxrate	NUMERIC(25,8),
			costtaxprice	NUMERIC(25,8),
			costtaxtotal	NUMERIC(25,8)
		) b
		inner join vw_b_Products p on b.p_id = p.p_id
		left join  vw_b_storage s  on b.ss_id =s.s_id
		left join  vw_b_storage s2 on b.sd_id =s2.s_id
		left join  vw_b_location l on b.location_id =l.l_id
		left join  vw_b_location l2 on b.location_id2 =l2.l_id
		left join  vw_b_client c on b.supplier_id = c.c_id
		left join  employees e   on b.RowE_ID = e.emp_id
		ORDER BY b.smb_ID
	END
	
	/*订单类*/
	IF @BillType IN (14,22)
	BEGIN
		SELECT b.smb_ID,b.bill_id,0 as a_id,b.p_id,b.batchno,b.quantity,b.costprice,b.saleprice as price,b.discount,b.discountprice,b.totalmoney, b.total,
		  b.taxprice,b.taxtotal,b.taxmoney,b.retailprice,b.retailtotal,b.makedate,b.validdate,b.qualitystatus, 0 as order_id, 0 AS orgbillid, 0 as  JSPrice,0 as aoid,
		  b.price_id,b.ss_id as s_id,b.sd_id as s_id2, b.location_id as l_id ,b.supplier_id as b_id,b.commissionflag,b.comment,b.unitid,b.taxrate,0 as l_id2, 0 as iotag,
		  p.code,p.name,p.standard,p.modal,p.makearea,p.factory,p.BulidNo,p.RegisterNo,p.comment as Pcomment, p.permitcode, p.trademark,p.medtype,p.medtype_id,
		  p.unitrate2, p.unitrate3, p.unitrate4, p.unit1, p.unit2, p.unit3, p.unit4, p.validmonth, p.validday, p.costmethod,
		  p.Unit1_id, p.Unit2_id, p.Unit3_id, p.Unit4_id, p.otcflag,p.alias, p.PackStd, p.StorageCon,p.PcName,p.PcCode,
		  ISNULL(l.l_name,'') as location,
		  '' as LOCATION2,
		  ISNULL(s.s_name,'') as STORAGE,
		  '' as STORAGE2,
		  0 as INVOICETOTAL,
		  b.COMEDATE,
		  b.COMEQTY,
		  /*COMEQTY=CAST( (b.COMEQTY /dbo.GetProductRate(b.p_id,b.unitid)) as NUMERIC(25,8)),*/
		  '' as SN,
		  case
		  when @billtype = 26 then ISNULL(c.c_name,'')
		  else ''
		  end as Vendor,
		  0.0000  as  ThQTY, 0.0000  as SendQTY, 0.0000  as SendCostTotal
		  ,p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5
		  ,0 as PriceType,b.RowE_ID, ISNULL(e.[name],'') as RowEName,  NewID() as YGUID, '0' as YCOSTPRICE, '0' as INVOICENO
		  ,b.Y_ID,InStoreTime, 0 as cxtype,
		  isnull(p.Wholerate,1)Wholerate,
		  isnull(s.wholeflag,0)wholeflag,
		  0 as wholeflag2, b.comment2, batchbarcode, scomment, batchprice,0 as newprice, '' as cxGuid, b.Conclusion,b.Factoryid,
		  b.costtaxprice,b.costtaxrate,b.costtaxtotal, p.IfZYCheck, 0 AS P_LCSL,0 as p_syts
		FROM OPENXML(@nxmlHandle, 'root/orderbill', 1)
		WITH
		(
			[smb_id] [int] ,
			[bill_id] [int] ,
			[p_id] [int] ,
			[batchno] [varchar](20) ,
			[quantity] NUMERIC(25,8) ,
			[costprice] NUMERIC(25,8) ,
			[saleprice] NUMERIC(25,8),
			[discount] NUMERIC(25,8) ,
			[discountprice] NUMERIC(25,8),
			[totalmoney] NUMERIC(25,8),
			[taxprice] NUMERIC(25,8) ,
			[taxtotal] NUMERIC(25,8) ,
			[taxmoney] NUMERIC(25,8) ,
			[retailprice] NUMERIC(25,8) ,
			[retailtotal] NUMERIC(25,8) ,
			[makedate] [datetime] ,
			[validdate] [datetime] ,
			[qualitystatus] [varchar](20) ,
			[price_id] [int] ,
			[ss_id] [int] ,
			[sd_id] [int] ,
			[location_id] [int] ,
			[supplier_id] [int] ,
			[commissionflag] [tinyint] ,
			[comment] [varchar](255) ,
			[unitid] [int] ,
			[taxrate] NUMERIC(3,2) ,
			[ComeDate] [datetime] ,
			[ComeQty] NUMERIC(25,8) ,
			[total] NUMERIC(25,8) ,
			[RowGuid] [uniqueidentifier] ,
			[RowE_id] [int] ,
			[Y_ID] [int] ,
			[comment2] [varchar](200) ,
			[Conclusion] [varchar](200) ,
			[Instoretime] [datetime] ,
			[BatchBarCode] [varchar](30) ,
			[scomment] [varchar](80) ,
			[batchprice] NUMERIC(25,8),
			factoryid	int,
			costtaxrate	NUMERIC(25,8),
			costtaxprice	NUMERIC(25,8),
			costtaxtotal	NUMERIC(25,8)
		) b
		inner join  vw_b_Products p on b.p_id = p.p_id
		left  join  vw_b_storage s  on b.ss_id =s.s_id
		left  join  vw_b_location l on b.location_id =l.l_id
		left  join  vw_b_client c   on b.supplier_id = c.c_id
		left  join  employees e     on b.RowE_ID = e.emp_id 
		ORDER BY b.smb_ID		
		
	END
	
	/*GSP类*/
	IF @billtype BETWEEN 501 AND 599
	BEGIN
			SELECT   b.checkaccept, p.alias, b.aoid, '' AS AOIDNAME, b.applicantqty, p.makearea AS AREA, b.BatchBarCode, b.Batchcomment, 
					b.batchprice, b.returnreason, b.batchno, b.supplier_id, p.BulidNo, b.thqty, b.cansaleqty, b.checkreason, 
					b.checkqty, b.checkstate, p.code, b.Iscold, b.commisionflag, b.COSTPRICE, b.COSTTOTAL, p.Custompro1, p.Custompro2, 
					p.Custompro3, p.Custompro4, p.Custompro5, b.discount, b.DiscountPrice, b.discounttotal, 0 AS EID, b.sfdacounts, 
					p.Factory, b.uneligibletransactor, b.uneligibleqty, b.uneligiblereason, b.instoretime, 0 AS IOTAG, b.s_id, b.location_id, 
					ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, p.medtype AS MEDTYPEID, b.comment, b.comment2, 
					p.name, 0 AS ORDERID, b.Yqty, b.Ytaxprice, b.orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
					b.pickqty, b.p_id, b.price, '合格' AS QUALITYSTATUS, p.rate2, p.rate3, p.rate4, b.inceptqty, 
					CASE ISNULL(b.inceptstate, 0) WHEN 0 THEN '收货' ELSE '拒收' END AS inceptstate, b.refuseqty, 
					b.refusereason, p.RegisterNo, 0 AS REMAINING, b.checkreport, b.sampleqty, b.Gspsmb_id AS SMBID, b.Isspec, 
					p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
					ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, b.eligibleqty, b.taxmoney, 
					b.taxprice, b.pricediscrepancy, b.TaxRate, b.TaxTotal, b.total, p.trademark, p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, 
					p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, p.Unit3Name, p.unit4_id AS UNIT4ID, 
					p.Unit4Name, p.unit1_id AS unit_id, b.validdate, ISNULL(c.name, '') AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, p.WholeRate, b.Yrowguid, b.y_id,
					p.validmonth, p.validday, p.StoreCondition AS DID,
					CASE WHEN g.BillType IN (521, 522, 523, 524) THEN b.EligibleQty ELSE 0 END AS BASEQTY,
					b.factoryid,b.costtaxprice,b.costtaxrate,b.costtaxtotal,isnull(b.OldOrderQty,0) as OldOrderQty ,
					isnull(b.OldOrderUnit,'') as OldOrderUnit,isnull(b.OldOrderUnitId,0) as OldOrderUnitId, 
					isnull(b.OldOrderUnitRate,0) as  OldOrderUnitRate,isnull(b.WholeQty,0) as WholeQty,isnull(b.PartQty,0) as PartQty
			FROM    OPENXML(@nxmlHandle, 'root/GSPbilldetail', 1)
					with(
						[Gspsmb_id] [int],
						[Gspbill_id] [int],
						[P_id] [int],
						[MakeDate] [datetime],
						[Validdate] [datetime],
						[Batchno] [varchar](20),
						[Unit_id] [smallint],
						[Yqty] NUMERIC(25,8),
						[EligibleQty] NUMERIC(25,8),
						[UneligibleQty] NUMERIC(25,8),
						[InceptQty] NUMERIC(25,8),
						[RefuseQty] NUMERIC(25,8),
						[PickQty] NUMERIC(25,8),
						[CheckQty] NUMERIC(25,8),
						[SampleQty] NUMERIC(25,8),
						[ApplicantQty] NUMERIC(25,8),
						[ThQty] NUMERIC(25,8),
						[YtaxPrice] NUMERIC(25,8),
						[Price] NUMERIC(25,8),
						[DiscountPrice] NUMERIC(25,8),
						[TaxPrice] NUMERIC(25,8),
						[Pricediscrepancy] NUMERIC(25,8),
						[Total] NUMERIC(25,8),
						[Discount] NUMERIC(25,8),
						[DiscountTotal] NUMERIC(25,8),
						[TaxRate] NUMERIC(3,2),
						[TaxMoney] NUMERIC(25,8),
						[TaxTotal] NUMERIC(25,8),
						[CostPrice] NUMERIC(25,8),
						[CostTotal] NUMERIC(25,8),
						[InceptState] [int],
						[RefuseReason] [varchar](100),
						[UneligibleReason] [varchar](100),
						[UneligibleTranSactor] [varchar](100),
						[CheckAccept] [varchar](100),
						[CheckReport] [varchar](200),
						[ReturnReason] [varchar](100),
						[CheckState] [varchar](200),
						[CheckReason] [varchar](100),
						[S_id] [int],
						[Location_id] [int],
						[Supplier_id] [int],
						[InstoreTime] [datetime],
						[CanSaleQty] NUMERIC(25,8),
						[BatchBarCode] [varchar](30),
						[Batchcomment] [varchar](100),
						[BatchPrice] NUMERIC(25,8),
						[Iscold] [smallint],
						[Isspec] [smallint],
						[Y_id] [int],
						[Aoid] [int],
						[SfdAcounts] [int],
						[OrgBillid] [int],
						[YrowGuid] [uniqueidentifier],
						[CommisionFlag] [int],
						[RowGUID] [uniqueidentifier],
						[Comment] [varchar](100),
						[Comment2] [varchar](100),
						[Comment3] [varchar](100),
						factoryid	int,
						costtaxrate	NUMERIC(25,8),
						costtaxprice	NUMERIC(25,8),
						costtaxtotal	NUMERIC(25,8),
						OldOrderQty  NUMERIC(25,8),
						OldOrderUnit varchar (100),
						OldOrderUnitId int,
						OldOrderUnitRate NUMERIC(25,8),
						WholeQty NUMERIC(25,8),
						PartQty NUMERIC(25,8)
					) b
			        INNER JOIN
					dbo.GSPbillidx AS g ON b.Gspbill_id = g.Gspbillid INNER JOIN
					dbo.vw_Products AS p ON b.p_id = p.product_id LEFT JOIN
					dbo.storages AS s ON b.s_id = s.storage_id LEFT OUTER JOIN
					dbo.clients AS c ON b.Supplier_id = c.client_id LEFT OUTER JOIN
					dbo.location AS l ON b.location_id = l.loc_id
			ORDER BY B.Gspsmb_id		
		
	END
	
	EXEC sp_xml_removedocument @nxmlHandle
	
	
END
GO
