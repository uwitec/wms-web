
CREATE	       PROCEDURE Ts_K_CreateScatteredFromRetail
(
	@P_Id   INT = 0,              /*商品ID*/
	@S_Id   INT = 0,              /*零售库ID*/
	@E_Id   INT = 0,              /*制单人ID*/
	@Y_Id   INT = 0,              /*制单人所属机构YID*/
    @nRet   INT OUTPUT
)
/*with encryption*/
AS
BEGIN
	DECLARE @S_Id1 INT
	SELECT TOP 1 @S_Id1 = s.storage_id
	  FROM storages s 
	WHERE s.Y_ID = @Y_Id AND s.[deleted] = 0 AND s.WholeFlag = 3
	
	IF @S_Id1 IS NULL
	BEGIN    
		SET @nRet = -1
		RETURN @nRet
	END	
	
	DECLARE @BillId INT
	DECLARE @BillNumber VARCHAR(50)
	
	EXEC TS_H_CreateBillSN;1 39, 1, NULL, @E_Id, @E_Id, @BillNumber OUTPUT, @Y_Id
	
	BEGIN TRAN K_CreateScattered
	
	INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id,
                             auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period,
                             billstates, order_id, department_id, posid, region_id, auditdate,
                             skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime,
                             [GUID], invoiceTotal, invoiceNO, businesstype, araptotal, sendqty,
                             gatheringman, vipcardid, jsinvoicetotal, Y_ID, transflag, begindate,
                             Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3,
                             RetailDate, sendC_id, WholeQty, PartQty,
                             QualityAudit, QualityAuditDate, YGuid, 
                             financeaudit, financeauditdate, follownumber, ticketdate,ZBAuditMan,ZBAuditDate)
	SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @BillNumber, 39, 0, 0, @E_Id, @S_Id, @S_Id1, 
           @E_Id, @E_Id, 0, 0, 0, 0, 0, 
           3, 0, 0, 0, 0, CONVERT(VARCHAR(100), GETDATE(), 23), 
           '1900-01-01', 0, 0, '零售自动生成零售拆零单', '', 0, 0, '1900-01-01',
           NEWID(), 0, '', 0, 0, 0,
           0, 0, 0, @Y_Id, 0, '1900-01-01',
           '1900-01-01', 0, 0, 0, 0, 0,
           '1900-01-01', 0, 0, 0, 0, '1900-01-01', 0x0,
           0, '1900-01-01', '', '1900-01-01',0,'1900-01-01'
	IF (@@ERROR <> 0) OR (@@ROWCOUNT <= 0)
	BEGIN
		ROLLBACK TRAN K_CreateScattered
		SET @nRet = -2
		RETURN @nRet
	END
	ELSE
		SET @BillId = @@IDENTITY
	
	DECLARE @UnitId INT, @Rate NUMERIC(25,8)
	SELECT @UnitId = p.cldw, @Rate = p.hsbl FROM products p WHERE p.product_id = @P_Id
	
	IF EXISTS(SELECT * FROM tempdb..sysobjects WHERE ID = OBJECT_ID('TEMPDB..#CreateScatteredTemp'))
        DROP TABLE #CreateScatteredTemp
	
	SELECT TOP 1 @BillId AS bill_id, s.p_id, s.batchno, 1 AS quantity, s.costprice AS price, s.costprice AS totalmoney, 
	       s.costprice, s.costprice AS costtotal, 0 AS retailprice, 0 AS retailmoney, s.makedate, s.validdate, 
	       '合格' AS qualitystatus, 0 as price_id, s.s_id AS ss_id, 0 AS sd_id, s.location_id, s.supplier_id, 
	       s.commissionflag, CAST('' AS VARCHAR(10)) AS comment, p.unit1_id AS unitid, 0 AS location_id2, 0 AS iotag, s.costprice AS total, 
	       0 AS invoicetotal, 1 AS thqty, s.costprice AS newprice, 0 AS orgbillid, 0 AS aoid, 1 AS sendqty, 
	       s.costprice AS sendcosttotal, NEWID() AS rowguid, @E_Id AS rowe_id, @Y_Id AS y_id, s.instoretime, 
	       CAST('' AS VARCHAR(10)) AS batchbarcode, CAST('' AS VARCHAR(10)) AS scomment, 0 AS batchprice, CAST('' AS VARCHAR(10)) AS conclusion, 
	       s.factoryid, s.costtaxprice, s.taxrate AS costtaxrate, s.costtaxtotal, p.unit1_id, p.cljg
	INTO #CreateScatteredTemp  
	FROM (SELECT * FROM storehouse WHERE s_id = @S_Id AND p_id = @P_Id) s 
		LEFT JOIN dbo.OutBatch(@S_Id, @P_Id) o ON o.p_id = s.p_id AND o.batchno=s.batchno AND o.supplier_id=s.supplier_id AND 
		                                     o.location_id=s.location_id AND o.validdate=s.validdate and o.makedate=s.makedate AND 
		                                     o.commissionflag=s.commissionflag AND o.costprice=s.costprice and o.instoretime=s.instoretime
		INNER JOIN products p ON s.p_id = p.product_id	
	WHERE (s.quantity + ISNULL(o.quantity, 0)) >= 1 ORDER BY s.validdate
	
	
	IF NOT EXISTS(SELECT * FROM tempdb..sysobjects WHERE ID = OBJECT_ID('TEMPDB..#CreateScatteredTemp'))
    BEGIN
		ROLLBACK TRAN K_CreateScattered
		SET @nRet = -3
		RETURN @nRet	
    END 
	
	INSERT INTO storemanagebilldrf(bill_id, p_id, batchno, quantity, price, totalmoney, costprice, costtotal, retailprice, retailmoney, makedate, validdate,
							       qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, comment, unitid, location_id2, iotag,
							       total, thqty, newprice, orgbillid, aoid, sendqty, sendcosttotal, rowguid, rowe_id, y_id, instoretime, batchbarcode,
							       scomment, batchprice, conclusion, factoryid, costtaxprice, costtaxrate, costtaxtotal)
	SELECT a.bill_id, a.p_id, a.batchno, a.quantity, a.price, a.totalmoney, a.costprice, a.costtotal, ISNULL(b.retailprice, 0), ISNULL(b.retailprice, 0), a.makedate, a.validdate,
	       a.qualitystatus, a.price_id, a.ss_id, a.sd_id, a.location_id, a.supplier_id, a.commissionflag, a.comment, a.unitid, a.location_id2, 0,
	       a.total, a.thqty, a.newprice, a.orgbillid, a.aoid, a.sendqty, a.sendcosttotal, a.rowguid, a.rowe_id, a.y_id, a.instoretime, a.batchbarcode,
	       a.scomment, a.batchprice, a.conclusion, a.factoryid, a.costtaxprice, a.costtaxrate, a.costtaxtotal
	FROM #CreateScatteredTemp a LEFT JOIN price b ON a.p_id = b.p_id AND a.unit1_id = b.u_id
	UNION ALL
	SELECT bill_id, p_id, batchno, quantity * @Rate, price / @Rate, totalmoney, costprice / @Rate, costtotal, Cljg, Cljg * quantity * @Rate, makedate, validdate,
	       qualitystatus, price_id, 0, @S_Id1, location_id, supplier_id, commissionflag, comment, @UnitId, location_id2, 1,
	       total, thqty * @Rate, newprice / @Rate, orgbillid, aoid, sendqty * @Rate, sendcosttotal, NEWID(), rowe_id, y_id, instoretime, batchbarcode,
	       scomment, batchprice, conclusion, factoryid, costtaxprice / @Rate, costtaxrate, costtaxtotal
	FROM #CreateScatteredTemp
	
    
	IF (@@ERROR <> 0) OR (@@ROWCOUNT < 2)
	BEGIN
		ROLLBACK TRAN K_CreateScattered
		SET @nRet = -4
		RETURN @nRet
	END
		
	IF EXISTS(SELECT * FROM tempdb..sysobjects WHERE ID = OBJECT_ID('TEMPDB..#CreateScatteredTemp'))
        DROP TABLE #CreateScatteredTemp
    
    DECLARE @p1 INT, @p2 INT
	SET @p1 = 0
	SET @p2 = 0
	EXEC ts_c_BillAuditUnTran;1 @BillId, @p1 OUTPUT, @p2 OUTPUT, 39
	IF (@@ERROR <> 0) OR (@p2 <> 0)
	BEGIN
		ROLLBACK TRAN K_CreateScattered
		SET @nRet = -5
		RETURN @nRet	
	END       
	ELSE
	BEGIN
		COMMIT TRAN K_CreateScattered
		SET @nRet = 0
		RETURN @nRet
	END

END
GO
