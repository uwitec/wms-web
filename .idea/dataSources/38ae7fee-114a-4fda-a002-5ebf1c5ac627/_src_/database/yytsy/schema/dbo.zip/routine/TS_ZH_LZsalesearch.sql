CREATE PROCEDURE TS_ZH_LZsalesearch
@BeginDate datetime=0,
@EndDate datetime=0
AS
BEGIN 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
/*Params Ini end*/
	SET NOCOUNT ON;
if object_id('tempdb..#total') is not null
 drop table #total
if object_id('tempdb..#temp1') is not null 
 drop table #temp1
/*------------------- */
select company_id,cname,sname,sum(taxtotal) as taxtotal,SUM(ml) as ml
,cast(sum(ml)/SUM(taxtotal)*100 as varchar)+'%' as mll into #temp1
from (select company_id,cname,sname,taxtotal,(taxtotal-(quantity*costprice)) as ml,costprice 
from(select product_id,company.company_id,company.name as cname,SaleRange2.name as sname,
 case when billtype in(10,12,212) then  sum(isnull(taxtotal,0)) when billtype in(11,13) then -sum(isnull(taxtotal,0)) end as taxtotal,
 case when billtype in(10,12,212) then sum(isnull(salemanagebill.quantity,0)) when billtype in(11,13) then -sum(isnull(salemanagebill.quantity,0)) end as quantity, 
 costprice 
 from products inner join salemanagebill on product_id=p_id 
  inner join billidx on bill_id=billid
  inner join SaleRange2 on SR2_id=SaleRange2.id
  inner join company on salemanagebill.Y_ID=company_id
  where AOID=0/*不统计赠品*/ and 
  billidx.billdate between @BeginDate and @EndDate /*company.company_id=@com_id */
  group by products.product_id,company.company_id,company.name,
    SaleRange2.name,billtype,salemanagebill.costprice) ab 
 ) a4 group by a4.company_id,cname,sname
/*--------------------------*/
create table #total(店名 varchar(100))
/*----	*/
 declare @lei_name varchar(200)
 declare @sql1 varchar(8000)
 declare @sql2 varchar(5000)
 declare cursor1 cursor for
select distinct sname from #temp1
 open cursor1
fetch next from cursor1 into @lei_name
while @@FETCH_STATUS=0
 begin 
  set @sql1='alter table #total add ['+@lei_name+'|'+@lei_name+'销售] money default 0,['
   +@lei_name+'|'+@lei_name+'毛利] money default 0,['
   +@lei_name+'|'+@lei_name+'毛利率] varchar(50) default ''0.0000%'''
   print(@sql1)
   exec(@sql1)
  fetch next from cursor1 into @lei_name
 end
 close cursor1
 deallocate cursor1
set @sql2='alter table #total add 销售合计 money default 0,毛利合计 money default 0,平均毛利率 varchar(50) default ''0.0000%'''
exec(@sql2)

declare @fd_id int
declare @fd_name varchar(50)
declare @fdstr varchar(7000)
declare @sale_total money/*销售合计*/
declare @sale_mltotal money/*毛利合计*/
declare @sale_avgmll varchar(50)/*平均毛利率*/
declare fendian cursor for
 select distinct company_id,cname from #temp1
open fendian
fetch next from fendian into @fd_id,@fd_name
while @@FETCH_STATUS=0
begin
/*--------各店销售合计*/

/*销售合计*/
select @sale_total=SUM(taxtotal) from #temp1 where company_id=@fd_id
/*毛利合计*/
select @sale_mltotal=SUM(ml) from #temp1 where company_id=@fd_id
/*-平均毛利率*/
select @sale_avgmll=cast(SUM(ml)/SUM(taxtotal)*100 as varchar)+'%' from #temp1 where company_id=@fd_id
/*----------*/
  set @fdstr='insert into #total([店名],[销售合计],[毛利合计],[平均毛利率]) values('''+@fd_name+''','+cast(@sale_total as varchar)+','+cast(@sale_mltotal as varchar)+','''+@sale_avgmll+''')'
  /*print @fdstr*/
  exec(@fdstr)
  fetch next from fendian into @fd_id,@fd_name
end 
close fendian
deallocate fendian

declare @cname varchar(100)
declare @sname varchar(50)
declare @taxtotal money
declare @ml money
declare @mll varchar(50)
declare @tm_sale1 varchar(50)
declare @tm_ml varchar(50)
declare @tm_mll varchar(50)
declare @str varchar(8000)
declare cursor2 cursor for
select cname,sname,taxtotal,ml,mll from #temp1
open cursor2
fetch next from cursor2 into @cname,@sname,@taxtotal,@ml,@mll 
while @@FETCH_STATUS=0
 begin
  set @tm_sale1=@sname+'|'+@sname+'销售'
  set @tm_ml=@sname+'|'+@sname+'毛利'
  set @tm_mll=@sname+'|'+@sname+'毛利率'
  /*if @@ROWCOUNT<=0 */
  set @str='UPDATE #total set ['+@tm_sale1+']='+cast(@taxtotal as varchar)+',['+@tm_ml+']='+cast(@ml as varchar)+',['+@tm_mll+']='''+@mll+''' where [店名]='''+@cname+''''
  /*print @str*/
  exec(@str)
  fetch next from cursor2 into @cname,@sname,@taxtotal,@ml,@mll
 end
 close cursor2
 deallocate cursor2
 
 /*select * from #temp1*/
 select * from #total
if object_id('tempdb..#total') is not null
 drop table #total
if object_id('tempdb..#temp1') is not null 
 drop table #temp1
END
GO
