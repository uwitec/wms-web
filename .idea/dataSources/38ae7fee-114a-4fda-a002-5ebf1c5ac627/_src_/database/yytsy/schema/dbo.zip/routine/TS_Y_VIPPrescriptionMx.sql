
/* =============================================*/
/* Author:		<YH>*/
/* Create date: <2014-12-29>*/
/* Description:	<会员处方明细查询>*/
/* =============================================*/
CREATE PROCEDURE TS_Y_VIPPrescriptionMx
	(	@BeginDate 		  VARCHAR(10)='',
	    @EndDate	 	  VARCHAR(10)='',
	    @billnumber	      VARCHAR(30)='',
        @symptom         varchar(100)='',  /* 症状*/
    	@nPID			  INT=0,
	    @nSortType		  INT=0,
        @nYClassid        varchar(50)='',
        @nloginEID        int=0,
        @vipno            varchar(100)='',   /*会员卡号 */
        @Inputman        int=0
        
)
AS
BEGIN
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	SET NOCOUNT ON;
  Declare @Companytable varchar(100)
  Declare @yid int
   
  if OBJECT_ID('tempdb..#Companytable') is not null
    drop table #Companytable 
   create table #Companytable([id] int)
  if OBJECT_ID('tempdb..#PrescriptionMx') is not null
    drop table #PrescriptionMx

  /*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
 
 if @nYClassid <>'' 
 begin
   select @yid=company_id from company where class_id=@nYClassid
 end
 else
 begin
   set @yid=0
 end
 
select * into #PrescriptionMx from
 (
	select  b.Billdate,b.billnumber,b.billtype,b.inputman, d.smb_id,d.bill_id,b.billstates,b.Y_ID,
			case when d.AOID = 8  then h.product_id else P.[product_id] end as P_id,
			case when d.AOID = 8  then h.Code else P.[Code] end as Code,
			case when d.AOID = 8  then h.name else P.[Name] end AS [PName],                 
			case when d.AOID = 8  then '' else P.[Standard] end as Standard,
			case when d.AOID = 8  then '' else P.[Makearea] end as Makearea,
			case when d.AOID = 8  then '' else P.[Medtype] end as Medtype,
			case when d.AOID = 8  then '' else P.Custompro1 end as Custompro1, 
			case when d.AOID = 8  then '' else P.Custompro2 end as Custompro2, 
			case when d.AOID = 8  then '' else P.Custompro3 end as Custompro3, 
			case when d.AOID = 8  then '' else P.Custompro4 end as Custompro4, 
			case when d.AOID = 8  then '' else P.Custompro5 end as Custompro5, 
			case when d.AOID = 8  then h.UnitName else P.[Unitname1] end AS [Unitname],
			d.[Validdate],
			d.[Batchno],
			d.comment,
			case when d.AOID = 8  then h.comment else p.Comment end as comments,
			case when d.AOID = 8  then h.alias else p.Alias end as alias,
			case when d.AOID = 8  then '' else isnull(f.AccountComment,'') end as factoryname,
			case when d.AOID = 8  then '' else isnull(c.name,'') end as suppliername,
			d.totalmoney,d.quantity,d.taxprice,d.taxtotal,d.taxmoney,
			b.note as symptom,/*症状*/
			b.summary as diagnosis,/*诊断*/
			v.CardNo,v.Name as vipname,e.name as inputname,
			case when d.AOID = 8  then '' else isnull(VP.e_name,'') end as e_name ,
			case when d.AOID = 8  then '' else isnull(VP.C_Name,'') end as c_name 
	 from  dbo.RETAILBILL as d 
	 left join dbo.RETAILBILLIDX as b on d.bill_id=b.billid
	 left join dbo.VW_C_Products as p on p.product_id=d.p_id
	 left join VW_H_SpecialProducts as h on d.p_id = h.product_id
	 LEFT JOIN dbo.clients as c   ON c.client_id=d.supplier_id 
     left join Registered as  r on r.Reg_ID = b.order_id
     left join Patients as ps on ps.PatientID = r.Patient_ID
     left join VIPCard as v on v.VIPCardID = ps.VIP_ID
	 left join dbo.employees as e on e.emp_id=b.inputman 
	 left join basefactory as f   on p.factoryc_id=f.CommID
	  LEFT JOIN vw_productbalance VP ON VP.p_id = d.p_id and VP.Y_id = b.Y_ID 
	
     WHERE (b.[Billtype] IN (244) AND
            b.[Billdate] BETWEEN @BeginDate AND @EndDate) and billstates=2 
           and ((@nPID=0) or (d.p_id=@nPID))
           and ((@billnumber='') or (b.billnumber=@billnumber))/*门诊号*/
           and ((@vipno='') or (v.CardNo=@vipno))/*会员卡号*/
           and ((@symptom='')or (b.note like'%'+@symptom+'%'))/*症状*/
           and ((@Inputman =0 )or (b.inputman=@Inputman ))
           and (@nYClassid='' OR b.Y_id=@yid)
     ) as a 
     
     select  
     CASE WHEN (GROUPING([Smb_ID])=1)  THEN 0  ELSE ISNULL([Smb_ID]        ,'UNKNOW') END AS [Smb_ID],
	CASE WHEN (GROUPING([Bill_ID])=1) THEN 0  ELSE ISNULL([Bill_ID]       ,'UNKNOW') END AS [BillID],
		MAX( Billdate )    AS [Billdate],
		MAX([Billnumber])    AS [Billnumber],
		MAX([Code])          AS [Code],
		MAX([Pname])         AS [Pname],
		MAX([Standard])      AS [Standard],
		MAX([Billstates])    AS [Billstates],
		MAX([Makearea])      AS [Makearea],
		MAX([Medtype])       AS [Medtype],
		MAX(Custompro1) as Custompro1, MAX(Custompro2) as Custompro2, 
		MAX(Custompro3) as Custompro3, Max(Custompro4) as Custompro4, 
		Max(Custompro5) as Custompro5,	
		MAX([Inputman])      AS [Inputman],
		MAX([inputname])     AS [inputname],
		MAX([Validdate])     AS [Validdate],
		MAX([Batchno])       AS [Batchno],
		MAX([Unitname])      AS [Unitname],
		dbo.Decimalbits(4,MAX([Taxprice])) AS [Taxprice],
		MAX(comment)         AS [comment],
	   MAX(suppliername)    AS [suppliername],
		SUM([Quantity])      AS [Quantity],
		SUM([Taxmoney])      AS [Taxmoney],
        dbo.Decimalbits(3,SUM([Taxtotal]))      AS [Taxtotal],
        MAX(symptom) as symptom,/*症状*/
		MAX(diagnosis) as diagnosis,/*诊断*/
		MAX(CardNo)	as CardNo,
		MAX(vipname) as vipname,MAX(inputman) as inputman,
		MAX(e_name) e_name ,
		MAX(billtype) billtype,
		max(c_name) c_name ,
		MAX(comments) as comments,
		MAX(factoryname) as factoryname,
		MAX(alias) as alias
     from #PrescriptionMx
     where ((@Companytable=0)or (Y_id in (select [id] from #Companytable)))
     GROUP BY [Bill_ID], [Smb_ID] WITH ROLLUP
     ORDER BY [Billdate],billnumber
     
     drop table #PrescriptionMx
     
           
END
GO
