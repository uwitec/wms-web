CREATE      PROCEDURE [WebAPP_RepYearAnalyse]
( 
  @params     	VARCHAR(200)
)
AS
--Params Ini begin
DECLARE @StoredProcMode INT,@szYear VARCHAR(4),@nMode INT
select @StoredProcMode = dbo.webapp_get_param(@params, 'StoredProcMode', default, default)
select @szYear = dbo.webapp_get_param(@params, 'szYear', default, default)
select @nMode = dbo.webapp_get_param(@params, 'nMode', default, default)
if @StoredProcMode 	 is null  SET @StoredProcMode = 0
if @szYear='' or @szYear is null  SET @szYear = '0'
if @nMode 	 	 is null  SET @nMode = 0
--Params Ini end
  SET NOCOUNT ON 

DECLARE @ONLYWRITE INT
SET @ONLYWRITE=0
IF @StoredProcMode<0 
BEGIN
	SET @StoredProcMode=ABS(@StoredProcMode)
	SET @ONLYWRITE=1
END

declare @nYear int
Select @nYear=cast(@szYear as int)

if @nMode=1 
begin
	if exists(select * FROM SaleSumRec WHERE Mode=1 AND (@nYear=0 OR [Year]=@nYear))--存在信息才删除重新更新
	begin
		--exec TS_H_RepSaleMonthAnalyse  1, 1, 3, @szYear, '000000', '', '', '', '', '', '0,7,6', '12,13,10,11,18,16,17,112,32', 0, 2
		delete from SaleSumRec where Mode=10 AND ([Year]=@nYear)
	
		INSERT INTO SaleSumRec([Mode],[Year],[Month],[BillType],[Id],[ClassId],[Quantity],[CostTotal],[MlTotal],[TotalMoney])
		SELECT  10 AS [Mode],[Year],[Month],0 AS [BillType],0 AS [Id],'' AS [ClassId],
			SUM(Quantity) AS Quantity,
			SUM(CostTotal) AS CostTotal,
			SUM(MlTotal) AS MlTotal,
			SUM(TotalMoney) AS TotalMoney
		FROM SaleSumRec
		WHERE Mode=1
		  AND (@nYear=0 OR [Year]=@nYear)
		GROUP BY [Year],[Month]
	end
end

IF @ONLYWRITE=1 
	RETURN 0
	
SELECT 0 as SerialNo,[Year],
	ISNULL(SUM(CASE Month WHEN  1 THEN [Quantity] END), 0) AS [Quantity1],
	ISNULL(SUM(CASE Month WHEN  2 THEN [Quantity] END), 0) AS [Quantity2],
	ISNULL(SUM(CASE Month WHEN  3 THEN [Quantity] END), 0) AS [Quantity3],
	ISNULL(SUM(CASE Month WHEN  4 THEN [Quantity] END), 0) AS [Quantity4],
	ISNULL(SUM(CASE Month WHEN  5 THEN [Quantity] END), 0) AS [Quantity5],
	ISNULL(SUM(CASE Month WHEN  6 THEN [Quantity] END), 0) AS [Quantity6],
	ISNULL(SUM(CASE Month WHEN  7 THEN [Quantity] END), 0) AS [Quantity7],
	ISNULL(SUM(CASE Month WHEN  8 THEN [Quantity] END), 0) AS [Quantity8],
	ISNULL(SUM(CASE Month WHEN  9 THEN [Quantity] END), 0) AS [Quantity9],
	ISNULL(SUM(CASE Month WHEN  10 THEN [Quantity] END), 0) AS [Quantity10],
	ISNULL(SUM(CASE Month WHEN  11 THEN [Quantity] END), 0) AS [Quantity11],
	ISNULL(SUM(CASE Month WHEN  12 THEN [Quantity] END), 0) AS [Quantity12],
	ISNULL(SUM(CASE Month WHEN  1 THEN [TaxPrice] END), 0) AS [TaxPrice1],
	ISNULL(SUM(CASE Month WHEN  2 THEN [TaxPrice] END), 0) AS [TaxPrice2],
	ISNULL(SUM(CASE Month WHEN  3 THEN [TaxPrice] END), 0) AS [TaxPrice3],
	ISNULL(SUM(CASE Month WHEN  4 THEN [TaxPrice] END), 0) AS [TaxPrice4],
	ISNULL(SUM(CASE Month WHEN  5 THEN [TaxPrice] END), 0) AS [TaxPrice5],
	ISNULL(SUM(CASE Month WHEN  6 THEN [TaxPrice] END), 0) AS [TaxPrice6],
	ISNULL(SUM(CASE Month WHEN  7 THEN [TaxPrice] END), 0) AS [TaxPrice7],
	ISNULL(SUM(CASE Month WHEN  8 THEN [TaxPrice] END), 0) AS [TaxPrice8],
	ISNULL(SUM(CASE Month WHEN  9 THEN [TaxPrice] END), 0) AS [TaxPrice9],
	ISNULL(SUM(CASE Month WHEN  10 THEN [TaxPrice] END), 0) AS [TaxPrice10],
	ISNULL(SUM(CASE Month WHEN  11 THEN [TaxPrice] END), 0) AS [TaxPrice11],
	ISNULL(SUM(CASE Month WHEN  12 THEN [TaxPrice] END), 0) AS [TaxPrice12],
	ISNULL(SUM(CASE Month WHEN  1 THEN [CostTotal] END), 0) AS [CostTotal1],
	ISNULL(SUM(CASE Month WHEN  2 THEN [CostTotal] END), 0) AS [CostTotal2],
	ISNULL(SUM(CASE Month WHEN  3 THEN [CostTotal] END), 0) AS [CostTotal3],
	ISNULL(SUM(CASE Month WHEN  4 THEN [CostTotal] END), 0) AS [CostTotal4],
	ISNULL(SUM(CASE Month WHEN  5 THEN [CostTotal] END), 0) AS [CostTotal5],
	ISNULL(SUM(CASE Month WHEN  6 THEN [CostTotal] END), 0) AS [CostTotal6],
	ISNULL(SUM(CASE Month WHEN  7 THEN [CostTotal] END), 0) AS [CostTotal7],
	ISNULL(SUM(CASE Month WHEN  8 THEN [CostTotal] END), 0) AS [CostTotal8],
	ISNULL(SUM(CASE Month WHEN  9 THEN [CostTotal] END), 0) AS [CostTotal9],
	ISNULL(SUM(CASE Month WHEN  10 THEN [CostTotal] END), 0) AS [CostTotal10],
	ISNULL(SUM(CASE Month WHEN  11 THEN [CostTotal] END), 0) AS [CostTotal11],
	ISNULL(SUM(CASE Month WHEN  12 THEN [CostTotal] END), 0) AS [CostTotal12],
	ISNULL(SUM(CASE Month WHEN  1 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal1],
	ISNULL(SUM(CASE Month WHEN  2 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal2],
	ISNULL(SUM(CASE Month WHEN  3 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal3],
	ISNULL(SUM(CASE Month WHEN  4 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal4],
	ISNULL(SUM(CASE Month WHEN  5 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal5],
	ISNULL(SUM(CASE Month WHEN  6 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal6],
	ISNULL(SUM(CASE Month WHEN  7 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal7],
	ISNULL(SUM(CASE Month WHEN  8 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal8],
	ISNULL(SUM(CASE Month WHEN  9 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal9],
	ISNULL(SUM(CASE Month WHEN  10 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal10],
	ISNULL(SUM(CASE Month WHEN  11 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal11],
	ISNULL(SUM(CASE Month WHEN  12 THEN [TotalMoney]-[CostTotal] END), 0) AS [MlTotal12],
	ISNULL(SUM(CASE Month WHEN  1 THEN [TotalMoney] END), 0) AS [TotalMoney1],
	ISNULL(SUM(CASE Month WHEN  2 THEN [TotalMoney] END), 0) AS [TotalMoney2],
	ISNULL(SUM(CASE Month WHEN  3 THEN [TotalMoney] END), 0) AS [TotalMoney3],
	ISNULL(SUM(CASE Month WHEN  4 THEN [TotalMoney] END), 0) AS [TotalMoney4],
	ISNULL(SUM(CASE Month WHEN  5 THEN [TotalMoney] END), 0) AS [TotalMoney5],
	ISNULL(SUM(CASE Month WHEN  6 THEN [TotalMoney] END), 0) AS [TotalMoney6],
	ISNULL(SUM(CASE Month WHEN  7 THEN [TotalMoney] END), 0) AS [TotalMoney7],
	ISNULL(SUM(CASE Month WHEN  8 THEN [TotalMoney] END), 0) AS [TotalMoney8],
	ISNULL(SUM(CASE Month WHEN  9 THEN [TotalMoney] END), 0) AS [TotalMoney9],
	ISNULL(SUM(CASE Month WHEN  10 THEN [TotalMoney] END), 0) AS [TotalMoney10],
	ISNULL(SUM(CASE Month WHEN  11 THEN [TotalMoney] END), 0) AS [TotalMoney11],
	ISNULL(SUM(CASE Month WHEN  12 THEN [TotalMoney] END), 0) AS [TotalMoney12],
	ISNULL(SUM(Quantity),0) AS Quantity,
	CASE ISNULL(SUM(Quantity),0) when 0 then 0 ELSE  ISNULL(SUM(TotalMoney), 0)/ ISNULL(SUM(Quantity), 0)  end as SumPrice,
	ISNULL(SUM(CostTotal),0) AS CostTotal,
	ISNULL(SUM(TotalMoney),0)-ISNULL(SUM(CostTotal),0) AS MlTotal,
	ISNULL(SUM(TotalMoney),0) AS TaxTotal  
FROM 
(
	SELECT *, CASE ISNULL([Quantity],0) when 0 then 0 ELSE  ISNULL([TotalMoney], 0)/ ISNULL([Quantity], 0)  end as TaxPrice
	FROM  SaleSumRec 
	WHERE Mode=10
) A
WHERE (@nYear=0 OR [Year]=@nYear)
GROUP BY [Year]
ORDER BY [Year]




  GOTO SUCCEE

	
SUCCEE:
  RETURN 0
ERROR101:
  RETURN -1
GO
