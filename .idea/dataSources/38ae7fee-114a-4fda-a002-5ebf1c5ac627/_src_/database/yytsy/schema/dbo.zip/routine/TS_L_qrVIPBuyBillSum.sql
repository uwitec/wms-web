/***************************************************
会员消费单据汇总统计，txy，2008－12－04
****************************************************/
CREATE PROCEDURE [TS_L_qrVIPBuyBillSum]
(
  @BeginDate   varchar(30)='',
  @EndDate     varchar(30)='',
  @CardID      int=0,
  @cardtype    int=0,
  @PosID       int=0,
  @E_ID        int=0,
  @inputman_id int=0
  
)
 AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = ''
if @EndDate is null  SET @EndDate = ''
if @CardID is null  SET @CardID = 0
if @cardtype is null  SET @cardtype = 0
if @PosID is null  SET @PosID = 0
if @E_ID is null  SET @E_ID = 0
if @inputman_id is null set @inputman_id = 0
/*Params Ini end*/

/*初始化变量*/
DECLARE @SQLScript   VARCHAR(8000)
DECLARE @SQLScript1  VARCHAR(8000)
DECLARE @SQLScript2  VARCHAR(8000)
DECLARE @SQLScript3  VARCHAR(8000)
DECLARE @SQLScript4  VARCHAR(8000)
DECLARE @BankClassID      VARCHAR(300)
DECLARE @BankName         VARCHAR(300)
DECLARE @FieldName        VARCHAR(80) 
DECLARE @FieldNameHead    VARCHAR(30)
DECLARE @FieldNameCounter INT

DECLARE @SQL	     VARCHAR(8000)

SELECT @SQLScript = '',@SQLScript1 = '',@SQLScript2 = '',@SQLScript3 = '',@SQLScript4 = '',@SQL = ''
/*使用银行名字作为字段名，会因为名字中存在非法字符或名字过长出错*/

SELECT @FieldNameHead = 'FIELD_NAME',@FieldNameCounter = 1
SELECT @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
/*游标取得银行帐户和现金的动态Sql*/
DECLARE BankSubject_cursor CURSOR FOR
SELECT  name,class_id
FROM    vw_Account
WHERE 	(class_id Like '000001000004%' or class_id='000002000006' or class_id = '000001000003') and Child_number = 0
ORDER BY [Class_ID] DESC  

OPEN BankSubject_cursor

FETCH NEXT FROM BankSubject_cursor
INTO @BankName,@BankClassID

WHILE @@FETCH_STATUS = 0 
BEGIN
    SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
	SET @BankName = REPLACE(@BankName,' ','')/*去除名字中的空格字符*/
    SET @SQL =@SQL + 'SUM(ISNULL((CASE class_id WHEN '+CHAR(39)+@BankClassID +CHAR(39)+' THEN (jdmoney) ELSE 0 END),0)) AS ['+ @FieldName +'],'
	SET @FieldNameCounter = @FieldNameCounter + 1
	SET @FieldName = @FieldNameHead + CAST(@FieldNameCounter as VARCHAR)
	
	FETCH NEXT FROM BankSubject_cursor
	INTO @BankName,@BankClassID
END

CLOSE BankSubject_cursor
DEALLOCATE BankSubject_cursor 

/*---------------------------------------------------------------*/

set @SQLScript1='select idx.billdate as billdate,     idx.billnumber as billnumber,  idx.billtype as billtype, idx.PosID as posID, idx.billid as billid, idx.inputman as inputman,
				   idx.note as note,  idx.billstates as billstates,
				   (case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -SM.quantity  else SM.quantity  end) as quantity,
				   (case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -SM.CostTotal else SM.CostTotal end) as CostTotal,
				   (case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -SM.SaleTotal else SM.SaleTotal end) as SaleTotal,    
					SM.avgDiscount, 
				   (case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -SM.Totalmoney else SM.Totalmoney end) as Totalmoney,
				   (case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -(SM.SaleTotal-SM.CostTotal) else (SM.SaleTotal-SM.CostTotal) end) as LrTotal,
				   (select [name] from company where Company_ID=idx.Y_id) as PosName,
				   (case when (idx.ysmoney-SM.CostTotal)<>0 and idx.ysmoney<>0 and idx.billtype in (12) then round((idx.ysmoney-SM.CostTotal)/idx.ysmoney*100,4)
						 when (idx.ysmoney-SM.CostTotal)<>0 and idx.ysmoney<>0 and idx.billtype in (13) then round(-(idx.ysmoney-SM.CostTotal)/idx.ysmoney*100,4) else 0 end) as LrRate,
				   ISNULL((case when (idx.billtype in (12) and idx.billstates=4) or(idx.billtype in (13) and idx.billstates<>4) then -ad.jdmoney else ad.jdmoney end),0) as zrTotal, 
				   VI.CardNo,        VI.Name,              VI.Sex,      --VI.Birthday,
				   VI.BulidDate,													 --发卡时间
				   isnull((select name from Company where company_id=VI.Y_ID),'''') as MakeYName,      --发卡机构  
				   intx.totalItg, 
				   VI.Address,       VI.Comment,           (select name from VIPCardType where ct_id=VI.CT_ID) as CardTypeName,
				   VI.IniMoney,      VI.TotalBuyMoney,     VI.SaveMoney,    cast(VI.Integral as NUMERIC(25,8)) as IntergralYE,  VI.RemainderMoney,
				   VI.IniIntergral, VI.Tel
			from billidx idx 
            left join VIPCard VI on idx.Vipcardid=VI.VIPCardID
			left join (	select VIPCardID,SUM(totalItg) as totalItg from Integralidx where billdate between '+CHAR(39)+ @BeginDate +CHAR(39)+' and '+CHAR(39)+@EndDate +CHAR(39)+'
						group by VIPCardID
						) intx on VI.VIPCardID = intx.VIPCardID   --该时间段内的积分汇总            
			   left join 
				 (
				   select bill_id,
						  sum(quantity) as quantity,
						  cast(sum(quantity*costtaxprice) as NUMERIC(25,8)) as CostTotal,
						  sum(case when aoid in (0,5)  then taxtotal else 0 end) as SaleTotal,
						 (case when sum(Totalmoney)<>0 and sum(total)<>0 then round(sum(Totalmoney)/sum(total),4)*100 else 0 end) as avgDisCount,
						  sum(Totalmoney) as Totalmoney  
				   from salemanagebill
				   where p_id>0 and ('+convert(varchar,@PosID)+'=0 or Y_id='+convert(varchar,@PosID)+')
				   group by bill_id
				   )SM 
			  on SM.bill_id=idx.billid  
			left join  
			  (select jdmoney,billid from VW_X_Adetail where AClass_ID like'+CHAR(39)+ '000004000003000004%' +CHAR(39)+') ad on idx.billid=ad.billid
			   
			where ('+convert(varchar,@PosID)+'=0 or idx.Y_id='+convert(varchar,@PosID)+') and idx.billtype in(12,13) and (convert(varchar(10),idx.billdate,120) between '+CHAR(39)+ @BeginDate +CHAR(39)+' and '+CHAR(39)+@EndDate +CHAR(39)+') 
				  and idx.billstates=0 and idx.vipcardid<>0 and (idx.e_id='+convert(varchar,@E_ID)+' or '+convert(varchar,@E_ID)+'=0) and (idx.inputman='+convert(varchar,@inputman_id)+' or '+convert(varchar,@inputman_id)+'=0) and
				 -- idx.order_id<>0  and
				  (VI.ct_id='+convert(varchar,@cardtype)+' or '+convert(varchar,@cardtype)+'=0) and 
				  (idx.Vipcardid='+convert(varchar,@CardID)+' or '+convert(varchar,@CardID)+'=0) ' 
set @SQLScript2	='	union all 
                select VP.billdate,     VP.billnumber,   VP.billtype,  '''' as PosID,   VP.billid, '''' as inputman,
					'''' as note,    ''0'' as billstates,
				   (case when ( VP.billtype in (13)) then -cast(sum(VP.quantity) AS NUMERIC(25,8))  else cast(sum(VP.quantity) as NUMERIC(25,8))  end) as quantity,
				   (case when (VP.billtype in (13))  then -cast(sum(VP.CostTotal) as NUMERIC(25,8)) else cast(sum(VP.CostTotal) as NUMERIC(25,8)) end) as CostTotal,
				   (case when (VP.billtype in (13)) then  -sum(case when aoid in (0,5)  then cast(total as [numeric](18, 4))  else 0 end) else sum(case when aoid in (0,5)  then cast(total as [numeric](18, 4)) else 0 end) end) as SaleTotal,    
					1 as avgDiscount, 
				   (case when (VP.billtype in (13)) then -cast(sum(VP.Quantity*VP.price) As [numeric](18, 4)) else cast(sum(VP.Quantity*VP.price) As [numeric](18, 4)) end) as Totalmoney,
				   (case when (VP.billtype in (13)) then -cast(sum(VP.ysMoney-VP.CostTotal) as [numeric](18, 4)) else cast(sum(VP.ysmoney-VP.CostTotal) as [numeric](18, 4)) end) as LrTotal,
				   (select [name] from company where Company_ID=VP.Y_id) as PosName,
				   (case when sum(VP.ysmoney-VP.CostTotal)<>0 and VP.ysmoney<>0 and VP.billtype in (12) then round(cast(sum(VP.ysmoney-VP.CostTotal)/VP.ysmoney*100 as [numeric](18, 4)),4)
						 when sum(VP.ysmoney-VP.CostTotal)<>0 and VP.ysmoney<>0 and VP.billtype in (13) then round(-cast(sum(VP.ysmoney-VP.CostTotal)/VP.ysmoney*100 as [numeric](18, 4)),4) else 0 end) as LrRate,
				   ISNULL((case when (VP.billtype in (13)) then -ad.jdmoney else ad.jdmoney end),0) as zrTotal, 
				   VI.CardNo,        VI.Name,     VI.Sex,
				   VI.BulidDate,													 --发卡时间
				   isnull((select name from Company where company_id=VI.Y_ID),'''') as MakeYName,      --发卡机构  
				   intx.totalItg, 				       
				   VI.Address,       VI.Comment,   (select name from VIPCardType where ct_id=VI.CT_ID) as CardTypeName,
				   VI.IniMoney,      VI.TotalBuyMoney,   VI.SaveMoney,   cast(VI.Integral as NUMERIC(25,8)) as IntergralYE,  VI.RemainderMoney,
				   VI.IniIntergral, VI.Tel
			from VipDetail VP '
set @SQLScript3	= 'inner join  VIPCard VI on VP.cardid=VI.VIPCardID
			left join (	select VIPCardID,SUM(totalItg) as totalItg from Integralidx where billdate between  '+CHAR(39)+ @BeginDate +CHAR(39)+' and '+CHAR(39)+@EndDate +CHAR(39)+'
						group by VIPCardID
						) intx on VI.VIPCardID = intx.VIPCardID   --该时间段内的积分汇总
			left join 
			  (select jdmoney,billid from VW_X_Adetail where AClass_ID like '+CHAR(39)+ '000004000003000004%'+CHAR(39)+') ad on VP.billid=ad.billid
			where ('+convert(varchar,@PosID)+'=0 or VP.Y_id='+convert(varchar,@PosID)+') and VP.billtype in(12,13) and (convert(varchar(10),VP.billdate,120) between '+CHAR(39)+ @BeginDate+CHAR(39)+' and '+CHAR(39)+ @EndDate +CHAR(39)+') 
				   and VP.cardid<>0 and (VP.e_id='+convert(varchar,@E_ID)+' or '+convert(varchar,@E_ID)+'=0)and
				  (VI.ct_id='+convert(varchar,@cardtype)+' or '+convert(varchar,@cardtype)+'=0) and 
				  (VP.cardid='+convert(varchar,@CardID)+' or '+convert(varchar,@CardID)+'=0) 
			 Group by   VP.billdate, VP.billnumber,VP.billtype,VP.billid,VP.ysMoney,VP.Y_ID,ad.jdmoney,VI.CardNo,
			   VI.Name,VI.sex, VI.BulidDate,VI.Y_ID,intx.totalItg,VI.Integral,VI.Address,  VI.Comment, VI.IniMoney,      VI.TotalBuyMoney,     VI.SaveMoney,   
				VI.IntergralYE,  VI.RemainderMoney,  VI.IniIntergral,VI.CT_ID, VI.Tel'
				
set @SQLScript4 = ' BILLID AS MYBILLID FROM
	(
	   select ad.billid,a_id,at.class_id,at.name,jdmoney from 
	     (
	        select * from accountdetail where exists(select 1 from billidx where billstates = 0 and billtype in (12,13))
	     ) ad,  
	    (
	        SELECT  account_id,name,class_id FROM    Account
	         WHERE (class_id Like '+CHAR(39)+'000001000004%'+CHAR(39)+'or class_id='+CHAR(39)+'000002000006'+CHAR(39)+'or class_id = '+CHAR(39)+'000001000003'+CHAR(39)+') 
	         and Child_number = 0
	     ) at 
	  where ad.a_id= at.account_id) AD group by billid '
/*print @SQLScript1*/
/*print @SQLScript2*/
/*print @SQLScript3*/
/*print @SQLScript4*/
exec ('select M.*,BK.* from ('+@SQLScript1 + @SQLScript2 + @SQLScript3 + ') M LEFT JOIN '+'(SELECT '+@SQL +@SQLScript4 +')Bk on bk.MYBILLID=M.billid')
GO
