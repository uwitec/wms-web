

CREATE VIEW dbo.vw_c_Ybilldraftidx
AS
SELECT dbo.Ybilldraftidx.*, 
      isnull(clients.[name], '') as cname,
      isnull(clients.address,'') as cAddress,
      isnull(clients.contact_personal, '') as cContact_personal,
      isnull(clients.phone_Number, '') as cPhone_Number,
      isnull(clients.class_id, '')cclass_id,
      isnull(clients.serial_number, '')Cnumber, 
      ISNULL(dbo.account.name, '') AS aname, ISNULL(dbo.employees.name, '') AS ename, 
      ISNULL(dbo.account.class_id, '') AS aclass_id,  ISNULL(dbo.employees.class_id, '') AS eclass_id, 
      ISNULL(emp.class_id, '') AS inputmanclass_id, ISNULL(emp.name, '') 
      AS inputmanname, ISNULL(empa.name, '') AS auditmanname, ISNULL(empa.class_id, 
      '') AS auditmanclass_id, ISNULL(dep.name, '') AS departmentname, ISNULL(reg.name, 
      '') AS regionname, ISNULL(ss.name, '') AS ssname, ISNULL(sd.name, '') 
      AS sdname,
      isnull(ss.class_id,'') as ssclass_id,
      isnull(sd.class_id,'') as sdclass_id,
      ISNULL(empg.name, '') AS GatheringManName, ISNULL(empg.class_id, '') AS GatheringManclass_id,
      ISNULL(Y.Class_ID,'') as YClass_ID,ISNULL(Y.[name],'') as Yname,
      isnull((case when Ybilldraftidx.billtype in (150,151,155,160,161,165) then CY.Class_ID else '' end),'') as CYClass_ID

FROM dbo.Ybilldraftidx LEFT OUTER JOIN
      dbo.account ON dbo.Ybilldraftidx.a_id = dbo.account.account_id LEFT OUTER JOIN
      dbo.clients ON dbo.Ybilldraftidx.c_id = dbo.clients.client_id LEFT OUTER JOIN
      dbo.employees ON dbo.Ybilldraftidx.e_id = dbo.employees.emp_id LEFT OUTER JOIN
      dbo.employees emp ON dbo.Ybilldraftidx.inputman = emp.emp_id LEFT OUTER JOIN
      dbo.employees empa ON 
      dbo.Ybilldraftidx.auditman = empa.emp_id LEFT OUTER JOIN
      dbo.employees empg ON dbo.Ybilldraftidx.GatheringMan = empg.emp_id LEFT OUTER JOIN
      dbo.department dep ON 
      dbo.Ybilldraftidx.department_id = dep.departmentId LEFT OUTER JOIN
      dbo.Region reg ON dbo.Ybilldraftidx.region_id = reg.region_id LEFT OUTER JOIN
      dbo.storages ss ON dbo.Ybilldraftidx.sout_id = ss.storage_id LEFT OUTER JOIN
      dbo.storages sd ON dbo.Ybilldraftidx.sin_id = sd.storage_id LEFT OUTER JOIN
      dbo.Company  Y  on dbo.Ybilldraftidx.Y_id = Y.company_id   LEFT OUTER JOIN 
          Company  CY  on dbo.Ybilldraftidx.C_id=CY.company_id
GO
