CREATE PROCEDURE Ts_C_GetCategoryBaseInfo  
(
  @nMode INT,
  @TypeRange  VARCHAR(8000)
)
AS 
BEGIN 
    DECLARE @CColName VARCHAR(100)
    DECLARE @info_ID INT
    DECLARE @classid VARCHAR(8000)
    DECLARE @szSql VARCHAR(8000)
    SET @CColName = ''
    SELECT @info_ID = Category_id FROM customCategory WHERE ID  IN (SELECT  type  FROM DecodeStr(@TypeRange))
    SELECT @classid = dbo.GetCateClassids(@TypeRange)

    IF @classid IS NULL 
       SET @classid = ''
    
    IF LEN(@classid) > 0 
       SET @classid = LEFT(@classid,LEN(@classid)-1)
 
    IF @nMode = 1
      BEGIN
      IF @TypeRange = ''
        SELECT company_id AS y_id,name FROM company m  WHERE (class_id <> '000000') AND company_id IN (SELECT Y_ID FROM storehouse GROUP BY Y_ID)      
      ELSE
      BEGIN   
        SET @CColName = dbo.GetColName(@info_ID,'CompanyCategory')
       
        SET @szSql = ' select c.company_id AS y_id,name from company c,CompanyCategory yc where c.company_id = yc.Y_id and yc.' + @CColName  
		           + ' in (select type  from DecodeStr(''' +@classid +'''))'  
	    EXEC (@szSql)        
      END
    END
END
GO
