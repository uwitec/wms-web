
CREATE	       PROCEDURE Ts_J_ReWriteCatalog
(
	@begindate  datetime,   
	@enddate    datetime,
	@BillType   INT,        	
	@c_id       int,        /*是否选择往来单位*/
  	@E_ID       int,		/*生成入库单人员*/
	@p_id       int,		/*商品id*/
	@Qty        numeric(25,8) /*入库数量		*/
)
/*with encryption*/
AS
	DECLARE @Bill VARCHAR(50), @nOOSid int, @OOSQty numeric(25,8), @PlanQty numeric(25,8), @sumQty numeric(25,8)
	SET @Bill = ''
	IF @BillType = 20 
	    SET @Bill = '已生成过采购入库单草稿；'
	IF @BillType = 26
		SET @Bill = '已生成过采购计划；'  
	IF @BillType = 22
		SET @Bill = '已生成过采购订单；' 
	IF @BillType = 10
		SET @Bill = '已生成过销售出库单草稿；'  
	IF @BillType = 152
		SET @Bill = '已生成过自营店发货单草稿；'  
	IF @BillType = 150
		SET @Bill = '已生成过机构发货单草稿；'  	
	IF @BillType = 52
		SET @Bill = '已生成过机构请货单；' 
				 	
	DECLARE @Remark VARCHAR(300)
	
	set @sumQty = @Qty
			
    declare UpdateOOSCur cursor for
	   select OOSID, OOSQty, planqty  from OOSCatalog 
	    where productid = @p_id and cast(convert(varchar(10), InputDate, 21) as datetime) 
	          between @begindate and @enddate and planQty < OOSQty and InDisposeflag in (0, 1, 2)
	          and (@c_id = 0 or clientid = @c_id)         
	open UpdateOOSCur
	
	fetch next from UpdateOOSCur into @nOOSid, @OOSQty, @PlanQty
	while @@FETCH_STATUS=0	
	begin
	  IF (@BillType IN (20, 22, 26,52)) and (@sumQty > 0)
	  begin
	    /*更新备注  */
	    SELECT @Remark = ISNULL(o.Remark, '') FROM OOSCatalog o WHERE o.OOSId = @nOOSid	
	    SET @Remark = REPLACE(@Remark, @Bill, '')
	    SET @Remark = @Remark + @Bill
	     	  	  
	    if (@OOSQty-@PlanQty) >=  @sumQty 
	    begin	      
	      UPDATE OOSCatalog SET PlanQty = @sumQty + PlanQty, Remark = @Remark, Inflag = 1, InDisposeflag = 1, InDisposeMan = @E_ID, InDisposeDate = GETDATE() WHERE OOSId = @nOOSid
	      set @sumQty = 0      
	    end	    	      
	    else begin	    
		  UPDATE OOSCatalog SET PlanQty = (@OOSQty-@PlanQty) + PlanQty, Remark = @Remark, Inflag = 1, InDisposeflag = 1, InDisposeMan = @E_ID, InDisposeDate = GETDATE() WHERE OOSId = @nOOSid
		  set @sumQty = @sumQty - (@OOSQty-@PlanQty)
		end		
	  end		  	  			  		      	      	      	      	      	    	            	              	   	  		  	   
	  fetch next from UpdateOOSCur into @nOOSid, @OOSQty, @PlanQty
	end	
	close UpdateOOSCur
	deallocate UpdateOOSCur
	
return 0
GO
