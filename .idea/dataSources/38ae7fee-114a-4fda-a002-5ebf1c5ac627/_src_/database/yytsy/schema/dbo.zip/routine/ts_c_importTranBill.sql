

/* 在修改分公司中,posid 代表的是Y_ID*/
create proc ts_c_importTranBill
/*with encryption*/
as
set nocount on
/*变量定义*/
declare @nBillType smallint /*单据类型*/
declare @nBillid int,@nnewbillid int/*单据id,*/
declare @PosGuid varchar(50),@nPosid int,@nC_id int
declare @nGuid uniqueidentifier
/*变量定义end*/

set @nPosid=0

begin tran 
	declare tranidxDtscur cursor for
	select billid,billtype,guid,posguid from tranidxdts
	open tranidxDtscur
	
	fetch next from tranidxDtscur into @nBillid,@nBillType,@nGuid,@PosGuid
	while @@FETCH_STATUS=0	
	begin
		if exists(select guid from tranidx where guid=@nguid)
		begin
			fetch next from tranidxDtscur into @nBillid,@nBillType,@nGuid,@PosGuid
		end else
		begin
			select @nPosid=posid from ReplicationAuthorize where guid=@PosGuid
		
			/*机构请货单*/
			if @nBilltype in (52) 
			begin     
				insert into Tranidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,
				businesstype,guid,araptotal,SendQty, GatheringMan, Y_ID) 
	
				select billdate, billnumber, billtype, a_id, C_id, 1, sout_id, sin_id, 0, 1, 
				ysmoney, ssmoney, quantity, taxrate, period, 2, order_id, department_id, 
				@nPosid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,
				businesstype,guid,araptotal,SendQty, GatheringMan, Y_ID
				from tranidxdts where billid=@nbillid
	
				select @nnewbillid=@@identity
				
				insert into tranbill(bill_id, p_id, quantity,retailprice, retailmoney,comment,unitid,rowguid,Y_ID)
				select @nnewbillid, p_id, quantity,retailprice, retailmoney,comment,unitid,rowguid,y_id
				from tranbilldts
				where bill_id=@nbillid	
				order by smb_id
			end
			fetch next from tranidxDtscur into @nBillid,@nBillType,@nGuid,@PosGuid
		end
	end	
	close tranidxDtscur
	deallocate tranidxDtscur
commit tran 
return 0
GO
