
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2013-04-08*/
/* Description:	拣货单流程控制       */
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_Y_jhprocedure]
(
  @billid   int,
  @billst   int,  
  @WholeQty int,
  @PartQty  int,
  @shr      int,
  @locID    int=0,
  @locname  varchar(100)=''  ,
  @lhQty int=0
  
)
AS
BEGIN
declare @prcount int 
declare @nSaleBillId int
set @prcount=(select BusinessType from  billdraftidx where billid=@billid)
  /*-修改数据*/
  if @billst=2   /*拣货成功*/
  begin
    if @prcount=0 
    begin
     update  billdraftidx  set VIPCardID=5,integral=@shr,BusinessType=BusinessType+1,note = note + ' '+@locname where billid=@billid     
    end
    if @prcount>=1
    begin
     update  billdraftidx  set BusinessType=BusinessType+1,integral=@shr , note = note + ' '+@locname where billid=@billid      
    end 
  end
  if @billst=5  /*复核完成*/
  begin
	select @nSaleBillId = saleBillId from JHBillInfo where jhBillId = @billid
    update  billdraftidx  set VIPCardID=6,WholeQty=@WholeQty,InvoiceTotal=@PartQty,integralYE=@shr,summary=@lhQty where billid=@billid 
    /*--写入发货货位*/
    update billdraftidx set B_CustomName1=CONVERT(varchar(20),@locID),B_CustomName2=@locname
    where billtype=254 and order_id=(select order_id from billdraftidx where billid=@billid)
    and B_CustomName1=''
	/* 写入复核表*/
	insert into checkidx (checkdate, checkman, billid, AuditMan, casedman, IsDraft) values(getdate(), @shr, @billid, 0, 0, 1)
	/* 更新拣货信息表*/
	/* 当前单据数量*/
	update JHBillInfo set loc_id = @locID, loc_name = @locname where saleBillId = @nSaleBillId
	update JHBillInfo set wholeQty = @WholeQty - @PartQty, partQty = @PartQty, packedQty = @lhQty where jhBillId = @billid
	/* 销售出库单合计数量*/
	update JHBillInfo set totalQty = x.qty
	from
	(select sum(wholeQty) + SUM(partQty) + SUM(packedQty) AS qty, saleBillId from JHBillInfo where saleBillId = @nSaleBillId group by saleBillId) x
	where JHBillInfo.saleBillId = x.saleBillId
	/* 装箱起始计数*/
	declare @nStNum int
	select @nStNum = MAX(startnum) from JHBillInfo where saleBillId = @nSaleBillId
	if @nStNum = 0
		set @nStNum = 1
	else
		select @nStNum = @nStNum + wholeQty + partQty + packedQty from JHBillInfo where startNum = @nStNum and saleBillId = @nSaleBillId
	update JHBillInfo set startNum = @nStNum where jhBillId = @billid
  end
  if @billst=12   /*拣货退货*/
  begin
    update  billdraftidx  set VIPCardID=1,integral=0 where billid=@billid     
  end
  if @billst=15  /*复核退货*/
  begin
    update  billdraftidx  set VIPCardID=2,integral=0 where billid=@billid
	delete from checkidx where billid = @billid and IsDraft = 1
  end
  else
  if @billst = 20 /* 获取拣货单信息*/
  begin
	select VIPCardID,WholeQty,InvoiceTotal, isnull(x.loc_id, '') as B_CustomName1, isnull(x.loc_name, '') as B_CustomName2, summary
	from billdraftidx 
	left join
	(SELECT   loc_id, loc_name, @billid AS jhBillId
		FROM      dbo.location
		WHERE   (loc_id =
			(SELECT   MIN(loc_id) AS Expr1
				FROM      dbo.JHBillInfo
				WHERE   
				/*(jhBillId IN*/
				/*	(SELECT   billid*/
				/*	FROM      dbo.billdraftidx*/
				/*	WHERE   (c_id IN*/
				/*		(SELECT   c_id*/
				/*		FROM      dbo.billdraftidx AS billdraftidx_1*/
				/*		WHERE   (billid = @billid))) AND (billtype = 254))) */
				EXISTS(SELECT 1 FROM  billdraftidx where jhBillId = billid and billtype = 254 and billid = @billid)
						AND (saleBillGuid NOT IN
							(SELECT guid from billidx where billid in
							(SELECT   billid
							FROM      dbo.Sendmangebill))
						) AND (loc_id > 0)))
	) x
	on billid = x.jhBillId
	where billid = @billid

  end
END
GO
