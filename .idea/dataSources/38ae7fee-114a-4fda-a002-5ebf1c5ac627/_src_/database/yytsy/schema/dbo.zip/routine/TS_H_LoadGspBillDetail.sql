
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-4*/
/* Description:	读取Gsp单据明细表*/
/* =============================================*/
CREATE PROCEDURE TS_H_LoadGspBillDetail 
	@billtype int = 0,	/* 单据类型*/
	@billid int = 0,	/* 单据编号*/
	@nRet int output	/* 返回值*/
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @bPubIsFollowProductLoc INT
	SET @bPubIsFollowProductLoc = 0
	select @bPubIsFollowProductLoc = sysvalue from sysconfig where sysname = 'IsFollowProductLoc' AND Y_ID = 2
  
    /* 直调采购单读取直调订单*/
	if @billtype in (108)
	begin
		SELECT  '' AS checkaccept, p.alias, 0 AS aoid, '' AS AOIDNAME, 0 AS applicantqty, p.makearea AS AREA, '' AS BatchBarCode, 
                '' AS Batchcomment, 0 AS batchprice, '' AS returnreason, 0 AS BASEQTY, b.batchno, b.supplier_id, p.BulidNo, 0 AS thqty, 
                0 AS cansaleqty, '' AS checkreason, 0 AS checkqty, '正常' AS checkstate, p.code, p.Iscold, 0 AS commisionflag, 
                0 AS costprice, 0 AS COSTTOTAL, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                p.Custompro5, b.discount, 0 AS discountprice, 0 AS discounttotal, 
                0 AS EID, 0 AS sfdacounts, 
                f.AccountComment as Factory, '' AS uneligibletransactor, 0 AS uneligibleqty, '' AS uneligiblereason, '1900-1-1' AS instoretime, 0 AS IOTAG, 
                b.ss_id AS s_id, b.location_id, ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, 
                p.medtype AS MEDTYPEID, b.comment, b.comment2, p.name, b.bill_id AS ORDERID, (b.quantity - b.comeqty) AS Yqty, 
                b.total / b.quantity AS Ytaxprice, b.smb_id AS orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                0 AS pickqty, b.p_id, 0 AS price, b.qualitystatus, p.rate2, p.rate3, p.rate4, (b.quantity - b.comeqty) AS inceptqty, '收货' AS inceptstate, 
                0 AS refuseqty, '' AS refusereason, p.RegisterNo, 0 AS REMAINING, '' AS checkreport, 0 AS sampleqty, 0 AS SMBID, 
                cast(p.Isspec as Int) as Isspec, p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, 0 AS eligibleqty, 
                0AS taxmoney, 0 AS taxprice, 0 AS pricediscrepancy, 0 AS total, p.trademark, 
                p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, 
                p.Unit3Name, p.unit4_id AS UNIT4ID, p.Unit4Name, p.unit1_id AS unit_id, b.validdate, b.supplier_id AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, 
                p.WholeRate, b.RowGuid AS Yrowguid, b.Y_ID,b.taxrate, 0 AS taxtotal, 
                p.validmonth, p.validday, p.StoreCondition AS DID,b.factoryid ,b.costtaxprice,b.costtaxrate,b.costtaxtotal,
				0 as oldorderqty,'' as oldorderunit,0 as OldOrderUnitid,0  as  OldOrderUnitrate ,0 as WholeQty,0 as PartQty  
		FROM      dbo.OrderBill AS b INNER JOIN
                dbo.vw_Products AS p ON b.p_id = p.product_id LEFT OUTER JOIN
                dbo.location AS l ON b.location_id = l.loc_id LEFT OUTER JOIN
                basefactory f on b.factoryid=f.CommID      LEFT OUTER JOIN
                dbo.storages AS s ON b.ss_id = s.storage_id WHERE bill_id = @billid AND b.quantity > b.ComeQty
		ORDER BY B.SMB_ID
	end
	ELSE
	/* 采购收货单读取采购订单*/
	if @billtype in (22)
	begin
		SELECT  '' AS checkaccept, p.alias, b.AOID AS aoid, '' AS AOIDNAME, 0 AS applicantqty, p.makearea AS AREA, '' AS BatchBarCode, 
                '' AS Batchcomment, 0 AS batchprice, '' AS returnreason, 0 AS BASEQTY, b.batchno, b.supplier_id, p.BulidNo, 0 AS thqty, 
                0 AS cansaleqty, '' AS checkreason, 0 AS checkqty, '正常' AS checkstate, p.code, p.Iscold, 0 AS commisionflag, 
                b.costprice, b.costprice * (b.quantity - b.comeqty) AS COSTTOTAL, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                p.Custompro5, b.discount, b.discountprice as discountprice, /*(b.saleprice * b.discount) AS discountprice, */
                b.totalmoney*((b.quantity - b.ComeQty)/b.quantity) AS discounttotal, 
                0 AS EID, 0 AS sfdacounts, 
                q.AccountComment as Factory, '' AS uneligibletransactor, 0 AS uneligibleqty, '' AS uneligiblereason, '1900-1-1' AS instoretime, 0 AS IOTAG, 
                case when @bPubIsFollowProductLoc = 1 AND p.locationid > 0 then isnull((select s_id from location where loc_id = p.locationid),0) else b.ss_id end  AS s_id,
                case when @bPubIsFollowProductLoc = 1 AND p.locationid > 0 then p.locationid else b.location_id end  AS location_id, 
                '' AS LOCATION, b.makedate, p.MedName AS medtype, 
                p.medtype AS MEDTYPEID, dbo.GetProductComment(b.p_id, b.quantity - b.ComeQty) as comment, b.comment2, p.name, b.bill_id AS ORDERID, (b.quantity - b.comeqty) AS Yqty, 
                /*CAST(b.taxtotal / b.quantity AS DECIMAL(18, 4)) AS  --XXX 这儿不重算 bug41063 */ taxprice as Ytaxprice, b.smb_id AS orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                0 AS pickqty, b.p_id, 
                /*(b.total / b.quantity) AS price, */
                 b.costprice as price,
                 b.qualitystatus, p.rate2, p.rate3, p.rate4, 0 AS inceptqty, '收货' AS inceptstate, 
                0 AS refuseqty, '' AS refusereason, p.RegisterNo, 0 AS REMAINING, '' AS checkreport, 0 AS sampleqty, 0 AS SMBID, 
                cast(p.Isspec as Int) as Isspec, p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, 0 AS eligibleqty, 
                b.taxmoney, /*CAST(b.taxtotal / b.quantity AS DECIMAL(18, 4)) AS  --XXX 这儿不重算 bug41063 */ taxprice, 0 AS pricediscrepancy, b.total*((b.quantity - b.ComeQty)/b.quantity) AS total, p.trademark, 
                p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, 
                p.Unit3Name, p.unit4_id AS UNIT4ID, p.Unit4Name, p.unit1_id AS unit_id, b.validdate, b.supplier_id AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, 
                p.WholeRate, b.RowGuid AS Yrowguid, b.Y_ID,b.taxrate, b.taxtotal*((b.quantity - b.ComeQty)/b.quantity) AS taxtotal, 
                p.validmonth, p.validday, p.StoreCondition AS DID,b.FactoryId as Factoryid,b.costtaxrate,b.costtaxprice,b.costtaxtotal,
				0 as oldorderqty,'' as oldorderunit,0 as OldOrderUnitid,0  as  OldOrderUnitrate ,0 as WholeQty,0 as PartQty  
		FROM      dbo.OrderBill AS b INNER JOIN
                FilterProduct(2) AS p ON b.p_id = p.product_id LEFT OUTER JOIN
                dbo.location AS l ON b.location_id = l.loc_id LEFT OUTER JOIN
                basefactory  q on b.FactoryId=q.CommID  left outer join 
                dbo.storages AS s ON b.ss_id = s.storage_id WHERE bill_id = @billid AND b.quantity > b.ComeQty
		ORDER BY B.SMB_ID
	end
	ELSE 
	if @billtype in (20, 160, 162)  /*采购退货申请单调采购单/机构退货申请单调机构收货单、自营店收货单*/
	begin
		DECLARE @sPids VARCHAR(8000)
		DECLARE @nPid INT

		SET @sPids = ' '
		SELECT DISTINCT p_id INTO #TMPP
		FROM buymanagebill WHERE bill_id = @billid

		DECLARE CURP CURSOR FOR
		SELECT p_id FROM #TMPP
		OPEN CURP
		FETCH NEXT FROM CURP INTO @nPid
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @sPids = @sPids + CAST(@nPid AS VARCHAR(10)) + ','
			FETCH NEXT FROM CURP INTO @nPid
		END
		CLOSE CURP
		DEALLOCATE CURP
/*		PRINT LEN(@sPids)*/
		IF LEN(@sPids) BETWEEN 2 AND 4000
		BEGIN
			SET @sPids = SUBSTRING(@sPids, 1, LEN(@sPids) - 1)
			SET @nPid = 0
		END
		ELSE
		IF LEN(@sPids) <= 1
		BEGIN
			SET @sPids = ''
			SET @nPid = -10
		END
		ELSE
		BEGIN
			SET @sPids = ''
			SET @nPid = 0
		END
		DROP TABLE #TMPP
		SELECT     '' AS checkaccept, p.alias, b.AOID AS aoid, '' AS AOIDNAME, CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS applicantqty, p.makearea AS AREA, b.BatchBarCode, 
                b.scomment as Batchcomment, b.batchprice, '' AS returnreason, CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS BASEQTY, b.batchno, b.supplier_id, p.BulidNo, CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS thqty, 
                CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END as cansaleqty, '' AS checkreason, 0 AS checkqty, '正常' AS checkstate, p.code, p.Iscold, b.commissionflag as commisionflag, 
                b.costprice, b.costprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS COSTTOTAL, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                p.Custompro5, b.discount, b.discountprice, b.discountprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS discounttotal, b.RowE_id as EID, 0 AS sfdacounts, 
                q.AccountComment as  Factory, '' AS uneligibletransactor, 0 AS uneligibleqty, '' AS uneligiblereason, b.instoretime, b.iotag, 
                b.ss_id AS s_id, b.location_id, ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, 
                p.medtype AS MEDTYPEID, p.comment, b.comment2, p.name, b.bill_id AS ORDERID, b.quantity AS Yqty, 
                b.newprice AS Ytaxprice, b.smb_id AS orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                0 AS pickqty, b.p_id, b.costprice AS price, b.qualitystatus, p.rate2, p.rate3, p.rate4, 0 AS inceptqty, '' AS inceptstate, 
                0 AS refuseqty, '' AS refusereason, p.RegisterNo, 0 AS REMAINING, '' AS checkreport, 0 AS sampleqty, 0 AS SMBID, 
                cast(p.Isspec as Int) as Isspec, p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, 0 AS eligibleqty, 
                b.taxmoney, b.newprice AS taxprice, 0 AS pricediscrepancy, b.buyprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS total, p.trademark, 
                p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, 
                p.Unit3Name, p.unit4_id AS UNIT4ID, p.Unit4Name, p.unit1_id AS unit_id, b.validdate,  ISNULL(c.name, '') AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, 
                p.WholeRate, b.RowGuid AS Yrowguid, b.Y_ID, b.discountprice, b.taxrate, b.taxtotal, p.validmonth, p.validday,p.StoreCondition AS DID,b.FactoryId as Factoryid,
                b.costtaxprice,b.costtaxrate,b.costtaxtotal,
				0 as oldorderqty,'' as oldorderunit,0 as OldOrderUnitid,0  as  OldOrderUnitrate ,0 as WholeQty,0 as PartQty   
		FROM    dbo.buymanagebill AS b INNER JOIN dbo.vw_Products AS p ON b.p_id = p.product_id 
		                               LEFT OUTER JOIN dbo.location AS l ON b.location_id = l.loc_id 
		                               LEFT OUTER JOIN dbo.storages AS s ON b.ss_id = s.storage_id
		                               left join   basefactory  q on b.FactoryId=q.CommID   
		                               LEFT OUTER JOIN clients as c on c.client_id=b.supplier_id
		                               LEFT OUTER JOIN dbo.FN_GetAvlqty(@nPid, 0, @sPids, 0) f ON b.Y_ID = f.Y_ID AND b.ss_id = f.s_id AND 
		                                                                       b.location_id = f.location_id AND b.p_id = f.p_id AND 
		                                                                       b.supplier_id = f.supplier_id AND b.batchno = f.batchno AND 
		                                                                       b.makedate = f.makedate AND b.validdate = f.validdate AND
		                                                                       b.instoretime = f.instoretime AND b.commissionflag = f.commissionflag AND
		                                                                       b.costprice = f.costprice
		                               
		                                                                         
		WHERE bill_id = @billid AND B.thqty > 0
		ORDER BY B.SMB_ID
	
	end
	else if @billtype = 10  /*销售退货申请单调销售单*/
	begin
	  SELECT   '' AS checkaccept, p.alias, b.AOID AS aoid, '' AS AOIDNAME, b.thqty AS applicantqty, p.makearea AS AREA, b.BatchBarCode, 
                b.scomment as Batchcomment, b.batchprice, '' AS returnreason, b.quantity AS BASEQTY, b.batchno, b.supplier_id, p.BulidNo, b.thqty, 
                b.quantity as cansaleqty, '' AS checkreason, 0 AS checkqty, '正常' AS checkstate, p.code, p.Iscold, b.commissionflag as commisionflag, 
                b.costprice, b.costprice * b.quantity AS COSTTOTAL, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                p.Custompro5, b.discount, b.discountprice, b.totalmoney AS discounttotal, b.RowE_id as EID, 0 AS sfdacounts, 
                f.AccountComment as Factory, '' AS uneligibletransactor, 0 AS uneligibleqty, '' AS uneligiblereason, b.instoretime, b.iotag, 
                b.ss_id AS s_id, b.location_id, ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, 
                p.medtype AS MEDTYPEID, p.comment, b.comment2, p.name, b.bill_id AS ORDERID, b.quantity AS Yqty, 
                b.newprice AS Ytaxprice, b.smb_id AS orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                0 AS pickqty, b.p_id, b.saleprice AS price, b.qualitystatus, p.rate2, p.rate3, p.rate4, 0 AS inceptqty, '' AS inceptstate, 
                0 AS refuseqty, '' AS refusereason, p.RegisterNo, 0 AS REMAINING, '' AS checkreport, 0 AS sampleqty, 0 AS SMBID, 
                cast(p.Isspec as Int) as Isspec, p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, 0 AS eligibleqty, 
                b.taxmoney, b.newprice AS taxPrice, 0 AS pricediscrepancy, b.total, p.trademark, 
                p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, 
                p.Unit3Name, p.unit4_id AS UNIT4ID, p.Unit4Name, p.unit1_id AS unit_id, b.validdate,  ISNULL(c.name, '') AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, 
                p.WholeRate, b.RowGuid AS Yrowguid, b.Y_ID, b.discountprice, b.taxrate, b.taxtotal, p.validmonth, p.validday, p.StoreCondition AS DID,
                b.factoryid,b.costtaxprice,b.costtaxrate,b.costtaxtotal,
				0 as oldorderqty,'' as oldorderunit,0 as OldOrderUnitid,0  as  OldOrderUnitrate ,0 as WholeQty,0 as PartQty   
		FROM      dbo.salemanagebill AS b INNER JOIN
                dbo.vw_Products AS p ON b.p_id = p.product_id LEFT OUTER JOIN
                dbo.location AS l ON b.location_id = l.loc_id LEFT OUTER JOIN
                dbo.storages AS s ON b.ss_id = s.storage_id 
                LEFT OUTER JOIN clients as c on c.client_id=b.supplier_id
                left join basefactory f on b.factoryid=f.CommID
		WHERE bill_id = @billid AND B.thqty > 0
		ORDER BY B.SMB_ID
	end
	else
	/* 开启同价调拨单不自动过账后的拣货单单独处理*/
	/* 使用sampleqty保存草稿中数量*/
	if @billtype = 541 and not exists(select * from sysconfigtmp where sysname = 'WholeSplitAutoAudit' and sysvalue = '1')
	begin
		SELECT  b.checkaccept, p.alias, b.aoid, '' AS AOIDNAME, b.applicantqty, p.makearea AS AREA, b.BatchBarCode, b.Batchcomment, 
                b.batchprice, b.returnreason, b.batchno, b.supplier_id, p.BulidNo, b.thqty, b.cansaleqty, b.checkreason, 
                b.checkqty, b.checkstate, p.code, b.Iscold, b.commisionflag, b.COSTPRICE, b.COSTTOTAL, p.Custompro1, p.Custompro2, 
                p.Custompro3, p.Custompro4, p.Custompro5, b.discount, b.DiscountPrice, b.discounttotal, 0 AS EID, b.sfdacounts, 
                f.AccountComment as Factory, b.uneligibletransactor, b.uneligibleqty, b.uneligiblereason, b.instoretime, 0 AS IOTAG, b.s_id, b.location_id, 
                ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, p.medtype AS MEDTYPEID, b.comment, b.comment2, 
                p.name, 0 AS ORDERID, b.Yqty, b.Ytaxprice, b.orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                b.pickqty, b.p_id, b.price, isnull(b.qualitystatus,'') AS QUALITYSTATUS, p.rate2, p.rate3, p.rate4, b.inceptqty, 
                CASE ISNULL(b.inceptstate, 0) WHEN 0 THEN '收货' ELSE '拒收' END AS inceptstate, b.refuseqty, 
                b.refusereason, p.RegisterNo, 0 AS REMAINING, b.checkreport, ISNULL(t.quantity, 0) as sampleqty, b.Gspsmb_id AS SMBID, b.Isspec, 
                p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, b.eligibleqty, b.taxmoney, 
                b.taxprice, b.pricediscrepancy, b.TaxRate, b.TaxTotal, b.total, p.trademark, p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, 
                p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, p.Unit3Name, p.unit4_id AS UNIT4ID, 
                p.Unit4Name, p.unit1_id AS unit_id, b.validdate, ISNULL(c.name, '') AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, p.WholeRate, b.Yrowguid, b.y_id,
				p.validmonth, p.validday, p.StoreCondition AS DID,
				CASE WHEN g.BillType IN (521, 522, 523, 524) THEN b.EligibleQty ELSE 0 END AS BASEQTY ,b.factoryid,b.costtaxprice,b.costtaxrate,
				b.costtaxtotal,b.oldorderqty as oldorderqty,b.oldorderunit as oldorderunit,b.OldOrderUnitid as OldOrderUnitid,b.OldOrderUnitrate  as  OldOrderUnitrate , 
				b.WMS_WholeQty as WholeQty,b.WMS_PartQty as PartQty 
		FROM    dbo.GSPbilldetail AS b INNER JOIN
		        dbo.GSPbillidx AS g ON b.Gspbill_id = g.Gspbillid INNER JOIN
                dbo.vw_Products AS p ON b.p_id = p.product_id LEFT JOIN
                dbo.storages AS s ON b.s_id = s.storage_id LEFT OUTER JOIN
                dbo.clients AS c ON b.Supplier_id = c.client_id LEFT OUTER JOIN
                dbo.location AS l ON b.location_id = l.loc_id LEFT OUTER JOIN
                basefactory f on b.factoryid=f.CommID      LEFT OUTER JOIN
				(SELECT   p_id, batchno, SUM(quantity) AS quantity, costprice, makedate, validdate, sd_id, supplier_id, commissionflag, 
					location_id2, Y_ID, instoretime
				FROM      dbo.storemanagebilldrf
				WHERE   (bill_id IN
					(SELECT   billid
					FROM      dbo.billdraftidx
					WHERE   (billtype = 44)))
				GROUP BY p_id, batchno, costprice, makedate, validdate, sd_id, supplier_id, commissionflag, location_id2, Y_ID, instoretime) t
				on b.P_id = t.p_id and b.Batchno = t.batchno and b.CostPrice = t.costprice and b.S_id = t.sd_id and b.Location_id = t.location_id2
				and b.Y_id = t.Y_ID and b.InstoreTime = t.instoretime and b.MakeDate = t.makedate and b.Validdate = t.validdate and b.CommisionFlag = t.commissionflag
				and b.Supplier_id = t.supplier_id
				WHERE GSPBILL_ID = @billid
		ORDER BY B.Gspsmb_id
	end
	else
	BEGIN
		SELECT   b.checkaccept, p.alias, b.aoid, '' AS AOIDNAME, b.applicantqty, p.makearea AS AREA, b.BatchBarCode, b.Batchcomment, 
                b.batchprice, b.returnreason, b.batchno, b.supplier_id, p.BulidNo, b.thqty, b.cansaleqty, b.checkreason, 
                b.checkqty, b.checkstate, p.code, b.Iscold, b.commisionflag, b.COSTPRICE, b.COSTTOTAL, p.Custompro1, p.Custompro2, 
                p.Custompro3, p.Custompro4, p.Custompro5, b.discount, b.DiscountPrice, b.discounttotal, 0 AS EID, b.sfdacounts, 
                e.AccountComment as Factory, b.uneligibletransactor, b.uneligibleqty, b.uneligiblereason, b.instoretime, 0 AS IOTAG, b.s_id, b.location_id, 
                ISNULL(l.loc_name, '') AS LOCATION, b.makedate, p.MedName AS medtype, p.medtype AS MEDTYPEID, b.comment, b.comment2, 
                p.name, 0 AS ORDERID, b.Yqty, b.Ytaxprice, b.orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                b.pickqty, b.p_id, b.price, isnull(qualitystatus,'') AS QUALITYSTATUS, p.rate2, p.rate3, p.rate4, b.inceptqty, 
                CASE ISNULL(b.inceptstate, 0) WHEN 0 THEN '收货' ELSE '拒收' END AS inceptstate, b.refuseqty, 
                b.refusereason, p.RegisterNo, 0 AS REMAINING, b.checkreport, b.sampleqty, b.Gspsmb_id AS SMBID, b.Isspec, 
                p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 0 AS STORETYPE, b.eligibleqty, b.taxmoney, 
                b.taxprice, b.pricediscrepancy, b.TaxRate, b.TaxTotal, b.total, p.trademark, p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, 
                p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, p.Unit3Name, p.unit4_id AS UNIT4ID, 
                p.Unit4Name, p.unit1_id AS unit_id, b.validdate, ISNULL(c.name, '') AS VENDOR, ISNULL(s.WholeFlag, 0) AS WholeFlag, p.WholeRate, b.Yrowguid, b.y_id,
				p.validmonth, p.validday, p.StoreCondition AS DID,
				CASE WHEN g.BillType IN (521, 522, 523, 524) THEN b.EligibleQty ELSE 0 END AS BASEQTY,b.factoryid,b.costtaxprice,b.costtaxrate,b.costtaxtotal,
				b.oldorderqty as oldorderqty,b.oldorderunit as oldorderunit,b.OldOrderUnitid as OldOrderUnitid,b.OldOrderUnitrate  as  OldOrderUnitrate ,
				b.WMS_WholeQty as WholeQty,b.WMS_PartQty as PartQty
		FROM    dbo.GSPbilldetail AS b INNER JOIN
		        dbo.GSPbillidx AS g ON b.Gspbill_id = g.Gspbillid INNER JOIN
                dbo.vw_Products AS p ON b.p_id = p.product_id LEFT JOIN
                dbo.storages AS s ON b.s_id = s.storage_id LEFT OUTER JOIN
                dbo.clients AS c ON b.Supplier_id = c.client_id LEFT OUTER JOIN
                basefactory as e on b.factoryid=e.CommID LEFT OUTER JOIN
                dbo.location AS l ON b.location_id = l.loc_id WHERE GSPBILL_ID = @billid
		ORDER BY B.Gspsmb_id
	END
	SET @nRet = 0
END
GO
