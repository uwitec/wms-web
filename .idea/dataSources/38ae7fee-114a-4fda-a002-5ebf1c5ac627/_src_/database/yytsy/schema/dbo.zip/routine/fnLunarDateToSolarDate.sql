CREATE FUNCTION dbo.fnLunarDateToSolarDate
    (
      @LunarDate NVARCHAR(50)
    )
RETURNS NVARCHAR(50)
AS
    BEGIN
        DECLARE @Result NVARCHAR(50)
        DECLARE @tmpSolarDate DATETIME 
        DECLARE @tmpLunarDate NVARCHAR(50)
        
        /*查询阴历阳历对照表 TBLunarData */
        IF OBJECT_ID('TBLunarData', 'U') IS NULL
            BEGIN
                SET @Result = N'错误：农历转公历基础表不存在!'
                RETURN @Result
            END   
        SELECT @Result = SolardateStr
            FROM TBLunarData
            WHERE LunarDate = @LunarDate
        RETURN @Result    
    END
GO
