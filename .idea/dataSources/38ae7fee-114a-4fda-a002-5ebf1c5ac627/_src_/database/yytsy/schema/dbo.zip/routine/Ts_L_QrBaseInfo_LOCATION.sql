
create PROCEDURE Ts_L_QrBaseInfo_LOCATION
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

 /*if @szWhere<>'0'
  select * 
  from vw_Location vl left join ELabelCfg on  vl.loc_id=ELabelCfg.loc_id
  where  ([loc_Name] like @szName or loc_Code like @szName ) and s_id=@szwhere
 else --@szWhere='0'  未选仓库的情况下
 begin
  if @nFilterY = 1 --修改商品基本资料货位选择 只能选择当前机构的货位
  	select * 
  	from vw_Location vl left join ELabelCfg on  vl.loc_id=ELabelCfg.loc_id
  	where  ([loc_Name] like @szName or loc_Code like @szName ) and (Y_id=@nY_ID or Y_id=0)  
  else             --报表查询显示全部货位
        select * 
	from vw_Location vl left join ELabelCfg on  vl.loc_id=ELabelCfg.loc_id
	where  ([loc_Name] like @szName or loc_Code like @szName )   
 end*/
 
 /****modify by luowei 2011-09-16  货位选择增加货位最近存放商品信息和当前货位是否存放有商品***********/
    /*-----获取货位变动表中的各个货位最后变动的商品信息*/
  select lt.l_id,lt.s_id,lt.p_id,p.alias as name,p.serial_number,p.standard,p.makearea into #lc from LocationTrace lt 
        join products p on p.product_id=lt.p_id 
  join  (
      SELECT l_id,MAX(rectime) as rectime,MAX(p_id) p_id from LocationTrace loct 
      where (loct.s_id=@szWhere or @szWhere='0')  group by l_id) c   /*-2表示选冷链货位*/
   on c.rectime=lt.rectime and lt.l_id=c.l_id and lt.p_id=c.p_id
   
                 
   /*-----查看各货位上在库存中是否有数量*/
  select location_id,max(quantity) as maxQty into #store from storehouse where location_id<>0 group by location_id                   
                      
  IF @nFilterY = -1000
  BEGIN
  	  /*只显示零售拆零库的货位*/
  	  select vl.*,ELabelCfg.id,ELabelCfg.StyleH,ELabelCfg.StyleL,ELabelCfg.ELabelCodeH,
			 ELabelCfg.ELabelCodeL,#lc.name as Pname,#lc.serial_number,#lc.standard,#lc.makearea,
			 (case isnull(#store.maxQty,0) when 0 then '是' else '否' end) as maxQty,isnull(#store.maxqty,0) as maxRealQty
			  from vw_Location vl
								   left join ELabelCfg on  vl.loc_id=ELabelCfg.loc_id
								   left join #lc       on  #lc.l_id=vl.loc_id
								   left join #store    on #store.location_id=vl.loc_id
	  where vl.sWholeFlag = 3 and ([loc_Name] like @szName or loc_Code like @szName ) 
	  and (vl.s_id=@szWhere or @szWhere='0' or (@szWhere='-2' and vl.storeCondition = 2))   /*-2表示选冷链货位*/
  END
  ELSE
  BEGIN
  	  /*过滤掉零售拆零库的货位*/
      select vl.*,ELabelCfg.id,ELabelCfg.StyleH,ELabelCfg.StyleL,ELabelCfg.ELabelCodeH,
			 ELabelCfg.ELabelCodeL,#lc.name as Pname,#lc.serial_number,#lc.standard,#lc.makearea,
			 (case isnull(#store.maxQty,0) when 0 then '是' else '否' end) as maxQty,isnull(#store.maxqty,0) as maxRealQty
			  from vw_Location vl
								   left join ELabelCfg on  vl.loc_id=ELabelCfg.loc_id
								   left join #lc       on  #lc.l_id=vl.loc_id
								   left join #store    on #store.location_id=vl.loc_id
	  where vl.sWholeFlag <> 3 and ([loc_Name] like @szName or loc_Code like @szName ) and (vl.s_id=@szWhere or @szWhere='0'
	  or (@szWhere='-2' and vl.storeCondition = 2))
  END
	  
  drop table #lc
  drop table #store
GO
