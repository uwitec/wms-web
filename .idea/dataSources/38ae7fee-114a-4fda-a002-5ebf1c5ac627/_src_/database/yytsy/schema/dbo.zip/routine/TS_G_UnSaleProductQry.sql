

/*修改： zjl 2013-04-27  统计时不管批次，不选仓库时，所有仓库数量进行合计*/
/*无销售商品查询*/
CREATE Proc TS_G_UnSaleProductQry
(
  @BeginDate DateTime = 0 ,
  @EndDate   Datetime = 0,
  @SaleBeginDate DateTime = 0 ,
  @SaleEndDate   Datetime = 0,
  @nDay      Int= 0,
  @S_ID      Int= 0,
  @nYClassID   varchar(50)='',
  @nloginEID   int=0,
  @isaddDate   int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
as
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0 
if @EndDate is null  SET @EndDate = 0
if @SaleBeginDate is null  SET @SaleBeginDate = 0 
if @SaleEndDate is null  SET @SaleEndDate = 0
if @nDay is null  SET @nDay = 0
if @S_ID is null  SET @S_ID = 0
if @nYClassID is null  SET @nYClassID = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/

  Declare @Companytable int,@Storetable integer
  Declare @szSClass_id varchar(50)

  create table #Companytable([id] int)
  create table #storagestable([id] int)
/*---分支机构授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权 */
/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/

if @nYClassID<>''  set @nYClassID=@nYClassID+'%' else  set @nYClassID='%%'
if @s_id=0 select @szSClass_id='%%' else select @szSClass_id=Class_id from storages where storage_id=@s_id
/*----------------------------------------------------------------------------------------------*/

if @S_ID > 0 
begin
   
        SELECT  sh.p_id as product_id,       vp.class_id,  vp.serial_number, vp.name,     vp.alias,    vp.standard,    vp.modal, vp.permitcode,
                vp.trademark,  vp.makearea,  vp.pinyin,        vp.EngName,  vp.ChemName,  vp.LatinName,IsNULL(MaX(PB.e_name),'')e_name ,
                ISNULL(Max(PB.C_Name),'')C_Name , ISNULL(m.name, '')MedName,
                vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,  
                sh.s_id,sh.SName, Min(sh.instoretime)instoretime, ISNULL(Sum(abs(sh.quantity)),0) as quantity
                ,cast(Sum(isnull(sh.quantity,0)*sh.costprice) AS NUMERIC(25,8))costtotal, '所有批号' as batchno,sh.validdate

          FROM  (select sh.p_id,sh.instoretime,sh.quantity,sh.Costprice,sh.Y_id,sh.s_id,sh.validdate,
                        ISNULL(Y.Class_id,'')YClass_id,isnull(s.Class_id,'')SClass_id,isnull(S.[name],'')SName
                   from FilterStorehouse(@nloginEID) sh
                     left join  storages  s  on sh.s_id  = s.storage_id
                     left join  company   Y  on sh.Y_id  = Y.company_id
                  where  not exists
                     (select p_id,ss_id 
                        from (select pd.p_id,pd.ss_id,isnull(s.Class_id,'')sClass_id,isnull(Y.Class_id,'')YClass_id
                                from (select sm.p_id,sm.ss_id,b.Y_id 
                                        FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
                                        LEFT JOIN  billidx  b on  b.billid=sm.bill_id 
                                       where b.billdate BETWEEN  @SaleBeginDate and @SaleEnddate and sm.aoid in (0,5) and p_id>0
                                             and b.billtype in (10, 12, 32, 53, 150, 152, 112,212) and b.billstates = '0' 
                                      )PD
                                 LEFT JOIN  Company  Y on  Y.Company_id=PD.Y_id
                                 LEFT JOIN  storages S on  S.storage_id=pd.ss_id
                             )sm
                       where  YClass_id like @nYClassID
                          and SClass_id like @szSClass_id
                          and sh.p_id=sm.p_id and sh.s_id=sm.ss_id
                     ) 
                  
                )sh
            LEFT JOIN  Products  vp  on  sh.p_id = vp.product_id 
            left   join 
		   (
            select P_id as baseinfo_id,c.name from ProductCategory pc
            left join customCategory c on PComent3 = c.class_id 
            where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
		   )m on vp.product_id = m.baseinfo_id
            LEFT JOIN vw_productbalance  PB ON vp.product_id = PB.p_id and sh.Y_ID = PB.Y_id 
          WHERE  Yclass_id like @nYClassID
            and (@CompanyTable=0 or sh.Y_id in (select [id] from #Companytable )) 
            AND (@Storetable=0   OR sh.s_id in (select [id] from #storagestable)) 
            and sclass_id like @szSClass_id
            and (sh.instoretime between @Begindate and @EndDate)
          Group by
                sh.p_id,  vp.class_id,  vp.serial_number,  vp.name,  vp.alias,  vp.standard,  vp.modal,  vp.permitcode,
                vp.trademark,  vp.makearea,   vp.pinyin,   vp.EngName,   vp.ChemName,   vp.LatinName, 
                 m.name, sh.s_id,vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,  
                sh.[SName],sh.validdate 
end
if @S_ID = 0 
begin
          SELECT  sh.p_id as product_id,       vp.class_id,  vp.serial_number, vp.name,     vp.alias,    vp.standard,    vp.modal, vp.permitcode,
                vp.trademark,  vp.makearea,  vp.pinyin,        vp.EngName,  vp.ChemName,  vp.LatinName,IsNULL(MaX(PB.e_name),'')e_name ,
                ISNULL(Max(PB.C_Name),'')C_Name , ISNULL(m.name, '')MedName,
                vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,  
                0 as s_id, '所有仓库合计' as SName, Min(sh.instoretime)instoretime, ISNULL(Sum(abs(sh.quantity)),0) as quantity
                ,cast(Sum(isnull(sh.quantity,0)*sh.costprice) AS NUMERIC(25,8))costtotal,'所有批号' as batchno, sh.validdate

          FROM  (select sh.p_id,sh.instoretime,sh.quantity,sh.Costprice,sh.Y_id,sh.validdate,
                        ISNULL(Y.Class_id,'')YClass_id
                   from FilterStorehouse(@nloginEID) sh                     
                     left join  company   Y  on sh.Y_id  = Y.company_id
                  where  not exists
                     (select p_id 
                        from (select pd.p_id, isnull(Y.Class_id,'')YClass_id,batchno
                                from (select sm.p_id,b.Y_id
                                        FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数*/
                                        LEFT JOIN  billidx  b on  b.billid=sm.bill_id 
                                       where b.billdate BETWEEN  @SaleBeginDate and @SaleEnddate and sm.aoid in (0,5) and p_id>0
                                             and b.billtype in (10, 12, 32, 53, 150, 152, 112,212) and b.billstates = '0' 
                                      )PD
                                 LEFT JOIN  Company  Y on  Y.Company_id=PD.Y_id                      
                             )sm
                       where  YClass_id like @nYClassID                      
                          and sh.p_id=sm.p_id
                     ) 
                  
                )sh
            LEFT JOIN  Products  vp  on  sh.p_id = vp.product_id 
            left   join 
		   (
             select P_id as baseinfo_id,c.name from ProductCategory pc
             left join customCategory c on PComent3 = c.class_id 
             where c.deleted = 0 and c.Child_Number = 0 and c.Category_id = 3 and baseType = 0
		   )m on vp.product_id = m.baseinfo_id
            LEFT JOIN vw_productbalance  PB ON vp.product_id = PB.p_id and sh.Y_ID = PB.Y_id 
          WHERE  Yclass_id like @nYClassID
            and (@CompanyTable=0 or sh.Y_id in (select [id] from #Companytable ))                     
            and (sh.instoretime between @Begindate and @EndDate)
          Group by
                sh.p_id,  vp.class_id,  vp.serial_number,  vp.name,  vp.alias,  vp.standard,  vp.modal,  vp.permitcode,
                vp.trademark,  vp.makearea,   vp.pinyin,   vp.EngName,   vp.ChemName,   vp.LatinName, 
                 m.name,vp.Inputman,vp.InputDate,vp.Custompro1,vp.Custompro2,vp.Custompro3,vp.Custompro4,vp.Custompro5,  
                 sh.validdate 

end
GO
