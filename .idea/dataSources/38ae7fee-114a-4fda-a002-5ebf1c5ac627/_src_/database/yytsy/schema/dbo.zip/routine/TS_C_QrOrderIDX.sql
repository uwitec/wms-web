


/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

合同查询
@cMode=0 以单据日期筛选
	=1 以过帐日期筛选

********************************************/
create PROCEDURE [dbo].[TS_C_QrOrderIDX]
(	
	@Begindate      DATETIME,
	@EndDate		DATETIME,
	@nBillType      INT=0,
	@nC_ID			INT=0,
	@nE_ID			INT=0,
    @nInputman      INT=0,  
    @nY_ID          varchar(50)='',
    @nLoginEid      INT=0,
    @nWLState       INT=0,        /*物流状态*/
	@nPid			int = 0,
	@nAudit			int = 0,
	@StrBusinessType varchar(50)='0',
	@Sorderstate    varchar(50)='N', /*-N不显示订单状态，S显示订单状态*/
	@SendC_id       int = 0,
	@BillNumber     varchar(50),   /*单据编号*/
	@Note           varchar(300),  /*单据备注*/
	@Custom1        varchar(200),  /*属性1*/
	@Custom2        varchar(200),  /*属性1 */
	@Custom3        varchar(200),  /*属性1*/
	@CyMode         varchar(50)    /*承运方式*/
)
AS
/*Params Ini begin*/
if @Begindate is null  SET @Begindate = GETDATE()
if @EndDate is null  SET @EndDate = GETDATE()
if @nBillType is null  SET @nBillType = 0
if @nC_ID is null  SET @nC_ID = 0
if @nE_ID is null  SET @nE_ID = 0
if @nInputman is null  SET @nInputman = 0
if @nY_ID is null  SET @nY_ID = ''
if @nLoginEid is null  SET @nLoginEid = 0
if @nPid is null  SET @nPid = 0
if @nAudit is null  SET @nAudit = 0
if @StrBusinessType is null set @StrBusinessType = '0'
if @SendC_id is null  SET @SendC_id = 0
if @BillNumber is null  SET  @BillNumber = ''
if @Note       is null  SET  @Note    = ''
if @Custom1    is null  SET  @Custom1 = ''
if @Custom2    is null  SET  @Custom2 = ''
if @Custom3    is null  SET  @Custom3 = ''
if @CyMode     is null  SET  @CyMode  = ''
/*Params Ini end*/
SET NOCOUNT ON
DECLARE
  @SQLScript VARCHAR(8000),
  @SQLBak    VARCHAR(200),
  @ClientTable varchar(100),@Companytable varchar(100),@employeestable varchar(100),@Storetable varchar(100),
  @szsql2    varchar(8000)


Declare @FilteClient varchar(8000),@FilteCompany varchar(8000),@Filteemployees  varchar(8000),@Filteemployees2  varchar(8000),@FilteStore   varchar(8000)
select  @FilteClient='',@FilteCompany='',@Filteemployees ='',@Filteemployees2 ='',@FilteStore =''
select szTYPE into #type from  DecodeToStr(@StrBusinessType)

  IF @nC_ID<>0 
  begin
    if @nbilltype=26
  		SET @SQLBak=' WHERE [Supplier_ID]='+CAST(@nC_ID AS VARCHAR)
    else if @nbilltype=22
  	   set @SQLBak=' WHERE AOID in (select szTYPE from #type)'
    else 
      set @sqlbak=''
  end ELSE
    SET @SQLBak=' WHERE AOID in (select szTYPE from #type)'

	IF @nPid > 0
	BEGIN
		IF @SQLBak = ''
			SET @SQLBak = ' WHERE P_ID = ' + CAST(@nPid AS VARCHAR(10))
		ELSE
			SET @SQLBak = @SQLBak + ' AND P_ID = ' + CAST(@nPid AS VARCHAR(10))
	END
	
  exec Ts_L_SearchUserauthorize @nLoginEid,1,@ClientTable out,1,@Companytable out,1,@employeestable out /*调用后，要在最后释放临时表*/
   
 IF ISNULL(@ClientTable,'')<>''     set @FilteClient=' and ((b.cclass_id='''') or (exists(select CCID FROM '+@ClientTable+' where b.cclass_id like CCID+''%''))) '
 IF ISNULL(@Companytable,'')<>''    set @FilteCompany=' and ((b.YClass_ID='''') or (exists(select YCID from '+@Companytable+' where b.YClass_ID  like YCID+''%''))) '/*只用于查询YProductDetail*/

 IF ISNULL(@employeestable,'')<>''  set @Filteemployees= ' and ((b.Eclass_id='''')  or (exists(select ECID FROM '+@employeestable+' where b.Eclass_id  like ECID+''%'')))'
 IF ISNULL(@employeestable,'')<>''  set @Filteemployees2= ' and ((b.inputmanclass_id='''')  or (exists(select ECID FROM '+@employeestable+' where b.inputmanclass_id  like ECID+''%'')))'

 if @nBillType > 0 
 begin
    if @Sorderstate='S' 
    begin
		SELECT @SQLScript='
		SELECT DISTINCT 
		  isnull(dbo.GetBillState(B.[BillID]),'''') as TranfStates, 
		  B.[BillID],   B.[Billtype], B.[Billdate], B.[Billnumber], B.[Billstates],
		  B.[Inputman], B.[Auditman], B.[Note],     B.[Summary],    oB.[Quantity],--zh100907
		  B.[Ysmoney],  B.[Ssmoney],  B.[Taxrate],  B.[Auditdate],
		  ISNULL(OB.[ComeQty]   ,0) AS [ComeQty],
		  case when OB.[UnComeQty]<0 then 0 else  OB.[UnComeQty] end  AS [UnComeQty],
				[Billname]=CASE B.[Billtype]
			  WHEN 14 THEN ''销售订单''
			  WHEN 108 THEN ''直调订单''
			  WHEN 22 THEN ''采购订单''
			  WHEN 26 THEN ''采购计划''
			  END,
			  B.[Ename]          AS [Employeename],
			  B.[Auditmanname]   AS [Auditmanname],
			  B.[Inputmanname]   AS [Inputmanname],
			  B.[Aname]          AS [Accountname],
			  B.[Departmentname] AS [Departmentname],
			  B.[Regionname]     AS [Regionname],
			  Cname = CASE B.[Billtype]
			  WHEN 154 THEN B.[COMname] 
			  ELSE   B.[Cname]
			  END, 0 as serialno,
			  b.[skdate], b.ordervaliddate
			  ,isnull(p.printcount,0) as [printcount]
			  ,isnull(b.sendcname,'''') as sendcname
			  ,b.YName
			  ,isnull(s.name,'''') as SName
			  ,isnull(w.saleEName,'''') as WTName
  		FROM VW_C_OrderIDX B left join (select * from vw_c_printcountYH where nflag=3 ) as  p on b.billid=p.Rep_id 
  		left join storages s on b.sout_id = s.storage_id
  		left join wtorder w on b.wt_id = w.wt_id  		
  		left join
		(SELECT [Bill_ID],sum(quantity) as quantity,--zh100907 
		cast(SUM(ComeQty) as NUMERIC(25,8))    AS [ComeQty],
		CAST(SUM(Quantity-ComeQty) as NUMERIC(25,8)) AS [UnComeQty]
		FROM OrderBill'+@SQLBak+'
		GROUP BY [BILL_ID]) OB on B.[BillID]=OB.[BILL_ID]
		WHERE  B.[BillID]=OB.[BILL_ID] AND  (' + CAST(@nAudit AS varchar(10)) + ' = 0 OR AUDITMAN = ' + CAST(@nAudit AS varchar(10)) + ') '
		if @nBillType < 0 
		begin
				set @SQLScript= @SQLScript +' AND B.[skdate] < '  +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) 
				+' AND b.billstates = 3 and B.[skdate] > 10 '                            
		end
		else 
		begin
		  set @SQLScript= @SQLScript +' AND (B.[Billdate] BETWEEN '
			  +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'   
		end    
		set @SQLScript= @SQLScript +' AND B.[Billtype]='+CAST(abs(@nBilltype) AS VARCHAR)
		+@FilteClient+@FilteCompany+@Filteemployees+@Filteemployees2

		IF @nE_ID<>0
		  SET @SQLScript=@SQLScript+' AND B.[E_ID]='+CHAR(39)+CAST(@nE_ID AS VARCHAR)+CHAR(39)
		IF @nInputman<>0
		  SET @SQLScript=@SQLScript+' AND B.[Inputman]='+CHAR(39)+CAST(@nInputman AS VARCHAR)+CHAR(39)
        if @SendC_id<>0 
	       set @SQLScript= @SQLScript +' AND B.sendc_id ='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
		IF @nC_ID<>0 and @nbilltype<>26
		    SET @SQLScript=@SQLScript+' AND B.[C_ID]='+CHAR(39)+CAST(@nC_ID AS VARCHAR)+CHAR(39)
		IF  @nY_id not in ('','000000','%%')   
		    SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''
		IF @BillNumber <> ''
		    SET @SQLScript=@SQLScript+' AND BillNumber like ''%'+ @BillNumber +'%'''
		IF @Note <> ''
		    SET @SQLScript=@SQLScript+' AND NOTE like ''%'+ @Note +'%'''
		IF @Custom1 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName1 = '''+ @Custom1 +''''
		IF @Custom2 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName2 = '''+ @Custom2 +''''
		IF @Custom3 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName3 = '''+ @Custom3 +''''
		IF @CyMode not in ('','全部显示')
		    SET @SQLScript=@SQLScript+' AND TrafficType = '''+ @CyMode +''''		
		
		SET @SQLScript = 'SELECT a.*, ISNULL(b.WLState, 0) AS WLState FROM ('+@SQLScript+') a 
					   LEFT JOIN (Select distinct o.billid,Case Transportation_States when 2 then 2 else 1 end as wlstate  
		                         From orderidx o
		                         left join VW_GSPBILLIDX g on o.Guid = g.Yguid and g.BillType = 551
		                         left join Sendidx s on g.Sendid = s.Send_id
		                         where o.billtype = 14) b ON a.billid = b.billid
					   WHERE a.billType <> 14 OR (a.billtype = 14 AND (ISNULL(b.WLState, 0) = '+CAST(@nWLState AS VARCHAR(8))+') OR '+CAST(@nWLState AS VARCHAR(8))+' = 0)'            
     end
     if @Sorderstate='N' 
     begin
		SELECT @SQLScript='
		SELECT DISTINCT 
		  '''' as TranfStates, 
		  B.[BillID],   B.[Billtype], B.[Billdate], B.[Billnumber], B.[Billstates],
		  B.[Inputman], B.[Auditman], B.[Note],     B.[Summary],    oB.[Quantity],--zh100907
		  B.[Ysmoney],  B.[Ssmoney],  B.[Taxrate],  B.[Auditdate],
		  ISNULL(OB.[ComeQty]   ,0) AS [ComeQty],
		  case when OB.[UnComeQty]<0 then 0 else  OB.[UnComeQty] end  AS [UnComeQty],
				[Billname]=CASE B.[Billtype]
			  WHEN 14 THEN ''销售订单''
			  WHEN 108 THEN ''直调订单''
			  WHEN 22 THEN ''采购订单''
			  WHEN 26 THEN ''采购计划''
			  END,
			  B.[Ename]          AS [Employeename],
			  B.[Auditmanname]   AS [Auditmanname],
			  B.[Inputmanname]   AS [Inputmanname],
			  B.[Aname]          AS [Accountname],
			  B.[Departmentname] AS [Departmentname],
			  B.[Regionname]     AS [Regionname],
			  Cname = CASE B.[Billtype]
			  WHEN 154 THEN B.[COMname] 
			  ELSE   B.[Cname]
			  END, 0 as serialno,
			  b.[skdate], b.ordervaliddate
			  ,isnull(p.printcount,0) as [printcount]
			  ,isnull(b.sendcname,'''') as sendcname
			  ,b.YName
			  ,isnull(s.name,'''') as SName
			  ,isnull(w.saleEName,'''') as WTName			  
  		FROM VW_C_OrderIDX B left join (select * from vw_c_printcountYH where nflag=3 ) as  p on b.billid=p.Rep_id 
  		left join storages s on b.sout_id = s.storage_id
  		left join wtorder w on b.wt_id = w.wt_id  		
  		left join
		(SELECT [Bill_ID],sum(quantity) as quantity,--zh100907 
		cast(SUM(ComeQty) as NUMERIC(25,8))    AS [ComeQty],
		CAST(SUM(Quantity-ComeQty) as NUMERIC(25,8)) AS [UnComeQty]
		FROM OrderBill'+@SQLBak+'
		GROUP BY [BILL_ID]) OB on B.[BillID]=OB.[BILL_ID]
		WHERE  B.[BillID]=OB.[BILL_ID] AND (' + CAST(@nAudit AS varchar(10)) + ' = 0 OR AUDITMAN = ' + CAST(@nAudit AS varchar(10)) + ') '
	    
		if @nBillType < 0 
		begin
				set @SQLScript= @SQLScript +' AND B.[skdate] < '  +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) 
				+' AND b.billstates = 3 and B.[skdate] > 10 '                            
		end
		else begin
		  set @SQLScript= @SQLScript +' AND (B.[Billdate] BETWEEN '
			  +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39) +' AND '+CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'   
		end    
		set @SQLScript= @SQLScript +' AND B.[Billtype]='+CAST(abs(@nBilltype) AS VARCHAR)
		+@FilteClient+@FilteCompany+@Filteemployees+@Filteemployees2

		IF @nE_ID<>0
			SET @SQLScript=@SQLScript+' AND B.[E_ID]='+CHAR(39)+CAST(@nE_ID AS VARCHAR)+CHAR(39)
		IF @nInputman<>0
			SET @SQLScript=@SQLScript+' AND B.[Inputman]='+CHAR(39)+CAST(@nInputman AS VARCHAR)+CHAR(39)
        if @SendC_id<>0 
	        set @SQLScript= @SQLScript +' AND B.sendc_id ='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
		IF @nC_ID<>0 and @nbilltype<>26
			SET @SQLScript=@SQLScript+' AND B.[C_ID]='+CHAR(39)+CAST(@nC_ID AS VARCHAR)+CHAR(39)
		IF  @nY_id not in ('','000000','%%')   
		    SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''
		IF @BillNumber <> ''
		    SET @SQLScript=@SQLScript+' AND BillNumber like ''%'+ @BillNumber +'%'''
		IF @Note <> ''
		    SET @SQLScript=@SQLScript+' AND NOTE like ''%'+ @Note +'%'''
		IF @Custom1 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName1 = '''+ @Custom1 +''''
		IF @Custom2 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName2 = '''+ @Custom2 +''''
		IF @Custom3 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName3 = '''+ @Custom3 +''''
		IF @CyMode not in ('','全部显示')
		    SET @SQLScript=@SQLScript+' AND TrafficType = '''+ @CyMode +''''		    
		    
		SET @SQLScript = 'SELECT a.*, ISNULL(b.WLState, 0) AS WLState FROM ('+@SQLScript+') a 
					   LEFT JOIN (Select distinct o.billid,Case Transportation_States when 2 then 2 else 1 end as wlstate  
		                         From orderidx o
		                         left join VW_GSPBILLIDX g on o.Guid = g.Yguid and g.BillType = 551
		                         left join Sendidx s on g.Sendid = s.Send_id
		                         where o.billtype = 14) b ON a.billid = b.billid
					   WHERE a.billType <> 14 OR (a.billtype = 14 AND (ISNULL(b.WLState, 0) = '+CAST(@nWLState AS VARCHAR(8))+') OR '+CAST(@nWLState AS VARCHAR(8))+' = 0)'            
     end
   end 
   else 
   begin
     if @Sorderstate='S' 
     begin
		 SELECT @SQLScript='
		  SELECT DISTINCT
		  isnull(dbo.GetBillState(B.[BillID]),'''') as TranfStates, 
		  B.[BillID],   B.[Billtype], B.[Billdate], B.[Billnumber], B.[Billstates],
		  B.[Inputman], B.[Auditman], B.[Note],     B.[Summary],    oB.[Quantity],--zh100907
		  B.[Ysmoney],  B.[Ssmoney],  B.[Taxrate],  B.[Auditdate],
		  ISNULL(OB.[ComeQty]   ,0) AS [ComeQty],
		  case when OB.[UnComeQty]<0 then 0 else  OB.[UnComeQty] end  AS [UnComeQty],
				[Billname]=CASE B.[Billtype]
			  WHEN 14 THEN ''销售合同''
			  WHEN 22 THEN ''采购合同''
			  WHEN 26 THEN ''采购计划''
			  END,
			  B.[Ename]          AS [Employeename],
			  B.[Auditmanname]   AS [Auditmanname],
			  B.[Inputmanname]   AS [Inputmanname],
			  B.[Aname]          AS [Accountname],
			  B.[Departmentname] AS [Departmentname],
			  B.[Regionname]     AS [Regionname],
			  Cname = CASE B.[Billtype]
			  WHEN 154 THEN B.[COMname] 
			  ELSE   B.[Cname]
			  END,
			  b.[skdate],
			  b.ordervaliddate
			 ,isnull(p.printcount,0) as [printcount]
			  ,isnull(b.sendcname,'''') as sendcname
			  ,b.YName
			  ,isnull(s.name,'''') as SName
			  ,isnull(w.saleEName,'''') as WTName			  
  		FROM VW_C_OrderIDX B
  		left join (select * from vw_c_printcountYH   where nflag=3) as  p on b.billid=p.Rep_id 
  		left join storages s on b.sout_id = s.storage_id
  		left join wtorder w on b.wt_id = w.wt_id  		
  		left join
		(SELECT [Bill_ID],sum(quantity) as quantity,--zh100907 
		cast(SUM(ComeQty) as NUMERIC(25,8))    AS [ComeQty],
		CAST(SUM(Quantity-ComeQty) as NUMERIC(25,8)) AS [UnComeQty]
		FROM OrderBill'+@SQLBak+'
		GROUP BY [BILL_ID]) OB on B.[BillID]=OB.[BILL_ID]
		WHERE  B.[BillID]=OB.[BILL_ID] AND (B.[skdate] BETWEEN '
		+CHAR(39)+'1910-01-01'+CHAR(39)
		+' AND '+CHAR(39)+CONVERT(VARCHAR(10),@Begindate,20)+CHAR(39)+')'
		/*+' AND B.[Billtype]='+CAST(abs(@nBilltype) AS VARCHAR)*/
		+ ' And b.billstates =3 '
		+@FilteClient+@FilteCompany+@Filteemployees+@Filteemployees2

		IF @nE_ID<>0
			SET @SQLScript=@SQLScript+' AND B.[E_ID]='+CHAR(39)+CAST(@nE_ID AS VARCHAR)+CHAR(39)
		IF @nInputman<>0
			SET @SQLScript=@SQLScript+' AND B.[Inputman]='+CHAR(39)+CAST(@nInputman AS VARCHAR)+CHAR(39)
        if @SendC_id<>0 
	        set @SQLScript= @SQLScript +' AND B.sendc_id ='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
		IF @nC_ID<>0 and @nbilltype<>26
			SET @SQLScript=@SQLScript+' AND B.[C_ID]='+CHAR(39)+CAST(@nC_ID AS VARCHAR)+CHAR(39)
		IF  @nY_id not in ('','000000','%%')   
		    SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''
		IF @BillNumber <> ''
		    SET @SQLScript=@SQLScript+' AND BillNumber like ''%'+ @BillNumber +'%'''
		IF @Note <> ''
		    SET @SQLScript=@SQLScript+' AND NOTE like ''%'+ @Note +'%'''
		IF @Custom1 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName1 = '''+ @Custom1 +''''
		IF @Custom2 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName2 = '''+ @Custom2 +''''
		IF @Custom3 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName3 = '''+ @Custom3 +''''
		IF @CyMode not in ('','全部显示')
		    SET @SQLScript=@SQLScript+' AND TrafficType = '''+ @CyMode +''''		    
		    
		SET @SQLScript = 'SELECT a.*, ISNULL(b.WLState, 0) AS WLState FROM ('+@SQLScript+') a 
					   LEFT JOIN (Select distinct o.billid,Case Transportation_States when 2 then 2 else 1 end as wlstate  
		                         From orderidx o
		                         left join VW_GSPBILLIDX g on o.Guid = g.Yguid and g.BillType = 551
		                         left join Sendidx s on g.Sendid = s.Send_id
		                         where o.billtype = 14) b ON a.billid = b.billid
					   WHERE a.billType <> 14 OR (a.billtype = 14 AND (ISNULL(b.WLState, 0) = '+CAST(@nWLState AS VARCHAR(8))+') OR '+CAST(@nWLState AS VARCHAR(8))+' = 0)'            
	end
    if @Sorderstate='N' 
    begin
		 SELECT @SQLScript='
		  SELECT DISTINCT
		  '''' as TranfStates, 
		  B.[BillID],   B.[Billtype], B.[Billdate], B.[Billnumber], B.[Billstates],
		  B.[Inputman], B.[Auditman], B.[Note],     B.[Summary],    oB.[Quantity],--zh100907
		  B.[Ysmoney],  B.[Ssmoney],  B.[Taxrate],  B.[Auditdate],
		  ISNULL(OB.[ComeQty]   ,0) AS [ComeQty],
		  case when OB.[UnComeQty]<0 then 0 else  OB.[UnComeQty] end  AS [UnComeQty],
				[Billname]=CASE B.[Billtype]
			  WHEN 14 THEN ''销售合同''
			  WHEN 22 THEN ''采购合同''
			  WHEN 26 THEN ''采购计划''
			  END,
			  B.[Ename]          AS [Employeename],
			  B.[Auditmanname]   AS [Auditmanname],
			  B.[Inputmanname]   AS [Inputmanname],
			  B.[Aname]          AS [Accountname],
			  B.[Departmentname] AS [Departmentname],
			  B.[Regionname]     AS [Regionname],
			  Cname = CASE B.[Billtype]
			  WHEN 154 THEN B.[COMname] 
			  ELSE   B.[Cname]
			  END,
			  b.[skdate],
			  b.ordervaliddate
			 ,isnull(p.printcount,0) as [printcount]
			 ,isnull(b.sendcname,'''') as sendcname
			 ,b.YName
			 ,isnull(s.name,'''') as SName
			 ,isnull(w.saleEName,'''') as WTName			 
  		FROM VW_C_OrderIDX B
  		left join (select * from vw_c_printcountYH   where nflag=3) as  p on b.billid=p.Rep_id 
  		left join storages s on b.sout_id = s.storage_id
  		left join wtorder w on b.wt_id = w.wt_id  		
  		left join
		(SELECT [Bill_ID],sum(quantity) as quantity,--zh100907 
		cast(SUM(ComeQty) as NUMERIC(25,8))    AS [ComeQty],
		CAST(SUM(Quantity-ComeQty) as NUMERIC(25,8)) AS [UnComeQty]
		FROM OrderBill'+@SQLBak+'
		GROUP BY [BILL_ID]) OB on B.[BillID]=OB.[BILL_ID]
		WHERE  B.[BillID]=OB.[BILL_ID] AND (B.[skdate] BETWEEN '
		+CHAR(39)+'1910-01-01'+CHAR(39)
		+' AND '+CHAR(39)+CONVERT(VARCHAR(10),@Begindate,20)+CHAR(39)+')'
		/*+' AND B.[Billtype]='+CAST(abs(@nBilltype) AS VARCHAR)*/
		+ ' And b.billstates =3 '
		+@FilteClient+@FilteCompany+@Filteemployees+@Filteemployees2

		IF @nE_ID<>0
			SET @SQLScript=@SQLScript+' AND B.[E_ID]='+CHAR(39)+CAST(@nE_ID AS VARCHAR)+CHAR(39)
		IF @nInputman<>0
			SET @SQLScript=@SQLScript+' AND B.[Inputman]='+CHAR(39)+CAST(@nInputman AS VARCHAR)+CHAR(39)
        if @SendC_id<>0 
	       set @SQLScript= @SQLScript +' AND B.sendc_id ='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
		IF @nC_ID<>0 and @nbilltype<>26
		   SET @SQLScript=@SQLScript+' AND B.[C_ID]='+CHAR(39)+CAST(@nC_ID AS VARCHAR)+CHAR(39)
		IF  @nY_id not in ('','000000','%%')   
		   SET @SQLScript=@SQLScript+' and b.Yclass_ID like '''+@nY_id+'%'''
		IF @BillNumber <> ''
		    SET @SQLScript=@SQLScript+' AND BillNumber like ''%'+ @BillNumber +'%'''
		IF @Note <> ''
		    SET @SQLScript=@SQLScript+' AND NOTE like ''%'+ @Note +'%'''
		IF @Custom1 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName1 = '''+ @Custom1 +''''
		IF @Custom2 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName2 = '''+ @Custom2 +''''
		IF @Custom3 <> ''
		    SET @SQLScript=@SQLScript+' AND B_CustomName3 = '''+ @Custom3 +''''
		IF @CyMode not in ('','全部显示')
		    SET @SQLScript=@SQLScript+' AND TrafficType = '''+ @CyMode +''''		   
		   
		SET @SQLScript = 'SELECT a.*, ISNULL(b.WLState, 0) AS WLState FROM ('+@SQLScript+') a 
					   LEFT JOIN (Select distinct o.billid,Case Transportation_States when 2 then 2 else 1 end as wlstate  
		                         From orderidx o
		                         left join VW_GSPBILLIDX g on o.Guid = g.Yguid and g.BillType = 551
		                         left join Sendidx s on g.Sendid = s.Send_id
		                         where o.billtype = 14) b ON a.billid = b.billid
					   WHERE a.billType <> 14 OR (a.billtype = 14 AND (ISNULL(b.WLState, 0) = '+CAST(@nWLState AS VARCHAR(8))+') OR '+CAST(@nWLState AS VARCHAR(8))+' = 0)'            
	end
   end                                                         
  PRINT @SQLScript
  EXEC(@SQLScript)

  if isnull(@ClientTable,'')<>''
  begin
    set @szsql2='drop table '+@ClientTable
    exec (@szsql2) 
  end

  if isnull(@companytable,'')<>''
  begin
    set @szsql2='drop table '+@Companytable
    exec (@szsql2) 
  end

  if isnull(@employeestable,'')<>''
  begin
    set @szsql2='drop table '+@employeestable
    exec (@szsql2) 
  end

  GOTO SUCCEE



SUCCEE:
  RETURN 0
GO
