



CREATE proc ts_c_GetTaskList
(
	@begindate datetime,
	@enddate   datetime,
	@billtype  int=0,
	@tranflag  tinyint=0 
)
/*with encryption*/
as
/*Params Ini begin*/
if @billtype is null  SET @billtype = 0
if @tranflag is null  SET @tranflag = 0
/*Params Ini end*/
set nocount on 
if @billtype=0/*所有任务*/
begin	

		select t.tsid,t.billid,t.billtype,t.taskdate,t.lasttrandate,t.trancount,t.tranflag,t.posid,
		vb.billnumber,vb.billdate,vb.cname,vb.inputman
		from tasklist t,vw_c_billidx vb
		where t.billid=vb.billid and t.billtype in (150,152, 12, 13) and t.taskdate>=@begindate and t.taskdate<dateadd(day,1,@enddate) and
		      (@tranflag = 0 or tranflag = @tranflag) 
    union
		select t.tsid,t.billid,t.billtype,t.taskdate,t.lasttrandate,t.trancount,t.tranflag,t.posid,
		vb.billnumber,vb.billdate,vb.posname as cname,vb.inputman
		from tasklist t,vw_c_priceidx vb
		where t.billid=vb.billid and t.billtype in (140) and t.taskdate>=@begindate and t.taskdate<dateadd(day,1,@enddate) and
		      (@tranflag = 0 or tranflag = @tranflag)
		order by t.taskdate
end else if @billtype in (150,152,12,13) 
begin
	select t.tsid,t.billid,t.billtype,t.taskdate,t.lasttrandate,t.trancount,t.tranflag,t.posid,
	vb.billnumber,vb.billdate,vb.cname,vb.inputman
	from tasklist t,vw_c_billidx vb
	where t.billid=vb.billid and t.billtype=@billtype and t.taskdate>=@begindate and t.taskdate<dateadd(day,1,@enddate) and
	      (@tranflag = 0 or tranflag = @tranflag) 
	order by t.taskdate
end else if @billtype in (140)
begin
	select t.tsid,t.billid,t.billtype,t.taskdate,t.lasttrandate,t.trancount,t.tranflag,t.posid,
	vb.billnumber,vb.billdate,vb.posname as cname,vb.inputman
	from tasklist t,vw_c_priceidx vb
	where t.billid=vb.billid and t.billtype=@billtype and t.taskdate>=@begindate and t.taskdate<dateadd(day,1,@enddate) and
	      (@tranflag = 0 or tranflag = @tranflag)
	order by t.taskdate
end
GO
