
/*
门店配送模板
*/

CREATE	       PROCEDURE ts_k_WizardBill
(
	@BillType INT = 152,         /*要生成的单据类型，默认自营店发货单*/
	@SourceYID VARCHAR(100) = '0',
	@TargetYID INT = 0,          /*收货机构YID*/
	@E_Id  INT = 0,              /*制单人ID*/
	@Y_Id  INT = 0,              /*制单人所属机构YID，既发货机构YID*/
	@iSector INT = 7,            /*时间区间*/
	@iDays INT = 3,              /*备货天数*/
	@BillNumber VARCHAR(20) = '' /*单据编号*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @BillType is null  SET @BillType = 152
if @SourceYID is null  SET @SourceYID = '0'
if @TargetYID is null  SET @TargetYID = 0
if @E_Id is null  SET @E_Id = 0
if @Y_Id is null  SET @Y_Id = 0
if @iSector is null  SET @iSector = 7
if @iDays is null  SET @iDays = 3
if @BillNumber is null  SET @BillNumber = ''
/*Params Ini end*/
DECLARE @SourceSID INT /*发货仓库SID*/
SELECT TOP 1 @SourceSID = storage_id FROM storages WHERE Y_ID = @Y_Id AND child_number = 0 AND deleted = 0
		AND WholeFlag <> 3 AND qualityFlag = 0 AND storeCondition = 0  /*仓库默认选择常温的合格品库*/
IF @SourceSID IS NULL
RETURN -1

DECLARE @TargetSID INT /*收货仓库SID*/
SELECT TOP 1 @TargetSID = storage_id FROM storages WHERE Y_ID = @TargetYID AND child_number = 0 AND deleted = 0
			AND WholeFlag <> 3 AND qualityFlag = 0 AND storeCondition = 0  /*仓库默认选择常温的合格品库*/
IF @TargetSID IS NULL
RETURN -1

/**/
IF EXISTS(SELECT * FROM tempdb.dbo.SYSOBJECTS WHERE id = OBJECT_ID(N'tempdb..#tmpk_WizardBill') AND type = 'U')
TRUNCATE TABLE #tmpk_WizardBill
ELSE
CREATE TABLE #tmpk_WizardBill
(
Y_ID INT 
)
DECLARE @szYID VARCHAR(100)
WHILE CHARINDEX(',', @SourceYID) <> 0
BEGIN
  SET @szYID = SUBSTRING(@SourceYID, 1, CHARINDEX(',', @SourceYID) - 1)
  INSERT INTO #tmpk_WizardBill(Y_ID) VALUES(@szYID)
  SET @SourceYID = SUBSTRING(@SourceYID, CHARINDEX(',', @SourceYID) + 1, LEN(@SourceYID))
END
IF LEN(@SourceYID) > 0
BEGIN
  INSERT INTO #tmpk_WizardBill(Y_ID) VALUES(@SourceYID)
END
/**/

IF NOT EXISTS(SELECT 1         
                FROM (SELECT b.p_id   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id)                  
RETURN -1

DECLARE @newbillid INT  /*新主单的BILLID*/

IF @BillType = 152
BEGIN
  BEGIN TRAN k_WizardBill
  INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id,
                           auditman, inputman, ysmoney, ssmoney, quantity, taxrate, period,
                           billstates, order_id, department_id, posid, region_id, auditdate,
                           skdate, jsye, jsflag, note, summary, invoice, transcount, lasttranstime,
                           GUID, invoiceTotal, invoiceNO, businesstype, araptotal, sendqty,
                           gatheringman, vipcardid, jsinvoicetotal, Y_ID, transflag, begindate,
                           Enddate, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3,
                           RetailDate, sendC_id, WholeQty, PartQty,ZBAuditMan,ZBAuditDate)
  SELECT CONVERT(VARCHAR(100), GETDATE(), 23), @BillNumber, @BillType, 0, @TargetYID, @E_Id, 
         @SourceSID, @TargetSID, 0, @E_id,  
         (SELECT SUM(a.quantity * b.recprice) AS ysmoney       
                FROM (SELECT b.p_id,
                             CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id), 
         0, 
         (SELECT SUM(a.quantity) AS quantity       
                FROM (SELECT b.p_id,
                             CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id), 
         0, 0, 2, 0, 0, 0, 0, '1900-01-01', '1900-01-01', 
         ((SELECT SUM(a.quantity * b.recprice) AS jsye       
                FROM (SELECT b.p_id,
                             CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id)),
         0, '', '', 0, 0, '1900-01-01', NEWID(), 0, '', 0, 0,
         (SELECT SUM(a.quantity) AS sendqty       
                FROM (SELECT b.p_id,
                             CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id), 
         0, 0, 0, @Y_Id, 0, '1900-01-01', '1900-01-01', 0, 0, '', '', '', '1900-01-01', 0, 0, 
         (SELECT SUM(a.quantity) AS partqty       
                FROM (SELECT b.p_id,
                             CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
                        FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
                      WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
                            a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
                            b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
                            a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
                      GROUP BY b.p_id
                     ) a INNER JOIN 
                     (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice 
                        FROM products a, price b 
                      WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND 
                            a.child_number = 0 AND a.deleted = 0 
                     ) b ON a.p_id = b.p_id),0,'1900-01-01'
          
  IF @@ROWCOUNT = 0
  BEGIN 
    ROLLBACK TRAN k_WizardBill
    RETURN -1
  END
                  
  SET @newbillid = @@IDENTITY
    
  INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, 
                                discountprice, totalmoney, taxprice, taxtotal, taxmoney, retailprice,
                                retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id,
                                location_id, supplier_id, commissionflag, comment, unitid, taxrate, order_id,
                                total, iotag, invoicetotal, thqty, newprice, orgbillid, aoid, jsprice, 
                                invoice, invoiceno, pricetype, sendqty, sendcosttotal, RowGuid, RowE_id, 
                                YCostPrice, YGuid, Y_ID, transflag, instoretime, cxType, location_id2, comment2,factoryid)
  SELECT @newbillid, a.p_id, '', a.quantity, b.recprice, b.recprice, 1, b.recprice, 
       b.recprice * a.quantity, b.recprice * (1+b.taxrate*1.0/100), b.recprice * (1 +b.taxrate*1.0/100) * a.quantity, b.recprice * (b.taxrate*1.0/100) * a.quantity, b.retailprice, b.retailprice * a.quantity,
       '1900-01-01', '1900-01-01', '', b.price_id, @SourceSID, @TargetSID, 0, 0, 0, '', b.unit1_id, b.taxrate*1.0/100, 0, 
       b.recprice * a.quantity, 0, 0, a.quantity, b.recprice, 0, 0, 0, 0, 1, 2, a.quantity, 
       b.recprice * a.quantity, NEWID(), @E_Id, CONVERT(VARCHAR(50), b.recprice), NEWID(), @Y_Id, 0, '1899-12-30', 
       0, 0, '',b.factoryc_id         
  FROM (SELECT b.p_id,
               CASE WHEN (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) < 1 THEN 1 ELSE (ROUND(SUM(b.quantity)/@iSector * @iDays, 0)) End AS quantity   
          FROM billidx a INNER JOIN salemanagebill b ON a.billid = b.bill_id 
        WHERE a.billtype IN (10, 12, 212) AND a.billstates = 0 AND 
              a.Y_ID IN (SELECT Y_ID FROM #tmpk_WizardBill) AND 
              b.p_id > 0 AND b.commissionflag = 0 AND b.AOID = 0 AND
              a.auditdate BETWEEN GETDATE() - @iSector AND GETDATE()
        GROUP BY b.p_id
       ) a INNER JOIN 
       (SELECT b.price_id, b.p_id, a.unit1_id, b.retailprice, b.recprice, b.lastprice, cast(isnull(c.name,'0') as int) taxrate,factoryc_id  
          FROM products a, price b,customCategory c 
        WHERE a.product_id = b.p_id AND a.unit1_id = b.u_id AND a.TaxRate = c.id AND
              a.child_number = 0 AND a.deleted = 0 
       ) b ON a.p_id = b.p_id                           
                                
  IF @@ROWCOUNT = 0
  BEGIN 
    ROLLBACK TRAN k_WizardBill
    RETURN -1
  END ELSE
  BEGIN
    COMMIT TRAN k_WizardBill
    RETURN 1
  END
END ELSE 
BEGIN
  RETURN -1
END
GO
