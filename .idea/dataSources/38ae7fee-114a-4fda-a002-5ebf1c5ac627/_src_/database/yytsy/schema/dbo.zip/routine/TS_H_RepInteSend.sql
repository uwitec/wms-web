
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-5-3*/
/* Description:	智能配货查询*/
/* =============================================*/
/*TS_H_RepInteSend 2,'2017-04-01','2017-04-25','3'*/
CREATE PROCEDURE [dbo].[TS_H_RepInteSend]
	@YID			int = 0,
	@BeginDate		varchar(30),
	@EndDate		varchar(30),
	@SZPtype      varchar(2000)    /*xxx. 选择的商品自定义类别串*/
AS
BEGIN
/*Params Ini begin*/
if @YID is null  SET @YID = 0
/*Params Ini end*/
	SET NOCOUNT ON

	DECLARE @sPids VARCHAR(8000)
	DECLARE @nPid INT
    DECLARE @info_ID INT 
    DECLARE @ColName VARCHAR(100)
    DECLARE @szSql varchar(2000)
    DECLARE @classid varchar(100)
    /*zjx--2017-04-25--处理（新）自定义类别*/
    CREATE TABLE #PORDUCTS ([p_id] [int] NOT NULL DEFAULT(0))
    if @SZPtype<>'' 
    begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@SZPtype))
            /*zjx.通过选择自定义类别id的字符串获取class_ID字符串串*/
			SELECT @classid = dbo.GetCateClassids(@SZPtype) 
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
            /*根据所选择的类别ID找出所关联的商品*/
		    set @szSql =  'INSERT INTO #PORDUCTS(p_id) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @ColName + 
			' in (select type  from DecodeStr(''' +@classid +'''))'  
		    exec (@szSql)
    end
	SET @sPids = ' '
	SELECT DISTINCT p_id INTO #TMPP
	FROM TranBill T INNER JOIN TranIdx I ON T.bill_id = I.billid
	WHERE I.billdate BETWEEN @BeginDate AND @EndDate AND (i.c_id = @YID OR @YID = 0) 
		AND (i.billtype = 52) AND (i.billstates IN ('3', '0')) AND i.CenterAuditMan > 0
		AND i.c_id <> 2

	DECLARE CURP CURSOR FOR
	SELECT p_id FROM #TMPP
	OPEN CURP
	FETCH NEXT FROM CURP INTO @nPid
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @sPids = @sPids + CAST(@nPid AS VARCHAR(10)) + ','
		FETCH NEXT FROM CURP INTO @nPid
	END
	CLOSE CURP
	DEALLOCATE CURP
	/*PRINT LEN(@sPids)*/
	IF LEN(@sPids) BETWEEN 2 AND 4000
	BEGIN
		SET @sPids = SUBSTRING(@sPids, 1, LEN(@sPids) - 1)
		SET @nPid = 0
	END
	ELSE
	IF LEN(@sPids) <= 1
	BEGIN
		SET @sPids = ''
		SET @nPid = -10
	END
	ELSE
	BEGIN
		SET @sPids = ''
		SET @nPid = 0
	END
	DROP TABLE #TMPP

/*在途数量*/	
SELECT billid,YGuid INTO #TmpA FROM billidx a where billtype = 152 AND billstates = 0 
SELECT YGuid INTO #TmpB FROM billidx a where billtype = 162 AND billstates = 0
SELECT billid INTO #TmpC FROM #TmpA WHERE YGuid NOT IN (SELECT YGuid FROM #TmpB)    
    
select p_id,sum(quantity) as ZTquantity,sum(taxtotal) as ZTtaxtotal,sum(costtaxtotal) as ZTcosttaxtotal,p.class_id as pclass_id,c.company_id into #ztTable from 
                    #TmpC a left join salemanagebill s on a.billid = s.bill_id 
                    left join storages st on s.sd_id = st.storage_id
                    left join Products p on s.p_id = p.product_id
                    left join company c on  c.company_id = st.Y_ID
                    where (@YID = 0 or c.company_id = @YID) and c.parent_id <> '0'
                    group by p_id,p.class_id,c.company_id

	SELECT     i.billnumber, b.p_id, i.billdate, y.name AS YName, p.name AS PName, p.alias, p.standard, u.name AS UName, b.quantity, b.ComeQty, isnull(s.qty, 0) as qty, 
						  b.comment, b.smb_id, i.c_id, p.makearea, p.serial_number, ISNULL(md.mdqty, 0) AS mdqty,ISNULL(o.OOSQty,0) as OOSQty, ISNULL(PK.YQTY, 0) AS PickQty,
						  ISNULL(B.quantity, 0) - ISNULL(PK.ComeQty, 0) AS WaitQty,isnull(f.AccountComment,'') as Factory,isnull(ZTquantity,0) as ZTquantity,isnull(ZTtaxtotal,0) as ZTtaxtotal
	FROM         dbo.TranBill AS b INNER JOIN
						  dbo.TranIdx AS i ON b.bill_id = i.billid INNER JOIN
						  dbo.company AS y ON i.c_id = y.company_id INNER JOIN
						  dbo.products AS p ON b.p_id = p.product_id INNER JOIN
						  dbo.unit AS u ON p.unit1_id = u.unit_id LEFT OUTER JOIN
						  /*一张单据可以分多次拣货，如果不进行quantity-ComeQty OrgBillid的数量quantity会一直递增*/
						  /*而非原来实际请货数量*/
						  (SELECT OrgBillid, SUM(OrderBill.quantity)-SUM(OrderBill.ComeQty) AS Yqty,SUM(OrderBill.ComeQty) AS ComeQty FROM dbo.OrderBill INNER JOIN dbo.orderidx ON billid = bill_id WHERE BillType = 154
							GROUP BY OrgBillid) pk
						  ON b.smb_id = pk.OrgBillid LEFT OUTER JOIN
						 (SELECT SUM(OOSQty) AS OOSQty, GUID FROM OOSCatalog GROUP BY GUID) o on o.GUID = b.RowGuid left outer join
							  (SELECT     SUM(h.quantity) AS qty, h.p_id
								FROM          dbo.FN_GetAvlqty(@nPid, 0, @sPids, 0) AS h INNER JOIN
													   dbo.storages AS r ON h.s_id = r.storage_id
								WHERE      (r.flag = 0) AND (r.Y_ID = 2) and h.storeQty > 0 and r.qualityFlag <> 1 /*剔除不合格品库*/
								            and r.WholeFlag<>3 /*zjx--tfs45072--2017-01-18--剔除拆零商品*/
								/*过滤掉已过效期的商品*/
								and (validdate<10 or validdate>GETDATE()) 	
								and DATEDIFF ( d , GETDATE(),case when validdate='1900-01-01 00:00:00.000' then '9999-01-01 00:00:00.000' else validdate end)>0
								GROUP BY h.p_id) AS s ON b.p_id = s.p_id LEFT OUTER JOIN
						(SELECT     sh.p_id, cy.company_id, SUM(sh.quantity) AS mdqty
							FROM         dbo.company AS cy INNER JOIN
												  dbo.storehouse AS sh ON cy.company_id = sh.Y_ID
							GROUP BY sh.p_id, cy.company_id) AS md ON i.c_id = md.company_id AND b.p_id = md.p_id
							LEFT JOIN BaseFactory F ON P.factoryc_id = f.CommID
							LEFT JOIN #ztTable z ON b.p_id = z.p_id AND i.c_id = z.company_id
	WHERE     (i.billtype = 52) AND (i.billstates IN ('3', '0')) AND (i.c_id = @YID OR @YID = 0)
		AND (i.billdate BETWEEN @BeginDate AND @EndDate) AND i.CenterAuditMan > 0
		AND i.c_id <> 2
		and p.deleted <> 5 /*智能配货过滤停止配送商品*/
		and  (@SZPtype = '' or p.product_id in (select p_id from  #PORDUCTS))
	ORDER BY i.billid
    IF object_id(N'#PORDUCTS', N'U') is not null  
    DROP TABLE #PORDUCTS    
END
GO
