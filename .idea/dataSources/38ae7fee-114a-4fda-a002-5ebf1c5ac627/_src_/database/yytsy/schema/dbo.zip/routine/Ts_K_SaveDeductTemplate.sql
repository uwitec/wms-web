
CREATE PROCEDURE Ts_K_SaveDeductTemplate(
    @TId            INT = 0,            /* 等于0新增，反之为修改*/
    @Type           INT = 0,            /*提成模板类型: 0 职员；1 机构*/
    @Name           VARCHAR(100) = '',
    @Comment        VARCHAR(200) = '',
    @YId            INT = 2,
    @CreateEId      INT = 0,
    @BaseInfoId     VARCHAR(3000) = '', /*提成模板支持计算的职员或分支机构Id*/
    @TempBase       NUMERIC(18,4) = 0.0,
    @nRet            INT = 0 OUTPUT 
)
AS
BEGIN
	IF @TId > 0
	BEGIN
		UPDATE Deduct_Template
			SET [Type] = @Type, Name = @Name, Comment = @Comment, YId = @YId, ModifyDate = GETDATE(), ModifyEId = @CreateEId, TempBase = @TempBase
		WHERE TId = @TId
		SET @nRet = @TId			
	END
	ELSE
	BEGIN
		INSERT INTO Deduct_Template([Type], Name, Comment, YId, CreateDate, CreateEId, ModifyDate, ModifyEId,TempBase)
		VALUES(@Type, @Name, @Comment, @YId, GETDATE(), @CreateEId, GETDATE(), @CreateEId, @TempBase)
		SET @nRet = @@identity
	END	
	
	IF @TId > 0 
	BEGIN
	    DELETE FROM Deduct_TemplateIds WHERE TId = @TId        	
	END
	
	INSERT INTO Deduct_TemplateIds(TId, BaseInfoId)
	SELECT @nRet, [str] From dbo.[Split](@BaseInfoId, ',')
END
GO
