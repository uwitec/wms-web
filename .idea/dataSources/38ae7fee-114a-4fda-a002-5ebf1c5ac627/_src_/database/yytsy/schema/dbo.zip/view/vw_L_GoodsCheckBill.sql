
CREATE VIEW dbo.vw_L_GoodsCheckBill
AS

  SELECT G.* ,
      
  ISNULL(P.class_id,'')Pclass_ID, ISNULL(P.[name],'')Pname,
  ISNULL(SS.Class_id,'')SSclass_ID, ISNULL(SS.[name],'')SSname,
  ISNULL(SD.Class_id,'')SDclass_ID, ISNULL(SD.[name],'')SDname,
  ISNULL(SL.class_id,'')SLClass_ID,ISNULL(SL.[name],'')SLname

  FROM  GoodsCheckBill G
  


   LEFT OUTER JOIN  products   P  ON G.p_id=P.product_id
   LEFT OUTER JOIN  storages   SS  ON G.ss_id=SS.storage_id
   LEFT OUTER JOIN  storages   SD  ON G.ss_id=SD.storage_id
   LEFT OUTER JOIN  clients    SL ON G.supplier_id=SL.client_id
   LEFT OUTER JOIN  location   L  ON G.location_id=L.loc_id
GO
