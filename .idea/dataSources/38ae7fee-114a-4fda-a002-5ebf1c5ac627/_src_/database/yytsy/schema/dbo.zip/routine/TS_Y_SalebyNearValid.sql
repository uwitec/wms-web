
/* =============================================*/
/* Author:		<yh>*/
/* Create date: <2014-01-05>*/
/* Description:	<近效期药品销售分析（零售）>*/
/* =============================================*/
CREATE PROCEDURE TS_Y_SalebyNearValid(
        @BeginDate 		  VARCHAR(10)='',
	    @EndDate	 	  VARCHAR(10)='',
	 	@nPID			  INT=0,
	    @nY_id            int=0,
        @nDay             int=0,/*近效期天数*/
        @productRange     int=0,/*药品类别*/
        @nloginEID        int=0

)
as
BEGIN
	/* SET NOCOUNT ON added to prevent extra result sets from*/
	/* interfering with SELECT statements.*/
	 SET NOCOUNT ON;
	 
   Declare @Companytable varchar(100)
   
	  if OBJECT_ID('tempdb..#Companytable') is not null
    drop table #Companytable 
   create table #Companytable([id] int)
   
	 /*---分支机构授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
       or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
    begin
       set @Companytable=0
    end
    else
    begin
       set @Companytable=1     
       Insert #Companytable ([id]) select Company_id from Company C where 
       exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
    end
   select a.Y_ID,a.billnumber,a.billdate,a.inputman,a.billtype,a.billid,a.saleman,a.Code,a.Alias,a.Standard,a.MakeArea,a.rangename,
   a.uname,a.batchno,a.validdate,a.storagename,a.quantity,a.saleprice,a.costprice,a.taxtotal,a.instoretime from 
   ( 
     select b.Y_ID, b.billnumber,b.inputman, b.billdate,b.billid,b.billtype,e.name AS saleman, p.Code,p.alias,p.standard,p.makearea,p.rangename,/*药品类别*/
     u.name AS uname, s.batchno,s.validdate,g.name as storagename,s.quantity,s.costprice,s.saleprice,s.taxtotal,s.instoretime from salemanagebill as s 
     left join dbo.billidx        as b on b.billid=s.bill_id
     left join dbo.vw_c_products  as p on p.product_id=s.p_id
     left join dbo.storages       as g on b.c_id=g.storage_id
     left join dbo.employees      as e on e.emp_id=b.e_id
     left join dbo.unit           as u on u.unit_id=s.unitid
     where b.billtype=12 and b.billstates=0  and s.p_id>0
     and b.Y_id=@nY_id 
     and s.validdate<convert(varchar(10),dateadd(day,@nDay,getdate()),20) 
     and s.validdate>convert(varchar(10),getdate(),20) 
     and ((@nPID=0)or (s.p_id=@nPID))
     and  b.[Billdate] BETWEEN @BeginDate AND @EndDate
     and (@ProductRange=0 or p.SR2_id=@ProductRange)
     ) as a    where ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))
END
GO
