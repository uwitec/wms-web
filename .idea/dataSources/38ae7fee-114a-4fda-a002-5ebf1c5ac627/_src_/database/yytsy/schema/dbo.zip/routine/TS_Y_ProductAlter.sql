/**********************/
/*****商品GMP证照报警*****/
/*****add by yanrui  2014-04-21*****/
/*********************/


create procedure TS_Y_ProductAlter
(
  @nAlterDay int
)
as
begin

	select serial_number,name,alias,[standard],makearea,MedName,Factory,permitcode,GMPNo,GMPvaliddate
	from vw_Products
	where child_number = 0 and deleted = 0 
	      and (GMPvaliddate <> '1900-01-01' )
		  and (GMPvaliddate <DATEADD(DAY,@nAlterDay,GETDATE()) )
		  
	  
end
GO
