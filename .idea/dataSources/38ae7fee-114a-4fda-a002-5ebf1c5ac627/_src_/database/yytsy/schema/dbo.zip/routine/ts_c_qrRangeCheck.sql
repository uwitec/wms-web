/*exec ts_c_qrRangeCheck 2,2,0*/
/* 	0	符合经营范围*/
/* 	-1	往来单位超出经营范围*/
/*	-2	自己超出经营范围*/
/*	-3  分支机构超出经营范围*/
CREATE PROC ts_c_qrRangeCheck(@nC_id INT, @nP_id INT, @nCType INT)
/*with encryption*/
AS
SET NOCOUNT ON 
DECLARE @iReturn INT
DECLARE @nCeType INT /* 所属类型*/
declare @RangClassid varchar(2000) /*zhangw 2017-08-17 tfs 50458 处理经营范围过长提示超过范围*/
SET @nCeType = -1
set @iReturn = 0
		IF @nCType = 0
		BEGIN
			SELECT @nCeType = ent_type FROM clients WHERE client_id = @nC_id
			IF @nCeType = 1
			BEGIN
				IF EXISTS(SELECT 0
					FROM dbo.GMPMedtype AS M INNER JOIN
					dbo.GMPIndex AS A ON M.ga_id = A.g_id INNER JOIN
					(select a.id,b.p_id as baseinfo_id from  customCategory a inner join ProductCategory b on a.class_id=b.PComent3) p on M.mt_id=p.id
					/*dbo.products AS P ON M.mt_id = P.medtype*/
					WHERE A.c_id = @nC_id AND P.baseinfo_id = @nP_id)
					SET @iReturn = 0
				ELSE
					SET @iReturn = -4
			END
			ELSE
			IF @nCeType = 3
			BEGIN
				IF EXISTS(SELECT  1
					FROM      dbo.products AS P INNER JOIN
						(SELECT   cm_id, baseInfoType, info_id, cr_id, cr_class_id
						 FROM      dbo.clinicRangeMapping
						 WHERE   (baseInfoType = 1)) AS PM ON P.product_id = PM.info_id INNER JOIN
						(SELECT   cm_id, baseInfoType, info_id, cr_id, cr_class_id
						 FROM      dbo.clinicRangeMapping AS clinicRangeMapping_1
						 WHERE   (baseInfoType = 2)) AS CM INNER JOIN
					dbo.clients AS C ON CM.info_id = C.client_id ON CM.cr_id = PM.cr_id
					WHERE C.client_id = @nC_id AND P.product_id = @nP_id)
					SET @iReturn = 0
				ELSE
					SET @iReturn = -5
			END
		END

IF @iReturn = 0
BEGIN
	IF EXISTS(SELECT 1 FROM products WHERE product_id = @nP_id) and  exists (select * from ProductCategory a ,customCategory b  where  a.PComent1=b.class_id and  P_id=@nP_id  and baseType=-1)
	BEGIN
		IF EXISTS(SELECT 1 FROM CompanyCategory WHERE Y_id=@nC_id and (YComent1<>'' or YComent1<>'0'))/*如果存在本单位经营范围定义才检查*/
		BEGIN
		    SELECT @RangClassid=YComent1 FROM CompanyCategory where Y_id = @nC_id
			IF EXISTS(
			           select r_id from 
			           (
			            SELECT  r.PComent1 as r_id  FROM ProductCategory r ,customCategory z WHERE  r.PComent1=z.class_id AND r.P_id = @nP_id and z.baseType=-1 

			           ) a where a.r_id in
			           ( 
			             select  szTYPE from  DecodeToStr(@RangClassid)
			            )  
			          ) 
				SELECT @iReturn = 0
			ELSE
				SELECT @iReturn = -2
		END
		ELSE
			SELECT @iReturn = 0
	        
		IF @iReturn = 0
		BEGIN
			IF @nCType = 1 OR @nCeType IN (2, 4)
			
			IF @iReturn = 0
		
            if @nCType=0/*-单位 */
			begin
			  IF  exists (select * from  ClientCategory where   C_id=@nC_id and (CComent1<>'' or CComent1<>'0')) /*如果存在经营范围定义才检查*/
				BEGIN
					SELECT @RangClassid=CComent1 FROM ClientCategory where c_id = @nC_id
			        IF EXISTS(
			           select r_id from 
			           (
			            SELECT  r.PComent1 as r_id  FROM ProductCategory r ,customCategory z WHERE  r.PComent1=z.class_id AND r.P_id = @nP_id and z.baseType=-1 

			           ) a where a.r_id in
			           ( 
			             select  szTYPE from  DecodeToStr(@RangClassid)
			            )  
			          ) 
				      SELECT @iReturn = 0
					ELSE
					BEGIN	
						IF @nCType = 0  /* 0往来单位对应的 customCategoryMapping里面BaseTypeid=1 就代表机构*/
							SELECT @iReturn = -1
					END
				END
				ELSE
					SELECT @iReturn = 0 
		   end
		   else
		   begin
		        IF  exists (select * from CompanyCategory  where Y_id=@nC_id and (YComent1<>'' or YComent1<>'0')) /*如果存在经营范围定义才检查*/
				BEGIN
					  SELECT @RangClassid=YComent1 FROM CompanyCategory where Y_id = @nC_id
			          IF EXISTS(
			           select r_id from 
			           (
			            SELECT  r.PComent1 as r_id  FROM ProductCategory r ,customCategory z WHERE  r.PComent1=z.class_id AND r.P_id = @nP_id and z.baseType=-1 

			           ) a where a.r_id in
			           ( 
			             select  szTYPE from  DecodeToStr(@RangClassid)
			            )  
			          ) 
				      SELECT @iReturn = 0
					ELSE
					BEGIN	
						  IF @nCType = 1  /*机构 对应的 customCategoryMapping里面BaseTypeid=2 就代表机构*/
							SELECT @iReturn = -3
					END
				END
				ELSE
					SELECT @iReturn = 0 
		   end
		END
	END
	ELSE
		SELECT @iReturn = 0	
END
	RETURN @iReturn
GO
