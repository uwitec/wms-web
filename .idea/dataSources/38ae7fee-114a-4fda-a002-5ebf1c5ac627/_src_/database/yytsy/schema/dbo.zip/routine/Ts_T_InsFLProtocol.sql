 Create procedure [dbo].[Ts_T_InsFLProtocol]
 ( @serial_number varchar(30),
   @c_id		   int,  
   @CName	       varchar(30),
   @inputman	   int ,
   @signTime	   datetime,
   @content	       text,
   @nRpid          int
 ) 
AS
if @nRpid=0
begin
	insert  RebehoofProtocol([serial_number],[c_id],[CName],[inputman],[signTime]     
	,[content],[States]  
	)						       
	values( @serial_number,
			@c_id,		 
			@CName,	  
			@inputman,	 
			@signTime,	  
			@content,
			0)  
	if @@rowCount=0 
	begin
	 return -1
	end else 
	 return @@IDENTITY
end else
begin
  update RebehoofProtocol 
  set  [serial_number] =@serial_number,
	   [c_id] =@c_id,		 
	   [CName] =@CName,	  
	   [updateman] =@inputman,	 
	   [updateTime] =@signTime,	  
	   [content] =@content
  where id=@nRpid 
  return @nRpid 
end
 GO
