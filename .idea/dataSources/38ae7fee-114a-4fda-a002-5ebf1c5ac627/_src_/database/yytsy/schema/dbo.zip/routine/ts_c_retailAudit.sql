

/*
-102 单据保存出错
--zhoujilin 2010-08-02修改
*/

CREATE proc ts_c_retailAudit
(
	@nBillId int,
	@nP_id int output,
	@nReturnNumber int output,
	@nVchtype int,
	@nUpFlag int = 0    /*--是否是上传单据，避免计算积分时重复扣减储值金额  1 :是, 0 : 不是*/
)
as

set nocount on

/*零售过账，单独处理*/
declare @nDraftBillid int, @nNewBillId int
declare @tBillDate datetime,@tBeginDate datetime,@tAuditDate datetime
declare @nDep_id int,@nRegion_id int,@nPeriod int, @nBilltype int
declare @totalmoney NUMERIC(25,8),@billguid varchar(50)
declare @Y_id int,@billdateAudit int
declare @nIntergalYE NUMERIC(25,8)/*单据积分余额*/
declare @intergal int, @vipCardID int /*积分处理*/
declare @dicount NUMERIC(25,8), @isBank int/*会员卡所有商品折扣*/
declare @ArApTotal NUMERIC(25,8)  /*标识是否已计算过积分*/
declare @nNewYBillId int
declare @cashcouponid int /*代金券会计科目ID*/
declare @DetailCount int
declare @IAodId int /*8诊疗费用单存入到RETAILIDX表中AOID等于8*/

	set @billguid=''
	set @totalmoney= 0 

        if @nVchtype not in (12,13,240,243)
        begin
          select @nReturnNumber=-6  /*异常错误*/
	      return 0		
        end
  
    select @Y_id = CAST(sysvalue as int) from sysconfig where [sysname] = 'Y_ID'    
	select @tBeginDate=begindate from MonthSettleInfo where monthname='本期' and Y_id=@Y_id
	if exists(select 1 from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id)
	  select @nPeriod=cast(sysvalue as int) from sysconfig where [sysname]='AccountPeriod' and y_id = @y_id
	else set @nPeriod = 1

	if @tBillDate<@tBeginDate 
	begin 
		select @nReturnNumber=-100
		if @nVchtype in (12, 13)
		begin
			delete from retailbillidx where billid=@nBillid
			delete from retailbill where bill_id=@nBillid
		end
		else
		begin
			delete from billdraftidx where billid=@nBillid
			if @nVchtype = 240
				delete from registerbilldrf where bill_id=@nBillid
			else
			if @nVchtype = 243
				delete from retailclinicbilldrf where bill_id=@nBillid
		end
		return 0
	end  
	
	if (@nVchtype = 12) and (@nUpFlag = 0)
	begin
	  exec @nReturnNumber = TS_j_CheckCashCoupon 0, 0, 0, @nBillid, 0,0, '', '', '', 1 
	  if  @nReturnNumber < 0
	  begin
	    delete from retailbillidx where billid=@nBillid
	    delete from retailbill where bill_id=@nBillid	
	    return 0
	  end	  
	end

	
	set @nReturnNumber = -1


  
  SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 
  begin tran RetailAudit

        set @nDraftBillid = 0
        
        
        /*保证零售单的表体金额=表头金额*/
        select @totalmoney = isnull(sum(b.taxtotal), 0)
        from retailbillidx a,retailbill b
        where a.billid=b.bill_id and b.p_id>0 and b.AOID in (0,5,8) and a.billid=@nBillId and a.billtype in (12,13, 243)

        update retailbillidx set ysmoney=@totalmoney,ssmoney=@totalmoney
        where billid=@nBillId

        
	exec @nReturnNumber=ts_c_RetailToHis @nBillId,@nDraftBillid output,@nVchtype /*从零售库拷贝到草稿单据库*/
	if @nReturnNumber<>0 goto error
         
        set @nNewBillId = 0
        set @nReturnNumber = -6
	exec @nReturnNumber=ts_c_DraftToHis @nDraftBillid,@nNewBillId output/*从草稿库拷贝到历史单据库*/
	if @nReturnNumber <> 0
	begin
		if @nReturnNumber > 35000000
		begin
			set @nP_id = @nReturnNumber - 35000000
			set @nReturnNumber = -35
		end
		goto error
	end

	/*if @nVchtype = 12*/
	/*begin*/
	/*	exec TS_H_AutoCreateBill @nNewBillId, @nVchtype, @nReturnNumber output*/
	/*	if @nReturnNumber <> 0*/
	/*		goto error*/
	/*end*/
	
	SELECT @nRegion_id = c.region_id, @nDep_id = e.dep_id 
		FROM billidx b 
		INNER JOIN clients c ON b.c_id = c.client_id 
		INNER JOIN employees e ON b.e_id = e.emp_id 
	WHERE b.billid = @nNewBillId
	if @nRegion_id is null select @nRegion_id=0
	if @nDep_id is null select @nDep_id=0

        /*update retailmerge set draft=0 where newbillguid=@billguid and draft=1(在以后版本，独立账套时处理)  */

	select @nBilltype =billtype, @ArApTotal=ArApTotal,@billguid=guid,@intergal = order_id,@vipCardID =vipcardid,@totalmoney =ssmoney ,@nIntergalYE =invoicetotal from billidx where billid=@nNewBillId
	select @dicount=ct.Discount, @isBank = ct.isBank from VIPCardType ct,Vipcard V where V.ct_id=ct.ct_id and v.VIPCardID= @vipcardid

	if @nBilltype in(12,13,243) and  @vipCardID <> 0 and @ArApTotal=0
	begin
          /*
	  if exists(select 1 from salemanagebill s, CTIntegralOther ct, VIPCard V,billidx b where b.billid=s.bill_id  and v.ct_id=ct.ct_id and b.VIPCardID=v.vipcardid and billid=@nNewBillId)
          begin        
		    execute ts_c_VipIntergral @nNewBillId,@nBilltype,0 ,@nUpFlag
		    if @@error<>0 goto error	
          end else
          begin
            exec  ts_c_TheAllVipIntergral  @nNewBillId,@nBilltype,0 ,@nUpFlag
            if @@error<>0 goto error	
          end
          */                      
	      update billidx set ArApTotal=1 where billid=@nNewBillId	         
	end

	if exists(select 1 from sysconfig where [sysname] = 'PosDataMode' and sysvalue = '2')
	  if exists(select 1 from sysconfig where [sysname] = 'YclassID' and sysvalue <> '000001')
          begin
	         set @nReturnNumber = -6	        	       	  
	         insert into upbilllist(mdbillid, y_id)
	         select @nNewBillId, @Y_id	         	          	      	                           
          end
	
	delete from billdraftidx where billid=@nDraftBillid /*删除原草稿单据*/
    
	exec ts_getsystmpvalue 'billdateAudidate',2,@billdateAudit out
        if @billdateAudit is null set @billdateAudit =0 
    
        Select @tAuditDate=getdate()
	
	IF ISNULL(@billdateAudit,0)=0
	  update billidx set billstates='0',period=@nPeriod,AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	    where BillId=@nNewBillId
	ELSE
          update billidx set billstates='0',period=@nPeriod,billdate=left(@tAuditDate,10),AuditDate=@tAuditDate,region_id=@nREgion_id,department_id=@nDep_id
	    where BillId=@nNewBillId

	/*修改零售过账状态*/
	if @nVchtype in (12,13)
	begin
        update retailbillidx set billstates='0' where billid=@nBillid
		if @@error<>0 goto error
	
		set @nReturnNumber = -6
		exec @nReturnNumber=ts_c_CreatePDetail @nNewBillId /*产生商品明细账*/
		if @@error<>0 goto error
		if @nReturnNumber<>0 goto error
			   
		set @nReturnNumber = -6
		exec ts_c_AuditP @nNewBillId,@nP_Id out,@nReturnNumber out /*商品登账*/
		if @@error<>0 goto error
		if @nReturnNumber<>0 goto error
		
		set @DetailCount = 0
	    select @DetailCount = COUNT(1) from productdetail where billid  = @nNewBillId
	    if @DetailCount is null set @DetailCount = 0	 
	    update billidx set detailcount  =	@DetailCount where billid  = @nNewBillId
	    set @IAodId = 0
	    select @IAodId=AOID from retailbill where bill_id=@nBillid  and  p_id>0
	    /*yypeng-2017-03-16 09:56:15- 存在零售单过账没有写PRODUCTDETAIL的情况，暂时在这里做个日志检测，其他地方都已检测过了*/
	    if (@DetailCount = 0) and (@IAodId<>8)/*如果没有productdetail--zjx--诊疗费用单不会写productdetail所以@DetailCount=0，但这个时候不需要回滚*/
	    begin
				rollback tran RetailAudit
				SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		
				if not exists(select 1 from productdetailtmp where billid=@nBillId)		    
				insert into LostDetailLog( BillID,BillGuid, BillType, y_id, AuditTime, BillNumber, BillDate, ErrMsg)
    			select @nNewBillId,GUID,billtype,Y_ID,GETDATE(),billnumber,billdate,'ts_c_AuditP之后productdetailtmp没有明细'  FROM billidx WHERE billid = @nNewBillId 
    			return -1
    					
	    end
	end
	else
	if @nVchtype in (240,243)
	begin
		delete from salemanagebilldrf where bill_id = @nBillId
		if @@error<>0 goto error
		delete from salemanagebilltmp where bill_id = @nNewBillId
		if @@error<>0 goto error
	end

	set @nReturnNumber = -6
	exec @nReturnNumber=ts_c_CreateADetail @nNewBillId /*产生会计科目明细账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
	/*检查是否存在删除的基本资料*/
	set @nReturnNumber = -6
	exec @nReturnNumber=ts_c_validcheck @nNewBillId,@nbilltype
	if @@error<>0 goto error
	if @nReturnNumber<>0 
	begin
		rollback tran RetailAudit
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return -1
	end
	
	set @nReturnNumber = -6
	exec @nReturnNumber=ts_c_BalanceCheck @nNewBillId /*会计凭证检查*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 
	begin 
		rollback tran RetailAudit
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		return -1
	end
	
	set @nReturnNumber = -6
	exec ts_c_AuditA @nNewBillId,@nReturnNumber out /*科目登账*/
	if @@error<>0 goto error
	if @nReturnNumber<>0 goto error
	
	declare @DepositTotal NUMERIC(25,8)    /*零钱*/
	if @nBilltype = 12 and @vipCardID > 0   /*零售单过账成功后，更新会员零钱*/
	begin
	    if @DepositTotal is null set @DepositTotal = 0	
		select @DepositTotal = sum(isnull(total,0)) from salemanagebill s 
			left join account a on abs(s.p_id) = a.account_id  
			where bill_id = @nNewBillId and a.class_id = '000002000008'	
		if abs(@DepositTotal) >0 	
	      update VIPCard set small = small + @DepositTotal where VIPCardID = @vipCardID
	end
	
	
	declare @RemainderMoney NUMERIC(25,8),   @StoreMoney_ID int
	if @nUpFlag = 0 /*上传单据扣减储值金额 */
    begin
       select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid     */
       select @RemainderMoney= Case when @nBilltype = 13 then -abs(isnull(sum(total),0)) else abs(isnull(sum(total),0)) end from salemanageBill where bill_id=@nNewBillId and p_id=-@StoreMoney_ID        
	   update Vipcard set RemainderMoney=RemainderMoney-@RemainderMoney where VipCardid=@Vipcardid        		 
     end
     	
	if @nBilltype = 12   /*更新代金券使用状态，零售退货不处理代金券*/
	begin	 
	  declare @nUseYid int, @szUseMan varchar(100)
	    select @nUseYid = y_id from billidx where billid = @nNewBillId
	  if @vipCardID > 0 
	    select @szUseMan = '卡号：'+cardno from VIPCard where VIPCardID = @vipCardID
	  else 
	    select @szUseMan = '单位：' +c.name from clients c  inner join billidx bi
	     on bi.c_id = c.client_id where bi.billid = @nNewBillId
	  /*-XXX. 2016-12-21 这儿有可能本地的配置导致这儿取值为null ，为了严谨，增加一个判断   */
	  if @szUseMan is null set @szUseMan = ''
	   		 
	  update Cashcoupon set flag = 5, UseDate = GETDATE(), UseCompany = @nUseYid, UseMan  = @szUseMan 
	   where ccid in (select price_id 
					   from salemanagebill 
					   where bill_id = @nNewBillId and p_id = -9999)
	end
	
 	exec ts_c_deletetmpdetail @nNewBillid
 	
	if @np_id=0 set @nP_id=@nNewBillid
	
	EXEC Ts_K_AfterBillAudit @nBilltype, @nBillId, @nNewBillId /*处理电子监管码*/

        /*---加入新积分计算*/
        exec  @nReturnNumber=Ts_L_findIntegralgz @nNewBillId
        if @@error<>0 goto error
	    if @nReturnNumber<>0
	    begin
		  rollback tran RetailAudit
		  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		  return -26
	    end 
   /*XXX. 2017-04-21 更新实际的积分 */
        update billidx set integral = i.totalItg from Integralidx i   where billidx.billid = @nNewBillId and billidx.billid = i.bill_id and billidx.GUID = i.billguid
        /*--end          */
/* 	--处理电子监管码
	INSERT INTO Sfda_Detail
	SELECT @nNewBillId, Sfda_Code, CASE WHEN @nVchtype = 12 THEN 2 ELSE 1 END FROM RetailBillidx_Sfda WHERE Bill_Id = @nBillId
	--处理电子监管码 */		    
  commit tran RetailAudit
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  return 0


error:
  rollback tran RetailAudit
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED
  delete from retailbillidx where billid=@nBillid
  delete from retailbill where bill_id=@nBillid

  return 0
GO
