
/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-5*/
/* Description:	诊治费用报表*/
/* =============================================*/
CREATE PROCEDURE TS_H_RepClinicSale 
	@BeginTime		datetime,
	@EndTime		datetime,
	@E_ID			int = 0,	/*销售*/
	@InputMan		int = 0		/*收银*/
AS
BEGIN
/*Params Ini begin*/
if @E_ID is null  SET @E_ID = 0
if @InputMan is null  SET @InputMan = 0
/*Params Ini end*/
	SET NOCOUNT ON;

	SELECT     ISNULL(SUM(b.quantity), 0) AS quantity, ISNULL(AVG(b.discountprice), 0) AS discountprice, ISNULL(SUM(b.totalmoney), 0) AS saletotal, ISNULL(AVG(b.saleprice), 0) AS saleprice, p.name, 
						  p.serial_number AS code, u.name AS unitName, ISNULL(CAST(SUM(b.retailtotal) - SUM(b.totalmoney) AS money), 0) AS discounttotal, p.product_id
	FROM         (SELECT     b2.*
			FROM         dbo.salemanagebill AS b2 INNER JOIN
								  dbo.billidx AS i ON b2.bill_id = i.billid
			WHERE     (i.RetailDate > @BeginTime) AND (i.RetailDate < @EndTime) AND i.billstates=0  AND (@InputMan = 0 OR i.inputman = @InputMan) AND (b2.AOID = 8) AND (@E_ID = 0 OR i.e_id = @E_ID)) AS b Right JOIN
									  dbo.SpecialProducts AS p ON b.p_id = p.product_id INNER JOIN
						  dbo.unit AS u ON p.unit_id = u.unit_id
	GROUP BY p.product_id, p.name, p.serial_number, u.name
END
GO
