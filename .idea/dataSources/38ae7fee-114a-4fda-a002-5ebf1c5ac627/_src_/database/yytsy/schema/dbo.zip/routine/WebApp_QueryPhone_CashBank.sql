-- =============================================
-- Author:	<杨林>
-- Create date: <2014-06-04,,>
-- Description:	<手机版本用于安时间段查现金银行的收入和支出情况,,>
-- =============================================
CREATE PROCEDURE [dbo].[WebApp_QueryPhone_CashBank]
(
	@BeginDate datetime , 
	@EndDate datetime ,
	@Params VARCHAR(100)--预留接口进行后期特殊版本传值
)
AS
BEGIN
 select @BeginDate = convert(varchar(10),@BeginDate,20),@enddate=convert(varchar(10),@enddate,20)  
  
 declare @cashini numeric(18,4),
         @bankini numeric(18,4) 
 
  select @cashini = ini_total from Account where  class_id='000001000003' 
  select @bankini = sum(ini_total) from Account where  parent_id like '000001000004%' -- and deleted<>1 
  
	DECLARE @y_id INT 
	SET @y_id = 0
	SELECT @y_id = dbo.webapp_get_param(@Params, 'y_id', default, default)
	SET @y_id = 2 --yyt调试用，正式发须去掉 
  
 select 1 as 'NO.',cast('此前余额' as nvarchar) Rowtype,  
    (select cast(isnull(@cashini,0) + isnull(sum(jdmoney),0) as numeric(18,4))  
       from Account a,accountdetail d,billidx b   
      where d.a_id=a.account_id and class_id='000001000003'   
                      and b.billid=d.billid  and billstates=0  
                      and convert(varchar(10),b.billdate,20)<@BeginDate) cash,  
    (select cast(isnull(@bankini,0) + isnull(sum(jdmoney),0) as numeric(18,4))    
       from Account a,accountdetail d,billidx b   
      where parent_id like '000001000004%' and d.a_id=a.account_id   
                      and b.billid=d.billid and billstates=0  
                      and convert(varchar(10),b.billdate,20)<@BeginDate) bank  
 union  
 select 2 as 'NO.',cast('收入' as nvarchar) Rowtype,  
     (select cast(isnull(sum(jdmoney),0)  as numeric(18,4))  
        from accountdetail d,account a ,billidx b  
       where d.a_id=a.account_id and a.class_id='000001000003'and jdmoney>0   
                       and b.billid=d.billid 
                       and b.billstates=0  
                       and convert(varchar(10),b.billdate,20) between @begindate and @enddate                       
   ) as Cash,  
     (select cast(isnull(sum(jdmoney),0)  as numeric(18,4))  
        from accountdetail d,account a,billidx b   
       where d.a_id=a.account_id and a.parent_id like '000001000004%' and jdmoney>0   
                       and b.billid=d.billid   
                       and b.billstates =0   
                       and convert(varchar(10),b.billdate,20) between @begindate and @enddate               
                    ) as bank   
  
 union  
 select 3 as 'NO.',cast('支出' as nvarchar) Rowtype,  
     (select cast(isnull(sum(-jdmoney),0)  as numeric(18,4))  
   from accountdetail d,account a ,billidx b  
   where d.a_id=account_id and a.class_id='000001000003'  and jdmoney<0   
                          and b.billid=d.billid   
                          and b.billstates = 0  
                          and convert(varchar(10),b.billdate,20) between @begindate and @enddate  
   ) as Cash,  
     (select cast(isnull(sum(-jdmoney),0)  as numeric(18,4))  
   from accountdetail d,account a,billidx b  
   where d.a_id=account_id and a.parent_id like '000001000004%' and jdmoney<0   
                          and b.billid=d.billid   
                          and b.billstates = 0  
                          and convert(varchar(10),b.billdate,20) between @begindate and @enddate  
                        ) bank    
 union          
 select 4 as 'NO.',cast('当前余额' as nvarchar) Rowtype,  
              (select cast(cur_total as numeric(18,4))  from Account where class_id='000001000003') cash,  
              (select cast(isnull(sum(cur_total),0.0) as numeric(18,4))   from Account where parent_id like '000001000004%') bank

END
GO
