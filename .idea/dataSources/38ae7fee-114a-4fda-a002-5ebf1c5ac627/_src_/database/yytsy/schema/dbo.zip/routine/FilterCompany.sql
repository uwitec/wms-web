CREATE FUNCTION FilterCompany(@Y_ID int)
RETURNS  table 
AS  
         RETURN
         (SELECT distinct c.*,
         isnull(YB.credit_total,0)credit_total,isnull(YB.sklimit,0)sklimit,isnull(YB.artotal,0)artotal,
         isnull(YB.artotal_ini,0)artotal_ini,  isnull(YB.aptotal,0)aptotal,isnull(YB.aptotal_ini,0)aptotal_ini,
         isnull(YB.pre_artotal,0)pre_artotal,  isnull(YB.pre_artotal_ini,0)pre_artotal_ini,
         isnull(YB.pre_aptotal,0)pre_aptotal,  isnull(YB.pre_aptotal_ini,0)pre_aptotal_ini,
         Ytypename=(case when c.Ytype=0 then '分公司'  when c.Ytype=1 then '自营店' when c.Ytype=2 then '加盟店'  when c.Ytype=3 then '内部机构' end),
         isnull(Y.name,'') as superiorname,SwarajPriceName=(case when c.swarajPrice=1 then '独立物价' when c.swarajPrice=0 then '总部物价' end),
         isnull(g.d1, '1900-01-01') as d1, 		isnull(g.d2, '1900-01-01') as d2,
		 isnull(g.d5, '1900-01-01') as d5, 		isnull(g.d8, '1900-01-01') as d8,
		 isnull(g.d9, '1900-01-01') as d9, 		isnull(g.d10, '1900-01-01') as d10,
		 isnull(g.d11, '1900-01-01') as d11,    isnull(g.d12, '1900-01-01') as d12,
		 isnull(g.d13, '1900-01-01') as d13,    isnull(g.d14, '1900-01-01') as d14,
	     isnull(g.d15, '1900-01-01') as d15,    isnull(g.d16, '1900-01-01') as d16,
	     isnull(r.name,'') as rname,
	     isnull(c.SendPriceType,0) as CompanyPriceType,
	     (case isnull(c.SendPriceType,0)
	       when 0 then '[无]'
	       when 1 then '预设售价1'
	       when 2 then '预设售价2'
	       when 3 then '预设售价3'
	       when 4 then '会员价'
	       when 5 then '国批价'
	       when 6 then '国零价'
	       when 7 then '特价'
	       when 8 then '最近进价'
	       when 9 then '零售价'
	       when 10 then '成本价'
	       end) as SendPriceTypeName,
		   (Case c.AuditStates when 1 then '已审核' else '未审核' end) as AuditStatesStr,
		   (case c.AuditStates when 1 then st.AuditEName else '' end) as AuditEName,
		   (Case c.AuditStates when 1 then st.AuditDate else '' end) as AuditDate,
		   ISNULL(sm.name, '') as shopmastername,isnull(mc.RoadID,0) as IRoadID,isnull(sd.RoadName,'无') as RoadName  
         FROM dbo.company Y
         right  join company c on Y.company_id = c.superior_id 
         left   join   gspalert g on c.Company_id = g.c_id and g.mt_id=0 and g.CType=1 
         left   join  region r  on c.region_id = r.region_id
         left   join  employees sm on c.shopmaster = sm.emp_id
         left   join  WMSCompany mc on c.company_id=mc.Company_ID 
         left   join  sendRoad  sd on mc.RoadID=sd.RoadID
         left join (
	                    select magbillid,e.name as AuditEName,updatedate as AuditDate 
	                    from  sysTnotes st left join employees e on updateman = e.emp_id 
	                    where billtype = 2 
	                    and exists(select 1 from 
	                                    (
	                                      select max(nid) as nid, magbillid,max(updatedate) as sysTnotes from  sysTnotes  
                                          where notes = '【审核】' and billtype = 2 group by magbillid 
	                                    ) st1 where st.nid = st1.nid )
	                 ) st on c.company_id = st.magbillid 
         Left Join 
         (select C_id,MAX(credit_total)credit_total,MAX(sklimit)sklimit,sum(artotal)artotal,sum(artotal_ini)artotal_ini,
                 sum(aptotal)aptotal ,sum(aptotal_ini)aptotal_ini ,sum(pre_artotal)pre_artotal
                 ,sum(pre_artotal_ini)pre_artotal_ini,sum(pre_aptotal)pre_aptotal,sum(pre_aptotal_ini)pre_aptotal_ini
          from Companybalance where Y_id =@Y_ID  Group by C_id )YB on YB.c_id=c.company_id
         )
GO
