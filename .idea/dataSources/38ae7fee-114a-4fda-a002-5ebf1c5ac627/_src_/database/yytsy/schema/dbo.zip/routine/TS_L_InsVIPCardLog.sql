
CREATE PROCEDURE TS_L_InsVIPCardLog
  @ntag   int=0,
  @eid    int ,
  @Computer varchar(50),

  @VIPCardID int,
  @NowIntegral int,
  @ModIntegral int,
  @NowMoney  numeric(12,4),
  @ModMoney numeric(12,4),
  @NewVIPCardID int,
  @Comment varchar(100)
/*with encryption*/
AS
/*Params Ini begin*/
if @ntag is null  SET @ntag = 0
/*Params Ini end*/
/*会员卡日志*/
DECLARE @szSQL varchar(8000) , @ActName  varchar(50)

if @ntag=0 set @Actname='新增'
if @ntag=1 set @Actname='修改'
if @ntag=2 set @Actname='删除'
if @ntag=3 set @Actname='停用'
if @ntag=4 set @Actname='启用'
if @ntag=5 set @Actname='挂失'
if @ntag=6 set @Actname='解挂'
if @ntag=7 set @Actname='锁定'
if @ntag=8 set @Actname='解锁'
if @ntag=9 set @Actname='积分清零'
if @ntag=10 set @Actname='换卡'
if @ntag=11 set @Actname='积分修改'
if @ntag=12 set @Actname='完成未确认操作'
if @ntag=13 set @Actname='金额升级'
if @ntag=14 set @Actname='积分升级'

if @ntag=15 set @Actname='零售单'
if @ntag=16 set @Actname='零售退货单'
if @ntag=17 set @Actname='储值单'
if @ntag=18 set @Actname='积分兑换单'


if @ntag=19 set @Actname='零售单红冲'
if @ntag=20 set @Actname='零售退货单红冲'
if @ntag=21 set @Actname='储值单红冲'
if @ntag=22 set @Actname='积分兑换单红冲'

if @ntag=23 set @Actname='储值升级'



Insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NowIntegral,ModIntegral,NowMoney,ModMoney,NewVIPCardID,Comment) 
      values( @eid,@Computer,@ActName,convert(varchar(10),getdate(),20),@VIPCardID,@NowIntegral,@ModIntegral,@NowMoney,@ModMoney,@NewVIPCardID,@Comment)
GO
