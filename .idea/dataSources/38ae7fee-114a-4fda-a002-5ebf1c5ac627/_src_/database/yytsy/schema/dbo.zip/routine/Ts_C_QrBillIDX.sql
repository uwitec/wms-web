




/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************
历史单据和草稿查询
@BeginDate   开始时间
@EndDate		 结束时间
@szBillType  单据类型
@nC_id			 客户的ID号
@nE_id			 职员的ID号
@nSs_id 		 经手人ID号
@nSd_id 		 审核人ID号
@PosId			 0 配送中心单据，<>0 门店单据
@cMode			 0 以单据日期来过滤, 1以单据过帐日期过滤
@nFlag			 0 已过帐单据, 1草稿 2 上传未成功的零售类单据
@nZd_id			 制单人ID号

********************************************/
CREATE PROCEDURE [Ts_C_QrBillIDX]
(	@BeginDate  DATETIME=0,
	@EndDate		DATETIME=0,
	@szBillType VARCHAR(1000)='',
	@nC_ID			INT=0,
	@nE_ID			INT=0,
	@nSs_ID 		INT=0,
	@nSd_ID 		INT=0,
	@PosId			INT=0,
	@cMode			INT=0,
	@nFlag			INT=0,
	@nZd_ID			INT=0,
	@nCompanyClass_id       varchar(50)='',
    @nloginEID              int=0,
    @Searchtype             int=0,
    @isUpdate               int=0,
	@nY_ID			INT=0,
	@SendC_id       int=0
)
/*with encryption*/
AS 
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szBillType is null  SET @szBillType = ''
if @nC_ID is null  SET @nC_ID = 0
if @nE_ID is null  SET @nE_ID = 0
if @nSs_ID is null  SET @nSs_ID = 0
if @nSd_ID is null  SET @nSd_ID = 0
if @PosId is null  SET @PosId = 0
if @cMode is null  SET @cMode = 0
if @nFlag is null  SET @nFlag = 0
if @nZd_ID is null  SET @nZd_ID = 0
if @nCompanyClass_id is null  SET @nCompanyClass_id = ''
if @nloginEID is null  SET @nloginEID = 0
if @Searchtype is null  SET @Searchtype = 0
if @isUpdate is null  SET @isUpdate = 0
if @nY_ID is null  SET @nY_ID = 0
if @SendC_id is null  SET @SendC_id = 0
/*Params Ini end*/
SET NOCOUNT ON

  IF @nCompanyClass_id<>'' select @nCompanyClass_id=@nCompanyClass_id+'%'
  else  select @nCompanyClass_id='%%'  
  
  DECLARE @SQLScript VARCHAR(8000),@szwhere varchar(8000),@SQLScript2 varchar(8000),@SQLScript3 varchar(8000),
  @szC_ID VARCHAR(30), @szE_ID VARCHAR(30), @szY_ID VARCHAR(100)
  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  /*set @szC_ID='' set @szE_ID='' set @szY_ID=''*/
  SELECT @szC_ID=[Class_ID] FROM Clients WHERE [Client_ID]=@nC_ID
  SELECT @szE_ID=[Class_ID] FROM Employees WHERE [Emp_ID]=@nE_ID
  SELECT @szY_ID=[Class_ID] FROM Company WHERE [Company_ID]=@nY_ID
 

  Declare @Filtertype varchar(100)
  select @Filtertype=''
/*
  if @Searchtype=0
     select @Filtertype=''
  else if @Searchtype=1
     select @Filtertype=' and b.billtype not in (150,151,155,160,161,165) '
  else if @Searchtype=2
     select @Filtertype=' and b.billtype in (150,151,155,160,161,165) '
*/
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)
/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
     Insert #Clienttable ([id]) select 0
   end
/*---往来单位授权*/

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
      Insert #Companytable ([id]) select 0
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
     set @Storetable=0
   end
   else
   begin 
     set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
      Insert #storagestable ([id]) select 0
   end
/*---仓库授权*/


  IF @nCompanyClass_id<>'' select @nCompanyClass_id=@nCompanyClass_id+'%'
    else  select @nCompanyClass_id='%%'


  IF  @nFlag=0
  BEGIN

     SELECT  @SQLScript=' SELECT  DISTINCT 
        b.billID, b.billtype, b.billdate, b.billstates, b.billnumber, b.skdate,
        b.inputman, b.auditman, b.GatheringMan, 
        CASE WHEN b.billtype=12 THEN dbo.FN_DRNoteMark(b.billid) else b.note end note, b.SUMmary, b.quantity, 
        ysmoney=case  when b.billtype in (11,13,21,23,24,25,54,111,121,211,221,153,151) then -b.ysmoney else b.ysmoney end, 
        --case  when b.billtype in (11,13,21,24,25,54,111,121,211,221) then -b.ssmoney else b.ssmoney end as ssmoney,
        (case when b.billtype in (11,13,21,23,24,25,54,111,121,211,221) or (b.billtype = 23 and b.ysmoney < 0) or (b.billtype =15 and b.ysmoney <0)  
        then -(abs(ysmoney)-abs(jsye)) else (abs(ysmoney)-jsye) end)  as ssmoney, 
        b.araptotal, b.taxrate, b.auditdate, 
        b.[sout_id], b.[sin_id],b.Yname,
        (case when billtype in (122,112) then '' '' else b.[ssname] end)ssname ,
        (case when billtype in (122,112) then '' '' else b.[sdname] end)sdname,
        CASE WHEN b.billtype IN (44, 45) THEN b.ssname when b.billtype in (171,172,173,174) Then '''' ELSE b.cname END AS cname,b.transflag,
    		b.ename AS employeename, 
    		b.auditmanname,
    		b.inputmanname,
    		b.aname AS accountname,
    		b.departmentname,
    		b.regionname,
		b.GatheringManName,
        isnull(p.printcount,0) as printcount,isnull(b.sendcname,'''') as sendcname,b.DiscountTotal,
        b.Y_id ,b.guid, b.importjscw,
        case b.B_CustomName1 when ''0'' then '''' else b.B_CustomName1 end  as B_CustomName1, 
        case b.B_CustomName2 when ''0'' then '''' else b.B_CustomName2 end  as B_CustomName2, 
        case b.B_CustomName3 when ''0'' then '''' else b.B_CustomName3 end  as B_CustomName3,
        (case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype,
        b.QualityAudit, b.QualityAuditdate, b.QualityAuditer, b.wtEname,b.FollowNumber,b.TicketDate        
        FROM vw_c_billidx b LEFT join productdetail pd ON b.billid=pd.billid  left join vw_c_printcount p on b.billid=p.Rep_id'
   
   IF  @cMode=0 
   BEGIN
       SET @SQLScript=@SQLScript+' WHERE (b.billdate between '
           +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
           +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'
   END ELSE
   BEGIN
       SET @SQLScript=@SQLScript+' WHERE (b.auditdate between '
           +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
           +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'
   END
   
   IF  @szBillType<>''
       SET @SQLScript=@SQLScript+@szBillType
   IF  @nC_id<>0 
       SET @SQLScript=@SQLScript+'and billtype not in (150,151,152, 153, 155,160,161,162,163,165) and left(b.cclass_id, len('+CHAR(39)+@szC_ID+CHAR(39)+'))='+CHAR(39)+@szC_ID+CHAR(39)
   IF  @nE_id<>0
       SET @SQLScript=@SQLScript+' and left(b.eclass_id, len('+CHAR(39)+@szE_ID+CHAR(39)+'))='+CHAR(39)+@szE_ID+CHAR(39)
   IF  @nY_id<>0 
       SET @SQLScript=@SQLScript+'and billtype  in (150,151,152, 153,155,160,161,162, 163, 165) and left(b.CYclass_id, len('+CHAR(39)+@szY_ID+CHAR(39)+'))='+CHAR(39)+@szY_ID+CHAR(39)
  
   IF  @nSs_id<>0                          
       SET @SQLScript=@SQLScript+' and CASE WHEN b.billtype = 50 THEN b.sout_id ELSE pd.s_id END ='+CHAR(39)+CAST(@nSs_id AS VARCHAR)+CHAR(39)

   IF  @nZd_id<>0
       SET @SQLScript=@SQLScript+' and b.inputman='+CHAR(39)+CAST(@nZd_id AS VARCHAR)+CHAR(39)
   IF  @SendC_id<>0
       SET @SQLScript=@SQLScript+' and b.sendc_id='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
   
   if @employeestable<>0
   set @SQLScript=@SQLScript+' AND (b.E_id in (select [id] from #employeestable))'
   
   if @Storetable<>0 
   set @SQLScript=@SQLScript+' AND (b.sin_id in (select [id] from #storagestable))' 
  
   if @ClientTable<>0 
   set @SQLScript=@SQLScript+' AND (b.c_id in (select [id] from #Clienttable)) '

   if @Companytable<>0
   set @SQLScript=@SQLScript+' AND ((b.billtype = 152) or (b.Y_id in (select [id] from #Companytable)))  '   

   set @SQLScript=@SQLScript+@Filtertype


   SET @SQLScript=@SQLScript+' and b.YClass_ID like '+CHAR(39)+@nCompanyClass_id+CHAR(39)+'  ORDER BY [billdate]'
 

  PRINT @SQLScript 
 EXEC(@SQLScript)
 	GOTO Succee
/*exec TS_C_QrBillIDX '2017-02-01 00:00:00','2017-02-27 00:00:00',' AND b.[BILLTYPE] in (-999, 10, 210, 211, 212, 11, 12, 13, 14, 18, 15, 16, 17, 20, 220, 221, 222, 21, 22, 23, 24, 25, 26, 27, 40, 41, 42, 43, 44, 48, 49, 50, 51, 60, 61, 62, 63, 64, 65, 66, 67, 80, 81, 82, 83, 84, 90, 100, 101, 102, 110, 111, 112, 120, 121, 122, 52, 53, 54, 88, 57, 140, 141, 147, 146, 148, 149, 150, 151, 155, 160, 161, 165, 170, 171, 172, 173, 174, 184, 185, 115, 152, 153, 162, 163, 186, 187, 244, 188, 254, 39, 104, 105, 106, 107, 108, 154, 142, 255, 200, 201, 202)',0,0,0,0,0,0,0,0,'',32,0,0,0,0*/

END ELSE if @nFlag = 1
BEGIN
/*查询草稿*/
   SELECT  @SQLScript=' SELECT  DISTINCT
        b.billid, b.billtype, b.billdate, b.billstates, b.billnumber,b.Yname,
        b.inputman, b.auditman, b.GatheringMan, b.note, b.SUMmary, b.quantity,b.skdate,
        ysmoney=case  when b.billtype in (11,13,21,23,24,25,153,151) then -b.ysmoney else b.ysmoney end, 
        (case when b.billtype in (11,13,21,23,24,25,54,111,121,211,221) or (b.billtype = 23 and b.ysmoney < 0) or (b.billtype =15 and b.ysmoney <0)  
          then -(abs(ysmoney)-abs(jsye)) else (abs(ysmoney)-jsye) end)  as ssmoney,
        b.araptotal, b.taxrate, b.auditdate, 
        b.[sout_id], b.[sin_id], b.[ssname], b.[sdname],
        CASE WHEN b.billtype IN (44, 45) THEN b.ssname  WHEN b.billtype in (171,172,173,174) THEN '''' ELSE b.cname END AS cname,b.transflag,
        b.ename AS employeename,
        b.auditmanname,
        b.inputmanname,
    	b.aname AS accountname,
    	b.departmentname,
	    b.regionname,
	    b.GatheringManName,
        isnull(p.printcount,0) as printcount,isnull(b.sendcname,'''') as sendcname,b.DiscountTotal,
        b.Y_id ,b.guid, b.B_CustomName1, b.B_CustomName2, b.B_CustomName3,
        (case b.invoice when 0 then ''无'' when 1 then ''收据'' when 2 then ''普票'' when 3 then ''增值税票'' else ''其他'' end) as invoicetype,
        b.QualityAudit, b.QualityAuditdate, b.QualityAuditer, b.wtEname,b.FollowNumber,b.TicketDate 
	FROM vw_c_billdraftidx b left join vw_c_printcountdrf p on b.billid=p.Rep_id '
	
	SET @SQLScript=@SQLScript+' WHERE (b.billdate between '
            +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+' and '
            +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+')'

   IF  @szBillType<>''
          SET @SQLScript=@SQLScript+@szBillType

   IF  @nC_id<>0 
          SET @SQLScript=@SQLScript+'and billtype not in (150,151,155,160,161,165) and left(b.cclass_id, len('+CHAR(39)+@szC_ID+CHAR(39)+'))='+CHAR(39)+@szC_ID+CHAR(39)
   IF  @nE_id<>0
	  SET @SQLScript=@SQLScript+' and left(b.eclass_id, len('+CHAR(39)+@szE_ID+CHAR(39)+'))='+CHAR(39)+@szE_ID+CHAR(39)
   IF  @nSs_id<>0
          SET @SQLScript=@SQLScript+' and b.sout_id='+CHAR(39)+CAST(@nSs_id AS VARCHAR)+CHAR(39)
   IF  @PosId>0 
          SET @SQLScript=@SQLScript+' and b.posid='+CHAR(39)+CAST(@PosId AS VARCHAR)+CHAR(39)
   IF  @nZd_id<>0
	  SET @SQLScript=@SQLScript+' and b.inputman='+CHAR(39)+CAST(@nZd_id AS VARCHAR)+CHAR(39)
  
   IF  @SendC_id<>0
      SET @SQLScript=@SQLScript+' and b.sendc_id='+CHAR(39)+CAST(@SendC_id AS VARCHAR)+CHAR(39)
   
   IF  @nY_id<>0 
      SET @SQLScript=@SQLScript+'and billtype in (150,151,155,160,161,165) and left(b.CYclass_id, len('+CHAR(39)+@szY_ID+CHAR(39)+'))='+CHAR(39)+@szY_ID+CHAR(39)

   if @employeestable<>0
   set @SQLScript=@SQLScript+' AND (b.E_id in (select [id] from #employeestable))'
   
   if @Storetable<>0 
   set @SQLScript=@SQLScript+' AND (b.sin_id in (select [id] from #storagestable))' 
   
   /*---机构类单据草稿中机构Id 为c_id add by luowei 2013-02-05*/
	   if @ClientTable<>0
	   set @SQLScript=@SQLScript+' AND (b.c_id in (select [id] from #Clienttable) or 
	   (b.billtype in (52,150,151,155,160,161,165))) '
	   if @Companytable<>0
	   set @SQLScript=@SQLScript+' AND (b.Y_id in (select [id] from #Companytable) or
	   (b.billtype in (52,150,151,155,160,161,165) and (b.c_id in (select [id] from #Companytable))))' 

    set @SQLScript=@SQLScript+@Filtertype 
        /*草稿中过滤(业务开单):状态=8,9*/
          SET @SQLScript=@SQLScript+' and b.YClass_ID like  '+CHAR(39)+@nCompanyClass_id+CHAR(39)+'  and b.BillStates not in (7,8,9) '
/*PRINT @SQLScript*/
  EXEC(@SQLScript)
 	GOTO Succee

END ELSE IF @nFlag = 2 
BEGIN 
       /*--------查询传输日志 add by luowei 2013-03-25*/
        select @SQLScript = 'SELECT  DISTINCT 
        L.billID, isnull(L.billtype,0) AS billtype, ISNULL(L.billdate,'''') AS billdate, ''0'' as billstates, isnull(L.billnumber,'''') AS billnumber,
        cast(''1900-01-01'' as datetime) as skdate,0 as inputman,0 AS auditman,0 as GatheringMan,'''' as note,
        '''' as SUMmary, 0.0 as quantity, 0.0 as ysmoney,0.0 as ssmoney, 
        0.0 as araptotal, 0.0 as taxrate, cast(''1900-01-01'' as datetime) as auditdate,0 AS sout_id, 0 AS sin_id,isnull(L.YNAME,'''') AS Yname,
        '' '' as ssname ,'''' as sdname,'''' AS cname,0 as transflag,'''' AS employeename,'''' as auditmanname,
        '''' as inputmanname,'''' AS accountname,'''' as departmentname,'''' as regionname,'''' as GatheringManName, 0 as printcount,
        L.Y_ID as Y_id,L.BillGuid AS GUID, 0 as importjscw, '''' as B_CustomName1, '''' as B_CustomName2, '''' as B_CustomName3,
        '''' as invoicetype, 0 as QualityAudit,  '''' as QualityAuditer, cast(''1900-01-01'' as datetime) as QualityAuditdate, 
        Transtype,isnull(L.errCount,0) as errCount,IndateTime,L.ErrFlag,BLStatus,ErrStr, '''' as wtEname,'''' as sendcname,0 as DiscountTotal
        FROM 
        (
           select bl.bill_id as BillID,bl.BillDate,bl.BillNumber,v.Comment as billtypename,y_id,isnull(y.name,'''') as yname,
			(Case bl.UpOrDown when 0 then ''上传'' else ''下传'' end) as Transtype,billtype,UpOrDown,billguid,
			 errCount,IndateTime,ErrFlag,Status as BLStatus,
			 (case when  BL.ErrFlag = -1 then ''【''+p.serial_number+''】【''+p.name+''】'' else '''' end) AS ErrStr
			 from BillLog bl
			left join VchType v on v.Vch_ID = bl.BillType
			left join company y on y.company_id = bl.y_id
			left join products p on p.product_id = bl.p_id
        )L            
        where (L.Y_ID = '+cast(@nY_ID as varchar)+' OR '+cast(@nY_ID as varchar)+' = 0) and  L.billdate between '
        +CHAR(39)+CONVERT(VARCHAR(10),@BeginDate,20)+CHAR(39)+ ' and ' 
           +CHAR(39)+CONVERT(VARCHAR(10),@EndDate,20)+CHAR(39)+' '  
  
 set @szwhere = ''          

 if @isUpdate = 0 
   set @szwhere = @szwhere + 'and L.UpOrDown = 0 ' /*上传 */
 if @isUpdate = 1 
   set @szwhere = @szwhere + 'and L.UpOrDown = 1 ' /*下传*/
 
 if @Searchtype = 0
   set @szwhere = @szwhere + 'and L.BLStatus = 1 ' /*异常*/
 if @Searchtype = 1
   set @szwhere = @szwhere + 'and L.BLStatus = 0 ' /*正常*/
   
 set @SQLScript = @SQLScript + @szwhere  
             
 EXEC('select * from ('+ @SQLScript + ') a  ORDER BY [billdate]')
 	GOTO Succee  
END


Succee:
  drop table #Clienttable
  drop table #Companytable
  drop table #employeestable
  drop table #storagestable
  RETURN  0
GO
