

CREATE   PROCEDURE [Ts_L_InsStorages]
 (@parent_id [varchar](30),
  @name [varchar](80),
  @alias  [varchar](30),
  @serial_number  [varchar](26),
  @Comment [varchar](256),
  @flag  [TinyInt],
  @PinYin [varchar](80),
  @RowIndex [int],     /*Wsk Add*/
  @WholeFlag     int =0,
  @Y_id          int =0,
  @Fzr_id        int =0,
  @Bgy_id        int =0,
  @StoreCondition int = 0,
  @QualityFlag int = 0
 )

AS 
/*Params Ini begin*/
if @WholeFlag is null  SET @WholeFlag = 0
if @Y_id is null  SET @Y_id = 0
/*Params Ini end*/
declare  @tempId  varchar(30),
   @child_number  [int],
  @child_count [int]
/*合法性检查*/
/*if exists(select * from products where )*/
if exists(select * from storages where serial_number=ltrim(@serial_number) and deleted=0)
begin
 RAISERROR('编号重复！不能添加！！',16,1)
 return -2
end

if exists(select * from storages 
   where @QualityFlag = 1 
     and Y_ID = @Y_id 
     and storeCondition = @StoreCondition                 
     and qualityFlag = @QualityFlag)
begin
  Raiserror('此类型的不合格品库已有，不能添加！',16,1)
  return -3  /*当返回值为-2的时候，客户端会弹出一个该警告类型的对话框，-3即可关闭*/
end

/*取得ID号*/
select @tempid=classid,@child_number=childnumber,@child_count=childCount 
from Getid(@Parent_id,'Storages')
if @@rowcount=0
begin
 RAISERROR('ID号生成错误，可能是这类目录的记录数已经超出限制',16,1)
 return-1
end

/*BEGIN TRAN insertBaseStorage*/

INSERT INTO [storages] 
  ( [class_id],
  [parent_id],
  [name],
  [alias],
  [serial_number],
  [Comment],
  [flag],
  [PinYin],
  [RowIndex],   /*Wsk Add*/
  [WholeFlag],
  [Y_ID],
  [Fzr_id],
  [Bgy_id],
  [StoreCondition],
  [QualityFlag]
  ) 
VALUES 
 (@tempid,
  @parent_id,
  @name,
  @alias,
  @serial_number,
  @Comment,
  @flag,
  @PinYin,
  @RowIndex,   /*Wsk Add*/
  @WholeFlag,
  @Y_id,
  @Fzr_id,
  @Bgy_id,
  @StoreCondition,
  @QualityFlag
  )

if @@rowCount=0 

 begin
/* rollback tran insertBaseStorage*/
 return -1
end else 
begin
 update Storages set child_number=@child_number,child_count=@child_count,Y_id=@Y_id
 where class_id =@Parent_id
/* commit tran insertBaseStorage*/
 return @@IDENTITY
end
GO
