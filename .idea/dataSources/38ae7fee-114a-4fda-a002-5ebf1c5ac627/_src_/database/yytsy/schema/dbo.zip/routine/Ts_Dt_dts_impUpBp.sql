/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-05-16*/
/* Description:	接收总部数据后修改数据*/
/* =============================================*/
CREATE PROCEDURE [dbo].[Ts_Dt_dts_impUpBp]
AS
BEGIN
  /*-修改 商品ID,基本单位*/
  update buymanagebilldrf  set p_id=x.product_id,unitid=x.unit_id
  from(
  select a.product_id,a.name,a.permitcode,b.magbillid,d.unit_id,a.deleted
  from products a 
  inner join Dtmangedatadts b  on a.name=b.proname
  inner join Dtmangedatadts c  on a.permitcode=c.permitcode
  left  join unit d            on d.name  = c.unitname
  ) x,buymanagebilldrf y 
  where   x.magbillid=y.smb_id   and x.deleted=0     
  /*--修改配送的商品是否存在基本资料中  1:存在 0:需要添加*/
  update Dtmangedatadts  set isvalid=1
  from Dtmangedatadts a, products b
  where a.proname=b.name and a.permitcode=b.permitcode and b.deleted=0
  /*-目前只判断了 药品名称和批文号  需要判断产地,规格 可以在此处加条件 */
  /*-基本单位用总部配送单位*/
END
GO
