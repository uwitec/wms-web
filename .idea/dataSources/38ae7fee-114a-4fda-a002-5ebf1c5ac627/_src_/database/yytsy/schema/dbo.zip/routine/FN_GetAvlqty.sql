
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014.6.10*/
/* Description:	取得可开数量*/
/* =============================================*/
CREATE FUNCTION FN_GetAvlqty 
(
	@nPid int ,
	@nSid int ,
	@sPname varchar(8000),
	@bStopSale int    /*这儿如果是3，表示不统计不合格品库*/
)
RETURNS 
@AvlQty TABLE 
(
	[location_id] [int] NOT NULL,
	[s_id] [int] NOT NULL,
	[p_id] [int] NOT NULL,
	[supplier_id] [int] NOT NULL,
	[quantity] numeric(25,8) NOT NULL,
	[costprice] numeric(25,8) NOT NULL,
	[batchno] [varchar](20) NOT NULL,
	[makedate] [datetime] NOT NULL,
	[instoretime] [datetime] NOT NULL,
	[validdate] [datetime] NOT NULL,
	[commissionflag] [tinyint] NOT NULL,
	[Y_ID] [int] NOT NULL,
	[storeQty] numeric(25,8) NOT NULL,
	[BatchBarCode] [varchar](30) NOT NULL,
	[scomment] [varchar](80) NOT NULL,
	[batchprice]  numeric(25,8) NOT NULL,
	[factoryid] [int] not null,
	[costtaxprice]  numeric(25,8) not null,/*成本含税单价*/
	[costtaxtotal] numeric(25,8) NOT NULL,/*成本含税金额  --这儿金额不能作为批次的判断，每个单据的数量不同，金额肯定不同*/
	[costtaxrate]  numeric(25,8) NOT NULL/*成本税率*/
)
AS
BEGIN

	DECLARE @SFlag INT /*= 0   --为1表示不统计不合格品库，默认为0*/
        select @SFlag = 0/*zjx--2017-01-02-SQL2000不支持局部变量边定义边赋值*/
    
	IF @nPid IS NULL SET @nPid = 0
	IF @nSid IS NULL SET @nSid = 0
	IF @sPname IS NULL SET @sPname = ''
	IF @bStopSale IS NULL SET @bStopSale = 1
	
	if @bStopSale = 3   /*为3时特殊处理，不统计不合格品库*/
	begin
		set @SFlag = 1
		SET @bStopSale = 1    /*把@bStopSale置为默认状态*/
	end
	else
		set @SFlag = 0	

	DECLARE @nStandard int
	DECLARE @nCalcMode int
	DECLARE @nCheckQtyByOrderDraft int
	
	/*XXX。2017-01-12 用一个表变量来存储后面多次用函数调用的值,测试在数据量较小的情况下，几百条一下，速度加快很明显*/
	declare @tmp_FN_FindProducts TABLE (PRODUCT_ID int )

	SET @nStandard = -1
	SET @nCalcMode = -1

	SELECT @nStandard = sysvalue FROM sysconfigtmp WHERE sysname = 'GspStandardProcess'
	SELECT @nCalcMode = sysvalue FROM sysconfig WHERE sysname = 'CheckSaleQty'
	 insert  @tmp_FN_FindProducts
    SELECT PRODUCT_ID   FROM DBO.FN_FindProducts(@sPname) 

	IF @nPid = 0 AND @sPname = ''
		SET @nPid = -1

	/*yypeng-- 可开数量使用余量表，加快模糊查询速度   开关	*/
	SELECT @nCheckQtyByOrderDraft = sysvalue FROM sysconfigtmp WHERE sysname = 'CheckQtyByOrderDraft'

if @nCheckQtyByOrderDraft = 0/*普通模式*/
begin
	/* 指定了PID*/
	IF @sPname = ''
	BEGIN
		/* 标准流程*/
		IF @nStandard = 1
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
			    INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.OrderBill AS b INNER JOIN
												 dbo.orderidx AS i ON b.bill_id = i.billid
								WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else if @bStopSale=157/*zjx--2017-03-11--(心联欣)处理店间调拨单停售商品包含在检测可开数量之中*/
			  begin
			    INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0))
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.OrderBill AS b INNER JOIN
												 dbo.orderidx AS i ON b.bill_id = i.billid
								WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								union all
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.salemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
							    where (b.billtype=157) and (b.billstates=3) AND (sb.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else
			  begin 
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.OrderBill AS b INNER JOIN
												 dbo.orderidx AS i ON b.bill_id = i.billid
								WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else if @bStopSale=157/*zjx--2017-03-11--(心联欣)处理店间调拨单停售商品包含在检测可开数量之中*/
			  begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									 union all
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 where (b.billtype=157) and (b.billstates=3) AND (sb.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
												 ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
								 UNION ALL
								 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.InceptQty AS InceptQty, b.CostPrice, b.Batchno, 
												b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,
												costtaxprice,costtaxrate as  TaxRate 
								 FROM      dbo.GSPbilldetail AS b INNER JOIN
												dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   ((i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0)) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
							) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			END
		END
		/* 非标准流程*/
		ELSE
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid,costtaxprice,taxrate
									 FROM      dbo.storehouse
									 WHERE  (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													 ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			  end
			  else
			  begin
			       	INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid,costtaxprice,taxrate
									 FROM      dbo.storehouse
									 WHERE  (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													 ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			  end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid ,
													 costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			   else
			   begin
			     	INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid ,
													 costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
	END
	ELSE
	BEGIN
		/* 标准流程*/
		IF @nStandard = 1
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									UNION ALL
									SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) 
									/*AND (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) */
									AND (@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) 
									/*AND (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) */
									AND (@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate
			    end
			    else
			    begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									UNION ALL
									SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									WHERE   (i.billtype IN (14, 154)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND  */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			   else
			   begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderBill AS b INNER JOIN
													 dbo.orderidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (14, 154)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.ApplicantQty AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR b.s_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
		/* 非标准流程*/
		ELSE
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													  ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR sb.ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			    else
			    begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													  ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR sb.ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
			 		GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			     end
			     else
			     begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
	END
	
end	

else if @nCheckQtyByOrderDraft = 1  /*采用余量表*/
begin
	/* 指定了PID*/
	IF @sPname = ''
	BEGIN
		/* 标准流程*/
		IF @nStandard = 1
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
			    INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
						        FROM      dbo.OrderDraft AS b 
								WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.commissionflag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else if @bStopSale=157/*zjx--2017-03-11--(心联欣)处理店间调拨单停售商品包含在检测可开数量之中*/
			  begin
			    INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0))
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.OrderDraft AS b
								WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommissionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								union all
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.salemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
							    where (b.billtype=157) and (b.billstates=3) AND (sb.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else
			  begin 
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (
				               SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid,costtaxprice,taxrate as taxrate
								FROM      dbo.storehouse
								WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
								UNION ALL
								SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
												 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.OrderDraft AS b
								WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
												 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.storemanagebilldrf AS sb INNER JOIN
												 dbo.billdraftidx AS b ON sb.bill_id = b.billid
								WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommissionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
								WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
								UNION ALL
								SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,costprice, taxrate
								FROM      dbo.GSPbilldetail AS b INNER JOIN
												 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
						
							) AS a
				  GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderDraft AS b
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity  AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommissionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPDraft AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else if @bStopSale=157/*zjx--2017-03-11--(心联欣)处理店间调拨单停售商品包含在检测可开数量之中*/
			  begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderDraft AS b
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity  AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommissionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPDraft AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
									 union all
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 where (b.billtype=157) and (b.billstates=3) AND (sb.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			  else
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													 ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.OrderDraft AS b
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity  AS ApplicantQty, b.CostPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommissionFlag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.GSPDraft AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									 WHERE   (i.BillType = 561) AND (i.BillStates = 13) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.ss_id = @nSid)
									 
									 UNION ALL
									 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.YQty AS InceptQty, b.DiscountPrice, b.Batchno, 
													 b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid, TaxPrice, taxrate
									 FROM      dbo.GSPbilldetail AS b INNER JOIN
													 dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
									 WHERE   (i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
								
								) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			  end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
												 ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
								 UNION ALL
								 SELECT   b.Location_id, b.S_id, b.P_id, b.Supplier_id, - b.InceptQty AS InceptQty, b.CostPrice, b.Batchno, 
												b.MakeDate, b.InstoreTime, b.Validdate, b.CommisionFlag, b.Y_id, 0, '', '', 0,factoryid,
												costtaxprice,costtaxrate as  TaxRate 
								 FROM      dbo.GSPbilldetail AS b INNER JOIN
												dbo.GSPbillidx AS i ON b.Gspbill_id = i.Gspbillid
								WHERE   ((i.BillType = 516 AND i.BillStates IN (10, 12) AND i.Ybillid > 0)) AND (b.P_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR b.s_id = @nSid)
							) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid,costtaxprice,taxrate
			END
		END
		/* 非标准流程*/
		ELSE
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid,costtaxprice,taxrate
									 FROM      dbo.storehouse
									 WHERE  (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in(0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													 ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			  end
			  else
			  begin
			       	INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid,costtaxprice,taxrate
									 FROM      dbo.storehouse
									 WHERE  (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													 ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR sb.ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			  end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			  if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			  begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid ,
													 costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			   else
			   begin
			     	INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid ,
													 costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,factoryid
													  ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND (@nPid = -1 OR p_id = @nPid) AND (@nSid = 0 OR ss_id = @nSid)) AS a
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (@nPid = -1 OR p_id = @nPid) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
	END
	ELSE
	BEGIN
		/* 标准流程*/
		IF @nStandard = 1
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									UNION ALL
									SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderDraft AS b 
									where (@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) 
									/*AND (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) */
									AND (@nSid = 0 OR ss_id = @nSid)
									UNION ALL
										SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.commissionflag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
													 	 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.ss_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate
			    end
			    else
			    begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									FROM      dbo.storehouse
									WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									UNION ALL
									SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderDraft AS b 
									where (@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR ss_id = @nSid)
									UNION ALL
									SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.commissionflag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
													 	 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.ss_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice,taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND  */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderDraft AS b 
									where (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.commissionflag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
													 	 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.ss_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			   else
			   begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, CASE WHEN b.ComeQty - b.quantity > 0 THEN 0 ELSE b.ComeQty - b.quantity END AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.Instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									FROM      dbo.OrderDraft AS b 
									where (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (b.billstates = '3') AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.Location_id, b.Ss_id, b.P_id, b.Supplier_id, - b.quantity AS ApplicantQty, b.CostPrice, b.Batchno, 
												 b.MakeDate, b.InstoreTime, b.Validdate, b.commissionflag, b.Y_id, 0, '', '', 0,factoryid,costtaxprice,costtaxrate as taxrate
								FROM      dbo.GSPDraft AS b INNER JOIN
													 	 dbo.GSPbillidx AS i ON b.bill_id = i.Gspbillid
									WHERE   (i.BillType = 561) AND (i.BillStates <> 15) AND (b.P_id > 0) AND 
									/*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									(@nSid = 0 OR b.ss_id = @nSid)
								) AS a
								where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			   end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
		/* 非标准流程*/
		ELSE
		BEGIN
			/* 所有草稿*/
			IF @nCalcMode = 1
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													  ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR sb.ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			    else
			    begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,factoryid
													  ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates <> '0') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (sb.AOID IN (0, 7)) AND (sB.P_ID > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR sb.ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			END
			ELSE
			/* 已审核草稿*/
			IF @nCalcMode = 2
			BEGIN
			   if @bStopSale=41/*zjx--2016-12-29--tfs44422--处理报损单停售商品包含在检测可开数量之中*/
			   begin
					INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag in (0,1))
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
			 		GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			     end
			     else
			     begin
			        INSERT INTO @AvlQty
					SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
									commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
									MAX(batchprice) AS batchprice,factoryid,costtaxprice,0 as costtaxtotal,taxrate
					FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
													 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
													 factoryid ,costtaxprice,taxrate as taxrate
									 FROM      dbo.storehouse
									 WHERE   /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.salemanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (10, 110, 210, 212, 150, 152)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   b.location_id, b.ss_id, b.p_id, b.supplier_id, - b.quantity AS quantity, b.costprice, b.batchno, b.makedate, 
													 b.instoretime, b.validdate, b.commissionflag, b.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.buymanagebilldrf AS b INNER JOIN
													 dbo.billdraftidx AS i ON b.bill_id = i.billid
									 WHERE   (i.billtype IN (21, 121, 161)) AND (i.billstates = '3') AND (b.p_id > 0) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)
									 UNION ALL
									 SELECT   sb.location_id, sb.ss_id, sb.p_id, sb.supplier_id, - sb.quantity AS quantity, sb.costprice, sb.batchno, 
													 sb.makedate, sb.instoretime, sb.validdate, sb.commissionflag, sb.Y_ID, 0, '', '', 0,
													 factoryid ,costtaxprice,costtaxrate as taxrate
									 FROM      dbo.storemanagebilldrf AS sb INNER JOIN
													 dbo.billdraftidx AS b ON sb.bill_id = b.billid
									 WHERE   (b.billtype IN (40, 41, 44, 45, 49, 51)) AND (b.billstates = '3') AND (sb.AOID IN (0, 7)) AND 
									 /*(p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND */
									 (@nSid = 0 OR ss_id = @nSid)) AS a
									 where (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts))
					GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			    end
			END
			ELSE
			/* 不检测*/
			BEGIN
				INSERT INTO @AvlQty
				SELECT   location_id, s_id, p_id, supplier_id, SUM(quantity) AS quantity, costprice, batchno, makedate, instoretime, validdate, 
								commissionflag, Y_ID, SUM(storeQty) AS storeQty, MAX(BatchBarCode) AS BatchBarCode, MAX(scomment) AS scomment, 
								MAX(batchprice) AS batchprice,factoryid ,costtaxprice,0 as costtaxtotal,taxrate
				FROM      (SELECT   location_id, s_id, p_id, supplier_id, quantity, costprice, batchno, makedate, instoretime, validdate, 
												 commissionflag, Y_ID, quantity as storeQty, BatchBarCode, scomment, batchprice,
												 factoryid ,costtaxprice,taxrate as taxrate
								 FROM      dbo.storehouse
								 WHERE   (p_id IN (SELECT PRODUCT_ID FROM @tmp_FN_FindProducts)) AND ((@nSid = 0 OR s_id = @nSid) and ((@SFlag = 0) or (@SFlag = 1 and s_id not in(select storage_id from storages where qualityFlag = 1)))) AND (@bStopSale = 1 OR stopsaleflag = 0)) AS a
				GROUP BY location_id, s_id, p_id, supplier_id, costprice, batchno, makedate, instoretime, validdate, commissionflag, Y_ID,factoryid ,costtaxprice, taxrate
			END
		END
	END
	
end	





	
	
	RETURN 
END
GO
