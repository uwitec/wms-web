
/* =============================================*/
/* Author:		YANRUI*/
/* Create date: 2014-1-22*/
/* Description:	将药品检验报告写入GSP明细表*/
/* =============================================*/
CREATE PROCEDURE TS_Y_InsertCheckReport 
	@BillID int = 0		/* 单据ID*/
AS
BEGIN
  update gspbilldetail set CheckReport=y.pathname
  from gspbilldetail x,
  (
    select  a.Gspsmb_id,isnull(b.Pathname,'') as pathname,a.Batchno
    from GSPbilldetail a
    inner join  MedReport b on a.P_id=b.p_id and a.Batchno=b.batchno
    inner join 
     (select MAX(inputTime) as inputTime,p_id,batchno from  MedReport  group by p_id,batchno
      )c 
    on c.inputTime=b.inputTime and b.p_id=c.p_id and b.batchno=c.batchno
    where a.Gspbill_id=@BillID 
   ) y
   where x.Gspsmb_id=y.Gspsmb_id  

END
GO
