
CREATE VIEW dbo.VW_H_ExamDept
AS
SELECT     departmentId, serial_number, name, comment, deleted, ModifyDate, pinyin
FROM         dbo.department
WHERE     (Type_ID = 1)
GO
