/* select * from dbo.FN_DRPrintText_MZ(12,384)*/
CREATE FUNCTION FN_DRPrintText_MZ 
(
  @billtype INT,
  @billid INT
)
RETURNS @PrintText TABLE(DR065 VARCHAR(10),taxtotal NUMERIC(15,2))
AS
BEGIN 
  DECLARE @nPubYZYiBao INT,@Default VARCHAR(10)  
  SELECT @nPubYZYiBao=sysvalue FROM sysconfigtmp WHERE sysname='yzshebao'
  SELECT @Default='00'/*CASE WHEN @nPubYZYiBao=3 THEN '91' ELSE '11' END */
  /*零售和对应退货均记录的是零售单id*/
  DECLARE @ProductMap TABLE(p_id INT,DR065 VARCHAR(10))
  INSERT INTO @ProductMap
  SELECT p_id,CASE WHEN DR065='' THEN AKA063 ELSE DR065 END
  FROM DRProductMap
  WHERE @nPubYZYiBao=3
  UNION ALL 
  SELECT p_id,aka063
  FROM YHProductMap
  WHERE @nPubYZYiBao=6
  
  INSERT INTO @PrintText
  SELECT t.DR065,SUM(taxtotal) taxtotal 
  FROM (
		SELECT CASE WHEN @billtype=12 THEN 1 ELSE -1 END*CAST(a.taxtotal AS NUMERIC(15,2)) taxtotal
			   ,CASE WHEN b.p_id IS NULL THEN @Default 
				ELSE b.DR065
				END DR065
		FROM salemanagebill a LEFT JOIN @ProductMap b  
			 ON a.p_id=b.p_id
		WHERE a.bill_id=@billid AND a.p_id>0
	 ) t
  GROUP BY t.DR065

  RETURN
END
GO
