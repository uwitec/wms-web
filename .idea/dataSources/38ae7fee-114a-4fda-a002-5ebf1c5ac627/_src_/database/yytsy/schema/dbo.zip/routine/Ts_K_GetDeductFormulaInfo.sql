
CREATE PROCEDURE Ts_K_GetDeductFormulaInfo(@Type INT, @FId INT)
AS
BEGIN
	IF @Type IN (1, 2, 3, 4)
	BEGIN
		SELECT a.FdId, a.FId, a.CategoryId, a.BatchNo, a.BeginNum1, a.EndNum1, a.Rate1, a.BeginNum2, a.EndNum2, a.Rate2, a.BeginNum3, a.EndNum3, a.Rate3,
		       a.BeginNum4, a.EndNum4, a.Rate4, b.name AS CgName, b.class_id, b.parent_id, '' AS PName, '' AS alias, '' AS [standard], '' AS makearea, 
		       '' AS UnitName, '' AS Code
			FROM Deduct_FormulaDetail a INNER JOIN customCategory b ON a.CategoryId = b.id 
		WHERE a.FId = @FId
	END
	ELSE
	IF @Type IN (0, 6, 7, 8)
	BEGIN
		SELECT a.FdId, a.FId, a.CategoryId, a.BatchNo, a.BeginNum1, a.EndNum1, a.Rate1, a.BeginNum2, a.EndNum2, a.Rate2, a.BeginNum3, a.EndNum3, a.Rate3,
		       a.BeginNum4, a.EndNum4, a.Rate4, '' AS CgName, b.class_id, b.parent_id, b.name AS PName, b.alias, b.[standard], b.makearea, 
		       u.name AS UnitName, b.serial_number AS Code,p.retailprice , p.recprice
			FROM Deduct_FormulaDetail a INNER JOIN products b ON a.CategoryId = b.product_id INNER JOIN unit u ON b.unit1_id = u.unit_id
			inner join price p ON b.product_id = p.p_id
		WHERE a.FId = @FId and p.unittype = 1		
	END
	ELSE
	IF @Type IN (5)
	BEGIN
		SELECT a.FdId, a.FId, a.CategoryId, a.BatchNo, a.BeginNum1, a.EndNum1, a.Rate1, a.BeginNum2, a.EndNum2, a.Rate2, a.BeginNum3, a.EndNum3, a.Rate3,
		       a.BeginNum4, a.EndNum4, a.Rate4, '' AS CgName,'' AS class_id, '' AS parent_id, '' AS PName, '' AS alias, '' AS [standard], '' AS makearea, 
		       '' AS UnitName, '' AS Code
			FROM Deduct_FormulaDetail a
		WHERE a.FId = @FId	
	END
END
GO
