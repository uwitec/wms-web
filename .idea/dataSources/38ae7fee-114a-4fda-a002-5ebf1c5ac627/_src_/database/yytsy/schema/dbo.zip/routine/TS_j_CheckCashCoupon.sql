
/* =============================================*/
/* Author:		zjilin	*/
/* Create date: 2013-06-06*/
/* Description:	检查代金券规则*/
  /*判断类型ID号是否相同 -11*/
  /*判断会员卡号是否相同 -12*/
  /*判断代金券是否在有效期 -13*/
  /*判断代金券状态是否启用 -14*/
   /*判断代金券是否使用    -15 */
  /*判断单据金额是否限额   */
    /*按商品判断           -21*/
    /*按类别判断           -22*/
    /*整单限额判断         -16  */
    /*nMode 模式　0按类型id 判断,按商品明细判断　1按草稿明细判断*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_j_CheckCashCoupon] 	
	@nTypeid  int, /*类型id*/
	@nOldTypeid  int, /*原有类型id*/
	@nCCID		 int, /*当前券id*/
	@nBillDraftid int =0, /*单据草稿id*/
	@nbillVipcard  int, /*单据会员卡				*/
	@dBillTotal    NUMERIC(25,8), /*单据金额	*/
	@szPid varchar(3000),/*商品id */
	@szCCid varchar(1000),  /*券id*/
	@szbillTotal varchar(3000), /*单据金额*/
	@nMode  int   /*0判断按类型id ,按商品明细判断 　1按草稿明细判断, 2 	*/
AS   
 
	declare @nRet int, @nCurDate int, @cpcount int /*券张数*/
	declare @total NUMERIC(25,8), @limitTotal NUMERIC(25,8),  @begindate datetime, @validdate datetime, @limitflag int,  @multiflag int
	declare @flag int,  @CPVipcard int	
			
	set @nRet = -1
	set @nCurDate = FLOOR(cast(GETDATE() as NUMERIC(25,8)))
	
	if OBJECT_ID('tempdb..#CheckP') is not null
		  drop table #CheckP
    if OBJECT_ID('tempdb..#CheckCP') is not null
		  drop table #CheckCP 	  
	
	select  top 0 IDENTITY(Int, 1,1 ) as smb_Id,  0  as p_id,  CAST (0  as NUMERIC(25,8))  as total into #checkp
	select  top 0 cast(0 as int) as ccid into #checkCP
	
	
	
	
	
  if @nMode = 0
  begin	
	if @szPid <> ''
	begin		
		if OBJECT_ID('tempdb..#billtotal') is not null
		  drop table #billtotal                               
		  
		insert into #checkp(p_id, total)  select cast(szTYPE as int) as p_id,  CAST (0  as NUMERIC(25,8))  as total from dbo.DecodeToStr(@szPid)
		select IDENTITY(Int, 1,1 ) as smb_Id,  cast(szTYPE as NUMERIC(25,8)) as total into #billtotal from dbo.DecodeToStr(@szbillTotal)
		update #checkp set total = t.total from #checkp c, #billtotal t where c.smb_Id = t.smb_Id					
    end
   
          		      
    if @szCCid <> ''
    begin
		insert into #checkCP(ccid)
		select cast(szTYPE as int) as ccid from dbo.DecodeToStr(@szCCid)       
    end            
  end  
   /*从单据中读取商品信息和券信息 */
  if @nMode = 1
  begin
     insert into #checkp(p_id, total) 	        
     select p_id,  taxtotal as total from retailbill where p_id > 0 and bill_id =@nBillDraftid
                     
     insert into #checkCP(ccid) 	                                        
		select price_id as ccid from retailbill where p_id = -9999 and bill_id =@nBillDraftid
  end
    
  if @nMode = 2
  begin
      set @nRet = 0
      goto checkover
  end  
  
  if (@nMode = 1) or (@nMode  =2) 
  begin
    if not exists (select 1 from #checkCP)
    begin
      set @nRet = 0
      goto CheckOver      
    end    
  end
              
	
  if @nMode = 0	
  begin
    /*判断数据是否合法 -10*/
	if (@nTypeid = 0) or (@nOldTypeid = 0) 
	begin
      set @nRet =-10
      goto CheckOver
	end
	/*判断类型ID号是否相同 -11*/
	if @nTypeid <> @nOldTypeid 
	begin
      set @nRet =-11
      goto CheckOver
	end
	
	select  @CPVipcard = VIPCardid from Cashcoupon where ccid = @nCCID
	/*判断会员卡号是否相同 -12	*/
	if @nbillVipcard =0 
	begin
	  if @cpvipcard > 0
	  begin
	    set @nRet =-12
		goto CheckOver
	  end	
	end
	if @nbillVipcard >0 
	begin
	  if (@nbillVipcard <> @CPVipcard) and (@CPVipcard >0)
	  begin
	    set @nRet =-12
		goto CheckOver
	  end	
	end
		
	select @total = total, @limitTotal = limitTotal, @begindate =begindate, @validdate = validDate, 
	       @limitflag = Limitflag,  @multiflag = MultiFlag
	  from cashcoupontype where typeid = @ntypeid	  
	  	
  /*判断代金券是否在有效期 -13*/
    if (@nCurDate < cast(@begindate as int)) or (@nCurDate > cast(@validdate as int))
    begin
      set @nRet = -13
      goto checkover 
    end
    
  /*判断代金券是否使用    -14 */
   if @flag = 5
   begin
     set @nRet = -14
     goto Checkover
   end   
  
  /*判断代金券状态是否启用 -15*/
   if @flag <> 0
   begin
     set @nRet = -15
     goto CheckOver
   end                      
   /*判断单据金额是否限额(整单)   -16*/
   if @limitTotal  > 0 
   begin
     select @cpcount = COUNT(1) from #checkCP
     if @cpcount is null set @cpcount = 0
     set @cpcount = @cpcount + 1   /*szccid 不包含当前记录，所以需要+1, @nmode=1 时不需要+1*/
     if @dBillTotal < @cpcount * @limitTotal 
     begin
       set @nRet = -16
       goto CheckOver     
     end     
   end     
   
   if exists(select 1 from CashcouponMapping where typeid = @nTypeid)
   begin   
      /*按商品判断           -21 */
      if @limitflag = 1
      begin
        delete #checkP where p_id not in (select baseid from CashcouponMapping where typeid = @nTypeid) 
        select @dBillTotal = SUM(total) from #checkp
        if @dBillTotal < @cpcount * @limitTotal 
        begin
         set @nRet = -21
         goto CheckOver     
        end                  
      end
      /*按类别判断           -22      */
      if @limitflag = 2
      begin                               
        delete #checkP 
         where  p_id not in (
							select cm.baseinfo_id 
							from CashcouponMapping cp 
							inner join customCategory cg on cp.BaseID = cg.id
							inner join (select p_id as baseinfo_id,class_id from (
										select p_id,PComent1 as class_id from ProductCategory
										union all 
										select p_id,PComent2 as class_id from ProductCategory
										union all
										select p_id,PComent3 as class_id from ProductCategory
										) a 
										) cm on cg.class_id = cm.class_id
							where cp.typeid = @nTypeid and cg.baseType = 0 and cg.deleted=0
							) 
        select @dBillTotal = SUM(total) from #checkp
        if @dBillTotal < @cpcount * @limitTotal 
        begin
         set @nRet = -22
         goto CheckOver     
        end                  
      end      
    end               
    /*检查全部合法	*/
	set @nRet = 0
	goto CheckOver
	
  end	
  else if @nMode =1
  begin
    /*判断所有，不能只判断一条*/
    select @nbillVipcard = vipcardid, @dBillTotal = ysmoney from retailbillidx where billid  = @nBillDraftid
    
    /*判断会员卡号是否相同 -12	*/
	if @nbillVipcard =0 
	begin
	  if exists(select 1 from Cashcoupon 
	             where ccid in
	              (select price_id 
	               from retailbill where p_id = -9999 and bill_id = @nBillDraftid) and vipcardid >0)
      begin
        set @nRet =-12
		goto CheckOver
      end        
    end   	
       	
	
	/*判断会员卡号是否相同 -12	*/
	if @nbillVipcard>0 
	begin
	  if exists(select 1 from Cashcoupon 
	             where ccid in
	              (select price_id 
	               from retailbill where p_id = -9999 and bill_id = @nBillDraftid) and vipcardid <> 0 and vipcardid <> @nbillVipcard)
	  begin	   
	    set @nRet = -12
	    goto CheckOver
	  end	
	end
	
	  	
  /*判断代金券是否在有效期 -13*/
     if exists(select 1 from Cashcoupon  cc
                inner join CashcouponType ct on cc.typeid =ct.typeid
                inner join  #checkCP cp on cc.ccid = cp.ccid                     
	             where (@nCurDate < cast(ct.begindate as int)) or (@nCurDate > cast(ct.validdate as int)))
    begin
      set @nRet = -13
      goto checkover 
    end
    
  /*判断代金券是否使用    -14 */
   if exists (select 1 from Cashcoupon 
	             where ccid in
	              (select price_id 
	               from retailbill where p_id = -9999 and bill_id = @nBillDraftid) and flag = 5)
   begin
     set @nRet = -14
     goto Checkover
   end   
  
  /*判断代金券状态是否启用 -15*/
   if exists (select 1 from Cashcoupon 
	             where ccid in
	              (select price_id 
	               from retailbill where p_id = -9999 and bill_id = @nBillDraftid) and flag <> 0)
   begin
     set @nRet = -15
     goto CheckOver
   end                      
   /*判断单据金额是否限额(整单)   -1   */
   
   select @limitTotal = SUM(ct.limitTotal) from Cashcoupon  cc
                inner join CashcouponType ct on cc.typeid =ct.typeid                      
	             where cc.ccid in
	              (select price_id 
	               from retailbill where p_id = -9999 and bill_id = @nBillDraftid)
	               
   if @limitTotal is null set @limitTotal = 0
   if @dBillTotal < @limitTotal 
   begin
     SET @NRET = -16
     GOTO CHECKOVER        
   end     
      
   select top 1 @nCCID = price_id from retailbill where bill_id =@nBillDraftid
   
   select @nTypeid = typeid from Cashcoupon where ccid = @nCCID
   
   select @cpcount = COUNT(1) from #checkCP
     if @cpcount is null set @cpcount = 0  
      
   if exists(select 1 from CashcouponMapping where typeid = @nTypeid)
   begin   
      /*按商品判断           -21 */
      if @limitflag = 1
      begin
        delete #checkP where p_id not in (select baseid from CashcouponMapping where typeid = @nTypeid) 
        select @dBillTotal = SUM(total) from #checkp
        if @dBillTotal < @cpcount * @limitTotal 
        begin
         set @nRet = -21
         goto CheckOver     
        end                  
      end
      /*按类别判断           -22      */
      if @limitflag = 2
      begin                               
        delete #checkP 
         where  p_id not in (
							select cm.baseinfo_id 
							from CashcouponMapping cp 
							inner join customCategory cg on cp.BaseID = cg.id
							inner join customCategoryMapping cm on cg.id = cm.category_id
							where cp.typeid = @nTypeid and cg.baseType = 0 and cm.deleted=0
							) 
        select @dBillTotal = SUM(total) from #checkp
        if @dBillTotal < @cpcount * @limitTotal 
        begin
         set @nRet = -22
         goto CheckOver     
        end                  
      end 
  end         
	 	 			 
	 set @nRet = 0
	 goto CheckOver
end
  	  	  

  CheckOver:
    if @nRet < 0 
      set @nRet = @nRet-50 /*避免后单据过账的其他返回值重复*/
	return @nRet
GO
