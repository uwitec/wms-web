
/*会员卡换卡记录*/
CREATE  procedure ts_L_qrExchangeVIPCard 
  @BeginDate varchar(50),
  @EndDate varchar(50),
  @VIPCardID int=0,
  @e_id int=0
as
begin
/*Params Ini begin*/
if @VIPCardID is null  SET @VIPCardID = 0
if @e_id is null  SET @e_id = 0
/*Params Ini end*/
  select ev.*,
         IsNull(v.CardNo,'') as OldCardNo,
         IsNull(v.Name,'') as OldCardName,
         IsNull(v.Tel,'') as OldTel,
         IsNull(v2.CardNo,'') as NewCardNo,
         IsNull(v2.Name,'') as NewCardName,
         IsNull(v2.Tel,'') as NewTel,
         IsNull(emp.Name,'') as EmpName         
    from ExchangeVIPCard ev left join VIPCard v on ev.OldVIPCardID=v.VIPCardID
                            left join VIPCard v2 on ev.NewVIPCardID=v2.VIPCardID
                            left join employees emp on ev.e_id=emp.emp_id
   where (ev.OldVIPCardID=@VIPCardID or ev.NewVIPCardID=@VIPCardID or @VIPCardID=0)
     and (ev.e_id=@e_id or @e_id=0)
     and ExchangeDate between @BeginDate and @EndDate

end
GO
