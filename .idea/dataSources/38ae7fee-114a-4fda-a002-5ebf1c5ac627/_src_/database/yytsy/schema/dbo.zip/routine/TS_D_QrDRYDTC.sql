

CREATE procedure TS_D_QrDRYDTC
@BeginDate	DATETIME,
@EndDate	DATETIME,
@y_id       INT,   /*分支机构*/
@e_id       INT,   /*收银员*/
@Custompro1 VARCHAR(100),    /*自定义属性1*/
@Custompro2 VARCHAR(100),    /*自定义属性2*/
@Custompro3 VARCHAR(100),    /*自定义属性3*/
@Custompro4 VARCHAR(100),    /*自定义属性4*/
@Custompro5 VARCHAR(100),    /*自定义属性5*/
@Page       INT              /*0汇总 1明细*/
AS  
  SET NOCOUNT ON 
  SELECT a.billid,a.billtype,a.billnumber,a.billdate,a.e_id,a.Y_ID,b.p_id,b.taxprice
         ,CASE WHEN a.billtype=13 THEN -1 ELSE 1 END*b.quantity quantity
         ,CASE WHEN a.billtype=13 THEN -1 ELSE 1 END*b.taxtotal taxtotal
         ,b.batchno,b.validdate,b.unitid
         ,c.serial_number,c.name,c.standard,c.makearea,c.trademark
         ,c.Custompro1,c.Custompro2,c.Custompro3
         ,c.Custompro4,c.Custompro5
         ,CASE WHEN a.billtype=12 THEN '零售单' ELSE '零售退货' END billname
         ,CAST(0 AS NUMERIC(25,8)) TCMoney
         ,CAST(0 AS NUMERIC(25,8)) YBMoney
         ,CAST(0 AS NUMERIC(25,8)) WXMoney
         ,CAST(0 AS NUMERIC(25,8)) ZFBMoney
         ,CAST(0 AS NUMERIC(25,8)) CashMoney
         ,0 IsOK
  INTO #QrDRYDTC
  FROM billidx a INNER JOIN salemanagebill b 
       ON a.billid=b.bill_id
       INNER JOIN products c
       ON b.p_id=c.product_id
  WHERE a.billdate BETWEEN @BeginDate AND @EndDate 
        AND a.billtype IN (12,13) AND a.billstates=0        
        AND (@y_id=0 OR a.Y_ID=@y_id)
        AND (@e_id=0 OR a.e_id=@e_id)
        AND b.AOID IN (0,5)
        AND (@Custompro1='' OR c.Custompro1 LIKE '%'+@Custompro1+'%')
        AND (@Custompro2='' OR c.Custompro2 LIKE '%'+@Custompro2+'%')
        AND (@Custompro3='' OR c.Custompro3 LIKE '%'+@Custompro3+'%')
        AND (@Custompro4='' OR c.Custompro4 LIKE '%'+@Custompro4+'%')
        AND (@Custompro5='' OR c.Custompro5 LIKE '%'+@Custompro5+'%')
  /*民政刷卡*/
  UPDATE R SET  
  TCMoney=R.taxtotal
  ,IsOK=1
  FROM #QrDRYDTC R INNER JOIN DRBillidx CI 
       ON R.billid=CI.Billid
  WHERE R.IsOK=0 AND CI.Billstates=0 AND CI.SettleFlag='600' AND CI.TCMoney>0
  /*医保刷卡*/
  UPDATE R SET  
  YBMoney=R.taxtotal
  ,IsOK=1
  FROM #QrDRYDTC R INNER JOIN DRBillidx CI 
       ON R.billid=CI.Billid
  WHERE R.IsOK=0 AND CI.Billstates=0 AND CI.SettleFlag='600' AND CI.YBMoney>0
  /*微信*/
  UPDATE M SET  
  WXMoney=M.taxtotal
  ,IsOK=1
  FROM account R INNER JOIN AccountDetail CI 
       ON R.account_id=CI.a_id
       INNER JOIN #QrDRYDTC M 
       ON CI.billid=M.billid
  WHERE R.class_id='000001000012' AND M.IsOK=0
  /*支付宝*/
  UPDATE M SET  
  ZFBMoney=M.taxtotal
  ,IsOK=1
  FROM account R INNER JOIN AccountDetail CI 
       ON R.account_id=CI.a_id
       INNER JOIN #QrDRYDTC M 
       ON CI.billid=M.billid
  WHERE R.class_id='000001000013' AND M.IsOK=0
  /*现金*/
  UPDATE #QrDRYDTC SET CashMoney=taxtotal WHERE IsOK=0
  
  IF @Page=0
  BEGIN
    SELECT t3.name yname,t2.name ename,t1.*
    FROM (
			SELECT Y_ID,e_id
				   ,SUM(TCMoney) TCMoney
				   ,SUM(YBMoney) YBMoney
				   ,SUM(WXMoney) WXMoney
				   ,SUM(ZFBMoney) ZFBMoney
				   ,SUM(CashMoney) CashMoney
			FROM #QrDRYDTC
			GROUP BY Y_ID,e_id
		 ) t1 LEFT JOIN employees t2 ON t1.e_id=t2.emp_id
		   LEFT JOIN company t3 ON t1.Y_ID=t3.company_id
    ORDER BY t1.Y_ID,t1.e_id
  END  
  ELSE 
  BEGIN
    SELECT t3.name yname,t2.name ename,t4.name uname,t1.*
    FROM #QrDRYDTC t1 LEFT JOIN employees t2 
         ON t1.e_id=t2.emp_id
         LEFT JOIN company t3 
         ON t1.Y_ID=t3.company_id
         LEFT JOIN unit t4 
         ON t1.unitid=t4.unit_id
    ORDER BY t1.Y_ID,t1.e_id,t1.billdate,t1.billid,t1.p_id    
  END  
  
  DROP TABLE #QrDRYDTC
GO
