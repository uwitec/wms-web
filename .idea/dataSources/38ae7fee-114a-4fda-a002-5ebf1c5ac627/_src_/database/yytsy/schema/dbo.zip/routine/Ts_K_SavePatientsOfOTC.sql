
create PROCEDURE Ts_K_SavePatientsOfOTC  
(  
  @Name      VARCHAR(20),  
  @Sex       VARCHAR(10),  
  @Age       INT = 0,  
  @Diagnose  VARCHAR(500),  
  @BillId    INT = 0,  
  @EId       INT = 0,  
  @YId       INT = 0,  
  @EName     VARCHAR(50),
  @Clinic	varchar(300),
  @Doctor	varchar(50),
  @Prepare   VARCHAR(80),
  @PathName varchar(200),
  @Audit_ID int,
  @Auditman varchar(50),
  @Tel varchar(80) = '',
  @Address varchar(200) = '',
  @IDCard varchar(20) = ''  
)  
AS   
BEGIN  
 DECLARE @PatientId INT  
 SET @PatientId = 0  
 IF NOT EXISTS(SELECT 1 FROM Patients  WHERE NAME = @Name AND sex = @Sex
               AND Tel = @Tel AND Address = @Address
               AND Birthday = CONVERT(VARCHAR(100), DATEADD(YEAR, -@Age, GETDATE()), 23) and billid=@BillId)  
 BEGIN  
  INSERT INTO Patients  
  (Name, sex, Tel, Birthday, [Job], [Address], Comment, IDCard,   
   BulidDate, Pos_Id, [Deleted], PinYin, [Guid], isVIP, VIP_ID,billid)  /*增加一个billid*/
  VALUES  
  (@Name, @Sex, @Tel, CONVERT(VARCHAR(100), DATEADD(YEAR, -@Age, GETDATE()), 23), '', @Address, '', @IDCard,   
   GETDATE(), @YId, 0, dbo.GetPy(@Name), NEWID(), 0, 0,@BillId)   
     
  IF @@ROWCOUNT <> 0  
   SET @PatientId = @@IDENTITY  
 END  
 ELSE  
 BEGIN  
  SELECT @PatientId = PatientID   /*存在该病人*/
   FROM Patients   
  WHERE NAME = @Name AND sex = @Sex AND Tel=@Tel AND Address=@Address AND Birthday = CONVERT(VARCHAR(100), DATEADD(YEAR, -@Age, GETDATE()), 23) and billid=@BillId   
 END  
   
 DECLARE @CaseId INT  
 SET @CaseId = 0  
 SELECT @CaseId = posid FROM Retailbillidx WHERE billid = @BillId  
 IF @CaseId > 0  
 BEGIN  
  UPDATE CaseHistory  /*诊断信息*/
  SET Patient_ID = @PatientId,  
   Age = @Age,  
   Doctor_ID = @EId,  
   Doctor = @EName,  
   Diagnose = @Diagnose,
	Custom1 = @Clinic,
	Custom2 = @Doctor,
	Custom3 = @Prepare,
	Pathname=@PathName,
	Audit_ID=@Audit_ID,
	Auditman=@Auditman     
  WHERE Case_ID = @CaseId  
 END  
 ELSE  
 BEGIN  
  INSERT INTO CaseHistory  
  (BillNo, Reg_ID, Patient_ID, Age, Doctor_ID, Doctor, CaseDate, SelfExp, Medical,  
   BodyExam, AssisExam, Diagnose, Deal, Custom1, Custom2, Custom3, Custom4,Pathname,Audit_ID,Auditman)  
  VALUES  
  ('', 0, @PatientId, @Age, @EId, @EName, GETDATE(), '', '',   
   '', '', @Diagnose, '', @Clinic, @Doctor, @Prepare, '',@PathName,@Audit_ID,@Auditman)  
  
  IF @@ROWCOUNT <> 0  
   SET @CaseId = @@IDENTITY   
 END  
   
 UPDATE Retailbillidx SET posid = @CaseId WHERE billid = @BillId  
 
  
END
GO
