create procedure ts_e_StoreWMSZAttemperSetSelect
 @BeginDate DateTime, /*开始时间*/
 @EndDate   DateTime, /*结束时间*/
 @Y_id      int=0,  /*机构id */
 @E_id      int=0, /*业务员Id*/
 @C_id      int=0, /*单位ID*/
 @ContactPeople varchar(100)='',/*联系人*/
 @BillNumber varchar(100)='',/*单据号*/
 @PSRoadId  int=0/*配送线路*/
as
begin
  select  a.billid,isnull(b.name,'') as cname,isnull(b.contact_personal,'') as ContactPeople,isnull(c.name,'') as EName,
          isnull(a.TrafficType,'') as  TranTyped, a.billdate  as billdated,isnull(a.billnumber,'')  as BillNumber,
          isnull(d.name,'') as sname,f.wholenum as wholenum,g.Zeronum as Zeronum,DetailCount as DetailCount,
          a.auditdate as AuditDate,
          case a.PrioRity when 0 then '普通' when 1 then '补货' when 2 then '优先' else '急救' end as  yxjname 
          
          from orderidx a
          left join clients b on a.c_id=b.client_id
          left join employees c on a.e_id=c.emp_id
          left join storages  d on a.sout_id=d.storage_id
          left join (select  COUNT(*) as DetailCount,bill_id from OrderBill group by bill_id) e on a.billid=e.bill_id
          left join (
                       select SUM(Floor(case (CASE WHEN b.wholeUnit_id = b.unit2_id THEN rate2 WHEN b.wholeUnit_id = b.unit3_id THEN rate3 WHEN b.wholeUnit_id = b.unit4_id THEN rate4 ELSE 1 END) when  0 then 0 else (a.quantity/(CASE WHEN b.wholeUnit_id = b.unit2_id THEN rate2 WHEN b.wholeUnit_id = b.unit3_id THEN rate3 WHEN b.wholeUnit_id = b.unit4_id THEN rate4 ELSE 1 END))end))  as wholenum,
                              a.bill_id
                        from OrderBill a left join products b on  a.p_id=b.product_id
                        where  p_id>0  
                        group by bill_id
                 ) f on a.billid=f.bill_id
          left join (
					    select sum(case (CASE WHEN b.wholeUnit_id = b.unit2_id THEN rate2 WHEN b.wholeUnit_id = b.unit3_id THEN rate3 WHEN b.wholeUnit_id = b.unit4_id THEN rate4 ELSE 1 END) when 0 then 0 else  (a.quantity%(CASE WHEN b.wholeUnit_id = b.unit2_id THEN rate2 WHEN b.wholeUnit_id = b.unit3_id THEN rate3 WHEN b.wholeUnit_id = b.unit4_id THEN rate4 ELSE 1 END))end) as Zeronum,
										a.bill_id from OrderBill a left join products b on  a.p_id=b.product_id
					  			 where  p_id>0 
					  			 group by  a.bill_id
           ) g on a.billid=g.bill_id    
       where 
       a.billdate between @BeginDate and @EndDate and
       (a.y_id=@y_id or @Y_id=0) and 
       (a.e_id=@E_id or @E_id=0) and 
       (a.c_id=@C_id or @C_id=0) and 
       b.contact_personal like '%'+@ContactPeople+'%' and 
       a.billnumber like  '%'+@BillNumber+'%' and 
       (b.RoadID=@PSRoadId or @PSRoadId=0) and
       a.billtype in (154,14)
end
GO
