CREATE	proc TS_C_BaseCategoryTemplate
(
@nSx_id int,
@nBaseType int,
@nTypeName varchar(400),
@nType int,
@nIsUse int,
@nFieldName varchar(20)
)
as
begin
  if NOT EXISTS (Select 1 from CategoryTemplate Where Sx_id = @nSx_id And BaseType = @nBaseType)
  begin 
    insert into CategoryTemplate
      (Sx_id,BaseType,TypeName,Type,IsUse,FieldName)
    values 
      (@nSx_id,@nBaseType,@nTypeName,@nType,@nIsUse,@nFieldName)     
  end 
  else
  begin
    Update CategoryTemplate set TypeName = @nTypeName,Type = @nType, IsUse = @nIsUse 
    Where Sx_id = @nSx_id and BaseType = @nBaseType
  end 
  if @nTypeName = ''
    Update CategoryTemplate Set IsUse = 0 Where Sx_id = @nSx_id and BaseType = @nBaseType
end
GO
