-- =============================================
-- Author:	<杨林>
-- Create date: <2015-07-02>
-- Description:	<手机版-用于按时间段查应收账款汇总>
-- =============================================
CREATE procedure [dbo].[WebApp_QueryPhone_Arap]
(
	@BeginDate datetime =0 , 
	@EndDate datetime  =0,
	@Params VARCHAR(100)--预留接口进行后期特殊版本传值
)
AS
BEGIN


     declare @ar_id varchar(30),
             @ap_id varchar(30),
             @allar float,
             @allap float,
             @ArApByDepartMent int,
             @listmode int  
     select @ar_id=[class_id],@allar=[cur_total] from account where [account_id]=9
     select @ap_id=[class_id],@allap=[cur_total] from account where [account_id]=15
     select @ArApByDepartMent = 0,@listmode = 3
     exec ts_GetSysValue 'ArApByDepartMent',@ArApByDepartMent output  

     if exists(select 1 from tempdb.dbo.sysobjects where [id] = object_id('tempdb.dbo.#c'))         drop table #c
     if exists(select 1 from tempdb.dbo.sysobjects where [id] = object_id('tempdb.dbo.#temp_arap')) drop table #temp_arap

      create table #c
      (
         class_id  varchar(30),
         client_id int,
         Artotal   float,
         Aptotal   float,
         Artotal_ini float,
         Aptotal_ini float,
         pre_artotal_ini float,
         pre_aptotal_ini float,
         pre_artotal float,
         pre_aptotal float
       )

      insert into #c(class_id,client_id,artotal,aptotal,artotal_ini,aptotal_ini,pre_artotal_ini,
             pre_aptotal_ini,pre_artotal,pre_aptotal)
      select class_id,client_id,artotal,aptotal,artotal_ini,aptotal_ini, pre_artotal_ini,
             pre_aptotal_ini,pre_artotal,pre_aptotal
        from clients 
       where @arapbydepartment=0 and deleted<>1
      union all
      select c.class_id,c.client_id,
             sum(a.artotal) as artotal,sum(a.aptotal) as aptotal,sum(a.artotal_ini) as artotal_ini,
             sum(a.aptotal_ini) as aptotal_ini,sum(a.pre_artotal_ini) as pre_artotal_ini,
             sum(a.pre_aptotal_ini) as pre_aptotal_ini,
             sum(a.pre_artotal) as pre_artotal,
             sum(a.pre_aptotal) as pre_aptotal
       from clientdepartarap a,clients c
      where  a.c_id=c.client_id
         and @arapbydepartment=1 and  deleted<>1
         group by c.class_id,c.client_id



        select a.[class_id],
 	    isnull(case when sum(a.[artotal]-a.[aptotal])>0 then sum(a.[artotal]-a.[aptotal]) else 0 end, 0) as [artotal], 
	    isnull(case when sum(a.[artotal]-a.[aptotal])<0 then -(sum(a.[artotal]-a.[aptotal])) else 0 end, 0) as [aptotal], 
	    isnull(case when sum(a.[artotal_ini]+isnull(b.[beginartotal], 0)-a.[aptotal_ini]-isnull(b.[beginaptotal], 0))>0 then sum(a.[artotal_ini]+isnull(b.[beginartotal], 0)-a.[aptotal_ini]-isnull(b.[beginaptotal], 0)) else 0 end, 0) as [beginartotal], 
	    isnull(case when sum(a.[artotal_ini]+isnull(b.[beginartotal], 0)-a.[aptotal_ini]-isnull(b.[beginaptotal], 0))<0 then -sum(a.[artotal_ini]+isnull(b.[beginartotal], 0)-a.[aptotal_ini]-isnull(b.[beginaptotal], 0)) else 0 end, 0) as [beginaptotal], 
	    isnull(case when sum(b.[nowartotal]-b.[nowaptotal])>0 then sum(b.[nowartotal]-b.[nowaptotal]) else 0 end, 0) as [nowartotal], 
	    isnull(case when sum(b.[nowartotal]-b.[nowaptotal])<0 then -sum(b.[nowartotal]-b.[nowaptotal]) else 0 end, 0) as [nowaptotal], 
	    isnull(case when sum(a.[artotal_ini]+isnull(b.[endartotal], 0)-a.[aptotal_ini]-isnull(b.[endaptotal], 0))>0 then sum(a.[artotal_ini]+isnull(b.[endartotal], 0)-a.[aptotal_ini]-isnull(b.[endaptotal], 0)) else 0 end, 0) as [endartotal], 
	    isnull(case when sum(a.[artotal_ini]+isnull(b.[endartotal], 0)-a.[aptotal_ini]-isnull(b.[endaptotal], 0))<0 then -sum(a.[artotal_ini]+isnull(b.[endartotal], 0)-a.[aptotal_ini]-isnull(b.[endaptotal], 0)) else 0 end, 0) as [endaptotal],
            isnull(sum(b.beginpreartotal),0) as beginpreartotal,
            isnull(sum(b.beginpreaptotal),0) as beginpreaptotal,
            isnull(sum(b.nowpreartotal),0)   as nowpreartotal,
            isnull(sum(b.nowpreaptotal),0)   as nowpreaptotal,
            isnull(sum(b.endpreartotal),0)   as endpreartotal,
            isnull(sum(b.endpreaptotal),0)   as endpreaptotal into #temp_arap
	    from #c a left join
	    (
              select ad.[class_id],
		      isnull(sum(case when [aclass_id]=@ar_id and bi.[billdate]<@begindate then [jdmoney] end), 0) as [beginartotal], 
		      isnull(sum(case when [aclass_id]=@ap_id and bi.[billdate]<@begindate then [jdmoney] end), 0) as [beginaptotal],
	              isnull(sum(case when [aclass_id]='000002000006' and bi.[billdate]<@begindate then [jdmoney] end), 0) as [beginpreartotal],
	              isnull(sum(case when [aclass_id]='000001000009' and bi.[billdate]<@begindate then [jdmoney] end), 0) as [beginpreaptotal],
		      isnull(sum(case when [aclass_id]=@ar_id and bi.[billdate] between @begindate
		         and @enddate then [jdmoney] end), 0) as [nowartotal], 
		      isnull(sum(case when [aclass_id]=@ap_id and bi.[billdate] between @begindate
		        and @enddate then [jdmoney] end), 0) as [nowaptotal], 
                      isnull(sum(case when [aclass_id]='000002000006' and bi.[billdate] between @begindate and @enddate then [jdmoney] end), 0) as [nowpreartotal],
                      isnull(sum(case when [aclass_id]='000001000009' and bi.[billdate] between @begindate and @enddate then [jdmoney] end), 0) as [nowpreaptotal],
	              isnull(sum(case when [aclass_id]=@ar_id and bi.[billdate]<=@enddate then [jdmoney] end), 0) as [endartotal], 
	              isnull(sum(case when [aclass_id]=@ap_id and bi.[billdate]<=@enddate then [jdmoney] end), 0) as [endaptotal],
                      isnull(sum(case when [aclass_id]='000002000006' and bi.[billdate]<=@enddate then [jdmoney] end), 0) as [endpreartotal],
                      isnull(sum(case when [aclass_id]='000001000009' and bi.[billdate]<=@enddate then [jdmoney] end), 0) as [endpreaptotal]  
	      from (select [cclass_id] as [class_id], [billid], [aclass_id], [jdmoney] from vw_x_adetail where [aclass_id] in (@ar_id,@ap_id,'000002000006','000001000009')) ad,
 	           (select [billid], convert(varchar(10),billdate,20) as [billdate]
                      from billidx
                     where (c_id   in (select client_id from #c union select 0) and billtype not in (78,79) or 
                            hyc_id in (select client_id from #c union select 0) and billtype in (78,79)) 
                       and [billstates]='0'                       
                       ) bi
	      where bi.[billid]=ad.[billid]
	      group by ad.[class_id]
               )b  on a.[class_id]=b.[class_id] group by a.[class_id]


--查询报表结果:	     
	    select a.[client_id], a.[class_id], a.[name],
	           isnull(sum(b.[beginartotal]), 0) as [beginartotal], 
	           isnull(sum(b.[beginaptotal]), 0) as [beginaptotal],
                   isnull(sum(b.beginpreartotal),0)+isnull(a.pre_artotal_ini,0) as beginpreartotal,
                   isnull(sum(b.beginpreaptotal),0)+isnull(a.pre_aptotal_ini,0) as beginpreaptotal,
	           isnull(sum(b.[endartotal]), 0)-isnull(sum(b.[beginartotal]), 0) as [nowartotal], 
	           isnull(sum(b.[endaptotal]), 0)-isnull(sum(b.[beginaptotal]), 0) as [nowaptotal],
                   isnull(sum(b.nowpreartotal),0) as nowpreartotal,
                   isnull(sum(b.nowpreaptotal),0) as nowpreaptotal,

	           isnull(sum(b.[endartotal]), 0) as [endartotal], 
	           isnull(sum(b.[endaptotal]), 0) as [endaptotal],
                   isnull(sum(b.endpreartotal),0)+isnull(a.pre_artotal_ini,0) as endpreartotal,
                   isnull(sum(b.endpreaptotal),0)+isnull(a.pre_aptotal_ini,0) as endpreaptotal

            from  (select  c.[client_id], c.[class_id], c.[name],c.[deleted],c.child_number,rowindex,
                           isnull(d.pre_artotal_ini,0.0) as pre_artotal_ini,
                           isnull(d.pre_aptotal_ini,0.0) as pre_aptotal_ini,
	                   isnull(d.pre_artotal,0.0)     as pre_artotal,
                           isnull(d.pre_aptotal,0.0)     as pre_aptotal            
                     from vw_clients c  join #c d on c.client_id = d.client_id
                    where c.deleted<>1
                   ) a            
       	             join #temp_arap b on @listmode in (3)   and left(b.[class_id], len(a.[class_id]))=a.[class_id] or 
                                          @listmode in (1,2) and b.class_id=a.class_id
           where b.artotal+b.aptotal+b.beginartotal+b.beginaptotal+b.nowartotal+b.nowaptotal+b.endartotal+b.endaptotal+b.beginpreartotal+b.beginpreaptotal+b.nowpreartotal+b.nowpreaptotal+b.endpreartotal+b.endpreaptotal<>0 
	  group by a.[client_id], a.[class_id], a.[name],a.pre_aptotal_ini,
                   a.pre_artotal_ini,a.pre_aptotal_ini,a.pre_artotal_ini,a.rowindex
           order by case when @listmode in (1,2) then a.class_id else cast(len(cast(a.rowindex as varchar)) as varchar) end

end
GO
