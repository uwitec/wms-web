Create  procedure Ts_T_InsorupGLrelation
( @glid  int,  /*自增id*/
  @glpid int, /*关联商品id*/
  @p_id  int   /*普通商品id*/
)
AS
if @glid=0
begin
  insert into GLProlation(glp_id,p_id) values(@glpid,@p_id)
end
else
begin
  update GLProlation set glp_id=@glpid,p_id=@p_id where Gl_id=@glid 
end
GO
