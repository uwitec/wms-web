/* select * from dbo.FN_DRPrintText(12,384)*/
CREATE FUNCTION FN_DRPrintText 
(
  @billtype INT,
  @billid INT
)
RETURNS TABLE
AS
  RETURN 
  ( /*零售和对应退货均记录的是零售单id*/
    /*CashMoney=已对码商品的总额超出(医保余额+社保补贴)的钱*/
    SELECT TOP 1 ISNULL(b.AAC003,'0') EmpName,ISNULL(b.EmpNum,'0') YBCardNo,a.DR10Num
           ,a.YBMoney,a.CurYBMoney,a.CurYBMoney-a.YBMoney LastMoney
           ,CASE WHEN d.billid IS NULL THEN a.CashMoney ELSE d.ysmoney-a.YBMoney-a.TCMoney END CashMoney
           ,a.TCMoney,ISNULL(c.TCAreaName,'') TCAreaName,ISNULL(e.TCAreaName,'') YBCompany
           ,a.DR01Num
    FROM DRBillidx a LEFT JOIN DRYDEmpinfo b
         ON a.EmpNum=b.EmpNum AND a.TCAreaNo=b.YAB003
         LEFT JOIN DRTCArea c 
         ON a.TCAreaNo=c.TCAreaNo AND c.Kind=0
         LEFT JOIN billidx d
         ON d.billid=@billid AND a.Billtype=d.billtype
         LEFT JOIN DRTCArea e 
         ON d.Y_ID=e.TCAreaNo AND e.Kind=1
    WHERE @billtype=12 AND a.Billid=@billid AND a.Billtype=12 AND a.SettleFlag='600' AND a.Billstates=0
    UNION ALL 
    SELECT TOP 1 ISNULL(b.AAC003,'0') EmpName,ISNULL(b.EmpNum,'0') YBCardNo,a.DR10Num
           ,a.YBMoney,a.CurYBMoney,a.CurYBMoney-a.YBMoney LastMoney
           ,CASE WHEN d.billid IS NULL THEN a.CashMoney ELSE -1*(d.ysmoney-a.YBMoney-a.TCMoney) END CashMoney
           ,a.TCMoney,ISNULL(c.TCAreaName,'') TCAreaName,ISNULL(e.TCAreaName,'') YBCompany
           ,a.DR01Num
    FROM DRBillidx a LEFT JOIN DRYDEmpinfo b
         ON a.EmpNum=b.EmpNum AND a.TCAreaNo=b.YAB003
         LEFT JOIN DRTCArea c 
         ON a.TCAreaNo=c.TCAreaNo AND c.Kind=0
         LEFT JOIN billidx d
         ON d.billid=@billid AND a.Billtype=d.billtype
         LEFT JOIN DRTCArea e 
         ON d.Y_ID=e.TCAreaNo AND e.Kind=1
    WHERE @billtype=13 AND a.Billid=(SELECT TOP 1 b.bill_id
		  FROM salemanagebill a INNER JOIN salemanagebill b 
			   ON a.orgbillid=b.smb_id
		  WHERE a.bill_id=@billid AND a.p_id>0 AND b.p_id>0) 
          AND a.Billtype=13 AND a.SettleFlag='601' AND a.Billstates=0 
  )
GO
