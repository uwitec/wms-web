CREATE PROCEDURE Ts_K_GetvtLogisticsDetail(@SendId INT, @BillId INT)
AS
BEGIN
	DECLARE @BillType INT, @CId INT
	SELECT @BillType = ISNULL(b.billtype, 0), @CId = ISNULL(b.c_id, 0)
	    FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid 
	WHERE s.sendid = @SendId AND s.billid = @BillId
	
	SELECT v.name AS P_Name, v.alias AS P_Alias, v.serial_number AS P_Code, v.MedName AS P_MedType, v.[standard] AS P_Standard,
	       v.trademark AS P_Trademark, v.Factory AS P_FACTORY, v.makearea AS P_MakeArea, v.permitcode AS P_PermitCode,
	       CASE WHEN d.makedate = '1900-01-01' THEN '' ELSE d.makedate END AS P_makedate, 
	       CASE WHEN d.validdate = '1900-01-01' THEN '' ELSE d.validdate END AS P_validity,
	       d.batchno AS P_serial, v.unit1name AS P_Unit, d.quantity AS Qty, d.saleprice AS price, d.total,
	       s.SendTime AS Date_Sale, CASE WHEN b.billtype IN (10, 11, 16, 17, 212, 21) THEN e.name ELSE f.name END AS C_Name,
	       s.trafficMode AS Tran_Tool, s.DeviceTemperature_Begin AS BeginTmp, s.AffirmTemperature AS EndTmp, 
	       CASE WHEN s.ArriveCustomer = '1900-01-01' THEN s.ArriveStation ELSE s.ArriveCustomer END AS EndDate,
	       s.TransportationHour AS TrafficTime,  '' AS TempControl, '' AS TempControlMode, s.trafficMode AS TrafficType,
	       ISNULL(g.name, '') AS e_Name, d.comment, v.StorageCon AS Ycondition,
	       d.p_id AS P_product_ID, b.c_id AS c_client_id, s.Driver AS E_Emp_id, v.unit1_id AS P_Unit_id, v.rate2 AS P_Rate2,
	       v.rate3 AS P_Rate3, v.rate4 AS P_Rate4, 0 AS P_UnitType, 0 AS Qty2, v.gspflag AS P_GspFlag, v.validday AS P_ValidDay,
	       v.validmonth AS P_ValidMonth, v.IsCold, v.IsSpec, s.serial_number, s.consign_dep, s.CamionCode, s.consignee,
	       d.qualitystatus, s.Porthole AS Tran_Add, c.Discharge AS Send_Add
		FROM Sendidx s INNER JOIN Sendmangebill c ON s.Send_id = c.sendid 
		               INNER JOIN billidx b ON c.billid = b.billid
		               INNER JOIN salemanagebill d ON b.billid = d.bill_id
		               INNER JOIN vw_Products v ON d.p_id = v.Product_Id 
		               LEFT JOIN clients e ON b.c_id = e.client_id 
		               LEFT JOIN company f ON b.c_id = f.company_id
		               LEFT JOIN employees g ON s.Driver = g.emp_id
	WHERE s.Send_id = @SendId AND b.billtype IN (10, 11, 16, 17, 212, 21, 150, 152) AND
	      c.sm_id IN (  SELECT s.sm_id
						  FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid 
						WHERE s.sendid = @SendId AND b.billtype = @BillType AND 
						      b.c_id = @CId)
	UNION ALL
	SELECT v.name AS P_Name, v.alias AS P_Alias, v.serial_number AS P_Code, v.MedName AS P_MedType, v.[standard] AS P_Standard,
	       v.trademark AS P_Trademark, v.Factory AS P_FACTORY, v.makearea AS P_MakeArea, v.permitcode AS P_PermitCode,
	       CASE WHEN d.makedate = '1900-01-01' THEN '' ELSE d.makedate END AS P_makedate, 
	       CASE WHEN d.validdate = '1900-01-01' THEN '' ELSE d.validdate END AS P_validity,
	       d.batchno AS P_serial, v.unit1name AS P_Unit, d.quantity AS Qty, d.buyprice AS price, d.total,
	       s.SendTime AS Date_Sale, CASE WHEN b.billtype IN (10, 11, 16, 17, 212, 21) THEN e.name ELSE f.name END AS C_Name,
	       s.trafficMode AS Tran_Tool, s.DeviceTemperature_Begin AS BeginTmp, s.AffirmTemperature AS EndTmp, 
	       CASE WHEN s.ArriveCustomer = '1900-01-01' THEN s.ArriveStation ELSE s.ArriveCustomer END AS EndDate, 
	       s.TransportationHour AS TrafficTime, '' AS TempControl, '' AS TempControlMode, s.trafficMode AS TrafficType,
	       ISNULL(g.name, '') AS e_Name, d.comment, v.StorageCon AS Ycondition,
	       d.p_id AS P_product_ID, b.c_id AS c_client_id, s.Driver AS E_Emp_id, v.unit1_id AS P_Unit_id, v.rate2 AS P_Rate2,
	       v.rate3 AS P_Rate3, v.rate4 AS P_Rate4, 0 AS P_UnitType, 0 AS Qty2, v.gspflag AS P_GspFlag, v.validday AS P_ValidDay,
	       v.validmonth AS P_ValidMonth, v.IsCold, v.IsSpec, s.serial_number, s.consign_dep, s.CamionCode, s.consignee,
	       d.qualitystatus, s.Porthole AS Tran_Add, c.Discharge AS Send_Add
		FROM Sendidx s INNER JOIN Sendmangebill c ON s.Send_id = c.sendid 
		               INNER JOIN billidx b ON c.billid = b.billid
		               INNER JOIN buymanagebill d ON b.billid = d.bill_id
		               INNER JOIN vw_Products v ON d.p_id = v.Product_Id 
		               LEFT JOIN clients e ON b.c_id = e.client_id 
		               LEFT JOIN company f ON b.c_id = f.company_id
		               LEFT JOIN employees g ON s.Driver = g.emp_id
	WHERE s.Send_id = @SendId AND b.billtype IN (16, 17, 21) AND
	      c.sm_id IN (  SELECT s.sm_id
						  FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid 
						WHERE s.sendid = @SendId AND b.billtype = @BillType AND 
						      b.c_id = @CId)
END
GO
