

CREATE PROCEDURE Ts_K_GetRateFromBarCode(@PId INT, @BarCode VARCHAR(100))
AS
BEGIN
	SELECT TOP 1 CASE WHEN a.Rate = 0 THEN 1 ELSE a.Rate END AS Rate FROM (
	SELECT p.unit1_id AS unitid, 1 AS Rate FROM products p WHERE p.product_id = @PId	            
	UNION ALL
	SELECT p.unit2_id AS unitid, P.rate2 AS Rate FROM products p WHERE p.product_id = @PId
	UNION ALL
	SELECT p.unit3_id AS unitid, P.rate3 AS Rate FROM products p WHERE p.product_id = @PId
	UNION ALL
	SELECT p.unit4_id AS unitid, P.rate4 AS Rate FROM products p WHERE p.product_id = @PId
	) a WHERE a.unitid IN (SELECT unitid FROM barcode b WHERE b.p_id = @PId AND b.barcode = @BarCode)
END
GO
