/*[BillStates] [int] DEFAULT (0) NOT NULL,             --结算状态  0未结算  1结算中  2 已结算*/
create procedure ts_e_PayMoneySelect
   @BeginDate   varchar(100),   /*开始日期*/
   @EndDate     varchar(100),    /*结束日期*/
   @C_id        int=0,/*单位ID*/
   @InvioceNumber varchar(100),/*发票编号*/
   @billnumber    varchar(100),/*单据编号*/
   @InputId       int=0, /*制单人ID*/
   @typed         varchar(10),/*区分主表还是明细表 'A' 查主表信息;'B' 查明细信息*/
   @Billid        Int=0 /*传入主表的ID查明细表，主要用于'B'*/
as
begin
 if @typed='A'
 begin
   select Case BillStates when 0 then '未结算' when 1 then '结算中' when 2 then '已结算' end as IsSettlement,
         BILLDATE,isnull(BillNumber,'') as BillNumber,isnull(InvoiceNumber,'') as InvoiceNumber,
         isnull(b.serial_number,'') as  C_Number,
         isnull(b.name,'') as C_NAME,PayMoney,isnull(c.name,'') as  IMAN,
         isnull(a.Comment,'') as Comment,billid,BillStates
         from PaymentIdx a left join clients b on a.c_id=b.client_id 
                           left join employees c on a.e_id=c.emp_id
             where (a.billdate>= @BeginDate) and (a.billdate<=@EndDate) 
                                   and  (a.c_id =@C_id or @C_id=0) 
                                   and a.invoicenumber like '%'+@InvioceNumber+'%'
                                   and a.billnumber    like '%'+@billnumber+'%'
                                   and (a.E_id =@InputId or @InputId=0)
 end
 else
 begin 
    SELECT * FROM (
    select a.Bill_Id,a.smb_id,  a.P_id  as P_id, isnull(b.name,'') as YName,
           a.Y_id,isnull(c.BillNumber,'') as BillNumber,c.BillDate,
           isnull(e.billnumber,'') as  BuyBillNumber  
           ,e.billdate as BuyBillDate,isnull(f.serial_number,'') as serial_number,
           isnull(f.alias,'') as ALIAS,isnull(f.name,'') as Name,
           isnull(f.standard,'') as STANDARD,isnull(f.permitcode,'') as P_PERMITCODE, 
           isnull(g.name,'') as UName,
           isnull(f.Custompro1,'') as Custompro1,isnull(f.Custompro2,'') as Custompro2,
           isnull(f.Custompro3,'') as Custompro3,
           isnull(f.Custompro4,'') as Custompro4,isnull(f.Custompro5,'') as Custompro5,
           case when e.billtype = 21 then -d.quantity else d.quantity end as quantity,
           isnull(d.taxprice,0) as taxprice,
	       case when e.billtype = 21 then -d.taxtotal else d.taxtotal end as taxtotal,
           isnull(d.batchno,'') as P_BATCHNO,isnull(d.MakeDate,'') as MakeDate,
           isnull(d.ValidDate,'') as ValidDate,isnull(h.AccountComment,'') as  Factory ,
           isnull(d.factoryid,0) as factoryid, Case c.BillStates when 0 then '未结算' when 1 then '结算中' when 2 then '已结算' end as IsSettlement
            from PaymentBill a left join  company b on a.y_id=b.company_id
                                                      left join PaymentIdx c on a.Bill_Id=c.BillId
                                                      left join buymanagebill d on a.BuyDetai_ID=d.smb_id
                                                      left join billidx       e on a.BuyBill_Id=e.billid
                                                      left join products      f on a.P_id=f.product_id
                                                      left join unit g on f.unit1_id=g.unit_id
                                                      left join basefactory h on d.factoryid=h.CommID
                                                      where a.bill_id=@Billid and e.billtype in (20,21)
          UNION ALL
              select a.Bill_Id,a.smb_id,  a.P_id  as P_id, isnull(b.name,'') as YName,
           a.Y_id,isnull(c.BillNumber,'') as BillNumber,c.BillDate,
           isnull(e.billnumber,'') as  BuyBillNumber  
           ,e.billdate as BuyBillDate,isnull(f.serial_number,'') as serial_number,
           isnull(f.alias,'') as ALIAS,isnull(f.name,'') as Name,
           isnull(f.standard,'') as STANDARD,isnull(f.permitcode,'') as P_PERMITCODE, 
           isnull(g.name,'') as UName,
           isnull(f.Custompro1,'') as Custompro1,isnull(f.Custompro2,'') as Custompro2,
           isnull(f.Custompro3,'') as Custompro3,
           isnull(f.Custompro4,'') as Custompro4,isnull(f.Custompro5,'') as Custompro5,
           isnull(d.quantity,0) as quantity,
           isnull(cast(m.taxprice as NUMERIC(25,8)),0) as taxprice,
           isnull(cast(m.taxtotal as NUMERIC(25,8)),0) as taxtotal,
           isnull(d.batchno,'') as P_BATCHNO,isnull(d.MakeDate,'') as MakeDate,
           isnull(d.ValidDate,'') as ValidDate,isnull(h.AccountComment,'') as  Factory ,
           isnull(d.factoryid,0) as factoryid, Case c.BillStates when 0 then '未结算' when 1 then '结算中' when 2 then '已结算' end as IsSettlement
           from PaymentBill a left join  company b on a.y_id=b.company_id
           LEFT JOIN (SELECT distinct a.smb_id,isnull(a.taxprice-b.taxprice,0) AS taxprice,isnull(a.taxtotal+b.taxtotal,0) AS taxtotal FROM
                      (SELECT smb_id,orgbillid,taxprice,taxtotal FROM buymanagebill a 
                      LEFT JOIN billidx b ON a.bill_id = b.billid 
                      WHERE b.billtype IN (24,25) AND a.iotag = 0 and b.billstates = 0) a
                   LEFT JOIN 
                     (SELECT smb_id,orgbillid,taxprice,taxtotal FROM buymanagebill a 
                      LEFT JOIN billidx b ON a.bill_id = b.billid 
                      WHERE b.billtype IN (24,25) AND a.iotag = 1 and b.billstates = 0) b
                      ON a.orgbillid = b.orgbillid
             )m on m.smb_id = a.BuyDetai_ID
             left join PaymentIdx c on a.Bill_Id=c.BillId
             left join buymanagebill d on a.BuyDetai_ID=d.smb_id
             left join billidx       e on a.BuyBill_Id=e.billid
             left join products      f on a.P_id=f.product_id
             left join unit g on f.unit1_id=g.unit_id
             left join basefactory h on d.factoryid=h.CommID
             where a.bill_id=@Billid and e.billtype in (24,25)
     )a order by smb_id
 end
end
GO
