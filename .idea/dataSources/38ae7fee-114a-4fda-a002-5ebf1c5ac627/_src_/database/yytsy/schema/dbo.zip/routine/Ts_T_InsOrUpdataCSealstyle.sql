/************************************************************
--过程名称：印鉴票样添加修改
--创建人：  YANRUI
--创建时间：2014-04-16
--最后修改:


参数说明：
		  @st_id  --0为添加，不为0是修改

备注：
**************************************************************/
create proc [dbo].[Ts_T_InsOrUpdataCSealstyle]
(   @st_id     int,
    @c_id      int,
    @name      varchar(60),
    @path      varchar(120),
    @comment   varchar(200)
    
)
as

if @st_id  = 0
begin	
	INSERT INTO [dbo].[CSealstyle] 
	(
	 [c_id],
	 [name],
	 [pic_path],
	 [comment]
	)
	Values
	(
	 @c_id,   
	 @name,
	 @path,    	 
	 @comment
	)
  if @@rowCount=0 
	 return -1
  else 
	 return @@IDENTITY
end else
begin
  update CSealstyle 
  set [c_id]=@c_id,
      [name]  = @name,
	  [pic_path]   = @path,
	  [comment]=@comment	 
  where st_id =@st_id
  return @st_id
end
GO
