create procedure ts_e_StoreWMSSelectBaseInfo
 @id integer,/*代表传入库区或者区域或者货位ID*/
 @QrName varchar(10)='',
 @Stype varchar(10)=''/*'KQ' 表示库区，'QY' 表示区域，'HW'表示货位,'ZCQ' 表示暂存区*/

as
begin
  if @Stype='KQ' 
  begin
	   if @ID=0 
	   begin
		  select  b.serial_number as Scode,b.name as sname,s_id as Store_id,
			  a.sa_id as Store_KQ_ID,a.serial_number as KQcode,a.name as KQname,
			  case isnull(d.SAType,0) when 0 then '整货库' when 1 then '零货库' else  '待验库' end as kQType,
			  case isnull(d.SAQuantityType,0) when 0 then '合格品库' when 1 then '不合格品库' else  '待退厂库' end as KQQuantityType,
			  case isnull(d.SAPickType,0) when 0 then '纸单' when 1 then '电子标签' else  'PDA' end as KQPickType,
			  case isnull(d.SAPrintType,0) when 0 then '整件标签打印' when 1 then '纸单拣货打印' else  '电子标签打印' end as KQPrintType,
			  c.name as yname
		      from stockArea a left join storages b on a.s_id=b.storage_id
		                       left join company  c on b.Y_ID=company_id
		                       left join WMSStockArea d on a.sa_id=d.Sa_ID
		      where a.deleted=0
	   end
	   else
	   begin
	      select  b.serial_number as Scode,b.name as sname,s_id as Store_id,
			  a.sa_id as Store_KQ_ID,a.serial_number as KQcode,a.name as KQname,
			  d.SAType as kQType,
			  d.SAQuantityType as KQQuantityType,
			  d.SAPickType as KQPickType,
			  d.SAPrintType  as KQPrintType,
			  c.name as yname
		      from stockArea a left join storages b on a.s_id=b.storage_id
		                       left join company  c on b.Y_ID=company_id
		                       left join WMSStockArea d on a.sa_id=d.Sa_ID
		      where a.sa_id=@ID
	   end
  end
  if @Stype='QY' 
  begin
	   if @ID=0 
	   begin
		  select c.name as sname,c.serial_number as scode,a.Name as qyname,a.serial_number as qycode,
		         b.serial_number as kqcode,b.name as kqname,a.ID as Store_QY_Id,b.sa_id  as Store_KQ_Id,
		         c.storage_id as store_id,a.RegionCode,a.RegionComent 
		      from WMSRegion a  left join stockArea b on  a.Store_KQ_ID=b.sa_id
		                        left join storages  c on b.s_id=c.storage_id
		      where a.deleted=0 and (a.Name like '%'+@QrName+'%' or a.serial_number like '%'+@QrName+'%')
		                
	   end
	   else
	   begin
	      select c.name as sname,c.serial_number as scode,a.Name as qyname,a.serial_number as qycode,
		         b.serial_number as kqcode,b.name as kqname,a.ID as Store_QY_Id,b.sa_id  as Store_KQ_Id,
		         c.storage_id as store_id,a.RegionCode,a.RegionComent 
		      from WMSRegion a  left join stockArea b on  a.Store_KQ_ID=b.sa_id
		                        left join storages  c on b.s_id=c.storage_id
		      where a.ID=@ID
	   end
  end
  if @Stype='HW' 
  begin
	   if @ID=0 
	   begin
		  select a.loc_id,a.s_id, isnull(d.serial_number,'') as scode,isnull(d.name,'') as sname,isnull(c.serial_number,'') as kqcode,
		         isnull(c.name,'') as kqname,
		         isnull(b.serial_number,'') as qycode,isnull(b.Name,'') as qyname,
		         isnull(a.loc_code,'') as hwcode,isnull(a.loc_name,'') as hwname,
		         isnull(b.ID,0) as Store_QY_Id,isnull(c.sa_id,0)  as Store_KQ_Id,
		         isnull(d.storage_id,0) as store_id,isnull(a.loc_id,0) as Store_HW_Id,
		         case f.LocationType when 0 then '货架' else '堆垛' end as LocationType,
		         case f.PickEasy when 0 then '非常容易' when 1 then '容易' when 2 then '一般'
		          when 3 then '较困难' else '困难' end as PickEasy,
		         isnull(f.stockpilePgNum,0) as stockpilePgNum,isnull(f.alreadyPgNum,0) as alreadyPgNum,
		         isnull(f.roadwayCode,0) as roadwaycode,isnull(f.beginrow,0) as beginrow,
		         isnull(f.begintier,0) as begintier,isnull(f.begincol,0) as begincol,
		         isnull(f.endrow,0) as endrow,isnull(f.endtier,0) as endtier, isnull(f.endcol,0) as endcol,
		         case isnull(e.name,'') when '' then '全部' else isnull(e.name,'') end   as tagtype,
		         isnull(f.ElecTronTagArea,'') as tagarea,
		         isnull(f.ControlCode,'') as controlcode  
		                            from location a 
		                            left join  WMSLocation f on  a.loc_id=f.Loc_Id
		                            left join  WMSTagType e on   f.TagTypeId=e.id
		                            left join  WMSRegion  b on f.regionid=b.ID
		                            left join  stockArea c  on b.Store_KQ_ID=c.sa_id
		                            left join  storages  d on a.s_id=d.storage_id 
		        where a.deleted=0       
	   end
	   else
	   begin
	       select isnull(d.serial_number,'') as scode,isnull(d.name,'') as sname,isnull(c.serial_number,'') as kqcode,
		         isnull(c.name,'') as kqname,
		         isnull(b.serial_number,'') as qycode,isnull(b.Name,'') as qyname,
		         isnull(a.loc_code,'') as hwcode,isnull(a.loc_name,'') as hwname,
		         isnull(b.ID,0) as Store_QY_Id,isnull(c.sa_id,0)  as Store_KQ_Id,
		         isnull(d.storage_id,0) as store_id,isnull(a.loc_id,0) as Store_HW_Id,
		         isnull(f.LocationType,0) as LocationType,
		         isnull(f.PickEasy,0) as PickEasy, isnull(f.stockpilePgNum,0) as stockpilePgNum,isnull(f.alreadyPgNum,0) as alreadyPgNum,
		         isnull(f.roadwayCode,0) as roadwaycode,isnull(f.beginrow,0) as beginrow,
		         isnull(f.begintier,0) as begintier,isnull(f.begincol,0) as begincol,
		         isnull(f.endrow,0) as endrow,isnull(f.endtier,0) as endtier, isnull(f.endcol,0) as endcol,
		         case isnull(e.name,'') when '' then '全部' else isnull(e.name,'') end   as tagtype,
		         isnull(f.ElecTronTagArea,'') as tagarea,
		         isnull(f.ControlCode,'') as controlcode   
		                            from location a  
		                            left join  WMSLocation f on  a.loc_id=f.Loc_Id
		                            left join  WMSRegion  b on f.regionid=b.ID
		                            left join  stockArea c  on b.Store_KQ_ID=c.sa_id
		                            left join  storages  d on c.s_id=d.storage_id
		                            left join  WMSTagType e on   f.TagTypeId=e.id
		                            where a.loc_id=@ID
	   end
  end
  if @Stype='ZCQ' 
  begin
	   if @ID=0 
	   begin
		  select isnull(a.ID,0) as Store_ZCQ_Id,isnull(a.name,'') as name ,
		      isnull(a.Code,'') as code,isnull(b.name,'') as sname,isnull(b.serial_number,'') as scode 
		      from WMSHold a  left join storages b on a.S_id=b.storage_id
		      where a.deleted=0 and (a.Name like '%'+@QrName+'%' or a.Code like '%'+@QrName+'%')
		                
	   end
  end
end
GO
