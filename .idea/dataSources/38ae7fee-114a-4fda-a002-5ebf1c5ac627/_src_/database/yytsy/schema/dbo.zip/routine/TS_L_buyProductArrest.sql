/* =============================================*/
/* Author:  luowei*/
/* Create date: 2012-01-04	*/
/* Description: 购进品种拦截*/
/* =============================================*/

create procedure TS_L_buyProductArrest
(
 @Act  int,    /* 操作*/
 @pid  int = 0,   /* 商品*/
 @cid  int = 0,   /* 客户*/
 @licence_no  varchar(100) = ''  /* 委托书编号*/
)
AS
BEGIN
/*Params Ini begin*/
if @pid is null  SET @pid = 0
if @cid is null  SET @cid = 0
if @licence_no is null  SET @licence_no = ''
/*Params Ini end*/
if @Act = 0
 begin
  begin
    select r.p_id,p.serial_number,p.name as Pname,p.alias,p.[standard],p.makearea,isnull(M.medtype,'') as mt_name, 
           r.c_id,c.name AS customer,r.licence_no,'' as region from productBuyHold r
		   inner join products p on p.product_id = r.p_id
		   inner join clients c on c.client_id = r.c_id
		   left   join VW_MedType m on p.product_id = m.product_id
    WHERE(r.p_id = @pid or @pid = 0) AND (r.c_id = @cid or @cid = 0) AND 
      (c.client_id =@cid or @cid = 0) and(r.licence_no like '%'+ @licence_no + '%' or @licence_no='') 
  end
 end
END
GO
