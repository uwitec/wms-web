


CREATE	    PROCEDURE [Ts_L_DelBaseInfo]
	(@TableName	varchar(30),
	 @parent_id	varchar(200),
	 @product_id	[int])
AS 

set nocount on

declare @child_number	int
declare @Yid int 
declare @RoleId int 
declare @Empid  int 
declare @LimGid int

exec ts_GetSysValue 'Y_id',@YID OUT

/*删除诊治项目*/
if upper(@tableName)='CLINICRANGE'
begin
	if exists(select * from clinicRangeMapping where cr_class_id = @parent_id)
	begin
		raiserror('诊治项目已被使用，不能删除！', 16, 1)
		return -1
	end
	
	update clinicRange set deleted = 1 where Class_id = @parent_id
	return 1
end

/*删除诊治费用*/
if upper(@tableName)='SPECIALPRODUCTS'
begin
	if exists(SELECT     0
		FROM         dbo.billidx AS i INNER JOIN
							  dbo.salemanagebill AS b ON i.billid = b.bill_id
		WHERE     (i.billtype = 240 OR
							  i.billtype = 243) AND (b.p_id = @product_id))
	begin
		raiserror('费用已被使用，不能删除！', 16, 1)
		return -1
	end

	if exists(select * from doctorgrade where spid = @product_id)
	begin
		raiserror('费用已被使用，不能删除！', 16, 1)
		return -1
	end
	
	update specialproducts set deleted = 1 where product_id = @product_id
	return 1
end
/*删除关联商品信息库*/
if Upper(@TableName)='GLProducts'
begin
  Update GLProducts  set deleted=1  WHERE ( [glp_id] = @product_id)
	if @@rowcount<>0 
	begin
		select @child_number=child_number from GLProducts  where Class_id=@parent_id
		select @child_number=@Child_number-1
		update GLProducts  set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1
end
/*删除商品信息库*/
if upper(@tableName)='PRODUCTS'
begin
/*    是否可删除*/
	if exists(select P_id from storehouse where P_id=@product_id) 
	 or exists(select P_id from storehouseini where P_id=@product_id) 
	 or exists(select P_id from dxstorehouseini where P_id=@product_id) 
	begin
		Raiserror('库存已经有此商品不能删除！',16,1)
		return -1
	end

	if exists(select P_id from productdetail where p_id=@product_id)
	begin
		Raiserror('商品明细已经产生不能删除！',16,1)
		return -1
	end
	if exists(select product_id from Products where Product_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end

	if exists(select P_id from BuyManageBill where P_id=@product_id) 
		or exists(Select P_id From BuymanageBillDrf where P_id=@product_id)
		or exists(select p_id from salemanagebill where p_id=@product_id)
		or exists(select p_id from salemanagebilldrf where p_id=@product_id)
		or exists(select P_id from storemanagebill where P_id =@product_id)
		or exists(select P_id from storemanagebilldrf where p_id=@product_id)
		or exists(select p_id from GoodsCheckBill where p_id=@product_id)
		or exists(select p_id from GoodsCheckBilldrf where p_id=@product_id)
        or exists(select p_id from PriceBill where p_id=@product_id) /*-mb:做商品调价单后,*/
	begin
		Raiserror('单据中已经存在该商品，不能删除！',16,1)
		return -1
	end
	update  ProductCategory set deleted=1 where p_id=@product_id
	Update Products set deleted=1  WHERE ( [product_id] = @product_id)
	if @@rowcount<>0 
	begin
		select @child_number=child_number from Products where Class_id=@parent_id
		select @child_number=@Child_number-1
		update Products set child_number= @child_number where Class_id =@parent_id
		return 1
	end 
	else 
	    return -1
end

if upper(@tableName)='EMPLOYEES'
begin
/*-    是否可删除*/
	if exists(select E_id from billidx where E_id=@product_id or auditman=@product_id or inputman=@product_id) 
	begin
		Raiserror('已经有该经手人的单据，不能删除！',16,1)
		return -1
	end

	if exists(select E_id from billdraftidx where E_id=@product_id or auditman=@product_id or inputman=@product_id) 
	begin
		Raiserror('已经有该经手人的草稿单据，不能删除！',16,1)
		return -1
	end
/*	if exists(select * from productdetail where E_id=@product_id)
	begin
		Raiserror('商品明细已经产生不能删除！',16,1)
		return -1
	end*/
	if exists(select * from employees where Emp_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end

	Update Employees set deleted=1	WHERE ( [Emp_id] = @product_id)
	if @@rowcount<>0 
	begin
		select @child_number=child_number from Employees where Class_id=@parent_id
		select @child_number=@Child_number-1
		update Employees set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1
end

if upper(@TableName)='CLIENTS'
begin
/*-    是否可删除*/
	if exists(select C_id from billidx where C_id=@product_id and billtype not in (150,151,155,160,161,165)) 
	begin
		Raiserror('已经有该单位的单据，不能删除！',16,1)
		return -1
	end

	if exists(select C_id from billdraftidx where C_id=@product_id and billtype not in (150,151,155,160,161,165)) 
	begin
		Raiserror('已经有该单位的草稿单据，不能删除！',16,1)
		return -1
	end
	if exists(select f.* from financebilldrf f left join billidx b on f.bill_id=b.billid
                  where f.C_id=@product_id and b.billtype not in (150,151,155,160,161,165)) 
	begin
		Raiserror('已经有该单位的草稿单据！',16,1)
		return -1
	end
	if exists(select a.* from accountdetail  a left join billidx b on a.billid=b.billid
		  where a.C_id=@product_id and b.billtype not in (150,151,155,160,161,165))
	begin
		Raiserror('科目明细已经产生不能删除！',16,1)
		return -1
	end
/*	if exists(select * from productdetail where C_id=@product_id)
	begin
		Raiserror('商品明细已经产生不能删除！',16,1)
		return -1
	end*/
	if exists(select * from Clients where Client_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end 
        if exists(select * from Clientsbalance where C_id=@product_id and (pre_artotal_ini>0 or pre_aptotal_ini>0 or artotal_ini>0 or aptotal_ini>0))
        begin
                Raiserror('期初应收应付不为零不能删除！',16,1)
                return -1
        end
    Update ClientCategory set deleted=1 where C_id=@product_id
	Update Clients set deleted=1  WHERE ( [Client_id] = @product_id or jsdw_id =@product_id)
	if @@rowcount<>0 
	begin
		select @child_number=child_number from Clients where Class_id=@parent_id
		select @child_number=@Child_number-1
		update Clients set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1


end

if Upper(@TableName)='STORAGES'
begin
/*-    是否可删除*/
	if exists(select * from storehouse where S_id=@product_id) 
	begin
		Raiserror('已经有该仓库的单据，不能删除！',16,1)
		return -1
	end
	if exists(select * from vw_locfindsid where s_id=@product_id) 
	begin
		Raiserror('已经有该仓库的拣货单据，不能删除！',16,1)
		return -1
	end
	
        if exists(select * from productdetail where S_id=@product_id)
	begin
		Raiserror('商品明细已经产生不能删除！',16,1)
		return -1
	end

	if exists(select * from Storages where Storage_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end

	Update STORAGES set deleted=1  WHERE ( [Storage_id] = @product_id)
	if @@rowcount<>0 
	begin
		select @child_number=child_number from STORAGES where Class_id=@parent_id
		select @child_number=@Child_number-1
		update STORAGES set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1

end

if Upper(@TableName)='ACCOUNT'
begin
/*-    是否可删除*/
	if exists(select Sysrow from account where sysrow=1 and account_id=@product_id)
	begin
		Raiserror('系统科目，不能删除！',16,1)
		return -1
	end

	if exists(select * from Billidx where a_id=@product_id) 
	begin
		Raiserror('已经有该科目的单据，不能删除！',16,1)
		return -1
	end

	if exists(select * from billdraftidx where a_id=@product_id) 
	begin
		Raiserror('已经有该科目的草稿单据，不能删除！',16,1)
		return -1
	end
	if exists(select * from accountdetail where a_id=@product_id)
	begin
		Raiserror('科目明细已经产生不能删除！',16,1)
		return -1
	end

	if exists(select * from Account where Account_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end

	Update Account set deleted=1  WHERE ( [Account_id] = @product_id)
	if @@rowcount<>0 

	begin
		select @child_number=child_number from Account where Class_id=@parent_id
		select @child_number=@Child_number-1
		update Account set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1

end

if Upper(@TableName)='ProductBlacklist'
begin
  delete from  ProductBlacklist where product_id=@parent_id 
end

if Upper(@TableName)='SHOP'
begin
	Update Shop set deleted=1  WHERE ( [Posid] = @product_id)
end

if  Upper(@TableName)='StoreKQ' 
begin
  if exists(select * from WMSRegion where Store_KQ_ID=@product_id and deleted=0) 
  begin
		Raiserror('库区已被区域使用不能删除！',16,1)
		return -1
  end
  update stockArea set deleted=1 where  sa_id=@product_id
end

if  Upper(@TableName)='StoreZCQ' /*删除暂存区*/
begin
  update WMSHold set deleted=1 where  id=@product_id
end

if  Upper(@TableName)='ClearZCQ' /*清空暂存区*/
begin
  update WMSHold set jobnum=0 where id=@product_id
end

if  Upper(@TableName)='StoreZCQ_Nolock' /*解锁暂存区*/
begin
  update WMSHold set LockStatus=0 where   id=@product_id
end

if  Upper(@TableName)='StoreZCQ_lock' /*锁定暂存区*/
begin
  update WMSHold set LockStatus=1 where   id=@product_id
end

if  Upper(@TableName)='StoreZCQ_Stop' /*停用暂存区*/
begin
  update WMSHold set Deleted=2 where   id=@product_id
end

if  Upper(@TableName)='StoreZCQ_NoStop' /*启用暂存区*/
begin
  update WMSHold set Deleted=0 where   id=@product_id
end

if  Upper(@TableName)='StoreFHT' /*删除复核台*/
begin
  update WMSCheckBaseInfo set deleted=1 where  id=@product_id
  update WMSCheckAHG set Deleted=1      where checkid=@product_id
end

if  Upper(@TableName)='StoreFHT_Stop' /*停用复核台*/
begin
  update WMSCheckBaseInfo set Deleted=2 where   id=@product_id
end

if  Upper(@TableName)='ClearFHT' /*清空复核台*/
begin
  update WMSCheckBaseInfo set jobnum=0 where   id=@product_id
end

if  Upper(@TableName)='StoreFHT_NoStop' /*启用复核台*/
begin
  update WMSCheckBaseInfo set Deleted=0 where   id=@product_id
end

if  Upper(@TableName)='StoreQY' /*区域*/
begin
  if exists(select * from WMSlocation where Regionid=@product_id and deleted=0) 
  begin
		Raiserror('区域已被货位使用不能删除！',16,1)
		return -1
  end
  update WMSRegion set deleted=1 where id=@product_id
  update WMSMedtype set deleted=1 where  StoreQYHWID=@product_id and Flag=1
end

if  Upper(@TableName)='Role' 
begin
  update WMSEmpRole set deleted=1    where id=@product_id
  update WMSEmpRoleAQ set Deleted=1  where Bill_id=@product_id
  update WMSEmpRoleGsp set Deleted=1 where Bill_id=@product_id
  select @RoleId=RoleId,@Empid=Empid from WMSEmpRole  where id=@product_id
  if @RoleId=1  
  begin
       select @LimGid=gid from limgroup where name ='收货员'
       delete from  limgroupuser where lgid=@LimGid and e_id=@Empid 
  end
  if @RoleId=2  
  begin
       select @LimGid=gid from limgroup where name ='验收员'
       delete from  limgroupuser where lgid=@LimGid and e_id=@Empid 
  end
  if @RoleId=3  
  begin
       select @LimGid=gid from limgroup where name ='拣货员'
       delete from  limgroupuser where lgid=@LimGid and e_id=@Empid 
  end
  if @RoleId=4  
  begin
       select @LimGid=gid from limgroup where name ='复核员'
       delete from  limgroupuser where lgid=@LimGid and e_id=@Empid 
  end
  if @RoleId=5  
  begin
       select @LimGid=gid from limgroup where name ='库管员'
       delete from  limgroupuser where lgid=@LimGid and e_id=@Empid 
  end

end

if Upper(@TableName)='LOCATION'
begin
	if exists(select location_id from storehouse where Location_id=@product_id) 
	begin
		Raiserror('库存已经有此货位不能删除！',16,1)
		return -1
	end

	if exists(select location_id from productdetail where Location_id=@product_id)
	begin
		Raiserror('明细帐已经有该货位不能删除！',16,1)
		return -1
	end

	if exists(select location_id from BuyManageBill where location_id=@product_id) 
		or exists(Select location_id From BuymanageBillDrf where location_id=@product_id)
		or exists(select location_id from salemanagebill where location_id=@product_id)
		or exists(select location_id from salemanagebilldrf where location_id=@product_id)
		or exists(select location_id from storemanagebill where location_id =@product_id)
		or exists(select location_id from storemanagebilldrf where location_id=@product_id)
		or exists(select location_id from GoodsCheckBill where location_id=@product_id)
		or exists(select location_id from GoodsCheckBilldrf where location_id=@product_id)
	begin
		Raiserror('单据中已经存在该货位，不能删除！',16,1)
		return -1
	end
        
        delete ELabelCfg Where Loc_id =@product_id /*mixiaobin*/
	Update Location set deleted=1  WHERE ( [Loc_id] = @product_id)
    update WMSMedtype set deleted=1 where  StoreQYHWID=@product_id and Flag=2
end


if upper(@TableName)='BaseFactory'
begin
	delete from BaseFactory where commid=@product_id
end

if upper(@TableName)='AccountComment'
begin
	delete from AccountComment where commid=@product_id
end

if upper(@TableName)='STORAGECON'
begin
	delete from Accountcomment where commid=@product_id
end


if Upper(@TableName)='GSP'
begin
	delete from GspTable where Gspid=@product_id
	delete from gspalert where Gspid=@product_id
end

if Upper(@TableName)='DEPARTMENT'
begin
/*    是否可删除*/
	if exists(select * from Employees where dep_id=@product_id and deleted=0) 
	begin
		Raiserror('职员信息中已经有该部门，不能删除！',16,1)
		return -1
	end
	delete from DEPARTMENT where DEPARTMENTid=@product_id
end

if Upper(@TableName)='REGION'
begin
/*    是否可删除*/
	if exists(select * from Clients where region_id=@product_id and deleted=0) 
	begin
		Raiserror('往来单位信息已经有该片区，不能删除！',16,1)
		return -1
	end
        if exists(select * from region where region_id=@product_id and Child_number<>0) 
	begin
		Raiserror('子结点数不为零不能删除！',16,1)
		return -1
	end
	update Region set deleted =1 where Region_id=@product_id
	if @@rowcount<>0 
	begin
		select @child_number=child_number from Region where Class_id=@parent_id
		select @child_number=@Child_number-1
		update Region  set child_number= @child_number where Class_id =@parent_id
		return 1
	end else return -1
end

if Upper(@TableName)='UNIT'
begin
/*    是否可删除*/
	if exists(select * 
		  from Products 
		  where (unit1_id=@product_id or 
			unit2_id=@product_id or 
			unit3_id=@product_id or 
			unit4_id=@product_id) and deleted<>1) 
	begin
		Raiserror('商品信息已经有该单位，不能删除！',16,1)
		return -1
	end
	delete from Unit where unit_id=@product_id
end

if Upper(@TableName)='MEDTYPE'
begin
/*    是否可删除*/
	if exists(select * 
		  from Products 
		  where (medType=@product_id) and deleted<>1 ) 
	begin
		Raiserror('商品信息已经有该剂型，不能删除！',16,1)
		return -1
	end
	delete From customCategory where id=@product_id
end


if Upper(@tableName)='MEMBERCARD'
begin
/*    是否可删除*/
/*	if exists(select * 
		  from Products 
		  where (unit1_id=@product_id or 
			unit2_id=@product_id or 
			unit3_id=@product_id or 
			unit4_id=@product_id) and deleted<>1 ) 
	begin
		Raiserror('商品信息已经有该单位，不能删除！',16,1)
		return -1
	end*/
	delete from MemberCard where cardID=@product_id
end

if Upper(@tablename)='PrintClass'
begin
  if exists(select * 
		  from Products 
		  where (PrintClass=@product_id) and deleted<>1 ) 
	begin
		Raiserror('商品信息已经有该打印类型，不能删除！',16,1)
		return -1
	end
	delete From PrintClass where pc_id=@product_id
end



if Upper(@TableName)='RANGE'
begin
	delete From customCategory where id=@product_id
end

if Upper(@TableName)='GSPPROPERT'
begin
	delete From GSPPROPERT where Gspid=@product_id
end


/*
XXX.2017-04-27 RANGECHECK 表已经不使用了 
if Upper(@TableName)='RANGECHECK'
begin
	update  customCategoryMapping  set deleted=1 where category_id=@product_id and BaseTypeid=3
end
*/

if Upper(@TableName)='SHELF'
begin
  if exists(select top 1 * from  location where Shelfid=@product_id)
  begin
    Raiserror('该货架已经使用，不能删除！',16,1)
    return -1
  end
    
  delete from Shelf where Slf_id=@product_id
end


if upper(@TableName)='PDA_MACHINE'
begin
	delete from PDA_MACHINE where mid=@product_id
end

if Upper(@TableName)='company'
begin
  if exists(select company_id from company where company_id=@product_id and Child_number<>0) 
  begin
    Raiserror('子结点数不为零不能删除！',16,1)
    return -1
  end
   
   if exists(select * from billidx          where Y_id=@product_id) or
      exists(select * from Clientsbalance   where Y_id=@product_id) or
      exists(select * from Companybalance   where c_id=@product_id  and artotal<>0 and artotal_ini<>0 
              and aptotal<>0 and aptotal_ini<>0 and pre_artotal<>0 and pre_artotal_ini<>0 and pre_aptotal<>0 and pre_aptotal_ini<>0) or
      exists(select * from YAccountDetail   where Y_id=@product_id) or
      exists(select * from YProductdetail   where Y_id=@product_id) or
      exists(select * from accountbalance   where Y_id=@product_id) or
      exists(select * from billdraftidx     where Y_id=@product_id) or
      exists(select * from billdtsidx       where Y_id=@product_id) or
      exists(select * from GspRegister      where Y_id=@product_id) or
      exists(select * from GSPSNStyle       where Y_id=@product_id) or
      exists(select * from GspTable         where Y_id=@product_id) or
      exists(select * from GspTableDts      where Y_id=@product_id) or
      exists(select * from invoiceidx       where Y_id=@product_id) or
      exists(select * from orderidx         where Y_id=@product_id) or
      exists(select * from OtherStorehouse  where Y_id=@product_id) or
      exists(select * from PosPrice         where Y_id=@product_id) or
      exists(select * from PriceIdx         where Y_id=@product_id) or
      exists(select * from redhistory       where Y_id=@product_id) or
      exists(select * from retailbillidx    where Y_id=@product_id) or
      exists(select * from storages         where Y_id=@product_id) or
      exists(select * from storebrrow       where Y_id=@product_id) or
      exists(select * from storebrrowini    where Y_id=@product_id) or
      exists(select * from storedx          where Y_id=@product_id) or
      exists(select * from storedxini       where Y_id=@product_id) or
      exists(select * from storehouse       where Y_id=@product_id) or
      exists(select * from storehouseini    where Y_id=@product_id) or
      exists(select * from TranIdx          where Y_id=@product_id) or
      exists(select * from VIPCard          where Y_id=@product_id) or
      exists(select * from VipDetail        where Y_id=@product_id) 

    begin
      Raiserror('单据中已存在该分支机构，不能删除！',16,1)
      return -1
    end
   update  CompanyCategory  set deleted=1 where Y_id=@product_id 
   update   company  set deleted=1 where company_id=@product_id
   if @@rowcount<>0 
   begin
	select @child_number=child_number from company where class_id=@parent_id
	select @child_number=@Child_number-1
	update company set child_number= @child_number where class_id =@parent_id
	return 1
   end 
   else 
    return -1

end
/*删除检查报告*/
if Upper(@TableName)='MEDREPORT'
begin
  delete medReport where  [mr_id]=@product_id 
	if @@rowcount<>0 
	  return 1
    else return -1
end

if upper(@tableName)='STOCKAREA'
begin
   if exists(select 1 from WMSRegion where Store_KQ_ID = @product_id)
   begin
      Raiserror('该库区已经使用，不能删除！',16,1)
      return -1
   end 
  /*update location set sa_id = 0 where sa_id = @product_id*/
  update stockArea set deleted=1 where sa_id = @product_id    
end

if upper(@tableName)='CUSTOMCATEGORY'
begin
    declare @parentid int
    declare @Par_id int
    declare @typeid  varchar(100)
	/*exec Ts_L_DelBaseInfo;1 'CustomCategory','0601',498*/
	declare @cColName varchar(20) 
	declare @szSql varchar(2000)
	declare @class_id varchar(20)
	declare @cate_id int
	declare @len int
	select @cate_id = Category_id,@class_id = class_id,@typeid = baseType from customCategory where id = @product_id
	set @len = LEN(@class_id)
	CREATE TABLE #Tmp ([pid] [int] NOT NULL DEFAULT(0))
	if @typeid in (-1,0)   /*表示商品*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'ProductCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
			Raiserror('存在关联基本资料，不能删除！',16,1)
			return -1
		end
	end
	if @typeid = 1   /*表示往来单位*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'ClientCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.client_id from clients p,ClientCategory c where p.client_id = c.c_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
			Raiserror('存在关联基本资料，不能删除！',16,1)
			return -1
		end
	end
	if @typeid = 2   /*表示机构*/
	begin
		set @cColName = dbo.GetColName(@cate_id,'CompanyCategory') 
	    set @szSql =  'INSERT INTO #Tmp(pid) ' +
			'select p.company_id from Company p,CompanyCategory c where p.company_id = c.y_id and left(c.' + @cColName + 
			','+ cast(@len as varchar) +') = '''+ @class_id + ''''
			 
		exec (@szSql)	
		if exists(select * from #Tmp) 
		begin
			Raiserror('存在关联基本资料，不能删除',16,1)
			return -1
		end
	end
	
	
	
	if exists(SELECT  0 from   customCategory
	 	WHERE id = @product_id and Child_Number>0)
	begin
		raiserror('存在下一级类别信息，请先删除下一级类别！', 16, 1)
		return -1
	end
	if @product_id=2 
	begin
	    raiserror('系统默认组不能删除！', 16, 1)
		return -1
	end
	else
	begin
		select @Par_id=parent_id,@typeid=Typeid from customCategory where [ID] = @product_id
		if ((@Par_id=1) and (@typeid in (1,2,3)))
		begin
			raiserror('系统默认组不能删除！', 16, 1)
			return -1
		end
		else
		begin
			update customCategory set deleted = 1 where [ID] = @product_id
			
			select @parentid = parent_id from customCategory where [ID] = @product_id
			
			update customCategory set Child_Number = Child_Number -1 where [ID] = @parentid 
			
			return 1
		  
		end
	end
end

if Upper(@TableName)='TABU'
begin
  delete TabuMx where  [tabu_id]=@product_id 
  delete TabuIndex where  [tabu_id]=@product_id   
	if @@rowcount<>0 
	  return 1
    else return -1
end
GO
