
/******************************************
分解类型字符串
********************************************/
CREATE  FUNCTION [DecodeStr](@szStr VARCHAR(8000))  
RETURNS 
  @DecodeStr TABLE ([TYPE] INT)
AS
BEGIN
  DECLARE @nPos INT, @szTemp VARCHAR(100)
  SET @szStr = LTRIM(RTRIM(@szStr))     
  WHILE @szStr<>''
  BEGIN
    SELECT @nPos = PATINDEX('%,%',@szStr)
    IF @nPos = 0
    BEGIN 
      INSERT INTO @DecodeStr([TYPE])
      VALUES(@szStr)
      BREAK
    END ELSE
    BEGIN
      SELECT @szTemp = SUBSTRING(@szStr, 1, @nPos - 1)
      INSERT INTO @DecodeStr([TYPE])
      VALUES(@szTemp)
      SELECT @szStr = SUBSTRING(@szStr, @nPos + 1, LEN(@szStr) - @nPos) 
    END
  END 
  RETURN
END
GO
