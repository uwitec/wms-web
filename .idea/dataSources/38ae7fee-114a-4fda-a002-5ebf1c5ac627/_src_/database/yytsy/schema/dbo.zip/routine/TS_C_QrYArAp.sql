



/******************************************
机构应收账款、应付账款
********************************************/
CREATE PROCEDURE TS_C_QrYArAp
( @szParid   	VARCHAR(30)='000000',
  @szPeriod   CHAR(2)='',
  @szListFlag CHAR(1)='L',
  @BeginDate  DATETIME=0,
  @EndDate    DATETIME=0,
  @EClass_id  varchar(30)='',
  @YClass_id  varchar(60)='',
  @nloginEID  int=0,
  @nFindOtherY  int=0,        /* 标示报表类型	5177 总部加盟店*/
  @nDetachArap  int=-1         /* 收款方式*/

)
/*with encryption*/
AS
begin
	SET NOCOUNT ON
	/*Params Ini begin*/
	if @szParid is null  SET @szParid = '000000'
	if @szPeriod is null  SET @szPeriod = ''
	if @szListFlag is null  SET @szListFlag = 'L'
	if @BeginDate is null  SET @BeginDate = 0
	if @EndDate is null  SET @EndDate = 0
	if @EClass_id is null  SET @EClass_id = ''
	if @YClass_id is null  SET @YClass_id = ''
	if @nloginEID is null  SET @nloginEID = 0
	if @nFindOtherY is null  SET @nFindOtherY = 0
	if @nDetachArap is null  SET @nDetachArap = -1
	/*Params Ini end*/

	select emp_id into #tmpE from employees where class_id like @EClass_id + '%'

	if @nFindOtherY = 5183
	begin
		if @nDetachArap = 0
		SELECT   company_id AS client_id, class_id, child_number, serial_number, name, alias, tel AS phone_number, 
						opaddress AS address, manager AS contact_personal, CASE WHEN sq > 0 THEN sq ELSE 0 END AS BeginArTotal, 
						CASE WHEN sq < 0 THEN - sq ELSE 0 END AS BeginApTotal, CASE WHEN bq > 0 THEN bq ELSE 0 END AS NowArTotal, 
						CASE WHEN bq < 0 THEN - bq ELSE 0 END AS NowApTotal, CASE WHEN ed > 0 THEN ed ELSE 0 END AS EndArTotal, 
						CASE WHEN ed < 0 THEN - ed ELSE 0 END AS EndApTotal, CASE WHEN ye > 0 THEN ye ELSE 0 END AS ArTotal, 
						CASE WHEN ye < 0 THEN - ye ELSE 0 END AS ApTotal
		FROM      (SELECT   company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager, SUM(sq) AS sq, SUM(bq) AS bq, SUM(jsye) AS ye, SUM(ed) AS ed
					 FROM      (SELECT   c.company_id, c.class_id, c.child_number, c.serial_number, c.name, c.alias, c.tel, c.opaddress, 
													  c.communicateaddr, c.manager, i.billdate, 
													  CASE WHEN i.billdate < @BeginDate THEN i.jsye ELSE 0 END AS sq, 
													  CASE WHEN i.billdate BETWEEN @BeginDate AND @EndDate THEN i.jsye ELSE 0 END AS bq, 
													  CASE WHEN i.billdate <= @EndDate THEN i.jsye ELSE 0 END AS ed, 
													 i.jsye
									  FROM      (SELECT  e_id, billdate, c_id, jsye
													   FROM      (SELECT e_id, billdate, c_id, 
																						CASE billtype WHEN 152 THEN jsye ELSE - jsye END AS jsye
																		FROM      dbo.billidx
																		WHERE   (billstates = '0') AND (billtype IN (152, 153))/* AND (billdate <= @EndDate)*/
																		UNION ALL
																		SELECT   e_id, billdate, c_id, jsye
																		FROM      dbo.billdraftidx
																		WHERE   (billstates = '3') AND (billtype = 166)) 
																	   AS derivedtbl_1) AS i INNER JOIN
													  dbo.company AS c ON i.c_id = c.company_id
									  WHERE   (c.deleted <> 1) AND (c.child_number = 0) AND (c.class_id like @YClass_id + '%')
									  AND (I.e_id in (select emp_id from #tmpE)) AND (c.payoff = @nDetachArap)
									  AND (c.company_id IN (select company_id from dbo.AuthorizeCompany(@nloginEID)))) AS s
					 GROUP BY company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager) AS g
		else
		/* 目前只统计配送金额，其余返回空数据*/
		SELECT   company_id AS client_id, class_id, child_number, serial_number, name, alias, tel AS phone_number, 
						opaddress AS address, manager AS contact_personal, CASE WHEN sq > 0 THEN sq ELSE 0 END AS BeginArTotal, 
						CASE WHEN sq < 0 THEN - sq ELSE 0 END AS BeginApTotal, CASE WHEN bq > 0 THEN bq ELSE 0 END AS NowArTotal, 
						CASE WHEN bq < 0 THEN - bq ELSE 0 END AS NowApTotal, CASE WHEN ed > 0 THEN ed ELSE 0 END AS EndArTotal, 
						CASE WHEN ed < 0 THEN - ed ELSE 0 END AS EndApTotal, CASE WHEN ye > 0 THEN ye ELSE 0 END AS ArTotal, 
						CASE WHEN ye < 0 THEN - ye ELSE 0 END AS ApTotal
		FROM      (SELECT   company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager, SUM(sq) AS sq, SUM(bq) AS bq, SUM(jsye) AS ye, SUM(ed) AS ed
					 FROM      (SELECT   c.company_id, c.class_id, c.child_number, c.serial_number, c.name, c.alias, c.tel, c.opaddress, 
													  c.communicateaddr, c.manager, i.billdate, 
													  CASE WHEN i.billdate < @BeginDate THEN i.jsye ELSE 0 END AS sq, 
													  CASE WHEN i.billdate BETWEEN @BeginDate AND @EndDate THEN i.jsye ELSE 0 END AS bq, 
													  CASE WHEN i.billdate <= @EndDate THEN i.jsye ELSE 0 END AS ed, 
													 i.jsye
									  FROM      (SELECT  e_id, billdate, c_id, jsye
													   FROM      (SELECT e_id, billdate, c_id, 
																						CASE billtype WHEN 152 THEN jsye ELSE - jsye END AS jsye
																		FROM      dbo.billidx
																		WHERE   (billstates = '0') AND (billtype IN (152, 153))/* AND (billdate <= @EndDate)*/
																		UNION ALL
																		SELECT   e_id, billdate, c_id, jsye
																		FROM      dbo.billdraftidx
																		WHERE   (billstates = '3') AND (billtype = 166)) 
																	   AS derivedtbl_1) AS i INNER JOIN
													  dbo.company AS c ON i.c_id = c.company_id
									  WHERE   (c.deleted <> 1) AND (c.child_number = 0) AND (c.class_id like @YClass_id + '%')
									  AND (I.e_id in (select emp_id from #tmpE)) AND (c.payoff = -2)
									  AND (c.company_id IN (select company_id from dbo.AuthorizeCompany(@nloginEID)))) AS s
					 GROUP BY company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager) AS g
	end
	else
	if @nFindOtherY = 5184
	begin
		if @nDetachArap = 0
		SELECT   company_id AS client_id, class_id, child_number, serial_number, name, alias, tel AS phone_number, 
						opaddress AS address, manager AS contact_personal, CASE WHEN sq > 0 THEN sq ELSE 0 END AS BeginArTotal, 
						CASE WHEN sq < 0 THEN - sq ELSE 0 END AS BeginApTotal, CASE WHEN bq > 0 THEN bq ELSE 0 END AS NowArTotal, 
						CASE WHEN bq < 0 THEN - bq ELSE 0 END AS NowApTotal, CASE WHEN ed > 0 THEN ed ELSE 0 END AS EndArTotal, 
						CASE WHEN ed < 0 THEN - ed ELSE 0 END AS EndApTotal, CASE WHEN ye > 0 THEN ye ELSE 0 END AS ArTotal, 
						CASE WHEN ye < 0 THEN - ye ELSE 0 END AS ApTotal
		FROM      (SELECT   company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager, SUM(sq) AS sq, SUM(bq) AS bq, SUM(jsye) AS ye, SUM(ed) AS ed
					 FROM      (SELECT   c.company_id, c.class_id, c.child_number, c.serial_number, c.name, c.alias, c.tel, c.opaddress, 
													  c.communicateaddr, c.manager, i.billdate, 
													  CASE WHEN i.billdate < @BeginDate THEN i.jsye ELSE 0 END AS sq, 
													  CASE WHEN i.billdate BETWEEN @BeginDate AND @EndDate THEN i.jsye ELSE 0 END AS bq, 
													  CASE WHEN i.billdate <= @EndDate THEN i.jsye ELSE 0 END AS ed, 
													 i.jsye
									  FROM      (SELECT  e_id, billdate, c_id, jsye
													   FROM      (SELECT e_id, billdate, c_id, 
																						CASE billtype WHEN 162 THEN jsye ELSE - jsye END AS jsye
																		FROM      dbo.billidx
																		WHERE   (billstates = '0') AND (billtype IN (162, 163))/* AND (billdate <= @EndDate)*/
																		UNION ALL
																		SELECT   e_id, billdate, c_id, jsye
																		FROM      dbo.billdraftidx
																		WHERE   (billstates = '3') AND (billtype = 166)) 
																	   AS derivedtbl_1) AS i INNER JOIN
													  dbo.company AS c ON i.c_id = c.company_id
									  WHERE   (c.deleted <> 1) AND (c.child_number = 0) AND (c.class_id like @YClass_id + '%')
									  AND (I.e_id in (select emp_id from #tmpE)) AND (c.payoff = @nDetachArap)
									  AND (c.company_id IN (select company_id from dbo.AuthorizeCompany(@nloginEID)))) AS s
					 GROUP BY company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager) AS g
		else
		/* 目前只统计配送金额，其余返回空数据*/
		SELECT   company_id AS client_id, class_id, child_number, serial_number, name, alias, tel AS phone_number, 
						opaddress AS address, manager AS contact_personal, CASE WHEN sq > 0 THEN sq ELSE 0 END AS BeginArTotal, 
						CASE WHEN sq < 0 THEN - sq ELSE 0 END AS BeginApTotal, CASE WHEN bq > 0 THEN bq ELSE 0 END AS NowArTotal, 
						CASE WHEN bq < 0 THEN - bq ELSE 0 END AS NowApTotal, CASE WHEN ed > 0 THEN ed ELSE 0 END AS EndArTotal, 
						CASE WHEN ed < 0 THEN - ed ELSE 0 END AS EndApTotal, CASE WHEN ye > 0 THEN ye ELSE 0 END AS ArTotal, 
						CASE WHEN ye < 0 THEN - ye ELSE 0 END AS ApTotal
		FROM      (SELECT   company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager, SUM(sq) AS sq, SUM(bq) AS bq, SUM(jsye) AS ye, SUM(ed) AS ed
					 FROM      (SELECT   c.company_id, c.class_id, c.child_number, c.serial_number, c.name, c.alias, c.tel, c.opaddress, 
													  c.communicateaddr, c.manager, i.billdate, 
													  CASE WHEN i.billdate < @BeginDate THEN i.jsye ELSE 0 END AS sq, 
													  CASE WHEN i.billdate BETWEEN @BeginDate AND @EndDate THEN i.jsye ELSE 0 END AS bq, 
													  CASE WHEN i.billdate <= @EndDate THEN i.jsye ELSE 0 END AS ed, 
													 i.jsye
									  FROM      (SELECT  e_id, billdate, c_id, jsye
													   FROM      (SELECT e_id, billdate, c_id, 
																						CASE billtype WHEN 162 THEN jsye ELSE - jsye END AS jsye
																		FROM      dbo.billidx
																		WHERE   (billstates = '0') AND (billtype IN (162, 163))/* AND (billdate <= @EndDate)*/
																		UNION ALL
																		SELECT   e_id, billdate, c_id, jsye
																		FROM      dbo.billdraftidx
																		WHERE   (billstates = '3') AND (billtype = 166)) 
																	   AS derivedtbl_1) AS i INNER JOIN
													  dbo.company AS c ON i.c_id = c.company_id
									  WHERE   (c.deleted <> 1) AND (c.child_number = 0) AND (c.class_id like @YClass_id + '%')
									  AND (I.e_id in (select emp_id from #tmpE)) AND (c.payoff = -2)
									  AND (c.company_id IN (select company_id from dbo.AuthorizeCompany(@nloginEID)))) AS s
					 GROUP BY company_id, class_id, child_number, serial_number, name, alias, tel, opaddress, communicateaddr, 
									 manager) AS g
	end
end
GO
