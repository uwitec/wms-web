
CREATE PROCEDURE ts_L_qrSendList 
(@BeginDate 	      DATETIME=0,/*开始时间*/
@EndDate	      DATETIME=0,/*结束时间*/
@szCClass_ID	      VARCHAR(30)='',/*客户ID*/
@szEClass_ID         VARCHAR(30)='',/*经手人ID*/
@szSClass_ID         VARCHAR(30)='',/*库房ID*/
@szPClass_ID	     VARCHAR(30)='',/*产品ID*/
@szParent_ID	     VARCHAR(30)='000000',/*产品父类ID*/
@szListFlag	     VARCHAR(1)='L',/*分级显示*/
@szInputClass_ID	VARCHAR(30)='',/*制单人ID*/
@nYClassid                 varchar(50)='',
@nloginEID               int=0,
@isaddDate              int=0 /*是否把临时表中的单据，搬移到YProductDetail,0:不搬移;1:要搬移*/
)
AS
/*Params Ini begin*/
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @szCClass_ID is null  SET @szCClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szSClass_ID is null  SET @szSClass_ID = ''
if @szPClass_ID is null  SET @szPClass_ID = ''
if @szParent_ID is null  SET @szParent_ID = '000000'
if @szListFlag is null  SET @szListFlag = 'L'
if @szInputClass_ID is null  SET @szInputClass_ID = ''
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
if @isaddDate is null  SET @isaddDate = 0
/*Params Ini end*/

  Declare @ClientTable INTEGER,@Companytable INTEGER,@employeestable integer,@Storetable integer
  Declare @isfinally int
  
  IF @szCClass_ID='' SET @szCClass_ID='%%'
  ELSE SET @szCClass_ID=@szCClass_ID+'%'

  IF @szEClass_ID='' SET @szEClass_ID='%%'
  ELSE SET @szEClass_ID=@szEClass_ID+'%'

  IF @szInputClass_ID='' SET @szInputClass_ID='%%'
  ELSE SET @szInputClass_ID=@szInputClass_ID+'%'
  create table #Clienttable([id] int) 
  create table #Companytable([id] int)
  create table #employeestable([id] int)
  create table #storagestable([id] int)

/*---往来单位授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='C' and u.psc_id='000000') 
   begin
     set @ClientTable=0 
   end
   else
   begin 
     set @ClientTable=1
     Insert #Clienttable ([id]) select Client_id  from Clients C where 
     exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='C' and C.class_id like u.psc_id+'%')
   end
/*---往来单位授权*/


/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin
      set @Companytable=1     
      Insert #Companytable ([id]) select Company_id from Company C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and C.class_id like u.psc_id+'%')
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
      set @employeestable=1
      Insert #employeestable ([id]) select emp_id   from employees C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='E' and C.class_id like u.psc_id+'%')
   end   

/*---职员授权*/

/*---仓库授权*/
   if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='S' and u.psc_id='000000') 
   begin
      set @Storetable=0
   end
   else
   begin 
      set @Storetable=1
      Insert #storagestable ([id]) select storage_id  from storages C where 
      exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='S' and C.class_id like u.psc_id+'%')
   end
/*---仓库授权*/


BEGIN
  select a.* from 
     (SELECT  B.[billid],B.[billdate],B.[Billnumber],B.[ename],B.[Inputmanname],B.[billtype],B.[Auditmanname],B.[inputman] as binputman,
          P.[Code], P.[Name] AS [PName], P.[Standard],P.[Makearea], P.[Medtype],P.[Unitname1] AS [Unitname],
          P.Inputman,P.InputDate,P.Custompro1,P.Custompro2,P.Custompro3,P.Custompro4,P.Custompro5,
          SM.SendQTY,SM.SendCostTotal,cast((SM.totalmoney/SM.quantity*SM.[SendQTY]) as NUMERIC(25,8)) as SendTotal,SM.comment,SM.Batchno,SM.makedate,
          SM.validdate as validdate,ISNULL(RE.CLASS_ID,'') AS Reclass_id,
          ISNULL(S.CLASS_ID,'') AS SSCLASS_ID,ISNULL(P.CLASS_ID,'') AS PClass_id,sm.RowE_id,b.c_id,b.Y_id
          FROM salemanagebill sm   /*FilterSalemanagebill(@nloginEID)   --XXX.2017-02-04提升报表效率，去掉这个价格保护的函数 */
     INNER JOIN
          (select B.*,ISNULL(IE.Class_id,'') as InputmanClass_id,isnull(IE.[name],'') as Inputmanname,ISNULL(AE.class_id,'') as AuditmanClass_id,
           ISNULL(AE.[name],'') as Auditmanname,ISNULL(E.[name],'') as Ename,ISNULL(C.Class_id,'') as Cclass_id,ISNULL(Y.class_id,'') as Yclass_id from billidx B 
           LEFT JOIN employees IE  ON IE.EMP_ID=B.INPUTMAN
           LEFT JOIN employees AE  ON AE.EMP_ID=B.AUDITMAN
           LEFT JOIN employees E   ON E.EMP_ID=B.E_ID
           LEFT JOIN Clients   C   ON C.CLIENT_ID=B.C_ID
           LEFT JOIN COMPANY   Y   ON Y.COMPANY_ID=B.Y_ID
           WHERE B.billtype in (10,53,112,212) and B.billstates=0 and b.[Billdate] BETWEEN @BeginDate AND @EndDate
          )B  
     ON SM.bill_id=B.billid 
     INNER JOIN (SELECT * FROM VW_C_Products p WHERE P.deleted<>1)P ON SM.[p_id] = P.product_id
     LEFT  JOIN  Employees RE  ON  SM.RowE_id=RE.emp_id
     LEFT  JOIN  Storages  S   ON  SM.ss_id  =S.storage_id         
     WHERE 
           Re.class_id like @szEClass_id
           and (@nYClassid='' OR B.Yclass_id like @nYclassID+'%')
           and b.[Cclass_ID] LIKE @szCClass_ID
           and b.inputmanclass_id like @szInputClass_ID
           AND (@szSClass_ID in ('','%%','000000','%') OR S.class_id like @szSClass_ID+'%')
           AND (@szPClass_ID in ('','%%','000000','%') OR p.class_id  like @szpClass_ID+'%')
    )a 
       
           where 
                ((@employeestable=0) OR (a.RowE_id in (select [id] from #employeestable)))
                  AND ((@ClientTable=0) or (a.c_id in (select [id] from #Clienttable)))
                  AND ((@Companytable=0)or (a.Y_id in (select [id] from #Companytable)))   
    GOTO SUCCESS
END

SUCCESS:
   RETURN 0
GO
