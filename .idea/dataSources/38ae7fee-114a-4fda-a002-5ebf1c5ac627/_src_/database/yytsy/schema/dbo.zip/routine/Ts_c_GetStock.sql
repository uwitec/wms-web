






























/*--------------------------------------
-取得单一品种或某一类商品的库存余量
--------------------------------------*/

CREATE	 PROCEDURE Ts_c_GetStock
(	
	@nP_id int=0,/*商品id*/
	@nS_id int=0,/*仓库id*/
	@nL_id int=0,/*货位id*/
	@szPeriod  varchar(2),/*会计期*/
	@szBatchNo varchar(20),/*批号*/
	@dQty	NUMERIC(25,8) output,/*数量*/
	@dTotal NUMERIC(25,8) output/*金额*/
)
/*with encryption*/
AS
/*Params Ini begin*/
if @nP_id is null  SET @nP_id = 0
if @nS_id is null  SET @nS_id = 0
if @nL_id is null  SET @nL_id = 0
/*Params Ini end*/
set nocount on
	declare @szPClass_id varchar(30),@szSClass_id varchar(30)
	select @szPClass_id=class_id from products where product_id=@nP_Id
	select @szSClass_id=class_id from clients  where client_id =@nS_Id

if @szperiod='' /*-取当前库存数量*/
begin
	if @szBatchNo<>'' /*取某一批次数量*/
	begin
		if @nS_id<>0
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouse 
			where p_id=@nP_id and s_id=@nS_id and BatchNo=@szBatchNo
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end else
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouse
			where p_id=@np_id and BatchNo=@szBatchNo
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end
	end else
	begin
		if @nS_id<>0
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouse 
			where p_id=@nP_id and s_id=@nS_id 
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end else
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouse
			where p_id=@np_id 
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end
	end
end else /*-取期初库存数量*/
begin
	if @szBatchNo<>'' /*取某一批次数量*/
	begin
		if @nS_id<>0
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouseini 
			where p_id=@nP_id and s_id=@nS_id and BatchNo=@szBatchNo
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end else
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouseini
			where p_id=@np_id and BatchNo=@szBatchNo
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end
	end else
	begin
		if @nS_id<>0
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouseini
			where p_id=@nP_id and s_id=@nS_id 
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end else
		begin
			select @dqty=(sum(quantity)),@dtotal=(sum(costtotal)) from storehouseini
			where p_id=@np_id 
			if @dqty is null select @dqty=0
			if @dtotal is null select @dtotal=0
			return 0
		end
	end
end
GO
