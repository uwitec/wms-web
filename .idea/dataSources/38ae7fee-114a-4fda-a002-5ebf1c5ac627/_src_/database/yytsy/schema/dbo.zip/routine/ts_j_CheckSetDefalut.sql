/************************************************************

--功能：
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_CheckSetDefalut]
( 
  @nY_ID int = 0
)
AS 
/*Params Ini begin*/
if @nY_ID is null  SET @nY_ID = 0
/*Params Ini end*/

declare @nRet int
set @nRet = -1

if exists(select 1 from sysconfig where upper([sysname]) = 'LOCALINPUTMAN' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
  if exists(select 1 from sysconfig where upper([sysname]) = 'LOCALAUDITMAN' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
   if exists(select 1 from sysconfig where upper([sysname]) = 'LOCALAUDITMAN2' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
    if exists(select 1 from sysconfig where upper([sysname]) = 'LOCALEID' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
      if exists(select 1 from sysconfig where upper([sysname]) = 'CENTERSID' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
        if exists(select 1 from sysconfig where upper([sysname]) = 'CENTERINPUTMAN' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
          if exists(select 1 from sysconfig where upper([sysname]) = 'CENTERAUDITMAN' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
           if exists(select 1 from sysconfig where upper([sysname]) = 'CENTERAUDITMAN2' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
            if exists(select 1 from sysconfig where upper([sysname]) = 'CENTEREID' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
              if exists(select 1 from sysconfig where upper([sysname]) = 'LOCALSID' and [sysvalue] <> '0' and [sysvalue] <> '' and Y_ID = @nY_ID)
                set @nRet = 0 
Return @nRet
GO
