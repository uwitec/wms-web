

/* =============================================*/
/* Author:		黄耀*/
/* Create date: 2010-11-6*/
/* Description:	选择商品授权状态*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_SelPRight] 
	@Type		int,	/*类型：0 职员授权；1 片区客户授权*/
	@PID		varchar(8000),
	@EID		int,	/*职员ID*/
	@RID		int		/*片区ID*/
AS
BEGIN
	SET NOCOUNT ON;

	declare @sql varchar(8000)
	create table #tmp (product_id int)
	set @sql = 'insert into #tmp select product_id from products where product_id in(' + @PID + ')'
	exec(@sql)
	
	if @Type = 0
	begin
		SELECT     p.PName, CAST(ISNULL(rt.EmpName, '') AS varchar) AS EmpName, p.product_id, p.class_id, ISNULL(rt.Emp_ID, 0) AS Emp_ID, 
							  CASE WHEN Emp_id IS NULL THEN 0 ELSE 1 END AS Rights, CAST('' AS varchar) AS CName, 0 AS CID, CAST(ISNULL(rt.RName, '') AS varchar) 
							  AS RName, ISNULL(rt.RID, 0) AS RID
		FROM         (SELECT     product_id, class_id, name AS PName
							   FROM          dbo.products
							   WHERE      (product_id IN (select product_id from #tmp))) AS p LEFT OUTER JOIN
								  (SELECT     t.p_id, t.R_ID AS RID, t.Emp_ID, e.name AS EmpName, r.name AS RName
									FROM          dbo.ProductEmpRight AS t INNER JOIN
														   dbo.employees AS e ON t.Emp_ID = e.emp_id INNER JOIN
														   dbo.Region AS r ON t.R_ID = r.region_id
									WHERE      (t.R_ID = @RID)) AS rt ON p.product_id = rt.p_id
	end
	else
	begin
		SELECT     p2.PName, CAST(ISNULL(c2.CName, '') AS varchar) AS CName, CAST(ISNULL(c2.RName, '') AS varchar) AS RName, ISNULL(c2.CID, 0) AS CID, 
							  ISNULL(c2.RID, 0) AS RID, CAST(CASE WHEN c2.CID IS NULL THEN 0 ELSE 1 END AS int) AS Rights, CAST('' AS varchar) AS EmpName, 0 AS Emp_ID, 
							  p2.product_id, p2.class_id
		FROM         (SELECT     p.product_id, p.name AS PName, p.class_id, r2.c_id AS CID
							   FROM          (SELECT     p_id, c_id
													   FROM          dbo.ProductCustomRight AS r
													   WHERE      (c_id IN
																				  (SELECT     client_id
																					FROM          dbo.clients
																					WHERE      (region_id = @RID)))) AS r2 RIGHT OUTER JOIN
													  dbo.products AS p ON r2.p_id = p.product_id 
													  where p.product_id in (select product_id from #tmp)) AS p2 LEFT OUTER JOIN
								  (SELECT     r.name AS RName, c.name AS CName, c.client_id AS CID, r.region_id AS RID
									FROM          dbo.Region AS r INNER JOIN
														   dbo.clients AS c ON r.region_id = c.region_id
									WHERE      (c.region_id = @RID)) AS c2 ON p2.CID = c2.CID
	end
	drop table #tmp
END
GO
