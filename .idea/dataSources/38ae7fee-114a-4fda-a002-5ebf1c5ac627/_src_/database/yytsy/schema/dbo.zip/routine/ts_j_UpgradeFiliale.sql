/************************************************************

--功能：升级启用分公司数据   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_UpgradeFiliale]

AS 


/*--------------------------------------*/
/*启用分公司升级脚本，升级业务数据*/
/*zjilin　09-05-27*/
/*升级步骤*/
/*1.往来账 2.科目余额  3.价格表 4.库存表计算Y_ID 5.补齐Y_ID*/
/*--------------------------------------*/
declare @Y_ID int, @szYClassID varchar(30)
  select @Y_ID = cast(sysvalue as int) from sysconfig where upper([sysname]) = 'Y_ID'
  select @szYClassID = cast(sysvalue as int) from sysconfig where upper([sysname]) = 'YCLASSID'

/*分公司升级往来账*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级往来账')
begin
  delete ClientsBalance where y_id = @Y_ID
  insert into ClientsBalance( Y_id,	   C_ID, 	   credit_total, sklimit,
                              artotal,     artotal_ini,    aptotal,      
                              aptotal_ini, pre_artotal,    pre_artotal_ini,
                              pre_aptotal, pre_aptotal_ini, e_id                 
                            )
  select @Y_ID,            client_id,  credit_total ,    sklimit,    artotal,          
         artotal_ini,      aptotal,    aptotal_ini,      pre_artotal,          
         pre_artotal_ini,  pre_aptotal,pre_aptotal_ini,  e_id
  from  clients                   
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级往来账','1')
end


/*分公司升级科目余额*/


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级科目余额')
begin
  delete AccountBalance where y_id = @Y_ID
  insert into AccountBalance(y_id,     a_id,     cur_total, ini_total,   
                             total_01, total_02, total_03,  total_04,  
                             total_05, total_06, total_07,  total_08,  
                             total_09, total_10, total_11,  total_12,  
                             bqtotal,   sumtotal        
                            )
  select @Y_ID,    account_id,  cur_total, ini_total,  
         total_01, total_02,    total_03,  total_04,  
         total_05, total_06,    total_07,  total_08,  
         total_09, total_10,    total_11,  total_12,  
         bqtotal,  sumtotal
  from  account                   
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级科目余额','1')
end

/*升级companybalance表  */
If not exists (select  * from tsupgradeinfo where UP_NAME = '升级companybalance表')
begin
  if not exists(select * from Companybalance where y_id = @Y_ID and c_id = 0)
  insert into companyBalance( Y_id,	   C_ID, OpenAccount
                            )
  select @Y_ID,     0,  0                            
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('升级companybalance表','1')
end



/*分公司升级价格表*/
if not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级价格表posprice')
begin
  update posprice set Y_ID = pos_id + 3 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级价格表posprice','1')
end



/*代销库只能升级为当前机构数据*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表storedxini')
begin
  update storedxini set y_id = @Y_ID
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表storedxini','1')
end

/*借进库只能升级为当前机构数据*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表storebrrowini')
begin
  update storebrrowini set y_id = @Y_ID
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表storebrrowini','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表storehouse')
begin
  update storehouse set y_id = st.Y_ID from storehouse s, storages st where s.s_id = st.storage_id
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表storehouse','1')
end

If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表storehouseini')
begin
  update storehouseini set y_id = st.Y_ID from storehouseini s, storages st where s.s_id = st.storage_id
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表storehouseini','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表OtherStorehouseini')
begin
  update OtherStorehouseini set y_id = st.Y_ID from OtherStorehouseini s, storages st where s.s_id = st.storage_id
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表OtherStorehouseini','1')
end

If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级库存类表OtherStorehouse')
begin
  update OtherStorehouse set y_id = st.Y_ID from OtherStorehouse s, storages st where s.s_id = st.storage_id
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级库存类表OtherStorehouse','1')
end


/*分公司补齐Y_ID*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_ID')
begin
  update priceidx set y_id = @Y_ID
  update BillSNStyle set y_id = @Y_ID  
  update GSPSNStyle set y_id = @Y_ID
  update MonthSettleInfo set y_id = @Y_ID  
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_ID','1')
end


/*分公司补齐Y_ID*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_IDGspTable')
begin
  update GspTable set y_id = @Y_ID
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_IDGspTable','1')
end


/*分公司补齐Y_ID*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_IDVIPCard')
begin
  update VIPCard set y_id = pos_id + 3 where pos_id <> 0 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_IDVIPCard','1')
end


/*分公司补齐Y_ID*/
If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_IDCXTable')
begin
  update CXTable set y_id = posid + 3 where posid <> 0
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_IDCXTable','1')
end

/*职员跟踪表*/
update TraceEmployee set y_id = e.y_id from TraceEmployee t, employees e where t.e_id=e.emp_id
update LocationTrace set y_id = e.y_id from LocationTrace t, storages e where t.s_id=e.storage_id

update buypricehis set y_id = @Y_ID
update salepricehis set y_id = @Y_ID
update storepricehis set y_id = @Y_ID


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_ID单据类')
begin

  update billdraftidx   set y_id = @Y_ID where posid = 0
  update billidx        set y_id = @Y_ID where posid = 0
  update invoiceidx     set y_id = @Y_ID
  update orderidx       set y_id = @Y_ID where posid = 0
  update redhistory     set y_id = @Y_ID
  update retailbillidx  set y_id = @Y_ID where posid = 0
  update TranIdx        set y_id = posid +3, c_id = posid+3

  update billdraftidx   set y_id = posid +3 where posid <> 0
  update billidx        set y_id = posid +3 where posid <> 0
  update orderidx       set y_id = posid +3 where posid <> 0
  update retailbillidx  set y_id = posid +3 where posid <> 0

  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_ID单据类','1')
end



If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司补齐Y_IDvipcard')
begin
  update vipdetail set y_id = @Y_ID
  update VIPErrorRec set y_id = @Y_ID 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司补齐Y_IDvipcard','1')
end



/*rowe_id*/

If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDbuymanagebill')
begin
  update buymanagebill set RowE_ID = b.e_id from buymanagebill a, billidx b where a.bill_id = b.billid and a.p_id > 0   
  update buymanagebillDrf  set RowE_ID = b.e_id from buymanagebilldrf a, billidx b where a.bill_id = b.billid and a.p_id > 0
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDbuymanagebill','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDOrderBill')
begin
  update OrderBill set RowE_ID = b.e_id from OrderBill a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDOrderBill','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDRetailBill')
begin
  update RetailBill set RowE_ID = b.e_id from Retailbill a,  Retailbillidx b where a.bill_id = b.billid and a.p_id > 0 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDRetailBill','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDsalemanagebill')
begin
  update salemanagebill set RowE_ID = b.e_id from salemanagebill a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  update salemanagebillDrf set RowE_ID = b.e_id from salemanagebilldrf a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDsalemanagebill','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDstoremanagebill')
begin
  update storemanagebill set RowE_ID = b.e_id from storemanagebill a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  update storemanagebillDrf set RowE_ID = b.e_id from storemanagebillDrf a, billidx b where a.bill_id = b.billid and a.p_id > 0  
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDstoremanagebill','1')
end

If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDTranManagebill')
begin
  update TranManagebill set RowE_ID = b.e_id from TranManagebill a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  update TranManagebillDrf set RowE_ID = b.e_id from TranManagebilldrf a, billidx b where a.bill_id = b.billid and a.p_id > 0 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDTranManagebill','1')
end


If not exists (select  * from tsupgradeinfo where UP_NAME = '分公司升级ROWE_IDproductdetail')
begin
  update productdetail set RowE_ID = b.e_id from productdetail a, billidx b where a.billid = b.billid and a.p_id > 0
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('分公司升级ROWE_IDproductdetail','1')
end

/*升级productdetail sendQty,sendcosttotal*/

If not exists (select  * from tsupgradeinfo where UP_NAME = '升级productdetail,sendQty,sendcosttotal')
begin
  update productdetail set sendQty = quantity, sendcosttotal = costtotal 
  insert tsupgradeinfo (UP_NAME,up_Value)VALUES('升级productdetail,sendQty,sendcosttotal','1')
end

select @Y_ID = sysvalue from sysconfig where upper([sysname]) = 'Y_ID'

if @Y_ID > 0 
begin
  update accountdetail set Y_iD = @y_id 
  update productdetail set y_id = @y_id
  update storelimit set Y_ID = @Y_ID where s_id = 0
  update storelimit set y_id = s.y_id from storelimit t, storages s where t.s_id = s.storage_id
  update storepricehis set y_id = @Y_ID
end

insert tsupgradeinfo (UP_NAME,up_Value)VALUES('升级storelimity_id','1')



delete buypricehis where c_id not in (select client_id from clients)
delete salepricehis where c_id not in (select client_id from clients)

update buypricehis set Y_ID = @y_id where y_id = 0
update salepricehis set Y_id = @y_id where y_id =0
if object_id('tempdb..#bphis') is not null
  drop table #bphis 
 
select p_id, supplier_id as c_id, costprice as buyprice, max(instoretime) instoretime, quantity into #bphis from storehouse 
   where supplier_id > 0 and p_id not in (select distinct p_id from buypricehis) 
   group by p_id, supplier_id, costprice, quantity
             
insert into buypricehis( p_id, c_id, buyprice, modifydate, quantity, y_id)
select b1.p_id, max(b1.c_id), min(b1.buyprice), b1.instoretime, max(b1.quantity), @Y_ID  from #bphis b1, #bphis b2 where b1.p_id = b2.p_id 
group by b1.p_id, b1.instoretime 
having b1.instoretime = max(b2.instoretime)

if object_id('tempdb..#bphis') is not null
  drop table #bphis 


update salemanagebill set y_id = bi.y_id from salemanagebill s, billidx bi where s.bill_id= bi.billid and s.y_id =0
update salemanagebilldrf set y_id = bi.y_id from salemanagebilldrf s, billdraftidx bi where s.bill_id= bi.billid and s.y_id =0
update buymanagebill set y_id = bi.y_id from buymanagebill s, billidx bi where s.bill_id= bi.billid and s.y_id =0
update buymanagebilldrf set y_id = bi.y_id from buymanagebilldrf s, billdraftidx bi where s.bill_id= bi.billid and s.y_id =0
update storemanagebill set y_id = bi.y_id from storemanagebill s, billidx bi where s.bill_id= bi.billid and s.y_id =0
update storemanagebilldrf set y_id = bi.y_id from storemanagebilldrf s, billdraftidx bi where s.bill_id= bi.billid and s.y_id =0
update GoodsCheckbill set y_id = bi.y_id from GoodsCheckbill s, billidx bi where s.bill_id= bi.billid and s.y_id =0
update GoodsCheckbilldrf set y_id = bi.y_id from GoodsCheckbilldrf s, billdraftidx bi where s.bill_id= bi.billid and s.y_id =0
update financebill set y_id = bi.y_id from financebill s, billidx bi where s.bill_id= bi.billid and s.y_id =0
update retailbill set y_id = bi.y_id from retailbill s, retailbillidx bi where s.bill_id= bi.billid and s.y_id =0
update productdetail set y_id = bi.y_id from productdetail s, billidx bi where s.billid= bi.billid and s.y_id =0
update accountdetail set y_id = bi.y_id from accountdetail s, retailbillidx bi where s.billid= bi.billid and s.y_id =0








  
Return 0
GO
