create procedure Ts_E_PDAPDDetail
 @pdid  integer=0,
 @kq_id integer=0,
 @qy_id integer=0,
 @p_id  integer=0,
 @e_id  integer=0,
 @pdstatus integer=0,
 @YKStatus integer=0
as
 declare @pdstatustr varchar(100)
 declare @SQLScript  varchar(8000)
 if @pdstatus=0 /*全部*/
   set  @pdstatustr='0,1,2'
 if @pdstatus=1 /*初盘*/
   set  @pdstatustr='1'
 if @pdstatus=2 /*复盘*/
   set  @pdstatustr='2'
 if @pdstatus=3 /*未盘*/
   set  @pdstatustr='0'
begin
 set @SQLScript='
  select distinct 0 as Serialno,cast(case b.WMS_PdStatus when 0 then ''未盘'' when 1 then ''初盘'' when 2 then ''复盘'' end as varchar(100)) as PdStatusName ,
         c.serial_number as pcode,c.name as pname,c.alias as alias,c.pinyin as pym, c.standard,isnull(d.pc_name,'''') as pcname,
         c.makearea,c.permitcode,isnull(e.medtype,'''') as Medname,isnull(f.name,'''') as kname,isnull(g.name,'''') as kqname,isnull(h.Name,'''') as qyname,
         isnull(i.loc_name,'''') as hwname,
         b.makedate,isnull(b.batchno,'''') as batchno, b.validdate,n.name as unitname, b.quantity as stockqty,b.WMS_FristPdQty as FristPdQty,
         b.WMS_FristPdQty-b.quantity  as fristSYQty, b.WMS_CheckPdQty as CheckPdQty,b.WMS_CheckPdQty-b.quantity  as CheckSyQty,
         b.costprice,b.costtaxrate,b.costtaxprice,b.costtaxtotal,
         case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else WMS_FristPdQty-b.quantity end) 
         else b.WMS_CheckPdQty-b.quantity  end SyQty,
         (case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else b.quantity-WMS_FristPdQty end) 
         else b.quantity- b.WMS_CheckPdQty end)*b.costtaxprice as SyCostTaxTotal,
          (case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else b.quantity-WMS_FristPdQty end) 
         else b.quantity- b.WMS_CheckPdQty end)*j.retailprice as SyRetailTotal,
         j.retailprice,b.quantity*j.retailprice as RetailTotal,k.name as pdEmpName,
         isnull(l.name,'''') as ClientName,c.PackStd,StorageCon,m.AccountComment as FactoryName,
         c.comment as pcomment,c.Custompro1,c.Custompro2,c.Custompro3,c.Custompro4,c.Custompro5,a.billdate,
         batchprice,scomment,BatchBarCode
         from pdplanidx a inner join pdplan b   on a.pdidx=b.pdidx
                          left  join products c on b.p_id=c.product_id
                          left  join (select * from PrintClass where deleted=0) d ON c.PrintClass=d.pc_id
                          left  join VW_MedType e on c.product_id = e.product_id
                          left  join (select * from storages where deleted=0)   f on a.k_id=f.storage_id
                          left  join (select * from stockArea where deleted=0)  g on a.WMS_KQ_ID=g.sa_id
                          left  join WMSRegion  h on a.WMS_QY_ID=h.ID
                          left  join location   i on b.location_id=i.loc_id
                          left  join (select retailprice,p_id from price where unittype=1)j on c.product_id=j.p_id
                          left  join employees  k on a.inputman=k.emp_id
                          left  join clients    l on b.supplier_id=l.client_id
                          left  join basefactory m on c.factoryc_id=m.CommID
                          left  join unit        n on c.unit1_id=n.unit_id
                          where  b.WMS_PdStatus in  (select sztype  from DecodetoStr('''+@pdstatustr+'''))'
   if @pdid<>0 
   begin
      SET @SQLScript=@SQLScript+' AND a.pdidx='+CHAR(39)+CAST(@pdid AS VARCHAR)+CHAR(39)
   end
   if @kq_id<>0
   begin 
      SET @SQLScript=@SQLScript+' AND a.WMS_KQ_ID='+CHAR(39)+CAST(@kq_id AS VARCHAR)+CHAR(39)
   end
   if @qy_id<>0
   begin 
      SET @SQLScript=@SQLScript+' AND a.WMS_QY_ID='+CHAR(39)+CAST(@qy_id AS VARCHAR)+CHAR(39)
   end
   if @p_id<>0
   begin 
      SET @SQLScript=@SQLScript+' AND b.p_id='+CHAR(39)+CAST(@p_id AS VARCHAR)+CHAR(39)
   end
   if @e_id<>0
   begin 
      SET @SQLScript=@SQLScript+' AND a.inputman='+CHAR(39)+CAST(@e_id AS VARCHAR)+CHAR(39)
   end
   if @YKStatus=1
   begin
       SET @SQLScript=@SQLScript+' and (case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else WMS_FristPdQty-b.quantity end) 
         else b.WMS_CheckPdQty-b.quantity  end)>0'
   end
   if @YKStatus=2
   begin
       SET @SQLScript=@SQLScript+' and (case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else WMS_FristPdQty-b.quantity end) 
         else b.WMS_CheckPdQty-b.quantity  end)<0'
   end
   if @YKStatus=3
   begin
       SET @SQLScript=@SQLScript+' and (case  b.WMS_CheckPdQty when 0 then (Case b.WMS_FristPdQty when 0 then 0 else WMS_FristPdQty-b.quantity end) 
         else b.WMS_CheckPdQty-b.quantity  end)=0'
   end
   print @SQLScript
   EXEC(@SQLScript)                       
end
/*EXEC Ts_E_PDAPDDetail;1 1,0, 0,0,0,0,0*/
GO
