
/*
	检查单据所含基本资料合法性
	返回值：
	-9：商品已删除
	-10：仓库已删除
	-11：职员已删除
	-12：往来单位已删除
	-13: 会计科目已删除
	-14: 货位已删除
	-15：商品单位已删除
*/

CREATE proc ts_c_OfflineValidcheck
(
	@nBillId numeric(10,0),
    @nBilltype int
)
AS


  declare @IntegralTotal numeric(16,4)
  declare @CardID int
/*set nocount on*/


if exists(select c_id from Yretailbillidx where billid=@nBillId and c_id in (select client_id from clients where deleted=1 and child_number=0))					return -12
if exists(select p_id from YRetailBill where bill_id=@nBillId and p_id in (select product_id from products where deleted=1 and child_number=0))	return -9
if exists(select sin_id from Yretailbillidx where billid=@nBillId and sin_id in (select storage_id from storages where deleted=1 and child_number=0))	return -10
if exists(select e_id from Yretailbillidx where billid=@nBillId and e_id in (select emp_id from employees where deleted=1 and child_number=0)) 					return -11
if exists(select inputman from Yretailbillidx where billid=@nBillId and inputman in (select emp_id from employees where deleted=1 and child_number=0)) 	return -11
if exists(select auditman from Yretailbillidx where billid=@nBillId and auditman in (select emp_id from employees where deleted=1 and child_number=0)) 	return -11
if exists(select location_id from Yretailbill where bill_id=@nBillId and location_id in (select loc_id from location where deleted=1)) 					return -14
if exists(select unitid from Yretailbill where bill_id=@nBillId and unitid in (select unit_id from unit where deleted=1))							return -15
     
declare @ysmoney NUMERIC(25,8),@total NUMERIC(25,8),@taxtotal NUMERIC(25,8)
set @ysmoney=0 set @total=0 
select @ysmoney=ysmoney from Yretailbillidx  where billid=@nBillId 
select @total=SUM(taxtotal) from Yretailbill where bill_id=@nBillId and p_id>0
if (@ysmoney<>@total) return -999

set @total=0 set @taxtotal=0
select @taxtotal=SUM(taxtotal) from Yretailbill where bill_id=@nBillId and p_id>0
select @total=SUM(total) from Yretailbill where bill_id=@nBillId and p_id<0
if (@taxtotal<>@total) return -999

return 0
GO
