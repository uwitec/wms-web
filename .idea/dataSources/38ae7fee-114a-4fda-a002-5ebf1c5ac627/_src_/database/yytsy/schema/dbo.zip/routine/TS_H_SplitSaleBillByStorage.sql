/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2013-10-9*/
/* Description:	按仓库拆分销售出库单草稿*/
/* =============================================*/
CREATE PROCEDURE TS_H_SplitSaleBillByStorage 
	@nBillId int = 0, 
	@szBillIds varchar(200) output,
	@nBillType int
AS
BEGIN
  /*标准流程不拆销售订单	*/
  IF @nBillType = 14
    IF EXISTS (SELECT 1 FROM sysconfigtmp WHERE sysvalue = '1' and [sysname] = 'GspStandardProcess')
      RETURN 0		

  SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 
  begin tran SplitSaleBill
    
	SET NOCOUNT ON;

	SET @szBillIds = ''

	if @nBillId is null set @nBillId = 0
	
	if @nBillId <= 0
	begin
	    commit tran SplitSaleBill
	    SET TRANSACTION ISOLATION LEVEL READ COMMITTED 
		RETURN -1
    end		

	IF NOT EXISTS(SELECT * FROM sysconfigtmp WHERE sysname = 'SplitSaleBillByStorage' AND sysvalue = '1')
	begin
	    commit tran SplitSaleBill
	    SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		RETURN -1
    end		

	DECLARE @nNewBillId int
	DECLARE @nSid int
	DECLARE @szStorageGroup varchar(80)
	DECLARE @nBillCount int
	DECLARE @nStorageCount int
	DECLARE @uBillGuid uniqueidentifier
	DECLARE @nError int
	
    SET @nError = 0
	SET @nBillCount = 0

	IF @nBillType in (10, 152) AND EXISTS(SELECT * FROM billdraftidx WHERE billid = @nBillId AND billtype IN (10, 152) AND billstates = '3')
	BEGIN
		SELECT @nStorageCount = COUNT(alias) FROM 
			(SELECT   s.alias
			FROM      dbo.salemanagebilldrf AS sb INNER JOIN
							dbo.storages AS s ON sb.ss_id = s.storage_id
			WHERE   (sb.bill_id = @nBillId) AND (sb.p_id > 0) AND (sb.ss_id > 0)
			GROUP BY s.alias) a
		IF @nStorageCount <= 1
		BEGIN
		    update billdraftidx set posid = @nBillId where billid = @nBillId
		    /*--检测信息*/
		    exec TS_L_CheckJhInfo @nBillId,@nBillId,1,@nError output
		    if @nError < 0 
		    goto error
		     
			INSERT INTO JHBillInfo(saleBillId, saleBillGuid)
			select billid, GUID from billdraftidx where billid = @nBillId

			SET @szBillIds = CAST(@nBillId AS VARCHAR(10))
			commit tran SplitSaleBill
	        SET TRANSACTION ISOLATION LEVEL READ COMMITTED
			RETURN 0
		END
		DECLARE curSplit CURSOR FOR
		SELECT alias, MIN(sb.ss_id) AS s_id FROM salemanagebilldrf sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @nBillId AND p_id > 0 GROUP BY alias
		OPEN curSplit
		FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nBillCount = @nBillCount + 1
			SET @uBillGuid = NEWID()
			INSERT INTO billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
                taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
                invoice, transcount, lasttranstime, GUID, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
                VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
                B_CustomName3, RetailDate, sendC_id, WholeQty, PartQty,ZBAuditMan,ZBAuditDate)
			SELECT billdate, billnumber + '-' + dbo.PadLeft(CAST(@nBillCount AS VARCHAR(2)), 2, '0'), billtype, a_id, c_id, e_id, @nSid, @nSid, auditman, inputman, ysmoney, 0, quantity, 
                taxrate, period, billstates, order_id, department_id, @nBillId, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
                invoice, transcount, lasttranstime, @uBillGuid, InvoiceTotal, InvoiceNO, BusinessType, ArAptotal, SendQTY, GatheringMan, 
                VIPCardID, jsInvoiceTotal, Y_ID, transflag, begindate, Enddate, integral, integralYE, B_CustomName1, B_CustomName2, 
                B_CustomName3, RetailDate, sendC_id, 0, PartQty,ZBAuditMan,ZBAuditDate
			FROM billdraftidx WHERE billid = @nBillId
            
            /*-------判断主表 add by luowei 2014-01-17*/
            if @@ROWCOUNT <= 0 
            goto error
            
			SET @nNewBillId = @@IDENTITY

			INSERT INTO salemanagebilldrf(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
                taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                commissionflag, comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
                invoice, invoiceno, PriceType, SendQTY, SendCostTotal, RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, transflag, 
                instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid)
			SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
                taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                commissionflag, sb.comment, unitid, taxrate, order_id, total, iotag, InvoiceTotal, thqty, newprice, orgbillid, AOID, jsprice, 
                invoice, invoiceno, PriceType, SendQTY, SendCostTotal, NEWID(), RowE_id, YCostPrice, NEWID(), sb.Y_ID, transflag, 
                instoretime, cxType, location_id2, comment2, BatchBarCode, scomment, batchprice, CxGuid, Conclusion, OOSid
			FROM salemanagebilldrf sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @nBillId AND s.alias = @szStorageGroup
            
            /*-------判断明细 add by luowei 2014-01-17*/
            if @@ROWCOUNT <= 0 
            goto error
            
            /*---判断单据是否正常生成 add by luowei 2014-01-20*/
            if (not exists(select 1 from billdraftidx where billid = @nNewBillId and billtype = 10)) 
            or (not exists(select 1 from salemanagebilldrf where bill_id = @nNewBillId 
                    and exists(select 1 from billdraftidx where billid = bill_id and billtype = 10)))
            goto error
            
            /*--检测信息*/
		    exec TS_L_CheckJhInfo @nBillId,@nNewBillId,1,@nError output
		    if @nError < 0 
		    goto error          
           
            
			UPDATE billdraftidx SET ysmoney = X.TOTAL, quantity = X.QTY, jsye = X.TOTAL, SendQTY = X.QTY, PartQty = X.QTY, sout_id = x.s_id, sin_id = x.s_id
			FROM(SELECT SUM(taxtotal) AS TOTAL, SUM(quantity) AS QTY, MIN(ss_id) AS s_id FROM salemanagebilldrf WHERE bill_id = @nNewBillId AND p_id > 0) X
			WHERE billdraftidx.billid = @nNewBillId

			INSERT INTO JHBillInfo(saleBillId, saleBillGuid)
			VALUES(@nBillId, @uBillGuid)

			SET @szBillIds = @szBillIds + CAST(@nNewBillId AS VARCHAR) + ','
			FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
		END
		CLOSE curSplit
		deallocate curSplit
		EXEC Ts_b_DeleteBillDraft @nNewBillId, 1, @nBillId
		/*--判断是否删除原单成功 add by luowei 2014-01-17*/
		if @nNewBillId < 0 
		goto error
		
		commit tran SplitSaleBill
	    SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		RETURN 0
	END
	ELSE
	IF @nBillType IN (14) AND EXISTS(SELECT * FROM orderidx WHERE billid = @nBillId AND billstates = '2')
	BEGIN
		SELECT @nStorageCount = COUNT(alias) FROM 
			(SELECT   s.alias
			FROM      dbo.OrderBill AS sb INNER JOIN
							dbo.storages AS s ON sb.ss_id = s.storage_id
			WHERE   (sb.bill_id = @nBillId) AND (sb.p_id > 0) AND (sb.ss_id > 0)
			GROUP BY s.alias) a
		IF @nStorageCount <= 1
		BEGIN
			SET @szBillIds = CAST(@nBillId AS VARCHAR(10))
			commit tran SplitSaleBill
	        SET TRANSACTION ISOLATION LEVEL READ COMMITTED
			RETURN 0
		END
		DECLARE curSplit CURSOR FOR
		SELECT alias, MIN(sb.ss_id) AS s_id FROM OrderBill sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @nBillId AND p_id > 0 GROUP BY alias
		OPEN curSplit
		FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nBillCount = @nBillCount + 1
			SET @uBillGuid = NEWID()
			INSERT INTO orderidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, ysmoney, ssmoney, quantity, 
                taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
                invoice, InvoiceTotal, InvoiceNO, BusinessType, Guid, Y_ID, WT_ID, OrderValidDate, GatheringMan, TrafficCompany, 
                TrafficType, SendTime, SendC_ID)
			SELECT billdate, billnumber + '-' + dbo.PadLeft(CAST(@nBillCount AS VARCHAR(2)), 2, '0'), billtype, a_id, c_id, e_id, @nSid, @nSid, auditman, inputman, ysmoney, 0, quantity, 
                taxrate, period, billstates, order_id, department_id, posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, 
                invoice, InvoiceTotal, InvoiceNO, BusinessType, @uBillGuid, Y_ID, WT_ID, OrderValidDate, GatheringMan, TrafficCompany, 
                TrafficType, SendTime, SendC_ID

			FROM orderidx WHERE billid = @nBillId
            
            /*-------判断主表 add by luowei 2014-01-17*/
            if @@ROWCOUNT <= 0 
            goto error
            
			SET @nNewBillId = @@IDENTITY

			INSERT INTO OrderBill(bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
                taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                commissionflag, comment, unitid, taxrate, ComeDate, ComeQty, total, RowGuid, RowE_id, Y_ID, comment2, Conclusion, 
                Instoretime, BatchBarCode, scomment, batchprice)
			SELECT @nNewBillId, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, totalmoney, taxprice, taxtotal, 
                taxmoney, retailprice, retailtotal, makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, 
                commissionflag, sb.comment, unitid, taxrate, ComeDate, ComeQty, total, NEWID(), RowE_id, sb.Y_ID, comment2, Conclusion, 
                Instoretime, BatchBarCode, scomment, batchprice
			FROM OrderBill sb INNER JOIN storages s ON sb.ss_id = s.storage_id WHERE bill_id = @nBillId AND s.alias = @szStorageGroup
            
            /*-------判断明细 add by luowei 2014-01-17*/
            if @@ROWCOUNT <= 0 
            goto error
            
			UPDATE orderidx SET ysmoney = X.TOTAL, quantity = X.QTY, jsye = X.TOTAL, sout_id = x.s_id, sin_id = x.s_id
			FROM(SELECT SUM(taxtotal) AS TOTAL, SUM(quantity) AS QTY, MIN(ss_id) AS s_id FROM OrderBill WHERE bill_id = @nNewBillId AND p_id > 0) X
			WHERE orderidx.billid = @nNewBillId

			SET @szBillIds = @szBillIds + CAST(@nNewBillId AS VARCHAR) + ','
			FETCH NEXT FROM curSplit INTO @szStorageGroup, @nSid
		END
		CLOSE curSplit
		deallocate curSplit
		EXEC Ts_b_DeleteBillDraft @nNewBillId, 4, @nBillId
		commit tran SplitSaleBill
	    SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		RETURN 0
	END
	
	error:
	rollback tran SplitSaleBill
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED
	/*raiserror('按仓库拆分销售出库单草稿失败，请重试！',16,1)*/
	return -1
END
GO
