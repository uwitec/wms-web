/*产生会计科目明细账*/
CREATE   procedure ts_c_CreateADetail
(  @nBillId numeric(10,0)
)
/*with encryption*/
as
/*  set nocount on*/
/*单据类型定义*/
declare
  @vtBuyDirectMid     int,/* 104;                  //  直调药品采购单（中间商）*/
  @vtBuyDirectGet     int,/* 105;                  //  直调药品采购单（收货方）*/
  @vtSaleDirectMid    int,/* 106;                  //  直调药品销售单（中间商）*/
  @vtSaleDirectSend   int,/* 107;                  //  直调药品销售单（发货方）*/
  
  @vtSale           int,/*= 10;                    //  销售出库单*/
  @vtSaleAccount    int,/*= 210;					//   销售单*/
  @vtSaleBack       int,/* = 11;                  //   销售出库退货单*/
  @vtSaleAccountBack int,/* 211;                  //  销售退货单*/
  @vtSend            int,/*= 212;                  //  发货单*/
  @vtRetail          int,/*= 12;                   //  零售单*/
  @vtRetailBack      int,/*= 13;                   //  零售退货单*/
  @vtSaleOrder       int,/* = 14;                  //  销售定单*/
  @vtGathering       int,/* = 15;                  //  收款单*/
  @vtPreAr          int,/*= 147                    //预收帐款 -->147*/
  @vtYSend 	    int,/*= 150;                     //  机构发货单*/
  @vtYSendBack      int,/*= 151;                 //  机构发货退货单*/
  @vtYSelfSend 	    int,/*= 150;                     //  自营店发货单*/
  @vtYSelfSendBack      int,/*= 151;                 //  自营店发货退货单*/
  @vtYGathering     int,/*= 155;                //  机构收款单*/

  @vtBuy              int,/*20;                  //  采购入库单*/
  @vtBuyAccount     int,/* 220;                  //  采购单*/
  @vtBuyBack        int,/*= 21;                  //  采购入库退货单*/
  @vtBuyAccountBack int,/* 221;                   //  采购退货单*/
  @vtReceive 	    int,/* 222;                   //  收货单*/
  @vtBuyOrder       int,/* = 22;                   //  进货定单*/
  @vtPayment        int,/*= 23;                    //  付款单*/
  @vtPreAp          int,/*= 146                    //预付帐款  --> 146*/
  @vtYReceive       int,/*= 160;                  //  机构收货单*/
  @vtYReceiveBack   int,/*= 161;              //  机构收货退货单*/
  @vtYSelfReceive       int,/*= 160;                  //自营店收货单*/
  @vtYSelfReceiveBack   int,/*= 161;              //  自营店收货退货单*/
  @vtYPayment       int,/*= 165;                  //  机构付款单*/

  @vtLend            int,/*= 30;                   //  借出单*/
  @vtLendBack        int,/*= 31;                   //  借出还回单*/
  @vtLendSale        int,/*= 32;                   //  借出转销售单*/
  @vtBorrow          int,/* 33;                    //  借进单*/
  @vtBorrowBack      int,/* 34;                    //  借进还出单*/
  @vtBorrowBuy      int,/* 35;                    //  借进转进货单*/
  
  @vtCleanPack      INT,/*38                   //清斗单*/
  @vtScattered      INT,/*39                   //零售拆零单*/
  @vtProduce        int,/* 40;                    //  组装单*/
  @vtLost            int,/* 41;                    //  报损单*/
  @vtOverflow        int,/* 42;                    //  报溢单*/
  @vtAdjustPrice    int,/* 43;                   //  调价单*/
  @vtTransfer        int,/* 44;                   //  调拨单*/
  @vtTransfer_Price int,/* 45;                  //  变价调拨单*/
  @vtGive            int,/* 46;                  //  赠送单*/
  @vtGain            int,/* 47;                  //  获赠单*/
  @vtInLib           int,/* 48;                      //  入库单*/
  @vtOutLib         int,/* 49;                     //  出库单*/
  @vtGoodsCheck     int,/*50;                   //  库存盘点单*/


  @vtTranOut     int,/*53//总部配送出库单*/
  @vtTranOutBack   int,/*54//总部配送退货单*/
  @vtTranIn     int,/*55//门店配送入库单*/
  @vtTranInBack   int,/*56//门店配送退货单*/
  @vtTranPayment   int,/*87//配送付款单*/
  @vtTranGathering   int,/*88//配送收款单*/


  @vtCashExpense    int,/* 60;                  //  现金费用单*/
  @vtExpense        int,/* 61;                  //  费用单*/
  @vtOtherIncome    int,/* 62;                  //  其它收入单*/
  @vtMoney          int,/* 63;                  //  现金转帐单*/
  @vtAR_Add          int,/* 64;                  //  应收增加*/
  @vtAR_Reduce      int,/* 65;                  //  应收减少*/
  @vtAP_Add          int,/* 66;                  //  应付增加*/
  @vtAP_Reduce      int,/* 67;                  //  应付减少*/
  @vtCash_Add        int,/* 68;                  //  资金增加*/
  @vtCash_Reduce    int,/* 69;                  //  资金减少*/
  
  @vtReturnBill int, /* 184; 返利单*/
  @vtProfitBill int, /* 185; 获利单*/

  @vtFixedBuy        int,/* 80;                  //  固定资产购置*/
  @vtFixedSale      int,/* 81;                  //  固定资产变卖*/
  @vtFixedDepreciation  int,/* 82;              //  固定资产折旧*/
  @vtExpenseHappen      int,/* 83;              //  待摊费用发生*/
  @vtExpenseAmortize    int,/* 84;              //  待摊费用摊销*/

  @vtAccount            int,/* 90;              //  会计凭证*/

  @vtSendGoods          int,/* 100;             //  发货单*/
  @vtSendBack            int,/* 101;             //  发货退货单*/
  @vtSendSettle          int,/* 102;             //  发货结算单*/
  @vtSendPrice          int,/* 103;             //  发货调价单*/

  @vtCommission          int,/* 110;             //  委托代销单*/
  @vtCommBack            int,/* 111;             //  委托代销退货单*/
  @vtCommSettle          int,/* 112;             //  委托代销结算单*/
  @vtCommPrice          int,/* 113;             //  委托代销调价*/

  @vtReCommission        int,/* 120;             //  受托代销单*/
  @vtReCommBack          int,/* 121;             //  受托代销退货单*/
  @vtReCommSettle        int,/* 122;             //  受托代销结算单*/
  @vtReCommPrice        int,/* 123;             //  受托代销调价*/

  @vtCommRecive          int,/* 130;             //  库外入库单*/
  @vtCommPayment        int,/* 131;             //  库外出库单*/
  @vtStoreMoney          int,  /*148            //  储值单*/
  @vtVipIntegralExChange int,   /*149            //  积分兑换单*/
  @vtPayOffset          int,     /*170               --对结单*/
  @vtYAR_Add 		int,     /*= 171;                   //机构应收增加*/
  @vtYAR_Reduce 	int,     /*= 172;                //机构应收减少*/
  @vtYAP_Add 		int,     /*= 173;                   //机构应付增加*/
  @vtYAP_Reduce 	int     /*= 174;                //机构应付减少*/

  SELECT
  @vtBuyDirectMid     = 104,                  /*  直调药品采购单（中间商）*/
  @vtBuyDirectGet     = 105,                  /*  直调药品采购单（收货方）*/
  @vtSaleDirectMid    = 106,                  /*  直调药品销售单（中间商）*/
  @vtSaleDirectSend   = 107,                  /*  直调药品销售单（发货方）*/
  @vtSale           = 10,                   /*  销售出库单*/
  @vtSaleAccount    = 210,	            /*   销售单*/
  @vtSaleBack       = 11,                   /*  销售出库退货单*/
  @vtSaleAccountBack = 211,                 /*  销售退货单*/
  @vtSend 	     = 212,                 /*  发货单*/
  @vtRetail          = 12,                   /*  零售单*/
  @vtRetailBack      = 13,                   /*  零售退货单*/
  @vtSaleOrder       = 14,                   /*  销售定单*/
  @vtGathering       = 15,                   /*  收款单*/
  @vtPreAr           = 147,                   /*  预收帐款 */
  @vtPreAr           = 147,                    /*//预收帐款 -->147*/
  @vtYSend 	     = 150,                 /*//  机构发货单*/
  @vtYSendBack       = 151,                 /*//  机构发货退货单*/
  @vtYSelfSend 	     = 152,                 /*//  自营店发货单*/
  @vtYSelfSendBack       = 153,                 /*//  自营店发货退货单*/
  @vtYGathering      = 155,                 /*//  机构收款单*/

  @vtBuy            = 20,                   /*  采购入库单*/
  @vtBuyAccount       = 220,                   /*  采购单*/
  @vtBuyBack        = 21,                   /*  采购入库退货单*/
  @vtBuyAccountBack   = 221,                    /*  采购退货单*/
  @vtReceive          = 222,                   /*  收货单*/
  @vtBuyOrder       = 22,                   /*  进货定单*/
  @vtPayment        = 23,                   /*  付款单*/
  @vtPreAp          = 146,                   /*  预付帐款*/
  @vtYReceive       = 160,                  /*//  机构收货单*/
  @vtYReceiveBack   = 161,                  /*//  机构收货退货单*/
  @vtYSelfReceive       = 162,                  /*//  自营店收货单*/
  @vtYSelfReceiveBack   = 163,                  /*//  自营店收货退货单*/
  @vtYPayment       = 165,                  /*//  机构付款单*/

  @vtLend            = 30,                   /*  借出单*/
  @vtLendBack        = 31,                   /*  借出还回单*/
  @vtLendSale        = 32,                   /*  借出转销售单*/
  @vtBorrow          = 33,                   /*  借进单*/
  @vtBorrowBack      = 34,                   /*  借进还出单*/
  @vtBorrowBuy      = 35,                   /*  借进转进货单*/

  @vtCleanPack      = 38,                   /*清斗单*/
  @vtScattered      = 39,                   /*零售拆零单*/
  @vtProduce        = 40,                   /*  组装单*/
  @vtLost            = 41,                   /*  报损单*/
  @vtOverflow        = 42,                   /*  报溢单*/
  @vtAdjustPrice    = 43,                   /*  调价单*/
  @vtTransfer        = 44,                   /*  调拨单*/
  @vtTransfer_Price = 45,                   /*  变价调拨单*/
  @vtGive            = 46,                   /*  赠送单*/
  @vtGain            = 47,                   /*  获赠单*/
  @vtInLib           = 48,                   /*  入库单*/
  @vtOutLib         = 49,                    /*  出库单*/
  @vtGoodsCheck      =  50,                    /*  库存盘点单*/

  @vtTranOut     =53,/*//总部配送出库单*/
  @vtTranOutBack   =54,/*//总部配送退货单*/
  @vtTranIn     =55,/*//门店配送入库单*/
  @vtTranInBack   =56,/*//门店配送退货单*/
  @vtTranPayment   =87,/*//配送付款单*/
  @vtTranGathering   =88,/*//配送收款单*/

  @vtCashExpense    = 60,                   /*  现金费用单*/
  @vtExpense        = 61,                   /*  费用单*/
  @vtOtherIncome    = 62,                   /*  其它收入单*/
  @vtMoney          = 63,                   /*  现金转帐单*/
  @vtAR_Add          = 64,                   /*  应收增加*/
  @vtAR_Reduce      = 65,                   /*  应收减少*/
  @vtAP_Add          = 66,                   /*  应付增加*/
  @vtAP_Reduce      = 67,                   /*  应付减少*/
  @vtCash_Add        = 68,                   /*  资金增加*/
  @vtCash_Reduce    = 69,                   /*  资金减少*/
  
  @vtReturnBill = 184, /* 返利单*/
  @vtProfitBill = 185, /*获利单*/

  @vtFixedBuy        = 80,                   /*  固定资产购置*/
  @vtFixedSale      = 81,                   /*  固定资产变卖*/
  @vtFixedDepreciation  = 82,               /*  固定资产折旧*/
  @vtExpenseHappen      = 83,               /*  待摊费用发生*/
  @vtExpenseAmortize    = 84,               /*  待摊费用摊销*/

  @vtAccount            = 90,               /*  会计凭证*/

  @vtSendGoods          = 100,              /*  发货单*/
  @vtSendBack            = 101,              /*  发货退货单*/
  @vtSendSettle          = 102,              /*  发货结算单*/
  @vtSendPrice          = 103,              /*  发货调价单*/

  @vtCommission          = 110,              /*  委托代销单*/
  @vtCommBack            = 111,              /*  委托代销退货单*/
  @vtCommSettle          = 112,              /*  委托代销结算单*/
  @vtCommPrice          = 113,              /*  委托代销调价*/

  @vtReCommission        = 120,              /*  受托代销单*/
  @vtReCommBack          = 121,              /*  受托代销退货单*/
  @vtReCommSettle        = 122,              /*  受托代销结算单*/
  @vtReCommPrice        = 123,              /*  受托代销调价*/

  @vtCommRecive          = 130,              /*  库外入库单*/
  @vtCommPayment        = 131,               /*  库外出库单*/
  @vtStoreMoney          = 148,             /*储值单*/
  @vtVipIntegralExChange =149,               /*积分兑换单*/
  @vtPayOffset           =170,                /*对结单*/
  @vtYAR_Add 		= 171,			/*机构应收增加*/
  @vtYAR_Reduce 	= 172,			/*机构应收减少*/
  @vtYAP_Add 		= 173,			/*机构应付增加*/
  @vtYAP_Reduce 	= 174			/*机构应付减少*/


/*会计科目定义*/
  declare
    @Asset_Id           int,/*2  【资产合计】*/
    @Products_Id         int,/*3  『库存商品总值合计』*/
    @FixedAsset_id       int,/*4  『固定资产合计』*/
    @FixedAsset1_id     int,/*5   固定资产__甲*/
    @Cash_id             int,/*6   现    金*/
                            /*7  『全部银行存款合计』*/
                            /*8  银行户头_1*/
    @Artotal_Id         int,/*9  『应收款合计』*/
    @nbArtotal_id       int,/*   『内部应收款』      */
    @Lendout_Id         int,/*10  『借出商品』*/
    @Dt_Expens_Id       int,/*11  待摊费用*/
    @Wt_Comm_Id         int,/*12  委托代销商品*/
    @St_Comm_Id         int,/*13  受托代销商品*/
                            /*14  【负债合计】*/
    @Aptotal_Id         int,/*15  『应付帐款合计』*/
    @nbAptotal_Id       int,/*  『内部应付款』*/
    @Brrowin_Id         int,/*16  『借入商品』*/
    @Dxtotal_Id         int,/*17  代销商品款*/
                            /*18  应交税金*/
                            /*19  【收入类】*/
    @SaleIncome_Id       int,/*20  『销售收入』*/
    @YSendIncome_Id      int, /*机构发货收入*/
                            /*21  『商品类收入』*/
    @OverflowIncome_Id   int,/*22  商品报溢收入*/
    @GiftIncome_Id       int,/*23  商品获赠收入*/
    @AdPriceIncome_Id    int,/*24  成本调价收入*/
    @BuySaleCj_Id         int,/*25  进货退货差价*/
    @BjMoveCj_Id         int,/*26  变价调拨差价*/
    @CzCj_Id             int,/*27  商品拆装差价*/
    @JzjhCj_Id           int,/*28  借转进货结算与成本差*/
    @CommissionCj_Id     int,/*29  受托代销结算差价*/
    @OtherIncome_Id       int,/*30  『其它收入』*/
    @AdDebtIncome_Id     int,/*31  调帐收入*/
    @LxIncome_Id         int,/*32  利息收入*/
    @SaleDiscount      int,/*销售折让*/
                             /*33  其它....*/
                             /*34  【支出类】*/
    @SaleCost_Id         int,/*35  『销售成本』*/
    @YSendCost_Id         int, /*  机构发货成本*/
                             /*36  『商品类支出』*/
    @Lose_Id             int,/*37  商品报损*/
    @GiftOut_Id           int,/*38  商品赠出*/
                             /*39  『费用合计』*/
    @AdDebtLose_Id       int,/*40  调帐亏损*/
    @FixedDec_Id         int,/*41  固定资产折旧*/
                              /*42  其它....*/
                             /*43  【所有者权益】*/
                             /*44  实收资本*/
                             /*45  资本公积*/
                             /*46  盈余公积*/
                             /*47  本年利润*/
                             /*48  利润分配*/
                             /*49  【利润】*/
    @TaxBuy_Id          int,/*54  进项税*/
    @TaxSale_Id          int,/*55  销项税*/
    @bank_id               int,  /*储值帐款*/
    @DiffPrice_id          int
    
 declare  @AutomaticDeposit   int /*小额储值  */

/*---------科目[在途物资]*/
declare @WayQty_id	int
select  @WayQty_id=-1
select  @WayQty_id=account_id from account where Class_id='000001009999'
/*--------科目[在途物资]*/

  select  @Asset_Id        =2  /*  【资产合计】*/
  select  @Products_Id    =3  /*  『库存商品总值合计』*/
  select  @FixedAsset_id  =4  /*  『固定资产合计』*/
  select  @Cash_id        =6  /*   现    金*/
                              /*7  『全部银行存款合计』*/
                              /*8  银行户头_1*/
  select  @Artotal_Id      =9  /*9  『应收款合计』*/
  select  @Lendout_Id      =10  /*10  『借出商品』*/
  select  @Dt_Expens_Id    =11  /* 11  待摊费用*/
  select  @Wt_Comm_Id      =12  /*12  委托代销商品*/
  select  @St_Comm_Id      =13  /*13  受托代销商品*/
                              /*14  【负债合计】*/
  select  @Aptotal_Id      =15  /*15  『应付帐款合计』*/
  select  @Brrowin_Id      =16  /*16  『借入商品』*/
  select  @Dxtotal_Id      =17  /*17  代销商品款*/
                              /*18  应交税金*/
                              /*19  【收入类】*/
  select  @SaleIncome_Id   =20  /*『销售收入』*/

                              /*21  『商品类收入』*/
  select  @OverflowIncome_Id=22/*  商品报溢收入*/
  select  @GiftIncome_Id    =23/*  商品获赠收入*/
  select  @AdPriceIncome_Id =24/*  成本调价收入*/
  select  @BuySaleCj_Id      =25/*  进货退货差价*/
  select  @BjMoveCj_Id      =26/*  变价调拨差价*/
  select  @CzCj_Id          =27/*  商品拆装差价*/
  select  @JzjhCj_Id        =28/*  借转进货结算与成本差*/
  select  @CommissionCj_Id  =29/*  受托代销结算差价*/
  select  @OtherIncome_Id    =30/*  『其它收入』*/
  select  @AdDebtIncome_Id  =31/*  调帐收入*/
  select  @LxIncome_Id      =32/*  利息收入*/
                                /*33  其它....*/
                                /*34  【支出类】*/
  select  @SaleCost_Id      =35/*『销售成本』*/
                                /*36『商品类支出』*/
  select  @Lose_Id          =37/*商品报损*/
  select  @GiftOut_Id        =38/*  商品赠出*/
                                /*39  『费用合计』*/
  select  @AdDebtLose_Id    =40/*调帐亏损*/
  select  @FixedDec_Id       =41/*  固定资产折旧*/
                                 /*42其它....*/
                                /*43所有者权益】*/
                                /*44  实收资本*/
                                /*45  资本公积*/
                                /*46  盈余公积*/
                                /*47  本年利润*/
                                /*48  利润分配*/
                                /*49  【利润】*/
  select  @TaxBuy_Id        =54/*进项税*/
  select  @TaxSale_Id        =55/*销项税*/

  declare @PreAr_ID int,
         @PreAp_ID int
         
  select @PreAp_ID = Account_ID FROM Account where Class_ID = '000001000009'  /*预付帐款*/
  select @PreAr_ID = Account_ID FROM Account where Class_ID = '000002000005'  /*预收帐款*/

  select  @DiffPrice_id=account_id from account where class_id='000004000002000003'
  if @DiffPrice_id is null goto error
  select  @SaleDiscount=account_id from account where class_id='000004000003000004'
  if @SaleDiscount is null goto error
 
  declare @Return_id int, /* 返利科目*/
          @Profit_id int  /*获利科目*/
         
  select @Return_id = isnull(Account_ID, -1) FROM Account where Class_ID = '000004000003000005'  /*返利科目*/
  select @Profit_id = isnull(Account_ID, -1) FROM Account where Class_ID = '000003000003000004'  /*获利科目*/
  select @nbArtotal_id = ISNULL(Account_id, -1) from account where class_id = '000001000010' /*内部应收 */
  select @nbAptotal_id = ISNULL(Account_id, -1) from account where class_id = '000002000007' /*内部应付*/
  select @YSendIncome_Id = ISNULL(Account_id, -1) from account where class_id = '000003000004' /*机构发货收入*/
  select @YSendCost_Id  = ISNULL(Account_id, -1) from account where  class_id = '000004000004' /*机构发货成本*/
  
  if @nbArtotal_Id = -1 goto Error
  if @nbAptotal_Id = -1 goto Error
  if @YSendIncome_Id = -1 goto Error
  if @YSendCost_Id = -1 goto Error
  
/*会计科目定义*/

  declare @nBillType smallint,@tBillDate datetime,@szBillNumber varchar(20),@nA_id int,@nC_id int,@nP_id int,@nE_id int,@nSs_id int,@nSd_id int,@nPrice_id int,@dDiscountPrice NUMERIC(25,8)
  declare @nAuditMan int,@nInputMan int,@dYsMoney NUMERIC(25,8),@dSsMoney NUMERIC(25,8),@dQuantity NUMERIC(25,8),@dSalePrice NUMERIC(25,8),@dBuyPrice NUMERIC(25,8),@dCostPrice NUMERIC(25,8)
  declare @dDiscountTotal NUMERIC(25,8),@dTaxTotal NUMERIC(25,8),@dTaxMoney NUMERIC(25,8),@dTaxrate numeric(5,2),@dCostTotal NUMERIC(25,8)
  declare @dArApTotal NUMERIC(25,8),@dChange NUMERIC(25,8),@dTotalTemp NUMERIC(25,8),@dJfTotal NUMERIC(25,8),@dDftotal NUMERIC(25,8),@direction bit
  declare @szAClass_id varchar(10),@saleDiscountMoney NUMERIC(25,8),@szDiscounttotal varchar(30)
  declare @nY_ID int,@Vipcardid int
/*借贷标志*/
  declare @jf bit
  declare @df bit

  select @jf=0
  select @df=1

  set @dYsMoney=0
  set @dTaxMoney=0
  set @dSsMoney=0
  set @dDiscountTotal=0
  set @dArApTotal=0
/*取表头信息*/
  select @nBillType=BillType,@tBillDate=BillDate,@nA_id=a_id,@nC_id=c_id,@nE_id=e_id,@Vipcardid=VIPCardid,
         @dYsMoney=ysmoney,@dSsMoney=SsMoney,@dTaxRate=taxrate,@nY_ID=Y_ID 
    from BillIdx where billid=@nBillId
  
  	/*自营店收货单、自营店收货退货单实时账套时不能产生凭证*/
	if @nBillType in (@vtYSelfReceive, @vtYSelfReceiveBack) 
	begin
	  if exists(select 1 from company where company_id = @nY_ID and posdatamode <> 1)
	    Return 0
	end
  
  /*对结单*/
  if (@nBillType = @vtPayOffset) 
  begin
     if @dYsMoney=0 
     begin 
       return 0
     end
     else if @dYsMoney>0 
     begin   
       goto PaySetoffBill_SK
       return 0
     end
     else if @dYsMoney<0 
     begin   
       goto PaySetoffBill_FK
       return 0
     end 
  end

/*  select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=abs(isnull(sum(costtotal),0)) from productdetailtmp where billid=@nbillid and storetype=0 --2004-07-19 曾川修改负库存问题*/
  select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
  select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype=0 /*2004-07-19 曾川修改负库存问题*/
/*  select @dTaxMoney=isnull(sum(taxtotal)-sum(total),0) from productdetailtmp where Billid=@nBillId and storetype=0*/
  if @dSsMoney<>@dYsMoney
    select @dArApTotal=@dYsMoney-@dSsMoney

  set @bank_id = -1
  set @AutomaticDeposit = -1
  if @nBilltype in(@vtRetail,@vtRetailBack)
  begin
     select @bank_id = account_id from account where class_id = '000002000006'
     SELECT @AutomaticDeposit = account_id FROM account WHERE class_id='000002000008'

  end

/*--------------------------*/

/*---------------------------发货单------------------------------*/
  if (@nBilltype=@vtSend)
  begin    
    set @dCostTotal=0
    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid<>7	/*王跃2005-8-5修改库外库商品可以参与销售，但销售成本不包含库外库商品，也不包含销售赠送*/

    if (@dCostTotal<>0) 
    begin
            /*借销售成本增加*/
	    insert into accountdetailtmp ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@SaleCost_Id,@nC_id,-@dCostTotal,@jf, @nY_ID)
	    if @@rowcount=0 goto error
	    /*贷库存商品减少*/
	    insert into accountdetailtmp ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
	    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df, @nY_ID)
	    if @@rowcount=0 goto error
    end

    goto SpecialProcess
  end 
/*---------------------------发货单------------------------------*/

/*---------------------------销售单------------------------------*/
/*销售单 不从productdetailtmp取数据*/
  if @nBilltype in (@vtSaleAccount)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid and aoid<>7 and P_Id>0
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(TotalMoney)),0) from salemanagebill where bill_id=@nBillId and aoid<>7  and P_Id>0/*2004-07-19 曾川修改负库存问题*/

    /*if @nBilltype<>@vtRetail*/
    /*begin*/
      /*借应收账款*/
      if @dArApTotal<>0
      begin
        insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@Artotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    /*end*/
    /*借银行存款增加*/
    if @dSsMoney<>0 and @nA_id>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
  /*多账户*/
  if @nbilltype in (@vtSaleAccount) and exists(select 1 from salemanagebill where bill_id=@nbillid and p_id<0 and p_id > -9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag, Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,(Case abs(P_id) when @PreAr_ID then -total else total end) as total,@jf, @nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷应交增值税金销项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,@dTaxMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*贷销售收入增加*/
    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid and P_Id>0
    if @dDiscounttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@SaleIncome_Id,@nC_id,@dDiscountTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
     /*-赠品处理*/
    select @dCostTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid and aoid=7 and P_Id>0
    if @dCostTotal<>0
    begin
	      /*商品赠出*/
	      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	      values (@nbillid,@GiftOut_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
              if @@rowcount=0 goto error
    end

  end
/*---------------------------挂号单、诊治费用单-----------------------*/
	if @nBillType in (240, 243)
	begin
		/*借银行存款增加*/
		if @dSsMoney<>0 and @nA_id>0 
		begin
		  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
		  if @@rowcount=0 goto error
		end
	  /*多账户*/
		if @nbilltype in (243) and exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id >-9999)
		begin
			insert into accountdetailtmp 
			([billid],[a_id],[c_id],jdmoney,jdflag, Y_ID)   
			select 
			@nBillId,abs(P_id),@nC_id,(Case when abs(P_id) in(@PreAr_ID,@bank_id) then -total else total end) as total,@jf, @nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id >-9999 order by smb_id
			if @@rowcount=0 goto error
		end
		declare crZS cursor for
		SELECT     dbo.SpecialProducts.AccountID, sum(dbo.salemanagebill.totalmoney)
		FROM         dbo.SpecialProducts INNER JOIN
							  dbo.salemanagebill ON dbo.SpecialProducts.product_id = dbo.salemanagebill.p_id
		WHERE     (dbo.salemanagebill.bill_id = @nbillid)
		GROUP BY dbo.SpecialProducts.AccountID
		open crZS
		declare @iFor int
		set @iFor = 0
		while @iFor < @@cursor_rows
		begin
			fetch next from crZS into @nA_ID, @dDiscountTotal
			insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
			values (@nbillid,@nA_ID,@nC_id,@dDiscountTotal,@df, @nY_ID)
			set @iFor = @iFor + 1
			if @@rowcount=0 goto error
		end
		close crZS
		deallocate crZS
	end

/*---------------------------销售单------------------------------*/

/*---------------------------销售出库单,零售单,配送出库单,机构发货单------------------------------*/
  if @nBilltype in (@vtSale,@vtRetail,@vtTranOut,@vtYSend, @vtSaleDirectSend, @vtSaleDirectMid)
  begin
	declare @dRespense NUMERIC(25,8)
  
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype in (0,3) and aoid<>7
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype  in (0,3) and aoid<>7 /*2004-07-19 曾川修改负库存问题*/

    if @nBilltype<>@vtRetail
    begin
      /*借应收账款*/
      if @dArApTotal<>0
      begin
        if @nBilltype = @vtYSend
           insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
			values (@nbillid,@nbArtotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
        else
			insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
			values (@nbillid,@Artotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end
    /*借银行存款增加*/
    if @dSsMoney<>0 and @nA_id>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
  /*多账户*/
  if @nbilltype in (@vtSale,@vtRetail,@vtYSend, @vtSaleDirectSend, @vtSaleDirectMid) and exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag, Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,(Case when abs(P_id) in(@PreAr_ID,@bank_id/*,@AutomaticDeposit*/) then -total else total end) as total,@jf, @nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id >-9999 order by smb_id
   if @@rowcount=0 goto error
  end
  else
  if exists(select * from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney, [Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,total,@nY_ID from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
	/*贷诊治费用科目*/
	declare crZS cursor for
	SELECT     sp.AccountID, SUM(sb.totalmoney) AS Expr1
	FROM         dbo.SpecialProducts AS sp INNER JOIN
                      dbo.salemanagebill AS sb ON sp.product_id = sb.p_id where sb.AOID = 8
	and (sb.bill_id = @nbillid)
	GROUP BY sp.AccountID
	open crZS
	/*declare @iFor int*/
	set @iFor = 0
	while @iFor < @@cursor_rows
	begin
		fetch next from crZS into @nA_ID, @dRespense
		insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		values (@nbillid,@nA_ID,@nC_id,@dRespense,@df, @nY_ID)
		set @iFor = @iFor + 1
		if @@rowcount=0 goto error
	end
	close crZS
	deallocate crZS
		                      
    /*贷销售收入增加*/
    if @dDiscounttotal<>0
    begin
      if @nBilltype =  @vtYSend
          insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@YSendIncome_Id,@nC_id,@dDiscountTotal,@df, @nY_ID)
      else   
		  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@SaleIncome_Id,@nC_id,@dDiscountTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷应交增值税金销项税 机构发货存在税率时等于销售，计销项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,@dTaxMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid<>7	/*王跃2005-8-5修改库外库商品可以参与销售，但销售成本不包含库外库商品，也不包含销售赠送*/

    if @dCostTotal<>0
    begin
      /*借销售成本增加*/
      if @nBilltype =  @vtYSend
          insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@YSendCost_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
      else
		  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@SaleCost_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)

      if @@rowcount=0 goto error
      /*贷库存商品减少*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    goto SpecialProcess
  end
/*----------------------------销售出库单,零售单,配送出库单--------------------------*/

/*----------------------------销售退货单--------------------------*/
/*销售退货单 不从productdetailtmp取数据*/
  if @nBillType in (@vtSaleAccountBack)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid  and aoid<>7 and P_Id>0
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(TotalMoney)),0) from salemanagebill where Bill_id=@nBillId  and aoid<>7 and P_Id>0/*2004-07-19 曾川修改负库存问题*/

    if @nBilltype<>@vtRetailBack
    begin
      /*借应收账款减少*/
      if @dArApTotal<>0
      begin
        insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@Artotal_Id,@nC_id,-@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end
    /*借银行存款减少*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

  if @nBillType in (@vtSaleAccountBack) and exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,(Case abs(P_id) when @PreAr_ID then total else -total end) as total,@jf,@nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id > -9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷应交增值税销项税金减少*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,-@dTaxMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*贷销售收入减少*/
    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid  and P_Id>0
    if @dDiscountTotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@SaleIncome_Id,@nC_id,-@dDiscountTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*-赠品处理*/
    select @dCostTotal=abs(isnull(sum(TotalMoney),0)) from salemanagebill where bill_id=@nbillid and aoid=7 and P_Id>0
    if @dCostTotal<>0
    begin
	      /*商品赠出*/
	      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	      values (@nbillid,@GiftOut_Id,@nC_id,-@dCostTotal,@jf, @nY_ID)
	      if @@rowcount=0 goto error
    end

  end
/*----------------------------销售退货单--------------------------*/

/*----------------------------销售出库退货单,零售退货单,配送出库退货单,机构发货退货单------------------------------*/
  if @nBillType in (@vtSaleBack,@vtRetailBack,@vtTranOutBack,@vtYSendBack)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype in (0,3) and aoid<>7
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype  in (0,3) and aoid<>7/*2004-07-19 曾川修改负库存问题*/

    if @nBilltype<>@vtRetailBack
    begin
      /*借应收账款减少*/
      if @dArApTotal<>0
      begin
        if @nBillType = @vtYSendBack
			insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
			values (@nbillid,@nbArtotal_Id,@nC_id,-@dArApTotal,@jf, @nY_ID)
        else
			insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
			values (@nbillid,@Artotal_Id,@nC_id,-@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end
    /*借银行存款减少*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID] )
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

  if @nBillType in (@vtSaleBack,@vtRetailBack,@vtYSendBack) and exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,[Y_ID])   
   select                                    
   @nBillId,abs(P_id),@nC_id,(Case when abs(P_id) in (@PreAr_ID,@bank_id) then total else -total end) as total,@jf,@nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
  else
  if exists(select 1 from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id >-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,-(total),@nY_ID from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id > -9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷销售收入减少*/
    if @dDiscountTotal<>0
    begin
      if @nBillType = @vtYSendBack
          insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@YSendIncome_Id,@nC_id,-@dDiscountTotal,@df, @nY_ID)
      else
		  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@SaleIncome_Id,@nC_id,-@dDiscountTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷应交增值税销项税金减少*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,-@dTaxMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid<>7	/*王跃2005-8-5修改库外库商品可以参与销售，但销售成本不包含库外库商品，也不包含销售赠送*/

    if @dCostTotal<>0
    begin
      /*借销售成本减少*/
      if @nBillType = @vtYSendBack
         insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@YSendCost_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
      else
		  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@SaleCost_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
      if @@rowcount=0 goto error
      /*贷库存商品增加*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    goto SpecialProcess
  end
/*----------------------------销售出库退货单,零售退货单,配送出库退货单--------------------------*/

/*----------------------------委托代销发货单---------------------------*/
  if @nBilltype in (@vtCommission)
  begin
    /*借委托代销商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Wt_Comm_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    /*贷库存商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
/*----------------------------委托代销发货单--------------------------*/


/*---------------------------委托代销退货单------------------------------*/
  if @nBilltype in (@vtCommBack)
  begin
    /*借库存商品*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    /*贷委托代销商品*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Wt_Comm_Id,@nC_id,-@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
/*----------------------------委托代销退货单--------------------------*/

/*----------------------------委托代销结算单---------------------------*/

  if @nBilltype in (@vtCommSettle)
  begin
    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=1
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype=1
     /*借应收账款*/
    if @dArApTotal<>0
    begin
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Artotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*借银行存款增加*/
    if @dSsMoney<>0  and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
  if exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,(Case abs(P_id) when @PreAr_ID then -total else total end) as total,@jf,@nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷销售收入增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@SaleIncome_Id,@nC_id,@dDiscountTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
    /*贷应交增值税金销项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,@dTaxMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*借销售成本增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@SaleCost_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    /*贷委托代销商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Wt_Comm_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error

    return 0
  end
/*----------------------------委托代销结算单--------------------------*/

/*----------------------------收货单--------------------------*/
  if @nBilltype in (@vtReceive)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype in (0,3) and aoid <>7
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype  in (0,3) and aoid<>7/*2004-07-19 曾川修改负库存问题*/

    /*借库存商品增加*/
    if (@dCosttotal<>0) 
    begin
	      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf,@nY_ID)
	      if @@rowcount=0 goto error
    end   
    /*在途物资减少     */
    if (@WayQty_id<>-1) and (@dCostTotal<>0) /* "采购单"影响科目:[在途物资] */
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@WayQty_id,@nC_id,-@dCostTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end

    goto SpecialProcess
  end
/*----------------------------收货单--------------------------*/

/*----------------------------采购单--------------------------*/
  if @nBilltype in (@vtBuyAccount)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)),@dCostTotal=abs(isnull(sum(TotalMoney),0)) from buymanagebill where bill_id=@nbillid  and aoid <>7 and P_Id>0
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(TotalMoney)),0) from buymanagebill where Bill_id=@nBillId  and aoid<>7 and P_Id>0 /*2004-07-19 曾川修改负库存问题*/

     /*贷应付账款*/
    if @dArApTotal<>0
    begin
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Aptotal_Id,@nC_id,@dArApTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款减少*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
  if @nbilltype=@vtBuyAccount and exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,-total,@jf,@nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
/*  else
  if exists(select * from Tranmanagebill where bill_id=@nbillid and p_id<0)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney)   
   select 
   @nBillId,abs(P_id),@nC_id,total from Tranmanagebill where bill_id=@nbillid and p_id<0 order by smb_id
   if @@rowcount=0 goto error
    end
*/
/*
    --借库存商品增加
    if (@dCosttotal<>0) and (@nBilltype<>@vtBuyAccount) --"采购单"不影响科目:[借库存商品]
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf)
      if @@rowcount=0 goto error
    end
*/
    /*借应交增值税金进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[y_id])
      values (@nbillid,@TaxBuy_Id,@nC_id,-@dTaxMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*在途物资增加            */
    select @dCostTotal=isnull(sum(TotalMoney),0) from buyManagebill where bill_id=@nbillid  and P_Id>0
    if (@WayQty_id<>-1) and (@dCostTotal<>0) /* "采购单"影响科目:[在途物资] */
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@WayQty_id,@nC_id,@dCostTotal,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end
    /*-赠品处理            */
    select @dCostTotal=isnull(sum(TotalMoney),0) from buyManagebill where bill_id=@nbillid  and aoid=7 and P_Id>0
    if @dCostTotal<>0 
    begin  
	    /*商品获赠收入*/
	    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@GiftIncome_Id,@nC_id,@dCostTotal,@df, @nY_ID)
	    if @@rowcount=0 goto error
     end
    
    
  end
/*----------------------------采购单--------------------------*/

/*----------------------------采购入库单,配送入库单,机构收货单------------------------------*/
  if @nBilltype in (@vtBuy,@vtTranIn,@vtYReceive,@vtYSelfReceive, @vtBuyDirectGet, @vtBuyDirectMid)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype in (0,3) and aoid <>7
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype  in (0,3) and aoid<>7/*2004-07-19 曾川修改负库存问题*/

     /*贷应付账款*/
    if @dArApTotal<>0
    begin
      if @nBilltype = @vtYReceive
		 insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@nbAptotal_Id,@nC_id,@dArApTotal,@df,@nY_ID)     
      else
		  insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@Aptotal_Id,@nC_id,@dArApTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款减少*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID]) 
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
  if @nbilltype in (@vtbuy,@vtYReceive, @vtBuyDirectGet, @vtBuyDirectMid) and exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,-(total),@jf,@nY_ID from buymanagebill where bill_id=@nbillid and p_id<0  and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
  else
  if exists(select * from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,-(total),@nY_ID from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
    end

    /*借库存商品增加*/
    if @dCosttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*借应交增值税金进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxBuy_Id,@nC_id,-@dTaxMoney,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end

    goto SpecialProcess
  end
/*----------------------------采购入库单,配送入库单--------------------------*/

/*----------------------------采购退货单------------------------------*/
  if @nBilltype in (@vtBuyAccountBack)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(TotalMoney),0)),@dCostTotal=isnull(sum(TotalMoney),0) from buymanageBill where bill_id=@nbillid  and aoid <>7 and P_Id>0
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(TotalMoney)),0) from buymanageBill where Bill_id=@nBillId  and aoid<>7 and P_Id>0/*2004-07-19 曾川修改负库存问题*/

    select @dChange=abs(@dDiscountTotal)-abs(@dCostTotal)
     /*贷应付账款减少*/
    if @dArApTotal<>0
    begin
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Aptotal_Id,@nC_id,-@dArApTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款增加*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
  if @nBilltype in (@vtBuyAccountBack) and exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,total,@jf,@nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
/*  else
  if exists(select * from Tranmanagebill where bill_id=@nbillid and p_id<0)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney)   
   select 
   @nBillId,abs(P_id),@nC_id,total from Tranmanagebill where bill_id=@nbillid and p_id<0 order by smb_id
   if @@rowcount=0 goto error
  end
*/    
/*    --借库存商品减少
    if @dCosttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf)
      if @@rowcount=0 goto error
    end
*/
    /*结算差价增加*/
    if @dChange<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@BuySaleCj_Id,@nC_id,@dChange,@df,@nY_ID)
      if @@rowcount=0 goto error
    end   

    /*借应交增值说进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxBuy_Id,@nC_id,@dTaxMoney,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end

    /*在途物资减少   */
    select @dCostTotal=isnull(sum(TotalMoney),0) from buyManagebill where bill_id=@nbillid  and P_Id>0
    if (@WayQty_id<>-1) and (@dCostTotal<>0)
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@WayQty_id,@nC_id,-@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*-赠品处理           */
    select @dCostTotal=isnull(sum(TotalMoney),0) from buyManagebill where bill_id=@nbillid and aoid=7 and P_Id>0
    if @dCostTotal<>0 
    begin  
	    /*商品获赠收入*/
	    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@GiftIncome_Id,@nC_id,-@dCostTotal,@df,@nY_ID)
	    if @@rowcount=0 goto error
     end


  end
/*----------------------------采购退货单------------------------------*/

/*----------------------------采购入库退货单,配送入库退货单,机构收货退货单------------------------------*/
  if @nBilltype in (@vtBuyBack,@vtTranInBack,@vtYReceiveBack, @vtYSelfReceiveBack)
  begin
    set @dTaxMoney=0
    set @dDiscountTotal=0
    set @dCostTotal=0

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype in (0,3) and aoid <>7
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype  in (0,3) and aoid<>7/*2004-07-19 曾川修改负库存问题*/

    select @dChange=abs(@dDiscountTotal)-abs(@dCostTotal)
     /*贷应付账款减少*/
    if @dArApTotal<>0
    begin
	  if @nBilltype	= @vtYReceiveBack
	     insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@nbAptotal_Id,@nC_id,-@dArApTotal,@df,@nY_ID)
	  else   
		  insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		  values (@nbillid,@Aptotal_Id,@nC_id,-@dArApTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款增加*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
  if @nBilltype in (@vtBuyBack,@vtYReceiveBack) and exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,total,@jf,@nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
  else
  if exists(select * from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,[Y_ID])   
   select 
   @nBillId,abs(P_id),@nC_id,total,@nY_ID from Tranmanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
    
    /*借库存商品减少*/
    if @dCosttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*结算差价增加*/
    if @dChange<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@BuySaleCj_Id,@nC_id,@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    /*借应交增值说进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxBuy_Id,@nC_id,@dTaxMoney,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end

    goto SpecialProcess
  end
/*-----------------------------采购入库退货单------------------------------*/

/*-----------------------------收款单--------------------------*/

  if @nBilltype in (@vtGathering,@vtTranGathering,@vtYGathering)
  begin
    PaySetoffBill_SK:
  
    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      if @PreAr_ID = @nA_id select @dJfTotal = -@dJfTotal    /*当科目为预收时需要反向*/
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@jf, @nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager

     /*贷应收账款减少*/
    if @nBilltype = @vtYGathering
	    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@nbArtotal_Id,@nC_id,-@dYsMoney,@df, @nY_ID)    
    else
	    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@Artotal_Id,@nC_id,-@dYsMoney,@df, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
/*-----------------------------收款单--------------------------*/

/*-----------------------------预收款单------------------------*/
  if @nBilltype in (@vtPreAr)
  begin
    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@jf, @nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@PreAr_ID,@nC_id,@dYsMoney,@df,@nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
/*-----------------------------预收款单------------------------*/


/*-----------------------------付款单----------------------------------*/

  if @nBillType in (@vtPayment,@vtTranPayment,@vtYPayment)
  begin
    PaySetoffBill_FK:

    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
       if @nBilltype=@vtPayOffset 
       begin
         select @dJFTotal=@dJFTotal
       end else
       begin
         select @dJFTotal=-@dJFTotal
       end

      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@df,@nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager

    if @nBilltype=@vtPayOffset 
      select @dYsMoney=@dYsMoney
    else 
      select @dYsMoney=-@dYsMoney

     /*借应付账款减少*/
    if @nBillType = @vtYPayment
	    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@nbAptotal_Id,@nC_id,@dYsMoney,@jf, @nY_ID)
    else
	    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
	    values (@nbillid,@Aptotal_Id,@nC_id,@dYsMoney,@jf, @nY_ID)
    if @@rowcount=0 goto error

    return 0
  end
/*-----------------------------付款单处理结束--------------------------*/

/*---------------------------  预付款单--------------------*/
  if @nBilltype in (@vtPreAp)
  begin
    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,-@dJfTotal,@jf, @nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])          
      values (@nbillid,@PreAp_ID,@nC_id,@dYsMoney,@df, @nY_ID)
    if @@rowcount=0 goto error
                             
    return 0
  end
/*-----------------------------预付款单-----------------------*/

/*-----------------------------报损单--------------------------*/

  if @nBillType  in (@vtLost, @vtCleanPack)
  begin
    /*贷库存商品减少*/
    if @dCostTotal<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*借商品报损*/
    if @dCostTotal<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Lose_Id,0,-@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
/*-----------------------------报损单--------------------------*/

/*-----------------------------报溢单--------------------------*/

  if @nBillType=@vtOverflow
  begin
    /*借库存商品增加*/
    if @dCostTotal<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷商品报溢*/
    if @dCostTotal<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@OverflowIncome_Id,0,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
/*-----------------------------报溢单--------------------------*/

/*-----------------------------调价单--------------------------*/

  if @nBillType=@vtAdjustPrice
  begin
    select @dChange=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*借库存商品变动*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,0,@dChange,@jf, @nY_ID)
    if @@rowcount=0 goto error
    /*贷成本调价收入*/
    if @dChange<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@AdPriceIncome_Id,0,@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
/*-----------------------------调价单--------------------------*/

/*-----------------------------同价调拨单--------------------------*/

  if @nBillType =@vtTransfer
  begin
    return 0
  end
/*----------------------------同价调拨单--------------------------*/

/*----------------------------变价调拨单--------------------------*/

  if @nBillType=@vtTransfer_Price
  begin
    select @dChange=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*借库存商品变动*/
    if @dChange<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dChange,@jf, @nY_ID)
      if @@rowcount=0 goto error
    /*贷变价调拨差价*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@BjMoveCj_Id,0,@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
  
  
/*----------------------------变价调拨单--------------------------*/

/*----------------------------自营店发货单--------------------------*/

  if @nBillType=@vtYSelfSend
  begin
    select @dChange=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*借库存商品变动*/
    if @dChange<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dChange,@jf, @nY_ID)
      if @@rowcount=0 goto error
    /*贷变价调拨差价*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@BjMoveCj_Id,@nC_id,@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
  
  
/*----------------------------自营店发货单--------------------------*/

/*----------------------------自营店发货单退货单--------------------------*/

  if @nBillType=@vtYSelfSendBack
  begin
    select @dChange=isnull(sum(total-costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*借库存商品变动*/
    if @dChange<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,-@dChange,@jf, @nY_ID)
      if @@rowcount=0 goto error
    /*贷变价调拨差价*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@BjMoveCj_Id,@nC_id,-@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
  
  
/*----------------------------自营店发货单退货单--------------------------*/


/*----------------------------转款单--------------------------*/

  if @nBillType=@vtMoney
  begin
    /*贷现金银行存款减少*/
    if @dSsMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,0,-@dSsMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@djfTotal,@direction,@nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager

    return 0
  end
/*----------------------------转款单处理结束--------------------------*/

/*----------------------------调帐单--------------------------*/

  /*---应收减少&应付增加*/

  if @nBillType in(@vtAR_Add,@vtAR_Reduce,@vtAP_Add,@vtAP_Reduce,
		   @vtYAR_Add,@vtYAR_Reduce,@vtYAP_Add,@vtYAP_Reduce)
  begin
    declare crMoneyManager cursor for
    SELECT a.a_id,a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      if @nBillType in(@vtAR_Reduce,@vtAP_Reduce,@vtYAR_Reduce,@vtYAP_Reduce)
      select @dJfTotal=-@dJfTotal
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@direction, @nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager

    select @dTotalTemp=isnull(sum(abs(jdmoney)),0) from accountdetailtmp where billid=@nbillid

    if @nBillType in (@vtAR_Reduce, @vtAP_Add, @vtYAR_Reduce, @vtYAP_Add)/*---应收减少&应付增加*/
    begin
      /*调帐亏损*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@AdDebtLose_Id,0,@dTotalTemp,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    if @nBillType in (@vtAR_Add, @vtAP_Reduce, @vtYAR_Add, @vtYAP_Reduce) /*---应收增加&应付减少*/
    begin
      /*调帐收入*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@AdDebtIncome_Id,0,@dTotalTemp,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    return 0
  end

/*----------------------------调帐单--------------------------*/

/*----------------------------拆装单--------------------------*/
  if @nBillType in (@vtScattered, @vtProduce)
  begin
    select @dChange=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*库存商品变动*/
    if @dChange<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dChange,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*拆装差价*/
    if @dChange<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@CzCj_Id,0,@dChange,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
/*----------------------------拆装单--------------------------*/

/*----------------------------入库单--------------------------*/

  if @nBillType=@vtInLib
  begin
    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid=0
    if @dCostTotal<>0
    begin
      /*借库存商品增加*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    /*贷其他收入增加*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
      values (@nbillid,@nA_Id,0,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    goto SpecialProcess
  end
/*----------------------------入库单--------------------------*/

/*----------------------------出库单--------------------------*/
  if @nBillType=@vtOutLib
  begin
    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid=0
    /*借库存商品减少*/
    if @dCostTotal<>0 
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dCostTotal,@jf,@nY_ID)
      if @@rowcount=0 goto error
  
      /*借其他费用增加*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,0,-@dCostTotal,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end
    goto SpecialProcess
  end
/*----------------------------出库单--------------------------*/

/*----------------------------受托代销收货单--------------------------*/

  if @nBillType=@vtReCommission
  begin
    /*借库存商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error
    /*贷受托代销商品款增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag], [Y_ID])
    values (@nbillid,@Dxtotal_Id,@nC_id,@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error

    return 0
  end
/*----------------------------受托代销收货单--------------------------*/

/*----------------------------受托代销退货单--------------------------*/

  if @nBillType=@vtReCommBack
  begin
    /*借库存商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    /*贷受托代销商品款减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Dxtotal_Id,@nC_id,@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
/*----------------------------受托代销退货单--------------------------*/

/*----------------------------受托代销结算单--------------------------*/
  if @nBillType=@vtReCommSettle
  begin
    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype='1'
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype='1'
    select @dChange=abs(@dCostTotal)-@dDiscountTotal
     /*贷应付账款*/
        if @dArApTotal<>0
    begin
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Aptotal_Id,@nC_id,@dArApTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款减少*/
    if @dSsMoney<>0 and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
  if exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,-total,1, @nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷受托代销商品款减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Dxtotal_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error

    /*贷受托代销结算差价*/
    if @dChange<>0
    begin
            insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
            values (@nbillid,@CommissionCj_Id,@nC_id,@dChange,@df, @nY_ID)
            if @@rowcount=0 goto error
    end

    /*借应交增值税金进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxBuy_Id,@nC_id,-@dTaxMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
/*----------------------------受托代销结算单处理结束--------------------------*/



  /*----------------------------钱流单--------------------------*/
  /*支出类  60 现金费用单    61 一般费用单    80 固定资产购买*/
  /*收入类  62 其他收入     81 固定资产变卖*/
  /*其他    82 固定资产折旧 83 待摊费用发生  84 待摊费用摊销*/
  /*资金增加 68 增加减少69*/

  if @nBilltype in (@vtCashExpense,@vtExpense,@vtExpenseAmortize,@vtFixedBuy,@vtCash_Add,@vtCash_Reduce,
                    @vtFixedSale,@vtFixedDepreciation,@vtExpenseHappen,@vtOtherIncome)
  begin
    if @nBilltype in (@vtCashExpense,@vtExpense,@vtFixedBuy,@vtExpenseAmortize)
    begin
      if @dSsMoney<>0
      begin
        insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@jf, @nY_ID)
        if @@rowcount=0 goto error

      end
      /*借应付账款*/
      if @dArApTotal<>0
      begin
        insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@Aptotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end else
    if @nBilltype in (@vtOtherIncome,@vtFixedSale,@vtFixedDepreciation,@vtExpenseHappen)
    begin
      if @dSsMoney<>0
      begin
        insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
      /*借应收账款*/
      if @dArApTotal<>0
      begin
        insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@Artotal_Id,@nC_id,@dArApTotal,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end else
    if @nBilltype =@vtCash_Add
    begin
      if @dSsMoney<>0
      begin
        insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
        if @@rowcount=0 goto error
      end
    end else
    if @nBilltype=@vtCash_Reduce
    begin
      if @dSsMoney<>0
      begin
        insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@df,@nY_ID)
        if @@rowcount=0 goto error
      end
    end

    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0
    begin
      if @nBilltype in (@vtFixedDepreciation,@vtExpenseHappen,@vtFixedSale)
        select @dJfTotal=-@dJfTotal
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@direction, @nY_ID)
      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    end
    close crMoneyManager
    deallocate crMoneyManager
/*
    select @dTotalTemp=abs(sum(total)) from accountdetailtmp where billnumberid=@nbillid

    --固定资产折旧
    if @nBillType=@vtFixedDepreciation
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag])
      values
      (@nBillId,@FixedDec_Id,@nC_id,@dJfTotal,@direction)
      if @@rowcount=0 goto error
    end
    --待摊费用发生
    if @nBillType=@vtExpenseHappen
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag])
      values
      (@nBillId,@Dt_Expens_Id,@nC_id,@dJfTotal,@direction)
      if @@rowcount=0 goto error
    end
    --待摊费用摊销
    if @nBillType=@vtExpenseAmortize
    begin
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag])
      values
      (@nBillId,@Dt_Expens_Id,@nC_id,-@dJfTotal,@direction)
      if @@rowcount=0 goto error
    end
*/
    return 0
  end
  /*----------------------------钱流单--------------------------*/

  /*--------------------------返利获利单begin--------------------------*/
  /*返利*/
  if @nBilltype=@vtReturnBill
  begin
    select @dDftotal = isnull(SUM(total), 0) from ReturnBill where bill_id = @nbillid and p_id < 0
    select @dJfTotal = isnull(SUM(RetTotal),0) from ReturnBill where bill_id = @nbillid and p_id >= 0
    set @dTotalTemp  = @dJfTotal - @dDftotal
    
    if @dJfTotal = 0 goto error
    
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Return_id, @nC_id, @dJfTotal, @jf, @nY_ID)
    if @@rowcount=0 goto error
    
    if @dTotalTemp <> @dJfTotal
    begin
		insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		select bill_id, ABS(p_id),@nC_id, -total, @df,@nY_ID from ReturnBill where bill_id = @nbillid and p_id < 0 
		if @@rowcount=0 goto error
    end
	
	if @dTotalTemp > 0
	begin
	  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		select @nbillid, @Aptotal_Id, @nC_id, @dTotalTemp, @df,@nY_ID
		if @@rowcount=0 goto error
	end
    return 0
  end
  
  /*获利*/
  if @nBilltype=@vtProfitBill
  begin
    select @dJftotal = isnull(SUM(total), 0) from ReturnBill where bill_id = @nbillid and p_id < 0
    select @dDfTotal = isnull(SUM(RetTotal),0) from ReturnBill where bill_id = @nbillid and p_id >= 0
    set @dTotalTemp  = @dDfTotal - @dJftotal
    
    if @dDfTotal = 0 goto error
    
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Profit_id, @nC_id, @dDfTotal, @Df, @nY_ID)
    if @@rowcount=0 goto error
    
    if @dTotalTemp <> @dDfTotal
    begin
		insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		select bill_id, ABS(p_id),@nC_id, total, @jf,@nY_ID from ReturnBill where bill_id = @nbillid and p_id < 0 
		if @@rowcount=0 goto error
	end
	
	if @dTotalTemp > 0
	begin
	  insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
		select @nbillid, @Artotal_Id, @nC_id, @dTotalTemp, @jf, @nY_ID 
		if @@rowcount=0 goto error
	end
    return 0
  end
  /*--------------------------返利获利单end--------------------------*/
 

  /*----------------------------会计凭证--------------------------*/
  if @nBilltype=@vtAccount
  begin
    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction,b.class_id
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id

    open crMoneyManager
    fetch next from crMoneyManager
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction,@szAClass_id
    while @@fetch_status=0
    begin
      if left(@szAClass_id,6)='000001' or left(@szAClass_id,6)='000004'
      begin
        if @dJfTotal<>0 select @dTotaltemp=@dJfTotal else select @dTotaltemp=-@dDfTotal

      end else if left(@szAClass_id,6)='000002' or left(@szAClass_id,6)='000003'
      begin
        if @dJfTotal<>0 select @dTotaltemp=-@dJfTotal else select @dTotaltemp=@dDfTotal
      end

      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nbillid,@na_id,@nc_id,@dTotaltemp,@direction, @nY_ID)

      if @@rowcount=0 goto errormoney

      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction,@szAClass_id
    end
    close crMoneyManager
    deallocate crMoneyManager
    return 0
  end
  /*----------------------------会计凭证--------------------------------*/

  /*----------------------------库单盘点单------------------------------*/
  if @nBilltype in (@vtGoodsCheck)
  begin
    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0
    /*贷库存商品变动*/
    if @dCostTotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,0,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end

    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and quantity<0
    /*借商品报损*/
    if @dCosttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Lose_Id,0,-@dCostTotal,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end
    select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and quantity>0
    /*贷商品报溢*/
    if @dCosttotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@OverflowIncome_Id,0,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
  /*----------------------------库单盘点单--------------------------*/

  /*----------------------------预收预付单开始--------------------------*/
  /*----------------------------预收预付单开始--------------------------*/


  /*----------------------------退补单------------------------------*/
  if @nBillType in (16,17,24,25)
  begin
           declare @tempA_id int

          set @szDiscounttotal=''
          select @szDiscounttotal=isnull(summary,'') from billidx where billid=@nbillid
          if @szDiscounttotal='' goto error  else set @dDiscounttotal=cast(@szDiscounttotal as NUMERIC(25,8))
          select @dTaxmoney=ysmoney-@dDiscounttotal  from billidx where Billid=@nBillId
/*          select @dDiscounttotal=jsye from billidx where billid=@nBillid*/

           if @nBilltype in (16,17) select @tempA_id=@Artotal_Id
           if @nBilltype in (24,25) select @tempA_id=@Aptotal_Id

           if @nBilltype in (25,24)
           begin
                select @dDiscounttotal=-@dDiscounttotal
       					select @dTaxmoney=-@dTaxmoney
       					select @dArApTotal=-@dArApTotal
           end

        /*借应收账款*/
          if @dArApTotal<>0
          begin
            insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
            values (@nbillid,@tempA_id,@nC_id,@dArApTotal,@jf, @nY_ID)
            if @@rowcount=0 goto error
          end

        /*借银行存款增加*/

          if @dSsMoney<>0  and @nA_id>0
          begin
            insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
            values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf, @nY_ID)
            if @@rowcount=0 goto error
          end else
          begin
            if @nbilltype in (16,17) and exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
            begin
             insert into accountdetailtmp 
              ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
             select 
             @nBillId,abs(P_id),@nC_id,(Case abs(P_id) when @PreAr_ID then -total else total end) as total,0,@nY_ID from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
           if @@rowcount=0 goto error
            end else if exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
          begin
           insert into accountdetailtmp 
            ([billid],[a_id],[c_id],jdmoney,jdflag,Y_ID)   
           select 
           @nBillId,abs(P_id),@nC_id,total,1, @nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
           if @@rowcount=0 goto error
          end
           end

          if @nbilltype in (24,25)
          begin

            /*插入退补差价*/
            if @dDiscounttotal<>0
            begin
              insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],Y_ID)
              values (@nbillid,@DiffPrice_id,@nC_id,@dDiscounttotal,@jf, @nY_ID)
              if @@rowcount=0 goto error
            end

            /*借应交增值税金进项税*/
            if @dTaxMoney<>0
            begin
              insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],Y_ID)
              values (@nbillid,@TaxBuy_Id,@nC_id,-@dTaxMoney,@jf,@nY_ID)
              if @@rowcount=0 goto error
            end
          end
          if @nbilltype in (16,17)
          begin
            /*贷应交增值税金销项税*/
            if @dTaxMoney<>0
            begin
              insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],Y_ID )
              values (@nbillid,@TaxSale_Id,@nC_id,@dTaxMoney,@df,@nY_ID)
              if @@rowcount=0 goto error
            end

            /*贷销售收入变动*/
      			if @dDiscounttotal<>0
      			begin
              insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
              values (@nbillid,@SaleIncome_Id,@nC_id,@dDiscounttotal,@df,@nY_ID)
              if @@rowcount=0 goto error
      			end
          end

    return 0
  end
/*----------------------------退补单处理结束--------------------------*/


  /*----------------------------借出单-----------------------------*/
    if @nBilltype=@vtLend
  begin
    /*贷库存商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
    /*借出商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Lendout_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------借出单-----------------------------*/



  /*----------------------------借出还回单-----------------------------*/
    if @nBilltype=@vtLendBack
  begin
    /*借库存商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
    /*贷借出商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Lendout_Id,@nC_id,-@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------借出还回单-----------------------------*/


  /*----------------------------借出转销售单-----------------------------*/
    if @nBilltype=@vtLendSale    /*= 32;                   //  借出转销售单*/
  begin

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=2
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype=2

    if @nBilltype<>@vtRetail
    begin
      /*借应收账款*/
      if @dArApTotal<>0
      begin
        insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
        values (@nbillid,@Artotal_Id,@nC_id,@dArApTotal,@jf,@nY_ID)
        if @@rowcount=0 goto error
      end
    end
    /*借银行存款增加*/
    if @dSsMoney<>0  and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,@dSsMoney,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end

  if exists(select * from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,(Case abs(P_id) when @PreAr_ID then -total else total end) as Total,@nY_ID  from salemanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end
    /*贷销售收入增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@SaleIncome_Id,@nC_id,@dDiscountTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    /*贷应交增值税金销项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxSale_Id,@nC_id,@dTaxMoney,@df,@nY_ID)
      if @@rowcount=0 goto error
    end

    /*借销售成本增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@SaleCost_Id,@nC_id,-@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error
    /*贷借出商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Lendout_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------借出转销售单-----------------------------*/


  /*----------------------------借进单-----------------------------*/
    if @nBilltype=@vtBorrow
  begin
    /*借库存商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error
    /*借进商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Brrowin_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------借进单-----------------------------*/


  /*----------------------------借进还回单-----------------------------*/
    if @nBilltype=@vtBorrowBack
  begin
    /*贷库存商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    /*借借进商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Brrowin_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------借进还回单-----------------------------*/

  /*----------------------------借进转进货单-----------------------------*/
    if @nBilltype=@vtBorrowBuy    /*  借进转进货单*/
  begin

    select @dDiscountTotal=abs(isnull(sum(total),0)),@dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=2
    select @dTaxMoney=isnull(abs(sum(taxtotal))-abs(sum(total)),0) from productdetailtmp where Billid=@nBillId and storetype=2
    select @dChange=@dDiscountTotal-abs(@dCostTotal)
     /*贷应付账款*/
        if @dArApTotal<>0
    begin
      insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Aptotal_Id,@nC_id,@dArApTotal,@df,@nY_ID)
      if @@rowcount=0 goto error
    end
    /*贷银行存款减少*/
    if @dSsMoney<>0  and @nA_id>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@nA_Id,@nC_id,-@dSsMoney,@df, @nY_ID)
      if @@rowcount=0 goto error
    end
  if exists(select * from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999)
  begin
   insert into accountdetailtmp 
    ([billid],[a_id],[c_id],jdmoney,Y_ID)   
   select 
   @nBillId,abs(P_id),@nC_id,-total, @nY_ID from buymanagebill where bill_id=@nbillid and p_id<0 and p_id>-9999 order by smb_id
   if @@rowcount=0 goto error
  end

    /*贷借进商品减少*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Brrowin_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error

    /*贷借进转进货差价*/
    if @dChange<>0
    begin
            insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
            values (@nbillid,@JzjhCj_Id,@nC_id,-@dChange,@df, @nY_ID)
            if @@rowcount=0 goto error
    end

    /*借应交增值税金进项税*/
    if @dTaxMoney<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@TaxBuy_Id,@nC_id,-@dTaxMoney,@jf, @nY_ID)
      if @@rowcount=0 goto error
    end

    return 0
  end
  /*----------------------------借进转进货单-----------------------------*/

  /*----------------------------获赠单-----------------------------*/
    if @nBilltype=@vtGain
  begin
    vtGain:
    /*借库存商品增加*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@jf, @nY_ID)
    if @@rowcount=0 goto error
    /*商品获赠收入*/
    insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@GiftIncome_Id,@nC_id,@dCostTotal,@df, @nY_ID)
    if @@rowcount=0 goto error
    return 0
  end
  /*----------------------------获赠单-----------------------------*/


  /*----------------------------赠出单-----------------------------*/
  if @nBilltype=@vtGive
  begin

    vtGive:
    /*贷库存商品减少*/
    if @dCostTotal<>0
    begin
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@Products_Id,@nC_id,@dCostTotal,@df, @nY_ID)
      if @@rowcount=0 goto error
      /*商品赠出*/
      insert into [accountdetailtmp] ( [billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values (@nbillid,@GiftOut_Id,@nC_id,-@dCostTotal,@jf,@nY_ID)
      if @@rowcount=0 goto error
    end
    return 0
  end
  /*----------------------------赠出单-----------------------------*/


/*------------------------------处理储值单--------------------------*/
  if @nBillType in (@vtStoreMoney)
  begin
    declare @StoreMoney_ID int
    declare @StoreMoneyA NUMERIC(25,8)   /*用来判断是否升级的金额*/
    declare @UpStoragMoney NUMERIC(25,8)  /*设置的升级金额*/
    declare @isStoragAutoup int   /*自动储值升级*/
    declare @isStoragUp int     /*储值升级*/
    declare @lStoragUpCT_id int     /*储值升级类型*/
    declare @CardName varchar(100)  /*原卡的名称*/
    declare @NewCardName varchar(100)  /*升级后的卡的名称*/
    set @StoreMoneyA=0.0 
    set @UpStoragMoney=0.0 
    set @isStoragAutoup=0 
    set @isStoragUp=0
    set @lStoragUpCT_id = 0
            /*@StoreProffer_ID int*/
    select @StoreMoney_ID = account_id from account where class_id =  '000002000006'/* 储值帐款classid*/
    /*select @StoreProffer_ID = account_id from account where class_id =  '000004000003000007'-- 储值赠送classid*/
  
    declare @StoreMoney NUMERIC(25,8)
    set @StoreMoney=0.0 
    declare crMoneyManager cursor for
    SELECT a.a_id, a.c_id, a.jftotal,a.dftotal,b.direction
    FROM financebill a,account b where a.bill_id=@nbillid and a.a_id=b.account_id
    open crMoneyManager
    fetch next from crMoneyManager 
    into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction
    while @@fetch_status=0  /*select * from financebill*/
    begin
      set @StoreMoney = @StoreMoney + @dJfTotal
      insert into accountdetailtmp
       ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
      values
      (@nBillId,@nA_id,@nC_id,@dJfTotal,@direction, @nY_ID)
      if @@rowcount=0 goto errormoney
      fetch next from crMoneyManager
      into @nA_id,@nC_id,@dJfTotal,@dDfTotal,@direction    
    end  
    close crMoneyManager
    deallocate crMoneyManager
    /*储值帐款*/
    insert into accountdetailtmp
     ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values
    (@nBillId,@StoreMoney_ID,@nC_id,@StoreMoney,@direction, @nY_ID)    
    if @@rowcount=0 goto error
    /*修改会员卡金额*/
    declare @RemainderMoney NUMERIC(25,8),
            @ArApTotal NUMERIC(25,8)  /*标识是否已计算过储值*/
    set @VIPCardID=0  /*select * from VIPCard*/
    set @RemainderMoney=0.0
    select @VIPCardID=VIPCardID,@ArApTotal=ArApTotal from billidx where billid=@nBillId
    select @RemainderMoney=RemainderMoney from VIPCard where VIPCardID=@VIPCardID

    if @ArApTotal=0 
    begin
	if (@RemainderMoney+@StoreMoney) < 0
	begin
	      raiserror('储值卡上金额不能为负!',16,1)
	      return -1
	end
	update VIPCard set RemainderMoney=RemainderMoney+@StoreMoney where VIPCardID=@VIPCardID
	if @@rowcount=0 goto error
	/*更改储值总额 */
	update VIPCard set SaveMoney=SaveMoney+@StoreMoney where VIPCardID=@VIPCardID
	if @@rowcount=0 goto error
	update billidx set ArApTotal=1 where billid=@nBillId        
	if @@rowcount=0 goto error
	/*一次性储值升级*/
	select @UpStoragMoney = UpStorag, @isStoragAutoup = isStoragAutoup ,@isStoragUp = isStoragUp, @lStoragUpCT_id = lStoragUpCT_id
				 from VipCardTypeExtend where bill_id = (select CT_ID from VIPCard where VIPCardID=@VIPCardID)
	if (@isStoragUp = 1) and (@isStoragAutoup = 1) and (@UpStoragMoney > 0)
	begin	
		select @StoreMoneyA= sum(ysmoney) from billidx where billtype = @vtStoreMoney and VIPCardID = @VIPCardID  /*计算储值单取会员卡保存的储值的总金额*/
		/*select @StoreMoneyA = SaveMoney from VIPCard where VIPCardID = @VIPCardID  --直接取的会员卡保存的储值的总金额*/
		if @StoreMoneyA >= @UpStoragMoney
		begin
		    select @CardName = t.name from VIPCard v,VipCardType t where v.CT_ID = t.ct_id and  VIPCardID=@VIPCardID
			update VIPCard set CT_ID = @lStoragUpCT_id where VIPCardID=@VIPCardID
			/*写入日志*/
			insert into VIPLog(eid,Computer,ActName,ActDate,VIPCardID,NewVIPCardID,NowIntegral,NowMoney,ModIntegral,ModMoney,Comment)
			select 1,'system','自动储值升级',GETDATE(),VIPCardID,0,0.0,0.0,v.RemainderMoney,v.SaveMoney,@CardName + '→' +t.Name
				FROM VIPCard v,VipCardType t  WHERE v.CT_ID = t.ct_id and VIPCardID = @VIPCardID  
		end
	end
end
end

/*------------------------------储值单结束-------------------------*/

/*------------------------------积分兑换单----------------------------*/
  if @nBillType in (@vtVipIntegralExChange)
  begin
  /*借积分兑换增加，000004000002000004*/
    declare @integralEx_id int
    select @integralEx_id=account_id from account where class_id='000004000002000004'
    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@integralEx_id,@nC_id,-@dCostTotal,@jf,@nY_ID)
    if @@rowcount=0 goto error
  /*贷库存商品减少*/
    insert into [accountdetailtmp] ([billid],[a_id],[c_id],[jdmoney],[jdflag],[Y_ID])
    values (@nbillid,@Products_Id, @nC_id,@dCostTotal,@df,@nY_ID)
    if @@rowcount=0 goto error
/* select * from VIPCard*/
  /*修改会员卡上积分余额*/
    declare @ExIntegral NUMERIC(25,8),@Integral NUMERIC(25,8),@DoIntegral NUMERIC(25,8)  /*标识是否已计算过积分*/
    select @ExIntegral=ysMoney,@DoIntegral=isnull(cast(ArApTotal as int),0) from billidx where billid=@nbillid    
    select @Integral=Integral from VIPCard where VIPCardID=@Vipcardid
    if @DoIntegral=0 
    begin
    	if @Integral<@ExIntegral
    	begin
      		raiserror('会员卡上积分余额小于兑换积分，不能兑换！',16,1)
      		return -1
    	end
	update VIPCard set Integral=(@Integral-@ExIntegral),SwapIntegral=SwapIntegral+@ExIntegral where VIPCardID=@Vipcardid
	if @@rowcount=0 goto error
	update billidx set ArApTotal=1 where billid=@nBillId        
	if @@rowcount=0 goto error
    end
    return 0
  end
/*-----------------------------积分兑换单结束--------------------------*/

  SpecialProcess:
  /*------------------特殊处理-------------------------------------*/
  if @nBilltype in (@vtSale,@vtRetail,@vtSaleBack,@vtRetailBack,@vtBuy,@vtBuyBack,@vtInlib,@vtOutlib,@vtTranOut,@vtTranOutback,@vtTranin,@vtTraninback,@vtSend,@vtReceive, @vtYSelfReceive, @vtYSelfReceiveBack)
  begin
	  select @dCostTotal=isnull(sum(costtotal),0) from productdetailtmp where billid=@nbillid and storetype=0 and aoid=7	/*销售赠送*/
    if @dCosttotal<>0
    begin
      if @nBilltype in (@vtSale,@vtRetail,@vtSaleBack,@vtRetailBack,@vtOutLib,@vtTranOut,@vtTranOutBack,@vtSend) goto vtGive
      if @nBilltype in (@vtBuy,@vtBuyBack,@vtInLib,@vtTranin,@vtTraninBack,@vtReceive) goto vtGain
    end
    return 0
  end
  /*------------------特殊处理-------------------------------------*/


return 0

error:
  return -1

errormoney:
    close crMoneyManager
    deallocate crMoneyManager
    return -1
GO
