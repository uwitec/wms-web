create procedure ts_e_BatchNoIsSlipt
  @billid integer
as
declare  @bsyqty  NUMERIC(25,8),
		 @ssyqty  NUMERIC(25,8),
		 @SHw_id  int,
		 @BHw_id  int,
		 @bigId  int,
		 @smaId  int,
		 @bpanid int,
		 @spanid int,
		 @newqty NUMERIC(25,8),
		 @nNewBillId int,
		 @dQuantity NUMERIC(25,8)
declare @billnumber varchar(30),@note varchar(300)
create table #NewBatchNOTableEnd
(
   RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
   PdPlan_id INT NULL, /*盘点计划明细ID */
   syqty NUMERIC(25,8) NULL, /*损溢数量*/
)
create table #NewBatchNOTableBig/*大于0的数量*/
(
   RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
   PdPlan_id INT NULL, /*盘点计划明细ID */
   syqty NUMERIC(25,8) NULL, /*损溢数量*/
   Hw_id INT NULL, /*盘点计划明细ID */
)
create table #NewBatchNOTableSmaill/*小于0的数量*/
(
   RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
   PdPlan_id INT NULL, /*盘点计划明细ID */
   syqty NUMERIC(25,8) NULL, /*损溢数量*/
   Hw_id INT NULL, /*盘点计划明细ID */
)
set @note=''
begin
      /*找出需要生成批次调整单的数据*/
      if exists (
             select  p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
									from pdplan where pdidx=@billid and WMS_PdStatus=2   
	        group by p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
	         having SUM(WMS_CheckPdQty - quantity) = 0 
	     )
	  begin
		 select  p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
								    into #temp1  
									from pdplan where pdidx=@billid and WMS_PdStatus=2   
	     group by p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
	     having SUM(WMS_CheckPdQty - quantity) = 0 
	     
	     /*将小于0的添加到对应临时表*/
	     insert into #NewBatchNOTableSmaill(PdPlan_id,syqty,Hw_id)
	     select a.PdPlan_id,abs(a.WMS_CheckPdQty-a.quantity) as syqty,a.location_id  from pdplan a inner join #temp1 b 
					  on  a.p_id=b.p_id and  a.s_id=b.s_id and a.batchno=b.batchno and a.supplier_id=b.supplier_id
			          and a.validdate=b.validdate and a.makedate=b.makedate
			          and a.commissionflag=b.commissionflag and a.costprice=b.costprice
			          and a.factoryid=b.factoryid and a.Y_ID=b.Y_ID and a.WMS_CheckPdQty-a.quantity<0 and a.pdidx=@billid and a.WMS_PdStatus=2
			          order by abs(a.WMS_CheckPdQty-a.quantity) desc 
	     /*将大于0的添加到对应的临时表*/
	     insert into #NewBatchNOTableBig(PdPlan_id,syqty,Hw_id)
	     select a.PdPlan_id,abs(a.WMS_CheckPdQty-a.quantity) as syqty,a.location_id  from pdplan a inner join #temp1 b 
							  on  a.p_id=b.p_id and  a.s_id=b.s_id and a.batchno=b.batchno and a.supplier_id=b.supplier_id
							  and a.validdate=b.validdate and a.makedate=b.makedate
							  and a.commissionflag=b.commissionflag and a.costprice=b.costprice
							  and a.factoryid=b.factoryid and a.Y_ID=b.Y_ID and a.WMS_CheckPdQty-a.quantity>0 and a.pdidx=@billid and a.WMS_PdStatus=2
							  order by abs(a.WMS_CheckPdQty-a.quantity) desc
		 /*清楚临时表*/
		 truncate table #NewBatchNOTableEnd
		  /*父类游标 先滚动负数*/
		 DECLARE MyCursor CURSOR   FOR  select RecNum,PdPlan_id,syqty,Hw_id from #NewBatchNOTableSmaill
		 OPEN MyCursor
		 FETCH NEXT FROM  MyCursor INTO @smaId,@spanid,@ssyqty,@SHw_id
		 WHILE @@FETCH_STATUS =0    
		 BEGIN     
		             DECLARE SMMyCursor CURSOR   FOR  select RecNum,PdPlan_id,syqty,Hw_id from #NewBatchNOTableBig
					 OPEN SMMyCursor
					 FETCH NEXT FROM  SMMyCursor INTO @bigId,@bpanid,@bsyqty,@BHw_id
					 WHILE @@FETCH_STATUS =0    
					 BEGIN     
					       if @ssyqty>@bsyqty
					       begin
					         if @bsyqty<>0 
					         begin
								  set @newqty=@ssyqty-@bsyqty
								  insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@spanid,-(@ssyqty-@newqty))
								  insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@bpanid,(@ssyqty-@newqty))
								  update #NewBatchNOTableSmaill set syqty=-@newqty where RecNum=@smaId
								  update #NewBatchNOTableBig    set syqty=@bsyqty-(@ssyqty-@newqty)  where RecNum=@bigid	
								  set @bsyqty=@bsyqty-(@ssyqty-@newqty)	
								  set @ssyqty=@newqty
							  end
							  FETCH NEXT FROM  SMMyCursor INTO @bigId,@bpanid,@bsyqty,@BHw_id
							  continue
					       end
					       if @ssyqty<@bsyqty 
					       begin
					         if @ssyqty<>0
					         begin
								  set @newqty=abs(@ssyqty-@bsyqty)
								  insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@spanid,-@newqty)
								  insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@bpanid,@newqty)
								  update #NewBatchNOTableSmaill set syqty=@ssyqty-@newqty where RecNum=@smaId
								  update #NewBatchNOTableBig    set syqty=@newqty  where RecNum=@bigid
								  if @ssyqty-@newqty=0 
								  begin
									  break
								  end
							  end
					       end
					       if @ssyqty=@bsyqty 
					       begin
					         if @bsyqty<>0
					         begin
					           insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@spanid,-@bsyqty)
							   insert into #NewBatchNOTableEnd(PdPlan_id,syqty) values(@bpanid,@bsyqty)
							   update #NewBatchNOTableSmaill set syqty=0 where RecNum=@smaId
							   update #NewBatchNOTableBig    set syqty=0  where RecNum=@bigid
							   break
							 end
							 else
							 begin 
							  break
							 end
					       end
		              FETCH NEXT FROM  SMMyCursor INTO @bigId,@bpanid,@bsyqty,@BHw_id
					 END    
					 CLOSE SMMyCursor
					 DEALLOCATE SMMyCursor
			        
			         
		 FETCH NEXT FROM  MyCursor INTO @smaId,@spanid,@ssyqty,@SHw_id
		 END    
		 CLOSE MyCursor
	     DEALLOCATE MyCursor
	      /*添加批次调整单主表*/
	     if exists (select 1 from #NewBatchNOTableEnd)
	     begin
			 insert billdraftidx 
			 (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,GatheringMan,ZBAuditMan,ZBAuditDate)
			 select  CONVERT(varchar(100), GETDATE(), 23),'',51,0,0,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',inputman,0,'1900-01-01'
			 from pdplanidx where pdidx=@billid  
			 select @nNewBillId=@@identity 
			 INSERT INTO storemanageBilldrf
			 (
					 bill_id  ,p_id  ,batchno  ,quantity  ,costprice  ,price ,totalmoney  ,retailprice  ,retailmoney  ,
					 makedate ,validdate ,price_id	,ss_id	,sd_id	,location_id  ,supplier_id  ,commissionflag  ,comment  ,
					 unitid	,location_id2, qualitystatus,iotag, total, invoiceTotal , OrgBillID,Aoid,
					 SendQTY,SendCostTotal,RowE_id,RowGUID, Y_ID, InStoreTime, scomment, batchprice, BatchBarCode,
					 factoryid,costtaxprice,costtaxrate,costtaxtotal
			 )
			 select  @nNewBillId,b.p_id,b.batchno,abs(syqty),costprice,costprice,0,c.retailprice,quantity*c.retailprice,
					 makedate, validdate, 2,        s_id    ,s_id   ,location_id  ,supplier_id , commissionflag, ''  ,
					 p.unit1_id, 0 ,'合格' ,case when  a.syqty<0 then 0 when a.syqty>0  then  1 end,0,0,0,0,
					 quantity,quantity*costprice,d.inputman,RowGuid,b.Y_ID,instoretime,scomment,batchprice,BatchBarCode,
					 b.factoryid,costtaxprice,costtaxrate,costtaxtotal
			 from #NewBatchNOTableEnd a left join pdplan b on a.PdPlan_id=b.PdPlan_id
										left join  (select retailprice,p_id from price where unittype=1) c on b.p_id=c.p_id
										left join  products p on b.p_id=product_id 
										left join  pdplanidx d on b.pdidx=d.pdidx
		   set @billnumber='KC'+right(cast(100000000+@nNewBillId as varchar),8)
		   set @note='从PDA盘点:【'+@billnumber+'】生成的库存批次调整单'
		   select @dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId   
		   update billdraftidx set note=@note,billnumber=@billnumber,quantity=@dQuantity where billid=@nNewBillId         
		   set @nNewBillId=0
	   end
	   drop table #temp1
    end
end
GO
