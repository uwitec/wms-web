create procedure [dbo].[ts_e_StoreWMSZCQInsBaseInfo]
 @S_id  integer=0,/*仓库ID*/
 @Code varchar(100)='',/*暂存区编号*/
 @Name varchar(100)='',/*暂存区名称*/
 @PinYin     varchar(100)='',/*拼音码*/
 @Billtype   integer=0,/*业务类型*/
 @CyFs integer=0,/*承运方式*/
 @YXjType integer=0,/*优先级类型*/
 @LockStatus  integer=0,/*解锁状态*/
 @Deleted   integer=0,/*停用状态*/
 @RoadID  integer=0,/*配送线路*/
 @InsOrUpdate   varchar(50) ,/*判断是新增还是修改*/
 @id    integer=0,/*暂存区ID（用于修改）*/
 @HoldCB integer=0,/*是否虚拟暂存区0 带表否，1带表是*/
 @MaxBillNum integer=0,/*最大单据数*/
 @nRet  int OUTPUT,/*新增成功后返回自增列ID*/
 @NewCode     varchar(2000) OUTPUT/*返回新的暂存区编号（连续添加生成新的编号）*/
as
declare @Newcodestr varchar(2000)
declare @i  integer
if @Deleted=1 set @Deleted=2
begin
 if @InsOrUpdate='Ins'
 begin
   insert into  WMSHold(s_id,code,name,pinyin, billtype,cyfs,priority,lockstatus,deleted,roadid,ifHold,MaxBillNum)
   values(@s_id,@Code,@Name,@PinYin,@Billtype,@CyFs,@YXjType,@LockStatus,@Deleted,@RoadID,@HoldCB,@MaxBillNum)
   set  @nRet= @@IDENTITY
   select @Newcodestr=dbo.GetWMSHWCode(1,@Code) 
   set @i=0
   while @i=0 
   begin
      if exists (select 1 from WMSHold  where code =@Newcodestr and deleted=0)
      begin
        select @Newcodestr=dbo.GetWMSHWCode(1,@Newcodestr)  
      end
      else
      begin
        set @i=1
      end
   end
   set @NewCode=@Newcodestr
 end
 else
 begin
   update WMSHold  set s_id=@s_id,Code=@Code,name=@Name,pinyin=@PinYin,
          billtype=@Billtype,cyfs=@CyFs,priority=@YXjType,lockstatus=@LockStatus,
   deleted=@Deleted,roadid=@RoadID,ifHold=@HoldCB,MaxBillNum=@MaxBillNum WHERE id=@id
   IF @@ERROR = 0 
   BEGIN
       set @nRet=1
   END
 end
end
GO
