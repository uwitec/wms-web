
CREATE FUNCTION FGetPY(@STR VARCHAR(500)='')
RETURNS VARCHAR(500)
AS
BEGIN
    DECLARE @STRLEN INT,@RETURN VARCHAR(500),@II INT
    DECLARE @N INT,@C CHAR(1),@CHN NCHAR(1)

    SELECT @STRLEN=LEN(@STR),@RETURN='',@II=0
    SET @II=0
    WHILE @II<@STRLEN
    BEGIN
        SELECT @II=@II+1,@N=63,@CHN=SUBSTRING(@STR,@II,1)
        IF @CHN>'Z'
        SELECT @N = @N +1
                    ,@C = CASE CHN WHEN @CHN THEN CHAR(@N) ELSE @C END
            FROM(
                SELECT TOP 27 * FROM (
                    SELECT CHN = '吖'
                    UNION ALL SELECT '八'
                    UNION ALL SELECT '嚓'
                    UNION ALL SELECT '咑'
                    UNION ALL SELECT '妸'
                    UNION ALL SELECT '发'
                    UNION ALL SELECT '旮'
                    UNION ALL SELECT '铪'
                    UNION ALL SELECT '丌'        /*BECAUSE HAVE NO 'I'*/
                    UNION ALL SELECT '丌'
                    UNION ALL SELECT '咔'
                    UNION ALL SELECT '垃'
                    UNION ALL SELECT '嘸'
                    UNION ALL SELECT '拏'
                    UNION ALL SELECT '噢'
                    UNION ALL SELECT '妑'
                    UNION ALL SELECT '七'
                    UNION ALL SELECT '呥'
                    UNION ALL SELECT '仨'
                    UNION ALL SELECT '他'
                    UNION ALL SELECT '屲'        /*NO 'U'*/
                    UNION ALL SELECT '屲'        /*NO 'V'*/
                    UNION ALL SELECT '屲'
                    UNION ALL SELECT '夕'
                    UNION ALL SELECT '丫'
                    UNION ALL SELECT '帀'
                    UNION ALL SELECT @CHN) AS A
                ORDER BY CHN COLLATE CHINESE_PRC_CI_AS 
            ) AS B
        ELSE SET @C=@CHN
        SET @RETURN=@RETURN+@C
    END
    RETURN(@RETURN)
END
GO
