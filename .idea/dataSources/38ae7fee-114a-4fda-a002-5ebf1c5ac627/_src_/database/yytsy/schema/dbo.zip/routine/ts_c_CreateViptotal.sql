




/*@bType=0 上传所有*/
/*@bType=1 只上传未传的数据*/
CREATE proc ts_c_CreateViptotal
(
	@BeginDate 	datetime,
	@EndDate 		datetime,
	@bType			int
)
/*with encryption*/
as
set nocount on
/*
begin tran
	truncate table cardtotal
	if @bType=0
	begin
    insert into cardtotal 
		select c.cardid,isnull(sum(c.saletotal),0)-isnull(sum(c.salebacktotal),0) as saletotal from 
		(
				select b.cardid,sum(a.ssmoney) as saletotal,0 as salebacktotal from retailbillidx a,membercard b
				where a.billdate between @begindate and dateadd(day,1,@enddate) and a.billtype=12 and a.billstates='0' and a.order_id<>0
				and a.order_id=b.cardid
				group by cardid
				union
				select b.cardid,0 as saletotal,sum(a.ssmoney) as salebacktotal from retailbillidx a,membercard b
				where a.billdate between @begindate and dateadd(day,1,@enddate) and a.billtype=13 and a.billstates='0' and a.order_id<>0
				and a.order_id=b.cardid
				group by cardid
		) as c
		group by cardid
  	update retailbillidx set transcount = transcount+1 where billdate between @begindate and dateadd(day,1,@enddate)
	end else
	begin
    insert into cardtotal 
		select c.cardid,isnull(sum(c.saletotal),0)-isnull(sum(c.salebacktotal),0) as saletotal from 
		(
				select b.cardid,sum(a.ssmoney) as saletotal,0 as salebacktotal from retailbillidx a,membercard b
				where a.billdate between @begindate and dateadd(day,1,@enddate) and a.billtype=12 and a.billstates='0' and a.order_id<>0 and a.transcount=0
				and a.order_id=b.cardid
				group by cardid
				union
				select b.cardid,0 as saletotal,sum(a.ssmoney) as salebacktotal from retailbillidx a,membercard b
				where a.billdate between @begindate and dateadd(day,1,@enddate) and a.billtype=13 and a.billstates='0' and a.order_id<>0 and a.transcount=0
				and a.order_id=b.cardid
				group by cardid
		) as c
		group by cardid
  	update retailbillidx set transcount = transcount+1 where billdate between @begindate and dateadd(day,1,@enddate) and transcount = 0
	end
	update membercard set buytotalperday=0
commit tran
*/

truncate table VIPLogdts
insert VIPLogdts ([id],eid,Computer,ActName,ActDate,VIPCardID,NowIntegral,ModIntegral,NowMoney,ModMoney,NewVIPCardID,Comment)
select [id],eid,Computer,ActName,ActDate,VIPCardID,NowIntegral,ModIntegral,NowMoney,ModMoney,NewVIPCardID,Comment
from VIPLog
where ActDate between @begindate and @enddate
GO
