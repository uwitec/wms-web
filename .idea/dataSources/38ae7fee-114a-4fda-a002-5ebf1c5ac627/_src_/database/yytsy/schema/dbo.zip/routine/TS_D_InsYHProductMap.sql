
create procedure TS_D_InsYHProductMap
@p_id INT,
@aka063 VARCHAR(3)
AS 
  SET NOCOUNT ON

  DELETE FROM YHProductMap WHERE p_id=@p_id
  INSERT INTO YHProductMap
	(p_id,YHP_id,aka063)
  SELECT @p_id,0,@aka063
  /*同步更新到注册商标字段*/
  UPDATE products SET 
  trademark=CASE WHEN @aka063='14' THEN '西药'
                 WHEN @aka063='15' THEN '中成药'
                 WHEN @aka063='16' THEN '中草药'  
                 WHEN @aka063='17' THEN '民族药'
            ELSE '其他'
            END  
  WHERE product_id=@p_id
GO
