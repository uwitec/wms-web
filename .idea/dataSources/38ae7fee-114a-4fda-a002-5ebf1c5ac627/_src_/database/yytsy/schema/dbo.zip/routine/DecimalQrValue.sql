/* =============================================*/
/* Author:	zjl */
/* Create date: 2013-07-05*/
/* Description:	根据出入类型格式化数据格式*/
/*@ALen  参数说明 小数位数长度*/
/*@Avalue:被格式数据 */
/* =============================================*/
CREATE FUNCTION [dbo].[DecimalQrValue]( @ALen INT,@Avalue Float)
RETURNS float AS  
BEGIN 
  declare @Ret  float     
     SET @Ret = 
     case  @alen  
     when 0 then convert(int,@Avalue)
     when 1 then convert(numeric(18,1),@Avalue)
     when 2 then convert(numeric(18,2),@Avalue)
     when 3 then convert(numeric(18,3),@Avalue)
     when 4 then convert(numeric(18,4),@Avalue)
     when 5 then convert(numeric(18,5),@Avalue)
     when 6 then convert(numeric(18,6),@Avalue)
     else  0       
     end       
  return @Ret
END
GO
