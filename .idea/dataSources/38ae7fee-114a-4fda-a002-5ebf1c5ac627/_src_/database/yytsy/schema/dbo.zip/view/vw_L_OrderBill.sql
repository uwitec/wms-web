
CREATE VIEW dbo.vw_L_OrderBill
AS

  SELECT O.* ,
      
  ISNULL(P.class_id,'')Pclass_ID, ISNULL(P.[name],'')Pname,
  ISNULL(SS.Class_id,'')SSclass_ID, ISNULL(SS.[name],'')SSname,
  ISNULL(SD.Class_id,'')SDclass_ID, ISNULL(SD.[name],'')SDname,
  ISNULL(SL.class_id,'')SLClass_ID,ISNULL(SL.[name],'')SLname,
  ISNULL(RE.class_id,'')REClass_ID,ISNULL(RE.[name],'')REname

  FROM  OrderBill O
  


   LEFT OUTER JOIN  products   P  ON O.p_id=P.product_id
   LEFT OUTER JOIN  storages   SS  ON O.ss_id=SS.storage_id
   LEFT OUTER JOIN  storages   SD  ON O.ss_id=SD.storage_id
   LEFT OUTER JOIN  clients    SL ON O.supplier_id=SL.client_id
   LEFT OUTER JOIN  location   L  ON O.location_id=L.loc_id
   LEFT OUTER JOIN  employees  RE ON O.RowE_id=RE.emp_id
GO
