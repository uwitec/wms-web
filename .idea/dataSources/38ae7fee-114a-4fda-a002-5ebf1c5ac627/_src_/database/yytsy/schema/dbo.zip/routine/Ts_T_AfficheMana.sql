
/******************************************
系统公告的增删改查
********************************************/
CREATE PROCEDURE [Ts_T_AfficheMana]
(   
  @AMode      INT,  /*0：新增；1：修改；2：删除; */
  @AID        INT,  /*ID号，@AMode为2,3时生效*/
  @ModifyDate DATETIME,
  @EID        INT,
  @YID        INT,
  @Title      VarChar(1000),
  @Content    VarChar(8000),
  @ContentNew Text
)
AS
  SET NOCOUNT ON
  DECLARE @NEWID INT

  IF @AMode = 0 GOTO InputDate
  IF @AMode = 1 GOTO ModifyData  
  IF @AMode = 2 GOTO DeleteData
  
InputDate:
  INSERT INTO AfficheRec (YID, EID, AffDate, AffTitle, AffContent, AffContentNew, DFlag) VALUES (@YID, @EID, @ModifyDate, @Title, @Content, @ContentNew, 0)  
  GOTO Succee

ModifyData:
  UPDATE AfficheRec SET YID = @YID, EID = @EID, AffDate = @ModifyDate, AffTitle = @Title, AffContent = @Content, AffContentNew = @ContentNew WHERE ID = @AID    
  GOTO Succee

DeleteData:  
   UPDATE AfficheRec SET DFlag = 1 where ID = @AID  
  GOTO Succee

Succee:
  RETURN  0
GO
