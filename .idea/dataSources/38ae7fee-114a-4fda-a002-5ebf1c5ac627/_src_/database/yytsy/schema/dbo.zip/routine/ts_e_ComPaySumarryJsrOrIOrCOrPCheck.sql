/*exec ts_e_ComPaySumarryJsrOrIOrCOrPCheck '2015-07-01','2015-07-23',1,0,0,'01',0,'02',-1,0,-1,2,2,'0,1,2'*/
create procedure ts_e_ComPaySumarryJsrOrIOrCOrPCheck
  @BeginDate DateTime, /*开始时间*/
  @EndDate DateTime, /*结束时间*/
  @GroupType Int = -1, /*汇总条件 -1：无；0：机构Y_ID， 1：业务员E_ID, 2：制单人InPutMan*/
  @ProductChecked Int = 0, /*是否按商品，默认否0*/
    
  @ProductGroupCheckd int=0, /*判断商品类别是否被勾中*/
  @ProductGroupClssid varchar(100),/*-商品类别ClassId*/

  
  @ComPanyGroupCheckd int=0, /*判断机构类别是否被勾中*/
  @ComPanyGroupClssid varchar(100),/*-机构类别ClassId*/
  @ComPanyAndProductsGroupRange  int=-1,/*类别范围 0：大，1中，2小 ，默认无-1*/
  
  @TimeChecked Int = 0, /*是否时间段汇总，默认否0*/
  @TimeRange Int = -1, /*时间段范围，0：日，1：月2：季度，默认无-1*/
  @inputMan  int=0,          /*当前登陆人 */
  @Y_id      int=0,         /*当前机构*/
  @YtypeStr  varchar(100),  /*判断机构类别*/
  /*增加三个汇总条件*/
  @Provider  int = 0, /*供应商，0未选，1已选*/
  @Factory   int = 0, /*生产产家，0未选，1已选*/
  @MakeArea  int = 0  /*产地，0未选，1已选*/
as
Create Table #FinalData 
  (
    RecId                 INT IDENTITY(1,1) NOT NULL,  /*自增列*/
    E_ID                  INT  NULL DEFAULT(0), /*配送单业务员*/
    INPUTMAN              INT NULL DEFAULT(0), /*配送单(制单人)*/
    PtypeGroupName        varchar (100) NULL DEFAULT(''),/*-商品类别组名称*/
    YtypeGroupName        varchar (100) NULL DEFAULT(''),/*-机构类别名称*/
    C_ID                  INT NULL DEFAULT(0), /*配送单目标机构         */
    YtimeType             varchar (100) NULL DEFAULT(''),/*-时间段日名称*/
    P_ID                  INT NULL DEFAULT(0), /*商品ID  */
    /*增加三个汇总条件*/
    supplier_id           int Not Null DEFAULT(0), /*供应商*/
    factoryid             int NOT NULL DEFAULT(0), /*生产产家，0未选，1已选*/
    MakeArea              varchar(1000) NOT NULL DEFAULT(''),  /*产地，0未选，1已选*/
    
    OrderQty              NUMERIC(25,8) NULL DEFAULT(0),  /*订单数量*/
    OrderTotal            NUMERIC(25,8) NULL DEFAULT(0),  /*订单金额*/
    OrderFlishLV          NUMERIC(25,8) NULL DEFAULT(0),  /*订单完成率*/
    
    SendQty               NUMERIC(25,8) DEFAULT(0)     ,  /*配送数量*/
    SendTotal             NUMERIC(25,8) NULL DEFAULT(0),  /*配送金额*/
    SendCostTotal         NUMERIC(25,8) NULL DEFAULT(0),  /*不含税配送成本*/
    BackQty               NUMERIC(25,8) NULL DEFAULT(0),  /*退货数量  */
    BackCostTotal         NUMERIC(25,8) NULL DEFAULT(0),  /*退货成本*/
    BackTotal             NUMERIC(25,8) NULL DEFAULT(0),  /*退货金额*/
    ML                    NUMERIC(25,8) NULL DEFAULT(0),  /*毛利*/
    MLV                   NUMERIC(25,8) NULL DEFAULT(0),  /*毛利率*/
    BackZb                NUMERIC(25,8) NULL DEFAULT(0),    /*退货占比*/
    SalePgQty             NUMERIC(25,8) DEFAULT(0),         /*动销品规数量*/
    BackPgQty             NUMERIC(25,8) DEFAULT(0),          /*退货品规数量*/
    lastsenddate          varchar (100) NULL DEFAULT(''),/*-最近配送日期*/
    SendCiShu             NUMERIC(25,8) DEFAULT(0),          /*配送次数*/
    ArTotal               NUMERIC(25,8) DEFAULT(0),           /*应收金额*/
    OosQty                NUMERIC(25,8) DEFAULT(0),           /*缺货数量*/
    YxyQty                NUMERIC(25,8) DEFAULT(0),           /*有效机构数*/
    StroeQty              NUMERIC(25,8) DEFAULT(0),           /*库存余量*/
    DaySaleQty            NUMERIC(25,8) DEFAULT(0),            /*日均销量*/
    NewPPgQty             NUMERIC(25,8) DEFAULT(0),            /*库存新品品规数*/
    costtaxtotal          NUMERIC(25,8) DEFAULT(0),           /*含税配送成本*/
    TotalMoney            NUMERIC(25,8) DEFAULT(0),             /*不含税配送金额*/
    TaxTotal              NUMERIC(25,8) DEFAULT(0)            /*税额*/
  )
  Create Table #YTypeGroupBigName 
  (
    baseinfo_id INT NULL DEFAULT(0),
    Name        varchar (100) NULL DEFAULT('')
  )
  Create Table #YTypeGroupHitName 
  (
    baseinfo_id INT NULL DEFAULT(0),
    Name        varchar (100) NULL DEFAULT('')
  )
  Create Table #YTypeGroupSmallName 
  (
    baseinfo_id INT NULL DEFAULT(0),
    Name        varchar (100) NULL DEFAULT('')
  )
begin  
      if convert(varchar(100) ,@enddate,23)>convert(varchar(100) ,GETDATE(),23)
      begin
         set @EndDate=GETDATE()  
      end
      /*EXEC语句  */
	  DECLARE @TMPSQL VARCHAR(200)  /*临时使用*/
	  DECLARE @INSSQL VARCHAR(8000) /*组合语句的INSERT部分*/
	  DECLARE @SELSQL VARCHAR(8000) /*组合语句的SELECT部分*/
	  DECLARE @GRPSQL VARCHAR(8000) /*组合语句的GROUP部分*/
	  DECLARE @WhereSQL VARCHAR(8000) /*组合语句的WHERE部分*/
	  DECLARE @EXESQL VARCHAR(8000) /*组合后需执行SQL语句，由前四部分组装而成    */
	  declare @Pinfo_id int 
	  declare @PColName VARCHAR(100)
	  declare @Yinfo_id int 
	  declare @YColName VARCHAR(100)
	  declare @sqlstrPBig VARCHAR(8000)
	  declare @sqlstrPHit VARCHAR(8000)
	  declare @sqlstrPSmall VARCHAR(8000)
	  declare @sqlstrYBig VARCHAR(8000)
	  declare @sqlstrYHitOne VARCHAR(8000)
	  declare @sqlstrYHitTwo VARCHAR(8000)
	  declare @sqlstrYSmall VARCHAR(8000)
	 if @ProductGroupClssid<>''
     begin
      SELECT distinct @Pinfo_id = Category_id FROM customCategory WHERE class_id=@ProductGroupClssid
      set @PColName = dbo.GetColName(@Pinfo_id,'ProductCategory')  
     end
     if @ComPanyGroupClssid<>''
     begin
      SELECT distinct @Yinfo_id = Category_id FROM customCategory WHERE class_id=@ComPanyGroupClssid
      set @YColName = dbo.GetColName(@Yinfo_id,'CompanyCategory')  
     end
     /*------查询商品类别大，中，小类别名称*/
    /*大*/
     set @sqlstrPBig ='
      select  distinct  b.p_id as baseinfo_id,isnull(a.name,'''') as name into ##PTypeGroupBigName from 
					   (
						  select a.id,b.name,a.PCclass_id  from 
						 (
						   select id,class_id as PCclass_id, left(class_id,4) as class_id from  customCategory where Child_Number=0 
						    and  LEFT(class_id,4) in 
						    (
						     select LEFT(class_id,4) from customCategory where LEFT(class_id,2) ='''+@ProductGroupClssid+''' and len(class_id) = 4
						     ) 
						  ) a left join customCategory b on LEFT(a.class_id,4)=b.class_id
					    )  a inner join ProductCategory b on a.PCclass_id=b.'+@PColName+' '
	exec (@sqlstrPBig)
	/*中*/
	set @sqlstrPHit='
	 select distinct b.p_id as baseinfo_id,
	        case isnull(a.zname,'''') when '''' then isnull(a.dname,'''') else  isnull(a.dname,'''')+''->''+isnull(a.zname,'''') end as name 
	        into ##PTypeGroupHitName from 
					   (
					      select distinct a.id,a.name as zname,b.dname as dname,pcclass_id from 
					      (
					        select a.id, b.name,left(a.class_id,4)  as class_id,pcclass_id from 
							 (
							   select id,left(class_id,6) as class_id,class_id as pcclass_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,6) in 
								(
								 select LEFT(class_id,6) from customCategory where LEFT(class_id,2) ='''+@ProductGroupClssid+''' and len(class_id) =6
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,6)=b.class_id
					          
						  ) a
						  left join 
						  ( 
						    select a.id,b.name as dname,a.class_id  from 
							 (
							   select id,left(class_id,4) as class_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,4) in 
								(
								 select LEFT(class_id,4) from customCategory where LEFT(class_id,2) ='''+@ProductGroupClssid+''' and len(class_id) =4
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,4)=b.class_id    
						  ) b on a.class_id=b.class_id
					    )  a inner join ProductCategory b on a.pcclass_id=b.'+@PColName+''
	exec (@sqlstrPHit)
	/*小*/
	set @sqlstrPSmall='
	 select distinct b.p_id as baseinfo_id, case isnull(a.zname,'''') when '''' then isnull(a.xname,'''') else   isnull(a.dname,'''')+''->''+isnull(a.zname,'''')+''->''+isnull(a.xname,'''') end as name
	  into ##PTypeGroupSmallName from 
				         (
				           select a.name as xname,b.name as zname,c.name as dname,a.id,pcclass_id  from 
				           (
				            select id,class_id as pcclass_id, name,left(class_id,6) as class_id  from customCategory where class_id like '''+@ProductGroupClssid+'''+''%'' and Child_Number=0
				           ) a left join 
				           (
				             select id,name,class_id  from customCategory where class_id like '''+@ProductGroupClssid+'''+''%'' and len(class_id) =6
				           ) b  on a.class_id=b.class_id
				           left join 
				           (
				             select id,name,class_id  from customCategory where class_id like '''+@ProductGroupClssid+'''+''%'' and len(class_id) =4
				           ) c  on left(a.class_id,4)=c.class_id
				         ) a left join ProductCategory b on a.pcclass_id=b.'+@PColName+' '
	exec (@sqlstrPSmall)	
    /*-查询机构类别大，中， 小类别名称*/
    /*大*/
    if @ComPanyAndProductsGroupRange=0
    begin
		set @sqlstrYBig='
		 insert into  #YTypeGroupBigName
		 select  distinct b.y_id as baseinfo_id,isnull(a.name,'''') as name from 
						   (
							  select a.id,b.name,ycclass_id  from 
							 (
							   select id,left(class_id,4) as class_id,class_id as ycclass_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,4) in 
								(
								 select LEFT(class_id,4) from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+''' and len(class_id) = 4
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,4)=b.class_id
							)  a inner join CompanyCategory b on a.ycclass_id=b.'+@YColName+' '
		exec (@sqlstrYBig)	
    end
   /*中*/
   if @ComPanyAndProductsGroupRange=1
   begin
    if not exists 
      (
      select a.id,a.name as zname from 
					     (
					       select a.id,b.name,left(a.class_id,4)  as class_id from 
							 (
							   select id,left(class_id,6) as class_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,6) in 
								(
								 select LEFT(class_id,6) from customCategory where LEFT(class_id,2) =@ComPanyGroupClssid and len(class_id) =6
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,6)=b.class_id
						  ) a
      
      )
     begin
        set  @sqlstrYHitOne ='
        insert into #YTypeGroupHitName
	    select  distinct b.y_id as baseinfo_id,case isnull(a.zname,'''') when '''' then isnull(a.dname,'''') else  isnull(a.dname,'''')+''->''+isnull(a.zname,'''') end as name  from 
					   (
					     select a.id,b.name as zname,a.dname as dname,ycclass_id from 
					     (
					     
					       select a.id,b.name as dname,a.class_id,ycclass_id  from 
							 (
							   select id,left(class_id,4) as class_id,class_id as ycclass_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,4) in 
								(
								 select LEFT(class_id,4) from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+''' and len(class_id) =4
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,4)=b.class_id     
					      
						  ) a
						  left join 
						  (
						     select a.id,b.name,left(a.class_id,4)  as class_id from 
							 (
							   select id,left(class_id,6) as class_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,6) in 
								(
								 select LEFT(class_id,6) from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+''' and len(class_id) =6
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,6)=b.class_id
						  ) b on a.class_id=b.class_id
					    )  a inner join CompanyCategory b on a.ycclass_id=b.'+@YColName+''
          exec (@sqlstrYHitOne)					  
    end
    else
    begin
       set  @sqlstrYHitTwo='
          insert into #YTypeGroupHitName
	      select  distinct b.y_id as baseinfo_id,case isnull(a.zname,'''') when '''' then isnull(a.dname,'''') else  isnull(a.dname,'''')+''->''+isnull(a.zname,'''') end as name  from 
					   (
					     select a.id,a.name as zname,b.dname as dname,YCclass_id from 
					     (
					       select a.id,b.name,left(a.class_id,4)  as class_id,YCclass_id from 
							 (
							   select id,left(class_id,6) as class_id,class_id as YCclass_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,6) in 
								(
								 select LEFT(class_id,6) from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+''' and len(class_id) =6
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,6)=b.class_id
						  ) a
						  right join 
						  (
						    select a.id,b.name as dname,a.class_id  from 
							 (
							   select id,left(class_id,4) as class_id from  customCategory where Child_Number=0 
								and  LEFT(class_id,4) in 
								(
								 select LEFT(class_id,4) from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+''' and len(class_id) =4
								 ) 
							  ) a left join customCategory b on LEFT(a.class_id,4)=b.class_id       
						  ) b on a.class_id=b.class_id
					    )  a inner join CompanyCategory b on a.YCclass_id=b.'+@YColName+''
       exec (@sqlstrYHitTwo)		
     end
    end
    /*小*/
    if @ComPanyAndProductsGroupRange=2
    begin
     set @sqlstrYSmall='
      insert  into #YTypeGroupSmallName
	  select distinct b.y_id as baseinfo_id,case isnull(a.zname,'''') when '''' then isnull(a.xname,'''') else   isnull(a.dname,'''')+''->''+isnull(a.zname,'''')+''->''+isnull(a.xname,'''') end as name
	            from 
				         (
				           select a.name as xname,b.name as zname,c.name as dname,a.id,ycclass_id  from 
				           (
				            select id,name,left(class_id,6) as class_id,class_id as ycclass_id  from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+'''  and Child_Number=0
				           ) a left join 
				           (
				             select id,name,class_id  from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+'''  and len(class_id) =6
				           ) b  on a.class_id=b.class_id
				           left join 
				           (
				             select id,name,class_id  from customCategory where LEFT(class_id,2) ='''+@ComPanyGroupClssid+'''  and len(class_id) =4
				           ) c  on left(a.class_id,4)=c.class_id
				         ) a left join CompanyCategory b on a.ycclass_id=b.'+@YColName+' '
	  exec (@sqlstrYSmall)
    end
    declare @PgSumQty NUMERIC(25,8) /*当前库存品规数-->有效品规*/
	declare @ProductSumQty  NUMERIC(25,8) /*总的品规数量*/
	declare @dcompanysumqty NUMERIC(25,8) /*总的机构数*/
	select @PgSumQty=COUNT(distinct p_id) from storehouse/*-有效品规则*/
    select @ProductSumQty=COUNT (distinct product_id) from products where deleted=0 and child_number=0
    select @dcompanysumqty=COUNT(*)  from company where deleted=0 and company_id>2
    
    if @ComPanyGroupCheckd=1
    begin 
			 select    a.e_id,a.p_id,a.c_id,a.inputman,TimeDayName,TimeMonthName,TimequarterName, a.factoryid, a.supplier_id, a.MakeArea,
					   c.name as PTypeGroupBigName,case isnull(d.name,'') when '' then c.name else d.name end  as  PTypeGroupHitName ,e.name as  PTypeGroupsmallName,
					   f.name as  YTypeGroupBigName,case isnull(g.name,'') when '' then  f.name else g.name end as  YTypeGroupHitName,h.name as  YTypeGroupsmallName,
					   SendQty,SendCostTotal,SendTotal,BackQty,BackCostTotal,BackTotal,
					   SendTotal-costtaxtotal as ML,
					   OrderQty,OrderTotal,billid,
					   artotal,costtaxtotal,totalmoney
					   into #BaseSumGroup
					   from 
				   (
					  select b.billid, e_id,p_id,c_id,inputman,billdate,TimeDayName,TimeMonthName,TimequarterName, b.factoryid, b.supplier_id, b.MakeArea,
							 SUM(SendQty) as sendqty,SUM(SendCostTotal) as SendCostTotal,
							 SUM(SendTotal) as SendTotal,SUM(BackQty) as BackQty ,SUM(BackCostTotal) as BackCostTotal,
							 SUM(BackTotal) as BackTotal,SUM(OrderQty) as OrderQty,SUM(OrderTotal) as OrderTotal,
							 SUM(SendTotal)-SUM(BackTotal) as artotal,
							 SUM(costtaxtotal) as costtaxtotal,SUM(totalmoney) as totalmoney
							 from 
					  (
	    				   select a.billid, a.e_id,b.p_id,a.c_id, a.inputman,a.billdate as billdate, b.factoryid, b.supplier_id, p.MakeArea, 
	    						 convert(varchar(10),a.billdate,21) as TimeDayName,
								 Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'  as TimeMonthName, 
								 Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'  as TimequarterName,
								 b.quantity as SendQty,
								 case a.billtype when 152 then b.taxtotal / (1 + b.taxrate) else b.SendCostTotal end as SendCostTotal,
								 b.taxtotal as SendTotal,
								 b.costtaxtotal AS costtaxtotal,
								 b.taxtotal / (1 + b.taxrate) AS totalmoney,
								 0 as BackQty,
								 0 as BackCostTotal,0 as BackTotal, 0 as OrderQty,0 as OrderTotal
								 from billidx a inner join salemanagebill b on a.billid=b.bill_id
												left join products p on b.p_id = p.product_id  
								 where billtype in (150,152) and billstates=0 and a.billdate between @BeginDate and @EndDate
						  union all
						  select 0 as billid, a.e_id,b.p_id,a.c_id, a.inputman,b.ComeDate as billdate, b.factoryid, b.supplier_id, p.MakeArea, 
								 convert(varchar(10),a.billdate ,21) as TimeDayName,
								 Cast(Year(a.billdate ) as VarChar) + '年' + Cast(Month(a.billdate ) as VarChar) + '月'  as TimeMonthName, 
								 Cast(Year(a.billdate ) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate ) as VarChar) + '季度'  as TimequarterName,
								 0 as SendQty,0 as SendCostTotal,0 as SendTotal, 
								 0 AS costtaxtotal,
								 0 AS totalmoney,
								 0 as BackQty,
								 0 as BackCostTotal,0 as BackTotal, 
								 b.quantity as OrderQty,
								 b.taxtotal as OrderTotal
								 from orderidx a inner join OrderBill b on a.billid=b.bill_id
												 left join products p on b.p_id = p.product_id  
								 where billtype in (154)   and  a.billdate between @BeginDate and @EndDate
						  union all
						  select 0 as billid, a.e_id,b.p_id,a.c_id, a.inputman,a.billdate, b.factoryid, b.supplier_id, p.MakeArea, 
								convert(varchar(10),a.billdate,21) as TimeDayName,
								Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'  as TimeMonthName, 
								Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'  as TimequarterName,
								0 as SendQty, 0 as SendCostTotal, 
								0 as SendTotal,
								0 AS costtaxtotal,
				  				0 AS totalmoney,
								b.quantity as BackQty,
								/*和自营店发货退货和机构发货退货保持一致.*/
								/*case a.billtype when 153 then b.taxtotal else b.costtaxtotal end as BackCostTotal,*/
								b.costtaxtotal as BackCostTotal,
								b.taxtotal as BackTotal,
								0 as OrderQty,0 as OrderTotal  
								from billidx a inner join salemanagebill b on a.billid=b.bill_id 
											   left join products p on b.p_id = p.product_id  
								where billtype in (151,153)  and a.billdate  between @BeginDate and @EndDate and billstates=0
	     			 )b  group by e_id,p_id,c_id,inputman,billdate,TimeDayName,TimeMonthName,TimequarterName,b.billid, b.factoryid, b.supplier_id, b.MakeArea
		                      
				) a left  join  ##PTypeGroupBigName c on a.p_id=c.baseinfo_id
				left  join  ##PTypeGroupHitName d on a.p_id=d.baseinfo_id
				left  join  ##PTypeGroupSmallName e on a.p_id=e.baseinfo_id
				left  join  #YTypeGroupBigName f on a.c_id=f.baseinfo_id
				left  join  #YTypeGroupHitName g on a.c_id=g.baseinfo_id 
				left  join  #YTypeGroupSmallName h on a.c_id=h.baseinfo_id
			   where a.c_id in (
								  select company_id from company where   YType in
								  (
									select TYPE from DecodeStr(@YtypeStr)
								  )
								)
	   end
	   else
	   begin
	     		 select    a.e_id,a.p_id,a.c_id,a.inputman,TimeDayName,TimeMonthName,TimequarterName, a.factoryid, a.supplier_id, a.MakeArea,
					   c.name as PTypeGroupBigName,case isnull(d.name,'') when '' then c.name else d.name end  as  PTypeGroupHitName ,e.name as  PTypeGroupsmallName,
					   SendQty,SendCostTotal,SendTotal,BackQty,BackCostTotal,BackTotal,
					   SendTotal-costtaxtotal as ML,
					   OrderQty,OrderTotal,billid,
					   artotal,costtaxtotal,totalmoney
					   into #BaseSumGroup2
					   from 
				   (
					  select b.billid, e_id,p_id,c_id,inputman,billdate,TimeDayName,TimeMonthName,TimequarterName, b.factoryid, b.supplier_id, b.MakeArea,
							 SUM(SendQty) as sendqty,SUM(SendCostTotal) as SendCostTotal,
							 SUM(SendTotal) as SendTotal,SUM(BackQty) as BackQty ,SUM(BackCostTotal) as BackCostTotal,
							 SUM(BackTotal) as BackTotal,SUM(OrderQty) as OrderQty,SUM(OrderTotal) as OrderTotal,
							 SUM(SendTotal)-SUM(BackTotal) as artotal,
							 SUM(costtaxtotal) as costtaxtotal,SUM(totalmoney) as totalmoney
							 from 
					  (
	    				   select a.billid, a.e_id,b.p_id,a.c_id, a.inputman,a.billdate as billdate, b.factoryid, b.supplier_id, p.MakeArea, 
	    						 convert(varchar(10),a.billdate,21) as TimeDayName,
								 Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'  as TimeMonthName, 
								 Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'  as TimequarterName,
								 b.quantity as SendQty,
								 case a.billtype when 152 then b.taxtotal / (1 + b.taxrate) else b.SendCostTotal end as SendCostTotal,
								 b.taxtotal as SendTotal,
								 b.costtaxtotal AS costtaxtotal,
								 b.taxtotal / (1 + b.taxrate) AS totalmoney,
								 0 as BackQty,
								 0 as BackCostTotal,0 as BackTotal, 0 as OrderQty,0 as OrderTotal
								 from billidx a inner join salemanagebill b on a.billid=b.bill_id
												left join products p on b.p_id = p.product_id  
								 where billtype in (150,152) and billstates=0 and a.billdate between @BeginDate and @EndDate
						  union all
						  select 0 as billid, a.e_id,b.p_id,a.c_id, a.inputman,b.ComeDate as billdate, b.factoryid, b.supplier_id, p.MakeArea, 
								 convert(varchar(10),a.billdate ,21) as TimeDayName,
								 Cast(Year(a.billdate ) as VarChar) + '年' + Cast(Month(a.billdate ) as VarChar) + '月'  as TimeMonthName, 
								 Cast(Year(a.billdate ) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate ) as VarChar) + '季度'  as TimequarterName,
								 0 as SendQty,0 as SendCostTotal,0 as SendTotal, 
								 0 AS costtaxtotal,
								 0 AS totalmoney,
								 0 as BackQty,
								 0 as BackCostTotal,0 as BackTotal, 
								 b.quantity as OrderQty,
								 b.taxtotal as OrderTotal
								 from orderidx a inner join OrderBill b on a.billid=b.bill_id
												 left join products p on b.p_id = p.product_id  
								 where billtype in (154)   and  a.billdate between @BeginDate and @EndDate
						  union all
						  select 0 as billid, a.e_id,b.p_id,a.c_id, a.inputman,a.billdate, b.factoryid, b.supplier_id, p.MakeArea, 
								convert(varchar(10),a.billdate,21) as TimeDayName,
								Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'  as TimeMonthName, 
								Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'  as TimequarterName,
								0 as SendQty, 0 as SendCostTotal, 
								0 as SendTotal,
								0 AS costtaxtotal,
				  				0 AS totalmoney,
								b.quantity as BackQty,
								/*case a.billtype when 153 then b.taxtotal else b.costtaxtotal end as BackCostTotal,*/
								b.costtaxtotal as BackCostTotal,
								b.taxtotal as BackTotal,
								0 as OrderQty,0 as OrderTotal  
								from billidx a inner join salemanagebill b on a.billid=b.bill_id 
											   left join products p on b.p_id = p.product_id  
								where billtype in (151,153)  and a.billdate  between @BeginDate and @EndDate and billstates=0
	     			 )b  group by e_id,p_id,c_id,inputman,billdate,TimeDayName,TimeMonthName,TimequarterName,b.billid, b.factoryid, b.supplier_id, b.MakeArea
		                      
				) a left  join   ##PTypeGroupBigName c on a.p_id=c.baseinfo_id
				left  join   ##PTypeGroupHitName d on a.p_id=d.baseinfo_id
				left  join   ##PTypeGroupSmallName e on a.p_id=e.baseinfo_id
			   where a.c_id in (
								  select company_id from company where   YType in
								  (
									select TYPE from DecodeStr(@YtypeStr)
								  )
								)
	   end
				 /*生成汇总SQL*/
				SET @INSSQL = ' INSERT INTO #FinalData ('
				SET @SELSQL = ' SELECT distinct '
				SET @GRPSQL = ' GROUP BY '
				SET @WhereSQL = ' WHERE  '
                                           
	            if (@GroupType=0)  /*机构*/
				begin
				  SET @TMPSQL = 'C_ID'
				  SET @INSSQL = @INSSQL + 'C_ID, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
				end 
				if @GroupType=1 /*业务员*/
				begin
				  SET @TMPSQL = 'E_ID'
				  SET @INSSQL = @INSSQL + 'E_ID, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
				end 
				if @GroupType=2 /*制单人*/
				begin
				  SET @TMPSQL = 'InputMan'
				  SET @INSSQL = @INSSQL + 'InputMan, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
				end 
				if (@ProductChecked=1)/*商品*/
				begin
				  SET @TMPSQL = 'P_ID'
				  SET @INSSQL = @INSSQL + 'P_ID, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
				end 
				if @ProductGroupCheckd=1 /*商品类别*/
				begin
				  IF @ComPanyAndProductsGroupRange = 0 SET @TMPSQL = 'PTypeGroupBigName'  /*大*/
				  IF @ComPanyAndProductsGroupRange = 1 SET @TMPSQL = 'PTypeGroupHitName' /*中*/
				  IF @ComPanyAndProductsGroupRange = 2 SET @TMPSQL = 'PTypeGroupSmallName' /*小*/
			      SET @INSSQL = @INSSQL + 'PtypeGroupName, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
                  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
                  SET @WhereSQL=@WhereSQL+@TMPSQL+'<>'''' and  '
				end
				if @ComPanyGroupCheckd=1 /*机构类别*/
				begin
				  IF @ComPanyAndProductsGroupRange = 0 SET @TMPSQL = 'YTypeGroupBigName'  /*大*/
				  IF @ComPanyAndProductsGroupRange = 1 SET @TMPSQL = 'YTypeGroupHitName' /*中*/
				  IF @ComPanyAndProductsGroupRange = 2 SET @TMPSQL = 'YTypeGroupsmallName' /*小*/
			      SET @INSSQL = @INSSQL + 'YtypeGroupName, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
                  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
                  SET @WhereSQL=@WhereSQL+@TMPSQL+'<> '''' '
				end
				if @TimeChecked=1 /*时间类别*/
				begin
				  IF @TimeRange = 0 SET @TMPSQL = 'TimeDayName'  /*日*/
				  IF @TimeRange = 1 SET @TMPSQL = 'TimeMonthName' /*月*/
				  IF @TimeRange = 2 SET @TMPSQL = 'TimequarterName' /*季度*/
			      SET @INSSQL = @INSSQL + 'YtimeType, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
                  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
				end 
				IF @Provider > 0 /*供应商*/
                BEGIN
                  SET @TMPSQL = 'supplier_id'
				  SET @INSSQL = @INSSQL + 'supplier_id, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
                END
                
                IF @Factory > 0 /*生产产家*/
                BEGIN
                  SET @TMPSQL = 'factoryid'
				  SET @INSSQL = @INSSQL + 'factoryid, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
                END
                
                IF @MakeArea > 0  /*产地*/
                BEGIN
                  SET @TMPSQL = 'MakeArea'
				  SET @INSSQL = @INSSQL + 'MakeArea, '
				  SET @SELSQL = @SELSQL + @TMPSQL + ', '
				  SET @GRPSQL = @GRPSQL + @TMPSQL + ', '
                END
				/*---组装SQL字符串*/
		        IF @INSSQL <> ''
			    BEGIN    
				  SET @INSSQL = @INSSQL 
							+ 'SendQty, SendCostTotal, SendTotal, BackQty, BackCostTotal, '
							+ 'BackTotal,ML,MLV,BackZb,OrderQty,OrderTotal,OrderFlishLV, '/*SendCiShu, '*/
							+ 'Artotal,costtaxtotal,totalmoney,taxtotal) '           
			    END
			    IF @SELSQL <> ''
			    BEGIN
			       if @ComPanyGroupCheckd=1
			       begin
			          SET @SELSQL = @SELSQL 
							+ 'SUM(SendQty) SendQty, SUM(SendCostTotal) SendCostTotal, SUM(SendTotal) SendTotal, '
							+ 'SUM(BackQty) BackQty, SUM(BackCostTotal) BackCostTotal,SUM(BackTotal) BackTotal,sum(ML) as ML, '
							+ '(sum(ML)/nullif(SUM(SendTotal),0))*100 as MLV, ' 
							/*+ 'case SUM(SendTotal) when 0 then 0 else (sum(ML)/SUM(SendTotal))*100 end as MLV, '*/
							+ '(sum(BackQty)/nullif(SUM(SendQty),0))*100 as BackZb, ' 
							/*+ 'case SUM(SendQty) when 0 then 0 else (SUM(BackQty)/SUM(SendQty))*100 end as BackZb, '*/
							+ 'sum(OrderQty) as OrderQty,sum(OrderTotal) as OrderTotal, '
							+ '(sum(SendQty)/nullif(SUM(OrderQty),0))*100 as OrderFlishLV,  ' 
							/*+ 'COUNT(DISTINCT billid) SendCiShu, '*/
							+ 'SUM(Artotal) Artotal,sum(costtaxtotal) as  costtaxtotal,sum(totalmoney) as totalmoney,SUM(SendTotal)-sum(totalmoney) as taxtotal  ' 
							/*+ 'case sum(OrderQty) when 0 then 0 else (SUM(SendQty)/sum(OrderQty))*100 end as OrderFlishLV '*/
							+ 'FROM  #BaseSumGroup '
			       end
			       else
			       begin
				      SET @SELSQL = @SELSQL 
							+ 'SUM(SendQty) SendQty, SUM(SendCostTotal) SendCostTotal, SUM(SendTotal) SendTotal, '
							+ 'SUM(BackQty) BackQty, SUM(BackCostTotal) BackCostTotal,SUM(BackTotal) BackTotal,sum(ML) as ML, '
							+ '(sum(ML)/nullif(SUM(SendTotal),0))*100 as MLV, ' 
							/*+ 'case SUM(SendTotal) when 0 then 0 else (sum(ML)/SUM(SendTotal))*100 end as MLV, '*/
							+ '(sum(BackQty)/nullif(SUM(SendQty),0))*100 as BackZb, ' 
							/*+ 'case SUM(SendQty) when 0 then 0 else (SUM(BackQty)/SUM(SendQty))*100 end as BackZb, '*/
							+ 'sum(OrderQty) as OrderQty,sum(OrderTotal) as OrderTotal, '
							+ '(sum(SendQty)/nullif(SUM(OrderQty),0))*100 as OrderFlishLV,  ' 
							/*+ 'COUNT(DISTINCT billid) SendCiShu, '*/
							+ 'SUM(Artotal) Artotal,sum(costtaxtotal) as  costtaxtotal,sum(totalmoney) as totalmoney,SUM(SendTotal)-sum(totalmoney) as taxtotal  ' 
							/*+ 'case sum(OrderQty) when 0 then 0 else (SUM(SendQty)/sum(OrderQty))*100 end as OrderFlishLV '*/
							+ 'FROM  #BaseSumGroup2 '
				    end
			    END  
			  IF @GRPSQL <> ''
			  BEGIN
				IF RIGHT(RTRIM(@GRPSQL), 1) = ','
				  SET @GRPSQL = LEFT(RTRIM(@GRPSQL), LEN(RTRIM(@GRPSQL))-1)          
			  END 	
			  IF @WhereSQL <> ''
			  BEGIN
				IF RIGHT(RTRIM(@WhereSQL), 3) = 'and'
				  SET @WhereSQL = LEFT(RTRIM(@WhereSQL), LEN(RTRIM(@WhereSQL))-3)          
			  END 
			  /*执行组装后的SQL，获取数据集后插入临时表中*/
			  IF RIGHT(RTRIM(@WhereSQL), 5) = 'WHERE'
			  begin
			    SET @EXESQL = @INSSQL + @SELSQL+@GRPSQL
			  end
			  else
			  begin
			    SET @EXESQL = @INSSQL + @SELSQL +@WhereSQL+@GRPSQL
			  end
			  
			  print(@EXESQL)
			  
			  IF @EXESQL <> ''
		   	  EXEC(@EXESQL) 
		   	  		   	  
		   	  /*---------------------------------------处理不能直接取出的值，单独处理*/
              DECLARE @RecId         INT /*自增列*/
              
		   	  DECLARE @SendQty       NUMERIC(25,8) /*配送总数量*/
		   	  DECLARE @BackQty       NUMERIC(25,8) /*退货总数量*/
		   	  
			  DECLARE @C_ID          int   /*配送机构ID*/
			  DECLARE @E_ID          int   /*业务员ID*/
			  DECLARE @InpuMan       int   /*制单人ID*/
			  DECLARE @P_ID          INT   /*-商品ID*/
			  DECLARE @YtimeType     VARCHAR(100)/*时间段名称*/
			  DECLARE @SalePgQty     NUMERIC(25,8)  /*动销品规数*/
			  DECLARE @BackPgQty     NUMERIC(25,8)  /*退货品规数*/
			  DECLARE @lastsenddate  VARCHAR(100)/*最近配送日期*/
			  
			  DECLARE @BackTotal     NUMERIC(25,8)  /*退货金额*/
			  DECLARE @SendTotal     NUMERIC(25,8)  /*配送金额*/
			  DECLARE @OosQty        NUMERIC(25,8)  /*缺货数量*/
			  DECLARE @YxyQty        NUMERIC(25,8)  /*有效机构数*/
			  DECLARE @StroeQty      NUMERIC(25,8)  /*库存余量*/
			  DECLARE @DaySaleQty    NUMERIC(25,8)  /*日均销量*/
			  DECLARE @NewPPgQty     NUMERIC(25,8)  /*新库存品品规数量*/
			  DECLARE @Year          varchar(100)/*年*/
			  DECLARE @Month         varchar(100)/*月*/
			  DECLARE @SUMYearAddMonth varchar(100)/*月*/
			  DECLARE @LastMonthDayDate      datetime/*一个月的最后一天日期*/
			  DECLARE @LastquarterDayDate      datetime/*一个季度的最后一天日期*/
			  DECLARE @SendCiShu    NUMERIC(25,8)  /*配送次数*/
			  /*-通过游标处理临时表的计算字段*/
			  DECLARE CurCalculate CURSOR FOR 
			  SELECT RecId, isnull(C_ID,0),isnull(E_ID,0), isnull(P_ID,0), isnull(inputman,0),isnull(YtimeType,''),isnull(SendTotal,0),isnull(@BackTotal,0),  
			         isnull(SendQty,0), isnull(BackQty,0) FROM #FinalData WHERE 1 = 1 
			  OPEN CurCalculate
			  FETCH NEXT FROM CurCalculate INTO @RecId, @C_ID, @E_ID, @P_ID, @inpuman,@YtimeType,@SendTotal,@BackTotal,@SendQty,@BackQty
			  WHILE @@FETCH_STATUS = 0
			  BEGIN
			     /*按日*/
			     if  @TimeRange=0
			     begin
	               select @SalePgQty=count(distinct b.p_id) from billidx a 
										  inner join salemanagebill b on a.billid=b.bill_id
										  where billtype in (150,152) and  ((convert(varchar(10),a.billdate,21)=@YtimeType) or @YtimeType='')
				 								        and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
			       select @BackPgQty=count(distinct b.p_id) from billidx a 
								 inner join salemanagebill b on a.billid=b.bill_id
								 where billtype in (151,153) and  ((convert(varchar(10),a.billdate,21)=@YtimeType) or @YtimeType='')
				 								        and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
				    
				   select top 1 @lastsenddate= convert(varchar(10),billdate,21) from billidx a
				         inner join salemanagebill b on a.billid=b.bill_id
						  where billtype in (150,152)   and  ((convert(varchar(10),a.billdate,21)=@YtimeType) or @YtimeType='')
				 								        and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
						  order by billdate	desc  
				  
				  
				   select  @OosQty=SUM(OOSQty)  from OOSCatalog a where   ((convert(varchar(10),a.inputdate,21)=@YtimeType) or @YtimeType='')
				   								        and (a.CompanyId=@C_ID or @C_ID=0) and (ProductId=@P_ID or @P_ID=0) and (EId=@E_ID or @E_ID=0) and (a.InputManId=@inpuman or @inpuman=0)
	               select @YxyQty=count(distinct c_id)  from billidx  a inner join salemanagebill b on a.billid=b.bill_id
				          where billtype in (150,152) and   ((convert(varchar(10),a.billdate,21)=@YtimeType) or @YtimeType='')
				 								        and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
	               select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@C_ID or @C_ID=0) and (ModifyDate=@YtimeType or  @YtimeType='')  
	               select @DaySaleQty=(@SendQty-@BackQty)/nullif(DATEDIFF(DAY,@begindate,@enddate)+1-dhday,0) from 
	               (
	                 select COUNT(1)as dhday From PerStockData  
							where datetime>=DATEDIFF(DAY,30,GETDATE())  
							and qty=0 and (y_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)
					) a		
				  select @NewPPgQty=COUNT(distinct p_id) from 
					 storehouse where instoretime between @begindate and @enddate and p_id not in 
					 (select p_id from  storehouse where instoretime<=@begindate)  and (Y_ID=@C_ID or @C_ID=0)
				  select @SendCiShu=COUNT(distinct billid)  from salemanagebill a  inner join billidx b 
                                on a.bill_id=b.billid where billtype in (150,152) and b.c_id=@C_ID and (a.p_id=@P_ID or @P_ID=0) and billdate between @begindate and @enddate
	             end
	             /*按月*/
	             else if  @TimeRange=1
			     begin
	                select @SalePgQty=count(distinct b.p_id) from billidx a 
										  inner join salemanagebill b on a.billid=b.bill_id
										  where billtype in (150,152) and  ((Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'=@YtimeType) or @YtimeType='')
	                                                       and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
	               
					select @BackPgQty=count(distinct b.p_id) from billidx a 
								 inner join salemanagebill b on a.billid=b.bill_id
								 where billtype in (151,153) and  ((Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'=@YtimeType) or @YtimeType='')
	                                                       and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
				    select top 1 @lastsenddate= convert(varchar(10),billdate,21) from billidx a
				         inner join salemanagebill b on a.billid=b.bill_id
						  where billtype in (150,152)    and  ((Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'=@YtimeType) or @YtimeType='')
	                            and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
						        order by billdate	desc 
				   
				 								        
	                select  @OosQty=SUM(OOSQty)  from OOSCatalog a where  ((Cast(Year(a.inputdate) as VarChar) + '年' + Cast(Month(a.inputdate) as VarChar) + '月'=@YtimeType) or @YtimeType='')
	                                                       and (a.CompanyId=@C_ID or @C_ID=0) and (a.ProductId=@P_ID or @P_ID=0) and (a.EId=@E_ID or @E_ID=0) and (a.InputManId=@inpuman or @inpuman=0)
	                select @YxyQty=count(distinct c_id)  from billidx  a inner join salemanagebill b on a.billid=b.bill_id
				          where billtype in (150,152) and  ((Cast(Year(a.billdate) as VarChar) + '年' + Cast(Month(a.billdate) as VarChar) + '月'=@YtimeType) or @YtimeType='')
	             
			        select @Year=REPLACE(substring(@YtimeType,1,5),'年','-')    
			       	select @Month=REPLACE(substring(@YtimeType,6,2),'月','') 
			       	set @SUMYearAddMonth=@Year+@Month     
			       	select  @LastMonthDayDate=DATEADD (DAY,-1,DATEADD(month,1,@SUMYearAddMonth+'-1') ) 
			       	if convert(varchar(100) ,@enddate,23)<convert(varchar(100) ,@LastMonthDayDate,23)
			       	begin
			       	    select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@C_ID or @C_ID=0) and
	                        ModifyDate=convert(varchar(100) ,@enddate,23)
			       	end
			       	else
			       	begin
			       	    select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@C_ID or @C_ID=0) and
	                        ModifyDate=convert(varchar(100) ,@LastMonthDayDate,23)
			       	end
	                                                                                             
	                select @DaySaleQty=(@SendQty-@BackQty)/nullif(DATEDIFF(DAY,@begindate,@enddate)+1-dhday,0) from 
	                (
	                  select COUNT(1)as dhday From PerStockData  
							where datetime>=DATEDIFF(DAY,30,GETDATE())  
							and qty=0 and (y_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)
					 ) a
			        select @NewPPgQty=COUNT(distinct p_id) from 
					 storehouse where instoretime between @begindate and @enddate and p_id not in 
					 (select p_id from  storehouse where instoretime<=@begindate)  and (Y_ID=@C_ID or @C_ID=0)
					select @SendCiShu=COUNT(distinct billid)  from salemanagebill a  inner join billidx b 
                                on a.bill_id=b.billid where billtype in (150,152) and b.c_id=@C_ID and (a.p_id=@P_ID or @P_ID=0)  and billdate between @begindate and @enddate
	             end
	             /*按季度*/
	             else if  @TimeRange=2
			     begin
	                 select @SalePgQty=count(distinct b.p_id) from billidx a 
										  inner join salemanagebill b on a.billid=b.bill_id
										  where billtype in (150,152) and ((Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'=@YtimeType) or @YtimeType='')
	                                                     and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
					 select @BackPgQty=count(distinct b.p_id) from billidx a 
								 inner join salemanagebill b on a.billid=b.bill_id
								 where billtype in (151,153) and ((Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'=@YtimeType) or @YtimeType='')
	                                                     and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
	                 select top 1 @lastsenddate= convert(varchar(10),billdate,21) from billidx a
				         inner join salemanagebill b on a.billid=b.bill_id
						  where billtype in (150,152)    and ((Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'=@YtimeType) or @YtimeType='')
	                                                     and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
						  order by billdate	desc  
											        
	                 select  @OosQty=SUM(OOSQty)  from OOSCatalog a where  ((Cast(Year(a.inputdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.inputdate) as VarChar) + '季度'=@YtimeType) or @YtimeType='')
	                                                       and (a.CompanyId=@C_ID or @C_ID=0) and (a.ProductId=@P_ID or @P_ID=0) and (a.EId=@E_ID or @E_ID=0) and (a.InputManId=@inpuman or @inpuman=0)
	                 select @YxyQty=count(distinct c_id)  from billidx  a inner join salemanagebill b on a.billid=b.bill_id
				          where billtype in (150,152) and  ((Cast(Year(a.billdate) as VarChar) + '年' +  Cast(DATEPART(qq, a.billdate) as VarChar) + '季度'=@YtimeType) or @YtimeType='')
	                                                     and (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0) and (e_id=@E_ID or @E_ID=0) and (inputman=@inpuman or @inpuman=0)
	                 select @LastquarterDayDate=DATEADD(day,-1, convert(char(8),dateadd(month,1+datepart(quarter,convert(varchar(100) ,@enddate,23))*3-month(convert(varchar(100) ,@enddate,23)),convert(varchar(100) ,@enddate,23)),120)+'1')
	                 if convert(varchar(100) ,@enddate,23)<convert(varchar(100) ,@LastquarterDayDate,23)
	                 begin
	                    select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@C_ID or @C_ID=0) and  
	                         ModifyDate=convert(varchar(100) ,@enddate,23)    
			       	 end
			       	 else
			       	 begin
			       	     select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@C_ID or @C_ID=0) and
	                         ModifyDate=convert(varchar(100) ,@LastquarterDayDate,23)    
			       	 end
	                 select @DaySaleQty=(@SendQty-@BackQty)/nullif(DATEDIFF(DAY,@begindate,@enddate)+1-dhday,0) from 
	                (
	                  select COUNT(1)as dhday From PerStockData  
							where datetime>=DATEDIFF(DAY,30,GETDATE())  
							and qty=0 and (y_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)
					 ) a
				     select @NewPPgQty=COUNT(distinct p_id) from 
					 storehouse where instoretime between @begindate and @enddate and p_id not in 
					 (select p_id from  storehouse where instoretime<=@begindate)  and (Y_ID=@C_ID or @C_ID=0)
					 
					 select @SendCiShu=COUNT(distinct billid)  from salemanagebill a  inner join billidx b 
                                on a.bill_id=b.billid where billtype in (150,152) and b.c_id=@C_ID and (a.p_id=@P_ID or @P_ID=0) and billdate between @begindate and @enddate
	             end
	             /*不与日,月，季度组合*/
	             else
	             begin
	                 select @SalePgQty=count(distinct b.p_id) from billidx a 
										  inner join salemanagebill b on a.billid=b.bill_id
										  where billtype in (150,152) and  (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)and (e_id=@E_ID or @E_ID=0)
										      and (inputman=@inpuman or @inpuman=0)  and   a.billdate between @BeginDate and @EndDate
					 select @BackPgQty=count(distinct b.p_id) from billidx a 
								 inner join salemanagebill b on a.billid=b.bill_id
								 where billtype in (151,153) and  (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)and 
								 (e_id=@E_ID or @E_ID=0)  and (inputman=@inpuman or @inpuman=0) and  a.billdate between @BeginDate and @EndDate
	             
	                 select top 1 @lastsenddate= convert(varchar(10),billdate,21) from billidx a
				         inner join salemanagebill b on a.billid=b.bill_id
						  where billtype in (150,152)   and  (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)and (e_id=@E_ID or @E_ID=0)
						        and (inputman=@inpuman or @inpuman=0) and   a.billdate between @BeginDate and @EndDate
						  order by billdate	desc  

	                 select  @OosQty=SUM(OOSQty)  from OOSCatalog a where (a.CompanyId=@C_ID or @C_ID=0) and (a.ProductId=@P_ID or @P_ID=0) 
	                         and (a.EId=@E_ID or @E_ID=0) and (a.InputManId=@inpuman or @inpuman=0) and   CreateDate between @BeginDate and @EndDate
	                
	                 select @YxyQty=count(distinct c_id)  from billidx  a inner join salemanagebill b on a.billid=b.bill_id
				          where billtype in (150,152) and  (a.c_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)and (e_id=@E_ID or @E_ID=0) 
				                and (inputman=@inpuman or @inpuman=0) and   a.billdate between @BeginDate and @EndDate
	                 if  convert(varchar(100) ,GETDATE(),23)=@EndDate 
	                 begin
	                    select @StroeQty=sum(quantity) from storehouse  where (p_id=@P_ID or @P_ID=0) and (Y_ID=@Y_ID or @Y_ID=0)               
	                 end
	                 else
	                 begin
	                    select @StroeQty=sum(quantity) from HistoryStorehouse where (p_id=@P_ID or @P_ID=0) and (Y_ID=@Y_ID or @Y_ID=0)  and
	                                      ModifyDate=@EndDate 
	                 end         
	                 select @DaySaleQty=(@SendQty-@BackQty)/nullif(DATEDIFF(DAY,@begindate,@enddate)+1-dhday,0) from 
	                (
	                  select COUNT(1)as dhday From PerStockData  
							where datetime>=DATEDIFF(DAY,30,GETDATE())  
							and qty=0 and (y_id=@C_ID or @C_ID=0) and (p_id=@P_ID or @P_ID=0)
					 ) a
					 select @NewPPgQty=COUNT(distinct p_id) from 
					 storehouse where instoretime between @begindate and @enddate and p_id not in 
					 (select p_id from  storehouse where instoretime<=@begindate)  and (Y_ID=@C_ID or @C_ID=0)
					 
					  select @SendCiShu=COUNT(distinct billid)  from salemanagebill a  inner join billidx b 
                                on a.bill_id=b.billid where billtype in (150,152) and b.c_id=@C_ID  and (a.p_id=@P_ID or @P_ID=0) and billdate between @begindate and @enddate
        
	             end
	             
	             update #FinalData set SalePgQty=@SalePgQty,BackPgQty=@BackPgQty,lastsenddate=@lastsenddate,
	                                   OosQty=@OosQty,YxyQty=@YxyQty,StroeQty=@StroeQty,DaySaleQty=@DaySaleQty,
	                                   NewPPgQty=@NewPPgQty,SendCiShu=@SendCiShu
	                                where RecId=@RecId
						 
			  FETCH NEXT FROM CurCalculate INTO @RecId, @C_ID, @E_ID, @P_ID, @inputman,@YtimeType,@SendTotal,@BackTotal,@SendQty,@BackQty 
			  END 
			  CLOSE CurCalculate
			  DEALLOCATE CurCalculate   

		      /*-处理临时表中字段为NULL的*/
		      update #FinalData set OosQty=ISNULL(OosQty,0),OrderQty=ISNULL(OrderQty,0),OrderTotal=ISNULL(OrderTotal,0),
		                            OrderFlishLV=ISNULL(OrderFlishLV,0),SendQty=ISNULL(SendQty,0), SendTotal=ISNULL(SendTotal,0),
		                            SendCostTotal=ISNULL(SendCostTotal,0),BackQty=ISNULL(BackQty,0),BackCostTotal=ISNULL(BackCostTotal,0)  
                                    ,BackTotal=ISNULL(BackTotal,0),ML=ISNULL(ML,0),MLV=ISNULL(MLV,0),BackZb=ISNULL(BackZb,0)            
                                    ,SalePgQty=ISNULL(SalePgQty,0) ,BackPgQty=ISNULL(BackPgQty,0),lastsenddate=ISNULL(lastsenddate,'')         
                                    ,SendCiShu=ISNULL(SendCiShu,0) ,ArTotal=ISNULL(ArTotal,0),YxyQty=ISNULL(YxyQty,0),StroeQty=ISNULL(StroeQty,0)
                                    ,NewPPgQty=ISNULL(NewPPgQty,0) , TotalMoney=ISNULL(TotalMoney,0),TaxTotal=ISNULL(TaxTotal,0)                     
             /*-查询最终结果集                                 */
		     SELECT   distinct a.RecId as sn, isnull(c.name,'') as yname,isnull(d.name,'') as pname,isnull(d.standard,'') as standard,
		               isnull(d.makearea,'') as makearea1,isnull(e.name,'') as unitname, isnull(NewPPgQty,0) as NewPgQty,
		                       ISNULL( case c.BalanceMode when 0 then '现结' when 1 then '挂账' when 2 then '月结' 
							    when 3 then '滚结' when 4 then '货到付款' when 5 then '预收' when 6 then '预付' 
							    when 7 then '实销实结' end,'') as jstype,isnull(f.credit_total,0) as XyEd,
							    case isnull(@PgSumQty,0) when 0 then 0 else (a.SalePgQty/isnull(@PgSumQty,0))*100 end as SalePgZb, 
							    CONVERT(int, case isnull(a.SendCiShu,0) when 0 then 0 else  DATEDIFF(DAY,@begindate,@enddate)/isnull(a.SendCiShu,0) end) as SendJgZq,
							    case @GroupType when 1 then isnull(g.name,'') when 2 then  isnull(h.name,'') else ''  end as  ename, 
							    isnull(@dcompanysumqty,0) as dcommpayqty,
							    isnull(d.factory,'') as factory1,isnull(@ProductSumQty,0) as pgqty,isnull(@ProductSumQty,0)-isnull(a.SalePgQty,0) as nosalepgqty,
					            isnull(@dcompanysumqty,0)-isnull(a.YxyQty,0) as dnosalecompanyqty,
					            isnull(a.YtypeGroupName,'') as ytypegroup,isnull(a.PtypeGroupName,'') as ptypegroup,isnull(a.YtimeType,'') as timed,					            
					            clt.Name as Provider, bf.AccountComment as factory, 					            
					            /*MakeArea,包含在a.*中					            */
		                        a.* FROM #FinalData a 
		                   left join products d on a.P_ID=d.product_id
			               left join company c on  a.C_ID=c.company_id
			               left join unit e     on d.unit1_id=e.unit_id
			               left join (select * from Companybalance where y_id=@Y_id) f on a.c_id=f.c_id
					       left join employees g on a.E_ID=g.emp_id
					       left join employees h on a.INPUTMAN=h.emp_id 					       
					       left join clients clt on a.supplier_id = clt.client_id
					       left join basefactory bf on a.factoryid = bf.CommID					                                             			    	
    
			    
			    
						  /*删除临时表  */
						  IF object_id(N'#BaseSumGroup', N'U') is not null
                          Drop Table #BaseSumGroup 
						   IF object_id(N'#BaseSumGroup2', N'U') is not null
                          Drop Table #BaseSumGroup2
						  DROP TABLE #FinalData  	
						  drop table ##PTypeGroupBigName
						  drop table ##PTypeGroupHitName
						  drop table ##PTypeGroupSmallName
						  drop table #YTypeGroupBigName
						  drop table #YTypeGroupHitName
						  drop table #YTypeGroupSmallName 
end
GO
