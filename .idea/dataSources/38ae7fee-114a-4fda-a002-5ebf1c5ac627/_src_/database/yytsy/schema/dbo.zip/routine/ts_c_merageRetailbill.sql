




/*@bType=0 上传所有单据*/
/*@bType=1 只上传未传过的单据*/
CREATE proc ts_c_merageRetailbill
(
	@begindate datetime,
	@enddate   datetime,
	@bType	   int,
	@nPosid    int,
	@nImputMan int
)
as
set nocount on
declare @nE_id int,@nCash_ID int,@nP_id int,@nC_id int,@nS_id int,@nReturn int,@nA_id int,@dTaxRate numeric(5,2)
declare @nNewBillId numeric(10,0),@tBillDate varchar(10),@tDatetemp datetime,@szBillCode varchar(30)
declare @dYsMoney NUMERIC(25,8),@dSsMoney NUMERIC(25,8)
declare @nPeriod int,@szBatchno varchar(30),@MakeDate datetime
declare @nDatetemp datetime,@nCount int,@dtotalmoney NUMERIC(25,8),@dtotalqty NUMERIC(25,8)


exec ts_getsysvalue 'TaxRate',@dTaxRate out
if @dTaxRate is null select @dTaxRate=0

select @nCount=1

	select @tBillDate=convert(varchar(10),getdate(),20)/*单据日期*/
	select @nCash_id=6/*现金帐户id*/
	select @nS_id=isnull(s_id,0),@nC_id=isnull(c_id,0) from shop where posid=@nPosid
	if (@nS_id=0) or (@nC_id=0)
	begin
		return -1
	end

/*按销售人员合并零售单*/
		if @bType=0
		begin
			select b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id,
			isnull(sum(s.quantity),0)		as quantity,
			isnull(sum(s.totalmoney),0)		as totalmoney,/*折后税前金额*/
			isnull(sum(s.retailtotal),0)		as retailtotal,
			isnull(sum(s.taxmoney),0)		as taxmoney,
			isnull(sum(s.taxtotal),0)		as taxtotal,
			isnull(sum(s.total),0)			as total/*折前金额*/
			into #temptable1 from billidx b right join salemanagebill s 
			on b.billid=s.bill_id
			left join products p
			on s.p_id=p.product_id
			where b.billdate>=@begindate and b.billdate<=@enddate and  b.billtype=12
			group by b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id

			declare merge_cursr cursor for
			select distinct billdate,e_id,a_id  
			from #temptable1 
		end else
		begin
			select b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id,
			isnull(sum(s.quantity),0)		as quantity,
			isnull(sum(s.totalmoney),0)		as totalmoney,
			isnull(sum(s.retailtotal),0)		as retailtotal,
			isnull(sum(s.taxmoney),0)		as taxmoney,
			isnull(sum(s.taxtotal),0)		as taxtotal,
			isnull(sum(s.total),0)				as total/*折前金额*/
			into #temptable2 from billidx b right join salemanagebill s 
			on b.billid=s.bill_id
			left join products p
			on s.p_id=p.product_id
			where b.billdate>=@begindate and b.billdate<=@enddate and  b.billtype=12 and  b.transcount=0
			group by b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id
			declare merge_cursr cursor for
			select distinct billdate,e_id,a_id  
			from #temptable2 
		end
		update billidx set transcount=transcount+1,lasttranstime=getdate()
		where billdate>=@begindate and billdate<=@enddate and  billtype=12
		
		open merge_cursr

		fetch next from merge_cursr into @tDatetemp,@nE_id,@nA_id
		while @@fetch_status=0
		begin
				select @szBillCode='LS-'+@tBillDate+'-'+right(cast(10000+@nCount as varchar(5)),4)
				select @nCount=@nCount+1
				if @bType=0
				begin
					select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
					from #temptable1
					where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id

					select @nNewbillid=isnull(max(billid),0)+1 from billdtsidx

					insert billdtsidx (billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,
					inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid)
					values(@nNewBillId,@tDateTemp,@szBillCode,12,@nA_id,@nC_id,@nE_id,@nS_id,
					@nImputMan,@dtotalmoney,@dtotalmoney,@dtotalqty,@dTaxRate,'2',@nposid)
					
					insert into salemanagebilldts
					(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
					 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
					 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
					 taxrate,total,unitid)
					select @nNewBillid,p_id,batchno,quantity,costprice,total/quantity,totalmoney/total,totalmoney/quantity, 
					totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
					validdate,'合格',0,@nS_id,location_id,supplier_id,commissionflag,@dTaxRate/100,total,unit1_id
					from #temptable1 where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id 

					if @@rowcount=0 goto error
				end else
				begin
					select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
					from #temptable2
					where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id

					select @nNewbillid=isnull(max(billid),0)+1 from billdtsidx
					
	
					insert billdtsidx (billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,
					inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid)
					values(@nNewBillId,@tDateTemp,@szBillCode,12,@nA_id,@nC_id,@nE_id,@nS_id,
					@nImputMan,@dtotalmoney,@dtotalmoney,@dtotalqty,@dTaxRate,'2',@nposid)
					
					insert into salemanagebilldts
					(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
					 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
					 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
					 taxrate,total,unitid)
					select @nNewBillid,p_id,batchno,quantity,costprice,total/quantity,totalmoney/total,totalmoney/quantity, 
					totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
					validdate,'合格',0,@nS_id,location_id,supplier_id,commissionflag,@dTaxRate/100,total,unit1_id
					from #temptable2 where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id 

					if @@rowcount=0 goto error
				end
			fetch next from merge_cursr into @tDatetemp,@nE_id,@nA_id
		end
/*		if @bType=0
			drop table #temptable1
		else 
			drop table #temptable2
*/
		close merge_cursr
		deallocate merge_cursr

select @nCount=1


/*按销售人员合并零售退货单*/
		if @bType=0
		begin
			select b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id,
			isnull(sum(s.quantity),0)		as quantity,
			isnull(sum(s.totalmoney),0)	as totalmoney,/*折后税前金额*/
			isnull(sum(s.retailtotal),0)	as retailtotal,
			isnull(sum(s.taxmoney),0)		as taxmoney,
			isnull(sum(s.taxtotal),0)		as taxtotal,
			isnull(sum(s.total),0)				as total/*折前金额*/
			into #temptable3 from billidx b right join salemanagebill s 
			on b.billid=s.bill_id
			left join products p
			on s.p_id=p.product_id
			where b.billdate>=@begindate and b.billdate<=@enddate and  b.billtype=13
			group by b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id

			declare merge_cursr cursor for
			select distinct billdate,e_id,a_id  
			from #temptable3 
		end else
		begin
			select b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id,
			isnull(sum(s.quantity),0)		as quantity,
			isnull(sum(s.totalmoney),0)	as totalmoney,
			isnull(sum(s.retailtotal),0)	as retailtotal,
			isnull(sum(s.taxmoney),0)		as taxmoney,
			isnull(sum(s.taxtotal),0)		as taxtotal,
			isnull(sum(s.total),0)				as total/*折前金额*/
			into #temptable4 from billidx b right join salemanagebill s 
			on b.billid=s.bill_id
			left join products p
			on s.p_id=p.product_id
			where b.billdate>=@begindate and b.billdate<=@enddate and  b.billtype=13 and  b.transcount=0
			group by b.billdate,b.e_id,b.a_id,
			s.p_id,s.batchno,s.costprice,s.location_id,s.supplier_id,s.commissionflag,
			s.makedate,s.validdate,s.ss_id,p.unit1_id

			declare merge_cursr cursor for
			select distinct billdate,e_id,a_id  
			from #temptable4 
		end
		update billidx set transcount=transcount+1,lasttranstime=convert(varchar(10),getdate(),20)
		where billdate>=@begindate and billdate<=@enddate and  billtype=13
		
		open merge_cursr

		fetch next from merge_cursr into @tDatetemp,@nE_id,@nA_id
		while @@fetch_status=0
		begin
				select @szBillCode='LT-'+@tBillDate+'-'+right(cast(10000+@nCount as varchar(5)),4)
				select @nCount=@nCount+1
				if @bType=0
				begin
					select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
					from #temptable3
					where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id

					select @nNewbillid=isnull(max(billid),0)+1 from billdtsidx
		
					insert billdtsidx (billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,
					inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid)
					values(@nNewBillId,@tDateTemp,@szBillCode,13,@nA_id,@nC_id,@nE_id,@nS_id,
					@nImputMan,@dtotalmoney,@dtotalmoney,@dtotalqty,@dTaxRate,'2',@nposid)
					
					if @@rowcount=0 goto error

					insert into salemanagebilldts
					(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
					 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
					 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
					 taxrate,total,unitid)
					select @nNewBillid,p_id,batchno,quantity,costprice,total/quantity,totalmoney/total,totalmoney/quantity, 
					totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
					validdate,'合格',0,@nS_id,location_id,supplier_id,commissionflag,@dTaxRate/100,total,unit1_id
					from #temptable3 where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id 

					if @@rowcount=0 goto error
				end else
				begin
					select @dtotalmoney=isnull(sum(taxtotal),0),@dtotalqty=isnull(sum(quantity),0) 
					from #temptable4
					where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id

					select @nNewbillid=isnull(max(billid),0)+1 from billdtsidx
			
					insert billdtsidx (billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,
					inputman,ysmoney,ssmoney,quantity,taxrate,billstates,posid)
					values(@nNewBillId,@tDateTemp,@szBillCode,13,@nA_id,@nC_id,@nE_id,@nS_id,
					@nImputMan,@dtotalmoney,@dtotalmoney,@dtotalqty,@dTaxRate,'2',@nposid)
					
					if @@rowcount=0 goto error

					insert into salemanagebilldts
					(bill_id,p_id,batchno,quantity,costprice,saleprice,discount,discountprice,
					 totalmoney,taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,
					 validdate,qualitystatus,price_id,ss_id,location_id,supplier_id,commissionflag,
					 taxrate,total,unitid)
					select @nNewBillid,p_id,batchno,quantity,costprice,total/quantity,totalmoney/total,totalmoney/quantity, 
					totalmoney,taxtotal/quantity,taxtotal,taxmoney,retailtotal/quantity,retailtotal,makedate,
					validdate,'合格',0,@nS_id,location_id,supplier_id,commissionflag,@dTaxRate/100,total,unit1_id
					from #temptable4 where billdate=@tDatetemp and e_id=@nE_id and a_id=@nA_id 

					if @@rowcount=0 goto error
				end
			fetch next from merge_cursr into @tDatetemp,@nE_id,@nA_id
		end
/*		if @bType=0
			drop table #temptable3
		else 
			drop table #temptable4
*/
		close merge_cursr
		deallocate merge_cursr


		return 0
error:
		deallocate merge_cursr
		return -1
GO
