


CREATE FUNCTION AuthorizeEmployees(@OperatorID int)
RETURNS TABLE
AS
RETURN(
 SELECT distinct E.emp_ID, E.Class_ID, E.Parent_ID, E.Child_Number, E.Serial_Number, E.[Name] FROM employees E 
    INNER JOIN
     (SELECT * FROM userauthorize WHERE upper(type) = 'E' AND e_id = @OperatorID) AS UA
   ON     (LEFT(E.Class_id,LEN(UA.psc_id)) = UA.psc_id) OR (LEFT(UA.psc_id,LEN(E.class_id)) = E.class_id)
 UNION ALL
  SELECT distinct E.Emp_ID, E.Class_ID, E.Parent_ID, E.Child_Number, E.Serial_Number, E.[Name] FROM employees E 
      WHERE (NOT EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'E' AND e_id = @OperatorID))
       OR (EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'E' AND e_id = @OperatorID AND psc_id = '000000'))
)
GO
