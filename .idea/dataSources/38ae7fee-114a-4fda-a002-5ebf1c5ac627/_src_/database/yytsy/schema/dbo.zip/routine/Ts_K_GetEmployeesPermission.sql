
CREATE PROCEDURE Ts_K_GetEmployeesPermission(@ShowAll INT, @LoginEId INT, @EId INT, @YId INT, @AuditStates INT, @Begin [DATETIME], @End [DATETIME])
AS
BEGIN
	IF @ShowAll = -9
	BEGIN
		/*审核权限申请记录获取申请权限*/
		SELECT e.name AS empname, e.serial_number AS serial_number, CAST(u.loginpass AS VARCHAR(60)) AS [PASSWORD],  
			   u.e_id, p.lim AS permission, u.USERPIN, u.isBinding, u.SerialNumber, e.class_id, e.Y_ID, p.ProductInfo AS ProductInfor,
			   p.ClientInfo AS ClientInfor, p.PriceInfo AS priceInfor, c.name AS YName, c.class_id AS YClass_id, 
			   ISNULL(c.posdatamode, 1) AS posdatamode, ISNULL(c.superior_id, 0) AS superior_id, P.limPlugin AS permPlugin, 
			   ISNULL(c.Ytype, 0) AS YType, p.Audit_Id, p.AuditStates, p.AuditReason, ISNULL(e1.name, '') AS Auditer
			FROM EmployeesPermission p INNER JOIN employees e ON p.Emp_Id = e.emp_id
			                           INNER JOIN users u ON e.emp_id = u.e_id
			                           INNER JOIN company c ON e.Y_ID = c.company_id
			                           LEFT JOIN employees e1 ON p.Audit_Id = e1.emp_id
		WHERE p.Permission_Id = @LoginEId		
	END
	ELSE
	BEGIN
		/*权限申请记录查询*/
		SELECT p.Permission_Id, p.Emp_Id, CONVERT(VARCHAR(100), p.RequestDate, 120) AS RequestDate, p.RequestReason, 
			   p.lim,p.limPlugin, p.ProductInfo, p.ClientInfo, p.PriceInfo, p.Audit_Id, p.AuditReason,
			   CASE WHEN P.AuditDate = '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), p.AuditDate, 120) END AS AuditDate,
			   p.Comment, p.Y_id, e.name AS RequestName, ISNULL(e1.name, '') AS AuditName, p.AuditStates,
			   CASE p.AuditStates WHEN 0 THEN '待审核' WHEN 1 THEN '通过' WHEN 2 THEN '拒绝' END AS AuditStatesDesc  
			FROM EmployeesPermission p INNER JOIN employees e ON p.Emp_Id = e.emp_id
									   LEFT JOIN employees e1 ON p.Audit_Id = e1.emp_id
		WHERE p.Y_id = @YId AND (p.Emp_Id = @LoginEId OR @ShowAll = 1) AND (p.Emp_Id = @EId OR @EId = 0) AND 
			  (p.AuditStates =  @AuditStates OR @AuditStates = -1) AND p.RequestDate BETWEEN @Begin AND @End 
	END
END
GO
