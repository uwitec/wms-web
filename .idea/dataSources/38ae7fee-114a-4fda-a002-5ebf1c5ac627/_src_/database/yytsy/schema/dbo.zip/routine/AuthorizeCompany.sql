

CREATE FUNCTION AuthorizeCompany(@OperatorID int)
RETURNS TABLE
AS
RETURN(
 SELECT distinct Y.company_ID, Y.Class_ID, Y.Parent_ID, Y.Child_Number, Y.Serial_Number, Y.[Name] FROM Company Y 
    INNER JOIN
     (SELECT * FROM userauthorize WHERE upper(type) = 'Y' AND e_id = @OperatorID) AS UA
   ON     (LEFT(Y.Class_id,LEN(UA.psc_id)) = UA.psc_id) OR (LEFT(UA.psc_id,LEN(Y.class_id)) = Y.class_id)
 UNION ALL
  SELECT distinct Y.company_ID, Y.Class_ID, Y.Parent_ID, Y.Child_Number, Y.Serial_Number, Y.[Name] FROM Company Y  
      WHERE (NOT EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'Y' AND e_id = @OperatorID))
       OR (EXISTS(SELECT * FROM userauthorize WHERE upper(type) = 'Y' AND e_id = @OperatorID AND psc_id = '000000'))
)
GO
