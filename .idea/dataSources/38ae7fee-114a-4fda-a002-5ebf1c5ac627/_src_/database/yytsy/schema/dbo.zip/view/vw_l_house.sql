

CREATE VIEW dbo.vw_l_house
AS
SELECT dbo.vw_Products.code, dbo.vw_Products.Unit3Name, 
      dbo.vw_Products.Unit2Name, dbo.vw_Products.Unit4Name, 
      dbo.vw_Products.LatinName, dbo.vw_Products.ChemName, 
      dbo.vw_Products.EngName, dbo.vw_Products.medtype, dbo.vw_Products.pinyin, 
      dbo.vw_Products.makearea, dbo.vw_Products.trademark, 
      dbo.vw_Products.permitcode, dbo.vw_Products.modal, dbo.vw_Products.standard, 
      dbo.vw_Products.alias, dbo.vw_Products.name, dbo.vw_Products.serial_number, 
      dbo.vw_Products.class_id, dbo.vw_Products.product_id, dbo.storehouse.batchno, 
      dbo.vw_Products.Posyhday, 
      dbo.storehouse.makedate, dbo.storehouse.validdate,dbo.storehouse.location_id,
      SUM(dbo.storehouse.costtotal) AS costtotal, SUM(dbo.storehouse.costprice) AS costPrice, 
      SUM(dbo.storehouse.quantity) AS quantity, dbo.vw_Products.MedName, 
      dbo.vw_Products.Unit1Name, dbo.storehouse.s_id, dbo.storehouse.yhdate, 
      dbo.storehouse.instoretime, dbo.storehouse.supplier_id, ISNULL(dbo.clients.name, '') 
      AS CName, dbo.vw_Products.MaintainType, dbo.vw_Products.MaintainDay, 
      dbo.vw_Products.validmonth, dbo.vw_Products.validday, dbo.vw_Products.gspflag, 
      ISNULL(dbo.storages.name, '') AS sName,dbo.vw_Products.Factory, dbo.vw_Products.StorageCon,
      dbo.vw_Products.PackStd,ISNULL(dbo.location.loc_id, 0) AS loc_id,ISNULL(dbo.location.loc_name, '') AS loc_name
FROM dbo.vw_Products INNER JOIN
      dbo.storehouse ON 
      dbo.vw_Products.product_id = dbo.storehouse.p_id LEFT OUTER JOIN
      dbo.storages ON dbo.storehouse.s_id = dbo.storages.storage_id LEFT OUTER JOIN
      dbo.location ON dbo.storehouse.location_id = dbo.location.loc_id LEFT OUTER JOIN
      dbo.clients ON dbo.storehouse.supplier_id = dbo.clients.client_id
GROUP BY dbo.vw_Products.code, dbo.vw_Products.Unit3Name, 
      dbo.vw_Products.Unit2Name, dbo.vw_Products.Unit4Name, 
      dbo.vw_Products.LatinName, dbo.vw_Products.ChemName, 
      dbo.vw_Products.EngName, dbo.vw_Products.medtype, dbo.vw_Products.pinyin, 
      dbo.vw_Products.makearea, dbo.vw_Products.trademark, 
      dbo.vw_Products.permitcode, dbo.vw_Products.modal, dbo.vw_Products.standard, 
      dbo.vw_Products.alias, dbo.vw_Products.name, dbo.vw_Products.serial_number, 
      dbo.vw_Products.class_id, dbo.vw_Products.product_id, dbo.storehouse.batchno, 
      dbo.vw_Products.Posyhday, 
      dbo.storehouse.makedate, dbo.storehouse.validdate, dbo.vw_Products.MedName, 
      dbo.vw_Products.Unit1Name, dbo.storehouse.s_id, dbo.storehouse.yhdate, 
      dbo.storehouse.instoretime, dbo.storehouse.supplier_id, dbo.clients.name, 
      dbo.vw_Products.MaintainType, dbo.vw_Products.MaintainDay, 
      dbo.vw_Products.validmonth, dbo.vw_Products.validday, dbo.vw_Products.gspflag, 
      dbo.storages.name,dbo.vw_Products.Factory,dbo.storehouse.location_id, dbo.vw_Products.StorageCon,
      dbo.vw_Products.PackStd,dbo.location.loc_id,dbo.location.loc_name
GO
