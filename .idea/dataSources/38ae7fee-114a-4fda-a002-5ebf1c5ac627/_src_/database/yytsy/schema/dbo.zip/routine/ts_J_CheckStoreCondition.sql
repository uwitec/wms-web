
CREATE	PROCEDURE [ts_J_CheckStoreCondition]
	(@nIsCold 	[int],
	 @nS_ID [int])

AS
  if @nIsCold = 1 
  begin
    if not exists(select 1 from storages where storage_id = @nS_ID and storeCondition = 2)
      Return -1    
  end
  else begin
    if exists(select 1 from storages where storage_id = @nS_ID and storeCondition = 2)
      Return -2    
  end
            
 return 0
GO
