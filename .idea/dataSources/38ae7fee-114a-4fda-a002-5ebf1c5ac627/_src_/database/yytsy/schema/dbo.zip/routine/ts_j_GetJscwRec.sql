/************************************************************

--功能：取得精算财务凭证数据   
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/
  
CREATE	 PROCEDURE [ts_j_GetJscwRec]
	(
	 @szBillid varchar(8000),
	 @szVoucherNo varchar(10),
	 @nMode integer = 0  /*预留,为查询上传数据用,确定数据结构调整后需要修改此处*/
     )
AS
/*Params Ini begin*/
if @nMode is null  SET @nMode = 0
/*Params Ini end*/

 
declare @nBillcount int, @jscwGuid uniqueidentifier, @szbillnumber varchar(100)

select top 1 @szbillnumber = '药易通导入: '+ billnumber from billidx where billid in (select [TYPE] from DecodeStr(@szBillid))
 
select dw.serialnumber as CCode, dw.serialnumber as SCode, km.serialnumber as serial_number,
	   CAST(CASE WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END = 1  and jdmoney>0 and billstates  <> 4 THEN jdmoney 
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END = -1 and jdmoney<0 and billstates  <> 4 THEN -jdmoney
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END = 1  and jdmoney<0 and billstates= 4 THEN jdmoney 
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END = -1 and jdmoney>0 and billstates= 4 THEN -jdmoney
			  ELSE 0 
		     END AS NUMERIC(18,2)) AS Md,
		CAST(CASE WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END =1 and jdmoney <0  and billstates <>4 THEN -jdmoney
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END =-1 and jdmoney >0 and billstates <>4 THEN jdmoney
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END =1 and jdmoney >0  and billstates = 4 THEN  -jdmoney
			  WHEN CASE WHEN SUBSTRING(a.class_id ,6,1) in (1,4) THEN 1 ELSE -1 END =-1 and jdmoney <0 and billstates = 4 THEN jdmoney
			  ELSE 0 
 		     END AS NUMERIC(18,2)) AS Mc,
       /*isnull(case jdflag when 0  then jdmoney end, 0) as md, isnull(case jdflag when 1 then jdmoney end, 0)as mc,*/
	   getdate() as VchDate, ' ' as TypeCode, @szVoucherNo as VoucherNo, ad.billid
	   into #jscwRctmp	     	
from 
  (select a_id, c_id, sum(jdmoney) as jdmoney, jdflag, MAX(billid) billid
    from accountdetail where billid in (select [TYPE] from DecodeStr(@szBillid))
    group by a_id, c_id, jdflag) ad INNER JOIN account a ON ad.a_id = a.account_id
    INNER JOIN billidx idx ON ad.billid = idx.billid
    left join (select * from kmdz where [type] = 'T') km on ad.a_id = km.a_id
    left join (select * from dwdz where [type] = 'T') dw on ad.c_id = dw.c_id


/*调整机构发货单的往来单位*/
  update #jscwRctmp set CCode=d.serialnumber,SCode=d.serialnumber 
  from #jscwRctmp a,company b,billidx c,
  (select A.*,b.name,b.serial_number from dwdz a,clients b where a.c_id=b.client_id and a.type='T') d
  where a.billid=c.billid and c.billtype in (150,152) and c.c_id=b.company_id and b.name=d.name and b.serial_number=d.serial_number


select @nBillcount = count(1) from decodestr(@szBillid)  

if @nBillcount = 1 
begin
  update billidx set jscwguid = [GUID] where billid in (select billid from #jscwRctmp)
   
  select js.*, bi.billnumber as CertificateNo, bi.billdate as VoucherDate, 
		 isnull(dp.serialnumber, '') as DCode, isnull(E.serialnumber, '') as Ecode, 
		 isnull(e.serialnumber, '') as YWCode, bi.GUID as InGUID, @szbillnumber as comment       
  from #jscwRctmp js 
  left join billidx bi on js.billid = bi.billid
  left join (select * from departmentdz where [type] = 'T') dp on bi.department_id = dp.d_id
  left join (select * from EmpDZ where [type] = 'T') e on bi.e_id = e.e_id    
end 
else begin
   set @jscwGuid = NEWID()
   set @szbillnumber = @szbillnumber + ' 等'
   update billidx set jscwguid = @jscwGuid where billid in (select [TYPE] from DecodeStr(@szBillid))

   select *, ' ' as CertificateNo, GETDATE() as VoucherDate, 
		 ' ' as DCode, ' ' as Ecode, ' ' as Ecode,
		 ' ' as YWCode,  @jscwGuid as InGUID, @szbillnumber as comment       
  from #jscwRctmp
end
GO
