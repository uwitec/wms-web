

/* =============================================*/
/* Author:		zjilin	*/
/* Create date: 2013-08-24*/
/* Description:	检查，更新总部代金券标识 */
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_j_CheckUpdateCCflag] 
    @nMode       int,
    @szCCID      varchar(1000) = '',    /*代金券ID 		*/
	@nYid        int,			
	@szUseMan    varchar(200),
	@szErr       varchar(100) output,    /*返回出错的信息　 */
	@nRet        int output
	
AS
   
  if @szCCID = ''
  begin
    set @nRet = 0
    return 0        
  end 
  if @nMode = 0 
  begin
   
    if exists(select 1 from cashcoupon where ccid in (select cast(sztype as int) from dbo.DecodeToStr(@szCCid)) and flag <> 0)
    begin
      select  top 1 @szErr = cashno, @nRet = flag  from cashcoupon where ccid in (select  cast(sztype as int) from dbo.DecodeToStr(@szCCid)) and flag <> 0
      if  @nRet = 1 set  @szErr = @szErr + '已删除'
      if  @nRet = 2 set  @szErr = @szErr + '已停用'
	  if  @nRet = 4 set  @szErr = @szErr + '已作废'
	  if  @nRet = 5 set  @szErr = @szErr + '已用'
	  set @nRet  = -@nRet      
	  return 0
    end
  end
 
/*放在同一过程中处理，避免出现多张券时，部分更新成功，部分更新失败*/
  if @nMode = 1
  begin
	  update Cashcoupon set flag = 5, UseDate = GETDATE(), UseCompany = @nYid, UseMan  = @szUseMan 
	  where ccid in (select  cast(sztype as int) from dbo.DecodeToStr(@szCCid))
	  set @nRet =@@ERROR
	  return 0
  end
  
  set @nRet = 0
  return 0
GO
