/* =============================================*/
/* Author:	yanrui */
/* Create date: 2012-05-16*/
/* Description:	门店抽取要上传数据*/
/* =============================================*/
CREATE PROCEDURE  [dbo].[Ts_Dt_dts_Up]
  @begindate varchar(20) ,  /*开始时间*/
  @enddate   varchar(20)    /*结束数据*/
AS
BEGIN
 set nocount on
 begin tran
  truncate table billdtsidxIN
  truncate table  buymanagebilldtsIN
  /*--写入billdtsidx*/
  insert into billdtsidxIN
  (
  billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty  
  )
  select billid,billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,
         ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,
         auditdate,skdate,jsye,jsflag,(note+'配送退货') as note,summary,invoice,transcount,lasttranstime,GUID,InvoiceTotal,
         InvoiceNO,BusinessType,ArAptotal,SendQTY,GatheringMan,VIPCardID,jsInvoiceTotal,Y_ID,transflag,
         begindate,Enddate,integral,integralYE,B_CustomName1,B_CustomName2,B_CustomName3,
         RetailDate,sendC_id,WholeQty,PartQty  
  from billidx /*a,buymanagebill b*/
  where billtype=21 and billdate>=@begindate and billdate<=@enddate   and billstates=0
  /*-写入明细  */
  insert into buymanagebilldtsIN
  (
    [smb_id],[bill_id],[p_id],[batchno],[quantity],[costprice],[buyprice],[discount],[discountprice],[totalmoney]
    ,[taxprice],[taxtotal],[taxmoney],[retailprice],[retailtotal],[makedate],[validdate],[qualitystatus],[price_id],[ss_id]
    ,[sd_id],[location_id],[supplier_id],[commissionflag],[comment],[unitid],[taxrate],[order_id],[total],[iotag],
    [InvoiceTotal],[thqty],[newprice],[orgbillid],[AOID],[jsprice],[invoice],[invoiceno],[PriceType],[SendQTY],
    [SendCostTotal],[RowGuid],[RowE_id],[YCostPrice],[YGuid],[Y_ID],[instoretime],[comment2],[BatchBarCode],[scomment],
    [batchprice]
  )
  select
    a.[smb_id],a.[bill_id],a.[p_id],a.[batchno],a.[quantity],a.[costprice],a.[buyprice],a.[discount],a.[discountprice],a.[totalmoney]
    ,a.[taxprice],a.[taxtotal],a.[taxmoney],a.[retailprice],a.[retailtotal],a.[makedate],a.[validdate],a.[qualitystatus],a.[price_id],a.[ss_id]
    ,a.[sd_id],a.[location_id],a.[supplier_id],a.[commissionflag],a.[comment],a.[unitid],a.[taxrate],a.[order_id],a.[total],a.[iotag],
    a.[InvoiceTotal],a.[thqty],a.[newprice],a.[orgbillid],a.[AOID],a.[jsprice],a.[invoice],a.[invoiceno],a.[PriceType],a.[SendQTY],
    a.[SendCostTotal],a.[RowGuid],a.[RowE_id],a.[YCostPrice],a.[YGuid],a.[Y_ID],a.[instoretime],a.[comment2],a.[BatchBarCode],a.[scomment],
    a.[batchprice]
    from buymanagebill a , billdtsidxIN b
    where a.bill_id=b.billid
  /*---orgbillid 修改为总公司发货时的明细ID*/
  update buymanagebilldtsIN set orgbillid=y.orgbillid
  from buymanagebilldtsIN x,
     (
     select b.orgbillid,b.smb_id,b.bill_id,b.p_id,a.smb_id as insmb_id
     from buymanagebilldtsIN a,buymanagebill b
     where a.orgbillid=b.smb_id and a.p_id=b.p_id) y
  where x.smb_id=y.insmb_id  
   
 commit Tran    
END
GO
