

/*@bType=0 			上传所有单据*/
/*@bType=1 			只上传未传过的单据*/
/*@bMerage =0		不合并*/
/*@bMerage =1		合并*/
/*@nPostype =0 	加盟版*/
/*@nPostype =1 	自营店*/


/*复制到DTS库*/
create  procedure ts_c_HisToDts
(
	@BeginDate 	datetime,
	@EndDate 	datetime,
	@nE_id      	int,
	@bType		int,
	@bMerage	int,
	@nPostype int
)
/*with encryption*/
as
set nocount on
declare @nPosid int,@nret int,@posguid varchar(50), @nYtype int

exec ts_getsysvalue 'Y_ID',@nPosid out
if @nPosid is null set @nPosid=0

/*
if @nPosid=0 or @nPosid is null 
begin
	return -100
end
*/
exec ts_getsysvalue 'GUID',@Posguid out
/*select @Posguid=sysvalue from sysconfig where [sysname]='GUID'*/

if @Posguid='' or @Posguid is null 
begin
	return -100
end
	truncate table billdtsidx
	truncate table salemanagebilldts
	truncate table buymanagebilldts
	truncate table storemanagebilldts
	truncate table goodscheckbilldts
	truncate table financebilldts
	truncate table tranmanagebilldts
	truncate table tranbilldts
	truncate table tranidxdts
  truncate table priceidxdts
  truncate table pricebilldts
  truncate table ExIntegralmanagebillDTS


begin tran createbill
 	if @nPostype =1 	
	begin	
			if @btype=0 
			begin
				if @bmerage=0
				begin				  
					insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal, VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, dpdate)
					select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, DPdate 	
					from billidx where (billdate between @begindate and @enddate) and billstates='0' and billtype not in (152, 55)
				end else
				begin
					insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, dpdate)
					select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, DPdate	
					from billidx where (billdate between @begindate and @enddate) and billstates='0' and billtype not in (12,13,152,55)
				end
				update billidx set transcount=transcount+1,lasttranstime=getdate()/*convert(varchar(10),getdate(),20)*/
				where billid in  (select billid from billdtsidx)
		
				/*门店缺货通知*/
				
				
				insert into tranidxdts(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
				SendQTY,GatheringMan, y_id)
				select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
				SendQTY,GatheringMan, Y_ID	
				from tranidx where (billdate between @begindate and @enddate) and billstates='3'
		
				update tranidx set transcount=transcount+1,lasttranstime=getdate()/*convert(varchar(10),getdate(),20)*/
				where billid in  (select billid from tranidxdts)
      		
			end
		  else
			begin
				if @bmerage=0
				begin
					insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty,dpdate)
					select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty,DPdate
					from billidx where (billdate between @begindate and @enddate) and billstates='0' and transcount=0 and billtype not in (152, 55)

				end else
				begin
					insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, dpdate)
					select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
					ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
					posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
					SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty, DPdate
					from billidx where (billdate between @begindate and @enddate) and billstates='0' and transcount=0 and billtype not in (12,13,152, 55)
				end
				update billidx set transcount=transcount+1,lasttranstime=getdate()/*convert(varchar(10),getdate(),20)*/
				where billid in  (select billid from billdtsidx)
		
				/*门店缺货通知*/
				
				insert into tranidxdts(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
				SendQTY,GatheringMan, Y_ID)
				select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
				ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
				posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
				SendQTY,GatheringMan, Y_ID
				from tranidx where (billdate between @begindate and @enddate) and billstates='3' and transcount=0
		
				update tranidx set transcount=transcount+1,lasttranstime=getdate()/*convert(varchar(10),getdate(),20)*/
				where billid in  (select billid from tranidxdts)
		
			end
		
		/*销售类单据*/
		/*销售出库单,销售出库退货单,零售,零售退货,委托代销发货,委托代销退货,委托代销结算,销售单,销售退货单,发货单*/
		
			if @bmerage=1
			begin
				insert into salemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
					RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, cxType, location_id2, comment2,batchbarcode,scomment,batchprice,
					factoryid, costtaxprice, costtaxrate, costtaxtotal)
				select smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,invoicetotal ,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
					RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, cxType, location_id2, comment2,batchbarcode,scomment,batchprice,
					factoryid, costtaxprice, costtaxrate, costtaxtotal
				from salemanagebill where bill_id in (select billid from billdtsidx where billtype in (10,11,16,17,110,111,112,32,210,212,211))
				order by smb_id
		
				/*合并零售单和零售退货单*/
				exec @nret=ts_c_merageretailbill @begindate,@enddate,@btype,@nposid,@ne_id
				if @nret<>0 goto error
			end else
			begin
				insert into salemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
					RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, cxType, location_id2, comment2,batchbarcode,scomment,batchprice,
					factoryid, costtaxprice, costtaxrate, costtaxtotal)
				select smb_id,bill_id, p_id, batchno, quantity, costprice, saleprice, discount, discountprice, 
					totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
					qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
					comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
					RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, cxType, location_id2,comment2,batchbarcode,scomment,batchprice,
					factoryid, costtaxprice, costtaxrate, costtaxtotal
				from salemanagebill where bill_id in (select billid from billdtsidx where billtype in (10,11,16,17,12,13,110,111,112))
				order by smb_id
			end
		/*销售类单据*/
			
		
		/*采购类单据*/
		/*采购入库单,采购入库退货单,受托代销收货,受托代销退货,受托代销结算,采购单,采购退货单,收货单, 自营店收货退货*/
			insert into buymanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
				      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, comment2,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
				      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime, comment2,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal
			from buymanagebill where bill_id in (select billid from billdtsidx where billtype in (20,21,24,25,120,121,122,35,220,222,221,163,161))	
			order by smb_id
		/*采购类单据*/
		
		/*库存类单据*/
		/*借出单,借出还回单,借转销售单,生产组装单,报损单,报溢单,成本调价单,同价调拨单,变价调拨单*/
		  		
			insert into storemanagebilldts(smb_id,bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
				     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,invoicetotal,aoid,SendQty,SendCostTotal,
				     RowGuid, RowE_id, Y_ID, instoretime,batchbarcode,scomment,batchprice,
					 factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select smb_id,bill_id, p_id, batchno, quantity, price, totalmoney,costprice, costtotal, retailprice,retailmoney,
				     makedate, validdate, qualitystatus, price_id, ss_id, sd_id, location_id,supplier_id, commissionflag, comment,unitid,location_id2,iotag,total,invoicetotal,aoid,SendQty,SendCostTotal,
				     RowGuid, RowE_id, Y_ID, instoretime,batchbarcode,scomment,batchprice,
					 factoryid, costtaxprice, costtaxrate, costtaxtotal
			from storemanagebill where bill_id in (select billid from billdtsidx where billtype in (30,31,33,34,40,41,42,43,44,45,46,47,48,49,51,141))	
			order by smb_id
		/*库存类单据*/
		
		/*库存盘点单*/
			insert into goodscheckbilldts (smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,aoid, RowGuid, Y_ID, instoretime,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,aoid,RowGuid, Y_ID, instoretime	,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal
			from goodscheckbill where bill_id in (select billid from billdtsidx where billtype =50)	
			order by smb_id
		/*库存盘点单*/
		
		/*钱流单据*/
		/*收款单,付款单,现金费用单,一般费用单,其他收入,固定资产购买,储值单*/
			insert into financebilldts(smb_id,bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,invoicetotal, RowGuid, Y_ID)
			select smb_id,bill_id,a_id, c_id, jftotal, dftotal, comment1, comment2, comment3,invoicetotal, RowGuid, Y_ID
			from financebill where bill_id in (select billid from billdtsidx where billtype in (15,23,60,61,62,63,64,65,66,67,68,69,80,81,82,83,84,90,148))	
			order by smb_id
		/*钱流单据*/

		/*积分兑换单*/
			insert into ExIntegralmanagebillDTS
			(smb_id, billid, p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid,
			batchno,makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal, rowguid, Y_Id, instoretime)
			select smb_id, billid, p_id, u_id, s_id, ColorID, SizeID, quantity, costprice, costTotal, price, TotalMoney, IntegralMoney, IntegRalTotal, status, comment, RowTag, Aoid,
			batchno,makedate,validdate,location_id,supplier_id,commissionflag,SendQTY,SendCostTotal, rowguid, Y_Id, instoretime
			from ExIntegralmanagebill where billid in (select billid from billdtsidx where billtype in (149))
			order by smb_id 
		/*积分兑换单*/
		
		/*缺货通知单*/
		
		insert into tranbilldts(smb_id,bill_id,p_id,quantity,retailprice,retailmoney,comment,unitid, RowGuid, Y_ID)
			select smb_id,bill_id,p_id,quantity,retailprice,retailmoney,comment,unitid, RowGuid, Y_ID
			from tranbill where bill_id in (select billid from tranidxdts where billtype in (52))
			order by smb_id
			
			update billdtsidx set posid=@nposid,billstates='2',posguid=@posguid
			update tranidxdts set posid=@nposid,posguid=@posguid,billstates='2'

		/*门店调价单*/
  					
  	if exists(select 1 from tasklistup where tranflag <> 2 and TableType = 'O' and trantype =0)/*调价单据*/
  	begin
  	/*索引 */
  	  insert into priceidxdts(billid,billdate, billnumber, billtype, e_id, auditman, inputman, 
  		period, billstates, order_id, department_id, 
  		posid, region_id, auditdate, note, summary,guid,Y_ID)
  	  select billid,billdate, billnumber, billtype, e_id, 0, inputman, 
  		period, 2, order_id, department_id, 
  		posid, region_id, auditdate, note, summary,guid,y_id
   		from priceidx where guid in (select billguid from tasklistup where tranflag <> 2 and TableType = 'O' and trantype =0)
  		/*调价单*/
  	  insert into pricebilldts([id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,Y_ID,oldretailprice)
  	  select [id],bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,Y_ID,oldretailprice
  	    from pricebill where bill_id in (select billid from priceidxdts where billtype = 140)
  	    order by [id]
  
  	  update tasklistUp set lasttrandate=getdate(),trancount=trancount+1,tranflag= 1 
                            where billguid in (select guid from priceidxdts where billtype = 140) and TableType = 'O' and trantype =0
    end

	end else if @nPostype =0 /*	加盟版*/
	begin

			insert into billdtsidx(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty)
			select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID, Y_ID, integral, integralYE, B_CustomName1, B_CustomName2, B_CustomName3, sendC_id,WholeQty,PartQty
			from billidx where (billdate between @begindate and @enddate) and billstates='0' and billtype in (161)

		/*机构收货退货单*/
			insert into buymanagebilldts(smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
				      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select smb_id,bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				      totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				      qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				      comment,unitid,taxrate,order_id,total,iotag,invoicetotal,jsprice,aoid,invoice,invoiceno,PriceType,SendQTY,SendCostTotal,
				      RowGuid, RowE_id, YCostPrice, YGuid, Y_ID, instoretime,batchbarcode,scomment,batchprice,
					  factoryid, costtaxprice, costtaxrate, costtaxtotal
			from buymanagebill where bill_id in (select billid from billdtsidx where billtype in (161))	
			order by smb_id

			insert into tranidxdts(billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
			SendQTY,GatheringMan, Y_ID)
			select billid,billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney, araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceno,businesstype,guid,
			SendQTY,GatheringMan, Y_ID	
			from tranidx where (billdate between @begindate and @enddate) and billstates='3'

		/*缺货通知单		*/
			insert into tranbilldts(smb_id,bill_id,p_id,quantity,retailprice,retailmoney,comment,unitid, RowGuid, Y_ID)
			select smb_id,bill_id,p_id,quantity,retailprice,retailmoney,comment,unitid,RowGuid, Y_ID
			from tranbill where bill_id in (select billid from tranidxdts where billtype in (52))
			order by smb_id
			
			update billdtsidx set posid=@nposid,billstates='2',posguid=@posguid
			update tranidxdts set posid=@nposid,posguid=@posguid,billstates='2'
	end
     delete TaskListUp where trantype = 0 and tranflag =  2 and TableType in ('A', 'P', 'V')
commit tran createbill

return 0
error:
	rollback tran createbill
	return -1
GO
