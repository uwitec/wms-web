create procedure Ts_E_UpdateFristPdQty
  @Pdidx integer=0,
  @PdStatus integer=0
as
begin
  if @PdStatus=1 /*更新初盘数量*/
  begin
      update pdplan set WMS_FristPdQty=b.quantity,  WMS_PdStatus=1 from pdplan a ,
       (select b.* from billdraftidx a inner join GoodsCheckBillDrf b on a.billid=b.bill_id where a.WMS_PdStatus=1) b 
      where  a.p_id=b.p_id AND
                a.batchno=b.batchno AND a.supplier_id=b.supplier_id  
				AND a.commissionflag=b.commissionflag AND a.costprice=b.costprice and a.instoretime=b.instoretime
				AND a.s_id = b.ss_id  and a.costtaxprice=b.costtaxprice and a.factoryid = b.factoryid 
				and a.makedate = b.makedate and a.validdate = b.validdate and a.Y_ID = b.Y_ID
				and a.pdidx=@Pdidx
				
	   /*更新复盘数量*/
       update pdplan set WMS_CheckPdQty=b.quantity  from pdplan a ,
      (select b.*  from billdraftidx a inner join GoodsCheckBillDrf b on a.billid=b.bill_id where a.WMS_PdStatus=2) b 
       where    a.p_id=b.p_id AND
                a.batchno=b.batchno AND a.supplier_id=b.supplier_id 
				AND a.commissionflag=b.commissionflag AND a.costprice=b.costprice and a.instoretime=b.instoretime
				AND a.s_id = b.ss_id  and a.costtaxprice=b.costtaxprice and a.factoryid = b.factoryid 
				and a.makedate = b.makedate and a.validdate = b.validdate and a.Y_ID = b.Y_ID
				and a.pdidx=@Pdidx		
  end
  if @PdStatus=2  /*更新初盘数量后，在更新复盘数量*/
  begin
      /*更新初盘数量*/
      update pdplan set WMS_FristPdQty=b.quantity, WMS_PdStatus=1  from pdplan a ,
       (select b.* from billdraftidx a inner join GoodsCheckBillDrf b on a.billid=b.bill_id where a.WMS_PdStatus=1) b 
       where  a.p_id=b.p_id AND
                a.batchno=b.batchno AND a.supplier_id=b.supplier_id  
				AND a.commissionflag=b.commissionflag AND a.costprice=b.costprice and a.instoretime=b.instoretime
				AND a.s_id = b.ss_id  and a.costtaxprice=b.costtaxprice and a.factoryid = b.factoryid 
				and a.makedate = b.makedate and a.validdate = b.validdate and a.Y_ID = b.Y_ID
				and a.pdidx=@Pdidx		
      update pdplan set WMS_PdStatus=2 where pdidx=@Pdidx and WMS_PdStatus<>2 and WMS_FristPdQty-quantity<>0
  end
end
GO
