Create  procedure Ts_L_InUpIntegralDay
( 
  @I_id   [int],
  @daystr   varchar(50) 
 )  
AS
   /*-写入数据   */
   insert into DayIntegral
	(
	  [ct_id],    
      [day],
      [Integral],
      [I_id],
      [Daystr]
	)						
	Values
	(	
       0,
       0,
       0,
       @I_id,
       @daystr 		    	    
    )
GO
