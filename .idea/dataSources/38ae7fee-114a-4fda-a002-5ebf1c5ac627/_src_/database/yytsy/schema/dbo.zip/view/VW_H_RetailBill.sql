
CREATE VIEW [dbo].[VW_H_RetailBill]
AS
SELECT     b.smb_id, b.bill_id, 0 AS a_id, b.p_id, b.batchno, b.quantity, b.costprice, b.saleprice AS price, b.discount, b.discountprice, b.totalmoney, b.total, 
                      b.taxprice, b.taxtotal, b.taxmoney, b.retailprice, b.retailtotal, b.makedate, b.validdate, b.qualitystatus, 0 AS order_id, b.orgbillid, 0 AS JSPrice, b.AOID, 
                      b.price_id, b.ss_id AS s_id, b.sd_id AS s_id2, b.location_id AS l_id, b.supplier_id AS b_id, b.commissionflag, b.comment, b.unitid, b.taxrate, 0 AS l_id2, 
                      0 AS iotag, p.Code, p.name, p.standard, p.modal, p.makearea, p.Factory, p.BulidNo, p.RegisterNo, p.comment AS Pcomment, p.permitcode, p.trademark,
                       p.medtype, p.UNITRATE2, p.UNITRATE3, p.UNITRATE4, p.unit1, p.unit2, p.unit3, p.unit4, p.ValidMonth, p.validday, p.costmethod, p.Unit1_id, p.Unit2_id, 
                      p.Unit3_id, p.Unit4_id, p.otcflag, p.alias, p.PackStd, p.StorageCon, p.PcName, p.pcCode, ISNULL(l.l_name, '') AS location, '' AS LOCATION2, 
                      ISNULL(s.s_name, '') AS STORAGE, '' AS STORAGE2, 0 AS INVOICETOTAL, 0 AS COMEDATE, 0 AS COMEQTY, '' AS SN, '' AS Vendor, 0.0000 AS ThQTY, 
                      0.0000 AS SendQTY, 0.0000 AS SendCostTotal, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, p.Custompro5, b.PriceType, b.RowE_id, 
                      ISNULL(e.name, '') AS RowEName, NEWID() AS YGUID, '0' AS YCOSTPRICE, '0' AS INVOICENO, b.Y_ID, b.instoretime, 0 AS cxtype, 
                      ISNULL(p.Wholerate, 1) AS Wholerate, ISNULL(s.WholeFlag, 0) AS wholeflag, 0 AS wholeflag2, '' AS comment2, b.BatchBarCode, b.scomment, 
                      b.batchprice, 0 AS newprice, b.CxGuid
FROM         dbo.RetailBill AS b INNER JOIN
                      dbo.vw_b_Products AS p ON b.p_id = p.p_id LEFT OUTER JOIN
                      dbo.vw_b_Storage AS s ON b.ss_id = s.s_id LEFT OUTER JOIN
                      dbo.vw_b_location AS l ON b.location_id = l.l_id LEFT OUTER JOIN
                      dbo.employees AS e ON b.RowE_id = e.emp_id
where aoid <> 8
UNION ALL
SELECT     b.smb_id, b.bill_id, 0 AS a_id, b.p_id, b.batchno, b.quantity, b.costprice, b.saleprice AS price, b.discount, b.discountprice, b.totalmoney, b.total, 
                      b.taxprice, b.taxtotal, b.taxmoney, b.retailprice, b.retailtotal, b.makedate, b.validdate, b.qualitystatus, 0 AS order_id, b.orgbillid, 0 AS JSPrice, b.AOID, 
                      b.price_id, b.ss_id AS s_id, b.sd_id AS s_id2, b.location_id AS l_id, b.supplier_id AS b_id, b.commissionflag, b.comment, p.unit_id, b.taxrate, 0 AS l_id2, 
                      0 AS iotag, p.Code, p.name, '' as [standard], p.modal, '' as makearea, '' as factory, '' as BulidNo, '' as RegisterNo, 
                      p.comment AS Pcomment, '' as permitcode, '' as trademark,'' as medtype,
   0 as unitrate2,  0 as unitrate3,  0 as unitrate4,  unitname as unit1,  '' as unit2,  '' as unit3,  '' as unit4,  '' as validmonth,  '' as validday,  3 as costmethod,
   p.unit_id as unit1_id, '' as Unit2_id,  '' as Unit3_id,  '' as Unit4_id,  '' as otcflag,p.alias,  '' as PackStd,  '' as StorageCon, '' as PcName, '' as PcCode,
  ISNULL(l.l_name,'') as location,
  '' as LOCATION2,
  ISNULL(s.s_name,'') as STORAGE,
  '' as STORAGE2,
  0 as INVOICETOTAL,
  0 as COMEDATE,
  0 as COMEQTY,
  '' as SN,
  '' as Vendor,
  0.0000  as  ThQTY, 0.0000  as SendQTY, 0.0000  as SendCostTotal
  , '' as Custompro1, '' as Custompro2, '' as Custompro3, '' as Custompro4, '' as Custompro5
  ,b.PriceType,b.RowE_ID, ISNULL(e.[name],'') as RowEName,  NewID() as YGUID, '0' as YCOSTPRICE, '0' as INVOICENO
  ,b.Y_ID,b.InStoreTime, 0 as cxtype,
  1 as Wholerate,
  isnull(s.wholeflag,0)wholeflag,
  0 as wholeflag2, '' as comment2,b.batchbarcode,b.scomment,b.batchprice,0 as newprice, b.cxGuid
FROM         dbo.RetailBill AS b INNER JOIN
                      dbo.VW_H_SpecialProducts AS p ON b.p_id = p.product_id LEFT OUTER JOIN
                      dbo.vw_b_Storage AS s ON b.ss_id = s.s_id LEFT OUTER JOIN
                      dbo.vw_b_location AS l ON b.location_id = l.l_id LEFT OUTER JOIN
                      dbo.employees AS e ON b.RowE_id = e.emp_id
where aoid = 8
GO
