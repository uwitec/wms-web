
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-1-23*/
/* Description:	*/
/* =============================================*/
CREATE FUNCTION FN_BigIntPower 
(
	@nValue bigint,
	@y int
)
RETURNS bigint
AS
BEGIN
	DECLARE @Result bigint

	SET @Result = 1

	WHILE @y > 0
	BEGIN
		SET @Result = @Result * @nValue
		SET @y = @y - 1
	END

	RETURN @Result

END
GO
