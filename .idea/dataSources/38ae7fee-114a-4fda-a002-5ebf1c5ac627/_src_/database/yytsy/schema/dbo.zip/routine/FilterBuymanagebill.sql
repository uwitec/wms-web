
CREATE FUNCTION FilterBuymanagebill(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     bb.smb_id, bb.bill_id, bb.p_id, bb.batchno, bb.quantity, CASE WHEN dbo._GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN bb.costprice ELSE 0 END as costprice, bb.buyprice, bb.discount, bb.discountprice, bb.totalmoney, bb.taxprice, bb.taxtotal,
							   bb.taxmoney, bb.retailprice, bb.retailtotal, bb.makedate, bb.validdate, bb.qualitystatus, bb.price_id, bb.ss_id, bb.sd_id, bb.location_id, bb.supplier_id, 
							  bb.commissionflag, bb.comment, bb.unitid, bb.taxrate, bb.order_id, bb.total, bb.iotag, bb.InvoiceTotal, bb.thqty, bb.newprice, bb.orgbillid, bb.jsprice, 
							  bb.AOID, bb.invoice, bb.invoiceno, bb.BatchBarCode, bb.SendQTY, bb.SendCostTotal, bb.RowGuid, bb.RowE_id, bb.YCostPrice, bb.YGuid, bb.Y_ID, 
							  bb.transflag, bb.instoretime, bb.PriceType, bb.comment2, bb.scomment, bb.batchprice, bb.Conclusion
		FROM         dbo.products AS p INNER JOIN
							  dbo.buymanagebill AS bb ON p.product_id = bb.p_id
GO
