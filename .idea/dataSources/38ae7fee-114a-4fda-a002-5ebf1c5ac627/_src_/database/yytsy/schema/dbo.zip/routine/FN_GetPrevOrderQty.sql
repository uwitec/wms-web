
/* =============================================*/
/* Author:		jfyan*/
/* Create date: 2016-8-29*/
/* Description:	得到最近一次采购信息(含未审核单据)*/
/* select  dbo.FN_GetPrevOrderQty(13056)*/
/* =============================================*/
CREATE FUNCTION FN_GetPrevOrderQty 
(
	@p_id int
)
RETURNS varchar(800)
AS
BEGIN
	DECLARE @ReturnStr varchar(800)
	set @ReturnStr=''
	if exists(select 1 from sysconfigtmp where sysname='PrevOrderQty' and sysvalue='1')
	begin
      select top 1 @ReturnStr='订单日期：'+CONVERT(VARCHAR(10),a.billdate,121)
							  +'、采购人员：'+ISNULL(c.name,'')
							  +'、供应商：'+ISNULL(d.name,'')
							  +'、数量：'+cast(cast(b.quantity as numeric(25,4)) as varchar)
							  +'、单价：'+cast(cast(b.taxprice as numeric(25,4)) as varchar)
							  +'、金额：'+cast(cast(b.taxtotal as numeric(25,4)) as varchar)
							  +'、订单状态：'+Case a.billstates when 0 then '已完成' 
															    when 2 then '未审核' 
															    when 3 then '已审核未完成' 
											  else '' 
											  end
      from orderidx a inner join OrderBill b
           on a.billid=b.bill_id
           left join employees c 
           on a.inputman=c.emp_id 
           left join clients d 
           on a.c_id=d.client_id
      where a.billtype=22 and b.p_id=@p_id
      order by a.billid desc 
      DECLARE @unitid INT 
      SELECT @unitid=unit1_id FROM products WHERE product_id=@p_id
      select top 1 @ReturnStr=@ReturnStr
                              +'、最近进价：'+cast(cast(taxprice as numeric(25,4)) as varchar)
      from buypricehis
      WHERE p_id=@p_id AND unit_id=@unitid
      order by ModifyDate desc 
      select @ReturnStr=@ReturnStr
                        +'、最低进价：'+cast(cast(MIN(taxprice) as numeric(25,4)) as varchar)
      from buypricehis
      WHERE p_id=@p_id AND unit_id=@unitid
      select @ReturnStr=@ReturnStr
                        +'、库存量：'+cast(cast(SUM(quantity) as numeric(25,4)) as varchar)
      from storehouse
      WHERE p_id=@p_id
	end 
	RETURN @ReturnStr

END
GO
