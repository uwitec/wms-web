
CREATE VIEW dbo.vw_GSPIndex
AS

SELECT a.GSPID, a.GSPType, a.BillCode, a.BillE, a.BillDate, a.Comment, a.CheckState, a.[sign], a.GspVer,a.Y_id,a.szid,a.szid2,a.P_ID,
       checkCase = CASE a.CheckState WHEN 0 THEN '' WHEN 2 THEN '√' WHEN 1 THEN '⊙'
       END,a.checkflag, 
       t.name as CGspType,        
        c.name AS YName,
        a.billid, a.BillType
FROM dbo.GspTable a 
     inner join  company c on a.Y_ID = c.company_id
     inner join gspvchtype t on a.gsptype = t.gsptype
GO
