CREATE proc ts_z_PriceCompare
(
  	@y_id  varchar(8000) /*机构id 拼接(1,2,3)*/
)
as
	declare @sql varchar(8000) 
	declare @sql02 varchar(8000)
	declare @cpid int
	declare @y_id02 varchar(8000)
	declare @y_id01 varchar(8000)
	declare @companyid int
	declare @cpname varchar(256)
	/*创建临时表存放所有竞争对手*/
	create table #tempCompete
	(
		cpid int, /*id*/
		cpname varchar(256)/*竞争对手名*/
	)
	
    insert into #tempCompete  /*把所有竞争对手查询到临时表*/
    select min(cp_id) as cpid,CompeteName as cpname from CompetePrice group by CompeteName 
    
    /*select company_id from company where company_id in ( @y_id01)*/
    set @y_id01 = @y_id
    set @y_id02 = '(2,'+@y_id+')' 
    set @sql02=''
    set @sql = 'select p.product_id as p_id,  p.product_id as p_id2 '
    
    /*游标循环开始，对竞争对手名称表循环，行转列，有多少行就转为多少列*/
    declare MyCursor cursor for (select cpid,cpname from #tempCompete)
    open mycursor;
    Fetch next from mycursor into @cpid, @cpname; /*先把第一行数据填入到临时变量 */
    while @@FETCH_STATUS = 0  /*循环添加列*/
    begin
		set @sql = @sql + ',isnull(cp' + cast(@cpid as varchar) + '.rprice,0)as rprice'+cast(@cpid as varchar)  /*+', ISNULL(cp' +@cpid +'.CompeteName, '''') as CompeteName'*/
		set @sql02 = @sql02 + ' left join '
	      +'((select c.p_id,rprice,c.CompeteName from CompetePrice c inner join '
	      +'(select MAX(cp_id) as cpid,P_id,CompeteName From CompetePrice where Y_id in '+@y_id02+' group by P_id,CompeteName) a on c.cp_id=a.cpid '
	      +'where a.CompeteName = '+''''+@cpname+''''+')) cp'+cast(@cpid as varchar)+' on p.product_id=cp'+cast(@cpid as varchar)+'.P_id '  /*竞争对手店*/
		Fetch next from mycursor into @cpid, @cpname; 
    end
	close mycursor;
	deallocate mycursor;
	  
    declare MyCursor02 cursor for (select szTYPE from dbo.DecodeToStr(@y_id01)) /*游标循环去读取各个分支机构的零售价和会员价*/
    open mycursor02;  
    Fetch next from mycursor02 into @companyid;
    while @@FETCH_STATUS = 0
    begin
      if EXISTS(SELECT company_id FROM COMPANY WHERE company_id = @companyid)
      BEGIN
		if @companyid <> 2 /*总部单独查询 在price表，门店在posprice表*/
		begin
			set @sql = @sql + ',isnull(pos'+cast(@companyid as varchar)+'.retailprice,0) as posrprice'+cast(@companyid as varchar)+', isnull(pos'+cast(@companyid as varchar)+'.price4,0) as posmprice'+cast(@companyid as varchar) /*+ ','+@companyid+' as posid'+@companyid 供应商id*/
			set @sql02 = @sql02 + ' left join '
				+ '(select * From PosPrice where Y_ID = ' +cast(@companyid as varchar) +') pos' +cast(@companyid as varchar)+' on p.product_id=pos'+cast(@companyid as varchar)+'.p_id'
		end
	  END
	  Fetch next from mycursor02 into @companyid;
    end
	close mycursor02;
	deallocate mycursor02;    
	
	set @sql=@sql+',isnull(przb.retailprice,0) as zbrprice, isnull(przb.price4,0) as zbmprice From products p ' +@sql02/*, 2 as zbid From products p */
	  /*+' left join price przb on p.product_id=przb.p_id where p.product_id=4316' --总公司的零售价和会员价*/
	  +' left join price przb on p.product_id=przb.p_id where 1=1' /*总公司的零售价和会员价*/
	/*print @sql*/
	exec(@sql)  
	
    drop table #tempCompete /*删除临时表*/
GO
