create procedure ts_e_StoreWMSUpdateBaseInfo
 @id integer=0,/*表示库区或者区域或者货位id*/
 @S_id  integer=0,
 @StoreKQSerial varchar(100),
 @StoreKQName varchar(100),
 @KQType     integer=0,
 @KQQuanFlag integer=0,
 @KQPickType integer=0,
 @KQPrintType integer=0,
 @RegionCode varchar(400)='',  /*区域功能编号*/
 @RegionComent varchar(400)='', /*区域功能说明*/
 @SType       varchar(10) /*'KQ' 表示库区，'QY' 表示区域，'HW'表示货位*/
as 
begin
	 if @SType='KQ'
	 begin
		  update stockArea set serial_number=@StoreKQSerial,name =@StoreKQName,s_id=@S_id,
		        comment=''  where sa_id=@id
		  update WMSStockArea set  SAType=@KQType,SAQuantityType=@KQQuanFlag,SAPickType=@KQPickType,SAPrintType=@KQPrintType
		         where sa_id=@id
	 end
	 if @SType='QY'
	 begin
		  update WMSRegion set serial_number=@StoreKQSerial,name =@StoreKQName,Store_KQ_ID=@S_id,
		         RegionCode=@RegionCode, RegionComent=@RegionComent
		        where id=@id
	 end
end
GO
