/************************************************************

--功能： 
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE  PROCEDURE [ts_j_setUsefiliale]
 (
  @nUse int =0,
  @nDataMode int=1 
        )
AS 
/*Params Ini begin*/
if @nUse is null  SET @nUse = 0
if @nDataMode is null  SET @nDataMode = 1
/*Params Ini end*/

declare  @szUse varchar(1), @szDataMode varchar(1)
set @szUse = cast(@nUse as varchar(1)) 
set @szDataMode = cast(@nDataMode as varchar(1)) 

if not exists (select * from dbo.sysconfig where [sysname]='isUsefiliale')
begin
  Insert dbo.sysconfig([sysname],sysvalue,comment,sysflag)
                Values('isUsefiliale',@szUse,'',0)
end
else
  update sysconfig set sysvalue = @szUse where upper([sysname]) ='ISUSEFILIALE'
  
  
if not exists (select * from dbo.sysconfig where [sysname]='PosDataMode')
begin
  Insert dbo.sysconfig([sysname],sysvalue,comment,sysflag)
                Values('PosDataMode',@szDataMode,'',1)
end
else
  update sysconfig set sysvalue = @szDataMode where upper([sysname]) ='POSDATAMODE' 

if @szUse in (0,2,4) 
  exec ts_j_setZBAccount
GO
