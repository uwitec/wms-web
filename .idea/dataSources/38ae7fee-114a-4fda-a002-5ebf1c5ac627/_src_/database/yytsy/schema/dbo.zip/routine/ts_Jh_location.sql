
/******************************************

福建定制   发货区域库 货位 显示

创建日期 2013-03-02

作者：yanrui

********************************************/
CREATE PROCEDURE ts_Jh_location
(
  @szfilter varchar(50)
)
as 
begin
  if @szfilter is null set @szfilter = ''
  select loc_id into #loc from location where loc_code like '%'+@szfilter+'%' or loc_name like '%'+@szfilter+'%'
  delete from #loc where loc_id in(select distinct  VIPCardID from billidx  where billtype=10 and billstates not in (1,4))
  delete from #loc where loc_id in(select distinct  convert(int,B_CustomName1) from billdraftidx where billtype=254 and VIPCardID in(5))
  select b.loc_id,b.s_id,b.loc_code,b.loc_name,b.loc_comment,b.deleted
  ,b.ModifyDate,b.Shelfid,b.loctype,'发货货位' as loctypename,a.name as sName,
  '' as Pname,'' as serial_number,'' as [standard],'' as makearea
  ,'是' as maxQty,0 as maxRealQty
  from  storages a,location b
  where  (a.name like '%发货区域库%') and a.Y_ID=2 and b.loctype=1 
    and b.deleted=0  and a.storage_id=b.s_id 
    and (@szfilter = '' or b.loc_id in (select loc_id from #loc))
  order by b.loc_name
    /*and b.loc_id not in(select distinct  VIPCardID from billidx  where billtype=10 and billstates not in (1,4))*/
    /*and b.loc_id not in(select distinct  convert(int,B_CustomName1) from billdraftidx where billtype=254 and VIPCardID in(5))*/
	drop table #loc
end
GO
