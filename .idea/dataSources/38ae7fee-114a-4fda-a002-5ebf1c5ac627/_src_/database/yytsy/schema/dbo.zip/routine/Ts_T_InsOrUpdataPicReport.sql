
create proc [dbo].[Ts_T_InsOrUpdataPicReport]
(   @Mrid      int,								/*0为第一次添加，*/
    @RepNo  varchar (200),
    @p_id  [int] ,
	@rpn_id [int] ,
	@inputTime varchar(100) ,
	@repname varchar(100),
	@Pathname varchar(100),      
	@c_name     varchar(120),
	@RepType  varchar(80),
	@validdate  varchar(100),
	@indexid  [int]
)
as

if (@Mrid  > 0) or (@Mrid = 0)
begin
    if exists(select 1 from  PicReport  where  (p_id=@p_id) and (rpn_id <> @rpn_id) and (RepNo =@RepNo) and (RepType =@RepType)   )
	begin
	  RAISERROR('证书编号,有重复！',16,1)
	  return-1
	end
	
	select @indexid =ISNULL(MAX(indexid),0) from PicReport where (rpn_id = @rpn_id) and (p_id = @p_id)
	set @indexid = @indexid + 1
	
	INSERT INTO [dbo].[PicReport]
	(
	 [repNo],
	 [p_id],
	 [rpn_id],
	 [repname],
	 [inputTime],
	 [pathName],
	 [c_name],
	 [RepType],
	 [validdate],
	 [indexid]
	)
	Values
	(
	 @repNo ,   
	 @p_id ,
	 @rpn_id,    	 
	 @repname,
     @inputTime,
	 @Pathname, 
	 @c_name,
	 @RepType,
	 @validdate,
	 @indexid
	)
end else
begin
  if exists(select 1 from  PicReport  where  (repNo=@repNo) and (rpn_id = @rpn_id) and (pr_id<>@Mrid) and (RepType =@RepType))
begin
  RAISERROR('证书编号,有重复！',16,1)
  return-1
end
  update PicReport 
  set [repNo]  = @repNo,
	  [p_id]   = @p_id,
	  [rpn_id] =@rpn_id,
	  [repname]=@repname,
	  [pathname] = @Pathname,
	  [c_name] = @c_name,
	  [RepType] = @RepType,
	  [validdate] =	@validdate 
  where (p_id =@Mrid) and (RepType =@RepType) 

end
GO
