/************************************************************

--功能：设置下载时间列表
--创建人：Zhou JiLin 
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE [ts_j_SetDownTimeList]
	(
	  @szTable varchar(100),
	  @ny_id  int,
	  @nflag  int = 0,
	  @nRet   int = 0
     )
AS 
/*Params Ini begin*/
if @nflag is null  SET @nflag = 0
if @nRet is null  SET @nRet = 0
/*Params Ini end*/
  set @nRet = -1
  if @ny_id = 0 
  begin
   set @nRet = 0  
   return 0
  end 
  
  if @nflag = 1 
  begin
    update DownTimeList set maxcount = lastMaxCount where Y_ID  = @ny_id
    set @nRet =0
    return 0
  end 
   
  declare @szSql varchar(8000)
 
  if not exists(select 1 from DownTimeList where tablename = @szTable and Y_ID = @ny_id)
    insert into downtimelist(tablename, maxcount, lastMaxCount, inmaxcount, Y_ID)
      values(@szTable, 0, 0, 0, @ny_id) 
  
  set @szSql = 'declare @szCount varchar(50) '
  set @szSql = @szSql+ 'select @szCount = cast(CAST(max(modifydate) as int) as varchar)  from '+@szTable
  set @szSql = @szSql+ ' if @szCount is not null '
  set @szSql=  @szSql + ' update DownTimeList set lastMaxCount = @szCount where y_id = '+ CAST(@ny_id as varchar) 
               + ' and tablename = ''' + @szTable + CHAR(39)
               
  /*print (@szSql)               */
  exec(@szSql)
  set @nRet = 0                
  return 0
GO
