
Create procedure ts_t_ControlQuery
( @BeginDate  DATETIME=0,
  @EndDate    DATETIME=0,
  @Billcode   varchar(100)=''  
)
AS
declare  @corporationCode  varchar(100)        
 select  @corporationCode = sysvalue  from sysconfig where  [sysname]='companycode'
if @Billcode='' 
begin
 select BC.[billcode], @corporationCode as corporationCode,B.[billnumber],convert(varchar(10),B.[billdate],112) billdate, C.[serial_number] as client_num, C.[name], C.[address], dbo.TrsCode(B.[billtype]) as companyType, ' ' as syspid, P.[serial_number] as Product_num,SB.[batchno],SB.[Quantity],convert(varchar(10),SB.makedate,112) makedate,convert(varchar(10),SB.validdate,112) validdate,' ' as comment 
          from billidx  B
	     left join   clients  C  on  B.[c_id]=C.[client_id] and C.[deleted]<>1
	         left join  billcode  BC  on  B.[billid]=BC.[billid] and BC.[flag]=1
	                 left join buymanagebill BM  on  B.[billid]=BM.[bill_id]
	                      left join  salemanagebill  SB on B.[billid]=SB.[bill_id]  
                                     left join products P on P.[product_id]=SB.[p_id]        
                                     where  B.[billtype] in (10,11)
                                            and (B.billdate  between @BeginDate and  @EndDate)
                                            and B.billstates=0
                                            and BC.[billcode] is not null and BC.[billcode]<>''
                                            and P.[controlyard]=1
end
else
begin
  select BC.[billcode], @corporationCode as corporationCode,B.[billnumber],convert(varchar(10),B.[billdate],112) billdate, C.[serial_number] as client_num, C.[name], C.[address], dbo.TrsCode(B.[billtype]) as companyType,' ' as syspid, P.[serial_number] as Product_num,SB.[batchno],SB.[Quantity],convert(varchar(10),SB.makedate,112) makedate,convert(varchar(10),SB.validdate,112) validdate,' ' as comment 
          from billidx  B
	     left join   clients  C  on  B.[c_id]=C.[client_id] and C.[deleted]<>1
	         left join  billcode  BC  on  B.[billid]=BC.[billid] and BC.[flag]=1 and BC.[billcode] like @Billcode+'%'
	                 left join buymanagebill BM  on  B.[billid]=BM.[bill_id]
	                      left join  salemanagebill  SB on B.[billid]=SB.[bill_id]
                                    left join products P on P.[product_id]=SB.[p_id]  
                                     where  B.[billtype] in (10,11)
                                            and ( B.billdate  between @BeginDate and  @EndDate )
                                            and B.billstates=0
                                            and BC.[billcode] is not null and BC.[billcode]<>''
                                            and P.[controlyard]=1
end
GO
