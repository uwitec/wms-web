 create procedure ts_e_SaleCheckMx
   @BeginDate  varchar(100) ,   /*开始日期*/
   @EndDate    varchar(100),    /*结束日期*/
   @AduitDate  varchar(100),    /*过账日期*/
   @k_name     varchar(100),    /*仓库名称*/
   @k_id       int,             /*仓库ID*/
   @p_name     varchar(100),    /*商品名称*/
   @p_id       int,             /*商品ID*/
   @c_name     varchar(100),    /*往来单位名称 */
   @C_id       int,             /*往来单位ID*/
   @input_name   varchar(100),  /*业务员名称 */
   @input_id     int,           /*业务员ID*/
   @jsr_name     varchar(100),  /*经手人名称 */
   @jsr_id       int,           /*经手人ID*/
   @billnumber   varchar(100),  /*单据编号*/
   @Supplier_name varchar(100), /*主供应商名称  */
   @Supplier_id  int,           /*主供应商ID*/
   @batchno       varchar(100), /*批号*/
   @factory_name varchar(100),  /*生产厂家名称*/
   @factory_id   int,           /*生产厂家ID*/
   @makearea     varchar(100),  /*产地*/
   @YPtype       varchar(100),  /*药品类别*/
   @Zone_name    varchar(100),  /*片区名称*/
   @Zone_id      int,           /*片区*/
   @ifBlurcheck  varchar(100),  /*是否模糊查询*/
   @vchstr       varchar(100),
   @StrBusinessType  varchar(100), /*判断赠送状态*/
   @szIDP       varchar(8000)   /*过滤商品类别*/
 as
    DECLARE @info_ID INT 
    DECLARE @ColName VARCHAR(100)
    DECLARE @szSql varchar(2000)
    DECLARE @classid varchar(100)
    CREATE TABLE #PORDUCTS ([p_id] [int] NOT NULL DEFAULT(0))
   
    if @szIDP<>'' 
    begin 
            /*获取对应属性ID*/
            select distinct @info_ID=Category_id  from customCategory where id in (select  szTYPE from  DecodeToStr(@szIDP))
            /*zjx.通过选择自定义类别id的字符串获取class_ID字符串串*/
			SELECT @classid = dbo.GetCateClassids(@szIDP)  
			/*获取横向表具体那列*/
            set @ColName = dbo.GetColName(@info_ID,'ProductCategory')
            /*根据所选择的类别ID找出所关联的商品*/
		    set @szSql =  'INSERT INTO #PORDUCTS(p_id) ' +
			'select p.product_id from products p,ProductCategory c where p.product_id = c.P_id and c.' + @ColName + 
			' in (select sztype  from DecodetoStr(''' +@classid +'''))'  
		    exec (@szSql)
    end
 
 set @StrBusinessType = @StrBusinessType + ',5'
 begin    
		 if @ifBlurcheck='Blur'
		 begin
		       select a.billid,a.billtype, c.Comment as billVchtype,a.billdate,a.auditdate as GzDate,a.billnumber,
		             case when  a.billtype in (150,151,152,153) then z.name else  d.name end as cname,e.name as zone,
					 f.name as ZDRname, g.name as JSRname,y.name as auditman,h.name as Yname,p.serial_number as SerialNO,
					 p.name as pname,p.alias,p.standard,i.name as unitname,j.name as zhunitname,k.AccountComment as factory,
					 l.RangeName as rang,m.GSPPropert as gspsx,n.medtype as metype,
					 zctj = (Case p.StoreCondition when 0 then '常温' when 1 then '阴凉' when 2 then '冷链' else '' end),
					 rx = (Case p.otcflag when 0 then '否'  else '是' end),
					 (case p.MaintainType when 0 then '一般养护'when 1 then'重点养护' when 2 then '不养护' end) yhtype,
					 isnull(p.deduct,0) as tcbl,ISNULL(u.name,'') as Supplier_Name,
					 isnull(r.name,'') as  zcgy,isnull(q.name,'') as zgys,isnull(s.name,'') as yptype,
					 ifdiscount = (Case p.ifdiscount when 0 then '否'  else '是' end),
					 ifjf=(Case p.ifIntegral when 0 then '否'  else '是' end),
					 ifcl=(Case p.sfcl when 0 then '否'  else '是' end),
					 ifdzjg=(Case p.basicMedication when 0 then '否'  else '是' end),
					 ifpricebh=(Case p.protectprice when 0 then '否'  else '是' end),
					 ifcheck=(Case p.isCheckReport when 0 then '否'  else '是' end),
					 p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,
					 case when a.billtype in (11,13,17,151,153) then -b.quantity else b.quantity end as qty,
					 b.taxprice as taxprice,
					 case when a.billtype in (11,13,17,151,153) then -b.taxtotal else b.taxtotal end as taxtotal,
					 b.costtaxprice as costtaxprice,
					 case when a.billtype in (11,13,17,151,153) then -b.costtaxtotal else b.costtaxtotal end as costtaxtotal,
					 case when a.billtype in (11,13,17,151,153) then -(b.taxtotal-b.costtaxtotal) else b.taxtotal-b.costtaxtotal end  as ml,
					 case when a.billtype in (11,13,17,151,153) then -((case b.costtaxtotal when 0 then 0 else ((b.taxtotal-b.costtaxtotal)/b.costtaxtotal)*100 end))
					 else ((case b.costtaxtotal when 0 then 0 else ((b.taxtotal-b.costtaxtotal)/b.costtaxtotal)*100 end)) end as mlv,
					 t.name as kname,p.permitcode,v.loc_name,b.batchno,b.validdate,
					 case when a.billtype in (11,13,17,151,153) then -b.totalmoney else b.totalmoney end as totalmoney,
					 b.taxmoney,b.costtaxrate as costtaxrate,isnull(x.saleEName,'') as saleEName,b.taxrate
					   from billidx a 
								   left join salemanagebill b on a.billid=b.bill_id 
								   left join products p  on b.p_id=p.product_id
								   left join VchType c on a.billtype=c.Vch_ID
								   left join clients d on a.c_id=d.client_id
								   left join clients u on u.client_id=b.supplier_id
								   left join Region  e on d.region_id=e.region_id
								   left join employees f on a.inputman=f.emp_id
								   left join employees g on a.e_id=g.emp_id
								   left join employees y on a.auditman=y.emp_id
								   left join company   h on a.Y_ID=h.company_id
								   left join unit i      on p.unit1_id=i.unit_id
								   left join unit j      on p.WholeUnit_id=j.unit_id
								   left join basefactory k on p.factoryc_id=k.CommID
							       left join VW_Range l on b.p_id=l.product_id
								   left join GSPPropert m on p.gspflag=m.GSPID
								   left join VW_MedType n on b.p_id=n.product_id
								   left join (select Supplier_id,Emp_id,p_id from productbalance where Y_id=2) o on b.p_id=o.p_id
								   left join clients        q on o.Supplier_id=q.client_id
								   left join employees      r on o.Emp_id=r.emp_id
								   left join SaleRange2     s on p.SR2_id=s.id
								   left join storages       t on a.sout_id=t.storage_id
								   left join location       v on v.loc_id = b.location_id
								   left join orderidx       w on w.billid = a.order_id
								   left join wtorder        x on x.WT_ID  = w.WT_ID
								   left join company        z on a.c_id=z.company_id
								   where  a.billstates=0 and b.p_id>0 and 
								          a.billtype in (select  szTYPE from  DecodeToStr(@vchstr)) and
								          a.billdate between @BeginDate and @EndDate and
								          (CONVERT(varchar(100), a.auditdate, 23)=@AduitDate or @AduitDate='') and /*Wsj-tfsbug43612-2016-12-06 修改*/
								          isnull(t.name,'') like '%'+@k_name+'%' and 
								          isnull(p.name,'') like '%'+@p_name+'%' and
								          isnull(d.name,'') like '%'+@c_name+'%' and
								          isnull(f.name,'') like '%'+@input_name+'%' and
								          isnull(g.name,'') like '%'+@jsr_name+'%' and
								          isnull(a.billnumber,'') like '%'+@billnumber+'%' and 
								          isnull(q.name,'') like '%'+@Supplier_name+'%' and 
								          isnull(b.batchno,'') like '%'+@batchno+'%'  and 
								          isnull(k.AccountComment,'') like '%'+@factory_name+'%'  and
								          isnull(p.makearea,'') like '%'+@makearea+'%' and 
								          isnull(s.name,'') like '%'+@YPtype+'%' and 
								          isnull(e.name,'') like  '%'+@Zone_name+'%'
								          and AOID in(select  szTYPE from  DecodeToStr(@StrBusinessType)) 
								          and ((@szIDP='')or(p.product_id in (select p_id from #PORDUCTS)))/*过滤商品类别							         */
	       end
	       else
	       begin
	             select a.billid,a.billtype, c.Comment as billVchtype,a.billdate,a.auditdate as GzDate,a.billnumber,
	                 case when  a.billtype in (150,151,152,153) then z.name else  d.name end as cname,e.name as zone,
					 f.name as ZDRname, g.name as JSRname,y.name as auditman,h.name as Yname,p.serial_number as SerialNO,
					 p.name as pname,p.alias,p.standard,i.name as unitname,isnull(j.name,'') as zhunitname,k.AccountComment as factory,
					 l.RangeName as rang,m.GSPPropert as gspsx,n.medtype as metype,
					 zctj = (Case p.StoreCondition when 0 then '常温' when 1 then '阴凉' when 2 then '冷链' else '' end),
					 rx = (Case p.otcflag when 0 then '否'  else '是' end),
					 (case p.MaintainType when 0 then '一般养护'when 1 then'重点养护' when 2 then '不养护' end) yhtype,
					 isnull(p.deduct,0) as tcbl,ISNULL(u.name,'') as Supplier_Name,
					 isnull(r.name,'') as  zcgy,isnull(q.name,'') as zgys,isnull(s.name,'') as yptype,
					 ifdiscount = (Case p.ifdiscount when 0 then '否'  else '是' end),
					 ifjf=(Case p.ifIntegral when 0 then '否'  else '是' end),
					 ifcl=(Case p.sfcl when 0 then '否'  else '是' end),
					 ifdzjg=(Case p.basicMedication when 0 then '否'  else '是' end),
					 ifpricebh=(Case p.protectprice when 0 then '否'  else '是' end),
					 ifcheck=(Case p.isCheckReport when 0 then '否'  else '是' end),
					 p.Custompro1,p.Custompro2,p.Custompro3,p.Custompro4,p.Custompro5,
					 case when a.billtype in (11,13,17,151,153) then -b.quantity else b.quantity end as qty,
					 b.taxprice as taxprice,
					 case when a.billtype in (11,13,17,151,153) then -b.taxtotal else b.taxtotal end as taxtotal,
					 b.costtaxprice as costtaxprice,
					 case when a.billtype in (11,13,17,151,153) then -b.costtaxtotal else b.costtaxtotal end as costtaxtotal,
					 case when a.billtype in (11,13,17,151,153) then -(b.taxtotal-b.costtaxtotal) else b.taxtotal-b.costtaxtotal end  as ml,
					 case when a.billtype in (11,13,17,151,153) then -((case b.costtaxtotal when 0 then 0 else ((b.taxtotal-b.costtaxtotal)/b.costtaxtotal)*100 end))
					 else ((case b.costtaxtotal when 0 then 0 else ((b.taxtotal-b.costtaxtotal)/b.costtaxtotal)*100 end)) end as mlv,
					 t.name as kname,p.permitcode,v.loc_name,b.batchno,b.validdate,
					 case when a.billtype in (11,13,17,151,153) then -b.totalmoney else b.totalmoney end as totalmoney,
					 b.taxmoney,b.costtaxrate as costtaxrate,isnull(x.saleEName,'') as saleEName,b.taxrate
					 from billidx a 
								   left join salemanagebill b on a.billid=b.bill_id 
								   left join products p  on b.p_id=p.product_id
								   left join VchType c on a.billtype=c.Vch_ID
								   left join clients d on a.c_id=d.client_id
								   left join clients u on u.client_id=b.supplier_id
								   left join Region  e on d.region_id=e.region_id
								   left join employees f on a.inputman=f.emp_id
								   left join employees g on a.e_id=g.emp_id
								   left join employees y on a.auditman=y.emp_id
								   left join company   h on a.Y_ID=h.company_id
								   left join unit i      on p.unit1_id=i.unit_id
								   left join unit j      on p.WholeUnit_id=j.unit_id
								   left join basefactory k on p.factoryc_id=k.CommID
								   left join VW_Range l on b.p_id=l.product_id
								   left join GSPPropert m on p.gspflag=m.GSPID
								   left join VW_MedType n on b.p_id=n.product_id
								   left join (select Supplier_id,Emp_id,p_id from productbalance where Y_id=2) o on b.p_id=o.p_id
								   left join clients        q on o.Supplier_id=q.client_id
								   left join employees      r on o.Emp_id=r.emp_id
								   left join SaleRange2     s on p.SR2_id=s.id
								   left join storages       t on a.sout_id=t.storage_id
								   left join location       v on v.loc_id = b.location_id
								   left join orderidx       w on w.billid = a.order_id
								   left join wtorder        x on x.WT_ID  = w.WT_ID
								   left join company        z on a.c_id=z.company_id
								   where  a.billstates=0 and b.p_id>0 and 
								          a.billtype in (select  szTYPE from  DecodeToStr(@vchstr)) and
								          a.billdate between @BeginDate and @EndDate and
								          (CONVERT(varchar(100), a.auditdate, 23)=@AduitDate or @AduitDate='') and  
								          (isnull(a.sout_id,'')=@k_id or @k_id=0) and 
								          (isnull(b.p_id,'')=@p_id or @p_id=0) and
								          (isnull(a.c_id,'')=@C_id or @C_id=0) and
								          (isnull(a.inputman,'')=@input_id or @input_id=0) and
								          (isnull(a.e_id,'')=@jsr_id or @jsr_id=0) and
								          (isnull(a.billnumber,'')=@billnumber or @billnumber='') and 
								          (isnull(o.Supplier_id,'')=@Supplier_id or @Supplier_id=0) and 
								          (isnull(b.batchno,'')=@batchno or @batchno='') and 
								          (isnull(p.factoryc_id,'')=@factory_id or @factory_id=0)  and
								          (isnull(p.makearea,'')=@makearea or @makearea='') and 
								          (isnull(s.name,'')=@YPtype or @YPtype='') and 
								          (isnull(d.region_id,'')=@Zone_id or @Zone_id=0)
								          and AOID in(select  szTYPE from  DecodeToStr(@StrBusinessType))
								          and ((@szIDP='')or(p.product_id in (select p_id from #PORDUCTS)))/*过滤商品类别		        			                              */
	       end
 end
 IF object_id(N'#PORDUCTS', N'U') is not null  
   DROP TABLE #PORDUCTS  
 IF object_id(N'#CLIENTS', N'U') is not null  
   DROP TABLE #CLIENTS  
 IF object_id(N'#PORDUCTSRANGNAME', N'U') is not null
   DROP TABLE TABLE#PORDUCTSRANGNAME
 IF object_id(N'#PORDUCTSTAXNAME', N'U') is not null
   DROP TABLE #PORDUCTSTAXNAME
 IF object_id(N'#PORDUCTSMETYPENAME', N'U') is not null
   DROP TABLE #PORDUCTSMETYPENAME
 GO
