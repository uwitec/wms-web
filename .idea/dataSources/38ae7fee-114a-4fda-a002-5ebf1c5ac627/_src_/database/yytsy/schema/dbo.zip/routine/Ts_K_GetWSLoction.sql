/************************************************************

--功能：读取上架确认单商品的整零库货位
--创建人：zk
--创建时间：  
--最后修改:

参数说明：

**************************************************************/

CREATE	 PROCEDURE Ts_K_GetWSLoction
	(
	 @Bill_Id int,
	 @y_id int
     )
AS 
    declare @PId int, @wholeLoc int, @singleLoc int,@locationid int, @WLocname varchar(60), @SLocname varchar(60),@locationname varchar(60)
	DECLARE @wholeSId int, @singleSId int, @SId int, @WSName varchar(60), @SSName varchar(60),@SName varchar(60)
	
    select wholeLoc, singleLoc,
           isnull(wl.[loc_name],'') WLocname,SLocname = isnull(SL.[loc_name],''),
           locationid = locationid,locationname = isnull(l.[loc_name],''), PId = pb.p_id,
           wholeSId = ISNULL(wl.s_id, 0), singleSId = ISNULL(sl.s_id, 0), S_Id = ISNULL(l.s_id, 0), 
           WSName = ISNULL(wl.name, ''), SSName = ISNULL(sl.name, ''), SName = ISNULL(l.name, '')
    from  productbalance pb
		left join (select l.loc_id, l.loc_name, l.s_id, s.name from location l INNER JOIN storages s ON l.s_id = s.storage_id) l on pb.locationid=l.loc_id
		left join (select wl.loc_id, wl.loc_name, wl.s_id, ws.name from location wl INNER JOIN storages ws ON wl.s_id = ws.storage_id)wl on pb.wholeloc=wl.loc_id
		left join (select sl.loc_id, sl.loc_name, sl.s_id, ss.name from location sl INNER JOIN storages ss ON sl.s_id = ss.storage_id)sl on pb.singleLoc=sl.loc_id
    where pb.Y_id=@Y_id AND 
          pb.p_id IN (SELECT DISTINCT g.P_id FROM GSPbilldetail g WHERE g.Gspbill_id = @Bill_Id)
  
	/*select @PId AS PId, isnull(@wholeLoc,0) as wholeLoc, isnull(@singleLoc,0) as singleLoc,isnull(@locationid,0) as locationid,*/
 /*          isnull(@WLocname,'') as WLocname,isnull(@SLocname,'') as SLocname, isnull(@locationname,'') as locationname,*/
 /*          @wholeSId AS wholeSId, @singleSId AS singleSId, @SId AS S_Id, */
 /*          @WSName AS WSName, @SSName AS SSName, @SName AS SName*/
GO
