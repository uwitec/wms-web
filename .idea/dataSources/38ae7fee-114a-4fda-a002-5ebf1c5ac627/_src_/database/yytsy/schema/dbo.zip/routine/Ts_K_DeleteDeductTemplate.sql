
CREATE PROCEDURE Ts_K_DeleteDeductTemplate(
    @TId            INT = 0
)
AS
BEGIN
	DELETE FROM Deduct_FormulaDetail WHERE FId IN (SELECT FId FROM Deduct_Formula WHERE TId = @TId) 
	DELETE FROM Deduct_Formula WHERE TId = @TId
	DELETE FROM Deduct_TemplateIds WHERE TId = @TId
	/*DELETE FROM Deduct_TemplateVchType WHERE TId = @TId*/
	DELETE FROM Deduct_Template	WHERE TId = @TId
END
GO
