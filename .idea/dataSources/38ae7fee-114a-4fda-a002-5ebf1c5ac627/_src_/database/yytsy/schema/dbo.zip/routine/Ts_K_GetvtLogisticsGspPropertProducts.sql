

CREATE PROCEDURE Ts_K_GetvtLogisticsGspPropertProducts(@BillId INT)
AS
BEGIN
	SELECT d.p_id, c.gspflag AS GspId, c.GSPPropert, c.otcflag, c.OTCType
	FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
	        FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
			) c
			INNER JOIN (
					SELECT DISTINCT p_id
					FROM   (   SELECT ss.p_id
							   FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid
	 											    INNER JOIN buymanagebill ss ON b.billid = ss.bill_id
							   WHERE s.sendid = @BillId
							   UNION ALL
							   SELECT ss.p_id
							   FROM Sendmangebill s INNER JOIN billidx b ON s.billid = b.billid
												   INNER JOIN salemanagebill ss ON b.billid = ss.bill_id
							   WHERE s.sendid = @BillId
						    ) e
            ) d
            ON  c.product_id = d.p_id 
END
GO
