
create procedure TS_D_YHQrProductMap
@ProductState   INT=0,  /*0未对照 1已对照未上传 2已对照已上传 3所有*/
@MedType VARCHAR(50)='',
@PName    VARCHAR(100)='库'
as 
  SET NOCOUNT ON 
  
  SELECT a.serial_number serial_number_Y,a.name name_Y,a.alias alias_Y,a.standard standard_Y
         ,a.pinyin pinyin_Y,a.MedName MedName_Y,a.product_id p_id_Y
         ,b.aka063
  FROM vw_Products a LEFT JOIN YHProductMap b 
       ON a.product_id=b.p_id
  WHERE a.deleted=0 AND a.child_number=0
        AND (a.trademark<>'00' OR b.billid IS NOT NULL)
        AND ((@ProductState=0 AND b.billid IS NULL) 
              OR (@ProductState=1 AND b.billid IS NOT NULL) 
              OR @ProductState=2)
        AND (@MedType='' OR a.MedName=@MedType)
        AND (@PName='' OR a.serial_number like '%'+@PName+'%' or a.name like '%'+@PName+'%' or a.pinyin like '%'+@PName+'%')
GO
