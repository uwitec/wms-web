

/********************************************************************************************************************************************************************************************************************
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxa
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxb
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxc
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxd
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxe
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxf
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxg
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxh
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxi
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxj
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxk
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxl
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxm
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxn
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxo
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxp
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxq
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxr
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxu
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxw
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxy
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxz
********************************************************************************************************************************************************************************************************************/
/******************************************

科目明细帐
最后的修改日期 2003-12-26

********************************************/
CREATE PROCEDURE TS_L_QrCompanyADetail
( @BeginDate 	  varchar(50),
  @EndDate        varchar(50),
  @szAClass_ID	VARCHAR(30)='',
	
  @szEClass_ID  VARCHAR(30)='',
  @szIClass_ID  VARCHAR(30)='',
  @iniTotal     NUMERIC(25,8)=0 OUTPUT,
  @nYClassid    varchar(100)='',
  @nloginEID    int=0

)
/*with encryption*/
AS
/*Params Ini begin*/
if @szAClass_ID is null  SET @szAClass_ID = ''
if @szEClass_ID is null  SET @szEClass_ID = ''
if @szIClass_ID is null  SET @szIClass_ID = ''
if @iniTotal is null  SET @iniTotal = 0 
if @nYClassid is null  SET @nYClassid = ''
if @nloginEID is null  SET @nloginEID = 0
/*Params Ini end*/
  SET NOCOUNT ON
  /*------Some account id*/
	DECLARE 
		@SQLScript  VARCHAR(8000),
		@ArTotal_Id VARCHAR(30),  /*9	『应收款合计』*/
		@ApTotal_Id VARCHAR(30),	/*15『应付帐款合计』*/
	  @dTempTotal NUMERIC(25,8)


 /* SET NOCOUNT ON*/

  Declare @Companytable int,@employeestable int

/*---分支机构授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='Y' and u.psc_id='000000') 
   begin
      set @Companytable=0
   end
   else
   begin 
      set @Companytable=1
   end
/*---分支机构授权*/

/*---职员授权*/
  if not exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E') 
      or exists(select * from userauthorize u where u.e_id=@nloginEID and u.Type='E' and u.psc_id='000000') 
   begin
     set @employeestable=0
   end
   else
   begin 
     set @employeestable=1
   end   

/*---职员授权*/

	SELECT	@ArTotal_Id		='000001000010'	/*『内部应收款合计』*/
	SELECT	@ApTotal_Id		='000002000007'	/*『内部应付帐款合计』*/


	IF @szAClass_ID= @ArTotal_Id
	BEGIN
		IF @nYClassid<>'' 
		BEGIN
			/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ArTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0) FROM
                         vw_c_Adetail a,
                        (select * from dbo.vw_c_billidx b where  b.billtype  in (150,151,155,160,161,165,171,172,173,174) 
                        ) b 
			WHERE a.billid=b.billid and b.billdate<@BeginDate  and a.aClass_ID IN (@ArTotal_Id,@APTotal_Id) 
      and LEFT(a.cClass_ID,LEN(@nYClassid))=@nYClassid and b.billstates='0'
			/*取期初余额*/
			SELECT @iniTotal=ISNULL(SUM(cb.artotal_ini)-SUM(cb.aptotal_ini),0) FROM vw_L_Companybalance cb
      WHERE LEFT(cb.CClass_ID,LEN(@nYClassid))=@nYClassid 
            AND (@CompanyTable=0 or ((cb.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and cb.cclass_id like u.psc_id+'%'))))

			SELECT @iniTotal=@iniTotal+@dTempTotal
		END ELSE
		BEGIN
			SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ArTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0) FROM
                        vw_c_Adetail a,
                        (select * from dbo.vw_c_billidx b where  b.billtype  in (150,151,155,160,161,165,171,172,173,174) 
                        ) b 
			WHERE a.billid=b.billid and b.billdate<@BeginDate  and a.aClass_ID IN (@ArTotal_Id,@APTotal_Id) 
      and b.billstates='0'
			/*取期初余额*/
			SELECT @iniTotal=ISNULL(SUM(ab.ini_total),0) FROM vw_L_accountbalance AB WHERE AB.AClass_ID=@szAClass_ID
	                AND (@CompanyTable=0 or ((ab.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and ab.Yclass_id like u.psc_id+'%'))))
	                AND (@nYClassID='' OR ab.Yclass_id like @nYClassID+'%')
			
			SELECT @iniTotal=@iniTotal+@dTempTotal
		END
	END
	ELSE IF @szAClass_ID= @ApTotal_Id
	BEGIN
		IF @nYClassid<>''
		BEGIN
			/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ApTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0) FROM
                        vw_c_Adetail a,
                        (select * from dbo.vw_c_billidx b where  b.billtype in (150,151,155,160,161,165,171,172,173,174) 
	                ) b 
			WHERE a.billid=b.billid and b.billdate<@BeginDate  and a.aClass_ID IN (@ArTotal_Id,@APTotal_Id) 
      and LEFT(a.cClass_ID,LEN(@szAClass_ID))=@szAClass_ID and b.billstates='0'

			/*取期初余额*/
			SELECT @iniTotal=ISNULL(SUM(cb.aptotal_ini)-SUM(cb.artotal_ini),0) FROM vw_L_Companybalance cb
      WHERE LEFT(CClass_ID,LEN(@szAClass_ID))=@szAClass_ID 
	AND (@CompanyTable=0 or ((cb.cclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and cb.cclass_id like u.psc_id+'%'))))
		
			SELECT @iniTotal=@iniTotal+@dTempTotal
		END ELSE
		BEGIN
			/*取起始时间段内的变化量*/
			SELECT @dTempTotal=ISNULL(SUM(CASE a.aClass_ID WHEN @ApTotal_id THEN a.jdmoney ELSE -a.jdmoney END),0) FROM
                        vw_c_Adetail a,
                        (select * from dbo.vw_c_billidx b where  b.billtype  in (150,151,155,160,161,165,171,172,173,174) 
                        ) b 
			WHERE a.billid=b.billid and b.billdate<@BeginDate  and a.aClass_ID IN (@ArTotal_Id,@APTotal_Id) 
      and b.billstates='0'
			/*取期初余额*/
			SELECT @iniTotal=ISNULL(SUM(ab.ini_total),0) FROM vw_L_accountbalance AB WHERE AB.AClass_ID=@szAClass_ID
	                AND (@CompanyTable=0 or ((ab.Yclass_id='') or (exists(select u.psc_id from userauthorize u where u.e_id=@nloginEID  and u.Type='Y' and ab.Yclass_id like u.psc_id+'%'))))
	                AND (@nYClassID='' OR ab.Yclass_id like @nYClassID+'%')
			
			SELECT @iniTotal=@iniTotal+@dTempTotal
		END
	END

	SET @SQLScript='SELECT b.billid,b.billtype,b.billdate,b.billnumber,b.inputman,b.auditman,
      b.note,b.SUMmary,b.billstates, b.inputmanname, b.auditmanname,'
	IF @szAClass_ID= @ArTotal_Id
	BEGIN
		SET @SQLScript=@SQLScript+'
			jdmoney=CASE p.aClass_ID 
			WHEN '+CHAR(39)+@ArTotal_id+CHAR(39)+' THEN p.jdmoney 
			WHEN '+CHAR(39)+@ApTotal_id+CHAR(39)+' THEN -p.jdmoney 
			ELSE p.jdmoney 
			END,'

	END ELSE IF @szAClass_ID= @ApTotal_Id
	BEGIN
		SET @SQLScript=@SQLScript+'
		jdmoney=CASE p.aClass_ID 
			WHEN '+CHAR(39)+@ApTotal_id+CHAR(39)+' THEN p.jdmoney 
			WHEN '+CHAR(39)+@ArTotal_id+CHAR(39)+' THEN -p.jdmoney 
			ELSE p.jdmoney 
			END,'
	END ELSE
		SET @SQLScript=@SQLScript+'p.jdmoney, '

	SET @SQLScript=@SQLScript+' ISNULL((SELECT [name] FROM employees e WHERE e.[emp_id]=b.[e_id]),'''') AS employeename,
		ISNULL(p.accountname,'' '') AS accountname,
		ISNULL((SELECT [serial_number] FROM clients c WHERE c.[client_id]=b.[c_id]),'''') AS [serial_nubmer],
		ISNULL(Y.name,'' '') AS clientname
		FROM VW_C_Adetail p INNER JOIN 

                (select * from dbo.vw_c_billidx b where  b.billtype  in (150,151,155,160,161,165,171,172,173,174) 
		        AND ('+cast(@employeestable as varchar(100))+'=0 OR ((b.eclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+'  and u.Type=''E'' and b.eclass_id like u.psc_id+''%''))))
		        AND ('+cast(@CompanyTable as varchar(100))+'=0 or ((b.Yclass_id='''') or (exists(select u.psc_id from userauthorize u where u.e_id='+cast(@nloginEID as varchar(50))+' and u.Type=''Y'' and b.Yclass_id like u.psc_id+''%''))))

		) b 

		ON p.billid=b.billid

                INNER JOIN
                Company Y  on p.c_id=Y.Company_id
		WHERE b.billstates IN (0) AND  b.billdate BETWEEN '+CHAR(39)+convert(VARCHAR(10),@BeginDate,20)
    +CHAR(39)+' and '+CHAR(39)+convert(VARCHAR(10),@EndDate,20)+CHAR(39) 

/*加入科目的条件  */
  IF @szAClass_ID= @ArTotal_Id or @szAClass_ID=@ApTotal_Id
	  SET @SQLScript=@SQLScript+' and LEFT(p.aClass_ID,LEN('+CHAR(39)+@szAClass_ID+CHAR(39)+')) IN ('
    +CHAR(39)+@ApTotal_Id+CHAR(39)+','+CHAR(39)+@ArTotal_Id+CHAR(39)+')'
  ELSE
	  SET @SQLScript=@SQLScript+' and LEFT(p.aClass_ID,LEN('+CHAR(39)+@szAClass_ID+CHAR(39)+'))='+CHAR(39)
    +@szAClass_ID+CHAR(39)

/*加入单位的条件  */
  IF @nYClassid<>''
	  SET @SQLScript=@SQLScript+' and LEFT(Y.Class_ID,LEN('+CHAR(39)+@nYClassid+CHAR(39)+'))='+CHAR(39)
    +@nYClassid+CHAR(39)

/*加入经手人的条件  */
  IF @szEClass_ID<>''
	  SET @SQLScript=@SQLScript+' and LEFT(b.[EClass_ID], LEN('+CHAR(39)+@szEClass_ID+CHAR(39)+'))='+CHAR(39)+@szEClass_ID+CHAR(39)

/*加入制单人的条件  */
  IF @szIClass_ID<>''
	  SET @SQLScript=@SQLScript+' and LEFT(b.[InputmanClass_ID], LEN('+CHAR(39)+@szIClass_ID+CHAR(39)+'))='+CHAR(39)+@szIClass_ID+CHAR(39)

/*PRINT @SQLScript*/
  EXEC(@SQLScript)
  GOTO Succee

Succee:
  RETURN 0
GO
