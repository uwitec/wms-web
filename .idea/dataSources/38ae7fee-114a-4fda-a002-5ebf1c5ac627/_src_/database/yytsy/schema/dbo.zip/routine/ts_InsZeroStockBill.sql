create procedure ts_InsZeroStockBill
(
  @nBillID  int=0,
  @naoid        int =1,   
  @dQuantity NUMERIC(25,8),
  @szPname  [varchar] (80), 
  @szPstandard [varchar] (20), 
  @szPpermitcode [varchar] (50), 
  @szPmakearea [varchar] (80),
  @szPfactoty [varchar] (80), 
  @szComment [varchar] (255), 
  @szComment2 [varchar] (200),
  @y_id   int = 0
 )
as
set nocount on 
  
 insert into ZeroStockBill(bill_id, aoid, quantity, Pname, Pstandard, PPermitcode, PMakearea, Pfactoty, comment, comment2, y_id) 
      values (@nBillID, 1, @dQuantity, @szPname, @szPstandard, @szPpermitcode, @szPmakearea, @szPfactoty, @szComment, @szComment2, @y_id) 
if @@rowcount > 0 return 0 else return -1
GO
