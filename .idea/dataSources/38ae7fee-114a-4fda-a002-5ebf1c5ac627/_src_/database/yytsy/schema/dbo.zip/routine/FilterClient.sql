CREATE FUNCTION FilterClient(@Y_ID int)
RETURNS  table 
AS  
  RETURN 
       (SELECT distinct c.client_id,c.class_id,c.parent_id,c.child_number,c.child_count,c.serial_number,c.[name],
       c.alias,c.region_id,c.phone_number,c.address,c.zipcode,c.contact_personal,c.tax_number,
       c.acount_number,c.pinyin,c.pricemode,c.firstcheck,c.comment,c.csflag,c.deleted,c.ProtocolDate,
       isnull(GI.GMP_NO, '') GMPNo,isnull(cr.gspno,'') as GSPNo,
       c.Cetype,c.ModifyDate,c.RowIndex,c.IncRate,
       isnull(cr.licence_no,'') as licence_no,c.ent_type,c.city_id,
       c.city_name,c.boro_id,c.boro_name,isnull(CB.e_id,0) as e_id, ISNULL(CB.BalanceMode, 1) AS BalanceMode,  c.consignBook_no,isnull(cr.organCard_no,'') as organCard_no, 
       isnull(cr.BusinessLicence_no,'') as BusinessLicence_no,isnull(cr.MassConfer_no,'') as MassConfer_no,isnull(cr.Cer_CustomNO1,'') as Cer_CustomNO1,isnull(cr.Cer_CustomNO2,'') as Cer_CustomNO2, 
       isnull(cr.Cer_CustomNO3,'') as Cer_CustomNO3,isnull(cr.Cer_CustomNO4,'') as Cer_CustomNO4,isnull(cr.Cer_CustomNO5,'') as Cer_CustomNO5,
       isnull(CB.credit_total,0)credit_total,isnull(CB.APcredit_total,0)APcredit_total,
       isnull(CB.sklimit,0)sklimit,isnull(CB.artotal,0)artotal,c.discount,
       isnull(CB.artotal_ini,0)artotal_ini,  isnull(CB.aptotal,0)aptotal,isnull(CB.aptotal_ini,0)aptotal_ini,
       isnull(CB.pre_artotal,0)pre_artotal,  isnull(CB.pre_artotal_ini,0)pre_artotal_ini,
       isnull(CB.pre_aptotal,0)pre_aptotal,  isnull(CB.pre_aptotal_ini,0)pre_aptotal_ini,
       ISNULL(r.name, '') AS RegionName,isnull(e.name,'') as ename,
       cename = CASE c.csflag WHEN '0' THEN '客户' WHEN '1' THEN '供应商' WHEN '2' THEN
       '两者皆是' END
       ,CN_PriceMode=case c.PriceMode 
			when 0 then'[无]'
			when 1 then'预设售价1'
			when 2 then'预设售价2'
			when 3 then'预设售价3'
			when 4 then'会员价'
			when 5 then'国批价'
			when 6 then'国零价'
			when 7 then'特价'
			when 8 then'最近进价'
			when 9 then'零售价'
		    end,
      StatusName=case c.deleted
      when 0 then '正常'  when 1 then '删除' when 4 then '停用'
      end,
      ISNULL(cr.d1,'1900-01-01') as d1, 		
      ISNULL(cr.d2,'1900-01-01') as d2,
      isnull(WT.d5, '1900-01-01') as d5, 		
      ISNULL(cr.d8,'1900-01-01') AS d8, 
      ISNULL(cr.d9,'1900-01-01') AS d9, 	
      ISNULL(cr.d10,'1900-01-01') AS d10, 
      isnull(GI.D11, '1900-01-01') as d11,               
      ISNULL(cr.d12, '1900-01-01') AS d12,
      ISNULL(cr.d13,'1900-01-01') AS d13,
      ISNULL(cr.d14,'1900-01-01') AS d14,
      ISNULL(cr.d15,'1900-01-01') AS d15,
      ISNULL(cr.d16,'1900-01-01') AS d16,
	 c.CloudCode,
      c.CreateDate,c.C_Customname1,c.C_Customname2,c.C_Customname3,c.C_Customname4,c.C_Customname5,
      c.clienttype_id,isnull(ct.name,'') as clienttypename,isnull(v.name,'') as cardname,c.card_id,
      c.bywayday,c.RoadID,isnull(S.RoadName,'')RoadName,c.szOrdernum,cast(c.OrderCredit as int)OrderCredit,c.jsdw_id, ISNULL(c2.name, '') as jsName,
      c.ElecCode,
      isnull(kp.billdate,0) lastkpdate,c.AuditStates,
      (Case c.AuditStates when 1 then '已审核' else '未审核' end) as AuditStatesStr,   
      CASE WHEN c.AuditStates = 1 THEN c.AuditEName ELSE '' END AS AuditEName,
	  CASE WHEN c.AuditStates = 1 THEN c.AuditDate ELSE 0 END AS AuditDate,
      c.auditMan, c.auditComment, c.AddressZC, c.CreateMan,
      ISNULL(c.ModifyEId, 0) AS ModifyEId,ISNULL(c.FirstOperationTime, '1900-01-01') AS FirstOperationTime,
      ISNULL(c.LastOperationTime, '1900-01-01') AS LastOperationTime,ISNULL(c.Quality_Phone, '') AS Quality_Phone,
      ISNULL(c.Quality_Personal, '') AS Quality_Personal, ISNULL(c.QQ, '') AS QQ,CB.moneyproffer, CB.moneyproffer_int, 
      CB.mlrateproffer, CB.mlrateproffer_ini, CB.operationcount,
      
      isnull(c.zljgPeople,'') as zljgPeople,isnull(c.zlglphone,'') as zlglphone,isnull(c.storePeople,'') as storePeople,
      isnull(c.storephone,'') as storephone,isnull(c.zljgphone,'') as zljgphone,isnull(c.cwPeople,'') as cwPeople,
      isnull(c.cwphone,'') as cwphone,isnull(c.zlglPeople,'') as zlglPeople,
      isnull(c.legalphone,'') as legalphone,isnull(c.legalPeople,'') as legalPeople		    
      FROM dbo.clients c LEFT OUTER JOIN     dbo.Region r ON c.region_id = r.region_id
                         LEFT OUTER JOIN     dbo.clienttype ct ON c.clienttype_id = ct.clienttype_id    
                         Left OUTER join     vipcard v on c.card_id=v.vipcardid 
                         Left OUTer JOIn     SendRoad S on c.RoadID=S.ROadID
                         LEFT OUTER JOIN ClientReport2_CMap CR ON c.client_id = cr.c_id                    
                         Left join    (   SELECT   MAX(Id) AS Id, c_id, MAX(d1) AS d1, MAX(d2) AS d2, MAX(d3) AS d3, MAX(d4) AS d4, MAX(d6) AS d6, 
											MAX(d7) AS d7, MAX(d8) AS d8, MAX(d9) AS d9, MAX(GspId) AS GspId, MAX(D10) AS D10, MAX(mt_id) 
											AS mt_id, MAX(d12) AS d12, MAX(d13) AS d13, MAX(d14) AS d14, MAX(d15) AS d15, MAX(d16) 
											AS d16, CType, MAX(d17) AS d17, MAX(d18) AS d18, MAX(d19) AS d19, MAX(d20) AS d20, MAX(d21) AS d21
										FROM      dbo.gspalert AS g
										GROUP BY c_id, CType
                                       ) g on c.Client_id = g.c_id and g.mt_id=0 and g.ctype = 0
                         Left Join 
      (select C_id,e_id,MAX(credit_total)credit_total,MAX(APcredit_total)APcredit_total,MAX(sklimit)sklimit,sum(artotal)artotal,sum(artotal_ini)artotal_ini,
                   sum(aptotal)aptotal          ,sum(aptotal_ini)aptotal_ini            ,sum(pre_artotal)pre_artotal
                  ,sum(pre_artotal_ini)pre_artotal_ini,sum(pre_aptotal)pre_aptotal,sum(pre_aptotal_ini)pre_aptotal_ini,
                  SUM(moneyproffer)moneyproffer,SUM(moneyproffer_Ini)moneyproffer_int,SUM(mlrateproffer)mlrateproffer,
                  SUM(mlrateproffer_ini)mlrateproffer_ini,MAX(operationcount)operationcount,MAX(BalanceMode)BalanceMode

             from Clientsbalance where Y_id =@Y_ID  Group by C_id,e_id )CB on CB.c_id=C.client_id
        LEFT JOIN           employees e on e.emp_id=cb.e_id
        LEFT Join clients c2 on c.jsdw_id = c2.client_id
		left join
		(
					select a.c_id,MAX(a.billdate) billdate from billidx a
					where a.billtype in (10,20) and a.billstates=0
					group by a.c_id
		) kp on kp.c_id=c.client_id
		LEFT JOIN (SELECT   MAX(GMP_NO) AS GMP_NO, c_id, MAX(validdate) AS D11
			FROM      dbo.GMPIndex
			GROUP BY c_id) GI ON C.client_id = GI.c_id
		LEFT JOIN (SELECT   c_id, MAX(validDate) AS D5, MAX(wtNO) AS wtNO
FROM      dbo.wtorder
GROUP BY c_id) WT ON C.client_id = WT.c_id
        
       WHERE (c.deleted in (0, 4, 5)))
GO
