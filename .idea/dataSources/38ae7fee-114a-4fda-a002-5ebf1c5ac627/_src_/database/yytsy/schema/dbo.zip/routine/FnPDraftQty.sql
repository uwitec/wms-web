

CREATE  FUNCTION [FnPDraftQty]( @nS_id int)  
returns @retPDraftQty table 
  (p_id int,
   DraftQty numeric(25,8)  
  )
AS 
begin

  declare @CheckSaleQty char(1)
	set @CheckSaleQty='0'
	select @CheckSaleQty=sysvalue from sysconfig where [sysname]='CheckSaleQty'/*存草稿是是否检测可开数量*/


  insert @retPDraftQty  
  select p_id, sum(DraftQty) as DraftQty   
    from
    (select p_id,
    	sum(quantity) as DraftQty
    	from salemanagebilldrf 
        where bill_id in (select billid 
                            from billdraftidx where billtype in (10,110,212,150,152) and 
                                                    (@CheckSaleQty = '1'  or ( @CheckSaleQty = '2' and billstates = 3))
                          ) and 
               /* @nS_id = -100 时只统计配送中心的数据*/
              /*(@nS_id = 0 or ss_id = @nS_id or (@nS_id = -100 and ss_id in (select storage_id from storages where flag =0 and deleted = 0))) and*/
              (@nS_id=-100 or Y_ID=@nS_id ) and 
              aoid in (0,7)
        group by p_id
 
    union all

    select p_id,
    	sum(quantity) as DraftQty
    	from buymanagebilldrf 
        where bill_id in (select billid 
                            from billdraftidx where billtype in (21,121) and 
                                                    (@CheckSaleQty = '1'  or ( @CheckSaleQty = '2' and billstates = 3))
                          ) and
              /*(@nS_id = 0 or ss_id = @nS_id or (@nS_id = -100 and ss_id in (select storage_id from storages where flag =0 and deleted = 0))) and*/
              (@nS_id=-100 or Y_ID=@nS_id ) and 
	       aoid in (0,7)
        group by p_id
 
     union all 
    
     select p_id,
    	sum(quantity) as DraftQty
    	from storemanagebilldrf 
        where bill_id in (select billid 
                            from billdraftidx where billtype in (40,41,44,45,47,49) and 
                                                    (@CheckSaleQty = '1'  or ( @CheckSaleQty = '2' and billstates = 3))
                          ) and
              /*(@nS_id = 0 or ss_id = @nS_id or (@nS_id = -100 and ss_id in (select storage_id from storages where flag =0 and deleted = 0))) and  */
              (@nS_id=-100 or Y_ID=@nS_id ) and
              aoid in (0,7)

        group by p_id
 
     union all

     select p_id,
    	sum(quantity) as DraftQty
    	from tranmanagebilldrf 
        where bill_id in (select billid 
                            from billdraftidx where billtype in (53,56) and 
                                                    (@CheckSaleQty = '1'  or ( @CheckSaleQty = '2' and billstates = 3))
                          ) and
              /*(@nS_id = 0 or ss_id = @nS_id or (@nS_id = -100 and ss_id in (select storage_id from storages where flag =0 and deleted = 0))) and*/
              (@nS_id=-100 or Y_ID=@nS_id ) and
              aoid in (0,7)
        group by p_id
     ) T  group by p_id     

  RETURN

end
GO
