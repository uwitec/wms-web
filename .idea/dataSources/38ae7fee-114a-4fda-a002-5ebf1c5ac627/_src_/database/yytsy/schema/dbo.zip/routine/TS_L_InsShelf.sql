

CREATE PROCEDURE [TS_L_InsShelf]
( @shelfname varchar(50)
)
 AS
  Insert Shelf(Slf_name,
               Slf_comment,
               deleted,
               ModifyDate)
  values      (@shelfname,
               '',
               0,
               Convert(varchar(10),getdate(),20))
GO
