
CREATE FUNCTION fn_GetAdjustBillPrevTotal (@nBillID int,@nDetail_ID int,@nTag int)  
RETURNS numeric(25,8) AS  
BEGIN 
	Declare @dTotal numeric(25,8),@dPrev numeric(25,8)
	Declare @c int

	if @nTag=0 
		Select @dTotal=(TaxTotal) from BuyManageBill where smb_id=@nDetail_ID and Bill_id=@nBillID
	else
		Select @dTotal=(TaxTotal) from SaleManageBill where smb_id=@nDetail_ID and Bill_id=@nBillID

 	SET @c = 10
	while @c>0 
	begin
		SET @nDetail_id = @nDetail_id-1
		if @nTag=0 
		begin
			if Exists(Select smb_id from BuyManageBill where smb_id=@nDetail_id and Bill_id=@nBillID and IoTag=1)
			begin
				Select @dPrev=(TaxTotal) from BuyManageBill where smb_id=@nDetail_ID and Bill_id=@nBillID and IoTag=1
				SET @c = 1
			end
		end
		else
		BEGIN
			if Exists(Select smb_id from SaleManageBill where smb_id=@nDetail_id and Bill_id=@nBillID and IoTag=1)
			begin
				Select @dPrev=(TaxTotal) from SaleManageBill where smb_id=@nDetail_ID and Bill_id=@nBillID and IoTag=1
				SET @c = 1
			end
		END
		SET @c = @c -1
	end
	
	IF @dPrev IS null SET @dPrev =0
	IF @dTotal IS null SET @dTotal =0
	SET @dTotal = -@dPrev - @dTotal
	Return(@dTotal)
END
GO
