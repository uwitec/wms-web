/************************************************************
--过程名称：Ts_T_InsorUpdatefinancebilldrf
--功能：通过勾兑界面生成付款单草稿明细
--创建人：xxx 
--创建时间：2015-02-25

**************************************************************/
create proc [dbo].[Ts_T_InsorUpdatefinancebilldrf]
(
  @bill_id int =0 ,  /*单据id*/
  @a_id int = 0 ,   /*付款类型（现金，银行户头……）*/
  @total NUMERIC(25,8) = 0 ,  /*金额*/
  @totalmoney NUMERIC(25,8) = 0 , 
  @c_id int ,			/*往来单位*/
  @comment varchar(100) = '' , /*备注*/
  @invoiceTotal NUMERIC(25,8) = 0, 
  @Y_ID  int = 0,   /*机构*/
  @nRet   int output  
)
as

declare @RowGUID uniqueidentifier
set @RowGUID=NEWID()
/*Params Ini begin*/
if @a_id is null  SET @a_id = 0
if @totalmoney is null  SET @totalmoney = 0
if @total is null  SET @total = 0
if @comment is null set @comment=''
if @c_id is null set @c_id=0
if @invoiceTotal is null set @invoiceTotal= 0
if @Y_ID is null set @Y_ID= 0

/*Params Ini end*/

  INSERT INTO financebilldrf
	(
	 bill_id  ,a_id  ,jftotal, dftotal ,c_id ,comment1, invoiceTotal ,RowGUID, Y_ID
	)
	VALUES
	(
	 @bill_id  ,@a_id  ,@total  ,@totalmoney ,@c_id  ,@comment  , @invoiceTotal ,@RowGUID, @Y_ID
	)

	set @nRet = @@IDENTITY
GO
