

CREATE PROCEDURE Ts_K_GetBillGspPropertProducts(@BillId INT, @BillType INT)
AS
BEGIN
	IF @BillType IN (14, 22, 26) /* 销售订单、采购订单，采购进货计划表*/
	BEGIN
		SELECT d.p_id, LTRIM(RTRIM(c.gspflag)) AS GspId, c.GSPPropert, c.otcflag, c.OTCType
		FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
		        FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
				) c
				INNER JOIN (
						SELECT DISTINCT p_id
						FROM   (   SELECT p_id FROM OrderBill
								   WHERE  bill_id = @BillId
								) e
	            ) d
	            ON  c.product_id = d.p_id
	END
	ELSE
	IF @BillType IN (52) /* 机构请货单*/
	BEGIN
		SELECT d.p_id, c.gspflag AS GspId, c.GSPPropert, c.otcflag, c.OTCType
		FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
		        FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
				) c
				INNER JOIN (
						SELECT DISTINCT p_id
						FROM   (   SELECT p_id FROM TranBill tb
								   WHERE  bill_id = @BillId
								) e
	            ) d
	            ON  c.product_id = d.p_id
	END	
	ELSE
	BEGIN
		SELECT d.p_id, LTRIM(RTRIM(c.gspflag)) AS GspId, c.GSPPropert, c.otcflag, c.OTCType
		FROM   (SELECT p.product_id, p.gspflag, g.GSPPropert, p.otcflag, p.OTCType 
		        FROM products p LEFT JOIN GSPPropert g ON p.gspflag = g.GSPID
				) c
				INNER JOIN (
						SELECT DISTINCT p_id
						FROM   (   SELECT p_id FROM salemanagebill
								   WHERE  bill_id = @BillId
								   UNION
	                               SELECT p_id FROM buymanagebill
	                               WHERE  bill_id = @BillId
	                               UNION
	                               SELECT p_id FROM storemanagebill
	                               WHERE  bill_id = @BillId
	                               UNION 
	                               SELECT p_id FROM goodscheckbill
	                               WHERE  bill_id = @BillId
	                               UNION 
	                               SELECT p_id FROM tranmanagebill
	                               WHERE  bill_id = @BillId
							    ) e
	            ) d
	            ON  c.product_id = d.p_id
	END	            
END
GO
