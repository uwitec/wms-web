





CREATE	PROCEDURE [Ts_L_InsTaxRate]
	(@mt_code	[varchar](3),
	 @mt_name	[varchar](50))

AS

IF exists (select * from customCategory where name=@mt_name and Typeid=3 and Child_Count=0)
begin
   	RAISERROR('该税率已经存在，请重新输入其它名称！',16,1) 
	return 0 
end
declare @parent_id  int,
        @class_id   varchar(100),
        @child_count int,
        @typeid     int,
        @class_one varchar(100),
        @id         int 

/*
INSERT INTO [medtype] 
	 ( [mt_code],
	 [mt_name]) 
 
VALUES 
	( @mt_code,
	 @mt_name)*/
select @class_id=class_id,@child_count=Child_Count,@id=id from customCategory where Typeid=3 and Child_Count<>0 
select @class_one=dbo.PadLeft(@child_count, 2,0)
select top 1 @parent_id=parent_id,@typeid=Typeid from customCategory where Typeid=3 and Child_Count=0 order by id desc
insert into customCategory(name,class_id,parent_id,baseType,rowIndex,deleted,pinyin,Child_Number,Child_Count,Typeid)
                           values(@mt_name,@class_id+@class_one,@parent_id,0,0,0,'',0,0,@typeid)
update customCategory set Child_Number=Child_Number+1 ,Child_Count=Child_Count+1 where id=@id
if @@rowcount<>0 
	return @@IDENTITY
else
	return 0
GO
