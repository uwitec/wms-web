
/*DTS库到草稿*/
create  procedure ts_c_DtsToDraftDown
/*with encryption*/
as
set nocount on

/*变量定义*/

declare @isUpSaleData smallint /*单据类型*/
declare @nBillType smallint /*单据类型*/
declare @nBillid int,@nnewbillid int/*单据id,*/
declare @PosGuid varchar(50),@nY_ID int, @nUpY_ID int, @nret int, @szYClassID varchar(50)
declare @nGuid uniqueidentifier
/*declare @RetailMerge int --零售单合并选项, 暂不处理零售单合并*/

select @szYClassID = sysvalue from sysconfig where upper([sysname]) = 'YCLASSID'
select @PosGuid = sysvalue from sysconfig where upper([sysname]) = 'GUID'
exec ts_getsysvalue 'Y_ID',@nY_ID out
if @nY_ID = 0 or @nY_ID is null or @szYClassid = ''
  Return -100

if object_id('tempdb..#tasktmp') is not null
      drop table #tasktmp
   select top 0 (tsid + 1) as tsid, RowGuid into #tasktmp from tasklistup

begin tran  
    /*分支机构导入总部数据begin*/
    
    /*处理促销单begin*/
    delete CxbilldtsIN from CxidxdtsIN b ,cxbilldtsIN s 
    where b.billid=s.bill_id  and b.guid in (select guid from cxidx)
    
    delete CxbilldtsIN from CxidxdtsIN b ,cxbilldtsIN s 
    where b.billid=s.bill_id  and (b.posid not in (select company_id from company where superior_id = @nY_ID or company_id = @nY_ID) or b.posid =0)
    
    delete cxidxdtsIN where guid in (select guid from cxidx)
    
    delete cxIdxdtsIN where posid not in (select company_id from company where superior_id = @nY_ID or company_id = @nY_ID union select 0)

  	declare cxdraftidxcur cursor for
	  select billid,billtype from cxidxdtsIN
	  open cxdraftidxcur
	
	  fetch next from cxdraftidxcur into @nBillid,@nBillType
	  while @@FETCH_STATUS=0	
	  begin				
	    insert into cxidx(billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid)
		select billdate, billnumber, billtype, a_id, e_id, c_id, auditman, inputman,
			period, billstates, priceorder, spnointeger,posid, region_id, auditdate,note,summary,araptotal,
			y_id,begindate,enddate,begintime,endtime,xq,cxtype,cardtype,ifintegral,integral,guid
 			from cxidxdtsin where billid=@nbillid

			select @nnewbillid=@@identity

		  /*促销单*/
		  insert into cxbill(bill_id, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment)
		  
		  
		  select @nnewbillid, p_id, price_id, unitid, lowQty, discount, cxprice, 
						   highQty, yxLimit, ifIntegral, Integral, aoid, comment
		  from cxbilldtsIN where bill_id=@nbillid
		  order by [smb_id]
		  fetch next from cxdraftidxcur into @nBillid,@nBillType
		  
	  end	
	  close cxdraftidxcur
	  deallocate cxdraftidxcur
    /*处理促销单end*/
    
    /*处理调价单begin*/
    delete pricebilldtsIN from priceidxdtsIN b ,pricebilldtsIN s 
    where b.billid=s.bill_id  and b.guid in (select guid from priceidx)
    
    delete pricebilldtsIN from priceidxdtsIN b ,pricebilldtsIN s 
    where b.billid=s.bill_id  and b.posid not in (select company_id from company where superior_id = @nY_ID or company_id = @nY_ID or class_id = '000001')
    
    delete priceidxdtsIN where guid in (select guid from priceidx)
    
    delete priceidxdtsIN where posid  not in (select company_id from company where superior_id = @nY_ID or company_id = @nY_ID or class_id = '000001')
    
 
  	declare pricedraftidxcur cursor for
	  select billid,billtype from priceidxdtsIN
	  open pricedraftidxcur
	
	  fetch next from pricedraftidxcur into @nBillid,@nBillType
	  while @@FETCH_STATUS=0	
	  begin
		
  		insert into priceidx(billdate, billnumber, billtype, e_id, auditman, inputman, 
			period, billstates, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid,y_id)
	  	select billdate, billnumber, billtype, e_id, 0, inputman, 
			period, 2, order_id, department_id, 
			posid, region_id, auditdate, note, summary,guid,y_id
 			from priceidxdtsIN where billid=@nbillid

			select @nnewbillid=@@identity

		  /*调价单*/
		  insert into pricebill(bill_id, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,Comment,Y_Id,oldretailprice)
		  select @nnewbillid, p_id, price_id,unitid,retailprice,price1,price2,price3,price4,glprice,gpprice,specialprice,recprice,lowprice,comment,y_id,oldretailprice
		  from pricebilldtsIN where bill_id=@nbillid
		  order by [id]
		  fetch next from pricedraftidxcur into @nBillid,@nBillType
	  end	
	  close pricedraftidxcur
	  deallocate pricedraftidxcur

      update tasklistUp set TranFlag = 1 where trantype = 1 and TableType = 'O' and billguid in (select guid from PriceIdxDtsIN where billtype = 140)

     /*处理调价单end*/

   /*导入收货单*/
    delete  billdtsidxIN where guid in (select Guid from billdraftidx where billtype in (160, 162)
				       union
                                     select Guid from billidx where billtype in (160,162) and billstates = '0'
				    )

    if exists(select 1 from billdtsidxIN where billtype in (160, 162))
    begin

	declare billdraftidxcur cursor for
	select billid,billtype from billdtsidxIN where billtype in (160, 162) and posguid = @PosGuid
	open billdraftidxcur
	
	fetch next from billdraftidxcur into @nBillid,@nBillType
	while @@FETCH_STATUS=0
	begin		
		
			insert into billdraftidx(billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, period, billstates, order_id, department_id, 
			posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,transcount,lasttranstime,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate, enddate,WholeQty,PartQty) 

			select billdate, billnumber, billtype, a_id, c_id, e_id, sout_id, sin_id, auditman, inputman, 
			ysmoney, ssmoney,araptotal, quantity, taxrate, 0, billstates, order_id, department_id, 
			Posid, region_id, auditdate, skdate, jsye, jsflag, note, summary, invoice,0,0,invoicetotal,invoiceNo,businesstype,guid,
			SendQTY,GatheringMan,jsInvoiceTotal,VIPCardID,Y_ID,begindate,Enddate,WholeQty,PartQty
			from billdtsidxIN where billid=@nbillid

			select @nnewbillid=@@identity
			
			insert into BuymanagebillDrf(bill_id, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,sendQty,SendCostTotal,
                                RowGuid,RowE_id,YcostPrice,YGUID,Y_ID, instoretime,comment2,
								factoryid, costtaxprice, costtaxrate, costtaxtotal)
			select @nnewbillid, p_id, batchno, quantity, costprice, buyprice, discount, discountprice, 
				totalmoney, taxprice, taxtotal, taxmoney, retailprice, retailtotal, makedate, validdate, 
				qualitystatus, price_id, ss_id, sd_id, location_id, supplier_id, commissionflag, 
				comment,unitid,taxrate,order_id,total,iotag,InvoiceTotal,thqty,newprice,orgbillid,aoid,quantity,totalmoney,
                                RowGuid,RowE_id,YcostPrice,YGUID,Y_ID,instoretime, comment2,
								factoryid, costtaxprice, costtaxrate, costtaxtotal
			from BuymanagebilldtsIN
			where bill_id=@nbillid	
			order by smb_id
 
	  fetch next from billdraftidxcur into @nBillid,@nBillType
	end	
	close billdraftidxcur
	deallocate billdraftidxcur
  end
    /*分支机构导入总部数据end */

commit tran


if object_id('tempdb..#tasktmp') is not null
  drop table #tasktmp

truncate table billdtsidxIN
truncate table buymanagebilldtsIN
truncate table salemanagebilldtsIN
truncate table priceidxdtsIN
truncate table PriceBillDtsIN
truncate table CxidxdtsIN
truncate table CxBilldtsIN
GO
