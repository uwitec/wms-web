








CREATE	PROCEDURE ts_c_SetRepConfig
(
	@nE_id int,
	@szRepName varchar(300),
	@repConfig text,
	@nFmStates int=0,
	@nFmWidth  int=0,
  @nFmHeight int=0
)
 AS
/*Params Ini begin*/
if @nFmStates is null  SET @nFmStates = 0
if @nFmWidth is null  SET @nFmWidth = 0
if @nFmHeight is null  SET @nFmHeight = 0
/*Params Ini end*/
set nocount on
if  exists(select * from reportcfg where e_id=@nE_id and repname=@szRepName)
	update reportcfg set repconfig=@repConfig,fmstates=@nFmStates,fmwidth=@nFmWidth,fmHeight=@nFmHeight where e_id=@nE_id and repname=@szRepName
else
	insert reportcfg (e_id,repname,repconfig,fmstates,fmwidth,fmheight) values (@nE_id,@szRepName,@repConfig,@nFmStates,@nfmWidth,@nFmHeight)
GO
