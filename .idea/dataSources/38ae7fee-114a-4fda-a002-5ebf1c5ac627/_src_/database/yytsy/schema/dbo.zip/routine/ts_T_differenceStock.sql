
CREATE PROCEDURE [dbo].[ts_T_differenceStock]
AS
	IF OBJECT_ID('tempdb..#cyStore') IS NOT NULL
	    DROP TABLE #cyStore
	
	IF OBJECT_ID('tempdb..#St1') IS NOT NULL
	    DROP TABLE #st1
	
	DECLARE @nP_id  INT,	/*商品id*/
	        @nS_id  INT,	/*仓库id*/
	        @dQty   NUMERIC(25,8),	/*数量*/
	        @nY_ID  INT
	
	SELECT a.p_id,
	       a.y_id,
	       a.ss_id,
	       a.quantity -(ISNULL(b.quantity, 0)) cyQty INTO #cyStore
	FROM   (
	           SELECT p_id,
	                  Y_ID,
	                  ss_id,
	                  SUM(quantity) quantity
	           FROM   Ysalemanagebilldrf
	           WHERE  p_id > 0
	           GROUP BY
	                  p_id,
	                  Y_ID,
	                  ss_id
	       ) a
	       LEFT JOIN (
	                SELECT p_id,
	                       y_id,
	                       s_id,
	                       SUM(quantity) AS quantity
	                FROM   storehouse
	                WHERE  Y_ID = 2
	                GROUP BY
	                       p_id,
	                       Y_ID,
	                       s_id
	            ) b
	            ON  a.p_id = b.p_id
	            AND a.Y_ID = b.Y_ID
	            AND a.ss_id = b.s_id
	WHERE  ISNULL(b.quantity, 0) <= 0
	
	SELECT TOP 0 p_id,
	       batchno,
	       quantity,
	       costprice,
	       makedate,
	       validdate,
	       location_id,
	       y_id,
	       ss_id,
	       instoretime INTO #St1
	FROM   Ysalemanagebilldrf
	
	DECLARE curP      CURSOR SCROLL 
	FOR
	    SELECT p_id,
	           y_id,
	           ss_id,
	           cyQty  
	    FROM   #cyStore
	
	OPEN curP
	FETCH NEXT FROM curP INTO @nP_id, @ny_id, @nS_ID,@dQty                                            
	WHILE @@fetch_status = 0/*有库存*/
	BEGIN
	    INSERT INTO #St1
	      (
	        p_id,
	        batchno,
	        quantity,
	        costprice,
	        makedate,
	        validdate,
	        location_id,
	        y_id,
	        ss_id,
	        instoretime
	      )
	    SELECT TOP 1 p_id,
	           batchno,
	           @dQty,
	           costprice,
	           makedate,
	           validdate,
	           location_id,
	           y_id,
	           ss_id,
	           instoretime
	    FROM   Ysalemanagebilldrf
	    WHERE  p_id = @nP_id
	           AND Y_ID = @nY_ID
	           AND ss_id = @nS_id
	    
	    FETCH NEXT FROM curP INTO @nP_id, @ny_id, @nS_ID, @dQty
	END 
	CLOSE curp
	DEALLOCATE curP
	
	SELECT y.name AS 门店名称,
	       st.name AS 仓库名称,
	       p.serial_number AS 商名编号,
	       p.name AS 商品名称,
	       p.standard AS 商品规格,
	       p.makearea AS 产地,
	       s.quantity 数量,
	       s.costprice 成本价,
	       s.batchno AS 批号,
	       s.makedate AS 生产日期,
	       s.validdate AS 有效期,
	       l.loc_name AS 货位,
	       s.instoretime AS 入库时间
	FROM   #St1 s
	       LEFT JOIN company y
	            ON  s.y_id = y.company_id
	       LEFT JOIN storages st
	            ON  s.ss_id = st.storage_id
	       LEFT JOIN products p
	            ON  s.p_id = p.product_id
	       LEFT JOIN location l
	            ON  s.location_id = l.loc_id
	ORDER BY
	       s.y_id,
	       s.ss_id,
	       s.p_id
GO
