
create PROCEDURE Ts_L_QrBaseInfo_CLIENTS
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

  if @szwhere <>'2'
  begin
	/*xxx.2017-02-16  增加收货方的模糊查询*/
	if SUBSTRING(@szWhere, 1, 1) = '3'
	begin
		set @nFilterY = CAST(SUBSTRING(@szWhere, 3, 10) as int)
		select c.client_id,c.class_id,c.parent_id,c.child_number,c.child_count,c.serial_number,c.[name],
			   c.alias,c.region_id,c.phone_number,c.address,c.zipcode,c.contact_personal,c.tax_number,
			   c.acount_number,c.pinyin,c.pricemode,c.firstcheck,c.comment,c.csflag,c.deleted,c.ProtocolDate,
			   '' GMPNo,'' as GSPNo,c.Cetype,c.ModifyDate,c.RowIndex,c.IncRate,'' as licence_no,c.ent_type,c.city_id,
			   c.city_name,c.boro_id,c.boro_name,0 as e_id, 0 AS BalanceMode,  c.consignBook_no,
			   '' as organCard_no, 
			   '' as BusinessLicence_no,'' as MassConfer_no,'' as Cer_CustomNO1, '' as Cer_CustomNO2, 
			   '' as Cer_CustomNO3,'' as Cer_CustomNO4,'' as Cer_CustomNO5,
			   0 as credit_total,0 as APcredit_total,0 as sklimit,0 as artotal,0 as discount,
			   0 as artotal_ini,0 as aptotal,0 as aptotal_ini,0 as pre_artotal, 0 as pre_artotal_ini,
			   0 as pre_aptotal, 0 as  pre_aptotal_ini, '' AS RegionName,'' as ename,'' as  cename,
			   '' as CN_PriceMode,'' as StatusName,'' as d1,'' as d2, '' as d5, 		
			   '' as d8, '' as d9, 	'' as d10, ''as d11,'' as d12, '' as d13,'' as d14,'' as d15,'' as d16,
			   c.CreateDate,c.C_Customname1,c.C_Customname2,c.C_Customname3,c.C_Customname4,c.C_Customname5,
			   c.clienttype_id,'' as clienttypename,'' as cardname,c.card_id,
			   c.bywayday,c.RoadID,'' RoadName,c.szOrdernum,cast(c.OrderCredit as int)OrderCredit,c.jsdw_id, 
			   '' as jsName,c.ElecCode,'' lastkpdate,c.AuditStates,'' as AuditStatesStr,'' as AuditEName,'' as AuditDate,      
			   c.auditMan, c.auditComment, c.AddressZC, c.CreateMan,
			   ISNULL(c.ModifyEId, 0) AS ModifyEId,ISNULL(c.FirstOperationTime, '1900-01-01') AS FirstOperationTime,
			   ISNULL(c.LastOperationTime, '1900-01-01') AS LastOperationTime,ISNULL(c.Quality_Phone, '') AS Quality_Phone,
			   ISNULL(c.Quality_Personal, '') AS Quality_Personal, ISNULL(c.QQ, '') AS QQ, 0 as moneyproffer, 0as moneyproffer_int, 
			   0 as mlrateproffer, 0 as mlrateproffer_ini, 0 as operationcount,
			   isnull(c.zljgPeople,'') as zljgPeople,isnull(c.zlglphone,'') as zlglphone,isnull(c.storePeople,'') as storePeople,
			   isnull(c.storephone,'') as storephone,isnull(c.zljgphone,'') as zljgphone,isnull(c.cwPeople,'') as cwPeople,
			   isnull(c.cwphone,'') as cwphone,isnull(c.zlglPeople,'') as zlglPeople,
			   isnull(c.legalphone,'') as legalphone,isnull(c.legalPeople,'') as legalPeople		
        from clients c inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
					on LEFT (u.class_id,len(c.class_id))=c.class_id
		where (c.child_number=0) and (c.name like @szName or c.serial_number like @szName or 
		PinYin like @szName) and ((csFlag=0) or (csFlag=2)) and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0))
			and (c.jsdw_id > 0) and (c.jsdw_id = @nFilterY OR @nFilterY = 0)
	end
	else
	begin
	   SELECT distinct C.*
	   FROM FilterClient(@nY_ID) C inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
					on LEFT (u.class_id,len(c.class_id))=c.class_id
	   WHERE (c.child_number=0) and (c.name like @szName or c.serial_number like @szName or 
		PinYin like @szName) and ((csFlag=@szWhere) or (csFlag=2)) and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0))
    end
  end else
  begin
   SELECT distinct C.*
   FROM FilterClient(@nY_ID) C inner join (select * from AuthorizeClients(@E_id) where Child_Number=0) u
				on LEFT (u.class_id,len(c.class_id))=c.class_id
   WHERE (c.Child_Number=0)
    and (c.[name] like @szName or c.serial_number like @szName or 
    PinYin like @szName) and (@nShowStatus = 0 or (@nShowStatus = 1 and deleted = 0))
  end
GO
