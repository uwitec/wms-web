
/* =============================================*/
/* Author:		ZK*/
/* Create date: 2015-09-09*/
/* Description:	采购退货申请单有选仓库时，读取单据明细表数据*/
/* =============================================*/
CREATE PROCEDURE Ts_K_LoadBillDetailSelBill 
	@nTargetBillType   INT = 0,	   /* 被调单的单据类型*/
	@nBillID           INT = 0,	   /* 单据编号*/
	@nSourceBillType   INT = 0,    /* 调单的单据类型*/
	@nSId              INT = 0,    /* 仓库ID*/
	@nRet              INT OUTPUT  /* 返回值*/
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @nTargetBillType = 20 AND @nSourceBillType = 561  /*采购退货申请单调采购单*/
	begin
		SELECT  '' AS checkaccept, p.alias, b.AOID AS aoid, '' AS AOIDNAME, 
		        CASE WHEN b.thqty < ISNULL(f.quantity, 0) or b.AOID in (6,7) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS applicantqty,   /*XXX.2017-02-13赠品特殊处理，暂时直接取可退货数量，让能调单退货*/
		        p.makearea AS AREA, b.BatchBarCode, 
                b.scomment as Batchcomment, b.batchprice, '' AS returnreason, 
                CASE WHEN b.thqty < ISNULL(f.quantity, 0) or b.AOID in (6,7) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS BASEQTY, 
                b.batchno, b.supplier_id, p.BulidNo, 
                CASE WHEN b.thqty < ISNULL(f.quantity, 0) or b.AOID in (6,7) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS thqty, 
                CASE WHEN b.thqty < ISNULL(f.quantity, 0) or b.AOID in (6,7) THEN b.thqty ELSE ISNULL(f.quantity, 0) END as cansaleqty, 
                '' AS checkreason, 0 AS checkqty, '正常' AS checkstate, p.code, p.Iscold, b.commissionflag as commisionflag, 
                b.costprice, b.costprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS COSTTOTAL, p.Custompro1, p.Custompro2, p.Custompro3, p.Custompro4, 
                p.Custompro5, b.discount, b.discountprice, 
                b.discountprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS discounttotal, 
                b.RowE_id as EID, 0 AS sfdacounts, 
                q.AccountComment as  Factory, '' AS uneligibletransactor, 0 AS uneligibleqty, '' AS uneligiblereason, b.instoretime, b.iotag, 
                @nSId AS s_id, b.location_id, 
                ISNULL(l.loc_name, '') AS LOCATION, 
                b.makedate, p.MedName AS medtype, 
                p.medtype AS MEDTYPEID, p.comment, b.comment2, p.name, b.bill_id AS ORDERID, b.quantity AS Yqty, 
                b.newprice AS Ytaxprice, b.smb_id AS orgbillid, p.PackStd, p.PcName, p.comment AS PCOMMENT, p.permitcode, 
                0 AS pickqty, b.p_id, b.costprice AS price, b.qualitystatus, p.rate2, p.rate3, p.rate4, 0 AS inceptqty, '' AS inceptstate, 
                0 AS refuseqty, '' AS refusereason, p.RegisterNo, 0 AS REMAINING, '' AS checkreport, 0 AS sampleqty, 0 AS SMBID, 
                cast(p.Isspec as Int) as Isspec, p.standard, CASE p.StoreCondition WHEN 2 THEN '冷链' WHEN 1 THEN '阴凉' ELSE '常温' END AS StorageCon, 
                ISNULL(s.name, '') AS STORE, ISNULL(s.flag, 0) AS STOREFLAG, 
                0 AS STORETYPE, 0 AS eligibleqty, 
                b.taxmoney, b.newprice AS taxprice, 0 AS pricediscrepancy, 
                b.buyprice * CASE WHEN b.thqty < ISNULL(f.quantity, 0) THEN b.thqty ELSE ISNULL(f.quantity, 0) END AS total, p.trademark, 
                p.Unit1Name AS UNIT, p.unit1_id AS UNIT1ID, p.Unit1Name, p.unit2_id AS UNIT2ID, p.Unit2Name, p.unit3_id AS UNIT3ID, 
                p.Unit3Name, p.unit4_id AS UNIT4ID, p.Unit4Name, p.unit1_id AS unit_id, b.validdate,  ISNULL(c.name, '') AS VENDOR, 
                ISNULL(s.WholeFlag, 0) AS WholeFlag, 
                p.WholeRate, b.RowGuid AS Yrowguid, b.Y_ID, b.discountprice, b.taxrate, b.taxtotal, p.validmonth, p.validday,p.StoreCondition AS DID,b.FactoryId as Factoryid,
                b.costtaxprice,b.costtaxrate,b.costtaxtotal,0 as OldOrderQty,'' as OldOrderUnit,0 as OldOrderUnitId,0 as OldOrderUnitRate,
                0 AS WholeQty, 0 AS partqty
		FROM    dbo.buymanagebill AS b INNER JOIN dbo.vw_Products AS p ON b.p_id = p.product_id 
		                               left join   basefactory  q on b.FactoryId=q.CommID   
		                               LEFT OUTER JOIN clients as c on c.client_id=b.supplier_id
		                               LEFT JOIN (SELECT * FROM storehouse WHERE s_id = @nSId) f ON b.Y_ID = f.Y_ID AND
		                                                                       b.factoryid = f.factoryid AND b.p_id = f.p_id AND 
		                                                                       b.supplier_id = f.supplier_id AND b.batchno = f.batchno AND 
		                                                                       b.makedate = f.makedate AND b.validdate = f.validdate AND
		                                                                       b.instoretime = f.instoretime AND b.commissionflag = f.commissionflag AND
		                                                                       b.costprice = f.costprice and b.location_id=f.location_id /*AND b.costtaxprice = f.costtaxprice*/
		                               LEFT OUTER JOIN dbo.location AS l ON f.location_id = l.loc_id 
		                               LEFT OUTER JOIN dbo.storages AS s ON f.s_id = s.storage_id                                        
		                               
		WHERE bill_id = @nBillID AND b.thqty > 0
		ORDER BY B.SMB_ID
		
		SET @nRet = 0	
	END
	ELSE
	BEGIN
		SET @nRet = -1
		RAISERROR('LoadDetail ERROR', 16, 1)	
	END
END
GO
