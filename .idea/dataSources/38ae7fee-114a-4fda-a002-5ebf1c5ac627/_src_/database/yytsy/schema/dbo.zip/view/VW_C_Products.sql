

CREATE  VIEW [VW_C_Products]
AS
SELECT PRO.[Product_ID], PRO.[Class_ID], PRO.[Parent_ID], PRO.[Child_number], PRO.[Child_Count], 
      PRO.[Name], PRO.[Alias], PRO.[Standard], PRO.[Modal], PRO.[PermitCode], PRO.[TradeMark], 
      PRO.[MakeArea],PRO.[Factory], PRO.[Rate2], PRO.[Rate3], PRO.[Rate4], PRO.[ValidMonth], PRO.[ValidDay], 
      PRO.[Comment], PRO.[Deleted], PRO.[FirstCheck], PRO.[Pinyin], PRO.[ValidCheck], PRO.[OTCFlag], 
      PRO.[GSPFlag],PRO.[Deduct], PRO.[Costmethod],convert(numeric(25,8),isnull(tx.TaxRate,0))  as  [TaxRate],
       pro.tc1,pro.tc2,pro.tcmoney,pro.EngName,
      pro.ChemName,pro.LatinName,pro.PackStd,pro.StorageCon,pro.RegisterNo,pro.BulidNo, pro.basicMedication,
      PRO.[Serial_Number] AS [Code], pro.unit1_id, pro.unit2_id, pro.unit3_id, pro.unit4_id, 
      ISNULL(U1.[Name], '')  AS UnitName1, 
      ISNULL(U2.[Name], '')  AS UnitName2, 
      ISNULL(U3.[Name], '')  AS UnitName3, 
      ISNULL(U4.[Name], '')  AS UnitName4, 
      ISNULL(M.medtype,'') AS [MedType],
      PRO.Custompro1,PRO.Custompro2,PRO.Custompro3,PRO.Custompro4,PRO.Custompro5,
      PRO.Inputdate,PRO.Inputman ,isnull(PC.pc_name,'')pc_name, isnull(PR.RangeName,'')rname,
      IsSplit,pro.SR2_id,isnull(s2.name,'') as rangename,pro.factoryc_id,pro.cljg,PRO.StandardCode, PRO.CloudCode 
FROM ProductS PRO 
      left   join VW_MedType m on pro.product_id = m.product_id
      LEFT JOIN Unit U1       ON PRO.[Unit1_ID]=U1.[Unit_ID]
      LEFT JOIN Unit U2       ON PRO.[Unit2_ID]=U2.[Unit_ID]
      LEFT JOIN Unit U3       ON PRO.[Unit3_ID]=U3.[Unit_ID]
      LEFT JOIN Unit U4       ON PRO.[Unit4_ID]=U4.[Unit_ID]
      LEFT JOIN (select * from PrintClass where deleted=0) PC ON PC.pc_id=pro.PrintClass
      left   join VW_Range pr on pro.product_id = pr.product_id
	  left join VW_TaxRate  tx on pro.product_id =tx.product_id
      left join SaleRange2 s2 on pro.SR2_id=s2.id
WHERE PRO.[Deleted]<>1 and pro.IsSplit = 0
GO
