
/* =============================================*/
/* Author:	yanrui */
/* Create date: 2013-09-09*/
/* Description:	写往来单位对账表      */
/* =============================================*/
CREATE PROCEDURE [dbo].[ts_y_VerifyAccountRec]
(
  @billid int,
  @smbid  int,
  @dzman  int,
  @vflag  int,  /*-1 确定 2 取消*/
  @vnots  varchar(255)=''
)
AS
BEGIN
  declare @vbilltype int ,@ncount int ,@vcount int 

  set @vbilltype=(select billtype from billidx where billid=@billid)
  if @vflag=1 /*--确定*/
  begin
    if @smbid = 0 
    begin 
      delete VerifyAccountRec where BillID=@billid
      /*插入主表*/
      insert VerifyAccountRec(BillID,BillGuid,smbID,Flag,Note,RowTYPE,dzman)
      select billid,GUID,@smbid,1,@vnots,1,@dzman
      from billidx where billid=@billid
      
      /*插入明细*/
      if  @vbilltype in (10,11)  /*销售*/
      begin       
        insert VerifyAccountRec(BillID,BillGuid,smbID,RowGuid,Flag,Note,RowTYPE,dzman)
        select distinct  b.bill_id,a.GUID,b.smb_id,b.RowGuid,1,@vnots,0,@dzman
        from billidx a
        inner join salemanagebill b on a.billid=b.bill_id
        where a.billid=@billid 
      end 
      if  @vbilltype in (20,21) /*采购*/
      begin       
        insert VerifyAccountRec(BillID,BillGuid,smbID,RowGuid,Flag,Note,RowTYPE,dzman)
        select distinct  b.bill_id,a.GUID,b.smb_id,b.RowGuid,1,@vnots,0,@dzman
        from billidx a
        inner join buymanagebill b on a.billid=b.bill_id
        where a.billid=@billid 
      end  
 
    end
    else
    begin
      delete VerifyAccountRec where BillID=@billid and smbID=@smbid
      /*插入明细*/
      if  @vbilltype in (10,11)  /*销售*/
      begin
        insert VerifyAccountRec(BillID,BillGuid,smbID,RowGuid,Flag,Note,RowTYPE,dzman)
        select distinct  b.bill_id,a.GUID,b.smb_id,b.RowGuid,1,@vnots,0,@dzman
        from billidx a
        inner join salemanagebill b on a.billid=b.bill_id
        where a.billid=@billid and b.smb_id=@smbid 
        /*---如果子项目都全部对账 写入主表对账标志 */
        set @ncount=( select COUNT(1)  from  salemanagebill   where bill_id=@billid) 
        set @vcount=( select COUNT(1)  from  VerifyAccountRec where billid=@billid)
        if @ncount= @vcount 
        begin
          insert VerifyAccountRec(BillID,BillGuid,smbID,Flag,Note,RowTYPE,dzman)
          select billid,GUID,0,1,'已对账',1,@dzman
          from billidx where billid=@billid
        end
      end  
      if  @vbilltype in (20,21)  /*采购*/
      begin
        insert VerifyAccountRec(BillID,BillGuid,smbID,RowGuid,Flag,Note,RowTYPE,dzman)
        select distinct  b.bill_id,a.GUID,b.smb_id,b.RowGuid,1,@vnots,0,@dzman
        from billidx a
        inner join buymanagebill b on a.billid=b.bill_id
        where a.billid=@billid and b.smb_id=@smbid 
        /*---如果子项目都全部对账 写入主表对账标志 */
        set @ncount=( select COUNT(1)  from  buymanagebill   where bill_id=@billid) 
        set @vcount=( select COUNT(1)  from  VerifyAccountRec where billid=@billid)
        if @ncount= @vcount 
        begin
          insert VerifyAccountRec(BillID,BillGuid,smbID,Flag,Note,RowTYPE,dzman)
          select billid,GUID,0,1,'已对账',1,@dzman
          from billidx where billid=@billid
        end  
      end     
    end
  end
  if @vflag=2 /*--取消*/
  begin
    if @smbid = 0 
    begin
      delete VerifyAccountRec where BillID=@billid
    end
    else
    begin
      delete VerifyAccountRec where BillID=@billid and smbID=@smbid
      delete VerifyAccountRec where BillID=@billid and smbID=0
    end  
  end
 
END
GO
