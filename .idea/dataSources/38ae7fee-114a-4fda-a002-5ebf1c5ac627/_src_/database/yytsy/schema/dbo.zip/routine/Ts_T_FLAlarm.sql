Create  procedure  Ts_T_FLAlarm
AS
  select R.serial_number as Rserial,C.serial_number,C.name,R.CName,fc.beginTime,fc.EndTime,fc.intendTime  from RebehoofProtocol R 
  left join FLCondition fc on R.id=fc.RP_id  
  left join clients C on R.c_id=C.client_id  
  where (fc.alarmTime<getdate() or fc.EndTime<GETDATE()) and fc.alarmTime>0 and 
  R.States<>2
GO
