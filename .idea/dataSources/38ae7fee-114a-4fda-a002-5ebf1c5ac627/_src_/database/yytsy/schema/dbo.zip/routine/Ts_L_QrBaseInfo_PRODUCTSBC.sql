
create PROCEDURE Ts_L_QrBaseInfo_PRODUCTSBC
(@TableName varchar(30),
 @szName varchar(8000),
 @szWhere varchar(60)='2',
 @E_id  int=0,
 @nShowStatus int = 0, /*控制往来单位是否显示停用信息, 0 显示，　1　不显示*/
 @nFilterY int=0,	/* 1: 只选择本机构的数据 0:所有分支机构的数据 2:只选择是独立帐套的分支机构 3: 商品精确查找 4,5: 按Product_ID查找*/
 @nY_ID    int=0,   /*机构ID，增加按机构*/
 @nLoginid int=0
 )       
 AS

  declare @Outszname varchar(30)
  set  @Outszname=@szName

  IF (@szName IS NULL) OR (@szName = '')
	SET @szName = '%%'
  ELSE
	SET @szName = '%' + @szName + '%'

   select a.*,b.BatchBarCode,b.batchno
   from vw_Products a,salemanagebill b
   where a.product_id=b.p_id 
   and b.BatchBarCode=@Outszname
GO
