
CREATE FUNCTION FilterVW_L_pDetailBySMBM(@E_ID int)
RETURNS  table 
AS
		RETURN
		SELECT     pd.pd_id, pd.billid, pd.p_id, pd.s_id, pd.quantity, pd.price, pd.total, CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costprice ELSE 0 END AS costprice, 
		                                                                                   CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.costtotal ELSE 0 END AS costtotal,
		                                                                                   CASE WHEN dbo.A_GetSubLimit(@E_ID, 4007, -1) = 1 or p.protectprice = 0 THEN pd.SendCostTotal ELSE 0 END AS SendCostTotal,
		                                                                                   pd.taxprice, pd.taxtotal, pd.batchno, pd.makedate, 
							  pd.validdate, pd.commissionflag, pd.supplier_id, pd.location_id, pd.storetype, pd.price_id, pd.order_id, pd.unitid, pd.smb_id, pd.comment, pd.jsprice, 
							  pd.oldcommissionflag, pd.AOID, pd.ROWE_id, pd.SendQTY, pd.retailtotal, pd.retailprice
		FROM         dbo.VW_L_pDetailBySMBM AS pd INNER JOIN
							  dbo.products AS p ON pd.p_id = p.product_id
GO
