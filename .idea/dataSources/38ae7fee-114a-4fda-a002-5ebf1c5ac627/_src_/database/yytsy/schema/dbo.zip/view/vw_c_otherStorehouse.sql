




CREATE VIEW dbo.vw_c_otherStorehouse
AS
SELECT SH.*,
  ISNULL(P.[Serial_number] ,'') AS [Code],
  ISNULL(P.[Name]          ,'') AS [Pname],
  ISNULL(P.[Alias]         ,'') AS [Alias],
  ISNULL(P.[Standard]      ,'') AS [Standard],
  ISNULL(m.id,0) AS [Medtype],
  ISNULL(P.[Makearea]      ,'') AS [Makearea],
  ISNULL(tx.TaxRate,'') AS [Taxrate],
  ISNULL(P.[Otcflag]       ,'') AS [Otcflag],
  ISNULL(P.[Validmonth]    ,'') AS [Validmonth],
  ISNULL(P.[Permitcode]    ,'') AS [Permitcode],
  ISNULL(P.[IsSplit]       ,0)  AS [IsSplit],
  ''                            AS [CclassID],
  ''                            AS [Cname],
  ''                            AS [Locname],
  ISNULL(S.[Class_ID]      ,'') AS [SClassID],
  ISNULL(S.[Name]          ,'') AS [Sname],
  ISNULL(P.[Class_ID]      ,'') AS [PClassID],
  ISNULL(P.[Rate2]         ,0)  AS [Rate2],
  ISNULL(P.[Rate3]         ,0)  AS [Rate3],
  ISNULL(P.[Rate4]         ,0)  AS [Rate4],
  ISNULL(U1.[Name]         ,'') AS [Name1],
  ISNULL(U2.[Name]         ,'') AS [Name2],
  ISNULL(U3.[Name]         ,'') AS [Name3],
  ISNULL(U4.[Name]         ,'') AS [Name4],
  ISNULL(M.medtype         ,'') AS [MedName],
  ISNULL(Y.Class_id        ,'') as YClass_id,
  ISNULL(Y.[name]          ,'') as Yname
FROM 
  otherstorehouse SH
  LEFT JOIN Products P  ON SH.[P_ID]=P.[Product_ID]
  LEFT JOIN Storages S  ON SH.[S_ID]=S.[Storage_ID]
  LEFT JOIN Unit     U1 ON P.[Unit1_ID]=U1.[Unit_ID]
  LEFT JOIN Unit     U2 ON P.[Unit2_ID]=U2.[Unit_ID]
  LEFT JOIN Unit     U3 ON P.[Unit3_ID]=U3.[Unit_ID]
  LEFT JOIN Unit     U4 ON P.[Unit4_ID]=U4.[Unit_ID]
  left   join 
	  VW_MedType m on p.product_id = m.product_id
  LEFT JOIN Company  Y  ON Y.company_id= SH.Y_id
  left   join 
  VW_TaxRate tx on p.product_id = tx.product_id
GO
