/* =============================================*/
/* Author:	yanrui */
/* Create date: 2013-11-06*/
/* Description:	重庆医保 药品目录 诊疗项目 病种目录 对照表关联本地数据      */
/* =============================================*/
CREATE	  PROCEDURE [Ts_Y_InYbdeddry]
   (
    @Vtype      int,  /*1药品2诊疗3病种*/
    @product_id	int,
    @accnumber   varchar(20),
	@name   varchar(200),
	@nots   varchar(400)
	)
as  
begin
  if @Vtype=1
  begin 
    update MedicaDictionaryA set Pid=@product_id,nots=@nots where   A0=@accnumber and A2=@name
  end;
  if @Vtype=2
  begin 
    update MedicaDictionaryB set Pid=@product_id,nots=@nots where   B0=@accnumber and B2=@name
  end;
  if @Vtype=3
  begin 
    update MedicaDictionaryC set Pid=@product_id,nots=@nots where   C0=@accnumber and C2=@name
  end;
end
GO
