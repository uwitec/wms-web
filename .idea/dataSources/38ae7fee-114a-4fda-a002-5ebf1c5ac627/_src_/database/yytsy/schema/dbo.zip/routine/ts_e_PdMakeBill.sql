create proc ts_e_PdMakeBill
(
	@billid int,
	@BillStatus int,
	@RowNum  int,
	@nRet int output
)
as
set nocount on 
declare @nNewBillid int,@dTotalMoney numeric(20,4),@dQuantity numeric(20,4),@nNewDraftBillid int
declare @billnumber varchar(30),@note varchar(300)
declare @Y_ID		int
declare @c_id int 
declare @Count int
declare @MakeCount int
declare @BeginCount int 
set @BeginCount=1
set @MakeCount=0
set @Count=0
set @c_id=0
set @note=''
set @nNewBillid=0
set @nNewDraftBillid=0
select @Y_ID=Y_Id from  pdplanidx  where pdidx=@billid
select @c_id=sysvalue from sysconfig where Y_ID=@Y_ID and sysname='PosCid'
create table #PosBillNum
(
   RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
   PdPlan_id INT NULL /*盘点计划明细ID */
)
create table #PosCenterBillNum
(
   RecNum INT IDENTITY(1,1) NOT NULL,  /*自增列*/
   PdPlan_id INT NULL /*盘点计划明细ID */
)
begin
    /*找出需要生成批次调整单的批次条件*/
    select  p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
								    into #temp1  
									from pdplan where pdidx=@billid and WMS_PdStatus=2   
    group by p_id,s_id,batchno,supplier_id,validdate,makedate,commissionflag,
									costprice,factoryid,Y_ID
    having SUM(WMS_CheckPdQty - quantity) = 0 
    /*找出需要生成批次调整单的批次信息 */
    select a.PdPlan_id  into #temp2 from pdplan a inner join #temp1 b 
					  on  a.p_id=b.p_id and  a.s_id=b.s_id and a.batchno=b.batchno and a.supplier_id=b.supplier_id
			          and a.validdate=b.validdate and a.makedate=b.makedate
			          and a.commissionflag=b.commissionflag and a.costprice=b.costprice
			          and a.factoryid=b.factoryid and a.Y_ID=b.Y_ID  and a.pdidx=@billid and a.WMS_PdStatus=2
	set @nRet = 0		         
    /*生成盘点单和批次调整单      */
	if @BillStatus=1
	begin
				     /*生成批次调整单*/
				     exec ts_e_BatchNoIsSlipt @billid
				     /*-判断如果已生成了批次调整单的批次信息将不在生成后续单据*/
					 if exists 
					 (
					  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and WMS_PdStatus=2
					      and WMS_CheckPdQty-quantity<>0
					 )
					 begin
							  /*生成盘点单主表*/
							  insert billdraftidx 
							  (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
							  select CONVERT(varchar(100), GETDATE(), 23),'',50,0,0,inputman,k_id,k_id,0,inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
							  from pdplanidx 
							  where pdidx=@billid   
							  select @nNewBillId=@@identity 
							  /*-生成盘点明细表*/
							  insert into GoodsCheckBillDrf  
							  (bill_id,p_id,batchno,quantity,costprice,buyprice,discount, discountprice,totalmoney,
							   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,
							   price_id,ss_id,sd_id,location_id,supplier_id,BatchBarCode, commissionflag,comment,unitid,taxrate,
							   order_id,total,Y_ID,instoretime,bybatch,scomment,batchprice,Conclusion,
							   factoryid,costtaxrate,costtaxprice,costtaxtotal)
							   select @nNewBillId,a.p_id,a.batchno,WMS_CheckPdQty,a.costprice,a.costprice,1,quantity,WMS_CheckPdQty-quantity,
							   quantity,a.costprice*(WMS_CheckPdQty-quantity),WMS_CheckPdQty-quantity,c.retailprice,quantity*c.retailprice,
							   a.makedate,a.validdate,'合格',
							   2,a.s_id,a.s_id,location_id,a.supplier_id,BatchBarCode, a.commissionflag, '',p.unit1_id,0,
							   0,WMS_CheckPdQty*a.costprice,a.Y_ID,instoretime,0,scomment,batchprice,'',
							   a.factoryid,costtaxrate,costtaxprice,costtaxtotal 
							   from pdplan a  left join  (select retailprice,p_id from price where unittype=1) c on a.p_id=c.p_id
											  left join  products p on a.p_id=p.product_id 
							   where  pdidx=@billid and WMS_PdStatus=2  and WMS_CheckPdQty-quantity<>0	and 
							          a.PdPlan_id not in (select PdPlan_id from #temp2)
							set @billnumber='KC'+right(cast(100000000+@nNewBillId as varchar),8)
							set @note='从PDA盘点:【'+@billnumber+'】生成的盘点单'
							select @dTotalMoney=sum(quantity*costprice),@dQuantity=sum(quantity) from GoodsCheckBillDrf where bill_id=@nNewBillId
							update billdraftidx set billnumber=@billnumber,note=@note,quantity=@dQuantity,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney where billid=@nNewBillId
							set @nRet = @nNewBillId 
							set @nNewBillId=0
			       end
			       else
			       begin
			       	 set @nNewBillId=0
			       end
	end 
	if @BillStatus=2/*生成报损报溢单*/
	begin
					/*生成批次调整单*/
					  exec ts_e_BatchNoIsSlipt @billid
					 /*-判断如果已生成了批次调整单的批次信息将不在生成后续单据*/
					 if exists 
					 (
					  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and WMS_PdStatus=2 and 
					  WMS_CheckPdQty-quantity<0
					 )
					 begin
							/*生成报损单主表*/
							insert billdraftidx 
							(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
							select CONVERT(varchar(100), GETDATE(), 23),'',41,0,0,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
							from pdplanidx 
							where pdidx=@billid 
							select @nNewBillId=@@identity
							/*生成报损单明细表*/
							insert storemanagebilldrf
							(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
							 supplier_id,commissionflag,unitid,total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
							select @nNewBillId,a.p_id,a.batchno,abs(WMS_CheckPdQty-quantity),a.costprice,abs((WMS_CheckPdQty-quantity)*a.costprice),
							a.costprice,abs((WMS_CheckPdQty-quantity)*a.costprice),d.retailprice,abs((WMS_CheckPdQty-quantity)*d.retailprice),
							a.makedate,a.validdate,0,a.s_id,a.s_id,location_id,a.supplier_id,a.commissionflag,c.unit1_id,
							abs((WMS_CheckPdQty-quantity)*a.costprice),0, instoretime,a.y_id, costtaxprice, costtaxrate, costtaxtotal, 
							a.factoryid
							from pdplan a left join products c on a.p_id=c.product_id
										  left join (select retailprice,p_id from price where unittype=1)d on a.p_id=d.p_id
							where pdidx=@billid and WMS_CheckPdQty-quantity<0 and a.WMS_PdStatus=2 and
							     a.PdPlan_id not in (select PdPlan_id from #temp2)
							set @billnumber='BS'+right(cast(100000000+@nNewBillId as varchar),8)
							set @note='从PDA盘点:【'+@billnumber+'】生成的报损单'
							select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
							update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
							set @nRet = @nNewBillId 
							set @nNewBillId=0
				   end
				   else
				   begin
				      set @nNewBillId=0
				   end
				   if exists 
				   (
					  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and PdStatus=2 and 
					  WMS_CheckPdQty-quantity>0
				   )
				   begin
							/*生成报溢单主表 */
							insert billdraftidx 
							(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
							select CONVERT(varchar(100), GETDATE(), 23),'',42,0,0,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
							from pdplanidx 
							where pdidx=@billid 
							select @nNewBillId=@@identity
							/*生成报溢单明细表*/
							insert storemanagebilldrf
							(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
							 supplier_id,commissionflag,unitid,total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
							select @nNewBillId,a.p_id,batchno,WMS_CheckPdQty-quantity,costprice,(WMS_CheckPdQty-quantity)*costprice,costprice,(WMS_CheckPdQty-quantity)*costprice,c.retailprice,(CheckPdQty-quantity)*c.retailprice,
							       makedate,validdate,0,s_id,s_id,location_id,supplier_id,commissionflag,b.unit1_id,(WMS_CheckPdQty-quantity)*costprice,0, 
							       instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid
							from pdplan a left join products b on a.p_id=b.product_id
										  left join (select retailprice,p_id from price where unittype=1)c on a.p_id=c.p_id
							where pdidx=@billid and WMS_CheckPdQty-quantity>0 and a.WMS_PdStatus=2 and 
							      a.PdPlan_id not in (select PdPlan_id from #temp2)
							set @billnumber='BY'+right(cast(100000000+@nNewBillId as varchar),8)
							select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
							set @note='从PDA盘点:【'+@billnumber+'】生成的报溢单'
							update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
							set @nRet = @nNewBillId 
							set @nNewBillId=0
				   end
				   else
				   begin
				   	  set @nNewBillId=0
				   end
	end
	if  @BillStatus=3/*生成盘点单，批次调整单，报损报溢单  */
	begin
						 /*生成批次调整单*/
					     exec ts_e_BatchNoIsSlipt @billid
					     /*盘点单*/
					     /*-判断如果已生成了批次调整单的批次信息将不在生成后续单据*/
						 if exists 
						 (
						  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and WMS_PdStatus=2
						                              and WMS_CheckPdQty-quantity<>0
						 )
						 begin
							  /*生成盘点单主表*/
							  insert billdraftidx 
							  (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
							  select CONVERT(varchar(100), GETDATE(), 23),'',50,0,0,inputman,k_id,k_id,0,inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
							  from pdplanidx 
							  where pdidx=@billid  
							  select @nNewBillId=@@identity 
							  /*-生成盘点明细表*/
							  insert into GoodsCheckBillDrf  
							  (bill_id,p_id,batchno,quantity,costprice,buyprice,discount, discountprice,totalmoney,
							   taxprice,taxtotal,taxmoney,retailprice,retailtotal,makedate,validdate,qualitystatus,
							   price_id,ss_id,sd_id,location_id,supplier_id,BatchBarCode, commissionflag,comment,unitid,taxrate,
							   order_id,total,Y_ID,instoretime,bybatch,scomment,batchprice,Conclusion,
							   factoryid,costtaxrate,costtaxprice,costtaxtotal)
							   select @nNewBillId,a.p_id,batchno,WMS_CheckPdQty,costprice,costprice,1,quantity,WMS_CheckPdQty-quantity,
							   quantity,costprice*(WMS_CheckPdQty-quantity),WMS_CheckPdQty-quantity,b.retailprice,
							   quantity*b.retailprice, makedate,validdate,'合格',
							   2,s_id,s_id,location_id,supplier_id,BatchBarCode, commissionflag, '',p.unit1_id,0,
							   0,WMS_CheckPdQty*costprice,Y_ID,instoretime,0,scomment,batchprice,'',
							   factoryid,costtaxrate,costtaxprice,costtaxtotal 
							   from pdplan a left join  (select retailprice,p_id from price where unittype=1) b on a.p_id=b.p_id
											  left join  products p on a.p_id=product_id 
							   where  pdidx=@billid and WMS_PdStatus=2  and WMS_CheckPdQty-quantity<>0	and 
							          a.PdPlan_id not in (select PdPlan_id from #temp2)
								set @billnumber='KC'+right(cast(100000000+@nNewBillId as varchar),8)
								set @note='从PDA盘点:【'+@billnumber+'】生成的盘点单'
								select @dTotalMoney=sum(quantity*costprice),@dQuantity=sum(quantity) from GoodsCheckBillDrf where bill_id=@nNewBillId
							    update billdraftidx set billnumber=@billnumber,note=@note,quantity=@dQuantity,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney where billid=@nNewBillId
								set @nRet = @nNewBillId 
								set @nNewBillId=0
						end
						else
						begin
						    set @nNewBillId=0
						end
						/*报损单*/
						if exists 
						 (
						  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and WMS_PdStatus=2
						                              and WMS_CheckPdQty-quantity<0
						 )
						 begin
								 /*生成报损单主表*/
								insert billdraftidx 
								(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
								select CONVERT(varchar(100), GETDATE(), 23),'',41,0,0,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
								from pdplanidx 
								where pdidx=@billid 
								select @nNewBillId=@@identity
								/*生成报损单明细表*/
								insert storemanagebilldrf
								(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
								 supplier_id,commissionflag,unitid,total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
								select @nNewBillId,a.p_id,batchno,abs(WMS_CheckPdQty-quantity),costprice,abs((WMS_CheckPdQty-quantity)*costprice),costprice,
								abs((WMS_CheckPdQty-quantity)*costprice),c.retailprice,abs((WMS_CheckPdQty-quantity)*c.retailprice),makedate,validdate,0,s_id,s_id,location_id,
								 supplier_id,commissionflag,b.unit1_id,abs((WMS_CheckPdQty-quantity)*costprice),0, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid
								from pdplan a left join products b on a.p_id=b.product_id
											  left join (select retailprice,p_id from price where unittype=1)c on a.p_id=c.p_id
								where pdidx=@billid and WMS_CheckPdQty-quantity<0 and a.WMS_PdStatus=2 and 
							          a.PdPlan_id not in (select PdPlan_id from #temp2)
								set @billnumber='BS'+right(cast(100000000+@nNewBillId as varchar),8)
								set @note='从PDA盘点:【'+@billnumber+'】生成的报损单'
								select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
								update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
								set @nRet = @nNewBillId 
								set @nNewBillId=0
						end
						else
						begin
						     set @nNewBillId=0
						end
						/*-报溢单*/
						if exists 
						 (
						  select 1 from pdplan  where PdPlan_id not in (select PdPlan_id from #temp2)  and pdidx=@billid and WMS_PdStatus=2
						                              and WMS_CheckPdQty-quantity>0
						 )
						 begin
								/*生成报溢单主表*/
								insert billdraftidx 
								(billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,ZBAuditMan,ZBAuditDate)
								select CONVERT(varchar(100), GETDATE(), 23),'',42,0,0,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '',0,'1900-01-01'
								from pdplanidx 
								where pdidx=@billid 
								select @nNewBillId=@@identity
								/*生成报溢单明细表*/
								insert storemanagebilldrf
								(bill_id,p_id,batchno,quantity,price,totalmoney,costprice,costtotal,retailprice,retailmoney,makedate,validdate,price_id,ss_id,sd_id,location_id,
								 supplier_id,commissionflag,unitid,total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid)
								select @nNewBillId,a.p_id,batchno,WMS_CheckPdQty-quantity,costprice,(WMS_CheckPdQty-quantity)*costprice,costprice,
								       (WMS_CheckPdQty-quantity)*costprice,c.retailprice,(WMS_CheckPdQty-quantity)*c.retailprice,makedate,validdate,0,s_id,s_id,location_id,
									   supplier_id,commissionflag,b.unit1_id,(WMS_CheckPdQty-quantity)*costprice,0, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid
								from pdplan a left join products b on a.p_id=b.product_id
											  left join (select retailprice,p_id from price where unittype=1)c on a.p_id=c.p_id
								where pdidx=@billid and WMS_CheckPdQty-quantity>0 and a.WMS_PdStatus=2 and 
							          a.PdPlan_id not in (select PdPlan_id from #temp2)
								set @billnumber='BY'+right(cast(100000000+@nNewBillId as varchar),8)
								select @dTotalMoney=sum(costtotal),@dQuantity=sum(quantity) from storemanagebilldrf where bill_id=@nNewBillId
								set @note='从PDA盘点:【'+@billnumber+'】生成的报溢单'
								update billdraftidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber where billid=@nNewBillId
								set @nRet = @nNewBillId 
								set @nNewBillId=0
						end
						else
						begin
						      set @nNewBillId=0
						end
	end
	if  @BillStatus=4/*生成零售单和零售退货单*/
	begin
	     /*生成批次调整单*/
		 exec ts_e_BatchNoIsSlipt @billid
	     /*-判断如果已生成了批次调整单的批次信息将不在生成后续单据*/
		 if exists (select PdPlan_id from pdplan where PdPlan_id not in  (select PdPlan_id from #temp2)
		                and pdidx=@billid and WMS_CheckPdQty-quantity<0 and WMS_PdStatus=2)
		 begin
						     insert into #PosBillNum(PdPlan_id)
						     select PdPlan_id from pdplan where PdPlan_id not in  (select PdPlan_id from #temp2)
						                                and pdidx=@billid and WMS_CheckPdQty-quantity<0 and WMS_PdStatus=2  
						     while 1=1 
						     begin

						                     /*生成零售单主表*/
											 insert retailbillidx 
												 (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,
												  period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,auditdate,skdate)
												  select CONVERT(varchar(100), GETDATE(), 23),'',12,0,@c_id,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '','1900-01-01 00:00:00.000','1900-01-01 00:00:00.000'
												  from pdplanidx where pdidx=@billid 
												  select @nNewBillId=@@identity
												  /*生成零售单明细*/
							                  insert retailbill(
														 bill_id,p_id,batchno,quantity,totalmoney,taxtotal, costprice,retailprice,retailtotal,
														 makedate,validdate,price_id,ss_id,sd_id,location_id, supplier_id,commissionflag,unitid,discount,discountprice,
														 total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid,saleprice,taxprice
												 )
							                   select   @nNewBillId,a.p_id,batchno,abs(WMS_CheckPdQty-quantity),abs(WMS_CheckPdQty-quantity)*retailprice,abs(CheckPdQty-quantity)*retailprice,costprice,retailprice,abs(CheckPdQty-quantity)*retailprice,
														 makedate,validdate,0,s_id,s_id,location_id,supplier_id,commissionflag,b.unit1_id,1,retailprice*1,
														 abs(WMS_CheckPdQty-quantity)*retailprice,0, instoretime, Y_ID, costtaxprice, costtaxrate, abs(CheckPdQty-quantity)*costtaxprice, factoryid,retailprice,retailprice
													from pdplan a inner join (select * from #PosBillNum where RecNum between @BeginCount and @RowNum) q on a.PdPlan_id=q.PdPlan_id
													              left join products b on a.p_id=b.product_id
																  left join (select retailprice,p_id from price where unittype=1)c on a.p_id=c.p_id
													where pdidx=@billid and WMS_CheckPdQty-quantity<0 and a.WMS_PdStatus=2 and 
														  a.PdPlan_id not in (select PdPlan_id from #temp2)
											   set @billnumber='LS'+right(cast(100000000+@nNewBillId as varchar),8)
											   select @dTotalMoney=sum(taxtotal),@dQuantity=sum(quantity) from retailbill where bill_id=@nNewBillId
											   set @note='从PDA盘点:【'+@billnumber+'】生成的零售单'
											   update retailbillidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber,quantity=@dQuantity where billid=@nNewBillId
											   set @nRet = @nNewBillId 
											   set @nNewBillId=0     
											   delete   from #PosBillNum where RecNum between @BeginCount and @RowNum
											   truncate table #PosCenterBillNum
											   insert into #PosCenterBillNum(PdPlan_id)
											   select PdPlan_id from #PosBillNum
											   truncate table #PosBillNum
											   insert into #PosBillNum(PdPlan_id)
											   select  PdPlan_id from #PosCenterBillNum
											   select @Count=count(*) from #PosBillNum
											   if @Count=0 
											   begin
											     break
											   end
							 end
		 end
		 else
		 begin
		    set @nNewBillId=0
		 end
	     /*生成零售退货单*/
		 if exists (select PdPlan_id from pdplan where PdPlan_id not in  (select PdPlan_id from #temp2)
		                and pdidx=@billid and WMS_CheckPdQty-quantity>0 and WMS_PdStatus=2)
		 begin  
	                         truncate table #PosBillNum
	                         truncate table #PosCenterBillNum
						     insert into #PosBillNum(PdPlan_id)
						     select PdPlan_id from pdplan where PdPlan_id not in  (select PdPlan_id from #temp2)
						            and pdidx=@billid and WMS_CheckPdQty-quantity>0 and WMS_PdStatus=2  
							 while 1=1 
							 begin
										  	    /*-生成零售退货主表*/
													   insert retailbillidx 
													  (billdate,billnumber,billtype,a_id,c_id,e_id,sout_id,sin_id,auditman,inputman,ysmoney,ssmoney,quantity,taxrate,
													   period,billstates,order_id,department_id,posid,region_id,Y_ID, summary,auditdate,skdate)
													   select CONVERT(varchar(100), GETDATE(), 23),'',13,0,@c_id,inputman,k_id,k_id,'',inputman,0,0,0,0,0,'2',0,0,0,0,Y_Id, '','1900-01-01 00:00:00.000','1900-01-01 00:00:00.000'
													   from pdplanidx where pdidx=@billid 
													   select @nNewBillId=@@identity
													   /*-生成零售退货明细表*/
													   insert retailbill
																   (
																   bill_id,p_id,batchno,quantity,totalmoney,taxtotal, costprice,retailprice,retailtotal,
																   makedate,validdate,price_id,ss_id,sd_id,location_id, supplier_id,commissionflag,unitid,discount,discountprice,
																   total,aoid, instoretime, Y_ID, costtaxprice, costtaxrate, costtaxtotal, factoryid,saleprice,taxprice
																   )
													   select   @nNewBillId,a.p_id,batchno,abs(WMS_CheckPdQty-quantity),abs(WMS_CheckPdQty-quantity)*retailprice,abs(WMS_CheckPdQty-quantity)*retailprice,costprice,retailprice,abs(CheckPdQty-quantity)*retailprice,
																 makedate,validdate,0,s_id,s_id,location_id,supplier_id,commissionflag,b.unit1_id,1,retailprice*1,
																 abs(WMS_CheckPdQty-quantity)*retailprice,0, instoretime, Y_ID, costtaxprice, costtaxrate, abs(WMS_CheckPdQty-quantity)*costtaxprice, factoryid,retailprice,retailprice
															from pdplan a inner join (select * from #PosBillNum where RecNum between @BeginCount and @RowNum) q on a.PdPlan_id=q.PdPlan_id
															              left join products b on a.p_id=b.product_id
																		  left join (select retailprice,p_id from price where unittype=1)c on a.p_id=c.p_id
															where pdidx=@billid and WMS_CheckPdQty-quantity>0 and a.WMS_PdStatus=2 and 
																  a.PdPlan_id not in (select PdPlan_id from #temp2)
													   set @billnumber='LS'+right(cast(100000000+@nNewBillId as varchar),8)
													   select @dTotalMoney=sum(taxtotal),@dQuantity=sum(quantity) from retailbill where bill_id=@nNewBillId
													   set @note='从PDA盘点:【'+@billnumber+'】生成的零售退货单'
													   update retailbillidx set note=@note,ysmoney=@dTotalMoney,ssmoney=@dTotalMoney,billnumber=@billnumber,quantity=@dQuantity where billid=@nNewBillId
													   set @nRet = @nNewBillId 
													   set @nNewBillId=0
													   delete   from #PosBillNum where RecNum between @BeginCount and @RowNum
													   truncate table #PosCenterBillNum
													   insert into #PosCenterBillNum(PdPlan_id)
													   select PdPlan_id from #PosBillNum
													   truncate table #PosBillNum
													   insert into #PosBillNum(PdPlan_id)
													   select  PdPlan_id from #PosCenterBillNum
													   select @Count=count(*) from #PosBillNum
													   if @Count=0
													   begin
													      break
													   end 
							end
										  
		        end  
		        else
			    begin
					set @nNewBillId=0
			    end     	
    end  
end  
    drop table #temp1
	drop table #temp2
	drop table #PosBillNum
	drop table #PosCenterBillNum
GO
