







/*根据不同的价格方式返回商品各种价格*/
/*nUnitMode : =1 基本单位；＝2 大单位1；＝3 大单位2；＝4 大单位3*/
CREATE procedure ts_c_GetPrice
(
	@szParent_id varchar(30),
	@nUnitMode int,
	@szListFlag		char(1)='L'			/*显示方式 A：全部列表 P：部分列表 L: 分级显示*/
)
/*with encryption*/
as
/*Params Ini begin*/
if @szListFlag is null  SET @szListFlag = 'L'
/*Params Ini end*/
if @szListFlag='L' goto listleveal
if @szListFlag='A' goto listall
if @szListFlag='P' goto listpart

listleveal:
if @nUnitMode=1
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit1_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.parent_id=@szParent_id and p.deleted<>1
	order by p.product_id
end
if @nUnitMode=2
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit2_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.parent_id=@szParent_id and p.deleted<>1
	order by p.product_id
end else
if @nUnitMode=3
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit3_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.parent_id=@szParent_id and p.deleted<>1
	order by p.product_id
end else 
if @nUnitMode=4
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit4_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.parent_id=@szParent_id and p.deleted<>1
	order by p.product_id
end

return 0

listpart:
if @nUnitMode=1
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit1_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where left(p.class_id,len(@szParent_id))=@szParent_id and p.deleted<>1 and product_id<>1 and p.child_number=0 
	order by p.product_id
end
if @nUnitMode=2
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit2_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where left(p.class_id,len(@szParent_id))=@szParent_id and p.deleted<>1 and product_id<>1 and p.child_number=0
	order by p.product_id
end else
if @nUnitMode=3
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit3_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where left(p.class_id,len(@szParent_id))=@szParent_id and p.deleted<>1 and product_id<>1 and p.child_number=0
	order by p.product_id
end else 
if @nUnitMode=4
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit4_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where left(p.class_id,len(@szParent_id))=@szParent_id and p.deleted<>1 and product_id<>1 and p.child_number=0
	order by p.product_id
end
return 0

listall:
if @nUnitMode=1
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit1_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.child_number=0 and p.deleted<>1 and product_id<>1
	order by p.product_id
end
if @nUnitMode=2
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit2_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.child_number=0 and p.deleted<>1 and product_id<>1
	order by p.product_id
end else
if @nUnitMode=3
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit3_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.child_number=0 and p.deleted<>1 and product_id<>1
	order by p.product_id
end else 
if @nUnitMode=4
begin
	select p.product_id,p.[name],isnull(pri.u_id,0) as u_id,isnull(pri.retailprice,0) as retailprice,isnull(pri.recprice,0) as recprice,
	isnull(pri.price1,0) as price1,isnull(pri.price2,0) as price2,isnull(pri.price3,0) as price3,isnull(pri.price4,0) as price4,isnull(pri.gpprice,0) as gpprice,isnull(pri.glprice,0) as glprice,isnull(pri.specialprice,0) as specialprice,isnull(u.[name],'') as unitname
	from products p left join price pri on p.product_id=pri.p_id and p.unit4_id=pri.u_id left join unit u on u.unit_id=pri.u_id
	where p.child_number=0 and p.deleted<>1 and product_id<>1
	order by p.product_id
end

return 0
GO
