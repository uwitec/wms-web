
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2014-2-15*/
/* Description:	GSP流程单据操作*/
/* =============================================*/
CREATE PROCEDURE TS_H_GspBillAct 
	@nAct int = 0,		/* 操作类型 2: 反审核 3：审核 4：删除*/
	@nBillID int = 0,
	@nBillType int = 0,
	@nEid int = 0,
	@bForce bit = 0		/* 强制处理*/
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @bForce IS NULL SET @bForce = 0
	
	DECLARE @nTransFlag INT
	DECLARE @nBillStates INT
	DECLARE @nAudit1 int
	DECLARE @nAudit2 int
	DECLARE @nRet int
	DECLARE @nNextBillType int
	DECLARE @nCur int
	DECLARE @uYGuid uniqueidentifier
	DECLARE @uCurGuid uniqueidentifier
	DECLARE @nOldBillType int
	DECLARE @nNewBillType int
	DECLARE @nNewBillID int
	DECLARE @nSid int
	DECLARE @nStoreCondition int
	DECLARE @SQL VARCHAR(8000)

	BEGIN TRAN SETSTATES

	SET @nRet = 0
	/* 创建临时表用于保存本张单据下一步单据列表*/
	CREATE TABLE #TMPNEXT(flag varchar(10), billid int, billstates int)
	/* 创建临时表保存本单明细的orgbillid*/
	SELECT OrgBillid INTO #TMPORG
	FROM GSPbilldetail WHERE Gspbill_id = @nBillID
	/* 反审核*/
	IF @nAct = 2
	BEGIN
		/* 订单*/
		IF @nBillType IN (14, 22)
		BEGIN
			SELECT @nBillStates = BillStates, @nAudit1 = AuditMan, @uYGuid = Guid, @uCurGuid = GUID FROM orderidx WHERE billid = @nBillID
			/* 强制处理不作判断*/
			IF @bForce <> 1
			BEGIN
				/* 单据未审核*/
				IF @nBillStates = 10
					SET @nRet = -1
				ELSE
				/* 非当前职员审核*/
				IF @nAudit1 <> @nEid
					SET @nRet = -2
			END
			/* 检测下一步单据状态*/
			/* 只判断本单生成的下一步单据*/
			IF @nRet = 0
			BEGIN
				/* 取出所有已生成单据*/
				/* GSP单据*/
				INSERT INTO #TMPNEXT(flag, billid, billstates)
				SELECT 'G', billId, BILLSTATES FROM VW_BILLTRACE WHERE lastId in (SELECT id FROM billTrace WHERE billId = @nBillID AND billType = @nBillType) AND BillType BETWEEN 501 AND 599
				/*SELECT 'G', Gspbillid, BillStates */
				/*FROM GSPbillidx*/
				/*WHERE BillType IN(SELECT DISTINCT NEXTVCH FROM VchFlow WHERE VchType = @nBillType)*/
				/*AND Yguid = @uYGuid AND Gspbillid IN(SELECT Gspbill_id FROM GSPbilldetail WHERE OrgBillid IN(SELECT OrgBillid FROM #TMPORG))*/

				/* 下一步单据已审核*/
				IF EXISTS(SELECT * FROM #TMPNEXT WHERE billstates > 10)
					SET @nRet = -3
			END
			IF @nRet = 0
			BEGIN
				/* 单据存档*/
				DECLARE curBill SCROLL CURSOR FOR
				SELECT billid FROM #TMPNEXT WHERE flag = 'G'
				OPEN curBill
				FETCH NEXT FROM curBill INTO @nNewBillID
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SELECT @nNewBillType = BillType FROM GSPbillidx WHERE GSPbillid = @nNewBillID
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nNewBillID AS VARCHAR(50)) + ', ' + CAST(@nNewBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					FETCH NEXT FROM curBill INTO @nNewBillID
				END
				CLOSE curBill
				DEALLOCATE curBill
				
				/* 删除下一步单据*/
				DELETE FROM GSPbilldetail WHERE Gspbill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')
				DELETE FROM GSPbillidx WHERE Gspbillid IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')

				/* 修改当前单据状态*/
				IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
				BEGIN
					SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
					EXEC(@SQL)
				END
				UPDATE orderidx SET AuditMan = 0, auditdate = '1900-1-1', billstates = 2 WHERE billid = @nBillID
			END			
		END
		ELSE
		/* GSP单据*/
		IF @nBillType BETWEEN 501 AND 599
		BEGIN
			SELECT @nTransFlag = transflag, @nBillStates = BillStates, @nAudit1 = AuditMan1, @nAudit2 = AuditMan2, @uYGuid = Yguid, @uCurGuid = GUID
			  FROM GSPbillidx 
			WHERE Gspbillid = @nBillID
			/* 强制处理不作判断*/
			IF @bForce <> 1
			BEGIN
				/* 单据未审核*/
				IF @nBillStates = 10
					SET @nRet = -1
				ELSE
				/* 非当前职员审核*/
				IF @nAudit1 <> @nEid AND @nAudit2 <> @nEid
					SET @nRet = -2
				ELSE
				/* 单据已下传*/
				IF @nTransFlag <> 0
					SET @nRet = -11
			END
			/* 检测下一步单据状态*/
			/* 只判断本单生成的下一步单据*/
			IF @nRet = 0
			BEGIN
				/* 取出所有已生成单据*/
				INSERT INTO #TMPNEXT(flag, billid, billstates)
				SELECT tableTag, billId, BILLSTATES FROM VW_BILLTRACE WHERE lastId in 
					(SELECT ID FROM billTrace WHERE billId = @nBillID AND billType = @nBillType)
				
				/* 下一步单据已审核*/
				IF EXISTS(SELECT * FROM #TMPNEXT WHERE (billstates > 10 OR billstates = 3) AND billstates <> 14)
					SET @nRet = -3
				ELSE
				/* 下一步单据已过账*/
				IF EXISTS(SELECT * FROM #TMPNEXT WHERE billstates = 0)
					SET @nRet = -4
			END
			IF @nRet = 0
			BEGIN
				/* 单据存档*/
				DECLARE curBill SCROLL CURSOR FOR
				SELECT billid FROM #TMPNEXT WHERE flag = 'G'
				OPEN curBill
				FETCH NEXT FROM curBill INTO @nNewBillID
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SELECT @nNewBillType = BillType FROM GSPbillidx WHERE GSPbillid = @nNewBillID
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nNewBillID AS VARCHAR(50)) + ', ' + CAST(@nNewBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					FETCH NEXT FROM curBill INTO @nNewBillID
				END
				CLOSE curBill
				DEALLOCATE curBill

				/* 单据存档*/
				DECLARE curBill SCROLL CURSOR FOR
				SELECT billid FROM #TMPNEXT WHERE flag in('B', 'S') AND BillStates IN (2, 3)
				OPEN curBill
				FETCH NEXT FROM curBill INTO @nNewBillID
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SELECT @nNewBillType = BillType FROM billdraftidx WHERE billid = @nNewBillID
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nNewBillID AS VARCHAR(50)) + ', ' + CAST(@nNewBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					FETCH NEXT FROM curBill INTO @nNewBillID
				END
				CLOSE curBill
				DEALLOCATE curBill
				/* 删除下一步单据*/
				DELETE FROM GSPbilldetail WHERE Gspbill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')
				DELETE FROM GSPbillidx WHERE Gspbillid IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')
				DELETE FROM buymanagebilldrf WHERE bill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'B')
				DELETE FROM salemanagebilldrf WHERE bill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'S')
				DELETE FROM billdraftidx WHERE billid IN(SELECT billid FROM #TMPNEXT WHERE flag IN('B', 'S'))

				/* 修改当前单据状态*/
				IF @bForce <> 1
				BEGIN
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END

					IF @nAudit1 = @nEid
						UPDATE GSPbillidx SET AuditMan1 = 0, AuditTime1 = '1900-1-1' WHERE Gspbillid = @nBillID
					ELSE
					IF @nAudit2 = @nEid
						UPDATE GSPbillidx SET AuditMan2 = 0, AuditTime2 = '1900-1-1' WHERE Gspbillid = @nBillID
					IF EXISTS(SELECT * FROM GSPbillidx WHERE Gspbillid = @nBillID AND (AuditMan1 > 0 OR AuditMan2 > 0))
						UPDATE GSPbillidx SET BillStates = 12 WHERE Gspbillid = @nBillID
					ELSE
						UPDATE GSPbillidx SET BillStates = 10 WHERE Gspbillid = @nBillID
				END
				ELSE
				BEGIN
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					UPDATE GSPbillidx SET AuditMan1 = 0, AuditTime1 = '1900-1-1', AuditMan2 = 0, AuditTime2 = '1900-1-1' WHERE Gspbillid = @nBillID
					UPDATE GSPbillidx SET BillStates = 10 WHERE Gspbillid = @nBillID
				END
				/* 采购收货单扣减订单完成数量*/
				IF @nBillType IN(511, 513, 515)
				BEGIN
					EXEC TS_H_GspQtyAct @nBillType, @nBillID, -1
				END else IF @nBillType=512 /*增加销售退回收货*/
					EXEC TS_H_GspQtyAct @nBillType, @nBillID, 1
			END
		END
	END
	ELSE
	/* 审核*/
	IF @nAct = 3
	BEGIN
		IF @nBillType BETWEEN 501 AND 599
		BEGIN
			SELECT @nBillStates = BillStates, @nAudit1 = AuditMan1, @nAudit2 = AuditMan2, @uYGuid = Yguid, @nSid = S_id FROM GSPbillidx WHERE Gspbillid = @nBillID
			SET @nStoreCondition = -1
			SELECT @nStoreCondition = storeCondition FROM storages WHERE storage_id = @nSid
			/* 判断是否录入仓库*/
			IF @nBillType IN(531, 541, 551, 561, 562, 525)
			BEGIN
				IF @nSid = 0
					SET @nRet = -7
				IF EXISTS(SELECT * FROM GSPbilldetail WHERE S_id = 0 AND Gspbill_id = @nBillID)
					SET @nRet = -7
				IF EXISTS(SELECT * FROM GSPbilldetail D INNER JOIN storages S ON D.S_id = S.storage_id WHERE (D.Iscold = 1) AND (S.storeCondition <> 2) AND D.Gspbill_id = @nBillID)
					SET @nRet = -7
				IF EXISTS(SELECT *
					FROM dbo.GSPbilldetail AS D LEFT OUTER JOIN
						 dbo.location AS L ON D.Location_id = L.loc_id
					WHERE (D.Gspbill_id = @nBillID) AND D.S_id - L.s_id <> 0 AND D.Location_id > 0)
					SET @nRet = -7
				IF EXISTS(SELECT * FROM GSPbilldetail WHERE CostPrice <= 0 AND P_id > 0 and Aoid in (0,5,7) AND Gspbill_id = @nBillID)  /*XXX.2017-06-30 这儿要剔除掉零成本赠品*/
					SET @nRet = -7
			END
			/* 判断是否录入检验报告*/
			IF @nBillType BETWEEN 521 AND 524
			BEGIN
				IF EXISTS(SELECT *
					FROM dbo.GSPbilldetail AS D INNER JOIN
						 dbo.products AS P ON D.P_id = P.product_id
					WHERE (D.Gspbill_id = @nBillID) AND (P.isCheckReport = 1) AND (D.CheckReport = ''))
					SET @nRet = -9
				IF EXISTS(SELECT *
					FROM dbo.GSPbilldetail 
					WHERE (Gspbill_id = @nBillID) AND (UneligibleQty > 0) AND (UneligibleTranSactor = ''))
					SET @nRet = -10
			END
			/* 单据已审核*/
			IF @nBillStates IN (13, 15)
				SET @nRet = -5
			ELSE
			IF @nAudit1 = @nEid OR @nAudit2 = @nEid
				SET @nRet = -5
				
			IF @nRet = 0
			BEGIN
				IF @nBillType IN (561, 562)
				BEGIN
					/*是否拥有质管部审核权限*/
					IF dbo.A_GetSubLimit(@nEid, 756, -1) = 1
					BEGIN
						IF @nAudit2 <= 0
						BEGIN
							IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
							BEGIN
								SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
								EXEC(@SQL)
							END
							UPDATE GSPbillidx SET AuditMan2 = @nEid, AuditTime2 = GETDATE() WHERE Gspbillid = @nBillID
							SET @nAudit2 = @nEid	
						END
						ELSE
							SET @nRet = -5	
					END
					ELSE
						/*SET @nRet = -8*/
					/*是否拥有采购退回申请单或销售退回申请单权限*/
					IF (dbo.A_GetSubLimit(@nEid, 9511, -1) = 1) OR (dbo.A_GetSubLimit(@nEid, 9512, -1) = 1)
					BEGIN
						IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
						BEGIN
							SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
							EXEC(@SQL)
						END
						IF @nAudit1 <= 0
						BEGIN
							UPDATE GSPbillidx SET AuditMan1 = @nEid, AuditTime1 = GETDATE() WHERE Gspbillid = @nBillID
							if @nBillType=512 
							begin
						    	update GSPbilldetail set InceptQty=ApplicantQty where Gspbill_id= @nBillID
							end
						    SET @nAudit1 = @nEid
						END
						ELSE
							SET @nRet = -5		
					END
					ELSE
						SET @nRet = -8
				END
				ELSE 
				BEGIN
					IF @nAudit1 = 0
					BEGIN
						IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
						BEGIN
							SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
							EXEC(@SQL)
						END
						UPDATE GSPbillidx SET AuditMan1 = @nEid, AuditTime1 = GETDATE() WHERE Gspbillid = @nBillID
						if @nBillType=512 
						    begin
							    update GSPbilldetail set InceptQty=ApplicantQty where Gspbill_id= @nBillID
						    end	
						SET @nAudit1 = @nEid
					END
					ELSE
					IF @nAudit2 = 0
					BEGIN
						IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
						BEGIN
							SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
							EXEC(@SQL)
						END
						UPDATE GSPbillidx SET AuditMan2 = @nEid, AuditTime2 = GETDATE() WHERE Gspbillid = @nBillID
						SET @nAudit2 = @nEid
					END	
				END
				/* 直接置为已审核*/
				IF @nRet < 0
					GOTO ACTERROR
				IF @nBillType IN(511, 512, 513, 514, 531, 541, 515, 525, 564,516,517)
				BEGIN
					UPDATE GSPbillidx SET BillStates = 13 WHERE Gspbillid = @nBillID
					/* 拣货单审核时更新拣货人*/
					IF @nBillType IN (541)
						UPDATE GSPbillidx SET B_CustomName4 = CAST(@nEid AS VARCHAR(10)), B_CustomName5 = (SELECT NAME FROM employees WHERE emp_id = @nEid)
						WHERE Gspbillid = @nBillID AND B_CustomName4 = ''
				END
				ELSE
				IF @nBillType IN (561, 562,563)
				BEGIN
					IF @nAudit1 > 0 AND @nAudit2 > 0
						UPDATE GSPbillidx SET BillStates = 13 WHERE Gspbillid = @nBillID
					Else	
				        UPDATE GSPbillidx SET BillStates = 12 WHERE Gspbillid = @nBillID
				END
				ELSE
				/* 下列单据需要判断是否有特殊药品*/
				IF @nBillType IN(521, 522, 523, 524, 551)
				BEGIN
					IF @nAudit1 > 0 AND @nAudit2 > 0
						UPDATE GSPbillidx SET BillStates = 13 WHERE Gspbillid = @nBillID
					ELSE
					IF EXISTS(SELECT * FROM GSPbilldetail WHERE Gspbill_id = @nBillID AND Isspec = 1)
						UPDATE GSPbillidx SET BillStates = 12 WHERE Gspbillid = @nBillID
					ELSE
						UPDATE GSPbillidx SET BillStates = 13 WHERE Gspbillid = @nBillID
				END
				/* 审核完成之后生成下一步单据*/
				IF (EXISTS(SELECT * FROM GSPbillidx WHERE Gspbillid = @nBillID AND BillStates = 13)) AND (@nBillType <> 564)
				BEGIN
					SELECT @nOldBillType = Ybilltype FROM GSPbillidx WHERE Gspbillid = @nBillID
					SELECT @nNewBillType = NextVch FROM VchFlow WHERE VchType = @nBillType AND LastVch = @nOldBillType
					IF (@nBillType = 525) AND (@nNextBillType = 106)
						SET @nNewBillType = 104
					EXEC TS_H_CreateNewGspBill @nBillID, @nBillType, @nNewBillType, @nNewBillID output
					IF @nNewBillID < 0
					BEGIN
						SET @nRet = -6
						GOTO ACTERROR
					END
				END
			END
		END
	END
	ELSE
	/* 删除*/
	IF @nAct = 4
	BEGIN
		IF @nBillType BETWEEN 501 AND 599
		BEGIN
			SELECT @nTransFlag = transflag, @nBillStates = BillStates, @nAudit1 = AuditMan1, @nAudit2 = AuditMan2, @uYGuid = Yguid
			  FROM GSPbillidx 
			WHERE Gspbillid = @nBillID
			/* 单据未审核*/
			IF @nBillStates IN(10, 14)
			BEGIN
				/* 取出所有已生成单据*/
				INSERT INTO #TMPNEXT(flag, billid, billstates)
				SELECT tableTag, billId, BILLSTATES FROM VW_BILLTRACE WHERE lastId in (SELECT id FROM billTrace WHERE billId = @nBillID AND billType = @nBillType)
				
				/* 下一步单据已审核*/
				IF EXISTS(SELECT * FROM #TMPNEXT WHERE billstates > 10 OR billstates = 3)
					SET @nRet = -3
				ELSE
				/* 下一步单据已过账*/
				IF EXISTS(SELECT * FROM #TMPNEXT WHERE billstates = 0)
					SET @nRet = -4
			END
			ELSE
				SET @nRet = -5
			IF @nRet = 0
			BEGIN
				/* 单据存档*/
				DECLARE curBill SCROLL CURSOR FOR
				SELECT billid FROM #TMPNEXT WHERE flag = 'G'
				OPEN curBill
				FETCH NEXT FROM curBill INTO @nNewBillID
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SELECT @nNewBillType = BillType FROM GSPbillidx WHERE GSPbillid = @nNewBillID
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nNewBillID AS VARCHAR(50)) + ', ' + CAST(@nNewBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					FETCH NEXT FROM curBill INTO @nNewBillID
				END
				CLOSE curBill
				DEALLOCATE curBill

				/* 单据存档*/
				DECLARE curBill SCROLL CURSOR FOR
				SELECT billid FROM #TMPNEXT WHERE flag in('B', 'S') AND BillStates IN (2, 3)
				OPEN curBill
				FETCH NEXT FROM curBill INTO @nNewBillID
				WHILE @@FETCH_STATUS = 0
				BEGIN
					SELECT @nNewBillType = BillType FROM billdraftidx WHERE billid = @nNewBillID
					IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
					BEGIN
						SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nNewBillID AS VARCHAR(50)) + ', ' + CAST(@nNewBillType AS VARCHAR(10)) + ', 0'
						EXEC(@SQL)
					END
					FETCH NEXT FROM curBill INTO @nNewBillID
				END
				CLOSE curBill
				DEALLOCATE curBill
				/* 删除下一步单据*/
				DELETE FROM GSPbilldetail WHERE Gspbill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')
				DELETE FROM GSPbillidx WHERE Gspbillid IN(SELECT billid FROM #TMPNEXT WHERE flag = 'G')
				DELETE FROM buymanagebilldrf WHERE bill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'B')
				DELETE FROM salemanagebilldrf WHERE bill_id IN(SELECT billid FROM #TMPNEXT WHERE flag = 'S')
				DELETE FROM billdraftidx WHERE billid IN(SELECT billid FROM #TMPNEXT WHERE flag IN('B', 'S'))
				/* 删除当前单据*/
				IF EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'BILLHISTORY')
				BEGIN
					SET @SQL = 'EXEC TS_H_BillToXml ' + CAST(@nBillID AS VARCHAR(50)) + ', ' + CAST(@nBillType AS VARCHAR(10)) + ', 0'
					EXEC(@SQL)
				END
				DELETE FROM GSPbilldetail WHERE Gspbill_id = @nBillID
				DELETE FROM GSPbillidx WHERE Gspbillid = @nBillID
			END
		END
	END
	/*SELECT * FROM #TMPORG*/
	/*SELECT * FROM #TMPNEXT*/

	DROP TABLE #TMPORG
	DROP TABLE #TMPNEXT

	COMMIT TRAN SETSTATES
	RETURN @nRet

ACTERROR:
	DROP TABLE #TMPORG
	DROP TABLE #TMPNEXT
	ROLLBACK TRAN SETSTATES

	RETURN @nRet
END
GO
