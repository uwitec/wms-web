/*****************
-企业业务经营状况表
*****************/
CREATE PROCEDURE WebApp_RepCompanyDealIn
( 
	@params VARCHAR(200)
 )
--WITH ENCRYPTION
AS
BEGIN
DECLARE @BeginDate  DATETIME,@EndDate DATETIME,@OperatorID INT
select @BeginDate = dbo.webapp_get_param(@params, 'begindate', default, default)
select @EndDate = dbo.webapp_get_param(@params, 'enddate', default, default)
select @OperatorID = dbo.webapp_get_param(@params, 'operatorid', default, default)
--Params Ini begin
if @BeginDate is null  SET @BeginDate = 0
if @EndDate is null  SET @EndDate = 0
if @OperatorID is null  SET @OperatorID = 1
--Params Ini end

declare @nTotalType int, @TT_TOTAL int, @TT_TOTALMONEY int, @TT_TAXTOTAL int
declare @szBusinessType varchar(10),
	@szBillType varchar(100)

set @TT_TOTAL      = 1
set @TT_TOTALMONEY = 2
set @TT_TAXTOTAL   = 3
set @nTotalType=@TT_TAXTOTAL

set @begindate=convert(varchar(10),@begindate,20)
set @enddate=convert(varchar(10),@enddate,20)+' 23:59:59'

----汇总清单表
if exists(select 1 from tempdb.dbo.sysobjects where id = object_id('tempdb.dbo.#Com_Total')) drop table #Com_Total
create table #Com_Total
(
	PageIndex	int not null default 0,  
	BillType	int not null default 0,  
	[Name]		varchar(100) default '',
	Total           numeric(20,8) not null default 0
)


if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_BuyMX'))    drop table #Com_BuyMX		--采购系列
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleMX'))   drop table #Com_SaleMX	--销售系列
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store1MX')) drop table #Com_Store1MX	--库存系列1
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_GroupMX'))  drop table #Com_GroupMX	--组装差价
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_OrderMX'))  drop table #Com_OrderMX	--采购、销售订单系列
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store2MX')) drop table #Com_Store2MX	--库存系列2
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store3MX')) drop table #Com_Store3MX	--库存系列3
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account1MX')) drop table #Com_Account1MX	--科目系列1
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account2MX')) drop table #Com_Account2MX	--科目系列2
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHK'))   drop table #Com_SaleHK	--销售回款
if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHKskd'))   drop table #Com_SaleHKskd	--销售回款收款


INSERT INTO #Com_Total([PageIndex], [BillType], [Name], [Total]) 
SELECT 101, 20, '', 0	UNION ALL
SELECT 101, 21, '', 0	UNION ALL
SELECT 101, 28, '', 0	UNION ALL
SELECT 101, 47, '', 0	UNION ALL
SELECT 101, 48, '', 0	UNION ALL
SELECT 101, 35, '', 0	UNION ALL
SELECT 101, 122, '', 0	UNION ALL
SELECT 101, 1021, '', 0	UNION ALL
SELECT 101, 1022, '', 0	UNION ALL
SELECT 101, 1023, '', 0	UNION ALL
SELECT 101, 1024, '', 0	UNION ALL
SELECT 102, 1000, '', 0	UNION ALL
SELECT 102, 1001, '', 0	UNION ALL
SELECT 102, 18, '', 0	UNION ALL
SELECT 102, 46, '', 0	UNION ALL
SELECT 102, 49, '', 0	UNION ALL
SELECT 102, 32, '', 0	UNION ALL
SELECT 102, 112, '', 0	UNION ALL
SELECT 102, 1013, '', 0	UNION ALL
SELECT 102, 1014, '', 0	UNION ALL
SELECT 102, 1015, '', 0	UNION ALL
SELECT 102, 1016, '', 0	UNION ALL
SELECT 102, 1201, '', 0	UNION ALL
SELECT 102, 1202, '', 0	UNION ALL
SELECT 102, 1203, '', 0	UNION ALL
SELECT 103, 30, '', 0	UNION ALL
SELECT 103, 33, '', 0	UNION ALL
SELECT 103, 31, '', 0	UNION ALL
SELECT 103, 34, '', 0	UNION ALL
SELECT 103, 50, '', 0	UNION ALL
SELECT 103, 41, '', 0	UNION ALL
SELECT 103, 42, '', 0	UNION ALL
SELECT 103, 40, '', 0	UNION ALL
SELECT 103, 43, '', 0	UNION ALL
SELECT 104, 2101, '', 0	UNION ALL
SELECT 104, 2102, '', 0	UNION ALL
SELECT 104, 62, '', 0	UNION ALL
SELECT 104, 60, '', 0	UNION ALL
SELECT 104, 61, '', 0	UNION ALL
SELECT 104, 2001, '', 0	UNION ALL
SELECT 104, 2002, '', 0	UNION ALL
SELECT 104, 2003, '', 0	UNION ALL
SELECT 104, 2004, '', 0	
--UNION ALL
--SELECT 105, 2201, '', 0	UNION ALL
--SELECT 105, 2202, '', 0	UNION ALL
--SELECT 105, 2203, '', 0	


----1----
/*************采购入库单、退货单、换货单、受托代销结算单、借进转采购单************/
	set @szBusinessType='0,7,6'  
	set @szBillType='20,21,28,122,35' --采购入库单、采购退货单、采购换货单、受托代销结算单、借进转采购单
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_BuyMX_Idx'))    drop table #Com_BuyMX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_BuyMX_Mx'))    drop table #Com_BuyMX_Mx
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_BuyMX_Idx
 	FROM BillIdx bi 	      
	WHERE [billtype]   IN (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	AND [billstates] = 0 --IN (SELECT Type FROM DBO.DecodeStr(@szBillStates)) 
	AND [c_id]  IN (SELECT Client_ID FROM AuthorizeClients(@OperatorID)) 
	
	SELECT bill_id as bill_id, AOID, IoTag, Quantity, CostPrice, Total, TotalMoney, TaxTotal--, PClass_ID
	INTO #Com_BuyMX_Mx
	FROM BuyManagebill --BuyManagebill--VW_X_BuyMB 
	WHERE AOID IN (SELECT Type FROM DBO.DecodeStr(@szBusinessType))
	  AND bill_id in (select billid from #Com_BuyMX_Idx)
	  
	----明细
	SELECT * INTO #Com_BuyMX FROM
	(
		SELECT 
			B.[BillID],                  B.[Billtype],                  B.[BillDate],
			CASE WHEN (((B.[BillType] IN (21,25)) OR (B.[BillType] IN (28) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR
			(((B.[BillType] IN (20,24,35,122)) OR (B.[BillType] IN (28) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			THEN -A.[Quantity] ELSE A.[Quantity] END 										AS [Quantity],
			CASE WHEN (((B.[BillType] IN (21,25)) OR (B.[BillType] IN (28) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR
			(((B.[BillType] IN (20,24,35,122)) OR (B.[BillType] IN (28) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			THEN -A.[Quantity]*A.[CostPrice] ELSE A.[Quantity]*A.[CostPrice] END 							AS [CostTotal],
			CASE WHEN (((B.[BillType] IN (21,25)) OR (B.[BillType] IN (28) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR
			(((B.[BillType] IN (20,24,35,122)) OR (B.[BillType] IN (28) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			THEN -A.[Total] ELSE A.[Total] END 											AS [Total],
			CASE WHEN (((B.[BillType] IN (21,25)) OR (B.[BillType] IN (28) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR
			(((B.[BillType] IN (20,24,35,122)) OR (B.[BillType] IN (28) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			THEN -A.[TotalMoney] ELSE A.[TotalMoney] END 										AS [TotalMoney],
			CASE WHEN (((B.[BillType] IN (21,25)) OR (B.[BillType] IN (28) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			(((B.[BillType] IN (20,24,35,122)) OR (B.[BillType] IN (28) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			THEN -A.[TaxTotal] ELSE A.[TaxTotal] END 										AS [TaxTotal]
		FROM #Com_BuyMX_Mx A
		INNER JOIN #Com_BuyMX_Idx B
		ON B.[billid]=A.[bill_id]
		WHERE (b.[billtype] IN (35,122))
		   OR (b.[billtype] IN (28) AND a.[IoTag]=1 ) 
		   OR NOT (b.[billtype] IN (28) AND a.[IoTag]=1) 
	) T
	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  101,
		BillType,
--	set @szBillType='20,21,28,122,35' --采购入库单、采购退货单、采购换货单、受托代销结算单、借进转采购单
		'',
		case when @nTotalType=@TT_TOTAL      then SUM([Total])
		     when @nTotalType=@TT_TOTALMONEY then SUM([TotalMoney])
		     when @nTotalType=@TT_TAXTOTAL   then SUM([Taxtotal]) else 0 end  AS [Total]
	FROM #Com_BuyMX
	GROUP BY [BillType]


----2----
/*************零售单、零售退货单、销售出库单、销售退货单、销售换货单、委托代销结算单、借出转销售单************/
	set @szBusinessType='0,7,6,8'  
	set @szBillType='12,13,10,11,18,112,32'
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleMX_Idx'))    drop table #Com_SaleMX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleMX_Mx'))    drop table #Com_SaleMX_Mx
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_SaleMX_Idx
	FROM BillIdx  BI
	WHERE [billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [billtype] IN (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	  AND [billstates]=0 -- IN (SELECT Type FROM DBO.DecodeStr(@szBillStates)) 
	  AND [C_id] IN (SELECT CLIENT_ID FROM AuthorizeClients(@OperatorID)) 
	  
	SELECT bill_id as bill_id, AOID, IoTag, Quantity, CostPrice, Total, TotalMoney, TaxTotal--, PClass_ID
	INTO #Com_SaleMX_Mx
	FROM Salemanagebill --SaleManageBill--VW_X_SaleMB 
	WHERE AOID IN (SELECT Type FROM DBO.DecodeStr(@szBusinessType))-- AND (RootP_ID=0 OR RootP_ID=ParentP_ID)
	  AND BILL_ID IN (SELECT BILLID FROM #Com_SaleMX_Idx)
	
	SELECT * INTO #Com_SaleMX FROM
	(
		SELECT 
			B.[BillID],                  B.[Billtype],                  B.[BillDate],
			CASE WHEN (((B.[BillType] IN (11,13,17)) OR (B.[BillType] IN (18) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			       (((B.[BillType] IN (10,12,16,32,112)) OR (B.[BillType] IN (18) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			  THEN -A.[Quantity] ELSE A.[Quantity] END 										AS [Quantity],
			CASE WHEN (A.[AOID] IN (6,8)) THEN 0.0 
			  WHEN (((B.[BillType] IN (11,13,17)) OR (B.[BillType] IN (18) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			       (((B.[BillType] IN (10,12,16,32,112)) OR (B.[BillType] IN (18) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			  THEN -A.[Quantity]*A.[CostPrice] ELSE A.[Quantity]*A.[CostPrice] END 							AS [CostTotal],
			CASE WHEN (((B.[BillType] IN (11,13,17)) OR (B.[BillType] IN (18) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			       (((B.[BillType] IN (10,12,16,32,112)) OR (B.[BillType] IN (18) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			  THEN -A.[Total] ELSE A.[Total] END 											AS [Total],
			CASE WHEN (((B.[BillType] IN (11,13,17)) OR (B.[BillType] IN (18) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			       (((B.[BillType] IN (10,12,16,32,112)) OR (B.[BillType] IN (18) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			  THEN -A.[TotalMoney] ELSE A.[TotalMoney] END 										AS [TotalMoney],
			CASE WHEN (((B.[BillType] IN (11,13,17)) OR (B.[BillType] IN (18) AND A.[IoTag]=0)) AND (B.[billstates] IN ('0','1'))) OR 
			       (((B.[BillType] IN (10,12,16,32,112)) OR (B.[BillType] IN (18) AND A.[IoTag]=1)) AND (B.[billstates] IN ('4')))
			  THEN -A.[TaxTotal] ELSE A.[TaxTotal] END 										AS [TaxTotal]
		FROM #Com_SaleMX_Mx A
		INNER JOIN #Com_SaleMX_Idx B
	      ON B.[billid]=A.[bill_id] 
	    	 WHERE (b.[billtype] IN (32,112))
	            OR (b.[billtype] IN (18) AND a.[IoTag]=1) 
		    OR NOT (b.[billtype] IN (18) AND a.[IoTag]=1) 
	  ) T


	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  102,
		CASE WHEN BillType in (10,12) THEN 1000
		     WHEN BillType in (11,13) THEN 1001
		     ELSE BillType END,
		'',
		Total
	FROM (
		SELECT 
			BillType,
			case when @nTotalType=@TT_TOTAL      then SUM([Total])
			     when @nTotalType=@TT_TOTALMONEY then SUM([TotalMoney])
			     when @nTotalType=@TT_TAXTOTAL   then SUM([Taxtotal]) else 0 end  AS [Total]
		FROM #Com_SaleMX
		GROUP BY [BillType]
	) A



----3----
/*************报损单、报溢单、库存成本调价差、赠送单、获赠单、其他入库单、其他出库单************/
	set @szBusinessType='0'  
	set @szBillType='41,42,43,46,47,48,49'


	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store1MX_Idx'))    drop table #Com_Store1MX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store1MX_Mx'))    drop table #Com_Store1MX_Mx
	
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_Store1MX_Idx
	FROM BillIDX  BI
	WHERE [billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [billtype] IN (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	  AND [billstates]=0 -- IN (SELECT Type FROM DBO.DecodeStr(@szBillStates)) 
	  AND [C_id] IN (SELECT CLIENT_ID FROM AuthorizeClients(@OperatorID)) 
	  
	SELECT A.BILL_ID,A.QUANTITY,A.COSTPRICE,A.COSTTOTAL,A.TOTALMONEY,A.TOTAL 
	INTO #Com_Store1MX_Mx
	FROM STOREMANAGEBILL A
	WHERE AOID IN (SELECT Type FROM DBO.DecodeStr(@szBusinessType))
	  --AND [STATUS]=0
	  AND BILL_ID IN (SELECT BILLID FROM #Com_Store1MX_Idx)

	SELECT * INTO #Com_Store1MX FROM
	(
		SELECT B.BillId, B.BillType, B.BillDate, 
	        ISNULL(SUM(A.[Quantity]), 0) AS [Quantity], 
	        ISNULL(SUM(A.[Costprice]*A.[Quantity]), 0) AS [Costtotal],
	        ISNULL(SUM(A.[TotalMoney]), 0) AS [Taxtotal],
	        ISNULL(SUM(A.[TotalMoney]) - SUM(A.[CostTotal]),0) as Balance,
	        ISNULL(SUM(A.[total]),0) as Total,
	        ISNULL(SUM(A.[TotalMoney]),0) as TotalMoney
	        FROM #Com_Store1MX_Mx A INNER  JOIN                 
	        #Com_Store1MX_Idx B ON B.[BillID]=A.[Bill_ID] 
		GROUP BY B.BillId, B.BillType, B.BillDate
	) AS T
	
	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  CASE WHEN billtype in (41,42) THEN 103
		     WHEN billtype in (47,48) THEN 101
		     WHEN billtype in (46,49) THEN 102 END,
		BillType,
		'',
		case when @nTotalType=@TT_TOTAL      then SUM([Total])
		     when @nTotalType=@TT_TOTALMONEY then SUM([TotalMoney])
		     when @nTotalType=@TT_TAXTOTAL   then SUM([Taxtotal]) else 0 end  AS [Total]
	FROM #Com_Store1MX
	WHERE BillType<>43	--除库存成本调价差以外的单据
	GROUP BY [BillType]
	
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  103,
		BillType,
		'',
		SUM([Balance]) AS [Total]
	FROM #Com_Store1MX
	WHERE BillType=43	--库存成本调价差
	GROUP BY [BillType]


----4----
/*************组装差价*************/
	set @szBusinessType='0'  
	set @szBillType='40'
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_GroupMX_Idx'))    drop table #Com_GroupMX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_GroupMX_Mx'))    drop table #Com_GroupMX_Mx
	
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_GroupMX_Idx
	FROM BillIDX  BI
	WHERE [billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [billstates]=0 
	  AND [Billtype]=40 
	  AND [C_id] IN (SELECT CLIENT_ID FROM AuthorizeClients(@OperatorID)) 
	  
	SELECT A.BILL_ID,A.IOTAG,A.P_ID,A.QUANTITY,A.TOTALMONEY
	INTO #Com_GroupMX_Mx
	FROM STOREMANAGEBILL A
	WHERE AOID IN (SELECT Type FROM DBO.DecodeStr(@szBusinessType))
	  --[STATUS]=0
	  AND ( (A.iotag = 0 and A.[SS_ID] IN (select Storage_ID FROM AuthorizeStorage(@OperatorID))) OR
	               (A.iotag = 1 and A.[SD_ID] IN (select Storage_ID FROM AuthorizeStorage(@OperatorID)))
		      ) 
	  AND BILL_ID IN (SELECT BILLID FROM #Com_GroupMX_Idx)
	
	SELECT * INTO #Com_GroupMX FROM
	(
	
		SELECT B.BillId, B.BillType, B.BillDate,
		      OutQty   = SUM(ISNULL((case when A.iotag = 0 then A.Quantity else 0 end),0)) ,
		      OutMoney = SUM(ISNULL((case when A.iotag = 0 then A.totalMoney else 0 end),0)) ,
		      InQty   = SUM(ISNULL((case when A.iotag = 1 then A.Quantity else 0 end),0)),              
		      InMoney  = SUM(ISNULL((case when A.iotag = 1 then A.totalMoney else 0 end),0)) 
	
		FROM #Com_GroupMX_Mx A 
		LEFT JOIN #Com_GroupMX_Idx B ON B.[BillID]=A.[Bill_ID]
		INNER JOIN Products P ON A.[P_ID] = P.[Product_ID]
		WHERE P.[Deleted] <> 1 
		GROUP BY B.BillId, B.BillType, B.BillDate 
	) AS T
	
	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  103,
		BillType,
		'',
		SUM([InMoney])-SUM([OutMoney]) AS [Total]
	FROM #Com_GroupMX
	GROUP BY [BillType]



----5----
/*************采购订货金额、到货金额、未到货金额*************/
	set @szBusinessType='0'  
	set @szBillType='14,22'
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_OrderMX_Idx'))    drop table #Com_OrderMX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_OrderMX_Mx'))    drop table #Com_OrderMX_Mx
	
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_OrderMX_Idx
	FROM BillIDX  BI
	WHERE [billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [Billtype] in (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	  AND [C_id] IN (SELECT CLIENT_ID FROM AuthorizeClients(@OperatorID)) 
	  
	SELECT bill_id,Quantity,discountPrice,costprice,ComeQty,0 AS BusinessType,aoid,0 AS status,'' as PClass_ID, taxrate as rate,
		case when aoid = 7 then 0.0 else TaxTotal end 						as TaxTotal,
		case when aoid = 7 then 0.0 else Total end 						as total,
		case when aoid = 7 then 0.0 else TotalMoney end 					as TotalMoney
	INTO #Com_OrderMX_Mx
	FROM orderbill                   
	WHERE [SS_ID] IN (select Storage_ID FROM AuthorizeStorage(@OperatorID)  union all select 0)
	  and p_id > 0
	  and bill_id in (select billid from #Com_OrderMX_Idx)
	  
	
	SELECT * INTO #Com_OrderMX FROM 
	(
		SELECT  B.BillId, B.BillType, B.BillDate,
			ISNULL(SUM(A.[Quantity]), 0) 												AS [Quantity], 
			ISNULL(SUM(A.[discountPrice]*A.[Quantity]/a.[rate]), 0) 								AS [Costtotal], 
			ISNULL(SUM(A.[TaxTotal]), 0) 												AS [Taxtotal],	
			ISNULL(SUM(A.[ComeQty]) ,0) 												As FinishQty,
			ISNULL(SUM(A.[ComeQty]/A.[Quantity] * A.[Total]),0) 									As FinishTotal,
			ISNULL(SUM(Case when (A.[Quantity] >= A.[ComeQty]) and (A.[BusinessType]=0)
			then (A.[Quantity] - A.[ComeQty]) 
			else 0 end) ,0) 													As UnFinishQty,
			ISNULL(SUM(Case when (A.[Quantity] >= A.[ComeQty]) and (A.[BusinessType]=0) and (A.[Quantity]<>0 and A.[Total] <>0)
			  then (A.[Quantity] - A.[ComeQty])/A.[Quantity] * A.[Total] 
			  else 0 end) ,0) 													As UnFinishTotal,
			ISNULL(SUM(Case when A.[Quantity] <= A.[ComeQty] then (A.[ComeQty] - A.[Quantity]) else 0 end) ,0) 			As OverQty,
			
			ISNULL(SUM(CASE WHEN (A.[BusinessType] = 1) AND A.[ComeQty] < A.[Quantity] THEN (A.[Quantity] - ISNULL(A.[ComeQty],0))
			ELSE 0 END),0) 														AS QFinishQty,
			ISNULL(SUM(Case when (A.[Quantity] >= A.[ComeQty]) and (A.[BusinessType]=1) and (A.[Quantity]<>0 and A.[Total]<>0 )
			then (A.[Quantity] - A.[ComeQty])/A.[Quantity] * A.[Total] 
			else 0 end) ,0) 													As QFinishTotal,
			ISNULL(SUM(A.[total]),0) 												as Total,
			ISNULL(SUM(A.[TotalMoney]),0) 												as TotalMoney	
		FROM #Com_OrderMX_Mx A              
		JOIN #Com_OrderMX_Idx B ON B.[BillID]=A.[Bill_ID]
		WHERE A.[Status]=0  
		GROUP BY B.BillId, B.BillType, B.BillDate
	) AS T
	
	----汇总插入  
	--订货金额
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  CASE WHEN BillType=22 THEN 101 ELSE 102 END,
		CASE WHEN BillType=22 THEN 1022 ELSE 1014 END 	AS BillType,'', Total
	FROM (
		SELECT BillType,
			case when @nTotalType=@TT_TOTAL      then SUM([Total])
			     when @nTotalType=@TT_TOTALMONEY then SUM([TotalMoney])
			     when @nTotalType=@TT_TAXTOTAL   then SUM([Taxtotal]) else 0 end  	AS [Total]
		FROM #Com_OrderMX
		GROUP BY [BillType]
	)A
	--到货、出货金额
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  CASE WHEN BillType=22 THEN 101 ELSE 102 END,
		CASE WHEN BillType=22 THEN 1023 ELSE 1015 END 	AS BillType,'', Total
	FROM (
		SELECT BillType,
			SUM([FinishTotal]) AS [Total]
		FROM #Com_OrderMX
				--WHERE FinishTotal<>0
		GROUP BY [BillType]
	)A
	--未到货、未出货金额
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  CASE WHEN BillType=22 THEN 101 ELSE 102 END,
		CASE WHEN BillType=22 THEN 1024 ELSE 1016 END 	AS BillType,'', Total
	FROM (
		SELECT BillType,SUM([UnFinishTotal]) AS [Total]
		FROM #Com_OrderMX
				--WHERE UnFinishTotal<>0
		GROUP BY [BillType]
	)A



----6----
/*************借出单、借出还回单、借进单、借进还出单*************/
	set @szBusinessType='0'  
	set @szBillType='30,31,33,34'
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store2MX_Idx'))    drop table #Com_Store2MX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store2MX_Mx'))    drop table #Com_Store2MX_Mx
	
	SELECT billid, Billtype, BillDate, billstates
	INTO #Com_Store2MX_Idx
	FROM BillIDX  BI
	WHERE [billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [Billstates]=0
	  AND [Billtype] in (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	  AND [C_id] IN (SELECT CLIENT_ID FROM AuthorizeClients(@OperatorID)) 
	  
	SELECT bill_id,Quantity,costprice,totalmoney,total
	INTO #Com_Store2MX_Mx
	FROM StoreManagebill--VW_X_StoreMB
	WHERE [SS_ID] IN (select Storage_ID FROM AuthorizeStorage(@OperatorID)  union all select 0)
	  --AND [Status]=0 
	  and bill_id in (select billid from #Com_Store2MX_Idx)
	
	SELECT * INTO #Com_Store2MX FROM 
	(
		SELECT B.BillId, B.BillType, B.BillDate,
		       ISNULL(SUM(A.[Quantity]), 0) AS [Quantity], 
		       ISNULL(SUM(A.[Costprice]*A.[Quantity]), 0) AS [Costtotal],
		       ISNULL(SUM(A.[TotalMoney]), 0) AS [Taxtotal],
		       ISNULL(SUM(A.[total]),0) as Total,
		       ISNULL(SUM(A.[TotalMoney]),0) as TotalMoney
		FROM #Com_Store2MX_Mx A INNER  JOIN                               
		#Com_Store2MX_Idx B ON B.[BillID]=A.[Bill_ID]
		GROUP BY B.BillId, B.BillType, B.BillDate
	) AS T
	
	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  103,
		BillType,
		'',
		case when @nTotalType=@TT_TOTAL      then SUM([Total])
		     when @nTotalType=@TT_TOTALMONEY then SUM([TotalMoney])
		     when @nTotalType=@TT_TAXTOTAL   then SUM([Taxtotal]) else 0 end  AS [Total]
	FROM #Com_Store2MX
	GROUP BY [BillType]




----7----
/*************库存盘点单*************/
	set @szBusinessType='0,6'  
	set @szBillType='50'
	
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store3MX_Idx'))    drop table #Com_Store3MX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Store3MX_Mx'))    drop table #Com_Store3MX_Mx
	SELECT BillId, BillType, BillDate 
	INTO #Com_Store3MX_Idx
	FROM BillIDX 
	WHERE [Billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [Billstates]=0 
  	  AND [Billtype] in (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
  	    	 
	SELECT BILL_ID,TOTALMONEY,TAXTOTAL
	INTO #Com_Store3MX_Mx
	FROM GoodsCheckBill--VW_X_GoodsMB
	WHERE [SS_ID] IN (SELECT Storage_ID FROM dbo.AuthorizeStorage(@OperatorID) UNION SELECT '') 
	  --AND  [Status]=0   
	  AND AOID IN (SELECT Type FROM DBO.DecodeStr(@szBusinessType))
	  AND BILL_ID IN (SELECT BILLID FROM #Com_Store3MX_Idx)

	SELECT * INTO #Com_Store3MX FROM 
	(
	        SELECT  B.BillId, B.BillType, B.BillDate, 
		        ISNULL(SUM(A.[TotalMoney]), 0) AS [Quantity],  
		        ISNULL(SUM(A.[TaxTotal]), 0)   AS [TaxTotal]
	        FROM #Com_Store3MX_Mx A JOIN #Com_Store3MX_Idx B            
	        ON B.[BillID]=A.[Bill_ID]  
		GROUP BY B.BillId, B.BillType, B.BillDate 
	) AS T 
	
	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  103,
		BillType,
		'',
		SUM([Taxtotal]) AS [Total]
	FROM #Com_Store3MX
	GROUP BY [BillType]





----8----
/*************应收金额、应付金额、预收金额、预付金额*************/


	DECLARE @AR_ID     VARCHAR(30), --应收
	        @AP_ID     VARCHAR(30), --应付
		@PreAR_ID  VARCHAR(30), --预收
		@PreAP_ID  VARCHAR(30)  --预付
	   
	SELECT @AR_ID=[Class_ID] FROM Account WHERE [Account_ID]=9
	SELECT @AP_ID=[Class_ID] FROM Account WHERE [Account_ID]=15
	SET @PreAR_ID='000002000006'
	SET @PreAP_ID='000001000009'
	if exists(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#temp_arap_c'))         drop table #temp_arap_c 
	--if exists(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#temp_arap')) drop table #temp_arap 
          


	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account1MX_Idx'))    drop table #Com_Account1MX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account1MX_Mx'))    drop table #Com_Account1MX_Mx
	
      
	create table #temp_arap_c
	(
		class_id  varchar(30),
		client_id int,
		Artotal   float,
		Aptotal   float,
		Artotal_ini float,
		Aptotal_ini float,
		pre_artotal_ini float,
		pre_aptotal_ini float,
		pre_artotal float,
		pre_aptotal float
	)

	insert into #temp_arap_c(class_id,client_id,Artotal,Aptotal,Artotal_ini,Aptotal_ini,pre_artotal_ini,
				pre_aptotal_ini,pre_artotal,pre_aptotal)
	select Class_ID,client_id,Artotal,Aptotal,Artotal_ini,Aptotal_ini, pre_artotal_ini,pre_aptotal_ini,pre_artotal,pre_aptotal
	from Clients 
	where client_id in (select client_id  from dbo.AuthorizeClients(@OperatorID)) 
	  and deleted<>1
	union all
	select c.class_id,c.client_id,
		sum(a.Artotal) as Artotal,sum(a.Aptotal) as aptotal,sum(a.Artotal_ini) as Artotal_ini,
		sum(a.Aptotal_ini) as Aptotal_ini,sum(a.pre_artotal_ini) as pre_artotal_ini,
		sum(a.pre_aptotal_ini) as pre_aptotal_ini,
		sum(a.pre_artotal) as pre_artotal,
		sum(a.pre_aptotal) as pre_aptotal
	FROM Clientsbalance a,clients c
	where  a.c_id=c.client_id
	  --and c_id in (select client_id  from dbo.AuthorizeClients(@OperatorID)) 
	  and deleted<>1
	group by c.class_id,c.client_id



	SELECT [BillID], convert(varchar(10),billdate,20) as [BillDate], c_id
	INTO #Com_Account1MX_Idx
	FROM billidx
	WHERE [Billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [BillStates]=0
	  AND (c_id   in (select client_id from #temp_arap_c union select 0) and billtype not in (78,79) ) 
	  
	SELECT [CClass_ID] AS [Class_ID], [BILLID], [AClass_ID], [JdMoney] 
	INTO #Com_Account1MX_Mx
	FROM VW_X_ADetail 
	WHERE BILLID IN (SELECT BILLID FROM #Com_Account1MX_Idx)
	  AND [AClass_ID] IN (@AR_ID,@AP_ID,@PreAR_ID,@PreAP_ID)
	  

	SELECT B.[AClass_ID],
		ISNULL(CASE WHEN SUM(A.[Artotal]-A.[Aptotal])>0 THEN SUM(A.[Artotal]-A.[Aptotal]) ELSE 0 END, 0) AS [Artotal], 
		ISNULL(CASE WHEN SUM(A.[Artotal]-A.[Aptotal])<0 THEN -(SUM(A.[Artotal]-A.[Aptotal])) ELSE 0 END, 0) AS [Aptotal], 
		ISNULL(CASE WHEN SUM(B.[NowArTotal]-B.[NowApTotal])>0 THEN SUM(B.[NowArTotal]-B.[NowApTotal]) ELSE 0 END, 0) AS [NowArTotal], 
		ISNULL(CASE WHEN SUM(B.[NowArTotal]-B.[NowApTotal])<0 THEN -SUM(B.[NowArTotal]-B.[NowApTotal]) ELSE 0 END, 0) AS [NowApTotal], 
		ISNULL(SUM(B.NOWPREARTOTAL),0)   AS NOWPREARTOTAL,
		ISNULL(SUM(B.NOWPREAPTOTAL),0)   AS NOWPREAPTOTAL
	INTO #Com_Account1MX
	FROM #temp_arap_c A LEFT JOIN
	(
		SELECT AD.[Class_ID],AD.[AClass_ID],
			ISNULL(SUM(CASE WHEN [AClass_ID]=@AR_ID AND BI.[BillDate] BETWEEN @BeginDate
			 AND @EndDate THEN [JdMoney] END), 0) AS [NowArTotal], 
			ISNULL(SUM(CASE WHEN [AClass_ID]=@AP_ID AND BI.[BillDate] BETWEEN @BeginDate
			AND @EndDate THEN [JdMoney] END), 0) AS [NowApTotal],
                      ISNULL(SUM(CASE WHEN [AClass_ID]=@PreAR_ID AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate THEN [JdMoney] END), 0) AS [NowPreArTotal],
                      ISNULL(SUM(CASE WHEN [AClass_ID]=@PreAP_ID AND BI.[BillDate] BETWEEN @BeginDate AND @EndDate THEN [JdMoney] END), 0) AS [NowPreApTotal]
		FROM #Com_Account1MX_Mx AD, #Com_Account1MX_Idx BI
		WHERE BI.[BILLID]=AD.[BILLID]
		GROUP BY AD.[Class_ID],AD.[AClass_ID]
	)B  ON A.[Class_ID]=B.[Class_ID] 
	GROUP BY B.[AClass_ID]




	----汇总插入  
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 104, 2001 as BillType,'',IsNull(NowArToTal,0) as Total FROM #Com_Account1MX WHERE AClass_ID=@AR_ID
	UNION ALL
	SELECT 104, 2002 as BillType,'',IsNull(NowApToTal,0) as Total FROM #Com_Account1MX WHERE AClass_ID=@AP_ID
	UNION ALL
	SELECT 104, 2003 as BillType,'',IsNull(NowPreArToTal,0) as Total FROM #Com_Account1MX WHERE AClass_ID=@PreAR_ID
	UNION ALL
	SELECT 104, 2004 as BillType,'',IsNull(NowPreApToTal,0) as Total FROM #Com_Account1MX WHERE AClass_ID=@PreAP_ID


----9----
/*************收款单、付款单*************/
	set @szBusinessType='0'  
	set @szBillType='10,11,18,16,17,112,32'
	declare @skflag int,
		@szBillTypeBuy varchar(100),
		@s varchar(200)
	set @skflag=0 --如果要按照收款日期那查询，请将此处@skflag值设为1
	set @szBillTypeBuy='20,21,28,24,25,122,35'
	set @s=@szBillType+','+@szBillTypeBuy
	
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account2MX_Idx'))    drop table #Com_Account2MX_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_Account2MX_Mx'))    drop table #Com_Account2MX_Mx
	SELECT [BillID], convert(varchar(10),billdate,20) as [BillDate], BillType, YsMoney, JsYe, SkDate 
	INTO #Com_Account2MX_Idx
	FROM billidx
	WHERE (@skflag=1 or [Billdate] BETWEEN @BeginDate AND @EndDate) 
	  AND [Billdate]>0
	  AND [BillStates]=0
	  AND [YsMoney] <> 0 
	  AND [BillType] IN (select [type] from dbo.DecodeStr(@s)) 
	  AND [C_ID] IN (SELECT Client_ID FROM dbo.AuthorizeClients(@OperatorID) UNION SELECT '') 
	  AND (@skflag=0 or @skflag=1 and [skdate] BETWEEN @BeginDate AND @EndDate--between CONVERT(VARCHAR(10), @BeginDate, 20) and CONVERT(VARCHAR(10), @EndDate, 20)
	      ) 
	      
	select billid as invoicebillid,max(jsFlag) as jsflagType
	into #Com_Account2MX_Mx
	from vw_j_invoice 
	where billid in (select billid from #Com_Account2MX_Idx)
	group by billid


	SELECT [BillID], [Billtype], [BillDate], SUM(YsMoney)-SUm(JsYE) AS SkMoney
	INTO #Com_Account2MX
	FROM 
	(
		SELECT 
			bidx.[BillID],        bidx.[Billtype],  CONVERT(VARCHAR(10), bidx.[Billdate], 20) AS [BillDate], bidx.[SKDate],
			CASE WHEN bidx.[BillType] in (24,25,11,21) THEN -bidx.[Ysmoney] ELSE bidx.[Ysmoney] END AS [YsMoney],
			CASE WHEN bidx.[BillType] in (24,25,11,21) THEN -bidx.[JsYE] ELSE bidx.[JsYE] END AS [JsYE]
		FROM #Com_Account2MX_Idx  bidx
		left join #Com_Account2MX_Mx as iv on bidx.billid= iv.invoicebillid   
        )  BI
	GROUP BY [BillID], [Billtype], [BillDate]

	----汇总插入 
	----收款金额
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  104, 2101,
		'',
		ISNULL(SUM([SkMoney]),0) AS [Total]
	FROM #Com_Account2MX
	WHERE [BillType] IN (select [type] from dbo.DecodeStr(@szBillType)) 
	----付款金额
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT  104, 2102,
		'',
		ISNULL(SUM([SkMoney]),0) AS [Total]
	FROM #Com_Account2MX
	WHERE [BillType] IN (select [type] from dbo.DecodeStr(@szBillTypeBuy)) 





----10----
/*************现金费用单、一般费用单、其它收入单*************/
	set @szBusinessType='0'  
	set @szBillType='60,61,62'

	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 104, BillType, '', SUM(YsMoney) AS YsMoney
	FROM BILLIDX
        WHERE [Billdate] BETWEEN @BeginDate AND @EndDate 
	  AND [Billstates]='0' 
  	  AND [Billtype] in (SELECT Type FROM DBO.DecodeStr(@szBillType)) 
	GROUP BY BillType


----11----
/*************入库金额（净额）*************/
	--入库金额(净额)=采购金额[20] - 采购退货金额[21] + (-)采购换货金额[28] + 其它入库金额[48] - 其它出库金额[49] + 获赠金额[47]

	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 101, 1021,'',SUM(Total)
	FROM (
		SELECT  BillType, 
			Total=CASE WHEN BillType IN (20,48,47) THEN ABS(Total)
				   WHEN BillType IN (21,49) THEN -ABS(Total)
				   WHEN BillType IN (28) THEN Total
				   ELSE 0 END
		FROM #Com_Total
	) A

----12----
/*************销售金额（净额）*************/
	--销售金额(净额)=销售金额[10,12] - 销售退货金额[11,13] + (-)销售换货金额[18] + 其它入库金额[48] - 其它出库金额[49] + 赠送金额[46]

	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 102, 1013,'',SUM(Total)
	FROM (
		SELECT  BillType, 
			Total=CASE WHEN BillType IN (10,12,48,47) THEN ABS(Total)
				   WHEN BillType IN (11,13,49) THEN -ABS(Total)
				   WHEN BillType IN (18) THEN Total
				   ELSE 0 END
		FROM #Com_Total
	) A




----13----
/*************资产、负债、利润*************/
	if exists(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#temp_Account'))         drop table #temp_Account     
	create table #temp_Account
	(
		Account_id Int,
		class_id  varchar(30),
		Serial_number varchar(100),
		Name varchar(100),
		Child_Number int,
		BeginJDMoney   float,
		CurJDMoney   float,
		EndJDMoney float,
		IniTotal float,
		CurTotal float
	)
    /*
	if not exists(select billdate from BoxUpAccountTotal where billdate = CONVERT(VARCHAR(10), @EndDate, 20))
	begin
		insert into #temp_Account(Account_id,class_id,Serial_number,Name,Child_Number,BeginJDMoney,CurJDMoney,EndJDMoney,IniTotal,CurTotal)
		--exec TS_X_RepSubjectZcfz 5, 1, @OperatorID, 0, 0, @BeginDate, @EndDate, 0, -1, 0, 0, 0
		exec TS_X_RepSubjectZcfz 5, 1, null, 0, 0, '1950-01-01', @EndDate, 0, null, 0, 0, 0	--（【任务Id：20247】结束时间为止的值，并非时间区间的值）；
		

		INSERT INTO BoxUpAccountTotal(BillDate, TypeId, Total)
		SELECT CONVERT(VARCHAR(10), @EndDate, 20), 2201, EndJDMoney
		FROM #temp_Account
		WHERE class_id='000001'	--资产
		UNION ALL
		SELECT CONVERT(VARCHAR(10), @EndDate, 20), 2202, EndJDMoney
		FROM #temp_Account
		WHERE class_id='000002'	--负债
		UNION ALL
		SELECT CONVERT(VARCHAR(10), @EndDate, 20), 2203, EndJDMoney
		FROM #temp_Account
		WHERE class_id='000005000004'	--利润
	end
	
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 105, 2201,'资产合计', Total
	FROM BoxUpAccountTotal
	WHERE TypeId=2201	--资产
	  AND BillDate=CONVERT(VARCHAR(10), @EndDate, 20)
	UNION ALL
	SELECT 105, 2202,'负债合计', Total
	FROM BoxUpAccountTotal
	WHERE TypeId=2202	--负债
	  AND BillDate=CONVERT(VARCHAR(10), @EndDate, 20)
	UNION ALL
	SELECT 105, 2203,'利润合计', Total
	FROM BoxUpAccountTotal
	WHERE TypeId=2203	--利润
	  AND BillDate=CONVERT(VARCHAR(10), @EndDate, 20)
    */





----14----
/*************库存金额*************/
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 103, 3000+s_id,'库存金额('+SName+')',SUM(ISNULL([CostTotal], 0.0)) AS [CostTotal] 
        --FROM VW_X_StoreHouseNew 
        FROM VW_C_Storehouse
	WHERE  S_ID IN (SELECT Storage_ID FROM AuthorizeStorage(@OperatorID))   
	  AND (isnull(quantity,0) <> 0 or isnull(CostTotal,0)<>0)
	GROUP BY s_id,SName
	ORDER BY s_id


----15----
/*************现金银行金额*************/
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 104, 4000+account_id,
		CASE WHEN Class_id like '000001000004%' THEN '银行金额('+[name]+')' ELSE [name] END,
		Cur_Total 
	FROM Account 
	WHERE (class_id like '000001000003%' OR class_id like '000001000004%')
	  AND child_number=0




----16----
/*************销售回款金额、回款毛利金额*************/
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHK_Idx'))    drop table #Com_SaleHK_Idx
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHK_Xsd'))    drop table #Com_SaleHK_Xsd
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHK_Idx2'))    drop table #Com_SaleHK_Idx2
	if exists(select [name] from tempdb..sysobjects where id = object_id('tempdb.dbo.#Com_SaleHK_Mx'))    drop table #Com_SaleHK_Mx
	select max(skd_bid) as skd_bid,d.xsd_bid
	into #Com_SaleHK_Idx
	from billidx a left join 
	     (Select skd_bid,xsd_bid from jspdetail group by xsd_bid,skd_bid) d on a.billid=d.skd_bid
	where a.billtype=15
	  and billdate between @BeginDate and @EndDate
	  and a.jsflag='p'
	group by d.xsd_bid
	
	select xsd_bid 
	into #Com_SaleHK_Xsd
	from (select skd_bid,xsd_bid from jsbdetail union 
	      select skd_bid,xsd_bid from jspdetail
	) a 
	where skd_bid in (select billid 
					from billidx 
					where billtype =15 
					--and billdate between @Begindate and @Enddate
					)
					

     /*****************************  2013-07-22 #EmpSaleTc_JS begin ******************************/
	select xsd_bid,SUM(b.ysmoney) As ysmoney,0 as costmoney  
	into #Com_SaleHKskd
	from billidx b left join jsbdetail j on b.billid=j.skd_bid 
	where b.billtype=15
	  and b.billstates=0
	  and jsflag='b'
	  --and j.jstotal=j.remaintotal
	  and billdate between @BeginDate and @EndDate
	  and xsd_bid in (select billid from billidx where billtype In (10,11,12,13,16,17,18,32,112) and billstates=0 and jsye<=0 )
          group by xsd_bid
	--以上是统计的“本单收款+收款单收款”
	--以下是仅统计的“本单收款”
	UNION ALL
	select billid,ysmoney,0 as costmoney 
	from billidx
	where  ssmoney>=ysmoney
	  AND billstates=0 
	  and jsflag='b'
	  and jsye<=0
	  and billdate between @BeginDate and @EndDate
	  AND Billtype In (10,11,12,13,16,17,18,32,112) 
	--以下是仅统计的“按行收款”
	UNION ALL
	select xsd_bid,sum(jstotal) as jstotal,sum(costmoney) as costmoney 
	from (
		select xsd_bid,detail_id,sum(jstotal) as jstotal,max(totalmoney) as totalmoney,max(costmoney) as costmoney
		from (
			select j.xsd_bid,jp.detail_id,jp.jstotal,sb.totalmoney,sb.quantity*sb.costprice as costmoney
			from #Com_SaleHK_Idx j 
			left join jspdetail jp on j.xsd_bid=jp.xsd_bid
	        left join salemanagebill sb on jp.detail_id=sb.smb_id --and (sb.rootp_id=0 or sb.rootp_id>0 and sb.rootp_id=sb.parentp_id)
			where jp.skd_bid<=j.skd_bid
			  and jstotal>=totalmoney
		) a
		group by xsd_bid,detail_id
	) a 
	--where jstotal>=totalmoney
	group by xsd_bid
	
	select billid--, E_id, EClass_ID
	into #Com_SaleHK_Idx2
	from billidx --vw_x_billidx 
	where billstates=0 and jsye<=0 --billtype in (10,11,12,13,16,17,18,32,112)and 
	and ((billdate between @begindate and @enddate and
	 (billtype in (10,11,12,13,16,17,18,32,112) 
	and (ssmoney>=ysmoney))) or 
		(billid in (select xsd_bid from #Com_SaleHK_Xsd
			)))
	
	select bill_id as bill_id,iotag,sum(totalmoney) as totalmoney,costmoney=sum(quantity*costprice) 
	into #Com_SaleHK_Mx
    from salemanagebill 
    where bill_id in (select [xsd_bid] from #Com_SaleHKskd)
    group by bill_id,iotag  



	                     SELECT  [hkMoney]   = SUM(CASE WHEN(PD.[AClass_Id] = '000001000003'              --结算:多账户收款  
				                                 OR PD.[AClass_Id] = '000002000007'
 								 OR PD.[AClass_Id] = '000002000006'           
								 OR PD.[AClass_Id] LIKE '000001000004%')                                              
						            THEN jdMoney ELSE 0.0 END),
				     [CostTotal] = SUM(CASE WHEN PD.[AClass_Id] = '000004000001' THEN jdMoney ELSE 0.0 END),
				     [mlTotal]   = SUM(CASE WHEN PD.[AClass_Id] = '000003000001' THEN jdMoney ELSE 0.0 END) - 
						   SUM(CASE WHEN PD.[AClass_Id] in ('000004000001','000004000002000002') THEN jdMoney ELSE 0.0 END),
					JsmlTotal =0,
				     [zrTotal]   = 0
                             INTO #Com_SaleHK
			     FROM VW_X_ADETAIL PD                          
			     JOIN #Com_SaleHK_Idx2 bi ON  PD.[billid] = bi.[Billid]      
			     WHERE 1=1 and (
                                   PD.[AClass_Id]  = '000001000003' OR 
				   PD.[AClass_Id] like '000001000004%' OR 
				   PD.[ACLASS_ID] = '000002000007' or --储值账户
				   PD.[ACLASS_ID] = '000002000006' or --预收账户
				   PD.[AClass_Id] = '000004000001' OR
				   PD.[AClass_Id] = '000003000001' --收入    
				   OR  PD.[AClass_Id] = '000004000003000004' --折让    --为了职员折让后金额或毛利提成而加折让金额   add by zhangtao 2011-10-24                                   
                                   )
		             --GROUP BY bi.[E_id],bi.[EClass_ID]

		             
 	                     UNION ALL   
	  		     SELECT  SUM(skmx.jsTotal) as hkMoney,0,0,0,ISNULL(SUM(ad.jdmoney),0) as ZRTOTAL
			     FROM billidx sk                                                     
			     JOIN (
				   SELECT skd_bid,xsd_bid, jstotal FROM jsbdetail 
				   UNION  ALL
				   SELECT skd_bid,xsd_bid, jstotal FROM jspdetail) skmx 
			     ON sk.[billid] = skmx.[skd_bid]
			     JOIN billidx bi on bi.[billid] = skmx.[xsd_bid]
			     LEFT JOIN (select billid,jdmoney from AccountDetail where a_id=59) ad on ad.billid=sk.billid
 			     WHERE 1=1
				   and sk.billdate BETWEEN @BeginDate AND @EndDate 
			       AND sk.billstates = 0
			       and bi.billstates = 0
			       and bi.billtype in (10,11,12,13,16,17,18,32,112)
			       and sk.billtype in (15)
	  			and xsd_bid in (select billid from billidx where billtype In (10,11,12,13,16,17,18,32,112) and billstates=0 and jsye<=0 )
			     --GROUP BY bi.[e_id],bi.[EClass_ID],BI.YSMONEY  


			     UNION ALL
			     SELECT [hkMoney] = 0,[CostTotal] = 0,[mlTotal]   = 0,
				   [jsmltotal] = sum(ISNULL(JSML.[jsmlTotal],0)) ,ZSTOTAL=0
			     FROM (         
 				    	SELECT jsmlTotal= SUM(mlTotal)
					FROM  
					(
						select mlTotal = CASE WHEN (BillType IN (11,13)  AND Billstates IN (0,1)) 
									     OR (BillType in (18) AND iotag = 0 AND Billstates IN (0,1))
									     OR (BillType in (18) AND iotag = 1 AND Billstates IN (4))
									     OR (BillType in (17) AND Billstates IN (0,1))
									     OR (Billstates = 4 AND BillType not in (11,13,18,17))
									  THEN 
                                                 CASE WHEN a.costmoney=0 THEN -(b.ysmoney - mx.costmoney) 
                                                                       ELSE -(a.ysmoney -  a.costmoney)
                                                 END
									  ELSE 
                                                 CASE WHEN a.costmoney=0 THEN b.ysmoney- mx.costmoney 
                                                                       ELSE a.ysmoney-  a.costmoney 
                                                 END
                                     END
						from 
						(
							select xsd_bid,sum(ysmoney) as ysmoney,sum(costmoney) as costmoney 
							from #Com_SaleHKskd  
							group by xsd_bid
						) a 
						left join billidx b on a.xsd_bid=b.billid
						left join  #Com_SaleHK_Mx mx ON a.[xsd_bid] = mx.[Bill_ID]   
					 )  T 
		                   
                             ) JSML 	
 	         

	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 102, 1201, '毛利金额', SUM(MLTOTAL)
	FROM #Com_SaleHK
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 102, 1202, '回款金额', SUM(HKMONEY)-SUM(ZRTOTAL)
	FROM #Com_SaleHK
	INSERT INTO #Com_Total(PageIndex, BillType, [Name], Total)
	SELECT 102, 1203, '回款毛利金额', SUM(JSMLTOTAL)-SUM(ZRTOTAL)
	FROM #Com_SaleHK


UPDATE #Com_Total SET [NAME]='采购金额'		WHERE BILLTYPE=20
UPDATE #Com_Total SET [NAME]='采购退货金额'	WHERE BILLTYPE=21
UPDATE #Com_Total SET [NAME]='采购换货金额'	WHERE BILLTYPE=28
UPDATE #Com_Total SET [NAME]='获赠金额'		WHERE BILLTYPE=47
UPDATE #Com_Total SET [NAME]='其它入库金额'	WHERE BILLTYPE=48
UPDATE #Com_Total SET [NAME]='借进转采购金额'	WHERE BILLTYPE=35
UPDATE #Com_Total SET [NAME]='受托代销金额'	WHERE BILLTYPE=122
UPDATE #Com_Total SET [NAME]='入库金额（净额）'	WHERE BILLTYPE=1021
UPDATE #Com_Total SET [NAME]='采购订货金额'	WHERE BILLTYPE=1022
UPDATE #Com_Total SET [NAME]='采订到货金额'	WHERE BILLTYPE=1023
UPDATE #Com_Total SET [NAME]='采订未到货金额'	WHERE BILLTYPE=1024
UPDATE #Com_Total SET [NAME]='销售金额'		WHERE BILLTYPE=1000
UPDATE #Com_Total SET [NAME]='销售退货金额'	WHERE BILLTYPE=1001
UPDATE #Com_Total SET [NAME]='销售换货金额'	WHERE BILLTYPE=18
UPDATE #Com_Total SET [NAME]='赠送金额'		WHERE BILLTYPE=46
UPDATE #Com_Total SET [NAME]='其它出库金额'	WHERE BILLTYPE=49
UPDATE #Com_Total SET [NAME]='借出转销售金额'	WHERE BILLTYPE=32
UPDATE #Com_Total SET [NAME]='委托代销金额'	WHERE BILLTYPE=112
UPDATE #Com_Total SET [NAME]='销售金额（净额）'	WHERE BILLTYPE=1013
UPDATE #Com_Total SET [NAME]='销售订货金额'	WHERE BILLTYPE=1014
UPDATE #Com_Total SET [NAME]='销售出货金额'	WHERE BILLTYPE=1015
UPDATE #Com_Total SET [NAME]='销售未出货金额'	WHERE BILLTYPE=1016
UPDATE #Com_Total SET [NAME]='毛利金额'		WHERE BILLTYPE=1201
UPDATE #Com_Total SET [NAME]='回款金额'		WHERE BILLTYPE=1202
UPDATE #Com_Total SET [NAME]='回款毛利金额'	WHERE BILLTYPE=1203
UPDATE #Com_Total SET [NAME]='借出金额'		WHERE BILLTYPE=30
UPDATE #Com_Total SET [NAME]='借进金额'		WHERE BILLTYPE=33
UPDATE #Com_Total SET [NAME]='借出还回金额'	WHERE BILLTYPE=31
UPDATE #Com_Total SET [NAME]='借进还出金额'	WHERE BILLTYPE=34
UPDATE #Com_Total SET [NAME]='盘点盈亏金额'	WHERE BILLTYPE=50
UPDATE #Com_Total SET [NAME]='报损金额'		WHERE BILLTYPE=41
UPDATE #Com_Total SET [NAME]='报溢金额'		WHERE BILLTYPE=42
UPDATE #Com_Total SET [NAME]='组装差价'		WHERE BILLTYPE=40
UPDATE #Com_Total SET [NAME]='成本调价金额'	WHERE BILLTYPE=43
UPDATE #Com_Total SET [NAME]='收款金额'		WHERE BILLTYPE=2101
UPDATE #Com_Total SET [NAME]='付款金额'		WHERE BILLTYPE=2102
UPDATE #Com_Total SET [NAME]='其它收入金额'	WHERE BILLTYPE=62
UPDATE #Com_Total SET [NAME]='现金费用金额'	WHERE BILLTYPE=60
UPDATE #Com_Total SET [NAME]='费用金额'		WHERE BILLTYPE=61
UPDATE #Com_Total SET [NAME]='应收金额'		WHERE BILLTYPE=2001
UPDATE #Com_Total SET [NAME]='应付金额'		WHERE BILLTYPE=2002
UPDATE #Com_Total SET [NAME]='预收金额'		WHERE BILLTYPE=2003
UPDATE #Com_Total SET [NAME]='预付金额'		WHERE BILLTYPE=2004
--UPDATE #Com_Total SET [NAME]='资产合计'		WHERE BILLTYPE=2201
--UPDATE #Com_Total SET [NAME]='负债合计'		WHERE BILLTYPE=2202
--UPDATE #Com_Total SET [NAME]='净利润'		WHERE BILLTYPE=2203


select PageIndex, BillType, [Name], Sum(Total) as Total 
from #Com_Total
group by PageIndex, BillType, [Name]
order by PageIndex, BillType


-- SUCCEE:
--    if exists(select 1 from tempdb.dbo.sysobjects where id = object_id('tempdb.dbo.#TmpTcMoney'))
--    DROP TABLE #TmpTcMoney
--    if exists(select 1 from tempdb.dbo.sysobjects where id = object_id('tempdb.dbo.#zytcRep')) drop table #zytcRep
--    RETURN 0 
-- SUCCEE1:
--    DROP TABLE #TmpTcMoneyE

   RETURN 0 
 
END
GO
