
/* =============================================*/
/* Author:		Huang.Y*/
/* Create date: 2011-5-27*/
/* Description:	商品区域保护操作*/
/* =============================================*/
CREATE PROCEDURE [dbo].[TS_H_ProductAuthAct] 
	@Act		int,				/* 操作*/
	@pid		int = 0,			/* 商品*/
	@cid		int = 0,			/* 客户*/
	@rid		int = 0,			/* 区域*/
	@Where		varchar(8000) = ''	/* 自定义条件*/
AS
BEGIN
/*Params Ini begin*/
if @pid is null  SET @pid = 0
if @cid is null  SET @cid = 0
if @rid is null  SET @rid = 0
if @Where is null  SET @Where = ''
/*Params Ini end*/
	SET NOCOUNT ON;

	if @Act = 0
	begin
		if @Where = ''
		begin
			SELECT     r.p_id, r.c_id, p.name as pname, p.alias, p.standard, CAST(ISNULL(m.name, '') AS varchar) AS mt_name, p.makearea, c.name AS customer,
						  CAST(ISNULL(g.name, '') AS varchar) AS region, p.serial_number
			FROM         dbo.ProductCustomRight AS r INNER JOIN
								  dbo.products AS p ON r.p_id = p.product_id INNER JOIN
								  dbo.clients AS c ON r.c_id = c.client_id LEFT OUTER JOIN
								  dbo.Region AS g ON c.region_id = g.region_id LEFT OUTER JOIN
								  (
										select name,P_id as baseinfo_id from customCategory a inner join ProductCategory b on a.class_id =  b.PComent3 where a.deleted = 0 
								  )m on p.product_id = m.baseinfo_id
			WHERE     (r.p_id = @pid or @pid = 0) AND (r.c_id = @cid or @cid = 0) AND 
						(c.client_id in (select client_id from clients where region_id = @rid) or @rid = 0)
		end
		else
		begin
			declare @SQL varchar(8000)
			set @SQL = 'SELECT     r.p_id, r.c_id, p.name as pname, p.alias, p.standard, CAST(ISNULL(m.name, '''') AS varchar) AS mt_name, p.makearea, c.name AS customer,
						  CAST(ISNULL(g.name, '''') AS varchar) AS region, p.serial_number
			FROM         dbo.ProductCustomRight AS r INNER JOIN
								  dbo.products AS p ON r.p_id = p.product_id INNER JOIN
								  dbo.clients AS c ON r.c_id = c.client_id LEFT OUTER JOIN
								  dbo.Region AS g ON c.region_id = g.region_id LEFT OUTER JOIN
								  (
										select name,P_id as baseinfo_id from customCategory a inner join ProductCategory b on a.class_id =  b.PComent3 where a.deleted = 0 
								  )m on p.product_id = m.baseinfo_id
			WHERE     ' + @Where
			EXEC(@SQL)
		end
	end
END
GO
